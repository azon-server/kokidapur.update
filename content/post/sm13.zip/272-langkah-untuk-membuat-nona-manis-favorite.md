---
description: "Langkah untuk membuat Nona manis Favorite"
title: "Langkah untuk membuat Nona manis Favorite"
slug: 272-langkah-untuk-membuat-nona-manis-favorite
date: 2020-11-15T16:54:05.243Z
image: https://img-global.cpcdn.com/recipes/e4bce7991067ec1d/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e4bce7991067ec1d/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e4bce7991067ec1d/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Alta Jefferson
ratingvalue: 4.2
reviewcount: 46425
recipeingredient:
- " Bahan A"
- "2 telur"
- "250 gr gula pasir butiran halus me diblender"
- "250 gr terigu"
- "500 santan kekentalan sedang"
- " Bahan B"
- "250 ml santan kekentalan sedang"
- "250 ml jus pandan 10 lembar daun pandan blender dgn 250 ml air"
- "120 gr gula pasir"
- "60 gr tepung maizena"
- "1 sdt garam"
- "1 tetes Pewarna hijau"
- " Bahan C"
- "500 ml santan kental sedang"
- "2 SDM gula pasir"
- "2 SDM terigu"
- "1/2 sdt garam"
recipeinstructions:
- "Step 1 Bahan A: pecahkan telur. Kocok lepas. Sisihkan. Masukkan terigu, gula pasir, santan aduk rata. Masuk kocokan telur. Aduk rata. Saring adonan agar tdk bergerindil. Sisihkan."
- "Step 2: Bahan B: masukkan maizena, gulpas, santan, jus pandan, pewarna 1 tetes aduk hingga rata dan licin. Nyalakan kompor, masak hingga meletup2, dgn api kecil. Nanti jadinya kental spt bubur"
- "Masukkan bahan A ke bahan B, aduk sampai rata, meletup dan licin"
- "Step 3, bahan C: api kompor jgn dinyalakan dulu. Masukkan semua bahan C ke dalam panci. Aduk rata. Nyalakan api, masak dengan api kecil hg meletup.setelah dingin masukkan ke botol kecap biar mudah memencetnya (buat ditengah)"
- "Oles cetakan dgn minyak sayur agar tdk lengket saat mengeluarkan nya"
- "Masuk bahan hijau, tuang bahan C ditengah2. Kukus kurang lebih 20 menit Sebelumnya sdh dipanaskan ya kukusannya. Tutup kukusan dilapis kain lap bersih agar uap air tidak jatuh ke adonan. Selamat mencoba moms"
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 297 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dessert

---


![Nona manis](https://img-global.cpcdn.com/recipes/e4bce7991067ec1d/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga empuk. Karasteristik makanan Indonesia nona manis yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Nona manis untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang dapat anda praktekkan salah satunya nona manis yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep nona manis tanpa harus bersusah payah.
Berikut ini resep Nona manis yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona manis:

1. Dibutuhkan  Bahan A:
1. Dibutuhkan 2 telur
1. Jangan lupa 250 gr gula pasir butiran halus (me: diblender)
1. Jangan lupa 250 gr terigu
1. Dibutuhkan 500 santan kekentalan sedang
1. Diperlukan  Bahan B:
1. Tambah 250 ml santan (kekentalan sedang)
1. Harap siapkan 250 ml jus pandan (10 lembar daun pandan blender dgn 250 ml air)
1. Dibutuhkan 120 gr gula pasir
1. Jangan lupa 60 gr tepung maizena
1. Jangan lupa 1 sdt garam
1. Dibutuhkan 1 tetes Pewarna hijau
1. Harap siapkan  Bahan C:
1. Jangan lupa 500 ml santan kental sedang
1. Jangan lupa 2 SDM gula pasir
1. Harap siapkan 2 SDM terigu
1. Harus ada 1/2 sdt garam




<!--inarticleads2-->

##### Instruksi membuat  Nona manis:

1. Step 1 Bahan A: pecahkan telur. Kocok lepas. Sisihkan. Masukkan terigu, gula pasir, santan aduk rata. Masuk kocokan telur. Aduk rata. Saring adonan agar tdk bergerindil. Sisihkan.
1. Step 2: Bahan B: masukkan maizena, gulpas, santan, jus pandan, pewarna 1 tetes aduk hingga rata dan licin. Nyalakan kompor, masak hingga meletup2, dgn api kecil. Nanti jadinya kental spt bubur
1. Masukkan bahan A ke bahan B, aduk sampai rata, meletup dan licin
1. Step 3, bahan C: api kompor jgn dinyalakan dulu. Masukkan semua bahan C ke dalam panci. Aduk rata. Nyalakan api, masak dengan api kecil hg meletup.setelah dingin masukkan ke botol kecap biar mudah memencetnya (buat ditengah)
1. Oles cetakan dgn minyak sayur agar tdk lengket saat mengeluarkan nya
1. Masuk bahan hijau, tuang bahan C ditengah2. Kukus kurang lebih 20 menit Sebelumnya sdh dipanaskan ya kukusannya. Tutup kukusan dilapis kain lap bersih agar uap air tidak jatuh ke adonan. Selamat mencoba moms




Demikianlah cara membuat nona manis yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
