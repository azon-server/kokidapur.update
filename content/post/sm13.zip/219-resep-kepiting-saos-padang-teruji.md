---
description: "Resep : Kepiting saos padang Teruji"
title: "Resep : Kepiting saos padang Teruji"
slug: 219-resep-kepiting-saos-padang-teruji
date: 2020-09-12T05:20:13.560Z
image: https://img-global.cpcdn.com/recipes/fcfe151d0dfa334a/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fcfe151d0dfa334a/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fcfe151d0dfa334a/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg
author: Emma Chapman
ratingvalue: 4.4
reviewcount: 29512
recipeingredient:
- "1 kg kepiting3 ekor uk sedang"
- "3 sdm cabe merah kering halus"
- "3 sdm cabe merah segar halusbuang biji"
- "1 buah Bawang bombayiris sesuai selera"
- "3 sdm saos tomat botol ABC"
- "3 sdm saos cabe botol ABC"
- "3 siung bawang putih cincang halus"
- "2 ruas jahe iris korek api"
- "1 sdm merica bubuk"
- " Garam gula"
- " Daun kemangi dan daun bwng"
recipeinstructions:
- "Siapkan bumbu dan bersihkan kepiting. Belah dua, kemudian rebus kira2 10 menit smpe matang. Angkat tiriskan"
- "Tumis bwg putih, tambhkan merica bubuk,cabe kering dan cabe merah halus, Tumis sampai harum kemudian masukkan saos cabe+tomat,gula,garam.tmbhkn air secukupnya masak. Hingga mendidih.. Masukkan bwg bombay iris terakhir masukkan kepiting rebus.. Aduk rata."
- "Angkat lalu taburkan dg daun bawang dan kemangi"
categories:
- Recipe
tags:
- kepiting
- saos
- padang

katakunci: kepiting saos padang 
nutrition: 140 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Lunch

---


![Kepiting saos padang](https://img-global.cpcdn.com/recipes/fcfe151d0dfa334a/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan renyah. Ciri khas kuliner Indonesia kepiting saos padang yang kaya dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Kepiting saos padang untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang dapat anda buat salah satunya kepiting saos padang yang merupakan resep favorite yang mudah dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep kepiting saos padang tanpa harus bersusah payah.
Seperti resep Kepiting saos padang yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 11 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kepiting saos padang:

1. Harus ada 1 kg kepiting(3 ekor uk. sedang)
1. Harus ada 3 sdm cabe merah kering halus
1. Harus ada 3 sdm cabe merah segar halus(buang biji)
1. Diperlukan 1 buah Bawang bombay,iris sesuai selera
1. Tambah 3 sdm saos tomat botol ABC
1. Harus ada 3 sdm saos cabe botol ABC
1. Jangan lupa 3 siung bawang putih cincang halus
1. Siapkan 2 ruas jahe iris korek api
1. Diperlukan 1 sdm merica bubuk
1. Dibutuhkan  Garam, gula
1. Dibutuhkan  Daun kemangi dan daun bwng




<!--inarticleads2-->

##### Cara membuat  Kepiting saos padang:

1. Siapkan bumbu dan bersihkan kepiting. Belah dua, kemudian rebus kira2 10 menit smpe matang. Angkat tiriskan
1. Tumis bwg putih, tambhkan merica bubuk,cabe kering dan cabe merah halus, Tumis sampai harum kemudian masukkan saos cabe+tomat,gula,garam.tmbhkn air secukupnya masak. Hingga mendidih.. Masukkan bwg bombay iris terakhir masukkan kepiting rebus.. Aduk rata.
1. Angkat lalu taburkan dg daun bawang dan kemangi




Demikianlah cara membuat kepiting saos padang yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
