---
description: "Cara singkat untuk membuat Nona manis Favorite"
title: "Cara singkat untuk membuat Nona manis Favorite"
slug: 340-cara-singkat-untuk-membuat-nona-manis-favorite
date: 2021-02-18T23:44:51.530Z
image: https://img-global.cpcdn.com/recipes/c90f5598ccbf2766/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c90f5598ccbf2766/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c90f5598ccbf2766/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Florence Silva
ratingvalue: 4.3
reviewcount: 41935
recipeingredient:
- " Bahan A"
- "140 gr terigu"
- "250 ml santan kekentalan sedang"
- "80 gr gula pasir"
- "1 biji telur"
- " Bahan B"
- "150 ml santan kekentalan sedang"
- "40 gr gula pasir"
- "100 ml jus pandan"
- "30 gr tepung maizena"
- "1/4 sendok teh garam"
- "Secukupnya pasta pandan"
- " Bahan C"
- "400 ml santan pekat"
- "5 sendok makan tepung terigu"
- "1/4 sendok teh garam"
recipeinstructions:
- "Campur semua bahan B aduk merata lalu masak dengan api sedang saja sampai kental dan sisihkan"
- "Satukan bahan C dan aduk hingga tercampur rata lalu masak dengan api sedang sampai mengental,jika sudah dingin masukkan dalam piping bag agar mudah di tuang dalam cetakan nti"
- "Buat adonan A..kocok telur dan gula sampai putih/mengembang setelah itu masukkan terigu dan santan secara bergantian hingga habis terakhir tambahkan adonan A yg sudah di masak tadi kocok hingga tercampur saja (jika warna hijaunya masih belum sempurna bisa tambahkan pasta pandan ya bun)"
- "Sebelumnya siapkan dahulu cetakan dan olesi sedikit minyak,tuang adonan hijau seprtiga cetakan saja ya bun,terus potong ujung plastik piping bag bahan C dan sumpitkan di tengah adonan hijau yang sudah ada dalam cetakan"
- "Panaskan dahulu kukusan dan masukkan kue dalam kukusan,kukus kurang lebih 10 menit lalu angkat.setelah agak dingin baru lepaskan dari cetakannya ya bun dan kue siap menemani minum teh ku..😍"
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 122 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Lunch

---


![Nona manis](https://img-global.cpcdn.com/recipes/c90f5598ccbf2766/680x482cq70/nona-manis-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti nona manis yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan keistimewahan yang merupakan keragaman Kita



Kedekatan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Nona manis untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi kultur, Banyak yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang bisa anda buat salah satunya nona manis yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona manis:

1. Tambah  Bahan A
1. Jangan lupa 140 gr terigu
1. Tambah 250 ml santan kekentalan sedang
1. Dibutuhkan 80 gr gula pasir
1. Harap siapkan 1 biji telur
1. Harus ada  Bahan B
1. Diperlukan 150 ml santan kekentalan sedang
1. Dibutuhkan 40 gr gula pasir
1. Tambah 100 ml jus pandan
1. Jangan lupa 30 gr tepung maizena
1. Diperlukan 1/4 sendok teh garam
1. Diperlukan Secukupnya pasta pandan
1. Harap siapkan  Bahan C
1. Tambah 400 ml santan pekat
1. Harus ada 5 sendok makan tepung terigu
1. Jangan lupa 1/4 sendok teh garam




<!--inarticleads2-->

##### Langkah membuat  Nona manis:

1. Campur semua bahan B aduk merata lalu masak dengan api sedang saja sampai kental dan sisihkan
1. Satukan bahan C dan aduk hingga tercampur rata lalu masak dengan api sedang sampai mengental,jika sudah dingin masukkan dalam piping bag agar mudah di tuang dalam cetakan nti
1. Buat adonan A..kocok telur dan gula sampai putih/mengembang setelah itu masukkan terigu dan santan secara bergantian hingga habis terakhir tambahkan adonan A yg sudah di masak tadi kocok hingga tercampur saja (jika warna hijaunya masih belum sempurna bisa tambahkan pasta pandan ya bun)
1. Sebelumnya siapkan dahulu cetakan dan olesi sedikit minyak,tuang adonan hijau seprtiga cetakan saja ya bun,terus potong ujung plastik piping bag bahan C dan sumpitkan di tengah adonan hijau yang sudah ada dalam cetakan
1. Panaskan dahulu kukusan dan masukkan kue dalam kukusan,kukus kurang lebih 10 menit lalu angkat.setelah agak dingin baru lepaskan dari cetakannya ya bun dan kue siap menemani minum teh ku..😍




Demikianlah cara membuat nona manis yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
