---
description: "Panduan membuat Ayam Pop Khas Padang minggu ini"
title: "Panduan membuat Ayam Pop Khas Padang minggu ini"
slug: 81-panduan-membuat-ayam-pop-khas-padang-minggu-ini
date: 2020-10-02T20:29:46.645Z
image: https://img-global.cpcdn.com/recipes/d058bbd7805ae396/680x482cq70/ayam-pop-khas-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d058bbd7805ae396/680x482cq70/ayam-pop-khas-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d058bbd7805ae396/680x482cq70/ayam-pop-khas-padang-foto-resep-utama.jpg
author: Cornelia Rhodes
ratingvalue: 4.2
reviewcount: 23860
recipeingredient:
- "1/2 kg ayam saya pakai bagian paha atas bawah cuci bersih"
- "1 buah jeruk nipis peras untuk marinasi"
- "1 sdm margarine"
- "500 ml air kelapa bisa diganti hydrococo apabila tidak ada"
- "1 sachet kaldu ayam bubuk"
- "  2 sdt garam sesuai selera"
- "Secukupnya sambal ijo           lihat resep"
- " Bahan Bumbu Halus"
- "3 butir bawang merah"
- "5 siung bawang putih"
- "3 butir kemiri sangrai"
- "1 cm jahe"
- "1 sdt lada bubuk"
- " Bahan Bumbu Utuh"
- "2 batang sereh geprek"
- "3 lembar daun salam sobek"
- "3 lembar daun jeruk sobek"
- "1 cm jahe geprek"
- "Sejempol lengkuas geprek"
recipeinstructions:
- "Marinasi ayam dengan perasan air jeruk nipis ± minimal 15 menit. Cuci bersih, tiriskan."
- "Panaskan minyak goreng dengan api kecil. Tumis bumbu halus dan bumbu utuh hingga matang dan harum. Masukkan ayam, aduk sambil dibalur."
- "Tambahkan air kelapa, kaldu ayam bubuk, dan garam. Ungkep dengan api kecil ± 50-60 menit. Tes rasa dan dinginkan sebentar."
- "Panaskan minyak dan margarine dengan api sedang. Goreng ungkepan ayam pop sebentar saja ± 10-15 detik setiap sisi. Tiriskan di piring saji. Sajikan dengan sambal ijo masakan padang, siap santap ❤           (lihat resep)"
categories:
- Recipe
tags:
- ayam
- pop
- khas

katakunci: ayam pop khas 
nutrition: 128 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Pop Khas Padang](https://img-global.cpcdn.com/recipes/d058bbd7805ae396/680x482cq70/ayam-pop-khas-padang-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan renyah. Ciri masakan Nusantara ayam pop khas padang yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam Pop Khas Padang untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang bisa anda buat salah satunya ayam pop khas padang yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep ayam pop khas padang tanpa harus bersusah payah.
Seperti resep Ayam Pop Khas Padang yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Pop Khas Padang:

1. Jangan lupa 1/2 kg ayam (saya pakai bagian paha atas bawah, cuci bersih)
1. Harus ada 1 buah jeruk nipis (peras untuk marinasi)
1. Tambah 1 sdm margarine
1. Diperlukan 500 ml air kelapa (bisa diganti hydrococo apabila tidak ada)
1. Tambah 1 sachet kaldu ayam bubuk
1. Harus ada  ± 2 sdt garam (sesuai selera)
1. Diperlukan Secukupnya sambal ijo           (lihat resep)
1. Dibutuhkan  Bahan Bumbu Halus
1. Harap siapkan 3 butir bawang merah
1. Tambah 5 siung bawang putih
1. Siapkan 3 butir kemiri sangrai
1. Jangan lupa 1 cm jahe
1. Harus ada 1 sdt lada bubuk
1. Harap siapkan  Bahan Bumbu Utuh
1. Harap siapkan 2 batang sereh (geprek)
1. Harap siapkan 3 lembar daun salam (sobek)
1. Jangan lupa 3 lembar daun jeruk (sobek)
1. Siapkan 1 cm jahe (geprek)
1. Dibutuhkan Sejempol lengkuas (geprek)




<!--inarticleads2-->

##### Cara membuat  Ayam Pop Khas Padang:

1. Marinasi ayam dengan perasan air jeruk nipis ± minimal 15 menit. Cuci bersih, tiriskan.
1. Panaskan minyak goreng dengan api kecil. Tumis bumbu halus dan bumbu utuh hingga matang dan harum. Masukkan ayam, aduk sambil dibalur.
1. Tambahkan air kelapa, kaldu ayam bubuk, dan garam. Ungkep dengan api kecil ± 50-60 menit. Tes rasa dan dinginkan sebentar.
1. Panaskan minyak dan margarine dengan api sedang. Goreng ungkepan ayam pop sebentar saja ± 10-15 detik setiap sisi. Tiriskan di piring saji. Sajikan dengan sambal ijo masakan padang, siap santap ❤ -           (lihat resep)




Demikianlah cara membuat ayam pop khas padang yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
