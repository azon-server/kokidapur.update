---
description: "Resep : Kue Nona Manis Cepat"
title: "Resep : Kue Nona Manis Cepat"
slug: 268-resep-kue-nona-manis-cepat
date: 2021-01-23T16:38:17.148Z
image: https://img-global.cpcdn.com/recipes/352743cf29b37910/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/352743cf29b37910/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/352743cf29b37910/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Wayne Jensen
ratingvalue: 4.9
reviewcount: 20648
recipeingredient:
- " Isian Santan "
- "250 ml santan kental me 50G santan bubuk  air sampai 250ml"
- "20 gram tepung terigu me segitiga"
- "15 gram gula pasir"
- "1/2 sdt garam"
- " Bahan Hijau "
- "125 ml santan kental sedang me 35G stbubuk  air sampai 125ml"
- "125 ml air jus dari 3 lembar daun pandan"
- "1/4 sdt pasta pandan me radbell"
- "55 gram gula pasir"
- "30 gram tepung maizena"
- "1/4 sdt garam"
- " Bahan Putih "
- "1 butir telur ayam"
- "90 gram gula pasir"
- "250 ml santan kental me 50G santan bubuk  air sampai 250ml"
- "145 gram tepung terigu me Segitiga"
recipeinstructions:
- "🌸 ISIAN SANTAN : takar atau buat SANTAN nya dulu, aduk rata. Masukkan semua bahan, aduk dahulu sampai rata pada api kecil, baru naikkan api ke sedang, aduk sampai meletup-letup, sisihkan"
- "Biarkan hangat lalu masukkan ke pipping bag / saya pakai suntikkan"
- "🌸 BAHAN HIJAU : takar atau buat SANTAN, aduk rata"
- "Jus DAUN PANDAN yang dipotong-potong. Saya jus bertahap sedikit-sedikit karena saya pakai grinder, saya tetap pakai 125ml air bertahap pakai nya. Jika air habis, saya ambil lagi air hasil jus pertama"
- "Saring &amp; masukkan ke santan tadi. Tambahkan PASTA, aduk rata."
- "Timbang MAIZENA di panci, masukkan air santan+pandan tadi. Masak dengan api sedang-kecil sampai mengental &amp; meletup-letup, sisihkan"
- "🌸 BAHAN PUTIH : mixer TELUR dengan GULA sampai mengembang. Campur TERIGU dan SANTAN (untuk SANTAN caranya sama seperti di atas ya). Lalu campur semua menjadi satu wadah, mixer sampai rata"
- "🌸 Campur BAHAN PUTIH dengan BAHAN HIJAU, mixer sampai rata"
- "Siapkan cetakkan yang diolesi minyak dahulu, tuang ¾ bagian saja. Tata di kukusan sambil didihkan air untuk mengukus"
- "Suntikkan ISIAN SANTAN ke tengah adonan, jangan terlalu dalam, sampai agak penuh. Kukus selama 15 menit dalam api sedang, saya tumpuk jadi agak lama lagi."
- "Teksturnya lembut dan lumer dalam nya"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 148 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Dinner

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/352743cf29b37910/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang harus kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti kue nona manis yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Indonesia

Kedekatan rumah tangga bisa ditemukan dengan cara sederhana. Diantaranya adalah memasak Kue Nona Manis untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang dapat anda coba salah satunya kue nona manis yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 bahan dan 11 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis:

1. Tambah  Isian Santan :
1. Tambah 250 ml santan kental (me 50G santan bubuk + air sampai 250ml)
1. Siapkan 20 gram tepung terigu (me segitiga)
1. Tambah 15 gram gula pasir
1. Diperlukan 1/2 sdt garam
1. Harus ada  Bahan Hijau :
1. Harap siapkan 125 ml santan kental sedang (me 35G st.bubuk + air sampai 125ml)
1. Tambah 125 ml air jus dari 3 lembar daun pandan
1. Jangan lupa 1/4 sdt pasta pandan (me radbell)
1. Harus ada 55 gram gula pasir
1. Jangan lupa 30 gram tepung maizena
1. Harus ada 1/4 sdt garam
1. Harap siapkan  Bahan Putih :
1. Siapkan 1 butir telur ayam
1. Harus ada 90 gram gula pasir
1. Diperlukan 250 ml santan kental (me 50G santan bubuk + air sampai 250ml)
1. Harap siapkan 145 gram tepung terigu (me Segitiga)




<!--inarticleads2-->

##### Instruksi membuat  Kue Nona Manis:

1. 🌸 ISIAN SANTAN : takar atau buat SANTAN nya dulu, aduk rata. Masukkan semua bahan, aduk dahulu sampai rata pada api kecil, baru naikkan api ke sedang, aduk sampai meletup-letup, sisihkan
1. Biarkan hangat lalu masukkan ke pipping bag / saya pakai suntikkan
1. 🌸 BAHAN HIJAU : takar atau buat SANTAN, aduk rata
1. Jus DAUN PANDAN yang dipotong-potong. Saya jus bertahap sedikit-sedikit karena saya pakai grinder, saya tetap pakai 125ml air bertahap pakai nya. Jika air habis, saya ambil lagi air hasil jus pertama
1. Saring &amp; masukkan ke santan tadi. Tambahkan PASTA, aduk rata.
1. Timbang MAIZENA di panci, masukkan air santan+pandan tadi. Masak dengan api sedang-kecil sampai mengental &amp; meletup-letup, sisihkan
1. 🌸 BAHAN PUTIH : mixer TELUR dengan GULA sampai mengembang. Campur TERIGU dan SANTAN (untuk SANTAN caranya sama seperti di atas ya). Lalu campur semua menjadi satu wadah, mixer sampai rata
1. 🌸 Campur BAHAN PUTIH dengan BAHAN HIJAU, mixer sampai rata
1. Siapkan cetakkan yang diolesi minyak dahulu, tuang ¾ bagian saja. Tata di kukusan sambil didihkan air untuk mengukus
1. Suntikkan ISIAN SANTAN ke tengah adonan, jangan terlalu dalam, sampai agak penuh. Kukus selama 15 menit dalam api sedang, saya tumpuk jadi agak lama lagi.
1. Teksturnya lembut dan lumer dalam nya




Demikianlah cara membuat kue nona manis yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
