---
description: "Resep : Kue Nona Manis Teruji"
title: "Resep : Kue Nona Manis Teruji"
slug: 273-resep-kue-nona-manis-teruji
date: 2021-01-24T17:41:27.300Z
image: https://img-global.cpcdn.com/recipes/97af75d16f67936d/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/97af75d16f67936d/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/97af75d16f67936d/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Chad Lloyd
ratingvalue: 4.4
reviewcount: 35938
recipeingredient:
- " Bahan A "
- "40 g BOLA Deli Tepung Beras"
- "100 g BOLA Salju Tepung Terigu"
- "250 ml santan sedang"
- "90 g gula pasir"
- "1 btr telur"
- " Bahan B "
- "150 ml santan sedang"
- "50 ml jus daun pandan"
- "50 g gula pasir"
- "30 g BOLA Deli Maizena"
- "1/2 sdt garam"
- "2 tetes pasta pandan"
- " Bahan C "
- "500 ml santan sedang"
- "60 g BOLA Deli Tepung Beras"
- "1/2 sdt garam"
recipeinstructions:
- "Campurkan semua bahan B, aduk rata lalu masak dengan api kecil hingga meletup-letup dan sisihkan."
- "Siapkan bahan A, aduk telur dan gula hingga mengental, tambahkan santan sedang dan BOLA Deli Tepung Beras bergantian dengan BOLA Deli Tepung Terigu."
- "Campurkan adonan A dengan adonan B lalu aduk rata hingga tidak ada yang menggumpal."
- "Campurkan semua bahan C dengan api kecil hingga mengental. Dinginkan dan masukkan ke dalam plastik segitiga."
- "Taruh campuran bahan A dan B ke dalam cetakan kemudian masukkan bahan C di tengah cetakan."
- "Kukus kue selama 15 menit. Angkat dan hidangkan."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 114 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Dessert

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/97af75d16f67936d/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang harus kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti kue nona manis yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Nusantara

Kedekatan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Kue Nona Manis untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang dapat anda contoh salah satunya kue nona manis yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Siapkan  Bahan A :
1. Diperlukan 40 g BOLA Deli Tepung Beras
1. Jangan lupa 100 g BOLA Salju Tepung Terigu
1. Siapkan 250 ml santan sedang
1. Tambah 90 g gula pasir
1. Tambah 1 btr telur
1. Harus ada  Bahan B :
1. Dibutuhkan 150 ml santan sedang
1. Jangan lupa 50 ml jus daun pandan
1. Tambah 50 g gula pasir
1. Tambah 30 g BOLA Deli Maizena
1. Diperlukan 1/2 sdt garam
1. Jangan lupa 2 tetes pasta pandan
1. Dibutuhkan  Bahan C :
1. Harus ada 500 ml santan sedang
1. Jangan lupa 60 g BOLA Deli Tepung Beras
1. Diperlukan 1/2 sdt garam




<!--inarticleads2-->

##### Instruksi membuat  Kue Nona Manis:

1. Campurkan semua bahan B, aduk rata lalu masak dengan api kecil hingga meletup-letup dan sisihkan.
1. Siapkan bahan A, aduk telur dan gula hingga mengental, tambahkan santan sedang dan BOLA Deli Tepung Beras bergantian dengan BOLA Deli Tepung Terigu.
1. Campurkan adonan A dengan adonan B lalu aduk rata hingga tidak ada yang menggumpal.
1. Campurkan semua bahan C dengan api kecil hingga mengental. Dinginkan dan masukkan ke dalam plastik segitiga.
1. Taruh campuran bahan A dan B ke dalam cetakan kemudian masukkan bahan C di tengah cetakan.
1. Kukus kue selama 15 menit. Angkat dan hidangkan.




Demikianlah cara membuat kue nona manis yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
