---
description: "Resep : Kue Nona Manis Homemade"
title: "Resep : Kue Nona Manis Homemade"
slug: 311-resep-kue-nona-manis-homemade
date: 2020-11-10T05:33:46.678Z
image: https://img-global.cpcdn.com/recipes/859d2c767bd48223/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/859d2c767bd48223/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/859d2c767bd48223/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Charlie Haynes
ratingvalue: 4.8
reviewcount: 40138
recipeingredient:
- " Bahan 1"
- "500 ml santan kental"
- "6 sdm terigu"
- "Sejumput garam"
- " Bahan 2"
- "250 ml santan kental"
- "40 g gula pasir 2 sdm"
- "30 g maizena 25 sdm"
- "1 sdt pasta pandan secukupnya"
- "Sejumput garam"
- " Bahan 3"
- "250 ml santan kental"
- "1 butir telur"
- "80 g gula pasir 4 sdm"
- "140 g terigu 1 gelas belimbing  1 sdm munjung"
recipeinstructions:
- "Siapkan cetakan, olesi minyak goreng tipis-tipis, sisihkan"
- "Bahan 1 (adonan putih), masak semua bahan 1 dengan api kecil, sampai beruap dan meletup-letup, matikan kompor, aduk terus sampai adonan kental, halus dan tidak bergerindil, angkat dan biarkan dingin"
- "Masukkan adonan putih kedalam botol untuk memudahkan menuangnya nanti, supaya hasil kuenya rapi bagian tengah putihnya, sisihkan (botolnya yang ujungnya agak panjang/ada moncongnya yang biasanya di gunakan untuk isi saos/kecap di warung baso ya), berhubung aku ga punya jadi langkah yang ini aku lewati aja 😁, dan hasilnya jadi kurang rapi 😅"
- "Bahan 2 (bahan hijau) masak semua bahan 2 dengan api kecil, aduk terus hingga menjadi adonan kental, matikan kompor, sisihkan, biarkan dingin"
- "Bahan 3, di wadah lain, kocok telur dan gula pasir, sampai gula larut menggunakan balon whisk, masukkan santan dan terigu secara bertahap, aduk rata, masukkan adonan bahan 2 sedikit demi sedikit, aduk rata sampai menjadi adonan yang halus dan tidak bergerindil"
- "Hasilnya seperti ini adonan hijaunya"
- "Panaskan kukusan dengan air secukupnya, alasi penutupnya dengan serbet/kain bersih agar air tidak menetes di adonan"
- "Tuang 3/4 adonan hijau kedalam cetakan lalu tuang/semprot adonan putih di tengahnya sampai agak penuh, benamkan sedikit moncong botolnya ya, lakukan sampai semua adonan habis, karena fotonya ke hapus, untuk langkah yang ini jadi ga ada foto stepnya 😅"
- "Kukus selama 10 menit dengan api sedang cenderung kecil, angkat"
- "Tunggu hingga dingin dulu baru dikeluarkan dari cetakan"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 236 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Lunch

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/859d2c767bd48223/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita lestarikan karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti kue nona manis yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia



Kehangatan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah memasak Kue Nona Manis untuk keluarga. kebiasaan makan bersama anak sudah menjadi budaya, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang dapat anda coba salah satunya kue nona manis yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Diperlukan  🍃Bahan 1🍃
1. Harus ada 500 ml santan kental
1. Siapkan 6 sdm terigu
1. Harus ada Sejumput garam
1. Jangan lupa  🍃Bahan 2🍃
1. Diperlukan 250 ml santan kental
1. Siapkan 40 g gula pasir (2 sdm)
1. Harus ada 30 g maizena (2,5 sdm)
1. Diperlukan 1 sdt pasta pandan (secukupnya)
1. Diperlukan Sejumput garam
1. Harap siapkan  🍃Bahan 3🍃
1. Dibutuhkan 250 ml santan kental
1. Tambah 1 butir telur
1. Diperlukan 80 g gula pasir (4 sdm)
1. Dibutuhkan 140 g terigu (1 gelas belimbing + 1 sdm munjung)




<!--inarticleads2-->

##### Langkah membuat  Kue Nona Manis:

1. Siapkan cetakan, olesi minyak goreng tipis-tipis, sisihkan
1. Bahan 1 (adonan putih), masak semua bahan 1 dengan api kecil, sampai beruap dan meletup-letup, matikan kompor, aduk terus sampai adonan kental, halus dan tidak bergerindil, angkat dan biarkan dingin
1. Masukkan adonan putih kedalam botol untuk memudahkan menuangnya nanti, supaya hasil kuenya rapi bagian tengah putihnya, sisihkan (botolnya yang ujungnya agak panjang/ada moncongnya yang biasanya di gunakan untuk isi saos/kecap di warung baso ya), berhubung aku ga punya jadi langkah yang ini aku lewati aja 😁, dan hasilnya jadi kurang rapi 😅
1. Bahan 2 (bahan hijau) masak semua bahan 2 dengan api kecil, aduk terus hingga menjadi adonan kental, matikan kompor, sisihkan, biarkan dingin
1. Bahan 3, di wadah lain, kocok telur dan gula pasir, sampai gula larut menggunakan balon whisk, masukkan santan dan terigu secara bertahap, aduk rata, masukkan adonan bahan 2 sedikit demi sedikit, aduk rata sampai menjadi adonan yang halus dan tidak bergerindil
1. Hasilnya seperti ini adonan hijaunya
1. Panaskan kukusan dengan air secukupnya, alasi penutupnya dengan serbet/kain bersih agar air tidak menetes di adonan
1. Tuang 3/4 adonan hijau kedalam cetakan lalu tuang/semprot adonan putih di tengahnya sampai agak penuh, benamkan sedikit moncong botolnya ya, lakukan sampai semua adonan habis, karena fotonya ke hapus, untuk langkah yang ini jadi ga ada foto stepnya 😅
1. Kukus selama 10 menit dengan api sedang cenderung kecil, angkat
1. Tunggu hingga dingin dulu baru dikeluarkan dari cetakan




Demikianlah cara membuat kue nona manis yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
