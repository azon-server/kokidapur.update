---
description: "Steps untuk menyiapakan Ayam Bakar Bumbu Padang Teruji"
title: "Steps untuk menyiapakan Ayam Bakar Bumbu Padang Teruji"
slug: 70-steps-untuk-menyiapakan-ayam-bakar-bumbu-padang-teruji
date: 2020-10-22T23:53:26.683Z
image: https://img-global.cpcdn.com/recipes/597dd99bd44730ff/680x482cq70/ayam-bakar-bumbu-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/597dd99bd44730ff/680x482cq70/ayam-bakar-bumbu-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/597dd99bd44730ff/680x482cq70/ayam-bakar-bumbu-padang-foto-resep-utama.jpg
author: Mark May
ratingvalue: 4
reviewcount: 24014
recipeingredient:
- "1 kg ayam potong 8"
- "1 buah jeruk lemon"
- "500 ml santan 65ml kara  air"
- "3 lembar daun salam"
- "4 lembar jeruk"
- "1 lembar daun kunyit potongpotong"
- "1 batang serai geprek"
- "2 buah kapulaga"
- "1 sdm gula pasir"
- "1 sdm garam atau sesuai selera"
- "1/2 sdt kaldu bubuk"
- " Bumbu yang dihaluskan "
- "7 buah cabe merah keriting"
- "5 siung bawang merah"
- "4 siung bawang putih"
- "2 cm kunyit"
- "1 jempol jahe"
- "1 jempol lengkuas"
- "1 sdm ketumbar sangrai"
- "1/2 sdt jinten sangrai"
- "3 butir kemiri sangrai"
- "3 sdm minyak goreng untuk menumis bumbu"
recipeinstructions:
- "Siapkan ayam, 1 ekor dipotong menjadi 8 bagian, lalu cuci hingga bersih, kemudian kucuri air perasan jeruk lemon, aduk rata lalu, diamkan selama 15 menit.           (lihat tips)"
- "Siapkan bumbu-bumbunya, haluskan bumbu halus, lalu tumis dengan 3 sdm minyak goreng, tumis bumbu hingga harum."
- "Lalu masukkan kapulaga, daun salam, daun jeruk, serai dan daun kunyit, aduk rata, masak hingga bumbu matang, lalu beri santan, masak hingga mendidih, lalu biarkan selama 5 menit, beri garam, gula pasir dan kaldu bubuk."
- "Lalu masukkan daging ayam (tanpa dicuci setelah diberi air jeruk lemon), aduk rata, masak dengan sesekali diaduk dan tes rasanya, masak hingga airnya menyusut, matikan api."
- "Untuk daging ayamnya, tidak langsung saya bakar, jadi setelah dingin dimasukkan kedalam wadah tertutup, simpan dikulkas, jadi jika mau makan mendadak dibakar. Jika akan dibakar, panaskan bakaran/teflon/happycall, saya pakai happycall, jika sudah panas, tata daging ayam, oles dengan sisa bumbu ungkep, lalu masak hingga ayam kecoklatan."
- "Lalu sajikan dengan sambal ijo, lalapan dan gulai nangka.           (lihat resep)"
categories:
- Recipe
tags:
- ayam
- bakar
- bumbu

katakunci: ayam bakar bumbu 
nutrition: 238 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Bakar Bumbu Padang](https://img-global.cpcdn.com/recipes/597dd99bd44730ff/680x482cq70/ayam-bakar-bumbu-padang-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau renyah. Karasteristik kuliner Nusantara ayam bakar bumbu padang yang kaya dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga dapat didapat dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Bakar Bumbu Padang untuk keluarga. Momen makan bersama anak sudah menjadi budaya, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang dapat anda praktekkan salah satunya ayam bakar bumbu padang yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep ayam bakar bumbu padang tanpa harus bersusah payah.
Seperti resep Ayam Bakar Bumbu Padang yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 22 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Bakar Bumbu Padang:

1. Jangan lupa 1 kg ayam, potong 8
1. Harap siapkan 1 buah jeruk lemon
1. Jangan lupa 500 ml santan (65ml kara + air)
1. Dibutuhkan 3 lembar daun salam
1. Dibutuhkan 4 lembar jeruk
1. Diperlukan 1 lembar daun kunyit, potong-potong
1. Harus ada 1 batang serai, geprek
1. Jangan lupa 2 buah kapulaga
1. Dibutuhkan 1 sdm gula pasir
1. Siapkan 1 sdm garam, atau sesuai selera
1. Tambah 1/2 sdt kaldu bubuk
1. Harus ada  Bumbu yang dihaluskan :
1. Tambah 7 buah cabe merah keriting
1. Harus ada 5 siung bawang merah
1. Tambah 4 siung bawang putih
1. Siapkan 2 cm kunyit
1. Dibutuhkan 1 jempol jahe
1. Harap siapkan 1 jempol lengkuas
1. Harap siapkan 1 sdm ketumbar, sangrai
1. Dibutuhkan 1/2 sdt jinten, sangrai
1. Diperlukan 3 butir kemiri, sangrai
1. Jangan lupa 3 sdm minyak goreng, untuk menumis bumbu




<!--inarticleads2-->

##### Langkah membuat  Ayam Bakar Bumbu Padang:

1. Siapkan ayam, 1 ekor dipotong menjadi 8 bagian, lalu cuci hingga bersih, kemudian kucuri air perasan jeruk lemon, aduk rata lalu, diamkan selama 15 menit. -           (lihat tips)
1. Siapkan bumbu-bumbunya, haluskan bumbu halus, lalu tumis dengan 3 sdm minyak goreng, tumis bumbu hingga harum.
1. Lalu masukkan kapulaga, daun salam, daun jeruk, serai dan daun kunyit, aduk rata, masak hingga bumbu matang, lalu beri santan, masak hingga mendidih, lalu biarkan selama 5 menit, beri garam, gula pasir dan kaldu bubuk.
1. Lalu masukkan daging ayam (tanpa dicuci setelah diberi air jeruk lemon), aduk rata, masak dengan sesekali diaduk dan tes rasanya, masak hingga airnya menyusut, matikan api.
1. Untuk daging ayamnya, tidak langsung saya bakar, jadi setelah dingin dimasukkan kedalam wadah tertutup, simpan dikulkas, jadi jika mau makan mendadak dibakar. Jika akan dibakar, panaskan bakaran/teflon/happycall, saya pakai happycall, jika sudah panas, tata daging ayam, oles dengan sisa bumbu ungkep, lalu masak hingga ayam kecoklatan.
1. Lalu sajikan dengan sambal ijo, lalapan dan gulai nangka. -           (lihat resep)




Demikianlah cara membuat ayam bakar bumbu padang yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan terbukti, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
