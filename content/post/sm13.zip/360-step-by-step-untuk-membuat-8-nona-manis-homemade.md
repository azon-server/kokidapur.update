---
description: "Step-by-Step untuk membuat 8. Nona manis Homemade"
title: "Step-by-Step untuk membuat 8. Nona manis Homemade"
slug: 360-step-by-step-untuk-membuat-8-nona-manis-homemade
date: 2021-02-17T10:41:37.354Z
image: https://img-global.cpcdn.com/recipes/689916abeab0ee3b/680x482cq70/8-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/689916abeab0ee3b/680x482cq70/8-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/689916abeab0ee3b/680x482cq70/8-nona-manis-foto-resep-utama.jpg
author: Mike Boyd
ratingvalue: 4.1
reviewcount: 43548
recipeingredient:
- " Bahan A "
- "2 gelas santan"
- "2 gelas terigu"
- "1 gelas gula pasir"
- "1 telur"
- " Bahan B "
- "1 gelas santan"
- " Daun Pandan blender dgn 1 gelas air"
- "1/2 gelas gula pasir"
- "1/2 gelas meizena"
- " Garam"
- "Beberapa tetes pewarna hijau"
- " Bahan C "
- "2 gelas santan"
- "2 sdm terigu"
- " Garam"
- "3 sdm gula pasir"
recipeinstructions:
- "Campur dan aduk rata bahan A kecuali telur, sisihkan"
- "Campur bahan B, masak dgn api kecil sampai kental dan nampak licin (mengkilap), sisihkan"
- "Setelah bahan B hangat, tuang bahan A kedalam bahan B, aduk rata (bisa juga diblender) lalu saring"
- "Kocok telur dgn garpu dan masukkan ke campuran bahan A dan B tadi, sisihkan"
- "Campur bahan C, saring lalu masak dgn api kecil, aduk terus sampai mendidih"
- "Siapkan cetakan cucing (cetakan kue talam), oles minyak"
- "Masukkan adonan hijau, lalu semprotkan adonan putih ditengahnya"
- "Kukus selama 7-10 menit"
- "Keluarkan dari kukusan, letakkan di wadah yg sudah diisi air kira2 setinggi 1cm (gunanya untuk memudahkan mengeluarkan kue dari cetakan)"
- "Lalu keluarkan dari cetakan dan siap disajikan"
categories:
- Recipe
tags:
- 8
- nona
- manis

katakunci: 8 nona manis 
nutrition: 269 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dinner

---


![8. Nona manis](https://img-global.cpcdn.com/recipes/689916abeab0ee3b/680x482cq70/8-nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis atau enak. Ciri masakan Indonesia 8. nona manis yang kaya dengan rempah menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kehangatan keluarga bisa diperoleh dengan cara simple. Diantaranya adalah memasak 8. Nona manis untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang bisa anda coba salah satunya 8. nona manis yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep 8. nona manis tanpa harus bersusah payah.
Seperti resep 8. Nona manis yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 8. Nona manis:

1. Diperlukan  Bahan A :
1. Tambah 2 gelas santan
1. Dibutuhkan 2 gelas terigu
1. Diperlukan 1 gelas gula pasir
1. Siapkan 1 telur
1. Harap siapkan  Bahan B :
1. Harap siapkan 1 gelas santan
1. Diperlukan  Daun Pandan blender dgn 1 gelas air
1. Jangan lupa 1/2 gelas gula pasir
1. Harap siapkan 1/2 gelas meizena
1. Siapkan  Garam
1. Harus ada Beberapa tetes pewarna hijau
1. Tambah  Bahan C :
1. Dibutuhkan 2 gelas santan
1. Jangan lupa 2 sdm terigu
1. Tambah  Garam
1. Siapkan 3 sdm gula pasir




<!--inarticleads2-->

##### Cara membuat  8. Nona manis:

1. Campur dan aduk rata bahan A kecuali telur, sisihkan
1. Campur bahan B, masak dgn api kecil sampai kental dan nampak licin (mengkilap), sisihkan
1. Setelah bahan B hangat, tuang bahan A kedalam bahan B, aduk rata (bisa juga diblender) lalu saring
1. Kocok telur dgn garpu dan masukkan ke campuran bahan A dan B tadi, sisihkan
1. Campur bahan C, saring lalu masak dgn api kecil, aduk terus sampai mendidih
1. Siapkan cetakan cucing (cetakan kue talam), oles minyak
1. Masukkan adonan hijau, lalu semprotkan adonan putih ditengahnya
1. Kukus selama 7-10 menit
1. Keluarkan dari kukusan, letakkan di wadah yg sudah diisi air kira2 setinggi 1cm (gunanya untuk memudahkan mengeluarkan kue dari cetakan)
1. Lalu keluarkan dari cetakan dan siap disajikan




Demikianlah cara membuat 8. nona manis yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
