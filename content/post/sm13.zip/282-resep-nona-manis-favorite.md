---
description: "Resep : Nona Manis Favorite"
title: "Resep : Nona Manis Favorite"
slug: 282-resep-nona-manis-favorite
date: 2020-09-19T19:48:33.409Z
image: https://img-global.cpcdn.com/recipes/deae6407cbd5901b/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/deae6407cbd5901b/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/deae6407cbd5901b/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Harriet Santiago
ratingvalue: 4.3
reviewcount: 11402
recipeingredient:
- " Bahan hijau A"
- "1 gelas santan"
- "1 gelas terigu"
- "1 butir telur"
- "1/2 gelas gula"
- " Bahan hijau B"
- "1/2 gelas santan"
- "1/2 gelas air pandan"
- "2 sdm maizena"
- " Bahan putih"
- "2 gelas santan"
- "2 sdm terigu"
- "Secukupnya garam"
- " Pasta pandan optional"
recipeinstructions:
- "Campurkan semua bahan hijau A dengan blender. Sisihkan"
- "Tuang semua bahan hijau B dalam teflon, aduk rata. Tambahkan hasil blender bahan A, aduk rata. Panaskan di atas kompor dengan api kecil. Aduk-aduk terus selama memasak. Saat sudah mulai sedikit mengental, angkat, dan saring. Sisihkan"
- "Campurkan seluruh bahan putih ke dalam teflon, aduk, lalu masak dengan api kecil sampai mengental. Saring, lalu sisihkan"
- "Olesi cetakan dengan minyak goreng. Tuang adonan hijau sampai setengah cetakan, kemudian tuang perlahan adonan putih ditengahnya dengam hati-hati sampai cetakan penuh. Agar lebih rapi, tuang adonan putih dengan bantuan piping bag"
- "Kukus selama 20 menit. Angkat. Keluarkan kue saat sudah tidak terlalu panas. Sajikan"
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 124 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Lunch

---


![Nona Manis](https://img-global.cpcdn.com/recipes/deae6407cbd5901b/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita jaga karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti nona manis yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Nusantara

Kehangatan keluarga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Nona Manis untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang bisa anda contoh salah satunya nona manis yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona Manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona Manis:

1. Tambah  Bahan hijau A
1. Jangan lupa 1 gelas santan
1. Harus ada 1 gelas terigu
1. Dibutuhkan 1 butir telur
1. Jangan lupa 1/2 gelas gula
1. Siapkan  Bahan hijau B
1. Siapkan 1/2 gelas santan
1. Siapkan 1/2 gelas air pandan
1. Harus ada 2 sdm maizena
1. Tambah  Bahan putih
1. Jangan lupa 2 gelas santan
1. Jangan lupa 2 sdm terigu
1. Diperlukan Secukupnya garam
1. Jangan lupa  Pasta pandan (optional)




<!--inarticleads2-->

##### Bagaimana membuat  Nona Manis:

1. Campurkan semua bahan hijau A dengan blender. Sisihkan
1. Tuang semua bahan hijau B dalam teflon, aduk rata. Tambahkan hasil blender bahan A, aduk rata. Panaskan di atas kompor dengan api kecil. Aduk-aduk terus selama memasak. Saat sudah mulai sedikit mengental, angkat, dan saring. Sisihkan
1. Campurkan seluruh bahan putih ke dalam teflon, aduk, lalu masak dengan api kecil sampai mengental. Saring, lalu sisihkan
1. Olesi cetakan dengan minyak goreng. Tuang adonan hijau sampai setengah cetakan, kemudian tuang perlahan adonan putih ditengahnya dengam hati-hati sampai cetakan penuh. Agar lebih rapi, tuang adonan putih dengan bantuan piping bag
1. Kukus selama 20 menit. Angkat. Keluarkan kue saat sudah tidak terlalu panas. Sajikan




Demikianlah cara membuat nona manis yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan terbukti, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
