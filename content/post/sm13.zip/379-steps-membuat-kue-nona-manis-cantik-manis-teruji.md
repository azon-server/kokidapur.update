---
description: "Steps membuat Kue nona manis (cantik manis) Teruji"
title: "Steps membuat Kue nona manis (cantik manis) Teruji"
slug: 379-steps-membuat-kue-nona-manis-cantik-manis-teruji
date: 2020-10-14T06:05:58.706Z
image: https://img-global.cpcdn.com/recipes/26e29a8ccb701621/680x482cq70/kue-nona-manis-cantik-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/26e29a8ccb701621/680x482cq70/kue-nona-manis-cantik-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/26e29a8ccb701621/680x482cq70/kue-nona-manis-cantik-manis-foto-resep-utama.jpg
author: Jorge Patrick
ratingvalue: 4.2
reviewcount: 40840
recipeingredient:
- "300 g tepung terigu"
- "2 butir telor"
- "200 g gula pasir"
- "700 ml santan sya pke susu cair"
- "100 ml susu kental manis"
- " Pasta pandan daun pandan"
- " Bahan pla"
- "2 sendok mkn tepung terigu"
- "2 sendok makan maizena"
- "1/2 sendok teh garam"
- "450 ml santan sya pke susu cair"
recipeinstructions:
- "Campur semua bahan aduk sampe rata. Bila perlu disaring, (klo saya di blender semua jd gk perlu di sharing krn udh lembut)"
- "Campur semua bahan pla aduk smpe campur rata, masak dngan api kecil. Diamkan sbntr agak dingin."
- "Tuang adonan hijau dlm cetakan, tambahkan bahan pla ditengahnya, kukus smpe mateng (kurleb 10 menit) angkat dingin kah suhu ruang lalu kluarkan dr cetakan. Selesai"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 243 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Lunch

---


![Kue nona manis (cantik manis)](https://img-global.cpcdn.com/recipes/26e29a8ccb701621/680x482cq70/kue-nona-manis-cantik-manis-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga empuk. Ciri masakan Indonesia kue nona manis (cantik manis) yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah memasak Kue nona manis (cantik manis) untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang dapat anda contoh salah satunya kue nona manis (cantik manis) yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep kue nona manis (cantik manis) tanpa harus bersusah payah.
Berikut ini resep Kue nona manis (cantik manis) yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 11 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue nona manis (cantik manis):

1. Harus ada 300 g tepung terigu
1. Tambah 2 butir telor
1. Diperlukan 200 g gula pasir
1. Jangan lupa 700 ml santan (sya pke susu cair)
1. Tambah 100 ml susu kental manis
1. Dibutuhkan  Pasta pandan (daun pandan)
1. Harap siapkan  Bahan pla
1. Jangan lupa 2 sendok mkn tepung terigu
1. Dibutuhkan 2 sendok makan maizena
1. Harus ada 1/2 sendok teh garam
1. Tambah 450 ml santan (sya pke susu cair)




<!--inarticleads2-->

##### Bagaimana membuat  Kue nona manis (cantik manis):

1. Campur semua bahan aduk sampe rata. Bila perlu disaring, (klo saya di blender semua jd gk perlu di sharing krn udh lembut)
1. Campur semua bahan pla aduk smpe campur rata, masak dngan api kecil. Diamkan sbntr agak dingin.
1. Tuang adonan hijau dlm cetakan, tambahkan bahan pla ditengahnya, kukus smpe mateng (kurleb 10 menit) angkat dingin kah suhu ruang lalu kluarkan dr cetakan. Selesai




Demikianlah cara membuat kue nona manis (cantik manis) yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
