---
description: "Resep : Angsle Sempurna"
title: "Resep : Angsle Sempurna"
slug: 492-resep-angsle-sempurna
date: 2020-10-12T17:32:42.475Z
image: https://img-global.cpcdn.com/recipes/5ba374d28c6261c4/680x482cq70/angsle-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5ba374d28c6261c4/680x482cq70/angsle-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5ba374d28c6261c4/680x482cq70/angsle-foto-resep-utama.jpg
author: Cora Rodriguez
ratingvalue: 4.8
reviewcount: 37442
recipeingredient:
- " Bahan ketan"
- "250 gr beras ketan"
- "165 ml santan 1 sachet  air"
- "1 sdt garam"
- "1 lembar daun pandan"
- " Bahan Kacang hijau"
- "250 gr kacang hijau"
- "1 ltr air"
- "3 bulatan kecil gula merah"
- "2 sdm tepung maizena campur sedikit air"
- "1 lembar daun pandan"
- " Bahan Mutiara"
- "100 gr (1 sachet) mutiara"
- "5 sdm gula pasir"
- "1500 ml air"
- " Bahan Kuah"
- "130 ml (2 sachet) santan instan"
- "2 ltr air"
- "200 gr gula pasir"
- "1 sdt garam"
- "sejumput vanili"
- " Bahan Lain"
- "10 lembar roti tawar potong dadu"
recipeinstructions:
- "Kacang hijau : rebus air mendidih, masukkan kacang hijau masak 5 menit, matikan api tutup diamkan 30 menit, lalu didihkan lagi, tambahkan gula,rebus selama 7 menit dg ditutup, tambahkan maizena, didihkan lalu matikan api"
- "Mutiara : rebus air sampai mendidih, masukkan mutiara, rebus 5 menit, matikan api, tutup diamkan 30 menit, lalu didihkan lagi, tambahkan gula, rebus lagi 7 menit"
- "Beras ketan : kukus 10 menit,matikan api, rebus santan, garam,daun pandan,matikan api, campur semua dan diamkan 10 mnt, kukus lg 5 menit"
- "Kuah : campur semua bahan kuah, masak sampai mendidih, matikan"
- "Tata semua isian lalu tambahkan kuah"
categories:
- Recipe
tags:
- angsle

katakunci: angsle 
nutrition: 264 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Dessert

---


![Angsle](https://img-global.cpcdn.com/recipes/5ba374d28c6261c4/680x482cq70/angsle-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan enak. Ciri khas masakan Nusantara angsle yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Angsle untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang bisa anda praktekkan salah satunya angsle yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep angsle tanpa harus bersusah payah.
Berikut ini resep Angsle yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 23 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Angsle:

1. Harap siapkan  Bahan ketan
1. Tambah 250 gr beras ketan
1. Siapkan 165 ml santan (1 sachet + air)
1. Harap siapkan 1 sdt garam
1. Diperlukan 1 lembar daun pandan
1. Harus ada  Bahan Kacang hijau
1. Diperlukan 250 gr kacang hijau
1. Tambah 1 ltr air
1. Siapkan 3 bulatan kecil gula merah
1. Jangan lupa 2 sdm tepung maizena (campur sedikit air)
1. Diperlukan 1 lembar daun pandan
1. Harus ada  Bahan Mutiara
1. Siapkan 100 gr (1 sachet) mutiara
1. Diperlukan 5 sdm gula pasir
1. Siapkan 1500 ml air
1. Dibutuhkan  Bahan Kuah
1. Dibutuhkan 130 ml (2 sachet) santan instan
1. Siapkan 2 ltr air
1. Siapkan 200 gr gula pasir
1. Dibutuhkan 1 sdt garam
1. Jangan lupa sejumput vanili
1. Harus ada  Bahan Lain
1. Jangan lupa 10 lembar roti tawar, potong dadu




<!--inarticleads2-->

##### Instruksi membuat  Angsle:

1. Kacang hijau : rebus air mendidih, masukkan kacang hijau masak 5 menit, matikan api tutup diamkan 30 menit, lalu didihkan lagi, tambahkan gula,rebus selama 7 menit dg ditutup, tambahkan maizena, didihkan lalu matikan api
1. Mutiara : rebus air sampai mendidih, masukkan mutiara, rebus 5 menit, matikan api, tutup diamkan 30 menit, lalu didihkan lagi, tambahkan gula, rebus lagi 7 menit
1. Beras ketan : kukus 10 menit,matikan api, rebus santan, garam,daun pandan,matikan api, campur semua dan diamkan 10 mnt, kukus lg 5 menit
1. Kuah : campur semua bahan kuah, masak sampai mendidih, matikan
1. Tata semua isian lalu tambahkan kuah




Demikianlah cara membuat angsle yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
