---
description: "Steps menyiapakan Kue Nona Manis Luar biasa"
title: "Steps menyiapakan Kue Nona Manis Luar biasa"
slug: 344-steps-menyiapakan-kue-nona-manis-luar-biasa
date: 2020-09-20T20:51:11.180Z
image: https://img-global.cpcdn.com/recipes/38c00da49fc119fd/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/38c00da49fc119fd/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/38c00da49fc119fd/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Louis Ball
ratingvalue: 4.3
reviewcount: 25953
recipeingredient:
- " Bahan I"
- "3 sdm tepung terigu"
- "500 ml santan kental2 gelas belimbingkira2"
- "1/2 sdt garam"
- " Bahan II"
- "250 ml santan kental25 gelas belimbingkira"
- "2 sdm tepung meizena"
- "2 sdm gula pasir"
- "1/2 sdt garam"
- "secukupnya pewarna hijau"
- " Bahan III"
- "250 ml santan kental"
- "8 sdm tepung terigu"
- "1 butir telur"
- "3 sdm gula pasir"
recipeinstructions:
- "Siapkan cetakan dg di olesi sdkt minyak"
- "Masak bahan I hingga kental dg api keciil dn aduk rata(jgn sampai bergerindil) angkat dn sisihkan"
- "Lalu masak bahan ke II hingga meletup dg api keciil, aduk sampai benar2 rata(tdk perlu lama2) angkat dn sisihkan"
- "Dlm wadah lain kocok telur dn gula hingga larut(sy pakai whisk), tambahkan tepung aduk rata, lalu campurkan santan kental aduk sampai rata, campurkan bahan ke II aduk hingga rata"
- "Tempatkan bahan ke 1 dlm wadah bercorong agar bahan putih bisa di semprotkan dlm adonan hijau"
- "Tuang 3/4 adonan hijau dlm cetakan, kemudian semprotkan adonan putih ke dlm adonan hijau, dn seterusnya sampai adonan habis"
- "Kukus selama 10mnt, angkat dn dinginkan, baru di sajikan"
- "😄😄😄😄😄"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 235 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dessert

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/38c00da49fc119fd/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas dan empuk. Karasteristik makanan Indonesia kue nona manis yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kehangatan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Kue Nona Manis untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang dapat anda buat salah satunya kue nona manis yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 8 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Harus ada  Bahan I
1. Diperlukan 3 sdm tepung terigu
1. Dibutuhkan 500 ml santan kental(2 gelas belimbing/kira2)
1. Siapkan 1/2 sdt garam
1. Tambah  Bahan II
1. Siapkan 250 ml santan kental(2,5 gelas belimbing/kira)
1. Tambah 2 sdm tepung meizena
1. Harap siapkan 2 sdm gula pasir
1. Harap siapkan 1/2 sdt garam
1. Harus ada secukupnya pewarna hijau
1. Harap siapkan  Bahan III
1. Jangan lupa 250 ml santan kental
1. Jangan lupa 8 sdm tepung terigu
1. Siapkan 1 butir telur
1. Harap siapkan 3 sdm gula pasir




<!--inarticleads2-->

##### Cara membuat  Kue Nona Manis:

1. Siapkan cetakan dg di olesi sdkt minyak
1. Masak bahan I hingga kental dg api keciil dn aduk rata(jgn sampai bergerindil) angkat dn sisihkan
1. Lalu masak bahan ke II hingga meletup dg api keciil, aduk sampai benar2 rata(tdk perlu lama2) angkat dn sisihkan
1. Dlm wadah lain kocok telur dn gula hingga larut(sy pakai whisk), tambahkan tepung aduk rata, lalu campurkan santan kental aduk sampai rata, campurkan bahan ke II aduk hingga rata
1. Tempatkan bahan ke 1 dlm wadah bercorong agar bahan putih bisa di semprotkan dlm adonan hijau
1. Tuang 3/4 adonan hijau dlm cetakan, kemudian semprotkan adonan putih ke dlm adonan hijau, dn seterusnya sampai adonan habis
1. Kukus selama 10mnt, angkat dn dinginkan, baru di sajikan
1. 😄😄😄😄😄




Demikianlah cara membuat kue nona manis yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan teruji, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
