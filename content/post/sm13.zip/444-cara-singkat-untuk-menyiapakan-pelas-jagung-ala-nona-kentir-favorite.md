---
description: "Cara singkat untuk menyiapakan Pelas Jagung ala Nona Kentir Favorite"
title: "Cara singkat untuk menyiapakan Pelas Jagung ala Nona Kentir Favorite"
slug: 444-cara-singkat-untuk-menyiapakan-pelas-jagung-ala-nona-kentir-favorite
date: 2021-01-01T12:13:07.166Z
image: https://img-global.cpcdn.com/recipes/b6b8a44d4dc601aa/680x482cq70/pelas-jagung-ala-nona-kentir-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b6b8a44d4dc601aa/680x482cq70/pelas-jagung-ala-nona-kentir-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b6b8a44d4dc601aa/680x482cq70/pelas-jagung-ala-nona-kentir-foto-resep-utama.jpg
author: Herbert Berry
ratingvalue: 4.6
reviewcount: 8211
recipeingredient:
- "4 bh jagung manis"
- "8 bh cabe rawit merah"
- "10 siung bawang merah"
- "7 siung bawang putih"
- "1 sdm ketumbar"
- "1/2 ruas kencur"
- "secukupnya garam"
- "1 sdt gula pasir"
- "3 sdm tepung terigu"
- "1 butir telur ayam"
recipeinstructions:
- "Kupas, cuci bersih, sisir dan ulek kasar jagung manis."
- "Haluskan cabe rawit, bawang merah, bawang putih, ketumbar, kencur, garam dan gula pasir."
- "Campur bumbu yang sudah dihaluskan dengan jagung tadi. Cek rasa. kalo sudah pas asin, manis dan pedasnya tambahkan tepung terigu dan telur ayam. Aduk. Cetak pake sendok. Goreng hingga ke brown goldtan gitu 😊"
categories:
- Recipe
tags:
- pelas
- jagung
- ala

katakunci: pelas jagung ala 
nutrition: 251 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT55M"
recipeyield: "4"
recipecategory: Lunch

---


![Pelas Jagung ala Nona Kentir](https://img-global.cpcdn.com/recipes/b6b8a44d4dc601aa/680x482cq70/pelas-jagung-ala-nona-kentir-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti pelas jagung ala nona kentir yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa ciri khas yang merupakan keragaman Nusantara



Keharmonisan keluarga dapat didapat dengan cara mudah. Diantaranya adalah memasak Pelas Jagung ala Nona Kentir untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi resep yang dapat anda coba salah satunya pelas jagung ala nona kentir yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep pelas jagung ala nona kentir tanpa harus bersusah payah.
Seperti resep Pelas Jagung ala Nona Kentir yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 10 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Pelas Jagung ala Nona Kentir:

1. Jangan lupa 4 bh jagung manis
1. Diperlukan 8 bh cabe rawit merah
1. Harap siapkan 10 siung bawang merah
1. Jangan lupa 7 siung bawang putih
1. Diperlukan 1 sdm ketumbar
1. Harus ada 1/2 ruas kencur
1. Tambah secukupnya garam
1. Diperlukan 1 sdt gula pasir
1. Harus ada 3 sdm tepung terigu
1. Siapkan 1 butir telur ayam




<!--inarticleads2-->

##### Instruksi membuat  Pelas Jagung ala Nona Kentir:

1. Kupas, cuci bersih, sisir dan ulek kasar jagung manis.
1. Haluskan cabe rawit, bawang merah, bawang putih, ketumbar, kencur, garam dan gula pasir.
1. Campur bumbu yang sudah dihaluskan dengan jagung tadi. Cek rasa. kalo sudah pas asin, manis dan pedasnya tambahkan tepung terigu dan telur ayam. Aduk. Cetak pake sendok. Goreng hingga ke brown goldtan gitu 😊




Demikianlah cara membuat pelas jagung ala nona kentir yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan teruji, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
