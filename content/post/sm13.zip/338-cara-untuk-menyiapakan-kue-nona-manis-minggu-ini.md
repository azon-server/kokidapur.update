---
description: "Cara untuk menyiapakan Kue Nona Manis minggu ini"
title: "Cara untuk menyiapakan Kue Nona Manis minggu ini"
slug: 338-cara-untuk-menyiapakan-kue-nona-manis-minggu-ini
date: 2020-12-21T01:32:15.893Z
image: https://img-global.cpcdn.com/recipes/53836993c6b6073b/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/53836993c6b6073b/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/53836993c6b6073b/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Lula Gray
ratingvalue: 4.5
reviewcount: 46016
recipeingredient:
- " Bahan A "
- "300 ml santan kental"
- "30 g tepung maizena"
- "40 g gula pasir"
- "1 ml pasta pandan kualitas bagus bisa ganti endapanjus pandan"
- " Bahan B "
- "500 ml santan kental"
- "100 g tepung terigu"
- "Seujung sendok garam"
- " Bahan C "
- "250 ml santan kental"
- "140 g tepung terigu"
- "1 butir telur"
- "80 g gula pasir"
- "sejumput garam"
recipeinstructions:
- "Campur dalam panci bahan A aduk rata nyalakan kompor masak sampai mengental angkat sisihkan dan dinginkan."
- "Campur bahan B di dalam panci aduk rata dahulu sampai tidak ada terigu yang menggerindil, lalu nyalakan kompor masak sampai meletup letup. angkat sisihkan, jika sudah dingin masukkan ke dalam pipping bag."
- "Kocok gula dan telur sampai mengembang dan kaku, dengan kecepatan tinggi,lalu masukkan tepung terigu dan santan kocok sampai rata menggunakan speed rendah, sampai tidak ada tepung terigu yang menggerindil."
- "Masukkan bahan A yang tadi di sisihkan (adonan warna hijau)lalu kocok lagi sampai benar benar halus, jadi gak ada adonan hijau yang menggerindil."
- "Tuang ke dalam cucing, sebanyak 3/4, Lakukan sampai semua adonan habis, lalu beri adonan (bahan B) di tengahnya. dengan cara gunting ujung pipping bag lalu benamkan ujungnya di tengah tengah cucing,"
- "Kukus selama 15 menit di dandang yang sudah panas dan beruap banyak, jangan lupa tutupnya di alas serbet bersih biar uap gak netes masuk ke dalam kue."
- "Dinginkan dan siap di hidangkan 😄😄😋😋😋"
- "Note n tips... 1.Selama mendinginkan adonan bahan A (warna hijau) sesekali di aduk biar gak gumpal gumpal... 2.Adonan hijau sebelum di campur ke adonan kocokan telur, ada baiknya ambil sedikit adonan telur lalu masukkan ke dalam adonan hijau lalu mixer sampai halus biar hijaunya gak gerindil2 (soalnya kalau langsung di masukkan ke adonan kocokan telur, butuh waktu lama sampai adonan hijau benar benar halus gak gerindil2,) baru setelah itu satukan dan mixer lagi sampai rata. happy cooking 😊😉"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 147 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dinner

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/53836993c6b6073b/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan empuk. Ciri khas masakan Indonesia kue nona manis yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Kue Nona Manis untuk keluarga. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang dapat anda praktekkan salah satunya kue nona manis yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis:

1. Tambah  Bahan A :
1. Jangan lupa 300 ml santan kental
1. Harus ada 30 g tepung maizena
1. Harap siapkan 40 g gula pasir
1. Harus ada 1 ml pasta pandan kualitas bagus (bisa ganti endapan/jus pandan)
1. Tambah  Bahan B :
1. Siapkan 500 ml santan kental
1. Harap siapkan 100 g tepung terigu
1. Diperlukan Seujung sendok garam
1. Dibutuhkan  Bahan C :
1. Dibutuhkan 250 ml santan kental
1. Dibutuhkan 140 g tepung terigu
1. Dibutuhkan 1 butir telur
1. Dibutuhkan 80 g gula pasir
1. Harap siapkan sejumput garam




<!--inarticleads2-->

##### Langkah membuat  Kue Nona Manis:

1. Campur dalam panci bahan A aduk rata nyalakan kompor masak sampai mengental angkat sisihkan dan dinginkan.
1. Campur bahan B di dalam panci aduk rata dahulu sampai tidak ada terigu yang menggerindil, lalu nyalakan kompor masak sampai meletup letup. angkat sisihkan, jika sudah dingin masukkan ke dalam pipping bag.
1. Kocok gula dan telur sampai mengembang dan kaku, dengan kecepatan tinggi,lalu masukkan tepung terigu dan santan kocok sampai rata menggunakan speed rendah, sampai tidak ada tepung terigu yang menggerindil.
1. Masukkan bahan A yang tadi di sisihkan (adonan warna hijau)lalu kocok lagi sampai benar benar halus, jadi gak ada adonan hijau yang menggerindil.
1. Tuang ke dalam cucing, sebanyak 3/4, Lakukan sampai semua adonan habis, lalu beri adonan (bahan B) di tengahnya. dengan cara gunting ujung pipping bag lalu benamkan ujungnya di tengah tengah cucing,
1. Kukus selama 15 menit di dandang yang sudah panas dan beruap banyak, jangan lupa tutupnya di alas serbet bersih biar uap gak netes masuk ke dalam kue.
1. Dinginkan dan siap di hidangkan 😄😄😋😋😋
1. Note n tips... 1.Selama mendinginkan adonan bahan A (warna hijau) sesekali di aduk biar gak gumpal gumpal... 2.Adonan hijau sebelum di campur ke adonan kocokan telur, ada baiknya ambil sedikit adonan telur lalu masukkan ke dalam adonan hijau lalu mixer sampai halus biar hijaunya gak gerindil2 (soalnya kalau langsung di masukkan ke adonan kocokan telur, butuh waktu lama sampai adonan hijau benar benar halus gak gerindil2,) baru setelah itu satukan dan mixer lagi sampai rata. happy cooking 😊😉




Demikianlah cara membuat kue nona manis yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
