---
description: "Cara menyiapakan Kue Nona Manis Cepat"
title: "Cara menyiapakan Kue Nona Manis Cepat"
slug: 298-cara-menyiapakan-kue-nona-manis-cepat
date: 2020-10-23T16:29:44.170Z
image: https://img-global.cpcdn.com/recipes/df45a12cc213680e/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/df45a12cc213680e/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/df45a12cc213680e/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Elizabeth Perez
ratingvalue: 4.3
reviewcount: 19123
recipeingredient:
- " Bahan A"
- "1 butir telur"
- "100 g gula asli 125 g"
- "250 santan"
- "145 g tepung terigu"
- " Bahan B"
- "250 ml santan asli 125ml santan dan 125 ml air pandan"
- "1/2 sdt pasta pandantambahan saya"
- "55 g gula pasir"
- "30 g tepung maizena"
- "1/4 sdt garam"
- " Bahan C"
- "250 ml santan"
- "1 sdm tepung terigu"
- "1 sdm gula pasir"
- "1/2 sdt garam"
recipeinstructions:
- "Masak bahan C, sampai meletup letup. biarkan agak dingin taruh di wadah botol atau masukkan kepiping bag, sisihkan"
- "Campur semua bahan B masak sampai meletup2, sisihkan"
- "Mixer telur dengan gula sampai mengembang, canpur tepung terigu dan santan, masukkan campuran tepung terigu dan santan tadi mixer sampai rata. tuang kedalam adonan b (adonan hijau) aduk dengan baloon whisk sampai rata (bisa dimixer juga sampai rata)"
- "Teksturnya (lihat video). Tuang 3/4 adonan hijau kedalam cetakan yang telah dioles dengan minyak"
- "Lalu isi di tengahnya dengan adonan putih. Secukupnya saja"
- "Kukus selama 10 menit dengan api sedang"
- "Angkat dan sajikan, superrr yummy"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 116 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Dinner

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/df45a12cc213680e/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis atau enak. Ciri makanan Indonesia kue nona manis yang kaya dengan rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kedekatan keluarga bisa didapat dengan cara sederhana. Salah satunya adalah memasak Kue Nona Manis untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang dapat anda praktekkan salah satunya kue nona manis yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis:

1. Dibutuhkan  Bahan A
1. Harus ada 1 butir telur
1. Dibutuhkan 100 g gula (asli 125 g)
1. Harap siapkan 250 santan
1. Siapkan 145 g tepung terigu
1. Jangan lupa  Bahan B
1. Tambah 250 ml santan (asli 125ml santan dan 125 ml air pandan)
1. Dibutuhkan 1/2 sdt pasta pandan(tambahan saya)
1. Dibutuhkan 55 g gula pasir
1. Harus ada 30 g tepung maizena
1. Jangan lupa 1/4 sdt garam
1. Harus ada  Bahan C
1. Harap siapkan 250 ml santan
1. Dibutuhkan 1 sdm tepung terigu
1. Tambah 1 sdm gula pasir
1. Jangan lupa 1/2 sdt garam




<!--inarticleads2-->

##### Bagaimana membuat  Kue Nona Manis:

1. Masak bahan C, sampai meletup letup. biarkan agak dingin taruh di wadah botol atau masukkan kepiping bag, sisihkan
1. Campur semua bahan B masak sampai meletup2, sisihkan
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Kue Nona Manis">1. Mixer telur dengan gula sampai mengembang, canpur tepung terigu dan santan, masukkan campuran tepung terigu dan santan tadi mixer sampai rata. tuang kedalam adonan b (adonan hijau) aduk dengan baloon whisk sampai rata (bisa dimixer juga sampai rata)
1. Teksturnya (lihat video). Tuang 3/4 adonan hijau kedalam cetakan yang telah dioles dengan minyak
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Kue Nona Manis">1. Lalu isi di tengahnya dengan adonan putih. Secukupnya saja
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Kue Nona Manis"><img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Kue Nona Manis">1. Kukus selama 10 menit dengan api sedang
1. Angkat dan sajikan, superrr yummy




Demikianlah cara membuat kue nona manis yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan cepat, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
