---
description: "Langkah untuk membuat Nona Manis Sempurna"
title: "Langkah untuk membuat Nona Manis Sempurna"
slug: 402-langkah-untuk-membuat-nona-manis-sempurna
date: 2020-11-16T17:51:08.805Z
image: https://img-global.cpcdn.com/recipes/68fe80631cf36e0d/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/68fe80631cf36e0d/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/68fe80631cf36e0d/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Russell Adams
ratingvalue: 5
reviewcount: 31783
recipeingredient:
- " Bahan A"
- "500 ml santan kental"
- "6 sdm terigu"
- "Secukupnya garam"
- " Bahan B"
- "250 ml santan kental"
- "45 gram gula pasir"
- "30 gram maizena"
- "2 sdt pasta pandan sy pakai merk Toffieco"
- "Secukupnya garam"
- " Bahan C"
- "250 ml santan kental"
- "1 butir telur"
- "80 gram gula pasir"
- "140 gram terigu"
recipeinstructions:
- "Campur semua bahan A jadi satu, aduk merata, lalu tuang ke panci dengan cara disaring. Kemudian masak dengan api kecil, sambil diaduk terus, hingga mulai mengeras/kental, dan meletup. Matikan api lalu diinginkan."
- "Campur semua bahan B hingga tercampur rata, lalu masukan ke panci dengan cara disaring. Kemudian masak dengan api kecil, sambil diaduk terus hingga mengeras/kental dan meletup. Matikan api, sisihkan."
- "Bahan C. Pertama tama kita mixer/kocok telur dengan gula hingga tercampur dan mengembang, lalu masukan terigu dan santan secara sedikit demi sedikit sambil terus di mixer/kocok. Jika sudah tercampur, lalu masukan adonan B yang sudah dimasak td. Kemudian mixer dengan kecepatan tinggi hingga tercampur rata."
- "Siapkan panci untuk mengukus. Ambil wadah cetakan lalu olesi minyak."
- "Masukan adonan putih ke paping bag, bisa juga pakai botol kecap. Tujuannya agar rapi ketika memasukan adonan putih ke cetakan."
- "Masukan 3/4 adonan hijau ke cetakan, lalu semprotkan adonan putih di bagian tengahnya."
- "Masukan adonan ke dalam kukusan, kukus selama 10 menit. Angkat dan sajikan."
- "Ini foto step by step nya."
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 244 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT30M"
recipeyield: "1"
recipecategory: Lunch

---


![Nona Manis](https://img-global.cpcdn.com/recipes/68fe80631cf36e0d/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti nona manis yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Indonesia



Kedekatan rumah tangga dapat diperoleh dengan cara simple. Diantaranya adalah memasak Nona Manis untuk orang di rumah. Momen makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang dapat anda coba salah satunya nona manis yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep nona manis tanpa harus bersusah payah.
Berikut ini resep Nona Manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 8 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona Manis:

1. Dibutuhkan  Bahan A
1. Siapkan 500 ml santan kental
1. Harus ada 6 sdm terigu
1. Diperlukan Secukupnya garam
1. Harus ada  Bahan B
1. Jangan lupa 250 ml santan kental
1. Siapkan 45 gram gula pasir
1. Harus ada 30 gram maizena
1. Harus ada 2 sdt pasta pandan (sy pakai merk Toffieco)
1. Diperlukan Secukupnya garam
1. Dibutuhkan  Bahan C
1. Jangan lupa 250 ml santan kental
1. Tambah 1 butir telur
1. Jangan lupa 80 gram gula pasir
1. Diperlukan 140 gram terigu




<!--inarticleads2-->

##### Cara membuat  Nona Manis:

1. Campur semua bahan A jadi satu, aduk merata, lalu tuang ke panci dengan cara disaring. Kemudian masak dengan api kecil, sambil diaduk terus, hingga mulai mengeras/kental, dan meletup. Matikan api lalu diinginkan.
1. Campur semua bahan B hingga tercampur rata, lalu masukan ke panci dengan cara disaring. Kemudian masak dengan api kecil, sambil diaduk terus hingga mengeras/kental dan meletup. Matikan api, sisihkan.
1. Bahan C. Pertama tama kita mixer/kocok telur dengan gula hingga tercampur dan mengembang, lalu masukan terigu dan santan secara sedikit demi sedikit sambil terus di mixer/kocok. Jika sudah tercampur, lalu masukan adonan B yang sudah dimasak td. Kemudian mixer dengan kecepatan tinggi hingga tercampur rata.
1. Siapkan panci untuk mengukus. Ambil wadah cetakan lalu olesi minyak.
1. Masukan adonan putih ke paping bag, bisa juga pakai botol kecap. Tujuannya agar rapi ketika memasukan adonan putih ke cetakan.
1. Masukan 3/4 adonan hijau ke cetakan, lalu semprotkan adonan putih di bagian tengahnya.
1. Masukan adonan ke dalam kukusan, kukus selama 10 menit. Angkat dan sajikan.
1. Ini foto step by step nya.




Demikianlah cara membuat nona manis yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
