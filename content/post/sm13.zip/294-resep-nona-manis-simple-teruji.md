---
description: "Resep : Nona Manis simple Teruji"
title: "Resep : Nona Manis simple Teruji"
slug: 294-resep-nona-manis-simple-teruji
date: 2020-10-24T19:03:48.280Z
image: https://img-global.cpcdn.com/recipes/f366b38932f93c41/680x482cq70/nona-manis-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f366b38932f93c41/680x482cq70/nona-manis-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f366b38932f93c41/680x482cq70/nona-manis-simple-foto-resep-utama.jpg
author: Lillian Garrett
ratingvalue: 4.9
reviewcount: 12154
recipeingredient:
- " Bahan A"
- "250 ml santan dr 1 bh kara kecil  air"
- "145 gr tepung terigu"
- "1 butir telur"
- "125 gr gula pasir"
- " Bahan B"
- "250 air pandan dan daun suji"
- "1 bh kara"
- "50 gr gula pasir"
- "Sejumput garam"
- "30 gr tepung maizena"
- " Bahan C"
- "250 ml santan dari kara kecil dan air"
- "1 sdm tepung terigu"
- "1 sdm gula pasir"
- "Sejumput garam"
recipeinstructions:
- "Siapkah bahan B"
- "Campurkan bahan B"
- "Masak bahan B hingga meletup letup lalu sisihkan"
- "Siapkan bahan A"
- "Kocok telur dan gula hingga mengembang. Lalu campurkan santan dan tepung jadi satu"
- "Campurkan bahan A dan B"
- "Siapkan bahan C"
- "Aduk bahan C jadi satu"
- "Masak bahan C hingga meletup letup. Sisihkan"
- "Siapkan cetakan. Oleskan dgn sedikit sekali minyak"
- "Masukkan adonan hijau terlebih dahulu"
- "Lalu tuang adonan putih pada bagian tengah. Lbh mudah apa bila dgn botol saus / kecap"
- "Kukus kurang lebih 10 sd 15 menit"
- "Hidangkan setelah dingin ya moms"
categories:
- Recipe
tags:
- nona
- manis
- simple

katakunci: nona manis simple 
nutrition: 298 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Dessert

---


![Nona Manis simple](https://img-global.cpcdn.com/recipes/f366b38932f93c41/680x482cq70/nona-manis-simple-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau gurih. Ciri khas kuliner Nusantara nona manis simple yang penuh dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kehangatan rumah tangga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Nona Manis simple untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang bisa anda contoh salah satunya nona manis simple yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep nona manis simple tanpa harus bersusah payah.
Berikut ini resep Nona Manis simple yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 14 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona Manis simple:

1. Jangan lupa  Bahan A
1. Harus ada 250 ml santan (dr 1 bh kara kecil + air)
1. Dibutuhkan 145 gr tepung terigu
1. Diperlukan 1 butir telur
1. Jangan lupa 125 gr gula pasir
1. Jangan lupa  Bahan B
1. Dibutuhkan 250 air pandan dan daun suji
1. Jangan lupa 1 bh kara
1. Diperlukan 50 gr gula pasir
1. Jangan lupa Sejumput garam
1. Tambah 30 gr tepung maizena
1. Siapkan  Bahan C
1. Jangan lupa 250 ml santan (dari kara kecil dan air)
1. Harus ada 1 sdm tepung terigu
1. Jangan lupa 1 sdm gula pasir
1. Harap siapkan Sejumput garam




<!--inarticleads2-->

##### Instruksi membuat  Nona Manis simple:

1. Siapkah bahan B
1. Campurkan bahan B
1. Masak bahan B hingga meletup letup lalu sisihkan
1. Siapkan bahan A
1. Kocok telur dan gula hingga mengembang. Lalu campurkan santan dan tepung jadi satu
1. Campurkan bahan A dan B
1. Siapkan bahan C
1. Aduk bahan C jadi satu
1. Masak bahan C hingga meletup letup. Sisihkan
1. Siapkan cetakan. Oleskan dgn sedikit sekali minyak
1. Masukkan adonan hijau terlebih dahulu
1. Lalu tuang adonan putih pada bagian tengah. Lbh mudah apa bila dgn botol saus / kecap
1. Kukus kurang lebih 10 sd 15 menit
1. Hidangkan setelah dingin ya moms




Demikianlah cara membuat nona manis simple yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
