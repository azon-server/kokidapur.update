---
description: "Resep : Kerang Hijau, Udang Saos Padang Cepat"
title: "Resep : Kerang Hijau, Udang Saos Padang Cepat"
slug: 1-resep-kerang-hijau-udang-saos-padang-cepat
date: 2020-11-18T07:41:15.266Z
image: https://img-global.cpcdn.com/recipes/aa2de0135734c529/680x482cq70/kerang-hijau-udang-saos-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/aa2de0135734c529/680x482cq70/kerang-hijau-udang-saos-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/aa2de0135734c529/680x482cq70/kerang-hijau-udang-saos-padang-foto-resep-utama.jpg
author: Lewis Bryan
ratingvalue: 4.4
reviewcount: 37635
recipeingredient:
- "1 kg kerang hijau"
- "10 ekor udang ukuran besar utuh"
- "1 buah jagung manis"
- "1/2 siung bawang Bombay potong2"
- "3 siung bawang putih iris"
- "3 siung bawang merah iris"
- "3 sdm saos tiram"
- "5 sdm saos sambal"
- "3 sdm saos tomat"
- "3 buah cabai besar rebus uleg halus saya di iris"
- "2 batang daun bawang potong2"
- "3 sdt kaldu bubuk"
- "1 sdm gula pasir"
- "2 sdt garam"
- " Untuk merebus kerang "
- "1 ruas jahe ukuran besar geprek"
- "3 buah daun jeruk"
- "2 buah daun salam"
- "1 batang serai geprek"
recipeinstructions:
- "Cuci dan sikat bersih kerang (kebetulan kerang saya sudah dibersihkan sama mang sayur jadi tinggal olah). Rebus kerang dalam air mendidih. Masukkan juga jahe, sereh, daun salam, daun jeruk. Rebus selama 10 menit. Buang air cuci bersih sisihkan."
- "Rebus jagung manis sampai empuk. Sisihkan."
- "Tumis bawang putih hingga harum lalu masukkan bawang Bombay. Setelah harum lalu masukkan udang tumis sebentar lalu beri air secukupnya tunggu sampai mendidih lalu masukkan saos tiram, saos tomat, saos sambal, cabai, garam, kaldu dan gula. Lalu aduk rata. Koreksi rasa."
- "Setelah rasanya pas, masukkan jagung, dan kerang lalu aduk rata. Tutupin wajan tunggu kurang lebih 5 menit. Lalu masukkan daun bawang aduk rata tutup wajan kembali dan tunggu 5 menit. Matikan api dan sajikan."
categories:
- Recipe
tags:
- kerang
- hijau
- udang

katakunci: kerang hijau udang 
nutrition: 269 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT57M"
recipeyield: "1"
recipecategory: Lunch

---


![Kerang Hijau, Udang Saos Padang](https://img-global.cpcdn.com/recipes/aa2de0135734c529/680x482cq70/kerang-hijau-udang-saos-padang-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti kerang hijau, udang saos padang yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan ciri khas yang merupakan keragaman Indonesia



Kehangatan rumah tangga dapat ditemukan dengan cara mudah. Salah satunya adalah memasak Kerang Hijau, Udang Saos Padang untuk keluarga. kebersamaan makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi resep yang bisa anda praktekkan salah satunya kerang hijau, udang saos padang yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep kerang hijau, udang saos padang tanpa harus bersusah payah.
Berikut ini resep Kerang Hijau, Udang Saos Padang yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kerang Hijau, Udang Saos Padang:

1. Siapkan 1 kg kerang hijau
1. Siapkan 10 ekor udang ukuran besar utuh
1. Jangan lupa 1 buah jagung manis
1. Siapkan 1/2 siung bawang Bombay potong2
1. Tambah 3 siung bawang putih iris
1. Harap siapkan 3 siung bawang merah iris
1. Siapkan 3 sdm saos tiram
1. Diperlukan 5 sdm saos sambal
1. Dibutuhkan 3 sdm saos tomat
1. Dibutuhkan 3 buah cabai besar rebus uleg halus (saya di iris)
1. Harus ada 2 batang daun bawang potong2
1. Dibutuhkan 3 sdt kaldu bubuk
1. Harap siapkan 1 sdm gula pasir
1. Siapkan 2 sdt garam
1. Harus ada  Untuk merebus kerang =
1. Siapkan 1 ruas jahe ukuran besar geprek
1. Harap siapkan 3 buah daun jeruk
1. Jangan lupa 2 buah daun salam
1. Jangan lupa 1 batang serai geprek




<!--inarticleads2-->

##### Bagaimana membuat  Kerang Hijau, Udang Saos Padang:

1. Cuci dan sikat bersih kerang (kebetulan kerang saya sudah dibersihkan sama mang sayur jadi tinggal olah). Rebus kerang dalam air mendidih. Masukkan juga jahe, sereh, daun salam, daun jeruk. Rebus selama 10 menit. Buang air cuci bersih sisihkan.
1. Rebus jagung manis sampai empuk. Sisihkan.
1. Tumis bawang putih hingga harum lalu masukkan bawang Bombay. Setelah harum lalu masukkan udang tumis sebentar lalu beri air secukupnya tunggu sampai mendidih lalu masukkan saos tiram, saos tomat, saos sambal, cabai, garam, kaldu dan gula. Lalu aduk rata. Koreksi rasa.
1. Setelah rasanya pas, masukkan jagung, dan kerang lalu aduk rata. Tutupin wajan tunggu kurang lebih 5 menit. Lalu masukkan daun bawang aduk rata tutup wajan kembali dan tunggu 5 menit. Matikan api dan sajikan.




Demikianlah cara membuat kerang hijau, udang saos padang yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
