---
description: "Resep : Kue nona manis Cepat"
title: "Resep : Kue nona manis Cepat"
slug: 319-resep-kue-nona-manis-cepat
date: 2020-10-10T03:56:32.443Z
image: https://img-global.cpcdn.com/recipes/945a8907d9ab9747/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/945a8907d9ab9747/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/945a8907d9ab9747/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Annie Tate
ratingvalue: 4.7
reviewcount: 29796
recipeingredient:
- " Bahan 1 "
- "1 butir telur ayam"
- "80 gr gula pasir"
- "250 ml santan kental"
- "140 gr terigu"
- " Bahan 2 "
- "250 ml santan di blender dengan daun suji"
- "40 gr gula pasir"
- "30 gr maizena"
- "1/2 sdt garam"
- " Bahan 3 "
- "300 ml santan kental"
- "2 sdm gula pasir"
- "4 sdm tepung terigu me  maizena dikit"
- "1/2 sdm garam"
recipeinstructions:
- "Siapkan kukusan dan cetakan talam yg telah dioles tipis minyak terlebih dulu"
- "Bahan 1 : Kocok telur dan gula pasir sampai mengembang. Turunkan kecepatan mixer, masukkan terigu, kocok rata. Tuang santan lalu aduk sampai rata."
- "Bahan 2 : Campur santan suji, gula pasir dan maizena. Masak diatas kompor sambil diaduk terus sampai meletup-letup. Angkat."
- "Campurkan adonan 1 dan 2. Gunakan mixer hingga tercampur rata. Sisihkan. Panaskan dandang untuk mengukus."
- "Bahan 3 : Campur santan kental, gula, terigu, maizena dan garam aduk hingga rata dan tidak bergerindil. Masak sambil diaduk terus agar santan tidak pecah. Jgn terlalu lama, Setelah mendidih angkat segera dari kompor. Dan terus diaduk2 spy tdk bergerindil. Siapkan cetakkan cucing yang sudah diolesi minyak. Tuang adonan pandan hingga hampir penuh. Beri tengahnya adonan santan menggunakan piping bag. Kukus selama kurang lebih 7-10 menit (tergantung besar kecilnya cucing) dengan panas sedang."
- "Angkat dari kukusan. Agar lbh mudah dikeluarkan dr cucing, dinginkan dlm chiller sebentar."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 241 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Lunch

---


![Kue nona manis](https://img-global.cpcdn.com/recipes/945a8907d9ab9747/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan renyah. Ciri khas makanan Nusantara kue nona manis yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Kue nona manis untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang bisa anda praktekkan salah satunya kue nona manis yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue nona manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 15 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue nona manis:

1. Jangan lupa  Bahan 1 :
1. Jangan lupa 1 butir telur ayam
1. Harus ada 80 gr gula pasir
1. Siapkan 250 ml santan kental
1. Dibutuhkan 140 gr terigu
1. Tambah  Bahan 2 :
1. Jangan lupa 250 ml santan di blender dengan daun suji
1. Diperlukan 40 gr gula pasir
1. Jangan lupa 30 gr maizena
1. Jangan lupa 1/2 sdt garam
1. Tambah  Bahan 3 :
1. Jangan lupa 300 ml santan kental
1. Diperlukan 2 sdm gula pasir
1. Tambah 4 sdm tepung terigu (me: + maizena dikit)
1. Tambah 1/2 sdm garam




<!--inarticleads2-->

##### Langkah membuat  Kue nona manis:

1. Siapkan kukusan dan cetakan talam yg telah dioles tipis minyak terlebih dulu
1. Bahan 1 : Kocok telur dan gula pasir sampai mengembang. Turunkan kecepatan mixer, masukkan terigu, kocok rata. Tuang santan lalu aduk sampai rata.
1. Bahan 2 : Campur santan suji, gula pasir dan maizena. Masak diatas kompor sambil diaduk terus sampai meletup-letup. Angkat.
1. Campurkan adonan 1 dan 2. Gunakan mixer hingga tercampur rata. Sisihkan. Panaskan dandang untuk mengukus.
1. Bahan 3 : Campur santan kental, gula, terigu, maizena dan garam aduk hingga rata dan tidak bergerindil. Masak sambil diaduk terus agar santan tidak pecah. Jgn terlalu lama, Setelah mendidih angkat segera dari kompor. Dan terus diaduk2 spy tdk bergerindil. Siapkan cetakkan cucing yang sudah diolesi minyak. Tuang adonan pandan hingga hampir penuh. Beri tengahnya adonan santan menggunakan piping bag. Kukus selama kurang lebih 7-10 menit (tergantung besar kecilnya cucing) dengan panas sedang.
1. Angkat dari kukusan. Agar lbh mudah dikeluarkan dr cucing, dinginkan dlm chiller sebentar.




Demikianlah cara membuat kue nona manis yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat gampang dan cepat, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
