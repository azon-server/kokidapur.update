---
description: "Resep : Angsle Malang Sempurna"
title: "Resep : Angsle Malang Sempurna"
slug: 484-resep-angsle-malang-sempurna
date: 2020-12-13T06:37:05.506Z
image: https://img-global.cpcdn.com/recipes/66d7ff88bdc102f9/680x482cq70/angsle-malang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/66d7ff88bdc102f9/680x482cq70/angsle-malang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/66d7ff88bdc102f9/680x482cq70/angsle-malang-foto-resep-utama.jpg
author: Vera Griffith
ratingvalue: 4.5
reviewcount: 48166
recipeingredient:
- "100 gr ketan putih rendam 1 jam"
- "100 gr kacang hijau"
- "2 lb daun pandan simpulkan"
- "50 gr sagu mutiara"
- "5 lb roti tawar"
- "50 gr kacang tanah kupas goreng"
- " Kuah santan "
- "700 ml santan"
- "150 gr gula pasir"
- "Sejempol Jahe memarkan"
- "2 lb daun pandan simpulkan"
- "1/2 sdt garam"
- "Secukupnya SKM"
recipeinstructions:
- "Ketan : masak seperti memasak nasi, bisa dengan magic com atau manual. Masak hingga matang, kemudian sisihkan"
- "Kacang hijau : aku pakai metode 5.30.7 cuci bersih kacang hijau, rebus air secukupnya. Setelah mendidih, masukkan kacang hijau, daun pandan dan garam. Rebus hingga 5 menit. Matikan api, tutup panci. Biarkan hingga 30 menit. Nyalakan kompor, tambahkan sedikit gula, masak kembali selama 7 menit hingga kacang hijau benar2 matang."
- "‎Mutiara : aku juga pakai metode 5.30.7 rebus air secukupnya. Setelah mendidih, masukkan sagu mutiara dan pewarna merah. Rebus hingga 5 menit. Matikan api, tutup panci. Biarkan hingga 30 menit. Nyalakan kompor, tambahkan sedikit gula, masak kembali selama 7 menit hingga sagu mutiara benar2 matang."
- "Kuah santan : campur santan bersama gula pasir, Jahe, vanili, daun pandan, dan garam. Didihkan sambil di aduk2 supaya santan tidak pecah. Matikan api"
- "Penyajian : tata dalam mangkok, Ketan, Kacang hijau, Mutiara, dan potongan roti. Siram dengan kuah santan panas. Beri SKM di atasnya dan taburan kacang goreng."
categories:
- Recipe
tags:
- angsle
- malang

katakunci: angsle malang 
nutrition: 105 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT35M"
recipeyield: "2"
recipecategory: Dessert

---


![Angsle Malang](https://img-global.cpcdn.com/recipes/66d7ff88bdc102f9/680x482cq70/angsle-malang-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau empuk. Ciri khas masakan Nusantara angsle malang yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kehangatan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Angsle Malang untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda contoh salah satunya angsle malang yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep angsle malang tanpa harus bersusah payah.
Seperti resep Angsle Malang yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 13 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Angsle Malang:

1. Dibutuhkan 100 gr ketan putih, rendam 1 jam
1. Harap siapkan 100 gr kacang hijau
1. Tambah 2 lb daun pandan, simpulkan
1. Harus ada 50 gr sagu mutiara
1. Tambah 5 lb roti tawar
1. Harus ada 50 gr kacang tanah kupas, goreng
1. Siapkan  Kuah santan :
1. Harus ada 700 ml santan
1. Jangan lupa 150 gr gula pasir
1. Tambah Sejempol Jahe, memarkan
1. Tambah 2 lb daun pandan, simpulkan
1. Dibutuhkan 1/2 sdt garam
1. Harap siapkan Secukupnya SKM




<!--inarticleads2-->

##### Langkah membuat  Angsle Malang:

1. Ketan : masak seperti memasak nasi, bisa dengan magic com atau manual. Masak hingga matang, kemudian sisihkan
1. Kacang hijau : aku pakai metode 5.30.7 cuci bersih kacang hijau, rebus air secukupnya. Setelah mendidih, masukkan kacang hijau, daun pandan dan garam. Rebus hingga 5 menit. Matikan api, tutup panci. Biarkan hingga 30 menit. Nyalakan kompor, tambahkan sedikit gula, masak kembali selama 7 menit hingga kacang hijau benar2 matang.
1. ‎Mutiara : aku juga pakai metode 5.30.7 rebus air secukupnya. Setelah mendidih, masukkan sagu mutiara dan pewarna merah. Rebus hingga 5 menit. Matikan api, tutup panci. Biarkan hingga 30 menit. Nyalakan kompor, tambahkan sedikit gula, masak kembali selama 7 menit hingga sagu mutiara benar2 matang.
1. Kuah santan : campur santan bersama gula pasir, Jahe, vanili, daun pandan, dan garam. Didihkan sambil di aduk2 supaya santan tidak pecah. Matikan api
1. Penyajian : tata dalam mangkok, Ketan, Kacang hijau, Mutiara, dan potongan roti. Siram dengan kuah santan panas. Beri SKM di atasnya dan taburan kacang goreng.




Demikianlah cara membuat angsle malang yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan cepat, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
