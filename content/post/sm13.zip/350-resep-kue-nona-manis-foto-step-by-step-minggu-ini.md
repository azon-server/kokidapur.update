---
description: "Resep : Kue Nona Manis + foto step by step minggu ini"
title: "Resep : Kue Nona Manis + foto step by step minggu ini"
slug: 350-resep-kue-nona-manis-foto-step-by-step-minggu-ini
date: 2020-10-17T20:56:10.802Z
image: https://img-global.cpcdn.com/recipes/1fa1387442ab30b2/680x482cq70/kue-nona-manis-foto-step-by-step-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1fa1387442ab30b2/680x482cq70/kue-nona-manis-foto-step-by-step-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1fa1387442ab30b2/680x482cq70/kue-nona-manis-foto-step-by-step-foto-resep-utama.jpg
author: Helen Cooper
ratingvalue: 4.3
reviewcount: 9030
recipeingredient:
- " Bahan 1 "
- "500 ml santan kental"
- "6 sdm terigu"
- "Sejumput garam"
- " Bahan 2 "
- "250 ml santan kental"
- "40 gram gula pasir 2 sdm"
- "30 gram maizena 25 sdm"
- "1 sdt pasta pandan secukupnya"
- "Sejumput garam"
- " Bahan 3 "
- "250 ml santan kental"
- "1 butir telur"
- "80 gram gula pasir 4 sdm"
- "140 gram terigu 1 gelas blimbing  1 sdm munjung"
recipeinstructions:
- "Siapkan cetakan,oles minyak goreng tipis-tipis,sisihkan."
- "Bahan 1 (adonan putih) : Masak semua bahan 1 dengan api kecil sampai beruap dan sedikit meletup,matikan kompor,aduk terus sampai adonan kental,halus dan tidak bergerindil.Angkat.Biarkan dingin."
- "Masukkan adonan putih (adonan bahan 1) ke dalam botol (atau bisa pakai plastik segitiga/piping bag) untuk memudahkan menuangkannya nanti dan supaya hasil kuenya rapih bagian tengah putihnya.Sisihkan."
- "Bahan 2 : Masak semua bahan 2 dengan api kecil,aduk terus sampai menjadi adonan yg kental,matikan kompor,sisihkan.Biarkan dingin."
- "Bahan 3 : Di wadah lain,kocok telur dan gula sampai gula larut menggunakan baloon whisk,masukkan santan dan terigu secara bertahap,aduk rata.Masukkan adonan bahan 2 sedikit demi sedikit,aduk rata sampai menjadi adonan yg halus dan tidak bergerindil."
- "Hasilnya seperti ini (adonan hijau)"
- "Panaskan kukusan dengan air secukupnya,alasi penutupnya dengan serbet/kain bersih agar air tidak menetes ke adonan."
- "Tuang 3/4 adonan hijau ke dalam cetakan lalu tuang/semprot adonan putih di tengahnya sampai agak penuh,benamkan sedikit moncong botolnya ya.Lakukan sampai semua adonan habis."
- "Kukus selama 10 menit dengan api sedang cenderung kecil.Angkat."
- "Tunggu dingin dulu baru di keluarkan dari cetakan ya."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 264 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Lunch

---


![Kue Nona Manis + foto step by step](https://img-global.cpcdn.com/recipes/1fa1387442ab30b2/680x482cq70/kue-nona-manis-foto-step-by-step-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti kue nona manis + foto step by step yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Nusantara

Kedekatan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah membuat makanan Kue Nona Manis + foto step by step untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang dapat anda buat salah satunya kue nona manis + foto step by step yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep kue nona manis + foto step by step tanpa harus bersusah payah.
Seperti resep Kue Nona Manis + foto step by step yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 15 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis + foto step by step:

1. Harus ada  Bahan 1 :
1. Harus ada 500 ml santan kental
1. Dibutuhkan 6 sdm terigu
1. Diperlukan Sejumput garam
1. Jangan lupa  Bahan 2 :
1. Jangan lupa 250 ml santan kental
1. Siapkan 40 gram gula pasir (2 sdm)
1. Dibutuhkan 30 gram maizena (2,5 sdm)
1. Harap siapkan 1 sdt pasta pandan (secukupnya)
1. Harap siapkan Sejumput garam
1. Harap siapkan  Bahan 3 :
1. Tambah 250 ml santan kental
1. Harus ada 1 butir telur
1. Siapkan 80 gram gula pasir (4 sdm)
1. Siapkan 140 gram terigu (1 gelas blimbing + 1 sdm munjung)




<!--inarticleads2-->

##### Bagaimana membuat  Kue Nona Manis + foto step by step:

1. Siapkan cetakan,oles minyak goreng tipis-tipis,sisihkan.
1. Bahan 1 (adonan putih) : Masak semua bahan 1 dengan api kecil sampai beruap dan sedikit meletup,matikan kompor,aduk terus sampai adonan kental,halus dan tidak bergerindil.Angkat.Biarkan dingin.
1. Masukkan adonan putih (adonan bahan 1) ke dalam botol (atau bisa pakai plastik segitiga/piping bag) untuk memudahkan menuangkannya nanti dan supaya hasil kuenya rapih bagian tengah putihnya.Sisihkan.
1. Bahan 2 : Masak semua bahan 2 dengan api kecil,aduk terus sampai menjadi adonan yg kental,matikan kompor,sisihkan.Biarkan dingin.
1. Bahan 3 : Di wadah lain,kocok telur dan gula sampai gula larut menggunakan baloon whisk,masukkan santan dan terigu secara bertahap,aduk rata.Masukkan adonan bahan 2 sedikit demi sedikit,aduk rata sampai menjadi adonan yg halus dan tidak bergerindil.
1. Hasilnya seperti ini (adonan hijau)
1. Panaskan kukusan dengan air secukupnya,alasi penutupnya dengan serbet/kain bersih agar air tidak menetes ke adonan.
1. Tuang 3/4 adonan hijau ke dalam cetakan lalu tuang/semprot adonan putih di tengahnya sampai agak penuh,benamkan sedikit moncong botolnya ya.Lakukan sampai semua adonan habis.
1. Kukus selama 10 menit dengan api sedang cenderung kecil.Angkat.
1. Tunggu dingin dulu baru di keluarkan dari cetakan ya.




Demikianlah cara membuat kue nona manis + foto step by step yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
