---
description: "Bagaimana untuk menyiapakan Si Nona Manis (Talam Pandan) Luar biasa"
title: "Bagaimana untuk menyiapakan Si Nona Manis (Talam Pandan) Luar biasa"
slug: 285-bagaimana-untuk-menyiapakan-si-nona-manis-talam-pandan-luar-biasa
date: 2021-01-14T00:10:39.128Z
image: https://img-global.cpcdn.com/recipes/6eb31e1bc3d1a2f8/680x482cq70/si-nona-manis-talam-pandan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6eb31e1bc3d1a2f8/680x482cq70/si-nona-manis-talam-pandan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6eb31e1bc3d1a2f8/680x482cq70/si-nona-manis-talam-pandan-foto-resep-utama.jpg
author: Abbie McBride
ratingvalue: 4.8
reviewcount: 12785
recipeingredient:
- " Bahan Pertama adonan hijau "
- "150 gr Tepung beras"
- "80 gr Gula pasir"
- "400 ml Santan 200ml santan instan  200 ml susu UHT yg plain"
- "secukupnya pasta pandan sesuai selera"
- "1/2 sdt garam"
- "1 lbr Daun Pandan"
- " Bahan Kedua adonan putih "
- "50 gr Tepung Beras"
- "200 ml Santan 65 ml santan instan  135 ml susu UHT yg plain"
- "1/2 sdt garam"
- "1 lbr Daun Pandan"
recipeinstructions:
- "Siapkan adonan pertama (adonan hijau)"
- "Campur...larutan santan dan susu td,masukan gula,garam,pasta pandan dan daun pandan....masak sebentar sampai gula larut saja jgn lama2.....lalu angkat...segera masukan tepung beras lalu aduk2 sampai rata...lalu saring sehingga adonan tdk bergerindil....sisihkan"
- "Siapkan lagi adonan kedua (adonan putih)"
- "Campur larutan santan dan susu tadi,lalu masukan garam dan daun pandan....masak sebentar saja...sampai agak anget...segera angkat...lalu masukan tepung beras nya...aduk2 sampai tercampur rata...sisihkan"
- "Langkah selanjutnya kita siapkan cetakannya lalu kita oles dgn minyak goreng tipis2"
- "Untuk kukusan....kita siapkan panci kukusan....lalu panaskan dan utk tutup panci nya...kita lapisi dgn kain atau serbet agar uap air nanti tdk jatuh kepermukaan kue"
- "Masukan adonan hijau sbyk 3/4 dr cetakan lalu segera kukus selama sepuluh menit dgn api sedang saja...jgn mengukus dgn api besar...krn akan membuar permukaan kue tdk rata atau bergelombang"
- "Setelah 10 menit mengukus adonan hijau...dan permukaan kue tampak lembab...segera masukan adonan putihnya dan kukus lg sekitar 15 menitan sampai matang"
- "Setelah matang....angkat...biarkan sebentar sampai agak hangat lalu keluarkan kue dr cetakan...."
- "Tata kue....dan hias dgn potongan daun pandan....lalu siap d santap....selamat mencoba"
- "🙏"
categories:
- Recipe
tags:
- si
- nona
- manis

katakunci: si nona manis 
nutrition: 248 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Lunch

---


![Si Nona Manis (Talam Pandan)](https://img-global.cpcdn.com/recipes/6eb31e1bc3d1a2f8/680x482cq70/si-nona-manis-talam-pandan-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang patut kita lestarikan karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti si nona manis (talam pandan) yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Nusantara



Kehangatan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Si Nona Manis (Talam Pandan) untuk keluarga. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang bisa anda coba salah satunya si nona manis (talam pandan) yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep si nona manis (talam pandan) tanpa harus bersusah payah.
Berikut ini resep Si Nona Manis (Talam Pandan) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 11 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Si Nona Manis (Talam Pandan):

1. Harus ada  Bahan Pertama (adonan hijau) :
1. Harap siapkan 150 gr Tepung beras
1. Diperlukan 80 gr Gula pasir
1. Jangan lupa 400 ml Santan (200ml santan instan + 200 ml susu UHT yg plain)
1. Harus ada secukupnya pasta pandan sesuai selera
1. Dibutuhkan 1/2 sdt garam
1. Harus ada 1 lbr Daun Pandan
1. Diperlukan  Bahan Kedua (adonan putih) :
1. Harap siapkan 50 gr Tepung Beras
1. Diperlukan 200 ml Santan (65 ml santan instan + 135 ml susu UHT yg plain)
1. Harap siapkan 1/2 sdt garam
1. Harap siapkan 1 lbr Daun Pandan




<!--inarticleads2-->

##### Langkah membuat  Si Nona Manis (Talam Pandan):

1. Siapkan adonan pertama (adonan hijau)
1. Campur...larutan santan dan susu td,masukan gula,garam,pasta pandan dan daun pandan....masak sebentar sampai gula larut saja jgn lama2.....lalu angkat...segera masukan tepung beras lalu aduk2 sampai rata...lalu saring sehingga adonan tdk bergerindil....sisihkan
1. Siapkan lagi adonan kedua (adonan putih)
1. Campur larutan santan dan susu tadi,lalu masukan garam dan daun pandan....masak sebentar saja...sampai agak anget...segera angkat...lalu masukan tepung beras nya...aduk2 sampai tercampur rata...sisihkan
1. Langkah selanjutnya kita siapkan cetakannya lalu kita oles dgn minyak goreng tipis2
1. Untuk kukusan....kita siapkan panci kukusan....lalu panaskan dan utk tutup panci nya...kita lapisi dgn kain atau serbet agar uap air nanti tdk jatuh kepermukaan kue
1. Masukan adonan hijau sbyk 3/4 dr cetakan lalu segera kukus selama sepuluh menit dgn api sedang saja...jgn mengukus dgn api besar...krn akan membuar permukaan kue tdk rata atau bergelombang
1. Setelah 10 menit mengukus adonan hijau...dan permukaan kue tampak lembab...segera masukan adonan putihnya dan kukus lg sekitar 15 menitan sampai matang
1. Setelah matang....angkat...biarkan sebentar sampai agak hangat lalu keluarkan kue dr cetakan....
1. Tata kue....dan hias dgn potongan daun pandan....lalu siap d santap....selamat mencoba
1. 🙏




Demikianlah cara membuat si nona manis (talam pandan) yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan teruji, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
