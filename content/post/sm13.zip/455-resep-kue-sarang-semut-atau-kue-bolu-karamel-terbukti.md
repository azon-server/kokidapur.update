---
description: "Resep : Kue Sarang Semut atau Kue Bolu Karamel Terbukti"
title: "Resep : Kue Sarang Semut atau Kue Bolu Karamel Terbukti"
slug: 455-resep-kue-sarang-semut-atau-kue-bolu-karamel-terbukti
date: 2021-01-14T18:17:13.768Z
image: https://img-global.cpcdn.com/recipes/67d948ed6229daea/680x482cq70/kue-sarang-semut-atau-kue-bolu-karamel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/67d948ed6229daea/680x482cq70/kue-sarang-semut-atau-kue-bolu-karamel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/67d948ed6229daea/680x482cq70/kue-sarang-semut-atau-kue-bolu-karamel-foto-resep-utama.jpg
author: Edna Hodges
ratingvalue: 4.6
reviewcount: 22414
recipeingredient:
- "425 gr Gula Pasir Merk Gula Ku"
- "450 gr Air Panas"
- "150 gr Margarin suhu Ruang Merk Blue Band"
- "200 gr Susu Putih Kental Manis Merk Cap Nona"
- "8 Butir atau 400 gr Telur Ayam"
- "180 gr Tepung Terigu Protein Sedang Merk Segitiga Biru"
- "50 gr Tepung Jagung Merk Maizenna"
- "10 gr Baking Soda Soda Kue Merk Koepoe Koepoe"
recipeinstructions:
- "Panaskan Teplon Untuk Gula Pasir biar kan sampai karamel JANGAN DIADUK BIARKAN SAJA..ketika sudah karamel tuang Air Panas sedikit demi sedikit dan Aduk hingga tercampur dan matang gunakan api sedang saja karna mudah GoSong angkat lalu biar kan saus karamel sampai Suhu Ruang"
- "Campur Susu Kental Manis Putih dengan Mentega Suhu Ruang Kocok tidak usah sampai rata sekali ya lalu masukkan Saus Karamel tadi yang sudah dingin lalu Aduk lagi"
- "Masukkan Telur Ayam aduk Hingga Merata saja..lalu Masukkan Tepung Terigu,Soda Kue dan Tepung Jagung Maizenna aduk lagi"
- "Alasi loyang dengan Mentega Tipis saja..lalu Tuang ke loyang...Jangan lupa Panaskan Oven 10 menit sebelum Memanggang yaa"
- "Panggang dengan Suhu 180⁰C selama 40 Menit"
- "Bila sudah Matang diamkan dulu disuhu Ruang lalu Potong dan sajikan..Selamat Mencoba"
categories:
- Recipe
tags:
- kue
- sarang
- semut

katakunci: kue sarang semut 
nutrition: 137 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dinner

---


![Kue Sarang Semut atau Kue Bolu Karamel](https://img-global.cpcdn.com/recipes/67d948ed6229daea/680x482cq70/kue-sarang-semut-atau-kue-bolu-karamel-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga empuk. Ciri khas makanan Indonesia kue sarang semut atau kue bolu karamel yang kaya dengan rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kedekatan keluarga bisa didapat dengan cara simple. Diantaranya adalah memasak Kue Sarang Semut atau Kue Bolu Karamel untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang bisa anda contoh salah satunya kue sarang semut atau kue bolu karamel yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep kue sarang semut atau kue bolu karamel tanpa harus bersusah payah.
Berikut ini resep Kue Sarang Semut atau Kue Bolu Karamel yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Sarang Semut atau Kue Bolu Karamel:

1. Diperlukan 425 gr Gula Pasir Merk Gula Ku
1. Harap siapkan 450 gr Air Panas
1. Harap siapkan 150 gr Margarin suhu Ruang Merk Blue Band
1. Jangan lupa 200 gr Susu Putih Kental Manis Merk Cap Nona
1. Jangan lupa 8 Butir atau 400 gr Telur Ayam
1. Tambah 180 gr Tepung Terigu Protein Sedang Merk Segitiga Biru
1. Tambah 50 gr Tepung Jagung Merk Maizenna
1. Tambah 10 gr Baking Soda /Soda Kue Merk Koepoe Koepoe




<!--inarticleads2-->

##### Instruksi membuat  Kue Sarang Semut atau Kue Bolu Karamel:

1. Panaskan Teplon Untuk Gula Pasir biar kan sampai karamel JANGAN DIADUK BIARKAN SAJA..ketika sudah karamel tuang Air Panas sedikit demi sedikit dan Aduk hingga tercampur dan matang gunakan api sedang saja karna mudah GoSong angkat lalu biar kan saus karamel sampai Suhu Ruang
1. Campur Susu Kental Manis Putih dengan Mentega Suhu Ruang Kocok tidak usah sampai rata sekali ya lalu masukkan Saus Karamel tadi yang sudah dingin lalu Aduk lagi
1. Masukkan Telur Ayam aduk Hingga Merata saja..lalu Masukkan Tepung Terigu,Soda Kue dan Tepung Jagung Maizenna aduk lagi
1. Alasi loyang dengan Mentega Tipis saja..lalu Tuang ke loyang...Jangan lupa Panaskan Oven 10 menit sebelum Memanggang yaa
1. Panggang dengan Suhu 180⁰C selama 40 Menit
1. Bila sudah Matang diamkan dulu disuhu Ruang lalu Potong dan sajikan..Selamat Mencoba




Demikianlah cara membuat kue sarang semut atau kue bolu karamel yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat mudah dan teruji, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
