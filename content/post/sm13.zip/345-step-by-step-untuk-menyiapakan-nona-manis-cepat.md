---
description: "Step-by-Step untuk menyiapakan Nona Manis💁‍♀️ Cepat"
title: "Step-by-Step untuk menyiapakan Nona Manis💁‍♀️ Cepat"
slug: 345-step-by-step-untuk-menyiapakan-nona-manis-cepat
date: 2020-11-10T08:03:14.557Z
image: https://img-global.cpcdn.com/recipes/8d1e5674e344863b/680x482cq70/nona-manis💁♀️-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8d1e5674e344863b/680x482cq70/nona-manis💁♀️-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8d1e5674e344863b/680x482cq70/nona-manis💁♀️-foto-resep-utama.jpg
author: Amelia Hampton
ratingvalue: 4.3
reviewcount: 23786
recipeingredient:
- " Bahan A"
- "1 butir telur"
- "120 gr gula pasir"
- "250 santan kental"
- "125 tepung terigu"
- " Bahan B"
- "300 ml santan kental"
- "60 gr gula pasir"
- "30 gr maizena"
- "Sejumput garam"
- "10 helai daun pandan"
- "1 tetes pewarna makanan hijau mudaboleh skip"
- " Bahan C"
- "250 ml santan kental"
- "1 sdm munjung tepung terigu"
- "1 sdm gula pasir"
- "1/2 sdt garam"
recipeinstructions:
- "Campur semua bahan A jadi satu kecuali telur aduk rata hingga gula larut pakai whisker, lalu masukkan telur aduk rata sisihkan"
- "Bahan B: blender santan dan daun pandan, saring(ambil airnya saja)"
- "Campur semua bahan jadi satu, kemudian masak dg api kecil aduk terus sampai meletup, matikan api."
- "Masukkan bahan A aduk rata"
- "Bahan C : campur semua bahan aduk rata, masak dgn api kecil asal meletup aja jangan terlalu lama agar tidak menggumpal"
- "Cara: 1. panaskan kukusan 2.oles cetakan kue talam dg minyak hingga rata 3. Isi adonan hijau hingga 3/4 cetakan 4.tuangkan 1sdm adonan putih tepat ditengah 5. Kukus 10mnt, setelah dingin keluarkan kue perlahan dari cetakan"
- ""
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 148 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Dessert

---


![Nona Manis💁‍♀️](https://img-global.cpcdn.com/recipes/8d1e5674e344863b/680x482cq70/nona-manis💁♀️-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau gurih. Ciri khas kuliner Indonesia nona manis💁‍♀️ yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan keluarga bisa didapat dengan cara mudah. Salah satunya adalah memasak Nona Manis💁‍♀️ untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi budaya, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda praktekkan salah satunya nona manis💁‍♀️ yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep nona manis💁‍♀️ tanpa harus bersusah payah.
Berikut ini resep Nona Manis💁‍♀️ yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona Manis💁‍♀️:

1. Harap siapkan  Bahan A
1. Jangan lupa 1 butir telur
1. Dibutuhkan 120 gr gula pasir
1. Tambah 250 santan kental
1. Siapkan 125 tepung terigu
1. Dibutuhkan  Bahan B
1. Jangan lupa 300 ml santan kental
1. Tambah 60 gr gula pasir
1. Tambah 30 gr maizena
1. Jangan lupa Sejumput garam
1. Jangan lupa 10 helai daun pandan
1. Dibutuhkan 1 tetes pewarna makanan hijau muda(boleh skip)
1. Siapkan  Bahan C
1. Harap siapkan 250 ml santan kental
1. Tambah 1 sdm munjung tepung terigu
1. Jangan lupa 1 sdm gula pasir
1. Diperlukan 1/2 sdt garam




<!--inarticleads2-->

##### Langkah membuat  Nona Manis💁‍♀️:

1. Campur semua bahan A jadi satu kecuali telur aduk rata hingga gula larut pakai whisker, lalu masukkan telur aduk rata sisihkan
1. Bahan B: blender santan dan daun pandan, saring(ambil airnya saja)
1. Campur semua bahan jadi satu, kemudian masak dg api kecil aduk terus sampai meletup, matikan api.
1. Masukkan bahan A aduk rata
1. Bahan C : campur semua bahan aduk rata, masak dgn api kecil asal meletup aja jangan terlalu lama agar tidak menggumpal
1. Cara: 1. panaskan kukusan 2.oles cetakan kue talam dg minyak hingga rata 3. Isi adonan hijau hingga 3/4 cetakan 4.tuangkan 1sdm adonan putih tepat ditengah 5. Kukus 10mnt, setelah dingin keluarkan kue perlahan dari cetakan
1. 




Demikianlah cara membuat nona manis💁‍♀️ yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
