---
description: "Resep : Kue Nona Manis Homemade"
title: "Resep : Kue Nona Manis Homemade"
slug: 242-resep-kue-nona-manis-homemade
date: 2020-09-21T13:02:28.785Z
image: https://img-global.cpcdn.com/recipes/af089b765408e183/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/af089b765408e183/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/af089b765408e183/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Jon Frank
ratingvalue: 4
reviewcount: 18969
recipeingredient:
- " Bahan A"
- "1 butir telur"
- "145 gr terigu"
- "100 gr gula"
- "250 ml santan"
- " Bahan B"
- "250 ml santan"
- "1/2 sdt pasta pandansesuai selera"
- "55 gr gula"
- "30 gr maizena"
- "1/4 sdt garam"
- " Bahan C"
- "250 ml santan"
- "1 sdm terigu"
- "1 sdm gula"
- "1/2 sdt garam"
recipeinstructions:
- "Masak bahan C hingga meletup2,dinginkan lalu masukkan kedalam pipingbag.berhubung ga ada,JD sy biarkan dingin SJ dimangkok,nanti nuangnya pake sendok kecil😁"
- "Campur semua bahan B,masak hingga meletup2.sisihkan"
- "Mixer/bs juga menggunakan whisker,kocok gula dan telur hingga berbusa,tambahkan santan dan terigu.aduk hingga semua tercampur rata"
- "Lalu tuang bahan A ke adonan B(adonan ijo).aduk2 hingga semua tercampur rata"
- "Siapakan cetakan kue mangkok,olesi dengan minyak,tuang adonan hijau 3/4 cup,lalu beri tengahnya dgn adonan putih sesuai selera(me:1sdt)"
- "Kukus selama 10menit.api sedang saja.jgn lupa utk tutup kukusan dialasi serbet bersih agar air Tdk menetes pada kue.Sajikan utk temen camilan pagi,siang,sore semua cocok😁😁"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 178 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Dinner

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/af089b765408e183/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita jaga karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti kue nona manis yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Kita

Keharmonisan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah memasak Kue Nona Manis untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi budaya, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang dapat anda buat salah satunya kue nona manis yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 16 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Harap siapkan  Bahan A:
1. Tambah 1 butir telur
1. Siapkan 145 gr terigu
1. Dibutuhkan 100 gr gula
1. Dibutuhkan 250 ml santan
1. Siapkan  Bahan B:
1. Harap siapkan 250 ml santan
1. Siapkan 1/2 sdt pasta pandan(sesuai selera)
1. Jangan lupa 55 gr gula
1. Tambah 30 gr maizena
1. Diperlukan 1/4 sdt garam
1. Dibutuhkan  Bahan C:
1. Tambah 250 ml santan
1. Tambah 1 sdm terigu
1. Harus ada 1 sdm gula
1. Tambah 1/2 sdt garam




<!--inarticleads2-->

##### Instruksi membuat  Kue Nona Manis:

1. Masak bahan C hingga meletup2,dinginkan lalu masukkan kedalam pipingbag.berhubung ga ada,JD sy biarkan dingin SJ dimangkok,nanti nuangnya pake sendok kecil😁
1. Campur semua bahan B,masak hingga meletup2.sisihkan
1. Mixer/bs juga menggunakan whisker,kocok gula dan telur hingga berbusa,tambahkan santan dan terigu.aduk hingga semua tercampur rata
1. Lalu tuang bahan A ke adonan B(adonan ijo).aduk2 hingga semua tercampur rata
1. Siapakan cetakan kue mangkok,olesi dengan minyak,tuang adonan hijau 3/4 cup,lalu beri tengahnya dgn adonan putih sesuai selera(me:1sdt)
1. Kukus selama 10menit.api sedang saja.jgn lupa utk tutup kukusan dialasi serbet bersih agar air Tdk menetes pada kue.Sajikan utk temen camilan pagi,siang,sore semua cocok😁😁




Demikianlah cara membuat kue nona manis yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
