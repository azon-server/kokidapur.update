---
description: "Cara singkat membuat Kue nona manis Luar biasa"
title: "Cara singkat membuat Kue nona manis Luar biasa"
slug: 259-cara-singkat-membuat-kue-nona-manis-luar-biasa
date: 2020-10-01T19:25:09.681Z
image: https://img-global.cpcdn.com/recipes/5403bd714c016ab8/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5403bd714c016ab8/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5403bd714c016ab8/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Dominic Webster
ratingvalue: 4.5
reviewcount: 7711
recipeingredient:
- " Bahan 1"
- "2 Bks santan kara ukuran 65ml"
- "6 sdm tepung terigu"
- "350 ml air"
- "Sejumput garam"
- "3 sdm susu bubuk"
- "1 lmbr daun pandan"
- " Bahan 2"
- "2 Bks santan kara"
- "4 sdm gula pasir"
- "2,5 sdm tepung maizena"
- " Pewarna makanan sesuai selera saya ada pink dan hijau"
- "120 ml air"
- "1 lembar daun pandan"
- " Bahan 3"
- "2 Bks santan kara"
- "2 btr telur ayam"
- "4 sdm gula pasir"
- "14 sdm tepung terigu"
- "120 ml air"
recipeinstructions:
- "Campur semua bahan 1 aduk hingga tidak menggerindil baru nyalakan kompor. Aduk terus ya biar g menggumpal. Matikan api jika tekstur sudah pas lalu sisihkan"
- "Campur semua bahan 2 kecuali pewarna makanan. Lakukan langkahnya seperti di bahan 1."
- "Aduk gula dan telur dari bahan 3 hingga gula larut. Kemudian masukkan santan yg sudah dilarutkan dalam air baru tepung. Aduk hingga tidak ada yg bergerindil."
- "Masukkan adonan dari bahan 1 kedalam piping bag"
- "Adonan dari bahan 2 bagi jadi dua. Lalu masing2 beri warna merah muda dan hijau."
- "Bagi adonan 3 jadi dua bagian. Setelah dibagi masukkan ke dalam adonan hijau dan sebagian ke adonan warna merah muda. Aduk hingga adonan 2 dan 3 tercampur rata"
- "Panaskan kukusan. Olesi cetakan dengan minyak goreng. Masukkan adonan merah muda dan hijau ke dalam cetakan"
- "Benamkan ujung paling bag kedalam cetakan yg berisi adonan. Lalu tekan hingga adonan 1 keluar"
- "Kukus sekitar 10-15 menit. Setelah matang kue nona manis siap disajikan. Selamat menikmati"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 100 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Dessert

---


![Kue nona manis](https://img-global.cpcdn.com/recipes/5403bd714c016ab8/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang dapat kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti kue nona manis yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa ciri khas yang merupakan keragaman Kita

Kue nona manis adalah salah satu jajanan tradisional yang melegenda di Indonesia. Ada yang tahu kue nona manis? SALAH satu jajanan pasar kue nona manis rasanya sudah jarang ditemui. Meski langkahnya sedikit rumit, ada rasa puas tersendiri saat berhasil membuat kue nona manis.

Keharmonisan keluarga dapat diperoleh dengan cara mudah. Diantaranya adalah memasak Kue nona manis untuk keluarga. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi makanan yang dapat anda praktekkan salah satunya kue nona manis yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue nona manis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 20 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue nona manis:

1. Harus ada  Bahan 1
1. Harus ada 2 Bks santan kara (ukuran 65ml)
1. Harap siapkan 6 sdm tepung terigu
1. Jangan lupa 350 ml air
1. Harus ada Sejumput garam
1. Jangan lupa 3 sdm susu bubuk
1. Harap siapkan 1 lmbr daun pandan
1. Siapkan  Bahan 2
1. Tambah 2 Bks santan kara
1. Diperlukan 4 sdm gula pasir
1. Jangan lupa 2,5 sdm tepung maizena
1. Diperlukan  Pewarna makanan sesuai selera (saya ada pink dan hijau)
1. Diperlukan 120 ml air
1. Tambah 1 lembar daun pandan
1. Diperlukan  Bahan 3
1. Jangan lupa 2 Bks santan kara
1. Tambah 2 btr telur ayam
1. Tambah 4 sdm gula pasir
1. Siapkan 14 sdm tepung terigu
1. Tambah 120 ml air


Nona manis adalah kue khas Sulawesi. Teksturnya lebih lembut dari kue talam Indonesia lainnya. Bagian yang berwarna hijau rasanya manis dan gurih santan, sedangkan bagian yang berwarna putih. Aih, sudah lama rasanya tidak mendengar Kue Nona Manis. 

<!--inarticleads2-->

##### Bagaimana membuat  Kue nona manis:

1. Campur semua bahan 1 aduk hingga tidak menggerindil baru nyalakan kompor. Aduk terus ya biar g menggumpal. Matikan api jika tekstur sudah pas lalu sisihkan
1. Campur semua bahan 2 kecuali pewarna makanan. Lakukan langkahnya seperti di bahan 1.
1. Aduk gula dan telur dari bahan 3 hingga gula larut. Kemudian masukkan santan yg sudah dilarutkan dalam air baru tepung. Aduk hingga tidak ada yg bergerindil.
1. Masukkan adonan dari bahan 1 kedalam piping bag
1. Adonan dari bahan 2 bagi jadi dua. Lalu masing2 beri warna merah muda dan hijau.
1. Bagi adonan 3 jadi dua bagian. Setelah dibagi masukkan ke dalam adonan hijau dan sebagian ke adonan warna merah muda. Aduk hingga adonan 2 dan 3 tercampur rata
1. Panaskan kukusan. Olesi cetakan dengan minyak goreng. Masukkan adonan merah muda dan hijau ke dalam cetakan
1. Benamkan ujung paling bag kedalam cetakan yg berisi adonan. Lalu tekan hingga adonan 1 keluar
1. Kukus sekitar 10-15 menit. Setelah matang kue nona manis siap disajikan. Selamat menikmati


Bagian yang berwarna hijau rasanya manis dan gurih santan, sedangkan bagian yang berwarna putih. Aih, sudah lama rasanya tidak mendengar Kue Nona Manis. Camilan klasik ini bisa Bunda hadirkan kembali dengan warna menarik yang tidak akan ditolak oleh si kecil. Your current browser isn&#39;t compatible with SoundCloud. Please download one of our supported browsers. 

Demikianlah cara membuat kue nona manis yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan cepat, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
