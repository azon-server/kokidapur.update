---
description: "Resep : Kue Nona Manis Homemade"
title: "Resep : Kue Nona Manis Homemade"
slug: 296-resep-kue-nona-manis-homemade
date: 2020-11-16T07:10:24.512Z
image: https://img-global.cpcdn.com/recipes/e3088c0a823b0c01/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e3088c0a823b0c01/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e3088c0a823b0c01/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Bradley Johnson
ratingvalue: 4.6
reviewcount: 38194
recipeingredient:
- " Bahan Putih "
- "250 ml santan"
- "1 sdm tepung terigu"
- "1 sdm gula pasit"
- "1/2 sdt garam"
- " Bahan Hijau A "
- "125 sari pandan dr 10 lbr daun pandan  120 ml air"
- "125 ml santan"
- "50 gr gula pasir"
- "30 gr maizena"
- "1/4 sdt garam"
- " Bahan Hijau B "
- "1 butir telur"
- "100 gr gula pasir"
- "250 ml santan"
- "145 gr tepung terigu"
recipeinstructions:
- "Bahan putih : campur semua bahan,aduk rata, masak di api kecil hingga kental dan meletup2. Tunggu dingin, masukan di piping bag."
- "Bahan hijau A : buat sari pandan, potong2 daun pandan, blender, saring. Campur semua bahan hijau A, aduk rata, masak dgn api kecil hingga kental dan meletup2."
- "Penyelesaian bahan hijau : campur gula pasir dan telur, mixer hingga gula larut. Masukan santan dan terigu aduk rata."
- "Campur bahan hijau A dan B, aduk rata (bisa dgn mikser) hingga tercampur. Adonan menjadi agak cair."
- "Oleskan cetakan kue talam dgn sedikit minyak goreng, tuang adonan hijau 3/4 cetakan."
- "Tambahkan adonan putih, dgn cara menyemprot di tengah adonan hijau perlahan. Kukus selama 20 mnt dgn api kecil. Angkat dr kukusan keluarga dr cetakan kalau sdh dingin."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 219 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Dinner

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/e3088c0a823b0c01/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti kue nona manis yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Indonesia

Keharmonisan rumah tangga bisa ditemukan dengan cara sederhana. Diantaranya adalah memasak Kue Nona Manis untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis makanan yang dapat anda contoh salah satunya kue nona manis yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Siapkan  Bahan Putih :
1. Tambah 250 ml santan
1. Siapkan 1 sdm tepung terigu
1. Harap siapkan 1 sdm gula pasit
1. Tambah 1/2 sdt garam
1. Harap siapkan  Bahan Hijau A :
1. Tambah 125 sari pandan (dr 10 lbr daun pandan + 120 ml air)
1. Diperlukan 125 ml santan
1. Tambah 50 gr gula pasir
1. Jangan lupa 30 gr maizena
1. Harus ada 1/4 sdt garam
1. Diperlukan  Bahan Hijau B :
1. Tambah 1 butir telur
1. Harus ada 100 gr gula pasir
1. Jangan lupa 250 ml santan
1. Siapkan 145 gr tepung terigu




<!--inarticleads2-->

##### Bagaimana membuat  Kue Nona Manis:

1. Bahan putih : campur semua bahan,aduk rata, masak di api kecil hingga kental dan meletup2. Tunggu dingin, masukan di piping bag.
1. Bahan hijau A : buat sari pandan, potong2 daun pandan, blender, saring. Campur semua bahan hijau A, aduk rata, masak dgn api kecil hingga kental dan meletup2.
1. Penyelesaian bahan hijau : campur gula pasir dan telur, mixer hingga gula larut. Masukan santan dan terigu aduk rata.
1. Campur bahan hijau A dan B, aduk rata (bisa dgn mikser) hingga tercampur. Adonan menjadi agak cair.
1. Oleskan cetakan kue talam dgn sedikit minyak goreng, tuang adonan hijau 3/4 cetakan.
1. Tambahkan adonan putih, dgn cara menyemprot di tengah adonan hijau perlahan. Kukus selama 20 mnt dgn api kecil. Angkat dr kukusan keluarga dr cetakan kalau sdh dingin.




Demikianlah cara membuat kue nona manis yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
