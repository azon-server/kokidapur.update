---
description: "Cara menyiapakan Cumi Saus Padang terupdate"
title: "Cara menyiapakan Cumi Saus Padang terupdate"
slug: 17-cara-menyiapakan-cumi-saus-padang-terupdate
date: 2020-11-03T17:57:28.341Z
image: https://img-global.cpcdn.com/recipes/64c492d2b31de580/680x482cq70/cumi-saus-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/64c492d2b31de580/680x482cq70/cumi-saus-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/64c492d2b31de580/680x482cq70/cumi-saus-padang-foto-resep-utama.jpg
author: Cornelia McCoy
ratingvalue: 4.6
reviewcount: 27113
recipeingredient:
- "2 ekor cumi ukuran sedang cuci bersih iris sesuai selera"
- "1 buah jagung saya potong jd 5 Bagian"
- "1 buah telor kocok lepas dan saya orak arik sisihkan"
- "4 sium bawang putih"
- "7 sium bawang merah"
- "1/2 sium bawang bombay saya iris2"
- "5 buah cabe merah"
- "10 cabe rawit"
- "5 sdm saus sambel botolan saya pake del monte"
- "3 sdm saus tomat saya pake del monte"
- "1 buah sereh geprek"
- "3 lembar daun salam"
- "1 ruas jahe saya iris2"
- "1 bungkus penyedap rasa ayam saya pake masako"
- "Secukupnya gula  garam"
- "Secukupnya air matang"
- "Secukupnya minyak untuk menumis  margarin 12 sdm tambahan"
recipeinstructions:
- "Saya buat telur orak arik dlu untuk campuran dan saya masukan di akhir masakan, ini saya kasih garam sedikit ya di kocokannya dan saya gunakan minyak juga sedikit.  Cumi setelah saya cuci bersih dan saya kasih sedikit garam juga perasan lemon, saya goreng sebentar dengan minyak, gak smpi 2 menit agar tidak alot. Saya angkat &amp; saya tiriskan (gak sempat kefoto)"
- "Siapkan wajan bersih, masukan minyak sayur juga margarin &amp; panaskan lalu masukan irisan bawang bombay tumis hingga harum. Untuk bawang merah &amp; putih juga cabai2an semua saya blender gak terlalu halus, lalu saya masukan ke tumisan berikut sereh, salam juga jahe, aduk hingga harum. Lanjut saya masukan potongan jagung dan saya tambahkan air agak banyak, supaya jagung matang, kurang lebih air agak berkurang saya masukan semua saus2an &amp; penyedap rasa, gula juga garam."
- "Saat air telah meyusut, kuah/sausnya mulai sedikit mengengental api kompor juga saya kecilkan dan saya masukan orak arik telur juga cumi yang tadi sdh saya goreng &amp; saya koreksi rasa lagi. Masak sebentar sambil saya aduk agar cuminya tertutup semua kuah/sausnya, jangan terlalu lama agar cumi tidak alot. Selesai &amp; siap di sajikan. Cocok dinikmati selagi panas."
categories:
- Recipe
tags:
- cumi
- saus
- padang

katakunci: cumi saus padang 
nutrition: 138 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Dinner

---


![Cumi Saus Padang](https://img-global.cpcdn.com/recipes/64c492d2b31de580/680x482cq70/cumi-saus-padang-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang patut kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti cumi saus padang yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa ciri khas yang merupakan keragaman Nusantara



Keharmonisan rumah tangga dapat ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Cumi Saus Padang untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang dapat anda coba salah satunya cumi saus padang yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep cumi saus padang tanpa harus bersusah payah.
Seperti resep Cumi Saus Padang yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Cumi Saus Padang:

1. Dibutuhkan 2 ekor cumi ukuran sedang, cuci bersih, iris sesuai selera
1. Dibutuhkan 1 buah jagung, saya potong jd 5 Bagian
1. Jangan lupa 1 buah telor, kocok lepas dan saya orak arik, sisihkan
1. Diperlukan 4 sium bawang putih
1. Tambah 7 sium bawang merah
1. Jangan lupa 1/2 sium bawang bombay, saya iris2
1. Harus ada 5 buah cabe merah
1. Diperlukan 10 cabe rawit
1. Tambah 5 sdm saus sambel botolan (saya pake del monte)
1. Siapkan 3 sdm saus tomat (saya pake del monte)
1. Diperlukan 1 buah sereh, geprek
1. Harus ada 3 lembar daun salam
1. Jangan lupa 1 ruas jahe saya iris2
1. Siapkan 1 bungkus penyedap rasa ayam (saya pake masako)
1. Harap siapkan Secukupnya gula &amp; garam
1. Dibutuhkan Secukupnya air matang
1. Harap siapkan Secukupnya minyak untuk menumis &amp; margarin 1/2 sdm tambahan




<!--inarticleads2-->

##### Instruksi membuat  Cumi Saus Padang:

1. Saya buat telur orak arik dlu untuk campuran dan saya masukan di akhir masakan, ini saya kasih garam sedikit ya di kocokannya dan saya gunakan minyak juga sedikit. -  - Cumi setelah saya cuci bersih dan saya kasih sedikit garam juga perasan lemon, saya goreng sebentar dengan minyak, gak smpi 2 menit agar tidak alot. Saya angkat &amp; saya tiriskan (gak sempat kefoto)
1. Siapkan wajan bersih, masukan minyak sayur juga margarin &amp; panaskan lalu masukan irisan bawang bombay tumis hingga harum. - Untuk bawang merah &amp; putih juga cabai2an semua saya blender gak terlalu halus, lalu saya masukan ke tumisan berikut sereh, salam juga jahe, aduk hingga harum. Lanjut saya masukan potongan jagung dan saya tambahkan air agak banyak, supaya jagung matang, kurang lebih air agak berkurang saya masukan semua saus2an &amp; penyedap rasa, gula juga garam.
1. Saat air telah meyusut, kuah/sausnya mulai sedikit mengengental api kompor juga saya kecilkan dan saya masukan orak arik telur juga cumi yang tadi sdh saya goreng &amp; saya koreksi rasa lagi. - Masak sebentar sambil saya aduk agar cuminya tertutup semua kuah/sausnya, jangan terlalu lama agar cumi tidak alot. - Selesai &amp; siap di sajikan. - Cocok dinikmati selagi panas.




Demikianlah cara membuat cumi saus padang yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
