---
description: "Resep : Kue Nona Manis Luar biasa"
title: "Resep : Kue Nona Manis Luar biasa"
slug: 397-resep-kue-nona-manis-luar-biasa
date: 2020-11-29T07:25:30.804Z
image: https://img-global.cpcdn.com/recipes/4241c4848c8c8be8/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4241c4848c8c8be8/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4241c4848c8c8be8/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Bertha Jones
ratingvalue: 4.6
reviewcount: 38666
recipeingredient:
- " Bahan A "
- "2 gelas belimbing air daun pandan suji"
- "1/2 kg tepung terigu"
- "1/2 kg gula pasir"
- "4 btr telur"
- "1 pack tepung maizena"
- "8 gelas belimbing santan sedang"
- " Bahan B "
- "1 ons tepung terigu"
- "2 gelas belimbing santan kental"
- "1 sdt garam"
recipeinstructions:
- "Masukan bahan A dlm panci yg terdiri dr tepung maizena dan santan, kemudian masak hingga mengental, lalu sisihkan hingga mendingin."
- "Masukan gula dan telur dalam wadah kemudian mixer hingga halus, kemudian masukan adonan tepung maizena (*no1) dan air daun pandan suji. Mixer kembali hingga rata."
- "Terakhir masukan sisa bahan A yakni tepung terigu, lanjutkan mixer kembali. Setelah lembut sisihkan."
- "Lanjut bahan B : masukan tepung terigu dalam panci bersama santan kental. Lalu didihkan diatas api, jangan lupa tambahkan garam. Masak hingga mengental sisihkan."
- "Siapkan cetakan (*bisa menggunakan cetakan kue mangkuk) lalu tuang adonan 1 (*bahan A) hingga 3/4 bagian. Kemudian ditengahnya tuang adonan 2 (*bahan b) serapi mungkin. Lakukan hingga bahan habis."
- "Kukus kue selama 10-15 menit, lalu angkat dan dinginkan. Keluarkan dr cetakan, kue nona manis siap dihidangkan (*tips saat mengukus sebaiknya tutup kukusan diberi kain bersih di bagian dalamnya, agar uap panas tdk jatuh pada kukusan kue yg akan mempengaruhi bentuk kue yg dihasilkan) selamat mencobaaa..... ini uwenaaakkk bingits"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 232 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Lunch

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/4241c4848c8c8be8/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti kue nona manis yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa ciri khas yang merupakan keragaman Indonesia



Kedekatan rumah tangga bisa didapat dengan cara mudah. Diantaranya adalah memasak Kue Nona Manis untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang dapat anda contoh salah satunya kue nona manis yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Diperlukan  Bahan A :
1. Diperlukan 2 gelas belimbing air daun pandan suji
1. Diperlukan 1/2 kg tepung terigu
1. Tambah 1/2 kg gula pasir
1. Tambah 4 btr telur
1. Diperlukan 1 pack tepung maizena
1. Tambah 8 gelas belimbing santan sedang
1. Tambah  Bahan B :
1. Siapkan 1 ons tepung terigu
1. Siapkan 2 gelas belimbing santan kental
1. Siapkan 1 sdt garam




<!--inarticleads2-->

##### Bagaimana membuat  Kue Nona Manis:

1. Masukan bahan A dlm panci yg terdiri dr tepung maizena dan santan, kemudian masak hingga mengental, lalu sisihkan hingga mendingin.
1. Masukan gula dan telur dalam wadah kemudian mixer hingga halus, kemudian masukan adonan tepung maizena (*no1) dan air daun pandan suji. Mixer kembali hingga rata.
1. Terakhir masukan sisa bahan A yakni tepung terigu, lanjutkan mixer kembali. Setelah lembut sisihkan.
1. Lanjut bahan B : masukan tepung terigu dalam panci bersama santan kental. Lalu didihkan diatas api, jangan lupa tambahkan garam. Masak hingga mengental sisihkan.
1. Siapkan cetakan (*bisa menggunakan cetakan kue mangkuk) lalu tuang adonan 1 (*bahan A) hingga 3/4 bagian. Kemudian ditengahnya tuang adonan 2 (*bahan b) serapi mungkin. Lakukan hingga bahan habis.
1. Kukus kue selama 10-15 menit, lalu angkat dan dinginkan. Keluarkan dr cetakan, kue nona manis siap dihidangkan (*tips saat mengukus sebaiknya tutup kukusan diberi kain bersih di bagian dalamnya, agar uap panas tdk jatuh pada kukusan kue yg akan mempengaruhi bentuk kue yg dihasilkan) selamat mencobaaa..... ini uwenaaakkk bingits




Demikianlah cara membuat kue nona manis yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
