---
description: "Resep : Lobster Saus Padang Teruji"
title: "Resep : Lobster Saus Padang Teruji"
slug: 176-resep-lobster-saus-padang-teruji
date: 2021-02-20T23:05:03.647Z
image: https://img-global.cpcdn.com/recipes/e26c61501bb01276/680x482cq70/lobster-saus-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e26c61501bb01276/680x482cq70/lobster-saus-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e26c61501bb01276/680x482cq70/lobster-saus-padang-foto-resep-utama.jpg
author: John Malone
ratingvalue: 4.5
reviewcount: 23202
recipeingredient:
- "500 gram lobster"
- " Bahan yang dihaluskan "
- "3 butir kemiri"
- "4 siung bawang putih"
- "6 siung bawang merah"
- "3 cm jahe"
- "2 cm kunyit"
- "15-20 buah cabai merah"
- "1 lembar daun jeruk"
- " Bumbu lainnya "
- "1/2 sdt garam"
- "1/2 sdt gula pasir"
- "1/4 sdt merica bubuk"
- "4 sdm saus tiram"
- "4 sdm saus sambal"
- "1 buah tomat kecil"
- "1/2 buah bawang bombay"
- "1/4 sdt kaldu jamur optional"
- "2 lembar daun salam"
- "1 batang daun bawang iris kasar"
- "Secukupnya minyak untuk menumis"
- "Secukupnya air bersih"
recipeinstructions:
- "Siapkan lobsternya. Lalu gunting dari bagian kepala hingga ekor, buang kotorannya. Jangan sampai rusak ya dagingnya (pada resep aslinya lobsternya kecil-kecil jadi tidak perlu dimasak di air yg mendidih, karena ini lobsternya besar, saya rebus sebentar dengan air supaya bersih dari kotorannya)."
- "Siapkan air mendidih, rebus lobster selama 3 sampai 5 menit. Kemudian langsung angkat dan rendam dalam air dingin."
- "Siapkan bumbunya lalu haluskan."
- "Siapkan bahan lainnya."
- "Tumis bumbu halus sampai harum, masukkan bahan lainnya."
- "Tambahkan jagung, masak sampai setengah layu. Masukkan bumbu lain dan tes rasa."
- "Tambahkan loster. Hati-hati memasaknya, jangan terlalu lama, nanti dagingnya hancur. Jika bumbu sudah meresap, matikan api dan siap untuk disajikan."
categories:
- Recipe
tags:
- lobster
- saus
- padang

katakunci: lobster saus padang 
nutrition: 208 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Lunch

---


![Lobster Saus Padang](https://img-global.cpcdn.com/recipes/e26c61501bb01276/680x482cq70/lobster-saus-padang-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang harus kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti lobster saus padang yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa keistimewahan yang merupakan keragaman Nusantara

Keharmonisan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah memasak Lobster Saus Padang untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang bisa anda buat salah satunya lobster saus padang yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep lobster saus padang tanpa harus bersusah payah.
Seperti resep Lobster Saus Padang yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 22 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Lobster Saus Padang:

1. Harus ada 500 gram lobster
1. Harus ada  Bahan yang dihaluskan :
1. Jangan lupa 3 butir kemiri
1. Jangan lupa 4 siung bawang putih
1. Harap siapkan 6 siung bawang merah
1. Harus ada 3 cm jahe
1. Dibutuhkan 2 cm kunyit
1. Harap siapkan 15-20 buah cabai merah
1. Dibutuhkan 1 lembar daun jeruk
1. Harap siapkan  Bumbu lainnya :
1. Siapkan 1/2 sdt garam
1. Harap siapkan 1/2 sdt gula pasir
1. Dibutuhkan 1/4 sdt merica bubuk
1. Harus ada 4 sdm saus tiram
1. Dibutuhkan 4 sdm saus sambal
1. Harus ada 1 buah tomat kecil
1. Dibutuhkan 1/2 buah bawang bombay
1. Harap siapkan 1/4 sdt kaldu jamur (optional)
1. Diperlukan 2 lembar daun salam
1. Jangan lupa 1 batang daun bawang iris kasar
1. Jangan lupa Secukupnya minyak untuk menumis
1. Tambah Secukupnya air bersih




<!--inarticleads2-->

##### Bagaimana membuat  Lobster Saus Padang:

1. Siapkan lobsternya. Lalu gunting dari bagian kepala hingga ekor, buang kotorannya. Jangan sampai rusak ya dagingnya (pada resep aslinya lobsternya kecil-kecil jadi tidak perlu dimasak di air yg mendidih, karena ini lobsternya besar, saya rebus sebentar dengan air supaya bersih dari kotorannya).
1. Siapkan air mendidih, rebus lobster selama 3 sampai 5 menit. Kemudian langsung angkat dan rendam dalam air dingin.
1. Siapkan bumbunya lalu haluskan.
1. Siapkan bahan lainnya.
1. Tumis bumbu halus sampai harum, masukkan bahan lainnya.
1. Tambahkan jagung, masak sampai setengah layu. Masukkan bumbu lain dan tes rasa.
1. Tambahkan loster. Hati-hati memasaknya, jangan terlalu lama, nanti dagingnya hancur. Jika bumbu sudah meresap, matikan api dan siap untuk disajikan.




Demikianlah cara membuat lobster saus padang yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
