---
description: "Cara membuat Ayam Bakar Padang Luar biasa"
title: "Cara membuat Ayam Bakar Padang Luar biasa"
slug: 75-cara-membuat-ayam-bakar-padang-luar-biasa
date: 2020-09-18T19:56:34.474Z
image: https://img-global.cpcdn.com/recipes/aa3bf55bf99b8a45/680x482cq70/ayam-bakar-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/aa3bf55bf99b8a45/680x482cq70/ayam-bakar-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/aa3bf55bf99b8a45/680x482cq70/ayam-bakar-padang-foto-resep-utama.jpg
author: Fanny Castillo
ratingvalue: 4.9
reviewcount: 3513
recipeingredient:
- "1/2 ekor ayam bagian paha"
- "1/2 bh jeruk nipis"
- "2 batang serai ambil putihnya"
- "2 cm lengkuas geprek"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 scht santan instan 65ml"
- "400 ml air"
- "1-2 sdt garam halus"
- "2 sdt gula pasir"
- "Secukupnya minyak goreng"
- " Bumbu halus "
- "8 butir bawang merah"
- "6 siung bawang putih"
- "5 butir kemiri sangrai dahulu"
- "2 cm jahe"
- "1 sdt kunyit bubuk"
recipeinstructions:
- "Cuci ayam, beri perasan jeruk nipis, diamkan 15menit, cuci bersih lalu tiriskan"
- "Siapkan bumbu halus, masukkan dalam Chopper lalu haluskan. Siapkan bumbu lainnya"
- "Siapkan bahan lainnya"
- "Selanjutnya tumis bumbu halus dan bahan lainnya dalam minyak panas sampai harum dan daun layu. Kemudian masukkan air, biarkan mendidih, lalu masukkan santan dan tambahkan garam dan gula. Aduk-aduk"
- "Setelah itu masukkan ayamnya, aduk agar tercampur rata, tutup dan masak sampai kuah menyusut. Selanjutnya panggang di teflon, olesi dengan sisa bumbu"
categories:
- Recipe
tags:
- ayam
- bakar
- padang

katakunci: ayam bakar padang 
nutrition: 179 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Bakar Padang](https://img-global.cpcdn.com/recipes/aa3bf55bf99b8a45/680x482cq70/ayam-bakar-padang-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau renyah. Karasteristik masakan Nusantara ayam bakar padang yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Hidangan ayam bakar bumbu padang adalah sajian yang enak dan lezat. Sajian kali ini akan cocok anda nikmati bersama dengan sepiring nasi dan juga lalapan serta sambal yang lezat. Sehat, murah dan mudah dibuat sendiri di rumah. Chef Yvan asli dari negara Perancis jadi maklum logatnya agak lucu gitu.

Keharmonisan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah memasak Ayam Bakar Padang untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang bisa anda buat salah satunya ayam bakar padang yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep ayam bakar padang tanpa harus bersusah payah.
Seperti resep Ayam Bakar Padang yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Bakar Padang:

1. Tambah 1/2 ekor ayam bagian paha
1. Dibutuhkan 1/2 bh jeruk nipis
1. Harus ada 2 batang serai, ambil putihnya
1. Harus ada 2 cm lengkuas, geprek
1. Siapkan 2 lembar daun salam
1. Diperlukan 2 lembar daun jeruk
1. Harus ada 1 scht santan instan (65ml)
1. Diperlukan 400 ml air
1. Dibutuhkan 1-2 sdt garam halus
1. Tambah 2 sdt gula pasir
1. Jangan lupa Secukupnya minyak goreng
1. Diperlukan  Bumbu halus :
1. Jangan lupa 8 butir bawang merah
1. Tambah 6 siung bawang putih
1. Jangan lupa 5 butir kemiri, sangrai dahulu
1. Harus ada 2 cm jahe
1. Siapkan 1 sdt kunyit bubuk


Ayam bakar yang pertama adalah Ayam Bakar Padang, sajian masakan ayam bakar ini bisa jadi alternatif buat kamu yang suka dengan makanan bercitarasa Minang. Ayam bakar is an Indonesian and Malaysian dish, consisting of charcoal-grilled chicken. Ayam bakar literally means &#34;roasted chicken&#34; in Indonesian and Malay. In Java, the chicken is usually marinated with the mixture of kecap manis (sweet soy sauce) and coconut oil, applied with a brush during grilling. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam Bakar Padang:

1. Cuci ayam, beri perasan jeruk nipis, diamkan 15menit, cuci bersih lalu tiriskan
1. Siapkan bumbu halus, masukkan dalam Chopper lalu haluskan. Siapkan bumbu lainnya
1. Siapkan bahan lainnya
1. Selanjutnya tumis bumbu halus dan bahan lainnya dalam minyak panas sampai harum dan daun layu. Kemudian masukkan air, biarkan mendidih, lalu masukkan santan dan tambahkan garam dan gula. Aduk-aduk
1. Setelah itu masukkan ayamnya, aduk agar tercampur rata, tutup dan masak sampai kuah menyusut. Selanjutnya panggang di teflon, olesi dengan sisa bumbu


Ayam bakar literally means &#34;roasted chicken&#34; in Indonesian and Malay. In Java, the chicken is usually marinated with the mixture of kecap manis (sweet soy sauce) and coconut oil, applied with a brush during grilling. Padang food is my favorite takeout in Indonesia. Whenever I am too lazy to cook, I can always drop Thank you for sharing the Ayam Bakar Padang recipe. I love to visit your website and I have tried. 

Demikianlah cara membuat ayam bakar padang yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat gampang dan terbukti, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
