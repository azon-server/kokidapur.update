---
description: "Resep : Kue Nona Manis teraktual"
title: "Resep : Kue Nona Manis teraktual"
slug: 357-resep-kue-nona-manis-teraktual
date: 2020-12-27T19:08:12.052Z
image: https://img-global.cpcdn.com/recipes/0222a7e0f9628491/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0222a7e0f9628491/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0222a7e0f9628491/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Gussie Goodwin
ratingvalue: 4.9
reviewcount: 33409
recipeingredient:
- " Bahan A"
- "2 butir telur"
- "1 gelas gula pasir"
- "2 gelas santan"
- "2 gelas tepung terigu"
- " Bahan B"
- "1 gelas santan"
- "8 lembar daun pandan dan 8 lembar daun suji"
- " blender dengan segelas air"
- "5 sdm tepung maizena"
- "1 sdt garam"
- "Secukupnya pastapewarna pandan hijau"
- " Bahan C warna putih"
- "2 gelas santan kental"
- "2 sdm tepung terigu muncungpenuh"
- "3 sdm gula pasir"
- "1 sdt garam"
recipeinstructions:
- "Campur semua bahan A.. mix pake wisk sampe gula larut.. sisihkan.."
- "Campur bahan B masak dengan api kecil aduk aduk terus sampe meletup letup.. dinginkan.. setelah dingin lalu campur kewadah bahan A.. aduk sampe rata, beri secukupnya pasta, aduk sampe tercampur rata.."
- "Campur semua bahan C aduk dan saring, lalu masak dengan api kecil sambil terus diaduk aduk.. angkat dan dinginkan.. masukan ke plastik segitiga gunting ujung plastiknya"
- "Siap dicetak... masukan adonan campuran A dan B warna hijau 3/4 cetakan mangkok yg sdh dioles minyak goreng, lalu semprot bagian tengahnya dngn adonan warna putih sampe hampir penuh dan kukus 10-15 menit dengan api sedang.. tutup panci dialasi kain serbet bersih. Angkat dan dinginkan.. Siap dinikmati"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 166 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Dessert

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/0222a7e0f9628491/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita lestarikan karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti kue nona manis yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa keistimewahan yang merupakan keragaman Indonesia

Keharmonisan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak Kue Nona Manis untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang bisa anda coba salah satunya kue nona manis yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Harap siapkan  Bahan A:
1. Siapkan 2 butir telur
1. Tambah 1 gelas gula pasir
1. Harap siapkan 2 gelas santan
1. Tambah 2 gelas tepung terigu
1. Diperlukan  Bahan B
1. Harus ada 1 gelas santan
1. Jangan lupa 8 lembar daun pandan dan 8 lembar daun suji
1. Siapkan  (blender dengan segelas air)
1. Diperlukan 5 sdm tepung maizena
1. Jangan lupa 1 sdt garam
1. Harus ada Secukupnya pasta/pewarna pandan hijau
1. Harus ada  Bahan C (warna putih)
1. Diperlukan 2 gelas santan kental
1. Diperlukan 2 sdm tepung terigu *muncung/penuh
1. Harus ada 3 sdm gula pasir
1. Tambah 1 sdt garam




<!--inarticleads2-->

##### Instruksi membuat  Kue Nona Manis:

1. Campur semua bahan A.. mix pake wisk sampe gula larut.. sisihkan..
1. Campur bahan B masak dengan api kecil aduk aduk terus sampe meletup letup.. dinginkan.. setelah dingin lalu campur kewadah bahan A.. aduk sampe rata, beri secukupnya pasta, aduk sampe tercampur rata..
1. Campur semua bahan C aduk dan saring, lalu masak dengan api kecil sambil terus diaduk aduk.. angkat dan dinginkan.. masukan ke plastik segitiga gunting ujung plastiknya
1. Siap dicetak... masukan adonan campuran A dan B warna hijau 3/4 cetakan mangkok yg sdh dioles minyak goreng, lalu semprot bagian tengahnya dngn adonan warna putih sampe hampir penuh dan kukus 10-15 menit dengan api sedang.. tutup panci dialasi kain serbet bersih. Angkat dan dinginkan.. Siap dinikmati




Demikianlah cara membuat kue nona manis yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
