---
description: "Resep : Sop Iga Sapi ala Nona Angela Homemade"
title: "Resep : Sop Iga Sapi ala Nona Angela Homemade"
slug: 415-resep-sop-iga-sapi-ala-nona-angela-homemade
date: 2020-11-06T05:07:16.473Z
image: https://img-global.cpcdn.com/recipes/ccaa645df9575dae/680x482cq70/sop-iga-sapi-ala-nona-angela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ccaa645df9575dae/680x482cq70/sop-iga-sapi-ala-nona-angela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ccaa645df9575dae/680x482cq70/sop-iga-sapi-ala-nona-angela-foto-resep-utama.jpg
author: John Salazar
ratingvalue: 4.9
reviewcount: 29080
recipeingredient:
- "1/2 kg iga sapi"
- "2 lembar daun salam"
- "5 butir cengkeh"
- "1 sdt bubuk pala"
- " Garam"
- " Presto"
- " Kuah sop"
- " Tetelan sapi"
- "5 buah bawang merah"
- "2 siung bawang putih"
- "1 sdm bubuk pala"
- "10 butir cengkeh"
- "2 ruas kayu manis"
- "4 buah kapulaga kupas kulitnya"
- "1 buah wortel"
- "2 buah kentang"
- "1 ruas jahe"
- "3 lembar daun salam"
- "1/4 Kol"
- " Daun bawang potong kecil"
- " Garam"
- " Gula"
- " Merica"
recipeinstructions:
- "Presto iga sapi dgn bahan2 diatas agar empuk dagingnya serta wangi dan gurih. Lalu tiriskan."
- "Haluskan bawang merah, putih dan jahe lalu tumis hingga wangi lalu seduh dengan air sesuai selera. Masukkan tetelan daging, kayu manis, pala, kapulaga, cengkeh, wortel dan kentang. Diamkan selama 10 menit agar kentang dan wortel empuk."
- "Lalu masukkan iga sapi yg telah di presto aduk hingga rata, tambahkan garam, gula dan merica secukupnya dan terakhir masukan kol, tunggu hingga sedikit layu."
- "And Finish. Sajikan dengan potongan daun bawang di atasnya. Soal rasa dijamin enak seperti di restaurant hotel bintang 5. Mantap👍🏻👍🏻👍🏻"
categories:
- Recipe
tags:
- sop
- iga
- sapi

katakunci: sop iga sapi 
nutrition: 231 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Dinner

---


![Sop Iga Sapi ala Nona Angela](https://img-global.cpcdn.com/recipes/ccaa645df9575dae/680x482cq70/sop-iga-sapi-ala-nona-angela-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti sop iga sapi ala nona angela yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa kesan tersendiri yang merupakan keragaman Nusantara

Keharmonisan keluarga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Sop Iga Sapi ala Nona Angela untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi makanan yang bisa anda praktekkan salah satunya sop iga sapi ala nona angela yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep sop iga sapi ala nona angela tanpa harus bersusah payah.
Seperti resep Sop Iga Sapi ala Nona Angela yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 23 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sop Iga Sapi ala Nona Angela:

1. Diperlukan 1/2 kg iga sapi
1. Diperlukan 2 lembar daun salam
1. Harus ada 5 butir cengkeh
1. Dibutuhkan 1 sdt bubuk pala
1. Harus ada  Garam
1. Harap siapkan  Presto
1. Dibutuhkan  Kuah sop
1. Tambah  Tetelan sapi
1. Dibutuhkan 5 buah bawang merah
1. Dibutuhkan 2 siung bawang putih
1. Tambah 1 sdm bubuk pala
1. Siapkan 10 butir cengkeh
1. Diperlukan 2 ruas kayu manis
1. Harap siapkan 4 buah kapulaga (kupas kulitnya)
1. Tambah 1 buah wortel
1. Harap siapkan 2 buah kentang
1. Harap siapkan 1 ruas jahe
1. Harus ada 3 lembar daun salam
1. Diperlukan 1/4 Kol
1. Harap siapkan  Daun bawang (potong kecil)
1. Tambah  Garam
1. Harus ada  Gula
1. Harap siapkan  Merica




<!--inarticleads2-->

##### Bagaimana membuat  Sop Iga Sapi ala Nona Angela:

1. Presto iga sapi dgn bahan2 diatas agar empuk dagingnya serta wangi dan gurih. Lalu tiriskan.
1. Haluskan bawang merah, putih dan jahe lalu tumis hingga wangi lalu seduh dengan air sesuai selera. Masukkan tetelan daging, kayu manis, pala, kapulaga, cengkeh, wortel dan kentang. Diamkan selama 10 menit agar kentang dan wortel empuk.
1. Lalu masukkan iga sapi yg telah di presto aduk hingga rata, tambahkan garam, gula dan merica secukupnya dan terakhir masukan kol, tunggu hingga sedikit layu.
1. And Finish. Sajikan dengan potongan daun bawang di atasnya. Soal rasa dijamin enak seperti di restaurant hotel bintang 5. Mantap👍🏻👍🏻👍🏻




Demikianlah cara membuat sop iga sapi ala nona angela yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan cepat, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
