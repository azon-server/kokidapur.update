---
description: "Cara singkat menyiapakan Kue nona manis Teruji"
title: "Cara singkat menyiapakan Kue nona manis Teruji"
slug: 302-cara-singkat-menyiapakan-kue-nona-manis-teruji
date: 2020-10-26T18:56:54.720Z
image: https://img-global.cpcdn.com/recipes/3df5684ae5380f68/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3df5684ae5380f68/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3df5684ae5380f68/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Alice Cobb
ratingvalue: 4.4
reviewcount: 21443
recipeingredient:
- " Bahan 1"
- "250 ml santan kental"
- "150 gram tepung terigu"
- "1 butir telur"
- "80 gram gula pasir"
- " Bahan 2 "
- "250 ml santan kental"
- "30 gram tepung maizena"
- "40 gram gula pasir"
- "1/2 sdt pasta pandan"
- "Sejumput garam"
- " Bahan 3 "
- "500 ml santan kental"
- "6 sdm tepung terigu"
- "Sejumput garam"
recipeinstructions:
- "Siapkan wadah masukkan gula pasir dan telur mixer dengan kecepatan tinggi hingga kental, turunkan speed masukkan santan dan tepung terigu bergantian mixer lagi sampai tercampur rata, sisihkan"
- "Siapkan panci lalu tuang semua bahan 2 masak dengan api kecil hingga mengental sisihkan"
- "Setelah dingin campur ke dalam bahan 1 mixer rata"
- "Siapkan panci masukkan bahan 3 aduk, masak dengan api kecil hingga mengental. Masukkan ke dalam botol kecap atau plastik segitiga"
- "Panaskan kukusan bungkus tutupnya dengan kain bersih"
- "Siapkan cetakan yang telah di oles minyak masukkan adonan hijau ke dalam cetakan 3/4 tinggi cetakan. Lalu semprotkan adonan 3 ke tengah cetakan dengan cara masukkan ujung botol ke tengah adonan dalam cetakan. Kukus kurang lebih 15 menit."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 136 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT43M"
recipeyield: "3"
recipecategory: Lunch

---


![Kue nona manis](https://img-global.cpcdn.com/recipes/3df5684ae5380f68/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang harus kita jaga karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti kue nona manis yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan keistimewahan yang merupakan keragaman Nusantara

Keharmonisan keluarga dapat ditemukan dengan cara simple. Salah satunya adalah membuat makanan Kue nona manis untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.

Kue nona manis adalah salah satu jajanan tradisional yang melegenda di Indonesia. Ada yang tahu kue nona manis? SALAH satu jajanan pasar kue nona manis rasanya sudah jarang ditemui. Meski langkahnya sedikit rumit, ada rasa puas tersendiri saat berhasil membuat kue nona manis.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang dapat anda buat salah satunya kue nona manis yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue nona manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue nona manis:

1. Dibutuhkan  Bahan 1:
1. Harap siapkan 250 ml santan kental
1. Tambah 150 gram tepung terigu
1. Diperlukan 1 butir telur
1. Jangan lupa 80 gram gula pasir
1. Diperlukan  Bahan 2 :
1. Harap siapkan 250 ml santan kental
1. Dibutuhkan 30 gram tepung maizena
1. Diperlukan 40 gram gula pasir
1. Tambah 1/2 sdt pasta pandan
1. Harus ada Sejumput garam
1. Harap siapkan  Bahan 3 :
1. Harus ada 500 ml santan kental
1. Harus ada 6 sdm tepung terigu
1. Harus ada Sejumput garam


Nona manis adalah kue khas Sulawesi. Teksturnya lebih lembut dari kue talam Indonesia lainnya. Bagian yang berwarna hijau rasanya manis dan gurih santan, sedangkan bagian yang berwarna putih. Aih, sudah lama rasanya tidak mendengar Kue Nona Manis. 

<!--inarticleads2-->

##### Bagaimana membuat  Kue nona manis:

1. Siapkan wadah masukkan gula pasir dan telur mixer dengan kecepatan tinggi hingga kental, turunkan speed masukkan santan dan tepung terigu bergantian mixer lagi sampai tercampur rata, sisihkan
1. Siapkan panci lalu tuang semua bahan 2 masak dengan api kecil hingga mengental sisihkan
1. Setelah dingin campur ke dalam bahan 1 mixer rata
1. Siapkan panci masukkan bahan 3 aduk, masak dengan api kecil hingga mengental. Masukkan ke dalam botol kecap atau plastik segitiga
1. Panaskan kukusan bungkus tutupnya dengan kain bersih
1. Siapkan cetakan yang telah di oles minyak masukkan adonan hijau ke dalam cetakan 3/4 tinggi cetakan. Lalu semprotkan adonan 3 ke tengah cetakan dengan cara masukkan ujung botol ke tengah adonan dalam cetakan. Kukus kurang lebih 15 menit.


Bagian yang berwarna hijau rasanya manis dan gurih santan, sedangkan bagian yang berwarna putih. Aih, sudah lama rasanya tidak mendengar Kue Nona Manis. Camilan klasik ini bisa Bunda hadirkan kembali dengan warna menarik yang tidak akan ditolak oleh si kecil. Your current browser isn&#39;t compatible with SoundCloud. Please download one of our supported browsers. 

Demikianlah cara membuat kue nona manis yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
