---
description: "Resep : Kue nona manis Terbukti"
title: "Resep : Kue nona manis Terbukti"
slug: 309-resep-kue-nona-manis-terbukti
date: 2021-01-15T05:29:54.749Z
image: https://img-global.cpcdn.com/recipes/a15c0dde3c7c7db1/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a15c0dde3c7c7db1/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a15c0dde3c7c7db1/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Ida Barber
ratingvalue: 4.4
reviewcount: 18115
recipeingredient:
- " Bahan 1 "
- "80 gram gula pasir"
- "1 butir telur"
- "250 ml santan kental"
- "140 gram tepung terigu"
- " Bahan 2"
- "250 gram santan kental"
- "40 gram gula pasir"
- "30 gram meizena"
- "1/2 sdt pasta pandan"
- "Sejumput garam"
- " Bahan 3"
- "500 ml santan kental"
- "6 sdm tepung terigu"
- "Sejumput garam"
recipeinstructions:
- "Bahan 1:mixer gula dan telur hingga kental pake speed tinggi.masukan santan dan terigu secara bertahap sambil di mixer speed rendah sampe rata.sisihkan"
- "Masak bahan 2 dengan api sedang sambil terus diaduk hingga mengental.angkat,biarkan uapnya hilang"
- "Jika bahan 2 sudah berkurang panasnya,tambahkan ke bahan 1.mixer sampe tercampur rata"
- "Masak bahan 3 dengan api sedang sambil terus diaduk hingga mengental.angkat.masukan ke botol saos plastik"
- "Olesi cetakan dengan minyak goreng.tuang adonan hijau 3/4 cetakan.semprotkan adonan putih hingga cetakan penuh.caranya benamkan ujung mulut botol ke adonan hijau"
- "Panaskan kukusan hingga beruap.kukus nona manis selama 10 menit pake api sedang.tutup kukusan dialasi serbet bersih supaya air tidak menetes ke adonan"
- "Sajikan"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 287 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Dessert

---


![Kue nona manis](https://img-global.cpcdn.com/recipes/a15c0dde3c7c7db1/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang patut kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti kue nona manis yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara

Kedekatan keluarga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Kue nona manis untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

Kue nona manis adalah salah satu jajanan tradisional yang melegenda di Indonesia. Ada yang tahu kue nona manis? SALAH satu jajanan pasar kue nona manis rasanya sudah jarang ditemui. Meski langkahnya sedikit rumit, ada rasa puas tersendiri saat berhasil membuat kue nona manis.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang bisa anda coba salah satunya kue nona manis yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue nona manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue nona manis:

1. Harus ada  Bahan 1 :
1. Harap siapkan 80 gram gula pasir
1. Jangan lupa 1 butir telur
1. Harus ada 250 ml santan kental
1. Dibutuhkan 140 gram tepung terigu
1. Tambah  Bahan 2:
1. Dibutuhkan 250 gram santan kental
1. Tambah 40 gram gula pasir
1. Jangan lupa 30 gram meizena
1. Diperlukan 1/2 sdt pasta pandan
1. Harus ada Sejumput garam
1. Diperlukan  Bahan 3:
1. Harus ada 500 ml santan kental
1. Diperlukan 6 sdm tepung terigu
1. Jangan lupa Sejumput garam


Nona manis adalah kue khas Sulawesi. Teksturnya lebih lembut dari kue talam Indonesia lainnya. Bagian yang berwarna hijau rasanya manis dan gurih santan, sedangkan bagian yang berwarna putih. Aih, sudah lama rasanya tidak mendengar Kue Nona Manis. 

<!--inarticleads2-->

##### Cara membuat  Kue nona manis:

1. Bahan 1:mixer gula dan telur hingga kental pake speed tinggi.masukan santan dan terigu secara bertahap sambil di mixer speed rendah sampe rata.sisihkan
1. Masak bahan 2 dengan api sedang sambil terus diaduk hingga mengental.angkat,biarkan uapnya hilang
1. Jika bahan 2 sudah berkurang panasnya,tambahkan ke bahan 1.mixer sampe tercampur rata
1. Masak bahan 3 dengan api sedang sambil terus diaduk hingga mengental.angkat.masukan ke botol saos plastik
1. Olesi cetakan dengan minyak goreng.tuang adonan hijau 3/4 cetakan.semprotkan adonan putih hingga cetakan penuh.caranya benamkan ujung mulut botol ke adonan hijau
1. Panaskan kukusan hingga beruap.kukus nona manis selama 10 menit pake api sedang.tutup kukusan dialasi serbet bersih supaya air tidak menetes ke adonan
1. Sajikan


Bagian yang berwarna hijau rasanya manis dan gurih santan, sedangkan bagian yang berwarna putih. Aih, sudah lama rasanya tidak mendengar Kue Nona Manis. Camilan klasik ini bisa Bunda hadirkan kembali dengan warna menarik yang tidak akan ditolak oleh si kecil. Your current browser isn&#39;t compatible with SoundCloud. Please download one of our supported browsers. 

Demikianlah cara membuat kue nona manis yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan teruji, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
