---
description: "Resep : Kue Nona Manis Cepat"
title: "Resep : Kue Nona Manis Cepat"
slug: 325-resep-kue-nona-manis-cepat
date: 2020-12-17T14:57:26.591Z
image: https://img-global.cpcdn.com/recipes/25e916be1f5e2b19/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/25e916be1f5e2b19/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/25e916be1f5e2b19/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Amelia Schneider
ratingvalue: 4.3
reviewcount: 13207
recipeingredient:
- " Bahan A "
- "250 ml santan kental"
- "100 gr tepung terigu"
- "1/2 sdt garam"
- " Bahan B "
- "125 ml santan kental"
- "125 ml jus pandan"
- "1 sdm gula"
- "3 sdm tepung maizena"
- " Bahan C "
- "1 btr telur uk agak besar"
- "250 ml santan kental"
- "140 gr tepung terigu"
- "4 sdm gula"
recipeinstructions:
- "Kita buat bahan a terlebih dahulu. Campur tepung terigu dan garam, tambahkan santan sedikit demi sedikit sambil diaduk agar tidak bergerindil. Setelah tercampur rata kita masak dengan api sedabg sambil terus diaduk hingga mengental dan meletup-letup. Matikan kompor dinginkan adonan."
- "Lanjut kita membuat bahan b. Campurkan tepung maizena dan gula, bisa juga ditambahkan garan sejumput. Masukan santan dan jus pandan sedikit demi sedikit sambil diaduk hingga rata. Setelah rata tidak ada yg bergerindil masak hingga meletup-letup. Kemudian dinginkan."
- "Lanjut dengan bahan c. Kocok telur dan gula hingga gula larut. Tambahkan tepung terigu dan santan secara bergantian sambil terus diaduk agar tidak ada yang bergerindil. Jika adonan sudah tercampur tambahkan adonan b lalu aduk hingga rata. Saya mengaduk menggunakan whis."
- "Kukus dandang dengan tutup yang telah ditutup serbet bersih. Sambil menunggu dandang mendidih kita olesi cetakan dengan minyak goreng."
- "Kemudian adonan a yang telah dimasak tadi kita masukan dalam plastik segitiga agar mudah untuk menuangkan pada cetakan. Isi cetakan dengan 3/4 adonan hijau kemuadian semprotkan adonan putih dengan ujung plastik yang telah digunting dan sedikit dibenamkan. Semprot hingga adonan penuh. Lakukan hingga adonan habis kemudian kukus selama 20 menit."
- "Setelah matang angkat kue dari dandang dan biarkan kue dingin terlebih dahulu baru dikeluarkan dari cetakan. Kue ini dinikmati dingin juga enak, jadi dapat disimpan dalam kulkas dulu juga bisa."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 118 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dinner

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/25e916be1f5e2b19/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti kue nona manis yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan ciri khas yang merupakan keragaman Nusantara



Kehangatan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah memasak Kue Nona Manis untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang dapat anda contoh salah satunya kue nona manis yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 14 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Jangan lupa  Bahan A :
1. Harus ada 250 ml santan kental
1. Jangan lupa 100 gr tepung terigu
1. Harus ada 1/2 sdt garam
1. Dibutuhkan  Bahan B :
1. Siapkan 125 ml santan kental
1. Harap siapkan 125 ml jus pandan
1. Jangan lupa 1 sdm gula
1. Tambah 3 sdm tepung maizena
1. Dibutuhkan  Bahan C :
1. Siapkan 1 btr telur uk agak besar
1. Jangan lupa 250 ml santan kental
1. Dibutuhkan 140 gr tepung terigu
1. Dibutuhkan 4 sdm gula




<!--inarticleads2-->

##### Cara membuat  Kue Nona Manis:

1. Kita buat bahan a terlebih dahulu. Campur tepung terigu dan garam, tambahkan santan sedikit demi sedikit sambil diaduk agar tidak bergerindil. Setelah tercampur rata kita masak dengan api sedabg sambil terus diaduk hingga mengental dan meletup-letup. Matikan kompor dinginkan adonan.
1. Lanjut kita membuat bahan b. Campurkan tepung maizena dan gula, bisa juga ditambahkan garan sejumput. Masukan santan dan jus pandan sedikit demi sedikit sambil diaduk hingga rata. Setelah rata tidak ada yg bergerindil masak hingga meletup-letup. Kemudian dinginkan.
1. Lanjut dengan bahan c. Kocok telur dan gula hingga gula larut. Tambahkan tepung terigu dan santan secara bergantian sambil terus diaduk agar tidak ada yang bergerindil. Jika adonan sudah tercampur tambahkan adonan b lalu aduk hingga rata. Saya mengaduk menggunakan whis.
1. Kukus dandang dengan tutup yang telah ditutup serbet bersih. Sambil menunggu dandang mendidih kita olesi cetakan dengan minyak goreng.
1. Kemudian adonan a yang telah dimasak tadi kita masukan dalam plastik segitiga agar mudah untuk menuangkan pada cetakan. Isi cetakan dengan 3/4 adonan hijau kemuadian semprotkan adonan putih dengan ujung plastik yang telah digunting dan sedikit dibenamkan. Semprot hingga adonan penuh. Lakukan hingga adonan habis kemudian kukus selama 20 menit.
1. Setelah matang angkat kue dari dandang dan biarkan kue dingin terlebih dahulu baru dikeluarkan dari cetakan. Kue ini dinikmati dingin juga enak, jadi dapat disimpan dalam kulkas dulu juga bisa.




Demikianlah cara membuat kue nona manis yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan teruji, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
