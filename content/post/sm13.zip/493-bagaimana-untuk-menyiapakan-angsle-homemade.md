---
description: "Bagaimana untuk menyiapakan Angsle Homemade"
title: "Bagaimana untuk menyiapakan Angsle Homemade"
slug: 493-bagaimana-untuk-menyiapakan-angsle-homemade
date: 2021-01-29T07:37:33.652Z
image: https://img-global.cpcdn.com/recipes/f0f0edbd9ce91486/680x482cq70/angsle-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f0f0edbd9ce91486/680x482cq70/angsle-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f0f0edbd9ce91486/680x482cq70/angsle-foto-resep-utama.jpg
author: Marion Nash
ratingvalue: 4.1
reviewcount: 20290
recipeingredient:
- " Bahan santan "
- "1 butir kelapa agak muda parut"
- "1 sdt garam"
- "8-10 sdm gula"
- "2 lembar pandan"
- " Bahan petulo "
- " Bahan kacamg hijau "
- "1/2 kg kacang hijau"
- "1000 ml air"
- "1/2 sdt garam"
- " Bahan ketan "
- "1/2 beras ketan           lihat resep"
- "1/2 sdt garam"
- "  Bahan agaragar"
- "1 bungkus agar warna pink"
- "800 ml air"
- "5-7 sdm gula pasir"
- "Sejumput garam"
recipeinstructions:
- "Membuat petulo /putu Mayang : Dalam wajan campur tepung beras, garam &amp; santan. Aduk rata sampai tidak ada yg bergerindil, jika perlu disaring"
- "Nyalakan kompor api kecil, aduk² adonan sampai mengental/menggumpal. Tambahkan tapioka sedikit², aduk rata.tambahkan pewarna hijau. Taruh dalam plastik (karna bahan terlalu berat dan keras maka saya ganti pakai saringan Krn g punya cetakan)"
- "Ambil 1 adonan, taruh saringann diatasnya lalu tekan² sampai keluar adonan seperti mie, ambil menggunakan spatula, lalu tata diatas daun pisang yang sudah dioles tipis minyak goreng. Lakukan sampai adonan habis. Jika tdk ada cetakan, gunakan piping bag yang ujungnya dipotong kecil lalu tekan/semprotkan secukupnya. Kukis 15 menit. Sajikan"
- "Membuat ketan : ini pke ketan kukus biasa, pernah saya share           (lihat resep)"
- "Membuat kacang hijau. Saya cuci bersih kacang hijau, masak dengan air hingga mendidih matikan kompor. Saring air rebusan. Bisa buat diminum tambah gula. Sisa kacang hijau tadi rendam kembali 5jam. Kemudian presto tambah garam sedikit dan air hingga terendam. Presto 10menit saja. Tiriskan tidak bersama airnya"
- "Membuat santan : campurkan santan peras 500ml tambahkan 750-1000ml air. Sejumput garam dan 8 sdm gulapasir. Aduk tambahkan pandan simpul. Aduk terus jangan sampai santan pecah, aduk hingga mendidih."
- "Membuat Agar agar : pakai merk swallow merah. Masak dengan 700ml air tambah gula sesuai petunjuk. Cetak dan potong kotak2"
- "Tara...sajikan hangaaatttt. Tinggal ambil ;)"
- "Sruput... Sruput anget manis :))"
categories:
- Recipe
tags:
- angsle

katakunci: angsle 
nutrition: 170 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Dessert

---


![Angsle](https://img-global.cpcdn.com/recipes/f0f0edbd9ce91486/680x482cq70/angsle-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas dan empuk. Ciri khas kuliner Indonesia angsle yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan rumah tangga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Angsle untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis makanan yang dapat anda praktekkan salah satunya angsle yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep angsle tanpa harus bersusah payah.
Seperti resep Angsle yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 9 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Angsle:

1. Siapkan  📍Bahan santan :
1. Jangan lupa 1 butir kelapa agak muda parut,
1. Diperlukan 1 sdt garam
1. Diperlukan 8-10 sdm gula
1. Jangan lupa 2 lembar pandan
1. Siapkan  📍Bahan petulo :
1. Jangan lupa  📍Bahan kacamg hijau :
1. Jangan lupa 1/2 kg kacang hijau
1. Jangan lupa 1000 ml air
1. Jangan lupa 1/2 sdt garam
1. Harus ada  📍Bahan ketan :
1. Harap siapkan 1/2 beras ketan           (lihat resep)
1. Harus ada 1/2 sdt garam
1. Harap siapkan  📍 Bahan agar-agar
1. Siapkan 1 bungkus agar² warna pink
1. Dibutuhkan 800 ml air
1. Harap siapkan 5-7 sdm gula pasir
1. Jangan lupa Sejumput garam




<!--inarticleads2-->

##### Instruksi membuat  Angsle:

1. Membuat petulo /putu Mayang : Dalam wajan campur tepung beras, garam &amp; santan. Aduk rata sampai tidak ada yg bergerindil, jika perlu disaring
1. Nyalakan kompor api kecil, aduk² adonan sampai mengental/menggumpal. Tambahkan tapioka sedikit², aduk rata.tambahkan pewarna hijau. Taruh dalam plastik (karna bahan terlalu berat dan keras maka saya ganti pakai saringan Krn g punya cetakan)
1. Ambil 1 adonan, taruh saringann diatasnya lalu tekan² sampai keluar adonan seperti mie, ambil menggunakan spatula, lalu tata diatas daun pisang yang sudah dioles tipis minyak goreng. Lakukan sampai adonan habis. Jika tdk ada cetakan, gunakan piping bag yang ujungnya dipotong kecil lalu tekan/semprotkan secukupnya. Kukis 15 menit. Sajikan
1. Membuat ketan : ini pke ketan kukus biasa, pernah saya share -           (lihat resep)
1. Membuat kacang hijau. Saya cuci bersih kacang hijau, masak dengan air hingga mendidih matikan kompor. Saring air rebusan. Bisa buat diminum tambah gula. Sisa kacang hijau tadi rendam kembali 5jam. Kemudian presto tambah garam sedikit dan air hingga terendam. Presto 10menit saja. Tiriskan tidak bersama airnya
1. Membuat santan : campurkan santan peras 500ml tambahkan 750-1000ml air. Sejumput garam dan 8 sdm gulapasir. Aduk tambahkan pandan simpul. Aduk terus jangan sampai santan pecah, aduk hingga mendidih.
1. Membuat Agar agar : pakai merk swallow merah. Masak dengan 700ml air tambah gula sesuai petunjuk. Cetak dan potong kotak2
1. Tara...sajikan hangaaatttt. Tinggal ambil ;)
1. Sruput... Sruput anget manis :))




Demikianlah cara membuat angsle yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan cepat, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
