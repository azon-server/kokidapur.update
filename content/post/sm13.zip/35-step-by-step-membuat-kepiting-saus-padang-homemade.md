---
description: "Step-by-Step membuat Kepiting saus padang Homemade"
title: "Step-by-Step membuat Kepiting saus padang Homemade"
slug: 35-step-by-step-membuat-kepiting-saus-padang-homemade
date: 2021-01-08T22:59:34.449Z
image: https://img-global.cpcdn.com/recipes/11a01e8a0c4ccd67/680x482cq70/kepiting-saus-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/11a01e8a0c4ccd67/680x482cq70/kepiting-saus-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/11a01e8a0c4ccd67/680x482cq70/kepiting-saus-padang-foto-resep-utama.jpg
author: Sam Houston
ratingvalue: 4.2
reviewcount: 21284
recipeingredient:
- "3 kg kepiting"
- "1/4 Udang"
- "3 jagung"
- "1 bawang bombay"
- "3 daun jeruk"
- "4 daun salam"
- " Garam dan penyedap rasa ayam"
- " Bumbu halus"
- "5 bawang putih"
- "5 bawang merah"
- "2 kemiri"
- "2 cm kunyit"
- "2 cm jahe"
- " Bahan saos"
- " Saos sambal"
- " Saos tomat"
- " Kecap manis"
- " Kecap asin"
recipeinstructions:
- "Rebus kepiting hingga setengah masak"
- "Blender bumbu halus lalu tumis"
- "Rebus jagung setengah masak dan masak udang setengah masak"
- "Masukan bumbu halus ke dalam wajan kepiting, masukan daun salam, daun jeruk dan bahan saos"
- "Masukan udang dan jagung, dirasa agaj menyusut masukan garam dan penyedap rasa."
- "Jika dirasa sudah pas, tunggu hingga mendidih dan matikan kompor. Kepiting saus padang siap di santap 😎"
- "Rebus"
categories:
- Recipe
tags:
- kepiting
- saus
- padang

katakunci: kepiting saus padang 
nutrition: 123 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dinner

---


![Kepiting saus padang](https://img-global.cpcdn.com/recipes/11a01e8a0c4ccd67/680x482cq70/kepiting-saus-padang-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau gurih. Karasteristik kuliner Indonesia kepiting saus padang yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Kepiting saus padang untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang dapat anda coba salah satunya kepiting saus padang yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep kepiting saus padang tanpa harus bersusah payah.
Berikut ini resep Kepiting saus padang yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kepiting saus padang:

1. Siapkan 3 kg kepiting
1. Tambah 1/4 Udang
1. Harus ada 3 jagung
1. Jangan lupa 1 bawang bombay
1. Dibutuhkan 3 daun jeruk
1. Siapkan 4 daun salam
1. Diperlukan  Garam dan penyedap rasa ayam
1. Tambah  Bumbu halus
1. Tambah 5 bawang putih
1. Tambah 5 bawang merah
1. Dibutuhkan 2 kemiri
1. Siapkan 2 cm kunyit
1. Tambah 2 cm jahe
1. Tambah  Bahan saos
1. Jangan lupa  Saos sambal
1. Harus ada  Saos tomat
1. Siapkan  Kecap manis
1. Jangan lupa  Kecap asin




<!--inarticleads2-->

##### Instruksi membuat  Kepiting saus padang:

1. Rebus kepiting hingga setengah masak
1. Blender bumbu halus lalu tumis
1. Rebus jagung setengah masak dan masak udang setengah masak
1. Masukan bumbu halus ke dalam wajan kepiting, masukan daun salam, daun jeruk dan bahan saos
1. Masukan udang dan jagung, dirasa agaj menyusut masukan garam dan penyedap rasa.
1. Jika dirasa sudah pas, tunggu hingga mendidih dan matikan kompor. Kepiting saus padang siap di santap 😎
1. Rebus




Demikianlah cara membuat kepiting saus padang yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan cepat, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
