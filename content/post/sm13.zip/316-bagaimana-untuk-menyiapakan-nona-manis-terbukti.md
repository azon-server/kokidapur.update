---
description: "Bagaimana untuk menyiapakan Nona Manis Terbukti"
title: "Bagaimana untuk menyiapakan Nona Manis Terbukti"
slug: 316-bagaimana-untuk-menyiapakan-nona-manis-terbukti
date: 2020-09-12T04:43:46.641Z
image: https://img-global.cpcdn.com/recipes/d70c4376126c1813/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d70c4376126c1813/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d70c4376126c1813/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Cora McKenzie
ratingvalue: 4.1
reviewcount: 16211
recipeingredient:
- " Bahan 1 "
- "250 ml santan kental"
- "1 butir telur"
- "80 gr gula pasir"
- "140 gr tepung terigu"
- " Bahan 2 "
- "250 ml santan kental"
- "40 gr gula pasir"
- "30 gr maizena"
- " Pewarna hijau"
- "Sejumput garam"
- " Bahan 3 "
- "500 ml santan kental"
- "6 sdm tepung terigu"
- "88 gr Keju quickmelt optional"
- "Sejumput garam"
recipeinstructions:
- "Bahan 1 : mixer gula dan telur hingga mengental dan berubah warna jadi putih. Masukkan santan dan tepung secara selang seling bertahap. Mixer dengan kecepatan rendah hingga merata. Sisihkan."
- "Bahan 2 : rebus semua bahan dengan api sedang hingga mengental. Matikan api. Setelah agak dingin, campur dengan bahan adonan 1 dan mixer hingga merata. Sisihkan."
- "Bahan 3 : rebus semua bahan dengan api sedang dan di aduk hingga mengental. Matikan api. Aduk hingga tak bergerindil. Jika masih bergerindil bisa menggunakan saringan agar halus. Setelah itu masukkan ke dalam botol kecap plastik."
- "Siapkan cetakan talam dan olesi dengan minyak goreng. Tuang adonan hijau kira kira 3/4 kemudian tuang adonan putih diatasnya hinnga penuh. Caranya, benamkan sedikit moncong botol ditengah adonan hijau. Kukus kurleb 10 menit. Jangan lupa tutup dandang di alasi serbet. Lepas kue ketika sudah dingin."
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 194 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Lunch

---


![Nona Manis](https://img-global.cpcdn.com/recipes/d70c4376126c1813/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita jaga karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti nona manis yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan keistimewahan yang merupakan keragaman Nusantara



Kedekatan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Nona Manis untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang dapat anda buat salah satunya nona manis yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona Manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona Manis:

1. Dibutuhkan  Bahan 1 :
1. Harus ada 250 ml santan kental
1. Tambah 1 butir telur
1. Harus ada 80 gr gula pasir
1. Siapkan 140 gr tepung terigu
1. Jangan lupa  Bahan 2 :
1. Diperlukan 250 ml santan kental
1. Diperlukan 40 gr gula pasir
1. Harus ada 30 gr maizena
1. Diperlukan  Pewarna hijau
1. Siapkan Sejumput garam
1. Tambah  Bahan 3 :
1. Tambah 500 ml santan kental
1. Harus ada 6 sdm tepung terigu
1. Jangan lupa 88 gr Keju quickmelt (optional)
1. Harus ada Sejumput garam




<!--inarticleads2-->

##### Bagaimana membuat  Nona Manis:

1. Bahan 1 : mixer gula dan telur hingga mengental dan berubah warna jadi putih. Masukkan santan dan tepung secara selang seling bertahap. Mixer dengan kecepatan rendah hingga merata. Sisihkan.
1. Bahan 2 : rebus semua bahan dengan api sedang hingga mengental. Matikan api. Setelah agak dingin, campur dengan bahan adonan 1 dan mixer hingga merata. Sisihkan.
1. Bahan 3 : rebus semua bahan dengan api sedang dan di aduk hingga mengental. Matikan api. Aduk hingga tak bergerindil. Jika masih bergerindil bisa menggunakan saringan agar halus. Setelah itu masukkan ke dalam botol kecap plastik.
1. Siapkan cetakan talam dan olesi dengan minyak goreng. Tuang adonan hijau kira kira 3/4 kemudian tuang adonan putih diatasnya hinnga penuh. Caranya, benamkan sedikit moncong botol ditengah adonan hijau. Kukus kurleb 10 menit. Jangan lupa tutup dandang di alasi serbet. Lepas kue ketika sudah dingin.




Demikianlah cara membuat nona manis yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
