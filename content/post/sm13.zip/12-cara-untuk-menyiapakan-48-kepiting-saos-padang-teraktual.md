---
description: "Cara untuk menyiapakan 48. Kepiting Saos Padang teraktual"
title: "Cara untuk menyiapakan 48. Kepiting Saos Padang teraktual"
slug: 12-cara-untuk-menyiapakan-48-kepiting-saos-padang-teraktual
date: 2021-02-21T13:10:20.678Z
image: https://img-global.cpcdn.com/recipes/4bc67cfa2a242b2b/680x482cq70/48-kepiting-saos-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4bc67cfa2a242b2b/680x482cq70/48-kepiting-saos-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4bc67cfa2a242b2b/680x482cq70/48-kepiting-saos-padang-foto-resep-utama.jpg
author: Joseph Norton
ratingvalue: 4.8
reviewcount: 33870
recipeingredient:
- "1 kg6 ekor rajungan"
- "1 ruas jahe geprek"
- "1/2 buah bawang bombai iris sesuai selera"
- "1 batang daun bawang iris serong"
- "1 buah jeruk nipis"
- "Secukupnya air"
- "Secukupnya garam gula dan kaldu jamur"
- " Bumbu Halus "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "3 buah cabe merah keriting"
- "3 buah cabe rawit setan"
- "2 ruas jahe geprek"
- " Bumbu Saos "
- "4 sdm saos sambal sy pakai Belibis"
- "3 sdm saos Cap Jempol ini yang bikin beda"
- "1 sdm saos tomat sy pakai ABC"
- "1 sdm saos tiram sy pakai Cap Panda"
- "2 sdt gula pasir"
recipeinstructions:
- "Didihkan air, masukkan 1 ruas jahe dan 1 sdm garam. Rebus kepiting dengan api kecil (tidak perlu terlalu lama). Tiriskan."
- "Tumis bumbu halus dan 1 ruas jahe sampai matang. Masukkan bawang bombai, tumis lagi sampai harum."
- "Masukkan bumbu saos, aduk sampai mendidih, lalu tambahkan air secukupnya dan daun bawang. Masak sampai agak mengental."
- "Masukkan kepiting, aduk sampai rata, masak sampai bumbu meresap. Koreksi rasa dengan garam (sedikit saja), gula dan kaldu jamur. Jika rasa sudah pas, beri perasan jeruk nipis sebagai sentuhan akhir."
categories:
- Recipe
tags:
- 48
- kepiting
- saos

katakunci: 48 kepiting saos 
nutrition: 129 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Dinner

---


![48. Kepiting Saos Padang](https://img-global.cpcdn.com/recipes/4bc67cfa2a242b2b/680x482cq70/48-kepiting-saos-padang-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti 48. kepiting saos padang yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa ciri khas yang merupakan keragaman Nusantara



Keharmonisan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak 48. Kepiting Saos Padang untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang bisa anda coba salah satunya 48. kepiting saos padang yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep 48. kepiting saos padang tanpa harus bersusah payah.
Berikut ini resep 48. Kepiting Saos Padang yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 48. Kepiting Saos Padang:

1. Harus ada 1 kg/6 ekor rajungan
1. Siapkan 1 ruas jahe, geprek
1. Diperlukan 1/2 buah bawang bombai, iris sesuai selera
1. Harap siapkan 1 batang daun bawang, iris serong
1. Siapkan 1 buah jeruk nipis
1. Tambah Secukupnya air
1. Diperlukan Secukupnya garam, gula dan kaldu jamur
1. Diperlukan  Bumbu Halus :
1. Siapkan 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Harap siapkan 3 buah cabe merah keriting
1. Dibutuhkan 3 buah cabe rawit setan
1. Diperlukan 2 ruas jahe, geprek
1. Tambah  Bumbu Saos :
1. Harap siapkan 4 sdm saos sambal (sy pakai Belibis)
1. Diperlukan 3 sdm saos Cap Jempol (ini yang bikin beda)
1. Jangan lupa 1 sdm saos tomat (sy pakai ABC)
1. Harap siapkan 1 sdm saos tiram (sy pakai Cap Panda)
1. Siapkan 2 sdt gula pasir




<!--inarticleads2-->

##### Cara membuat  48. Kepiting Saos Padang:

1. Didihkan air, masukkan 1 ruas jahe dan 1 sdm garam. Rebus kepiting dengan api kecil (tidak perlu terlalu lama). Tiriskan.
1. Tumis bumbu halus dan 1 ruas jahe sampai matang. Masukkan bawang bombai, tumis lagi sampai harum.
1. Masukkan bumbu saos, aduk sampai mendidih, lalu tambahkan air secukupnya dan daun bawang. Masak sampai agak mengental.
1. Masukkan kepiting, aduk sampai rata, masak sampai bumbu meresap. Koreksi rasa dengan garam (sedikit saja), gula dan kaldu jamur. Jika rasa sudah pas, beri perasan jeruk nipis sebagai sentuhan akhir.




Demikianlah cara membuat 48. kepiting saos padang yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
