---
description: "Steps membuat Kue Nona Manis minggu ini"
title: "Steps membuat Kue Nona Manis minggu ini"
slug: 358-steps-membuat-kue-nona-manis-minggu-ini
date: 2020-11-12T17:02:22.291Z
image: https://img-global.cpcdn.com/recipes/5a14f4450eb2a5fc/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5a14f4450eb2a5fc/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5a14f4450eb2a5fc/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Sophia Blair
ratingvalue: 4.4
reviewcount: 16915
recipeingredient:
- "1 Bahan"
- "1 butir telur ayam"
- "250 ml santan kental"
- "80 gr Gula Pasir"
- "140 gr tepung terigu"
- "2 Bahan"
- "250 ml santan kental"
- "40 gr gula pasir"
- "30 gr tepung maizena"
- "Sejumput garam"
- "3 Bahan"
- "400 ml santan kental"
- "5 sdm tepung terigu"
- "sejumput garam"
- " Bahan pelengkap"
- "2 sdm pasta pandan"
- "secukupnya minyak"
recipeinstructions:
- "Bahan 1: mixer telur n gula sampai mengental dengan kecepatan tinggi, turunkan kecepatan mixer masukkan santan n tepung terigu perlahan2"
- "Bahan 2: rebus semua bahan dengan api kecil, aduk2 hingga beruap matikan n dinginkan. Setelah dirasa dingin masukkan bahan ke 2 ke bahan 1 mixer dengan kecepatan rendah sampai rata tuang 2 sdm pasta pandan. Sisihkan"
- "Bahan 3: rebus semua bahan dengan api kecil hingga kental aduk hingga tidak terlihat tepungnya dinginkan, tuang ke dalam botol kecap."
- "Siapkan cetakan kue talam, olesi sedikit dengan minyak agar adonan tidak lengket"
- "Tuang adonan pandan ke cetakan 3/4 dari cetakan. Masukkan adonan putih kedalam cetakan membentuk lingkaran"
- "Kukus kurang lebih 15 menit. Beri penutup dandang dengan kain serbet agar air tidak terjatuh."
- "Dinginkan adonan yang telah matang, angkat n sajikan"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 287 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Dessert

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/5a14f4450eb2a5fc/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang harus kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti kue nona manis yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan keistimewahan yang merupakan keragaman Indonesia

Keharmonisan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah memasak Kue Nona Manis untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang dapat anda praktekkan salah satunya kue nona manis yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Siapkan 1 Bahan
1. Harus ada 1 butir telur ayam
1. Dibutuhkan 250 ml santan kental
1. Dibutuhkan 80 gr Gula Pasir
1. Siapkan 140 gr tepung terigu
1. Harap siapkan 2 Bahan
1. Jangan lupa 250 ml santan kental
1. Dibutuhkan 40 gr gula pasir
1. Diperlukan 30 gr tepung maizena
1. Harus ada Sejumput garam
1. Dibutuhkan 3 Bahan
1. Dibutuhkan 400 ml santan kental
1. Dibutuhkan 5 sdm tepung terigu
1. Tambah sejumput garam
1. Jangan lupa  Bahan pelengkap
1. Diperlukan 2 sdm pasta pandan
1. Jangan lupa secukupnya minyak




<!--inarticleads2-->

##### Langkah membuat  Kue Nona Manis:

1. Bahan 1: mixer telur n gula sampai mengental dengan kecepatan tinggi, turunkan kecepatan mixer masukkan santan n tepung terigu perlahan2
1. Bahan 2: rebus semua bahan dengan api kecil, aduk2 hingga beruap matikan n dinginkan. Setelah dirasa dingin masukkan bahan ke 2 ke bahan 1 mixer dengan kecepatan rendah sampai rata tuang 2 sdm pasta pandan. Sisihkan
1. Bahan 3: rebus semua bahan dengan api kecil hingga kental aduk hingga tidak terlihat tepungnya dinginkan, tuang ke dalam botol kecap.
1. Siapkan cetakan kue talam, olesi sedikit dengan minyak agar adonan tidak lengket
1. Tuang adonan pandan ke cetakan 3/4 dari cetakan. Masukkan adonan putih kedalam cetakan membentuk lingkaran
1. Kukus kurang lebih 15 menit. Beri penutup dandang dengan kain serbet agar air tidak terjatuh.
1. Dinginkan adonan yang telah matang, angkat n sajikan




Demikianlah cara membuat kue nona manis yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
