---
description: "Langkah membuat Kepiting Saus Padang Teruji"
title: "Langkah membuat Kepiting Saus Padang Teruji"
slug: 62-langkah-membuat-kepiting-saus-padang-teruji
date: 2021-01-21T14:23:09.437Z
image: https://img-global.cpcdn.com/recipes/d22166551a6562cb/680x482cq70/kepiting-saus-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d22166551a6562cb/680x482cq70/kepiting-saus-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d22166551a6562cb/680x482cq70/kepiting-saus-padang-foto-resep-utama.jpg
author: Angel Mendez
ratingvalue: 4.3
reviewcount: 19447
recipeingredient:
- "2 kg kepiting"
- " Bumbu Halus"
- "10 siung bawang merah"
- "6 siung bawang putih"
- "Sedikit laos"
- "Sedikit jahe"
- "Sedikit kunyit bakar"
- "5 butir kemiri sangrai"
- "6 cabe merah besar"
- "12 cabe kecil optional kalau suka pedas bisa ditambahi"
- " Bumbu Pelengkap"
- "1 bawang bombay iris2"
- "2 tomat iris2"
- "2 Daun salam"
- "2 Daun jeruk"
- " Sereh"
- "5 sdm Soas tomat"
- "4 sdm Saus sambal"
- "3 sdm Soas tiram"
- "2 butir telur kocok lepas"
- " Bawang pre"
- "secukupnya Garam"
- "secukupnya Gula"
- " Minyak goreng untuk menumis"
- "secukupnya Air"
recipeinstructions:
- "Matikan kepiting, bersihkan dari kotoran2, kalau perlu disikat lalu rebus dengan air mendidih"
- "Blender bumbu halus sampai lembut, lalu tumis dengan minyak panas. Setelah setengah matang masukkan bawang bombay iris. Jangan lupa tambahkan daun salam, jeruk purut, serai, irisan tomat. Masak bumbu sampai harum dan tanek/matang"
- "Setelah bumbu matang tambahkan soas tiram, saos tomat, saos cabe, garam, dan gula. Tes rasa. Jika rasanya sudah pas masukkan air biarkan mendidih lalu masukkan kepiting. Masak kepiting sampai meresap bumbunya."
- "Setelah kepiting matang dan bumbu berkurang/asat. Masukkan kocokan telur, aduk dengan cepat. Kepiting siap disajikan. Bisa juga pakai larutan maizena kalau tidak suka telur. Selamat mencoba bunda2 cantik"
categories:
- Recipe
tags:
- kepiting
- saus
- padang

katakunci: kepiting saus padang 
nutrition: 100 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Dessert

---


![Kepiting Saus Padang](https://img-global.cpcdn.com/recipes/d22166551a6562cb/680x482cq70/kepiting-saus-padang-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti kepiting saus padang yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan keistimewahan yang merupakan keragaman Kita

Kedekatan keluarga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Kepiting Saus Padang untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang bisa anda contoh salah satunya kepiting saus padang yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep kepiting saus padang tanpa harus bersusah payah.
Seperti resep Kepiting Saus Padang yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 25 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kepiting Saus Padang:

1. Harus ada 2 kg kepiting
1. Dibutuhkan  Bumbu Halus
1. Dibutuhkan 10 siung bawang merah
1. Tambah 6 siung bawang putih
1. Harap siapkan Sedikit laos
1. Jangan lupa Sedikit jahe
1. Diperlukan Sedikit kunyit bakar
1. Dibutuhkan 5 butir kemiri sangrai
1. Tambah 6 cabe merah besar
1. Dibutuhkan 12 cabe kecil (optional kalau suka pedas bisa ditambahi)
1. Tambah  Bumbu Pelengkap
1. Harus ada 1 bawang bombay iris2
1. Siapkan 2 tomat iris2
1. Harus ada 2 Daun salam
1. Jangan lupa 2 Daun jeruk
1. Tambah  Sereh
1. Harap siapkan 5 sdm Soas tomat
1. Harus ada 4 sdm Saus sambal
1. Siapkan 3 sdm Soas tiram
1. Diperlukan 2 butir telur kocok lepas
1. Dibutuhkan  Bawang pre
1. Dibutuhkan secukupnya Garam
1. Tambah secukupnya Gula
1. Dibutuhkan  Minyak goreng untuk menumis
1. Jangan lupa secukupnya Air




<!--inarticleads2-->

##### Langkah membuat  Kepiting Saus Padang:

1. Matikan kepiting, bersihkan dari kotoran2, kalau perlu disikat lalu rebus dengan air mendidih
1. Blender bumbu halus sampai lembut, lalu tumis dengan minyak panas. Setelah setengah matang masukkan bawang bombay iris. Jangan lupa tambahkan daun salam, jeruk purut, serai, irisan tomat. Masak bumbu sampai harum dan tanek/matang
1. Setelah bumbu matang tambahkan soas tiram, saos tomat, saos cabe, garam, dan gula. Tes rasa. Jika rasanya sudah pas masukkan air biarkan mendidih lalu masukkan kepiting. Masak kepiting sampai meresap bumbunya.
1. Setelah kepiting matang dan bumbu berkurang/asat. Masukkan kocokan telur, aduk dengan cepat. Kepiting siap disajikan. Bisa juga pakai larutan maizena kalau tidak suka telur. Selamat mencoba bunda2 cantik




Demikianlah cara membuat kepiting saus padang yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan teruji, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
