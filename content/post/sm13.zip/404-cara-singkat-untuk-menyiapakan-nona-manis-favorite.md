---
description: "Cara singkat untuk menyiapakan Nona Manis Favorite"
title: "Cara singkat untuk menyiapakan Nona Manis Favorite"
slug: 404-cara-singkat-untuk-menyiapakan-nona-manis-favorite
date: 2021-02-07T06:47:26.663Z
image: https://img-global.cpcdn.com/recipes/5a8fdc9e24770478/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5a8fdc9e24770478/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5a8fdc9e24770478/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Claudia Harmon
ratingvalue: 5
reviewcount: 36553
recipeingredient:
- "250 gram terigu"
- "250 gram gula pasir"
- "2 butir telur"
- "5 gelas santan"
- "secukupnya garam halus"
- "secukupnya vanili"
- " perwarna makanan pandan pasta"
- "2 sdm tepung maizena"
- "2 sdm terigu"
- "2 sdm gula pasir"
recipeinstructions:
- "Siapkan wadah, masukkan 250 gr gula pasir, telur aduk hingga larut lalu tambahkan 3 gelas santan, 250 gr terigu aduk lagi hingga tercampur rata. Masukkan pandan pasta secukupnya. Lalu sisihkah."
- "Siapkan panci kecil, masukkan tepung maizena, 1 gelas santan. Kemudian masak hingga mendidih. Adonan ini dimasukkan ke adonan berwarna hijau (no. 1)aduk hingga merata. Sisihkan."
- "Siapkan panci kecil, masukkan 2 sdm terigu, 2 sdm gula pasir, vanili, 1/2 sdm garam halus, 1 gelas santan kemudian dimasak hingga mendidih. Jika adonan mengental dapat ditambah air lagi. Adonan jgn terlalu kental dan jgn terlalu cair sekali."
- "Siapkan kukusan dan cetakan plastik yang kecil yang sudah diolesi mentega/minyak."
- "Masukkan adonan hijau dalam cetakan, lalu tambahkan 1 sendok adonan putih (no.3) ditengah2 adonan yang hijau.lalu kukus 15 menit."
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 183 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dinner

---


![Nona Manis](https://img-global.cpcdn.com/recipes/5a8fdc9e24770478/680x482cq70/nona-manis-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti nona manis yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan keistimewahan yang merupakan keragaman Indonesia

Keharmonisan rumah tangga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Nona Manis untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang bisa anda praktekkan salah satunya nona manis yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona Manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona Manis:

1. Harus ada 250 gram terigu
1. Siapkan 250 gram gula pasir
1. Dibutuhkan 2 butir telur
1. Harap siapkan 5 gelas santan
1. Diperlukan secukupnya garam halus
1. Jangan lupa secukupnya vanili
1. Dibutuhkan  perwarna makanan (pandan pasta)
1. Harap siapkan 2 sdm tepung maizena
1. Diperlukan 2 sdm terigu
1. Dibutuhkan 2 sdm gula pasir




<!--inarticleads2-->

##### Cara membuat  Nona Manis:

1. Siapkan wadah, masukkan 250 gr gula pasir, telur aduk hingga larut lalu tambahkan 3 gelas santan, 250 gr terigu aduk lagi hingga tercampur rata. Masukkan pandan pasta secukupnya. Lalu sisihkah.
1. Siapkan panci kecil, masukkan tepung maizena, 1 gelas santan. Kemudian masak hingga mendidih. Adonan ini dimasukkan ke adonan berwarna hijau (no. 1)aduk hingga merata. Sisihkan.
1. Siapkan panci kecil, masukkan 2 sdm terigu, 2 sdm gula pasir, vanili, 1/2 sdm garam halus, 1 gelas santan kemudian dimasak hingga mendidih. Jika adonan mengental dapat ditambah air lagi. Adonan jgn terlalu kental dan jgn terlalu cair sekali.
1. Siapkan kukusan dan cetakan plastik yang kecil yang sudah diolesi mentega/minyak.
1. Masukkan adonan hijau dalam cetakan, lalu tambahkan 1 sendok adonan putih (no.3) ditengah2 adonan yang hijau.lalu kukus 15 menit.




Demikianlah cara membuat nona manis yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
