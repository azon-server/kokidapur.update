---
description: "Step-by-Step untuk menyiapakan Udang Saus Padang Extra Pedas Homemade"
title: "Step-by-Step untuk menyiapakan Udang Saus Padang Extra Pedas Homemade"
slug: 222-step-by-step-untuk-menyiapakan-udang-saus-padang-extra-pedas-homemade
date: 2020-11-06T13:22:10.555Z
image: https://img-global.cpcdn.com/recipes/aa7bf9726a70f927/680x482cq70/udang-saus-padang-extra-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/aa7bf9726a70f927/680x482cq70/udang-saus-padang-extra-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/aa7bf9726a70f927/680x482cq70/udang-saus-padang-extra-pedas-foto-resep-utama.jpg
author: Wesley Wong
ratingvalue: 4
reviewcount: 4296
recipeingredient:
- "150 gram udang"
- "1 buah tomat"
- "1/4 bh bawang bombay"
- "1 lembar daun jeruk"
- "Secukupnya garam gula lada bubuk air"
- "Secukupnya saus tomat saus tiram dan kecap manis"
- " Bumbu Halus "
- "1 butir bawang merah ukuran besar"
- "1 siung bawang putih ukuran besar"
- "2 bh cabe merah besar"
- "11 bh cabe rawit"
- "1 cm jahe"
recipeinstructions:
- "Cuci bersih udang, sy cuma buang kepalanya aja. Klo mau dikupas kulitnya jg gpp sih. Hehe. Setelah itu rebus udang hingga berubah warna. Tiriskan"
- "Siapkan bumbu halus, potong2 bawang bombay dan tomat. Tumis bumbu halus hingga harum. Kemudian masukkan tomat, bawang bombay dan daun jeruk. Tumis hingga layu"
- "Setelah layu tambahkan sedikit air, masukkan garam, gula, lada, saus tomat, saus tiram dan kecap manis. Jika sudah mendidih, masukkan udang. Aduk2 rata, masak hingga bumbu meresap"
- "Siap disajikan. Rasanya mantull bgt"
categories:
- Recipe
tags:
- udang
- saus
- padang

katakunci: udang saus padang 
nutrition: 168 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT56M"
recipeyield: "3"
recipecategory: Lunch

---


![Udang Saus Padang Extra Pedas](https://img-global.cpcdn.com/recipes/aa7bf9726a70f927/680x482cq70/udang-saus-padang-extra-pedas-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang patut kita lestarikan karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti udang saus padang extra pedas yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan keistimewahan yang merupakan keragaman Indonesia



Kehangatan keluarga dapat ditemukan dengan cara mudah. Salah satunya adalah memasak Udang Saus Padang Extra Pedas untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang bisa anda coba salah satunya udang saus padang extra pedas yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep udang saus padang extra pedas tanpa harus bersusah payah.
Seperti resep Udang Saus Padang Extra Pedas yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Udang Saus Padang Extra Pedas:

1. Siapkan 150 gram udang
1. Diperlukan 1 buah tomat
1. Diperlukan 1/4 bh bawang bombay
1. Siapkan 1 lembar daun jeruk
1. Harus ada Secukupnya garam, gula, lada bubuk, air
1. Harus ada Secukupnya saus tomat, saus tiram, dan kecap manis
1. Tambah  Bumbu Halus :
1. Jangan lupa 1 butir bawang merah ukuran besar
1. Diperlukan 1 siung bawang putih ukuran besar
1. Dibutuhkan 2 bh cabe merah besar
1. Harus ada 11 bh cabe rawit
1. Harus ada 1 cm jahe




<!--inarticleads2-->

##### Langkah membuat  Udang Saus Padang Extra Pedas:

1. Cuci bersih udang, sy cuma buang kepalanya aja. Klo mau dikupas kulitnya jg gpp sih. Hehe. Setelah itu rebus udang hingga berubah warna. Tiriskan
1. Siapkan bumbu halus, potong2 bawang bombay dan tomat. Tumis bumbu halus hingga harum. Kemudian masukkan tomat, bawang bombay dan daun jeruk. Tumis hingga layu
1. Setelah layu tambahkan sedikit air, masukkan garam, gula, lada, saus tomat, saus tiram dan kecap manis. Jika sudah mendidih, masukkan udang. Aduk2 rata, masak hingga bumbu meresap
1. Siap disajikan. Rasanya mantull bgt




Demikianlah cara membuat udang saus padang extra pedas yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan teruji, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
