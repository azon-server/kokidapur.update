---
description: "Cara menyiapakan Seafood Saos Padang (Kepiting &amp;amp; udang) Sempurna"
title: "Cara menyiapakan Seafood Saos Padang (Kepiting &amp;amp; udang) Sempurna"
slug: 87-cara-menyiapakan-seafood-saos-padang-kepiting-and-amp-udang-sempurna
date: 2021-01-10T00:46:51.560Z
image: https://img-global.cpcdn.com/recipes/4801e01e9b63fe41/680x482cq70/seafood-saos-padang-kepiting-udang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4801e01e9b63fe41/680x482cq70/seafood-saos-padang-kepiting-udang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4801e01e9b63fe41/680x482cq70/seafood-saos-padang-kepiting-udang-foto-resep-utama.jpg
author: Marguerite Chavez
ratingvalue: 4.2
reviewcount: 44163
recipeingredient:
- "2 ekor kepiting ukuran kecil"
- "100 gr udang segar"
- "1 buah jagung potong jd bbrp bagian"
- "1/2 jeruk nipis utk seafood agr tdk amis"
- " Bumbu halus "
- "4 siung bawang merah"
- "2 siung bawang putih ukuran besar"
- "4 buah cabe keriting merah"
- "4 buah cabe rawit merah cengek domba"
- " Bumbu tumis tambahan "
- "1 batang daun bawang"
- "1/2 buah bombay ukuran kecil"
- "1/2 ruas jari jahe geprek"
- "2 helai daun jeruk"
- "2 sdm saus sambal"
- "1 sdm saus tomat"
- "1 sdm kecap manis"
- "secukupnya Garam gula putih kaldu aku pakai totole merica"
- " Air secukupnya dan minyak goreng utk menumis bumbu"
- "1 sdt maizena"
recipeinstructions:
- "Siapkan bahan. Cuci bersih udang dan kepiting kemudian beri perasan jeruk nipis agar tdk amis. Kemudian rebus. Utk udang jangan terlalu lama ya...kemudian sisihkan terlebih dahulu"
- "Rebus jagung hingga matang kemudian sisihkan."
- "Haluskan bumbu halus (bwg merah, bwg putih, cabe keriting dan rawit) beri air saat diblender. Kemudian tumis bersama dengan bawang bombay, daun jeruk dan jahe geprekHingga harum"
- "Biarkan bumbu matang, kemudian tambahkan air secukupnya, masukan garam, gula putih, kaldu, merica saus smabal, saus tomat dan kecap koreksi rasa. Lalu masukan jagung terlebih dahulu."
- "Setelah bumbu sudah Ok, masukan seafood (udang dan kepiting) kemudian disusul daun bawang. Biarkan bumbu meresap (tambah air jika kurang ya). Sesekali koreksi rasa jika bumbu sudah pas masukan 1/2 sdr maizenna biarkan kuah smpai agak kental"
- "Seafood saos pdang siap dihidangkan. Dijamin enakkkk mantul dimakan dengan nasi panas yummy👍🏻👍🏻"
categories:
- Recipe
tags:
- seafood
- saos
- padang

katakunci: seafood saos padang 
nutrition: 148 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Lunch

---


![Seafood Saos Padang (Kepiting &amp; udang)](https://img-global.cpcdn.com/recipes/4801e01e9b63fe41/680x482cq70/seafood-saos-padang-kepiting-udang-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau gurih. Karasteristik makanan Indonesia seafood saos padang (kepiting &amp; udang) yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga dapat didapat dengan cara simple. Diantaranya adalah memasak Seafood Saos Padang (Kepiting &amp; udang) untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang dapat anda buat salah satunya seafood saos padang (kepiting &amp; udang) yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep seafood saos padang (kepiting &amp; udang) tanpa harus bersusah payah.
Seperti resep Seafood Saos Padang (Kepiting &amp; udang) yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Seafood Saos Padang (Kepiting &amp; udang):

1. Harap siapkan 2 ekor kepiting (ukuran kecil)
1. Jangan lupa 100 gr udang segar
1. Harus ada 1 buah jagung (potong jd bbrp bagian)
1. Tambah 1/2 jeruk nipis (utk seafood agr tdk amis)
1. Tambah  Bumbu halus :
1. Jangan lupa 4 siung bawang merah
1. Jangan lupa 2 siung bawang putih ukuran besar
1. Diperlukan 4 buah cabe keriting merah
1. Diperlukan 4 buah cabe rawit merah (cengek domba)
1. Diperlukan  Bumbu tumis tambahan :
1. Dibutuhkan 1 batang daun bawang
1. Tambah 1/2 buah bombay (ukuran kecil)
1. Dibutuhkan 1/2 ruas jari jahe geprek
1. Harap siapkan 2 helai daun jeruk
1. Siapkan 2 sdm saus sambal
1. Harap siapkan 1 sdm saus tomat
1. Harus ada 1 sdm kecap manis
1. Diperlukan secukupnya Garam, gula putih, kaldu (aku pakai totole), merica
1. Harus ada  Air secukupnya dan minyak goreng utk menumis bumbu
1. Diperlukan 1 sdt maizena




<!--inarticleads2-->

##### Instruksi membuat  Seafood Saos Padang (Kepiting &amp; udang):

1. Siapkan bahan. Cuci bersih udang dan kepiting kemudian beri perasan jeruk nipis agar tdk amis. Kemudian rebus. Utk udang jangan terlalu lama ya...kemudian sisihkan terlebih dahulu
1. Rebus jagung hingga matang kemudian sisihkan.
1. Haluskan bumbu halus (bwg merah, bwg putih, cabe keriting dan rawit) beri air saat diblender. Kemudian tumis bersama dengan bawang bombay, daun jeruk dan jahe geprekHingga harum
1. Biarkan bumbu matang, kemudian tambahkan air secukupnya, masukan garam, gula putih, kaldu, merica saus smabal, saus tomat dan kecap koreksi rasa. Lalu masukan jagung terlebih dahulu.
1. Setelah bumbu sudah Ok, masukan seafood (udang dan kepiting) kemudian disusul daun bawang. Biarkan bumbu meresap (tambah air jika kurang ya). Sesekali koreksi rasa jika bumbu sudah pas masukan 1/2 sdr maizenna biarkan kuah smpai agak kental
1. Seafood saos pdang siap dihidangkan. Dijamin enakkkk mantul dimakan dengan nasi panas yummy👍🏻👍🏻




Demikianlah cara membuat seafood saos padang (kepiting &amp; udang) yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan cepat, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
