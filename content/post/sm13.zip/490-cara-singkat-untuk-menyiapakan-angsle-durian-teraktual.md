---
description: "Cara singkat untuk menyiapakan Angsle Durian teraktual"
title: "Cara singkat untuk menyiapakan Angsle Durian teraktual"
slug: 490-cara-singkat-untuk-menyiapakan-angsle-durian-teraktual
date: 2020-10-20T08:17:09.435Z
image: https://img-global.cpcdn.com/recipes/7d437e662d974adb/680x482cq70/angsle-durian-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7d437e662d974adb/680x482cq70/angsle-durian-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7d437e662d974adb/680x482cq70/angsle-durian-foto-resep-utama.jpg
author: Brian Sanders
ratingvalue: 4.4
reviewcount: 15393
recipeingredient:
- "500 gr beras ketan"
- "250 gr kacang hijau"
- "1 bungkus sagu mutiara"
- "1 bungkus roti tawar"
- "600 ml santan kental bisa pakai santan instan"
- "1 buah durian"
- "250 ml susu cair bisa skip"
- "Secukupnya gula dan garam"
- "4 lembar daun pandan"
recipeinstructions:
- "Pertama kita buat ketan nya dulu, caranya sama seperti cara menanak nasi."
- "Kemudian bikin kacang hijaunya, tinggal cuci dan bersihkan kacang hijau, rebus kurang lebih 45 menit, sampai mekar empuk, beri sedikit gula dan sejumput garam, biar gak tawar aja ya."
- "Selanjutnya kita bikin mutiara, panaskan air kalau sudah mendidih masukan sagu mutiara, rebus selam 30 menit, bisa diberi pewarna makanan merah sedikit biar merahnya cantik dan merata, beri sedikit gula dan garam, sisihkan."
- "Selanjutnya kita bikin santan nya, tinggal didihkan santan dengan tambahan gula dan garam, cicipi ya, kalau rasa sudah pas dan santan mendidih matikan api."
- "Selanjutnya tata ketan, kacang hijau, mutiara dan potongan roti, tambahkan buah durian, lengkap dengan santan, siap dihidangkan selagi hangat, selamat mencoba."
categories:
- Recipe
tags:
- angsle
- durian

katakunci: angsle durian 
nutrition: 202 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Dinner

---


![Angsle Durian](https://img-global.cpcdn.com/recipes/7d437e662d974adb/680x482cq70/angsle-durian-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau renyah. Ciri khas makanan Indonesia angsle durian yang penuh dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Angsle Durian untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang bisa anda coba salah satunya angsle durian yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep angsle durian tanpa harus bersusah payah.
Berikut ini resep Angsle Durian yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 9 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Angsle Durian:

1. Siapkan 500 gr beras ketan
1. Harus ada 250 gr kacang hijau
1. Harus ada 1 bungkus sagu mutiara
1. Harap siapkan 1 bungkus roti tawar
1. Tambah 600 ml santan kental, bisa pakai santan instan
1. Harap siapkan 1 buah durian
1. Diperlukan 250 ml susu cair (bisa skip)
1. Harus ada Secukupnya gula dan garam
1. Harus ada 4 lembar daun pandan




<!--inarticleads2-->

##### Cara membuat  Angsle Durian:

1. Pertama kita buat ketan nya dulu, caranya sama seperti cara menanak nasi.
1. Kemudian bikin kacang hijaunya, tinggal cuci dan bersihkan kacang hijau, rebus kurang lebih 45 menit, sampai mekar empuk, beri sedikit gula dan sejumput garam, biar gak tawar aja ya.
1. Selanjutnya kita bikin mutiara, panaskan air kalau sudah mendidih masukan sagu mutiara, rebus selam 30 menit, bisa diberi pewarna makanan merah sedikit biar merahnya cantik dan merata, beri sedikit gula dan garam, sisihkan.
1. Selanjutnya kita bikin santan nya, tinggal didihkan santan dengan tambahan gula dan garam, cicipi ya, kalau rasa sudah pas dan santan mendidih matikan api.
1. Selanjutnya tata ketan, kacang hijau, mutiara dan potongan roti, tambahkan buah durian, lengkap dengan santan, siap dihidangkan selagi hangat, selamat mencoba.




Demikianlah cara membuat angsle durian yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
