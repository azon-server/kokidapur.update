---
description: "Resep : Kue nona manis Terbukti"
title: "Resep : Kue nona manis Terbukti"
slug: 406-resep-kue-nona-manis-terbukti
date: 2021-01-21T03:08:00.314Z
image: https://img-global.cpcdn.com/recipes/660f8694aebc083b/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/660f8694aebc083b/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/660f8694aebc083b/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Katie Banks
ratingvalue: 4.7
reviewcount: 9914
recipeingredient:
- " Bahan I "
- "250 ml santan kental"
- "1 btr telur ayam"
- "100 gr gula pasir"
- "140 gr terigu serbaguna"
- " Bahan II "
- "125 ml santan kental"
- "125 ml air pandan suji"
- "30 gr tepung maizena"
- "25 gr gula pasir"
- "sejumput garam"
- " Bahan III "
- "500 ml santan kental"
- "40 gr tepung beras"
- "40 gr gula pasir"
- "sejumput garam"
recipeinstructions:
- "Siapkan dandang, bungkus tutupnya dgn serbet, cetakan kue mangkok/talam, olesi dgn minyak. Siapkan juga botol yg tutupnya bermoncong."
- "Bahan II, aduk rata santan, air pandan suji, tepung maizena, gula pasir &amp; garam. Masak dgn api sedang sambil diaduk sampai kental &amp; tdk bergerindil. Sisihkan."
- "Bahan I, kocok telur &amp; gula pasir sampai kental, masukkan santan &amp; terigu. Kocok lagi dgn speed rendah hingga tercampur rata."
- "Masukkan bahan II ke bahan I, kocok hingga halus &amp; tdk bergerindil (ini akan jadi adonan hijau)."
- "Campur &amp; aduk rata bahan III. Masak sambil diaduk2 hingga mengental dan halus. Masukkan dlm botol (adonan putih)."
- "Panaskan dandang dgn api sedang hingga mendidih."
- "Tuang adonan hijau setinggi 3/4 cetakan, lalu semprotkan adonan putih di bagian tengah dgn cara membenamkan sedikit moncong botol sampai adonan penuh."
- "Kukus 10-15 menit. Dinginkan, baru keluarkan dari cetakan."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 195 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dessert

---


![Kue nona manis](https://img-global.cpcdn.com/recipes/660f8694aebc083b/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti kue nona manis yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa ciri khas yang merupakan keragaman Kita

Kedekatan keluarga bisa didapat dengan cara simple. Diantaranya adalah membuat makanan Kue nona manis untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang bisa anda coba salah satunya kue nona manis yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue nona manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue nona manis:

1. Harus ada  Bahan I :
1. Harus ada 250 ml santan kental
1. Jangan lupa 1 btr telur ayam
1. Jangan lupa 100 gr gula pasir
1. Harap siapkan 140 gr terigu serbaguna
1. Jangan lupa  Bahan II :
1. Diperlukan 125 ml santan kental
1. Tambah 125 ml air pandan suji
1. Tambah 30 gr tepung maizena
1. Diperlukan 25 gr gula pasir
1. Siapkan sejumput garam
1. Jangan lupa  Bahan III :
1. Dibutuhkan 500 ml santan kental
1. Dibutuhkan 40 gr tepung beras
1. Siapkan 40 gr gula pasir
1. Dibutuhkan sejumput garam




<!--inarticleads2-->

##### Langkah membuat  Kue nona manis:

1. Siapkan dandang, bungkus tutupnya dgn serbet, cetakan kue mangkok/talam, olesi dgn minyak. Siapkan juga botol yg tutupnya bermoncong.
1. Bahan II, aduk rata santan, air pandan suji, tepung maizena, gula pasir &amp; garam. Masak dgn api sedang sambil diaduk sampai kental &amp; tdk bergerindil. Sisihkan.
1. Bahan I, kocok telur &amp; gula pasir sampai kental, masukkan santan &amp; terigu. Kocok lagi dgn speed rendah hingga tercampur rata.
1. Masukkan bahan II ke bahan I, kocok hingga halus &amp; tdk bergerindil (ini akan jadi adonan hijau).
1. Campur &amp; aduk rata bahan III. Masak sambil diaduk2 hingga mengental dan halus. Masukkan dlm botol (adonan putih).
1. Panaskan dandang dgn api sedang hingga mendidih.
1. Tuang adonan hijau setinggi 3/4 cetakan, lalu semprotkan adonan putih di bagian tengah dgn cara membenamkan sedikit moncong botol sampai adonan penuh.
1. Kukus 10-15 menit. Dinginkan, baru keluarkan dari cetakan.




Demikianlah cara membuat kue nona manis yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
