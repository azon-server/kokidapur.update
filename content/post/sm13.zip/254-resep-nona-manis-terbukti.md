---
description: "Resep : Nona Manis Terbukti"
title: "Resep : Nona Manis Terbukti"
slug: 254-resep-nona-manis-terbukti
date: 2020-11-04T00:40:55.728Z
image: https://img-global.cpcdn.com/recipes/7b4af0dd918fa6fe/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7b4af0dd918fa6fe/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7b4af0dd918fa6fe/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Victor Soto
ratingvalue: 4.6
reviewcount: 4815
recipeingredient:
- " Adonan hijau"
- " Bahan A"
- "250 ml santan kekentalan sedang"
- "10 lembar daun pandan"
- "Secukupnya pasta pandan"
- "2 butir telur ukuran sedang"
- "80 gr gula pasir"
- "140 gr terigu serbaguna"
- " Bahan B"
- "300 ml santan kekentalan sedang"
- "40 gr gula pasir"
- "30 gr maizena"
- "3 gr garam"
- " Adonan putih"
- "500 ml santan kental"
- "6 sdm terigu serbaguna"
- "3 gr garam"
recipeinstructions:
- "Bahan B : campurkan semua bahan didalam panci. Aduk rata. Lalu masak dengan api kecil hingga beruap dan agak kental. Matikan api. Dinginkan."
- "Bahan A : blender pandan dg santan &amp; pasta pandan. Saring dan peras ampasnya. Lalu ukur lagi cairan pandan 250ml. Jika kurang boleh tambah air biasa. Sisihkan. Mixer gula dan telur hingga kental. Masukkan cairan pandan dan terigu sedikit demi sedikit. Aduk rata, tidak bergerindil. Sisihkan"
- "Setelah bahan B dingin, tambahkan ke bahan A secara bertahap. Campur rata. Sisihkan"
- "Adonan putih : campurkan semua bahan didalam panci. Masak dengan api kecil hingga mengental. Matikan api. Aduk2 sampai dingin agar tidak bergerindil. Masukkan ke dalam botol kecap."
- "Panaskan kukusan."
- "Siapkan cetakan kue talam. Oles tipis dengan minyak. Tuang adonan hijau 1/2 bagian lalu semprotkan adonan putih dibagian tengah adonan hijau hingga cetakan hampir penuh."
- "Kukus selama 10 menit.Atau sampai pinggirannya terlepas. Tunggu dingin baru di lepas dari cetakan."
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 148 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Lunch

---


![Nona Manis](https://img-global.cpcdn.com/recipes/7b4af0dd918fa6fe/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau renyah. Ciri khas makanan Indonesia nona manis yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Nona Manis untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang bisa anda contoh salah satunya nona manis yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona Manis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona Manis:

1. Tambah  Adonan hijau
1. Harus ada  Bahan A
1. Diperlukan 250 ml santan kekentalan sedang
1. Harus ada 10 lembar daun pandan
1. Dibutuhkan Secukupnya pasta pandan
1. Diperlukan 2 butir telur ukuran sedang
1. Siapkan 80 gr gula pasir
1. Harap siapkan 140 gr terigu serbaguna
1. Tambah  Bahan B
1. Jangan lupa 300 ml santan kekentalan sedang
1. Harus ada 40 gr gula pasir
1. Harap siapkan 30 gr maizena
1. Harus ada 3 gr garam
1. Harap siapkan  Adonan putih
1. Harus ada 500 ml santan kental
1. Jangan lupa 6 sdm terigu serbaguna
1. Siapkan 3 gr garam




<!--inarticleads2-->

##### Instruksi membuat  Nona Manis:

1. Bahan B : campurkan semua bahan didalam panci. Aduk rata. Lalu masak dengan api kecil hingga beruap dan agak kental. Matikan api. Dinginkan.
1. Bahan A : blender pandan dg santan &amp; pasta pandan. Saring dan peras ampasnya. Lalu ukur lagi cairan pandan 250ml. Jika kurang boleh tambah air biasa. Sisihkan. Mixer gula dan telur hingga kental. Masukkan cairan pandan dan terigu sedikit demi sedikit. Aduk rata, tidak bergerindil. Sisihkan
1. Setelah bahan B dingin, tambahkan ke bahan A secara bertahap. Campur rata. Sisihkan
1. Adonan putih : campurkan semua bahan didalam panci. Masak dengan api kecil hingga mengental. Matikan api. Aduk2 sampai dingin agar tidak bergerindil. Masukkan ke dalam botol kecap.
1. Panaskan kukusan.
1. Siapkan cetakan kue talam. Oles tipis dengan minyak. Tuang adonan hijau 1/2 bagian lalu semprotkan adonan putih dibagian tengah adonan hijau hingga cetakan hampir penuh.
1. Kukus selama 10 menit.Atau sampai pinggirannya terlepas. Tunggu dingin baru di lepas dari cetakan.




Demikianlah cara membuat nona manis yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
