---
description: "Resep : Kepiting saos Padang/asem manis Homemade"
title: "Resep : Kepiting saos Padang/asem manis Homemade"
slug: 165-resep-kepiting-saos-padang-asem-manis-homemade
date: 2020-09-28T01:56:13.374Z
image: https://img-global.cpcdn.com/recipes/9a0a64c941b06059/680x482cq70/kepiting-saos-padangasem-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9a0a64c941b06059/680x482cq70/kepiting-saos-padangasem-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9a0a64c941b06059/680x482cq70/kepiting-saos-padangasem-manis-foto-resep-utama.jpg
author: Alma Page
ratingvalue: 5
reviewcount: 19461
recipeingredient:
- "5 ekor kepiting"
- "1 buah bawang bombay besar"
- "1 bawang merah besar5 bawang merah kecil"
- "1/2 sdt garam"
- "2 helai daun bawang"
- "1 buah jagung manisoptional"
- "1 butir telur kocok lepas"
- "5 sdm saos ABC pedas"
- "1 SDM saos tomapasta tomat"
- "2 cabai merah besar"
- "3 bawah putih"
- "1 rusa jahe geprek"
- "1 biji sereh"
recipeinstructions:
- "Bgi dua bumbu.,setengah saya aluskan setengah saya iris tipis..kmudian tumis sampai harum"
- "Rebus dulu kepiting setngah matang.,belah tengah ny buang ingsan ny..kalo kepiting besar suka banyak lumpur dingsan ny..kalo kepiting yg kecil Gpp gak dibuang.."
- "Tumis bumbu hingga harum..masukan jahe,sereh yg sudah di geprek..masukan sedikit air..tunggu hingga mendidih Masukan jagung manis,trus kepiting yg sudah dibelah JD dua..aduk2..jngan lupa icip rasa..dirasa kurang apa tinggal tambah"
- "Stelah di aduk n jagung di rasa dah mateng..masukan kocokan telur..aduk2 lg sajikan.."
categories:
- Recipe
tags:
- kepiting
- saos
- padangasem

katakunci: kepiting saos padangasem 
nutrition: 154 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dinner

---


![Kepiting saos Padang/asem manis](https://img-global.cpcdn.com/recipes/9a0a64c941b06059/680x482cq70/kepiting-saos-padangasem-manis-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau renyah. Ciri khas masakan Indonesia kepiting saos padang/asem manis yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kedekatan rumah tangga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Kepiting saos Padang/asem manis untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang bisa anda contoh salah satunya kepiting saos padang/asem manis yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep kepiting saos padang/asem manis tanpa harus bersusah payah.
Berikut ini resep Kepiting saos Padang/asem manis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kepiting saos Padang/asem manis:

1. Diperlukan 5 ekor kepiting
1. Diperlukan 1 buah bawang bombay besar
1. Siapkan 1 bawang merah besar/5 bawang merah kecil
1. Diperlukan 1/2 sdt garam
1. Siapkan 2 helai daun bawang
1. Harus ada 1 buah jagung manis(optional)
1. Jangan lupa 1 butir telur kocok lepas
1. Diperlukan 5 sdm saos ABC pedas
1. Dibutuhkan 1 SDM saos toma/pasta tomat
1. Harus ada 2 cabai merah besar
1. Diperlukan 3 bawah putih
1. Tambah 1 rusa jahe (geprek)
1. Tambah 1 biji sereh




<!--inarticleads2-->

##### Instruksi membuat  Kepiting saos Padang/asem manis:

1. Bgi dua bumbu.,setengah saya aluskan setengah saya iris tipis..kmudian tumis sampai harum
1. Rebus dulu kepiting setngah matang.,belah tengah ny buang ingsan ny..kalo kepiting besar suka banyak lumpur dingsan ny..kalo kepiting yg kecil Gpp gak dibuang..
1. Tumis bumbu hingga harum..masukan jahe,sereh yg sudah di geprek..masukan sedikit air..tunggu hingga mendidih - Masukan jagung manis,trus kepiting yg sudah dibelah JD dua..aduk2..jngan lupa icip rasa..dirasa kurang apa tinggal tambah
1. Stelah di aduk n jagung di rasa dah mateng..masukan kocokan telur..aduk2 lg sajikan..




Demikianlah cara membuat kepiting saos padang/asem manis yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
