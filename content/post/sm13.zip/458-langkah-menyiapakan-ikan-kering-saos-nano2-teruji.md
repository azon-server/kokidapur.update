---
description: "Langkah menyiapakan Ikan kering saos nano2 Teruji"
title: "Langkah menyiapakan Ikan kering saos nano2 Teruji"
slug: 458-langkah-menyiapakan-ikan-kering-saos-nano2-teruji
date: 2021-02-04T00:53:05.579Z
image: https://img-global.cpcdn.com/recipes/a13f89dceffc0c02/680x482cq70/ikan-kering-saos-nano2-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a13f89dceffc0c02/680x482cq70/ikan-kering-saos-nano2-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a13f89dceffc0c02/680x482cq70/ikan-kering-saos-nano2-foto-resep-utama.jpg
author: Lawrence Figueroa
ratingvalue: 4.7
reviewcount: 15282
recipeingredient:
- " Ikan kering make semangkok kecilorg sini bilangnya"
- "sesuai selera Kacang goreng"
- "9 butir Lombok  rica nona"
- "2 buah Tomat"
- "2 butir Bawang merah"
- "2 butir Bawang putih"
- "1 butir Kemiri"
- "3 gr Kaldu jamur"
- "75 ml Asam jawa secukunya larutkan air"
- "1/2 sdt Ketumbar"
- "1/2 sdt Jintan"
- "secukupnya Gula merah"
- "1 sdm Kecap manis"
- "1 sdm Garam himalaya"
- "8 sdm Minyak kelapa"
recipeinstructions:
- "Ikan keringnya saya gunting jadi 2 bagian, kemudian goreng kecokelatan"
- "Haluskan lombok,bumbu2 bawang merah, bawang putih, kemiri, kemudian iris2 tomat pisah di tempat sendiri"
- "Panaskan minyak kelapa, kemudian tumis bumbu halus sampai kecokelatan lalu turunkan tomat tumis hingga layu tomatnya baru tuangkan air asamnya terakhir campurkan jintan/ ketumbar, kecap dan Gula merah, garam hingga airnya mendidih kering sampai tinggal minyak sambal"
- "Setelah minyak sambal kita diamkan sampai dingin sekitar 10 menit baru campurkan ikan kering sama kacang aduk rata dan siap disantap (tahan sampai beberapa hari kedepan kalau kita tumis hingga airnya kering tersisa minyak)"
categories:
- Recipe
tags:
- ikan
- kering
- saos

katakunci: ikan kering saos 
nutrition: 134 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Dinner

---


![Ikan kering saos nano2](https://img-global.cpcdn.com/recipes/a13f89dceffc0c02/680x482cq70/ikan-kering-saos-nano2-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau empuk. Ciri khas masakan Nusantara ikan kering saos nano2 yang kaya dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga bisa ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ikan kering saos nano2 untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang dapat anda coba salah satunya ikan kering saos nano2 yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan cepat menemukan resep ikan kering saos nano2 tanpa harus bersusah payah.
Berikut ini resep Ikan kering saos nano2 yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 15 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ikan kering saos nano2:

1. Tambah  Ikan kering make semangkok kecil(org sini bilangnya)
1. Harus ada sesuai selera Kacang goreng
1. Harus ada 9 butir Lombok / rica nona
1. Diperlukan 2 buah Tomat
1. Jangan lupa 2 butir Bawang merah
1. Diperlukan 2 butir Bawang putih
1. Dibutuhkan 1 butir Kemiri
1. Jangan lupa 3 gr Kaldu jamur
1. Dibutuhkan 75 ml Asam jawa secukunya larutkan air
1. Harap siapkan 1/2 sdt Ketumbar
1. Siapkan 1/2 sdt Jintan
1. Harap siapkan secukupnya Gula merah
1. Harus ada 1 sdm Kecap manis
1. Harap siapkan 1 sdm Garam himalaya
1. Diperlukan 8 sdm Minyak kelapa




<!--inarticleads2-->

##### Instruksi membuat  Ikan kering saos nano2:

1. Ikan keringnya saya gunting jadi 2 bagian, kemudian goreng kecokelatan
1. Haluskan lombok,bumbu2 bawang merah, bawang putih, kemiri, kemudian iris2 tomat pisah di tempat sendiri
1. Panaskan minyak kelapa, kemudian tumis bumbu halus sampai kecokelatan lalu turunkan tomat tumis hingga layu tomatnya baru tuangkan air asamnya terakhir campurkan jintan/ ketumbar, kecap dan Gula merah, garam hingga airnya mendidih kering sampai tinggal minyak sambal
1. Setelah minyak sambal kita diamkan sampai dingin sekitar 10 menit baru campurkan ikan kering sama kacang aduk rata dan siap disantap (tahan sampai beberapa hari kedepan kalau kita tumis hingga airnya kering tersisa minyak)




Demikianlah cara membuat ikan kering saos nano2 yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
