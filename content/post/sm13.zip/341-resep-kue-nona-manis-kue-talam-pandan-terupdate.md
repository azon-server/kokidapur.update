---
description: "Resep : Kue Nona Manis / Kue Talam Pandan terupdate"
title: "Resep : Kue Nona Manis / Kue Talam Pandan terupdate"
slug: 341-resep-kue-nona-manis-kue-talam-pandan-terupdate
date: 2020-10-26T10:59:27.560Z
image: https://img-global.cpcdn.com/recipes/95973fa29439fa6f/680x482cq70/kue-nona-manis-kue-talam-pandan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/95973fa29439fa6f/680x482cq70/kue-nona-manis-kue-talam-pandan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/95973fa29439fa6f/680x482cq70/kue-nona-manis-kue-talam-pandan-foto-resep-utama.jpg
author: Olive Harris
ratingvalue: 4
reviewcount: 31829
recipeingredient:
- " Bahan 1 "
- "1/5 gelas gula pasir ak pake 14 gelas"
- "2 gelas santan kental"
- "3 sdm agak munjung tepung maizena"
- "15 lembar daun pandanblender dengan santan lalu saring"
- "1/4 sdt garam"
- "7 tts pewarna hijau tua merk koepoe koepoe"
- " Bahan 2 "
- "2 gelas santan kental"
- "3 sdm tepung maezena"
- "Secukupnya garam sampai terasa gurih"
- " Bahan 3 "
- "2-3 butir telur ak pake 2 butir"
- "2 gelas tepung terigu"
- "1/2 gelas tepung maizena"
- "2 gelas santan kental"
- "1 gelas gula pasir sesuaikan selera"
recipeinstructions:
- "Masukan semua bahan 1(adonan hijau) ke panci.nyalakan api kecil. Masak hingga meletup2(sambil diaduk terus). Angkat dinginkan.."
- "Masukan bahan 2 ke panci lain.nyalakan api...sambil diaduk terus.bila sudah mengental dan meletup2 matikan api.biarkan uap panas hilang..masukan kebotol kecap supaya mudah dituang."
- "Siapkan baskom kocok telur &amp; gula hingga gula larut.lalu masukan duo tepung &amp; santan bertahap selang seling.mixer sampai tdk ada yg menggerindil.. (maaf telur kepot 1 ja nggah ngeh)"
- "Lalu masukan bahan 1(adonan hijau) ke dllm adonan 3 sambil dimixer supaya tercampur rata. Jadilah adonan encer."
- "Olesi cetakan talam dengan minyak goreng. Tipis2 saja😊"
- "Tuang adonan hijau 3/4 cetakkan lalu tuang adonan putih diatasnya."
- "Kukus selama 10 menit api besar. Tutup dandang jngn lupa dibungkus."
- "Angkat..bila uap panas sudah hilang lalu keluarkan dari cetakan.bila sulit keluar gunakan bantuan sendok."
- "Dinginkan..beri potongan daun pandan. Supaya lebih cantik. Bungkus bila sudah benar2 dingin ya."
- "Sajikan😊😍"
- "Tips nona cantik : 🍀1. Adonan putih (yg ditengah) saat dimasak jangan terlalu kental nanti sulit dituang 🍀2. Gunakan pasta pandan asli (dengan cara memblender daun pandan asli) hasilnya lebih syedep &amp; warna levih cantik😍 dibanding pasta pandan instan. 🍀3. Ketika sudah matang,kipasin dlu supaya cepat dingin dan lebih kokoh saat dikeluarkan😊. 🍀4. Gunakan gelas yg sama untuk menakar santan,tepung &amp; gula ya. SEMOGA BERMANFAAT😊"
- "Contoh gelas yg aku pake untuk takaran."
- "Tutorial nona manis"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 135 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Lunch

---


![Kue Nona Manis / Kue Talam Pandan](https://img-global.cpcdn.com/recipes/95973fa29439fa6f/680x482cq70/kue-nona-manis-kue-talam-pandan-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga renyah. Ciri kuliner Nusantara kue nona manis / kue talam pandan yang penuh dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga dapat didapat dengan cara simple. Salah satunya adalah memasak Kue Nona Manis / Kue Talam Pandan untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang dapat anda praktekkan salah satunya kue nona manis / kue talam pandan yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep kue nona manis / kue talam pandan tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis / Kue Talam Pandan yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 bahan dan 13 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis / Kue Talam Pandan:

1. Jangan lupa  Bahan 1 :
1. Jangan lupa 1/5 gelas gula pasir (ak pake 1/4 gelas)
1. Jangan lupa 2 gelas santan kental
1. Diperlukan 3 sdm agak munjung tepung maizena
1. Siapkan 15 lembar daun pandan,blender dengan santan lalu saring
1. Siapkan 1/4 sdt garam
1. Diperlukan 7 tts pewarna hijau tua (merk koepoe koepoe)
1. Tambah  Bahan 2 :
1. Harap siapkan 2 gelas santan kental
1. Diperlukan 3 sdm tepung maezena
1. Dibutuhkan Secukupnya garam (sampai terasa gurih)
1. Dibutuhkan  Bahan 3 :
1. Harus ada 2-3 butir telur (ak pake 2 butir)
1. Diperlukan 2 gelas tepung terigu
1. Siapkan 1/2 gelas tepung maizena
1. Dibutuhkan 2 gelas santan kental
1. Jangan lupa 1 gelas gula pasir (sesuaikan selera)




<!--inarticleads2-->

##### Langkah membuat  Kue Nona Manis / Kue Talam Pandan:

1. Masukan semua bahan 1(adonan hijau) ke panci.nyalakan api kecil. Masak hingga meletup2(sambil diaduk terus). Angkat dinginkan..
1. Masukan bahan 2 ke panci lain.nyalakan api...sambil diaduk terus.bila sudah mengental dan meletup2 matikan api.biarkan uap panas hilang..masukan kebotol kecap supaya mudah dituang.
1. Siapkan baskom kocok telur &amp; gula hingga gula larut.lalu masukan duo tepung &amp; santan bertahap selang seling.mixer sampai tdk ada yg menggerindil.. (maaf telur kepot 1 ja nggah ngeh)
1. Lalu masukan bahan 1(adonan hijau) ke dllm adonan 3 sambil dimixer supaya tercampur rata. Jadilah adonan encer.
1. Olesi cetakan talam dengan minyak goreng. Tipis2 saja😊
1. Tuang adonan hijau 3/4 cetakkan lalu tuang adonan putih diatasnya.
1. Kukus selama 10 menit api besar. Tutup dandang jngn lupa dibungkus.
1. Angkat..bila uap panas sudah hilang lalu keluarkan dari cetakan.bila sulit keluar gunakan bantuan sendok.
1. Dinginkan..beri potongan daun pandan. Supaya lebih cantik. Bungkus bila sudah benar2 dingin ya.
1. Sajikan😊😍
1. Tips nona cantik : 🍀1. Adonan putih (yg ditengah) saat dimasak jangan terlalu kental nanti sulit dituang 🍀2. Gunakan pasta pandan asli (dengan cara memblender daun pandan asli) hasilnya lebih syedep &amp; warna levih cantik😍 dibanding pasta pandan instan. 🍀3. Ketika sudah matang,kipasin dlu supaya cepat dingin dan lebih kokoh saat dikeluarkan😊. 🍀4. Gunakan gelas yg sama untuk menakar santan,tepung &amp; gula ya. SEMOGA BERMANFAAT😊
1. Contoh gelas yg aku pake untuk takaran.
1. Tutorial nona manis




Demikianlah cara membuat kue nona manis / kue talam pandan yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan cepat, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
