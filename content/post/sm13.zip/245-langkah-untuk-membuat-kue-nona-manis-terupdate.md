---
description: "Langkah untuk membuat Kue nona manis terupdate"
title: "Langkah untuk membuat Kue nona manis terupdate"
slug: 245-langkah-untuk-membuat-kue-nona-manis-terupdate
date: 2021-01-10T23:42:39.878Z
image: https://img-global.cpcdn.com/recipes/7673f4b1322fa216/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7673f4b1322fa216/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7673f4b1322fa216/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Gabriel Wheeler
ratingvalue: 4.5
reviewcount: 30066
recipeingredient:
- " Bahan A"
- "250 ml santan"
- "1 btr telur"
- "125 gr gula pasir"
- "125 gr tepung terigu"
- " Bahan B"
- "250 ml santan disini saya pakai santan  jus pandan"
- "60 gr gula pasir"
- "30 gr maizena"
- " Bahan C"
- "250 ml santan kental"
- "1 sdm munjung terigu"
- "1 sdm gula pasir"
- "Sedikit garam"
- "secukupnya Cucing atau cetakan kue talam"
recipeinstructions:
- "Siapkan bahan terlebih dahulu."
- "Campur semua bahan B jadi satu lalu masak dengan api kecil sampai mengental, sisihkan. Campur semua bahan C lalu masak dengan api kecil sampai mengental lalu sisihkan. Untuk bahan A masukkan dalam blender telur, gula dan santan. Lalu blender sampai rata. Terakhir masukkan tepung terigu lalu aduk sampai rata dan tidak bergerindil."
- "Lalu campur bahan B ke bahan A aduk rata. Olesi cucing dengan minyak goreng tipis2."
- "Tuang adonan hijau ke dalam cucing jangan penuh2... kemudian tuang adonan C boleh pakai sendok boleh pakai botol kecap. Lalu kukus sampai matang dengan api sedang. Kukusan sudah dipanaskan terlebih dahulu"
- "Ketika sudah matang, angkat dan biarkan dingin lalu keluarkan dari cetakan si nona manis."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 143 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Lunch

---


![Kue nona manis](https://img-global.cpcdn.com/recipes/7673f4b1322fa216/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis dan renyah. Ciri masakan Indonesia kue nona manis yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga dapat ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Kue nona manis untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

Kue nona manis adalah salah satu jajanan tradisional yang melegenda di Indonesia. Ada yang tahu kue nona manis? SALAH satu jajanan pasar kue nona manis rasanya sudah jarang ditemui. Meski langkahnya sedikit rumit, ada rasa puas tersendiri saat berhasil membuat kue nona manis.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang dapat anda praktekkan salah satunya kue nona manis yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue nona manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue nona manis:

1. Jangan lupa  Bahan A
1. Harap siapkan 250 ml santan
1. Dibutuhkan 1 btr telur
1. Tambah 125 gr gula pasir
1. Dibutuhkan 125 gr tepung terigu
1. Harus ada  Bahan B
1. Harus ada 250 ml santan (disini saya pakai santan + jus pandan)
1. Diperlukan 60 gr gula pasir
1. Siapkan 30 gr maizena
1. Jangan lupa  Bahan C
1. Tambah 250 ml santan kental
1. Diperlukan 1 sdm munjung terigu
1. Dibutuhkan 1 sdm gula pasir
1. Siapkan Sedikit garam
1. Diperlukan secukupnya Cucing atau cetakan kue talam


Nona manis adalah kue khas Sulawesi. Teksturnya lebih lembut dari kue talam Indonesia lainnya. Bagian yang berwarna hijau rasanya manis dan gurih santan, sedangkan bagian yang berwarna putih. Aih, sudah lama rasanya tidak mendengar Kue Nona Manis. 

<!--inarticleads2-->

##### Instruksi membuat  Kue nona manis:

1. Siapkan bahan terlebih dahulu.
1. Campur semua bahan B jadi satu lalu masak dengan api kecil sampai mengental, sisihkan. Campur semua bahan C lalu masak dengan api kecil sampai mengental lalu sisihkan. Untuk bahan A masukkan dalam blender telur, gula dan santan. Lalu blender sampai rata. Terakhir masukkan tepung terigu lalu aduk sampai rata dan tidak bergerindil.
1. Lalu campur bahan B ke bahan A aduk rata. Olesi cucing dengan minyak goreng tipis2.
1. Tuang adonan hijau ke dalam cucing jangan penuh2... kemudian tuang adonan C boleh pakai sendok boleh pakai botol kecap. Lalu kukus sampai matang dengan api sedang. Kukusan sudah dipanaskan terlebih dahulu
1. Ketika sudah matang, angkat dan biarkan dingin lalu keluarkan dari cetakan si nona manis.


Bagian yang berwarna hijau rasanya manis dan gurih santan, sedangkan bagian yang berwarna putih. Aih, sudah lama rasanya tidak mendengar Kue Nona Manis. Camilan klasik ini bisa Bunda hadirkan kembali dengan warna menarik yang tidak akan ditolak oleh si kecil. Your current browser isn&#39;t compatible with SoundCloud. Please download one of our supported browsers. 

Demikianlah cara membuat kue nona manis yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
