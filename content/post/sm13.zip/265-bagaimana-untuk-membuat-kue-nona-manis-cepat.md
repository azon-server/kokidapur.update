---
description: "Bagaimana untuk membuat Kue Nona Manis Cepat"
title: "Bagaimana untuk membuat Kue Nona Manis Cepat"
slug: 265-bagaimana-untuk-membuat-kue-nona-manis-cepat
date: 2020-12-01T21:07:54.540Z
image: https://img-global.cpcdn.com/recipes/43f28d30c868a2db/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/43f28d30c868a2db/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/43f28d30c868a2db/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Helena Adams
ratingvalue: 4.5
reviewcount: 1997
recipeingredient:
- " bahan 1"
- "500 ml santan sedang"
- "55 gram terigu protein sedang"
- "2,5 sendok makan susu bubuk"
- "1 sendok teh garam"
- " Bahan 2"
- "250 ml santan sedang"
- "250 ml jus pandan"
- "100 sampai 120 gram gula pasir"
- "50 sampai 60 gram maizena atau tepung beras"
- "1/2 sendok teh garam"
- " bahan 3"
- "200 gram gula pasir"
- "2 butir telur"
- "500 ml santan sedang"
- "250 gram terigu protein sedang"
recipeinstructions:
- "Campur jadi satu semua bahan 1 menggunakan api kecil dan diaduk sampai meletup dan mengental lalu sisihkan atau tuang kedalam piping bag"
- "Campur jadi satu semua bahan 2 aduk rata Kemudian masak di atas api kecil terus diaduk sampai agak mengental lalu matikan api"
- "Aduk di dalam baskom bahan 3 telur dan gula dikocok menggunakan wis sampai larut kemudian tambahkan terigu dan santan secara bergantian sampai selesai"
- "Kemudian ambil bahan2 lalu tuang ke dalam baskom tadi Aduk menggunakan wis sampai merata"
- "Saring adonan supaya tidak ada yang menggumpal"
- "Olesi cetakan cucing dengan menggunakan minyak goreng"
- "Panaskan api kompor suhu sedang jangan lupa tutup panci dilapisi serbet"
- "Tuang bahan 3 ke dalam cetakan cucing sebanyak 3/4"
- "Lalu tuang ditengah-tengahnya bahan 1 sampai adonan hampir penuh"
- "Kukus Kurang lebih 10 menit dengan api sedang"
- "Angkat dari kukusan dan diamkan sesaat sampai agak hangat Kemudian keluarkan dari cetakan"
- "Hidangkan dalam keadaan dingin😘"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 291 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dessert

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/43f28d30c868a2db/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga renyah. Ciri khas masakan Indonesia kue nona manis yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan rumah tangga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Kue Nona Manis untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang dapat anda buat salah satunya kue nona manis yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 12 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Tambah  bahan 1:
1. Diperlukan 500 ml santan sedang
1. Tambah 55 gram terigu protein sedang
1. Tambah 2,5 sendok makan susu bubuk
1. Tambah 1 sendok teh garam
1. Diperlukan  Bahan 2:
1. Diperlukan 250 ml santan sedang
1. Harap siapkan 250 ml jus pandan
1. Diperlukan 100 sampai 120 gram gula pasir
1. Harus ada 50 sampai 60 gram maizena atau tepung beras
1. Harus ada 1/2 sendok teh garam
1. Harap siapkan  bahan 3:
1. Diperlukan 200 gram gula pasir
1. Dibutuhkan 2 butir telur
1. Tambah 500 ml santan sedang
1. Harus ada 250 gram terigu protein sedang




<!--inarticleads2-->

##### Bagaimana membuat  Kue Nona Manis:

1. Campur jadi satu semua bahan 1 menggunakan api kecil dan diaduk sampai meletup dan mengental lalu sisihkan atau tuang kedalam piping bag
1. Campur jadi satu semua bahan 2 aduk rata Kemudian masak di atas api kecil terus diaduk sampai agak mengental lalu matikan api
1. Aduk di dalam baskom bahan 3 telur dan gula dikocok menggunakan wis sampai larut kemudian tambahkan terigu dan santan secara bergantian sampai selesai
1. Kemudian ambil bahan2 lalu tuang ke dalam baskom tadi Aduk menggunakan wis sampai merata
1. Saring adonan supaya tidak ada yang menggumpal
1. Olesi cetakan cucing dengan menggunakan minyak goreng
1. Panaskan api kompor suhu sedang jangan lupa tutup panci dilapisi serbet
1. Tuang bahan 3 ke dalam cetakan cucing sebanyak 3/4
1. Lalu tuang ditengah-tengahnya bahan 1 sampai adonan hampir penuh
1. Kukus Kurang lebih 10 menit dengan api sedang
1. Angkat dari kukusan dan diamkan sesaat sampai agak hangat Kemudian keluarkan dari cetakan
1. Hidangkan dalam keadaan dingin😘




Demikianlah cara membuat kue nona manis yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan terbukti, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
