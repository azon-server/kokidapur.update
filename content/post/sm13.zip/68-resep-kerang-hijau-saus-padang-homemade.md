---
description: "Resep : Kerang Hijau Saus Padang Homemade"
title: "Resep : Kerang Hijau Saus Padang Homemade"
slug: 68-resep-kerang-hijau-saus-padang-homemade
date: 2020-10-08T03:46:51.944Z
image: https://img-global.cpcdn.com/recipes/c197cf7483591c6a/680x482cq70/kerang-hijau-saus-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c197cf7483591c6a/680x482cq70/kerang-hijau-saus-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c197cf7483591c6a/680x482cq70/kerang-hijau-saus-padang-foto-resep-utama.jpg
author: Irene Page
ratingvalue: 4.2
reviewcount: 35120
recipeingredient:
- "250 gr kerang hijau"
- " untuk merebus menggunakan"
- "2 lembar daun salam"
- "1 ruas lengkuas"
- "1 ruas jahe"
- " bumbu2"
- "2 siung bawang putih"
- "3 siung bawang merah"
- "1 sdm saus tiram"
- "2 sdm saus tomat"
- "1 sdm saus sambal"
- " cabe skip"
- "1 batang sereh"
- "1 ruas jahe"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 sdm minyak goreng"
- "2 sdm air"
- "1/2 sdt gula pasir"
- "1/2 sdt kaldu jamur"
- "1/4 sdt lada bubuk"
- "1 batang daun bawang"
recipeinstructions:
- "Cuci bersih kerang hijau, lalu didihkan air beri daun salam, lengkuas, jahe, masukkan kerang hijau.. bila ada kerang yg tidak terbuka, pisahkan dan buang, jangan ikut dimasak"
- "Lalu cuci kembali, bersihkan bagian yg berserabut dr kerang"
- "Ini tampilan setelah dibersihkan"
- "Tumis bumbu yg sudah diiris hingga harum, masukkan saus, beri air dan kerang, masak hingga matang, taburi daun bawang"
- "Sajikan bersama nasi hangat"
categories:
- Recipe
tags:
- kerang
- hijau
- saus

katakunci: kerang hijau saus 
nutrition: 190 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Dinner

---


![Kerang Hijau Saus Padang](https://img-global.cpcdn.com/recipes/c197cf7483591c6a/680x482cq70/kerang-hijau-saus-padang-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga empuk. Karasteristik makanan Indonesia kerang hijau saus padang yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga dapat didapat dengan cara simple. Salah satunya adalah memasak Kerang Hijau Saus Padang untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang bisa anda buat salah satunya kerang hijau saus padang yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep kerang hijau saus padang tanpa harus bersusah payah.
Berikut ini resep Kerang Hijau Saus Padang yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 22 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kerang Hijau Saus Padang:

1. Harap siapkan 250 gr kerang hijau
1. Jangan lupa  untuk merebus menggunakan:
1. Harap siapkan 2 lembar daun salam
1. Harap siapkan 1 ruas lengkuas
1. Dibutuhkan 1 ruas jahe
1. Harap siapkan  bumbu2:
1. Harap siapkan 2 siung bawang putih
1. Siapkan 3 siung bawang merah
1. Siapkan 1 sdm saus tiram
1. Diperlukan 2 sdm saus tomat
1. Tambah 1 sdm saus sambal
1. Harap siapkan  cabe (skip)
1. Harus ada 1 batang sereh
1. Harap siapkan 1 ruas jahe
1. Harus ada 2 lembar daun salam
1. Tambah 2 lembar daun jeruk
1. Harap siapkan 1 sdm minyak goreng
1. Diperlukan 2 sdm air
1. Dibutuhkan 1/2 sdt gula pasir
1. Dibutuhkan 1/2 sdt kaldu jamur
1. Siapkan 1/4 sdt lada bubuk
1. Harus ada 1 batang daun bawang




<!--inarticleads2-->

##### Bagaimana membuat  Kerang Hijau Saus Padang:

1. Cuci bersih kerang hijau, lalu didihkan air beri daun salam, lengkuas, jahe, masukkan kerang hijau.. bila ada kerang yg tidak terbuka, pisahkan dan buang, jangan ikut dimasak
1. Lalu cuci kembali, bersihkan bagian yg berserabut dr kerang
1. Ini tampilan setelah dibersihkan
1. Tumis bumbu yg sudah diiris hingga harum, masukkan saus, beri air dan kerang, masak hingga matang, taburi daun bawang
1. Sajikan bersama nasi hangat




Demikianlah cara membuat kerang hijau saus padang yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat simple dan cepat, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
