---
description: "Resep : Udang Saus Padang Luar biasa"
title: "Resep : Udang Saus Padang Luar biasa"
slug: 85-resep-udang-saus-padang-luar-biasa
date: 2020-12-26T20:54:13.133Z
image: https://img-global.cpcdn.com/recipes/90aee28ff8bff264/680x482cq70/udang-saus-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/90aee28ff8bff264/680x482cq70/udang-saus-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/90aee28ff8bff264/680x482cq70/udang-saus-padang-foto-resep-utama.jpg
author: Sean Payne
ratingvalue: 4.3
reviewcount: 22715
recipeingredient:
- "1/2 kg udang boleh ga dibuang kepala dan buntut sesuai selera"
- "1 sdm garam"
- "1 buah jeruk nipis  lemon"
- "1/2 sdt lada"
- "1 sdt garam"
- "1 sdt gula"
- "2 cm jahe"
- "3 lembar daun jeruk"
- "4 sdm saos tomat"
- "1 sdm saos tiram"
- "1 buah tomat ukuran kecil dipotong dadu"
- "100 ml air"
- "1 batang daun bawang"
- " Bahan halus"
- "6 buah cabe keriting"
- "4 buah cabe rawit"
- "6 siung bawang merah"
- "4 siung bawang putih"
recipeinstructions:
- "Lumuri udang dengan garam dan jeruk nipis/lemon. Diamkan 15 menit, kemudian cuci bersih"
- "Tumis bumbu halus hingga wangi, lalu masukkan daun jeruk, jahe, saos tomat dan saos tiram. Serta masukkan garam. Tumis hingga merata dan matang"
- "Masukkan udang, tumis hingga udang berubah warna. Kemudian tambahkan air 100 ml. Didihkan udang hingga matang. Tambah gula dan cek rasa. Tunggu hingga kuah mengental."
- "Terakhir masukkan daun bawang dan tomat, matikan api. Udang saus padang siap disantap."
categories:
- Recipe
tags:
- udang
- saus
- padang

katakunci: udang saus padang 
nutrition: 181 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT43M"
recipeyield: "3"
recipecategory: Dessert

---


![Udang Saus Padang](https://img-global.cpcdn.com/recipes/90aee28ff8bff264/680x482cq70/udang-saus-padang-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti udang saus padang yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan keistimewahan yang merupakan keragaman Nusantara

Kedekatan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak Udang Saus Padang untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang dapat anda contoh salah satunya udang saus padang yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep udang saus padang tanpa harus bersusah payah.
Seperti resep Udang Saus Padang yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Udang Saus Padang:

1. Diperlukan 1/2 kg udang (boleh ga dibuang kepala dan buntut, sesuai selera)
1. Harus ada 1 sdm garam
1. Harus ada 1 buah jeruk nipis / lemon
1. Siapkan 1/2 sdt lada
1. Harus ada 1 sdt garam
1. Siapkan 1 sdt gula
1. Harap siapkan 2 cm jahe
1. Harus ada 3 lembar daun jeruk
1. Dibutuhkan 4 sdm saos tomat
1. Dibutuhkan 1 sdm saos tiram
1. Siapkan 1 buah tomat (ukuran kecil) dipotong dadu
1. Dibutuhkan 100 ml air
1. Dibutuhkan 1 batang daun bawang
1. Dibutuhkan  Bahan halus
1. Tambah 6 buah cabe keriting
1. Siapkan 4 buah cabe rawit
1. Diperlukan 6 siung bawang merah
1. Siapkan 4 siung bawang putih




<!--inarticleads2-->

##### Langkah membuat  Udang Saus Padang:

1. Lumuri udang dengan garam dan jeruk nipis/lemon. Diamkan 15 menit, kemudian cuci bersih
1. Tumis bumbu halus hingga wangi, lalu masukkan daun jeruk, jahe, saos tomat dan saos tiram. Serta masukkan garam. Tumis hingga merata dan matang
1. Masukkan udang, tumis hingga udang berubah warna. Kemudian tambahkan air 100 ml. Didihkan udang hingga matang. Tambah gula dan cek rasa. Tunggu hingga kuah mengental.
1. Terakhir masukkan daun bawang dan tomat, matikan api. Udang saus padang siap disantap.




Demikianlah cara membuat udang saus padang yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
