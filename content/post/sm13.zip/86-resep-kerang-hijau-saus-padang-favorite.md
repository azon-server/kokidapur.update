---
description: "Resep : Kerang Hijau Saus Padang Favorite"
title: "Resep : Kerang Hijau Saus Padang Favorite"
slug: 86-resep-kerang-hijau-saus-padang-favorite
date: 2021-01-11T16:42:38.173Z
image: https://img-global.cpcdn.com/recipes/3605ef8895ac2fcc/680x482cq70/kerang-hijau-saus-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3605ef8895ac2fcc/680x482cq70/kerang-hijau-saus-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3605ef8895ac2fcc/680x482cq70/kerang-hijau-saus-padang-foto-resep-utama.jpg
author: Steve Banks
ratingvalue: 5
reviewcount: 10846
recipeingredient:
- "250 gr kerang hijau  1 daun salam"
- "1 buah jagung manis"
- "1 sdm butter"
- " Bahan bumbu"
- "3 siung bawang putih iris"
- "5 siung bawang merah iris"
- "1/4 bawang Bombai iris"
- "13 cabe rawit iris"
- "2 cabe keriting merah  3 cabe keriting hijau bisa salah satu"
- "1 daun salam"
- "3 daun jeruk"
- "1/2 sdt jahe bubuk"
- "1/4 sdt lengkuas bubuk"
- "1/4 sdt lada bubuk"
- " Bahan saus  perasa"
- "2 sdm saus tiram"
- "2 sdm saus tomat"
- "5 sdm saus sambal"
- " Perasa  1 sdt garam  1 sdt kaldu  12 sdt gula sesuaikan"
recipeinstructions:
- "Rebus keras 5-7 menit tambahkan daun salam. Rebus jagung selama 15 menit atau hingga matang. Persiapkan bahan lainnya"
- "Lelehkan butter masukan bumbu iris tunggu matang baru aneka saus"
- "Beri 300ml air dan masukan jagung. Beri perasa dan tunggu airnya berkurang setengahnya. Masukan kerang aduk rata koreksi rasa. Masak cukup 3-5 menit supaya kerang tidak alot 😁"
- "Plating ala ala wkwkwk"
categories:
- Recipe
tags:
- kerang
- hijau
- saus

katakunci: kerang hijau saus 
nutrition: 191 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Lunch

---


![Kerang Hijau Saus Padang](https://img-global.cpcdn.com/recipes/3605ef8895ac2fcc/680x482cq70/kerang-hijau-saus-padang-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga empuk. Karasteristik masakan Indonesia kerang hijau saus padang yang penuh dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Kerang Hijau Saus Padang untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang dapat anda buat salah satunya kerang hijau saus padang yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep kerang hijau saus padang tanpa harus bersusah payah.
Seperti resep Kerang Hijau Saus Padang yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 19 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kerang Hijau Saus Padang:

1. Dibutuhkan 250 gr kerang hijau + 1 daun salam
1. Siapkan 1 buah jagung manis
1. Diperlukan 1 sdm butter
1. Harus ada  Bahan bumbu
1. Siapkan 3 siung bawang putih iris
1. Diperlukan 5 siung bawang merah iris
1. Diperlukan 1/4 bawang Bombai iris
1. Harap siapkan 13 cabe rawit iris
1. Harus ada 2 cabe keriting merah + 3 cabe keriting hijau (bisa salah satu)
1. Tambah 1 daun salam
1. Diperlukan 3 daun jeruk
1. Siapkan 1/2 sdt jahe bubuk
1. Tambah 1/4 sdt lengkuas bubuk
1. Diperlukan 1/4 sdt lada bubuk
1. Jangan lupa  Bahan saus &amp; perasa
1. Harap siapkan 2 sdm saus tiram
1. Tambah 2 sdm saus tomat
1. Tambah 5 sdm saus sambal
1. Diperlukan  Perasa -&gt; 1 sdt garam + 1 sdt kaldu + 1/2 sdt gula (sesuaikan)




<!--inarticleads2-->

##### Instruksi membuat  Kerang Hijau Saus Padang:

1. Rebus keras 5-7 menit tambahkan daun salam. Rebus jagung selama 15 menit atau hingga matang. Persiapkan bahan lainnya
1. Lelehkan butter masukan bumbu iris tunggu matang baru aneka saus
1. Beri 300ml air dan masukan jagung. Beri perasa dan tunggu airnya berkurang setengahnya. Masukan kerang aduk rata koreksi rasa. Masak cukup 3-5 menit supaya kerang tidak alot 😁
1. Plating ala ala wkwkwk




Demikianlah cara membuat kerang hijau saus padang yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
