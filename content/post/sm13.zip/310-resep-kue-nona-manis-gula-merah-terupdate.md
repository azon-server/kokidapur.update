---
description: "Resep : Kue Nona Manis Gula Merah terupdate"
title: "Resep : Kue Nona Manis Gula Merah terupdate"
slug: 310-resep-kue-nona-manis-gula-merah-terupdate
date: 2021-01-30T17:49:58.694Z
image: https://img-global.cpcdn.com/recipes/816f26759ce8fb48/680x482cq70/kue-nona-manis-gula-merah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/816f26759ce8fb48/680x482cq70/kue-nona-manis-gula-merah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/816f26759ce8fb48/680x482cq70/kue-nona-manis-gula-merah-foto-resep-utama.jpg
author: Sylvia Sutton
ratingvalue: 4.8
reviewcount: 49979
recipeingredient:
- " Bahan 1"
- "1 btr telur"
- "40 gr gula pasir"
- "240 ml santan kental"
- "130 gr tepung terigu"
- " Bahan 2"
- "120 mlsantan kental"
- "120 ml air"
- "100 gr gula merah irishancurkan"
- "30 gr maizena"
- "Sejumput garam"
- "1 lmbr daun pandan potong potong saya pake vanili"
- " Bahan 3"
- "240 ml santan kental"
- "1 sdm maizena"
- "1/4 sdt garam"
recipeinstructions:
- "Bahan 2:Masak gula merah,vanili,air sampai gula larut.matikan api,saring dan biarkan dingin.siapkan wadah.masukan tepung maizena,santan kental dan garam aduk hingga tidak bergerindil."
- "Masukan larutan gula.aduk rata.masak sampai meletup.matikan api.dinginkan sampai uapnya hilang.selanjutnya disebut adonan 2.siapkan wadah masukan telur dan gula sampai gula larut masukan terigu"
- "Masukan selang selingdengan santan.masukan adonan 2.mixer lagi kemudian saring."
- "Bahan 3 : campur semuanya aduk rata masak sampai meletup.matikan api.biarkan dingin.masukan plastik segitiga gunting ujungnya.oles cetakan kue talam dengan minyak kemudian tuang adonan gula 3/4 cetakan"
- "Semprotkan tengahnya dengan adonan 3.panaskan kukusan hingga beruap banyak.kukus selama 15menit.angkat.kemudian biarkan dingin baru lepas dari cetakan.sajika"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 248 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Dinner

---


![Kue Nona Manis Gula Merah](https://img-global.cpcdn.com/recipes/816f26759ce8fb48/680x482cq70/kue-nona-manis-gula-merah-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau empuk. Ciri kuliner Nusantara kue nona manis gula merah yang kaya dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga dapat diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Kue Nona Manis Gula Merah untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang bisa anda coba salah satunya kue nona manis gula merah yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep kue nona manis gula merah tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis Gula Merah yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis Gula Merah:

1. Tambah  Bahan 1:
1. Harus ada 1 btr telur
1. Harap siapkan 40 gr gula pasir
1. Dibutuhkan 240 ml santan kental
1. Dibutuhkan 130 gr tepung terigu
1. Harus ada  Bahan 2:
1. Harap siapkan 120 ml.santan kental
1. Harus ada 120 ml air
1. Diperlukan 100 gr gula merah iris/hancurkan
1. Tambah 30 gr maizena
1. Harus ada Sejumput garam
1. Siapkan 1 lmbr daun pandan potong potong (saya pake vanili)
1. Siapkan  Bahan 3:
1. Jangan lupa 240 ml santan kental
1. Dibutuhkan 1 sdm maizena
1. Diperlukan 1/4 sdt garam




<!--inarticleads2-->

##### Instruksi membuat  Kue Nona Manis Gula Merah:

1. Bahan 2:Masak gula merah,vanili,air sampai gula larut.matikan api,saring dan biarkan dingin.siapkan wadah.masukan tepung maizena,santan kental dan garam aduk hingga tidak bergerindil.
1. Masukan larutan gula.aduk rata.masak sampai meletup.matikan api.dinginkan sampai uapnya hilang.selanjutnya disebut adonan 2.siapkan wadah masukan telur dan gula sampai gula larut masukan terigu
1. Masukan selang selingdengan santan.masukan adonan 2.mixer lagi kemudian saring.
1. Bahan 3 : campur semuanya aduk rata masak sampai meletup.matikan api.biarkan dingin.masukan plastik segitiga gunting ujungnya.oles cetakan kue talam dengan minyak kemudian tuang adonan gula 3/4 cetakan
1. Semprotkan tengahnya dengan adonan 3.panaskan kukusan hingga beruap banyak.kukus selama 15menit.angkat.kemudian biarkan dingin baru lepas dari cetakan.sajika




Demikianlah cara membuat kue nona manis gula merah yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan teruji, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
