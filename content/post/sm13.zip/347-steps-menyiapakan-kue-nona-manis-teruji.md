---
description: "Steps menyiapakan Kue nona manis Teruji"
title: "Steps menyiapakan Kue nona manis Teruji"
slug: 347-steps-menyiapakan-kue-nona-manis-teruji
date: 2020-12-18T00:07:58.531Z
image: https://img-global.cpcdn.com/recipes/c9e1a13de0f551ed/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c9e1a13de0f551ed/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c9e1a13de0f551ed/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Ryan Rios
ratingvalue: 4.4
reviewcount: 9851
recipeingredient:
- " bahan 1"
- "500 ml santan kental"
- "3 sdm tepung terigu"
- "1 sdt garam"
- " Bahan 2 "
- "250 gr santan kental"
- "2 sdm gula pasir"
- "2,5 sdm tepung maizena"
- "1/2 sdt garam"
- "1 sdt pasta pandan"
- " Bahan 3 "
- "1 butir telor"
- "140 gr tepung terigu"
- "4 sdm gula pasir"
- "250 gr santan kental"
recipeinstructions:
- "Masak bahan 1 dg api kecil sampe beruap dan meletup matikan api aduk trs sampe tidak bergerindil dinginkan,,masukan botol kecap biar memudahkan memasukan keadonan"
- "Masak bahan 3 dengan api kecil aduk sampe kental dan meletup,dinginkan"
- "Kocok telor sama gula sampe larut trs masukan santan,terigu,adonan hijau no 2 sampe tercampur rata dan tidak bergerindil,,kalo perlu disaring"
- "Panaskan kukusan dg ditutup serbet pada tutupnya,,masukan adonan hijau 3/4 cetakan,lalu masukan adonan putih yg dibotol dg agak dimasukan ujung botolnya"
- "Kukus dg api sedang selama 10 menit"
- "Angkat dinginkan baru keluarkan dari cetakan"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 295 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Dinner

---


![Kue nona manis](https://img-global.cpcdn.com/recipes/c9e1a13de0f551ed/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita lestarikan karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti kue nona manis yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan keistimewahan yang merupakan keragaman Indonesia

Kedekatan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Kue nona manis untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang bisa anda praktekkan salah satunya kue nona manis yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue nona manis yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue nona manis:

1. Tambah  bahan 1:
1. Siapkan 500 ml santan kental
1. Dibutuhkan 3 sdm tepung terigu
1. Dibutuhkan 1 sdt garam
1. Jangan lupa  Bahan 2 :
1. Harus ada 250 gr santan kental
1. Jangan lupa 2 sdm gula pasir
1. Jangan lupa 2,5 sdm tepung maizena
1. Harus ada 1/2 sdt garam
1. Harap siapkan 1 sdt pasta pandan
1. Jangan lupa  Bahan 3 :
1. Diperlukan 1 butir telor
1. Diperlukan 140 gr tepung terigu
1. Harus ada 4 sdm gula pasir
1. Diperlukan 250 gr santan kental




<!--inarticleads2-->

##### Instruksi membuat  Kue nona manis:

1. Masak bahan 1 dg api kecil sampe beruap dan meletup matikan api aduk trs sampe tidak bergerindil dinginkan,,masukan botol kecap biar memudahkan memasukan keadonan
1. Masak bahan 3 dengan api kecil aduk sampe kental dan meletup,dinginkan
1. Kocok telor sama gula sampe larut trs masukan santan,terigu,adonan hijau no 2 sampe tercampur rata dan tidak bergerindil,,kalo perlu disaring
1. Panaskan kukusan dg ditutup serbet pada tutupnya,,masukan adonan hijau 3/4 cetakan,lalu masukan adonan putih yg dibotol dg agak dimasukan ujung botolnya
1. Kukus dg api sedang selama 10 menit
1. Angkat dinginkan baru keluarkan dari cetakan




Demikianlah cara membuat kue nona manis yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan terbukti, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
