---
description: "Cara singkat menyiapakan Sambel Kentang manis ala Nona Kentir teraktual"
title: "Cara singkat menyiapakan Sambel Kentang manis ala Nona Kentir teraktual"
slug: 410-cara-singkat-menyiapakan-sambel-kentang-manis-ala-nona-kentir-teraktual
date: 2020-11-20T04:32:57.925Z
image: https://img-global.cpcdn.com/recipes/86219d5d45de9ad3/680x482cq70/sambel-kentang-manis-ala-nona-kentir-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/86219d5d45de9ad3/680x482cq70/sambel-kentang-manis-ala-nona-kentir-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/86219d5d45de9ad3/680x482cq70/sambel-kentang-manis-ala-nona-kentir-foto-resep-utama.jpg
author: Catherine Griffith
ratingvalue: 4
reviewcount: 36566
recipeingredient:
- "12 butir telur puyuh"
- "1/2 kg kentang"
- "2 pasang ati dan ampela"
- "2 lembar daun salam"
- "1 lembar daun jeruk"
- "7 siung bawang merah"
- "5 siung bawang putih"
- "3 buah cabe merah"
- "2 butir kemiri"
- "1 cm jahe"
- "1 cm lengkuas digeprek"
- "1 batang serai digeprek diikat"
- "1/2 butir gula merah"
- "Secukupnya gula pasir garam dan air"
- "Sesuai selera kecap manis"
- "300 ml air"
recipeinstructions:
- "Bersihkan dan cuci ati ampela, rebus sampai matang, tiriskan lalu potong sesuai selera."
- "Rebus telur puyuh, kupas dari kulitnya, tiriskan."
- "Kupas kentang, cuci bersih, potong dadu, goreng sampai kecoklatan, tiriskan."
- "Haluskan: cabe merah (buang bijinya), bawang merah,bawang putih, kemiri, jahe dan garam."
- "Siapkan larutan gula merah dalam air 300ml. Panaskan minyak, tumis bumbu halus, masukkan lengkuas, serai, daun salam, dan daun jeruk hingga harum. Kemudian masukkan kentang, telur puyuh, dan ati ampela. Tambahkan air larutan gula merah. Aduk rata."
- "Cek rasa. (Mungkin tambah garam/gula pasir/kecap manis) tunggu sampai kuah mengering, angkat lalu sajikan. 😇"
categories:
- Recipe
tags:
- sambel
- kentang
- manis

katakunci: sambel kentang manis 
nutrition: 258 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Dessert

---


![Sambel Kentang manis ala Nona Kentir](https://img-global.cpcdn.com/recipes/86219d5d45de9ad3/680x482cq70/sambel-kentang-manis-ala-nona-kentir-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang harus kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti sambel kentang manis ala nona kentir yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Kita



Kedekatan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak Sambel Kentang manis ala Nona Kentir untuk keluarga. kebersamaan makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang dapat anda praktekkan salah satunya sambel kentang manis ala nona kentir yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep sambel kentang manis ala nona kentir tanpa harus bersusah payah.
Seperti resep Sambel Kentang manis ala Nona Kentir yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambel Kentang manis ala Nona Kentir:

1. Harus ada 12 butir telur puyuh
1. Jangan lupa 1/2 kg kentang
1. Diperlukan 2 pasang ati dan ampela
1. Tambah 2 lembar daun salam
1. Jangan lupa 1 lembar daun jeruk
1. Jangan lupa 7 siung bawang merah
1. Jangan lupa 5 siung bawang putih
1. Diperlukan 3 buah cabe merah
1. Siapkan 2 butir kemiri
1. Harus ada 1 cm jahe
1. Harap siapkan 1 cm lengkuas digeprek
1. Harap siapkan 1 batang serai digeprek, diikat
1. Siapkan 1/2 butir gula merah
1. Tambah Secukupnya gula pasir, garam dan air
1. Siapkan Sesuai selera kecap manis
1. Diperlukan 300 ml air




<!--inarticleads2-->

##### Instruksi membuat  Sambel Kentang manis ala Nona Kentir:

1. Bersihkan dan cuci ati ampela, rebus sampai matang, tiriskan lalu potong sesuai selera.
1. Rebus telur puyuh, kupas dari kulitnya, tiriskan.
1. Kupas kentang, cuci bersih, potong dadu, goreng sampai kecoklatan, tiriskan.
1. Haluskan: cabe merah (buang bijinya), bawang merah,bawang putih, kemiri, jahe dan garam.
1. Siapkan larutan gula merah dalam air 300ml. Panaskan minyak, tumis bumbu halus, masukkan lengkuas, serai, daun salam, dan daun jeruk hingga harum. Kemudian masukkan kentang, telur puyuh, dan ati ampela. Tambahkan air larutan gula merah. Aduk rata.
1. Cek rasa. (Mungkin tambah garam/gula pasir/kecap manis) tunggu sampai kuah mengering, angkat lalu sajikan. 😇




Demikianlah cara membuat sambel kentang manis ala nona kentir yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan cepat, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
