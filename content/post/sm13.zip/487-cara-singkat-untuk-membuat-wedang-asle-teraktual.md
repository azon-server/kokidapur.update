---
description: "Cara singkat untuk membuat Wedang Asle teraktual"
title: "Cara singkat untuk membuat Wedang Asle teraktual"
slug: 487-cara-singkat-untuk-membuat-wedang-asle-teraktual
date: 2021-02-02T04:41:28.219Z
image: https://img-global.cpcdn.com/recipes/8fd9f222fc72cec3/680x482cq70/wedang-asle-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8fd9f222fc72cec3/680x482cq70/wedang-asle-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8fd9f222fc72cec3/680x482cq70/wedang-asle-foto-resep-utama.jpg
author: Lucile Russell
ratingvalue: 4.1
reviewcount: 49376
recipeingredient:
- "4 lembar roti tawar"
- "4 sdm ketan"
- "500 ml santan"
- "1/2 bungkus agaragar"
- "500 ml air mineral"
- "1 lembar daun pandan"
- "200 gr gula pasir"
recipeinstructions:
- "Masak santan tambahkan garam dan daun pandan aduk perlahan dan masak hingga mendidih. Sisihkan"
- "Masak agar-agar dengan air mineral dan tambahkan 50 gr gula pasir. Tuang pada tempat dinginkan dan potong2."
- "Siapkan semua bahan yang telah jadi untuk wedang asle."
- "Siapkan mangkok, beri gula pasir dan tambahkan ketan. Lalu masukkan agar2."
- "Tambahkan santan yang telah mendidih. Kemudian beri potongan roti."
- "Wedang asle siap disantap."
categories:
- Recipe
tags:
- wedang
- asle

katakunci: wedang asle 
nutrition: 179 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Dessert

---


![Wedang Asle](https://img-global.cpcdn.com/recipes/8fd9f222fc72cec3/680x482cq70/wedang-asle-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti wedang asle yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia

Kedekatan keluarga bisa diperoleh dengan cara sederhana. Diantaranya adalah memasak Wedang Asle untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang dapat anda coba salah satunya wedang asle yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep wedang asle tanpa harus bersusah payah.
Seperti resep Wedang Asle yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 7 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Wedang Asle:

1. Jangan lupa 4 lembar roti tawar
1. Siapkan 4 sdm ketan
1. Jangan lupa 500 ml santan
1. Tambah 1/2 bungkus agar-agar
1. Tambah 500 ml air mineral
1. Siapkan 1 lembar daun pandan
1. Dibutuhkan 200 gr gula pasir




<!--inarticleads2-->

##### Instruksi membuat  Wedang Asle:

1. Masak santan tambahkan garam dan daun pandan aduk perlahan dan masak hingga mendidih. Sisihkan
1. Masak agar-agar dengan air mineral dan tambahkan 50 gr gula pasir. Tuang pada tempat dinginkan dan potong2.
1. Siapkan semua bahan yang telah jadi untuk wedang asle.
1. Siapkan mangkok, beri gula pasir dan tambahkan ketan. Lalu masukkan agar2.
1. Tambahkan santan yang telah mendidih. Kemudian beri potongan roti.
1. Wedang asle siap disantap.




Demikianlah cara membuat wedang asle yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan teruji, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
