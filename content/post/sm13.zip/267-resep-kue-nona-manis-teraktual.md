---
description: "Resep : Kue Nona Manis teraktual"
title: "Resep : Kue Nona Manis teraktual"
slug: 267-resep-kue-nona-manis-teraktual
date: 2020-09-15T08:04:35.900Z
image: https://img-global.cpcdn.com/recipes/ce3b8fb556e6665c/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ce3b8fb556e6665c/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ce3b8fb556e6665c/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Tom Kelly
ratingvalue: 4.7
reviewcount: 33544
recipeingredient:
- " Bahan 1 "
- "250 ml santan kental"
- "1 butir telur uk sedang"
- "140 gr gula pasir"
- "140 gr tepung terigu protein sedang"
- "1/2 sdt vanili"
- " Bahan 2 "
- "150 ml santan kental"
- "100 ml endapan pandan"
- " 15 lbr daun pandan  100 ml air diblender lalu saring"
- "1/4 sdt garam"
- "30 gr tepung beras"
- " Pewarna makanan hijaupasta pandan"
- " Bahan 3 "
- "500 ml santan kental me  2 bgks kara kecil  air"
- "30 gr tepung beras"
- "1 sdm gula pasir"
- "Sejumput garam"
recipeinstructions:
- "Mixer telur, gula dan vanili sampai gula larut, gunakan speed sedang. Masukkan tepung terigu lalu santan. Mixer sampai semua tercampur rata. Sisihkan."
- "Campur semua bahan 2 dalam panci, aduk rata dulu. Kalo sudah tercampur rata baru nyalakan api dan masak sambil diaduk terus hingga kental dan meletup letup. Gunakan api kecil saja. Oya kalo warnanya kurang boleh tambahkan pewarna hijau atau pasta pandan ya. Angkat lalu dinginkan sebentar."
- "Campur adonan 2 ke adonan 1 lalu mixer hingga adonan tercampur rata."
- "Campur jadi satu bahan 3 lalu aduk rata. Kemudian masak dengan api kecil hingga kental dan meletup letup sambil diaduk terus. Angkat dan dinginkan."
- "Masukkan adonan 3 (adonan putih) ke dalam piping bag atau botol saos/kecap yg ujungnya lancip/panjang. Adonan pandan masukkan kedalam gelas ukur agar gampang dituang ke cetakan nanti."
- "Tuang adonan pandan ke dalam cetakan hingga ¾ cetakan banyaknya. Cetakan sudah diolesi minyak. Lalu masukkan adonan putih ke tengah adonan pandan dengan sedikit ditekan agar adonan masuk kedalam."
- "Kukus selama 10 menit dalam kukusan yg sudah di panasi terlebih dahulu. Jangan kelamaan waktu kukusnya nanti tampilan kue jadi ga bagus."
- "Note : untuk santan bahan 1 dan 2 saya gunakan santan kara segitiga sebanyak 2 buah + air lalu di bagi sesuai kebutuhannya yaitu 250 ml dan 150 ml. Jd 2 santan kara segitiga + air hingga mencapai 400 ml."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 232 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dinner

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/ce3b8fb556e6665c/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau renyah. Ciri khas kuliner Nusantara kue nona manis yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Kue Nona Manis untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang dapat anda contoh salah satunya kue nona manis yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis:

1. Jangan lupa  Bahan 1 :
1. Siapkan 250 ml santan kental
1. Siapkan 1 butir telur uk sedang
1. Dibutuhkan 140 gr gula pasir
1. Harus ada 140 gr tepung terigu protein sedang
1. Tambah 1/2 sdt vanili
1. Tambah  Bahan 2 :
1. Tambah 150 ml santan kental
1. Siapkan 100 ml endapan pandan
1. Diperlukan  (15 lbr daun pandan + 100 ml air diblender lalu saring)
1. Dibutuhkan 1/4 sdt garam
1. Harus ada 30 gr tepung beras
1. Dibutuhkan  Pewarna makanan hijau/pasta pandan
1. Tambah  Bahan 3 :
1. Siapkan 500 ml santan kental (me : 2 bgks kara kecil + air)
1. Siapkan 30 gr tepung beras
1. Diperlukan 1 sdm gula pasir
1. Diperlukan Sejumput garam




<!--inarticleads2-->

##### Langkah membuat  Kue Nona Manis:

1. Mixer telur, gula dan vanili sampai gula larut, gunakan speed sedang. Masukkan tepung terigu lalu santan. Mixer sampai semua tercampur rata. Sisihkan.
1. Campur semua bahan 2 dalam panci, aduk rata dulu. Kalo sudah tercampur rata baru nyalakan api dan masak sambil diaduk terus hingga kental dan meletup letup. Gunakan api kecil saja. Oya kalo warnanya kurang boleh tambahkan pewarna hijau atau pasta pandan ya. Angkat lalu dinginkan sebentar.
1. Campur adonan 2 ke adonan 1 lalu mixer hingga adonan tercampur rata.
1. Campur jadi satu bahan 3 lalu aduk rata. Kemudian masak dengan api kecil hingga kental dan meletup letup sambil diaduk terus. Angkat dan dinginkan.
1. Masukkan adonan 3 (adonan putih) ke dalam piping bag atau botol saos/kecap yg ujungnya lancip/panjang. Adonan pandan masukkan kedalam gelas ukur agar gampang dituang ke cetakan nanti.
1. Tuang adonan pandan ke dalam cetakan hingga ¾ cetakan banyaknya. Cetakan sudah diolesi minyak. Lalu masukkan adonan putih ke tengah adonan pandan dengan sedikit ditekan agar adonan masuk kedalam.
1. Kukus selama 10 menit dalam kukusan yg sudah di panasi terlebih dahulu. Jangan kelamaan waktu kukusnya nanti tampilan kue jadi ga bagus.
1. Note : untuk santan bahan 1 dan 2 saya gunakan santan kara segitiga sebanyak 2 buah + air lalu di bagi sesuai kebutuhannya yaitu 250 ml dan 150 ml. Jd 2 santan kara segitiga + air hingga mencapai 400 ml.




Demikianlah cara membuat kue nona manis yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan terbukti, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
