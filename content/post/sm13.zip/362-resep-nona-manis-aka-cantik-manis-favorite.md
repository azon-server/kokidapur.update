---
description: "Resep : Nona manis a.k.a Cantik manis Favorite"
title: "Resep : Nona manis a.k.a Cantik manis Favorite"
slug: 362-resep-nona-manis-aka-cantik-manis-favorite
date: 2021-01-05T21:26:33.770Z
image: https://img-global.cpcdn.com/recipes/6901c4ef3b149c86/680x482cq70/nona-manis-aka-cantik-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6901c4ef3b149c86/680x482cq70/nona-manis-aka-cantik-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6901c4ef3b149c86/680x482cq70/nona-manis-aka-cantik-manis-foto-resep-utama.jpg
author: Miguel Wilkerson
ratingvalue: 4.7
reviewcount: 47685
recipeingredient:
- " Bahan a "
- "250 ml santan kental"
- "2 sdm tepung terigu"
- "1 sdm gula pasir"
- "1/2 sdt garam"
- " Bahan b "
- "250 ml santan kental"
- "125 gr gula pasir"
- "125 gr tepung terigu"
- "1 btr telur"
- " Bahan c "
- "250 ml santan kental"
- "30 gr maizena"
- "60 gr gula pasir"
- "Secubit garam halus"
- "Secukupnya pasta pandan"
recipeinstructions:
- "Bahan a : masukkan santan kental, tepung terigu dan garam dalan panci. Aduk terlebih dahulu agar tidak ada gumpalan, setelah tdk ada gumpalan masak dengan api sedang sambil d aduk hingga mendidih kemudian matikan kompor dan sisihkan."
- "Bahan b : masukkan tepung terigu, gula dan santan kental aduk menggunakan whisker hingga halus kemudian masukkan 1 butir telur dan aduk lagi hingga rata. Sisihkan."
- "Bahan c : masukkan santan kental, maizena, gula, secubit garam halus dan secukupnya pasta pandan ke dalam panci. Aduk rata dan masak dengan api sedang sambil terus d aduk hingga mendidih."
- "Bahan b dan bahan c di gabungkan kemudian di aduk rata = bahan d. Sisihkan."
- "Siapkan cetakan kue dan olesi minyak. Panaskan kukusan dan tutup kukusan d alasi kain serbet agar air tidak turun ke kue."
- "Pertama masukka bahan d ke dalam cetakan kue kemudian di tambah dengan 1 sendok teh bahan a di tengahnya. Lakukab sampai adonan bahan d dan bahan a habis."
- "Masukkan ke dalam kukusan dan masak kurleb 15 menit."
- "Angkat dan sajikan."
- "Selamat mencoba !!!"
categories:
- Recipe
tags:
- nona
- manis
- aka

katakunci: nona manis aka 
nutrition: 217 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dinner

---


![Nona manis a.k.a Cantik manis](https://img-global.cpcdn.com/recipes/6901c4ef3b149c86/680x482cq70/nona-manis-aka-cantik-manis-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti nona manis a.k.a cantik manis yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia

Telolet Garuda mas a.k.a mahessa &#34;nona manis&#34;. Kue Cantik Manis Kue Tradisional Cantik Manis Sagu Mutiara. Putu Mayang Jajanan Pasar Yang Kenyal Manis Seger A. Rindu (Debi Sagita) yang kerja jadi badut suka sama Deni di FTV Nona Manis Si Badut Cantik, masalahnya Deni takut sama badut!

Kehangatan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah membuat makanan Nona manis a.k.a Cantik manis untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang dapat anda buat salah satunya nona manis a.k.a cantik manis yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep nona manis a.k.a cantik manis tanpa harus bersusah payah.
Berikut ini resep Nona manis a.k.a Cantik manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona manis a.k.a Cantik manis:

1. Harus ada  Bahan a :
1. Jangan lupa 250 ml santan kental
1. Harap siapkan 2 sdm tepung terigu
1. Dibutuhkan 1 sdm gula pasir
1. Harap siapkan 1/2 sdt garam
1. Diperlukan  Bahan b :
1. Dibutuhkan 250 ml santan kental
1. Harus ada 125 gr gula pasir
1. Diperlukan 125 gr tepung terigu
1. Dibutuhkan 1 btr telur
1. Harus ada  Bahan c :
1. Dibutuhkan 250 ml santan kental
1. Diperlukan 30 gr maizena
1. Harus ada 60 gr gula pasir
1. Dibutuhkan Secubit garam halus
1. Jangan lupa Secukupnya pasta pandan


Assalamualaikum jumpa lagi yc di Channel Resep Bunda Tika kali ini saya akan berbagi Resep Kue Nona Manis Super Lembut. &#34;&#39;Nona Manis&#39; (Sweet Girl) is a traditional folk song from the Maluku Province. It is also very popular throughout Indonesia. Nona manis siapa yang punya Nona manis siapa yang punya Nona manis siapa yang punya Rasa sayang sayange. Masak #SamaSaya #DiRumahAja #MasakSamaSaya Cara membuat kue Nona Manis Mudah banget Assalamu alaikum Kali ini. 

<!--inarticleads2-->

##### Instruksi membuat  Nona manis a.k.a Cantik manis:

1. Bahan a : masukkan santan kental, tepung terigu dan garam dalan panci. Aduk terlebih dahulu agar tidak ada gumpalan, setelah tdk ada gumpalan masak dengan api sedang sambil d aduk hingga mendidih kemudian matikan kompor dan sisihkan.
1. Bahan b : masukkan tepung terigu, gula dan santan kental aduk menggunakan whisker hingga halus kemudian masukkan 1 butir telur dan aduk lagi hingga rata. Sisihkan.
1. Bahan c : masukkan santan kental, maizena, gula, secubit garam halus dan secukupnya pasta pandan ke dalam panci. Aduk rata dan masak dengan api sedang sambil terus d aduk hingga mendidih.
1. Bahan b dan bahan c di gabungkan kemudian di aduk rata = bahan d. Sisihkan.
1. Siapkan cetakan kue dan olesi minyak. Panaskan kukusan dan tutup kukusan d alasi kain serbet agar air tidak turun ke kue.
1. Pertama masukka bahan d ke dalam cetakan kue kemudian di tambah dengan 1 sendok teh bahan a di tengahnya. Lakukab sampai adonan bahan d dan bahan a habis.
1. Masukkan ke dalam kukusan dan masak kurleb 15 menit.
1. Angkat dan sajikan.
1. Selamat mencoba !!!


Nona manis siapa yang punya Nona manis siapa yang punya Nona manis siapa yang punya Rasa sayang sayange. Masak #SamaSaya #DiRumahAja #MasakSamaSaya Cara membuat kue Nona Manis Mudah banget Assalamu alaikum Kali ini. Lihat Istri Temannya Cantik, Lelaki Ini Tega Main Belakang, Lihat Apa Yang Terjadi. Lihat juga resep Cantik Manis (Hunkwe Mutiara) enak lainnya. Lihat ide lainnya tentang kecantikan, wanita, gadis ulzzang. 

Demikianlah cara membuat nona manis a.k.a cantik manis yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan teruji, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
