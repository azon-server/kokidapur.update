---
description: "Cara menyiapakan Nona Manis Cepat"
title: "Cara menyiapakan Nona Manis Cepat"
slug: 398-cara-menyiapakan-nona-manis-cepat
date: 2020-11-19T23:28:35.815Z
image: https://img-global.cpcdn.com/recipes/19bb1e3b1c15ec89/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/19bb1e3b1c15ec89/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/19bb1e3b1c15ec89/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Herbert Francis
ratingvalue: 4.9
reviewcount: 39855
recipeingredient:
- " Bahan A "
- "20 lbr daun pandan"
- "100 ml air"
- "200 ml santan"
- "30 gr maizena"
- "40 gr gula pasir"
- "Sejumput garam"
- " Bahan B "
- "250 ml santan kental"
- "1 butir telur"
- "80 gr gula pasir"
- "140 gr tp Terigu"
- " Bahan C "
- "500 ml santan kental"
- "100 gr tp Terigu"
- "Sejumput garam"
recipeinstructions:
- "Bahan A : campur daun pandan dan air, blender lalu saring. Campur jus pandan + santan + maizena + gula +garam. Aduk rata. Masak sampai kental. Sisihkan"
- "Bahan B : mixer gula + telur sampai kental. Masukkan santan. Aduk rata. Masukkan tepung. Aduk rata"
- "Campur bahan A dan B. Aduj rata. Sisihkan"
- "Campur semua bahan C. Masak diatas api sampai kental. Usahakan tidak ada yang bergerindil. Dinginkan. Masukkan dalam botol kecap plastik. (agar mudah disemprot)"
- "Siapkan cetakam kue talam.oles minyak. Tuang adonan hijau 3/4 lalu semprot adonan putih ditengah sambil ditekan kedalam. Isi sampai cetakan penuh."
- "Kukus dalam kukusan yg sudah dipanaskan terlebih dahulu. Selama 10 menit. Jangan lupa tutupnya dialasi serbet."
- "Angkat kue, biarkan dingin dalam cetakan, baru dilepas."
- "Nb : mohon maaf yaa foti step by step sebenarnya ada. Pas mau di post udah pada ilang di galery.. Mudah2an mengerti yaa.."
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 153 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Dinner

---


![Nona Manis](https://img-global.cpcdn.com/recipes/19bb1e3b1c15ec89/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan renyah. Karasteristik kuliner Nusantara nona manis yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Nona Manis untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang dapat anda contoh salah satunya nona manis yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan gampang menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona Manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona Manis:

1. Siapkan  Bahan A :
1. Harus ada 20 lbr daun pandan
1. Harap siapkan 100 ml air
1. Harus ada 200 ml santan
1. Jangan lupa 30 gr maizena
1. Jangan lupa 40 gr gula pasir
1. Diperlukan Sejumput garam
1. Dibutuhkan  Bahan B :
1. Harus ada 250 ml santan kental
1. Harus ada 1 butir telur
1. Tambah 80 gr gula pasir
1. Jangan lupa 140 gr tp. Terigu
1. Dibutuhkan  Bahan C :
1. Diperlukan 500 ml santan kental
1. Tambah 100 gr tp. Terigu
1. Harus ada Sejumput garam




<!--inarticleads2-->

##### Cara membuat  Nona Manis:

1. Bahan A : campur daun pandan dan air, blender lalu saring. Campur jus pandan + santan + maizena + gula +garam. Aduk rata. Masak sampai kental. Sisihkan
1. Bahan B : mixer gula + telur sampai kental. Masukkan santan. Aduk rata. Masukkan tepung. Aduk rata
1. Campur bahan A dan B. Aduj rata. Sisihkan
1. Campur semua bahan C. Masak diatas api sampai kental. Usahakan tidak ada yang bergerindil. Dinginkan. Masukkan dalam botol kecap plastik. (agar mudah disemprot)
1. Siapkan cetakam kue talam.oles minyak. Tuang adonan hijau 3/4 lalu semprot adonan putih ditengah sambil ditekan kedalam. Isi sampai cetakan penuh.
1. Kukus dalam kukusan yg sudah dipanaskan terlebih dahulu. Selama 10 menit. Jangan lupa tutupnya dialasi serbet.
1. Angkat kue, biarkan dingin dalam cetakan, baru dilepas.
1. Nb : mohon maaf yaa foti step by step sebenarnya ada. Pas mau di post udah pada ilang di galery.. Mudah2an mengerti yaa..




Demikianlah cara membuat nona manis yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
