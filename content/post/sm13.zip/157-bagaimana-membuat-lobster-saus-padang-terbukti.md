---
description: "Bagaimana membuat Lobster Saus Padang Terbukti"
title: "Bagaimana membuat Lobster Saus Padang Terbukti"
slug: 157-bagaimana-membuat-lobster-saus-padang-terbukti
date: 2021-01-31T19:19:28.674Z
image: https://img-global.cpcdn.com/recipes/146839db06caea7d/680x482cq70/lobster-saus-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/146839db06caea7d/680x482cq70/lobster-saus-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/146839db06caea7d/680x482cq70/lobster-saus-padang-foto-resep-utama.jpg
author: Mario Boone
ratingvalue: 4.2
reviewcount: 16902
recipeingredient:
- "1/2 kg lobster isi 4 ekor"
- "200 ml air"
- " Minyak goreng"
- " Bumbu "
- "1 butir bawang bombay"
- "2 lembar daun salam"
- "2 sct saos tiram"
- "2 sdm saos sambal"
- "Secukupnya garam gula pasir dan kaldu ayampenyedap rasa"
- " Bumbu halus "
- "12 siung bawang merah"
- "8 siung bawang putih"
- "2 ruas jahe"
- "2 ruas kunyit"
- "4 butir kemiri"
- "20 buah cabai keriting merah"
- "10 buah cabai rawit merah"
recipeinstructions:
- "Cuci bersih lobster, belah kepala buang isi kepalanya."
- "Rebus/kukus lobster 10 menit, lalu tiriskan."
- "Siapkan bumbu."
- "Tumis bawang bombay dan daun bawang hingga harum."
- "Masukkan bumbu halus, daun salam dan daun jeruk sambil diaduk-aduk."
- "Masukkan air, garam, gula, kaldu, saos tiram dan saos sambal. Tunggu hingga mendidih. Koreksi rasa."
- "Masukkan lobster, aduk-aduk hingga bumbu dan lobster tercampur rata. Tunggu air sedikit menyusut, angkat dan sajikan."
categories:
- Recipe
tags:
- lobster
- saus
- padang

katakunci: lobster saus padang 
nutrition: 129 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Lunch

---


![Lobster Saus Padang](https://img-global.cpcdn.com/recipes/146839db06caea7d/680x482cq70/lobster-saus-padang-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas dan empuk. Ciri khas masakan Indonesia lobster saus padang yang penuh dengan rempah-rempah memberikan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kedekatan rumah tangga dapat didapat dengan cara sederhana. Diantaranya adalah membuat makanan Lobster Saus Padang untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang bisa anda contoh salah satunya lobster saus padang yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep lobster saus padang tanpa harus bersusah payah.
Berikut ini resep Lobster Saus Padang yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Lobster Saus Padang:

1. Harus ada 1/2 kg lobster (isi 4 ekor)
1. Harap siapkan 200 ml air
1. Diperlukan  Minyak goreng
1. Jangan lupa  Bumbu :
1. Siapkan 1 butir bawang bombay
1. Dibutuhkan 2 lembar daun salam
1. Diperlukan 2 sct saos tiram
1. Diperlukan 2 sdm saos sambal
1. Diperlukan Secukupnya garam, gula pasir dan kaldu ayam/penyedap rasa
1. Diperlukan  Bumbu halus :
1. Harap siapkan 12 siung bawang merah
1. Dibutuhkan 8 siung bawang putih
1. Harap siapkan 2 ruas jahe
1. Dibutuhkan 2 ruas kunyit
1. Diperlukan 4 butir kemiri
1. Harap siapkan 20 buah cabai keriting merah
1. Jangan lupa 10 buah cabai rawit merah




<!--inarticleads2-->

##### Langkah membuat  Lobster Saus Padang:

1. Cuci bersih lobster, belah kepala buang isi kepalanya.
1. Rebus/kukus lobster 10 menit, lalu tiriskan.
1. Siapkan bumbu.
1. Tumis bawang bombay dan daun bawang hingga harum.
1. Masukkan bumbu halus, daun salam dan daun jeruk sambil diaduk-aduk.
1. Masukkan air, garam, gula, kaldu, saos tiram dan saos sambal. Tunggu hingga mendidih. Koreksi rasa.
1. Masukkan lobster, aduk-aduk hingga bumbu dan lobster tercampur rata. Tunggu air sedikit menyusut, angkat dan sajikan.




Demikianlah cara membuat lobster saus padang yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
