---
description: "Steps untuk membuat Kue Nona Manis Sempurna"
title: "Steps untuk membuat Kue Nona Manis Sempurna"
slug: 246-steps-untuk-membuat-kue-nona-manis-sempurna
date: 2021-01-25T09:22:20.080Z
image: https://img-global.cpcdn.com/recipes/a2760b9302a43e99/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a2760b9302a43e99/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a2760b9302a43e99/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Tommy Hansen
ratingvalue: 4.1
reviewcount: 11807
recipeingredient:
- " Bahan A"
- "1 butir telur"
- "100 gram gula pasir"
- "250 ml santan"
- "145 gram tepung terigu"
- " Bahan B"
- "250 ml santan"
- "55 gram gula pasir"
- "30 gram tepung maizena"
- "1/2 sdt pasta pandan"
- "1/4 sdt garam"
- " Bahan C"
- "250 ml santan"
- "1 sdm tepung terigu"
- "1 sdm gula pasir"
- "1/2 sdt garam"
recipeinstructions:
- "Siapkan semua bahan. Panaskan kukusan, tutup dilapisi dengan kain bersih."
- "Masak bahan C hingga meletup-letup menggunakan api sedang, lalu sisihkan dan biarkan hingga dingin. Masukkan ke dalam wadah botol atau ke dalam pipping bag."
- "Masak bahan B hingga meletup-letup, sisihkan."
- "Lanjut ke bahan A, mixer telur dan gula hingga mengembang."
- "Campurkan tepung dan santan."
- "Lalu tuang ke dalam adonan telur+gula, mixer sebentar saja sampai rata."
- "Masukkan adonan B (adonan hijau), lalu mixer lagi sebentar saja hingga cukup rata."
- "Ini cara masukin ke cup nya nanti boleh pakai sendok ataupun pakai pipping bag ya. Aku pakai pipping bag."
- "Siapkan cetakan lalu oles tipis dengan minyak. Tuang adonan hijau hingga 3/4 bagian. Lalu tuang adonan putih dibagian tengahnya, secukupnya saja."
- "Kukus hingga matang kira-kira 10 menit. Bila sudah matang segera keluarkan dari cetakan. Sajikan bersama teh hangat🥰😍😘❣️"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 225 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Dessert

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/a2760b9302a43e99/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan gurih. Ciri kuliner Indonesia kue nona manis yang kaya dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah memasak Kue Nona Manis untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang bisa anda coba salah satunya kue nona manis yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 16 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Jangan lupa  Bahan A:
1. Harus ada 1 butir telur
1. Harus ada 100 gram gula pasir
1. Diperlukan 250 ml santan
1. Diperlukan 145 gram tepung terigu
1. Tambah  Bahan B:
1. Harap siapkan 250 ml santan
1. Harus ada 55 gram gula pasir
1. Tambah 30 gram tepung maizena
1. Harus ada 1/2 sdt pasta pandan
1. Harus ada 1/4 sdt garam
1. Jangan lupa  Bahan C:
1. Diperlukan 250 ml santan
1. Diperlukan 1 sdm tepung terigu
1. Diperlukan 1 sdm gula pasir
1. Harap siapkan 1/2 sdt garam




<!--inarticleads2-->

##### Langkah membuat  Kue Nona Manis:

1. Siapkan semua bahan. Panaskan kukusan, tutup dilapisi dengan kain bersih.
1. Masak bahan C hingga meletup-letup menggunakan api sedang, lalu sisihkan dan biarkan hingga dingin. Masukkan ke dalam wadah botol atau ke dalam pipping bag.
1. Masak bahan B hingga meletup-letup, sisihkan.
1. Lanjut ke bahan A, mixer telur dan gula hingga mengembang.
1. Campurkan tepung dan santan.
1. Lalu tuang ke dalam adonan telur+gula, mixer sebentar saja sampai rata.
1. Masukkan adonan B (adonan hijau), lalu mixer lagi sebentar saja hingga cukup rata.
1. Ini cara masukin ke cup nya nanti boleh pakai sendok ataupun pakai pipping bag ya. Aku pakai pipping bag.
1. Siapkan cetakan lalu oles tipis dengan minyak. Tuang adonan hijau hingga 3/4 bagian. Lalu tuang adonan putih dibagian tengahnya, secukupnya saja.
1. Kukus hingga matang kira-kira 10 menit. Bila sudah matang segera keluarkan dari cetakan. Sajikan bersama teh hangat🥰😍😘❣️




Demikianlah cara membuat kue nona manis yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
