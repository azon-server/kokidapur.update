---
description: "Resep : Seafood Asap Bumbu Padang Cepat"
title: "Resep : Seafood Asap Bumbu Padang Cepat"
slug: 57-resep-seafood-asap-bumbu-padang-cepat
date: 2021-01-05T03:23:34.177Z
image: https://img-global.cpcdn.com/recipes/76fe3974cf5ecd0e/680x482cq70/seafood-asap-bumbu-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/76fe3974cf5ecd0e/680x482cq70/seafood-asap-bumbu-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/76fe3974cf5ecd0e/680x482cq70/seafood-asap-bumbu-padang-foto-resep-utama.jpg
author: Helen Valdez
ratingvalue: 4
reviewcount: 43418
recipeingredient:
- "2 ekor Kepiting"
- "10 ekor Udang"
- "2 Jagung pot bagi 3 direbus stgh matang dulu"
- "1 telor ayam"
- "3 lembar Daun salam"
- "5 lembar daun jeruk"
- "3 batang sereh"
- "2 ruas jari laja geprek"
- "2 batang daun bawang ambil putihnya aj potong panjang2"
- " Bumbu halus"
- "1/2 Bawang bombay besar"
- "10 siung Bawang merah besar"
- "5 siung Bawang putih"
- "6 butir Kemiri"
- "7 cabe Tanjung"
- "secukupnya Rawit"
- "1 sdm Kunyit halus"
- "2 ruas jari Jahe"
- " Bahan saos"
- "2 sdm saos tiram"
- "2 sdm saos tomat"
- "sesuai selera Saos sambel"
- " Garamgulatotolelada hitam secukupnya"
recipeinstructions:
- "Bersihkan kepiting sampai bnr2 bersih,lalu siapkan air bersih masukan jahe 1 jari digeprek,sereh 2 batang geprek,3 lembar daun salam,nyalakan api tunggu hingga ngegolak,masukkan kepitingnya (hanya sebentar 5 menit angkat)biar gk bau amis..bumbu halus di blander.."
- "Lalu tumis bumbu halus...masukkan laja,daun salam,sereh,daun jeruk,kecuali daun bawang.masukkan bahan saosnya... Tumis hingga matang..lalu beri bumbu dapur..secukupnya"
- "Setelah matang masukkan kepiting,udang n jagung...aduk hingga bumbu meresap..test rasa ya...simpan kepiting yang sudah dimasak di atas daun pisang yang dialasin alumunium foil.lalu panggang ±20 menit 180°c.."
- "Hidangkan selagi panas dengan nasi hangat...mantabbb...wanginya daun pisang bikin auto nambah trs makannya..selamat mencoba"
categories:
- Recipe
tags:
- seafood
- asap
- bumbu

katakunci: seafood asap bumbu 
nutrition: 146 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Lunch

---


![Seafood Asap Bumbu Padang](https://img-global.cpcdn.com/recipes/76fe3974cf5ecd0e/680x482cq70/seafood-asap-bumbu-padang-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti seafood asap bumbu padang yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan keistimewahan yang merupakan keragaman Nusantara



Kedekatan keluarga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Seafood Asap Bumbu Padang untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang dapat anda contoh salah satunya seafood asap bumbu padang yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep seafood asap bumbu padang tanpa harus bersusah payah.
Seperti resep Seafood Asap Bumbu Padang yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 23 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Seafood Asap Bumbu Padang:

1. Diperlukan 2 ekor Kepiting
1. Jangan lupa 10 ekor Udang
1. Dibutuhkan 2 Jagung (pot bagi 3) direbus stgh matang dulu
1. Harap siapkan 1 telor ayam
1. Harus ada 3 lembar Daun salam
1. Diperlukan 5 lembar daun jeruk
1. Dibutuhkan 3 batang sereh
1. Dibutuhkan 2 ruas jari laja geprek
1. Siapkan 2 batang daun bawang ambil putihnya aj potong panjang2
1. Tambah  Bumbu halus:
1. Dibutuhkan 1/2 Bawang bombay besar
1. Harap siapkan 10 siung Bawang merah besar
1. Dibutuhkan 5 siung Bawang putih
1. Siapkan 6 butir Kemiri
1. Jangan lupa 7 cabe Tanjung
1. Harap siapkan secukupnya Rawit
1. Jangan lupa 1 sdm Kunyit halus
1. Harap siapkan 2 ruas jari Jahe
1. Tambah  Bahan saos:
1. Jangan lupa 2 sdm saos tiram
1. Dibutuhkan 2 sdm saos tomat
1. Tambah sesuai selera Saos sambel
1. Tambah  Garam,gula,totole,lada hitam (secukupnya)




<!--inarticleads2-->

##### Langkah membuat  Seafood Asap Bumbu Padang:

1. Bersihkan kepiting sampai bnr2 bersih,lalu siapkan air bersih masukan jahe 1 jari digeprek,sereh 2 batang geprek,3 lembar daun salam,nyalakan api tunggu hingga ngegolak,masukkan kepitingnya (hanya sebentar 5 menit angkat)biar gk bau amis..bumbu halus di blander..
1. Lalu tumis bumbu halus...masukkan laja,daun salam,sereh,daun jeruk,kecuali daun bawang.masukkan bahan saosnya... - Tumis hingga matang..lalu beri bumbu dapur..secukupnya
1. Setelah matang masukkan kepiting,udang n jagung...aduk hingga bumbu meresap..test rasa ya...simpan kepiting yang sudah dimasak di atas daun pisang yang dialasin alumunium foil.lalu panggang ±20 menit 180°c..
1. Hidangkan selagi panas dengan nasi hangat...mantabbb...wanginya daun pisang bikin auto nambah trs makannya..selamat mencoba




Demikianlah cara membuat seafood asap bumbu padang yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
