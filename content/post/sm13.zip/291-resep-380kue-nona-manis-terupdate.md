---
description: "Resep : 380.Kue Nona Manis terupdate"
title: "Resep : 380.Kue Nona Manis terupdate"
slug: 291-resep-380kue-nona-manis-terupdate
date: 2020-12-22T19:47:34.376Z
image: https://img-global.cpcdn.com/recipes/d450c0f8fe362602/680x482cq70/380kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d450c0f8fe362602/680x482cq70/380kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d450c0f8fe362602/680x482cq70/380kue-nona-manis-foto-resep-utama.jpg
author: Virgie Carter
ratingvalue: 4.6
reviewcount: 37498
recipeingredient:
- " Bahan A"
- "1 butir telurkocok lepas"
- "125 gram tepung terigu"
- "125 gram gula pasir"
- "250 ml santan"
- " Bahan B"
- "125 ml santan"
- "125 ml jus pandan dr 810 lbr pandan  air blender  saring"
- "60 gram gula pasir halus"
- "30 gram tepung maizena"
- "1/2 sdt garam"
- "2 tetes pewarna hijau"
- " Bahan C"
- "125 ml santal kental"
- "1 sdm gula pasir"
- "1 sdm munjung tepung"
- "1/4 sdt garam"
recipeinstructions:
- "Bahan A : Campur tepung terigu + gula halus. Tuang santan, aduk hingga tercampur rata (boleh pke whisker atau pun garpu). Tuang telur kocok, aduk rata."
- "Lalu saring biar hasil nya halus. Sisihkan."
- "Bahan B : Aduk semua bahan B jd satu."
- "Masak bahan B dg api kecil sambil di aduk hingga meletup.. Matikan api, angkat dan aduk². Masukkan bahan A."
- "Aduk hingga tercampur dg rata. Sisihkan."
- "Bahan C : aduk semua bahan C hingga tercampur rata. Lalu masak dg api kecil sambil di aduk hingga meletup². Angkat dan aduk². Selagi hangat masukkan ke dlm plastik segitiga (klo mau rapi hasil nya, masukkan ke dlm botol kecap/saus)"
- "Panaskan kukusan hingga beruap banyak. Siapkan cetakan kue mangkok. Oles tipis dg minyak goreng. Tuang adonan hijau sampai 2/3 tinggi cetakan. Lalu semprotkan adonan putih tepat di tengah² nya"
- "Setelah kukusan panas. Kukus kue hingga matang ±10-15 menit. (tutup kukusan di alasi serbet).. Keluarkan kue dr kukusan, biarkan hingga agak dingin baru keluarkan dr cetakan."
- "Sajikan."
categories:
- Recipe
tags:
- 380kue
- nona
- manis

katakunci: 380kue nona manis 
nutrition: 128 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dessert

---


![380.Kue Nona Manis](https://img-global.cpcdn.com/recipes/d450c0f8fe362602/680x482cq70/380kue-nona-manis-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang patut kita jaga karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti 380.kue nona manis yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa keistimewahan yang merupakan keragaman Indonesia

Keharmonisan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah membuat makanan 380.Kue Nona Manis untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda coba salah satunya 380.kue nona manis yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep 380.kue nona manis tanpa harus bersusah payah.
Berikut ini resep 380.Kue Nona Manis yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat 380.Kue Nona Manis:

1. Diperlukan  Bahan A
1. Dibutuhkan 1 butir telur,kocok lepas
1. Siapkan 125 gram tepung terigu
1. Jangan lupa 125 gram gula pasir
1. Harus ada 250 ml santan
1. Dibutuhkan  Bahan B
1. Harus ada 125 ml santan
1. Harap siapkan 125 ml jus pandan (dr 8-10 lbr pandan + air, blender &amp; saring)
1. Siapkan 60 gram gula pasir halus
1. Siapkan 30 gram tepung maizena
1. Harus ada 1/2 sdt garam
1. Jangan lupa 2 tetes pewarna hijau
1. Diperlukan  Bahan C
1. Siapkan 125 ml santal kental
1. Harus ada 1 sdm gula pasir
1. Jangan lupa 1 sdm munjung tepung
1. Siapkan 1/4 sdt garam




<!--inarticleads2-->

##### Cara membuat  380.Kue Nona Manis:

1. Bahan A : Campur tepung terigu + gula halus. Tuang santan, aduk hingga tercampur rata (boleh pke whisker atau pun garpu). Tuang telur kocok, aduk rata.
1. Lalu saring biar hasil nya halus. Sisihkan.
1. Bahan B : Aduk semua bahan B jd satu.
1. Masak bahan B dg api kecil sambil di aduk hingga meletup.. Matikan api, angkat dan aduk². Masukkan bahan A.
1. Aduk hingga tercampur dg rata. Sisihkan.
1. Bahan C : aduk semua bahan C hingga tercampur rata. Lalu masak dg api kecil sambil di aduk hingga meletup². Angkat dan aduk². Selagi hangat masukkan ke dlm plastik segitiga (klo mau rapi hasil nya, masukkan ke dlm botol kecap/saus)
1. Panaskan kukusan hingga beruap banyak. Siapkan cetakan kue mangkok. Oles tipis dg minyak goreng. Tuang adonan hijau sampai 2/3 tinggi cetakan. Lalu semprotkan adonan putih tepat di tengah² nya
1. Setelah kukusan panas. Kukus kue hingga matang ±10-15 menit. (tutup kukusan di alasi serbet).. Keluarkan kue dr kukusan, biarkan hingga agak dingin baru keluarkan dr cetakan.
1. Sajikan.




Demikianlah cara membuat 380.kue nona manis yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan cepat, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
