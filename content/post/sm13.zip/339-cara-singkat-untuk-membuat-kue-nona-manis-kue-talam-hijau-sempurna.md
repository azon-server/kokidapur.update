---
description: "Cara singkat untuk membuat Kue nona manis (kue talam hijau) Sempurna"
title: "Cara singkat untuk membuat Kue nona manis (kue talam hijau) Sempurna"
slug: 339-cara-singkat-untuk-membuat-kue-nona-manis-kue-talam-hijau-sempurna
date: 2020-09-12T08:39:40.593Z
image: https://img-global.cpcdn.com/recipes/f40ab74148d8378d/680x482cq70/kue-nona-manis-kue-talam-hijau-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f40ab74148d8378d/680x482cq70/kue-nona-manis-kue-talam-hijau-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f40ab74148d8378d/680x482cq70/kue-nona-manis-kue-talam-hijau-foto-resep-utama.jpg
author: Ray Brady
ratingvalue: 4.9
reviewcount: 22651
recipeingredient:
- " Bahan vla "
- "2 gelas santan"
- "2 sdm terigu"
- "2 sdm gula pasir"
- "1 sdt garam"
- " Adonan hijau "
- "2 gelas air putih"
- "1/2 gelas maizena"
- "1/2 gelas gula"
- "1 sdt garam"
- "2 sdt pasta pandan"
- " Adonan putih "
- "1 gelas santan"
- "1 gelas air"
- "1 gelas gula"
- "2 gelas terigu"
- "2 butir telur ayam"
recipeinstructions:
- "Tahap 1 : campurkan semua bahan vla jadi satu, aduk rata (boleh diblender biar cepat), masak hingga mendidih. Sisihkan"
- "Tahap 2 : campurkan semua adonan hijau, aduk rata, masak juga hingga mendidih. Sisihkan"
- "Tahap 3 : campurkan semua bahan putih dalam blender, lalu blender hingga tercampur rata. Sisihkan"
- "Tahap 4 : campurkan adonan putih tadi kedalam adonan hijau, aduk hingga rata. (Hasil menjadi hijau semua) kalo kurang hijau tambahkan sedikit lagi pasta pandan."
- "Panaskan kukusan. Hingga panas maksimal."
- "Oles cetakan dengan minyak. Cetak adonan kedalam cetakannya dgn cara : pertama masukan adonan hijau hingga 1/2 bagian cetakan, lalu timpa dengan vla putih 1 sendok teh saja. Cetak hingga selesai. Kukus selama 20 menit."
- "Selesai. Biarkan kue dingin, baru keluarkan dari cetakan"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 149 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Lunch

---


![Kue nona manis (kue talam hijau)](https://img-global.cpcdn.com/recipes/f40ab74148d8378d/680x482cq70/kue-nona-manis-kue-talam-hijau-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti kue nona manis (kue talam hijau) yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Kita



Keharmonisan rumah tangga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak Kue nona manis (kue talam hijau) untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang bisa anda praktekkan salah satunya kue nona manis (kue talam hijau) yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep kue nona manis (kue talam hijau) tanpa harus bersusah payah.
Seperti resep Kue nona manis (kue talam hijau) yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue nona manis (kue talam hijau):

1. Tambah  Bahan vla :
1. Tambah 2 gelas santan
1. Harus ada 2 sdm terigu
1. Harus ada 2 sdm gula pasir
1. Tambah 1 sdt garam
1. Tambah  Adonan hijau :
1. Tambah 2 gelas air putih
1. Jangan lupa 1/2 gelas maizena
1. Dibutuhkan 1/2 gelas gula
1. Dibutuhkan 1 sdt garam
1. Tambah 2 sdt pasta pandan
1. Diperlukan  Adonan putih :
1. Harap siapkan 1 gelas santan
1. Harap siapkan 1 gelas air
1. Harap siapkan 1 gelas gula
1. Harap siapkan 2 gelas terigu
1. Diperlukan 2 butir telur ayam




<!--inarticleads2-->

##### Cara membuat  Kue nona manis (kue talam hijau):

1. Tahap 1 : campurkan semua bahan vla jadi satu, aduk rata (boleh diblender biar cepat), masak hingga mendidih. Sisihkan
1. Tahap 2 : campurkan semua adonan hijau, aduk rata, masak juga hingga mendidih. Sisihkan
1. Tahap 3 : campurkan semua bahan putih dalam blender, lalu blender hingga tercampur rata. Sisihkan
1. Tahap 4 : campurkan adonan putih tadi kedalam adonan hijau, aduk hingga rata. (Hasil menjadi hijau semua) kalo kurang hijau tambahkan sedikit lagi pasta pandan.
1. Panaskan kukusan. Hingga panas maksimal.
1. Oles cetakan dengan minyak. Cetak adonan kedalam cetakannya dgn cara : pertama masukan adonan hijau hingga 1/2 bagian cetakan, lalu timpa dengan vla putih 1 sendok teh saja. Cetak hingga selesai. Kukus selama 20 menit.
1. Selesai. Biarkan kue dingin, baru keluarkan dari cetakan




Demikianlah cara membuat kue nona manis (kue talam hijau) yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat simple dan teruji, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
