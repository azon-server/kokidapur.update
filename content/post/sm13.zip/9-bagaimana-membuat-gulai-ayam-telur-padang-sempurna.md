---
description: "Bagaimana membuat Gulai Ayam Telur Padang Sempurna"
title: "Bagaimana membuat Gulai Ayam Telur Padang Sempurna"
slug: 9-bagaimana-membuat-gulai-ayam-telur-padang-sempurna
date: 2020-10-22T13:47:22.179Z
image: https://img-global.cpcdn.com/recipes/c19fe56855f80ef9/680x482cq70/gulai-ayam-telur-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c19fe56855f80ef9/680x482cq70/gulai-ayam-telur-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c19fe56855f80ef9/680x482cq70/gulai-ayam-telur-padang-foto-resep-utama.jpg
author: Isaiah Nelson
ratingvalue: 4.2
reviewcount: 26620
recipeingredient:
- "1 1/2 kg ayam kampung potong 6"
- "6 butir telur rebus"
- " Bahan yang dihaluskan "
- "12 siung bawang merah"
- "8 siung bawang putih"
- "4 buah cabai merah dibuang biji  direbus agar warna kuah bgs"
- "4 buah kemiri disangrai"
- "1 1/2 sendok teh ketumbar disangrai"
- "1 1/2 sendok teh jinten"
- "1 sendok teh merica"
- "6 cm kunyit"
- "6 cm jahe"
- " Bahan cemplung"
- "1 batang serai"
- "4 daun jeruk"
- "Sepotong lengkuas"
- "6 buah kapulaga"
- "2 buah bunga lawang"
- "6 buah cengkeh"
- "5 cm kayu manis"
- " Garam"
- "1 sendok teh gula pasir"
- "400 ml Santan kental"
- " Minyak goreng"
recipeinstructions:
- "Haluskan semua bahan yang dihaluskan (saya campurkan minyak goreng untuk membantu blender)."
- "Tumis bumbu yang dihaluskan, serai, daun jeruk, lengkuas, cengkeh, bunga lawang dan kayu manis."
- "Tambahkan air 1 liter dan 200 ml santan kental, kecilkan api, aduk hingga mendidih."
- "Tambahkan ayam dan tambahkan air lagi sampai ayam terendam, lalu rebus dan tambahkan garam serta gula pasir."
- "Tambahkan telur setelah ayam 1/2 matang, tutup kembali."
- "Setelah ayam empuk, tambahkan sisa santan. Aduk sampai mendidih dan uah menyusut. Koreksi rasa."
categories:
- Recipe
tags:
- gulai
- ayam
- telur

katakunci: gulai ayam telur 
nutrition: 267 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Dinner

---


![Gulai Ayam Telur Padang](https://img-global.cpcdn.com/recipes/c19fe56855f80ef9/680x482cq70/gulai-ayam-telur-padang-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti gulai ayam telur padang yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa ciri khas yang merupakan keragaman Indonesia

Keharmonisan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah memasak Gulai Ayam Telur Padang untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda buat salah satunya gulai ayam telur padang yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep gulai ayam telur padang tanpa harus bersusah payah.
Seperti resep Gulai Ayam Telur Padang yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 24 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Gulai Ayam Telur Padang:

1. Diperlukan 1 1/2 kg ayam kampung (potong 6)
1. Harap siapkan 6 butir telur rebus
1. Diperlukan  Bahan yang dihaluskan :
1. Diperlukan 12 siung bawang merah
1. Jangan lupa 8 siung bawang putih
1. Diperlukan 4 buah cabai merah (dibuang biji &amp; direbus agar warna kuah bgs)
1. Harus ada 4 buah kemiri (disangrai)
1. Dibutuhkan 1 1/2 sendok teh ketumbar (disangrai)
1. Tambah 1 1/2 sendok teh jinten
1. Harap siapkan 1 sendok teh merica
1. Jangan lupa 6 cm kunyit
1. Diperlukan 6 cm jahe
1. Tambah  Bahan cemplung:
1. Jangan lupa 1 batang serai
1. Diperlukan 4 daun jeruk
1. Siapkan Sepotong lengkuas
1. Harus ada 6 buah kapulaga
1. Diperlukan 2 buah bunga lawang
1. Tambah 6 buah cengkeh
1. Harus ada 5 cm kayu manis
1. Dibutuhkan  Garam
1. Siapkan 1 sendok teh gula pasir
1. Siapkan 400 ml Santan kental
1. Jangan lupa  Minyak goreng




<!--inarticleads2-->

##### Instruksi membuat  Gulai Ayam Telur Padang:

1. Haluskan semua bahan yang dihaluskan (saya campurkan minyak goreng untuk membantu blender).
1. Tumis bumbu yang dihaluskan, serai, daun jeruk, lengkuas, cengkeh, bunga lawang dan kayu manis.
1. Tambahkan air 1 liter dan 200 ml santan kental, kecilkan api, aduk hingga mendidih.
1. Tambahkan ayam dan tambahkan air lagi sampai ayam terendam, lalu rebus dan tambahkan garam serta gula pasir.
1. Tambahkan telur setelah ayam 1/2 matang, tutup kembali.
1. Setelah ayam empuk, tambahkan sisa santan. Aduk sampai mendidih dan uah menyusut. Koreksi rasa.




Demikianlah cara membuat gulai ayam telur padang yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan cepat, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
