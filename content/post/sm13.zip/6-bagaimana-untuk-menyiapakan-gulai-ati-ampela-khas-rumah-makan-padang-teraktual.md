---
description: "Bagaimana untuk menyiapakan Gulai Ati Ampela Khas Rumah Makan Padang teraktual"
title: "Bagaimana untuk menyiapakan Gulai Ati Ampela Khas Rumah Makan Padang teraktual"
slug: 6-bagaimana-untuk-menyiapakan-gulai-ati-ampela-khas-rumah-makan-padang-teraktual
date: 2021-02-15T11:38:24.757Z
image: https://img-global.cpcdn.com/recipes/2caec11b4671fc9f/680x482cq70/gulai-ati-ampela-khas-rumah-makan-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2caec11b4671fc9f/680x482cq70/gulai-ati-ampela-khas-rumah-makan-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2caec11b4671fc9f/680x482cq70/gulai-ati-ampela-khas-rumah-makan-padang-foto-resep-utama.jpg
author: Nora Grant
ratingvalue: 4.4
reviewcount: 15810
recipeingredient:
- " Ati ampela 5 pasang cuci bersih"
- "10 buah cabai merah keriting"
- "5 buah cabai rawit merah"
- "7 siung bawang merah"
- "4 siung bawang putih"
- "1 bungkus santan kara"
- "1 ruas jari jahe"
- "1 ruas jari kunyit"
- "1 ruas jari lengkuas digeprek"
- "1 sdt ketumbar bubuk"
- "1/2 bungkus royco ayam"
- "secukupnya Garam"
- "secukupnya Gula"
- "1 lembar daun kunyit"
- "1 batang sereh digeprek"
- "3 buah asam matang"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "secukupnya Air"
recipeinstructions:
- "Cuci semua bahan sampai bersih. Lalu rebus ati ampela sampai empuk dan masukan daun salam."
- "Uleg semua bahan sampai halus. Lalu tumis bumbu sampai matang dan harum, masukan daun salam, daun jeruk, sereh, lengkuas."
- "Tambahkan air sedikit demi sedikit, aduk2 kembali. Setelah ati amppela empuk, tiriskan baru masukan kedalam bumbu dan aduk2 kembali."
- "Masukan santan, royco, gula, asam, aduk2 kembali."
- "Beri air kembali, tunggu sampai mendidih dan koreksi rasa, kira2 air nya sudah berkurang dan tinggal sedikit lalu angkat dan siap sajikan Karna ati ampela nya sudah direbus jadi dimasak nya tidak terlalu lama karna sudah empuk ya...."
categories:
- Recipe
tags:
- gulai
- ati
- ampela

katakunci: gulai ati ampela 
nutrition: 244 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dinner

---


![Gulai Ati Ampela Khas Rumah Makan Padang](https://img-global.cpcdn.com/recipes/2caec11b4671fc9f/680x482cq70/gulai-ati-ampela-khas-rumah-makan-padang-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga gurih. Karasteristik kuliner Indonesia gulai ati ampela khas rumah makan padang yang kaya dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Gulai Ati Ampela Khas Rumah Makan Padang untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang bisa anda praktekkan salah satunya gulai ati ampela khas rumah makan padang yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep gulai ati ampela khas rumah makan padang tanpa harus bersusah payah.
Berikut ini resep Gulai Ati Ampela Khas Rumah Makan Padang yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Gulai Ati Ampela Khas Rumah Makan Padang:

1. Dibutuhkan  Ati ampela 5 pasang (cuci bersih)
1. Jangan lupa 10 buah cabai merah keriting
1. Dibutuhkan 5 buah cabai rawit merah
1. Diperlukan 7 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Siapkan 1 bungkus santan kara
1. Harap siapkan 1 ruas jari jahe
1. Tambah 1 ruas jari kunyit
1. Tambah 1 ruas jari lengkuas (digeprek)
1. Siapkan 1 sdt ketumbar bubuk
1. Tambah 1/2 bungkus royco ayam
1. Dibutuhkan secukupnya Garam
1. Diperlukan secukupnya Gula
1. Harap siapkan 1 lembar daun kunyit
1. Jangan lupa 1 batang sereh (digeprek)
1. Siapkan 3 buah asam matang
1. Harus ada 2 lembar daun salam
1. Siapkan 2 lembar daun jeruk
1. Jangan lupa secukupnya Air




<!--inarticleads2-->

##### Bagaimana membuat  Gulai Ati Ampela Khas Rumah Makan Padang:

1. Cuci semua bahan sampai bersih. - Lalu rebus ati ampela sampai empuk dan masukan daun salam.
1. Uleg semua bahan sampai halus. Lalu tumis bumbu sampai matang dan harum, masukan daun salam, daun jeruk, sereh, lengkuas.
1. Tambahkan air sedikit demi sedikit, aduk2 kembali. Setelah ati amppela empuk, tiriskan baru masukan kedalam bumbu dan aduk2 kembali.
1. Masukan santan, royco, gula, asam, aduk2 kembali.
1. Beri air kembali, tunggu sampai mendidih dan koreksi rasa, kira2 air nya sudah berkurang dan tinggal sedikit lalu angkat dan siap sajikan - Karna ati ampela nya sudah direbus jadi dimasak nya tidak terlalu lama karna sudah empuk ya....




Demikianlah cara membuat gulai ati ampela khas rumah makan padang yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
