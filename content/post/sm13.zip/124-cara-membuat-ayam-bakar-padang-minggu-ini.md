---
description: "Cara membuat Ayam Bakar Padang minggu ini"
title: "Cara membuat Ayam Bakar Padang minggu ini"
slug: 124-cara-membuat-ayam-bakar-padang-minggu-ini
date: 2021-02-28T22:41:24.838Z
image: https://img-global.cpcdn.com/recipes/5fe047afaf7b5a64/680x482cq70/ayam-bakar-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5fe047afaf7b5a64/680x482cq70/ayam-bakar-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5fe047afaf7b5a64/680x482cq70/ayam-bakar-padang-foto-resep-utama.jpg
author: Helena Ball
ratingvalue: 4.3
reviewcount: 16702
recipeingredient:
- "6 potong paha ayam beri perasan jeruk cuci bersih"
- "3 cm kayu manis"
- "5 lembar daun jeruk"
- "1 lembar daun kunyit"
- "3 butir cengkeh"
- "2 batang serai"
- "200 ml santan instan"
- "300 ml air"
- "1/2 sdt garam"
- "1/2 sdt gula"
- "1/2 sdt kaldu bubuk"
- " Bumbu Halus"
- "8 butir bawang merah"
- "4 siung bawang putih"
- "1/2 sdm ketumbar"
- "1/2 sdt adas"
- "1/2 sdt jintan"
- "1/2 sdt merica butiran"
- "2 cm jahe"
- "2 cm lengkuas"
- "3 cm kunyit"
- "3 butir kemiri"
recipeinstructions:
- "Siapkan bumbunya."
- "Haluskan bumbu. Tumis bumbu halus bersama daun jeruk, daun kunyit, serai, cengkeh, kayu manis, sampai harum"
- "Masukkan ayam, aduk rata sampai berubah warna"
- "Tuang air dan santan, beri garam, gula, kaldu. Aduk rata. Masak sampai kuah tinggal sedikit, bumbu meresap dan ayam empuk"
- "Panggang ayam diatas wajan anti lengket. Olesi dengan bumbunya"
- "Sajikan hangat, enaak banget 🥰"
categories:
- Recipe
tags:
- ayam
- bakar
- padang

katakunci: ayam bakar padang 
nutrition: 128 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Bakar Padang](https://img-global.cpcdn.com/recipes/5fe047afaf7b5a64/680x482cq70/ayam-bakar-padang-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau empuk. Ciri makanan Nusantara ayam bakar padang yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Bakar Padang untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang bisa anda contoh salah satunya ayam bakar padang yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep ayam bakar padang tanpa harus bersusah payah.
Seperti resep Ayam Bakar Padang yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Bakar Padang:

1. Tambah 6 potong paha ayam, beri perasan jeruk, cuci bersih
1. Dibutuhkan 3 cm kayu manis
1. Harap siapkan 5 lembar daun jeruk
1. Siapkan 1 lembar daun kunyit
1. Tambah 3 butir cengkeh
1. Tambah 2 batang serai
1. Diperlukan 200 ml santan instan
1. Jangan lupa 300 ml air
1. Tambah 1/2 sdt garam
1. Diperlukan 1/2 sdt gula
1. Dibutuhkan 1/2 sdt kaldu bubuk
1. Dibutuhkan  Bumbu Halus
1. Harus ada 8 butir bawang merah
1. Harap siapkan 4 siung bawang putih
1. Harap siapkan 1/2 sdm ketumbar
1. Tambah 1/2 sdt adas
1. Harap siapkan 1/2 sdt jintan
1. Dibutuhkan 1/2 sdt merica butiran
1. Jangan lupa 2 cm jahe
1. Dibutuhkan 2 cm lengkuas
1. Diperlukan 3 cm kunyit
1. Jangan lupa 3 butir kemiri




<!--inarticleads2-->

##### Langkah membuat  Ayam Bakar Padang:

1. Siapkan bumbunya.
1. Haluskan bumbu. Tumis bumbu halus bersama daun jeruk, daun kunyit, serai, cengkeh, kayu manis, sampai harum
1. Masukkan ayam, aduk rata sampai berubah warna
1. Tuang air dan santan, beri garam, gula, kaldu. Aduk rata. Masak sampai kuah tinggal sedikit, bumbu meresap dan ayam empuk
1. Panggang ayam diatas wajan anti lengket. Olesi dengan bumbunya
1. Sajikan hangat, enaak banget 🥰




Demikianlah cara membuat ayam bakar padang yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan teruji, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
