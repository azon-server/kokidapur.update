---
description: "Cara singkat untuk membuat Cantik manis / Nona manis terupdate"
title: "Cara singkat untuk membuat Cantik manis / Nona manis terupdate"
slug: 393-cara-singkat-untuk-membuat-cantik-manis-nona-manis-terupdate
date: 2020-10-28T06:08:36.449Z
image: https://img-global.cpcdn.com/recipes/3a34329ba4ead0f1/680x482cq70/cantik-manis-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3a34329ba4ead0f1/680x482cq70/cantik-manis-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3a34329ba4ead0f1/680x482cq70/cantik-manis-nona-manis-foto-resep-utama.jpg
author: Tom Barnett
ratingvalue: 4.7
reviewcount: 38378
recipeingredient:
- " Bahan IPutih  450 ml santan"
- "75 gram tepung terigu sy pake segitiga biru"
- "25 gram tepung beras sy pake rose brand Garam Sdt"
- " Bahan IIHijau  300gram tepung terigu 1 sdm tepung beras rosebrand 150gram gulam pasir 700ml santan 3sdt perasa pandan"
recipeinstructions:
- "Masukan tepung terigu, tepung beras, garam dan santan lalu aduk, hingga tercampur rata kemudian nyalakn kompor, panaskan hingga mengental dan sisihkan."
- "Campurkan semua bahan II(hijau) lalu tuang ke dalam cetakan jangan sampai penuh karena akan di beri bahan I atau bahan putih nya"
- "Kukus kurang lebih 15 menit lalu dinginkan dan keluarkan dari cetakan"
categories:
- Recipe
tags:
- cantik
- manis
- 

katakunci: cantik manis  
nutrition: 149 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Lunch

---


![Cantik manis / Nona manis](https://img-global.cpcdn.com/recipes/3a34329ba4ead0f1/680x482cq70/cantik-manis-nona-manis-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang harus kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti cantik manis / nona manis yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan keistimewahan yang merupakan keragaman Kita

Kehangatan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Cantik manis / Nona manis untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang dapat anda coba salah satunya cantik manis / nona manis yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep cantik manis / nona manis tanpa harus bersusah payah.
Berikut ini resep Cantik manis / Nona manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 4 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Cantik manis / Nona manis:

1. Tambah  Bahan I/Putih : 450 ml santan
1. Harap siapkan 75 gram tepung terigu (sy pake segitiga biru)
1. Tambah 25 gram tepung beras (sy pake rose brand), Garam Sdt
1. Tambah  Bahan II/Hijau : 300gram tepung terigu 1 sdm tepung beras (rosebrand) 150gram gulam pasir 700ml santan, 3sdt perasa pandan




<!--inarticleads2-->

##### Bagaimana membuat  Cantik manis / Nona manis:

1. Masukan tepung terigu, tepung beras, garam dan santan lalu aduk, hingga tercampur rata kemudian nyalakn kompor, panaskan hingga mengental dan sisihkan.
1. Campurkan semua bahan II(hijau) lalu tuang ke dalam cetakan jangan sampai penuh karena akan di beri bahan I atau bahan putih nya
1. Kukus kurang lebih 15 menit lalu dinginkan dan keluarkan dari cetakan




Demikianlah cara membuat cantik manis / nona manis yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat simple dan teruji, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
