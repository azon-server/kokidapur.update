---
description: "Panduan membuat Gimbal Udang dan Tempe ala Nona Kentir Teruji"
title: "Panduan membuat Gimbal Udang dan Tempe ala Nona Kentir Teruji"
slug: 426-panduan-membuat-gimbal-udang-dan-tempe-ala-nona-kentir-teruji
date: 2020-12-03T14:30:09.571Z
image: https://img-global.cpcdn.com/recipes/04f0054da411b00f/680x482cq70/gimbal-udang-dan-tempe-ala-nona-kentir-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/04f0054da411b00f/680x482cq70/gimbal-udang-dan-tempe-ala-nona-kentir-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/04f0054da411b00f/680x482cq70/gimbal-udang-dan-tempe-ala-nona-kentir-foto-resep-utama.jpg
author: Miguel Green
ratingvalue: 4.1
reviewcount: 22969
recipeingredient:
- "1/2 kg udang segar"
- "3/4 kg tepung beras"
- "2 sdm tepung terigu"
- "Secukupnya garam"
- "Secukupnya jinten"
- "1/2 ruas kunyit"
- "10 butir kemiri"
- "Secukupnya ketumbar"
- "10 siung bawang putih"
- "10 butir cabe rawit"
- "3 butir kencur"
- "5 lembar daun jeruk"
recipeinstructions:
- "Cuci bersih udang baru dikupas kepala dan badannya saja. Kaki dan ekor jangan dibuang."
- "Blender bumbu dg sedikit air: bawang putih, kemiri, ketumbar, kencur, kunyit, daun salam dan cabe rawit."
- "Siapkan wadah. Masukkan tepung terigu, tepung beras, bumbu yg sudah di blender, jinten dan air secukupnya. Nti adonan yg agak kental untuk gimbal tempe ditsmbah irisan daun bawang ya, trs yg utk gimbal udang ditambahkan air lagi supaya lebih encer."
- "Goreng gimbal udang dan tempe dengan minyak baru, jangan jelantah. Sajikan selagi hangat. Hmm paling cocok pakai sayur bening (kelo kunci) oyong, kemangi dan jagung manis."
categories:
- Recipe
tags:
- gimbal
- udang
- dan

katakunci: gimbal udang dan 
nutrition: 168 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Dessert

---


![Gimbal Udang dan Tempe ala Nona Kentir](https://img-global.cpcdn.com/recipes/04f0054da411b00f/680x482cq70/gimbal-udang-dan-tempe-ala-nona-kentir-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan renyah. Karasteristik masakan Indonesia gimbal udang dan tempe ala nona kentir yang kaya dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah memasak Gimbal Udang dan Tempe ala Nona Kentir untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang bisa anda buat salah satunya gimbal udang dan tempe ala nona kentir yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep gimbal udang dan tempe ala nona kentir tanpa harus bersusah payah.
Berikut ini resep Gimbal Udang dan Tempe ala Nona Kentir yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Gimbal Udang dan Tempe ala Nona Kentir:

1. Diperlukan 1/2 kg udang segar
1. Dibutuhkan 3/4 kg tepung beras
1. Harus ada 2 sdm tepung terigu
1. Tambah Secukupnya garam
1. Harus ada Secukupnya jinten
1. Harap siapkan 1/2 ruas kunyit
1. Tambah 10 butir kemiri
1. Dibutuhkan Secukupnya ketumbar
1. Harap siapkan 10 siung bawang putih
1. Dibutuhkan 10 butir cabe rawit
1. Tambah 3 butir kencur
1. Jangan lupa 5 lembar daun jeruk




<!--inarticleads2-->

##### Bagaimana membuat  Gimbal Udang dan Tempe ala Nona Kentir:

1. Cuci bersih udang baru dikupas kepala dan badannya saja. Kaki dan ekor jangan dibuang.
1. Blender bumbu dg sedikit air: bawang putih, kemiri, ketumbar, kencur, kunyit, daun salam dan cabe rawit.
1. Siapkan wadah. Masukkan tepung terigu, tepung beras, bumbu yg sudah di blender, jinten dan air secukupnya. Nti adonan yg agak kental untuk gimbal tempe ditsmbah irisan daun bawang ya, trs yg utk gimbal udang ditambahkan air lagi supaya lebih encer.
1. Goreng gimbal udang dan tempe dengan minyak baru, jangan jelantah. Sajikan selagi hangat. Hmm paling cocok pakai sayur bening (kelo kunci) oyong, kemangi dan jagung manis.




Demikianlah cara membuat gimbal udang dan tempe ala nona kentir yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
