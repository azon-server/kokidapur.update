---
description: "Cara membuat Nona Manis Ubi Ungu🍠🍠 Favorite"
title: "Cara membuat Nona Manis Ubi Ungu🍠🍠 Favorite"
slug: 366-cara-membuat-nona-manis-ubi-ungu-favorite
date: 2021-01-17T01:59:05.817Z
image: https://img-global.cpcdn.com/recipes/9dc352a209a25077/680x482cq70/nona-manis-ubi-ungu🍠🍠-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9dc352a209a25077/680x482cq70/nona-manis-ubi-ungu🍠🍠-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9dc352a209a25077/680x482cq70/nona-manis-ubi-ungu🍠🍠-foto-resep-utama.jpg
author: Norman Mann
ratingvalue: 5
reviewcount: 16550
recipeingredient:
- "250 g ubi ungu yang sudah di kukus"
- "200 g gula pasir resep asli 250"
- "70 ml Santan instan 1 bungkus santan klatu"
- "250 ml air"
- "125 g tepung sagu aku pakai alini"
- "25 g tepung berasaku pakai rosebrand"
- "1/2 sdt garam"
- "1/4 sdt vanili"
- " isian  adonan putih"
- "18 g tepung beras"
- "18 g tepung maizena"
- "70 ml santan instan 1 bungkus santan klatu"
- "380 ml air resep asli 375"
- "3/4 sdt garam halus"
- "1 lembar daun pandan saya skip habis"
recipeinstructions:
- "Kukus ubi ungu sementara kita masak isian (adonan putih) dengan cara campur semua bahan aduk rata masak sampai mengental dan meletup letup angkat dan sisihkan"
- "Campurkan semua bahan lalu blender sampai halus, lalu masukkan ke dalam cetakan sekitar 3/4, yang sudah di oles minyak, aku kemarin lupa tp alhamdulillah gak lengket 😊"
- "Setelah adonan putih sudah gak panas lagi masukkan dalam plastik segitiga, 👉"
- "Gunting ujung plastik lalu benamkan di tengah adonan ungu pencet sampai adonan penuh"
- "Setelah semua selesai kukus selama 20 menit"
- "Setelah matang biarkan dingin baru setelah itu di keluarkan dari cetakan"
categories:
- Recipe
tags:
- nona
- manis
- ubi

katakunci: nona manis ubi 
nutrition: 168 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT40M"
recipeyield: "3"
recipecategory: Dessert

---


![Nona Manis Ubi Ungu🍠🍠](https://img-global.cpcdn.com/recipes/9dc352a209a25077/680x482cq70/nona-manis-ubi-ungu🍠🍠-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau renyah. Ciri makanan Nusantara nona manis ubi ungu🍠🍠 yang penuh dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kedekatan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah membuat makanan Nona Manis Ubi Ungu🍠🍠 untuk keluarga. Momen makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda contoh salah satunya nona manis ubi ungu🍠🍠 yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep nona manis ubi ungu🍠🍠 tanpa harus bersusah payah.
Berikut ini resep Nona Manis Ubi Ungu🍠🍠 yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona Manis Ubi Ungu🍠🍠:

1. Harus ada 250 g ubi ungu yang sudah di kukus
1. Dibutuhkan 200 g gula pasir (resep asli 250)
1. Harus ada 70 ml Santan instan (1 bungkus santan klatu)
1. Tambah 250 ml air
1. Dibutuhkan 125 g tepung sagu (aku pakai alini)
1. Jangan lupa 25 g tepung beras(aku pakai rosebrand)
1. Siapkan 1/2 sdt garam
1. Jangan lupa 1/4 sdt vanili
1. Jangan lupa  🌹isian / adonan putih🌹
1. Tambah 18 g tepung beras
1. Harap siapkan 18 g tepung maizena
1. Jangan lupa 70 ml santan instan (1 bungkus santan klatu)
1. Tambah 380 ml air (resep asli 375)
1. Harus ada 3/4 sdt garam halus
1. Jangan lupa 1 lembar daun pandan (saya skip.. habis)




<!--inarticleads2-->

##### Bagaimana membuat  Nona Manis Ubi Ungu🍠🍠:

1. Kukus ubi ungu sementara kita masak isian (adonan putih) dengan cara campur semua bahan aduk rata masak sampai mengental dan meletup letup angkat dan sisihkan
1. Campurkan semua bahan lalu blender sampai halus, lalu masukkan ke dalam cetakan sekitar 3/4, yang sudah di oles minyak, aku kemarin lupa tp alhamdulillah gak lengket 😊
1. Setelah adonan putih sudah gak panas lagi masukkan dalam plastik segitiga, 👉
1. Gunting ujung plastik lalu benamkan di tengah adonan ungu pencet sampai adonan penuh
1. Setelah semua selesai kukus selama 20 menit
1. Setelah matang biarkan dingin baru setelah itu di keluarkan dari cetakan




Demikianlah cara membuat nona manis ubi ungu🍠🍠 yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan terbukti, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
