---
description: "Resep : Nona cantik atau cantik manis minggu ini"
title: "Resep : Nona cantik atau cantik manis minggu ini"
slug: 323-resep-nona-cantik-atau-cantik-manis-minggu-ini
date: 2021-03-05T22:12:14.416Z
image: https://img-global.cpcdn.com/recipes/1d0f7f349e675e5c/680x482cq70/nona-cantik-atau-cantik-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1d0f7f349e675e5c/680x482cq70/nona-cantik-atau-cantik-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1d0f7f349e675e5c/680x482cq70/nona-cantik-atau-cantik-manis-foto-resep-utama.jpg
author: Ina Wolfe
ratingvalue: 4.2
reviewcount: 30707
recipeingredient:
- " Bahan hijau"
- "300 gr Tepung terigu"
- "800 ml santan saya santan kara 65ml 3 bungkus campur air"
- "200 gr gula pasir"
- "secukupnya Pewarna pandan pasta"
- "2 telur"
- " Bahan fla"
- "2 sdm tepung maizena"
- "2 sdm tepung terigu"
- "500 ml santan"
- "sejumput Garam"
- " Untuk santannya saya gunakan santan kara ukuran 65ml campur air"
recipeinstructions:
- "Buat fla, campur jadi satu masak sampai meletup meletup,,sisihkan..dinginkan"
- "Cetakan di olesi minyak baru tuang adonan hijau dan fla putihnya."
- "Bahan hijaunya dicampur jadi satu,,saya pakai wisk jadi tidak bergerindil.."
- "Siapkan panci kukus, penutupnya di alasi kain,,"
- "Kukus selama 15menit"
- "Done"
categories:
- Recipe
tags:
- nona
- cantik
- atau

katakunci: nona cantik atau 
nutrition: 165 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT55M"
recipeyield: "4"
recipecategory: Dessert

---


![Nona cantik atau cantik manis](https://img-global.cpcdn.com/recipes/1d0f7f349e675e5c/680x482cq70/nona-cantik-atau-cantik-manis-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang harus kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti nona cantik atau cantik manis yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan ciri khas yang merupakan keragaman Nusantara

Kedekatan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah memasak Nona cantik atau cantik manis untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang dapat anda coba salah satunya nona cantik atau cantik manis yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep nona cantik atau cantik manis tanpa harus bersusah payah.
Seperti resep Nona cantik atau cantik manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 12 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona cantik atau cantik manis:

1. Jangan lupa  Bahan hijau
1. Harus ada 300 gr Tepung terigu
1. Jangan lupa 800 ml santan (saya santan kara 65ml 3 bungkus campur air)
1. Siapkan 200 gr gula pasir
1. Diperlukan secukupnya Pewarna pandan pasta
1. Tambah 2 telur
1. Tambah  Bahan fla
1. Diperlukan 2 sdm tepung maizena
1. Jangan lupa 2 sdm tepung terigu
1. Tambah 500 ml santan
1. Harus ada sejumput Garam
1. Diperlukan  Untuk santannya saya gunakan santan kara ukuran 65ml campur air




<!--inarticleads2-->

##### Instruksi membuat  Nona cantik atau cantik manis:

1. Buat fla, campur jadi satu masak sampai meletup meletup,,sisihkan..dinginkan
1. Cetakan di olesi minyak baru tuang adonan hijau dan fla putihnya.
1. Bahan hijaunya dicampur jadi satu,,saya pakai wisk jadi tidak bergerindil..
1. Siapkan panci kukus, penutupnya di alasi kain,,
1. Kukus selama 15menit
1. Done




Demikianlah cara membuat nona cantik atau cantik manis yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
