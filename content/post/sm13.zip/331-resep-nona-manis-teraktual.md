---
description: "Resep : Nona Manis teraktual"
title: "Resep : Nona Manis teraktual"
slug: 331-resep-nona-manis-teraktual
date: 2020-12-23T11:12:45.302Z
image: https://img-global.cpcdn.com/recipes/5158a298447bb764/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5158a298447bb764/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5158a298447bb764/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Pauline Sandoval
ratingvalue: 4.7
reviewcount: 1975
recipeingredient:
- " Bahan A"
- "250 ml santankara Kecil tambah air"
- "50 gr tepung terigu"
- "Sejumput garam"
- " Bahan B"
- "125 ml santan Kara kecil tambah air"
- "Sejumput garam"
- "1 sdm gula pasir"
- "15 gr maizena"
- "1/2 sdt pasta pandan"
- " Bahan C"
- "1 butir telur"
- "125 ml santan kental Kara kecil tambah air"
- "40 gr gula pasir 2 sdm"
- "70 gr tepung terigu protein sedang"
recipeinstructions:
- "Campur semua bahan A (adonan putih), aduk rata. Saring. Masak sambil diaduk-aduk dengan api kecil hingga meletup-letup. Matikan api. Aduk-aduk hingga licin, agak kental, tidak bergerindil. Biarkan dingin. Lalu masukkan ke dalam plastik segitiga. Sisihkan."
- "Olesi cetakan talam dengan minyak goreng tipis-tipis. Sisihkan."
- "Campur semua bahan B lalu masak dengan api kecil sambil terus diaduk hingga meletup-letup dan menjadi adonan yang kental. Angkat lalu biarkan dingin. Sisihkan."
- "Bahan C: Kocok telur dan gula pasir dengan whisker hingga gula larut. Masukkan santan dan terigu secara bertahap sambil terus diaduk hingga rata dan tidak bergerindil. Masukkan adonan B (adonan hijau) secara bertahap, kocok dengan whisker hingga rata dan tidak bergerindil. Saring."
- "Didihkan air dalam dandang kukusan. Penutup kukusan dilapisi serbet bersih ya, supaya air tidak menetesi ke atas permukaan kue."
- "Sambil menunggu kukusan siap, tuang adonan hijau ke dalam cetakan setinggi 3/4 cetakannya. Setelah semua adonan hijau habis, semprotkan adonan putih ditengah adonan hijau(bagian ujung/moncong plastik agak dibenamkan ya). Tuang hingga hampir penuh. Lakukan hingga semua adonan"
- "Kukus selama 20 menit dengan api sedang cenderung kecil. Matikan kompor, angkat lalu biarkan hingga dingin di dalam cetakan, Setelah dingin, keluarkan dari cetakan. kue nona manis siao di sajikan. 😊👌"
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 284 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Dessert

---


![Nona Manis](https://img-global.cpcdn.com/recipes/5158a298447bb764/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan empuk. Ciri khas kuliner Indonesia nona manis yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga bisa diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Nona Manis untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang dapat anda contoh salah satunya nona manis yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona Manis yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona Manis:

1. Tambah  Bahan A:
1. Diperlukan 250 ml santan(kara Kecil tambah air)
1. Tambah 50 gr tepung terigu
1. Diperlukan Sejumput garam
1. Tambah  Bahan B:
1. Harap siapkan 125 ml santan (Kara kecil tambah air)
1. Siapkan Sejumput garam
1. Diperlukan 1 sdm gula pasir
1. Tambah 15 gr maizena
1. Harus ada 1/2 sdt pasta pandan
1. Harus ada  Bahan C:
1. Harap siapkan 1 butir telur
1. Siapkan 125 ml santan kental (Kara kecil tambah air)
1. Siapkan 40 gr gula pasir (2 sdm)
1. Dibutuhkan 70 gr tepung terigu protein sedang




<!--inarticleads2-->

##### Instruksi membuat  Nona Manis:

1. Campur semua bahan A (adonan putih), aduk rata. Saring. Masak sambil diaduk-aduk dengan api kecil hingga meletup-letup. Matikan api. Aduk-aduk hingga licin, agak kental, tidak bergerindil. Biarkan dingin. Lalu masukkan ke dalam plastik segitiga. Sisihkan.
1. Olesi cetakan talam dengan minyak goreng tipis-tipis. Sisihkan.
1. Campur semua bahan B lalu masak dengan api kecil sambil terus diaduk hingga meletup-letup dan menjadi adonan yang kental. Angkat lalu biarkan dingin. Sisihkan.
1. Bahan C: Kocok telur dan gula pasir dengan whisker hingga gula larut. Masukkan santan dan terigu secara bertahap sambil terus diaduk hingga rata dan tidak bergerindil. Masukkan adonan B (adonan hijau) secara bertahap, kocok dengan whisker hingga rata dan tidak bergerindil. Saring.
1. Didihkan air dalam dandang kukusan. Penutup kukusan dilapisi serbet bersih ya, supaya air tidak menetesi ke atas permukaan kue.
1. Sambil menunggu kukusan siap, tuang adonan hijau ke dalam cetakan setinggi 3/4 cetakannya. Setelah semua adonan hijau habis, semprotkan adonan putih ditengah adonan hijau(bagian ujung/moncong plastik agak dibenamkan ya). Tuang hingga hampir penuh. Lakukan hingga semua adonan
1. Kukus selama 20 menit dengan api sedang cenderung kecil. Matikan kompor, angkat lalu biarkan hingga dingin di dalam cetakan, Setelah dingin, keluarkan dari cetakan. kue nona manis siao di sajikan. 😊👌




Demikianlah cara membuat nona manis yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
