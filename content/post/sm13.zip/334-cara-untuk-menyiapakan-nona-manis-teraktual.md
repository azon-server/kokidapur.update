---
description: "Cara untuk menyiapakan Nona manis teraktual"
title: "Cara untuk menyiapakan Nona manis teraktual"
slug: 334-cara-untuk-menyiapakan-nona-manis-teraktual
date: 2021-02-05T23:00:14.817Z
image: https://img-global.cpcdn.com/recipes/fdb7f4a4d654ed34/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fdb7f4a4d654ed34/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fdb7f4a4d654ed34/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Edna Fernandez
ratingvalue: 4.4
reviewcount: 8755
recipeingredient:
- " Bahan A"
- "500 ml santan sedang"
- "50 gr terigu"
- "1/4 sdt garam"
- " Bahan B"
- "40 gr gula pasir"
- "30 gr tepung maizena"
- "250 ml santan sedang"
- " Pasta pandan secukupnya"
- "1/4 sdt garam"
- " Bahan c"
- "140 gr terigu"
- "80 gr gula pasir"
- "250 ml santan sedang"
- " I butir telur"
recipeinstructions:
- "Masukkan smua bahan A. Lalu masak dng api kecil aduk terus sampai meletup&#34;. Matikan kompor. Aduk trus sampai adonan mengental dan halus. Biarkan dingin."
- "Masukkan ke botol/ piping bag"
- "Masak smua bahan b dng api kecil. Aduk terus smpai mnjadi adonan yg kental. Matikan dan dinginkan"
- "Di wadah yg lain mix telur + gula dampai gula larut.. masukkan tepung dan santan scr bergantian mix rata. Masukkan adonan B sdikit demi sdikit mix rata sampai mnjadi adonan yg halus dan tidak bergerindil. Sy saring."
- "Tuang adonan hijau 1/2 lebih ke cetakan. Semprotkan adonan putih di tengahnya sampai agak penuh. Benamkan sdikit tutup botolnya agar rapi."
- "Kukus slama 15 mnt. ttp dng serbet tutup kukusan."
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 233 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Dessert

---


![Nona manis](https://img-global.cpcdn.com/recipes/fdb7f4a4d654ed34/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau renyah. Ciri kuliner Indonesia nona manis yang kaya dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga bisa didapat dengan cara simple. Salah satunya adalah memasak Nona manis untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang bisa anda contoh salah satunya nona manis yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep nona manis tanpa harus bersusah payah.
Berikut ini resep Nona manis yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona manis:

1. Dibutuhkan  Bahan A
1. Diperlukan 500 ml santan sedang
1. Dibutuhkan 50 gr terigu
1. Tambah 1/4 sdt garam
1. Diperlukan  Bahan B
1. Harus ada 40 gr gula pasir
1. Tambah 30 gr tepung maizena
1. Jangan lupa 250 ml santan sedang
1. Harap siapkan  Pasta pandan secukupnya
1. Harap siapkan 1/4 sdt garam
1. Tambah  Bahan c
1. Siapkan 140 gr terigu
1. Harap siapkan 80 gr gula pasir
1. Siapkan 250 ml santan sedang
1. Harap siapkan  I butir telur




<!--inarticleads2-->

##### Bagaimana membuat  Nona manis:

1. Masukkan smua bahan A. Lalu masak dng api kecil aduk terus sampai meletup&#34;. Matikan kompor. Aduk trus sampai adonan mengental dan halus. Biarkan dingin.
1. Masukkan ke botol/ piping bag
1. Masak smua bahan b dng api kecil. Aduk terus smpai mnjadi adonan yg kental. Matikan dan dinginkan
1. Di wadah yg lain mix telur + gula dampai gula larut.. masukkan tepung dan santan scr bergantian mix rata. Masukkan adonan B sdikit demi sdikit mix rata sampai mnjadi adonan yg halus dan tidak bergerindil. Sy saring.
1. Tuang adonan hijau 1/2 lebih ke cetakan. Semprotkan adonan putih di tengahnya sampai agak penuh. Benamkan sdikit tutup botolnya agar rapi.
1. Kukus slama 15 mnt. ttp dng serbet tutup kukusan.




Demikianlah cara membuat nona manis yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
