---
description: "Resep : Nona manis terupdate"
title: "Resep : Nona manis terupdate"
slug: 337-resep-nona-manis-terupdate
date: 2020-12-08T13:18:15.179Z
image: https://img-global.cpcdn.com/recipes/afe4cec028fc626f/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/afe4cec028fc626f/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/afe4cec028fc626f/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Nettie Briggs
ratingvalue: 4.2
reviewcount: 8428
recipeingredient:
- " Bahan A"
- "500 ml santan kental"
- "50 gr tepung terigu"
- "1/4 sdt garam"
- " Bahan B"
- "80 gr gula pasir"
- "60 gr tepung maizena"
- "500 ml santan"
- "1/4 sdt garam"
- " Pasta pandan secukup nya"
- " Bahan C"
- "280 gr tepung terigu"
- "150 gr gula pasir"
- "500 ml santan"
- "2 butir telur"
recipeinstructions:
- "Campur semua bahan A aduk sampe larut, masak d atas kompor sampe meletup&#34;sambil di aduk terus sampe adonan kental dan halus, matikan kompor setelah adonan meletup&#34; masih terus d aduk ya biar hasil na halus bgt dan lembut, hilang kan uap panas nya"
- "Setelah adonan A halus dan lembut uap panas sudah hilang masukan kedalam botol kecap supaya lebih gampang nanti saat ngisi ke cetakan,sisihkan"
- "Lanjut bahan B,campur semua bahan B aduk sampe larut,mask di atas kompor sampe adonan kental dan meletup, adonan kental angkat sisihkan"
- "Selanjutnya bahan C,mixer telur sama gula sampe gula larut masukan terigu dan santan secara bergantian sampe habis,"
- "Selanjutnya masukan bahan B ke dalam bahan C sedikit demi sedikit sampe adonan tercampur dan halus sisihkan."
- "Siapkan cetakn kue talam, olesi dengan minyak goreng,"
- "Isi cetakan dengan adonan campuran bahan B dan C,isi 3/4 cetakan"
- "Setelah cetakan terisi semua, tuang adonan A d botol kecap tadi dengan cara mulut botol masuk ke dalam adonan d cetakan sampe terisi ke atas sisihkan,"
- "Kukus sampe matang selama 20 menit, angkat biarkn dingin dulu baru keluar kan dari cetakan"
- "Sajikan selagi hangat, dengan teh tawar panas atau masuk kulkas juga enak 😊"
- "NB : untuk rasa yg lebih legit saya gunakan santan asli, kalo ribet parut d pasar langsung bikin santan d tukang kelapa nya, pake 1 buah kelapa tua besar di kupas giling jadiin 1,5 liter santan, kenapa saya recomen santan asli karena saya pernah bikin pake santan instan Ka** rasanya kurang mantap 😊😊"
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 174 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Dinner

---


![Nona manis](https://img-global.cpcdn.com/recipes/afe4cec028fc626f/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau empuk. Ciri masakan Nusantara nona manis yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Nona manis untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang bisa anda praktekkan salah satunya nona manis yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona manis yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 15 bahan dan 11 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona manis:

1. Diperlukan  Bahan A
1. Diperlukan 500 ml santan kental
1. Dibutuhkan 50 gr tepung terigu
1. Jangan lupa 1/4 sdt garam
1. Harus ada  Bahan B
1. Dibutuhkan 80 gr gula pasir
1. Siapkan 60 gr tepung maizena
1. Diperlukan 500 ml santan
1. Siapkan 1/4 sdt garam
1. Harap siapkan  Pasta pandan secukup nya
1. Diperlukan  Bahan C
1. Dibutuhkan 280 gr tepung terigu
1. Jangan lupa 150 gr gula pasir
1. Dibutuhkan 500 ml santan
1. Jangan lupa 2 butir telur




<!--inarticleads2-->

##### Cara membuat  Nona manis:

1. Campur semua bahan A aduk sampe larut, masak d atas kompor sampe meletup&#34;sambil di aduk terus sampe adonan kental dan halus, matikan kompor setelah adonan meletup&#34; masih terus d aduk ya biar hasil na halus bgt dan lembut, hilang kan uap panas nya
1. Setelah adonan A halus dan lembut uap panas sudah hilang masukan kedalam botol kecap supaya lebih gampang nanti saat ngisi ke cetakan,sisihkan
1. Lanjut bahan B,campur semua bahan B aduk sampe larut,mask di atas kompor sampe adonan kental dan meletup, adonan kental angkat sisihkan
1. Selanjutnya bahan C,mixer telur sama gula sampe gula larut masukan terigu dan santan secara bergantian sampe habis,
1. Selanjutnya masukan bahan B ke dalam bahan C sedikit demi sedikit sampe adonan tercampur dan halus sisihkan.
1. Siapkan cetakn kue talam, olesi dengan minyak goreng,
1. Isi cetakan dengan adonan campuran bahan B dan C,isi 3/4 cetakan
1. Setelah cetakan terisi semua, tuang adonan A d botol kecap tadi dengan cara mulut botol masuk ke dalam adonan d cetakan sampe terisi ke atas sisihkan,
1. Kukus sampe matang selama 20 menit, angkat biarkn dingin dulu baru keluar kan dari cetakan
1. Sajikan selagi hangat, dengan teh tawar panas atau masuk kulkas juga enak 😊
1. NB : untuk rasa yg lebih legit saya gunakan santan asli, kalo ribet parut d pasar langsung bikin santan d tukang kelapa nya, pake 1 buah kelapa tua besar di kupas giling jadiin 1,5 liter santan, kenapa saya recomen santan asli karena saya pernah bikin pake santan instan Ka** rasanya kurang mantap 😊😊




Demikianlah cara membuat nona manis yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan terbukti, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
