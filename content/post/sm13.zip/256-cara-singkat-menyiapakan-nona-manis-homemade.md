---
description: "Cara singkat menyiapakan Nona Manis Homemade"
title: "Cara singkat menyiapakan Nona Manis Homemade"
slug: 256-cara-singkat-menyiapakan-nona-manis-homemade
date: 2020-11-04T10:56:06.451Z
image: https://img-global.cpcdn.com/recipes/267e8d7832f92ec9/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/267e8d7832f92ec9/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/267e8d7832f92ec9/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Mathilda Cannon
ratingvalue: 4
reviewcount: 48625
recipeingredient:
- " Bahan A "
- "1 butir telur"
- "125 gr gula pasir"
- "125 gr tepung terigu"
- "250 ml santan"
- " Bahan B "
- "125 ml santan"
- "125 air matang"
- "1 sdm pasta pandan"
- "60 gr gula pasir"
- "30 gr tepung maizena"
- "1/4 sdt garam"
- " Bahan C "
- "125 ml santan"
- "1 sdm tepung terigu"
- "1 sdm gula pasir"
- "1/4 sdt garam"
recipeinstructions:
- "Campur semua bahan A, lalu aduk rata."
- "Campur semua bahan B, aduk rata, lalu masak sambil diaduk-aduk hingga meletup-letup, matikan api."
- "Lalu sambil teus diaduk-aduk campurkan semua bahan B yang masih panas kedalam bahan A, aduk hingga adonan tercampur rata, jika masih ada yang bergerindil maka harus disaring."
- "Dalam panci lain, siapkan bahan C, aduk rata lalu masak sambil aduk-aduk hingga mengental dan meletup-letup, matikan api, biarka hingga hangat, karena jika masih panas masih terasa encer."
- "Siapkan kukusan, lapisia tutup kukusan dengan serbet, olesi cetakan dengan minyak goreng, lalu masukkan adonan hijau setinggi 2/3 dari tinggi cetakan."
- "Kemudian masukkan lapisan putih ditengah secukupna, karena adonan putih masih panas jadi adonan masih encer jadi bisa langsung dituang secara perlahan, tapi jika adonan putih sudah dingin akan mengental, jadi bisa dituang dengan menggunakan sendok / bisa dimasukkan kedalam plastik segitiga. Lalu kukus adonan selama 15 - 20 menit hingga matang."
- "Sesudah kue matang, diamkan dahulu hingga adoanan hangat, supaya pas dibuka adonan putihnya akan hancur karena masih lembek kalau masih panas, dan jika sudah dingin akan mengeras sendirinya, lepaskan kue dari cetakan secara perlahan."
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 136 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Lunch

---


![Nona Manis](https://img-global.cpcdn.com/recipes/267e8d7832f92ec9/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau gurih. Ciri masakan Indonesia nona manis yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kedekatan rumah tangga bisa ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Nona Manis untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang dapat anda contoh salah satunya nona manis yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona Manis yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona Manis:

1. Tambah  Bahan A :
1. Harap siapkan 1 butir telur
1. Harap siapkan 125 gr gula pasir
1. Jangan lupa 125 gr tepung terigu
1. Jangan lupa 250 ml santan
1. Diperlukan  Bahan B :
1. Harus ada 125 ml santan
1. Siapkan 125 air matang
1. Dibutuhkan 1 sdm pasta pandan
1. Siapkan 60 gr gula pasir
1. Harus ada 30 gr tepung maizena
1. Jangan lupa 1/4 sdt garam
1. Diperlukan  Bahan C :
1. Harus ada 125 ml santan
1. Tambah 1 sdm tepung terigu
1. Siapkan 1 sdm gula pasir
1. Dibutuhkan 1/4 sdt garam




<!--inarticleads2-->

##### Langkah membuat  Nona Manis:

1. Campur semua bahan A, lalu aduk rata.
1. Campur semua bahan B, aduk rata, lalu masak sambil diaduk-aduk hingga meletup-letup, matikan api.
1. Lalu sambil teus diaduk-aduk campurkan semua bahan B yang masih panas kedalam bahan A, aduk hingga adonan tercampur rata, jika masih ada yang bergerindil maka harus disaring.
1. Dalam panci lain, siapkan bahan C, aduk rata lalu masak sambil aduk-aduk hingga mengental dan meletup-letup, matikan api, biarka hingga hangat, karena jika masih panas masih terasa encer.
1. Siapkan kukusan, lapisia tutup kukusan dengan serbet, olesi cetakan dengan minyak goreng, lalu masukkan adonan hijau setinggi 2/3 dari tinggi cetakan.
1. Kemudian masukkan lapisan putih ditengah secukupna, karena adonan putih masih panas jadi adonan masih encer jadi bisa langsung dituang secara perlahan, tapi jika adonan putih sudah dingin akan mengental, jadi bisa dituang dengan menggunakan sendok / bisa dimasukkan kedalam plastik segitiga. Lalu kukus adonan selama 15 - 20 menit hingga matang.
1. Sesudah kue matang, diamkan dahulu hingga adoanan hangat, supaya pas dibuka adonan putihnya akan hancur karena masih lembek kalau masih panas, dan jika sudah dingin akan mengeras sendirinya, lepaskan kue dari cetakan secara perlahan.




Demikianlah cara membuat nona manis yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan cepat, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
