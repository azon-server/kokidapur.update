---
description: "Resep : Nona manis minggu ini"
title: "Resep : Nona manis minggu ini"
slug: 396-resep-nona-manis-minggu-ini
date: 2020-09-15T18:12:51.662Z
image: https://img-global.cpcdn.com/recipes/19410e6a175b15ee/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/19410e6a175b15ee/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/19410e6a175b15ee/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Brent Baker
ratingvalue: 4.8
reviewcount: 16645
recipeingredient:
- " Bahan A"
- "500 ml santan kekentalan sedang"
- "60 gr tepung terigu"
- " Bahan B"
- "500 ml santan"
- "50 gr tepung maizena"
- "100 gr gula pasir"
- "secukupnya Pasta pandan"
- "600 ml santan"
- "400 gr tepung terigu"
- "150 gr gula pasir"
- "Sejumput garam"
- "3 butir telur utuh"
recipeinstructions:
- "Memasak bahan B terlebih dahulu, cempur semua bahan B masak sampai meletu-letup angkat dan dinginkan"
- "Sambil nunggu bahan B dingin, kita masak bahan A, campur semua bahan A masak sampai meletup-letup angkat dan biarkan agak sedikit hangat baru masukkan kedalam plastik segi tiga agar lebih mudah"
- "Sekarang kita olah bahan C, campurkan telur dan gula di baskom yg agak besar lalu di mixer sampai gula agak larut"
- "Setelah itu masukkan santan sambil terus di mixer, setelah gula larut baru masukkan tepung dan sedikit garam"
- "Setelah semuax tercampur rata baru masukkan bahan B yg sudah dingin sambil terus di mixer sampai semuax tercampur rata"
- "Panaskan kukusan, sambil lalu mengolesi cetakan kue dengan minyak agar tidak lengket,(saya pakek cetakan kue talam)"
- "Masukkan campuran adonan B danC terlebih dahulu sepertiga cetakan baru kemudian kita semprotkan adonan A ditengah2 adonan hijau tdi, begitu seterusnya"
- "Setelah tempat pengukusan sudah siap masukkan adonan yg sudah dicetak tunggu 20 menit"
- "Setelah 20 menit cek angkat dan sajikan"
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 218 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dessert

---


![Nona manis](https://img-global.cpcdn.com/recipes/19410e6a175b15ee/680x482cq70/nona-manis-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita lestarikan karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti nona manis yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa ciri khas yang merupakan keragaman Kita



Keharmonisan keluarga bisa didapat dengan cara simple. Salah satunya adalah memasak Nona manis untuk keluarga. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang bisa anda contoh salah satunya nona manis yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep nona manis tanpa harus bersusah payah.
Berikut ini resep Nona manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 9 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona manis:

1. Harus ada  Bahan A
1. Harus ada 500 ml santan (kekentalan sedang)
1. Harap siapkan 60 gr tepung terigu
1. Jangan lupa  Bahan B
1. Dibutuhkan 500 ml santan
1. Diperlukan 50 gr tepung maizena
1. Diperlukan 100 gr gula pasir
1. Harus ada secukupnya Pasta pandan
1. Diperlukan 600 ml santan
1. Harus ada 400 gr tepung terigu
1. Harus ada 150 gr gula pasir
1. Siapkan Sejumput garam
1. Siapkan 3 butir telur utuh




<!--inarticleads2-->

##### Bagaimana membuat  Nona manis:

1. Memasak bahan B terlebih dahulu, cempur semua bahan B masak sampai meletu-letup angkat dan dinginkan
1. Sambil nunggu bahan B dingin, kita masak bahan A, campur semua bahan A masak sampai meletup-letup angkat dan biarkan agak sedikit hangat baru masukkan kedalam plastik segi tiga agar lebih mudah
1. Sekarang kita olah bahan C, campurkan telur dan gula di baskom yg agak besar lalu di mixer sampai gula agak larut
1. Setelah itu masukkan santan sambil terus di mixer, setelah gula larut baru masukkan tepung dan sedikit garam
1. Setelah semuax tercampur rata baru masukkan bahan B yg sudah dingin sambil terus di mixer sampai semuax tercampur rata
1. Panaskan kukusan, sambil lalu mengolesi cetakan kue dengan minyak agar tidak lengket,(saya pakek cetakan kue talam)
1. Masukkan campuran adonan B danC terlebih dahulu sepertiga cetakan baru kemudian kita semprotkan adonan A ditengah2 adonan hijau tdi, begitu seterusnya
1. Setelah tempat pengukusan sudah siap masukkan adonan yg sudah dicetak tunggu 20 menit
1. Setelah 20 menit cek angkat dan sajikan




Demikianlah cara membuat nona manis yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
