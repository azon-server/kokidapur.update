---
description: "Bagaimana untuk membuat Kue Nona Manis Favorite"
title: "Bagaimana untuk membuat Kue Nona Manis Favorite"
slug: 328-bagaimana-untuk-membuat-kue-nona-manis-favorite
date: 2020-12-21T05:57:00.854Z
image: https://img-global.cpcdn.com/recipes/f358d59762c71a25/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f358d59762c71a25/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f358d59762c71a25/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Jared Morris
ratingvalue: 5
reviewcount: 30732
recipeingredient:
- " Lapisan hijau A"
- "250 gr tepung terigu"
- "250 gr gula pasir"
- "18 gr tepung beras"
- "17 gr tepung maizena"
- "2 butir telur"
- "1000 ml santan sedang matang"
- "Sejumput vanili bubuk"
- "3 tetes pasta pandan santan 50ml pandan asli lebih bgs"
- " Lapisan putih B"
- "18 gr tepung beras"
- "17 gr tepung maizena"
- "300 ml santan kental"
- "1/4 sdt garam"
recipeinstructions:
- "Membuat lapisan hijau; Campurkan semua bahan A, mixer sebentar sampai adonan larut dan licin (saya pakai whisk aja) saring. Sisihkan"
- "Lapisan putih; Campurkan semua bahan B aduk rata masak dengan api kecil sambil terus diaduk sampai mengental dan licin. Sisihkan"
- "Cetakan mawar--- tuang 1 sdt adonan putih lalu tambahkan adonan hijau sampai penuh Cetakan kue talam---- tuang 3/4 adonan hijau lalu tambahkan adonan putih 1 sdt"
- "Kukus selama 25 menit (pastikan kukusan panas dan tutupnya dialasi serbet/kain bersih) angkat dan diamkan suhu ruang baru lepas dari cetakan"
- "Sajikan... Yummy. Lebih enak disimpan dulu di kulkas biar dingin (sesuai selera aja ya) *Happy Cooking Ummah*"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 140 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT39M"
recipeyield: "1"
recipecategory: Dessert

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/f358d59762c71a25/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan empuk. Karasteristik kuliner Indonesia kue nona manis yang penuh dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah memasak Kue Nona Manis untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang bisa anda praktekkan salah satunya kue nona manis yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Dibutuhkan  Lapisan hijau (A);
1. Harap siapkan 250 gr tepung terigu
1. Harap siapkan 250 gr gula pasir
1. Diperlukan 18 gr tepung beras
1. Dibutuhkan 17 gr tepung maizena
1. Harap siapkan 2 butir telur
1. Dibutuhkan 1000 ml santan sedang matang
1. Siapkan Sejumput vanili bubuk
1. Diperlukan 3 tetes pasta pandan+ santan 50ml (pandan asli lebih bgs)
1. Dibutuhkan  Lapisan putih (B);
1. Dibutuhkan 18 gr tepung beras
1. Jangan lupa 17 gr tepung maizena
1. Jangan lupa 300 ml santan kental
1. Jangan lupa 1/4 sdt garam




<!--inarticleads2-->

##### Cara membuat  Kue Nona Manis:

1. Membuat lapisan hijau; Campurkan semua bahan A, mixer sebentar sampai adonan larut dan licin (saya pakai whisk aja) saring. Sisihkan
1. Lapisan putih; Campurkan semua bahan B aduk rata masak dengan api kecil sambil terus diaduk sampai mengental dan licin. Sisihkan
1. Cetakan mawar--- tuang 1 sdt adonan putih lalu tambahkan adonan hijau sampai penuh - Cetakan kue talam---- tuang 3/4 adonan hijau lalu tambahkan adonan putih 1 sdt
1. Kukus selama 25 menit (pastikan kukusan panas dan tutupnya dialasi serbet/kain bersih) angkat dan diamkan suhu ruang baru lepas dari cetakan
1. Sajikan... Yummy. Lebih enak disimpan dulu di kulkas biar dingin (sesuai selera aja ya) *Happy Cooking Ummah*




Demikianlah cara membuat kue nona manis yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan cepat, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
