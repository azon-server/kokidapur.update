---
description: "Bagaimana untuk menyiapakan Kue Talam / Kue nona manis Luar biasa"
title: "Bagaimana untuk menyiapakan Kue Talam / Kue nona manis Luar biasa"
slug: 377-bagaimana-untuk-menyiapakan-kue-talam-kue-nona-manis-luar-biasa
date: 2021-02-18T20:19:47.390Z
image: https://img-global.cpcdn.com/recipes/dd2a7ee1e61a53f8/680x482cq70/kue-talam-kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dd2a7ee1e61a53f8/680x482cq70/kue-talam-kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dd2a7ee1e61a53f8/680x482cq70/kue-talam-kue-nona-manis-foto-resep-utama.jpg
author: Jason Sparks
ratingvalue: 4.3
reviewcount: 36759
recipeingredient:
- " Bahan A"
- "250 ml santan 2 bks santan kara 65 ml  1 gelas kecil air matang"
- "5 sdm gula pasir"
- "3 sdm tepung maizena"
- "1/4 sdt garam"
- "2 tetes pandan"
- " Bahan B "
- "1 butir telur"
- "8 sdm gula pasir kalau suka manis boleh ditmbah"
- "200 ml santan 1 bks kara 65 ml  1 gelas kecil air matang"
- "150 gr tepung terigu"
- " Bahan C "
- "200 ml santan kara  1 gelas kecil air matang"
- "1 sdm tepung terigu"
- "1 sdm gula pasir"
- "1/2 sdt garam"
recipeinstructions:
- "Campur smua bahan A. Masak dengan api kecil hingga mengental dan meletup&#34;. Nb : aduk terus supaya tdk cpt gosong"
- "Bahan B. Mixer telur dan gula hingga halus (tidak perlu mengembang sprti adonan bolu) selama krg lbh 10 mnt. Lalu tmbhkan gula dan santan. Mixer kmbali hingga rata. Tambahkan bahan A tadi kedalam adonan B, mixer sebentar. Kemudian saring."
- "Masak bahan c smpai sdikit kental dan meletup&#34;. Taruh didalam botol kecap atau di piping bag."
- "Panaskan kukusan. Selagi menunggu kukusan panas. Siapkan cetakan. Olesi dengan minyak goreng (oles tipis aja). Masukkan adonan hijau (jangan smpai cetakan penuh, cukup 3/4 saja). Kemudian selipkan adonan putih di tengahnya. Lakukan hingga adonan habis."
- "Kukus selama 10 - 15 menit. Angkat dan sajikan 😉"
- "Jangan lupa setor recooknya yaah adik kakak dan bunda 😇😁"
categories:
- Recipe
tags:
- kue
- talam
- 

katakunci: kue talam  
nutrition: 188 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dessert

---


![Kue Talam / Kue nona manis](https://img-global.cpcdn.com/recipes/dd2a7ee1e61a53f8/680x482cq70/kue-talam-kue-nona-manis-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang patut kita jaga karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti kue talam / kue nona manis yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara



Kedekatan rumah tangga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Kue Talam / Kue nona manis untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang bisa anda buat salah satunya kue talam / kue nona manis yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep kue talam / kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Talam / Kue nona manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Talam / Kue nona manis:

1. Harus ada  Bahan A:
1. Harap siapkan 250 ml santan (2 bks santan kara 65 ml + 1 gelas kecil air matang
1. Tambah 5 sdm gula pasir
1. Siapkan 3 sdm tepung maizena
1. Dibutuhkan 1/4 sdt garam
1. Dibutuhkan 2 tetes pandan
1. Diperlukan  Bahan B :
1. Siapkan 1 butir telur
1. Tambah 8 sdm gula pasir (kalau suka manis boleh ditmbah)
1. Diperlukan 200 ml santan (1 bks kara 65 ml + 1 gelas kecil air matang)
1. Harus ada 150 gr tepung terigu
1. Siapkan  Bahan C :
1. Harap siapkan 200 ml santan kara + 1 gelas kecil air matang
1. Dibutuhkan 1 sdm tepung terigu
1. Harap siapkan 1 sdm gula pasir
1. Dibutuhkan 1/2 sdt garam




<!--inarticleads2-->

##### Bagaimana membuat  Kue Talam / Kue nona manis:

1. Campur smua bahan A. Masak dengan api kecil hingga mengental dan meletup&#34;. Nb : aduk terus supaya tdk cpt gosong
1. Bahan B. Mixer telur dan gula hingga halus (tidak perlu mengembang sprti adonan bolu) selama krg lbh 10 mnt. Lalu tmbhkan gula dan santan. Mixer kmbali hingga rata. Tambahkan bahan A tadi kedalam adonan B, mixer sebentar. Kemudian saring.
1. Masak bahan c smpai sdikit kental dan meletup&#34;. Taruh didalam botol kecap atau di piping bag.
1. Panaskan kukusan. Selagi menunggu kukusan panas. Siapkan cetakan. Olesi dengan minyak goreng (oles tipis aja). Masukkan adonan hijau (jangan smpai cetakan penuh, cukup 3/4 saja). Kemudian selipkan adonan putih di tengahnya. Lakukan hingga adonan habis.
1. Kukus selama 10 - 15 menit. Angkat dan sajikan 😉
1. Jangan lupa setor recooknya yaah adik kakak dan bunda 😇😁




Demikianlah cara membuat kue talam / kue nona manis yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
