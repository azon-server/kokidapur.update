---
description: "Cara singkat menyiapakan Pentol Kanji ala Nona Kentir Cepat"
title: "Cara singkat menyiapakan Pentol Kanji ala Nona Kentir Cepat"
slug: 440-cara-singkat-menyiapakan-pentol-kanji-ala-nona-kentir-cepat
date: 2021-01-18T12:34:16.471Z
image: https://img-global.cpcdn.com/recipes/250c194cb0a52ff8/680x482cq70/pentol-kanji-ala-nona-kentir-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/250c194cb0a52ff8/680x482cq70/pentol-kanji-ala-nona-kentir-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/250c194cb0a52ff8/680x482cq70/pentol-kanji-ala-nona-kentir-foto-resep-utama.jpg
author: Milton Bryant
ratingvalue: 4.9
reviewcount: 38367
recipeingredient:
- " bahan cilok"
- "500 gr tepung tapioka kanji rose brand"
- "1 ons tepung terigu"
- "3 helai daun bawang"
- "4 siung bawang putih"
- "Secukupnya garam"
- "1 sachet royco sapi"
- "1 sdt lada bubuk ladaku"
- " Bisa tambah daging sapi kebetulan nemu dikulkas "
- "Secukupnya Air hangat"
- " Bahan kuah rebusan cilok"
- "1/2 panci air"
- "2 helai daun bawang"
- "3 siung bawang putih"
- " Bahan bumbu cilok"
- "Sesuai selera cabe rawit"
- "5 siung bawang merah"
- "4 siung bawang putih"
- "3 helai daun bawang"
- "Secukupnya kecap manis"
- "1 sdm saus tiram"
- "Secukupnya garam ladaku dan royco sapi"
recipeinstructions:
- "Pertama. Utk rebusan ciloknya, Panaskan air dipanci. Geprek bawang putih, iris daun bawang. Kalau sudah mendidih, masukkan bawang putih dan daun bawang tsb. Matikan kompor."
- "Utk adonan cilok: uleg bawang putih, garam, lada bubuk, royco da daging sapi."
- "Siapkan loyang. Masukkan tepung kanji, tepung terigu, daun bawang yg sudah di iris kecil2, dan bumbu uleg tadi. Uleni dg air panas hingga kalis dan bisa dibentuk bulat."
- "Bentuk bulat2 sesuai selera. Jgn lupa wadah utk cilok yg sudah dibentuk lumuri minyak spy tidak lengket. Nah ini cilok yg lonjong, ada isinya: cabe rawit 😁 bebas lah sesuka ade2. kalau sudah selesai dibentuk. Didihkan rebusan cilok td. Masukkan smw cilok. Tunggu sampai matang (muncul di permukaan air) saring."
- "Panaskan minyak. Tumis cabe rawit, bawang merah, bawang putih hingga harum. Masukkan cilok. Tambahkan kecap manis, tambahkan saos tiram. Masukkan daun bawang. Cek rasa. Sajikan."
categories:
- Recipe
tags:
- pentol
- kanji
- ala

katakunci: pentol kanji ala 
nutrition: 155 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Dessert

---


![Pentol Kanji ala Nona Kentir](https://img-global.cpcdn.com/recipes/250c194cb0a52ff8/680x482cq70/pentol-kanji-ala-nona-kentir-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang patut kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti pentol kanji ala nona kentir yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa ciri khas yang merupakan keragaman Indonesia



Kehangatan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Pentol Kanji ala Nona Kentir untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang bisa anda contoh salah satunya pentol kanji ala nona kentir yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep pentol kanji ala nona kentir tanpa harus bersusah payah.
Berikut ini resep Pentol Kanji ala Nona Kentir yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 22 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Pentol Kanji ala Nona Kentir:

1. Harus ada  bahan cilok**
1. Harap siapkan 500 gr tepung tapioka/ kanji (rose brand)
1. Diperlukan 1 ons tepung terigu
1. Siapkan 3 helai daun bawang
1. Siapkan 4 siung bawang putih
1. Harus ada Secukupnya garam
1. Harap siapkan 1 sachet royco sapi
1. Harap siapkan 1 sdt lada bubuk (ladaku)
1. Siapkan  Bisa tambah daging sapi (kebetulan nemu dikulkas) 😊
1. Jangan lupa Secukupnya Air hangat
1. Dibutuhkan  Bahan kuah rebusan cilok**
1. Diperlukan 1/2 panci air
1. Diperlukan 2 helai daun bawang
1. Dibutuhkan 3 siung bawang putih
1. Harus ada  Bahan bumbu cilok**
1. Dibutuhkan Sesuai selera cabe rawit
1. Diperlukan 5 siung bawang merah
1. Jangan lupa 4 siung bawang putih
1. Diperlukan 3 helai daun bawang
1. Harap siapkan Secukupnya kecap manis
1. Harus ada 1 sdm saus tiram
1. Siapkan Secukupnya garam, ladaku dan royco sapi




<!--inarticleads2-->

##### Instruksi membuat  Pentol Kanji ala Nona Kentir:

1. Pertama. Utk rebusan ciloknya, Panaskan air dipanci. Geprek bawang putih, iris daun bawang. Kalau sudah mendidih, masukkan bawang putih dan daun bawang tsb. Matikan kompor.
1. Utk adonan cilok: uleg bawang putih, garam, lada bubuk, royco da daging sapi.
1. Siapkan loyang. Masukkan tepung kanji, tepung terigu, daun bawang yg sudah di iris kecil2, dan bumbu uleg tadi. Uleni dg air panas hingga kalis dan bisa dibentuk bulat.
1. Bentuk bulat2 sesuai selera. Jgn lupa wadah utk cilok yg sudah dibentuk lumuri minyak spy tidak lengket. Nah ini cilok yg lonjong, ada isinya: cabe rawit 😁 bebas lah sesuka ade2. kalau sudah selesai dibentuk. Didihkan rebusan cilok td. Masukkan smw cilok. Tunggu sampai matang (muncul di permukaan air) saring.
1. Panaskan minyak. Tumis cabe rawit, bawang merah, bawang putih hingga harum. Masukkan cilok. Tambahkan kecap manis, tambahkan saos tiram. Masukkan daun bawang. Cek rasa. Sajikan.




Demikianlah cara membuat pentol kanji ala nona kentir yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
