---
description: "Resep : Nona manis (talam pandan) teraktual"
title: "Resep : Nona manis (talam pandan) teraktual"
slug: 368-resep-nona-manis-talam-pandan-teraktual
date: 2020-09-21T11:08:10.577Z
image: https://img-global.cpcdn.com/recipes/77997a2b004a912d/680x482cq70/nona-manis-talam-pandan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/77997a2b004a912d/680x482cq70/nona-manis-talam-pandan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/77997a2b004a912d/680x482cq70/nona-manis-talam-pandan-foto-resep-utama.jpg
author: Delia Jackson
ratingvalue: 4.1
reviewcount: 40972
recipeingredient:
- " Bahan A"
- "8 lembar daun pandan"
- "2 gelas santan"
- "1/2 gelas gula"
- "1/2 gelas maizena"
- "secukupnya Pasta pandan"
- "sedikit Garam"
- " Bahan B "
- "1 gelas gula"
- "3 butir telur"
- "2 gelas terigu"
- "2 gelas santan"
- " Bahan C "
- "2 gelas santan"
- "2 sdm gula"
- "2 sdm terigu"
- "Sedikit garam"
recipeinstructions:
- "Buat bahan A."
- "Blender daun panda dengan sebagia santan. Lau peras. Ukur lagi santan pandan menjadi 2 gelas. Rebus semua bahan A, denga api kecil hingga mengental. Sisihkan"
- "Buat bahan C. Rebus semua bahan C dengan api kecil. Sisihkan."
- "Buat bahan B. Mixer telur dan gula hingga megembang. Lalu masukan terigu sedikit demi sedikit. Lalu masukan santan."
- "Mixer lagi lau masukan bahan A. Aduk hingga rata."
- "Siakan cetakan cucing. Oles minyak tipis. Siapkan juga dandang kukusan. Tutupnya diberi alas kan yaa."
- "Penyelesaian. Ambil adonan hijau. Tuang dicetakan 3/4 cetakan. Lalu beri adonan putih ditengahnya. Kukus. Laukan hingga habis."
categories:
- Recipe
tags:
- nona
- manis
- talam

katakunci: nona manis talam 
nutrition: 168 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dinner

---


![Nona manis (talam pandan)](https://img-global.cpcdn.com/recipes/77997a2b004a912d/680x482cq70/nona-manis-talam-pandan-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau renyah. Ciri kuliner Nusantara nona manis (talam pandan) yang kaya dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan keluarga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Nona manis (talam pandan) untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang dapat anda coba salah satunya nona manis (talam pandan) yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep nona manis (talam pandan) tanpa harus bersusah payah.
Seperti resep Nona manis (talam pandan) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona manis (talam pandan):

1. Siapkan  Bahan A
1. Tambah 8 lembar daun pandan
1. Dibutuhkan 2 gelas santan
1. Dibutuhkan 1/2 gelas gula
1. Tambah 1/2 gelas maizena
1. Dibutuhkan secukupnya Pasta pandan
1. Harap siapkan sedikit Garam
1. Dibutuhkan  Bahan B :
1. Siapkan 1 gelas gula
1. Jangan lupa 3 butir telur
1. Tambah 2 gelas terigu
1. Harus ada 2 gelas santan
1. Dibutuhkan  Bahan C :
1. Siapkan 2 gelas santan
1. Diperlukan 2 sdm gula
1. Siapkan 2 sdm terigu
1. Dibutuhkan Sedikit garam




<!--inarticleads2-->

##### Langkah membuat  Nona manis (talam pandan):

1. Buat bahan A.
1. Blender daun panda dengan sebagia santan. Lau peras. Ukur lagi santan pandan menjadi 2 gelas. Rebus semua bahan A, denga api kecil hingga mengental. Sisihkan
1. Buat bahan C. Rebus semua bahan C dengan api kecil. Sisihkan.
1. Buat bahan B. Mixer telur dan gula hingga megembang. Lalu masukan terigu sedikit demi sedikit. Lalu masukan santan.
1. Mixer lagi lau masukan bahan A. Aduk hingga rata.
1. Siakan cetakan cucing. Oles minyak tipis. Siapkan juga dandang kukusan. Tutupnya diberi alas kan yaa.
1. Penyelesaian. Ambil adonan hijau. Tuang dicetakan 3/4 cetakan. Lalu beri adonan putih ditengahnya. Kukus. Laukan hingga habis.




Demikianlah cara membuat nona manis (talam pandan) yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan teruji, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
