---
description: "Cara membuat Chicken Teriyaki ala Nona Kentir Sempurna"
title: "Cara membuat Chicken Teriyaki ala Nona Kentir Sempurna"
slug: 450-cara-membuat-chicken-teriyaki-ala-nona-kentir-sempurna
date: 2021-01-26T06:35:02.670Z
image: https://img-global.cpcdn.com/recipes/e05f427026635fe0/680x482cq70/chicken-teriyaki-ala-nona-kentir-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e05f427026635fe0/680x482cq70/chicken-teriyaki-ala-nona-kentir-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e05f427026635fe0/680x482cq70/chicken-teriyaki-ala-nona-kentir-foto-resep-utama.jpg
author: Louise Ingram
ratingvalue: 4
reviewcount: 25710
recipeingredient:
- "1/2 kg ayam segar 15k"
- "1 bh paprika merah warna lain boleh tapi cantik merah 13k"
- "1 bh bawang bombay 2k"
- "3 bh helai daun bawang"
- "3 siung bawang putih"
- "1 cm jahe"
- "2 sachet saos teriyaki saori 6k"
- "2 sachet saos tiram saori 5k"
- "Secukupnya kecap manis"
- "Secukupnya minyak wijen"
- "Secukupnya wijen krn hanya buat topping ngambil wijen dr onde"
- "50 ml air"
- "Secukupnya garam"
- "Secukupnya gula pasir"
- "Secukupnya kaldu sapi bubuk saya pake pronas cornet aja secuil"
recipeinstructions:
- "Kupas, cuci bersih, dan iris: paprika, daun bawang dan bawang bombay. Untuk bawang putih (digeprek), jahe (digeprek)."
- "Masukkan minyak wijen, saos teriyaki, saos tiram, sebagian bawang bombay yang sudah diiris dan jahe kedalam adonan ayam yang sudah dicuci dan dipotong bentuk dadu atau sesuai selera. Aduk rata. (Diamkan selama 15-20 menit, supaya bumbu meresap)."
- "Larutkan kaldu sapi bubuk kedalam 50 ml air, tambakan garam dan gula secukupnya sedikit saja supaya tidak mengubah rasa khas saos teriyakinya."
- "Panaskan minyak diatas teflon, tumis bawang putih dan bawang bombay sanpai harum. Masukkan larutan kaldu sapi bubuk. Masukkan adonan ayam. Tambahkan kecap manis. Masukkan daun bawang. Aduk rata. Cek rasa. Tunggu hingga matang dan mengental."
- "Sajikan dengan taburan wijen sebagai topping."
categories:
- Recipe
tags:
- chicken
- teriyaki
- ala

katakunci: chicken teriyaki ala 
nutrition: 292 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Dinner

---


![Chicken Teriyaki ala Nona Kentir](https://img-global.cpcdn.com/recipes/e05f427026635fe0/680x482cq70/chicken-teriyaki-ala-nona-kentir-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti chicken teriyaki ala nona kentir yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Kita

Keharmonisan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Chicken Teriyaki ala Nona Kentir untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang bisa anda contoh salah satunya chicken teriyaki ala nona kentir yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep chicken teriyaki ala nona kentir tanpa harus bersusah payah.
Seperti resep Chicken Teriyaki ala Nona Kentir yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Chicken Teriyaki ala Nona Kentir:

1. Harus ada 1/2 kg ayam segar (15k)
1. Harap siapkan 1 bh paprika merah (warna lain boleh, tapi cantik merah) (13k)
1. Harap siapkan 1 bh bawang bombay (2k)
1. Siapkan 3 bh helai daun bawang
1. Diperlukan 3 siung bawang putih
1. Diperlukan 1 cm jahe
1. Tambah 2 sachet saos teriyaki (saori) (6k)
1. Tambah 2 sachet saos tiram (saori) (5k)
1. Harap siapkan Secukupnya kecap manis
1. Harus ada Secukupnya minyak wijen
1. Jangan lupa Secukupnya wijen (krn hanya buat topping, ngambil wijen dr onde-
1. Diperlukan 50 ml air
1. Dibutuhkan Secukupnya garam
1. Siapkan Secukupnya gula pasir
1. Harus ada Secukupnya kaldu sapi bubuk (saya pake pronas cornet aja secuil)




<!--inarticleads2-->

##### Instruksi membuat  Chicken Teriyaki ala Nona Kentir:

1. Kupas, cuci bersih, dan iris: paprika, daun bawang dan bawang bombay. Untuk bawang putih (digeprek), jahe (digeprek).
1. Masukkan minyak wijen, saos teriyaki, saos tiram, sebagian bawang bombay yang sudah diiris dan jahe kedalam adonan ayam yang sudah dicuci dan dipotong bentuk dadu atau sesuai selera. Aduk rata. (Diamkan selama 15-20 menit, supaya bumbu meresap).
1. Larutkan kaldu sapi bubuk kedalam 50 ml air, tambakan garam dan gula secukupnya sedikit saja supaya tidak mengubah rasa khas saos teriyakinya.
1. Panaskan minyak diatas teflon, tumis bawang putih dan bawang bombay sanpai harum. Masukkan larutan kaldu sapi bubuk. Masukkan adonan ayam. Tambahkan kecap manis. Masukkan daun bawang. Aduk rata. Cek rasa. Tunggu hingga matang dan mengental.
1. Sajikan dengan taburan wijen sebagai topping.




Demikianlah cara membuat chicken teriyaki ala nona kentir yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
