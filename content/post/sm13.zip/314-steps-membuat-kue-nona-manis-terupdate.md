---
description: "Steps membuat Kue Nona Manis terupdate"
title: "Steps membuat Kue Nona Manis terupdate"
slug: 314-steps-membuat-kue-nona-manis-terupdate
date: 2021-02-15T21:39:55.497Z
image: https://img-global.cpcdn.com/recipes/77279d54f1d5241f/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/77279d54f1d5241f/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/77279d54f1d5241f/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Ophelia Stone
ratingvalue: 4.3
reviewcount: 36253
recipeingredient:
- " Bahan 1 "
- "50 grm gula pasir"
- "500 ml Santan kental"
- "3 sdm tepung maizena"
- "1/4 sdt garam"
- "Secukupnya pasta pandan"
- " Bahan 2 "
- "500 ml Santan kental"
- "3 sdm tepung maizena"
- "Secukupnya garam"
- " Bahan 3 "
- "2 butir telur"
- "250 grm Tepung terigu"
- "60 grm Tepung maizena"
- "500 ml Santan kental"
- "200 grm gula pasir"
recipeinstructions:
- "Masukkan semua bahan 1 (adonan hijau) ke panci, nyalakan api kecil dan masak hingga meletup2 sambil terus diaduk. Angkat dinginkan"
- "Campurkan semua bahan 2 di panci lain, masak sambil terus diaduk hingga mengental dan meletup2 matikan api. Biarkan hingga uap hilang lalu masukkan ke dalam piping bag /botol kecap supaya mudah dituangkan."
- "Siapkan baskom, kocok telur &amp; gula hingga larut lalu Masukan duo tepung dan Santan bertahap selang seling sambil dimixer sampai tidak bergerindil."
- "Masukkan bahan 1 (adonan hijau) ke bahan 3 sambil dimixer hingga tercampur rata. (Hasil adonan akan encer)"
- "Tuang adonan hijau 3/4 cetakan, sebelumnya jangan lupa olesi cetakan dg sedikit minyak. Lalu tuang adonan putih diatasnya"
- "Kukus selama 10 menit dengan api besar. Tutup dandang jangan lupa ditutup agar uap air tidak menetes di adonan. Setelah matang tunggu uap panasnya hilang baru keluarkan kue dg bantuan sendok."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 256 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Lunch

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/77279d54f1d5241f/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau empuk. Ciri khas makanan Indonesia kue nona manis yang kaya dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga bisa didapat dengan cara simple. Diantaranya adalah memasak Kue Nona Manis untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang bisa anda praktekkan salah satunya kue nona manis yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis:

1. Harap siapkan  Bahan 1 :
1. Siapkan 50 grm gula pasir
1. Jangan lupa 500 ml Santan kental
1. Tambah 3 sdm tepung maizena
1. Jangan lupa 1/4 sdt garam
1. Dibutuhkan Secukupnya pasta pandan
1. Diperlukan  Bahan 2 :
1. Harus ada 500 ml Santan kental
1. Siapkan 3 sdm tepung maizena
1. Diperlukan Secukupnya garam
1. Siapkan  Bahan 3 :
1. Harap siapkan 2 butir telur
1. Tambah 250 grm Tepung terigu
1. Diperlukan 60 grm Tepung maizena
1. Jangan lupa 500 ml Santan kental
1. Harus ada 200 grm gula pasir




<!--inarticleads2-->

##### Cara membuat  Kue Nona Manis:

1. Masukkan semua bahan 1 (adonan hijau) ke panci, nyalakan api kecil dan masak hingga meletup2 sambil terus diaduk. Angkat dinginkan
1. Campurkan semua bahan 2 di panci lain, masak sambil terus diaduk hingga mengental dan meletup2 matikan api. Biarkan hingga uap hilang lalu masukkan ke dalam piping bag /botol kecap supaya mudah dituangkan.
1. Siapkan baskom, kocok telur &amp; gula hingga larut lalu Masukan duo tepung dan Santan bertahap selang seling sambil dimixer sampai tidak bergerindil.
1. Masukkan bahan 1 (adonan hijau) ke bahan 3 sambil dimixer hingga tercampur rata. (Hasil adonan akan encer)
1. Tuang adonan hijau 3/4 cetakan, sebelumnya jangan lupa olesi cetakan dg sedikit minyak. Lalu tuang adonan putih diatasnya
1. Kukus selama 10 menit dengan api besar. Tutup dandang jangan lupa ditutup agar uap air tidak menetes di adonan. Setelah matang tunggu uap panasnya hilang baru keluarkan kue dg bantuan sendok.




Demikianlah cara membuat kue nona manis yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan cepat, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
