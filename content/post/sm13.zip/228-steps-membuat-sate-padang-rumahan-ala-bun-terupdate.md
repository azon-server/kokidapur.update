---
description: "Steps membuat Sate padang rumahan ala bun terupdate"
title: "Steps membuat Sate padang rumahan ala bun terupdate"
slug: 228-steps-membuat-sate-padang-rumahan-ala-bun-terupdate
date: 2020-11-30T02:58:43.665Z
image: https://img-global.cpcdn.com/recipes/384e0b51cc735be0/680x482cq70/sate-padang-rumahan-ala-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/384e0b51cc735be0/680x482cq70/sate-padang-rumahan-ala-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/384e0b51cc735be0/680x482cq70/sate-padang-rumahan-ala-bun-foto-resep-utama.jpg
author: Maud Baker
ratingvalue: 4.4
reviewcount: 12758
recipeingredient:
- " Lidah rebus dari 1 buah lidah"
- "Lidi untuk menusuk"
- "5 sdm tepung beras"
- "1 liter air"
- " Bumbu halus"
- " 12 sdt jintan biji lada ketumbar"
- " 2 ruas kunyit sedikit jahe"
- "8 buah bamer 4 buah baput"
- "4 bh cabe keriting  rawit merah sesukanya"
- " Bahan rempah tumis"
- " Sereh lengkuas geprek salam daun kunyitdaun jeruk"
- " Pelengkap"
- " Lontongketupat dan bawang goreng"
recipeinstructions:
- "Siapkan bahan2, sangrai dulu semua bumbu halus sebelum dihaluskan (agar keluar aroma) kecuali cabai, haluskan dengan blender"
- "Tumis rempah tumis kecuali daun kunyit sampai wangi, masukan lidah rebus yang sudah disimpan"
- "Biarkan sampai agak menyerap lalu tambahkan air"
- "Apabila air sudah berkurang dan sudah meresap matikan lalu angkat lidah serta rempah2nya agar tersisa air saja, dan lidah siap Kita potong"
- "Potong lidah, lalu tusuk dgn tusuk satai, bakar agar ada efek burn..lalu panaskan kembali sisa kuah..dan beri air tepung beras yang sudah dipersiapkan"
- "Setelah bumbu mendidih masukan tepung beras, aduk terus sampe dia sangat mengental dan meletup. Angkat"
- "Potong2 lontong/ketupat tambahkan sate beri kuah dan taburi bawang goreng"
categories:
- Recipe
tags:
- sate
- padang
- rumahan

katakunci: sate padang rumahan 
nutrition: 155 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dessert

---


![Sate padang rumahan ala bun](https://img-global.cpcdn.com/recipes/384e0b51cc735be0/680x482cq70/sate-padang-rumahan-ala-bun-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga gurih. Ciri khas makanan Indonesia sate padang rumahan ala bun yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga bisa didapat dengan cara sederhana. Salah satunya adalah membuat makanan Sate padang rumahan ala bun untuk orang di rumah. Momen makan bersama anak sudah menjadi kultur, Banyak yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang bisa anda buat salah satunya sate padang rumahan ala bun yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep sate padang rumahan ala bun tanpa harus bersusah payah.
Berikut ini resep Sate padang rumahan ala bun yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 13 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sate padang rumahan ala bun:

1. Harap siapkan  Lidah rebus dari 1 buah lidah
1. Diperlukan Lidi untuk menusuk
1. Diperlukan 5 sdm tepung beras
1. Tambah 1 liter air
1. Tambah  Bumbu halus
1. Siapkan  1/2 sdt jintan, biji lada, ketumbar
1. Dibutuhkan  2 ruas kunyit, sedikit jahe
1. Jangan lupa 8 buah bamer 4 buah baput
1. Harus ada 4 bh cabe keriting + rawit merah (sesukanya)
1. Dibutuhkan  Bahan rempah tumis
1. Tambah  Sereh, lengkuas geprek, salam, daun kunyit,daun jeruk
1. Tambah  Pelengkap
1. Siapkan  Lontong/ketupat dan bawang goreng




<!--inarticleads2-->

##### Cara membuat  Sate padang rumahan ala bun:

1. Siapkan bahan2, sangrai dulu semua bumbu halus sebelum dihaluskan (agar keluar aroma) kecuali cabai, haluskan dengan blender
1. Tumis rempah tumis kecuali daun kunyit sampai wangi, masukan lidah rebus yang sudah disimpan
1. Biarkan sampai agak menyerap lalu tambahkan air
1. Apabila air sudah berkurang dan sudah meresap matikan lalu angkat lidah serta rempah2nya agar tersisa air saja, dan lidah siap Kita potong
1. Potong lidah, lalu tusuk dgn tusuk satai, bakar agar ada efek burn..lalu panaskan kembali sisa kuah..dan beri air tepung beras yang sudah dipersiapkan
1. Setelah bumbu mendidih masukan tepung beras, aduk terus sampe dia sangat mengental dan meletup. Angkat
1. Potong2 lontong/ketupat tambahkan sate beri kuah dan taburi bawang goreng




Demikianlah cara membuat sate padang rumahan ala bun yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
