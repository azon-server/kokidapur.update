---
description: "Panduan untuk membuat Kue Nona Manis Teruji"
title: "Panduan untuk membuat Kue Nona Manis Teruji"
slug: 405-panduan-untuk-membuat-kue-nona-manis-teruji
date: 2021-01-27T08:27:22.654Z
image: https://img-global.cpcdn.com/recipes/fb27e4e6a4cb74c8/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fb27e4e6a4cb74c8/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fb27e4e6a4cb74c8/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Violet Mullins
ratingvalue: 4.5
reviewcount: 23895
recipeingredient:
- "1 Bahan"
- "250 ml santan kental"
- "1 butir telur"
- "80 gr gula pasir"
- "140 gr terigu"
- "2 Bahan"
- "250 ml santan kental"
- "40 gr gula pasir"
- "30 gr maizena"
- "secukupnya pewarna"
- "sejumput garam"
- "3 Bahan"
- "500 ml santan kental"
- "6 sdm terigu"
- "sejumput garam"
recipeinstructions:
- "Mixer telur dan gula pasir sampai kental, kemudian tambahkan santan dan terigu bergantian sambil di mixer speed rendah"
- "Masak bahan 2 sampai mulai mengental, angkat dinginkan. Campur di bahan 1 dan mixer sampai tercampur"
- "Masak bahan 3 sampai terus diaduk agar tidak bergerindil, dinginkan tarih di piping bag"
- "Tuang adonan hijau di cetakan talam yang sudah di olesi minhak sebelumnya, kemudia semprotkan adonan putih yang sudah dimasukkan dalam piping bag ditengahnya (ujung piping bag agak di tenggelamkan di adonan)"
- "Lakukan langkah 4 sampai adonan habis, kukus dalam dandang yang sudah dilapisi kain pada penutupnya, kukus sekita 15-20 menit"
- "Kue nona manis siap diaajikan"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 209 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dinner

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/fb27e4e6a4cb74c8/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau enak. Ciri khas makanan Nusantara kue nona manis yang penuh dengan rempah memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Keharmonisan rumah tangga bisa didapat dengan cara simple. Diantaranya adalah memasak Kue Nona Manis untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang bisa anda coba salah satunya kue nona manis yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Siapkan 1 Bahan
1. Tambah 250 ml santan kental
1. Jangan lupa 1 butir telur
1. Dibutuhkan 80 gr gula pasir
1. Siapkan 140 gr terigu
1. Dibutuhkan 2 Bahan
1. Harap siapkan 250 ml santan kental
1. Harap siapkan 40 gr gula pasir
1. Harap siapkan 30 gr maizena
1. Diperlukan secukupnya pewarna
1. Diperlukan sejumput garam
1. Tambah 3 Bahan
1. Diperlukan 500 ml santan kental
1. Harap siapkan 6 sdm terigu
1. Tambah sejumput garam




<!--inarticleads2-->

##### Cara membuat  Kue Nona Manis:

1. Mixer telur dan gula pasir sampai kental, kemudian tambahkan santan dan terigu bergantian sambil di mixer speed rendah
1. Masak bahan 2 sampai mulai mengental, angkat dinginkan. Campur di bahan 1 dan mixer sampai tercampur
1. Masak bahan 3 sampai terus diaduk agar tidak bergerindil, dinginkan tarih di piping bag
1. Tuang adonan hijau di cetakan talam yang sudah di olesi minhak sebelumnya, kemudia semprotkan adonan putih yang sudah dimasukkan dalam piping bag ditengahnya (ujung piping bag agak di tenggelamkan di adonan)
1. Lakukan langkah 4 sampai adonan habis, kukus dalam dandang yang sudah dilapisi kain pada penutupnya, kukus sekita 15-20 menit
1. Kue nona manis siap diaajikan




Demikianlah cara membuat kue nona manis yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan cepat, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
