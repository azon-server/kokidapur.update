---
description: "Panduan untuk menyiapakan Wedang Angsle Cepat"
title: "Panduan untuk menyiapakan Wedang Angsle Cepat"
slug: 488-panduan-untuk-menyiapakan-wedang-angsle-cepat
date: 2020-12-14T13:28:17.740Z
image: https://img-global.cpcdn.com/recipes/ead708fc1d52f87a/680x482cq70/wedang-angsle-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ead708fc1d52f87a/680x482cq70/wedang-angsle-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ead708fc1d52f87a/680x482cq70/wedang-angsle-foto-resep-utama.jpg
author: Nelle Turner
ratingvalue: 4.8
reviewcount: 42586
recipeingredient:
- "1 cup beras ketan"
- "4 sdm sagu mutiara"
- "4 sdm kacang hijau"
- "3 lembar roti tawar"
- " Kacang bawang resep silakan lihat link ini           lihat resep"
- " Susu kental manis"
- " Bahan kuah"
- "2 bungkus santan bubuk Sasa kemasan 20 gram"
- "8 sdm gula pasir"
- "1/2 sdt garam"
- "2 bongkah jahe geprek"
- "1 liter air"
- " Daun pandan ikat simpul"
recipeinstructions:
- "Persiapkan bahan isian : 1. Masak beras ketan, beri sedikit garam 2. Masak kacang hijau 3. Masak sagu mutiara 4. Potong - potong roti tawar 5. Siapkan kacang bawang (bisa beli jadi atau buat sendiri, resep lihat link di bawah ini)  TIPS : Untuk menghemat waktu dan gas, masak kacang hijau dan sagu mutiara dengan metode 5.30.7, yaitu : - rebus kacang hijau/sagu mutiara selama 5 menit - matikan kompor (panci tetap ditutup), diamkan selama 30 menit - rebus kembali selama 7 menit atau hingga matang           (lihat resep)"
- "Buat kuah santan : Campur air, santan bubuk, gula pasir, garam dan jahe yang sudah digeprek. Beri daun pandan. Rebus sampai mendidih."
- "Tata dalam mangkok :  1 sdm ketan, 1 sdm kacang hijau, 1 sdm sagu mutiara, roti tawar, kacang bawang. Beri 1sdm susu kental manis. Tuang kuah santan. Sajikan hangat-hangat. Nikmat..."
categories:
- Recipe
tags:
- wedang
- angsle

katakunci: wedang angsle 
nutrition: 174 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Dessert

---


![Wedang Angsle](https://img-global.cpcdn.com/recipes/ead708fc1d52f87a/680x482cq70/wedang-angsle-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas atau gurih. Ciri khas makanan Indonesia wedang angsle yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kedekatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Wedang Angsle untuk keluarga. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang dapat anda contoh salah satunya wedang angsle yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep wedang angsle tanpa harus bersusah payah.
Berikut ini resep Wedang Angsle yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Wedang Angsle:

1. Siapkan 1 cup beras ketan
1. Diperlukan 4 sdm sagu mutiara
1. Siapkan 4 sdm kacang hijau
1. Harap siapkan 3 lembar roti tawar
1. Harus ada  Kacang bawang (resep silakan lihat link ini)           (lihat resep)
1. Siapkan  Susu kental manis
1. Siapkan  Bahan kuah
1. Harus ada 2 bungkus santan bubuk Sasa kemasan 20 gram
1. Harap siapkan 8 sdm gula pasir
1. Harus ada 1/2 sdt garam
1. Harus ada 2 bongkah jahe, geprek
1. Harus ada 1 liter air
1. Harap siapkan  Daun pandan, ikat simpul




<!--inarticleads2-->

##### Langkah membuat  Wedang Angsle:

1. Persiapkan bahan isian : - 1. Masak beras ketan, beri sedikit garam - 2. Masak kacang hijau - 3. Masak sagu mutiara - 4. Potong - potong roti tawar - 5. Siapkan kacang bawang (bisa beli jadi atau buat sendiri, resep lihat link di bawah ini) -  - TIPS : - Untuk menghemat waktu dan gas, masak kacang hijau dan sagu mutiara dengan metode 5.30.7, yaitu : - - rebus kacang hijau/sagu mutiara selama 5 menit - - matikan kompor (panci tetap ditutup), diamkan selama 30 menit - - rebus kembali selama 7 menit atau hingga matang -           (lihat resep)
1. Buat kuah santan : - Campur air, santan bubuk, gula pasir, garam dan jahe yang sudah digeprek. Beri daun pandan. Rebus sampai mendidih.
1. Tata dalam mangkok :  - 1 sdm ketan, 1 sdm kacang hijau, 1 sdm sagu mutiara, roti tawar, kacang bawang. Beri 1sdm susu kental manis. Tuang kuah santan. Sajikan hangat-hangat. Nikmat...




Demikianlah cara membuat wedang angsle yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan teruji, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
