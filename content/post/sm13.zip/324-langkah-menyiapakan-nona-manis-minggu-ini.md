---
description: "Langkah menyiapakan Nona Manis minggu ini"
title: "Langkah menyiapakan Nona Manis minggu ini"
slug: 324-langkah-menyiapakan-nona-manis-minggu-ini
date: 2021-01-07T21:29:00.358Z
image: https://img-global.cpcdn.com/recipes/7403496b2f10303b/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7403496b2f10303b/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7403496b2f10303b/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Luella Gutierrez
ratingvalue: 4.6
reviewcount: 18569
recipeingredient:
- " Bahan A"
- "2 gelas santan"
- "2 gelas tepung terigu"
- "1 gelas gula pasir"
- "3 butir telur"
- " Bahan B"
- "2 gelas air daun pandan"
- "1/2 gelas gula"
- "1/2 gelas maizena"
- " Bahan C"
- "2 gelas santan"
- "11/2 sdm gula pasir"
- "3 sdm tepung terigu"
- "1/2 sdt garam"
recipeinstructions:
- "Siapkan panci kukusan,(tutupnya di alasi serbet)dgn api sedang.Bahan A dikocok gula dan telur hingga berjejak masukkan tepung,santan aduk rata.sisikan"
- "Campurkan semua bahan B kemudian di masak hingga meletup letup"
- "Campurkan bahan A dan Bahan B aduk pakai mixer hingga rata."
- "Bahan C di campur semua aduk aduk jgn sampai menggumpal kemudian di masak hingga meletup letup,angkat"
- "Masukkan adonan kedalam cetakan yg sudah di olesi minyak setenggah bagian aja kemudian tambahkan adonan C dibagian tenggah secukupnya"
- "Kukus selama ±20 menit,angkat setelah dingin keluarkan dari cetakan,sajikan"
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 148 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT43M"
recipeyield: "3"
recipecategory: Lunch

---


![Nona Manis](https://img-global.cpcdn.com/recipes/7403496b2f10303b/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan empuk. Ciri makanan Nusantara nona manis yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Nona Manis untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang bisa anda coba salah satunya nona manis yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep nona manis tanpa harus bersusah payah.
Berikut ini resep Nona Manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona Manis:

1. Diperlukan  Bahan A:
1. Harus ada 2 gelas santan
1. Tambah 2 gelas tepung terigu
1. Harap siapkan 1 gelas gula pasir
1. Dibutuhkan 3 butir telur
1. Jangan lupa  Bahan B:
1. Harap siapkan 2 gelas air daun pandan
1. Dibutuhkan 1/2 gelas gula
1. Harap siapkan 1/2 gelas maizena
1. Harap siapkan  Bahan C:
1. Jangan lupa 2 gelas santan
1. Diperlukan 11/2 sdm gula pasir
1. Diperlukan 3 sdm tepung terigu
1. Jangan lupa 1/2 sdt garam




<!--inarticleads2-->

##### Langkah membuat  Nona Manis:

1. Siapkan panci kukusan,(tutupnya di alasi serbet)dgn api sedang.Bahan A dikocok gula dan telur hingga berjejak masukkan tepung,santan aduk rata.sisikan
1. Campurkan semua bahan B kemudian di masak hingga meletup letup
1. Campurkan bahan A dan Bahan B aduk pakai mixer hingga rata.
1. Bahan C di campur semua aduk aduk jgn sampai menggumpal kemudian di masak hingga meletup letup,angkat
1. Masukkan adonan kedalam cetakan yg sudah di olesi minyak setenggah bagian aja kemudian tambahkan adonan C dibagian tenggah secukupnya
1. Kukus selama ±20 menit,angkat setelah dingin keluarkan dari cetakan,sajikan




Demikianlah cara membuat nona manis yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan terbukti, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
