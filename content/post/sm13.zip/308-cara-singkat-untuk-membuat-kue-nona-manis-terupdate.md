---
description: "Cara singkat untuk membuat Kue Nona Manis terupdate"
title: "Cara singkat untuk membuat Kue Nona Manis terupdate"
slug: 308-cara-singkat-untuk-membuat-kue-nona-manis-terupdate
date: 2021-02-01T11:33:47.021Z
image: https://img-global.cpcdn.com/recipes/c205e4865a97db71/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c205e4865a97db71/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c205e4865a97db71/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Harriett Pearson
ratingvalue: 4.2
reviewcount: 5371
recipeingredient:
- " Bahan I "
- "500 ml santan kental"
- "6 sdm tepung terigu segitiga"
- "Sejumput garam"
- " Bahan II "
- "250 ml santan kental"
- "40 gram gula pasir"
- "30 gram maizena"
- "1 sdt pasta pandan"
- "Sejumput garam"
- " Bahan III "
- "250 ml santan kental"
- "1 butir telur"
- "80 gram gula pasir"
- "140 gram tepung terigu segitiga"
recipeinstructions:
- "Campur bahan I semua diwadah aduk sampai tidak bergerindil masak dalam api kecil sampai meletup&#34; halus ga bergerindil ya...angkat dinginkan..jika sdh dingin masukan ke piping bag ya..."
- "Campur semua bahan II pada wadah aduk rata lalu masak dalam api kecil sampai meletub..angkat sisihkan"
- "Kocok bahan III.,gula dan telur pakai whisk aja sampai gula larut lalu masukan tepung bergantian dengan santan aduk rata..."
- "Lalu masukan bahan II pada campuran telur tadi aduk rata..."
- "Panaskan kukusan...ambil cetakan olesi dengan minyak sedikit ya..isi 3/4 aja lalu beri adonan yg putih di tengah&#34; adonan..."
- "Kukus selama 10 sampai 15 menit ya bun..."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 122 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Dinner

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/c205e4865a97db71/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang patut kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti kue nona manis yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Nusantara

Kehangatan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Kue Nona Manis untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang dapat anda coba salah satunya kue nona manis yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 15 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Jangan lupa  Bahan I :
1. Tambah 500 ml santan kental
1. Dibutuhkan 6 sdm tepung terigu segitiga
1. Harap siapkan Sejumput garam
1. Tambah  Bahan II :
1. Tambah 250 ml santan kental
1. Diperlukan 40 gram gula pasir
1. Jangan lupa 30 gram maizena
1. Dibutuhkan 1 sdt pasta pandan
1. Jangan lupa Sejumput garam
1. Dibutuhkan  Bahan III :
1. Jangan lupa 250 ml santan kental
1. Harus ada 1 butir telur
1. Dibutuhkan 80 gram gula pasir
1. Diperlukan 140 gram tepung terigu segitiga




<!--inarticleads2-->

##### Langkah membuat  Kue Nona Manis:

1. Campur bahan I semua diwadah aduk sampai tidak bergerindil masak dalam api kecil sampai meletup&#34; halus ga bergerindil ya...angkat dinginkan..jika sdh dingin masukan ke piping bag ya...
1. Campur semua bahan II pada wadah aduk rata lalu masak dalam api kecil sampai meletub..angkat sisihkan
1. Kocok bahan III.,gula dan telur pakai whisk aja sampai gula larut lalu masukan tepung bergantian dengan santan aduk rata...
1. Lalu masukan bahan II pada campuran telur tadi aduk rata...
1. Panaskan kukusan...ambil cetakan olesi dengan minyak sedikit ya..isi 3/4 aja lalu beri adonan yg putih di tengah&#34; adonan...
1. Kukus selama 10 sampai 15 menit ya bun...




Demikianlah cara membuat kue nona manis yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
