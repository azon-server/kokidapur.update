---
description: "Steps membuat Kue nona manis Teruji"
title: "Steps membuat Kue nona manis Teruji"
slug: 332-steps-membuat-kue-nona-manis-teruji
date: 2021-01-14T20:49:50.690Z
image: https://img-global.cpcdn.com/recipes/52f6ac9f7c9c7229/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/52f6ac9f7c9c7229/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/52f6ac9f7c9c7229/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Florence Lawrence
ratingvalue: 4.2
reviewcount: 44274
recipeingredient:
- " Bahan jus pandan"
- "6 lembar daun pandan"
- "100 ml air"
- " Bahan A "
- "150 ml santan kekentalan sedang"
- "100 ml jus pandan"
- "40 gram gula pasir"
- "30 gram tepung maizena"
- "1/4 sdt garam"
- "1-2 tetes pasta pandan"
- " Bahan B "
- "140 gram tepung terigu segitiga"
- "250 ml santan kekentalan sedang"
- "1 butir telur"
- "80 gram gula pasir"
- " Bahan C "
- "500 ml santan kekentalan sedang"
- "6 sdm tepung terigu"
- "1/4 sdt garam"
recipeinstructions:
- "Blender bahan jus pandan, kemudian saring. Siapkan semua bahan yang akan dipakai."
- "Campur semua bahan A, aduk merata. Nyalakan api, masak hingga mengental dan meletup2. Sisihkan"
- "Kocok telur dan gula pasir (bahan B) hingga mengembang, tambahkan tepung terigu serta bahan A yg sudah dimasak. Mixer sampai tercampur rata."
- "Olesi cetakan dengan minyak goreng tipis saja. Masak bahan C sampai kental dan meletup2. Masukkan kedalam plastik segitiga, potong ujungnya."
- "Masukkan adonan (A+B) tadi, masukkan hingga 3/4 bagian,. Kemudian tusukkan bahan C kedalam adonan, tekan plastik segitiga, agar terisi bagian putihnya ditengah. Lakukan hingga adonan habis."
- "Panaskan kukusan terlebih dahulu, tutup kukusan diberi serbet. Masukkan adonan dalam cetakan ke kukusan. Kukus hingga 20 menit. Setelah dingin baru dikeluarkan dari cetakan."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 233 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT56M"
recipeyield: "3"
recipecategory: Dinner

---


![Kue nona manis](https://img-global.cpcdn.com/recipes/52f6ac9f7c9c7229/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis dan empuk. Karasteristik masakan Nusantara kue nona manis yang kaya dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga dapat didapat dengan cara simple. Diantaranya adalah memasak Kue nona manis untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.

Kue nona manis adalah salah satu jajanan tradisional yang melegenda di Indonesia. Ada yang tahu kue nona manis? SALAH satu jajanan pasar kue nona manis rasanya sudah jarang ditemui. Meski langkahnya sedikit rumit, ada rasa puas tersendiri saat berhasil membuat kue nona manis.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang dapat anda contoh salah satunya kue nona manis yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue nona manis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue nona manis:

1. Diperlukan  Bahan jus pandan:
1. Tambah 6 lembar daun pandan
1. Harus ada 100 ml air
1. Tambah  Bahan A :
1. Harap siapkan 150 ml santan, kekentalan sedang
1. Tambah 100 ml jus pandan
1. Jangan lupa 40 gram gula pasir
1. Tambah 30 gram tepung maizena
1. Tambah 1/4 sdt garam
1. Jangan lupa 1-2 tetes pasta pandan
1. Siapkan  Bahan B :
1. Siapkan 140 gram tepung terigu segitiga
1. Dibutuhkan 250 ml santan, kekentalan sedang
1. Tambah 1 butir telur
1. Tambah 80 gram gula pasir
1. Diperlukan  Bahan C :
1. Dibutuhkan 500 ml santan, kekentalan sedang
1. Siapkan 6 sdm tepung terigu
1. Dibutuhkan 1/4 sdt garam


Nona manis adalah kue khas Sulawesi. Teksturnya lebih lembut dari kue talam Indonesia lainnya. Bagian yang berwarna hijau rasanya manis dan gurih santan, sedangkan bagian yang berwarna putih. Aih, sudah lama rasanya tidak mendengar Kue Nona Manis. 

<!--inarticleads2-->

##### Langkah membuat  Kue nona manis:

1. Blender bahan jus pandan, kemudian saring. Siapkan semua bahan yang akan dipakai.
1. Campur semua bahan A, aduk merata. Nyalakan api, masak hingga mengental dan meletup2. Sisihkan
1. Kocok telur dan gula pasir (bahan B) hingga mengembang, tambahkan tepung terigu serta bahan A yg sudah dimasak. Mixer sampai tercampur rata.
1. Olesi cetakan dengan minyak goreng tipis saja. Masak bahan C sampai kental dan meletup2. Masukkan kedalam plastik segitiga, potong ujungnya.
1. Masukkan adonan (A+B) tadi, masukkan hingga 3/4 bagian,. Kemudian tusukkan bahan C kedalam adonan, tekan plastik segitiga, agar terisi bagian putihnya ditengah. Lakukan hingga adonan habis.
1. Panaskan kukusan terlebih dahulu, tutup kukusan diberi serbet. Masukkan adonan dalam cetakan ke kukusan. Kukus hingga 20 menit. Setelah dingin baru dikeluarkan dari cetakan.


Bagian yang berwarna hijau rasanya manis dan gurih santan, sedangkan bagian yang berwarna putih. Aih, sudah lama rasanya tidak mendengar Kue Nona Manis. Camilan klasik ini bisa Bunda hadirkan kembali dengan warna menarik yang tidak akan ditolak oleh si kecil. Your current browser isn&#39;t compatible with SoundCloud. Please download one of our supported browsers. 

Demikianlah cara membuat kue nona manis yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
