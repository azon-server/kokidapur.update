---
description: "Langkah untuk membuat Nona manis minggu ini"
title: "Langkah untuk membuat Nona manis minggu ini"
slug: 394-langkah-untuk-membuat-nona-manis-minggu-ini
date: 2020-10-18T03:28:45.208Z
image: https://img-global.cpcdn.com/recipes/befed39b9606bac8/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/befed39b9606bac8/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/befed39b9606bac8/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Lelia Flowers
ratingvalue: 4.2
reviewcount: 25130
recipeingredient:
- " Bahan 1 adonan putih"
- "500 ml santan kental saya memakai 2 sachet kara  65 ml ditambah air sampai 500 ml"
- "6 sdm tepung terigu"
- "1/2 sdt garam"
- " Bahan 2 adonan hijau"
- "250 ml santan blender dengan 3 helai daun pandan wangi dan 8 helai pandan suji saring"
- "40 gram gula pasir"
- "1/4 sdt garam"
- "30 gram maizena"
- " Bahan 3 adonan hijau"
- "90 gram gula pasir"
- "1 butir telur"
- "140 gram tepung terigu"
- "250 ml santan"
recipeinstructions:
- "Campur semua bahan 1, aduk rata sampai licin, masak hingga mengental. Dinginkan lalu masukkan dalam kantong segitiga."
- "Campur semua bahan 2, aduk2 sampai licin, lalu masak sampai mengental. Dinginkan."
- "Bahan 3: campur telur dengan gula pasir, aduk sampai mengental dan gula larut. Bisa dengan mixer atau baloonwhisk."
- "Masukkan tepung bergantian dengan santan, aduk sampai tercampur rata dan licin (jika memakai mixer gunakan speed rendah)."
- "Masukkan bahan 2 yang sudah dingin ke adonan bahan 3, aduk sampai rata."
- "Tuang adonan hijau pada cetakan talam yang sudah dioles minyak sampai 3/4 cetakan."
- "Semprotkan adonan putih di tengah adonan hijau sambil agak ditekan."
- "Lakukan sampai semua adonan habis."
- "Kukus adonan dalam dandang yang sudah dipanaskan terlebih dahulu selama kurang-lebih 10-15 menit."
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 225 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dessert

---


![Nona manis](https://img-global.cpcdn.com/recipes/befed39b9606bac8/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga empuk. Ciri khas makanan Indonesia nona manis yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.


Keharmonisan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah memasak Nona manis untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang dapat anda buat salah satunya nona manis yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep nona manis tanpa harus bersusah payah.
Berikut ini resep Nona manis yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 14 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona manis:

1. Harap siapkan  Bahan 1 (adonan putih):
1. Dibutuhkan 500 ml santan kental (saya memakai 2 sachet kara @ 65 ml ditambah air sampai 500 ml)
1. Harus ada 6 sdm tepung terigu
1. Tambah 1/2 sdt garam
1. Jangan lupa  Bahan 2 (adonan hijau):
1. Jangan lupa 250 ml santan blender dengan 3 helai daun pandan wangi dan 8 helai pandan suji, saring
1. Harus ada 40 gram gula pasir
1. Dibutuhkan 1/4 sdt garam
1. Jangan lupa 30 gram maizena
1. Jangan lupa  Bahan 3 (adonan hijau):
1. Siapkan 90 gram gula pasir
1. Harus ada 1 butir telur
1. Harap siapkan 140 gram tepung terigu
1. Harap siapkan 250 ml santan




<!--inarticleads2-->

##### Cara membuat  Nona manis:

1. Campur semua bahan 1, aduk rata sampai licin, masak hingga mengental. Dinginkan lalu masukkan dalam kantong segitiga.
1. Campur semua bahan 2, aduk2 sampai licin, lalu masak sampai mengental. Dinginkan.
1. Bahan 3: campur telur dengan gula pasir, aduk sampai mengental dan gula larut. Bisa dengan mixer atau baloonwhisk.
1. Masukkan tepung bergantian dengan santan, aduk sampai tercampur rata dan licin (jika memakai mixer gunakan speed rendah).
1. Masukkan bahan 2 yang sudah dingin ke adonan bahan 3, aduk sampai rata.
1. Tuang adonan hijau pada cetakan talam yang sudah dioles minyak sampai 3/4 cetakan.
1. Semprotkan adonan putih di tengah adonan hijau sambil agak ditekan.
1. Lakukan sampai semua adonan habis.
1. Kukus adonan dalam dandang yang sudah dipanaskan terlebih dahulu selama kurang-lebih 10-15 menit.




Demikianlah cara membuat nona manis yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
