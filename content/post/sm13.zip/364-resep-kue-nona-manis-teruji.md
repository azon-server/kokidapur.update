---
description: "Resep : Kue nona manis Teruji"
title: "Resep : Kue nona manis Teruji"
slug: 364-resep-kue-nona-manis-teruji
date: 2020-10-01T10:25:44.432Z
image: https://img-global.cpcdn.com/recipes/eab8c57488010219/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/eab8c57488010219/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/eab8c57488010219/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Ellen Casey
ratingvalue: 4.1
reviewcount: 14249
recipeingredient:
- " Bahan 1 "
- "3 butir telur"
- "1 cangkir gula pasir 222gr"
- "2 cangkir santan 384 ml"
- "2 cangkir terigu 214 gr"
- " Bahan 2 "
- "2 cangkir santandaun pandan diblender dgn sedikit santan384ml"
- "1/2 cangkir maizena 38gr"
- "1/2 cangkir gula pasir 111gr"
- "1/2 sdt garam"
- " Bahan 3 "
- "2 cangkir santan"
- "2 sdm terigu"
- "2 sdm gula pasir"
- "1/2 sdt garam"
recipeinstructions:
- "Campur bahan 2,masak sampe meletup-letup,angkat,sisihkan"
- "Mixer dgn kecepatan tinggi telur dan gula sampe mengembang,turunkan kecepatan mixer masukkan terigu,santan dan pasta pandan secara bergantian,masukkan adonan yg ke 2 mixer sampe tercampur,sisihkan"
- "Campur bahan 3 masak sampe meletup,angkat,dinginkan..Masukkan adonan ke dalam botol kecap"
- "Tuang adonan hijau 3/4 dicetakan cucing,masukkan adonan putih ditengah2ny"
- "Kukus 7-10 menit dengan api sedang"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 180 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Lunch

---


![Kue nona manis](https://img-global.cpcdn.com/recipes/eab8c57488010219/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti kue nona manis yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Kita

Kedekatan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Kue nona manis untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.

Kue nona manis adalah salah satu jajanan tradisional yang melegenda di Indonesia. Ada yang tahu kue nona manis? SALAH satu jajanan pasar kue nona manis rasanya sudah jarang ditemui. Meski langkahnya sedikit rumit, ada rasa puas tersendiri saat berhasil membuat kue nona manis.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang dapat anda praktekkan salah satunya kue nona manis yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue nona manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue nona manis:

1. Jangan lupa  Bahan 1 :
1. Tambah 3 butir telur
1. Dibutuhkan 1 cangkir gula pasir (222gr)
1. Tambah 2 cangkir santan (384 ml)
1. Harap siapkan 2 cangkir terigu (214 gr)
1. Jangan lupa  Bahan 2 :
1. Dibutuhkan 2 cangkir santan(daun pandan diblender dgn sedikit santan)=384ml
1. Dibutuhkan 1/2 cangkir maizena (38gr)
1. Tambah 1/2 cangkir gula pasir (111gr)
1. Diperlukan 1/2 sdt garam
1. Dibutuhkan  Bahan 3 :
1. Harus ada 2 cangkir santan
1. Dibutuhkan 2 sdm terigu
1. Jangan lupa 2 sdm gula pasir
1. Siapkan 1/2 sdt garam


Nona manis adalah kue khas Sulawesi. Teksturnya lebih lembut dari kue talam Indonesia lainnya. Bagian yang berwarna hijau rasanya manis dan gurih santan, sedangkan bagian yang berwarna putih. Aih, sudah lama rasanya tidak mendengar Kue Nona Manis. 

<!--inarticleads2-->

##### Instruksi membuat  Kue nona manis:

1. Campur bahan 2,masak sampe meletup-letup,angkat,sisihkan
1. Mixer dgn kecepatan tinggi telur dan gula sampe mengembang,turunkan kecepatan mixer masukkan terigu,santan dan pasta pandan secara bergantian,masukkan adonan yg ke 2 mixer sampe tercampur,sisihkan
1. Campur bahan 3 masak sampe meletup,angkat,dinginkan..Masukkan adonan ke dalam botol kecap
1. Tuang adonan hijau 3/4 dicetakan cucing,masukkan adonan putih ditengah2ny
1. Kukus 7-10 menit dengan api sedang


Bagian yang berwarna hijau rasanya manis dan gurih santan, sedangkan bagian yang berwarna putih. Aih, sudah lama rasanya tidak mendengar Kue Nona Manis. Camilan klasik ini bisa Bunda hadirkan kembali dengan warna menarik yang tidak akan ditolak oleh si kecil. Your current browser isn&#39;t compatible with SoundCloud. Please download one of our supported browsers. 

Demikianlah cara membuat kue nona manis yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan terbukti, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
