---
description: "Resep : Ayam Bakar Padang Sempurna"
title: "Resep : Ayam Bakar Padang Sempurna"
slug: 76-resep-ayam-bakar-padang-sempurna
date: 2020-12-20T18:50:19.661Z
image: https://img-global.cpcdn.com/recipes/7a4bea0eb29cf4de/680x482cq70/ayam-bakar-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7a4bea0eb29cf4de/680x482cq70/ayam-bakar-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7a4bea0eb29cf4de/680x482cq70/ayam-bakar-padang-foto-resep-utama.jpg
author: Justin Frank
ratingvalue: 4.7
reviewcount: 48009
recipeingredient:
- "1 kg paha ayam"
- "1 buah jeruk nipis"
- "500 ml air"
- "65 ml santan kara"
- "2 batang serai memarkan"
- "2 buah asam kandis"
- "3 lembar daun jeruk"
- "1 lembar daun salam"
- "Secukupnya garam gula pasir"
- " Bumbu halus "
- "8 siung bawang merah"
- "5 siung bawang putih"
- "5 butir kemiri sangrai"
- "Seruas jahe"
- "Seruas lengkuas"
- "Seruas kunyit"
- "5 buah cabe merah keriting"
- "4 buah cabe rawit"
recipeinstructions:
- "Lumuri ayam dengan perasan jeruk nipis dan garam. Diamkan 15 menit. Bilas hingga bersih."
- "Tumis bumbu halus, salam, serai, daun jeruk, asam kandis hingga harum dan matang."
- "Masukkan ayam. Aduk rata hingga berubah warna."
- "Masukkan air, santan, garam dan gula pasir. Aduk rata. Masak hingga air sat."
- "Panggang di atas grill plate/teflon sambil di oles sisa bumbu."
categories:
- Recipe
tags:
- ayam
- bakar
- padang

katakunci: ayam bakar padang 
nutrition: 249 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Bakar Padang](https://img-global.cpcdn.com/recipes/7a4bea0eb29cf4de/680x482cq70/ayam-bakar-padang-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan empuk. Karasteristik kuliner Nusantara ayam bakar padang yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Hidangan ayam bakar bumbu padang adalah sajian yang enak dan lezat. Sajian kali ini akan cocok anda nikmati bersama dengan sepiring nasi dan juga lalapan serta sambal yang lezat. Sehat, murah dan mudah dibuat sendiri di rumah. Chef Yvan asli dari negara Perancis jadi maklum logatnya agak lucu gitu.

Kedekatan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Bakar Padang untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang bisa anda coba salah satunya ayam bakar padang yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam bakar padang tanpa harus bersusah payah.
Berikut ini resep Ayam Bakar Padang yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Bakar Padang:

1. Harus ada 1 kg paha ayam
1. Harus ada 1 buah jeruk nipis
1. Diperlukan 500 ml air
1. Diperlukan 65 ml santan kara
1. Harus ada 2 batang serai, memarkan
1. Siapkan 2 buah asam kandis
1. Siapkan 3 lembar daun jeruk
1. Harap siapkan 1 lembar daun salam
1. Dibutuhkan Secukupnya garam, gula pasir
1. Dibutuhkan  Bumbu halus :
1. Harus ada 8 siung bawang merah
1. Harus ada 5 siung bawang putih
1. Jangan lupa 5 butir kemiri sangrai
1. Siapkan Seruas jahe
1. Tambah Seruas lengkuas
1. Dibutuhkan Seruas kunyit
1. Siapkan 5 buah cabe merah keriting
1. Diperlukan 4 buah cabe rawit


Ayam bakar yang pertama adalah Ayam Bakar Padang, sajian masakan ayam bakar ini bisa jadi alternatif buat kamu yang suka dengan makanan bercitarasa Minang. Ayam bakar is an Indonesian and Malaysian dish, consisting of charcoal-grilled chicken. Ayam bakar literally means &#34;roasted chicken&#34; in Indonesian and Malay. In Java, the chicken is usually marinated with the mixture of kecap manis (sweet soy sauce) and coconut oil, applied with a brush during grilling. 

<!--inarticleads2-->

##### Instruksi membuat  Ayam Bakar Padang:

1. Lumuri ayam dengan perasan jeruk nipis dan garam. Diamkan 15 menit. Bilas hingga bersih.
1. Tumis bumbu halus, salam, serai, daun jeruk, asam kandis hingga harum dan matang.
1. Masukkan ayam. Aduk rata hingga berubah warna.
1. Masukkan air, santan, garam dan gula pasir. Aduk rata. Masak hingga air sat.
1. Panggang di atas grill plate/teflon sambil di oles sisa bumbu.


Ayam bakar literally means &#34;roasted chicken&#34; in Indonesian and Malay. In Java, the chicken is usually marinated with the mixture of kecap manis (sweet soy sauce) and coconut oil, applied with a brush during grilling. Padang food is my favorite takeout in Indonesia. Whenever I am too lazy to cook, I can always drop Thank you for sharing the Ayam Bakar Padang recipe. I love to visit your website and I have tried. 

Demikianlah cara membuat ayam bakar padang yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan teruji, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
