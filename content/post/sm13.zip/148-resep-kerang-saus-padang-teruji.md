---
description: "Resep : Kerang saus padang Teruji"
title: "Resep : Kerang saus padang Teruji"
slug: 148-resep-kerang-saus-padang-teruji
date: 2021-03-09T15:52:41.862Z
image: https://img-global.cpcdn.com/recipes/f8f4648fead2588d/680x482cq70/kerang-saus-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f8f4648fead2588d/680x482cq70/kerang-saus-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f8f4648fead2588d/680x482cq70/kerang-saus-padang-foto-resep-utama.jpg
author: Jerry Reynolds
ratingvalue: 4
reviewcount: 44944
recipeingredient:
- "250 gr kerang ijo kupas"
- "2 bh kentang potong dadu"
- " bumbu halus"
- "4 siung bw merah"
- "2 siung bawang putih"
- "7 bh rawit merah"
- "3 bh cabai kriting"
- "1 kemiri"
- "1 cm jahe"
- " bumbu tumis"
- "2 Btg sereh bila kecil"
- "2 lbr daun salam"
- "2 lbr daun jeruk"
- "1 cm laos keprek"
- "1 sdm kunyit bubuk"
- "1 btg daun bawang"
- " Garam secukuonya"
- " Penyedap rasa"
- "Sedikit perasan jeruk"
- "Sedikit saus tiram"
recipeinstructions:
- "Haluskan bawang cabai, kemiri dan jahe. Aku tambah air gpp.. nanti kalo udh halis airnya di saring. Cabainya akan kita tumis."
- "Itu bahan buat menumisnya. Tumis cabai dulu, tambahin bubuk kunyit, masukin daun daun sereh dan laos. Masak sampe harum dan daun layu. Kemudian masukan kerang hijaunya juga kentang potong nya. Aduk rata masukan sedikit perasan jeruk nipis. Masukan garam dan penyedap rasa juga saus tiram.. Jangan lupa Koreksi rasa."
- "Masukan air perasan cabai blender tadi, kalo suka berkuah kalian bisa tambahin air lagi. Togalnya 200ml ya. Masak sampe kentang lunak dan air menyusut. Terakhir masukan irisan daun bawang dan matikan api."
- "Selalu masukan daun bawang terakhir dan langsung matikan api setelah dimasukan."
categories:
- Recipe
tags:
- kerang
- saus
- padang

katakunci: kerang saus padang 
nutrition: 248 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dinner

---


![Kerang saus padang](https://img-global.cpcdn.com/recipes/f8f4648fead2588d/680x482cq70/kerang-saus-padang-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau renyah. Ciri kuliner Nusantara kerang saus padang yang penuh dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Bau amis kerang tertutupi aroma menggoda dari saus padang. Disantap dengan nasi panas lebih nikmat! Kerang Hijau Saus Padang is one of my favorite street hawkers food in Indonesia. On rear of the Kerang Saus Padang Adapted from Dekap.com, Modified by me.

Kehangatan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah memasak Kerang saus padang untuk orang di rumah. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang dapat anda praktekkan salah satunya kerang saus padang yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep kerang saus padang tanpa harus bersusah payah.
Berikut ini resep Kerang saus padang yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 20 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kerang saus padang:

1. Harap siapkan 250 gr kerang ijo kupas
1. Harap siapkan 2 bh kentang potong dadu
1. Jangan lupa  bumbu halus
1. Tambah 4 siung bw merah
1. Dibutuhkan 2 siung bawang putih
1. Dibutuhkan 7 bh rawit merah
1. Harus ada 3 bh cabai kriting
1. Jangan lupa 1 kemiri
1. Siapkan 1 cm jahe
1. Harus ada  bumbu tumis
1. Siapkan 2 Btg sereh bila kecil
1. Tambah 2 lbr daun salam
1. Siapkan 2 lbr daun jeruk
1. Dibutuhkan 1 cm laos keprek
1. Siapkan 1 sdm kunyit bubuk
1. Jangan lupa 1 btg daun bawang
1. Harap siapkan  Garam secukuonya
1. Harus ada  Penyedap rasa
1. Harap siapkan Sedikit perasan jeruk
1. Harus ada Sedikit saus tiram


Kamu cukup membuat menu berbuka praktis seperti resep kerang dara saus padang ini saja, yang tidak memakan banyak waktu dan mudah dibuat. Nah, sajian kerang ijo saus padang memadukan kelezatan dari daging kerang dengan bumbu saus padang yang nikmat. Tekstur garing dan lembut kerang hijau yang berpadu dengan Asam, Manis dan pedasnya Saus Padang menjadi salah satu menu Seafood Favorit! Crab in Padang sauce or Padang crab (Indonesian: Kepiting saus Padang) is an Indonesian seafood dish of crab served in hot and spicy Padang sauce. 

<!--inarticleads2-->

##### Bagaimana membuat  Kerang saus padang:

1. Haluskan bawang cabai, kemiri dan jahe. Aku tambah air gpp.. nanti kalo udh halis airnya di saring. Cabainya akan kita tumis.
1. Itu bahan buat menumisnya. Tumis cabai dulu, tambahin bubuk kunyit, masukin daun daun sereh dan laos. Masak sampe harum dan daun layu. Kemudian masukan kerang hijaunya juga kentang potong nya. Aduk rata masukan sedikit perasan jeruk nipis. Masukan garam dan penyedap rasa juga saus tiram.. Jangan lupa Koreksi rasa.
1. Masukan air perasan cabai blender tadi, kalo suka berkuah kalian bisa tambahin air lagi. Togalnya 200ml ya. Masak sampe kentang lunak dan air menyusut. Terakhir masukan irisan daun bawang dan matikan api.
1. Selalu masukan daun bawang terakhir dan langsung matikan api setelah dimasukan.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Kerang saus padang">

Tekstur garing dan lembut kerang hijau yang berpadu dengan Asam, Manis dan pedasnya Saus Padang menjadi salah satu menu Seafood Favorit! Crab in Padang sauce or Padang crab (Indonesian: Kepiting saus Padang) is an Indonesian seafood dish of crab served in hot and spicy Padang sauce. Sebut saja ikan bakar, kepiting saus padang, cumi goreng tepung, dan teman-temannya. Semuanya tentu lezat, namun kurang rasanya bila tidak dibuka dengan hidangan kerang dara saus pedas. Kebanyakan saus padang biasanya diolah untuk masakan seafood. 

Demikianlah cara membuat kerang saus padang yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan teruji, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
