---
description: "Cara untuk menyiapakan Nona Manis Sempurna"
title: "Cara untuk menyiapakan Nona Manis Sempurna"
slug: 286-cara-untuk-menyiapakan-nona-manis-sempurna
date: 2020-11-11T19:14:12.869Z
image: https://img-global.cpcdn.com/recipes/f055843db7eeb616/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f055843db7eeb616/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f055843db7eeb616/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Noah McCarthy
ratingvalue: 4.5
reviewcount: 8494
recipeingredient:
- " Bahan 1"
- "250 ml santan kental"
- "40 gr gula pasir"
- "30 gr maizena"
- "Sedikit garam"
- "secukupnya Pasta pandan"
- " Bahan 2"
- "1 butir telur"
- "80 gr gula pasir"
- "140 gr terigu"
- "250 ml santan"
- " Bahan 3"
- "250 ml santan"
- "3 sdm terigu"
- "Sedikit garam"
recipeinstructions:
- "Campur semua bahan 1. Masak menggunakan api sedang hingga agak mengental. Biarkan hingga agak dingin"
- "Campurkan gula pasir dan telur, mixer hingga mengembang. Kemudian masukkan terigu dan santan bergantian sedikit demi sedikit hingga habis."
- "Campurkan bahan 1 ke bahan 2, aduk hingga rata."
- "Masukkan bahan 3 dalam panci lain, masak hingga mengental. Setelah agak dingin, masukkan ke dalam piping bag."
- "Masukkan campuran bahan 1 &amp; 2 ke dalam cetakan yang telah diolesi minyak hingga 3/4 bagian, kemudian tambahkan bahan 3 di tengah."
- "Kukus di dalam panci kukus yang telah panas kira-kira 5 sampai 10 menit."
- "Angkat. Keluarkan dari cetakan setelah dingin."
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 192 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Dinner

---


![Nona Manis](https://img-global.cpcdn.com/recipes/f055843db7eeb616/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis dan enak. Ciri khas masakan Nusantara nona manis yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga dapat diperoleh dengan cara simple. Diantaranya adalah membuat makanan Nona Manis untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang dapat anda contoh salah satunya nona manis yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona Manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 15 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona Manis:

1. Tambah  Bahan 1:
1. Diperlukan 250 ml santan kental
1. Tambah 40 gr gula pasir
1. Harap siapkan 30 gr maizena
1. Diperlukan Sedikit garam
1. Jangan lupa secukupnya Pasta pandan
1. Harus ada  Bahan 2:
1. Tambah 1 butir telur
1. Siapkan 80 gr gula pasir
1. Siapkan 140 gr terigu
1. Harap siapkan 250 ml santan
1. Harus ada  Bahan 3:
1. Diperlukan 250 ml santan
1. Harus ada 3 sdm terigu
1. Tambah Sedikit garam




<!--inarticleads2-->

##### Langkah membuat  Nona Manis:

1. Campur semua bahan 1. Masak menggunakan api sedang hingga agak mengental. Biarkan hingga agak dingin
1. Campurkan gula pasir dan telur, mixer hingga mengembang. Kemudian masukkan terigu dan santan bergantian sedikit demi sedikit hingga habis.
1. Campurkan bahan 1 ke bahan 2, aduk hingga rata.
1. Masukkan bahan 3 dalam panci lain, masak hingga mengental. Setelah agak dingin, masukkan ke dalam piping bag.
1. Masukkan campuran bahan 1 &amp; 2 ke dalam cetakan yang telah diolesi minyak hingga 3/4 bagian, kemudian tambahkan bahan 3 di tengah.
1. Kukus di dalam panci kukus yang telah panas kira-kira 5 sampai 10 menit.
1. Angkat. Keluarkan dari cetakan setelah dingin.




Demikianlah cara membuat nona manis yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
