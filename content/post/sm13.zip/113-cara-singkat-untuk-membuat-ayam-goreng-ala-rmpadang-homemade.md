---
description: "Cara singkat untuk membuat Ayam goreng ala RM.Padang Homemade"
title: "Cara singkat untuk membuat Ayam goreng ala RM.Padang Homemade"
slug: 113-cara-singkat-untuk-membuat-ayam-goreng-ala-rmpadang-homemade
date: 2021-03-02T19:40:27.419Z
image: https://img-global.cpcdn.com/recipes/bd9a8e61756056ad/680x482cq70/ayam-goreng-ala-rmpadang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bd9a8e61756056ad/680x482cq70/ayam-goreng-ala-rmpadang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bd9a8e61756056ad/680x482cq70/ayam-goreng-ala-rmpadang-foto-resep-utama.jpg
author: Billy Price
ratingvalue: 4.6
reviewcount: 47798
recipeingredient:
- "1 kg ayam"
- "3 lembar daun salam"
- "5 lembar daun jeruk"
- "2 butir telur"
- " Bumbu halus "
- "10 siung bawang merah"
- "8 siung bawang putih"
- "3 cm jahe"
- "3 cm lengkuas"
- "1 sdm ketumbar"
- "1/2 sdm kunyit"
- "1/2 sdm lada"
- "Secukupnya penyedap"
- "Secukupnya garam"
recipeinstructions:
- "Tumis bumbu halus, daun salam dan daun jeruk sampai harum kemudian tambahkan air sampai menutupi ayam."
- "Tunggu hingga bumbu meresap dan menyusut lalu matikan kompor."
- "Tiriskan ayam lalu buang daun jeruk dan daun salamnya sehingga menyisakan kuah bumbu saja di wajan."
- "Selagi kuah masih panas masukkan 2 butir telur aduk hingga menyatu di kuah bumbu (kompor keadaan mati agar telur tidak cepat menggumpal)."
- "Goreng ayam hingga matang kemudian tiriskan."
- "Masukkan bumbu bercampur telur pada minyak panas, goreng sebentar hingga kecoklatan."
- "Saring bumbu agar minyak cepat menetes kemudian bungkus didalam tisu agar tidak menyisakan minyak pada kremesan bumbu."
- "Taruh ayam pada piring saji kemudian taburkan kremesan bumbu tadi."
- "Ayam goreng padang anda siap disantap."
categories:
- Recipe
tags:
- ayam
- goreng
- ala

katakunci: ayam goreng ala 
nutrition: 247 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam goreng ala RM.Padang](https://img-global.cpcdn.com/recipes/bd9a8e61756056ad/680x482cq70/ayam-goreng-ala-rmpadang-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga gurih. Ciri makanan Nusantara ayam goreng ala rm.padang yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah memasak Ayam goreng ala RM.Padang untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang dapat anda praktekkan salah satunya ayam goreng ala rm.padang yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep ayam goreng ala rm.padang tanpa harus bersusah payah.
Berikut ini resep Ayam goreng ala RM.Padang yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 9 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam goreng ala RM.Padang:

1. Dibutuhkan 1 kg ayam
1. Siapkan 3 lembar daun salam
1. Dibutuhkan 5 lembar daun jeruk
1. Diperlukan 2 butir telur
1. Siapkan  Bumbu halus :
1. Harap siapkan 10 siung bawang merah
1. Dibutuhkan 8 siung bawang putih
1. Jangan lupa 3 cm jahe
1. Siapkan 3 cm lengkuas
1. Jangan lupa 1 sdm ketumbar
1. Dibutuhkan 1/2 sdm kunyit
1. Harus ada 1/2 sdm lada
1. Diperlukan Secukupnya penyedap
1. Harap siapkan Secukupnya garam




<!--inarticleads2-->

##### Instruksi membuat  Ayam goreng ala RM.Padang:

1. Tumis bumbu halus, daun salam dan daun jeruk sampai harum kemudian tambahkan air sampai menutupi ayam.
1. Tunggu hingga bumbu meresap dan menyusut lalu matikan kompor.
1. Tiriskan ayam lalu buang daun jeruk dan daun salamnya sehingga menyisakan kuah bumbu saja di wajan.
1. Selagi kuah masih panas masukkan 2 butir telur aduk hingga menyatu di kuah bumbu (kompor keadaan mati agar telur tidak cepat menggumpal).
1. Goreng ayam hingga matang kemudian tiriskan.
1. Masukkan bumbu bercampur telur pada minyak panas, goreng sebentar hingga kecoklatan.
1. Saring bumbu agar minyak cepat menetes kemudian bungkus didalam tisu agar tidak menyisakan minyak pada kremesan bumbu.
1. Taruh ayam pada piring saji kemudian taburkan kremesan bumbu tadi.
1. Ayam goreng padang anda siap disantap.




Demikianlah cara membuat ayam goreng ala rm.padang yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
