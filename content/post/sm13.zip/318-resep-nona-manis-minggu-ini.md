---
description: "Resep : Nona manis minggu ini"
title: "Resep : Nona manis minggu ini"
slug: 318-resep-nona-manis-minggu-ini
date: 2020-10-26T16:43:00.646Z
image: https://img-global.cpcdn.com/recipes/d4b494e8cb9e3358/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d4b494e8cb9e3358/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d4b494e8cb9e3358/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Elva Elliott
ratingvalue: 4.5
reviewcount: 27954
recipeingredient:
- " Adonan A putih"
- "125 ml santan kental"
- "125 ml susu SKM 2sachet  air"
- "100 gr tepung terigu"
- "1/2 sdt garam"
- "1/2 sdt vanili"
- " Adonan B hijau"
- "125 ml santan kental"
- "125 ml jus pandan"
- "2 sdm gula pasir"
- "3 sdm maizena"
- "Secukupnya pewarna pandan"
- " Adonan C hijau"
- "250 ml santan kental"
- "2 butir telur"
- "150 gr tepung terigu"
- "4 sdm gula pasir"
- "2 sdm susu bubuk"
- "1/2 sdt vanili"
recipeinstructions:
- "Campurkan semua bahan adonan A aduk hingga tercampur rata masak dgn menggunakan api sedang sambil terus diaduk hingga mengental dan licin,sisihkan"
- "Masukkan dalam panci adonan B masak dgn api kecil sambil terus diaduk hingga mengental dan licin, sisihkan"
- "Campur semua adonan C dgn menggunakan wisk hingga tercampur rata dan gula larut"
- "Masukkan adonan C sebanyak 3sdm kedalam adonan B sambil diaduk menggunakan wisk hingga licin masukkan lagi sedikit demi sedikit hingga adonan C habis dan adonan B tercampur rata dan licin"
- "Oles mangkok loyang dgn minyak secukupnya lalu tuang setengah adonan hijau dan masukkan 1sdt adonan A tuang ditengah adonan hijau"
- "Panaskan kukusan lalu kukus adonan selama kurang lebih 20-25menit ato matang"
- "Sajikan dgn teh hangat"
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 144 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT49M"
recipeyield: "4"
recipecategory: Lunch

---


![Nona manis](https://img-global.cpcdn.com/recipes/d4b494e8cb9e3358/680x482cq70/nona-manis-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang setidaknya kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti nona manis yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan ciri khas yang merupakan keragaman Kita



Kehangatan rumah tangga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak Nona manis untuk keluarga. Momen makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang bisa anda buat salah satunya nona manis yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep nona manis tanpa harus bersusah payah.
Berikut ini resep Nona manis yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona manis:

1. Harus ada  Adonan A (putih)
1. Diperlukan 125 ml santan kental
1. Siapkan 125 ml susu SKM (2sachet + air)
1. Harus ada 100 gr tepung terigu
1. Harap siapkan 1/2 sdt garam
1. Harus ada 1/2 sdt vanili
1. Dibutuhkan  Adonan B (hijau)
1. Dibutuhkan 125 ml santan kental
1. Dibutuhkan 125 ml jus pandan
1. Siapkan 2 sdm gula pasir
1. Harus ada 3 sdm maizena
1. Jangan lupa Secukupnya pewarna pandan
1. Dibutuhkan  Adonan C (hijau)
1. Dibutuhkan 250 ml santan kental
1. Jangan lupa 2 butir telur
1. Diperlukan 150 gr tepung terigu
1. Diperlukan 4 sdm gula pasir
1. Dibutuhkan 2 sdm susu bubuk
1. Tambah 1/2 sdt vanili




<!--inarticleads2-->

##### Cara membuat  Nona manis:

1. Campurkan semua bahan adonan A aduk hingga tercampur rata masak dgn menggunakan api sedang sambil terus diaduk hingga mengental dan licin,sisihkan
1. Masukkan dalam panci adonan B masak dgn api kecil sambil terus diaduk hingga mengental dan licin, sisihkan
1. Campur semua adonan C dgn menggunakan wisk hingga tercampur rata dan gula larut
1. Masukkan adonan C sebanyak 3sdm kedalam adonan B sambil diaduk menggunakan wisk hingga licin masukkan lagi sedikit demi sedikit hingga adonan C habis dan adonan B tercampur rata dan licin
1. Oles mangkok loyang dgn minyak secukupnya lalu tuang setengah adonan hijau dan masukkan 1sdt adonan A tuang ditengah adonan hijau
1. Panaskan kukusan lalu kukus adonan selama kurang lebih 20-25menit ato matang
1. Sajikan dgn teh hangat




Demikianlah cara membuat nona manis yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
