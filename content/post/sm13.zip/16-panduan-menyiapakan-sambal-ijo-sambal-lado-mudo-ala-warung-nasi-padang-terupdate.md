---
description: "Panduan menyiapakan Sambal Ijo (Sambal Lado Mudo) ala Warung Nasi Padang terupdate"
title: "Panduan menyiapakan Sambal Ijo (Sambal Lado Mudo) ala Warung Nasi Padang terupdate"
slug: 16-panduan-menyiapakan-sambal-ijo-sambal-lado-mudo-ala-warung-nasi-padang-terupdate
date: 2020-10-07T11:12:03.845Z
image: https://img-global.cpcdn.com/recipes/51ac2d340e3fb2a0/680x482cq70/sambal-ijo-sambal-lado-mudo-ala-warung-nasi-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/51ac2d340e3fb2a0/680x482cq70/sambal-ijo-sambal-lado-mudo-ala-warung-nasi-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/51ac2d340e3fb2a0/680x482cq70/sambal-ijo-sambal-lado-mudo-ala-warung-nasi-padang-foto-resep-utama.jpg
author: Bryan Collier
ratingvalue: 4.8
reviewcount: 5885
recipeingredient:
- "250 gram cabai hijau kriting"
- "100 gram tomat hijau"
- "50 gram bawang merah"
- "25 gram bawang putih"
- "5 gram daun jeruk purut buang tulang daun"
- "10-12 gram gula pasir"
- "5-7 gram garam"
- "5 gram kaldu bubuk saya  knorr beef"
- "50 ml minyak sayur"
- "150 ml air"
recipeinstructions:
- "Goreng bawang merah dan bawang putih hingga wangi, masukkan cabai hijau kriting, tomat hijau dan daun jeruk, goreng kembali hingga lunak"
- "Angkat dan dinginkan. Tumbuk sebagian sebagian (atau blender kasar)"
- "Rebus kembali bahan sambal dengan air bersama garam, gula pasir dan kaldu bubuk hingga meletup letup"
categories:
- Recipe
tags:
- sambal
- ijo
- sambal

katakunci: sambal ijo sambal 
nutrition: 165 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Lunch

---


![Sambal Ijo (Sambal Lado Mudo) ala Warung Nasi Padang](https://img-global.cpcdn.com/recipes/51ac2d340e3fb2a0/680x482cq70/sambal-ijo-sambal-lado-mudo-ala-warung-nasi-padang-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan enak. Karasteristik masakan Indonesia sambal ijo (sambal lado mudo) ala warung nasi padang yang penuh dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Sambal Ijo (Sambal Lado Mudo) ala Warung Nasi Padang untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang bisa anda praktekkan salah satunya sambal ijo (sambal lado mudo) ala warung nasi padang yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep sambal ijo (sambal lado mudo) ala warung nasi padang tanpa harus bersusah payah.
Seperti resep Sambal Ijo (Sambal Lado Mudo) ala Warung Nasi Padang yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambal Ijo (Sambal Lado Mudo) ala Warung Nasi Padang:

1. Tambah 250 gram cabai hijau kriting
1. Tambah 100 gram tomat hijau
1. Diperlukan 50 gram bawang merah
1. Harus ada 25 gram bawang putih
1. Jangan lupa 5 gram daun jeruk purut buang tulang daun
1. Harus ada 10-12 gram gula pasir
1. Tambah 5-7 gram garam
1. Tambah 5 gram kaldu bubuk (saya : knorr beef)
1. Diperlukan 50 ml minyak sayur
1. Tambah 150 ml air




<!--inarticleads2-->

##### Langkah membuat  Sambal Ijo (Sambal Lado Mudo) ala Warung Nasi Padang:

1. Goreng bawang merah dan bawang putih hingga wangi, masukkan cabai hijau kriting, tomat hijau dan daun jeruk, goreng kembali hingga lunak
1. Angkat dan dinginkan. Tumbuk sebagian sebagian (atau blender kasar)
1. Rebus kembali bahan sambal dengan air bersama garam, gula pasir dan kaldu bubuk hingga meletup letup




Demikianlah cara membuat sambal ijo (sambal lado mudo) ala warung nasi padang yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
