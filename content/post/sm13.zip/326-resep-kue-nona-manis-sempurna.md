---
description: "Resep : Kue Nona Manis Sempurna"
title: "Resep : Kue Nona Manis Sempurna"
slug: 326-resep-kue-nona-manis-sempurna
date: 2021-01-11T15:59:31.130Z
image: https://img-global.cpcdn.com/recipes/26c18cb24c0c2521/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/26c18cb24c0c2521/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/26c18cb24c0c2521/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Catherine Potter
ratingvalue: 4.8
reviewcount: 45131
recipeingredient:
- " Bahan I"
- "250 ml santan kental"
- "1 btr telur"
- "80 gr gula pasir"
- "140 gr tepung terigu"
- " Bahan II"
- "250 ml santan kental"
- "40 gr gula pasir"
- "30 gr maizena"
- "Secukupnya jus pandanpewarna hijau"
- "Sejumput garam"
- " Bahan III"
- "500 ml santan kental"
- "6 sdm tepung terigu"
- "Sejumput garam"
recipeinstructions:
- "Bahan I : mixer gula dan telur sampai kental, masukan tepung terigu dan santan secara bertahap dengan menggunakan mixer kecepatan rendah sampai rata, sisihkan"
- "Bahan II : rebus semua bahan dengan api sedang hingga beruap dan mengental, matikan api, setelah agak dingin tambahkan ke dalam adonan I secara bertahap sambil di mixer sampai tercampur rata, sisihkan"
- "Bahan III : rebus semua bahan dengan api sedang dan aduk terus sampai beruap dan mengental, matikan api sambil terus diaduk agar tidak bergerindil. Masukan ke dalam botol kecap plastik"
- "Siapkan cetakan kue talam yang sudah dioles minyak tipis"
- "Isi adonan hijau 3/4 kemudian semprotkan adonan putih hingga penuh dengan cara moncong botol dibenamkan sedikit kedalam adonan hijau, lakukan sampai habis"
- "Kukus selama 15 menit, jangan lupa tutup kukusan dibungkus dengan serbet bersih"
- "Tunggu hingga dingin untuk mengeluarkan dari cetakan"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 204 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Dinner

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/26c18cb24c0c2521/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti kue nona manis yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa ciri khas yang merupakan keragaman Indonesia

Kedekatan rumah tangga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Kue Nona Manis untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang dapat anda contoh salah satunya kue nona manis yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis:

1. Harap siapkan  Bahan I
1. Tambah 250 ml santan kental
1. Diperlukan 1 btr telur
1. Dibutuhkan 80 gr gula pasir
1. Jangan lupa 140 gr tepung terigu
1. Diperlukan  Bahan II
1. Harus ada 250 ml santan kental
1. Harap siapkan 40 gr gula pasir
1. Tambah 30 gr maizena
1. Jangan lupa Secukupnya jus pandan/pewarna hijau
1. Siapkan Sejumput garam
1. Harap siapkan  Bahan III
1. Dibutuhkan 500 ml santan kental
1. Harus ada 6 sdm tepung terigu
1. Jangan lupa Sejumput garam




<!--inarticleads2-->

##### Bagaimana membuat  Kue Nona Manis:

1. Bahan I : mixer gula dan telur sampai kental, masukan tepung terigu dan santan secara bertahap dengan menggunakan mixer kecepatan rendah sampai rata, sisihkan
1. Bahan II : rebus semua bahan dengan api sedang hingga beruap dan mengental, matikan api, setelah agak dingin tambahkan ke dalam adonan I secara bertahap sambil di mixer sampai tercampur rata, sisihkan
1. Bahan III : rebus semua bahan dengan api sedang dan aduk terus sampai beruap dan mengental, matikan api sambil terus diaduk agar tidak bergerindil. Masukan ke dalam botol kecap plastik
1. Siapkan cetakan kue talam yang sudah dioles minyak tipis
1. Isi adonan hijau 3/4 kemudian semprotkan adonan putih hingga penuh dengan cara moncong botol dibenamkan sedikit kedalam adonan hijau, lakukan sampai habis
1. Kukus selama 15 menit, jangan lupa tutup kukusan dibungkus dengan serbet bersih
1. Tunggu hingga dingin untuk mengeluarkan dari cetakan




Demikianlah cara membuat kue nona manis yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
