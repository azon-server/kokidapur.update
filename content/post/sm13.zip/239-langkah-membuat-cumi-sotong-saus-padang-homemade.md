---
description: "Langkah membuat Cumi Sotong Saus Padang Homemade"
title: "Langkah membuat Cumi Sotong Saus Padang Homemade"
slug: 239-langkah-membuat-cumi-sotong-saus-padang-homemade
date: 2021-01-07T14:06:16.547Z
image: https://img-global.cpcdn.com/recipes/d5fb8104d0f9f8ea/680x482cq70/cumi-sotong-saus-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d5fb8104d0f9f8ea/680x482cq70/cumi-sotong-saus-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d5fb8104d0f9f8ea/680x482cq70/cumi-sotong-saus-padang-foto-resep-utama.jpg
author: Mabelle Ingram
ratingvalue: 4.3
reviewcount: 6191
recipeingredient:
- "1 kg cumi sotong"
- "1-2 bonggol jagung rebus"
- "1 papan petai"
- "5 buah cabe merah besar"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "2 ruas jahe"
- "2 batang sereh gepraaakkk"
- "2 lembar daun jeruk"
- "2 sdm saus tiram"
- "1 sdm saus tomat"
- "1 1/2 sdm saus cabai"
- "1 sdt garam"
- "1 sdm gula pasir"
- "1 sdm gula merah iris"
- "1 sdm kaldu bubuk"
recipeinstructions:
- "Siangi sotong kemudian cuci bersih, kucuri jeruk nipis diamkan 15 menit kemudian potong² sesuai selera, lalu goreng setengah matang, sisihkan"
- "Blender/ulek cabe merah besar, bawang merah, bawang putih, jahe. Sereh hanya digeprek saja. Sisihkan"
- "Panaskan minyak diwajan, kemudian goreng petai aduk² sebentar kemudian masukkan bumbu halus td beserta daun jeruk lalu aduk tumis hingga wangi"
- "Kemudian tambahkan sedikit air matang (sy kira² 175 ml) dan tambahkan saus tiram, saus tomat, saus cabai, garam, gula merah, gula pasir dan kaldu bubuk, aduk rata (jgn lupa tes rasa)"
- "Lalu masukkan cumi sotong, aduk rata, selanjutnya masukkan potongan jagung rebusnya, aduk rata kembali. Tutup wajan beberapa saat kemudian aduk² sebentar, matikan kompor"
- "Cumi sotong saus padang dan kawan²nya siap dihidangkan"
categories:
- Recipe
tags:
- cumi
- sotong
- saus

katakunci: cumi sotong saus 
nutrition: 247 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Lunch

---


![Cumi Sotong Saus Padang](https://img-global.cpcdn.com/recipes/d5fb8104d0f9f8ea/680x482cq70/cumi-sotong-saus-padang-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita lestarikan karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti cumi sotong saus padang yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan keistimewahan yang merupakan keragaman Kita



Kehangatan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Cumi Sotong Saus Padang untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda contoh salah satunya cumi sotong saus padang yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep cumi sotong saus padang tanpa harus bersusah payah.
Seperti resep Cumi Sotong Saus Padang yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Cumi Sotong Saus Padang:

1. Harus ada 1 kg cumi sotong
1. Dibutuhkan 1-2 bonggol jagung rebus
1. Harap siapkan 1 papan petai
1. Harap siapkan 5 buah cabe merah besar
1. Diperlukan 8 siung bawang merah
1. Tambah 4 siung bawang putih
1. Jangan lupa 2 ruas jahe
1. Harus ada 2 batang sereh gepraaakkk
1. Diperlukan 2 lembar daun jeruk
1. Diperlukan 2 sdm saus tiram
1. Harap siapkan 1 sdm saus tomat
1. Harus ada 1 1/2 sdm saus cabai
1. Harap siapkan 1 sdt garam
1. Tambah 1 sdm gula pasir
1. Siapkan 1 sdm gula merah iris
1. Siapkan 1 sdm kaldu bubuk




<!--inarticleads2-->

##### Bagaimana membuat  Cumi Sotong Saus Padang:

1. Siangi sotong kemudian cuci bersih, kucuri jeruk nipis diamkan 15 menit kemudian potong² sesuai selera, lalu goreng setengah matang, sisihkan
1. Blender/ulek cabe merah besar, bawang merah, bawang putih, jahe. Sereh hanya digeprek saja. Sisihkan
1. Panaskan minyak diwajan, kemudian goreng petai aduk² sebentar kemudian masukkan bumbu halus td beserta daun jeruk lalu aduk tumis hingga wangi
1. Kemudian tambahkan sedikit air matang (sy kira² 175 ml) dan tambahkan saus tiram, saus tomat, saus cabai, garam, gula merah, gula pasir dan kaldu bubuk, aduk rata (jgn lupa tes rasa)
1. Lalu masukkan cumi sotong, aduk rata, selanjutnya masukkan potongan jagung rebusnya, aduk rata kembali. Tutup wajan beberapa saat kemudian aduk² sebentar, matikan kompor
1. Cumi sotong saus padang dan kawan²nya siap dihidangkan




Demikianlah cara membuat cumi sotong saus padang yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
