---
description: "Steps membuat Nona manis (bakar/kukus) Terbukti"
title: "Steps membuat Nona manis (bakar/kukus) Terbukti"
slug: 277-steps-membuat-nona-manis-bakar-kukus-terbukti
date: 2020-11-30T07:36:18.708Z
image: https://img-global.cpcdn.com/recipes/04e94fc1f4eec1c5/680x482cq70/nona-manis-bakarkukus-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/04e94fc1f4eec1c5/680x482cq70/nona-manis-bakarkukus-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/04e94fc1f4eec1c5/680x482cq70/nona-manis-bakarkukus-foto-resep-utama.jpg
author: Thomas Hudson
ratingvalue: 4.7
reviewcount: 47101
recipeingredient:
- " Bahan A"
- "1 butir telur"
- "1/2 cup gula"
- "1 cup tepung terigu"
- "1 cup santan kental"
- " Bahan B"
- "1/2 cup santan kental"
- "1/2 cup air"
- "1/2 kaleng  1 cup jagung blender"
- "1 tete pewarna kuning"
- "1/4 cup tepung jagung"
- " Bahan C"
- "1 cup santan kental"
- "1 sdm tepung terigu optional peres munjung"
- "1/2 sdt garam"
recipeinstructions:
- "Kocok rata bahan A, menggunakan wisk."
- "Masak bahan B, hingga mengkilat."
- "Campur bahan A &amp; bahan B, sisihkan."
- "Masak bahan C hingga kental. Masukkan dalam botol saos atau plastik segitiga untuk memudahkan."
- "Panaskas kukusan, jangan lupa alasi penutup dengan serbet agar uap tidak jatuh mengenai kue."
- "Olesi cetakan menggunakan minyak."
- "Isi adonan AB hingga setinggi ¾ cetakan, kemudian suntikkan adonan C tepat di tengah2."
- "Kukus selama 15 menit. Biarkan sejuk, keluarkan kue dari cetakan."
- "Lakukan sampai adonan habis."
- "Atau campur sisa adonan AB &amp; C, tambahkan 2 sdm jagung blender, 1 sdm mentega &amp; sedikit air... Kemudian panggang dalam oven selam 1 jam dengan panas 180⁰-200⁰ (sesuaikan oven masing2) hingga bagian atas kecoklatan. Potong &amp; sajikan sejuk."
categories:
- Recipe
tags:
- nona
- manis
- bakarkukus

katakunci: nona manis bakarkukus 
nutrition: 236 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT55M"
recipeyield: "2"
recipecategory: Lunch

---


![Nona manis (bakar/kukus)](https://img-global.cpcdn.com/recipes/04e94fc1f4eec1c5/680x482cq70/nona-manis-bakarkukus-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga enak. Karasteristik kuliner Indonesia nona manis (bakar/kukus) yang kaya dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan rumah tangga bisa ditemukan dengan cara simple. Salah satunya adalah membuat makanan Nona manis (bakar/kukus) untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang bisa anda buat salah satunya nona manis (bakar/kukus) yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep nona manis (bakar/kukus) tanpa harus bersusah payah.
Berikut ini resep Nona manis (bakar/kukus) yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona manis (bakar/kukus):

1. Jangan lupa  Bahan A
1. Harus ada 1 butir telur
1. Siapkan 1/2 cup gula
1. Jangan lupa 1 cup tepung terigu
1. Tambah 1 cup santan kental
1. Harus ada  Bahan B
1. Harap siapkan 1/2 cup santan kental
1. Dibutuhkan 1/2 cup air
1. Harap siapkan 1/2 kaleng / 1 cup jagung blender
1. Siapkan 1 tete pewarna kuning
1. Jangan lupa 1/4 cup tepung jagung
1. Harap siapkan  Bahan C
1. Harus ada 1 cup santan kental
1. Dibutuhkan 1 sdm tepung terigu (optional peres/ munjung)
1. Siapkan 1/2 sdt garam




<!--inarticleads2-->

##### Instruksi membuat  Nona manis (bakar/kukus):

1. Kocok rata bahan A, menggunakan wisk.
1. Masak bahan B, hingga mengkilat.
1. Campur bahan A &amp; bahan B, sisihkan.
1. Masak bahan C hingga kental. Masukkan dalam botol saos atau plastik segitiga untuk memudahkan.
1. Panaskas kukusan, jangan lupa alasi penutup dengan serbet agar uap tidak jatuh mengenai kue.
1. Olesi cetakan menggunakan minyak.
1. Isi adonan AB hingga setinggi ¾ cetakan, kemudian suntikkan adonan C tepat di tengah2.
1. Kukus selama 15 menit. Biarkan sejuk, keluarkan kue dari cetakan.
1. Lakukan sampai adonan habis.
1. Atau campur sisa adonan AB &amp; C, tambahkan 2 sdm jagung blender, 1 sdm mentega &amp; sedikit air... Kemudian panggang dalam oven selam 1 jam dengan panas 180⁰-200⁰ (sesuaikan oven masing2) hingga bagian atas kecoklatan. Potong &amp; sajikan sejuk.




Demikianlah cara membuat nona manis (bakar/kukus) yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
