---
description: "Resep : Ayam saus padang Sempurna"
title: "Resep : Ayam saus padang Sempurna"
slug: 122-resep-ayam-saus-padang-sempurna
date: 2020-12-10T16:02:57.546Z
image: https://img-global.cpcdn.com/recipes/3af3bc5b014b9387/680x482cq70/ayam-saus-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3af3bc5b014b9387/680x482cq70/ayam-saus-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3af3bc5b014b9387/680x482cq70/ayam-saus-padang-foto-resep-utama.jpg
author: Fannie Francis
ratingvalue: 5
reviewcount: 6714
recipeingredient:
- "1/2 ekor ayam"
- " Bumbu halus"
- "5 bawang merah"
- "2 Bawang putih"
- "5 buah cabe merah"
- " Bumbu iris"
- "1 bawang bombai"
- "1 btg daun sop"
- " Cabe rawit"
- " Bumbu saos"
- "40 gr saus tomat"
- "40 gr saus sambal"
- "1 sdt gula"
- "1 sdt garam"
recipeinstructions:
- "Cuci bersih ayam, baluri dgn asam jawa, Cuci bersih kembali"
- "Marinasi ayam dengan asam dan garam. Diamkan"
- "Goreng ayam nggak usah terlalu kering"
- "Tumis bumbu halus dan bawang bombai"
- "Tambahkan air"
- "Masukkan ayam, masak sampai mengental"
- "Sebelum diangkat, masukkan daun sop dan cabe rawit"
- "Ayam saus Padang siap"
categories:
- Recipe
tags:
- ayam
- saus
- padang

katakunci: ayam saus padang 
nutrition: 265 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam saus padang](https://img-global.cpcdn.com/recipes/3af3bc5b014b9387/680x482cq70/ayam-saus-padang-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan gurih. Karasteristik kuliner Nusantara ayam saus padang yang penuh dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam saus padang untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang bisa anda coba salah satunya ayam saus padang yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep ayam saus padang tanpa harus bersusah payah.
Seperti resep Ayam saus padang yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 14 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam saus padang:

1. Jangan lupa 1/2 ekor ayam
1. Tambah  Bumbu halus
1. Dibutuhkan 5 bawang merah
1. Harus ada 2 Bawang putih
1. Harus ada 5 buah cabe merah
1. Dibutuhkan  Bumbu iris
1. Siapkan 1 bawang bombai
1. Harap siapkan 1 btg daun sop
1. Dibutuhkan  Cabe rawit
1. Diperlukan  Bumbu saos
1. Harap siapkan 40 gr saus tomat
1. Dibutuhkan 40 gr saus sambal
1. Jangan lupa 1 sdt gula
1. Tambah 1 sdt garam




<!--inarticleads2-->

##### Langkah membuat  Ayam saus padang:

1. Cuci bersih ayam, baluri dgn asam jawa, Cuci bersih kembali
1. Marinasi ayam dengan asam dan garam. Diamkan
1. Goreng ayam nggak usah terlalu kering
1. Tumis bumbu halus dan bawang bombai
1. Tambahkan air
1. Masukkan ayam, masak sampai mengental
1. Sebelum diangkat, masukkan daun sop dan cabe rawit
1. Ayam saus Padang siap




Demikianlah cara membuat ayam saus padang yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan cepat, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
