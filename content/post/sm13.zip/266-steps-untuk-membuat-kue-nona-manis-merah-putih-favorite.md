---
description: "Steps untuk membuat Kue nona manis merah putih Favorite"
title: "Steps untuk membuat Kue nona manis merah putih Favorite"
slug: 266-steps-untuk-membuat-kue-nona-manis-merah-putih-favorite
date: 2020-11-07T03:00:18.687Z
image: https://img-global.cpcdn.com/recipes/adba1db094eaff66/680x482cq70/kue-nona-manis-merah-putih-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/adba1db094eaff66/680x482cq70/kue-nona-manis-merah-putih-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/adba1db094eaff66/680x482cq70/kue-nona-manis-merah-putih-foto-resep-utama.jpg
author: Bryan Tucker
ratingvalue: 4.5
reviewcount: 41605
recipeingredient:
- " Bahan A"
- "250 ml santan"
- "3 sdm maizena"
- "50 gr gula pasir"
- "1/2 sdt garam"
- "4 tetes pewarna merah"
- "1 lbr daun pandan"
- " Bahan B"
- "250 ml santan"
- "150 gr tepung terigu"
- "1 btr telur"
- "100 gr gula pasir"
- "1/2 sdt garam"
- " Bahan C "
- "100 ml santan"
- "2 sdm tepung terigu"
- "1 sdm gula pasir"
- "sejumput garam"
recipeinstructions:
- "Campur jadi satu bahan A kedalam panci. masak dan aduk2 agak tidak bergerindil. masak sampai mendidih dan dinginkan"
- "Campur jadi satu bahan C atau adonan putih. masak dan aduk2 agar tidak bergerindil. masak sampe mendidih dn dinginkan. masukkan dalam plastik segitiga atau piping bag"
- "Masukkan dalam wadah bahan B. aduk menggunakan wisk sampai adonan rata tidak bergerindil. lalu masukkan bahan A. aduk lg dengan wisk sampai rata. jadilah adonan merah"
- "Olesi cetakan kue talam dengan minyak. masukkan adonan merah sampai 3/4 cetakan. lalu semprotkan adonan putih ditengahnya. ulangi sampai adonan habis"
- "Didihkan kukusan. masukkan adonan ke dalam kukusan. kukus 15-20 menit."
- "Sajikan"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 248 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dinner

---


![Kue nona manis merah putih](https://img-global.cpcdn.com/recipes/adba1db094eaff66/680x482cq70/kue-nona-manis-merah-putih-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang harus kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti kue nona manis merah putih yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan keistimewahan yang merupakan keragaman Indonesia



Keharmonisan rumah tangga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Kue nona manis merah putih untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang bisa anda coba salah satunya kue nona manis merah putih yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep kue nona manis merah putih tanpa harus bersusah payah.
Berikut ini resep Kue nona manis merah putih yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue nona manis merah putih:

1. Jangan lupa  Bahan A:
1. Jangan lupa 250 ml santan
1. Harus ada 3 sdm maizena
1. Tambah 50 gr gula pasir
1. Harap siapkan 1/2 sdt garam
1. Harus ada 4 tetes pewarna merah
1. Harap siapkan 1 lbr daun pandan
1. Harus ada  Bahan B:
1. Dibutuhkan 250 ml santan
1. Dibutuhkan 150 gr tepung terigu
1. Siapkan 1 btr telur
1. Harus ada 100 gr gula pasir
1. Harap siapkan 1/2 sdt garam
1. Tambah  Bahan C :
1. Harus ada 100 ml santan
1. Tambah 2 sdm tepung terigu
1. Diperlukan 1 sdm gula pasir
1. Harap siapkan sejumput garam




<!--inarticleads2-->

##### Instruksi membuat  Kue nona manis merah putih:

1. Campur jadi satu bahan A kedalam panci. masak dan aduk2 agak tidak bergerindil. masak sampai mendidih dan dinginkan
1. Campur jadi satu bahan C atau adonan putih. masak dan aduk2 agar tidak bergerindil. masak sampe mendidih dn dinginkan. masukkan dalam plastik segitiga atau piping bag
1. Masukkan dalam wadah bahan B. aduk menggunakan wisk sampai adonan rata tidak bergerindil. lalu masukkan bahan A. aduk lg dengan wisk sampai rata. jadilah adonan merah
1. Olesi cetakan kue talam dengan minyak. masukkan adonan merah sampai 3/4 cetakan. lalu semprotkan adonan putih ditengahnya. ulangi sampai adonan habis
1. Didihkan kukusan. masukkan adonan ke dalam kukusan. kukus 15-20 menit.
1. Sajikan




Demikianlah cara membuat kue nona manis merah putih yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
