---
description: "Bagaimana membuat Kepiting Saos Padang Favorite"
title: "Bagaimana membuat Kepiting Saos Padang Favorite"
slug: 74-bagaimana-membuat-kepiting-saos-padang-favorite
date: 2020-09-15T01:32:33.501Z
image: https://img-global.cpcdn.com/recipes/092994e248946f6d/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/092994e248946f6d/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/092994e248946f6d/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg
author: Elnora Grant
ratingvalue: 4.8
reviewcount: 42317
recipeingredient:
- "1 ekor kepiting ukuran jumbo"
- "1 buah bawang bombai ukuran besar iris"
- "6 siung bawang putih cincang"
- "4 buah cabe rawit iris tipis tipis"
- "2 sdm saos tomat"
- "4 sdm saus sambal"
- "1 sdm kecap manis"
- "1 sdm saos tiram"
- "1 cm jahe geprek"
- "1 butir jeruk nipis"
- "1 buah dan baan iris"
- "secukupnya Garam Gula Pasir Merica"
- "1 sdm tepung maizena cairkan dengan air"
recipeinstructions:
- "Bersihkan kepiting bang kotorannya, taburi garam dan jeruk nipis. Goreng di minyak panas dengan api sedans sampai matang, sishkan."
- "Tumis bawang bombai dan bawang putih sampai harum, masukkan jahe, cabe rawit, lalu tambahkan semua bumbu saos, kecap, gula, garam, merica, dan bawang, beri sedikit air."
- "Tuang cairan maizena sedikit demi sedikit sampai mengental, koreksi rasa, jika sudah pas masukkan kepiting yang tadi sudah di goreng, aduk rata hingga bambu tercampur rata. sajıkan"
categories:
- Recipe
tags:
- kepiting
- saos
- padang

katakunci: kepiting saos padang 
nutrition: 263 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT31M"
recipeyield: "4"
recipecategory: Dinner

---


![Kepiting Saos Padang](https://img-global.cpcdn.com/recipes/092994e248946f6d/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga empuk. Karasteristik masakan Nusantara kepiting saos padang yang penuh dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Kepiting Saos Padang untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang bisa anda coba salah satunya kepiting saos padang yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep kepiting saos padang tanpa harus bersusah payah.
Seperti resep Kepiting Saos Padang yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 13 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kepiting Saos Padang:

1. Harap siapkan 1 ekor kepiting ukuran jumbo
1. Siapkan 1 buah bawang bombai ukuran besar iris
1. Harus ada 6 siung bawang putih, cincang
1. Diperlukan 4 buah cabe rawit iris tipis tipis
1. Jangan lupa 2 sdm saos tomat
1. Dibutuhkan 4 sdm saus sambal
1. Siapkan 1 sdm kecap manis
1. Dibutuhkan 1 sdm saos tiram
1. Tambah 1 cm jahe geprek
1. Harus ada 1 butir jeruk nipis
1. Dibutuhkan 1 buah dan baan iris
1. Jangan lupa secukupnya Garam, Gula Pasir, Merica
1. Diperlukan 1 sdm tepung maizena, cairkan dengan air




<!--inarticleads2-->

##### Instruksi membuat  Kepiting Saos Padang:

1. Bersihkan kepiting bang kotorannya, taburi garam dan jeruk nipis. Goreng di minyak panas dengan api sedans sampai matang, sishkan.
1. Tumis bawang bombai dan bawang putih sampai harum, masukkan jahe, cabe rawit, lalu tambahkan semua bumbu saos, kecap, gula, garam, merica, dan bawang, beri sedikit air.
1. Tuang cairan maizena sedikit demi sedikit sampai mengental, koreksi rasa, jika sudah pas masukkan kepiting yang tadi sudah di goreng, aduk rata hingga bambu tercampur rata. sajıkan




Demikianlah cara membuat kepiting saos padang yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
