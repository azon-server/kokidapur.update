---
description: "Resep : Kue Nona Manis Luar biasa"
title: "Resep : Kue Nona Manis Luar biasa"
slug: 370-resep-kue-nona-manis-luar-biasa
date: 2020-10-24T19:37:01.371Z
image: https://img-global.cpcdn.com/recipes/0d893b0cdb72de43/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0d893b0cdb72de43/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0d893b0cdb72de43/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Chester Norris
ratingvalue: 4.1
reviewcount: 10154
recipeingredient:
- " bahan 1 "
- "250 ml santan kental"
- "1 butir telur"
- "80 gr gula pasir"
- "140 gr terigu"
- " bahan 2 "
- "250 ml santan kental"
- "40 gr gula pasir"
- "30 gr maizena"
- "secukupnya pewarna hijau"
- "sejumput garam"
- " bahan 3 "
- "500 ml santan kental"
- "6 sendok makan terigu"
- "sejumput garam"
recipeinstructions:
- "Bahan 1 : mixer gula dan telur hingga kental. Kemudian masukkan santan, terigu secara bertahap sambil di mixer dgn kecepatan rendah sampe rata. Sisihkan"
- "Bahan 2 : rebus semua bahan dgn api sedang hingga beruap dan mengental. Matikan. setelah agak sedikit dingin tmbhkan secara bertahap ke dlm adonan 1 sambil di mixer agar tercampur rata. Sisihkan"
- "Bahan 3 : rebus semua bahan dgn api sedang dan diaduk2 terus hingga beruap dan mengental. Matikan api sambil terus diaduk agar tdk bergerindil. Tuang dlm botol kecap plastik."
- "Siapkan cetakan kue talam yg dioles minyak tipis. Tuang adonan hijau 3/4. Kemudian semprotkan adonan putih hingga penuh dgn cara moncong botol dibenamkan sedikit ke dalam adonan hijau. Lakukan sampe habis."
- "Kukus selama 10 menit. Jgn lupa tutup dandang dilapisi serbet. Biarkan dingin utk melepasnya"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 105 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Lunch

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/0d893b0cdb72de43/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti kue nona manis yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan ciri khas yang merupakan keragaman Indonesia

Keharmonisan keluarga dapat ditemukan dengan cara mudah. Salah satunya adalah memasak Kue Nona Manis untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang dapat anda contoh salah satunya kue nona manis yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis:

1. Jangan lupa  bahan 1 :
1. Jangan lupa 250 ml santan kental
1. Siapkan 1 butir telur
1. Diperlukan 80 gr gula pasir
1. Diperlukan 140 gr terigu
1. Dibutuhkan  bahan 2 :
1. Jangan lupa 250 ml santan kental
1. Tambah 40 gr gula pasir
1. Diperlukan 30 gr maizena
1. Siapkan secukupnya pewarna hijau
1. Jangan lupa sejumput garam
1. Dibutuhkan  bahan 3 :
1. Tambah 500 ml santan kental
1. Jangan lupa 6 sendok makan terigu
1. Harus ada sejumput garam




<!--inarticleads2-->

##### Langkah membuat  Kue Nona Manis:

1. Bahan 1 : mixer gula dan telur hingga kental. Kemudian masukkan santan, terigu secara bertahap sambil di mixer dgn kecepatan rendah sampe rata. Sisihkan
1. Bahan 2 : rebus semua bahan dgn api sedang hingga beruap dan mengental. Matikan. setelah agak sedikit dingin tmbhkan secara bertahap ke dlm adonan 1 sambil di mixer agar tercampur rata. Sisihkan
1. Bahan 3 : rebus semua bahan dgn api sedang dan diaduk2 terus hingga beruap dan mengental. Matikan api sambil terus diaduk agar tdk bergerindil. Tuang dlm botol kecap plastik.
1. Siapkan cetakan kue talam yg dioles minyak tipis. Tuang adonan hijau 3/4. Kemudian semprotkan adonan putih hingga penuh dgn cara moncong botol dibenamkan sedikit ke dalam adonan hijau. Lakukan sampe habis.
1. Kukus selama 10 menit. Jgn lupa tutup dandang dilapisi serbet. Biarkan dingin utk melepasnya




Demikianlah cara membuat kue nona manis yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
