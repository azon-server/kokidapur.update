---
description: "Step-by-Step membuat Nona Manis Nangka Favorite"
title: "Step-by-Step membuat Nona Manis Nangka Favorite"
slug: 400-step-by-step-membuat-nona-manis-nangka-favorite
date: 2021-01-16T23:52:01.370Z
image: https://img-global.cpcdn.com/recipes/c9d0e575e2e11ff3/680x482cq70/nona-manis-nangka-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c9d0e575e2e11ff3/680x482cq70/nona-manis-nangka-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c9d0e575e2e11ff3/680x482cq70/nona-manis-nangka-foto-resep-utama.jpg
author: Stanley Boone
ratingvalue: 4.9
reviewcount: 11976
recipeingredient:
- " Bahan A"
- "140 gram tepung terigu"
- "2 butir telur"
- "250 ml santan"
- "80 gram gula pasir"
- "100 gram buah nangka"
- " Bahan B"
- "250 ml santan"
- "40 gram gula pasir"
- "30 gram tepung maizena"
- "1/4 sdt garam"
- "4 tetes pasta pandan"
- " Bahan C"
- "500 ml santan kental"
- "3 sdm tepung terigu"
- "1/4 sdt garam"
- " Bahan lain"
- "2 liter air"
- "1 sdm minyak goreng"
recipeinstructions:
- "Cuci nangka sampai bersih dan buang bijinya"
- "Potong buah nangka menjadi potongan dadu kecil"
- "Olesi cetakan kue Nona Manis dengan minyak goreng"
- "Masak Bahan B:"
- "Campur semua bahan B pada panci dan masak sampai mengental dan meletup-letup(gunakan api kecil dan terus diaduk). Diamkan sampai dingin dan sisihkan"
- "Masak Bahan C:"
- "Masukkan semua bahan C dalam panci /wadah dan aduk sampai rata lalu saring(agar tidak bergerindil)"
- "Masak sampai mengental dan meletup-letup(masak dengan api kecil dan terus diaduk agar santan tidak pecah).Diamkan sampai dingin"
- "Jika bahan C sudah dingin masukkan pada plastik segitiga"
- "Panaskan alat kukus sambil kita membuat adonan dari bahan A"
- "Kocok telur dan gula sampai mengembang.Turunkan kecepatan mixer, masukkan santan dan terigu secara bergantian sampai semua tercampur rata"
- "Campurkan (mixer) adonan bahan B yang sudah dingin dengan adonan bahan A sampai tercampur merata"
- "Tambahkan nangka dan aduk kembali sampai rata"
- "Tuang adonan pandan nangka (campuran adonan A dan B) sampai 3/4 dari cetakan"
- "Gunting ujung plastik segitiga dan semprotkan adonan C di tengah adonan pandan nangka(tenggelamkan ujung plastik kira-kira ditengah-tengah cetakan dan tekan plastik sampai adonan putih atau adonan C muncul)"
- "Jika air kukusan sudah mendidih masukan adonan yang sudah dicetak pada pengukus dan kukus kurang lebih 10-15 menit dengan api sedang"
- "Jika kue sudah matang angkat dan dinginkan"
- "Setelah kue dingin, keluarkan kue dari cetakan dan sajikan"
categories:
- Recipe
tags:
- nona
- manis
- nangka

katakunci: nona manis nangka 
nutrition: 129 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Dinner

---


![Nona Manis Nangka](https://img-global.cpcdn.com/recipes/c9d0e575e2e11ff3/680x482cq70/nona-manis-nangka-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti nona manis nangka yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa keistimewahan yang merupakan keragaman Nusantara



Kedekatan keluarga bisa didapat dengan cara sederhana. Salah satunya adalah memasak Nona Manis Nangka untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang bisa anda buat salah satunya nona manis nangka yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep nona manis nangka tanpa harus bersusah payah.
Berikut ini resep Nona Manis Nangka yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 18 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona Manis Nangka:

1. Harap siapkan  Bahan A:
1. Harap siapkan 140 gram tepung terigu
1. Dibutuhkan 2 butir telur
1. Siapkan 250 ml santan
1. Diperlukan 80 gram gula pasir
1. Dibutuhkan 100 gram buah nangka
1. Harap siapkan  Bahan B:
1. Diperlukan 250 ml santan
1. Tambah 40 gram gula pasir
1. Siapkan 30 gram tepung maizena
1. Harus ada 1/4 sdt garam
1. Jangan lupa 4 tetes pasta pandan
1. Siapkan  Bahan C:
1. Harus ada 500 ml santan kental
1. Siapkan 3 sdm tepung terigu
1. Dibutuhkan 1/4 sdt garam
1. Diperlukan  Bahan lain:
1. Harus ada 2 liter air
1. Harap siapkan 1 sdm minyak goreng




<!--inarticleads2-->

##### Cara membuat  Nona Manis Nangka:

1. Cuci nangka sampai bersih dan buang bijinya
1. Potong buah nangka menjadi potongan dadu kecil
1. Olesi cetakan kue Nona Manis dengan minyak goreng
1. Masak Bahan B:
1. Campur semua bahan B pada panci dan masak sampai mengental dan meletup-letup(gunakan api kecil dan terus diaduk). Diamkan sampai dingin dan sisihkan
1. Masak Bahan C:
1. Masukkan semua bahan C dalam panci /wadah dan aduk sampai rata lalu saring(agar tidak bergerindil)
1. Masak sampai mengental dan meletup-letup(masak dengan api kecil dan terus diaduk agar santan tidak pecah).Diamkan sampai dingin
1. Jika bahan C sudah dingin masukkan pada plastik segitiga
1. Panaskan alat kukus sambil kita membuat adonan dari bahan A
1. Kocok telur dan gula sampai mengembang.Turunkan kecepatan mixer, masukkan santan dan terigu secara bergantian sampai semua tercampur rata
1. Campurkan (mixer) adonan bahan B yang sudah dingin dengan adonan bahan A sampai tercampur merata
1. Tambahkan nangka dan aduk kembali sampai rata
1. Tuang adonan pandan nangka (campuran adonan A dan B) sampai 3/4 dari cetakan
1. Gunting ujung plastik segitiga dan semprotkan adonan C di tengah adonan pandan nangka(tenggelamkan ujung plastik kira-kira ditengah-tengah cetakan dan tekan plastik sampai adonan putih atau adonan C muncul)
1. Jika air kukusan sudah mendidih masukan adonan yang sudah dicetak pada pengukus dan kukus kurang lebih 10-15 menit dengan api sedang
1. Jika kue sudah matang angkat dan dinginkan
1. Setelah kue dingin, keluarkan kue dari cetakan dan sajikan




Demikianlah cara membuat nona manis nangka yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
