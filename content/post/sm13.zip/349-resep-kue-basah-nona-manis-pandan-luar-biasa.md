---
description: "Resep : Kue basah nona manis pandan 🍃 Luar biasa"
title: "Resep : Kue basah nona manis pandan 🍃 Luar biasa"
slug: 349-resep-kue-basah-nona-manis-pandan-luar-biasa
date: 2020-11-27T23:51:42.050Z
image: https://img-global.cpcdn.com/recipes/01c09a09f76e460d/680x482cq70/kue-basah-nona-manis-pandan-🍃-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/01c09a09f76e460d/680x482cq70/kue-basah-nona-manis-pandan-🍃-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/01c09a09f76e460d/680x482cq70/kue-basah-nona-manis-pandan-🍃-foto-resep-utama.jpg
author: Richard Francis
ratingvalue: 4
reviewcount: 36077
recipeingredient:
- " Bahan pertama "
- "140 gram tepung terigu"
- "250 ml santan"
- "80 gram gula pasir"
- "1 biji telur ayam"
- " Bahan ke 2 "
- "250 ml santan"
- "30 gram tepung meizena"
- "40 gram gula pasir"
- "1/2 sdt garam"
- " Bahan ke 3 "
- "400 ml santan"
- "5 sdm tepung terigu"
- "1/2 sdt garam"
- " Bahan pelengkap "
- " Pasta pandansari pandan asli yg sdh di blender dan di saring"
- " Minyak goreng dan kuas"
- "Plastik segitiga kalo ga ada bisa gunakan plastik gula bening"
- " Cetakan"
recipeinstructions:
- "Masak bahan ke 2 : Masukan santan, tepung meizena, garam, gula pasir (aduk sampai rata agar tepung tidak menggumpal) kemudian hidupkan api,aduk sampai kental dan mendidih.. tunggu hingga dingin"
- "Masak bahan ke 3 : masukan santan, garam, tepung terigu (aduk sampai rata agar tepung tidak menggumpal) kemudian hidupkan api, aduk sampai kental dan mendidih.. tunggu hingga dingin"
- "Kocok bahan pertama : telur, gula (sampai berbuih)"
- "Tambahkan santan kental, tepung terigu sedikit demi sedikit (aduk sampai rata) note : ini msih bahan pertama ya"
- "Campurkan bahan ke 2 yg sudah direbus dan di dinginkan tadi ke bahan pertama, aduk sampai tercampur rata"
- "Tambahkan pasta pandan setitik, (kalo saya campur dg sari pandan asli yg sudah blender dan di saring) tpi kalo ga ada bisa skip"
- "Aduk adonan sampai tercampur rata"
- "Masukkan bahan/adonan ke 3 ke dalam plastik segitiga bening (untuk Vla di atas kue)"
- "Oleskan minyak goreng pada cetakan agar tidak lengket"
- "Tuang adonan warna hijau ke dalam cetakan sebanyak 3/4 bagian dan tuang vla putih secara melingkar diatas adonan hijau"
- "Kukus kue kurang lebih 30 menit,gunakan tutup yg dibungkus serbet"
- "Sajikan :)"
categories:
- Recipe
tags:
- kue
- basah
- nona

katakunci: kue basah nona 
nutrition: 111 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Lunch

---


![Kue basah nona manis pandan 🍃](https://img-global.cpcdn.com/recipes/01c09a09f76e460d/680x482cq70/kue-basah-nona-manis-pandan-🍃-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis dan gurih. Karasteristik makanan Nusantara kue basah nona manis pandan 🍃 yang kaya dengan bumbu memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kue talam ini teksturnya lembut (tidak kenyal), rasanya gurih dan manis. Cara Membuat Kue Talam Pandan Yang Super Lembut dan Wangi. #kuenonamanispandan #resepkuenonamanis #kuenonamanishai semua. ketemu lagi dichannel youtube atha naufal, hari ini mama buat kue tradisional kue nona. Sepintas kue ape ini nampak mirip seperti bentuk kue serabi yang berasal dari Solo, namun kue ini lebih tipis serta bagian tengahnya sedikit basah dan tebal. Kue ini pada umumnya berwarna hijau, pinggiran dari kue ini memiliki tekstur yang garing dan renyah.

Kedekatan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah memasak Kue basah nona manis pandan 🍃 untuk orang di rumah. Momen makan bersama orang tua sudah menjadi budaya, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang bisa anda coba salah satunya kue basah nona manis pandan 🍃 yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep kue basah nona manis pandan 🍃 tanpa harus bersusah payah.
Berikut ini resep Kue basah nona manis pandan 🍃 yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 12 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue basah nona manis pandan 🍃:

1. Tambah  Bahan pertama :
1. Harap siapkan 140 gram tepung terigu
1. Tambah 250 ml santan
1. Tambah 80 gram gula pasir
1. Tambah 1 biji telur ayam
1. Jangan lupa  Bahan ke 2 :
1. Jangan lupa 250 ml santan
1. Harus ada 30 gram tepung meizena
1. Diperlukan 40 gram gula pasir
1. Harap siapkan 1/2 sdt garam
1. Harus ada  Bahan ke 3 :
1. Siapkan 400 ml santan
1. Diperlukan 5 sdm tepung terigu
1. Diperlukan 1/2 sdt garam
1. Diperlukan  Bahan pelengkap :
1. Diperlukan  Pasta pandan/sari pandan asli yg sdh di blender dan di saring
1. Jangan lupa  Minyak goreng dan kuas
1. Harap siapkan Plastik segitiga (kalo ga ada bisa gunakan plastik gula bening)
1. Dibutuhkan  Cetakan


Simak resep bahan dan cara membuat kue nona manis yang berpadu pandan dan vla santan gurih. Merdeka.com - Satu lagi resep kue basah yang bisa dipraktikkan di rumah. Kali ini kue nona manis yang memadukan santan dan pandan. Lihat juga resep Kue Cantik Manis dan Cara memasak Sagu Mutiara enak lainnya. 

<!--inarticleads2-->

##### Instruksi membuat  Kue basah nona manis pandan 🍃:

1. Masak bahan ke 2 : Masukan santan, tepung meizena, garam, gula pasir (aduk sampai rata agar tepung tidak menggumpal) kemudian hidupkan api,aduk sampai kental dan mendidih.. tunggu hingga dingin
1. Masak bahan ke 3 : masukan santan, garam, tepung terigu (aduk sampai rata agar tepung tidak menggumpal) kemudian hidupkan api, aduk sampai kental dan mendidih.. tunggu hingga dingin
1. Kocok bahan pertama : telur, gula (sampai berbuih)
1. Tambahkan santan kental, tepung terigu sedikit demi sedikit (aduk sampai rata) note : ini msih bahan pertama ya
1. Campurkan bahan ke 2 yg sudah direbus dan di dinginkan tadi ke bahan pertama, aduk sampai tercampur rata
1. Tambahkan pasta pandan setitik, (kalo saya campur dg sari pandan asli yg sudah blender dan di saring) tpi kalo ga ada bisa skip
1. Aduk adonan sampai tercampur rata
1. Masukkan bahan/adonan ke 3 ke dalam plastik segitiga bening (untuk Vla di atas kue)
1. Oleskan minyak goreng pada cetakan agar tidak lengket
1. Tuang adonan warna hijau ke dalam cetakan sebanyak 3/4 bagian dan tuang vla putih secara melingkar diatas adonan hijau
1. Kukus kue kurang lebih 30 menit,gunakan tutup yg dibungkus serbet
1. Sajikan :)


Kali ini kue nona manis yang memadukan santan dan pandan. Lihat juga resep Kue Cantik Manis dan Cara memasak Sagu Mutiara enak lainnya. Resep Kue Talam Pandan Kue Nona Manis. Resep Kue Basah Putu Pandan Kue Tradisional Ala Rumahan. atha naufal. Kumpulan resep kue basah yang gampang dibuat. 

Demikianlah cara membuat kue basah nona manis pandan 🍃 yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
