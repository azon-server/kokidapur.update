---
description: "Step-by-Step untuk membuat Cumi Saus Padang! Terbukti"
title: "Step-by-Step untuk membuat Cumi Saus Padang! Terbukti"
slug: 53-step-by-step-untuk-membuat-cumi-saus-padang-terbukti
date: 2021-01-24T17:30:45.981Z
image: https://img-global.cpcdn.com/recipes/ca899893c1253aa7/680x482cq70/cumi-saus-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ca899893c1253aa7/680x482cq70/cumi-saus-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ca899893c1253aa7/680x482cq70/cumi-saus-padang-foto-resep-utama.jpg
author: Emma Washington
ratingvalue: 4.3
reviewcount: 36402
recipeingredient:
- "500 gr cumi flower"
- "1 sdt cukabisa diganti perasan jeruk"
- "2-3 sdm minyak untuk menumis"
- "1 butir telur kocok lepas"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "1 btg serai geprek"
- "1 cm jahe iris tipis"
- "1/2 buah bawang bombay iris"
- "1/4 sdt merica bubuk"
- "1 sdt kaldu jamur"
- "1/4 sdt garam optional"
- "5-6 sdm saus tomat"
- "1 sdm minyak wijen"
- "1 sdm kecap inggris"
- " Bumbu Iris"
- "4 buah bawang merah"
- "3 siung bawang putih"
- "3 buah cabe merah boleh ditambah cabe rawit"
- "secukupnya Air"
recipeinstructions:
- "Siapkan wajan beri minyak. Masukkan kocokkan telur, buat orak arik."
- "Masukkan bumbu halus, daun jeruk, daun salam, serai, jahe dan jagung aduk-aduk sampai kuah menyusut."
- "Masukkan cumi dan aduk rata. Masukkan bawang bombay, air dan sisa bumbu lainnya. Masak sampai kuah sedikit menyusut (masaknya jangan terlalu lama agar cumi tidak alot). Tes rasa dan matikan api."
- "Sajikan selagi hangat."
categories:
- Recipe
tags:
- cumi
- saus
- padang

katakunci: cumi saus padang 
nutrition: 297 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT44M"
recipeyield: "3"
recipecategory: Lunch

---


![Cumi Saus Padang!](https://img-global.cpcdn.com/recipes/ca899893c1253aa7/680x482cq70/cumi-saus-padang-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan enak. Ciri khas makanan Nusantara cumi saus padang! yang penuh dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan keluarga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Cumi Saus Padang! untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang bisa anda contoh salah satunya cumi saus padang! yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep cumi saus padang! tanpa harus bersusah payah.
Seperti resep Cumi Saus Padang! yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Cumi Saus Padang!:

1. Harap siapkan 500 gr cumi flower
1. Harus ada 1 sdt cuka(bisa diganti perasan jeruk)
1. Jangan lupa 2-3 sdm minyak untuk menumis
1. Diperlukan 1 butir telur, kocok lepas
1. Dibutuhkan 3 lembar daun salam
1. Jangan lupa 3 lembar daun jeruk
1. Harap siapkan 1 btg serai, geprek
1. Tambah 1 cm jahe, iris tipis
1. Tambah 1/2 buah bawang bombay, iris
1. Siapkan 1/4 sdt merica bubuk
1. Tambah 1 sdt kaldu jamur
1. Harus ada 1/4 sdt garam (optional)
1. Siapkan 5-6 sdm saus tomat
1. Jangan lupa 1 sdm minyak wijen
1. Tambah 1 sdm kecap inggris
1. Jangan lupa  Bumbu Iris:
1. Jangan lupa 4 buah bawang merah
1. Harus ada 3 siung bawang putih
1. Harus ada 3 buah cabe merah (boleh ditambah cabe rawit)
1. Jangan lupa secukupnya Air




<!--inarticleads2-->

##### Bagaimana membuat  Cumi Saus Padang!:

1. Siapkan wajan beri minyak. Masukkan kocokkan telur, buat orak arik.
1. Masukkan bumbu halus, daun jeruk, daun salam, serai, jahe dan jagung aduk-aduk sampai kuah menyusut.
1. Masukkan cumi dan aduk rata. Masukkan bawang bombay, air dan sisa bumbu lainnya. Masak sampai kuah sedikit menyusut (masaknya jangan terlalu lama agar cumi tidak alot). Tes rasa dan matikan api.
1. Sajikan selagi hangat.




Demikianlah cara membuat cumi saus padang! yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan terbukti, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
