---
description: "Resep : Nona manis ubi ungu panggang Cepat"
title: "Resep : Nona manis ubi ungu panggang Cepat"
slug: 297-resep-nona-manis-ubi-ungu-panggang-cepat
date: 2020-10-17T09:45:00.451Z
image: https://img-global.cpcdn.com/recipes/c86b5ff1d89ac301/680x482cq70/nona-manis-ubi-ungu-panggang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c86b5ff1d89ac301/680x482cq70/nona-manis-ubi-ungu-panggang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c86b5ff1d89ac301/680x482cq70/nona-manis-ubi-ungu-panggang-foto-resep-utama.jpg
author: Cecelia Luna
ratingvalue: 4.3
reviewcount: 3613
recipeingredient:
- "150 gr ubi ungu kukus haluskan"
- "3 sdm tepung terigu"
- "3 sdm gula pasir"
- "100 ml santan instan  50 ml air untuk membersihkan kotak santan"
- "1 butir telur"
- " Bahan putih"
- "1 sdm tepung terigu"
- "100 ml santan kental"
- "Sejumput garam"
recipeinstructions:
- "Campurkan ubi ungu kukus yang sudah dihaluskan dengan telur &amp; gula pasir."
- "Tambahkan tepung terigu &amp; santan."
- "Campur dalam wajan bahan putih. Masak hingga mengental sambil diaduk supaya tidak bergerindil."
- "Panaskan cetakan yang sudah diolesi minyak makan."
- "Masukan adonan ungu, lalu masukan adonan putih di tengah."
- "Jika adonan putih sudah dimasukan, tutup dan masak hingga kue matang."
- "Jika sudah matang sajikan."
categories:
- Recipe
tags:
- nona
- manis
- ubi

katakunci: nona manis ubi 
nutrition: 175 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Dinner

---


![Nona manis ubi ungu panggang](https://img-global.cpcdn.com/recipes/c86b5ff1d89ac301/680x482cq70/nona-manis-ubi-ungu-panggang-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga gurih. Ciri khas makanan Nusantara nona manis ubi ungu panggang yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah memasak Nona manis ubi ungu panggang untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang dapat anda coba salah satunya nona manis ubi ungu panggang yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep nona manis ubi ungu panggang tanpa harus bersusah payah.
Berikut ini resep Nona manis ubi ungu panggang yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 9 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona manis ubi ungu panggang:

1. Harap siapkan 150 gr ubi ungu kukus, haluskan
1. Dibutuhkan 3 sdm tepung terigu
1. Diperlukan 3 sdm gula pasir
1. Diperlukan 100 ml santan instan + 50 ml air untuk membersihkan kotak santan
1. Diperlukan 1 butir telur
1. Jangan lupa  Bahan putih:
1. Dibutuhkan 1 sdm tepung terigu
1. Siapkan 100 ml santan kental
1. Dibutuhkan Sejumput garam




<!--inarticleads2-->

##### Bagaimana membuat  Nona manis ubi ungu panggang:

1. Campurkan ubi ungu kukus yang sudah dihaluskan dengan telur &amp; gula pasir.
1. Tambahkan tepung terigu &amp; santan.
1. Campur dalam wajan bahan putih. Masak hingga mengental sambil diaduk supaya tidak bergerindil.
1. Panaskan cetakan yang sudah diolesi minyak makan.
1. Masukan adonan ungu, lalu masukan adonan putih di tengah.
1. Jika adonan putih sudah dimasukan, tutup dan masak hingga kue matang.
1. Jika sudah matang sajikan.




Demikianlah cara membuat nona manis ubi ungu panggang yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
