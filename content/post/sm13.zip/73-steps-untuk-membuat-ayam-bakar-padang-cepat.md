---
description: "Steps untuk membuat Ayam Bakar Padang Cepat"
title: "Steps untuk membuat Ayam Bakar Padang Cepat"
slug: 73-steps-untuk-membuat-ayam-bakar-padang-cepat
date: 2021-01-23T20:00:53.070Z
image: https://img-global.cpcdn.com/recipes/7c02c20c5fd9fedb/680x482cq70/ayam-bakar-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7c02c20c5fd9fedb/680x482cq70/ayam-bakar-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7c02c20c5fd9fedb/680x482cq70/ayam-bakar-padang-foto-resep-utama.jpg
author: Maggie Terry
ratingvalue: 4
reviewcount: 47683
recipeingredient:
- "1 ekor ayam kampung atau negri 4 potong"
- "1 buah jeruk nipis peras airnya"
- "400 ml santan kental"
- "200 ml air"
- "2 btg seraigeprek"
- "2 buah asam kandis"
- "4 lbr daun jeruk"
- "2 lbr daun salam"
- "1/2 sdt penyedap rasa totole"
- "1/2 sdt garam halus"
- " bahan halus"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "3 cm jahe"
- "2 cm lengkuas"
- "5 buah kemirisangrai"
- "6 buah cabe merah keriting"
- "5 buah cabai rawitme udh giling halus"
- "3 cm kunyit me pakai kunyit bubuk"
recipeinstructions:
- "Siapkan semua bahan terlebih dahulu, lalu bersihkan dan potong ayam jadi 4 bagian yah, karna salah beli ayam jdnya pakai yang dada semua. lalu baluri dengan perasan air jeruk nipis dan beri garam halus sedikit kemudian diamkan 15 menit."
- "Siapkan blender lalu masukkan bahan bumbu halus semuanya lalu blender sampai halus. kemudian tuang bumbu di wadah dan sisihkan."
- "Siapkan wajan beri sedikit minyak goreng lalu masukkan bumbu halus tumis sampai harum, kemudian masukkan kunyit bubuk, serai, daun salam dan daun jeruk."
- "Setelah itu baru masukkan santan kental sedikit demi sedikit dan air aduk sampai tercampur rata masukkan sedikit cabai rawit yang sudah dihaluskan."
- "Kemudian baru masukkan potongan ayam,garam halus,dan penyedap rasa aduk rata lalu cicip rasa nya yah."
- "Masak ayam sampai matang dan menyusut kuahnya, jika mw cepet bs di tutup yah. setelah ayamnya matang dan empuk angkat ayam lalu siapkan oven dan tinggal di panggang."
- "Panggang ayam kedalam oven selama 25-30 menit ya sesuai dengan oven masing-masing atau sesuai selera, sudah matang kecoklatan angkat dan keluarkan dari oven."
- "Setelah itu ayam siap disantap dan dihidangkan,selamat mencoba ya"
categories:
- Recipe
tags:
- ayam
- bakar
- padang

katakunci: ayam bakar padang 
nutrition: 203 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Bakar Padang](https://img-global.cpcdn.com/recipes/7c02c20c5fd9fedb/680x482cq70/ayam-bakar-padang-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang harus kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam bakar padang yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan keistimewahan yang merupakan keragaman Indonesia



Kedekatan keluarga dapat diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam Bakar Padang untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda praktekkan salah satunya ayam bakar padang yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam bakar padang tanpa harus bersusah payah.
Berikut ini resep Ayam Bakar Padang yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 19 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Bakar Padang:

1. Tambah 1 ekor ayam kampung atau negri (4 potong)
1. Harus ada 1 buah jeruk nipis (peras airnya)
1. Dibutuhkan 400 ml santan kental
1. Tambah 200 ml air
1. Jangan lupa 2 btg serai,geprek
1. Diperlukan 2 buah asam kandis
1. Siapkan 4 lbr daun jeruk
1. Dibutuhkan 2 lbr daun salam
1. Tambah 1/2 sdt penyedap rasa totole
1. Tambah 1/2 sdt garam halus
1. Harus ada  bahan halus:
1. Tambah 8 siung bawang merah
1. Harap siapkan 5 siung bawang putih
1. Tambah 3 cm jahe
1. Dibutuhkan 2 cm lengkuas
1. Harus ada 5 buah kemiri,sangrai
1. Dibutuhkan 6 buah cabe merah keriting
1. Diperlukan 5 buah cabai rawit,(me: udh giling halus)
1. Diperlukan 3 cm kunyit (me pakai kunyit bubuk)




<!--inarticleads2-->

##### Cara membuat  Ayam Bakar Padang:

1. Siapkan semua bahan terlebih dahulu, lalu bersihkan dan potong ayam jadi 4 bagian yah, karna salah beli ayam jdnya pakai yang dada semua. lalu baluri dengan perasan air jeruk nipis dan beri garam halus sedikit kemudian diamkan 15 menit.
1. Siapkan blender lalu masukkan bahan bumbu halus semuanya lalu blender sampai halus. kemudian tuang bumbu di wadah dan sisihkan.
1. Siapkan wajan beri sedikit minyak goreng lalu masukkan bumbu halus tumis sampai harum, kemudian masukkan kunyit bubuk, serai, daun salam dan daun jeruk.
1. Setelah itu baru masukkan santan kental sedikit demi sedikit dan air aduk sampai tercampur rata masukkan sedikit cabai rawit yang sudah dihaluskan.
1. Kemudian baru masukkan potongan ayam,garam halus,dan penyedap rasa aduk rata lalu cicip rasa nya yah.
1. Masak ayam sampai matang dan menyusut kuahnya, jika mw cepet bs di tutup yah. setelah ayamnya matang dan empuk angkat ayam lalu siapkan oven dan tinggal di panggang.
1. Panggang ayam kedalam oven selama 25-30 menit ya sesuai dengan oven masing-masing atau sesuai selera, sudah matang kecoklatan angkat dan keluarkan dari oven.
1. Setelah itu ayam siap disantap dan dihidangkan,selamat mencoba ya




Demikianlah cara membuat ayam bakar padang yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan teruji, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
