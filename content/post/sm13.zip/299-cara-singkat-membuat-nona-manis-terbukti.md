---
description: "Cara singkat membuat Nona manis Terbukti"
title: "Cara singkat membuat Nona manis Terbukti"
slug: 299-cara-singkat-membuat-nona-manis-terbukti
date: 2021-01-01T17:19:48.905Z
image: https://img-global.cpcdn.com/recipes/38e99c975f169a7f/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/38e99c975f169a7f/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/38e99c975f169a7f/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Lillie Santiago
ratingvalue: 4.1
reviewcount: 3080
recipeingredient:
- " Bahan santanlalaan"
- "2 cangkir santan kental"
- "3 sdm tepung beras"
- "4 sdm gula pasirsesuai selera"
- "1 sdt garam"
- " Bahan 2"
- "2 cangkir tepung terigu"
- "2 telor ayam"
- "2 cangkir gula pasir"
- "2 cangkir santan kental"
- " bahan 3"
- "1/2 cangkir tepung beras"
- "1/2 cangkir gula pasir"
- "secukupnya Daun pandanSuji"
- "sejumput Garam"
- "2 cangkir santan"
recipeinstructions:
- "Pertama kita bikin santan/lalaan,campur semua bahan 1 lalu aduk sampai mengental lalu dinginkan"
- "Lanjut bahan kedua mixer telor+gula sampai tercampur rata lalu masukkan tepung secara perlahan dan sambil tuang santan kental yang sudah di masak ya"
- "Blender daun Suji +pandan yg di pakai air santan buat blendernya sampai halus dan saring,,setelah di saring campur gula dan tepung beras lalu masak sampai mengental..."
- "Setelah bahan 3 sudah mengental masukkan bahan 3 ke adonan bahan 2 mixer lagi sampe tercampur rata,,,,jika berasa pucat bisa kasih 3 tetes pewarna hijau sy pake merk kupu kupu.."
- "Masukkan dalam cetakan dan tuang/semprot adonan santan/lalaan ketengah adonan ya siap di gunakan dan kukus selama kurleb 12 menit"
- "Setelah di kukus diamkan dan dinginkan lalu keluarkan dari cetakan"
- "Selamat menikmati,,wangi banget ini kue"
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 139 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dessert

---


![Nona manis](https://img-global.cpcdn.com/recipes/38e99c975f169a7f/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti nona manis yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa ciri khas yang merupakan keragaman Kita

Kedekatan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Nona manis untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang dapat anda contoh salah satunya nona manis yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep nona manis tanpa harus bersusah payah.
Berikut ini resep Nona manis yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona manis:

1. Siapkan  Bahan santan/lalaan:
1. Dibutuhkan 2 cangkir santan kental
1. Tambah 3 sdm tepung beras
1. Tambah 4 sdm gula pasir/sesuai selera
1. Diperlukan 1 sdt garam
1. Jangan lupa  Bahan 2:
1. Diperlukan 2 cangkir tepung terigu
1. Dibutuhkan 2 telor ayam
1. Tambah 2 cangkir gula pasir
1. Harap siapkan 2 cangkir santan kental
1. Siapkan  bahan 3:
1. Harus ada 1/2 cangkir tepung beras
1. Harap siapkan 1/2 cangkir gula pasir
1. Diperlukan secukupnya Daun pandan+Suji
1. Siapkan sejumput Garam
1. Siapkan 2 cangkir santan




<!--inarticleads2-->

##### Cara membuat  Nona manis:

1. Pertama kita bikin santan/lalaan,campur semua bahan 1 lalu aduk sampai mengental lalu dinginkan
1. Lanjut bahan kedua mixer telor+gula sampai tercampur rata lalu masukkan tepung secara perlahan dan sambil tuang santan kental yang sudah di masak ya
1. Blender daun Suji +pandan yg di pakai air santan buat blendernya sampai halus dan saring,,setelah di saring campur gula dan tepung beras lalu masak sampai mengental...
1. Setelah bahan 3 sudah mengental masukkan bahan 3 ke adonan bahan 2 mixer lagi sampe tercampur rata,,,,jika berasa pucat bisa kasih 3 tetes pewarna hijau sy pake merk kupu kupu..
1. Masukkan dalam cetakan dan tuang/semprot adonan santan/lalaan ketengah adonan ya siap di gunakan dan kukus selama kurleb 12 menit
1. Setelah di kukus diamkan dan dinginkan lalu keluarkan dari cetakan
1. Selamat menikmati,,wangi banget ini kue




Demikianlah cara membuat nona manis yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan cepat, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
