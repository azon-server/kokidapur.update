---
description: "Cara singkat membuat Kue nona manis Sempurna"
title: "Cara singkat membuat Kue nona manis Sempurna"
slug: 375-cara-singkat-membuat-kue-nona-manis-sempurna
date: 2020-10-20T01:14:16.830Z
image: https://img-global.cpcdn.com/recipes/e9a40526b732b4df/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e9a40526b732b4df/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e9a40526b732b4df/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Brett Graves
ratingvalue: 4.1
reviewcount: 49440
recipeingredient:
- " Bahan A"
- "1 butir telur kocok lepas"
- "125 gr tepung terigu"
- "125 gr gula pasir bisa dikurangi kalau tidak suka manis"
- "250 ml santan"
- " Bahan B"
- "125 ml sari pandan 8 lbr pandan betawi  air blender saring"
- "125 ml santan"
- "60 gr gula pasir"
- "30 gr tepung maizena"
- "1 sdt garam"
- " Bahan C"
- "250 ml santan kental"
- "1 sdm munjung tepung terigu"
- "1 sdm gula pasir"
- "1 sdt garam"
recipeinstructions:
- "Untuk bahan A : campurkan tepung terigu dan gula. Masukan santan, lalu aduk menggunakan whisk. Kemudian, masukan telur, aduk rata. Sisihkan."
- "Untuk bahan B : campurkan semua bahan, aduk rata menggunakan whisk."
- "Masak adonan bahan B dengan api kecil, aduk hingga meletup-letup, matikan api, lalu masukan adonan bahan A sambil terus diaduk."
- "Untuk bahan C : masukan semua bahan, aduk menggunakan whisk, lalu masak sambil terus diaduk hingga meletup-letup. Masukan kedalam piping bag selagi hangat."
- "Oleskan sedikit minyak pada cetakan, masukan 2/3 cetakan adonan hijau, lalu semprotkan adonan putih dibagian tengahnya."
- "Kukus hingga matang selama 15-20 menit."
- "Dinginkan dulu beberapa menit sebelum dikeluarkan dari cetakan."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 127 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dessert

---


![Kue nona manis](https://img-global.cpcdn.com/recipes/e9a40526b732b4df/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti kue nona manis yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Indonesia



Kehangatan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Kue nona manis untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang bisa anda contoh salah satunya kue nona manis yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue nona manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue nona manis:

1. Jangan lupa  Bahan A
1. Siapkan 1 butir telur (kocok lepas)
1. Diperlukan 125 gr tepung terigu
1. Harus ada 125 gr gula pasir (bisa dikurangi kalau tidak suka manis)
1. Harap siapkan 250 ml santan
1. Dibutuhkan  Bahan B
1. Jangan lupa 125 ml sari pandan (8 lbr pandan betawi + air, blender, saring)
1. Dibutuhkan 125 ml santan
1. Harap siapkan 60 gr gula pasir
1. Siapkan 30 gr tepung maizena
1. Dibutuhkan 1 sdt garam
1. Jangan lupa  Bahan C
1. Jangan lupa 250 ml santan kental
1. Harus ada 1 sdm munjung tepung terigu
1. Dibutuhkan 1 sdm gula pasir
1. Tambah 1 sdt garam




<!--inarticleads2-->

##### Langkah membuat  Kue nona manis:

1. Untuk bahan A : campurkan tepung terigu dan gula. Masukan santan, lalu aduk menggunakan whisk. Kemudian, masukan telur, aduk rata. Sisihkan.
1. Untuk bahan B : campurkan semua bahan, aduk rata menggunakan whisk.
1. Masak adonan bahan B dengan api kecil, aduk hingga meletup-letup, matikan api, lalu masukan adonan bahan A sambil terus diaduk.
1. Untuk bahan C : masukan semua bahan, aduk menggunakan whisk, lalu masak sambil terus diaduk hingga meletup-letup. Masukan kedalam piping bag selagi hangat.
1. Oleskan sedikit minyak pada cetakan, masukan 2/3 cetakan adonan hijau, lalu semprotkan adonan putih dibagian tengahnya.
1. Kukus hingga matang selama 15-20 menit.
1. Dinginkan dulu beberapa menit sebelum dikeluarkan dari cetakan.




Demikianlah cara membuat kue nona manis yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
