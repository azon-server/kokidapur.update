---
description: "Steps untuk menyiapakan Kue Nona Manis Terbukti"
title: "Steps untuk menyiapakan Kue Nona Manis Terbukti"
slug: 252-steps-untuk-menyiapakan-kue-nona-manis-terbukti
date: 2020-09-25T02:43:53.769Z
image: https://img-global.cpcdn.com/recipes/f671e33d67f5c88b/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f671e33d67f5c88b/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f671e33d67f5c88b/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Leon Mason
ratingvalue: 5
reviewcount: 43085
recipeingredient:
- " Bahan 1"
- "250 ml santan kental"
- "80 gr gula pasir"
- "1 btr telur"
- "140 gr tepung terigu"
- " Bahan 2"
- "250 gr santan kental"
- "40 gr gula pasir"
- "30 gr maizena"
- "Sejumput garam"
- " Pasta pandan"
- " Bahan 3"
- "500 ml santan kental"
- "6 sdm terigu"
- "Sejumput garam"
recipeinstructions:
- "Campur bahan 2 aduk rata dan masak sampai mengental.matikan api.sisihkan.siapkan wadah masukan telur dan gula mixer hingga kental,masukan terigu selang seling dengan santan dengan kecepatan rendah.masukan adonan yg disisihkan tadi sedikit sedikit hingga rata.matikan mixer.sisihkan"
- "Siapkan panci masukan semua bahan 3 aduk rata dan masak sampai mengental sambil diaduk supaya tidak bergerindil.matikan api.adonan ini harus kental dan ga bergerindil ya kalo encer nanti amblas pas matang.masukan ke botol kecap(aku pake plastik segitiga gunting ujungnya).ambil cetakan kue talam oles minyak tuang adonan hijau 3/4penuh"
- "Kemudian semprotkan adonan putih dengan cara membenamkan moncong botol atau plastik segitiga sampai penuh.panaskan kukusan hingga beruap banyak.kukus kue nona manis dengan api sedang selama 15-20menit.matikan api.biarkan dingin baru lepas pelan pelan dari cetakan.o ya ini linknya ya kali aja mau lihat caranya🙏 :https://youtu.be/M7j6cUs-YeM"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 151 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Dessert

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/f671e33d67f5c88b/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti kue nona manis yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa keistimewahan yang merupakan keragaman Kita



Keharmonisan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Kue Nona Manis untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang dapat anda contoh salah satunya kue nona manis yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis:

1. Dibutuhkan  Bahan 1:
1. Tambah 250 ml santan kental
1. Jangan lupa 80 gr gula pasir
1. Diperlukan 1 btr telur
1. Dibutuhkan 140 gr tepung terigu
1. Diperlukan  Bahan 2:
1. Tambah 250 gr santan kental
1. Harus ada 40 gr gula pasir
1. Harap siapkan 30 gr maizena
1. Tambah Sejumput garam
1. Siapkan  Pasta pandan
1. Siapkan  Bahan 3:
1. Dibutuhkan 500 ml santan kental
1. Siapkan 6 sdm terigu
1. Tambah Sejumput garam




<!--inarticleads2-->

##### Cara membuat  Kue Nona Manis:

1. Campur bahan 2 aduk rata dan masak sampai mengental.matikan api.sisihkan.siapkan wadah masukan telur dan gula mixer hingga kental,masukan terigu selang seling dengan santan dengan kecepatan rendah.masukan adonan yg disisihkan tadi sedikit sedikit hingga rata.matikan mixer.sisihkan
1. Siapkan panci masukan semua bahan 3 aduk rata dan masak sampai mengental sambil diaduk supaya tidak bergerindil.matikan api.adonan ini harus kental dan ga bergerindil ya kalo encer nanti amblas pas matang.masukan ke botol kecap(aku pake plastik segitiga gunting ujungnya).ambil cetakan kue talam oles minyak tuang adonan hijau 3/4penuh
1. Kemudian semprotkan adonan putih dengan cara membenamkan moncong botol atau plastik segitiga sampai penuh.panaskan kukusan hingga beruap banyak.kukus kue nona manis dengan api sedang selama 15-20menit.matikan api.biarkan dingin baru lepas pelan pelan dari cetakan.o ya ini linknya ya kali aja mau lihat caranya🙏 :https://youtu.be/M7j6cUs-YeM




Demikianlah cara membuat kue nona manis yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
