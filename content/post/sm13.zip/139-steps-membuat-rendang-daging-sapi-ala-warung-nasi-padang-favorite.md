---
description: "Steps membuat Rendang Daging Sapi Ala Warung Nasi Padang Favorite"
title: "Steps membuat Rendang Daging Sapi Ala Warung Nasi Padang Favorite"
slug: 139-steps-membuat-rendang-daging-sapi-ala-warung-nasi-padang-favorite
date: 2020-10-09T21:00:11.870Z
image: https://img-global.cpcdn.com/recipes/634ff9dba722b425/680x482cq70/rendang-daging-sapi-ala-warung-nasi-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/634ff9dba722b425/680x482cq70/rendang-daging-sapi-ala-warung-nasi-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/634ff9dba722b425/680x482cq70/rendang-daging-sapi-ala-warung-nasi-padang-foto-resep-utama.jpg
author: Maria Green
ratingvalue: 4.4
reviewcount: 37604
recipeingredient:
- "1,5 kg daging sapi"
- "1200 ml santan dari 1 kg kelapa parut"
- " Bumbu Halus"
- "150 gram bawang merah"
- "50 gram bawang putih"
- "100 gram cabai merah"
- "10 gram kunyit"
- "10 gram sereh"
- "5 gram jahe"
- "5 gram lengkuas"
- "5 gram daun jeruk purut buang tulang daun goreng"
- "5 gram pala butir"
- "5 gram merica butir"
- "5 gram ketumbar sangrai"
- "5 gram jinten"
- "2 gram adas manis"
- "2 butir kapulaga boleh skip"
- "2 butir cengkeh boleh skip"
- "200 ml air"
- "50 ml minyak"
- " Perasa"
- "20 gram garam"
- "50 gram gula aren"
- "5 gram kaldu bubuk"
recipeinstructions:
- "Tumis bumbu halus hingga matang dan wangi (minyak terpisah dari bumbu) dengan api kecil"
- "Masukkan santan dan daging sapi, gunakan api sedang sekitar 1,5 jam. Tutup wajan dan lanjut masak dengan api kecil sambil tetap sesekali diaduk hingga 1,5 jam berikutnya"
- "Catatan : untuk tekstur dan rasa terbaik, setelah ditutup, lanjut masak selama setengah jam saja. Lalu diamkan dulu sekitar 12 jam (diinapkan). Lanjutkan proses memasak esok harinya. Total waktu memasak setelah daging dan santan masuk sekitar 3 s.d 4 jam, hingga kepekatan bumbu yang diinginkan. Foto diambil setelah 3 jam proses pemasakan daging"
categories:
- Recipe
tags:
- rendang
- daging
- sapi

katakunci: rendang daging sapi 
nutrition: 118 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Lunch

---


![Rendang Daging Sapi Ala Warung Nasi Padang](https://img-global.cpcdn.com/recipes/634ff9dba722b425/680x482cq70/rendang-daging-sapi-ala-warung-nasi-padang-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis atau empuk. Karasteristik kuliner Nusantara rendang daging sapi ala warung nasi padang yang penuh dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Rendang Daging Sapi Ala Warung Nasi Padang untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang dapat anda praktekkan salah satunya rendang daging sapi ala warung nasi padang yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep rendang daging sapi ala warung nasi padang tanpa harus bersusah payah.
Berikut ini resep Rendang Daging Sapi Ala Warung Nasi Padang yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 24 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Rendang Daging Sapi Ala Warung Nasi Padang:

1. Dibutuhkan 1,5 kg daging sapi
1. Harap siapkan 1200 ml santan dari 1 kg kelapa parut
1. Dibutuhkan  Bumbu Halus
1. Diperlukan 150 gram bawang merah
1. Siapkan 50 gram bawang putih
1. Harap siapkan 100 gram cabai merah
1. Diperlukan 10 gram kunyit
1. Tambah 10 gram sereh
1. Diperlukan 5 gram jahe
1. Siapkan 5 gram lengkuas
1. Dibutuhkan 5 gram daun jeruk purut, buang tulang daun, goreng
1. Diperlukan 5 gram pala butir
1. Harap siapkan 5 gram merica butir
1. Diperlukan 5 gram ketumbar sangrai
1. Harus ada 5 gram jinten
1. Tambah 2 gram adas manis
1. Siapkan 2 butir kapulaga (boleh skip)
1. Harus ada 2 butir cengkeh (boleh skip)
1. Tambah 200 ml air
1. Siapkan 50 ml minyak
1. Diperlukan  Perasa
1. Siapkan 20 gram garam
1. Harus ada 50 gram gula aren
1. Dibutuhkan 5 gram kaldu bubuk




<!--inarticleads2-->

##### Langkah membuat  Rendang Daging Sapi Ala Warung Nasi Padang:

1. Tumis bumbu halus hingga matang dan wangi (minyak terpisah dari bumbu) dengan api kecil
1. Masukkan santan dan daging sapi, gunakan api sedang sekitar 1,5 jam. Tutup wajan dan lanjut masak dengan api kecil sambil tetap sesekali diaduk hingga 1,5 jam berikutnya
1. Catatan : untuk tekstur dan rasa terbaik, setelah ditutup, lanjut masak selama setengah jam saja. Lalu diamkan dulu sekitar 12 jam (diinapkan). Lanjutkan proses memasak esok harinya. Total waktu memasak setelah daging dan santan masuk sekitar 3 s.d 4 jam, hingga kepekatan bumbu yang diinginkan. Foto diambil setelah 3 jam proses pemasakan daging




Demikianlah cara membuat rendang daging sapi ala warung nasi padang yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan terbukti, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
