---
description: "Cara singkat untuk membuat Udang cumi saus padang terupdate"
title: "Cara singkat untuk membuat Udang cumi saus padang terupdate"
slug: 164-cara-singkat-untuk-membuat-udang-cumi-saus-padang-terupdate
date: 2020-10-29T00:05:42.048Z
image: https://img-global.cpcdn.com/recipes/9a6bd09e9add72ee/680x482cq70/udang-cumi-saus-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9a6bd09e9add72ee/680x482cq70/udang-cumi-saus-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9a6bd09e9add72ee/680x482cq70/udang-cumi-saus-padang-foto-resep-utama.jpg
author: Estella Murphy
ratingvalue: 4.9
reviewcount: 19931
recipeingredient:
- "150 gr udang"
- "150 gr cumi"
- "1 buah jagung"
- " Bumbu halus "
- "5 siung bawang merah"
- "4 siung bawang putih"
- "5 buah cabe merah"
- "7 buah cabe rawit"
- "2 ruas jahe"
- " Bahan pelengkap "
- "3 lembar daun salam"
- "4 lembar daun jeruk"
- "1 buah sereh geprek"
- "1 buah daun bawang"
- "2 sdm saus sambal"
- "2 sdm saus tomat"
- "1 sdm saus tiram"
- "1 sdm kecap manis"
- "1 sdt garam"
- "1 sdt gula"
recipeinstructions:
- "Rebus jagung sampai matang, lalu rebus cumi dan udang sampai berubah warna tiriskan (mengurangi bau amis)"
- "Tumis bumbu halus sampai harum, lalu masukkan daun salam, daun jeruk dan sereh, aduk rata"
- "Tambahkan saus sambal, saus tomat, saus tiram, dan kecap manis, tambahkan sedikit air, jangan lupa garam dan gula. Koreksi rasa."
- "Terakhir masukkan cumi udang dan jagung, aduk2 masak sebentar. Taburi daun bawang, angkat dan sajikan.."
categories:
- Recipe
tags:
- udang
- cumi
- saus

katakunci: udang cumi saus 
nutrition: 249 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT44M"
recipeyield: "3"
recipecategory: Dinner

---


![Udang cumi saus padang](https://img-global.cpcdn.com/recipes/9a6bd09e9add72ee/680x482cq70/udang-cumi-saus-padang-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga renyah. Karasteristik makanan Indonesia udang cumi saus padang yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Udang cumi saus padang untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang bisa anda contoh salah satunya udang cumi saus padang yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep udang cumi saus padang tanpa harus bersusah payah.
Seperti resep Udang cumi saus padang yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Udang cumi saus padang:

1. Harus ada 150 gr udang
1. Diperlukan 150 gr cumi
1. Tambah 1 buah jagung
1. Dibutuhkan  Bumbu halus :
1. Jangan lupa 5 siung bawang merah
1. Harap siapkan 4 siung bawang putih
1. Dibutuhkan 5 buah cabe merah
1. Jangan lupa 7 buah cabe rawit
1. Dibutuhkan 2 ruas jahe
1. Harus ada  Bahan pelengkap :
1. Jangan lupa 3 lembar daun salam
1. Diperlukan 4 lembar daun jeruk
1. Diperlukan 1 buah sereh (geprek)
1. Siapkan 1 buah daun bawang
1. Diperlukan 2 sdm saus sambal
1. Tambah 2 sdm saus tomat
1. Diperlukan 1 sdm saus tiram
1. Siapkan 1 sdm kecap manis
1. Jangan lupa 1 sdt garam
1. Tambah 1 sdt gula




<!--inarticleads2-->

##### Cara membuat  Udang cumi saus padang:

1. Rebus jagung sampai matang, lalu rebus cumi dan udang sampai berubah warna tiriskan (mengurangi bau amis)
1. Tumis bumbu halus sampai harum, lalu masukkan daun salam, daun jeruk dan sereh, aduk rata
1. Tambahkan saus sambal, saus tomat, saus tiram, dan kecap manis, tambahkan sedikit air, jangan lupa garam dan gula. Koreksi rasa.
1. Terakhir masukkan cumi udang dan jagung, aduk2 masak sebentar. Taburi daun bawang, angkat dan sajikan..




Demikianlah cara membuat udang cumi saus padang yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
