---
description: "Resep : Nona manis Luar biasa"
title: "Resep : Nona manis Luar biasa"
slug: 367-resep-nona-manis-luar-biasa
date: 2021-01-24T05:28:13.667Z
image: https://img-global.cpcdn.com/recipes/689f40a97078cfcb/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/689f40a97078cfcb/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/689f40a97078cfcb/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Eva Peters
ratingvalue: 4.2
reviewcount: 39759
recipeingredient:
- "1 bahan"
- "2 gls tepung terigu"
- "1 gls gula pasir"
- "2 gls santan"
- "4 btr telur"
- "1/2 sdm garam"
- "2 bahan"
- "2 gls santan 20 daun suji5 daun pandan wangi blender"
- "1/2 gls gula"
- "1/2 gls tepung maizena"
- "sedikit garam"
- "3 bahan"
- "2 gls santan kental"
- "2 sdm terigu"
- "2 sdm gula"
- "1/2 sdt garam"
recipeinstructions:
- "Campur bahan 1,lalu mix"
- "Masak bahan 2 hingga kental n meletup.."
- "Masukan bahan 2, kedalam adonan bahan 1 mix hingga rata n lembut"
- "Siapakan kukusan.sambil menunggu kukusan panas masak bahan 3 hingga kental n meletup letup.."
- "Siapkan cetakan olesi dg sedikit minyak tuang adonan hijau..lalu tambahkan adonan 3. dtengahnya kukus selama 20 menit."
- "Selamat mencoba..."
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 265 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dinner

---


![Nona manis](https://img-global.cpcdn.com/recipes/689f40a97078cfcb/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau gurih. Ciri makanan Nusantara nona manis yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Nona manis untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda contoh salah satunya nona manis yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona manis:

1. Jangan lupa 1 bahan
1. Dibutuhkan 2 gls tepung terigu
1. Diperlukan 1 gls gula pasir
1. Dibutuhkan 2 gls santan
1. Harus ada 4 btr telur
1. Diperlukan 1/2 sdm garam
1. Siapkan 2 bahan
1. Jangan lupa 2 gls santan +20 daun suji+5 daun pandan wangi blender
1. Tambah 1/2 gls gula
1. Dibutuhkan 1/2 gls tepung maizena
1. Jangan lupa sedikit garam
1. Harus ada 3 bahan
1. Tambah 2 gls santan kental
1. Jangan lupa 2 sdm terigu
1. Harap siapkan 2 sdm gula
1. Dibutuhkan 1/2 sdt garam




<!--inarticleads2-->

##### Instruksi membuat  Nona manis:

1. Campur bahan 1,lalu mix
1. Masak bahan 2 hingga kental n meletup..
1. Masukan bahan 2, kedalam adonan bahan 1 mix hingga rata n lembut
1. Siapakan kukusan.sambil menunggu kukusan panas masak bahan 3 hingga kental n meletup letup..
1. Siapkan cetakan olesi dg sedikit minyak tuang adonan hijau..lalu tambahkan adonan 3. dtengahnya kukus selama 20 menit.
1. Selamat mencoba...




Demikianlah cara membuat nona manis yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan teruji, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
