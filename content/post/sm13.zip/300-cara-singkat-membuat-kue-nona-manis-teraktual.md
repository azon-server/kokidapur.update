---
description: "Cara singkat membuat Kue Nona Manis teraktual"
title: "Cara singkat membuat Kue Nona Manis teraktual"
slug: 300-cara-singkat-membuat-kue-nona-manis-teraktual
date: 2020-09-14T02:28:46.237Z
image: https://img-global.cpcdn.com/recipes/8a782b58b4b0cf09/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8a782b58b4b0cf09/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8a782b58b4b0cf09/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Kyle Cummings
ratingvalue: 4.4
reviewcount: 29748
recipeingredient:
- "1 Bahan"
- "50 gram gula pasir"
- "500 ml santan kental"
- "3 SDM maizena"
- "1/4 sdt garam"
- "secukupnya Pasta pandan"
- "2 Bahan"
- "500 mo santan kental"
- "3 SDM maizena"
- "secukupnya Garam"
- "3 Bahan"
- "2 butir telur"
- "250 tepung terigu"
- "60 gram maizena"
- "500 ml santan kental"
- "200 gram gula pasir"
recipeinstructions:
- "Campur semua bahan 1 (adonan hijau) kedalam panci, aduk rata"
- "Masak bahan 1 dengan api kecil sambil terus diaduk, masak sampai meletup 2 angkat dan dinginkan"
- "Campur semua bahan 2 dipanci lain"
- "Masak sambil terus diaduk hingga mengental dan meletup matikan api, biarkan hingga uap hilang lalu masukkan kedalam paping bag / botol kecap supaya mudah dituangkan."
- "Kocok lepas telur dan gula hingga larut lalu masukkan tepung terigu, maizena dan santan bertahap sambil terus dimixer sampai adonan tidak bergerindil. Kemudian campurkan adonan hijau keadonan 3 sambil dimixer hingga tercampur rata"
- "Siapkan cetakan yang sudah diolesi minyak agar tidak lengket, kemudian tuang adonan hijau 3/4 cetakan lalu tuang adonan putih diatasnya."
- "Kukus adonan selama 10 menit dengan api besar ( untuk tutup dandang beri alas seperti kain agar air tidak menetes diadonan, jika sudah matang angkat dan tunggu dingin baru keluarkan dari cetakan."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 152 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dessert

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/8a782b58b4b0cf09/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas atau empuk. Karasteristik masakan Indonesia kue nona manis yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga dapat didapat dengan cara mudah. Salah satunya adalah memasak Kue Nona Manis untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang dapat anda praktekkan salah satunya kue nona manis yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Jangan lupa 1 Bahan
1. Dibutuhkan 50 gram gula pasir
1. Harap siapkan 500 ml santan kental
1. Jangan lupa 3 SDM maizena
1. Tambah 1/4 sdt garam
1. Harap siapkan secukupnya Pasta pandan
1. Harap siapkan 2 Bahan
1. Jangan lupa 500 mo santan kental
1. Tambah 3 SDM maizena
1. Siapkan secukupnya Garam
1. Tambah 3 Bahan
1. Diperlukan 2 butir telur
1. Diperlukan 250 tepung terigu
1. Tambah 60 gram maizena
1. Harus ada 500 ml santan kental
1. Harus ada 200 gram gula pasir




<!--inarticleads2-->

##### Langkah membuat  Kue Nona Manis:

1. Campur semua bahan 1 (adonan hijau) kedalam panci, aduk rata
1. Masak bahan 1 dengan api kecil sambil terus diaduk, masak sampai meletup 2 angkat dan dinginkan
1. Campur semua bahan 2 dipanci lain
1. Masak sambil terus diaduk hingga mengental dan meletup matikan api, biarkan hingga uap hilang lalu masukkan kedalam paping bag / botol kecap supaya mudah dituangkan.
1. Kocok lepas telur dan gula hingga larut lalu masukkan tepung terigu, maizena dan santan bertahap sambil terus dimixer sampai adonan tidak bergerindil. Kemudian campurkan adonan hijau keadonan 3 sambil dimixer hingga tercampur rata
1. Siapkan cetakan yang sudah diolesi minyak agar tidak lengket, kemudian tuang adonan hijau 3/4 cetakan lalu tuang adonan putih diatasnya.
1. Kukus adonan selama 10 menit dengan api besar ( untuk tutup dandang beri alas seperti kain agar air tidak menetes diadonan, jika sudah matang angkat dan tunggu dingin baru keluarkan dari cetakan.




Demikianlah cara membuat kue nona manis yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan teruji, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
