---
description: "Panduan untuk membuat Angsle Luar biasa"
title: "Panduan untuk membuat Angsle Luar biasa"
slug: 489-panduan-untuk-membuat-angsle-luar-biasa
date: 2020-10-16T05:47:32.581Z
image: https://img-global.cpcdn.com/recipes/a41e3002d02faa6d/680x482cq70/angsle-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a41e3002d02faa6d/680x482cq70/angsle-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a41e3002d02faa6d/680x482cq70/angsle-foto-resep-utama.jpg
author: Josie Wise
ratingvalue: 4.9
reviewcount: 20288
recipeingredient:
- "1 bungkus sagu mutiara"
- "1/4 kg kacang hijau"
- "secukupnya Gula"
- "6 lembar roti tawar"
- " Kuah santan"
- "2 santan kara"
- "Sejumput garam"
- "3 sendok makan gula pasir"
- "1 sendok teh vanili"
- "500 ml air"
recipeinstructions:
- "Masukkan air ke dalam 2 panci (untuk sagu mutiara dan kacang hijau) lalu didihkan."
- "Jika sudah mendidih, di panci pertama masukkan sagu mutiara dan aduk-aduk agar bagian bawah tidak gosong. Di panci yg ke dua masukkan kacang hijau yg sudah dicuci bersih. Masak menggunakan metode 5-30-7"
- "Didihkan sagu mutiara dan kacang hijau selama 5 menit dengan api sedang (jangan lupa sesekali diaduk ya bun agar tidak gosong bagian bawahnya). Setelah 5 menit matikan kompor dan tutup kedua panci lalu tunggu sampai 30 menit setelah itu disihkan diatas api sedang selama 7 menit."
- "Oh iya setelah memasak sagu mutiara dan kacang hijau selama 5 menit jangan lupa ditambahkan gula secukupnya dan sejumput garam agar rasanya tidak hambar."
- "Sambil nunggu sagu dan kacang hijaunya matang sempurna, bikin kuah santannya yuk."
- "Didihkan air sebanyak 500ml dan ketika mendidih, kecilkan api lalu masukkan santan kara sedikit demi sedikit dan diaduk-aduk agar santan tidak pecar tambahkan 1st vanili, gula sesuai selera dan sedikit garam sambil tetap diaduk dan cek rasa setelah mendidih matikan kompor."
- "Angsle sudah siap untuk disajikan. Lebih nikmat dimakan saat masih hangat 🤤😁"
categories:
- Recipe
tags:
- angsle

katakunci: angsle 
nutrition: 228 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Dinner

---


![Angsle](https://img-global.cpcdn.com/recipes/a41e3002d02faa6d/680x482cq70/angsle-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan empuk. Ciri masakan Indonesia angsle yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Angsle untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang dapat anda praktekkan salah satunya angsle yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep angsle tanpa harus bersusah payah.
Berikut ini resep Angsle yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 10 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Angsle:

1. Dibutuhkan 1 bungkus sagu mutiara
1. Dibutuhkan 1/4 kg kacang hijau
1. Jangan lupa secukupnya Gula
1. Tambah 6 lembar roti tawar
1. Diperlukan  Kuah santan
1. Diperlukan 2 santan kara
1. Siapkan Sejumput garam
1. Diperlukan 3 sendok makan gula pasir
1. Tambah 1 sendok teh vanili
1. Jangan lupa 500 ml air




<!--inarticleads2-->

##### Instruksi membuat  Angsle:

1. Masukkan air ke dalam 2 panci (untuk sagu mutiara dan kacang hijau) lalu didihkan.
1. Jika sudah mendidih, di panci pertama masukkan sagu mutiara dan aduk-aduk agar bagian bawah tidak gosong. Di panci yg ke dua masukkan kacang hijau yg sudah dicuci bersih. Masak menggunakan metode 5-30-7
1. Didihkan sagu mutiara dan kacang hijau selama 5 menit dengan api sedang (jangan lupa sesekali diaduk ya bun agar tidak gosong bagian bawahnya). Setelah 5 menit matikan kompor dan tutup kedua panci lalu tunggu sampai 30 menit setelah itu disihkan diatas api sedang selama 7 menit.
1. Oh iya setelah memasak sagu mutiara dan kacang hijau selama 5 menit jangan lupa ditambahkan gula secukupnya dan sejumput garam agar rasanya tidak hambar.
1. Sambil nunggu sagu dan kacang hijaunya matang sempurna, bikin kuah santannya yuk.
1. Didihkan air sebanyak 500ml dan ketika mendidih, kecilkan api lalu masukkan santan kara sedikit demi sedikit dan diaduk-aduk agar santan tidak pecar tambahkan 1st vanili, gula sesuai selera dan sedikit garam sambil tetap diaduk dan cek rasa setelah mendidih matikan kompor.
1. Angsle sudah siap untuk disajikan. Lebih nikmat dimakan saat masih hangat 🤤😁




Demikianlah cara membuat angsle yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan teruji, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
