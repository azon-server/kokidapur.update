---
description: "Resep : Nona Manis Teruji"
title: "Resep : Nona Manis Teruji"
slug: 355-resep-nona-manis-teruji
date: 2021-02-14T16:24:19.269Z
image: https://img-global.cpcdn.com/recipes/061bcdb6f2bd9e44/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/061bcdb6f2bd9e44/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/061bcdb6f2bd9e44/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Teresa Woods
ratingvalue: 5
reviewcount: 32969
recipeingredient:
- " Bahan 1 "
- "250 mL santan kental"
- "1 butir telur"
- "80 gr gula pasir"
- "140 gr terigu"
- " Bahan 2 "
- "250 mL santan kental"
- "40 gr gula pasir"
- "30 gr tepung maizena"
- "1,5 sdt bubuk bubble gum"
- "Sejumput garam"
- " Bahan 3 "
- "500 mL santan kental"
- "6 sdm tepung terigu"
- "Sejumput garam"
recipeinstructions:
- "Kocok telur dan gula (bahan 1) sampai kental. Masukkan santan dan tepung secara bergantian dengan speed rendah."
- "Masak bahan 2 sampai matang dan mengental. Sisihkan dan dinginkan."
- "Campurkan adonan bahan 2 ke dalam adonan bahan 1. Mixer sampai rata."
- "Masak bahan 3 sampai matang. Dinginkan dan masukkan dalam piping bag."
- "Ambil cetakan. Olesi dengan minyak. Tuang adonan campuran 1 dan 2 dalam cetakan sampai 3/4 volume cetakan. Semprotkan bahan 3 ditengah. Usahakan menyemprot sampai agak ke dalam. Lakukan sampai adonan habis."
- "Kukus selama 30 menit. Tutup kukusan dibungkus dengan serbet ya. Angkat dan tunggu dingin baru dikeluarkan dari cetakan. 👍👍"
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 221 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Dessert

---


![Nona Manis](https://img-global.cpcdn.com/recipes/061bcdb6f2bd9e44/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga enak. Karasteristik masakan Indonesia nona manis yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan rumah tangga dapat didapat dengan cara mudah. Salah satunya adalah memasak Nona Manis untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang dapat anda contoh salah satunya nona manis yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep nona manis tanpa harus bersusah payah.
Berikut ini resep Nona Manis yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona Manis:

1. Tambah  Bahan 1 :
1. Harap siapkan 250 mL santan kental
1. Jangan lupa 1 butir telur
1. Dibutuhkan 80 gr gula pasir
1. Siapkan 140 gr terigu
1. Tambah  Bahan 2 :
1. Tambah 250 mL santan kental
1. Diperlukan 40 gr gula pasir
1. Tambah 30 gr tepung maizena
1. Harus ada 1,5 sdt bubuk bubble gum
1. Tambah Sejumput garam
1. Harus ada  Bahan 3 :
1. Jangan lupa 500 mL santan kental
1. Jangan lupa 6 sdm tepung terigu
1. Tambah Sejumput garam




<!--inarticleads2-->

##### Langkah membuat  Nona Manis:

1. Kocok telur dan gula (bahan 1) sampai kental. Masukkan santan dan tepung secara bergantian dengan speed rendah.
1. Masak bahan 2 sampai matang dan mengental. Sisihkan dan dinginkan.
1. Campurkan adonan bahan 2 ke dalam adonan bahan 1. Mixer sampai rata.
1. Masak bahan 3 sampai matang. Dinginkan dan masukkan dalam piping bag.
1. Ambil cetakan. Olesi dengan minyak. Tuang adonan campuran 1 dan 2 dalam cetakan sampai 3/4 volume cetakan. Semprotkan bahan 3 ditengah. Usahakan menyemprot sampai agak ke dalam. Lakukan sampai adonan habis.
1. Kukus selama 30 menit. Tutup kukusan dibungkus dengan serbet ya. Angkat dan tunggu dingin baru dikeluarkan dari cetakan. 👍👍




Demikianlah cara membuat nona manis yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat gampang dan teruji, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
