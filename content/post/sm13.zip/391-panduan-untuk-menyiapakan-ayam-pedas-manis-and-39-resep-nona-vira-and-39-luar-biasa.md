---
description: "Panduan untuk menyiapakan Ayam pedas manis &amp;#39; Resep nona vira &amp;#39; Luar biasa"
title: "Panduan untuk menyiapakan Ayam pedas manis &amp;#39; Resep nona vira &amp;#39; Luar biasa"
slug: 391-panduan-untuk-menyiapakan-ayam-pedas-manis-and-39-resep-nona-vira-and-39-luar-biasa
date: 2020-11-30T22:43:57.872Z
image: https://img-global.cpcdn.com/recipes/2230f118a4c42c1f/680x482cq70/ayam-pedas-manis-resep-nona-vira-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2230f118a4c42c1f/680x482cq70/ayam-pedas-manis-resep-nona-vira-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2230f118a4c42c1f/680x482cq70/ayam-pedas-manis-resep-nona-vira-foto-resep-utama.jpg
author: Nina Jefferson
ratingvalue: 4.9
reviewcount: 33002
recipeingredient:
- "1 kg ayam segar"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- " cuci ayam bersih kemudian rebus selama 30 menit"
- " Masukan daun salam k dalam rebusan ayam beri sdkt garam"
- " Bumbu halus"
- "5 buah cabe merah besar"
- "3 buah cabe keriting"
- "5 siung Bawang merah"
- "2 siung Bawang putih"
- "1 helai daun serai geprek"
- "3 buah kemiri yg bungkusan"
- " Sdkt lada bubuk"
- " blend semua bahan ini sampai halus"
recipeinstructions:
- "Tumis bumbu halus bersamaan dgn salam. Serai dan daun jeruk.  Aduk, hingga tercium wangi. Masukan kurang lebih 2 gelas air.  Lalu masukan rebusan ayam td beserta air kaldu &amp; daun salam nya.  Aduk kembali, lalu tmbahkan garam, gula, penyedap rasa.  Aduk, dan biar kan hingga kuah mendidih.  Lalu tambhkan 2 sdm kecap manis (tidak juga bisa) sesuai selera.  Jika bumbu sudah meresap, aduk kembali.  Siapkan wadah lalu sajikan.  (garnis bsa juga pakai potongan cabe merah. Di iris miring) 😊"
categories:
- Recipe
tags:
- ayam
- pedas
- manis

katakunci: ayam pedas manis 
nutrition: 179 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT58M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam pedas manis &#39; Resep nona vira &#39;](https://img-global.cpcdn.com/recipes/2230f118a4c42c1f/680x482cq70/ayam-pedas-manis-resep-nona-vira-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas atau gurih. Ciri masakan Nusantara ayam pedas manis &#39; resep nona vira &#39; yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam pedas manis &#39; Resep nona vira &#39; untuk orang di rumah. Momen makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang dapat anda coba salah satunya ayam pedas manis &#39; resep nona vira &#39; yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam pedas manis &#39; resep nona vira &#39; tanpa harus bersusah payah.
Berikut ini resep Ayam pedas manis &#39; Resep nona vira &#39; yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 14 bahan dan 1 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam pedas manis &#39; Resep nona vira &#39;:

1. Jangan lupa 1 kg ayam segar
1. Diperlukan 2 lembar daun salam
1. Siapkan 2 lembar daun jeruk
1. Diperlukan  (cuci ayam bersih, kemudian rebus selama 30 menit)
1. Dibutuhkan  Masukan daun salam k dalam rebusan ayam, beri sdkt garam
1. Harap siapkan  Bumbu halus
1. Harap siapkan 5 buah cabe merah besar
1. Harus ada 3 buah cabe keriting
1. Jangan lupa 5 siung Bawang merah
1. Dibutuhkan 2 siung Bawang putih
1. Diperlukan 1 helai daun serai (geprek)
1. Siapkan 3 buah kemiri (yg bungkusan)
1. Diperlukan  Sdkt lada bubuk
1. Tambah  (blend semua bahan ini sampai halus)




<!--inarticleads2-->

##### Cara membuat  Ayam pedas manis &#39; Resep nona vira &#39;:

1. Tumis bumbu halus bersamaan dgn salam. Serai dan daun jeruk.  - Aduk, hingga tercium wangi. Masukan kurang lebih 2 gelas air.  - Lalu masukan rebusan ayam td beserta air kaldu &amp; daun salam nya.  - Aduk kembali, lalu tmbahkan garam, gula, penyedap rasa.  - Aduk, dan biar kan hingga kuah mendidih.  - Lalu tambhkan 2 sdm kecap manis (tidak juga bisa) sesuai selera.  - Jika bumbu sudah meresap, aduk kembali.  - Siapkan wadah lalu sajikan.  - (garnis bsa juga pakai potongan cabe merah. Di iris miring) 😊




Demikianlah cara membuat ayam pedas manis &#39; resep nona vira &#39; yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan teruji, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
