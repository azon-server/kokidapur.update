---
description: "Cara singkat menyiapakan Nona manis pandan / lesung pipi terupdate"
title: "Cara singkat menyiapakan Nona manis pandan / lesung pipi terupdate"
slug: 353-cara-singkat-menyiapakan-nona-manis-pandan-lesung-pipi-terupdate
date: 2020-11-19T13:07:28.379Z
image: https://img-global.cpcdn.com/recipes/a404f971397b8ab6/680x482cq70/nona-manis-pandan-lesung-pipi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a404f971397b8ab6/680x482cq70/nona-manis-pandan-lesung-pipi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a404f971397b8ab6/680x482cq70/nona-manis-pandan-lesung-pipi-foto-resep-utama.jpg
author: Clyde Hanson
ratingvalue: 4.3
reviewcount: 28361
recipeingredient:
- " bahan a"
- "125 ml santan"
- "3 sdm terigu"
- "1 sdm gula pasir"
- "1/4 sdt garam"
- " bahan b"
- "125 ml santan"
- "1 sdm maizena"
- "2 sdm gula pasir"
- "2 tetes Pasta pandan"
- "Secukupnya garam"
- " bahan c"
- "1 butir telur"
- "7 sdm gula pasir"
- "125 ml santan"
- "10 sdm terigu"
recipeinstructions:
- "Campur semua bahan A, masak dengan api kecil sambil diaduk terus sampai rata dan tidak bergerindil, sisihkan."
- "Campur semua bahan B, masak dengan api kecil sambil di aduk rata, sisihkan."
- "Mixer telur dan gula pasir sampai tercampur rata (pake whisk juga bisa), setelah tercampur masukkan santan dan terigu."
- "Tuang bahan B ke bahan C, mixer sampe rata."
- "Tuang adonan hijau ke cetakan kue yang sebelumnya sudah diolesi minyak, 3/4 bagian saja. Setelah itu tambahkan adonan putih di tengah2 adonan hijau"
- "Tips: kalo mau rapi, masukkan adonan putih ke dalam piping bag, lalu semprotkan ke adonan hijau). Klo tidak punya piping bag, pake sendok juga bisa (Sy pakai sendok). Hihihi"
- "Kukus dalam dandang yang sudah dipanaskan sebelumnya selama 10-15 menit dengan api sedang. Jangan lupa alasi tutup dandang dengan serbet bersih supaya airnya tidak jatuh ke adonan."
- "Kalo sudah matang, dinginkan sebentar baru dilepas dari cetakannya."
- "Selamat mencoba..."
categories:
- Recipe
tags:
- nona
- manis
- pandan

katakunci: nona manis pandan 
nutrition: 206 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Dinner

---


![Nona manis pandan / lesung pipi](https://img-global.cpcdn.com/recipes/a404f971397b8ab6/680x482cq70/nona-manis-pandan-lesung-pipi-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti nona manis pandan / lesung pipi yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan ciri khas yang merupakan keragaman Indonesia



Kedekatan rumah tangga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Nona manis pandan / lesung pipi untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang dapat anda praktekkan salah satunya nona manis pandan / lesung pipi yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep nona manis pandan / lesung pipi tanpa harus bersusah payah.
Seperti resep Nona manis pandan / lesung pipi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 9 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona manis pandan / lesung pipi:

1. Harap siapkan  bahan a
1. Diperlukan 125 ml santan
1. Tambah 3 sdm terigu
1. Diperlukan 1 sdm gula pasir
1. Harap siapkan 1/4 sdt garam
1. Siapkan  bahan b
1. Siapkan 125 ml santan
1. Harap siapkan 1 sdm maizena
1. Diperlukan 2 sdm gula pasir
1. Dibutuhkan 2 tetes Pasta pandan
1. Jangan lupa Secukupnya garam
1. Dibutuhkan  bahan c
1. Jangan lupa 1 butir telur
1. Dibutuhkan 7 sdm gula pasir
1. Harap siapkan 125 ml santan
1. Siapkan 10 sdm terigu




<!--inarticleads2-->

##### Cara membuat  Nona manis pandan / lesung pipi:

1. Campur semua bahan A, masak dengan api kecil sambil diaduk terus sampai rata dan tidak bergerindil, sisihkan.
1. Campur semua bahan B, masak dengan api kecil sambil di aduk rata, sisihkan.
1. Mixer telur dan gula pasir sampai tercampur rata (pake whisk juga bisa), setelah tercampur masukkan santan dan terigu.
1. Tuang bahan B ke bahan C, mixer sampe rata.
1. Tuang adonan hijau ke cetakan kue yang sebelumnya sudah diolesi minyak, 3/4 bagian saja. Setelah itu tambahkan adonan putih di tengah2 adonan hijau
1. Tips: kalo mau rapi, masukkan adonan putih ke dalam piping bag, lalu semprotkan ke adonan hijau). Klo tidak punya piping bag, pake sendok juga bisa (Sy pakai sendok). Hihihi
1. Kukus dalam dandang yang sudah dipanaskan sebelumnya selama 10-15 menit dengan api sedang. Jangan lupa alasi tutup dandang dengan serbet bersih supaya airnya tidak jatuh ke adonan.
1. Kalo sudah matang, dinginkan sebentar baru dilepas dari cetakannya.
1. Selamat mencoba...




Demikianlah cara membuat nona manis pandan / lesung pipi yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan teruji, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
