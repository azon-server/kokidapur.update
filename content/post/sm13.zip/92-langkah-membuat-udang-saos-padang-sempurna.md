---
description: "Langkah membuat Udang saos padang Sempurna"
title: "Langkah membuat Udang saos padang Sempurna"
slug: 92-langkah-membuat-udang-saos-padang-sempurna
date: 2020-12-19T08:16:56.109Z
image: https://img-global.cpcdn.com/recipes/971ac51ccfa177c6/680x482cq70/udang-saos-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/971ac51ccfa177c6/680x482cq70/udang-saos-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/971ac51ccfa177c6/680x482cq70/udang-saos-padang-foto-resep-utama.jpg
author: Jeffrey Wallace
ratingvalue: 4.7
reviewcount: 7250
recipeingredient:
- " Bahan  200 gram udang 1 buah tofu udang optional"
- " Bumbu halus "
- "4 siung bawang putih"
- "5 siung bawang merah"
- "8 buah cabe merah keriting"
- "2 buah cabe rawit ukuran besar sesuai selera"
- "Secukupnya lada putih butir"
- " Bahanbumbu pelengkap "
- "1 sdm kecap manis"
- "1 sdm saos sambal"
- "1 sdm saos tomat"
- "1 sdm saus tiram"
- "1/2 siung bawang bombay"
- "3 lembar daun jeruk"
- " Daun salam lengkuas sereh"
- "Secukupnya garam gula pasir dan kaldu penyedap rasa"
- " Daun bawang untuk hiasan"
- " Jeruk nipis untuk melumuri udang"
recipeinstructions:
- "Cuci bersih udang kemudian lumuri dgn perasaan/air jeruk nipis dan garam, diamkan krg lebih sktr 15 menit. Setelah 15 menit cuci/bilas bersih udang"
- "Potong² tofu kemudian goreng"
- "Haluskan semua bahan bumbu halus. Potong² bawang bombay"
- "Tumis bumbu halus beserta bahan pelengkap (bawang Bombay, daun salam, lengkuas, sereh) - bila sudah layu atau tercium bau wangi kemudian tambahkan kecap, saos sambal, saos tomat &amp; saos tiram"
- "Masukan udang, beri air secukupnya, masukan daun jeruk &amp; tofu. Tambahkan garam, gula pasir &amp; kaldu/penyedap rasa. Cek rasa sambil menunggu air surut"
- "Setelah air cukup surut dan rasa dr masakan sudah dirasa pas siap untuk dihidangkan"
categories:
- Recipe
tags:
- udang
- saos
- padang

katakunci: udang saos padang 
nutrition: 267 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Dinner

---


![Udang saos padang](https://img-global.cpcdn.com/recipes/971ac51ccfa177c6/680x482cq70/udang-saos-padang-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau renyah. Ciri khas kuliner Nusantara udang saos padang yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan Udang saos padang untuk keluarga. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda buat salah satunya udang saos padang yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep udang saos padang tanpa harus bersusah payah.
Seperti resep Udang saos padang yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Udang saos padang:

1. Siapkan  Bahan : 200 gram udang, 1 buah tofu udang (optional)
1. Harus ada  Bumbu halus :
1. Siapkan 4 siung bawang putih
1. Harap siapkan 5 siung bawang merah
1. Tambah 8 buah cabe merah keriting
1. Tambah 2 buah cabe rawit ukuran besar (sesuai selera)
1. Siapkan Secukupnya lada putih butir
1. Siapkan  Bahan/bumbu pelengkap :
1. Dibutuhkan 1 sdm kecap manis
1. Diperlukan 1 sdm saos sambal
1. Diperlukan 1 sdm saos tomat
1. Tambah 1 sdm saus tiram
1. Harap siapkan 1/2 siung bawang bombay
1. Diperlukan 3 lembar daun jeruk
1. Diperlukan  Daun salam, lengkuas, sereh
1. Dibutuhkan Secukupnya garam, gula pasir, dan kaldu (penyedap rasa)
1. Jangan lupa  Daun bawang untuk hiasan
1. Harap siapkan  Jeruk nipis untuk melumuri udang




<!--inarticleads2-->

##### Cara membuat  Udang saos padang:

1. Cuci bersih udang kemudian lumuri dgn perasaan/air jeruk nipis dan garam, diamkan krg lebih sktr 15 menit. Setelah 15 menit cuci/bilas bersih udang
1. Potong² tofu kemudian goreng
1. Haluskan semua bahan bumbu halus. Potong² bawang bombay
1. Tumis bumbu halus beserta bahan pelengkap (bawang Bombay, daun salam, lengkuas, sereh) - - bila sudah layu atau tercium bau wangi kemudian tambahkan kecap, saos sambal, saos tomat &amp; saos tiram
1. Masukan udang, beri air secukupnya, masukan daun jeruk &amp; tofu. Tambahkan garam, gula pasir &amp; kaldu/penyedap rasa. Cek rasa sambil menunggu air surut
1. Setelah air cukup surut dan rasa dr masakan sudah dirasa pas siap untuk dihidangkan




Demikianlah cara membuat udang saos padang yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat mudah dan terbukti, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
