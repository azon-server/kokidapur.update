---
description: "Resep : Kue Nona Manis Favorite"
title: "Resep : Kue Nona Manis Favorite"
slug: 371-resep-kue-nona-manis-favorite
date: 2020-11-24T09:51:36.221Z
image: https://img-global.cpcdn.com/recipes/9e835455b27babf0/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9e835455b27babf0/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9e835455b27babf0/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Nathaniel Thompson
ratingvalue: 4.9
reviewcount: 12205
recipeingredient:
- " Bahan I"
- "3 butir telur"
- "1 cangkir gula pasir"
- "2 cangkir santan"
- "2 cangkir terigu"
- " Bahan II "
- "2 cangkir santan suji santan yg diblender bersama pandan dan suji"
- "1/2 cangkir gula pasir"
- "1/2 cangkir maizena"
- "1/2 sdt garam"
- " Bahan III "
- "2 cangkir santan kental"
- "2 sdm gula pasir"
- "2 sdm terigu"
- "1/2 sdt garam"
recipeinstructions:
- "Bahan I: Kocok telur dan gula sampai mengembang. Turunkan kecepatan mixer, masukan terigu, kocok rata. Tuang santan lalu aduk sampai rata."
- "BAHAN II : Campur santan suji, gula pasir dan maizena. Masak di atas kompor sambil diaduk terus sampai meletup letup. Angkat.  Campurkan adonan I dan II. Gunakan mixer hingga tercampur rata. Sisihkan. Panaskan dandang utk mengukus."
- "Bahan III : Campur santan kental, gula, terigu dan garam. Aduk hingga rata dan tdk bergerindil. Masak sambil diaduk terus agar santan tdk pecah. Setelah mendidih angkat segera dari kompor. Siapkan cetakan cucing yg sudah diolesi minyak. Tuang adonan pandan hingga hampir penuh. Beri tengahnya adonan santan menggunakan sendok. Kukus selama kurang lebih 7-10 menit (tergantung besar kecilnya cucing) dgn panas sedang. Angkat dari kukusan. biarkan sebentar. Kikis sedikit sekeliling cucing menggunakan sendok atau pisau lalu balikkan kue diatas telapak tangan. Segera letakkan di piring. Semua dilakukan dlm keadaan cepat agar adonan santan yg ditengah tdk beleber di tangan."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 279 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Dessert

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/9e835455b27babf0/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang patut kita jaga karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti kue nona manis yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan keistimewahan yang merupakan keragaman Indonesia

Keharmonisan keluarga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Kue Nona Manis untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang bisa anda contoh salah satunya kue nona manis yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis:

1. Harap siapkan  Bahan I:
1. Harus ada 3 butir telur
1. Tambah 1 cangkir gula pasir
1. Siapkan 2 cangkir santan
1. Harus ada 2 cangkir terigu
1. Dibutuhkan  Bahan II :
1. Harus ada 2 cangkir santan suji (santan yg diblender bersama pandan dan suji)
1. Jangan lupa 1/2 cangkir gula pasir
1. Diperlukan 1/2 cangkir maizena
1. Jangan lupa 1/2 sdt garam
1. Tambah  Bahan III :
1. Siapkan 2 cangkir santan kental
1. Harus ada 2 sdm gula pasir
1. Siapkan 2 sdm terigu
1. Diperlukan 1/2 sdt garam




<!--inarticleads2-->

##### Bagaimana membuat  Kue Nona Manis:

1. Bahan I: - Kocok telur dan gula sampai mengembang. Turunkan kecepatan mixer, masukan terigu, kocok rata. Tuang santan lalu aduk sampai rata.
1. BAHAN II : - Campur santan suji, gula pasir dan maizena. Masak di atas kompor sambil diaduk terus sampai meletup letup. Angkat.  - Campurkan adonan I dan II. Gunakan mixer hingga tercampur rata. Sisihkan. Panaskan dandang utk mengukus.
1. Bahan III : - Campur santan kental, gula, terigu dan garam. Aduk hingga rata dan tdk bergerindil. Masak sambil diaduk terus agar santan tdk pecah. Setelah mendidih angkat segera dari kompor. Siapkan cetakan cucing yg sudah diolesi minyak. Tuang adonan pandan hingga hampir penuh. Beri tengahnya adonan santan menggunakan sendok. Kukus selama kurang lebih 7-10 menit (tergantung besar kecilnya cucing) dgn panas sedang. Angkat dari kukusan. - biarkan sebentar. Kikis sedikit sekeliling cucing menggunakan sendok atau pisau lalu balikkan kue diatas telapak tangan. Segera letakkan di piring. Semua dilakukan dlm keadaan cepat agar adonan santan yg ditengah tdk beleber di tangan.




Demikianlah cara membuat kue nona manis yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
