---
description: "Langkah menyiapakan Kepiting saus padang terupdate"
title: "Langkah menyiapakan Kepiting saus padang terupdate"
slug: 189-langkah-menyiapakan-kepiting-saus-padang-terupdate
date: 2020-10-01T01:03:00.839Z
image: https://img-global.cpcdn.com/recipes/9662977f5053f6e3/680x482cq70/kepiting-saus-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9662977f5053f6e3/680x482cq70/kepiting-saus-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9662977f5053f6e3/680x482cq70/kepiting-saus-padang-foto-resep-utama.jpg
author: James Owen
ratingvalue: 4
reviewcount: 7876
recipeingredient:
- "2 dan 12 ekor kepiting"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "4 butir kemiri sangrai"
- "1 cm jahe"
- "10 buah cabe merah kriting"
- " Daun bawang secukupnya opsional"
- "1 buah bawang bombai"
- "3 sendok makan saus tomat"
- "3 sendok makan saus ekstra pedas"
- "1 bungkus saori saus tiram"
- " Garam"
- " Penyedao rasa"
- " Gula"
- "2 lembar daun jeruk"
recipeinstructions:
- "Rebus kepiting dengan air bersih, setelah matang air rebusannya jangan dibuang untuk kaldu"
- "Haluskan bawang merah, bawang putih, kemiri, jahe, dan cabe"
- "Panaskan minyak lalu timis bumbu halus sampai harum, tambahkan daun bawang dan bawang bombai."
- "Masukan 100ml air biasa dan 100ml air rebusan kepiting"
- "Tambahkan gula,garam dan penyedap rasa sesuai selera"
- "Tambahkan 3 sendok makan saos tomat dan 3 sendok makan saos ekstra pedas."
- "Tambahkan saus tiram 1 sampai 2 sendok makan saja jangan terlalu banyak karna rasanya asin"
- "Masak hingga air surut dan mengental."
- "Selesai. Kepiting saus padang siap dihidangkan.. untuk vidio memasak ada di chanel youtubeku ya jangan lupa like, share and subscribe"
categories:
- Recipe
tags:
- kepiting
- saus
- padang

katakunci: kepiting saus padang 
nutrition: 154 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Dessert

---


![Kepiting saus padang](https://img-global.cpcdn.com/recipes/9662977f5053f6e3/680x482cq70/kepiting-saus-padang-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga empuk. Ciri khas kuliner Nusantara kepiting saus padang yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa didapat dengan cara sederhana. Salah satunya adalah memasak Kepiting saus padang untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda coba salah satunya kepiting saus padang yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep kepiting saus padang tanpa harus bersusah payah.
Berikut ini resep Kepiting saus padang yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 9 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kepiting saus padang:

1. Tambah 2 dan 1/2 ekor kepiting
1. Jangan lupa 8 siung bawang merah
1. Harap siapkan 5 siung bawang putih
1. Jangan lupa 4 butir kemiri sangrai
1. Siapkan 1 cm jahe
1. Siapkan 10 buah cabe merah kriting
1. Harap siapkan  Daun bawang secukupnya (opsional)
1. Siapkan 1 buah bawang bombai
1. Siapkan 3 sendok makan saus tomat
1. Harus ada 3 sendok makan saus ekstra pedas
1. Tambah 1 bungkus saori saus tiram
1. Diperlukan  Garam
1. Harus ada  Penyedao rasa
1. Harap siapkan  Gula
1. Harus ada 2 lembar daun jeruk




<!--inarticleads2-->

##### Cara membuat  Kepiting saus padang:

1. Rebus kepiting dengan air bersih, setelah matang air rebusannya jangan dibuang untuk kaldu
1. Haluskan bawang merah, bawang putih, kemiri, jahe, dan cabe
1. Panaskan minyak lalu timis bumbu halus sampai harum, tambahkan daun bawang dan bawang bombai.
1. Masukan 100ml air biasa dan 100ml air rebusan kepiting
1. Tambahkan gula,garam dan penyedap rasa sesuai selera
1. Tambahkan 3 sendok makan saos tomat dan 3 sendok makan saos ekstra pedas.
1. Tambahkan saus tiram 1 sampai 2 sendok makan saja jangan terlalu banyak karna rasanya asin
1. Masak hingga air surut dan mengental.
1. Selesai. Kepiting saus padang siap dihidangkan.. untuk vidio memasak ada di chanel youtubeku ya jangan lupa like, share and subscribe




Demikianlah cara membuat kepiting saus padang yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
