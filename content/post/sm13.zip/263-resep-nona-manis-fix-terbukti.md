---
description: "Resep : Nona Manis Fix Terbukti"
title: "Resep : Nona Manis Fix Terbukti"
slug: 263-resep-nona-manis-fix-terbukti
date: 2020-11-29T00:57:42.792Z
image: https://img-global.cpcdn.com/recipes/be1744388bc1b0af/680x482cq70/nona-manis-fix-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/be1744388bc1b0af/680x482cq70/nona-manis-fix-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/be1744388bc1b0af/680x482cq70/nona-manis-fix-foto-resep-utama.jpg
author: Jeffery Kennedy
ratingvalue: 4.4
reviewcount: 21155
recipeingredient:
- "2 bks kara uk 200ml  air hingga 750ml utk 3 adonan"
- " Adonan 1"
- "250 ml santan"
- "3 sdm terigu"
- "Sejumput garam"
- " Bahan 2"
- "250 ml santan"
- "40 gr gula pasir"
- "30 gr maizena"
- " Pewarna hijau makanan"
- "Sejumput garam"
- " Bahan 3"
- "80 gr gula pasir"
- "1 butir telur"
- "250 ml santan"
- "140 gr terigu"
recipeinstructions:
- "Campurkan 2 bungkus kara (400ml) ke dalam wadah, kemudian tambahkan air hingga menjadi 750ml santan. Santan ini dibagi untuh 3 macam adonan ya, masing-masing adonan 250ml santan."
- "Campurkan semua bahan 1 kedalam panci, aduk hingga tepung tidak menggumpal. Nyalakan kompor dengan api sedang, masak hingga agak mengental tetapi masih cair ya. Ini supaya adonan putihnya nanti bagus, jadi tidak boleh sampai kental banget yaa. Kalau tekstur sudah bagus, diamkan agar dingin. Setelah dingin masukkan ke dalam plastik air atau piping bag kalau ada"
- "Masukkan semua bahan 2 ke dalam panci, aduk hingga tidak menggumpal. Nyalakan api sedang, kemudian masak hingga gula larut saja yaa. Sisihkan hingga tidak panas lagi"
- "Mixer gula &amp; telur hingga berwarna putih. Masukkan terigu &amp; santan secara bergantian sambil terus diaduk dengan kecepatan rendah. Lakukan hingga terigu &amp; santan habis"
- "Masukkan adonan 2 ke dalam adonan 3, aduk rata. Kalau aku dimixer sebentar aja supaya adonan yang menggumpal bisa tercampur rata. Setelah itu pindahkan adonan ke gelas takar agar mudah memasukkan ke cetakan"
- "Olesi cetakan dengan sedikit minyak sayur. Masukkan adonan hijau hingga 3/4 cetakan, kemudian masukkan adonan putih ditengah cetakan, isi hingga cetakan hampir penuh"
- "Panaskan kukusan terlebih dahulu, kemudian kukus adonan kue selama 10 menit. Jangan lupa lapisi tutupnya dengan kain yaa"
- "Angkat setelah matang. Dan keluarkan dari cetakan setelah agak dingin"
- "Bisa jadi ide jualan juga nihhh... Dijamin enak &amp; lembut. Rasa manisnya passsss banget!"
categories:
- Recipe
tags:
- nona
- manis
- fix

katakunci: nona manis fix 
nutrition: 149 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT36M"
recipeyield: "4"
recipecategory: Lunch

---


![Nona Manis Fix](https://img-global.cpcdn.com/recipes/be1744388bc1b0af/680x482cq70/nona-manis-fix-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang harus kita jaga karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti nona manis fix yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Kita

Kehangatan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah memasak Nona Manis Fix untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang bisa anda buat salah satunya nona manis fix yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep nona manis fix tanpa harus bersusah payah.
Seperti resep Nona Manis Fix yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 9 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona Manis Fix:

1. Siapkan 2 bks kara uk. 200ml + air hingga 750ml (utk 3 adonan)
1. Harus ada  Adonan 1
1. Harus ada 250 ml santan
1. Jangan lupa 3 sdm terigu
1. Jangan lupa Sejumput garam
1. Dibutuhkan  Bahan 2
1. Harap siapkan 250 ml santan
1. Siapkan 40 gr gula pasir
1. Harus ada 30 gr maizena
1. Diperlukan  Pewarna hijau makanan
1. Harap siapkan Sejumput garam
1. Tambah  Bahan 3
1. Siapkan 80 gr gula pasir
1. Tambah 1 butir telur
1. Jangan lupa 250 ml santan
1. Harus ada 140 gr terigu




<!--inarticleads2-->

##### Bagaimana membuat  Nona Manis Fix:

1. Campurkan 2 bungkus kara (400ml) ke dalam wadah, kemudian tambahkan air hingga menjadi 750ml santan. Santan ini dibagi untuh 3 macam adonan ya, masing-masing adonan 250ml santan.
1. Campurkan semua bahan 1 kedalam panci, aduk hingga tepung tidak menggumpal. Nyalakan kompor dengan api sedang, masak hingga agak mengental tetapi masih cair ya. Ini supaya adonan putihnya nanti bagus, jadi tidak boleh sampai kental banget yaa. Kalau tekstur sudah bagus, diamkan agar dingin. Setelah dingin masukkan ke dalam plastik air atau piping bag kalau ada
1. Masukkan semua bahan 2 ke dalam panci, aduk hingga tidak menggumpal. Nyalakan api sedang, kemudian masak hingga gula larut saja yaa. Sisihkan hingga tidak panas lagi
1. Mixer gula &amp; telur hingga berwarna putih. Masukkan terigu &amp; santan secara bergantian sambil terus diaduk dengan kecepatan rendah. Lakukan hingga terigu &amp; santan habis
1. Masukkan adonan 2 ke dalam adonan 3, aduk rata. Kalau aku dimixer sebentar aja supaya adonan yang menggumpal bisa tercampur rata. Setelah itu pindahkan adonan ke gelas takar agar mudah memasukkan ke cetakan
1. Olesi cetakan dengan sedikit minyak sayur. Masukkan adonan hijau hingga 3/4 cetakan, kemudian masukkan adonan putih ditengah cetakan, isi hingga cetakan hampir penuh
1. Panaskan kukusan terlebih dahulu, kemudian kukus adonan kue selama 10 menit. Jangan lupa lapisi tutupnya dengan kain yaa
1. Angkat setelah matang. Dan keluarkan dari cetakan setelah agak dingin
1. Bisa jadi ide jualan juga nihhh... Dijamin enak &amp; lembut. Rasa manisnya passsss banget!




Demikianlah cara membuat nona manis fix yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
