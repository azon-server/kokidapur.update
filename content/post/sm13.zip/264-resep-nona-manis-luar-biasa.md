---
description: "Resep : Nona Manis Luar biasa"
title: "Resep : Nona Manis Luar biasa"
slug: 264-resep-nona-manis-luar-biasa
date: 2020-10-23T23:38:14.543Z
image: https://img-global.cpcdn.com/recipes/39a8daa68855b949/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/39a8daa68855b949/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/39a8daa68855b949/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Jack McDonald
ratingvalue: 5
reviewcount: 7959
recipeingredient:
- " Bahan A "
- "1 butir Telur"
- "100 gr Gula Pasir"
- "250 ml Santan"
- "145 gr Tepung Terigu"
- " Bahan B "
- "250 ml Santan"
- "1/2 sdt Pasta Pandan"
- "55 gr Gula Pasir"
- "30 gr Tepung Maizena"
- "1/4 sdt Garam"
- " Bahan C "
- "250 ml Santan"
- "1 sdm Tepung Terigu"
- "1 sdm Gula Pasir"
- "1/2 sdt Garam"
recipeinstructions:
- "Campur semua bahan adonan C masak dalam api sedang hingga meletup2 dan kental, sisihkan"
- "Campur semua bahan adonan A (kecuali telur) aduk rata, kemudian masukkan telur yg sudah dikocok aduk rata"
- "Campur semua bahan adonan B kemudian masak dalam api kecil sampai meletup2 dan kental"
- "Tuang adonan A ke dalam adonan B, aduk cepat (supaya tidak menggumpal)"
- "Olesi cetakan dengan minyak goreng, kemudian isi adonan 3/4 bagian"
- "Tuang adonan bahan C ditengahnya (gunakan piping bag atau botol plastik)"
- "Kukus selama 20 menit (sudah dipanaskan terlebih dahulu kukusannya sampai mendidih)"
- "Setelah 20 menit buka tutup panci kukusan, biarkan uap nya menghilang"
- "Sajikan kue nona manis, dijamin ketagihan karena teksturnya lembut &amp; manisnya pas"
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 179 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Lunch

---


![Nona Manis](https://img-global.cpcdn.com/recipes/39a8daa68855b949/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita jaga karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti nona manis yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Nusantara



Kehangatan keluarga dapat didapat dengan cara sederhana. Diantaranya adalah membuat makanan Nona Manis untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda contoh salah satunya nona manis yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona Manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona Manis:

1. Dibutuhkan  Bahan A :
1. Dibutuhkan 1 butir Telur
1. Dibutuhkan 100 gr Gula Pasir
1. Tambah 250 ml Santan
1. Tambah 145 gr Tepung Terigu
1. Tambah  Bahan B :
1. Tambah 250 ml Santan
1. Jangan lupa 1/2 sdt Pasta Pandan
1. Tambah 55 gr Gula Pasir
1. Harap siapkan 30 gr Tepung Maizena
1. Jangan lupa 1/4 sdt Garam
1. Diperlukan  Bahan C :
1. Jangan lupa 250 ml Santan
1. Tambah 1 sdm Tepung Terigu
1. Jangan lupa 1 sdm Gula Pasir
1. Siapkan 1/2 sdt Garam




<!--inarticleads2-->

##### Bagaimana membuat  Nona Manis:

1. Campur semua bahan adonan C masak dalam api sedang hingga meletup2 dan kental, sisihkan
1. Campur semua bahan adonan A (kecuali telur) aduk rata, kemudian masukkan telur yg sudah dikocok aduk rata
1. Campur semua bahan adonan B kemudian masak dalam api kecil sampai meletup2 dan kental
1. Tuang adonan A ke dalam adonan B, aduk cepat (supaya tidak menggumpal)
1. Olesi cetakan dengan minyak goreng, kemudian isi adonan 3/4 bagian
1. Tuang adonan bahan C ditengahnya (gunakan piping bag atau botol plastik)
1. Kukus selama 20 menit (sudah dipanaskan terlebih dahulu kukusannya sampai mendidih)
1. Setelah 20 menit buka tutup panci kukusan, biarkan uap nya menghilang
1. Sajikan kue nona manis, dijamin ketagihan karena teksturnya lembut &amp; manisnya pas




Demikianlah cara membuat nona manis yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
