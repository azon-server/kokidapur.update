---
description: "Cara menyiapakan Kue Nona Manis Enak Teruji"
title: "Cara menyiapakan Kue Nona Manis Enak Teruji"
slug: 382-cara-menyiapakan-kue-nona-manis-enak-teruji
date: 2020-12-22T15:33:17.086Z
image: https://img-global.cpcdn.com/recipes/88d0ad3b82a25a4a/680x482cq70/kue-nona-manis-enak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/88d0ad3b82a25a4a/680x482cq70/kue-nona-manis-enak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/88d0ad3b82a25a4a/680x482cq70/kue-nona-manis-enak-foto-resep-utama.jpg
author: Hannah Wheeler
ratingvalue: 4.1
reviewcount: 29638
recipeingredient:
- " Bahan 1"
- "1/5 gelas gula pasir"
- "2 sdm tepung maizena"
- "1 sdm tepung terigu"
- "6 sdm perasan jus pandan"
- "2 tetes pewarna rasa pandan"
- "2 gelas santan"
- "1/4 sdt garam"
- "3 sdm susu kental manis"
- " Bahan 2"
- "2 gelas santal kental"
- "1 sdm tepung maizena"
- "3 sdm tepung terigu"
- "3 sdm susu kental manis"
- "Sedikit garam"
- " Bahan 3"
- "2 butir telur"
- "2 gelas tepung terigu"
- "1/2 gelas tepung maizena"
- "2 gelas santan kental"
- "1/2 gelas gula pasir sesuai selera"
recipeinstructions:
- "Buat bahan 1. Campur kan semua bahan kemudian masak diatas kompor diaduk trus sampai adonan meletup2 ya."
- "Jika sudah meletup matikan api dan kemudian dinginkan adonan."
- "Buat bahan 2. Campur semua bahan kemudian masak diatas kompor sampai meletup2. Lalu angkat dan dinginkan."
- "Membuat bahan C :Mixer telur dan gula jika sdh mengembang masukkan duo tepung secara perlahan dan masukkan santan. Mixer kembali"
- "Masukkan bahan 1 ke bahan 3 kemudian mixer sampai tidak menggerindil ya."
- "Panaskan dandang.oleskan minyak pada permukaan cetakan. Kemudian masukkan adonan hijau kemudian beri sedikit adonan putih ditengah"
- "Kukus sekitar 7 menit kemudian dinginkan baru keluarkan dr cetakan."
- "Selamat menikmati"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 294 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Lunch

---


![Kue Nona Manis Enak](https://img-global.cpcdn.com/recipes/88d0ad3b82a25a4a/680x482cq70/kue-nona-manis-enak-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga enak. Ciri masakan Nusantara kue nona manis enak yang kaya dengan rempah menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kehangatan keluarga dapat diperoleh dengan cara simple. Diantaranya adalah memasak Kue Nona Manis Enak untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang bisa anda buat salah satunya kue nona manis enak yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep kue nona manis enak tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis Enak yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis Enak:

1. Siapkan  Bahan 1:
1. Dibutuhkan 1/5 gelas gula pasir
1. Tambah 2 sdm tepung maizena
1. Dibutuhkan 1 sdm tepung terigu
1. Dibutuhkan 6 sdm perasan jus pandan
1. Harus ada 2 tetes pewarna rasa pandan
1. Dibutuhkan 2 gelas santan
1. Jangan lupa 1/4 sdt garam
1. Harap siapkan 3 sdm susu kental manis
1. Tambah  Bahan 2:
1. Jangan lupa 2 gelas santal kental
1. Harus ada 1 sdm tepung maizena
1. Harap siapkan 3 sdm tepung terigu
1. Jangan lupa 3 sdm susu kental manis
1. Siapkan Sedikit garam
1. Diperlukan  Bahan 3:
1. Harap siapkan 2 butir telur
1. Diperlukan 2 gelas tepung terigu
1. Diperlukan 1/2 gelas tepung maizena
1. Dibutuhkan 2 gelas santan kental
1. Diperlukan 1/2 gelas gula pasir (sesuai selera)




<!--inarticleads2-->

##### Instruksi membuat  Kue Nona Manis Enak:

1. Buat bahan 1. Campur kan semua bahan kemudian masak diatas kompor diaduk trus sampai adonan meletup2 ya.
1. Jika sudah meletup matikan api dan kemudian dinginkan adonan.
1. Buat bahan 2. Campur semua bahan kemudian masak diatas kompor sampai meletup2. Lalu angkat dan dinginkan.
1. Membuat bahan C :Mixer telur dan gula jika sdh mengembang masukkan duo tepung secara perlahan dan masukkan santan. Mixer kembali
1. Masukkan bahan 1 ke bahan 3 kemudian mixer sampai tidak menggerindil ya.
1. Panaskan dandang.oleskan minyak pada permukaan cetakan. Kemudian masukkan adonan hijau kemudian beri sedikit adonan putih ditengah
1. Kukus sekitar 7 menit kemudian dinginkan baru keluarkan dr cetakan.
1. Selamat menikmati




Demikianlah cara membuat kue nona manis enak yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
