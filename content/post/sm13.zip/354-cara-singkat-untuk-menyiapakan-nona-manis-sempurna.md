---
description: "Cara singkat untuk menyiapakan Nona Manis Sempurna"
title: "Cara singkat untuk menyiapakan Nona Manis Sempurna"
slug: 354-cara-singkat-untuk-menyiapakan-nona-manis-sempurna
date: 2020-09-20T22:50:30.899Z
image: https://img-global.cpcdn.com/recipes/a4c9c39a13147449/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a4c9c39a13147449/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a4c9c39a13147449/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Jonathan Tucker
ratingvalue: 4.2
reviewcount: 7801
recipeingredient:
- " Bahan 1 "
- "1 butir kelapa untuk semua bahan"
- "2 butir telur"
- "230 gr gula pasir"
- "400 ml santan kental"
- "220 gr tepung terigu"
- " Bahan 2 "
- "400 ml santan kental"
- "40 gr meizena"
- "120 gr gula pasir"
- "1/2 sdt garam"
- "secukupnya pewarna hijau"
- " daun pandan"
- " Bahan 3 "
- "400 gr santan kental"
- "3 sdm tepung trigu"
- "3 sdm gula pasir"
- "1/2 sdt garam"
- "1/2 sdt Extrak Vanilli"
recipeinstructions:
- "Bahan 1 : Mix gula, telur, extrak vanilli hinggal kental. gula larut yaa. lalu masukkan santan kental dan terigu secara bertahap. mixer kecepatan rendah sampai rata lalu sisihkan."
- "Bahan 2 : Rebus semua bahan dengan api sedang hingga beruap dan mengental. beri pewarna hijau dan daun pandan. matikan api. setelah agak dingin campur ke adonan pertama (1) sambil di mixer dan tercampur rata. sisihkan."
- "Bahan 3 : rebus semua bahan dengan api sedang dan diaduk2 terus hingga beruap dan mengental. aduk hingga tdk bergerindil. matikan api. setelah agak dingin masukkan ke dalam botol plastik kecap atau papingbag."
- "Siapkan loyang kue talam yg telah diolesi minyak. tuang adonan hijau 3/4 kemudian semprotkan adonan putih dgn cara dicelupkan sedikit kedalam adonan hijau."
- "Kukus selama 15 menit. biarkan dingin agar bisa melepaskan dr cetakan kue. jgn keadaan panas. kue msh lembek"
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 143 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Dinner

---


![Nona Manis](https://img-global.cpcdn.com/recipes/a4c9c39a13147449/680x482cq70/nona-manis-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang setidaknya kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti nona manis yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan keistimewahan yang merupakan keragaman Indonesia

Kedekatan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah memasak Nona Manis untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang dapat anda praktekkan salah satunya nona manis yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep nona manis tanpa harus bersusah payah.
Berikut ini resep Nona Manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona Manis:

1. Dibutuhkan  Bahan 1 :
1. Harus ada 1 butir kelapa untuk semua bahan
1. Diperlukan 2 butir telur
1. Harap siapkan 230 gr gula pasir
1. Siapkan 400 ml santan kental
1. Harus ada 220 gr tepung terigu
1. Siapkan  Bahan 2 :
1. Jangan lupa 400 ml santan kental
1. Jangan lupa 40 gr meizena
1. Tambah 120 gr gula pasir
1. Dibutuhkan 1/2 sdt garam
1. Harus ada secukupnya pewarna hijau
1. Diperlukan  daun pandan
1. Tambah  Bahan 3 :
1. Harap siapkan 400 gr santan kental
1. Diperlukan 3 sdm tepung trigu
1. Harus ada 3 sdm gula pasir
1. Jangan lupa 1/2 sdt garam
1. Tambah 1/2 sdt Extrak Vanilli




<!--inarticleads2-->

##### Bagaimana membuat  Nona Manis:

1. Bahan 1 : Mix gula, telur, extrak vanilli hinggal kental. gula larut yaa. lalu masukkan santan kental dan terigu secara bertahap. mixer kecepatan rendah sampai rata lalu sisihkan.
1. Bahan 2 : Rebus semua bahan dengan api sedang hingga beruap dan mengental. beri pewarna hijau dan daun pandan. matikan api. setelah agak dingin campur ke adonan pertama (1) sambil di mixer dan tercampur rata. sisihkan.
1. Bahan 3 : rebus semua bahan dengan api sedang dan diaduk2 terus hingga beruap dan mengental. aduk hingga tdk bergerindil. matikan api. setelah agak dingin masukkan ke dalam botol plastik kecap atau papingbag.
1. Siapkan loyang kue talam yg telah diolesi minyak. tuang adonan hijau 3/4 kemudian semprotkan adonan putih dgn cara dicelupkan sedikit kedalam adonan hijau.
1. Kukus selama 15 menit. biarkan dingin agar bisa melepaskan dr cetakan kue. jgn keadaan panas. kue msh lembek




Demikianlah cara membuat nona manis yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan cepat, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
