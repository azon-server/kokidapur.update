---
description: "Resep : Ayam Masak Kecap Nona Manis Sempurna"
title: "Resep : Ayam Masak Kecap Nona Manis Sempurna"
slug: 408-resep-ayam-masak-kecap-nona-manis-sempurna
date: 2021-02-21T16:35:34.025Z
image: https://img-global.cpcdn.com/recipes/046d40fc683824a5/680x482cq70/ayam-masak-kecap-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/046d40fc683824a5/680x482cq70/ayam-masak-kecap-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/046d40fc683824a5/680x482cq70/ayam-masak-kecap-nona-manis-foto-resep-utama.jpg
author: Zachary Bryan
ratingvalue: 4
reviewcount: 44131
recipeingredient:
- "250 gram ayam potong"
- "1/4 sendok teh air asam jawa"
- "1/2 sendok teh garam halus"
- "2 sendok makan kecap manis"
- "1 sendok teh kecap asin"
- "1/2 sendok teh garam halus"
- "2 buah cabe merah buah bijinya iris miring"
- "1/2 sendok teh merica bubuk"
- "secukupnya Gula merah"
- "2 batang daun bawangiris"
- "1 lembar daun jeruk"
- " Bawang bombay iris horisontal secukupnya"
- "3 sendok makan minyak untuk goreng dan menumis"
- " Bumbu halus "
- "3 butir bawang merah"
- "2 siung bawah putih"
recipeinstructions:
- "Persiapkan bahan"
- "Lumuri ayam dengan air asam, garam, merica bubuk. Diamkan 30 menit"
- "Goreng ayam sampai matang dan berkulit"
- "Panaskan minyak. Tumis Bawang bombay, bumbu halus dan cabe merah sampai harum. Tambahkan ayam goreng. Aduk rata."
- "Masukkan kecap asin dan manis,garam,gula merah, merica bubuk. daun jeruk. Aduk rata"
- "Tuang air. Masak ayam hingga air meresap. setelah matang taburkan daun bawang. Aduk rata"
- "Siap"
categories:
- Recipe
tags:
- ayam
- masak
- kecap

katakunci: ayam masak kecap 
nutrition: 118 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT54M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Masak Kecap Nona Manis](https://img-global.cpcdn.com/recipes/046d40fc683824a5/680x482cq70/ayam-masak-kecap-nona-manis-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga gurih. Ciri khas makanan Nusantara ayam masak kecap nona manis yang penuh dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan rumah tangga dapat diperoleh dengan cara simple. Diantaranya adalah memasak Ayam Masak Kecap Nona Manis untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang dapat anda coba salah satunya ayam masak kecap nona manis yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam masak kecap nona manis tanpa harus bersusah payah.
Berikut ini resep Ayam Masak Kecap Nona Manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Masak Kecap Nona Manis:

1. Diperlukan 250 gram ayam potong
1. Tambah 1/4 sendok teh air asam jawa
1. Dibutuhkan 1/2 sendok teh garam halus
1. Diperlukan 2 sendok makan kecap manis
1. Harap siapkan 1 sendok teh kecap asin
1. Dibutuhkan 1/2 sendok teh garam halus
1. Jangan lupa 2 buah cabe merah buah bijinya, iris miring
1. Siapkan 1/2 sendok teh merica bubuk
1. Dibutuhkan secukupnya Gula merah
1. Tambah 2 batang daun bawang,iris
1. Siapkan 1 lembar daun jeruk
1. Harap siapkan  Bawang bombay iris horisontal secukupnya
1. Harap siapkan 3 sendok makan minyak untuk goreng dan menumis
1. Harap siapkan  Bumbu halus :
1. Diperlukan 3 butir bawang merah
1. Harap siapkan 2 siung bawah putih




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Masak Kecap Nona Manis:

1. Persiapkan bahan
1. Lumuri ayam dengan air asam, garam, merica bubuk. Diamkan 30 menit
1. Goreng ayam sampai matang dan berkulit
1. Panaskan minyak. Tumis Bawang bombay, bumbu halus dan cabe merah sampai harum. Tambahkan ayam goreng. Aduk rata.
1. Masukkan kecap asin dan manis,garam,gula merah, merica bubuk. daun jeruk. Aduk rata
1. Tuang air. Masak ayam hingga air meresap. setelah matang taburkan daun bawang. Aduk rata
1. Siap




Demikianlah cara membuat ayam masak kecap nona manis yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat simple dan teruji, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
