---
description: "Step-by-Step untuk menyiapakan Gulai Ayam khas Padang Sempurna"
title: "Step-by-Step untuk menyiapakan Gulai Ayam khas Padang Sempurna"
slug: 67-step-by-step-untuk-menyiapakan-gulai-ayam-khas-padang-sempurna
date: 2021-02-17T16:57:26.606Z
image: https://img-global.cpcdn.com/recipes/29f4607b4f0707ae/680x482cq70/gulai-ayam-khas-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/29f4607b4f0707ae/680x482cq70/gulai-ayam-khas-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/29f4607b4f0707ae/680x482cq70/gulai-ayam-khas-padang-foto-resep-utama.jpg
author: Cole Castro
ratingvalue: 4.2
reviewcount: 44088
recipeingredient:
- "1/2 kg ayam"
- "1 bh jeruk nipis"
- "2 btg serai memarkan"
- "3 lbr daun jeruk"
- "1 sch santan instan"
- "600 ml air secukupnya"
- "1 1/2 sdm garam"
- "1 1/2 sdt kaldu jamur"
- "1 sdm gula pasir"
- "3 sdm minyak goreng utk menumis"
- " Bumbu halus"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "2 btr kemiri sangrai"
- "1 bh cabe merah besar"
- "1/2 sdt ketumbar sangrai"
- "1 sdt jinten sangrai"
- "1 ruas jahe"
- "2 ruas kunyit"
recipeinstructions:
- "Cuci bersih ayam, lalu kucuri air jeruk nipis, diamkan 10 mnt, bilas sampai bersih. Haluskan bumbu halus."
- "Panaskan minyak, tumis bumbu halus, serai dan daun jeruk sampai harum dan matang. Masukkan ayam."
- "Tambahkan air secukupnya, beri garam, gula, dan kaldu jamur. Aduk² sampai merata dan masak sampai ayam matang, empuk dan bumbu meresap. Terakhir masukkan santan instan, aduk rata, tunggu mendidih, lalu koreksi rasa. Angkat dan sajikan😋🥰"
categories:
- Recipe
tags:
- gulai
- ayam
- khas

katakunci: gulai ayam khas 
nutrition: 217 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Lunch

---


![Gulai Ayam khas Padang](https://img-global.cpcdn.com/recipes/29f4607b4f0707ae/680x482cq70/gulai-ayam-khas-padang-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga empuk. Ciri khas makanan Nusantara gulai ayam khas padang yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan keluarga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Gulai Ayam khas Padang untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda buat salah satunya gulai ayam khas padang yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep gulai ayam khas padang tanpa harus bersusah payah.
Berikut ini resep Gulai Ayam khas Padang yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Gulai Ayam khas Padang:

1. Tambah 1/2 kg ayam
1. Siapkan 1 bh jeruk nipis
1. Diperlukan 2 btg serai, memarkan
1. Jangan lupa 3 lbr daun jeruk
1. Harus ada 1 sch santan instan
1. Dibutuhkan 600 ml air (secukupnya)
1. Diperlukan 1 1/2 sdm garam
1. Jangan lupa 1 1/2 sdt kaldu jamur
1. Harus ada 1 sdm gula pasir
1. Harus ada 3 sdm minyak goreng, utk menumis
1. Tambah  Bumbu halus:
1. Diperlukan 6 siung bawang merah
1. Tambah 4 siung bawang putih
1. Siapkan 2 btr kemiri sangrai
1. Harap siapkan 1 bh cabe merah besar
1. Tambah 1/2 sdt ketumbar sangrai
1. Dibutuhkan 1 sdt jinten sangrai
1. Harus ada 1 ruas jahe
1. Diperlukan 2 ruas kunyit




<!--inarticleads2-->

##### Bagaimana membuat  Gulai Ayam khas Padang:

1. Cuci bersih ayam, lalu kucuri air jeruk nipis, diamkan 10 mnt, bilas sampai bersih. Haluskan bumbu halus.
1. Panaskan minyak, tumis bumbu halus, serai dan daun jeruk sampai harum dan matang. Masukkan ayam.
1. Tambahkan air secukupnya, beri garam, gula, dan kaldu jamur. Aduk² sampai merata dan masak sampai ayam matang, empuk dan bumbu meresap. Terakhir masukkan santan instan, aduk rata, tunggu mendidih, lalu koreksi rasa. Angkat dan sajikan😋🥰




Demikianlah cara membuat gulai ayam khas padang yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
