---
description: "Step-by-Step membuat Kerang saos padang (plus kemangi) minggu ini"
title: "Step-by-Step membuat Kerang saos padang (plus kemangi) minggu ini"
slug: 215-step-by-step-membuat-kerang-saos-padang-plus-kemangi-minggu-ini
date: 2020-09-23T19:54:58.057Z
image: https://img-global.cpcdn.com/recipes/c2b245cdadb73a15/680x482cq70/kerang-saos-padang-plus-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c2b245cdadb73a15/680x482cq70/kerang-saos-padang-plus-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c2b245cdadb73a15/680x482cq70/kerang-saos-padang-plus-kemangi-foto-resep-utama.jpg
author: Marc Benson
ratingvalue: 4
reviewcount: 23148
recipeingredient:
- "250 gr kerang hijau kupas"
- " Jeruk nipis"
- "1/2 ruas jahe geprek"
- " Air untuk merebus kerang"
- "1 ruas laos geprek"
- " Daun jeruk"
- " Garam gula MSG"
- " Kemangi optional"
- " Bumbu halus "
- "3 pcs bawang putih"
- "5 pcs bawang merah"
- "3 pcs cabe besar"
- "sesuai selera Cabe kecil"
- "1 ruas kunyit"
recipeinstructions:
- "Cuci bersih kerang, tiriskan dan baluri dgn air jeruk nipis. Diamkan 10-15 menit"
- "Kemudian cuci lg kerang dan rebus di air mendidih + jahe geprek selama 5 menit. Tiriskan."
- "Tumis bumbu halus + laos + daun jeruk sampai wangi dan berminyak. Masukkan kerang tadi, aduk sebentar lalu tambahkan air. Beri garam, gula, MSG. Tes rasa. Biarkan mendidih."
- "Bila air sdh meresap dan mengental tambahkan daun kemangi. Matikan api. Sajikan."
categories:
- Recipe
tags:
- kerang
- saos
- padang

katakunci: kerang saos padang 
nutrition: 271 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Lunch

---


![Kerang saos padang (plus kemangi)](https://img-global.cpcdn.com/recipes/c2b245cdadb73a15/680x482cq70/kerang-saos-padang-plus-kemangi-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita lestarikan karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti kerang saos padang (plus kemangi) yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia

Kedekatan rumah tangga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Kerang saos padang (plus kemangi) untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang bisa anda praktekkan salah satunya kerang saos padang (plus kemangi) yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep kerang saos padang (plus kemangi) tanpa harus bersusah payah.
Seperti resep Kerang saos padang (plus kemangi) yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kerang saos padang (plus kemangi):

1. Harus ada 250 gr kerang hijau kupas
1. Tambah  Jeruk nipis
1. Tambah 1/2 ruas jahe geprek
1. Siapkan  Air untuk merebus kerang
1. Harus ada 1 ruas laos geprek
1. Harus ada  Daun jeruk
1. Harus ada  Garam, gula, MSG
1. Diperlukan  Kemangi (optional)
1. Tambah  Bumbu halus :
1. Harap siapkan 3 pcs bawang putih
1. Diperlukan 5 pcs bawang merah
1. Jangan lupa 3 pcs cabe besar
1. Siapkan sesuai selera Cabe kecil
1. Diperlukan 1 ruas kunyit




<!--inarticleads2-->

##### Langkah membuat  Kerang saos padang (plus kemangi):

1. Cuci bersih kerang, tiriskan dan baluri dgn air jeruk nipis. Diamkan 10-15 menit
1. Kemudian cuci lg kerang dan rebus di air mendidih + jahe geprek selama 5 menit. Tiriskan.
1. Tumis bumbu halus + laos + daun jeruk sampai wangi dan berminyak. Masukkan kerang tadi, aduk sebentar lalu tambahkan air. Beri garam, gula, MSG. Tes rasa. Biarkan mendidih.
1. Bila air sdh meresap dan mengental tambahkan daun kemangi. Matikan api. Sajikan.




Demikianlah cara membuat kerang saos padang (plus kemangi) yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan terbukti, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
