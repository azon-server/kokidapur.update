---
description: "Cara singkat untuk membuat Sate Padang terupdate"
title: "Cara singkat untuk membuat Sate Padang terupdate"
slug: 135-cara-singkat-untuk-membuat-sate-padang-terupdate
date: 2021-01-23T22:13:54.932Z
image: https://img-global.cpcdn.com/recipes/f6bd227742ecf4a4/680x482cq70/sate-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f6bd227742ecf4a4/680x482cq70/sate-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f6bd227742ecf4a4/680x482cq70/sate-padang-foto-resep-utama.jpg
author: Katie Harper
ratingvalue: 4.5
reviewcount: 13682
recipeingredient:
- "1 kg dada ayam buang kulitnya potong kecil"
- " Bahan 1"
- "7 bh bawang putih"
- "2 sdm ketumbar kasar"
- "secukupnya Garam"
- " Bahan 2"
- "7 bh bawang merah"
- "7 bh bawang putih"
- "6 bh cabe keriting sesuai selera"
- "secukupnya Kunyit"
- "secukupnya Jahe"
- "secukupnya Laos geprek"
- "2 batang sereh geprek"
- "4 lembar daun jeruk buang tulang tengahnya"
- "1 lembar daun kunyit"
- "1 sdm ketumbar"
- "secukupnya Merica"
- "4 bh kemiri"
- "Sedikit jinten"
- "2 bh kapulaga"
- "2 bh bunga lawang"
- "7 bh cengkeh"
- "3 sdm tepung beras"
recipeinstructions:
- "Langkah 1 Giling halus bahan 1, balurkan di daging yg sudah ditusuk, diamkan sambil menunggu untuk memasak kuah masukkan kulkas lebih baik. Setelah bumbu meresap sate siap dibakar"
- "Blender halus cabe, bawang, merica, ketumbar, kemiri, kunyit, jahe, jinten"
- "Tumis bumbu yg sudah dihaluskan, masukkan laos, sereh, daun jeruk, daun kunyit, kapulaga, cengkeh, bunga lawang sampai matang dan harum"
- "Beri air secukupnya, masukkan kacang yg sudah digiling kasar, masak sampai kacang sedikit lembut"
- "Cairkan tepung beras dengan sedikit air sampai merata dan tidak menggumpal, lalu masukkan kedalam kuah yg sudah mendidih, aduk rata"
- "Tes rasa, untuk kekentalan bisa diatur sesuai selera. Sajikan dengan ketupat atau lontong"
categories:
- Recipe
tags:
- sate
- padang

katakunci: sate padang 
nutrition: 143 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Lunch

---


![Sate Padang](https://img-global.cpcdn.com/recipes/f6bd227742ecf4a4/680x482cq70/sate-padang-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga gurih. Karasteristik kuliner Indonesia sate padang yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Sate Padang untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang bisa anda buat salah satunya sate padang yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep sate padang tanpa harus bersusah payah.
Berikut ini resep Sate Padang yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 23 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sate Padang:

1. Siapkan 1 kg dada ayam buang kulitnya, potong kecil
1. Dibutuhkan  Bahan 1
1. Harap siapkan 7 bh bawang putih
1. Dibutuhkan 2 sdm ketumbar kasar
1. Harap siapkan secukupnya Garam
1. Harus ada  Bahan 2
1. Siapkan 7 bh bawang merah
1. Harap siapkan 7 bh bawang putih
1. Siapkan 6 bh cabe keriting (sesuai selera)
1. Dibutuhkan secukupnya Kunyit
1. Diperlukan secukupnya Jahe
1. Diperlukan secukupnya Laos, geprek
1. Tambah 2 batang sereh, geprek
1. Siapkan 4 lembar daun jeruk, buang tulang tengahnya
1. Siapkan 1 lembar daun kunyit
1. Jangan lupa 1 sdm ketumbar
1. Dibutuhkan secukupnya Merica
1. Dibutuhkan 4 bh kemiri
1. Diperlukan Sedikit jinten
1. Harap siapkan 2 bh kapulaga
1. Harus ada 2 bh bunga lawang
1. Jangan lupa 7 bh cengkeh
1. Jangan lupa 3 sdm tepung beras




<!--inarticleads2-->

##### Cara membuat  Sate Padang:

1. Langkah 1 - Giling halus bahan 1, balurkan di daging yg sudah ditusuk, diamkan sambil menunggu untuk memasak kuah masukkan kulkas lebih baik. Setelah bumbu meresap sate siap dibakar
1. Blender halus cabe, bawang, merica, ketumbar, kemiri, kunyit, jahe, jinten
1. Tumis bumbu yg sudah dihaluskan, masukkan laos, sereh, daun jeruk, daun kunyit, kapulaga, cengkeh, bunga lawang sampai matang dan harum
1. Beri air secukupnya, masukkan kacang yg sudah digiling kasar, masak sampai kacang sedikit lembut
1. Cairkan tepung beras dengan sedikit air sampai merata dan tidak menggumpal, lalu masukkan kedalam kuah yg sudah mendidih, aduk rata
1. Tes rasa, untuk kekentalan bisa diatur sesuai selera. Sajikan dengan ketupat atau lontong
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Sate Padang">



Demikianlah cara membuat sate padang yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan teruji, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
