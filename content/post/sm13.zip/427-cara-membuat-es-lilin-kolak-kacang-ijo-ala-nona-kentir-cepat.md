---
description: "Cara membuat Es Lilin Kolak Kacang Ijo ala Nona Kentir Cepat"
title: "Cara membuat Es Lilin Kolak Kacang Ijo ala Nona Kentir Cepat"
slug: 427-cara-membuat-es-lilin-kolak-kacang-ijo-ala-nona-kentir-cepat
date: 2020-09-26T13:00:28.244Z
image: https://img-global.cpcdn.com/recipes/9a59509cc8067bb2/680x482cq70/es-lilin-kolak-kacang-ijo-ala-nona-kentir-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9a59509cc8067bb2/680x482cq70/es-lilin-kolak-kacang-ijo-ala-nona-kentir-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9a59509cc8067bb2/680x482cq70/es-lilin-kolak-kacang-ijo-ala-nona-kentir-foto-resep-utama.jpg
author: Derrick Cross
ratingvalue: 4.9
reviewcount: 18143
recipeingredient:
- "1/4 kg kacang ijo"
- "1/2 butir kelapa"
- "4 bh gula merah"
- "5 irus gula pasir setara 14 kg kayaknya hehe"
- "2 helai daun pandai ikat"
- "1 sdt garam"
recipeinstructions:
- "Cuci kacang ijo rendam 30 menit aja. Habis itu panaskan air sepanci. Masukkan kacang ijo. Tunggu sampai mendidih dan kacang ijo mekar (mengelupas kulitnya) jangan sekali2 masukkan gula kalo belum bener2 empuk."
- "Bikin santen yaa. Tips: iris kelapa kecil2, diblender kasi air. Trs diperas. Ulangi sampe 3 kali. Kalau bisa jangan pake santan instan. Nti kurang sedep."
- "Udah mekar kacang ijonya baru masukkan santan.. gula merah.. gula pasir.. garam.. Cek rasa sampai dapet manisnya sesuai selera kamu 😊 daun pandan ganti yg baru. Biar tetep wangi. Aduk terus sampai mendidih. Matikan kompor. Pisah isi dan kuahnya biar cepat dingin."
- "Udah deh. Tinggal masukkan kolak ke wadah plastik es lilin. Taruh di freezer kulkas. Dan nikmati pagi harinya atau kalo ga sabar, bisa dinikmati waktu masi setengah membeku..muanis dan nagih banget 😍"
categories:
- Recipe
tags:
- es
- lilin
- kolak

katakunci: es lilin kolak 
nutrition: 109 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Lunch

---


![Es Lilin Kolak Kacang Ijo ala Nona Kentir](https://img-global.cpcdn.com/recipes/9a59509cc8067bb2/680x482cq70/es-lilin-kolak-kacang-ijo-ala-nona-kentir-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang harus kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti es lilin kolak kacang ijo ala nona kentir yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia

Kedekatan rumah tangga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Es Lilin Kolak Kacang Ijo ala Nona Kentir untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian masakan yang bisa anda praktekkan salah satunya es lilin kolak kacang ijo ala nona kentir yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep es lilin kolak kacang ijo ala nona kentir tanpa harus bersusah payah.
Berikut ini resep Es Lilin Kolak Kacang Ijo ala Nona Kentir yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 6 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Es Lilin Kolak Kacang Ijo ala Nona Kentir:

1. Dibutuhkan 1/4 kg kacang ijo
1. Harap siapkan 1/2 butir kelapa
1. Harus ada 4 bh gula merah
1. Jangan lupa 5 irus gula pasir (setara 1/4 kg kayaknya hehe)
1. Siapkan 2 helai daun pandai (ikat)
1. Harus ada 1 sdt garam




<!--inarticleads2-->

##### Bagaimana membuat  Es Lilin Kolak Kacang Ijo ala Nona Kentir:

1. Cuci kacang ijo rendam 30 menit aja. Habis itu panaskan air sepanci. Masukkan kacang ijo. Tunggu sampai mendidih dan kacang ijo mekar (mengelupas kulitnya) jangan sekali2 masukkan gula kalo belum bener2 empuk.
1. Bikin santen yaa. Tips: iris kelapa kecil2, diblender kasi air. Trs diperas. Ulangi sampe 3 kali. Kalau bisa jangan pake santan instan. Nti kurang sedep.
1. Udah mekar kacang ijonya baru masukkan santan.. gula merah.. gula pasir.. garam.. Cek rasa sampai dapet manisnya sesuai selera kamu 😊 daun pandan ganti yg baru. Biar tetep wangi. Aduk terus sampai mendidih. Matikan kompor. Pisah isi dan kuahnya biar cepat dingin.
1. Udah deh. Tinggal masukkan kolak ke wadah plastik es lilin. Taruh di freezer kulkas. Dan nikmati pagi harinya atau kalo ga sabar, bisa dinikmati waktu masi setengah membeku..muanis dan nagih banget 😍




Demikianlah cara membuat es lilin kolak kacang ijo ala nona kentir yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan terbukti, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
