---
description: "Steps membuat Ayam Goreng Kelapa Khas Padang Sempurna"
title: "Steps membuat Ayam Goreng Kelapa Khas Padang Sempurna"
slug: 72-steps-membuat-ayam-goreng-kelapa-khas-padang-sempurna
date: 2021-01-01T15:21:04.394Z
image: https://img-global.cpcdn.com/recipes/971e55af0f1716ba/680x482cq70/ayam-goreng-kelapa-khas-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/971e55af0f1716ba/680x482cq70/ayam-goreng-kelapa-khas-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/971e55af0f1716ba/680x482cq70/ayam-goreng-kelapa-khas-padang-foto-resep-utama.jpg
author: Sue Guerrero
ratingvalue: 4.7
reviewcount: 18276
recipeingredient:
- "1.5 ekor Ayam Broiler kurleb total 18kg"
- "1 buah jeruk nipis"
- "500 ml air"
- "1 buah kelapa kerok kulit dan parut"
- " Bumbu halus "
- "1 ruas kunyit"
- "1 ruas jahe"
- "6 butir kemiri"
- "12 siung bawang putih"
- "1.5 sdm ketumbar"
- "2 ruas lengkuas"
- "secukupnya Garam"
- " Bumbu cemplung "
- "3 lembar daun salam"
- "2 batang sereh"
- "3 lembar daun jeruk"
recipeinstructions:
- "Bersihkan ayam, biasanya saya cek satu persatu apakah masih ada bulu menempel. Jika ada cabut bulu yg masih menempel, setelah bersih beri perasan jeruk nipis, diamkan 15 menit lalu bilas kembali. Blender halus bumbu bersama 250ml air. Lalu tuang bumbu halus bersama sisa air dan bumbu cemplung, tes rasa dan masak hingga mendidih."
- "Masukkan ayam, masak hingga air tinggal sedikit, matikan kompor. Ambil ayam dari penggorengan dan masukkan kedalam wadah, sisihkan."
- "Ini sisa kuah ayam, lalu masukkan kelapa dan nyalakan kompor kembali. Masak kelapa hingga air asat, tes rasa. Saya disini menambah 1/2 sdt garam."
- "Panaskan minyak goreng, masukkan ayam dan goreng hingga keemasan. Angkat dan tiriskan. Disini saya memakai tips sama seperti menggoreng ikan agar minyak tidak mudah meletup.           (lihat tips)"
- "Setelah ayam semua matang, lalu goreng kelapa. Masak hingga warnanya kekuningan, jangan takut tidak matang ya karena jika sudah coklat nanti diangkat cepat gosong dan membuat kelapa menjadi agak pahit."
- "Cara penyajian, taruh ayam goreng diatas piring dan siram dengan kelapa goreng. Ayam goreng kelapa khas padang siapkan dinikmati 🥰🥰"
categories:
- Recipe
tags:
- ayam
- goreng
- kelapa

katakunci: ayam goreng kelapa 
nutrition: 109 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Goreng Kelapa Khas Padang](https://img-global.cpcdn.com/recipes/971e55af0f1716ba/680x482cq70/ayam-goreng-kelapa-khas-padang-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga empuk. Ciri masakan Nusantara ayam goreng kelapa khas padang yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah memasak Ayam Goreng Kelapa Khas Padang untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang bisa anda praktekkan salah satunya ayam goreng kelapa khas padang yang merupakan resep favorite yang mudah dengan kreasi sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep ayam goreng kelapa khas padang tanpa harus bersusah payah.
Seperti resep Ayam Goreng Kelapa Khas Padang yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Kelapa Khas Padang:

1. Dibutuhkan 1.5 ekor Ayam Broiler (kurleb total 1.8kg)
1. Harap siapkan 1 buah jeruk nipis
1. Jangan lupa 500 ml air
1. Tambah 1 buah kelapa, kerok kulit dan parut
1. Diperlukan  Bumbu halus :
1. Harap siapkan 1 ruas kunyit
1. Jangan lupa 1 ruas jahe
1. Dibutuhkan 6 butir kemiri
1. Jangan lupa 12 siung bawang putih
1. Diperlukan 1.5 sdm ketumbar
1. Harus ada 2 ruas lengkuas
1. Jangan lupa secukupnya Garam
1. Harus ada  Bumbu cemplung :
1. Jangan lupa 3 lembar daun salam
1. Tambah 2 batang sereh
1. Harus ada 3 lembar daun jeruk




<!--inarticleads2-->

##### Cara membuat  Ayam Goreng Kelapa Khas Padang:

1. Bersihkan ayam, biasanya saya cek satu persatu apakah masih ada bulu menempel. Jika ada cabut bulu yg masih menempel, setelah bersih beri perasan jeruk nipis, diamkan 15 menit lalu bilas kembali. Blender halus bumbu bersama 250ml air. Lalu tuang bumbu halus bersama sisa air dan bumbu cemplung, tes rasa dan masak hingga mendidih.
1. Masukkan ayam, masak hingga air tinggal sedikit, matikan kompor. Ambil ayam dari penggorengan dan masukkan kedalam wadah, sisihkan.
1. Ini sisa kuah ayam, lalu masukkan kelapa dan nyalakan kompor kembali. Masak kelapa hingga air asat, tes rasa. Saya disini menambah 1/2 sdt garam.
1. Panaskan minyak goreng, masukkan ayam dan goreng hingga keemasan. Angkat dan tiriskan. Disini saya memakai tips sama seperti menggoreng ikan agar minyak tidak mudah meletup. -           (lihat tips)
1. Setelah ayam semua matang, lalu goreng kelapa. Masak hingga warnanya kekuningan, jangan takut tidak matang ya karena jika sudah coklat nanti diangkat cepat gosong dan membuat kelapa menjadi agak pahit.
1. Cara penyajian, taruh ayam goreng diatas piring dan siram dengan kelapa goreng. Ayam goreng kelapa khas padang siapkan dinikmati 🥰🥰




Demikianlah cara membuat ayam goreng kelapa khas padang yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan teruji, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
