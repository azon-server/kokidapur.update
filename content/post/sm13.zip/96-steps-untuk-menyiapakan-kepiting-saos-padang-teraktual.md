---
description: "Steps untuk menyiapakan Kepiting Saos Padang teraktual"
title: "Steps untuk menyiapakan Kepiting Saos Padang teraktual"
slug: 96-steps-untuk-menyiapakan-kepiting-saos-padang-teraktual
date: 2021-01-31T18:26:17.526Z
image: https://img-global.cpcdn.com/recipes/cd81e7901e39998a/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cd81e7901e39998a/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cd81e7901e39998a/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg
author: Jeremiah Greene
ratingvalue: 4.4
reviewcount: 7618
recipeingredient:
- "3 ekor kepiting"
- "3 lembar daun jeruk"
- "1/2 butir bawang bombai"
- "1 ruas jahe"
- "3 sdm saos tomat"
- "2 sdm saos tiram"
- "1 sdm saos cabe"
- "1 buah tomat"
- "1/2 sdt lada bubuk"
- " Kaldu jamur"
- " Gula"
- " Garam"
- "Secukupnya air"
- " Bumbu halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "4 cabe merah"
- "5 cabe rawit"
recipeinstructions:
- "Sebelumnya cuci bersih kepitingnya dulu ya lalu buka sedikit cangkangnya agar bumbu meresap hingga kedalam. Untuk cara membersihkan sudah aku share di postingan sebelumnya           (lihat tips)"
- "Siapkan bawang bombai dan jahe geprek. Lalu haluskan bahan bumbu halus"
- "Tumis bumbu halus dengan sedikit minyak lalu tambahkan daun jeruk, bawang bombai dan jahe aduk rata masak hingga bumbu harum."
- "Setelah bumbu harum masukkan kepiting, aduk rata hingga berubah warna. Disini aku pakai kepiting yang masih mentah ya biar lebih gurih dan bumbunya meresap kedalam."
- "Setelah kepiting berubah warna masukkan air, usahakan air bisa merendam kepiting kemudian masak hingga air sedikit surut. Tambahkan gula, soas tomat, saos tiram, saos cabe, lada bubuk aduk rata"
- "Setelah air surut masukkan potongan tomat aduk rata lalu koreksi rasa, disini aku pakai garam terakhir setelah masukin tomat lalu aku koreksi rasanya dulu jika kurang asin baru beri garam. Karena kepiting yg di masak mentah dia akan menggeluarkan kaldu&#34;nya dan itu sudah memberi rasa asin."
- "Masak hingga soas sedikit mengental angkat dan sajikan"
categories:
- Recipe
tags:
- kepiting
- saos
- padang

katakunci: kepiting saos padang 
nutrition: 139 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Lunch

---


![Kepiting Saos Padang](https://img-global.cpcdn.com/recipes/cd81e7901e39998a/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang patut kita jaga karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti kepiting saos padang yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan keistimewahan yang merupakan keragaman Nusantara

Kehangatan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak Kepiting Saos Padang untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang bisa anda contoh salah satunya kepiting saos padang yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep kepiting saos padang tanpa harus bersusah payah.
Berikut ini resep Kepiting Saos Padang yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kepiting Saos Padang:

1. Diperlukan 3 ekor kepiting
1. Harap siapkan 3 lembar daun jeruk
1. Tambah 1/2 butir bawang bombai
1. Dibutuhkan 1 ruas jahe
1. Jangan lupa 3 sdm saos tomat
1. Jangan lupa 2 sdm saos tiram
1. Jangan lupa 1 sdm saos cabe
1. Harus ada 1 buah tomat
1. Tambah 1/2 sdt lada bubuk
1. Harus ada  Kaldu jamur
1. Harap siapkan  Gula
1. Harus ada  Garam
1. Jangan lupa Secukupnya air
1. Siapkan  Bumbu halus
1. Dibutuhkan 5 siung bawang merah
1. Diperlukan 3 siung bawang putih
1. Jangan lupa 4 cabe merah
1. Siapkan 5 cabe rawit




<!--inarticleads2-->

##### Langkah membuat  Kepiting Saos Padang:

1. Sebelumnya cuci bersih kepitingnya dulu ya lalu buka sedikit cangkangnya agar bumbu meresap hingga kedalam. Untuk cara membersihkan sudah aku share di postingan sebelumnya -           (lihat tips)
1. Siapkan bawang bombai dan jahe geprek. Lalu haluskan bahan bumbu halus
1. Tumis bumbu halus dengan sedikit minyak lalu tambahkan daun jeruk, bawang bombai dan jahe aduk rata masak hingga bumbu harum.
1. Setelah bumbu harum masukkan kepiting, aduk rata hingga berubah warna. Disini aku pakai kepiting yang masih mentah ya biar lebih gurih dan bumbunya meresap kedalam.
1. Setelah kepiting berubah warna masukkan air, usahakan air bisa merendam kepiting kemudian masak hingga air sedikit surut. Tambahkan gula, soas tomat, saos tiram, saos cabe, lada bubuk aduk rata
1. Setelah air surut masukkan potongan tomat aduk rata lalu koreksi rasa, disini aku pakai garam terakhir setelah masukin tomat lalu aku koreksi rasanya dulu jika kurang asin baru beri garam. Karena kepiting yg di masak mentah dia akan menggeluarkan kaldu&#34;nya dan itu sudah memberi rasa asin.
1. Masak hingga soas sedikit mengental angkat dan sajikan
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Kepiting Saos Padang">



Demikianlah cara membuat kepiting saos padang yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
