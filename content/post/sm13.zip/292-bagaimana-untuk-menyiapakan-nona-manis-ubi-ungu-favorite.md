---
description: "Bagaimana untuk menyiapakan Nona manis ubi ungu Favorite"
title: "Bagaimana untuk menyiapakan Nona manis ubi ungu Favorite"
slug: 292-bagaimana-untuk-menyiapakan-nona-manis-ubi-ungu-favorite
date: 2020-09-22T19:36:34.151Z
image: https://img-global.cpcdn.com/recipes/f3b9c19b332f2872/680x482cq70/nona-manis-ubi-ungu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f3b9c19b332f2872/680x482cq70/nona-manis-ubi-ungu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f3b9c19b332f2872/680x482cq70/nona-manis-ubi-ungu-foto-resep-utama.jpg
author: Francis Palmer
ratingvalue: 4.4
reviewcount: 5230
recipeingredient:
- " Adonan ungu"
- "350 gr ubi ungu yg sudah dikukus lumatkan"
- "2 butir telur"
- "3 sdm tepung terigu"
- "2 bungkus santan kara 65ml"
- "5 sdm gula pasir"
- " Adonan putih"
- "2 bungkus santan kara 65ml"
- "2 bungkus air bungkus bekas santan utk bersihin bungkus santan"
- "Sejumput garam"
- "2 sdm tepung terigu"
- " Minyak makan untuk mengolesi cetakan"
recipeinstructions:
- "Siapkan ubi ungu, haluskan."
- "Campur semua bahan adonan ungu."
- "Jerang adonan putih hingga mengental &amp; meletup-letup."
- "Isi cetakan dengan adonan ungu, diakhiri dengan adonan putih. Kukus hingga matang."
- "Setelah matang biarkan dingin, lalu keluarkan kue dari cetakan."
- "Kue nona manies siap dibagikan ke tetangga."
categories:
- Recipe
tags:
- nona
- manis
- ubi

katakunci: nona manis ubi 
nutrition: 277 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT58M"
recipeyield: "1"
recipecategory: Dinner

---


![Nona manis ubi ungu](https://img-global.cpcdn.com/recipes/f3b9c19b332f2872/680x482cq70/nona-manis-ubi-ungu-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan empuk. Ciri masakan Nusantara nona manis ubi ungu yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah memasak Nona manis ubi ungu untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang bisa anda buat salah satunya nona manis ubi ungu yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep nona manis ubi ungu tanpa harus bersusah payah.
Seperti resep Nona manis ubi ungu yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 12 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona manis ubi ungu:

1. Siapkan  Adonan ungu:
1. Siapkan 350 gr ubi ungu yg sudah dikukus, lumatkan
1. Dibutuhkan 2 butir telur
1. Siapkan 3 sdm tepung terigu
1. Harus ada 2 bungkus santan kara @65ml
1. Diperlukan 5 sdm gula pasir
1. Jangan lupa  Adonan putih
1. Diperlukan 2 bungkus santan kara @65ml
1. Siapkan 2 bungkus air (bungkus bekas santan utk bersihin bungkus santan)
1. Tambah Sejumput garam
1. Jangan lupa 2 sdm tepung terigu
1. Dibutuhkan  Minyak makan untuk mengolesi cetakan




<!--inarticleads2-->

##### Langkah membuat  Nona manis ubi ungu:

1. Siapkan ubi ungu, haluskan.
1. Campur semua bahan adonan ungu.
1. Jerang adonan putih hingga mengental &amp; meletup-letup.
1. Isi cetakan dengan adonan ungu, diakhiri dengan adonan putih. Kukus hingga matang.
1. Setelah matang biarkan dingin, lalu keluarkan kue dari cetakan.
1. Kue nona manies siap dibagikan ke tetangga.




Demikianlah cara membuat nona manis ubi ungu yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
