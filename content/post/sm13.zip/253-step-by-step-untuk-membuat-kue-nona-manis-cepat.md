---
description: "Step-by-Step untuk membuat Kue Nona Manis Cepat"
title: "Step-by-Step untuk membuat Kue Nona Manis Cepat"
slug: 253-step-by-step-untuk-membuat-kue-nona-manis-cepat
date: 2020-11-09T00:59:20.901Z
image: https://img-global.cpcdn.com/recipes/e6ad2f95c0967151/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e6ad2f95c0967151/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e6ad2f95c0967151/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Helena Simon
ratingvalue: 4.4
reviewcount: 46599
recipeingredient:
- " BAHAN 1 ADONAN PUTIH "
- "6 sdm tepung terigu"
- "1/2 sdt garam"
- "500 ml santan kental"
- " BAHAN 2 "
- "250 ml santan"
- "40 gram gula pasir"
- "30 gram maizena"
- "1 sdt pasta pandan"
- "Sejumput garam"
- " BAHAN 3 "
- "250 ml santan"
- "1 butir telur"
- "80 gram gula pasir"
- "140 gram tepung terigu"
recipeinstructions:
- "BAHAN 1 (ADONAN PUTIH) : Campur tepung terigu dengan garam, masukkan santan kental. Aduk rata."
- "Masak adonan di atas api kecil sambil terus diaduk sampai beruap dan meletup - letup. Matikan api, aduk terus adonan hingga kental, halus dan tidak bergerindil. Angkat, sisihkan."
- "Jika sudah dingin, masukkan adonan putih ke dalam piping bag. Bisa juga menggunakan botol yang ujung corong tutupnya berlubang."
- "BAHAN 2 : Masak semua bahan dengan api kecil, aduk terus sampai menjadi adonan yang kental. Angkat, sisihkan."
- "BAHAN 3 : Di wadah lain, masukkan terigu, gula pasir dan telur. Aduk rata menggunakan whisk."
- "Masukkan santan sedikit demi sedikit sambil terus diaduk hingga adonan tercampur rata dan gula mencair."
- "Masukkan adonan 2 yang telah dingin sedikit demi sedikit. Aduk rata sampai menjadi adonan yang halus dan tidak bergerindil. Saring bila perlu."
- "Panaskan kukusan dengan air secukupnya, alasi penutupnya dengan serbet atau kain bersih agar air uap tidak menetes keadonan saat pengukusan."
- "Tuang 3/4 adonan hijau ke dalam cetakan yang sebelumnya telah dioles minyak tipis - tipis."
- "Lalu semprot adonan putih di tengahnya sampai agak penuh. Benamkan sedikit ujung piping bag / tutup botolnya. Lakukan sampai adonan habis."
- "Kukus selama 10 menit dengan api sedang."
- "Angkat dan dinginkan. Setelah dingin baru dikeluarkan dari loyangnya."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 256 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Dessert

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/e6ad2f95c0967151/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga enak. Karasteristik kuliner Nusantara kue nona manis yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kedekatan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Kue Nona Manis untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang dapat anda coba salah satunya kue nona manis yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 12 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis:

1. Harus ada  BAHAN 1 (ADONAN PUTIH) :
1. Siapkan 6 sdm tepung terigu
1. Dibutuhkan 1/2 sdt garam
1. Harus ada 500 ml santan kental
1. Harus ada  BAHAN 2 :
1. Harap siapkan 250 ml santan
1. Harus ada 40 gram gula pasir
1. Siapkan 30 gram maizena
1. Dibutuhkan 1 sdt pasta pandan
1. Dibutuhkan Sejumput garam
1. Siapkan  BAHAN 3 :
1. Siapkan 250 ml santan
1. Jangan lupa 1 butir telur
1. Tambah 80 gram gula pasir
1. Harap siapkan 140 gram tepung terigu




<!--inarticleads2-->

##### Instruksi membuat  Kue Nona Manis:

1. BAHAN 1 (ADONAN PUTIH) : Campur tepung terigu dengan garam, masukkan santan kental. Aduk rata.
1. Masak adonan di atas api kecil sambil terus diaduk sampai beruap dan meletup - letup. Matikan api, aduk terus adonan hingga kental, halus dan tidak bergerindil. Angkat, sisihkan.
1. Jika sudah dingin, masukkan adonan putih ke dalam piping bag. Bisa juga menggunakan botol yang ujung corong tutupnya berlubang.
1. BAHAN 2 : Masak semua bahan dengan api kecil, aduk terus sampai menjadi adonan yang kental. Angkat, sisihkan.
1. BAHAN 3 : Di wadah lain, masukkan terigu, gula pasir dan telur. Aduk rata menggunakan whisk.
1. Masukkan santan sedikit demi sedikit sambil terus diaduk hingga adonan tercampur rata dan gula mencair.
1. Masukkan adonan 2 yang telah dingin sedikit demi sedikit. Aduk rata sampai menjadi adonan yang halus dan tidak bergerindil. Saring bila perlu.
1. Panaskan kukusan dengan air secukupnya, alasi penutupnya dengan serbet atau kain bersih agar air uap tidak menetes keadonan saat pengukusan.
1. Tuang 3/4 adonan hijau ke dalam cetakan yang sebelumnya telah dioles minyak tipis - tipis.
1. Lalu semprot adonan putih di tengahnya sampai agak penuh. Benamkan sedikit ujung piping bag / tutup botolnya. Lakukan sampai adonan habis.
1. Kukus selama 10 menit dengan api sedang.
1. Angkat dan dinginkan. Setelah dingin baru dikeluarkan dari loyangnya.




Demikianlah cara membuat kue nona manis yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
