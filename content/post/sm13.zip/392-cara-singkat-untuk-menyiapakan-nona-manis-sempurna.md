---
description: "Cara singkat untuk menyiapakan Nona Manis Sempurna"
title: "Cara singkat untuk menyiapakan Nona Manis Sempurna"
slug: 392-cara-singkat-untuk-menyiapakan-nona-manis-sempurna
date: 2021-02-21T05:11:10.361Z
image: https://img-global.cpcdn.com/recipes/5f98979b99019e0c/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5f98979b99019e0c/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5f98979b99019e0c/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Pauline Ballard
ratingvalue: 5
reviewcount: 30807
recipeingredient:
- " Bahan 1  90 ml santan"
- "1 btr telur"
- "40 gr gula pasir"
- "65 gr terigu"
- " Bahan 2  110 gr santan"
- "20 gr gula pasir"
- "15 gr maizena"
- "1/2 sdt garam"
- "1 sdm pasta pandan 2 tetes warna hijau"
- " Bahan 3  125 ml santan"
- "2 sdm terigu"
- "secukupnya Garam"
recipeinstructions:
- "Bahan 1 ➡️ mixer gula dan telur hingga kental, masukkan santan, terigu bergantian secara bertahap mixer speed rendah sampai rata sisihkan"
- "Bahan 2 : rebus semua bahan dengan api sedang hingga mengental sambil diaduk rata dan beruap. Matikan setelah hangat masukan secara bertahap kedalam adonan 1 mix rendah agar tercampur rata, sisihkan."
- "Bahan 3 : rebus semua bahan dengan api sedang dan diaduk2 terus hingga beruap dan mengental. Matikan"
- "Masukkan dalam piping bag/ botol kecap plastik."
- "Panaskan kukusan,,"
- "Siapkan cetakan oles tipis mentega/ minyak tuang adonan 1 yg udh dicampur adonan 2 setengahnya"
- "Kemudian semprotkan adonan bahan 3 di tengah"
- "Kukus selama 15 mnt, jangan lupa tutup di lapisi serbet.."
- "Angkat, beri hiasan daun pandan sajikan"
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 218 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT59M"
recipeyield: "2"
recipecategory: Dessert

---


![Nona Manis](https://img-global.cpcdn.com/recipes/5f98979b99019e0c/680x482cq70/nona-manis-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti nona manis yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan keistimewahan yang merupakan keragaman Kita

Kehangatan keluarga bisa ditemukan dengan cara simple. Diantaranya adalah membuat makanan Nona Manis untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang bisa anda buat salah satunya nona manis yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona Manis yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 12 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona Manis:

1. Dibutuhkan  Bahan 1 : 90 ml santan
1. Tambah 1 btr telur
1. Siapkan 40 gr gula pasir
1. Siapkan 65 gr terigu
1. Harus ada  Bahan 2 : 110 gr santan
1. Siapkan 20 gr gula pasir
1. Tambah 15 gr maizena
1. Harap siapkan 1/2 sdt garam
1. Dibutuhkan 1 sdm pasta pandan, 2 tetes warna hijau
1. Harap siapkan  Bahan 3 : 125 ml santan
1. Diperlukan 2 sdm terigu
1. Siapkan secukupnya Garam




<!--inarticleads2-->

##### Cara membuat  Nona Manis:

1. Bahan 1 ➡️ mixer gula dan telur hingga kental, masukkan santan, terigu bergantian secara bertahap mixer speed rendah sampai rata sisihkan
1. Bahan 2 : rebus semua bahan dengan api sedang hingga mengental sambil diaduk rata dan beruap. Matikan setelah hangat masukan secara bertahap kedalam adonan 1 mix rendah agar tercampur rata, sisihkan.
1. Bahan 3 : rebus semua bahan dengan api sedang dan diaduk2 terus hingga beruap dan mengental. Matikan
1. Masukkan dalam piping bag/ botol kecap plastik.
1. Panaskan kukusan,,
1. Siapkan cetakan oles tipis mentega/ minyak tuang adonan 1 yg udh dicampur adonan 2 setengahnya
1. Kemudian semprotkan adonan bahan 3 di tengah
1. Kukus selama 15 mnt, jangan lupa tutup di lapisi serbet..
1. Angkat, beri hiasan daun pandan sajikan




Demikianlah cara membuat nona manis yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat simple dan teruji, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
