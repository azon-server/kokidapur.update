---
description: "Resep : Nona Manis Pandan Suji Teruji"
title: "Resep : Nona Manis Pandan Suji Teruji"
slug: 374-resep-nona-manis-pandan-suji-teruji
date: 2020-12-09T18:06:22.540Z
image: https://img-global.cpcdn.com/recipes/fa05a061843726b1/680x482cq70/nona-manis-pandan-suji-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fa05a061843726b1/680x482cq70/nona-manis-pandan-suji-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fa05a061843726b1/680x482cq70/nona-manis-pandan-suji-foto-resep-utama.jpg
author: Cordelia Cain
ratingvalue: 4.1
reviewcount: 44542
recipeingredient:
- " Bahan Adonan Hijau A blender"
- "250 gr tepung terigu protein sedang"
- "260 gr gula pasir"
- "300 ml santan cair"
- "2 butir telur"
- "80 gr susu kental manis"
- " Bahan Adonan Hijau B masak di teflon"
- "75 gr tepung maizena"
- "300 ml santan kental"
- "125 ml jus pandan suji 10 lbr suji 5 lbr pandan"
- "1/2 sdt garam"
- " Bahan Fla Putih"
- "2 sdm tepung terigu"
- "2 sdm gula pasir"
- "1/2 sdt garam"
- "300 ml santan kental"
recipeinstructions:
- "Blender semua bahan adonan hijau A sampai tercampur rata"
- "Di atas teflon, campur bahan adonan hijau B hingga rata lalu masak di api kecil hingga mengental seperti bubur sumsum. Kemudian tunggu hingga dingin"
- "Mixer adonan hijau A dan B sampai tercampur rataa hingga menjadi adonan (adonan hijau sudah jadi)"
- "Di wadah lain masukan semua bahan fla putih hingga rata, kemudian masak di api sedang sampai kental sedikit aja yaaa jangan sampe terlalu kental, (adonan fla putih sudah jadi)"
- "Ambil cetakan lalu olesi dengan minyak kemudian masukan 3/4 adonan hijau, setelah itu ditengah2nya masukan fla putih. Kemudian kukus kue selama 10 menit. Selesaiii"
categories:
- Recipe
tags:
- nona
- manis
- pandan

katakunci: nona manis pandan 
nutrition: 131 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dinner

---


![Nona Manis Pandan Suji](https://img-global.cpcdn.com/recipes/fa05a061843726b1/680x482cq70/nona-manis-pandan-suji-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau enak. Ciri makanan Nusantara nona manis pandan suji yang kaya dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan rumah tangga dapat diperoleh dengan cara simple. Diantaranya adalah membuat makanan Nona Manis Pandan Suji untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda buat salah satunya nona manis pandan suji yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep nona manis pandan suji tanpa harus bersusah payah.
Berikut ini resep Nona Manis Pandan Suji yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona Manis Pandan Suji:

1. Diperlukan  Bahan Adonan Hijau A (blender)
1. Siapkan 250 gr tepung terigu protein sedang
1. Dibutuhkan 260 gr gula pasir
1. Harus ada 300 ml santan cair
1. Siapkan 2 butir telur
1. Dibutuhkan 80 gr susu kental manis
1. Siapkan  Bahan Adonan Hijau B (masak di teflon)
1. Harap siapkan 75 gr tepung maizena
1. Tambah 300 ml santan kental
1. Diperlukan 125 ml jus pandan suji (10 lbr suji, 5 lbr pandan)
1. Jangan lupa 1/2 sdt garam
1. Diperlukan  Bahan Fla Putih
1. Siapkan 2 sdm tepung terigu
1. Tambah 2 sdm gula pasir
1. Dibutuhkan 1/2 sdt garam
1. Harap siapkan 300 ml santan kental




<!--inarticleads2-->

##### Cara membuat  Nona Manis Pandan Suji:

1. Blender semua bahan adonan hijau A sampai tercampur rata
1. Di atas teflon, campur bahan adonan hijau B hingga rata lalu masak di api kecil hingga mengental seperti bubur sumsum. Kemudian tunggu hingga dingin
1. Mixer adonan hijau A dan B sampai tercampur rataa hingga menjadi adonan (adonan hijau sudah jadi)
1. Di wadah lain masukan semua bahan fla putih hingga rata, kemudian masak di api sedang sampai kental sedikit aja yaaa jangan sampe terlalu kental, (adonan fla putih sudah jadi)
1. Ambil cetakan lalu olesi dengan minyak kemudian masukan 3/4 adonan hijau, setelah itu ditengah2nya masukan fla putih. Kemudian kukus kue selama 10 menit. Selesaiii




Demikianlah cara membuat nona manis pandan suji yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
