---
description: "Resep : Kue nona manis Terbukti"
title: "Resep : Kue nona manis Terbukti"
slug: 289-resep-kue-nona-manis-terbukti
date: 2021-02-05T23:57:47.958Z
image: https://img-global.cpcdn.com/recipes/e7de356b6fc542a5/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e7de356b6fc542a5/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e7de356b6fc542a5/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Alvin Jimenez
ratingvalue: 4.2
reviewcount: 27068
recipeingredient:
- " Bahan pertama "
- "1 btr telur"
- "4 sdm gula pasir 75gr"
- "250 ml santan"
- "8 sdm tepung terigu 140gr"
- "1/3 sdt garam"
- "1 sdt vanilla"
- " Bahan kedua "
- "2,5 sdm tepung maizena 35gr"
- "2 sdm gula pasir 35gr"
- "1/3 sdt garam"
- "1 sdt pasta pandan"
- " Bahan ketiga "
- "6 sdm tepung terigu 100gr"
- "1/3 sdt garam"
- "500 ml santan"
- "1 sdt vanilla"
recipeinstructions:
- "Kocok telur bersama gula sampai gula larut lalu masukkan santan, garam Dan vanilla. Aduk2 lalu masukkan tepung terigu, aduk sampai tercampur lalu saring"
- "Untuk bahan kedua, campurkan tepung bersama gula Dan garam lalu masukkan santan. Aduk sampai tercampur lalu tambahkan pasta pandan, aduk lg hingga tercampur rata"
- "Campur Bahan pertama Dan kedua, lalu aduk sampai tercampur rata"
- "Untuk Bahan ketiga, campurkan tepung bersama gula Dan vanilli Serta santan lalu saring Dan masak sampai agak mengental. Masukkan kedalam kantong plastik"
- "Tuang adonan hijau kedalam cetakan lalu tuang adonan putih ditengahnya. Kukus selama 15 menit"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 249 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Dessert

---


![Kue nona manis](https://img-global.cpcdn.com/recipes/e7de356b6fc542a5/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau gurih. Karasteristik makanan Indonesia kue nona manis yang penuh dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan rumah tangga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Kue nona manis untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang bisa anda buat salah satunya kue nona manis yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue nona manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue nona manis:

1. Jangan lupa  Bahan pertama :
1. Siapkan 1 btr telur
1. Harap siapkan 4 sdm gula pasir (75gr)
1. Harap siapkan 250 ml santan
1. Harus ada 8 sdm tepung terigu (140gr)
1. Tambah 1/3 sdt garam
1. Harap siapkan 1 sdt vanilla
1. Siapkan  Bahan kedua :
1. Dibutuhkan 2,5 sdm tepung maizena (35gr)
1. Harus ada 2 sdm gula pasir (35gr)
1. Dibutuhkan 1/3 sdt garam
1. Jangan lupa 1 sdt pasta pandan
1. Diperlukan  Bahan ketiga :
1. Harus ada 6 sdm tepung terigu (100gr)
1. Tambah 1/3 sdt garam
1. Harus ada 500 ml santan
1. Jangan lupa 1 sdt vanilla




<!--inarticleads2-->

##### Bagaimana membuat  Kue nona manis:

1. Kocok telur bersama gula sampai gula larut lalu masukkan santan, garam Dan vanilla. Aduk2 lalu masukkan tepung terigu, aduk sampai tercampur lalu saring
1. Untuk bahan kedua, campurkan tepung bersama gula Dan garam lalu masukkan santan. Aduk sampai tercampur lalu tambahkan pasta pandan, aduk lg hingga tercampur rata
1. Campur Bahan pertama Dan kedua, lalu aduk sampai tercampur rata
1. Untuk Bahan ketiga, campurkan tepung bersama gula Dan vanilli Serta santan lalu saring Dan masak sampai agak mengental. Masukkan kedalam kantong plastik
1. Tuang adonan hijau kedalam cetakan lalu tuang adonan putih ditengahnya. Kukus selama 15 menit




Demikianlah cara membuat kue nona manis yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat simple dan cepat, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
