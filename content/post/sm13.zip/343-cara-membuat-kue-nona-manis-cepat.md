---
description: "Cara membuat Kue nona manis Cepat"
title: "Cara membuat Kue nona manis Cepat"
slug: 343-cara-membuat-kue-nona-manis-cepat
date: 2020-11-12T21:15:28.958Z
image: https://img-global.cpcdn.com/recipes/b22cdb383cf4c1b5/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b22cdb383cf4c1b5/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b22cdb383cf4c1b5/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Leonard Gonzales
ratingvalue: 4.5
reviewcount: 33854
recipeingredient:
- " Bahan 1 "
- "250 ml santan kental"
- "1 btr telur"
- "80 gr gula"
- "140 gr tepung"
- " Bahan 2 "
- "250 ml santan kental"
- "40 gr gula"
- "30 gr maizena"
- " Pasta pandan secukup nya"
- " Garam"
- " Bahan 3 "
- "500 ml santal kental"
- "6 sdm tepung"
- "2 sdm gula"
- " Garam secukup nya"
recipeinstructions:
- "Campur semua bahan 3 dan masak sampai mengental,sisihkan"
- "Bahan 2,larutkan maizena dg 3 sdm air sisihkan"
- "Masak santan,gula,garam dan pasta pandan,setelah mendidih masukkan larutan maizena aduk2 hingga meletup2,dinginkan"
- "Bahan 1,kocok telur dan gula dg ballon whisk hingga gula larut"
- "Masukkan tepung dan santan secara bergantian aduk sampai rata"
- "Lalu masukkan bahan 2 yg sdh di dinginkan,aduk hingga adonan menyatu"
- "Oles cetakan lalu tuang adonan hijau dan beri 1 sdt bahan 3 di tengah nya lalu kukus hingga matang"
- "Keluarkan kue dari cetakan dan siap di nikmati,,selamat mencoba☺☺☺"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 105 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Dessert

---


![Kue nona manis](https://img-global.cpcdn.com/recipes/b22cdb383cf4c1b5/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan gurih. Ciri kuliner Nusantara kue nona manis yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah memasak Kue nona manis untuk orang di rumah. Momen makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang bisa anda contoh salah satunya kue nona manis yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue nona manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue nona manis:

1. Diperlukan  Bahan 1 :
1. Diperlukan 250 ml santan kental
1. Dibutuhkan 1 btr telur
1. Jangan lupa 80 gr gula
1. Tambah 140 gr tepung
1. Harus ada  Bahan 2 :
1. Jangan lupa 250 ml santan kental
1. Dibutuhkan 40 gr gula
1. Harus ada 30 gr maizena
1. Tambah  Pasta pandan secukup nya
1. Diperlukan  Garam
1. Tambah  Bahan 3 :
1. Harus ada 500 ml santal kental
1. Dibutuhkan 6 sdm tepung
1. Harus ada 2 sdm gula
1. Harus ada  Garam secukup nya




<!--inarticleads2-->

##### Langkah membuat  Kue nona manis:

1. Campur semua bahan 3 dan masak sampai mengental,sisihkan
1. Bahan 2,larutkan maizena dg 3 sdm air sisihkan
1. Masak santan,gula,garam dan pasta pandan,setelah mendidih masukkan larutan maizena aduk2 hingga meletup2,dinginkan
1. Bahan 1,kocok telur dan gula dg ballon whisk hingga gula larut
1. Masukkan tepung dan santan secara bergantian aduk sampai rata
1. Lalu masukkan bahan 2 yg sdh di dinginkan,aduk hingga adonan menyatu
1. Oles cetakan lalu tuang adonan hijau dan beri 1 sdt bahan 3 di tengah nya lalu kukus hingga matang
1. Keluarkan kue dari cetakan dan siap di nikmati,,selamat mencoba☺☺☺




Demikianlah cara membuat kue nona manis yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
