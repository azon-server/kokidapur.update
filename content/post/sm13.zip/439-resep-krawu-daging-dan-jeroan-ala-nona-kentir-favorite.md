---
description: "Resep : Krawu Daging dan Jeroan ala Nona Kentir Favorite"
title: "Resep : Krawu Daging dan Jeroan ala Nona Kentir Favorite"
slug: 439-resep-krawu-daging-dan-jeroan-ala-nona-kentir-favorite
date: 2021-01-29T17:40:50.878Z
image: https://img-global.cpcdn.com/recipes/0db2ae37446c068c/680x482cq70/krawu-daging-dan-jeroan-ala-nona-kentir-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0db2ae37446c068c/680x482cq70/krawu-daging-dan-jeroan-ala-nona-kentir-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0db2ae37446c068c/680x482cq70/krawu-daging-dan-jeroan-ala-nona-kentir-foto-resep-utama.jpg
author: Seth Perkins
ratingvalue: 4.5
reviewcount: 36547
recipeingredient:
- " Bumbu halus"
- "4 bh cabe merah"
- "1 ons bawang merah"
- "60 gr bawang putih"
- "1 sdm ketumbar"
- "1,5 sdt jinten"
- "1 ruas jahe"
- "1,5 kg Jeroan sapi usus paru babat"
- "1/2 kg daging sapi"
- "Secuil asem"
- "4 tangkai kayu mesoyi"
- "1 tangkai kayu manis"
- "2 sdm  Secukupnya garam"
- "1 sdm  Secukupnya gula pasir"
- " Bahan sambel krawu"
- "25 bh cabe rawit"
- "5 butir kemiri"
- "5 butir bawang merah"
- "3 butir bawang putih"
- "1/2 blok terasi"
- "Secukupnya garam"
- "Secukupnya gula pasir"
recipeinstructions:
- "Cuci bersih jeroan (babat, usus, paru) rebus dalam panci hingga air mendidih. Buang airnya. Cuci dan rebus lagi sampe 3 kali (utk menghilangkan bau basin dan agar jeroan cepat empuk). Setelah itu, cuci bersih daging sapi dan ikutkan dalam rebusan yg ke - 4. Kalau sudah mendidih. Matikan kompor. Saring daging dan jeroan. Taruh di tampah hingga agak dingin."
- "Potong agak besar tidak beraturan: daging, paru, babat. Khusus usus yg sudah dipotong, agar dikunci dengan lidi agar isi usus tidak meluber sewaktu dimasak. Selesai dipotong, masukkan kedalam panci yg berisi air rebusan tadi."
- "Blender bumbu halus: cabe merah, bawang merah,bawang putih, ketumbar,jinten, jahe, asem. Masukkan bumbu halus ke panci berisi daging dan jeroan yg sudah dipotong. Tamvahkan kayu medoyi, kayu manis, garam dan gula. Masak hingga air mendidih dan sat. Jangan lupa cek rasa sebelum Krawu di goreng."
- "Panaskan minyak goreng agak banyak diwajan besar. Setelah benar-benar panas masukkan adonan krawu. Aduk sampai mateng. Hmm sedapnya nih 😋"
- "Sebenernya krawu tadi udh nikmat disajikan dg nasi hangat. Tp nikmat lg kita buat sambelnya: kupas, cuci bersih bawang merah, bawang putih lalu goreng sapai kering dg kemiri, terasi, laos. Uleg. tambahkan dg gula dan garam."
- "Tips: lebih nikmatan lagi klo kita bikin foya serundeng merah dan kuning. Tp berhubung drumah ga ada kelapa. Jd cukup krawu dan sambelnya sj udh mantep ga kerasa ngabisin nasi se-bakul. Disantap orang serumah 8 org. Dan bisa dimakan sampe besoknya. Oiya. Jangan lupa stiap mau dmakan, hrs dipanaskan lagi. Krn mengandung gaji, jadi ya agak mengendap gitu. Selamat mencoba 😊"
categories:
- Recipe
tags:
- krawu
- daging
- dan

katakunci: krawu daging dan 
nutrition: 209 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Lunch

---


![Krawu Daging dan Jeroan ala Nona Kentir](https://img-global.cpcdn.com/recipes/0db2ae37446c068c/680x482cq70/krawu-daging-dan-jeroan-ala-nona-kentir-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau empuk. Ciri khas kuliner Nusantara krawu daging dan jeroan ala nona kentir yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.


Keharmonisan keluarga dapat didapat dengan cara mudah. Salah satunya adalah memasak Krawu Daging dan Jeroan ala Nona Kentir untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang dapat anda praktekkan salah satunya krawu daging dan jeroan ala nona kentir yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan cepat menemukan resep krawu daging dan jeroan ala nona kentir tanpa harus bersusah payah.
Seperti resep Krawu Daging dan Jeroan ala Nona Kentir yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Krawu Daging dan Jeroan ala Nona Kentir:

1. Harap siapkan  Bumbu halus**
1. Harap siapkan 4 bh cabe merah
1. Harus ada 1 ons bawang merah
1. Dibutuhkan 60 gr bawang putih
1. Dibutuhkan 1 sdm ketumbar
1. Diperlukan 1,5 sdt jinten
1. Dibutuhkan 1 ruas jahe
1. Harus ada 1,5 kg Jeroan sapi (usus, paru, babat)
1. Jangan lupa 1/2 kg daging sapi
1. Dibutuhkan Secuil asem
1. Dibutuhkan 4 tangkai kayu mesoyi
1. Dibutuhkan 1 tangkai kayu manis
1. Jangan lupa 2 sdm / Secukupnya garam
1. Harus ada 1 sdm / Secukupnya gula pasir
1. Diperlukan  Bahan sambel krawu**
1. Harus ada 25 bh cabe rawit
1. Diperlukan 5 butir kemiri
1. Tambah 5 butir bawang merah
1. Harus ada 3 butir bawang putih
1. Tambah 1/2 blok terasi
1. Dibutuhkan Secukupnya garam
1. Jangan lupa Secukupnya gula pasir




<!--inarticleads2-->

##### Bagaimana membuat  Krawu Daging dan Jeroan ala Nona Kentir:

1. Cuci bersih jeroan (babat, usus, paru) rebus dalam panci hingga air mendidih. Buang airnya. Cuci dan rebus lagi sampe 3 kali (utk menghilangkan bau basin dan agar jeroan cepat empuk). Setelah itu, cuci bersih daging sapi dan ikutkan dalam rebusan yg ke - 4. Kalau sudah mendidih. Matikan kompor. Saring daging dan jeroan. Taruh di tampah hingga agak dingin.
1. Potong agak besar tidak beraturan: daging, paru, babat. Khusus usus yg sudah dipotong, agar dikunci dengan lidi agar isi usus tidak meluber sewaktu dimasak. Selesai dipotong, masukkan kedalam panci yg berisi air rebusan tadi.
1. Blender bumbu halus: cabe merah, bawang merah,bawang putih, ketumbar,jinten, jahe, asem. Masukkan bumbu halus ke panci berisi daging dan jeroan yg sudah dipotong. Tamvahkan kayu medoyi, kayu manis, garam dan gula. Masak hingga air mendidih dan sat. Jangan lupa cek rasa sebelum Krawu di goreng.
1. Panaskan minyak goreng agak banyak diwajan besar. Setelah benar-benar panas masukkan adonan krawu. Aduk sampai mateng. Hmm sedapnya nih 😋
1. Sebenernya krawu tadi udh nikmat disajikan dg nasi hangat. Tp nikmat lg kita buat sambelnya: kupas, cuci bersih bawang merah, bawang putih lalu goreng sapai kering dg kemiri, terasi, laos. Uleg. tambahkan dg gula dan garam.
1. Tips: lebih nikmatan lagi klo kita bikin foya serundeng merah dan kuning. Tp berhubung drumah ga ada kelapa. Jd cukup krawu dan sambelnya sj udh mantep ga kerasa ngabisin nasi se-bakul. Disantap orang serumah 8 org. Dan bisa dimakan sampe besoknya. Oiya. Jangan lupa stiap mau dmakan, hrs dipanaskan lagi. Krn mengandung gaji, jadi ya agak mengendap gitu. Selamat mencoba 😊




Demikianlah cara membuat krawu daging dan jeroan ala nona kentir yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan teruji, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
