---
description: "Resep : Nona manis / cantik manis Luar biasa"
title: "Resep : Nona manis / cantik manis Luar biasa"
slug: 257-resep-nona-manis-cantik-manis-luar-biasa
date: 2021-03-05T19:15:54.659Z
image: https://img-global.cpcdn.com/recipes/9eb72fc94dcf6283/680x482cq70/nona-manis-cantik-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9eb72fc94dcf6283/680x482cq70/nona-manis-cantik-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9eb72fc94dcf6283/680x482cq70/nona-manis-cantik-manis-foto-resep-utama.jpg
author: Jacob Cunningham
ratingvalue: 4.2
reviewcount: 1015
recipeingredient:
- " Bahan 1 adonan putih"
- "500 mil santan kental"
- "2 sdm gula pasir"
- "1 sdt garam"
- "40 gram tepung beras"
- " Bhan 2 adonan hijau"
- "250 mil santan"
- "2 sdm gula pasir"
- "30 gram tepung beras"
- " Pandan pasta"
- " Bhan 3 adonan telur"
- "1 bji telur"
- "140 gram gula pasir"
- "140 gram tepung terigu"
- "250 mil santan"
recipeinstructions:
- "Masak adonan 1 smpai meletup dan sisihkan"
- "Msak adonan 2 smpai meletup dan sisihkan"
- "Cmpur smua bhan 3 mix smpai gula larut"
- "Adonan bahan 2 campur ke adonan bahan 3 aduk rata dan saring spya teksturnya halus"
- "Masukkan adonan (2&amp;3) kecetakan yg sudah diolesi minyak tipis tipis semprotkan adonan 1 ketengah"
- "Lakukan smpai habis"
- "Kukus selma ±20 menit smpai adonan mtang"
- "Dinginkan dan keluarkan kue dr cetakan"
- "Siap dihidangkan dan slmat menikmati😊😊"
categories:
- Recipe
tags:
- nona
- manis
- 

katakunci: nona manis  
nutrition: 265 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Dessert

---


![Nona manis / cantik manis](https://img-global.cpcdn.com/recipes/9eb72fc94dcf6283/680x482cq70/nona-manis-cantik-manis-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang harus kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti nona manis / cantik manis yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan keistimewahan yang merupakan keragaman Kita

Keharmonisan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah memasak Nona manis / cantik manis untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda buat salah satunya nona manis / cantik manis yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep nona manis / cantik manis tanpa harus bersusah payah.
Seperti resep Nona manis / cantik manis yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 9 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona manis / cantik manis:

1. Harap siapkan  👉Bahan 1 adonan putih
1. Diperlukan 500 mil santan kental
1. Siapkan 2 sdm gula pasir
1. Tambah 1 sdt garam
1. Dibutuhkan 40 gram tepung beras
1. Jangan lupa  👉Bhan 2 adonan hijau
1. Harus ada 250 mil santan
1. Diperlukan 2 sdm gula pasir
1. Harap siapkan 30 gram tepung beras
1. Siapkan  Pandan pasta
1. Diperlukan  👉Bhan 3 adonan telur
1. Diperlukan 1 bji telur
1. Dibutuhkan 140 gram gula pasir
1. Siapkan 140 gram tepung terigu
1. Jangan lupa 250 mil santan




<!--inarticleads2-->

##### Cara membuat  Nona manis / cantik manis:

1. Masak adonan 1 smpai meletup dan sisihkan
1. Msak adonan 2 smpai meletup dan sisihkan
1. Cmpur smua bhan 3 mix smpai gula larut
1. Adonan bahan 2 campur ke adonan bahan 3 aduk rata dan saring spya teksturnya halus
1. Masukkan adonan (2&amp;3) kecetakan yg sudah diolesi minyak tipis tipis semprotkan adonan 1 ketengah
1. Lakukan smpai habis
1. Kukus selma ±20 menit smpai adonan mtang
1. Dinginkan dan keluarkan kue dr cetakan
1. Siap dihidangkan dan slmat menikmati😊😊




Demikianlah cara membuat nona manis / cantik manis yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
