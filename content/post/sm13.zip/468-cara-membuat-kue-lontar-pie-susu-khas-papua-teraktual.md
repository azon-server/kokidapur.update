---
description: "Cara membuat Kue Lontar / Pie Susu khas Papua teraktual"
title: "Cara membuat Kue Lontar / Pie Susu khas Papua teraktual"
slug: 468-cara-membuat-kue-lontar-pie-susu-khas-papua-teraktual
date: 2020-12-22T21:53:32.369Z
image: https://img-global.cpcdn.com/recipes/18f00090651002fd/680x482cq70/kue-lontar-pie-susu-khas-papua-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/18f00090651002fd/680x482cq70/kue-lontar-pie-susu-khas-papua-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/18f00090651002fd/680x482cq70/kue-lontar-pie-susu-khas-papua-foto-resep-utama.jpg
author: Christina Flowers
ratingvalue: 4.4
reviewcount: 16023
recipeingredient:
- " Bahan kulit"
- " Ada di kumpulan resep saya dengan nama KULIT PIE"
- " Bahan isi"
- "5 butir Telur Utuh"
- "2 butir Kuning Telur"
- "1 kaleng Susu Kental Manis biasa oma saya pakai merk cap Nona krn di Medan tdk ada saya pakai merk Carnation"
- "1 kaleng air putih saya pakai kaleng bekas susu Kental Manis"
- "1 sdt Vanilla"
- "1 sdt Rum"
recipeinstructions:
- "Buat kulit Pie, bisa dilihat cara pembuatannya di kumpulan resep saya, dengan judul KULIT PIE."
- "Setelah kulit pie nya jadi, cetak di loyang, tusuk2 dengan menggunakan garpu. Dan simpan di kulkas."
- "Buat isi dengan mencampur semua bahan. Dan aduk sampai tercampur rata. Bisa tambahkan sedikit pewarna kuning, agar warna adonan tdk terlalu pucat. Tp jika tidak mau menggunakan pewarna jg tidak apa2. Kemudian saring adonan menggunakan saringan agar tidak ada telur yg menggumpal."
- "Keluarkan adonan pie yg sudah disimpan di kulkas, dan tuangkan adonan isi. Panggang di oven dengan suhu 120 derajat selama 1,5 jam. Oven saya min 160 derajat, jadi saya panggang selama 1 jam."
- "Jika oven kalian bs menggunakan suhu 120 derajat lebih bagus lg. Krn nanti permukaan kue akan lebih mulus. Jadi sesuaikan dgn kemampuan oven masing2 yahh.."
categories:
- Recipe
tags:
- kue
- lontar
- 

katakunci: kue lontar  
nutrition: 135 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Lunch

---


![Kue Lontar / Pie Susu khas Papua](https://img-global.cpcdn.com/recipes/18f00090651002fd/680x482cq70/kue-lontar-pie-susu-khas-papua-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau enak. Ciri khas masakan Nusantara kue lontar / pie susu khas papua yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Kue Lontar / Pie Susu khas Papua untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang bisa anda contoh salah satunya kue lontar / pie susu khas papua yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep kue lontar / pie susu khas papua tanpa harus bersusah payah.
Berikut ini resep Kue Lontar / Pie Susu khas Papua yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 9 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Lontar / Pie Susu khas Papua:

1. Harap siapkan  Bahan kulit
1. Harus ada  Ada di kumpulan resep saya dengan nama KULIT PIE
1. Diperlukan  Bahan isi
1. Diperlukan 5 butir Telur Utuh
1. Harap siapkan 2 butir Kuning Telur
1. Harap siapkan 1 kaleng Susu Kental Manis (biasa oma saya pakai merk cap Nona, krn di Medan tdk ada, saya pakai merk Carnation)
1. Jangan lupa 1 kaleng air putih (saya pakai kaleng bekas susu Kental Manis)
1. Siapkan 1 sdt Vanilla
1. Tambah 1 sdt Rum




<!--inarticleads2-->

##### Bagaimana membuat  Kue Lontar / Pie Susu khas Papua:

1. Buat kulit Pie, bisa dilihat cara pembuatannya di kumpulan resep saya, dengan judul KULIT PIE.
1. Setelah kulit pie nya jadi, cetak di loyang, tusuk2 dengan menggunakan garpu. Dan simpan di kulkas.
1. Buat isi dengan mencampur semua bahan. Dan aduk sampai tercampur rata. Bisa tambahkan sedikit pewarna kuning, agar warna adonan tdk terlalu pucat. Tp jika tidak mau menggunakan pewarna jg tidak apa2. Kemudian saring adonan menggunakan saringan agar tidak ada telur yg menggumpal.
1. Keluarkan adonan pie yg sudah disimpan di kulkas, dan tuangkan adonan isi. Panggang di oven dengan suhu 120 derajat selama 1,5 jam. Oven saya min 160 derajat, jadi saya panggang selama 1 jam.
1. Jika oven kalian bs menggunakan suhu 120 derajat lebih bagus lg. Krn nanti permukaan kue akan lebih mulus. Jadi sesuaikan dgn kemampuan oven masing2 yahh..




Demikianlah cara membuat kue lontar / pie susu khas papua yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan teruji, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
