---
description: "Step-by-Step membuat Angsle Homemade"
title: "Step-by-Step membuat Angsle Homemade"
slug: 497-step-by-step-membuat-angsle-homemade
date: 2020-10-28T02:37:53.308Z
image: https://img-global.cpcdn.com/recipes/6bc58bc246b773d9/680x482cq70/angsle-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6bc58bc246b773d9/680x482cq70/angsle-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6bc58bc246b773d9/680x482cq70/angsle-foto-resep-utama.jpg
author: Norman Gonzales
ratingvalue: 4.7
reviewcount: 17351
recipeingredient:
- " Ketan "
- "330 gram ketan putih"
- "1/2 sachet Kara kecil"
- "Sejumput garam"
- "1 lembar daun pandan"
- " Air panas"
- " Kacang ijo "
- "100 gram kacang ijo"
- "2 sdm gula pasir"
- "Sejumput garam"
- " Pertulo "
- "1,5 keping bihun jagung"
- "1 sdt garam"
- "2 sdm tepung tapioka"
- "75 ml air tuk melarutkan"
- "3 tetes pewarna merah rose"
- " Air panas tuk merendam"
- "3 lembar Roti Tawar me Gandum"
- " Kacang goreng tuk taburan me kacang cincang sangrai"
recipeinstructions:
- "Ketan : cuci bersih beras ketan, tuang air panas, Santan, garam dan daun pandan dalam panci magic com, colokin listrik dan tekan cook"
- "Kacang ijo : Rendam kacang ijo selama kurleb 30 menit, kemudian masak, setelah agak empuk masukan gula pasir dan garam. Masak sampe air susut, tiriskan. Roti tawar : potong kotak kecil"
- "Petulo bihun : Rendam bihun dengan air panas hingga empuk. Larutkan maizena, air dan pewarna, kemudian aduk rata dengan bihun. Panaskan dandang, olesin cetakan dengan minyak goreng, tuang adonan kukus hingga matang"
- "Kuah : Rebus air bersama jahe dan pandan hingga mendidih, masukkan gula pasir, garam dan santan. Masak lagi sambil di aduk hingga mendidih"
- "Siapkan mangkuk, tata bahan isian siram kuah dan tabur kacang tanah goreng."
categories:
- Recipe
tags:
- angsle

katakunci: angsle 
nutrition: 235 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT50M"
recipeyield: "3"
recipecategory: Dessert

---


![Angsle](https://img-global.cpcdn.com/recipes/6bc58bc246b773d9/680x482cq70/angsle-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau gurih. Ciri kuliner Nusantara angsle yang penuh dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Angsle untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang dapat anda contoh salah satunya angsle yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep angsle tanpa harus bersusah payah.
Seperti resep Angsle yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Angsle:

1. Dibutuhkan  Ketan :
1. Dibutuhkan 330 gram ketan putih
1. Tambah 1/2 sachet Kara kecil
1. Dibutuhkan Sejumput garam
1. Jangan lupa 1 lembar daun pandan
1. Dibutuhkan  Air panas
1. Jangan lupa  Kacang ijo :
1. Siapkan 100 gram kacang ijo
1. Siapkan 2 sdm gula pasir
1. Jangan lupa Sejumput garam
1. Harap siapkan  Pertulo :
1. Dibutuhkan 1,5 keping bihun jagung
1. Dibutuhkan 1 sdt garam
1. Harus ada 2 sdm tepung tapioka
1. Siapkan 75 ml air tuk melarutkan
1. Harap siapkan 3 tetes pewarna merah rose
1. Siapkan  Air panas tuk merendam
1. Harus ada 3 lembar Roti Tawar (me Gandum)
1. Harus ada  Kacang goreng tuk taburan (me kacang cincang sangrai)




<!--inarticleads2-->

##### Bagaimana membuat  Angsle:

1. Ketan : cuci bersih beras ketan, tuang air panas, Santan, garam dan daun pandan dalam panci magic com, colokin listrik dan tekan cook
1. Kacang ijo : Rendam kacang ijo selama kurleb 30 menit, kemudian masak, setelah agak empuk masukan gula pasir dan garam. Masak sampe air susut, tiriskan. Roti tawar : potong kotak kecil
1. Petulo bihun : Rendam bihun dengan air panas hingga empuk. Larutkan maizena, air dan pewarna, kemudian aduk rata dengan bihun. Panaskan dandang, olesin cetakan dengan minyak goreng, tuang adonan kukus hingga matang
1. Kuah : Rebus air bersama jahe dan pandan hingga mendidih, masukkan gula pasir, garam dan santan. Masak lagi sambil di aduk hingga mendidih
1. Siapkan mangkuk, tata bahan isian siram kuah dan tabur kacang tanah goreng.




Demikianlah cara membuat angsle yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan teruji, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
