---
description: "Bagaimana menyiapakan Beef Basil ala Nona Angela Luar biasa"
title: "Bagaimana menyiapakan Beef Basil ala Nona Angela Luar biasa"
slug: 414-bagaimana-menyiapakan-beef-basil-ala-nona-angela-luar-biasa
date: 2021-03-10T18:03:35.132Z
image: https://img-global.cpcdn.com/recipes/4d39edc5cffc940c/680x482cq70/beef-basil-ala-nona-angela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4d39edc5cffc940c/680x482cq70/beef-basil-ala-nona-angela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4d39edc5cffc940c/680x482cq70/beef-basil-ala-nona-angela-foto-resep-utama.jpg
author: Russell Perez
ratingvalue: 4.3
reviewcount: 30781
recipeingredient:
- "1/2 daging sapi cincang"
- "1 butir jeruk nipis"
- "1 sdm kecap manis"
- "1 sdm kecap asin"
- "1 sdt kecap ikan"
- "1 sdt lada hitam"
- " Thai basil  daun kemangi sedikit aja"
- " Daun ketumbar sesuai selera kalo saya pake banyak biar lbh enak"
- "4 buah bawang merah diiris tipis"
- "2 buah bawang putih diiris tipis"
- "1 buah cabai merah besar dipotong besarbesar"
- " Cabe kering ditumbuk bila tak ada ganti dengan cabai bubuk juga boleh"
- "2 lembar daun jeruk"
- "secukupnya Garam Gula"
- " Selada Lettuce secukupnya digunakan untuk penyajian"
recipeinstructions:
- "Tumis irisan bawang merah, putih dan cabai merah besar yg telah diiris dan dipotong dengan sedikit minyak hingga harum, masukkan daun jeruk lalu masukan daging cincang."
- "Setelah itu masukkan cabai kering yg sudah di tumbuk, masukkan perasan jeruk nipis, kecap asin, kecap manis, kecap ikan, lada hitam, garam, dan gula secukupnya."
- "Terakhir masukkan daun kemangi + daun kemiri aduk hingga rata, setelah daun terlihat layu masakan siap disajikan."
- "Sajikan masakan dibawah potongan daun selada lettuce agar terlihat cantik, soal rasa dijamin mantap👍🏻👍🏻👍🏻"
categories:
- Recipe
tags:
- beef
- basil
- ala

katakunci: beef basil ala 
nutrition: 224 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Lunch

---


![Beef Basil ala Nona Angela](https://img-global.cpcdn.com/recipes/4d39edc5cffc940c/680x482cq70/beef-basil-ala-nona-angela-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga gurih. Ciri makanan Indonesia beef basil ala nona angela yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Beef Basil ala Nona Angela untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian masakan yang dapat anda contoh salah satunya beef basil ala nona angela yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep beef basil ala nona angela tanpa harus bersusah payah.
Berikut ini resep Beef Basil ala Nona Angela yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 15 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Beef Basil ala Nona Angela:

1. Jangan lupa 1/2 daging sapi cincang
1. Harap siapkan 1 butir jeruk nipis
1. Diperlukan 1 sdm kecap manis
1. Dibutuhkan 1 sdm kecap asin
1. Jangan lupa 1 sdt kecap ikan
1. Harap siapkan 1 sdt lada hitam
1. Harap siapkan  Thai basil / daun kemangi (sedikit aja)
1. Tambah  Daun ketumbar (sesuai selera) kalo saya pake banyak biar lbh enak
1. Dibutuhkan 4 buah bawang merah (diiris tipis)
1. Harap siapkan 2 buah bawang putih (diiris tipis)
1. Tambah 1 buah cabai merah besar (dipotong besar-besar)
1. Dibutuhkan  Cabe kering (ditumbuk) bila tak ada ganti dengan cabai bubuk juga boleh
1. Diperlukan 2 lembar daun jeruk
1. Siapkan secukupnya Garam, Gula
1. Jangan lupa  Selada Lettuce (secukupnya) digunakan untuk penyajian




<!--inarticleads2-->

##### Cara membuat  Beef Basil ala Nona Angela:

1. Tumis irisan bawang merah, putih dan cabai merah besar yg telah diiris dan dipotong dengan sedikit minyak hingga harum, masukkan daun jeruk lalu masukan daging cincang.
1. Setelah itu masukkan cabai kering yg sudah di tumbuk, masukkan perasan jeruk nipis, kecap asin, kecap manis, kecap ikan, lada hitam, garam, dan gula secukupnya.
1. Terakhir masukkan daun kemangi + daun kemiri aduk hingga rata, setelah daun terlihat layu masakan siap disajikan.
1. Sajikan masakan dibawah potongan daun selada lettuce agar terlihat cantik, soal rasa dijamin mantap👍🏻👍🏻👍🏻




Demikianlah cara membuat beef basil ala nona angela yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
