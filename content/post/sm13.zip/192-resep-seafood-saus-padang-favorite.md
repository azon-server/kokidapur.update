---
description: "Resep : Seafood Saus Padang Favorite"
title: "Resep : Seafood Saus Padang Favorite"
slug: 192-resep-seafood-saus-padang-favorite
date: 2020-11-25T16:27:53.172Z
image: https://img-global.cpcdn.com/recipes/fa2e654687dfec62/680x482cq70/seafood-saus-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fa2e654687dfec62/680x482cq70/seafood-saus-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fa2e654687dfec62/680x482cq70/seafood-saus-padang-foto-resep-utama.jpg
author: Michael Webster
ratingvalue: 4.1
reviewcount: 46285
recipeingredient:
- "1 kg seafood direbus dulu bisa udang kepiting kerang dll"
- "50 gr bawang merah"
- "1 bonggol bawang putih uk besar"
- "1 buah bawang bombay"
- "1 ruas jahe"
- "75 gr cabe giling"
- "1 buah tomat"
- "1 buah pala uk kecil"
- "1 sdt merica bubuk"
- "1 buah bunga lawang"
- "3 buah cengkeh"
- "2 buah kapulaga"
- "2 batang daun bawang"
- "2 batang seledri"
- "1 batang serai"
- "2 helai daun salam uk besar"
- "2 helai daun jeruk uk besar"
- "1 sachet saori"
- "3 sdm saus sambal"
- "3 sdm kecap manis"
- "2 buah jagung manis yg sudah direbus"
- "Secukupnya air bersih"
- "Secukupnya garam"
- "Secukupnya penyedap bisa di skip"
recipeinstructions:
- "Haluskan bawang merah, bawang putih, jahe dan tomat."
- "Panaskan minyak, kemudian masukan rempah2 dan daun2an. Setelah aroma rempah dan daun2 keluar masukan bahan2 yg telah dihaluskan tadi, tambahkan merica bubuk, cabe giling, bawang bombay, daun bawang, seledri kemudian tumis hingga harum"
- "Tambahkan air dan biarkan hingga mendidih"
- "Setelah mendidih, masukan seafood yg sudah direbus tadi. Biarkan hingga air agak menyusut baru tambahkan jagung, saus sambal, saus tiram dan kecap manis, biarkan bumbu meresap."
- "Setelah dirasa cukup matang matikan kompor dan seafood saus padang siap disajikan."
categories:
- Recipe
tags:
- seafood
- saus
- padang

katakunci: seafood saus padang 
nutrition: 125 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dessert

---


![Seafood Saus Padang](https://img-global.cpcdn.com/recipes/fa2e654687dfec62/680x482cq70/seafood-saus-padang-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau gurih. Ciri kuliner Indonesia seafood saus padang yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan keluarga bisa ditemukan dengan cara simple. Diantaranya adalah memasak Seafood Saus Padang untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang dapat anda praktekkan salah satunya seafood saus padang yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep seafood saus padang tanpa harus bersusah payah.
Seperti resep Seafood Saus Padang yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 24 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Seafood Saus Padang:

1. Diperlukan 1 kg seafood, direbus dulu (bisa udang, kepiting, kerang, dll)
1. Harus ada 50 gr bawang merah
1. Harap siapkan 1 bonggol bawang putih uk besar
1. Diperlukan 1 buah bawang bombay
1. Jangan lupa 1 ruas jahe
1. Harap siapkan 75 gr cabe giling
1. Siapkan 1 buah tomat
1. Harap siapkan 1 buah pala uk kecil
1. Siapkan 1 sdt merica bubuk
1. Tambah 1 buah bunga lawang
1. Tambah 3 buah cengkeh
1. Harap siapkan 2 buah kapulaga
1. Tambah 2 batang daun bawang
1. Siapkan 2 batang seledri
1. Diperlukan 1 batang serai
1. Jangan lupa 2 helai daun salam uk besar
1. Dibutuhkan 2 helai daun jeruk uk besar
1. Harap siapkan 1 sachet saori
1. Siapkan 3 sdm saus sambal
1. Harus ada 3 sdm kecap manis
1. Tambah 2 buah jagung manis yg sudah direbus
1. Dibutuhkan Secukupnya air bersih
1. Dibutuhkan Secukupnya garam
1. Dibutuhkan Secukupnya penyedap (bisa di skip)




<!--inarticleads2-->

##### Langkah membuat  Seafood Saus Padang:

1. Haluskan bawang merah, bawang putih, jahe dan tomat.
1. Panaskan minyak, kemudian masukan rempah2 dan daun2an. Setelah aroma rempah dan daun2 keluar masukan bahan2 yg telah dihaluskan tadi, tambahkan merica bubuk, cabe giling, bawang bombay, daun bawang, seledri kemudian tumis hingga harum
1. Tambahkan air dan biarkan hingga mendidih
1. Setelah mendidih, masukan seafood yg sudah direbus tadi. Biarkan hingga air agak menyusut baru tambahkan jagung, saus sambal, saus tiram dan kecap manis, biarkan bumbu meresap.
1. Setelah dirasa cukup matang matikan kompor dan seafood saus padang siap disajikan.




Demikianlah cara membuat seafood saus padang yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
