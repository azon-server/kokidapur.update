---
description: "Steps membuat Ikan Kembung Bakar ala Padang Cepat"
title: "Steps membuat Ikan Kembung Bakar ala Padang Cepat"
slug: 134-steps-membuat-ikan-kembung-bakar-ala-padang-cepat
date: 2020-09-15T05:10:52.420Z
image: https://img-global.cpcdn.com/recipes/daa7693205732134/680x482cq70/ikan-kembung-bakar-ala-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/daa7693205732134/680x482cq70/ikan-kembung-bakar-ala-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/daa7693205732134/680x482cq70/ikan-kembung-bakar-ala-padang-foto-resep-utama.jpg
author: Mathilda Williams
ratingvalue: 4.9
reviewcount: 26891
recipeingredient:
- "3 ekor ikan kembung bersihkan dan kerat"
- "1 buah jeruk sambal"
- "2,5 sdm santan kental"
- "3 lembar daun jeruk"
- "1 batang serai geprek"
- "secukupnya Gula garam dan lada bubuk"
- "secukupnya Air"
- " Bumbu halus"
- "5 siung bawang merah"
- "4 siung bawang putih"
- "1 ruas kunyit"
- "1/2 ruas jahe"
- "2 butir kemiri"
recipeinstructions:
- "Lumuri ikan dg perasan jeruk diamkan sebentar"
- "Blender bumbu hingga halus kemudian tumis, masukkan juga serai dan daun jeruk, aduk rata jika sudah mulai matang bumbunya masukkan santan kental"
- "Beri air secukupnya, garam, gula pasir, lada bubuk aduk&#34; kemudian masukkan ikan biarkan matang satu sisinya kemudian balik perlahan utk satu sisinya lagi, masak hingga bumbu menyusut/mengering, matikan kompor dan diamkan sekitar 15menit biar bumbu makin meresap"
- "Panaskan teflon, lalu bakar ikan hingga matang kecokelatan, sambil diolesi dg bumbu ungkepnya tadi. Jika sudah matang siap disajikan"
categories:
- Recipe
tags:
- ikan
- kembung
- bakar

katakunci: ikan kembung bakar 
nutrition: 195 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Dinner

---


![Ikan Kembung Bakar ala Padang](https://img-global.cpcdn.com/recipes/daa7693205732134/680x482cq70/ikan-kembung-bakar-ala-padang-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ikan kembung bakar ala padang yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan keistimewahan yang merupakan keragaman Indonesia



Kehangatan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah memasak Ikan Kembung Bakar ala Padang untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang dapat anda praktekkan salah satunya ikan kembung bakar ala padang yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ikan kembung bakar ala padang tanpa harus bersusah payah.
Berikut ini resep Ikan Kembung Bakar ala Padang yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ikan Kembung Bakar ala Padang:

1. Harap siapkan 3 ekor ikan kembung (bersihkan dan kerat&#34;)
1. Siapkan 1 buah jeruk sambal
1. Jangan lupa 2,5 sdm santan kental
1. Harap siapkan 3 lembar daun jeruk
1. Harus ada 1 batang serai (geprek)
1. Tambah secukupnya Gula, garam dan lada bubuk
1. Diperlukan secukupnya Air
1. Diperlukan  Bumbu halus
1. Harus ada 5 siung bawang merah
1. Jangan lupa 4 siung bawang putih
1. Tambah 1 ruas kunyit
1. Harap siapkan 1/2 ruas jahe
1. Diperlukan 2 butir kemiri




<!--inarticleads2-->

##### Instruksi membuat  Ikan Kembung Bakar ala Padang:

1. Lumuri ikan dg perasan jeruk diamkan sebentar
1. Blender bumbu hingga halus kemudian tumis, masukkan juga serai dan daun jeruk, aduk rata jika sudah mulai matang bumbunya masukkan santan kental
1. Beri air secukupnya, garam, gula pasir, lada bubuk aduk&#34; kemudian masukkan ikan biarkan matang satu sisinya kemudian balik perlahan utk satu sisinya lagi, masak hingga bumbu menyusut/mengering, matikan kompor dan diamkan sekitar 15menit biar bumbu makin meresap
1. Panaskan teflon, lalu bakar ikan hingga matang kecokelatan, sambil diolesi dg bumbu ungkepnya tadi. Jika sudah matang siap disajikan




Demikianlah cara membuat ikan kembung bakar ala padang yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan cepat, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
