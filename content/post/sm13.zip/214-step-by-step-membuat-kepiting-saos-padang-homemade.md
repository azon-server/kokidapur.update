---
description: "Step-by-Step membuat Kepiting Saos Padang Homemade"
title: "Step-by-Step membuat Kepiting Saos Padang Homemade"
slug: 214-step-by-step-membuat-kepiting-saos-padang-homemade
date: 2020-11-02T07:29:49.884Z
image: https://img-global.cpcdn.com/recipes/5076c3e674e153ca/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5076c3e674e153ca/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5076c3e674e153ca/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg
author: Pearl Burke
ratingvalue: 4.3
reviewcount: 12602
recipeingredient:
- "2 kg kepiting bersihkan"
- "2 telur kocok lepas"
- "1 buah bawang bombay iris tipis"
- "1 sdt bawang putih haluskan"
- "10 butir bawang merah iris tipis"
- "5 kemiri sangrai haluskan"
- "3 cabe besar iris2"
- "1 ruas kecil jahe parut halus"
- "5 sdm saos sambal"
- "5 sdm saos tomat"
- "2 sdm saos tiram"
- "1 sdt penyedap rasa kaldu bubuk micin"
- "1 sdm gula"
- "100 ml air matang"
- "1 sdm maizena cairkan dengan sedikit air"
- " Daun bawang iris2"
recipeinstructions:
- "Iris bawang bombay, dan telur dikocok lepas."
- "Tumis bawang bombay, bawang putih, lalu beri air matang. Kemudian masukkan saos sambal, saos tomat, dan saos tiram."
- "Masukkan bawang merah, kemiri, jahe, dan cabe, kemudian beri kocokan telur."
- "Masukkan kepiting yang sudah dibersihkan. Lalu masukkan penyedap rasa dan gula, cicipin koreksi rasa. Terakhir, masukkan daun bawang."
- "Masukkan maizena yang sudah dicampur air, hingga kekentalan yang diinginkan."
categories:
- Recipe
tags:
- kepiting
- saos
- padang

katakunci: kepiting saos padang 
nutrition: 128 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dinner

---


![Kepiting Saos Padang](https://img-global.cpcdn.com/recipes/5076c3e674e153ca/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan renyah. Ciri khas masakan Indonesia kepiting saos padang yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan Kepiting Saos Padang untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang dapat anda contoh salah satunya kepiting saos padang yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep kepiting saos padang tanpa harus bersusah payah.
Seperti resep Kepiting Saos Padang yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kepiting Saos Padang:

1. Siapkan 2 kg kepiting, bersihkan
1. Diperlukan 2 telur, kocok lepas
1. Dibutuhkan 1 buah bawang bombay, iris tipis
1. Tambah 1 sdt bawang putih, haluskan
1. Jangan lupa 10 butir bawang merah, iris tipis
1. Harus ada 5 kemiri, sangrai, haluskan
1. Harus ada 3 cabe besar, iris2
1. Diperlukan 1 ruas kecil jahe, parut halus
1. Jangan lupa 5 sdm saos sambal
1. Siapkan 5 sdm saos tomat
1. Jangan lupa 2 sdm saos tiram
1. Dibutuhkan 1 sdt penyedap rasa (kaldu bubuk, micin)
1. Diperlukan 1 sdm gula
1. Dibutuhkan 100 ml air matang
1. Jangan lupa 1 sdm maizena, cairkan dengan sedikit air
1. Dibutuhkan  Daun bawang, iris2




<!--inarticleads2-->

##### Cara membuat  Kepiting Saos Padang:

1. Iris bawang bombay, dan telur dikocok lepas.
1. Tumis bawang bombay, bawang putih, lalu beri air matang. Kemudian masukkan saos sambal, saos tomat, dan saos tiram.
1. Masukkan bawang merah, kemiri, jahe, dan cabe, kemudian beri kocokan telur.
1. Masukkan kepiting yang sudah dibersihkan. Lalu masukkan penyedap rasa dan gula, cicipin koreksi rasa. Terakhir, masukkan daun bawang.
1. Masukkan maizena yang sudah dicampur air, hingga kekentalan yang diinginkan.




Demikianlah cara membuat kepiting saos padang yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
