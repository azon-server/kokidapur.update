---
description: "Panduan untuk membuat Kue Nona Manis minggu ini"
title: "Panduan untuk membuat Kue Nona Manis minggu ini"
slug: 250-panduan-untuk-membuat-kue-nona-manis-minggu-ini
date: 2021-01-06T17:35:18.590Z
image: https://img-global.cpcdn.com/recipes/9d39df57127dbb2f/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9d39df57127dbb2f/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9d39df57127dbb2f/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Lucinda Holmes
ratingvalue: 4.7
reviewcount: 34240
recipeingredient:
- " Bahan 1"
- "5 SDM tepung terigu"
- "5 SDM gula pasir"
- "1 butir telur"
- "250 ml santan"
- "Sejumput garam"
- " Bahan 2"
- "2 SDM maizena"
- "200 ml santan"
- "1/2 sdt vanilla essense"
- "1 sdt pasta pandan"
- " Bahan 3"
- "200 ml santan"
- "1 SDM tepung terigu"
- "Sejumput garam"
recipeinstructions:
- "Campurkan tepung terigu, gula dan garam pada wadah, kemudian tuangkan santan, aduk hingga tercampur dan tidak ada yang menggerindil, kemudian tambahkan telur, kocok sampai tercampur rata. (Bahan 1)"
- "Campurkan bahan 2 aduk hingga rata, kemudian masak hingga adonan berwarna hijau bening."
- "Campurkan bahan 1 dan 2, kocok hingga tercampur."
- "Campurkan bahan 3, masak hingga meletup2."
- "Olesi cetakan dengan minyak, tuang adonan 1+2 ke cetakan 3/4 cetakan, kemudian tuangkan adonan 3 ditengahnya."
- "Kukus selama 10 menit, jangan lupa tutupnya dilapisi kain agar airnya uap tidak menetes ke adonan. Diamkan hingga dingin, baru keluar lkan dari cetakan"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 276 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT57M"
recipeyield: "1"
recipecategory: Lunch

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/9d39df57127dbb2f/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau gurih. Karasteristik kuliner Nusantara kue nona manis yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa didapat dengan cara simple. Salah satunya adalah memasak Kue Nona Manis untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda buat salah satunya kue nona manis yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 15 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Siapkan  Bahan 1
1. Siapkan 5 SDM tepung terigu
1. Siapkan 5 SDM gula pasir
1. Siapkan 1 butir telur
1. Diperlukan 250 ml santan
1. Harap siapkan Sejumput garam
1. Dibutuhkan  Bahan 2
1. Diperlukan 2 SDM maizena
1. Harap siapkan 200 ml santan
1. Dibutuhkan 1/2 sdt vanilla essense
1. Dibutuhkan 1 sdt pasta pandan
1. Siapkan  Bahan 3
1. Jangan lupa 200 ml santan
1. Tambah 1 SDM tepung terigu
1. Harus ada Sejumput garam




<!--inarticleads2-->

##### Cara membuat  Kue Nona Manis:

1. Campurkan tepung terigu, gula dan garam pada wadah, kemudian tuangkan santan, aduk hingga tercampur dan tidak ada yang menggerindil, kemudian tambahkan telur, kocok sampai tercampur rata. (Bahan 1)
1. Campurkan bahan 2 aduk hingga rata, kemudian masak hingga adonan berwarna hijau bening.
1. Campurkan bahan 1 dan 2, kocok hingga tercampur.
1. Campurkan bahan 3, masak hingga meletup2.
1. Olesi cetakan dengan minyak, tuang adonan 1+2 ke cetakan 3/4 cetakan, kemudian tuangkan adonan 3 ditengahnya.
1. Kukus selama 10 menit, jangan lupa tutupnya dilapisi kain agar airnya uap tidak menetes ke adonan. Diamkan hingga dingin, baru keluar lkan dari cetakan




Demikianlah cara membuat kue nona manis yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan teruji, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
