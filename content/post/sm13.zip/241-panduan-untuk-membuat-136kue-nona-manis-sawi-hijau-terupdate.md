---
description: "Panduan untuk membuat 136.Kue Nona Manis Sawi Hijau terupdate"
title: "Panduan untuk membuat 136.Kue Nona Manis Sawi Hijau terupdate"
slug: 241-panduan-untuk-membuat-136kue-nona-manis-sawi-hijau-terupdate
date: 2020-10-30T12:34:50.885Z
image: https://img-global.cpcdn.com/recipes/e791a0e1e1d5255c/680x482cq70/136kue-nona-manis-sawi-hijau-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e791a0e1e1d5255c/680x482cq70/136kue-nona-manis-sawi-hijau-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e791a0e1e1d5255c/680x482cq70/136kue-nona-manis-sawi-hijau-foto-resep-utama.jpg
author: Lydia Watts
ratingvalue: 4.4
reviewcount: 24926
recipeingredient:
- " Bahan I "
- " Tepung gandum terigu 1 cawan 110 gram"
- " Santan 1 cawan 200 ml saya fibercreme 3 sendok makan  air"
- " Gula pasir 12 cawan 100 gram"
- "1 butir Telur"
- " Bahan II "
- " Air daun pandan saya 6 daun sawi  200 ml air"
- " Santan 12 cawan 100 ml saya fibercreme 2 sendok makanair"
- "2 sendok makan Tepung jagung maizena"
- " Pewarna makanan 1 sendok teh saya pasta pandan"
- " Bahan III "
- " Santan 2 cawan 400 ml saya fibercreme 5 sendok makanair"
- "2 sendok makan Tepung gandum terigu"
- "1 sendok teh Garam"
- "1 sendok teh Gula pasir"
recipeinstructions:
- "Siapkan bahan-bahannya : adonan I,adonan II,adonan III"
- "Potong2 daun sawi beri garam dan air rendam sebentar kemudian bilas hingga bersih,kemudian blender daun sawi dengan 100 ml air hingga benar2 halus"
- "Kemudian saring sambil ditekan dengan punggung sendok biar airnya habis buang ampasnya sisihkan"
- "Kita larutkan fibercreme dengan air hangat hingga 300 ml aduk rata,kemudian masukkan dalam blender telur,gula pasir,tepung terigu dan larutan fibercreme blender hingga rata"
- "Kita masak bahan II siapkan panci atau teflon masukkan larutan fibercreme,air sawi,tepung maizena aduk rata dahulu baru nyalakan api kompor aduk hingga rata baru nyalakan api kompor dengan api kecil"
- "Masukkan pasta pandan aduk rata,kemudian masukkan adonan I"
- "Aduk perlahan bila adonan sudah agak mengental sedikit matikan api angkat dari kompor sisihkan"
- "Kita buat bahan III, campur semua bahan aduk hingga rata dahulu baru nyalakan api aduk perlahan dengan api kecil hingga adonan agak kental sedikit angkat dari kompor"
- "Saring biar adonan tidak bergerindil masukkan dalam botol nggk juga nggk apa2 ya maksudnya biar nggk belepotan masukkin kedalam cetakkan"
- "Oles cetakkan dengan minyak goreng bersih dan masukkan adonan hijau 1/3 cetakan baru masukkan adonan putih jangan penuh ya nanti adonan akan keluar cetakkan bila dikukus"
- "Kukus kue dengan api sedang kecilkan sedikit dan tutup dandang dengan serbet kira-kira 20 menit"
- "Dan kuepun telah matang dinginkan sampai benar2 dingin baru keluarkan dari cetakkan tata dipiring"
- "Kuenya lembut membelai lidah 🤭😁🤗"
categories:
- Recipe
tags:
- 136kue
- nona
- manis

katakunci: 136kue nona manis 
nutrition: 106 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Lunch

---


![136.Kue Nona Manis Sawi Hijau](https://img-global.cpcdn.com/recipes/e791a0e1e1d5255c/680x482cq70/136kue-nona-manis-sawi-hijau-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang setidaknya kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti 136.kue nona manis sawi hijau yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan ciri khas yang merupakan keragaman Indonesia



Kedekatan rumah tangga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak 136.Kue Nona Manis Sawi Hijau untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang dapat anda coba salah satunya 136.kue nona manis sawi hijau yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep 136.kue nona manis sawi hijau tanpa harus bersusah payah.
Berikut ini resep 136.Kue Nona Manis Sawi Hijau yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 13 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 136.Kue Nona Manis Sawi Hijau:

1. Dibutuhkan  Bahan I :
1. Tambah  Tepung gandum/ terigu 1 cawan (110 gram)
1. Jangan lupa  Santan 1 cawan (200 ml) saya fibercreme 3 sendok makan + air
1. Harap siapkan  Gula pasir 1/2 cawan (100 gram)
1. Tambah 1 butir Telur
1. Harap siapkan  Bahan II :
1. Diperlukan  Air daun pandan (saya 6 daun sawi + 200 ml air)
1. Siapkan  Santan 1/2 cawan (100 ml) saya fibercreme 2 sendok makan+air
1. Dibutuhkan 2 sendok makan Tepung jagung/ maizena
1. Harus ada  Pewarna makanan 1 sendok teh (saya pasta pandan)
1. Diperlukan  Bahan III :
1. Harap siapkan  Santan 2 cawan (400 ml) saya fibercreme 5 sendok makan+air
1. Jangan lupa 2 sendok makan Tepung gandum/ terigu
1. Diperlukan 1 sendok teh Garam
1. Jangan lupa 1 sendok teh Gula pasir




<!--inarticleads2-->

##### Langkah membuat  136.Kue Nona Manis Sawi Hijau:

1. Siapkan bahan-bahannya : adonan I,adonan II,adonan III
1. Potong2 daun sawi beri garam dan air rendam sebentar kemudian bilas hingga bersih,kemudian blender daun sawi dengan 100 ml air hingga benar2 halus
1. Kemudian saring sambil ditekan dengan punggung sendok biar airnya habis buang ampasnya sisihkan
1. Kita larutkan fibercreme dengan air hangat hingga 300 ml aduk rata,kemudian masukkan dalam blender telur,gula pasir,tepung terigu dan larutan fibercreme blender hingga rata
1. Kita masak bahan II siapkan panci atau teflon masukkan larutan fibercreme,air sawi,tepung maizena aduk rata dahulu baru nyalakan api kompor aduk hingga rata baru nyalakan api kompor dengan api kecil
1. Masukkan pasta pandan aduk rata,kemudian masukkan adonan I
1. Aduk perlahan bila adonan sudah agak mengental sedikit matikan api angkat dari kompor sisihkan
1. Kita buat bahan III, campur semua bahan aduk hingga rata dahulu baru nyalakan api aduk perlahan dengan api kecil hingga adonan agak kental sedikit angkat dari kompor
1. Saring biar adonan tidak bergerindil masukkan dalam botol nggk juga nggk apa2 ya maksudnya biar nggk belepotan masukkin kedalam cetakkan
1. Oles cetakkan dengan minyak goreng bersih dan masukkan adonan hijau 1/3 cetakan baru masukkan adonan putih jangan penuh ya nanti adonan akan keluar cetakkan bila dikukus
1. Kukus kue dengan api sedang kecilkan sedikit dan tutup dandang dengan serbet kira-kira 20 menit
1. Dan kuepun telah matang dinginkan sampai benar2 dingin baru keluarkan dari cetakkan tata dipiring
1. Kuenya lembut membelai lidah 🤭😁🤗




Demikianlah cara membuat 136.kue nona manis sawi hijau yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan terbukti, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
