---
description: "Resep : Cantik Manis (Nona Manis) Terbukti"
title: "Resep : Cantik Manis (Nona Manis) Terbukti"
slug: 403-resep-cantik-manis-nona-manis-terbukti
date: 2021-03-08T23:25:28.549Z
image: https://img-global.cpcdn.com/recipes/d47bd4a2588cb3f0/680x482cq70/cantik-manis-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d47bd4a2588cb3f0/680x482cq70/cantik-manis-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d47bd4a2588cb3f0/680x482cq70/cantik-manis-nona-manis-foto-resep-utama.jpg
author: Wayne Schneider
ratingvalue: 4.8
reviewcount: 43797
recipeingredient:
- " Bahan Hijau"
- "1 liter santan kental"
- "270 gr terigu"
- "3 butir telur"
- "8 sdm maizena"
- "230 gr gula pasir"
- "15 lembar daun pandan"
- " Bahan Fla Santan"
- "300 santan kental"
- "4 sdm maizena"
- "secukupnya Garam"
- " Minyak untuk olesan"
- "2 tetes perisa pandan"
recipeinstructions:
- "Siapkan bahan"
- "Blender daun pandan dengan 400 ml santan lalu saring. Untuk memperkuat warna, berikan perisa pandan."
- "Masak maizena dengan 600 ml santan. Aduk-aduk hingga mengental"
- "Kocok/mixer telur dengan gula pasir hingga gula hancur. Lalu masukkan terigu dan santan hijau secara bertahap. Aduk hingga rata. Lalu masukkan maizena yg telah dimasak, aduk rata."
- "Masak bahan untuk fla santan dengan memasak santan dan maizena, jangan lupa tambahkan garam secukupnya agar rasa santannya semakin kuat dan gurih."
- "Tips. Agar fla di tengah hasilnya rapi, saya gunakan pipping bag untuk pengisiannya. Tp pakai sendok pun bisa kok"
- "Olesi cetakan dengan minyak, lalu masukkan adonan hijau ke loyang. Beri adonan fla santan di tengahnya."
- "Kukus dengan api sedang selama kurang lebih 10 menit. Jangan lupa beri kain di tutup panci agar uap air tidak menetes di adonan."
- "Cantik manis atau nona manis siap disajikan"
categories:
- Recipe
tags:
- cantik
- manis
- nona

katakunci: cantik manis nona 
nutrition: 119 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT30M"
recipeyield: "2"
recipecategory: Dessert

---


![Cantik Manis (Nona Manis)](https://img-global.cpcdn.com/recipes/d47bd4a2588cb3f0/680x482cq70/cantik-manis-nona-manis-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga empuk. Karasteristik masakan Nusantara cantik manis (nona manis) yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Cantik Manis (Nona Manis) untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang dapat anda praktekkan salah satunya cantik manis (nona manis) yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep cantik manis (nona manis) tanpa harus bersusah payah.
Seperti resep Cantik Manis (Nona Manis) yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 13 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Cantik Manis (Nona Manis):

1. Siapkan  Bahan Hijau:
1. Tambah 1 liter santan kental
1. Jangan lupa 270 gr terigu
1. Diperlukan 3 butir telur
1. Tambah 8 sdm maizena
1. Siapkan 230 gr gula pasir
1. Harap siapkan 15 lembar daun pandan
1. Harap siapkan  Bahan Fla Santan:
1. Dibutuhkan 300 santan kental
1. Harus ada 4 sdm maizena
1. Jangan lupa secukupnya Garam
1. Harus ada  Minyak untuk olesan
1. Tambah 2 tetes perisa pandan




<!--inarticleads2-->

##### Instruksi membuat  Cantik Manis (Nona Manis):

1. Siapkan bahan
1. Blender daun pandan dengan 400 ml santan lalu saring. Untuk memperkuat warna, berikan perisa pandan.
1. Masak maizena dengan 600 ml santan. Aduk-aduk hingga mengental
1. Kocok/mixer telur dengan gula pasir hingga gula hancur. Lalu masukkan terigu dan santan hijau secara bertahap. Aduk hingga rata. Lalu masukkan maizena yg telah dimasak, aduk rata.
1. Masak bahan untuk fla santan dengan memasak santan dan maizena, jangan lupa tambahkan garam secukupnya agar rasa santannya semakin kuat dan gurih.
1. Tips. Agar fla di tengah hasilnya rapi, saya gunakan pipping bag untuk pengisiannya. Tp pakai sendok pun bisa kok
1. Olesi cetakan dengan minyak, lalu masukkan adonan hijau ke loyang. Beri adonan fla santan di tengahnya.
1. Kukus dengan api sedang selama kurang lebih 10 menit. Jangan lupa beri kain di tutup panci agar uap air tidak menetes di adonan.
1. Cantik manis atau nona manis siap disajikan




Demikianlah cara membuat cantik manis (nona manis) yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
