---
description: "Resep : Nona Manis minggu ini"
title: "Resep : Nona Manis minggu ini"
slug: 361-resep-nona-manis-minggu-ini
date: 2021-01-02T17:35:12.319Z
image: https://img-global.cpcdn.com/recipes/8c8a5c830d5c425c/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8c8a5c830d5c425c/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8c8a5c830d5c425c/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Walter Owen
ratingvalue: 4
reviewcount: 18396
recipeingredient:
- " Bahan I"
- "250 ml santan kental beri sejumput garam"
- "1 butir telur"
- "100 gr gula pasir"
- "140 gr terigu protein sedang"
- " Bahan II"
- "125 ml santan kental beri sejumput garam"
- "125 ml air perasaan daun suji pandan"
- "30 gr maizena"
- "25 gr gula pasir"
- " Bahan III"
- "500 ml santan kental"
- "40 gr tepung beras"
- "40 gr gula pasir"
- "1 sdt garam"
recipeinstructions:
- "Masak di api sedang Bahan I"
- "Kocok dengan speed rendah Bahan I. Yang Kemudian masukan Bahan II."
- "Masak di api sedang Bahan III, aduk hingga matang. Terus aduk until mengeluarkan uap. Masukan dalam botol plastik tempat kecap."
- "Isi cup cetakan kurleb 35 gr campuran Bahan I dan II."
- "Semprot bagian tengah dengan Bahan III."
- "Kukus di api besar kurang lebih 15 menit"
- "Setelah dingin baru bisa di keluarkan dari cetakan"
- "Note : ketika di kukus adonan akan sedikit menggembang, so jangan terlalu penuh isinya yah."
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 150 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT46M"
recipeyield: "2"
recipecategory: Dessert

---


![Nona Manis](https://img-global.cpcdn.com/recipes/8c8a5c830d5c425c/680x482cq70/nona-manis-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang dapat kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti nona manis yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara



Kehangatan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak Nona Manis untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang dapat anda contoh salah satunya nona manis yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona Manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 15 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona Manis:

1. Jangan lupa  Bahan I
1. Tambah 250 ml santan kental beri sejumput garam
1. Jangan lupa 1 butir telur
1. Harap siapkan 100 gr gula pasir
1. Diperlukan 140 gr terigu protein sedang
1. Jangan lupa  Bahan II
1. Siapkan 125 ml santan kental beri sejumput garam
1. Jangan lupa 125 ml air perasaan daun suji pandan
1. Tambah 30 gr maizena
1. Siapkan 25 gr gula pasir
1. Jangan lupa  Bahan III
1. Harus ada 500 ml santan kental
1. Diperlukan 40 gr tepung beras
1. Dibutuhkan 40 gr gula pasir
1. Tambah 1 sdt garam




<!--inarticleads2-->

##### Langkah membuat  Nona Manis:

1. Masak di api sedang Bahan I
1. Kocok dengan speed rendah Bahan I. Yang Kemudian masukan Bahan II.
1. Masak di api sedang Bahan III, aduk hingga matang. Terus aduk until mengeluarkan uap. Masukan dalam botol plastik tempat kecap.
1. Isi cup cetakan kurleb 35 gr campuran Bahan I dan II.
1. Semprot bagian tengah dengan Bahan III.
1. Kukus di api besar kurang lebih 15 menit
1. Setelah dingin baru bisa di keluarkan dari cetakan
1. Note : ketika di kukus adonan akan sedikit menggembang, so jangan terlalu penuh isinya yah.




Demikianlah cara membuat nona manis yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan cepat, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
