---
description: "Cara singkat untuk membuat Nona Manis Pandan teraktual"
title: "Cara singkat untuk membuat Nona Manis Pandan teraktual"
slug: 255-cara-singkat-untuk-membuat-nona-manis-pandan-teraktual
date: 2020-10-22T23:49:50.939Z
image: https://img-global.cpcdn.com/recipes/9906495f9cefec61/680x482cq70/nona-manis-pandan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9906495f9cefec61/680x482cq70/nona-manis-pandan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9906495f9cefec61/680x482cq70/nona-manis-pandan-foto-resep-utama.jpg
author: Ida Washington
ratingvalue: 5
reviewcount: 21898
recipeingredient:
- " Bahan A"
- "1 butir telur"
- "100 gr gula Pasir"
- "250 ml santan"
- "145 gr tepung terigu"
- " Bahan B"
- "250 ml santan"
- "1/2 sdt pasta pandan"
- "2 Tetes Pewarna hijau"
- "50 gr gula pasir"
- "1/4 sdt Garam"
- "30 gr tepung maizena"
- " Bahan C"
- "250 ml santan"
- "1 sdm tepung terigu"
- "1 sdm gula pasir"
- "1/2 sdt Garam"
recipeinstructions:
- "Masak Bahan C dengan panci anti lengket sampai meletup2. Dinginkan lalu masukkan kedalam plastik segitiga,ikat ujungnya. (boleh pake botol kecap plastik yaa)."
- "Campur semua bahan B, masak sampai meletup2 sisihkan."
- "Mixer telur dan gula sampai mengembang Lalu masukkan tepung terigu dan santan secara bertahap. Mixer sampai rata. Tuang adonan B aduk rata."
- "Siapkan cetakan yang sudah dioles minyak, lalu masukkan adonan hingga 3/4 bagian."
- "Semprotkan adonan putih ditengahnya. (Secukupnya saja) lalu Kukus selama 10-15 menit dengan api sedang (kukusan dipanaskan dulu yaaa)."
- "Tunggu sampai dingin lalu keluarkan dari cetakan.... Yummyyyy❤️❤️"
categories:
- Recipe
tags:
- nona
- manis
- pandan

katakunci: nona manis pandan 
nutrition: 169 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Dessert

---


![Nona Manis Pandan](https://img-global.cpcdn.com/recipes/9906495f9cefec61/680x482cq70/nona-manis-pandan-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan empuk. Ciri khas makanan Nusantara nona manis pandan yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan keluarga bisa diperoleh dengan cara sederhana. Diantaranya adalah memasak Nona Manis Pandan untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang dapat anda praktekkan salah satunya nona manis pandan yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep nona manis pandan tanpa harus bersusah payah.
Seperti resep Nona Manis Pandan yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona Manis Pandan:

1. Tambah  Bahan A
1. Diperlukan 1 butir telur
1. Harus ada 100 gr gula Pasir
1. Dibutuhkan 250 ml santan
1. Siapkan 145 gr tepung terigu
1. Diperlukan  Bahan B
1. Diperlukan 250 ml santan
1. Diperlukan 1/2 sdt pasta pandan
1. Siapkan 2 Tetes Pewarna hijau
1. Diperlukan 50 gr gula pasir
1. Tambah 1/4 sdt Garam
1. Harus ada 30 gr tepung maizena
1. Harus ada  Bahan C
1. Tambah 250 ml santan
1. Siapkan 1 sdm tepung terigu
1. Jangan lupa 1 sdm gula pasir
1. Dibutuhkan 1/2 sdt Garam




<!--inarticleads2-->

##### Instruksi membuat  Nona Manis Pandan:

1. Masak Bahan C dengan panci anti lengket sampai meletup2. Dinginkan lalu masukkan kedalam plastik segitiga,ikat ujungnya. (boleh pake botol kecap plastik yaa).
1. Campur semua bahan B, masak sampai meletup2 sisihkan.
1. Mixer telur dan gula sampai mengembang Lalu masukkan tepung terigu dan santan secara bertahap. Mixer sampai rata. Tuang adonan B aduk rata.
1. Siapkan cetakan yang sudah dioles minyak, lalu masukkan adonan hingga 3/4 bagian.
1. Semprotkan adonan putih ditengahnya. (Secukupnya saja) lalu Kukus selama 10-15 menit dengan api sedang (kukusan dipanaskan dulu yaaa).
1. Tunggu sampai dingin lalu keluarkan dari cetakan.... Yummyyyy❤️❤️




Demikianlah cara membuat nona manis pandan yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan teruji, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
