---
description: "Step-by-Step membuat Capit Piting Saos Padang minggu ini"
title: "Step-by-Step membuat Capit Piting Saos Padang minggu ini"
slug: 181-step-by-step-membuat-capit-piting-saos-padang-minggu-ini
date: 2021-01-03T15:24:37.598Z
image: https://img-global.cpcdn.com/recipes/56f4a4ae9e6c0d95/680x482cq70/capit-piting-saos-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/56f4a4ae9e6c0d95/680x482cq70/capit-piting-saos-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/56f4a4ae9e6c0d95/680x482cq70/capit-piting-saos-padang-foto-resep-utama.jpg
author: Manuel Wheeler
ratingvalue: 4.1
reviewcount: 47163
recipeingredient:
- "1 kg capit kepitingkepiting utuh"
- "3 bh jagung potong2"
- "1 bh bombay ukuran besar iris2 sesuai selera"
- "5 bh bawang putih"
- "15 sdm saos cabe sesuaikan pedasnya"
- "2 sdm cabe merah halus beli dipasar"
- "2 sdm cabe rawit setan haluskan"
- "3 bh telur ayam kocok lepas"
- "10 lembar daun salam"
- "2 ruas jahe geprek"
- "secukupnya garam dan kaldu bubuk"
recipeinstructions:
- "Siapkan dulu bahan2 nya yaa"
- "Cuci bersih capit piting dan rebus dg tambahan daun salam + jahe hingga mendidih atau sampai aroma amis nya tercium. sisihkan"
- "Tumis duo bawang hingga layu dan wangi, lalu masukkan duo cabe halus. tumis hingga wangi dan matang"
- "Lalu tambahkan air, kurlang lebih 300ml atau sesuaikan dengan banyaknya rajungan aja yaa dan sekaligus masukkan saos cabe nya. aduk2 rata, bairkan hingga mendidih"
- "Setelah itu, masukkan capit kepiting, aduk2 sebentar dan lanjut masukkan telur. masukkan secara bertahap yaa, sambil diaduk2."
- "Masukkan jagung, garam dan kaldu bubuk. aduk kembali hingga mendidih. test rasa"
- "Kalo kuah nya ingin kental, bisa tambahkan larutan maizena yaa, kira2 2sdm dilarutkan dengan 10sdm air.. tuang kedalam masakan dan aduk rata kembali."
- "Taaarrraaaa, jadi deh.. hhmmm enyaakk.. pada rebutan nih wkwkwkw.. selamat mencoba yaa, jangan lupa recooknya.. #salamkenyang"
categories:
- Recipe
tags:
- capit
- piting
- saos

katakunci: capit piting saos 
nutrition: 257 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Dessert

---


![Capit Piting Saos Padang](https://img-global.cpcdn.com/recipes/56f4a4ae9e6c0d95/680x482cq70/capit-piting-saos-padang-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti capit piting saos padang yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara



Kehangatan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah memasak Capit Piting Saos Padang untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang bisa anda contoh salah satunya capit piting saos padang yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep capit piting saos padang tanpa harus bersusah payah.
Berikut ini resep Capit Piting Saos Padang yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 11 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Capit Piting Saos Padang:

1. Dibutuhkan 1 kg capit kepiting/kepiting utuh
1. Dibutuhkan 3 bh jagung, potong2
1. Tambah 1 bh bombay ukuran besar, iris2 sesuai selera
1. Jangan lupa 5 bh bawang putih
1. Siapkan 15 sdm saos cabe (sesuaikan pedasnya)
1. Tambah 2 sdm cabe merah halus (beli dipasar)
1. Tambah 2 sdm cabe rawit setan (haluskan)
1. Jangan lupa 3 bh telur ayam, kocok lepas
1. Harap siapkan 10 lembar daun salam
1. Harap siapkan 2 ruas jahe, geprek
1. Siapkan secukupnya garam dan kaldu bubuk




<!--inarticleads2-->

##### Instruksi membuat  Capit Piting Saos Padang:

1. Siapkan dulu bahan2 nya yaa
1. Cuci bersih capit piting dan rebus dg tambahan daun salam + jahe hingga mendidih atau sampai aroma amis nya tercium. sisihkan
1. Tumis duo bawang hingga layu dan wangi, lalu masukkan duo cabe halus. tumis hingga wangi dan matang
1. Lalu tambahkan air, kurlang lebih 300ml atau sesuaikan dengan banyaknya rajungan aja yaa dan sekaligus masukkan saos cabe nya. aduk2 rata, bairkan hingga mendidih
1. Setelah itu, masukkan capit kepiting, aduk2 sebentar dan lanjut masukkan telur. masukkan secara bertahap yaa, sambil diaduk2.
1. Masukkan jagung, garam dan kaldu bubuk. aduk kembali hingga mendidih. test rasa
1. Kalo kuah nya ingin kental, bisa tambahkan larutan maizena yaa, kira2 2sdm dilarutkan dengan 10sdm air.. tuang kedalam masakan dan aduk rata kembali.
1. Taaarrraaaa, jadi deh.. hhmmm enyaakk.. pada rebutan nih wkwkwkw.. selamat mencoba yaa, jangan lupa recooknya.. #salamkenyang




Demikianlah cara membuat capit piting saos padang yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
