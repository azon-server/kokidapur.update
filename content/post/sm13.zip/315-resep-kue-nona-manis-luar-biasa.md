---
description: "Resep : Kue Nona Manis Luar biasa"
title: "Resep : Kue Nona Manis Luar biasa"
slug: 315-resep-kue-nona-manis-luar-biasa
date: 2020-12-05T23:13:50.575Z
image: https://img-global.cpcdn.com/recipes/8dc22c306230b606/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8dc22c306230b606/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8dc22c306230b606/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Lucas Powell
ratingvalue: 4.9
reviewcount: 12282
recipeingredient:
- "100 gr tepung hun kwe"
- "100 gr sagu mutiara"
- "100 gr gula pasir"
- "1 bungkus santan 12 sdt garam"
- "700 ml air"
- "1 bungkus vanili"
recipeinstructions:
- "Masak air hingga mendidih lalu masukan sagu mutiara biarkan hingga tengah sagu mutiaranya matang, angkat dan saring lalu siram diair mengalir."
- "Dalam satu wadah campur tepung hunkwe, gulpas, vanili, air dan santan, garam aduk hingga rata"
- "Masak dengan api kecil sambil di aduk aduk, jika sudah mengental masukan sagu mutiara aduk rata hingga meletup letup sambil diaduk, angkat."
- "Cepat cepat masukan kedalam cetakan cup karena jika sudah dingin akan cepat mengeras."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 120 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Lunch

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/8dc22c306230b606/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau gurih. Karasteristik kuliner Nusantara kue nona manis yang kaya dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Kue Nona Manis untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang bisa anda praktekkan salah satunya kue nona manis yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis:

1. Harus ada 100 gr tepung hun kwe
1. Dibutuhkan 100 gr sagu mutiara
1. Diperlukan 100 gr gula pasir
1. Diperlukan 1 bungkus santan+ 1/2 sdt garam
1. Harap siapkan 700 ml air
1. Diperlukan 1 bungkus vanili




<!--inarticleads2-->

##### Cara membuat  Kue Nona Manis:

1. Masak air hingga mendidih lalu masukan sagu mutiara biarkan hingga tengah sagu mutiaranya matang, angkat dan saring lalu siram diair mengalir.
1. Dalam satu wadah campur tepung hunkwe, gulpas, vanili, air dan santan, garam aduk hingga rata
1. Masak dengan api kecil sambil di aduk aduk, jika sudah mengental masukan sagu mutiara aduk rata hingga meletup letup sambil diaduk, angkat.
1. Cepat cepat masukan kedalam cetakan cup karena jika sudah dingin akan cepat mengeras.




Demikianlah cara membuat kue nona manis yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
