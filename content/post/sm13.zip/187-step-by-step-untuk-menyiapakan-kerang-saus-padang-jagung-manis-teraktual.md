---
description: "Step-by-Step untuk menyiapakan Kerang saus Padang jagung manis teraktual"
title: "Step-by-Step untuk menyiapakan Kerang saus Padang jagung manis teraktual"
slug: 187-step-by-step-untuk-menyiapakan-kerang-saus-padang-jagung-manis-teraktual
date: 2021-02-05T05:36:55.500Z
image: https://img-global.cpcdn.com/recipes/5fe9c445436b33f5/680x482cq70/kerang-saus-padang-jagung-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5fe9c445436b33f5/680x482cq70/kerang-saus-padang-jagung-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5fe9c445436b33f5/680x482cq70/kerang-saus-padang-jagung-manis-foto-resep-utama.jpg
author: Trevor Price
ratingvalue: 5
reviewcount: 31055
recipeingredient:
- "500 gr kerang"
- "1 bh jagung manis"
- "1 bh bawang bombay"
- "2 sdm saus sambal"
- "3 sdm saus tomal"
- "1 sdt lada bubuk"
- "1 sdt kecap ikan"
- "1 ltr air"
- "3 btg serai"
- "1 sdt gula pasir"
- "secukupnya Garam"
- "secukupnya Penyedap"
- " Minyak secukupnya untuk menumis"
- " Bumbu halus"
- "4 siung bawang putih"
- "6 siung bawang merah"
- "1 ruas jahe"
- "secukupnya Garam"
recipeinstructions:
- "Kerang yang sudah di rebus terlebih dahulu hingga matang dan empuk. Tumis bumbu halus dan bawang Bombay yang sudah dipotong - potong sampai harum. Lalu masukkan kerang tumis hingga bumbu merasuk, tambahkan sedikit air aduk rata."
- "Diamkan beberapa menit lalu masukkan serai semua saus dan tambahkan sisa airnya. Aduk rata diamkan dan tutup."
- "Buka tutup aduk rata masukkan bumbu penyedap dan gula putih. Aduk rata lagi sampai tercampur rata, uji rasa dan jika sudah pas angkat dan sajikan."
categories:
- Recipe
tags:
- kerang
- saus
- padang

katakunci: kerang saus padang 
nutrition: 167 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dessert

---


![Kerang saus Padang jagung manis](https://img-global.cpcdn.com/recipes/5fe9c445436b33f5/680x482cq70/kerang-saus-padang-jagung-manis-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti kerang saus padang jagung manis yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa ciri khas yang merupakan keragaman Nusantara



Kehangatan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Kerang saus Padang jagung manis untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang dapat anda contoh salah satunya kerang saus padang jagung manis yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep kerang saus padang jagung manis tanpa harus bersusah payah.
Seperti resep Kerang saus Padang jagung manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kerang saus Padang jagung manis:

1. Harus ada 500 gr kerang
1. Tambah 1 bh jagung manis
1. Siapkan 1 bh bawang bombay
1. Dibutuhkan 2 sdm saus sambal
1. Dibutuhkan 3 sdm saus tomal
1. Harus ada 1 sdt lada bubuk
1. Tambah 1 sdt kecap ikan
1. Harus ada 1 ltr air
1. Diperlukan 3 btg serai
1. Tambah 1 sdt gula pasir
1. Dibutuhkan secukupnya Garam
1. Harap siapkan secukupnya Penyedap
1. Dibutuhkan  Minyak secukupnya untuk menumis
1. Siapkan  Bumbu halus
1. Jangan lupa 4 siung bawang putih
1. Tambah 6 siung bawang merah
1. Siapkan 1 ruas jahe
1. Diperlukan secukupnya Garam




<!--inarticleads2-->

##### Langkah membuat  Kerang saus Padang jagung manis:

1. Kerang yang sudah di rebus terlebih dahulu hingga matang dan empuk. Tumis bumbu halus dan bawang Bombay yang sudah dipotong - potong sampai harum. Lalu masukkan kerang tumis hingga bumbu merasuk, tambahkan sedikit air aduk rata.
1. Diamkan beberapa menit lalu masukkan serai semua saus dan tambahkan sisa airnya. Aduk rata diamkan dan tutup.
1. Buka tutup aduk rata masukkan bumbu penyedap dan gula putih. Aduk rata lagi sampai tercampur rata, uji rasa dan jika sudah pas angkat dan sajikan.




Demikianlah cara membuat kerang saus padang jagung manis yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
