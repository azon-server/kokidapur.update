---
description: "Steps untuk menyiapakan Kue Nona manis terupdate"
title: "Steps untuk menyiapakan Kue Nona manis terupdate"
slug: 399-steps-untuk-menyiapakan-kue-nona-manis-terupdate
date: 2021-03-07T13:32:00.942Z
image: https://img-global.cpcdn.com/recipes/9be56825fc6d3670/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9be56825fc6d3670/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9be56825fc6d3670/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Della Paul
ratingvalue: 4.1
reviewcount: 5052
recipeingredient:
- " Bahan A"
- "2 sdm tepung maizena"
- "2 gelas santan kental"
- "1/2 gelas gula pasir"
- "15 lmbr daun pandan di blender dgn air santan saring"
- " Garam sdkt"
- " Bahan B"
- "3 gelas santan kental"
- "3 sdm tepung maizena"
- " Garam sdkt"
- " Bahan C"
- "2 gelas tepung terigu"
- "2 btr telur"
- "1 gelas gula pasir"
- "2 sdm tepung maizena"
- "3 gelas santan kental"
recipeinstructions:
- "Di wadah lain campurkan bahan B, masak aduk rata, sampe meletup&#34;...stlh hangat masukkan ke dlm plastik segitiga"
- "Ambil wadah lain, bahan C...mixer gula pasir, telur sampai larut ya...tambahkan tepung terigu, maizena, santan...aduk terus..kemudian masukkan bahan A aduk rata...."
- "Siapkan cetakan talam yang telah diolesi minyak sdkt...tuang 3/4 adonan hijau ke dlm cetakan, lalu tambahkan adonan B (putih) ke tengah-tengah adonan hijau...ulang sampai adonan habis"
- "Kukus kurleb 15-20 menit....sampe matang lha ya...angkat, diamkan dulu sbntr dlm cetakan, stlh agak dingin baru keluarkan dlm cetakan.."
- "Selamat mencoba"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 267 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT37M"
recipeyield: "3"
recipecategory: Dessert

---


![Kue Nona manis](https://img-global.cpcdn.com/recipes/9be56825fc6d3670/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau gurih. Ciri khas masakan Nusantara kue nona manis yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa diperoleh dengan cara mudah. Diantaranya adalah memasak Kue Nona manis untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang dapat anda coba salah satunya kue nona manis yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona manis:

1. Jangan lupa  Bahan A
1. Jangan lupa 2 sdm tepung maizena
1. Harap siapkan 2 gelas santan kental
1. Harap siapkan 1/2 gelas gula pasir
1. Jangan lupa 15 lmbr daun pandan, di blender dgn air santan, saring
1. Harus ada  Garam sdkt
1. Diperlukan  Bahan B
1. Diperlukan 3 gelas santan kental
1. Jangan lupa 3 sdm tepung maizena
1. Siapkan  Garam sdkt
1. Harap siapkan  Bahan C
1. Harus ada 2 gelas tepung terigu
1. Tambah 2 btr telur
1. Harus ada 1 gelas gula pasir
1. Tambah 2 sdm tepung maizena
1. Harap siapkan 3 gelas santan kental




<!--inarticleads2-->

##### Cara membuat  Kue Nona manis:

1. Di wadah lain campurkan bahan B, masak aduk rata, sampe meletup&#34;...stlh hangat masukkan ke dlm plastik segitiga
1. Ambil wadah lain, bahan C...mixer gula pasir, telur sampai larut ya...tambahkan tepung terigu, maizena, santan...aduk terus..kemudian masukkan bahan A aduk rata....
1. Siapkan cetakan talam yang telah diolesi minyak sdkt...tuang 3/4 adonan hijau ke dlm cetakan, lalu tambahkan adonan B (putih) ke tengah-tengah adonan hijau...ulang sampai adonan habis
1. Kukus kurleb 15-20 menit....sampe matang lha ya...angkat, diamkan dulu sbntr dlm cetakan, stlh agak dingin baru keluarkan dlm cetakan..
1. Selamat mencoba




Demikianlah cara membuat kue nona manis yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
