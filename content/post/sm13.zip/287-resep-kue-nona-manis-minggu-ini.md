---
description: "Resep : Kue Nona Manis minggu ini"
title: "Resep : Kue Nona Manis minggu ini"
slug: 287-resep-kue-nona-manis-minggu-ini
date: 2021-01-20T00:32:22.067Z
image: https://img-global.cpcdn.com/recipes/407200a4d95bccbb/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/407200a4d95bccbb/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/407200a4d95bccbb/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Milton Foster
ratingvalue: 4.4
reviewcount: 11753
recipeingredient:
- " Bahan A "
- "1 butir telur kocok lepas"
- "125 gram Gula pasir"
- "125 gram tepung terigu"
- "250 ml santan"
- " Bahan B "
- "125 ml santan"
- "125 air matang"
- "1 sdm pasta pandan"
- "60 gram Gula pasir"
- "30 gram tepung maizena"
- "1/2 sdt garam"
- " Bahan C Inti Putih "
- "250 ml santan kental"
- "1 sdm tepung terigu"
- "1 sdm gula pasir"
- "1/4 sdt garam"
recipeinstructions:
- "Campur semua bahan A, aduk menggunakan whisk atau garpu sampai merata lalu saring agar adonan tdak bergerindil, sisihkan."
- "Campur semua bahan B jd satu, kemudian masak sampai meletup2, matikan kompor, sambil terus mengaduk adonan kemudian campur dgn bahan A, aduk hingga semua adonan tercampur rata. (Ini part sulit jd aku pake saringan untuk menghaluskan adonan, biar gak lama)."
- "Selanjutnya campur semua bahan C, masak dgn api kecil hingga meletup2, angkat dan terus diaduk hingga hangat kemudian masukkan dlm plastik segitiga."
- "Panaskan kukusan, oles cetakan kue dgn minyak goreng, panaskan kukusan kurangnya lebih 10 menit lalu angkat, tuang adonan hijau 2/3 tinggi cetakkan kue, baru tambah adonan putih di tengah2nya."
- "Kukus kue hingga matang (kurleb 15-20 menit), jangan lupa alas tutup kukusan dgn serbet. Jika sudah matang, angkat dan sisihkan hingga sdikit hangat barulah keluarkan dri cetakan dan sajikan."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 182 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Lunch

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/407200a4d95bccbb/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis atau renyah. Ciri makanan Nusantara kue nona manis yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak Kue Nona Manis untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda buat salah satunya kue nona manis yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya sekarang ini anda bisa dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis:

1. Harus ada  Bahan A :
1. Tambah 1 butir telur (kocok lepas)
1. Dibutuhkan 125 gram Gula pasir
1. Jangan lupa 125 gram tepung terigu
1. Harap siapkan 250 ml santan
1. Jangan lupa  Bahan B :
1. Siapkan 125 ml santan
1. Harus ada 125 air matang
1. Dibutuhkan 1 sdm pasta pandan
1. Harap siapkan 60 gram Gula pasir
1. Siapkan 30 gram tepung maizena
1. Harap siapkan 1/2 sdt garam
1. Harap siapkan  Bahan C (Inti Putih) :
1. Tambah 250 ml santan kental
1. Dibutuhkan 1 sdm tepung terigu
1. Jangan lupa 1 sdm gula pasir
1. Harap siapkan 1/4 sdt garam




<!--inarticleads2-->

##### Bagaimana membuat  Kue Nona Manis:

1. Campur semua bahan A, aduk menggunakan whisk atau garpu sampai merata lalu saring agar adonan tdak bergerindil, sisihkan.
1. Campur semua bahan B jd satu, kemudian masak sampai meletup2, matikan kompor, sambil terus mengaduk adonan kemudian campur dgn bahan A, aduk hingga semua adonan tercampur rata. (Ini part sulit jd aku pake saringan untuk menghaluskan adonan, biar gak lama).
1. Selanjutnya campur semua bahan C, masak dgn api kecil hingga meletup2, angkat dan terus diaduk hingga hangat kemudian masukkan dlm plastik segitiga.
1. Panaskan kukusan, oles cetakan kue dgn minyak goreng, panaskan kukusan kurangnya lebih 10 menit lalu angkat, tuang adonan hijau 2/3 tinggi cetakkan kue, baru tambah adonan putih di tengah2nya.
1. Kukus kue hingga matang (kurleb 15-20 menit), jangan lupa alas tutup kukusan dgn serbet. Jika sudah matang, angkat dan sisihkan hingga sdikit hangat barulah keluarkan dri cetakan dan sajikan.




Demikianlah cara membuat kue nona manis yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
