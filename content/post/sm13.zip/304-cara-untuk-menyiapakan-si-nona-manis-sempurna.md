---
description: "Cara untuk menyiapakan Si NONA MANIS Sempurna"
title: "Cara untuk menyiapakan Si NONA MANIS Sempurna"
slug: 304-cara-untuk-menyiapakan-si-nona-manis-sempurna
date: 2020-12-14T00:06:44.111Z
image: https://img-global.cpcdn.com/recipes/2eb9c8d34f0fe314/680x482cq70/si-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2eb9c8d34f0fe314/680x482cq70/si-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2eb9c8d34f0fe314/680x482cq70/si-nona-manis-foto-resep-utama.jpg
author: Maurice Sparks
ratingvalue: 4.2
reviewcount: 7248
recipeingredient:
- " Bahan 1 "
- "250 ml santan kental"
- "150 gr tepung terigu"
- "1 butir telor"
- "80 gr gula pasir"
- " Bahan 2 "
- "250 ml santan kental"
- "30 gr tepung maizena"
- "40 gr gula pasir"
- "1/2 sdt pasta pandan"
- "Sejumput garam"
- " Bahan 3 "
- "500 ml santan kental"
- "6 sdm tepung terigu"
- "Sejumput garam"
- " Minyak secukupnya untuk olesan cetakan"
recipeinstructions:
- "Bahan 1 : Siapkan wadah, masukkan gula pasir dan telor, kocok dengan menggunakan mixer kecepatan tinggi hingga mengental,,, setelah mengental turunkan speed mixer lalu masukan santan dan tepung terigu secara bergantian dan mixer lagi sampai tercampur rata"
- "Setelah tercampur rata, sisihkan adonan pertama"
- "Bahan 2 : siapkan panci lalu tuang semua bahan ke 2 lalu masak dg api kecil sampai mengental,, setelah mengental sisihkan hingga dingin dan uap panas menghilang"
- "Setelah adonan bahan ke 2 dingin dan uap panas berkurang, campur adonan bahan ke 2 ke dalam adonan bahan 1, lalu mixer sampai rata. Lalu sisihkan adonan"
- "Untuk adonan bahan ke 3. Siapkan panci lalu masukkan semua bahan adonan ke 3, aduk dan masak dg api kecil sampai mengental,, lalu masukkan ke dlm botol saus plastik arau plastik segitiga"
- "Siapkan kukusan,,, masak air sampai mendidih yaa,, jgn lupa, tutup kukusan dibungkus dg kain agar air hasil kukusan tdk menetas dlm adonan"
- "Sambil menunggu kukusan siap. Siapkan cetakan yg sebelumnya di olesin minyak,,, masukkan adonan hijau ke dlm cetakan setinggi 3/4 dr tinggi cetakan,,, lalu tambah adonan putih ke dalam adonan hijau sampai penuh,, lakukan sampai habis,,"
- "Kukus adonan selama 10-15 menit."
- "Setelah matang,,, dinginkan adonan lalu keluarkan dr cetakan. Kue Nona manis siap untuk di nikmati"
- "Selamat mencoba"
- "Oya,, aku pakai cetakan talam yg diameternya 5cm dg tinggi kurleb 3,3cm itu bs jd 20 biji lah,,,"
categories:
- Recipe
tags:
- si
- nona
- manis

katakunci: si nona manis 
nutrition: 101 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT55M"
recipeyield: "2"
recipecategory: Dinner

---


![Si NONA MANIS](https://img-global.cpcdn.com/recipes/2eb9c8d34f0fe314/680x482cq70/si-nona-manis-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga gurih. Ciri khas kuliner Nusantara si nona manis yang penuh dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Si NONA MANIS untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

Pada si nona manis yang mungil ini terkandung zat dan vitamin riboflavin, dengan mengkonsumsi secara teratur dapat membantu menjaga mata tetap sehat. Nah, nona manis dapat juga digunakan. Cлушайте онлайн и cкачивайте песню Cat Rambut Highlight Si Nona Manis Catrambut Pehli Si Muhabbat Ost Cover Ali Zafar Atif Arif Unplugged. Saksikan selengkapnya hanya di FTV SCTV - Nona Manis Si Badut Cantik, dimainkan Debi Sagita, Kiki Farel, Joshua Otay, dan artis lainnya.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang dapat anda coba salah satunya si nona manis yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep si nona manis tanpa harus bersusah payah.
Berikut ini resep Si NONA MANIS yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 11 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Si NONA MANIS:

1. Tambah  Bahan 1 :
1. Tambah 250 ml santan kental
1. Jangan lupa 150 gr tepung terigu
1. Jangan lupa 1 butir telor
1. Dibutuhkan 80 gr gula pasir
1. Diperlukan  Bahan 2 :
1. Dibutuhkan 250 ml santan kental
1. Dibutuhkan 30 gr tepung maizena
1. Jangan lupa 40 gr gula pasir
1. Siapkan 1/2 sdt pasta pandan
1. Diperlukan Sejumput garam
1. Diperlukan  Bahan 3 :
1. Siapkan 500 ml santan kental
1. Siapkan 6 sdm tepung terigu
1. Diperlukan Sejumput garam
1. Dibutuhkan  Minyak secukupnya untuk olesan cetakan


C G seng mungkin beta mau bage cinta. Lirik Nona Manis Siapa Yang Punya oleh Maluku. Dapatkan lirik lagu lain oleh Maluku di KapanLagi.com. Nona manis siapa yang punya?&#34; Aku menyenandungkan lagu anak-anak yang sering dinyanyikan nenek sembari melangkah. 

<!--inarticleads2-->

##### Instruksi membuat  Si NONA MANIS:

1. Bahan 1 : Siapkan wadah, masukkan gula pasir dan telor, kocok dengan menggunakan mixer kecepatan tinggi hingga mengental,,, setelah mengental turunkan speed mixer lalu masukan santan dan tepung terigu secara bergantian dan mixer lagi sampai tercampur rata
1. Setelah tercampur rata, sisihkan adonan pertama
1. Bahan 2 : siapkan panci lalu tuang semua bahan ke 2 lalu masak dg api kecil sampai mengental,, setelah mengental sisihkan hingga dingin dan uap panas menghilang
1. Setelah adonan bahan ke 2 dingin dan uap panas berkurang, campur adonan bahan ke 2 ke dalam adonan bahan 1, lalu mixer sampai rata. Lalu sisihkan adonan
1. Untuk adonan bahan ke 3. Siapkan panci lalu masukkan semua bahan adonan ke 3, aduk dan masak dg api kecil sampai mengental,, lalu masukkan ke dlm botol saus plastik arau plastik segitiga
1. Siapkan kukusan,,, masak air sampai mendidih yaa,, jgn lupa, tutup kukusan dibungkus dg kain agar air hasil kukusan tdk menetas dlm adonan
1. Sambil menunggu kukusan siap. Siapkan cetakan yg sebelumnya di olesin minyak,,, masukkan adonan hijau ke dlm cetakan setinggi 3/4 dr tinggi cetakan,,, lalu tambah adonan putih ke dalam adonan hijau sampai penuh,, lakukan sampai habis,,
1. Kukus adonan selama 10-15 menit.
1. Setelah matang,,, dinginkan adonan lalu keluarkan dr cetakan. Kue Nona manis siap untuk di nikmati
1. Selamat mencoba
1. Oya,, aku pakai cetakan talam yg diameternya 5cm dg tinggi kurleb 3,3cm itu bs jd 20 biji lah,,,


Dapatkan lirik lagu lain oleh Maluku di KapanLagi.com. Nona manis siapa yang punya?&#34; Aku menyenandungkan lagu anak-anak yang sering dinyanyikan nenek sembari melangkah. Terdapat banyak pilihan penyedia file pada halaman tersebut. Meski jajanan manis seperti kue nona manis sudah sangat jarang ditemukan, bukan berarti kamu enggak bisa menikmatinya lagi. Predikat &#34;Ratu dari segala ratu bulutangkis&#34; hanya milik si &#34;Nona Manis&#34;. 

Demikianlah cara membuat si nona manis yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
