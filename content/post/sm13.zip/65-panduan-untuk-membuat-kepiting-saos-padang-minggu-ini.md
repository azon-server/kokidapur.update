---
description: "Panduan untuk membuat Kepiting Saos Padang minggu ini"
title: "Panduan untuk membuat Kepiting Saos Padang minggu ini"
slug: 65-panduan-untuk-membuat-kepiting-saos-padang-minggu-ini
date: 2021-01-25T09:25:09.533Z
image: https://img-global.cpcdn.com/recipes/9e63b2f1c50aa49a/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9e63b2f1c50aa49a/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9e63b2f1c50aa49a/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg
author: Celia Murphy
ratingvalue: 4.8
reviewcount: 26492
recipeingredient:
- "4 ekor kepiting me 1 kresek kecil"
- "1/2 siung bawang bombay potongpotong"
- "2 lembar daun jeruk"
- "6 sdm saos tomat me 4 sdm"
- "4 sdm saos sambal me 12 sdt"
- "2 sdm saos tiram"
- "1 sdm garam me 13 sdt"
- "1 sdm kaldu bubuk me 14 sdt"
- "1 sdt gula pasir"
- "1 butir telur kocok lepas"
- "150 ml air me 250 ml"
- " Minyak untuk menumis"
- " Air panas"
- " Bumbu Halus "
- "5 buah cabe merah besar me buang bijinya"
- "7 buah cabe merah rawit saya skip"
- "4 siung bawang putih"
- "4 siung bawang merah"
recipeinstructions:
- "Siram kepiting dengan air panas. Jika kepiting sudah tidak bergerak, bersihkan kepiting (sikat-sikat) dan siram dengan air mengalir. Sisihkan."
- "Tumis bumbu halus dan daun jeruk hingga wangi dan matang. Masukkan saos tomat, saos sambal, saos tiram, garam, kaldu bubuk, dan gula. Aduk rata."
- "Masukkan kepiting, aduk rata."
- "Tambahkan air dan masak hingga kepiting berubah warna orange (kepiting sudah matang). Aduk sesekali ya."
- "Tambahkan telur kocok lepas, aduk rata. Masukkan bawang bombay dan masak hingga kuah menyusut dan mengental. Koreksi rasa."
- "Siap dinikmati...yummy."
categories:
- Recipe
tags:
- kepiting
- saos
- padang

katakunci: kepiting saos padang 
nutrition: 193 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dessert

---


![Kepiting Saos Padang](https://img-global.cpcdn.com/recipes/9e63b2f1c50aa49a/680x482cq70/kepiting-saos-padang-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang setidaknya kita jaga karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti kepiting saos padang yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Kita



Kedekatan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Kepiting Saos Padang untuk orang di rumah. Momen makan bersama keluarga sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang bisa anda praktekkan salah satunya kepiting saos padang yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep kepiting saos padang tanpa harus bersusah payah.
Berikut ini resep Kepiting Saos Padang yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kepiting Saos Padang:

1. Dibutuhkan 4 ekor kepiting (me: 1 kresek kecil)
1. Siapkan 1/2 siung bawang bombay, potong-potong
1. Tambah 2 lembar daun jeruk
1. Jangan lupa 6 sdm saos tomat (me: 4 sdm)
1. Tambah 4 sdm saos sambal (me: 1/2 sdt)
1. Jangan lupa 2 sdm saos tiram
1. Siapkan 1 sdm garam (me: 1/3 sdt)
1. Jangan lupa 1 sdm kaldu bubuk (me: 1/4 sdt)
1. Harus ada 1 sdt gula pasir
1. Siapkan 1 butir telur, kocok lepas
1. Dibutuhkan 150 ml air (me: 250 ml)
1. Diperlukan  Minyak untuk menumis
1. Dibutuhkan  Air panas
1. Siapkan  Bumbu Halus :
1. Dibutuhkan 5 buah cabe merah besar (me: buang bijinya)
1. Siapkan 7 buah cabe merah rawit (saya skip)
1. Dibutuhkan 4 siung bawang putih
1. Jangan lupa 4 siung bawang merah




<!--inarticleads2-->

##### Cara membuat  Kepiting Saos Padang:

1. Siram kepiting dengan air panas. Jika kepiting sudah tidak bergerak, bersihkan kepiting (sikat-sikat) dan siram dengan air mengalir. Sisihkan.
1. Tumis bumbu halus dan daun jeruk hingga wangi dan matang. Masukkan saos tomat, saos sambal, saos tiram, garam, kaldu bubuk, dan gula. Aduk rata.
1. Masukkan kepiting, aduk rata.
1. Tambahkan air dan masak hingga kepiting berubah warna orange (kepiting sudah matang). Aduk sesekali ya.
1. Tambahkan telur kocok lepas, aduk rata. Masukkan bawang bombay dan masak hingga kuah menyusut dan mengental. Koreksi rasa.
1. Siap dinikmati...yummy.




Demikianlah cara membuat kepiting saos padang yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
