---
description: "Resep : Nona Manis Durian Teruji"
title: "Resep : Nona Manis Durian Teruji"
slug: 243-resep-nona-manis-durian-teruji
date: 2021-02-15T07:40:28.478Z
image: https://img-global.cpcdn.com/recipes/74b92e7b36cbf5a8/680x482cq70/nona-manis-durian-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/74b92e7b36cbf5a8/680x482cq70/nona-manis-durian-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/74b92e7b36cbf5a8/680x482cq70/nona-manis-durian-foto-resep-utama.jpg
author: Jesus Brewer
ratingvalue: 4.7
reviewcount: 44912
recipeingredient:
- " Bahan Hijau"
- "300 ml santan kental"
- "1/2 cup gula pasir"
- "1 cup tepung terigu"
- "1 butir telur"
- "125 ml air pandan"
- "Sejumput garam"
- "1/4 cup tepung maizena"
- "secukupnya Daging durian"
- " Bahan Putih"
- "1/3 cup tepung terigu"
- "1/4 cup gula pasir"
- "150 ml santan kental"
- "Sejumput garam"
recipeinstructions:
- "Siapkan bahan-bahan untuk bagian hijau, aduk durian, tepung dan telur."
- "Didihkan air pandan, gula pasir dan santan. Kemudian tuang sedikit demi sedikit di adonan tepung. Kemudian masak kembali sampai mengental. Isi ke dalam cetakan kira kira 2/3"
- "Buat bahan putih. Campur semua bahan, setelah rata baru hidupkan kompor. Masak hingga mengental. Kemudian masukkan ke plastik segitiga"
- "Masih dalam kondisi panas, masukkan adonan putih ke tengah adonan hijau. Kemudian kukus selama 10 menit. Setelah dingin, keluarkan dari cetakan dan simpan di lemari es. Karena lebih nikmat dalam kondisi dingin. Selamat mencoba"
categories:
- Recipe
tags:
- nona
- manis
- durian

katakunci: nona manis durian 
nutrition: 284 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Dessert

---


![Nona Manis Durian](https://img-global.cpcdn.com/recipes/74b92e7b36cbf5a8/680x482cq70/nona-manis-durian-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga empuk. Karasteristik kuliner Nusantara nona manis durian yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga dapat ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Nona Manis Durian untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang dapat anda praktekkan salah satunya nona manis durian yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep nona manis durian tanpa harus bersusah payah.
Seperti resep Nona Manis Durian yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona Manis Durian:

1. Harap siapkan  Bahan Hijau
1. Harus ada 300 ml santan kental
1. Tambah 1/2 cup gula pasir
1. Harus ada 1 cup tepung terigu
1. Jangan lupa 1 butir telur
1. Tambah 125 ml air pandan
1. Harap siapkan Sejumput garam
1. Diperlukan 1/4 cup tepung maizena
1. Jangan lupa secukupnya Daging durian
1. Tambah  Bahan Putih
1. Harap siapkan 1/3 cup tepung terigu
1. Jangan lupa 1/4 cup gula pasir
1. Harap siapkan 150 ml santan kental
1. Harus ada Sejumput garam




<!--inarticleads2-->

##### Langkah membuat  Nona Manis Durian:

1. Siapkan bahan-bahan untuk bagian hijau, aduk durian, tepung dan telur.
1. Didihkan air pandan, gula pasir dan santan. Kemudian tuang sedikit demi sedikit di adonan tepung. Kemudian masak kembali sampai mengental. Isi ke dalam cetakan kira kira 2/3
1. Buat bahan putih. Campur semua bahan, setelah rata baru hidupkan kompor. Masak hingga mengental. Kemudian masukkan ke plastik segitiga
1. Masih dalam kondisi panas, masukkan adonan putih ke tengah adonan hijau. Kemudian kukus selama 10 menit. Setelah dingin, keluarkan dari cetakan dan simpan di lemari es. Karena lebih nikmat dalam kondisi dingin. Selamat mencoba




Demikianlah cara membuat nona manis durian yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan cepat, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
