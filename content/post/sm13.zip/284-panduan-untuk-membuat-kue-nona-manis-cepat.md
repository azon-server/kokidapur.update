---
description: "Panduan untuk membuat Kue nona manis Cepat"
title: "Panduan untuk membuat Kue nona manis Cepat"
slug: 284-panduan-untuk-membuat-kue-nona-manis-cepat
date: 2021-01-02T05:12:16.444Z
image: https://img-global.cpcdn.com/recipes/c54254aff3f06959/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c54254aff3f06959/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c54254aff3f06959/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Dollie Schultz
ratingvalue: 4.9
reviewcount: 11465
recipeingredient:
- " Bahan 1 "
- "150 ml santan"
- "100 ml endapan jus pandan"
- "30 gram tepung beras"
- "1/4 garam"
- " Pewarna hijau optional"
- " Bahan 2 "
- "250 ml santan"
- "1 butir telur"
- "125 gram gula pasir"
- "140 gram tepung terigu"
- " Bahan 3 "
- "500 ml santan"
- "40 gram tepung beras"
- "1/2 sdt gula pasir"
- "1/2 sdt garam"
recipeinstructions:
- "Campur semua bahan 1 lalu masak aduk2 sampai tidak ada yang bergelindir sisikan blender lagi sampai bener2 tercampur rata dan sisikan"
- "Lalu blender bahan 2 telor gula sampai gula larut lalu masukkan santan dan tepung blender lagi sampai tercampur rata masukkan adonan hijau tadi blender lagi sampai tercampur rata sisikan"
- "Campur semua bahan 3 : aduk rata lalu masak sama sampai agak kental angkat lalu masukkan de dalam botol kecap"
- "Lalu oles cetakan kue talam dengan minyak tipis2"
- "Lalu masukkan adonan hijau lalu tekan di tengahnya adonan putih lalu kukus lakukan sampai selesai ya da matang angkat dan sajikan"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 223 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dessert

---


![Kue nona manis](https://img-global.cpcdn.com/recipes/c54254aff3f06959/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga renyah. Karasteristik makanan Indonesia kue nona manis yang kaya dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Kue nona manis untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

Kue nona manis adalah salah satu jajanan tradisional yang melegenda di Indonesia. Ada yang tahu kue nona manis? SALAH satu jajanan pasar kue nona manis rasanya sudah jarang ditemui. Meski langkahnya sedikit rumit, ada rasa puas tersendiri saat berhasil membuat kue nona manis.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda contoh salah satunya kue nona manis yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue nona manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue nona manis:

1. Tambah  Bahan 1 :
1. Siapkan 150 ml santan
1. Diperlukan 100 ml endapan jus pandan
1. Diperlukan 30 gram tepung beras
1. Jangan lupa 1/4 garam
1. Dibutuhkan  Pewarna hijau (optional)
1. Dibutuhkan  Bahan 2 :
1. Tambah 250 ml santan
1. Harus ada 1 butir telur
1. Harus ada 125 gram gula pasir
1. Dibutuhkan 140 gram tepung terigu
1. Harus ada  Bahan 3 :
1. Dibutuhkan 500 ml santan
1. Diperlukan 40 gram tepung beras
1. Tambah 1/2 sdt gula pasir
1. Jangan lupa 1/2 sdt garam


Nona manis adalah kue khas Sulawesi. Teksturnya lebih lembut dari kue talam Indonesia lainnya. Bagian yang berwarna hijau rasanya manis dan gurih santan, sedangkan bagian yang berwarna putih. Aih, sudah lama rasanya tidak mendengar Kue Nona Manis. 

<!--inarticleads2-->

##### Bagaimana membuat  Kue nona manis:

1. Campur semua bahan 1 lalu masak aduk2 sampai tidak ada yang bergelindir sisikan blender lagi sampai bener2 tercampur rata dan sisikan
1. Lalu blender bahan 2 telor gula sampai gula larut lalu masukkan santan dan tepung blender lagi sampai tercampur rata masukkan adonan hijau tadi blender lagi sampai tercampur rata sisikan
1. Campur semua bahan 3 : aduk rata lalu masak sama sampai agak kental angkat lalu masukkan de dalam botol kecap
1. Lalu oles cetakan kue talam dengan minyak tipis2
1. Lalu masukkan adonan hijau lalu tekan di tengahnya adonan putih lalu kukus lakukan sampai selesai ya da matang angkat dan sajikan


Bagian yang berwarna hijau rasanya manis dan gurih santan, sedangkan bagian yang berwarna putih. Aih, sudah lama rasanya tidak mendengar Kue Nona Manis. Camilan klasik ini bisa Bunda hadirkan kembali dengan warna menarik yang tidak akan ditolak oleh si kecil. Your current browser isn&#39;t compatible with SoundCloud. Please download one of our supported browsers. 

Demikianlah cara membuat kue nona manis yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan cepat, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
