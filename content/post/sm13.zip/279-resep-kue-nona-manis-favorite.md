---
description: "Resep : Kue Nona Manis Favorite"
title: "Resep : Kue Nona Manis Favorite"
slug: 279-resep-kue-nona-manis-favorite
date: 2020-12-06T20:39:18.777Z
image: https://img-global.cpcdn.com/recipes/e7eb69708974925c/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e7eb69708974925c/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e7eb69708974925c/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Norman Williamson
ratingvalue: 4
reviewcount: 48368
recipeingredient:
- " Bahan A "
- "250 ml Santan"
- "1 butir telur"
- "125 gr Gula pasir"
- "125 gr tepung terigu"
- " Bahan B "
- "125 ml santan"
- "125 ml jus pandan blender 8 lembar daun pandan dan saring"
- "60 gr gula pasir"
- "30 gr tepung maizena"
- "1/2 sdt garam"
- "Secukupnya pewarna hijau"
- " Bahan C inti putih"
- "250 santan kental"
- "1 sdm munjung tepung terigu"
- "1 sdm gula pasir"
- "1/4 sdt garam"
recipeinstructions:
- "Bahan A : mixer telur + gula sampai gula larut tekstur kental putih, lalu masukkan tepung dan santan secara bertahap mixer lagi sampai tercampur rata"
- "Lalu saring agar adonan halus dan tidak bergerindil, sisihkan"
- "Bahan B : aduk rata semua bahan B sampai tercampur rata, lalu nyalakan api masak dg api kecil sampai kental meletup2, aduk terus ya supaya tidak menggumpal"
- "Matikan api lalu, masukan bahan A dan aduk sampai rata, sisihkan"
- "Bahan C : aduk semua bahan C lalu nyalakan api masak dg api kecil aduk2 sampai kental dan meletup2. Angkat dan aduk2, tunggu sampai hangat dan masukan ke plastik segitia atau kedalam botos kecap/saus"
- "Panaskan kukusan hingga beruap, siapkan cetakan kue olesi dg minyak tipis saja. Tuang adonan hijau 2/3 tinggi cetakan lalu semprotkan adonan putih ditengahnya"
- "Setelah kukusan panas, kukus kue hingga matang -+ 10-15 menit. Jangan lupa tutup kukusan dialasi serbet. Keluarkan dr kukusan biarkan hingga dingin lalu keluarkan dari cetakan."
- "Lembutttt dalemnya lumer 😋"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 233 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Lunch

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/e7eb69708974925c/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau renyah. Karasteristik makanan Nusantara kue nona manis yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Kue Nona Manis untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang dapat anda contoh salah satunya kue nona manis yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Siapkan  Bahan A :
1. Harus ada 250 ml Santan
1. Dibutuhkan 1 butir telur
1. Tambah 125 gr Gula pasir
1. Dibutuhkan 125 gr tepung terigu
1. Dibutuhkan  Bahan B :
1. Diperlukan 125 ml santan
1. Tambah 125 ml jus pandan (blender -+8 lembar daun pandan dan saring)
1. Diperlukan 60 gr gula pasir
1. Siapkan 30 gr tepung maizena
1. Diperlukan 1/2 sdt garam
1. Jangan lupa Secukupnya pewarna hijau
1. Harus ada  Bahan C (inti putih)
1. Dibutuhkan 250 santan kental
1. Tambah 1 sdm munjung tepung terigu
1. Jangan lupa 1 sdm gula pasir
1. Tambah 1/4 sdt garam




<!--inarticleads2-->

##### Instruksi membuat  Kue Nona Manis:

1. Bahan A : mixer telur + gula sampai gula larut tekstur kental putih, lalu masukkan tepung dan santan secara bertahap mixer lagi sampai tercampur rata
1. Lalu saring agar adonan halus dan tidak bergerindil, sisihkan
1. Bahan B : aduk rata semua bahan B sampai tercampur rata, lalu nyalakan api masak dg api kecil sampai kental meletup2, aduk terus ya supaya tidak menggumpal
1. Matikan api lalu, masukan bahan A dan aduk sampai rata, sisihkan
1. Bahan C : aduk semua bahan C lalu nyalakan api masak dg api kecil aduk2 sampai kental dan meletup2. Angkat dan aduk2, tunggu sampai hangat dan masukan ke plastik segitia atau kedalam botos kecap/saus
1. Panaskan kukusan hingga beruap, siapkan cetakan kue olesi dg minyak tipis saja. Tuang adonan hijau 2/3 tinggi cetakan lalu semprotkan adonan putih ditengahnya
1. Setelah kukusan panas, kukus kue hingga matang -+ 10-15 menit. Jangan lupa tutup kukusan dialasi serbet. Keluarkan dr kukusan biarkan hingga dingin lalu keluarkan dari cetakan.
1. Lembutttt dalemnya lumer 😋




Demikianlah cara membuat kue nona manis yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat gampang dan cepat, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
