---
description: "Steps untuk membuat Puding Ubi Kuning Cepat"
title: "Steps untuk membuat Puding Ubi Kuning Cepat"
slug: 463-steps-untuk-membuat-puding-ubi-kuning-cepat
date: 2021-01-18T09:47:43.994Z
image: https://img-global.cpcdn.com/recipes/823b2c37d2f09797/680x482cq70/puding-ubi-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/823b2c37d2f09797/680x482cq70/puding-ubi-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/823b2c37d2f09797/680x482cq70/puding-ubi-kuning-foto-resep-utama.jpg
author: Victor Robertson
ratingvalue: 4
reviewcount: 26797
recipeingredient:
- "1 kg ubi kuningorange"
- "1 kaleng cream kental manis cap nona boleh merk apa aja y bun"
- "2 bks bubuk agaragar tanpa rasa"
- "1800 cc air"
- "Secukupnya gula pasir opsi  boleh di skip aja"
recipeinstructions:
- "Cuci bersih ubi, lalu kukus sampai matang"
- "Setelah ubi matang, dinginkan dan haluskan ubi tersebut (opsi: dihaluskan pakai garpu atw diblender, klw saya diblender ditambah air yg disiapkan td pakai 500cc)"
- "Masukkan 2 bungkus bubuk agar-agar kedalam panci masukkan sisa air td (1300cc), sambil di aduk hingga bubuk agar2 nya larut."
- "Masak diatas kompor sampai mendidih smbil terus diaduk perlahan, kalau sudah mendidih masukkan ubi yang sudah dihaluskan perlahan smbil terus diaduk agar tercampur rata. Kemudian masukkan cream kental manis kedalam adonan agar2, tes rasa y bun jgn lupa. Kalau saya gx pakai gula lagi krn menurut sy manisny udh pas bgt, manisny didapat dr ubi itu sendri n krim kental manis td."
- "Kalau sudah tercampur rata, matikan kompor dan diamkan sebentar sampai uap panasnya hilang."
- "Setelah itu tuang kedalam cetakan (cetakannya bebas y bun) 😉. Lalu dinginkan dlm frezer smpai mengeras."
- "Puding siap dihidangkan dan dinikmati,"
- "Lebih enak disantap pas cuaca panas y bun. Krn puding yg dingin bisa memberikan kesegaran jiwa dan raga"
categories:
- Recipe
tags:
- puding
- ubi
- kuning

katakunci: puding ubi kuning 
nutrition: 196 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Lunch

---


![Puding Ubi Kuning](https://img-global.cpcdn.com/recipes/823b2c37d2f09797/680x482cq70/puding-ubi-kuning-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan enak. Ciri kuliner Nusantara puding ubi kuning yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga bisa didapat dengan cara mudah. Diantaranya adalah memasak Puding Ubi Kuning untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi makanan yang bisa anda buat salah satunya puding ubi kuning yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep puding ubi kuning tanpa harus bersusah payah.
Seperti resep Puding Ubi Kuning yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Puding Ubi Kuning:

1. Dibutuhkan 1 kg ubi kuning/orange
1. Siapkan 1 kaleng cream kental manis cap nona (boleh merk apa aja y bun)
1. Diperlukan 2 bks bubuk agar-agar tanpa rasa
1. Harus ada 1800 cc air
1. Dibutuhkan Secukupnya gula pasir (opsi : boleh di skip aja)




<!--inarticleads2-->

##### Langkah membuat  Puding Ubi Kuning:

1. Cuci bersih ubi, lalu kukus sampai matang
1. Setelah ubi matang, dinginkan dan haluskan ubi tersebut (opsi: dihaluskan pakai garpu atw diblender, klw saya diblender ditambah air yg disiapkan td pakai 500cc)
1. Masukkan 2 bungkus bubuk agar-agar kedalam panci masukkan sisa air td (1300cc), sambil di aduk hingga bubuk agar2 nya larut.
1. Masak diatas kompor sampai mendidih smbil terus diaduk perlahan, kalau sudah mendidih masukkan ubi yang sudah dihaluskan perlahan smbil terus diaduk agar tercampur rata. Kemudian masukkan cream kental manis kedalam adonan agar2, tes rasa y bun jgn lupa. Kalau saya gx pakai gula lagi krn menurut sy manisny udh pas bgt, manisny didapat dr ubi itu sendri n krim kental manis td.
1. Kalau sudah tercampur rata, matikan kompor dan diamkan sebentar sampai uap panasnya hilang.
1. Setelah itu tuang kedalam cetakan (cetakannya bebas y bun) 😉. Lalu dinginkan dlm frezer smpai mengeras.
1. Puding siap dihidangkan dan dinikmati,
1. Lebih enak disantap pas cuaca panas y bun. Krn puding yg dingin bisa memberikan kesegaran jiwa dan raga




Demikianlah cara membuat puding ubi kuning yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
