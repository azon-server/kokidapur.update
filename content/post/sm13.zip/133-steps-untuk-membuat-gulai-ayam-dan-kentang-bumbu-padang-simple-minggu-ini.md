---
description: "Steps untuk membuat Gulai ayam dan kentang bumbu padang simple minggu ini"
title: "Steps untuk membuat Gulai ayam dan kentang bumbu padang simple minggu ini"
slug: 133-steps-untuk-membuat-gulai-ayam-dan-kentang-bumbu-padang-simple-minggu-ini
date: 2020-12-11T03:42:35.448Z
image: https://img-global.cpcdn.com/recipes/97e3bb2beeeaea79/680x482cq70/gulai-ayam-dan-kentang-bumbu-padang-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/97e3bb2beeeaea79/680x482cq70/gulai-ayam-dan-kentang-bumbu-padang-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/97e3bb2beeeaea79/680x482cq70/gulai-ayam-dan-kentang-bumbu-padang-simple-foto-resep-utama.jpg
author: Shane Thompson
ratingvalue: 4.1
reviewcount: 30686
recipeingredient:
- "1 kg ayam"
- "3 buah kentang"
- "1/2 kelapa atau santan cair"
- " Royco"
- " Garam"
- " Bumbu halus"
- "10 buah cabai merah optional jika mau pedas"
- "5 buah cabai rawit"
- "7 siung bawang merah"
- "5 siung bawang putih"
- "1 buah serai potong kecil kecil"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1 ruas kunyit"
- "1/2 sendok kecil bubuk ketumbar"
- " Bahan lain nya"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "1 lembar daun kunyit"
recipeinstructions:
- "Bersihkan 1kg ayam dengan air mengalir"
- "Blender halus bumbu, lalu tumis hingga harum. Minyak di banyakan sedikit. Lalu masukkan daun salam, daun kunyit dan daun jeruk. Tumis bersama bumbu."
- "Lalu masukkan ayam, tumis kembali sampai bumbu nya meresap."
- "Setelah itu masukkan santan, masukkan sedikit demi sedikit. Lalu aduk agar santan tidak pecah."
- "Lalu masukkan kentang yang sudah di potong, tuang santan,Tunggu hingga santan agak berkurang. Masukkan garam, dan royco."
- "Icip, dan tiriskan."
- "Selesaii"
categories:
- Recipe
tags:
- gulai
- ayam
- dan

katakunci: gulai ayam dan 
nutrition: 287 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Dessert

---


![Gulai ayam dan kentang bumbu padang simple](https://img-global.cpcdn.com/recipes/97e3bb2beeeaea79/680x482cq70/gulai-ayam-dan-kentang-bumbu-padang-simple-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga empuk. Karasteristik masakan Indonesia gulai ayam dan kentang bumbu padang simple yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Gulai ayam dan kentang bumbu padang simple untuk orang di rumah. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis makanan yang bisa anda praktekkan salah satunya gulai ayam dan kentang bumbu padang simple yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep gulai ayam dan kentang bumbu padang simple tanpa harus bersusah payah.
Berikut ini resep Gulai ayam dan kentang bumbu padang simple yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Gulai ayam dan kentang bumbu padang simple:

1. Harus ada 1 kg ayam
1. Harus ada 3 buah kentang
1. Dibutuhkan 1/2 kelapa atau santan cair
1. Siapkan  Royco
1. Diperlukan  Garam
1. Harap siapkan  Bumbu halus
1. Diperlukan 10 buah cabai merah (optional jika mau pedas)
1. Harap siapkan 5 buah cabai rawit
1. Dibutuhkan 7 siung bawang merah
1. Siapkan 5 siung bawang putih
1. Tambah 1 buah serai (potong kecil kecil)
1. Siapkan 1 ruas jahe
1. Dibutuhkan 1 ruas lengkuas
1. Jangan lupa 1 ruas kunyit
1. Diperlukan 1/2 sendok kecil bubuk ketumbar
1. Harus ada  Bahan lain nya
1. Dibutuhkan 3 lembar daun salam
1. Diperlukan 3 lembar daun jeruk
1. Tambah 1 lembar daun kunyit




<!--inarticleads2-->

##### Instruksi membuat  Gulai ayam dan kentang bumbu padang simple:

1. Bersihkan 1kg ayam dengan air mengalir
1. Blender halus bumbu, lalu tumis hingga harum. Minyak di banyakan sedikit. Lalu masukkan daun salam, daun kunyit dan daun jeruk. Tumis bersama bumbu.
1. Lalu masukkan ayam, tumis kembali sampai bumbu nya meresap.
1. Setelah itu masukkan santan, masukkan sedikit demi sedikit. Lalu aduk agar santan tidak pecah.
1. Lalu masukkan kentang yang sudah di potong, tuang santan,Tunggu hingga santan agak berkurang. Masukkan garam, dan royco.
1. Icip, dan tiriskan.
1. Selesaii




Demikianlah cara membuat gulai ayam dan kentang bumbu padang simple yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
