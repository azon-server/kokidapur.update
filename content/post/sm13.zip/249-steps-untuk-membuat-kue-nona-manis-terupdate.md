---
description: "Steps untuk membuat Kue Nona Manis terupdate"
title: "Steps untuk membuat Kue Nona Manis terupdate"
slug: 249-steps-untuk-membuat-kue-nona-manis-terupdate
date: 2020-11-09T22:07:34.920Z
image: https://img-global.cpcdn.com/recipes/2768ecdf9653d52a/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2768ecdf9653d52a/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2768ecdf9653d52a/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Olive French
ratingvalue: 5
reviewcount: 38137
recipeingredient:
- " Bahan A"
- "250 ml santan kekentalan sedang 65 ml santan instanair"
- "1 butir telur"
- "140 gr gula pasir"
- "140 gr terigu serbaguna"
- "1/2 sdt vanili"
- " Bahan B"
- "250 ml santan kekentalan sedang"
- "30 gr tepung maizena"
- "Sejumput garam"
- "1/4 sdt pasta talas"
- " Bahan C"
- "500 ml santan kekentalan sedang"
- "40 gr tepung beras"
- "1 sdm gula pasir"
- "Sejumput garam"
recipeinstructions:
- "Siapkan bahan A. Kocok lepas telur. Campur terigu, gula, dan vanili dalam satu wadah, aduk rata."
- "Tuang santan aduk rata. Lalu tuang telur kocok aduk rata. Saring adonan utk memastikan tidak bergerindil jadi nanti hasilnya mulus. Sisihkan."
- "Siapkan bahan B. Campur tepung maizena, gula, garam, aduk rata. Tuang santan aduk rata."
- "Tuang pasta talas, aduk rata. Lalu masak di api kecil, aduk-aduk terus sampai adonan kental dan meletup."
- "Masukkan adonan B ke dalam adonan A, aduk merata. Sisihkan."
- "Siapkan bahan C. Dalam panci campur semua, aduk rata. Masak dengan api kecil sambil diaduk terus sampai adonan kental dan meletup. Angkat, tunggu sampai hangat."
- "Siapkan cetakan kue talam, oles dengan minyak tipis-tipis. Setelah adonan C hangat masukkan le dalam botol kecap atau bisa juga pakai plastik segitiga spy mudah menuangnya. Tuang adonan ungu ke dalam cetakan 3/4 penuh, lalu semprotkan adonan putih di tengahnya. Lakukan sampai selesai."
- "Didihkan air kukusan, alasi tutupnya dgn serbet bersih. Kukus kue selama 15 menit."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 259 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT57M"
recipeyield: "1"
recipecategory: Lunch

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/2768ecdf9653d52a/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang setidaknya kita lestarikan karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti kue nona manis yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Nusantara



Keharmonisan rumah tangga dapat diperoleh dengan cara simple. Diantaranya adalah membuat makanan Kue Nona Manis untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang bisa anda buat salah satunya kue nona manis yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Jangan lupa  Bahan A
1. Harus ada 250 ml santan kekentalan sedang (65 ml santan instan+air)
1. Diperlukan 1 butir telur
1. Dibutuhkan 140 gr gula pasir
1. Diperlukan 140 gr terigu serbaguna
1. Diperlukan 1/2 sdt vanili
1. Harus ada  Bahan B
1. Tambah 250 ml santan kekentalan sedang
1. Harus ada 30 gr tepung maizena
1. Harus ada Sejumput garam
1. Dibutuhkan 1/4 sdt pasta talas
1. Siapkan  Bahan C
1. Diperlukan 500 ml santan kekentalan sedang
1. Harus ada 40 gr tepung beras
1. Dibutuhkan 1 sdm gula pasir
1. Diperlukan Sejumput garam




<!--inarticleads2-->

##### Cara membuat  Kue Nona Manis:

1. Siapkan bahan A. Kocok lepas telur. Campur terigu, gula, dan vanili dalam satu wadah, aduk rata.
1. Tuang santan aduk rata. Lalu tuang telur kocok aduk rata. Saring adonan utk memastikan tidak bergerindil jadi nanti hasilnya mulus. Sisihkan.
1. Siapkan bahan B. Campur tepung maizena, gula, garam, aduk rata. Tuang santan aduk rata.
1. Tuang pasta talas, aduk rata. Lalu masak di api kecil, aduk-aduk terus sampai adonan kental dan meletup.
1. Masukkan adonan B ke dalam adonan A, aduk merata. Sisihkan.
1. Siapkan bahan C. Dalam panci campur semua, aduk rata. Masak dengan api kecil sambil diaduk terus sampai adonan kental dan meletup. Angkat, tunggu sampai hangat.
1. Siapkan cetakan kue talam, oles dengan minyak tipis-tipis. Setelah adonan C hangat masukkan le dalam botol kecap atau bisa juga pakai plastik segitiga spy mudah menuangnya. Tuang adonan ungu ke dalam cetakan 3/4 penuh, lalu semprotkan adonan putih di tengahnya. Lakukan sampai selesai.
1. Didihkan air kukusan, alasi tutupnya dgn serbet bersih. Kukus kue selama 15 menit.




Demikianlah cara membuat kue nona manis yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat simple dan cepat, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
