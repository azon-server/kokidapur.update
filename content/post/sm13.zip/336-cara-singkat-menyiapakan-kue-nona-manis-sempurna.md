---
description: "Cara singkat menyiapakan Kue Nona Manis Sempurna"
title: "Cara singkat menyiapakan Kue Nona Manis Sempurna"
slug: 336-cara-singkat-menyiapakan-kue-nona-manis-sempurna
date: 2020-10-14T01:39:14.800Z
image: https://img-global.cpcdn.com/recipes/a2e1953855aa6b6f/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a2e1953855aa6b6f/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a2e1953855aa6b6f/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Philip Cannon
ratingvalue: 4.5
reviewcount: 24645
recipeingredient:
- " Bahan A"
- "250 ml santan kental"
- "50 gr tepung terigu protein sedang"
- "Sejumput garam"
- " Bahan B"
- "125 ml santan kentalsejumput garam"
- "20 gr gula pasir 1 sdm"
- "15 gr maizena 1 14 sdm"
- "1/2 sdt pasta pandan saya pakai secukupnya endapan pandan"
- " Bahan C"
- "1 butir telur ukuran kecil kalau besar cukup separuhnya saja"
- "125 ml santan kental"
- "40 gr gula pasir 2 sdm"
- "70 gr tepung terigu protein sedang"
recipeinstructions:
- "Olesi cetakan talam dengan minyak goreng tipis-tipis. Sisihkan."
- "Campur semua bahan A (adonan putih), aduk rata. Saring. Masak sambil diaduk-aduk dengan api kecil hingga meletup-letup. Matikan api. Aduk-aduk hingga licin, agak kental, tidak bergerindil. Biarkan dingin. Lalu masukkan ke dalam plastik segitiga. Sisihkan."
- "Campur semua bahan B lalu masak dengan api kecil sambil terus diaduk hingga meletup-letup dan menjadi adonan yang kental. Angkat lalu biarkan dingin. Sisihkan."
- "Bahan C: Kocok telur dan gula pasir dengan whisker hingga gula larut. Masukkan santan dan terigu secara bertahap sambil terus diaduk hingga rata dan tidak bergerindil. Masukkan adonan B (adonan hijau) secara bertahap, kocok dengan whisker hingga rata dan tidak bergerindil. Saring."
- "Didihkan air dalam dandang kukusan. Penutup kukusan dilapisi serbet bersih ya, supaya air tidak menetesi kue."
- "Sambil menunggu kukusan siap, tuang adonan hijau ke dalam cetakan setinggi 3/4 cetakannya. Setelah semua adonan hijau habis, semprotkan adonan putih ditengah adonan hijau(bagian ujung/moncong plastik agak dibenamkan ya). Tuang hingga hampir penuh. Lakukan hingga semua adonan habis."
- "Kukus selama 20 menit dengan api sedang cenderung kecil."
- "Matikan kompor, angkat lalu biarkan hingga dingin di dalam cetakan (supaya set). Setelah dingin, keluarkan dari cetakan."
- "Siap disajikan."
- "Enak. Ini bagian dalamnya."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 154 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Dessert

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/a2e1953855aa6b6f/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau gurih. Karasteristik makanan Nusantara kue nona manis yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Kue Nona Manis untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang bisa anda coba salah satunya kue nona manis yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 14 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis:

1. Harus ada  Bahan A:
1. Dibutuhkan 250 ml santan kental
1. Tambah 50 gr tepung terigu protein sedang
1. Dibutuhkan Sejumput garam
1. Harus ada  Bahan B:
1. Diperlukan 125 ml santan kental+sejumput garam
1. Jangan lupa 20 gr gula pasir (1 sdm)
1. Dibutuhkan 15 gr maizena (1 1/4 sdm)
1. Diperlukan 1/2 sdt pasta pandan (saya pakai secukupnya endapan pandan)
1. Jangan lupa  Bahan C:
1. Jangan lupa 1 butir telur ukuran kecil (kalau besar cukup separuhnya saja)
1. Harus ada 125 ml santan kental
1. Dibutuhkan 40 gr gula pasir (2 sdm)
1. Siapkan 70 gr tepung terigu protein sedang




<!--inarticleads2-->

##### Bagaimana membuat  Kue Nona Manis:

1. Olesi cetakan talam dengan minyak goreng tipis-tipis. Sisihkan.
1. Campur semua bahan A (adonan putih), aduk rata. Saring. Masak sambil diaduk-aduk dengan api kecil hingga meletup-letup. Matikan api. Aduk-aduk hingga licin, agak kental, tidak bergerindil. Biarkan dingin. Lalu masukkan ke dalam plastik segitiga. Sisihkan.
1. Campur semua bahan B lalu masak dengan api kecil sambil terus diaduk hingga meletup-letup dan menjadi adonan yang kental. Angkat lalu biarkan dingin. Sisihkan.
1. Bahan C: Kocok telur dan gula pasir dengan whisker hingga gula larut. Masukkan santan dan terigu secara bertahap sambil terus diaduk hingga rata dan tidak bergerindil. Masukkan adonan B (adonan hijau) secara bertahap, kocok dengan whisker hingga rata dan tidak bergerindil. Saring.
1. Didihkan air dalam dandang kukusan. Penutup kukusan dilapisi serbet bersih ya, supaya air tidak menetesi kue.
1. Sambil menunggu kukusan siap, tuang adonan hijau ke dalam cetakan setinggi 3/4 cetakannya. Setelah semua adonan hijau habis, semprotkan adonan putih ditengah adonan hijau(bagian ujung/moncong plastik agak dibenamkan ya). Tuang hingga hampir penuh. Lakukan hingga semua adonan habis.
1. Kukus selama 20 menit dengan api sedang cenderung kecil.
1. Matikan kompor, angkat lalu biarkan hingga dingin di dalam cetakan (supaya set). Setelah dingin, keluarkan dari cetakan.
1. Siap disajikan.
1. Enak. Ini bagian dalamnya.




Demikianlah cara membuat kue nona manis yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan terbukti, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
