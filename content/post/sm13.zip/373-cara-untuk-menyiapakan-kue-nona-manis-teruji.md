---
description: "Cara untuk menyiapakan Kue Nona Manis Teruji"
title: "Cara untuk menyiapakan Kue Nona Manis Teruji"
slug: 373-cara-untuk-menyiapakan-kue-nona-manis-teruji
date: 2020-11-21T01:28:54.761Z
image: https://img-global.cpcdn.com/recipes/89e449191119b5df/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/89e449191119b5df/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/89e449191119b5df/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Loretta Norman
ratingvalue: 4.5
reviewcount: 2213
recipeingredient:
- "3 santan instant  65 ml ditambah air hingga menjadi 1100 ml"
- " Bahan Hijau"
- "250 gr tepung terigu"
- "50 gr tepung beras"
- "200 gr gula pasir"
- "100 ml Susu Kental Manis"
- "2 butir telur ayam"
- "700 ml santan"
- "2 sdt pasta pandan"
- " Bahan putih"
- "2 sdm maizena"
- "2 sdm tepung terigu"
- "400 ml santan"
- "1/2 sdt garam"
recipeinstructions:
- "Kita buat vla putih. Campur semua bahan vla, aduk rata, rebus hingga kental dan meletup-letup, biarkan dingin."
- "Kita buat bahan hijau. Campurkan semua bahan, aduk hingga gula pasir larut. Agar tidak bergerindil bisa di saring."
- "Oleskan tipis-tipis minyak di cetakan. Isi cetakan dengan adonan hijau, kemudian taruh adonan putih di tengahnya (saya masukkan vla ke dalam piping bag kemudian saya semprotkan)."
- "Panaskan kukusan. Gunakan api sedang. Kukus adonan selama 10 menit, sampai adonan hijau mengeras. Angkat dan keluarkan dari cetakan saat sudah dingin. Kue Nona Manis siap dihidangkan."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 218 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Dinner

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/89e449191119b5df/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti kue nona manis yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa kesan tersendiri yang merupakan keragaman Kita

Kedekatan keluarga dapat didapat dengan cara sederhana. Diantaranya adalah membuat makanan Kue Nona Manis untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang bisa anda coba salah satunya kue nona manis yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 14 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis:

1. Harap siapkan 3 santan instant @ 65 ml ditambah air hingga menjadi 1100 ml
1. Siapkan  Bahan Hijau
1. Tambah 250 gr tepung terigu
1. Siapkan 50 gr tepung beras
1. Siapkan 200 gr gula pasir
1. Jangan lupa 100 ml Susu Kental Manis
1. Harus ada 2 butir telur ayam
1. Tambah 700 ml santan
1. Harus ada 2 sdt pasta pandan
1. Harap siapkan  Bahan putih
1. Diperlukan 2 sdm maizena
1. Jangan lupa 2 sdm tepung terigu
1. Jangan lupa 400 ml santan
1. Dibutuhkan 1/2 sdt garam




<!--inarticleads2-->

##### Langkah membuat  Kue Nona Manis:

1. Kita buat vla putih. Campur semua bahan vla, aduk rata, rebus hingga kental dan meletup-letup, biarkan dingin.
1. Kita buat bahan hijau. Campurkan semua bahan, aduk hingga gula pasir larut. Agar tidak bergerindil bisa di saring.
1. Oleskan tipis-tipis minyak di cetakan. Isi cetakan dengan adonan hijau, kemudian taruh adonan putih di tengahnya (saya masukkan vla ke dalam piping bag kemudian saya semprotkan).
1. Panaskan kukusan. Gunakan api sedang. Kukus adonan selama 10 menit, sampai adonan hijau mengeras. Angkat dan keluarkan dari cetakan saat sudah dingin. Kue Nona Manis siap dihidangkan.




Demikianlah cara membuat kue nona manis yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan teruji, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
