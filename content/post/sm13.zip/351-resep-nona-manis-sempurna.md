---
description: "Resep : Nona Manis Sempurna"
title: "Resep : Nona Manis Sempurna"
slug: 351-resep-nona-manis-sempurna
date: 2021-02-16T14:39:17.393Z
image: https://img-global.cpcdn.com/recipes/9259ecc186f15d64/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9259ecc186f15d64/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9259ecc186f15d64/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Virgie Tucker
ratingvalue: 4.7
reviewcount: 25895
recipeingredient:
- " Bahan 1"
- "3 butir telur"
- "1 cangkir gula pasir"
- "2 cangkir santan"
- "2 cangkir terigu"
- " Bahan 2"
- "1/2 cangkir tepung maizena"
- "1/2 cangkir gula pasir"
- "2 cangkir air santan pandan suji"
- "secukupnya Garam"
- " Bahan 3"
- "3 sdm tepung terigu"
- "2 cangkir santan kental"
- "secukupnya Garam"
- "1 sdm gula pasir"
recipeinstructions:
- "Bahan 1: kocok gula dgn telur hingga gula larut, lalu masukkan terigu."
- "Masukkan santan lalu aduk rata"
- "Bahan 2: campur semua bahan jadi satu, lalu masak diatas kompor sambil diaduk sampai meletup letup. Angkat"
- "Campurkan bahan 1 dan 2 dengan menggunakan mixer hingga tercampur rata. Sisihkan"
- "Bahan 3: campur semua bahan lalu masak sambil diaduk dgn whisk. Sampai mengental. Tes rasa kalo kurang garam.. bisa tambahkan sesuai selera. Saya suka rasa asin gurih"
- "Oles cetakan talam dengan minyak goreng"
- "Masukan adonan berwarna hijau (bahan 1 dan 2) sampai hampir penuh, lalu tuang adonan putih (bahan 3) dengan menggunakan sendok kecil di tengah adonan hijau. Lakukan sampai adonan habis"
- "Kukus dalam kukusan yg telah dipanaskan terlebih dahulu. Kue matang ketika sudah terlihat mengembang. Tapi jgn terlalu over cooking karna akan mengakibatkan bentuk kue menciut."
- "Setelah dingin keluarkan dari cetakan... dan siap di hidangkan untuk takjil buka puasa."
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 141 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Dinner

---


![Nona Manis](https://img-global.cpcdn.com/recipes/9259ecc186f15d64/680x482cq70/nona-manis-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang dapat kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti nona manis yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa ciri khas yang merupakan keragaman Kita



Kehangatan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan Nona Manis untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang bisa anda contoh salah satunya nona manis yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona Manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona Manis:

1. Tambah  Bahan 1:
1. Dibutuhkan 3 butir telur
1. Siapkan 1 cangkir gula pasir
1. Tambah 2 cangkir santan
1. Dibutuhkan 2 cangkir terigu
1. Siapkan  Bahan 2:
1. Jangan lupa 1/2 cangkir tepung maizena
1. Harap siapkan 1/2 cangkir gula pasir
1. Diperlukan 2 cangkir air santan pandan suji
1. Harus ada secukupnya Garam
1. Tambah  Bahan 3:
1. Harus ada 3 sdm tepung terigu
1. Harus ada 2 cangkir santan kental
1. Harus ada secukupnya Garam
1. Dibutuhkan 1 sdm gula pasir




<!--inarticleads2-->

##### Instruksi membuat  Nona Manis:

1. Bahan 1: kocok gula dgn telur hingga gula larut, lalu masukkan terigu.
1. Masukkan santan lalu aduk rata
1. Bahan 2: campur semua bahan jadi satu, lalu masak diatas kompor sambil diaduk sampai meletup letup. Angkat
1. Campurkan bahan 1 dan 2 dengan menggunakan mixer hingga tercampur rata. Sisihkan
1. Bahan 3: campur semua bahan lalu masak sambil diaduk dgn whisk. Sampai mengental. Tes rasa kalo kurang garam.. bisa tambahkan sesuai selera. Saya suka rasa asin gurih
1. Oles cetakan talam dengan minyak goreng
1. Masukan adonan berwarna hijau (bahan 1 dan 2) sampai hampir penuh, lalu tuang adonan putih (bahan 3) dengan menggunakan sendok kecil di tengah adonan hijau. Lakukan sampai adonan habis
1. Kukus dalam kukusan yg telah dipanaskan terlebih dahulu. Kue matang ketika sudah terlihat mengembang. Tapi jgn terlalu over cooking karna akan mengakibatkan bentuk kue menciut.
1. Setelah dingin keluarkan dari cetakan... dan siap di hidangkan untuk takjil buka puasa.




Demikianlah cara membuat nona manis yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
