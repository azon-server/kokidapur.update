---
description: "Cara membuat Kue Nona Manis minggu ini"
title: "Cara membuat Kue Nona Manis minggu ini"
slug: 376-cara-membuat-kue-nona-manis-minggu-ini
date: 2021-02-17T22:26:06.890Z
image: https://img-global.cpcdn.com/recipes/3b416f2dac2b0a68/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3b416f2dac2b0a68/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3b416f2dac2b0a68/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Peter Gilbert
ratingvalue: 4
reviewcount: 32611
recipeingredient:
- "150 gr maizena"
- "2 sache skm"
- "1 bonggol jagung manis pipil dan rebus sebentar"
- "Sejumput garam"
- "100 gr gula pasir"
- "60 gr santan kara"
- "200 cc air untuk maizena"
- "1 lembar pandan"
- "1000 cc air untuk santan"
recipeinstructions:
- "Masukkan"
- "Air, santan, gula, garam, skm dan daun pandan direbus hingga mendidih lalu masukkan jagung."
- "Setelah mendidih kembali masukkan larutan maizena secara perlahan dgn disaring."
- "Aduk sampai mendidih lalu tuang dalam cetakan. Jagung bisa juga diganti sagu mutiara, pisang, atau nangka. Selain dicetak, bisa juga dibungkus plastik satu persatu. Selamat mencoba 😍"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 203 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Lunch

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/3b416f2dac2b0a68/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan renyah. Karasteristik makanan Nusantara kue nona manis yang kaya dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak Kue Nona Manis untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang dapat anda praktekkan salah satunya kue nona manis yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 9 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Diperlukan 150 gr maizena
1. Diperlukan 2 sache skm
1. Jangan lupa 1 bonggol jagung manis, pipil dan rebus sebentar
1. Diperlukan Sejumput garam
1. Harap siapkan 100 gr gula pasir
1. Diperlukan 60 gr santan kara
1. Harap siapkan 200 cc air untuk maizena
1. Jangan lupa 1 lembar pandan
1. Harus ada 1000 cc air untuk santan




<!--inarticleads2-->

##### Bagaimana membuat  Kue Nona Manis:

1. Masukkan
1. Air, santan, gula, garam, skm dan daun pandan direbus hingga mendidih lalu masukkan jagung.
1. Setelah mendidih kembali masukkan larutan maizena secara perlahan dgn disaring.
1. Aduk sampai mendidih lalu tuang dalam cetakan. Jagung bisa juga diganti sagu mutiara, pisang, atau nangka. Selain dicetak, bisa juga dibungkus plastik satu persatu. Selamat mencoba 😍




Demikianlah cara membuat kue nona manis yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan terbukti, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
