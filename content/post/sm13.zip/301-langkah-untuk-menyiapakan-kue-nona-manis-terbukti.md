---
description: "Langkah untuk menyiapakan Kue Nona Manis Terbukti"
title: "Langkah untuk menyiapakan Kue Nona Manis Terbukti"
slug: 301-langkah-untuk-menyiapakan-kue-nona-manis-terbukti
date: 2021-01-15T17:22:13.385Z
image: https://img-global.cpcdn.com/recipes/004e518ba40a0978/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/004e518ba40a0978/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/004e518ba40a0978/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Edith Davidson
ratingvalue: 4.4
reviewcount: 26147
recipeingredient:
- " Bahan A "
- "1 butir telur kocok lepas"
- "125 gr gula pasir halus"
- "125 gr tepung terigu"
- "250 ml santan"
- " Bahan B "
- "125 ml santan"
- "125 ml jus pandan dr 810 lbr pandan  air blender  saring"
- "60 gr gula pasir halus"
- "30 gr tepung maizena"
- "1/2 sdt garam resep asli 1 sdt"
- "2 tetes pewarna hijau"
- " Bahan C inti putih "
- "250 ml santan kental segar"
- "1 sdm munjung tepung terigu"
- "1 sdm gula pasir"
- "1/4 sdt garam halus resep asli 1 sdt"
recipeinstructions:
- "Bahan A : Campur tepung terigu + gula halus. Tuang santan, aduk hingga tercampur rata (boleh pke whisker atau pun garpu). Tuang telur kocok, aduk rata."
- "Lalu saring biar hasil nya halus. Sisihkan."
- "Bahan B : Aduk semua bahan B jd satu."
- "Masak bahan B dg api kecil sambil di aduk hingga meletup.. Matikan api, angkat dan aduk². Masukkan bahan A."
- "Aduk hingga tercampur dg rata. Sisihkan."
- "Bahan C : aduk semua bahan C hingga tercampur rata. Lalu masak dg api kecil sambil di aduk hingga meletup². Angkat dan aduk². Selagi hangat masukkan ke dlm plastik segitiga (klo mau rapi hasil nya, masukkan ke dlm botol kecap/saus)"
- "Panaskan kukusan hingga beruap banyak. Siapkan cetakan kue mangkok. Oles tipis dg minyak goreng. Tuang adonan hijau sampai 2/3 tinggi cetakan. Lalu semprotkan adonan putih tepat di tengah² nya"
- "Setelah kukusan panas. Kukus kue hingga matang ±10-15 menit. (tutup kukusan di alasi serbet).. Keluarkan kue dr kukusan, biarkan hingga agak dingin baru keluarkan dr cetakan."
- "Kue nona manis siap di sajikan. (Hasil 24 buah). Semoga bermanfaat 💕💕"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 153 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dinner

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/004e518ba40a0978/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti kue nona manis yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa keistimewahan yang merupakan keragaman Kita

Kedekatan rumah tangga dapat ditemukan dengan cara simple. Salah satunya adalah membuat makanan Kue Nona Manis untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang bisa anda buat salah satunya kue nona manis yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini anda bisa dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis:

1. Harap siapkan  Bahan A :
1. Jangan lupa 1 butir telur, kocok lepas
1. Diperlukan 125 gr gula pasir halus
1. Siapkan 125 gr tepung terigu
1. Harap siapkan 250 ml santan
1. Siapkan  Bahan B :
1. Jangan lupa 125 ml santan
1. Siapkan 125 ml jus pandan (dr 8-10 lbr pandan + air, blender &amp; saring)
1. Harap siapkan 60 gr gula pasir halus
1. Jangan lupa 30 gr tepung maizena
1. Jangan lupa 1/2 sdt garam (resep asli 1 sdt)
1. Tambah 2 tetes pewarna hijau
1. Siapkan  Bahan C (inti putih) :
1. Tambah 250 ml santan kental segar
1. Diperlukan 1 sdm munjung tepung terigu
1. Tambah 1 sdm gula pasir
1. Diperlukan 1/4 sdt garam halus (resep asli 1 sdt)




<!--inarticleads2-->

##### Instruksi membuat  Kue Nona Manis:

1. Bahan A : Campur tepung terigu + gula halus. Tuang santan, aduk hingga tercampur rata (boleh pke whisker atau pun garpu). Tuang telur kocok, aduk rata.
1. Lalu saring biar hasil nya halus. Sisihkan.
1. Bahan B : Aduk semua bahan B jd satu.
1. Masak bahan B dg api kecil sambil di aduk hingga meletup.. Matikan api, angkat dan aduk². Masukkan bahan A.
1. Aduk hingga tercampur dg rata. Sisihkan.
1. Bahan C : aduk semua bahan C hingga tercampur rata. Lalu masak dg api kecil sambil di aduk hingga meletup². Angkat dan aduk². Selagi hangat masukkan ke dlm plastik segitiga (klo mau rapi hasil nya, masukkan ke dlm botol kecap/saus)
1. Panaskan kukusan hingga beruap banyak. Siapkan cetakan kue mangkok. Oles tipis dg minyak goreng. Tuang adonan hijau sampai 2/3 tinggi cetakan. Lalu semprotkan adonan putih tepat di tengah² nya
1. Setelah kukusan panas. Kukus kue hingga matang ±10-15 menit. (tutup kukusan di alasi serbet).. Keluarkan kue dr kukusan, biarkan hingga agak dingin baru keluarkan dr cetakan.
1. Kue nona manis siap di sajikan. (Hasil 24 buah). Semoga bermanfaat 💕💕




Demikianlah cara membuat kue nona manis yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan teruji, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
