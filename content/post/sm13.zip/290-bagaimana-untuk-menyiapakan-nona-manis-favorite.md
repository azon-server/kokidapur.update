---
description: "Bagaimana untuk menyiapakan Nona manis Favorite"
title: "Bagaimana untuk menyiapakan Nona manis Favorite"
slug: 290-bagaimana-untuk-menyiapakan-nona-manis-favorite
date: 2020-10-17T02:59:55.628Z
image: https://img-global.cpcdn.com/recipes/dc5ac4d146ef3d2c/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dc5ac4d146ef3d2c/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dc5ac4d146ef3d2c/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Johnny Jennings
ratingvalue: 4.7
reviewcount: 38072
recipeingredient:
- " Bahan A"
- "250 ml satan ketal"
- "1 butir telur"
- "80 gram gula halus"
- "140 gram terigu protein sedang"
- " Bahan B"
- "250 gram satan kental"
- "40 gram gula pasir"
- "30 gram tepung maizena"
- " Sari jus pandandaun pandandaun suji blender ambil sarinya"
- " Bahan C"
- "500 ml satan kental"
- "6 sedok makan tepung terigu"
- "sejumput Garam"
recipeinstructions:
- "Bahan A: mix telur dan gula sampai mengental masukan tepung dan satan secara bergatian sambil mix hingga tercampur rata dan tidak berkedil"
- "Bahan B: masak bahan B dengan api sedang hinggal mengental"
- "Setelah bahan B agak dingin masukan perlahan kebahan A sambil diaduk rata."
- "Bahan C: masak bahan hingga mengental angkat terus diaduk agar tidak berkedil,setelah agak dingin masukan kantung plastik segitiga"
- "Selanjutnya siapkan kukusan dan tutup dialasin serbet,sambil menunggu kukus mendidik.tuang adonan hijau ke dalam cetakan talam yang telah diolesin minyak sayur 3/4 dan setelah itu semprotkan adonan putih diditengah agak ditekan hingga penuh,ulangi sampai habis"
- "Kukus 15 menit angkat dan dinginkan.keluarin dari cetakan.selamat mencoba"
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 160 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dessert

---


![Nona manis](https://img-global.cpcdn.com/recipes/dc5ac4d146ef3d2c/680x482cq70/nona-manis-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti nona manis yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa kesan tersendiri yang merupakan keragaman Nusantara



Keharmonisan keluarga bisa ditemukan dengan cara simple. Salah satunya adalah membuat makanan Nona manis untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang bisa anda praktekkan salah satunya nona manis yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 14 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona manis:

1. Jangan lupa  Bahan A
1. Dibutuhkan 250 ml satan ketal
1. Jangan lupa 1 butir telur
1. Siapkan 80 gram gula halus
1. Harap siapkan 140 gram terigu protein sedang
1. Siapkan  Bahan B
1. Tambah 250 gram satan kental
1. Harus ada 40 gram gula pasir
1. Tambah 30 gram tepung maizena
1. Harap siapkan  Sari jus pandan(daun pandan+daun suji blender ambil sarinya)
1. Dibutuhkan  Bahan C:
1. Siapkan 500 ml satan kental
1. Siapkan 6 sedok makan tepung terigu
1. Harus ada sejumput Garam




<!--inarticleads2-->

##### Bagaimana membuat  Nona manis:

1. Bahan A: mix telur dan gula sampai mengental masukan tepung dan satan secara bergatian sambil mix hingga tercampur rata dan tidak berkedil
1. Bahan B: masak bahan B dengan api sedang hinggal mengental
1. Setelah bahan B agak dingin masukan perlahan kebahan A sambil diaduk rata.
1. Bahan C: masak bahan hingga mengental angkat terus diaduk agar tidak berkedil,setelah agak dingin masukan kantung plastik segitiga
1. Selanjutnya siapkan kukusan dan tutup dialasin serbet,sambil menunggu kukus mendidik.tuang adonan hijau ke dalam cetakan talam yang telah diolesin minyak sayur 3/4 dan setelah itu semprotkan adonan putih diditengah agak ditekan hingga penuh,ulangi sampai habis
1. Kukus 15 menit angkat dan dinginkan.keluarin dari cetakan.selamat mencoba




Demikianlah cara membuat nona manis yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan cepat, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
