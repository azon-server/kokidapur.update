---
description: "Resep : Kue nona manis minggu ini"
title: "Resep : Kue nona manis minggu ini"
slug: 348-resep-kue-nona-manis-minggu-ini
date: 2020-11-09T00:26:18.652Z
image: https://img-global.cpcdn.com/recipes/f9f5f0af11426d7d/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f9f5f0af11426d7d/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f9f5f0af11426d7d/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Elijah Hawkins
ratingvalue: 4
reviewcount: 20347
recipeingredient:
- " Bahan I "
- "3 Butir telur ayam"
- "2 Cangkir santan  384 ml"
- "2 Cangkir terigu  214 gr"
- "1 Cangkir gula pasir  222 gr"
- " Bahan II "
- "2 Cangkir santan santan diblender bersama daun pandan 10 lbr"
- "1/2 Cangkir Maizena  38 gr"
- "1/2 Cangkir gula pasir  111 gr"
- "1/2 sdt garam"
- " Bahan III "
- "2 Cangkir Santan kental  384 ml"
- "2 sdm Gula pasir"
- "2 Sdm Terigu"
- "1/2 sdt Garam"
recipeinstructions:
- "Bahan II : Campur santan suji, gula pasir dan maizena. Masak diatas kompor sambil diaduk terus sampai meletup-letup. Angkatdan biarkan sampai hangat-hangat kuku"
- "Bahan I : Kocok telur dan gula sampai mengembang. Turunkan kecepatan mixer, masukan terigu, kocok rata. Tuang santan lalu aduk hingga rata."
- "Campurkan adonan I dan II, gunakan mixer hingga tercampur rata. Sisihkan"
- "Panaskan dandang untuk mengukus"
- "Bahan III : Campur santan kental, gula, terigu dan garam. Aduk hingga rata dan tidak bergerindil. Masak sambil diaduk terus agar santan tidak pecah. Setelah mendidih angkat segera dari kompor"
- "Siapkan cetakan cucing yang sudah diolesi minyak. Tuang adonan pandan hingga hampir penuh. Beri tengahnya santan menggunakan sendok. Kukus selama kurlb 7-10 menit dengan panas sedang. Tergantung besar kecilnya cucing"
- "Angkat dari kukusan. Rendam didalam talam berisi air biasa agar mudah dilepaskan. Biarkan sebentar"
- ""
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 248 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Lunch

---


![Kue nona manis](https://img-global.cpcdn.com/recipes/f9f5f0af11426d7d/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang setidaknya kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti kue nona manis yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Nusantara

Kue nona manis adalah salah satu jajanan tradisional yang melegenda di Indonesia. Ada yang tahu kue nona manis? SALAH satu jajanan pasar kue nona manis rasanya sudah jarang ditemui. Meski langkahnya sedikit rumit, ada rasa puas tersendiri saat berhasil membuat kue nona manis.

Kedekatan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Kue nona manis untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang bisa anda praktekkan salah satunya kue nona manis yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue nona manis yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 8 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue nona manis:

1. Siapkan  Bahan I :
1. Siapkan 3 Butir telur ayam
1. Jangan lupa 2 Cangkir santan = 384 ml
1. Dibutuhkan 2 Cangkir terigu = 214 gr
1. Tambah 1 Cangkir gula pasir = 222 gr
1. Harap siapkan  Bahan II :
1. Siapkan 2 Cangkir santan (santan diblender bersama daun pandan 10 lbr)
1. Jangan lupa 1/2 Cangkir Maizena = 38 gr
1. Harap siapkan 1/2 Cangkir gula pasir = 111 gr
1. Jangan lupa 1/2 sdt garam
1. Diperlukan  Bahan III :
1. Harap siapkan 2 Cangkir Santan kental = 384 ml
1. Siapkan 2 sdm Gula pasir
1. Diperlukan 2 Sdm Terigu
1. Harus ada 1/2 sdt Garam


Nona manis adalah kue khas Sulawesi. Teksturnya lebih lembut dari kue talam Indonesia lainnya. Bagian yang berwarna hijau rasanya manis dan gurih santan, sedangkan bagian yang berwarna putih. Aih, sudah lama rasanya tidak mendengar Kue Nona Manis. 

<!--inarticleads2-->

##### Langkah membuat  Kue nona manis:

1. Bahan II : Campur santan suji, gula pasir dan maizena. Masak diatas kompor sambil diaduk terus sampai meletup-letup. Angkatdan biarkan sampai hangat-hangat kuku
1. Bahan I : Kocok telur dan gula sampai mengembang. Turunkan kecepatan mixer, masukan terigu, kocok rata. Tuang santan lalu aduk hingga rata.
1. Campurkan adonan I dan II, gunakan mixer hingga tercampur rata. Sisihkan
1. Panaskan dandang untuk mengukus
1. Bahan III : Campur santan kental, gula, terigu dan garam. Aduk hingga rata dan tidak bergerindil. Masak sambil diaduk terus agar santan tidak pecah. Setelah mendidih angkat segera dari kompor
1. Siapkan cetakan cucing yang sudah diolesi minyak. Tuang adonan pandan hingga hampir penuh. Beri tengahnya santan menggunakan sendok. Kukus selama kurlb 7-10 menit dengan panas sedang. Tergantung besar kecilnya cucing
1. Angkat dari kukusan. Rendam didalam talam berisi air biasa agar mudah dilepaskan. Biarkan sebentar
1. 


Bagian yang berwarna hijau rasanya manis dan gurih santan, sedangkan bagian yang berwarna putih. Aih, sudah lama rasanya tidak mendengar Kue Nona Manis. Camilan klasik ini bisa Bunda hadirkan kembali dengan warna menarik yang tidak akan ditolak oleh si kecil. Your current browser isn&#39;t compatible with SoundCloud. Please download one of our supported browsers. 

Demikianlah cara membuat kue nona manis yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan terbukti, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
