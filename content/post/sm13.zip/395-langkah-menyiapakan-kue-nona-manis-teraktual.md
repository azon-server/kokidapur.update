---
description: "Langkah menyiapakan Kue nona manis teraktual"
title: "Langkah menyiapakan Kue nona manis teraktual"
slug: 395-langkah-menyiapakan-kue-nona-manis-teraktual
date: 2021-03-03T14:07:28.213Z
image: https://img-global.cpcdn.com/recipes/556429885eb7ff79/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/556429885eb7ff79/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/556429885eb7ff79/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Gregory Reid
ratingvalue: 4.2
reviewcount: 31971
recipeingredient:
- " Bahan A"
- "420 gr tepung terigu"
- "750 ml santan sedang"
- "240 gula pasir"
- "3 butir telur"
- " Bahan B"
- "750 santan"
- "50 lembar daun suji"
- "10 lembar daun pandan"
- "120 gr gula pasir"
- "100 gr maizena"
- "1 sdt garam"
- " Bahan C"
- "1500 ml santan sedang"
- "300 gr tepung terigu"
- "1 sdt garam"
recipeinstructions:
- "Blender daun pandan dan suji bersama santan saring dan tambahkan tepung maizena gula pasir dan garam masak hingga mengental dan meletup letup angkat dan dinginkan"
- "Kocok telur dan gula pasir dengan kecepatan tinggi sampai kental dan berjejak lalu turunkan mixser hingga yang terkecil masukkan tepung terigu bersamaan dengan santan lalu masukkan adonan hijau yang (A) sudah dingin kocok lagi hingga tercampur rata lalu matikan mixer"
- "Buat bahan (C) campur santan tepung terigu dan santan aduk sampai tercampur dan tidak bergerindil masak hingga mendidih dan meletup letup angkat dan dinginkan"
- "Siapkan dandang pengukus biarkan mendidih sementara menunggu dandang mendidih"
- "Siapkan citakan kue mangkok yang sudah di olesi minyak goreng lalu isi dengan adonan warna hijau hampir penuh lalu tambahkan adonan putih di tengah tengah adonan hijau lalu kukus selama kurang lebih 25 menit hingga matang angkat dan dinginkan"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 127 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Dessert

---


![Kue nona manis](https://img-global.cpcdn.com/recipes/556429885eb7ff79/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti kue nona manis yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa ciri khas yang merupakan keragaman Indonesia

Kehangatan keluarga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Kue nona manis untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang dapat anda praktekkan salah satunya kue nona manis yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue nona manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue nona manis:

1. Diperlukan  Bahan A
1. Harap siapkan 420 gr tepung terigu
1. Harus ada 750 ml santan sedang
1. Diperlukan 240 gula pasir
1. Diperlukan 3 butir telur
1. Tambah  Bahan B
1. Harap siapkan 750 santan
1. Siapkan 50 lembar daun suji
1. Siapkan 10 lembar daun pandan
1. Diperlukan 120 gr gula pasir
1. Diperlukan 100 gr maizena
1. Siapkan 1 sdt garam
1. Harus ada  Bahan C
1. Harap siapkan 1500 ml santan sedang
1. Harus ada 300 gr tepung terigu
1. Tambah 1 sdt garam




<!--inarticleads2-->

##### Instruksi membuat  Kue nona manis:

1. Blender daun pandan dan suji bersama santan saring dan tambahkan tepung maizena gula pasir dan garam masak hingga mengental dan meletup letup angkat dan dinginkan
1. Kocok telur dan gula pasir dengan kecepatan tinggi sampai kental dan berjejak lalu turunkan mixser hingga yang terkecil masukkan tepung terigu bersamaan dengan santan lalu masukkan adonan hijau yang (A) sudah dingin kocok lagi hingga tercampur rata lalu matikan mixer
1. Buat bahan (C) campur santan tepung terigu dan santan aduk sampai tercampur dan tidak bergerindil masak hingga mendidih dan meletup letup angkat dan dinginkan
1. Siapkan dandang pengukus biarkan mendidih sementara menunggu dandang mendidih
1. Siapkan citakan kue mangkok yang sudah di olesi minyak goreng lalu isi dengan adonan warna hijau hampir penuh lalu tambahkan adonan putih di tengah tengah adonan hijau lalu kukus selama kurang lebih 25 menit hingga matang angkat dan dinginkan




Demikianlah cara membuat kue nona manis yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan teruji, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
