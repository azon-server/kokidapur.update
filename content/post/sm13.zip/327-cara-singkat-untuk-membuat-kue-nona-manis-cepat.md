---
description: "Cara singkat untuk membuat Kue Nona Manis Cepat"
title: "Cara singkat untuk membuat Kue Nona Manis Cepat"
slug: 327-cara-singkat-untuk-membuat-kue-nona-manis-cepat
date: 2020-11-02T05:12:21.046Z
image: https://img-global.cpcdn.com/recipes/17497221d7256314/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/17497221d7256314/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/17497221d7256314/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Bettie Reed
ratingvalue: 4.4
reviewcount: 45242
recipeingredient:
- " bahan 1 "
- "250 ml santan kental"
- "40 gram gula pasir"
- "30 gram maizena"
- "Sejumput garam"
- "Secukupnya pasta pandanpewarna hijau daun"
- " bahan 2 "
- "250 ml santan kental"
- "1 butir telur"
- "80 gram gula pasir"
- "140 gram terigu"
- " bahan 3 "
- "500 ml santan kental"
- "6 sdm terigu"
- "Sejumput garam"
recipeinstructions:
- "Rebus semua bahan ke 1 dengan api sedang hingga kental, sisihkan hingga agak dingin"
- "Siapkan bahan ke 2, mikser gula dan telur hingga kental masukkan terigu serta santan bergantian dimikser dengan kecepatan rendah hingga rata"
- "Tambahkan adonan bahan ke 1 kedalam adonan ke 2 aduk rata"
- "Siapkan bahan ke 3, rebus semua bahan hingga mengental dan diaduk sampai tidak bergerindil tuangkan diplastik botol atau pakai piping bag segitiga yg di potong ujungnya."
- "Siapkan cetakan yang telah diolesi minyak tipis, sambil mengoles panaskan kukusan, isi dengan adonan hijau 3/4 lalu tambahkan adonan putihnya hingga penuh"
- "Kukus selama 15 menit dengan api kecil agar tidak berkerut dan tidak bergolak. Tutup kukusan dengan serbet. Diamkan hingga dingin baru dikeluarkan dari cetakan, sajikan."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 112 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Dinner

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/17497221d7256314/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga enak. Karasteristik kuliner Indonesia kue nona manis yang kaya dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Kue Nona Manis untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang dapat anda praktekkan salah satunya kue nona manis yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 15 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis:

1. Jangan lupa  bahan 1 :
1. Dibutuhkan 250 ml santan kental
1. Diperlukan 40 gram gula pasir
1. Harap siapkan 30 gram maizena
1. Harus ada Sejumput garam
1. Siapkan Secukupnya pasta pandan/pewarna hijau daun
1. Harus ada  bahan 2 :
1. Dibutuhkan 250 ml santan kental
1. Jangan lupa 1 butir telur
1. Tambah 80 gram gula pasir
1. Harus ada 140 gram terigu
1. Jangan lupa  bahan 3 :
1. Diperlukan 500 ml santan kental
1. Tambah 6 sdm terigu
1. Jangan lupa Sejumput garam




<!--inarticleads2-->

##### Instruksi membuat  Kue Nona Manis:

1. Rebus semua bahan ke 1 dengan api sedang hingga kental, sisihkan hingga agak dingin
1. Siapkan bahan ke 2, mikser gula dan telur hingga kental masukkan terigu serta santan bergantian dimikser dengan kecepatan rendah hingga rata
1. Tambahkan adonan bahan ke 1 kedalam adonan ke 2 aduk rata
1. Siapkan bahan ke 3, rebus semua bahan hingga mengental dan diaduk sampai tidak bergerindil tuangkan diplastik botol atau pakai piping bag segitiga yg di potong ujungnya.
1. Siapkan cetakan yang telah diolesi minyak tipis, sambil mengoles panaskan kukusan, isi dengan adonan hijau 3/4 lalu tambahkan adonan putihnya hingga penuh
1. Kukus selama 15 menit dengan api kecil agar tidak berkerut dan tidak bergolak. Tutup kukusan dengan serbet. Diamkan hingga dingin baru dikeluarkan dari cetakan, sajikan.




Demikianlah cara membuat kue nona manis yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
