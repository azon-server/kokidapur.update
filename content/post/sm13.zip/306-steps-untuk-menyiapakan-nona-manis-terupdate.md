---
description: "Steps untuk menyiapakan Nona Manis terupdate"
title: "Steps untuk menyiapakan Nona Manis terupdate"
slug: 306-steps-untuk-menyiapakan-nona-manis-terupdate
date: 2021-02-17T12:05:59.492Z
image: https://img-global.cpcdn.com/recipes/8db77baabe0d5108/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8db77baabe0d5108/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8db77baabe0d5108/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Myrtle Cox
ratingvalue: 4.5
reviewcount: 24135
recipeingredient:
- "1 Bahan"
- "250 ml santan kelapa"
- "1 btr telur"
- "80 gr gula pasir"
- "140 gr terigu"
- "2 Bahan"
- "250 ml santan kelapa"
- "40 gr gula pasir"
- "30 gr maizena"
- "Secukupnya pasta pandan"
- "Sejumput garam"
- "3 Bahan"
- "500 ml santan kelapa"
- "3 sdm tepung terigu"
- "Sejumput garam"
recipeinstructions:
- "Bahan 1 : Mixer telur dan gula sampai mengental kemudian masukkan terigu bergantian dengan santan aduk sampai rata. Sisihkan"
- "Bahan 2 : Campur santan, gula dan maizena aduk rata sampai tidak ada yg bergerindil tambahkan pasta dan garam lalu masak dengan api sedang hingga mengental. Matikan dan diamkan sampai hangat lalu masukkan kedalam adonan 1 mixer sampai tercampur rata. Sisihkan"
- "Bahan 3 : Campur santan, terigu dan garam aduk hingga tercampur rata lalu masak hingga mengental. Diamkan sampai dingin lalu masukkan kedalam botol plastik yg ujung runcing untuk memudahkan pengisian."
- "Panaskan kukusan, siapkan cetakan talam yg sudah diolesi minyak sedikit lalu tuang adonan hijau 3/4 dr cetakan semprotkan bahan 3 ke tengah adonan hijau agak di celupkan moncong botolnya isi hingga penuh. Lakukan sampai habis kukus slm 10 menit."
- "Jika sdh matang biarkan dingin terlebih dahulu untuk melepasnya."
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 248 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Dessert

---


![Nona Manis](https://img-global.cpcdn.com/recipes/8db77baabe0d5108/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau renyah. Karasteristik makanan Indonesia nona manis yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kehangatan rumah tangga bisa ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Nona Manis untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang dapat anda coba salah satunya nona manis yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona Manis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona Manis:

1. Diperlukan 1 Bahan
1. Harus ada 250 ml santan kelapa
1. Harap siapkan 1 btr telur
1. Harap siapkan 80 gr gula pasir
1. Harus ada 140 gr terigu
1. Tambah 2 Bahan
1. Tambah 250 ml santan kelapa
1. Harus ada 40 gr gula pasir
1. Siapkan 30 gr maizena
1. Jangan lupa Secukupnya pasta pandan
1. Dibutuhkan Sejumput garam
1. Tambah 3 Bahan
1. Siapkan 500 ml santan kelapa
1. Siapkan 3 sdm tepung terigu
1. Tambah Sejumput garam




<!--inarticleads2-->

##### Bagaimana membuat  Nona Manis:

1. Bahan 1 : Mixer telur dan gula sampai mengental kemudian masukkan terigu bergantian dengan santan aduk sampai rata. Sisihkan
1. Bahan 2 : Campur santan, gula dan maizena aduk rata sampai tidak ada yg bergerindil tambahkan pasta dan garam lalu masak dengan api sedang hingga mengental. Matikan dan diamkan sampai hangat lalu masukkan kedalam adonan 1 mixer sampai tercampur rata. Sisihkan
1. Bahan 3 : Campur santan, terigu dan garam aduk hingga tercampur rata lalu masak hingga mengental. Diamkan sampai dingin lalu masukkan kedalam botol plastik yg ujung runcing untuk memudahkan pengisian.
1. Panaskan kukusan, siapkan cetakan talam yg sudah diolesi minyak sedikit lalu tuang adonan hijau 3/4 dr cetakan semprotkan bahan 3 ke tengah adonan hijau agak di celupkan moncong botolnya isi hingga penuh. Lakukan sampai habis kukus slm 10 menit.
1. Jika sdh matang biarkan dingin terlebih dahulu untuk melepasnya.




Demikianlah cara membuat nona manis yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan cepat, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
