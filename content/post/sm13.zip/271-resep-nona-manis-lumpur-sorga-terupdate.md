---
description: "Resep : Nona Manis / Lumpur Sorga terupdate"
title: "Resep : Nona Manis / Lumpur Sorga terupdate"
slug: 271-resep-nona-manis-lumpur-sorga-terupdate
date: 2020-11-17T15:49:51.008Z
image: https://img-global.cpcdn.com/recipes/0ffd611d8ca4b938/680x482cq70/nona-manis-lumpur-sorga-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0ffd611d8ca4b938/680x482cq70/nona-manis-lumpur-sorga-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0ffd611d8ca4b938/680x482cq70/nona-manis-lumpur-sorga-foto-resep-utama.jpg
author: Elva Mann
ratingvalue: 4.7
reviewcount: 3362
recipeingredient:
- " Bahan A"
- "175 ml santan kental instan"
- " 250 ml air"
- "40 gr tepung terigu serbaguna"
- "1/2 sdt garam"
- " Bahan B "
- "100 gr gula halus"
- "100 gr terigu serbaguna"
- "90 ml santan kental instan"
- "1 telor ayam ukuran besar"
- " Bahan C"
- "50 gr gula halus"
- "30 gr maezena"
- "90 ml santan kental instan"
- "180 ml air daun pandan"
- "10 batang daun pandan potong kecil"
- "1/2 sdt garam"
- "2 tetes pewarna hijau"
recipeinstructions:
- "Bahan A: campur santan, tepung terigu, garam, air, aduk menggunakan wisk, sampai tercampur rata, masak sampai meletup letup sambil terus diaduk, matikan api, kalau masih ada bergindil, saring sebelum masuk botol &amp; dinginkan suhu ruang"
- "Bahan B: kocok lepas telor ayam dlm mangkuk. Dlm bowl masukkan gula halus, terigu, santan, air aduk rata dg wisk, baru masuk telor yg dikocok, aduk kembali, kalau ada bergindil bisa saring dahulu, sisihkan"
- "Bahan C : - Blender daun pandan dengan air 200 ml, saring ambil air pandan 160 ml - Campur gula halus, maezena, santan, air pandan, garam, pewarna hijau, aduk rata dg wisk, masak dengan api kecil sampai mengental, angkat dinginkan"
- "Campurkan adonan B ke adonan C, aduk sampai tercampur rata, hasil ahir aga encer, tuang kedalam gelas ukur"
- "Panaskan kukusan, tutup kukusan balut dg kain - Oles tipis cetakan dg minyak goreng, tuang adonan C sampai 3/4 cetakan - Semprotkan bahan A sampai ujung botol masuk adonan - Kukus dengan api sedang 20-25 menit, tunggu dingin baru lepaskan dr cetakan, jangan lepaskan suhu masih panas, bisa merusak kue - Nona manis dapat 30 buah"
categories:
- Recipe
tags:
- nona
- manis
- 

katakunci: nona manis  
nutrition: 276 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dinner

---


![Nona Manis / Lumpur Sorga](https://img-global.cpcdn.com/recipes/0ffd611d8ca4b938/680x482cq70/nona-manis-lumpur-sorga-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang dapat kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti nona manis / lumpur sorga yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan ciri khas yang merupakan keragaman Kita

Kedekatan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Nona Manis / Lumpur Sorga untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang bisa anda buat salah satunya nona manis / lumpur sorga yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep nona manis / lumpur sorga tanpa harus bersusah payah.
Berikut ini resep Nona Manis / Lumpur Sorga yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona Manis / Lumpur Sorga:

1. Jangan lupa  Bahan A
1. Jangan lupa 175 ml santan kental instan
1. Diperlukan  250 ml air
1. Harap siapkan 40 gr tepung terigu serbaguna
1. Harus ada 1/2 sdt garam
1. Siapkan  Bahan B :
1. Dibutuhkan 100 gr gula halus
1. Tambah 100 gr terigu serbaguna
1. Jangan lupa 90 ml santan kental instan
1. Dibutuhkan 1 telor ayam ukuran besar
1. Diperlukan  Bahan C
1. Dibutuhkan 50 gr gula halus
1. Harap siapkan 30 gr maezena
1. Tambah 90 ml santan kental instan
1. Harap siapkan 180 ml air daun pandan
1. Siapkan 10 batang daun pandan, potong kecil
1. Siapkan 1/2 sdt garam
1. Harap siapkan 2 tetes pewarna hijau




<!--inarticleads2-->

##### Bagaimana membuat  Nona Manis / Lumpur Sorga:

1. Bahan A: campur santan, tepung terigu, garam, air, aduk menggunakan wisk, sampai tercampur rata, masak sampai meletup letup sambil terus diaduk, matikan api, kalau masih ada bergindil, saring sebelum masuk botol &amp; dinginkan suhu ruang
1. Bahan B: kocok lepas telor ayam dlm mangkuk. Dlm bowl masukkan gula halus, terigu, santan, air aduk rata dg wisk, baru masuk telor yg dikocok, aduk kembali, kalau ada bergindil bisa saring dahulu, sisihkan
1. Bahan C : - Blender daun pandan dengan air 200 ml, saring ambil air pandan 160 ml - Campur gula halus, maezena, santan, air pandan, garam, pewarna hijau, aduk rata dg wisk, masak dengan api kecil sampai mengental, angkat dinginkan
1. Campurkan adonan B ke adonan C, aduk sampai tercampur rata, hasil ahir aga encer, tuang kedalam gelas ukur
1. Panaskan kukusan, tutup kukusan balut dg kain - Oles tipis cetakan dg minyak goreng, tuang adonan C sampai 3/4 cetakan - Semprotkan bahan A sampai ujung botol masuk adonan - Kukus dengan api sedang 20-25 menit, tunggu dingin baru lepaskan dr cetakan, jangan lepaskan suhu masih panas, bisa merusak kue - Nona manis dapat 30 buah




Demikianlah cara membuat nona manis / lumpur sorga yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
