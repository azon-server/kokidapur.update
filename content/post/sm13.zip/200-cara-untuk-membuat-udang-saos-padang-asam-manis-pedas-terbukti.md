---
description: "Cara untuk membuat Udang Saos Padang Asam Manis Pedas Terbukti"
title: "Cara untuk membuat Udang Saos Padang Asam Manis Pedas Terbukti"
slug: 200-cara-untuk-membuat-udang-saos-padang-asam-manis-pedas-terbukti
date: 2020-10-28T11:31:39.079Z
image: https://img-global.cpcdn.com/recipes/a173d1729da8d19a/680x482cq70/udang-saos-padang-asam-manis-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a173d1729da8d19a/680x482cq70/udang-saos-padang-asam-manis-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a173d1729da8d19a/680x482cq70/udang-saos-padang-asam-manis-pedas-foto-resep-utama.jpg
author: Cecelia Todd
ratingvalue: 4.7
reviewcount: 2452
recipeingredient:
- "500 gr Udang"
- "1 buah Jagung"
- "1 Buah tomat blender sebagai saosnya"
- "1 tangkai daun bawang"
- "10 sdm saos sambal saya ABC"
- "2 sdm kecap manis"
- "1 sdt Lada"
- "1/4 sdt garam halus"
- "1/4 sdt kaldu bubuk saya royco ayam"
- "1 sdm gula pasir"
- " Air secukupnya kurleb 80ml"
- " Bumbu Halus"
- "5 Cabe Merah"
- "10 Cabe rawit saya pake rawit setan merah"
- "4 siung bawang merah"
- "2 siung bawang putih"
- " Bumbu cemplung"
- "2 siung bawang putih iris2"
- "1 buah bawang bombay iris2"
- "2 lembar daun jeruk"
- "1 batang serai di memarkan"
recipeinstructions:
- "Bersihkan udang, buang kepala dan kulitnya sampe ekor, taburkan garam 1/4 sdt teh, diamkan 15 menit, lalu cuci bersih2, lalu goreng sebentar"
- "Tumis minyak manis, masukan bumbu cempung, disusul bumbu halus, sampai harus masukan udang dan jagung, sampai udang berubah warna masukan air"
- "Masukan saos sambal, saos tomat, kecap, lada, garam, penyedap, gula,(jgn lupa icip2 dulu)setelah mendidih sedikit masukan daun bawang, jadi deh :)"
categories:
- Recipe
tags:
- udang
- saos
- padang

katakunci: udang saos padang 
nutrition: 259 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT41M"
recipeyield: "2"
recipecategory: Dessert

---


![Udang Saos Padang Asam Manis Pedas](https://img-global.cpcdn.com/recipes/a173d1729da8d19a/680x482cq70/udang-saos-padang-asam-manis-pedas-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga empuk. Ciri kuliner Indonesia udang saos padang asam manis pedas yang penuh dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Udang Saos Padang Asam Manis Pedas untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang dapat anda coba salah satunya udang saos padang asam manis pedas yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep udang saos padang asam manis pedas tanpa harus bersusah payah.
Seperti resep Udang Saos Padang Asam Manis Pedas yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Udang Saos Padang Asam Manis Pedas:

1. Jangan lupa 500 gr Udang
1. Dibutuhkan 1 buah Jagung
1. Dibutuhkan 1 Buah tomat (blender) sebagai saosnya
1. Diperlukan 1 tangkai daun bawang
1. Jangan lupa 10 sdm saos sambal (saya ABC)
1. Siapkan 2 sdm kecap manis
1. Harus ada 1 sdt Lada
1. Diperlukan 1/4 sdt garam halus
1. Harap siapkan 1/4 sdt kaldu bubuk (saya royco ayam)
1. Dibutuhkan 1 sdm gula pasir
1. Siapkan  Air secukupnya kurleb 80ml
1. Harap siapkan  Bumbu Halus
1. Dibutuhkan 5 Cabe Merah
1. Harap siapkan 10 Cabe rawit (saya pake rawit setan merah)
1. Dibutuhkan 4 siung bawang merah
1. Tambah 2 siung bawang putih
1. Harus ada  Bumbu cemplung
1. Siapkan 2 siung bawang putih iris2
1. Siapkan 1 buah bawang bombay iris2
1. Siapkan 2 lembar daun jeruk
1. Dibutuhkan 1 batang serai di memarkan




<!--inarticleads2-->

##### Instruksi membuat  Udang Saos Padang Asam Manis Pedas:

1. Bersihkan udang, buang kepala dan kulitnya sampe ekor, taburkan garam 1/4 sdt teh, diamkan 15 menit, lalu cuci bersih2, lalu goreng sebentar
1. Tumis minyak manis, masukan bumbu cempung, disusul bumbu halus, sampai harus masukan udang dan jagung, sampai udang berubah warna masukan air
1. Masukan saos sambal, saos tomat, kecap, lada, garam, penyedap, gula,(jgn lupa icip2 dulu)setelah mendidih sedikit masukan daun bawang, jadi deh :)
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Udang Saos Padang Asam Manis Pedas">



Demikianlah cara membuat udang saos padang asam manis pedas yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan cepat, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
