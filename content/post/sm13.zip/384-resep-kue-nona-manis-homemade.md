---
description: "Resep : Kue Nona Manis Homemade"
title: "Resep : Kue Nona Manis Homemade"
slug: 384-resep-kue-nona-manis-homemade
date: 2021-01-09T16:22:37.353Z
image: https://img-global.cpcdn.com/recipes/6d87f203ce9922d3/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6d87f203ce9922d3/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6d87f203ce9922d3/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Jerome Carlson
ratingvalue: 4
reviewcount: 45704
recipeingredient:
- "1 bahan"
- " 1 12 gelas santan kental"
- " 5 sdm tepung beras"
- " 1 sdm gula pasir"
- " 14 garam"
- " bahan 2 di blender"
- " 1 gelas santan textur sedang"
- " 1 butir telur ukuran sedang"
- " 9 sdm gula pasir"
- " 14 sdm tepung terigu"
- " 12 sdt vanili"
- "3 Bahan"
- " 1 12 gelas santan textur sedang"
- " 12 sdt perisa pandan"
- " 14 garam"
recipeinstructions:
- "Campurkan semua bahan 1 lalu aduk menggunakan tangan agar tepung larut dan tidak menggrindil, masak dengan api sedang sampai kental tetapi tidak seperti textur bubur sum sum pada umumnya. Angkat dan tutup rapat."
- "Campur kan semua bahan 2 lalu blender sampai semua tercampur rata"
- "Campurkan semua bahan 3, sama seperti bahan 1, campur menggunakan tangan sampai larut"
- "Campurkan bahan 2 dan bahan 3, masak dengan api kecil sampai seperti textur kecap."
- "Masukkan Kedalam cetakan hingga setengahnya,lalu masukkan bahan sum sum tadi di tengahnya. Kukus hingga 20 menit dan tutup dengan dandang yg sudah di lapisi kain"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 153 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Dinner

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/6d87f203ce9922d3/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan empuk. Ciri masakan Nusantara kue nona manis yang kaya dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Kue Nona Manis untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang bisa anda contoh salah satunya kue nona manis yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 15 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Dibutuhkan 1 bahan
1. Siapkan  1 1/2 gelas santan kental
1. Harap siapkan  5 sdm tepung beras
1. Harus ada  1 sdm gula pasir
1. Jangan lupa  1/4 garam
1. Dibutuhkan  bahan 2 (di blender)
1. Jangan lupa  1 gelas santan textur sedang
1. Tambah  1 butir telur ukuran sedang
1. Jangan lupa  9 sdm gula pasir
1. Harap siapkan  14 sdm tepung terigu
1. Tambah  1/2 sdt vanili
1. Harus ada 3 Bahan
1. Dibutuhkan  1 1/2 gelas santan textur sedang
1. Diperlukan  1/2 sdt perisa pandan
1. Tambah  1/4 garam




<!--inarticleads2-->

##### Langkah membuat  Kue Nona Manis:

1. Campurkan semua bahan 1 lalu aduk menggunakan tangan agar tepung larut dan tidak menggrindil, masak dengan api sedang sampai kental tetapi tidak seperti textur bubur sum sum pada umumnya. Angkat dan tutup rapat.
1. Campur kan semua bahan 2 lalu blender sampai semua tercampur rata
1. Campurkan semua bahan 3, sama seperti bahan 1, campur menggunakan tangan sampai larut
1. Campurkan bahan 2 dan bahan 3, masak dengan api kecil sampai seperti textur kecap.
1. Masukkan Kedalam cetakan hingga setengahnya,lalu masukkan bahan sum sum tadi di tengahnya. Kukus hingga 20 menit dan tutup dengan dandang yg sudah di lapisi kain




Demikianlah cara membuat kue nona manis yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
