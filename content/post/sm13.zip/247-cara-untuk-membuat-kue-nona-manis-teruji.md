---
description: "Cara untuk membuat Kue nona manis Teruji"
title: "Cara untuk membuat Kue nona manis Teruji"
slug: 247-cara-untuk-membuat-kue-nona-manis-teruji
date: 2021-01-18T20:35:28.503Z
image: https://img-global.cpcdn.com/recipes/b9acf43b7fe42102/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b9acf43b7fe42102/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b9acf43b7fe42102/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Alfred Holland
ratingvalue: 4
reviewcount: 18357
recipeingredient:
- " Bahan A"
- "1 butir telur"
- "100 gr gula pasir"
- "145 gr tepung terigu"
- "250 ml santan saya pake 1 kara segitiga dicairkan"
- " Bahan B"
- "250 ml santan saya pake 1 kara segitiga dicairkan"
- "55 gr gula pasir"
- "30 gr tepung maizena"
- "1 sdt pasta pandan"
- "1/4 sdt garam"
- " Bahan C"
- "250 ml santan saya pake 1 kara segitiga dicairkan"
- "1 sdm gula pasir"
- "1 sdm tepung terigu"
- "1/2 sdt garam"
recipeinstructions:
- "Masak bahan C hingga meletup-letup dengan api sedang, lalu sisihkan dan biarkan dingin, masukan ke dalam botol saos atau pipping bag"
- "Masak bahan B hingga meletup-letup, sisihkan"
- "Kocok telur dengan gula hingga mengembang"
- "Ditempat lain aduk tepung terigu dengan santan"
- "Setelah telur dan gula terkocok dan mengembang, masukkan campuran tepung dan santan"
- "Masukkan bahan B kedalam adonan, kocok lagi hingga rata"
- "Siapkan cetakan kue talam, olesi sedikit minyak, tuangkan adonan 3/4 cetakan, kemudian beri adonan C ditengah2 nya sedikit saja"
- "Kukus di panci yg airnya sudah mendidih selama 10mnt, angkat, dinginkan sedikit, lalu keluarkan dari cetakan dan hias dengan potongan pandan"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 105 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Dinner

---


![Kue nona manis](https://img-global.cpcdn.com/recipes/b9acf43b7fe42102/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan empuk. Ciri kuliner Indonesia kue nona manis yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga dapat ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Kue nona manis untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang bisa anda contoh salah satunya kue nona manis yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue nona manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue nona manis:

1. Siapkan  Bahan A
1. Tambah 1 butir telur
1. Jangan lupa 100 gr gula pasir
1. Jangan lupa 145 gr tepung terigu
1. Jangan lupa 250 ml santan (saya pake 1 kara segitiga dicairkan)
1. Diperlukan  Bahan B
1. Dibutuhkan 250 ml santan (saya pake 1 kara segitiga dicairkan)
1. Harus ada 55 gr gula pasir
1. Tambah 30 gr tepung maizena
1. Tambah 1 sdt pasta pandan
1. Harap siapkan 1/4 sdt garam
1. Tambah  Bahan C
1. Harus ada 250 ml santan (saya pake 1 kara segitiga dicairkan)
1. Diperlukan 1 sdm gula pasir
1. Siapkan 1 sdm tepung terigu
1. Dibutuhkan 1/2 sdt garam




<!--inarticleads2-->

##### Cara membuat  Kue nona manis:

1. Masak bahan C hingga meletup-letup dengan api sedang, lalu sisihkan dan biarkan dingin, masukan ke dalam botol saos atau pipping bag
1. Masak bahan B hingga meletup-letup, sisihkan
1. Kocok telur dengan gula hingga mengembang
1. Ditempat lain aduk tepung terigu dengan santan
1. Setelah telur dan gula terkocok dan mengembang, masukkan campuran tepung dan santan
1. Masukkan bahan B kedalam adonan, kocok lagi hingga rata
1. Siapkan cetakan kue talam, olesi sedikit minyak, tuangkan adonan 3/4 cetakan, kemudian beri adonan C ditengah2 nya sedikit saja
1. Kukus di panci yg airnya sudah mendidih selama 10mnt, angkat, dinginkan sedikit, lalu keluarkan dari cetakan dan hias dengan potongan pandan




Demikianlah cara membuat kue nona manis yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
