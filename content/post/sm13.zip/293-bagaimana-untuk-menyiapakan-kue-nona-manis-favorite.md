---
description: "Bagaimana untuk menyiapakan Kue Nona Manis Favorite"
title: "Bagaimana untuk menyiapakan Kue Nona Manis Favorite"
slug: 293-bagaimana-untuk-menyiapakan-kue-nona-manis-favorite
date: 2020-12-12T11:29:04.847Z
image: https://img-global.cpcdn.com/recipes/55c424da32f7d49d/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/55c424da32f7d49d/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/55c424da32f7d49d/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Hulda Vargas
ratingvalue: 4.1
reviewcount: 42232
recipeingredient:
- " Bahan A"
- "500 ml santan kental sedang"
- "40 gr tepung beras"
- "Secukupnya garam"
- "Secukupnya vanili"
- " Bahan B"
- "30 gr tepung beras"
- "200 ml air"
- "1 sdt pasta pandan"
- "Secukupnya garam"
- " Bahan C"
- "250 ml santan kental"
- "130 gr terigu"
- "140 gr gula pasir"
- "1 btr telur"
- "Secukupnya vanili"
recipeinstructions:
- "Campur semua bahan A kedalam panci aduk rata, baru masak diatas api sedang hingga matang.angkat biarkn dingin."
- "Siapkan panci lain masukan bahan B aduk rata,masak dg api kecil hingga mengental dan angkat.sisihkan"
- "Siapkan baskom, masukan gula,telur,vanili,kocok dg speed rendah,masukan bahan B kedalam mixer sampai rata."
- "Masukan terigu bergantian dg santan sampai habis hingga adonan kalis.matikan mixer"
- "Siapkan cetakan kue lumpang,masukan adonan hijau 3/4 cetakan, lalu masukan adonan putih yg sdh dimasukan kedlan plastik,beri lubang sedikit."
- "Sampe cetakan hampir penuh. Isi semua cetakan sampai adonan habis. Kukus ±15menit dg api sedang. Angkat sajikan"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 133 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Dessert

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/55c424da32f7d49d/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga enak. Ciri khas masakan Nusantara kue nona manis yang penuh dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga dapat didapat dengan cara mudah. Salah satunya adalah memasak Kue Nona Manis untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang bisa anda praktekkan salah satunya kue nona manis yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 16 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Harus ada  Bahan A;
1. Harap siapkan 500 ml santan kental sedang
1. Harus ada 40 gr tepung beras
1. Diperlukan Secukupnya garam
1. Siapkan Secukupnya vanili
1. Siapkan  Bahan B;
1. Diperlukan 30 gr tepung beras
1. Siapkan 200 ml air
1. Diperlukan 1 sdt pasta pandan
1. Harus ada Secukupnya garam
1. Dibutuhkan  Bahan C;
1. Harap siapkan 250 ml santan kental
1. Dibutuhkan 130 gr terigu
1. Harap siapkan 140 gr gula pasir
1. Diperlukan 1 btr telur
1. Siapkan Secukupnya vanili




<!--inarticleads2-->

##### Langkah membuat  Kue Nona Manis:

1. Campur semua bahan A kedalam panci aduk rata, baru masak diatas api sedang hingga matang.angkat biarkn dingin.
1. Siapkan panci lain masukan bahan B aduk rata,masak dg api kecil hingga mengental dan angkat.sisihkan
1. Siapkan baskom, masukan gula,telur,vanili,kocok dg speed rendah,masukan bahan B kedalam mixer sampai rata.
1. Masukan terigu bergantian dg santan sampai habis hingga adonan kalis.matikan mixer
1. Siapkan cetakan kue lumpang,masukan adonan hijau 3/4 cetakan, lalu masukan adonan putih yg sdh dimasukan kedlan plastik,beri lubang sedikit.
1. Sampe cetakan hampir penuh. Isi semua cetakan sampai adonan habis. Kukus ±15menit dg api sedang. Angkat sajikan




Demikianlah cara membuat kue nona manis yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
