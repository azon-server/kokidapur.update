---
description: "Bagaimana menyiapakan Talam Nona Manis Luar biasa"
title: "Bagaimana menyiapakan Talam Nona Manis Luar biasa"
slug: 342-bagaimana-menyiapakan-talam-nona-manis-luar-biasa
date: 2020-09-12T05:45:59.834Z
image: https://img-global.cpcdn.com/recipes/87bbf7c27a7cc4b3/680x482cq70/talam-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/87bbf7c27a7cc4b3/680x482cq70/talam-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/87bbf7c27a7cc4b3/680x482cq70/talam-nona-manis-foto-resep-utama.jpg
author: Hettie Norris
ratingvalue: 4.4
reviewcount: 14844
recipeingredient:
- " bahan A "
- "250 cc santan kental"
- "1 btr telor"
- "80 gr gula pasir"
- "140 gr tepung terigu"
- "sejumput garam"
- " bahan B "
- "300 cc santan kental"
- "30 gr maizena"
- "40 gr gula pasir"
- "2 sdm endapan santanpasta pandan"
- "sejumput garam"
- " bahan C "
- "500 cc santal kental"
- "100 gr tepung terigu"
- "sejumput garam"
recipeinstructions:
- "Maaf ya sebelumnya saya nggak foto step by stepnya.."
- "Bahan A mixer telur dan gula hingga kental. tambahan santan dan terigu. aduk hingga tidak bergerindil. bisa pake balon whisk atau mixer speed rendah."
- "Bahan B campur semua bahan menjadi satu.masak hingga kental.angkat dan dinginkan"
- "Campur bahan A dan bahan B menjadi satu dan mixer rata tidak bergerindil"
- "Bahan C campur semua jadi satu masak hingga meletup&#34;. Angkat dan tetap aduk supaya tdk bergerindil dinginkan dan masukkan ke piping bag"
- "Isi cetakan dg adonan hijau 3/4 penuh"
- "Masukkan adonan putih dg di spuit. Ujung spuit agak dibenamkan ke adonan hijau"
- "Kukus 15 menit dalam kukusan yg sudah dipanaskan sebelumnya"
- "Note: 1. adonan B sementara nunggu dingin sesekali tetap diaduk spy tdk menggumpal"
- "2. lebih disarankan memakai piping bag karna kalau pake botol banyak sisa adonan menempel susah dikeluarkan"
- "3. cetakan tdk usah dioles minyak. hasil 24bji cetakan talam besar"
categories:
- Recipe
tags:
- talam
- nona
- manis

katakunci: talam nona manis 
nutrition: 169 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Dinner

---


![Talam Nona Manis](https://img-global.cpcdn.com/recipes/87bbf7c27a7cc4b3/680x482cq70/talam-nona-manis-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan renyah. Ciri masakan Indonesia talam nona manis yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah memasak Talam Nona Manis untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang dapat anda coba salah satunya talam nona manis yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep talam nona manis tanpa harus bersusah payah.
Seperti resep Talam Nona Manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 11 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Talam Nona Manis:

1. Tambah  bahan A :
1. Jangan lupa 250 cc santan kental
1. Siapkan 1 btr telor
1. Siapkan 80 gr gula pasir
1. Tambah 140 gr tepung terigu
1. Dibutuhkan sejumput garam
1. Dibutuhkan  bahan B :
1. Tambah 300 cc santan kental
1. Tambah 30 gr maizena
1. Harap siapkan 40 gr gula pasir
1. Harus ada 2 sdm endapan santan/pasta pandan
1. Dibutuhkan sejumput garam
1. Jangan lupa  bahan C :
1. Diperlukan 500 cc santal kental
1. Diperlukan 100 gr tepung terigu
1. Harap siapkan sejumput garam




<!--inarticleads2-->

##### Langkah membuat  Talam Nona Manis:

1. Maaf ya sebelumnya saya nggak foto step by stepnya..
1. Bahan A mixer telur dan gula hingga kental. tambahan santan dan terigu. aduk hingga tidak bergerindil. bisa pake balon whisk atau mixer speed rendah.
1. Bahan B campur semua bahan menjadi satu.masak hingga kental.angkat dan dinginkan
1. Campur bahan A dan bahan B menjadi satu dan mixer rata tidak bergerindil
1. Bahan C campur semua jadi satu masak hingga meletup&#34;. Angkat dan tetap aduk supaya tdk bergerindil dinginkan dan masukkan ke piping bag
1. Isi cetakan dg adonan hijau 3/4 penuh
1. Masukkan adonan putih dg di spuit. Ujung spuit agak dibenamkan ke adonan hijau
1. Kukus 15 menit dalam kukusan yg sudah dipanaskan sebelumnya
1. Note: 1. adonan B sementara nunggu dingin sesekali tetap diaduk spy tdk menggumpal
1. 2. lebih disarankan memakai piping bag karna kalau pake botol banyak sisa adonan menempel susah dikeluarkan
1. 3. cetakan tdk usah dioles minyak. hasil 24bji cetakan talam besar




Demikianlah cara membuat talam nona manis yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
