---
description: "Langkah untuk menyiapakan Nona manis teraktual"
title: "Langkah untuk menyiapakan Nona manis teraktual"
slug: 274-langkah-untuk-menyiapakan-nona-manis-teraktual
date: 2020-10-08T17:10:37.862Z
image: https://img-global.cpcdn.com/recipes/bafd0e78e32ebbaa/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bafd0e78e32ebbaa/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bafd0e78e32ebbaa/680x482cq70/nona-manis-foto-resep-utama.jpg
author: David Vasquez
ratingvalue: 4
reviewcount: 36538
recipeingredient:
- " Bahan A"
- "250 ml santan kekentalan sedang"
- "250 ml air pandan 10 lbr pandan di blender dgan air 250ml"
- "60 gr maizena"
- "120 gr gula halus aku gula pasir biasa di blender"
- "1 sdt garam"
- "2 tetes pewarna pandan"
- " Bahan B"
- "2 btir telur"
- "250 gr tepung terigu"
- "500 ml santan kekentalan sedang"
- "250 gr gula halus"
- " Bahan C"
- "500 ml santan kekentalan sedang"
- "2 sdm gula aku skip"
- "2 sdm tepung terigu"
- "1/2 sdt garam"
- " Minyak goreng untuk olesan cetakan"
recipeinstructions:
- "Campur semua bahan A jadi satu. Lalu masak sampai licin dan meletup letup. Matikan dan tunggu dingin. Biar hemat waktu tdi aku kipas angin full, 30 menit udah dingin"
- "Campur bahan B. Aduk rata. Lalu masukkan ke dalam bahan A. Aduk terus sampai kalis. Aku tdi di blender biar cepet. Sisihkan"
- "Campur bahan C sampai rata. Lalu masak sampai mendidih. Matikan. Tunggu sampai uap hilang. Masukkan dalam botol kecap biar gampang nanti pas masukkan ke cetakan"
- "Panaskan kukusan dan tutup nya dialasi serbet. Olesi cetakan dengan minyak goreng, tuang adonan hijau 1/2 dari cetakan lalu tekan botol kecap sampai dasar cetakan pencet, usahakan jgan terlalu penuh. Biar gk tumpah pas di kukus. Kukus selama 20-25 menit. Angkat. Lalu biarkan sampai benar² dingin baru di pindahkan dari cetakan. Biar Hasil nya bagus. Lakukan sampai adonan habis."
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 133 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT41M"
recipeyield: "2"
recipecategory: Dinner

---


![Nona manis](https://img-global.cpcdn.com/recipes/bafd0e78e32ebbaa/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga renyah. Ciri masakan Nusantara nona manis yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan keluarga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Nona manis untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang dapat anda praktekkan salah satunya nona manis yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona manis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona manis:

1. Harus ada  Bahan A
1. Harap siapkan 250 ml santan kekentalan sedang
1. Jangan lupa 250 ml air pandan (10 lbr pandan di blender dgan air 250ml)
1. Harap siapkan 60 gr maizena
1. Tambah 120 gr gula halus (aku gula pasir biasa di blender)
1. Diperlukan 1 sdt garam
1. Harus ada 2 tetes pewarna pandan
1. Harap siapkan  Bahan B
1. Dibutuhkan 2 btir telur
1. Dibutuhkan 250 gr tepung terigu
1. Harus ada 500 ml santan kekentalan sedang
1. Harap siapkan 250 gr gula halus
1. Tambah  Bahan C
1. Harus ada 500 ml santan kekentalan sedang
1. Siapkan 2 sdm gula (aku skip)
1. Siapkan 2 sdm tepung terigu
1. Tambah 1/2 sdt garam
1. Harus ada  Minyak goreng untuk olesan cetakan




<!--inarticleads2-->

##### Cara membuat  Nona manis:

1. Campur semua bahan A jadi satu. Lalu masak sampai licin dan meletup letup. Matikan dan tunggu dingin. Biar hemat waktu tdi aku kipas angin full, 30 menit udah dingin
1. Campur bahan B. Aduk rata. Lalu masukkan ke dalam bahan A. Aduk terus sampai kalis. Aku tdi di blender biar cepet. Sisihkan
1. Campur bahan C sampai rata. Lalu masak sampai mendidih. Matikan. Tunggu sampai uap hilang. Masukkan dalam botol kecap biar gampang nanti pas masukkan ke cetakan
1. Panaskan kukusan dan tutup nya dialasi serbet. Olesi cetakan dengan minyak goreng, tuang adonan hijau 1/2 dari cetakan lalu tekan botol kecap sampai dasar cetakan pencet, usahakan jgan terlalu penuh. Biar gk tumpah pas di kukus. Kukus selama 20-25 menit. Angkat. Lalu biarkan sampai benar² dingin baru di pindahkan dari cetakan. Biar Hasil nya bagus. Lakukan sampai adonan habis.




Demikianlah cara membuat nona manis yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan teruji, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
