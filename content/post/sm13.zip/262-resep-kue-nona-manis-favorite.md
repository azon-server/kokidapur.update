---
description: "Resep : Kue Nona Manis Favorite"
title: "Resep : Kue Nona Manis Favorite"
slug: 262-resep-kue-nona-manis-favorite
date: 2020-11-09T23:07:49.880Z
image: https://img-global.cpcdn.com/recipes/b1478c29a0aac94b/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b1478c29a0aac94b/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b1478c29a0aac94b/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Chris Holmes
ratingvalue: 5
reviewcount: 34949
recipeingredient:
- " Bahan A"
- "1 butir telur"
- "100 gr gula pasir"
- "250 ml santan sedang"
- "130 gr tepung terigu pro sedang segitiga biru"
- " Bahan B"
- "125 ml santan"
- "125 ml air pandan suji 20 lembar suji 10 lembar pandan"
- "50 gr gula pasir"
- "25 gr maizena"
- "1/4 sdt garam"
- " Bahan C"
- "500 ml santan"
- "65 gr tepung terigu"
- "1 sdm susu bubuk"
- "1/2 sdt garam"
recipeinstructions:
- "Blender 20 lembar daun suji 10.lembar daun pandan dengan 125 ml air.saring lalu sisihkan"
- "Campur semua bahan C.aduk rata,masak sampai meletup letup sampai mengental.biarkan agak dingin,lalu masukkan ke botol atau piping bag"
- "Campur semua bahan B,aduk rata.masak sampai mengental"
- "Untuk bahan A,campur semua bahan.aduk sampai tidak ada yang bergerindil.lalu campur kan ke adonan B.aduk sampai tercampur rata"
- "Siapkan cetakan,olesi dengan minyak sayur.masukkan campuran adonan A dan B.1/4 bagian saja.lalu masukkan adonan C di bagian tengah nya"
- "Lakukan sampai semua adonan habis,panaskan kukusan lalu kukus 10 menit dengan api sedang,angkat.biarkan suhu ruang dulu,baru di lepas dari cetakan"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 160 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Lunch

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/b1478c29a0aac94b/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga renyah. Karasteristik kuliner Indonesia kue nona manis yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Kue Nona Manis untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang dapat anda praktekkan salah satunya kue nona manis yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Harus ada  Bahan A
1. Siapkan 1 butir telur
1. Jangan lupa 100 gr gula pasir
1. Harap siapkan 250 ml santan sedang
1. Siapkan 130 gr tepung terigu pro sedang (segitiga biru)
1. Tambah  Bahan B
1. Tambah 125 ml santan
1. Jangan lupa 125 ml air pandan suji (20 lembar suji 10 lembar pandan)
1. Harus ada 50 gr gula pasir
1. Dibutuhkan 25 gr maizena
1. Siapkan 1/4 sdt garam
1. Tambah  Bahan C
1. Jangan lupa 500 ml santan
1. Tambah 65 gr tepung terigu
1. Tambah 1 sdm susu bubuk
1. Dibutuhkan 1/2 sdt garam




<!--inarticleads2-->

##### Cara membuat  Kue Nona Manis:

1. Blender 20 lembar daun suji 10.lembar daun pandan dengan 125 ml air.saring lalu sisihkan
1. Campur semua bahan C.aduk rata,masak sampai meletup letup sampai mengental.biarkan agak dingin,lalu masukkan ke botol atau piping bag
1. Campur semua bahan B,aduk rata.masak sampai mengental
1. Untuk bahan A,campur semua bahan.aduk sampai tidak ada yang bergerindil.lalu campur kan ke adonan B.aduk sampai tercampur rata
1. Siapkan cetakan,olesi dengan minyak sayur.masukkan campuran adonan A dan B.1/4 bagian saja.lalu masukkan adonan C di bagian tengah nya
1. Lakukan sampai semua adonan habis,panaskan kukusan lalu kukus 10 menit dengan api sedang,angkat.biarkan suhu ruang dulu,baru di lepas dari cetakan




Demikianlah cara membuat kue nona manis yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan cepat, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
