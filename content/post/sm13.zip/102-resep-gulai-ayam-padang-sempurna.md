---
description: "Resep : Gulai Ayam Padang Sempurna"
title: "Resep : Gulai Ayam Padang Sempurna"
slug: 102-resep-gulai-ayam-padang-sempurna
date: 2020-09-27T14:30:58.919Z
image: https://img-global.cpcdn.com/recipes/5129303f6ccea67b/680x482cq70/gulai-ayam-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5129303f6ccea67b/680x482cq70/gulai-ayam-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5129303f6ccea67b/680x482cq70/gulai-ayam-padang-foto-resep-utama.jpg
author: Anne Howell
ratingvalue: 4.5
reviewcount: 25902
recipeingredient:
- "1/2 kg Ayam"
- "2 sacset santan"
- " Bumbu kuah"
- "1/4 cabe besar buang bijinya"
- "1/2 buah asam gandis"
- "8 siung bawang merah"
- "5 Siung bawang putih"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1 ruas kunyit Sangrai"
- "1 sdt ketumbar Sangrai"
- "4 buah kemiri Sangrai"
- "3 buah daun salam"
- "3 buah daun jeruk"
- "2 buah daun kunyit"
- "2 buah serai"
- "1/2 sdt garam"
- "1/2 sdt gula"
- "1 sacset kalau bubuk"
- " Pelengkap "
- " Daun singkong rebus"
- " Sambal ijo"
recipeinstructions:
- "Bersihkan Ayam sisihkan,bersihkan smua bumbu2 lalu haluskan kecuali daun2nan"
- "Lalu tumis sampai harum bumbunya smua,lalu masukkan daun salam,daun jeruk,daun kunyit dan geprek serai aduk rata"
- "Setelah bau harum masukkan air sedikit aja dan masukkan ayam,garam,gula,kaldu bubuk dan asam gandis aduk rata,setelah mendidih masukkan santan aduk2 sampai matang sempurna dan kuah agak menyusut dan kental,lalu tes rasa"
- "Dan gulai Ayam Padang siap dinikmati bersama sambal ijo dan rebusan daun singkong,hmm rasanya luar biasa lezat🤗👍"
categories:
- Recipe
tags:
- gulai
- ayam
- padang

katakunci: gulai ayam padang 
nutrition: 220 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Dinner

---


![Gulai Ayam Padang](https://img-global.cpcdn.com/recipes/5129303f6ccea67b/680x482cq70/gulai-ayam-padang-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti gulai ayam padang yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa kesan tersendiri yang merupakan keragaman Kita



Kedekatan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Gulai Ayam Padang untuk keluarga. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang dapat anda praktekkan salah satunya gulai ayam padang yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep gulai ayam padang tanpa harus bersusah payah.
Berikut ini resep Gulai Ayam Padang yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Gulai Ayam Padang:

1. Diperlukan 1/2 kg Ayam
1. Siapkan 2 sacset santan
1. Siapkan  Bumbu kuah
1. Siapkan 1/4 cabe besar buang bijinya
1. Siapkan 1/2 buah asam gandis
1. Jangan lupa 8 siung bawang merah
1. Jangan lupa 5 Siung bawang putih
1. Dibutuhkan 1 ruas jahe
1. Harus ada 1 ruas lengkuas
1. Dibutuhkan 1 ruas kunyit Sangrai
1. Harap siapkan 1 sdt ketumbar Sangrai
1. Diperlukan 4 buah kemiri Sangrai
1. Harus ada 3 buah daun salam
1. Siapkan 3 buah daun jeruk
1. Harap siapkan 2 buah daun kunyit
1. Harus ada 2 buah serai
1. Tambah 1/2 sdt garam
1. Harus ada 1/2 sdt gula
1. Jangan lupa 1 sacset kalau bubuk
1. Diperlukan  Pelengkap :
1. Harap siapkan  Daun singkong rebus
1. Dibutuhkan  Sambal ijo




<!--inarticleads2-->

##### Cara membuat  Gulai Ayam Padang:

1. Bersihkan Ayam sisihkan,bersihkan smua bumbu2 lalu haluskan kecuali daun2nan
1. Lalu tumis sampai harum bumbunya smua,lalu masukkan daun salam,daun jeruk,daun kunyit dan geprek serai aduk rata
1. Setelah bau harum masukkan air sedikit aja dan masukkan ayam,garam,gula,kaldu bubuk dan asam gandis aduk rata,setelah mendidih masukkan santan aduk2 sampai matang sempurna dan kuah agak menyusut dan kental,lalu tes rasa
1. Dan gulai Ayam Padang siap dinikmati bersama sambal ijo dan rebusan daun singkong,hmm rasanya luar biasa lezat🤗👍




Demikianlah cara membuat gulai ayam padang yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan terbukti, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
