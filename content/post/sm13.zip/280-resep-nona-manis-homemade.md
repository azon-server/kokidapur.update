---
description: "Resep : Nona Manis Homemade"
title: "Resep : Nona Manis Homemade"
slug: 280-resep-nona-manis-homemade
date: 2020-11-07T03:33:04.550Z
image: https://img-global.cpcdn.com/recipes/88433104e612b034/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/88433104e612b034/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/88433104e612b034/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Mary Tate
ratingvalue: 4.2
reviewcount: 11993
recipeingredient:
- " Bahan step 1"
- "1 butir telur"
- "1/2 gelas gula"
- "1 gelas terigu"
- "1 gelas santan"
- " Bahan step 2"
- "1/2 gelas santan"
- "1/2 gelas air jus daun pandan"
- "2 sdm maizena"
- "2 sdt pasta pandan"
- " Bahan step 3"
- "2 gelas santan"
- "1 sdm gula"
- "2 sdm terigu"
- "1 sdt garam"
recipeinstructions:
- "Step 1.Satukan semua bahan, kemuadian mixer sebentar saja,sisihkan."
- "Untuk step 2. Satukan semua bahan pada step dua,aduk sampai tercampur rata, masukkan bahan step 1, masak sampai sedikit mengental, jangan sampai menggumpal.Matikan api,kemudian saring, dan sisihkan."
- "Step 3.Satukan semua bahan step 3.Aduk rata,masak sampai sedikit mengental.Matikan api."
- "Oles cetakan menggunakan minyak goreng, tuang adonan hijau sebanyak 3/4 cetakan, kemudianntuang adonan putih pada bagian tengah adonan hijau.Lakukan berulang sampai adonan habis kemudian kukus"
- "Kukusan harus dipanaskan terlebih dahulu, sampai benar-benar panas, sebelum adonan dalam cetakan di masukkan dalam kukusan"
- "Kukus selama 30 menit.Setelah masak biarkan sampai benar-benar dingin,baru keluarkan dari cetakan secara perlahan dan hati-hati."
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 254 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Lunch

---


![Nona Manis](https://img-global.cpcdn.com/recipes/88433104e612b034/680x482cq70/nona-manis-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang setidaknya kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti nona manis yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan keistimewahan yang merupakan keragaman Nusantara

Keharmonisan rumah tangga bisa didapat dengan cara simple. Diantaranya adalah membuat makanan Nona Manis untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang dapat anda buat salah satunya nona manis yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona Manis yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona Manis:

1. Harap siapkan  Bahan step 1:
1. Harap siapkan 1 butir telur
1. Tambah 1/2 gelas gula
1. Harap siapkan 1 gelas terigu
1. Diperlukan 1 gelas santan
1. Dibutuhkan  Bahan step 2:
1. Siapkan 1/2 gelas santan
1. Harus ada 1/2 gelas air jus daun pandan
1. Harap siapkan 2 sdm maizena
1. Harus ada 2 sdt pasta pandan
1. Siapkan  Bahan step 3:
1. Jangan lupa 2 gelas santan
1. Tambah 1 sdm gula
1. Harap siapkan 2 sdm terigu
1. Dibutuhkan 1 sdt garam




<!--inarticleads2-->

##### Langkah membuat  Nona Manis:

1. Step 1.Satukan semua bahan, kemuadian mixer sebentar saja,sisihkan.
1. Untuk step 2. Satukan semua bahan pada step dua,aduk sampai tercampur rata, masukkan bahan step 1, masak sampai sedikit mengental, jangan sampai menggumpal.Matikan api,kemudian saring, dan sisihkan.
1. Step 3.Satukan semua bahan step 3.Aduk rata,masak sampai sedikit mengental.Matikan api.
1. Oles cetakan menggunakan minyak goreng, tuang adonan hijau sebanyak 3/4 cetakan, kemudianntuang adonan putih pada bagian tengah adonan hijau.Lakukan berulang sampai adonan habis kemudian kukus
1. Kukusan harus dipanaskan terlebih dahulu, sampai benar-benar panas, sebelum adonan dalam cetakan di masukkan dalam kukusan
1. Kukus selama 30 menit.Setelah masak biarkan sampai benar-benar dingin,baru keluarkan dari cetakan secara perlahan dan hati-hati.




Demikianlah cara membuat nona manis yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan teruji, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
