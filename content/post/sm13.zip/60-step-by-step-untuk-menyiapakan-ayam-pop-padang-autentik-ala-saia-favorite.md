---
description: "Step-by-Step untuk menyiapakan Ayam Pop Padang Autentik ala Saia Favorite"
title: "Step-by-Step untuk menyiapakan Ayam Pop Padang Autentik ala Saia Favorite"
slug: 60-step-by-step-untuk-menyiapakan-ayam-pop-padang-autentik-ala-saia-favorite
date: 2021-02-03T19:46:30.392Z
image: https://img-global.cpcdn.com/recipes/beda569fe9859472/680x482cq70/ayam-pop-padang-autentik-ala-saia-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/beda569fe9859472/680x482cq70/ayam-pop-padang-autentik-ala-saia-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/beda569fe9859472/680x482cq70/ayam-pop-padang-autentik-ala-saia-foto-resep-utama.jpg
author: Rena Myers
ratingvalue: 4.6
reviewcount: 42165
recipeingredient:
- "1 ekor ayam kampung"
- " Air kelapa dari 1 butir kelapa"
- " Bumbu Halus Marinasi"
- "3 siung bawang putih"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "1 ruas jahe geprek"
- "1 ruas lengkuas geprek"
- "2 tangkai sereh geprek"
- "1/2 ruas jari kayu manis"
- "1 keping pekak"
- "1 buah kapulaga"
- "1 saset pala bubuk"
- "1 tangkai daun bawang bisa skip"
- " Tambahan"
- " Daun singkong daun pepaya Jepang           lihat tips"
- " Sambal           lihat resep"
- "2-3 sdm VCO Virgin Coconut Oil"
recipeinstructions:
- "Bersihkan ayam, beri perasan jeruk nipis, diamkan 15 menit, bilas."
- "Tumis bumbu halus sampai harum dan tambahkan air secukupnya, beri garam dan penyedap. Masak sampai mendidih dan bumbu matang. Matikan kompor. Angkat."
- "Tuang ayam ke wajan yang berisi tumisan bumbu, aduk aduk, istirahatkan sampai dingin kemudian masukkan ke freezer, marinasi minimal 2 jam (saya 6 jam)"
- "Setelah dimarinasi, keluarkan ayam dari kulkas, biarkan dalam suhu ruangan selama kurang lebih 30 menit."
- "Masukkan ayam ke dalam air hangat dan air kelapa, lalu angkat lagi ayamnya (hanya untuk melarutkan bumbu yang menempel pada ayam)."
- "Rebus air berbumbu marinasi ayam sampai mendidih, baru kemudian masukkan ayam saat kuah mendidih. Tujuannya agar ayam kampung mudah lunak. Rebus ayam hingga 30 menit."
- "Setelah 30 menit, matikan kompor. Biarkan kuali tertutup terus agar bumbu meresap."
- "Siapkan minyak panas dan 3 sdm VCO, panaskan dan celup ayam selama 1 menit, angkat."
- "Sajikan ayam bersama rebusan daun singkong dan sambalnya. Selamat mencoba💗."
categories:
- Recipe
tags:
- ayam
- pop
- padang

katakunci: ayam pop padang 
nutrition: 133 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Pop Padang Autentik ala Saia](https://img-global.cpcdn.com/recipes/beda569fe9859472/680x482cq70/ayam-pop-padang-autentik-ala-saia-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita lestarikan karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam pop padang autentik ala saia yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Kita



Kedekatan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ayam Pop Padang Autentik ala Saia untuk keluarga. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang bisa anda contoh salah satunya ayam pop padang autentik ala saia yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam pop padang autentik ala saia tanpa harus bersusah payah.
Seperti resep Ayam Pop Padang Autentik ala Saia yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Pop Padang Autentik ala Saia:

1. Tambah 1 ekor ayam kampung
1. Dibutuhkan  Air kelapa dari 1 butir kelapa
1. Diperlukan  Bumbu Halus/ Marinasi:
1. Jangan lupa 3 siung bawang putih
1. Tambah 3 lembar daun salam
1. Jangan lupa 3 lembar daun jeruk
1. Jangan lupa 1 ruas jahe, geprek
1. Siapkan 1 ruas lengkuas, geprek
1. Tambah 2 tangkai sereh, geprek
1. Harus ada 1/2 ruas jari kayu manis
1. Jangan lupa 1 keping pekak
1. Tambah 1 buah kapulaga
1. Tambah 1 saset pala bubuk
1. Siapkan 1 tangkai daun bawang (bisa skip)
1. Diperlukan  Tambahan:
1. Harap siapkan  Daun singkong/ daun pepaya Jepang           (lihat tips)
1. Jangan lupa  Sambal           (lihat resep)
1. Siapkan 2-3 sdm VCO (Virgin Coconut Oil)




<!--inarticleads2-->

##### Langkah membuat  Ayam Pop Padang Autentik ala Saia:

1. Bersihkan ayam, beri perasan jeruk nipis, diamkan 15 menit, bilas.
1. Tumis bumbu halus sampai harum dan tambahkan air secukupnya, beri garam dan penyedap. Masak sampai mendidih dan bumbu matang. Matikan kompor. Angkat.
1. Tuang ayam ke wajan yang berisi tumisan bumbu, aduk aduk, istirahatkan sampai dingin kemudian masukkan ke freezer, marinasi minimal 2 jam (saya 6 jam)
1. Setelah dimarinasi, keluarkan ayam dari kulkas, biarkan dalam suhu ruangan selama kurang lebih 30 menit.
1. Masukkan ayam ke dalam air hangat dan air kelapa, lalu angkat lagi ayamnya (hanya untuk melarutkan bumbu yang menempel pada ayam).
1. Rebus air berbumbu marinasi ayam sampai mendidih, baru kemudian masukkan ayam saat kuah mendidih. Tujuannya agar ayam kampung mudah lunak. Rebus ayam hingga 30 menit.
1. Setelah 30 menit, matikan kompor. Biarkan kuali tertutup terus agar bumbu meresap.
1. Siapkan minyak panas dan 3 sdm VCO, panaskan dan celup ayam selama 1 menit, angkat.
1. Sajikan ayam bersama rebusan daun singkong dan sambalnya. Selamat mencoba💗.




Demikianlah cara membuat ayam pop padang autentik ala saia yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan cepat, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
