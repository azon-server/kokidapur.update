---
description: "Steps untuk membuat Udang Saos Padang kemangi Cepat"
title: "Steps untuk membuat Udang Saos Padang kemangi Cepat"
slug: 154-steps-untuk-membuat-udang-saos-padang-kemangi-cepat
date: 2021-02-26T20:08:27.915Z
image: https://img-global.cpcdn.com/recipes/1672b7b8be62fc7e/680x482cq70/udang-saos-padang-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1672b7b8be62fc7e/680x482cq70/udang-saos-padang-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1672b7b8be62fc7e/680x482cq70/udang-saos-padang-kemangi-foto-resep-utama.jpg
author: Aaron Howard
ratingvalue: 4.2
reviewcount: 8026
recipeingredient:
- "250 gr Udang ukuran sedang"
- "1 buah Jeruk Nipis"
- "3 butir telur ayam"
- "1 ikat daun kemangi"
- "1 bawang bombay kecil  1 tomat besar"
- "5 butir bawang merah  4 butir bawang putih"
- "3 cabai merah keriting  2 cabai merah besar"
- "4 sdm saos sambal"
- "2 sdm saos tomat"
- "2 sdm saos tiram"
- "1 sdm kecap manis"
- "2 sdm tepung maizena larutkan dengan air"
- " Garam  merica"
- "1 ruas jahe"
- "3 cm kunyit"
- "secukupnya Minyak goreng"
recipeinstructions:
- "Bersihkan udang dari kepala,kulit dan kotorannya. Cuci dan beri perasan jeruk nipis."
- "Haluskan bawang merah, bawang putih, cabai merah, kunyit, jahe dan tomat.  Bawang bombay iris tipis, siapkan tepung maizena larutkan dengan air"
- "Panaskan wajan/ teflon dengan minyak, goreng udang hingga setengah matang, rebus telur ayam sekitar 10 menit, kupas kulit telur kemudian goreng telur ayam yg telah direbus hingga permukaan kecoklatan, angkat dan tiriskan"
- "Panaskan kembali wajan/teflon, tembahkan minyak goreng, Tumis bumbu yang telah dihaluskan sampai harum."
- "Masukkan saus sambal, saus tomat, saus tiram, dan kecap. Aduk rata."
- "Masukkan udang dan telur. Aduk sampai udang berubah warna lalu tambahkan air pengental tepung maizena. Kemudian masukan garam dan merica."
- "Masak terus sambil diaduk aduk sampai saus mengental agar bumbu meresap dan rasa merata.  Koreksi kembali rasa."
- "Masukan daun kemangi, aduk sebentar. Matikan api kompor. udang saus Padang siap disajikan."
categories:
- Recipe
tags:
- udang
- saos
- padang

katakunci: udang saos padang 
nutrition: 153 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Lunch

---


![Udang Saos Padang kemangi](https://img-global.cpcdn.com/recipes/1672b7b8be62fc7e/680x482cq70/udang-saos-padang-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga empuk. Ciri kuliner Indonesia udang saos padang kemangi yang penuh dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Udang Saos Padang kemangi untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang dapat anda buat salah satunya udang saos padang kemangi yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep udang saos padang kemangi tanpa harus bersusah payah.
Seperti resep Udang Saos Padang kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Udang Saos Padang kemangi:

1. Harap siapkan 250 gr Udang ukuran sedang
1. Harus ada 1 buah Jeruk Nipis
1. Tambah 3 butir telur ayam
1. Harap siapkan 1 ikat daun kemangi
1. Jangan lupa 1 bawang bombay kecil + 1 tomat besar
1. Dibutuhkan 5 butir bawang merah + 4 butir bawang putih
1. Harus ada 3 cabai merah keriting + 2 cabai merah besar
1. Siapkan 4 sdm saos sambal
1. Harap siapkan 2 sdm saos tomat
1. Jangan lupa 2 sdm saos tiram
1. Jangan lupa 1 sdm kecap manis
1. Diperlukan 2 sdm tepung maizena (larutkan dengan air)
1. Tambah  Garam + merica
1. Siapkan 1 ruas jahe
1. Siapkan 3 cm kunyit
1. Dibutuhkan secukupnya Minyak goreng




<!--inarticleads2-->

##### Cara membuat  Udang Saos Padang kemangi:

1. Bersihkan udang dari kepala,kulit dan kotorannya. Cuci dan beri perasan jeruk nipis.
1. Haluskan bawang merah, bawang putih, cabai merah, kunyit, jahe dan tomat.  - Bawang bombay iris tipis, siapkan tepung maizena larutkan dengan air
1. Panaskan wajan/ teflon dengan minyak, goreng udang hingga setengah matang, rebus telur ayam sekitar 10 menit, kupas kulit telur kemudian goreng telur ayam yg telah direbus hingga permukaan kecoklatan, angkat dan tiriskan
1. Panaskan kembali wajan/teflon, tembahkan minyak goreng, Tumis bumbu yang telah dihaluskan sampai harum.
1. Masukkan saus sambal, saus tomat, saus tiram, dan kecap. Aduk rata.
1. Masukkan udang dan telur. Aduk sampai udang berubah warna lalu tambahkan air pengental tepung maizena. Kemudian masukan garam dan merica.
1. Masak terus sambil diaduk aduk sampai saus mengental agar bumbu meresap dan rasa merata.  - Koreksi kembali rasa.
1. Masukan daun kemangi, aduk sebentar. Matikan api kompor. udang saus Padang siap disajikan.




Demikianlah cara membuat udang saos padang kemangi yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
