---
description: "Step-by-Step menyiapakan Nona manis Terbukti"
title: "Step-by-Step menyiapakan Nona manis Terbukti"
slug: 275-step-by-step-menyiapakan-nona-manis-terbukti
date: 2021-02-23T22:12:56.166Z
image: https://img-global.cpcdn.com/recipes/49e24341d402cea3/680x482cq70/nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/49e24341d402cea3/680x482cq70/nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/49e24341d402cea3/680x482cq70/nona-manis-foto-resep-utama.jpg
author: Wesley Ross
ratingvalue: 4.9
reviewcount: 24458
recipeingredient:
- " Bahan 1"
- "1 butir telur"
- "250 ml santan"
- "secukupnya Garam"
- "8 sdm gula"
- "6 sdm tepung terigu"
- " Bahan 2"
- "250 ml santan"
- " Garam secukupnyanya"
- "100 ml air pandan atau perasa pandan"
- "6 sdm tepung maizena"
- " Bahan 3"
- "250 ml santan"
- "3 sdm terigu"
- "secukupnya Garam"
recipeinstructions:
- "Campurkan bahan 1."
- "Campurkan bahan 2. Lalu masak hingga agak mengental. Tuangkan bahan 1 agar tercampur."
- "Jika sudah mengental angkat lalu saring. Dan tuang ke dalam cup cetakan talam kecil sebanyak 3/4 cetakan."
- "Campurkan bahan 3. Masak lalu masak hingga sedikit mengental. Masukkan dalam plastik segitiga."
- "Semprot di bagian tengah adonan dalam cup cetakan hingga penuh"
- "Panaskan kukusan."
- "Kukus selama 10 menit"
- "Angkat, keluar kan dari cetakan jika sudah dingin."
categories:
- Recipe
tags:
- nona
- manis

katakunci: nona manis 
nutrition: 101 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Lunch

---


![Nona manis](https://img-global.cpcdn.com/recipes/49e24341d402cea3/680x482cq70/nona-manis-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau enak. Ciri khas makanan Indonesia nona manis yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kehangatan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Nona manis untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang dapat anda praktekkan salah satunya nona manis yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep nona manis tanpa harus bersusah payah.
Seperti resep Nona manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 15 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nona manis:

1. Harus ada  Bahan 1
1. Diperlukan 1 butir telur
1. Harap siapkan 250 ml santan
1. Siapkan secukupnya Garam
1. Dibutuhkan 8 sdm gula
1. Siapkan 6 sdm tepung terigu
1. Dibutuhkan  Bahan 2:
1. Harap siapkan 250 ml santan
1. Tambah  Garam secukupnyanya
1. Harus ada 100 ml air pandan atau perasa pandan
1. Dibutuhkan 6 sdm tepung maizena
1. Jangan lupa  Bahan 3:
1. Jangan lupa 250 ml santan
1. Siapkan 3 sdm terigu
1. Harus ada secukupnya Garam




<!--inarticleads2-->

##### Langkah membuat  Nona manis:

1. Campurkan bahan 1.
1. Campurkan bahan 2. Lalu masak hingga agak mengental. Tuangkan bahan 1 agar tercampur.
1. Jika sudah mengental angkat lalu saring. Dan tuang ke dalam cup cetakan talam kecil sebanyak 3/4 cetakan.
1. Campurkan bahan 3. Masak lalu masak hingga sedikit mengental. Masukkan dalam plastik segitiga.
1. Semprot di bagian tengah adonan dalam cup cetakan hingga penuh
1. Panaskan kukusan.
1. Kukus selama 10 menit
1. Angkat, keluar kan dari cetakan jika sudah dingin.




Demikianlah cara membuat nona manis yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
