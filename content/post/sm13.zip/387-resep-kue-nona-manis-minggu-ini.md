---
description: "Resep : Kue Nona Manis minggu ini"
title: "Resep : Kue Nona Manis minggu ini"
slug: 387-resep-kue-nona-manis-minggu-ini
date: 2021-01-28T21:03:13.438Z
image: https://img-global.cpcdn.com/recipes/eb3341b2518f376d/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/eb3341b2518f376d/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/eb3341b2518f376d/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Ryan Lawson
ratingvalue: 4.7
reviewcount: 23687
recipeingredient:
- " Bahan 1 "
- "150 ml santan"
- "100 ml jus pandan saya  100 ml air  3 tetes pasta pandan"
- "30 gr tepung beras"
- "1/4 sdt garam"
- "1 sdt pewarna hijau saya skip"
- "1/2 sdt vanilla"
- " Bahan 2 "
- "250 ml santan"
- "1 butit telur"
- "125 gr gula pasir"
- "140 gr tepung terigu"
- " Bahan 3 "
- "500 ml santan"
- "40 gr tepung beras"
- "1/2 sdt garam"
- "1 sdt gula"
recipeinstructions:
- "Cara membuat bahan 1 : campur semua bahan sebelum dimasak diatas kompor, aduk sampai halus. Setelah itu masak diatas api kecil sampai mengental dan licin, sisihkan."
- "Cara membuat bahan 2 : campur semua bahan jadi satu, mix dengan mixer setelah tercampur rata, masukkan adonan bahan 1 kedalam adonan 2, aduk lagi sampai merata, jika masih bergerinjil saring adonan kedalam wadah baru."
- "Cara membuat bahan 3 : campur semua bahan jadi satu sampai halus, masak diatas api kecil hingga agak mengental. Sisihkan sampai agak dingin."
- "Tuang adonan pandan ke dalam loyang talam, jangan sampai penuh, kira-kira 2 sdm. Setelah itu baru tuang adonan bahan 3 diatasnya 1 sdt dan agak ditekan pelan-pelan kedalam agar masuk kedalam adonan pandan. Lakukan sampai adonan habis. Kukus selama 15 menit, lapis tutupan panci dengan serbet. Selamat mencoba."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 161 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Lunch

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/eb3341b2518f376d/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang setidaknya kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti kue nona manis yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa keistimewahan yang merupakan keragaman Kita



Kehangatan rumah tangga dapat diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Kue Nona Manis untuk keluarga. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang bisa anda contoh salah satunya kue nona manis yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Siapkan  Bahan 1 :
1. Harap siapkan 150 ml santan
1. Harus ada 100 ml jus pandan (saya : 100 ml air + 3 tetes pasta pandan)
1. Dibutuhkan 30 gr tepung beras
1. Jangan lupa 1/4 sdt garam
1. Tambah 1 sdt pewarna hijau (saya skip)
1. Siapkan 1/2 sdt vanilla
1. Siapkan  Bahan 2 :
1. Harap siapkan 250 ml santan
1. Jangan lupa 1 butit telur
1. Tambah 125 gr gula pasir
1. Jangan lupa 140 gr tepung terigu
1. Dibutuhkan  Bahan 3 :
1. Siapkan 500 ml santan
1. Harus ada 40 gr tepung beras
1. Diperlukan 1/2 sdt garam
1. Harap siapkan 1 sdt gula




<!--inarticleads2-->

##### Instruksi membuat  Kue Nona Manis:

1. Cara membuat bahan 1 : campur semua bahan sebelum dimasak diatas kompor, aduk sampai halus. Setelah itu masak diatas api kecil sampai mengental dan licin, sisihkan.
1. Cara membuat bahan 2 : campur semua bahan jadi satu, mix dengan mixer setelah tercampur rata, masukkan adonan bahan 1 kedalam adonan 2, aduk lagi sampai merata, jika masih bergerinjil saring adonan kedalam wadah baru.
1. Cara membuat bahan 3 : campur semua bahan jadi satu sampai halus, masak diatas api kecil hingga agak mengental. Sisihkan sampai agak dingin.
1. Tuang adonan pandan ke dalam loyang talam, jangan sampai penuh, kira-kira 2 sdm. Setelah itu baru tuang adonan bahan 3 diatasnya 1 sdt dan agak ditekan pelan-pelan kedalam agar masuk kedalam adonan pandan. Lakukan sampai adonan habis. Kukus selama 15 menit, lapis tutupan panci dengan serbet. Selamat mencoba.




Demikianlah cara membuat kue nona manis yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan teruji, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
