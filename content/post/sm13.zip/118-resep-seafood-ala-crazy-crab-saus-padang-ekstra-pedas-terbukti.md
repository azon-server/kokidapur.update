---
description: "Resep : Seafood ala crazy crab (saus padang ekstra pedas) Terbukti"
title: "Resep : Seafood ala crazy crab (saus padang ekstra pedas) Terbukti"
slug: 118-resep-seafood-ala-crazy-crab-saus-padang-ekstra-pedas-terbukti
date: 2020-10-17T12:00:09.453Z
image: https://img-global.cpcdn.com/recipes/221bf9e00f3ed6d2/680x482cq70/seafood-ala-crazy-crab-saus-padang-ekstra-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/221bf9e00f3ed6d2/680x482cq70/seafood-ala-crazy-crab-saus-padang-ekstra-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/221bf9e00f3ed6d2/680x482cq70/seafood-ala-crazy-crab-saus-padang-ekstra-pedas-foto-resep-utama.jpg
author: Dora Brooks
ratingvalue: 4.8
reviewcount: 21044
recipeingredient:
- "4 ekor kepiting"
- "1/2 kg kerang utuh masih ada cangkang"
- "1/4 cumi"
- "1/4 udang"
- "10 buah bakso ayam"
- "10 buah Cabe merah"
- "10 buah Cabe caplak"
- "5 siung Bawang merah"
- "3 siung Bawang putih"
- "1 buah Kemiri"
- "1/2 buah Tomat"
- " Saos tomat"
- " Saos cabai ekstra pedas"
- " Saos tiram"
- "sedikit Tepung maizena"
- " Garam"
- "2 lembar Daun jeruk"
- "Sedikit Kaldu bubuk"
- "Sedikit Merica bubuk"
- "1 lembar Daun salam"
- " Daun bawang"
- "Sedikit Bawang bombai"
- "1 buah telur"
- " Minyak"
- " Jagung potong2"
recipeinstructions:
- "Bersihkan kepiting+udang+kerang+cumi lumurin jeruk nipis dan garam biar tidak amis"
- "Rebus kepiting+kerang supaya lebih matang"
- "Rebus udang sebentar"
- "Buat bumbu halus : bawang merah, bawang putih, kemiri, cabe merah, cabe caplak, tomat (blender hingga halus seperti saos)"
- "Iris bawang bombay dan daun bawang"
- "Panaskan minyak Tumis bumbu halus tadi sampai harum"
- "Masukkan daun jeruk, daun salam, bawang bombay,"
- "Masukkan saos tomat, saos cabai, saos tiram sedikit saja karena rasa saos tiram manis (boleh tidak pakai saos tiram)"
- "Larutkan tepung maizena kedalam air aduk sampai tercampur sempurna dan masukkan ke dalam wajan tadi"
- "Tambahkan merica bubuk, garam, kaldu bubuk"
- "Masukkan cumi yg belum matang, aduk2 hingga cumi matang"
- "Masukkan jagung yg sudah di potong2"
- "Masukkan udang dan bakso (boleh tdk pakai bakso)"
- "Kemudian masukkan daun bawang"
- "Kocok lepas telur dan masukkan smbil diaduk supaya telur tercampur sempurna ke bumbu"
- "Masukkan kepiting dan kerang yg sudah matang"
- "Aduk terus sampai bumbu meresap ke seafood"
- "Koreksi rasa, tunggu sampai benar2 matang (air sudah meresap dan bumbu kental) tingkat kekentalan bisa di atur sendiri sesuai selera.. jika ingin sedikit cair bisa tambahkan air lagi aduk2"
- "Siap disajikan dengan nasi hangat 🤤🤤"
categories:
- Recipe
tags:
- seafood
- ala
- crazy

katakunci: seafood ala crazy 
nutrition: 180 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT30M"
recipeyield: "2"
recipecategory: Dessert

---


![Seafood ala crazy crab (saus padang ekstra pedas)](https://img-global.cpcdn.com/recipes/221bf9e00f3ed6d2/680x482cq70/seafood-ala-crazy-crab-saus-padang-ekstra-pedas-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang patut kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti seafood ala crazy crab (saus padang ekstra pedas) yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Kita

Kehangatan rumah tangga dapat ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Seafood ala crazy crab (saus padang ekstra pedas) untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi resep yang bisa anda praktekkan salah satunya seafood ala crazy crab (saus padang ekstra pedas) yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep seafood ala crazy crab (saus padang ekstra pedas) tanpa harus bersusah payah.
Berikut ini resep Seafood ala crazy crab (saus padang ekstra pedas) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 25 bahan dan 19 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Seafood ala crazy crab (saus padang ekstra pedas):

1. Dibutuhkan 4 ekor kepiting
1. Siapkan 1/2 kg kerang utuh (masih ada cangkang)
1. Siapkan 1/4 cumi
1. Diperlukan 1/4 udang
1. Harap siapkan 10 buah bakso ayam
1. Harap siapkan 10 buah Cabe merah
1. Tambah 10 buah Cabe caplak
1. Harus ada 5 siung Bawang merah
1. Dibutuhkan 3 siung Bawang putih
1. Harus ada 1 buah Kemiri
1. Dibutuhkan 1/2 buah Tomat
1. Diperlukan  Saos tomat
1. Siapkan  Saos cabai ekstra pedas
1. Dibutuhkan  Saos tiram
1. Harap siapkan sedikit Tepung maizena
1. Dibutuhkan  Garam
1. Dibutuhkan 2 lembar Daun jeruk
1. Jangan lupa Sedikit Kaldu bubuk
1. Diperlukan Sedikit Merica bubuk
1. Jangan lupa 1 lembar Daun salam
1. Jangan lupa  Daun bawang
1. Tambah Sedikit Bawang bombai
1. Diperlukan 1 buah telur
1. Harus ada  Minyak
1. Jangan lupa  Jagung potong2




<!--inarticleads2-->

##### Bagaimana membuat  Seafood ala crazy crab (saus padang ekstra pedas):

1. Bersihkan kepiting+udang+kerang+cumi lumurin jeruk nipis dan garam biar tidak amis
1. Rebus kepiting+kerang supaya lebih matang
1. Rebus udang sebentar
1. Buat bumbu halus : bawang merah, bawang putih, kemiri, cabe merah, cabe caplak, tomat (blender hingga halus seperti saos)
1. Iris bawang bombay dan daun bawang
1. Panaskan minyak Tumis bumbu halus tadi sampai harum
1. Masukkan daun jeruk, daun salam, bawang bombay,
1. Masukkan saos tomat, saos cabai, saos tiram sedikit saja karena rasa saos tiram manis (boleh tidak pakai saos tiram)
1. Larutkan tepung maizena kedalam air aduk sampai tercampur sempurna dan masukkan ke dalam wajan tadi
1. Tambahkan merica bubuk, garam, kaldu bubuk
1. Masukkan cumi yg belum matang, aduk2 hingga cumi matang
1. Masukkan jagung yg sudah di potong2
1. Masukkan udang dan bakso (boleh tdk pakai bakso)
1. Kemudian masukkan daun bawang
1. Kocok lepas telur dan masukkan smbil diaduk supaya telur tercampur sempurna ke bumbu
1. Masukkan kepiting dan kerang yg sudah matang
1. Aduk terus sampai bumbu meresap ke seafood
1. Koreksi rasa, tunggu sampai benar2 matang (air sudah meresap dan bumbu kental) tingkat kekentalan bisa di atur sendiri sesuai selera.. jika ingin sedikit cair bisa tambahkan air lagi aduk2
1. Siap disajikan dengan nasi hangat 🤤🤤




Demikianlah cara membuat seafood ala crazy crab (saus padang ekstra pedas) yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan teruji, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
