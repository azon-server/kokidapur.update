---
description: "Step-by-Step menyiapakan Kue nona manis Teruji"
title: "Step-by-Step menyiapakan Kue nona manis Teruji"
slug: 281-step-by-step-menyiapakan-kue-nona-manis-teruji
date: 2020-10-17T03:21:23.924Z
image: https://img-global.cpcdn.com/recipes/e80d5d2aa558cd07/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e80d5d2aa558cd07/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e80d5d2aa558cd07/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Allen Ingram
ratingvalue: 5
reviewcount: 17081
recipeingredient:
- "6 sdm tepung beras"
- "1 sdm gula pasir"
- "1/4 sdm garam"
- "500 ml santan"
- " 2 Bahan blender"
- "2 btr telur"
- "9 sdm gula pasir"
- "1 sdt vanili bubuk"
- "14 sdm tpung trigu"
- "1 gelas blimbing santan"
- " 3 Bahan masak api sedang"
- "3 sdm tepung beras"
- "4 lmbr daun pndan blender ambil air nya"
- "1 sdt garam"
- "5 sdm gula psir"
- "1 gelas santan"
recipeinstructions:
- "Siapkan panci masak masukan tepung beras, gula pasir, garam dan santan tuang sedikit dlu aduk rata setelah merata masukan sisa santan aduk lg kemudian masak adonan hingga mengental api kecil saja supaya tdk gosong smnil di aduk hingga mengental"
- "Jika sudah mengental matikan api pindah ke mangkok ttup dgn plstik atau wadah yg trtutu supaya kulit atas nya tdk mengeras kemudian"
- "Siapkan blender masukan telur, vanilli, gula pasir, tepung terigu, santan kemudian blender supaya trcmpur rata sisihkan"
- "Siapkan panci masukan tepung beras, air pandan, gula, garam, aduk2 hingga trcmpur rata masak sampai mengental dgn api kecil sebelum adonan mengental masukan adonan yg di blender sebelumnya aduk2 smpai matang jgn trlalu kental. Matikan api saring supaya tdk bergerindil"
- "Panaskan kukusan olesi cetakan adonn dgn minyak tipis2 saja kemudian tuang adonan hijau nya trus adonan putih nya di tengah2 ya lakukan smpai habis aku pakai botol kecap buwat adonan putih nya yg bahan nomer 1 itu supaya gampang di tuang di tengah2 atau pakai pkstik segitiga pun boleh"
- "Ttup kukusan lapisi dgn kain kukus selama 30 mnit"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 296 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Lunch

---


![Kue nona manis](https://img-global.cpcdn.com/recipes/e80d5d2aa558cd07/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita jaga karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti kue nona manis yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan keistimewahan yang merupakan keragaman Indonesia

Kue nona manis adalah salah satu jajanan tradisional yang melegenda di Indonesia. Ada yang tahu kue nona manis? SALAH satu jajanan pasar kue nona manis rasanya sudah jarang ditemui. Meski langkahnya sedikit rumit, ada rasa puas tersendiri saat berhasil membuat kue nona manis.

Kedekatan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Kue nona manis untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang dapat anda coba salah satunya kue nona manis yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini anda bisa dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue nona manis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue nona manis:

1. Diperlukan 6 sdm tepung beras
1. Harus ada 1 sdm gula pasir
1. Tambah 1/4 sdm garam
1. Harap siapkan 500 ml santan
1. Dibutuhkan  2 Bahan blender
1. Harap siapkan 2 btr telur
1. Harap siapkan 9 sdm gula pasir
1. Diperlukan 1 sdt vanili bubuk
1. Harap siapkan 14 sdm tpung trigu
1. Diperlukan 1 gelas blimbing santan
1. Jangan lupa  3 Bahan masak api sedang
1. Diperlukan 3 sdm tepung beras
1. Tambah 4 lmbr daun pndan blender ambil air nya
1. Dibutuhkan 1 sdt garam
1. Tambah 5 sdm gula psir
1. Harap siapkan 1 gelas santan


Nona manis adalah kue khas Sulawesi. Teksturnya lebih lembut dari kue talam Indonesia lainnya. Bagian yang berwarna hijau rasanya manis dan gurih santan, sedangkan bagian yang berwarna putih. Aih, sudah lama rasanya tidak mendengar Kue Nona Manis. 

<!--inarticleads2-->

##### Bagaimana membuat  Kue nona manis:

1. Siapkan panci masak masukan tepung beras, gula pasir, garam dan santan tuang sedikit dlu aduk rata setelah merata masukan sisa santan aduk lg kemudian masak adonan hingga mengental api kecil saja supaya tdk gosong smnil di aduk hingga mengental
1. Jika sudah mengental matikan api pindah ke mangkok ttup dgn plstik atau wadah yg trtutu supaya kulit atas nya tdk mengeras kemudian
1. Siapkan blender masukan telur, vanilli, gula pasir, tepung terigu, santan kemudian blender supaya trcmpur rata sisihkan
1. Siapkan panci masukan tepung beras, air pandan, gula, garam, aduk2 hingga trcmpur rata masak sampai mengental dgn api kecil sebelum adonan mengental masukan adonan yg di blender sebelumnya aduk2 smpai matang jgn trlalu kental. Matikan api saring supaya tdk bergerindil
1. Panaskan kukusan olesi cetakan adonn dgn minyak tipis2 saja kemudian tuang adonan hijau nya trus adonan putih nya di tengah2 ya lakukan smpai habis aku pakai botol kecap buwat adonan putih nya yg bahan nomer 1 itu supaya gampang di tuang di tengah2 atau pakai pkstik segitiga pun boleh
1. Ttup kukusan lapisi dgn kain kukus selama 30 mnit


Bagian yang berwarna hijau rasanya manis dan gurih santan, sedangkan bagian yang berwarna putih. Aih, sudah lama rasanya tidak mendengar Kue Nona Manis. Camilan klasik ini bisa Bunda hadirkan kembali dengan warna menarik yang tidak akan ditolak oleh si kecil. Your current browser isn&#39;t compatible with SoundCloud. Please download one of our supported browsers. 

Demikianlah cara membuat kue nona manis yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
