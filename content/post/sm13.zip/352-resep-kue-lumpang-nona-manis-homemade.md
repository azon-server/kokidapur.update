---
description: "Resep : Kue lumpang/nona manis Homemade"
title: "Resep : Kue lumpang/nona manis Homemade"
slug: 352-resep-kue-lumpang-nona-manis-homemade
date: 2020-10-13T10:06:11.767Z
image: https://img-global.cpcdn.com/recipes/7460bf13affb7e27/680x482cq70/kue-lumpangnona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7460bf13affb7e27/680x482cq70/kue-lumpangnona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7460bf13affb7e27/680x482cq70/kue-lumpangnona-manis-foto-resep-utama.jpg
author: Mitchell Lambert
ratingvalue: 4.8
reviewcount: 47941
recipeingredient:
- " Bahan fla "
- "2 sdm terigu"
- "2 sdm gula"
- "1,5 gls santan matang"
- "2 sdm susu kental"
- " Bahan kue"
- "250 gr terigu"
- "250 gr gula sy pake 200gr"
- "50 gr maizena"
- "1 btr telur"
- "4 gls santan matang"
- " Pewarna makanan"
recipeinstructions:
- "Untuk fla: terigu, gula, susu di campur jd satu. Lalu masukkan santai sedikit demi sedikit sampai tercampur rata dan tdk bergerindil"
- "Lalu masak sampai kental. Lalu masukkan dlm plastik segitiga yg ujungnya d gunting"
- "Utk bahan kue : semua bahan d campur. Masukkan santan sedikit demi sedikit. Lalu aduk sampai rata dan tidak bergerindil"
- "Masukkan adonan ke dalam cetakan kue talam yg sdh d olesi minyak. Lalu masukkan flanya"
- "Kukus selama 15 mnt. Lalu angkat"
- "Kl sdh hangat keluarkan dr cetakan lalu sajikan"
- "Selamat mencoba"
categories:
- Recipe
tags:
- kue
- lumpangnona
- manis

katakunci: kue lumpangnona manis 
nutrition: 208 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Lunch

---


![Kue lumpang/nona manis](https://img-global.cpcdn.com/recipes/7460bf13affb7e27/680x482cq70/kue-lumpangnona-manis-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang dapat kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti kue lumpang/nona manis yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan keistimewahan yang merupakan keragaman Nusantara



Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Kue lumpang/nona manis untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda praktekkan salah satunya kue lumpang/nona manis yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep kue lumpang/nona manis tanpa harus bersusah payah.
Seperti resep Kue lumpang/nona manis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue lumpang/nona manis:

1. Jangan lupa  Bahan fla :
1. Dibutuhkan 2 sdm terigu
1. Harap siapkan 2 sdm gula
1. Harap siapkan 1,5 gls santan matang
1. Siapkan 2 sdm susu kental
1. Harap siapkan  Bahan kue:
1. Siapkan 250 gr terigu
1. Diperlukan 250 gr gula (sy pake 200gr)
1. Harap siapkan 50 gr maizena
1. Jangan lupa 1 btr telur
1. Jangan lupa 4 gls santan matang
1. Dibutuhkan  Pewarna makanan




<!--inarticleads2-->

##### Instruksi membuat  Kue lumpang/nona manis:

1. Untuk fla: terigu, gula, susu di campur jd satu. Lalu masukkan santai sedikit demi sedikit sampai tercampur rata dan tdk bergerindil
1. Lalu masak sampai kental. Lalu masukkan dlm plastik segitiga yg ujungnya d gunting
1. Utk bahan kue : semua bahan d campur. Masukkan santan sedikit demi sedikit. Lalu aduk sampai rata dan tidak bergerindil
1. Masukkan adonan ke dalam cetakan kue talam yg sdh d olesi minyak. Lalu masukkan flanya
1. Kukus selama 15 mnt. Lalu angkat
1. Kl sdh hangat keluarkan dr cetakan lalu sajikan
1. Selamat mencoba




Demikianlah cara membuat kue lumpang/nona manis yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan terbukti, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
