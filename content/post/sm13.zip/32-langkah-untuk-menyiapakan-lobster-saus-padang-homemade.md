---
description: "Langkah untuk menyiapakan Lobster saus padang Homemade"
title: "Langkah untuk menyiapakan Lobster saus padang Homemade"
slug: 32-langkah-untuk-menyiapakan-lobster-saus-padang-homemade
date: 2020-10-23T00:50:27.351Z
image: https://img-global.cpcdn.com/recipes/bf06704efa62dd25/680x482cq70/lobster-saus-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bf06704efa62dd25/680x482cq70/lobster-saus-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bf06704efa62dd25/680x482cq70/lobster-saus-padang-foto-resep-utama.jpg
author: Adele Burke
ratingvalue: 4.9
reviewcount: 20192
recipeingredient:
- "2 ekor lobster ukuran sedang"
- "1 butir telur"
- " Bumbu giling"
- "3 siung bawang putih"
- "5 siung bawang merah"
- "5 buah cabe keriting"
- "2 ruas Laos  lengkuas"
- "1 ruas kunyit"
- "1 ruas jahe"
- " Bumbu utuh"
- "1 batang serai"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "4 batang daun bawang"
- " Bumbu tabur"
- "1 (1/2 sdt) garam"
- "1 sdt chicken powder  penyedap rasa"
- "2 sdt gula pasir"
- "1/2 sdt lada bubuk"
- " Bahan pelengkap"
- " Saos tomat"
- " Saos sambal"
- " Minyak goreng untuk menumis"
recipeinstructions:
- "Bersihkan lobster di belah 2, cuci bersih dan rebus ke dalam air mendidih selama 5 menit sampai cangkangnya berwarna merah ya bun, jgn buang kaldu rebusannya yaaaa;)"
- "Haluskan bumbu gilingnya, setelah halus panaskan minyak untuk menumis. Masukkan bumbu yg sudah di giling. Tambahkan bumbu utuh kecuali daun bawang yaaa. Tumis sampai harum"
- "Setelah harum masukkan bumbu tabur dan bumbu pelengkap yaaa kalo banyak saosnya sesuai selerah yaa bunda, kocok lepas telur dan tambahkan ke dalam tumisan lalu beri 150ml air kaldu lobster dari rebusan tadi yaaa :)"
- "Masukkan lobsternya, masak sampai matang yaaa jgn lupa icip2 kalo kurang pas di lidah tambahin bumbunya sesuai selerah, tambahkan daun bawang yg sudah di potong2. Semoga cocok yaaa bun❤️"
- "Lobster saus Padang siap di sajikan, selamat mencoba"
categories:
- Recipe
tags:
- lobster
- saus
- padang

katakunci: lobster saus padang 
nutrition: 125 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT30M"
recipeyield: "1"
recipecategory: Lunch

---


![Lobster saus padang](https://img-global.cpcdn.com/recipes/bf06704efa62dd25/680x482cq70/lobster-saus-padang-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga empuk. Ciri khas kuliner Nusantara lobster saus padang yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Lobster saus padang untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang dapat anda buat salah satunya lobster saus padang yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep lobster saus padang tanpa harus bersusah payah.
Seperti resep Lobster saus padang yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 23 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Lobster saus padang:

1. Jangan lupa 2 ekor lobster ukuran sedang
1. Siapkan 1 butir telur
1. Jangan lupa  Bumbu giling
1. Jangan lupa 3 siung bawang putih
1. Diperlukan 5 siung bawang merah
1. Siapkan 5 buah cabe keriting
1. Tambah 2 ruas Laos / lengkuas
1. Jangan lupa 1 ruas kunyit
1. Harus ada 1 ruas jahe
1. Siapkan  Bumbu utuh
1. Harus ada 1 batang serai
1. Dibutuhkan 2 lembar daun jeruk
1. Jangan lupa 2 lembar daun salam
1. Harus ada 4 batang daun bawang
1. Harus ada  Bumbu tabur
1. Harap siapkan 1 (1/2 sdt) garam
1. Harap siapkan 1 sdt chicken powder / penyedap rasa
1. Diperlukan 2 sdt gula pasir
1. Dibutuhkan 1/2 sdt lada bubuk
1. Diperlukan  Bahan pelengkap
1. Siapkan  Saos tomat
1. Harus ada  Saos sambal
1. Siapkan  Minyak goreng untuk menumis




<!--inarticleads2-->

##### Cara membuat  Lobster saus padang:

1. Bersihkan lobster di belah 2, cuci bersih dan rebus ke dalam air mendidih selama 5 menit sampai cangkangnya berwarna merah ya bun, jgn buang kaldu rebusannya yaaaa;)
1. Haluskan bumbu gilingnya, setelah halus panaskan minyak untuk menumis. Masukkan bumbu yg sudah di giling. Tambahkan bumbu utuh kecuali daun bawang yaaa. Tumis sampai harum
1. Setelah harum masukkan bumbu tabur dan bumbu pelengkap yaaa kalo banyak saosnya sesuai selerah yaa bunda, kocok lepas telur dan tambahkan ke dalam tumisan lalu beri 150ml air kaldu lobster dari rebusan tadi yaaa :)
1. Masukkan lobsternya, masak sampai matang yaaa jgn lupa icip2 kalo kurang pas di lidah tambahin bumbunya sesuai selerah, tambahkan daun bawang yg sudah di potong2. Semoga cocok yaaa bun❤️
1. Lobster saus Padang siap di sajikan, selamat mencoba




Demikianlah cara membuat lobster saus padang yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
