---
description: "Steps untuk membuat Soto Padang minggu ini"
title: "Steps untuk membuat Soto Padang minggu ini"
slug: 232-steps-untuk-membuat-soto-padang-minggu-ini
date: 2020-12-11T15:53:07.942Z
image: https://img-global.cpcdn.com/recipes/b3d87c448ff798da/680x482cq70/soto-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b3d87c448ff798da/680x482cq70/soto-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b3d87c448ff798da/680x482cq70/soto-padang-foto-resep-utama.jpg
author: Aiden Mathis
ratingvalue: 4.2
reviewcount: 7053
recipeingredient:
- "400 gr daging sapi potong dadu"
- "200 gr paru"
- "2 batang daun bawang iris"
- "1 ikat seledri iris"
- "1/2 sdt garam"
- "1 sdt kaldu sapi"
- "2 liter air untuk merebus"
- "secukupnya minyak goreng untuk menumis"
- " Bumbu halus"
- "5 siung bawang putih"
- "11 siung bawang merah"
- "2 cm jahe"
- "4 cm lengkuas"
- "1 sdt garam"
- " Bumbu rempah"
- "1 batang serai geprek"
- "4 lembar daun salam"
- "3 lembar daun jeruk buang bagian tulang daun"
- "3 butir bunga lawang sangrai"
- "4 butir kapulaga sangrai"
- "8 butir cengkeh sangrai"
- "2 cm kayu manis sangrai"
- "1/2 sdt lada bubuk"
- "1/4 sdt pala bubuk bisa dr biji pala parut sangrai sebelumnya"
- "1/4 sdt jinten bubuk"
- " Pelengkap"
- " Soun"
- " Tomat belah"
- " Perkedel kentang"
- " Bawang goreng"
- " Kerupuk pink"
- " Sambal rawit merah rebus"
- " Jeruk nipis"
recipeinstructions:
- "Rebus daging sapi dengan sedikit air sampai mendidih dan keluar busa kotorannya. Ambil dan buang kotoran yang mengapung. Matikan api lalu buang air bekas rebusannya. Sisihkan."
- "Rebus 2 liter air baru. Masukkan daging, daun bawang, dan seledri. Masak hingga daging empuk. Kecilkan api."
- "Haluskan bumbu dengan menggunakan ulekan / blender sampai benar-benar halus."
- "Panaskan sedikit minyak, tumis bumbu halus dan bahan rempah hingga harum. Matikan api."
- "Tuang tumisan bumbu ke dalam panci rebusan. Masukkan kaldu sapi dan garam. Masak kuah hingga mendidih lalu koreksi rasanya. Matikan api."
- "Ambil paru, lalu potong jadi dadu kecil atau iris tipis. Goreng paru dalam minyak panas sampai kering. Angkat dan tiriskan. Sisihkan."
- "Tata soun, tomat, paru goreng, dan perkedel kentang dalam mangkok saji. Siram dengan kuah. Taburi dengan bawang goreng dan beri kerupuk pink. Soto siap disajikan dengan sambal dan irisan jeruk nipis."
categories:
- Recipe
tags:
- soto
- padang

katakunci: soto padang 
nutrition: 267 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Dessert

---


![Soto Padang](https://img-global.cpcdn.com/recipes/b3d87c448ff798da/680x482cq70/soto-padang-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang harus kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti soto padang yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan ciri khas yang merupakan keragaman Kita



Kedekatan keluarga bisa diperoleh dengan cara simple. Diantaranya adalah membuat makanan Soto Padang untuk orang di rumah. Momen makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang bisa anda coba salah satunya soto padang yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep soto padang tanpa harus bersusah payah.
Berikut ini resep Soto Padang yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 33 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Soto Padang:

1. Diperlukan 400 gr daging sapi, potong dadu
1. Diperlukan 200 gr paru
1. Tambah 2 batang daun bawang, iris
1. Harus ada 1 ikat seledri, iris
1. Tambah 1/2 sdt garam
1. Harus ada 1 sdt kaldu sapi
1. Jangan lupa 2 liter air untuk merebus
1. Jangan lupa secukupnya minyak goreng untuk menumis
1. Tambah  Bumbu halus
1. Harus ada 5 siung bawang putih
1. Diperlukan 11 siung bawang merah
1. Diperlukan 2 cm jahe
1. Jangan lupa 4 cm lengkuas
1. Tambah 1 sdt garam
1. Jangan lupa  Bumbu rempah
1. Dibutuhkan 1 batang serai, geprek
1. Siapkan 4 lembar daun salam
1. Jangan lupa 3 lembar daun jeruk, buang bagian tulang daun
1. Jangan lupa 3 butir bunga lawang, sangrai
1. Dibutuhkan 4 butir kapulaga, sangrai
1. Siapkan 8 butir cengkeh, sangrai
1. Tambah 2 cm kayu manis, sangrai
1. Tambah 1/2 sdt lada bubuk
1. Diperlukan 1/4 sdt pala bubuk (bisa dr biji pala parut, sangrai sebelumnya)
1. Jangan lupa 1/4 sdt jinten bubuk
1. Dibutuhkan  Pelengkap
1. Tambah  Soun
1. Harap siapkan  Tomat, belah
1. Harus ada  Perkedel kentang
1. Jangan lupa  Bawang goreng
1. Dibutuhkan  Kerupuk pink
1. Tambah  Sambal rawit merah, rebus
1. Dibutuhkan  Jeruk nipis




<!--inarticleads2-->

##### Cara membuat  Soto Padang:

1. Rebus daging sapi dengan sedikit air sampai mendidih dan keluar busa kotorannya. Ambil dan buang kotoran yang mengapung. Matikan api lalu buang air bekas rebusannya. Sisihkan.
1. Rebus 2 liter air baru. Masukkan daging, daun bawang, dan seledri. Masak hingga daging empuk. Kecilkan api.
1. Haluskan bumbu dengan menggunakan ulekan / blender sampai benar-benar halus.
1. Panaskan sedikit minyak, tumis bumbu halus dan bahan rempah hingga harum. Matikan api.
1. Tuang tumisan bumbu ke dalam panci rebusan. Masukkan kaldu sapi dan garam. Masak kuah hingga mendidih lalu koreksi rasanya. Matikan api.
1. Ambil paru, lalu potong jadi dadu kecil atau iris tipis. Goreng paru dalam minyak panas sampai kering. Angkat dan tiriskan. Sisihkan.
1. Tata soun, tomat, paru goreng, dan perkedel kentang dalam mangkok saji. Siram dengan kuah. Taburi dengan bawang goreng dan beri kerupuk pink. Soto siap disajikan dengan sambal dan irisan jeruk nipis.




Demikianlah cara membuat soto padang yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan terbukti, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
