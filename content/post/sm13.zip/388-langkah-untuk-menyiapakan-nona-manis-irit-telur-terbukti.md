---
description: "Langkah untuk menyiapakan Nona Manis irit telur Terbukti"
title: "Langkah untuk menyiapakan Nona Manis irit telur Terbukti"
slug: 388-langkah-untuk-menyiapakan-nona-manis-irit-telur-terbukti
date: 2021-02-26T09:23:32.813Z
image: https://img-global.cpcdn.com/recipes/c34044d086e2d280/680x482cq70/nona-manis-irit-telur-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c34044d086e2d280/680x482cq70/nona-manis-irit-telur-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c34044d086e2d280/680x482cq70/nona-manis-irit-telur-foto-resep-utama.jpg
author: Christopher Rose
ratingvalue: 5
reviewcount: 22694
recipeingredient:
- " Bahan 1 "
- "180 gram gula pasir"
- "250 gram Tepung terigu"
- "500 ml santan cair"
- "1 butir telur"
- " Pewarna makanan hijau"
- "secukupnya Vanili bubuk"
- " Bahan 2 "
- "500 ml santan cair"
- "60 gram gula pasir"
- "60 gram maizena"
- "secukupnya Pasta pandan"
- " Bahan vla "
- "400 ml santan cair"
- "2 sdm maizena"
- " Gula pasir secukupnyasesuai tingkat kemanisan me  60 gram gula pasir"
- "secukupnya Garam"
recipeinstructions:
- "Siapkan bahan- bahan, campur bahan 1, aduk hingga tercampur rata dan tmbahkan pewarna makanan secukupnya dan sisihkan"
- "Selanjutnya, bahan ke 2, campur semua bahan hingga tercampur rata dalam panci, kemudian tambahkan pasta pandan secukupnya dan masak tepung maizena cukup sampai teksturnya seperti bubur, jngan terlalu kental 😊"
- "Setelah adonan 2 dimasak, kemudian msukkan ke adonan 1 dan aduk hingga tercampur rata. (dimasukkan adonan 2 pada saat masih panas😊ya)"
- "Membuat vla nona manis, campur semua bahan vla, masak dengan api kecil sambil terus diaduk agar tidak bergerindil. Untuk tekstur vlanya jangan terlalu kental sampai kya adonan 😊 cukup dimsak sampai teksturnya kental tapi masih cair. Vlanya yg sdah dimsak segera masukkan ke dalam btol saos agar tidak beku 😉"
- "Selanjutnya tuang adonan kue nona manis yg warna hijau ke cetakan yg sdh diolesi minyak goreng dan semprotkan vla diatas adonan hijau"
- "Kukus kue nona manis selama 15 menit dengan api sedang dan tutup kukusan dialasi serbet."
- "Ini hasil kue nona manisnya 😉selamat mencoba"
categories:
- Recipe
tags:
- nona
- manis
- irit

katakunci: nona manis irit 
nutrition: 298 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Lunch

---


![Nona Manis irit telur](https://img-global.cpcdn.com/recipes/c34044d086e2d280/680x482cq70/nona-manis-irit-telur-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti nona manis irit telur yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Nusantara

Kehangatan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Nona Manis irit telur untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang bisa anda contoh salah satunya nona manis irit telur yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep nona manis irit telur tanpa harus bersusah payah.
Seperti resep Nona Manis irit telur yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nona Manis irit telur:

1. Diperlukan  Bahan 1 :
1. Diperlukan 180 gram gula pasir
1. Siapkan 250 gram Tepung terigu
1. Harap siapkan 500 ml santan cair
1. Harap siapkan 1 butir telur
1. Diperlukan  Pewarna makanan (hijau)
1. Harap siapkan secukupnya Vanili bubuk
1. Tambah  Bahan 2 :
1. Diperlukan 500 ml santan cair
1. Siapkan 60 gram gula pasir
1. Diperlukan 60 gram maizena
1. Tambah secukupnya Pasta pandan
1. Jangan lupa  Bahan vla :
1. Siapkan 400 ml santan cair
1. Harap siapkan 2 sdm maizena
1. Diperlukan  Gula pasir secukupnya/sesuai tingkat kemanisan (me : 60 gram gula pasir)
1. Tambah secukupnya Garam




<!--inarticleads2-->

##### Langkah membuat  Nona Manis irit telur:

1. Siapkan bahan- bahan, campur bahan 1, aduk hingga tercampur rata dan tmbahkan pewarna makanan secukupnya dan sisihkan
1. Selanjutnya, bahan ke 2, campur semua bahan hingga tercampur rata dalam panci, kemudian tambahkan pasta pandan secukupnya dan masak tepung maizena cukup sampai teksturnya seperti bubur, jngan terlalu kental 😊
1. Setelah adonan 2 dimasak, kemudian msukkan ke adonan 1 dan aduk hingga tercampur rata. (dimasukkan adonan 2 pada saat masih panas😊ya)
1. Membuat vla nona manis, campur semua bahan vla, masak dengan api kecil sambil terus diaduk agar tidak bergerindil. Untuk tekstur vlanya jangan terlalu kental sampai kya adonan 😊 cukup dimsak sampai teksturnya kental tapi masih cair. Vlanya yg sdah dimsak segera masukkan ke dalam btol saos agar tidak beku 😉
1. Selanjutnya tuang adonan kue nona manis yg warna hijau ke cetakan yg sdh diolesi minyak goreng dan semprotkan vla diatas adonan hijau
1. Kukus kue nona manis selama 15 menit dengan api sedang dan tutup kukusan dialasi serbet.
1. Ini hasil kue nona manisnya 😉selamat mencoba




Demikianlah cara membuat nona manis irit telur yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
