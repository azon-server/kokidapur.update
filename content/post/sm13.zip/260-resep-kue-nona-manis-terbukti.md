---
description: "Resep : Kue Nona Manis Terbukti"
title: "Resep : Kue Nona Manis Terbukti"
slug: 260-resep-kue-nona-manis-terbukti
date: 2020-12-02T16:37:04.580Z
image: https://img-global.cpcdn.com/recipes/8fc19f95ca885b42/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8fc19f95ca885b42/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8fc19f95ca885b42/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Rodney Greer
ratingvalue: 4
reviewcount: 29183
recipeingredient:
- " Bahan A"
- "1 butir telur"
- "250 cc santan"
- "125 gr gula"
- "125 gr terigu"
- " Bahan B"
- "125 cc santan"
- "125 Jus pandan8 lembar daun pandan"
- "30 gr maizena"
- "60 gr gula"
- "1/2 sejumput garam"
- "2 Teresa pewarna pangan hijau"
- " Bahan C"
- "250 cc santan kental"
- "1 sdm munjung terigu"
- "1 sdt garam"
- "1 sdm gula"
recipeinstructions:
- "Siapkan semua bahan A. Blender gula hingga halus"
- "Campur semua bahan A aduk merata hingga tidak bergerindil. Sisihkan."
- "Siapkan semua bahan B. Blender daun pandan yang sudah di potong dan tambahkan air hingga halus."
- "Campur semua bahan B. Aduk merata dan masukan sari pandan sambil di saring. Tambahkan 2 tetes pewarna pangan hijau."
- "Masak ia tas api kecil hingga meletup-letup. Lalu matikan api."
- "Campur bahan A (sambil di saring) dan B aduk hingga tercampur merata. Siapkan cetakan yang sudah di olesi tipis dengan Minyak goreng. Lalu tuang adonan 3/4 tinggi cetakan. Sisihkan."
- "Siapkan bahan C. Campur semua bahan C. Masak diatas api kecil hingga sedikit mendidi lalu matikan api. Biarkan dulu hingga hangat lalu tuang pada Pipingbag."
- "Potong ujung Pipingbag. Dan masukan (ujung Pipingbag tenggelamkan) pada cetakan berisi adonan, hingga volume adonan di dalam cetakan bertambah naik. Lalu angkat Pipingbag dan isikan hingga semua adonan dalam cetakan terisi oleh adonan C. Lalu kukus (pastikan kukusan sudah panas) selama 15 menit."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 118 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dinner

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/8fc19f95ca885b42/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau renyah. Ciri kuliner Nusantara kue nona manis yang kaya dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa didapat dengan cara sederhana. Salah satunya adalah memasak Kue Nona Manis untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang bisa anda coba salah satunya kue nona manis yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Harus ada  Bahan A:
1. Dibutuhkan 1 butir telur
1. Harap siapkan 250 cc santan
1. Harap siapkan 125 gr gula
1. Jangan lupa 125 gr terigu
1. Dibutuhkan  Bahan B:
1. Diperlukan 125 cc santan
1. Diperlukan 125 Jus pandan(8 lembar daun pandan)
1. Siapkan 30 gr maizena
1. Harap siapkan 60 gr gula
1. Tambah 1/2 sejumput garam
1. Jangan lupa 2 Teresa pewarna pangan hijau
1. Diperlukan  Bahan C:
1. Siapkan 250 cc santan kental
1. Tambah 1 sdm munjung terigu
1. Jangan lupa 1 sdt garam
1. Tambah 1 sdm gula




<!--inarticleads2-->

##### Bagaimana membuat  Kue Nona Manis:

1. Siapkan semua bahan A. Blender gula hingga halus
1. Campur semua bahan A aduk merata hingga tidak bergerindil. Sisihkan.
1. Siapkan semua bahan B. Blender daun pandan yang sudah di potong dan tambahkan air hingga halus.
1. Campur semua bahan B. Aduk merata dan masukan sari pandan sambil di saring. Tambahkan 2 tetes pewarna pangan hijau.
1. Masak ia tas api kecil hingga meletup-letup. Lalu matikan api.
1. Campur bahan A (sambil di saring) dan B aduk hingga tercampur merata. Siapkan cetakan yang sudah di olesi tipis dengan Minyak goreng. Lalu tuang adonan 3/4 tinggi cetakan. Sisihkan.
1. Siapkan bahan C. Campur semua bahan C. Masak diatas api kecil hingga sedikit mendidi lalu matikan api. Biarkan dulu hingga hangat lalu tuang pada Pipingbag.
1. Potong ujung Pipingbag. Dan masukan (ujung Pipingbag tenggelamkan) pada cetakan berisi adonan, hingga volume adonan di dalam cetakan bertambah naik. Lalu angkat Pipingbag dan isikan hingga semua adonan dalam cetakan terisi oleh adonan C. Lalu kukus (pastikan kukusan sudah panas) selama 15 menit.




Demikianlah cara membuat kue nona manis yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan terbukti, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
