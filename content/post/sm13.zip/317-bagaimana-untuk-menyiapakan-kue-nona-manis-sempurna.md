---
description: "Bagaimana untuk menyiapakan Kue Nona Manis Sempurna"
title: "Bagaimana untuk menyiapakan Kue Nona Manis Sempurna"
slug: 317-bagaimana-untuk-menyiapakan-kue-nona-manis-sempurna
date: 2020-10-02T08:49:12.685Z
image: https://img-global.cpcdn.com/recipes/df9b02f4b810a136/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/df9b02f4b810a136/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/df9b02f4b810a136/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Lora Powell
ratingvalue: 4.5
reviewcount: 40873
recipeingredient:
- " Bahan A"
- "250 ml santan kental"
- "80 gr gula pasir"
- "140 gr tepung terigu serbaguna"
- "1 butir telur ayam"
- " Bahan B"
- "250 ml santan kental"
- "30 gr maizena"
- "40 gr gula pasir"
- "Secukupnya pasta pandan lg males bkin jus pandan sndiri"
- " Bahan C"
- "500 ml santan"
- "6 SDM terigu serbaguna"
- "1/2 SDT garam"
recipeinstructions:
- "Mixer bahan A, masukan sedikit demi sedikit secara bergantian santan dn terigunya. Sisihkan"
- "Masak bahan B dengan api kecil aduk aduk supaya ga menggerindil. Setelah matang dinginkan. Lalu campurkan dengan bahan A, mixer kembali supaya tercampur rata."
- "Siapkan cetakan talam yang sudah dioles dengan minyak, masukkan kedalam cetakan 3/4 bagian saja."
- "Masak bahan C, aduk2 supaya terigunya ga gerindil ya. Setelah dingin masukkan ke dalam piping bag. Lalu isikan ke bagian tengah adonan hijau tadi, saat mengisi masukkan ujung piping bag aga tenggelam kedalam ya."
- "Kukus di dandang yg sdh mendidih kurleb 15-20menit. Usahakan tutup dandang di beri alas lap bersih ya bun."
- "Setelah matang dinginkan, untuk mengeluarkan nya ckup dibantu dengan sendok kecil."
- "Selamat mencoba.. 👌🏻"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 260 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Dinner

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/df9b02f4b810a136/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau renyah. Ciri khas kuliner Nusantara kue nona manis yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Kue Nona Manis untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang dapat anda contoh salah satunya kue nona manis yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep kue nona manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Harap siapkan  Bahan A
1. Tambah 250 ml santan kental
1. Siapkan 80 gr gula pasir
1. Jangan lupa 140 gr tepung terigu serbaguna
1. Jangan lupa 1 butir telur ayam
1. Dibutuhkan  Bahan B
1. Jangan lupa 250 ml santan kental
1. Dibutuhkan 30 gr maizena
1. Diperlukan 40 gr gula pasir
1. Tambah Secukupnya pasta pandan (lg males bkin jus pandan sndiri)
1. Tambah  Bahan C
1. Harap siapkan 500 ml santan
1. Harus ada 6 SDM terigu serbaguna
1. Harus ada 1/2 SDT garam




<!--inarticleads2-->

##### Cara membuat  Kue Nona Manis:

1. Mixer bahan A, masukan sedikit demi sedikit secara bergantian santan dn terigunya. Sisihkan
1. Masak bahan B dengan api kecil aduk aduk supaya ga menggerindil. Setelah matang dinginkan. Lalu campurkan dengan bahan A, mixer kembali supaya tercampur rata.
1. Siapkan cetakan talam yang sudah dioles dengan minyak, masukkan kedalam cetakan 3/4 bagian saja.
1. Masak bahan C, aduk2 supaya terigunya ga gerindil ya. Setelah dingin masukkan ke dalam piping bag. Lalu isikan ke bagian tengah adonan hijau tadi, saat mengisi masukkan ujung piping bag aga tenggelam kedalam ya.
1. Kukus di dandang yg sdh mendidih kurleb 15-20menit. Usahakan tutup dandang di beri alas lap bersih ya bun.
1. Setelah matang dinginkan, untuk mengeluarkan nya ckup dibantu dengan sendok kecil.
1. Selamat mencoba.. 👌🏻




Demikianlah cara membuat kue nona manis yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan cepat, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
