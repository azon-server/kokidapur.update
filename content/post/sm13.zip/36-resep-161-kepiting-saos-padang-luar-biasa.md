---
description: "Resep : #161 Kepiting Saos Padang Luar biasa"
title: "Resep : #161 Kepiting Saos Padang Luar biasa"
slug: 36-resep-161-kepiting-saos-padang-luar-biasa
date: 2020-09-27T08:47:48.596Z
image: https://img-global.cpcdn.com/recipes/d8e8952ddacee983/680x482cq70/161-kepiting-saos-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d8e8952ddacee983/680x482cq70/161-kepiting-saos-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d8e8952ddacee983/680x482cq70/161-kepiting-saos-padang-foto-resep-utama.jpg
author: Agnes Turner
ratingvalue: 4.1
reviewcount: 44643
recipeingredient:
- "10 biji kepiting kecil"
- "2 buah jagung potongpotong"
- "1 ruas jahe geprek direbus bareng kepiting"
- "1 batang daun bawang iris"
- "1 butir telur"
- "1 siung bwg bombay iris"
- "2 sdm saos tiram"
- "Secukupnya saos sambal extra pedas"
- "Secukupnya saos tomat"
- "Secukupnya gula garam"
- "1/4 sdt micin sasa"
- "1 sdm tepung maizena larutkan ke dalam 2sdm air"
- " Bumbu Cemplung"
- "1 btg sereh geprek"
- "1 ruas lengkuas geprek"
- "3 lembar daun jeruk"
- "2 lembar daun salam"
- " Bumbu Halus"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "7 biji cabe merah"
- "13 biji cabe rawit opsional mau pedes bisa tambah"
- "1 ruas jahe geprek"
- "1 ruas kunyit"
- "3 buah kemiri"
- "1 sdt merica  lada bubuk"
recipeinstructions:
- "Didihkan air, masukkan kepiting, jagung potong, dan jahe geprek. Rebus hingga jagung matang, matikan lalu tiriskan. Air rebusan jangan dibuang."
- "Panaskan secukupnya minyak, masukkan bumbu halus dan bawang bombay, tambahkan bumbu cemplung. Masak hingga harum dan matang."
- "Tambahkan air kaldu bekas rebusan sesuai selera. Tambahkan saos sambal, saos tomat, saos tiram, gula, garam, dan micin lalu aduk rata. Tambahkan telur orak arik."
- "Tes rasa, kalau sudah oke masukkan kepiting dan jagung. Aduk rata, diamkan +-5 menit sampai bumbu meresap. Tambahkan sedikit cairan maizena. Masukkan irisan daun bawang, aduk rata, matikan api. Selamat mencoba."
categories:
- Recipe
tags:
- 161
- kepiting
- saos

katakunci: 161 kepiting saos 
nutrition: 199 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Dessert

---


![#161 Kepiting Saos Padang](https://img-global.cpcdn.com/recipes/d8e8952ddacee983/680x482cq70/161-kepiting-saos-padang-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti #161 kepiting saos padang yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Nusantara

Kedekatan keluarga bisa diperoleh dengan cara sederhana. Diantaranya adalah memasak #161 Kepiting Saos Padang untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang bisa anda praktekkan salah satunya #161 kepiting saos padang yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep #161 kepiting saos padang tanpa harus bersusah payah.
Seperti resep #161 Kepiting Saos Padang yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 26 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat #161 Kepiting Saos Padang:

1. Tambah 10 biji kepiting kecil
1. Harap siapkan 2 buah jagung, potong-potong
1. Harus ada 1 ruas jahe, geprek direbus bareng kepiting
1. Dibutuhkan 1 batang daun bawang, iris
1. Diperlukan 1 butir telur
1. Tambah 1 siung bwg bombay, iris
1. Jangan lupa 2 sdm saos tiram
1. Harus ada Secukupnya saos sambal extra pedas
1. Harap siapkan Secukupnya saos tomat
1. Siapkan Secukupnya gula, garam
1. Siapkan 1/4 sdt micin sasa
1. Siapkan 1 sdm tepung maizena, larutkan ke dalam 2sdm air
1. Dibutuhkan  Bumbu Cemplung:
1. Jangan lupa 1 btg sereh, geprek
1. Tambah 1 ruas lengkuas, geprek
1. Tambah 3 lembar daun jeruk
1. Dibutuhkan 2 lembar daun salam
1. Dibutuhkan  Bumbu Halus:
1. Siapkan 6 siung bawang merah
1. Dibutuhkan 4 siung bawang putih
1. Diperlukan 7 biji cabe merah
1. Dibutuhkan 13 biji cabe rawit (opsional mau pedes bisa tambah)
1. Siapkan 1 ruas jahe, geprek
1. Dibutuhkan 1 ruas kunyit
1. Tambah 3 buah kemiri
1. Harus ada 1 sdt merica / lada bubuk




<!--inarticleads2-->

##### Cara membuat  #161 Kepiting Saos Padang:

1. Didihkan air, masukkan kepiting, jagung potong, dan jahe geprek. Rebus hingga jagung matang, matikan lalu tiriskan. Air rebusan jangan dibuang.
1. Panaskan secukupnya minyak, masukkan bumbu halus dan bawang bombay, tambahkan bumbu cemplung. Masak hingga harum dan matang.
1. Tambahkan air kaldu bekas rebusan sesuai selera. Tambahkan saos sambal, saos tomat, saos tiram, gula, garam, dan micin lalu aduk rata. Tambahkan telur orak arik.
1. Tes rasa, kalau sudah oke masukkan kepiting dan jagung. Aduk rata, diamkan +-5 menit sampai bumbu meresap. Tambahkan sedikit cairan maizena. Masukkan irisan daun bawang, aduk rata, matikan api. Selamat mencoba.




Demikianlah cara membuat #161 kepiting saos padang yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan cepat, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
