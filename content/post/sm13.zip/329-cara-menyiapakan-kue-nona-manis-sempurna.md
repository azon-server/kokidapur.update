---
description: "Cara menyiapakan Kue Nona Manis Sempurna"
title: "Cara menyiapakan Kue Nona Manis Sempurna"
slug: 329-cara-menyiapakan-kue-nona-manis-sempurna
date: 2020-11-04T07:37:39.241Z
image: https://img-global.cpcdn.com/recipes/930e09bd70752766/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/930e09bd70752766/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/930e09bd70752766/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Dennis Mann
ratingvalue: 4.6
reviewcount: 1878
recipeingredient:
- " Bahan 1 hijau "
- "500 gr terigu"
- "500 gr gula pasir"
- "2000 ml santan matang dari 2 btr kelapa"
- "3 butir telur"
- "35 gr tepung maizena"
- "35 gr tepung beras"
- "1/2 sdt vanilli"
- "100 ml air pandansuji30 lbr daun pandansuji diblendersaring"
- "3 tetes pasta pandan"
- " Bahan 2 putih "
- "35 gr tepung maizena"
- "35 gr tepung beras"
- "600 ml santan kental matang"
- "3/4 sdt garam"
recipeinstructions:
- "Campur semua bahan 1 jadi satu, aduk rata dgn mixer sebentar saja hingga tercampur rata bisa juga hanya dengan whisker. #Bila masih ada adonan yang bergerindil saring adonan hingga adonan halus tak bergerindil."
- "Campur bahan II jadi satu, rebus di kompor hingga mengental, angkat, sisihkan.#bila terlalu kental bisa di tambahkan santan cair lagi,masak hingga meletup2 angkat dan masukkan ke dalam botol kecap agar memudahkan saat menuang adonan nanti."
- "Dengan cetakan cucing &gt;&gt; Masukan adonan hijau ke dlm cetakan yg sudah diolesi minyak sayur sebanyak 3/4 bagian lalu masukan 1 sdt adonan putih. • dengan cetakan Jasmine &gt;&gt; sendokan adonan putih ke bagian tengah cetakan lalu tuang adonan hijau"
- "Kukus selama 20 menit, pake cetakan Jasmine 25 menit, angkat. Tunggu kue agak dingin sebentar lalu keluarkan dari cetakan, siap dihidangkan."
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 187 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Dessert

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/930e09bd70752766/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga enak. Karasteristik masakan Nusantara kue nona manis yang penuh dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah membuat makanan Kue Nona Manis untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian masakan yang dapat anda contoh salah satunya kue nona manis yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 15 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Diperlukan  Bahan 1 (hijau) :
1. Tambah 500 gr terigu
1. Harus ada 500 gr gula pasir
1. Harap siapkan 2000 ml santan matang (dari 2 btr kelapa)
1. Diperlukan 3 butir telur
1. Siapkan 35 gr tepung maizena
1. Siapkan 35 gr tepung beras
1. Dibutuhkan 1/2 sdt vanilli
1. Dibutuhkan 100 ml air pandan+suji(30 lbr daun pandan+suji diblender,saring)
1. Jangan lupa 3 tetes pasta pandan
1. Siapkan  Bahan 2 (putih) :
1. Siapkan 35 gr tepung maizena
1. Harap siapkan 35 gr tepung beras
1. Siapkan 600 ml santan kental matang
1. Harus ada 3/4 sdt garam




<!--inarticleads2-->

##### Bagaimana membuat  Kue Nona Manis:

1. Campur semua bahan 1 jadi satu, aduk rata dgn mixer sebentar saja hingga tercampur rata bisa juga hanya dengan whisker. #Bila masih ada adonan yang bergerindil saring adonan hingga adonan halus tak bergerindil.
1. Campur bahan II jadi satu, rebus di kompor hingga mengental, angkat, sisihkan.#bila terlalu kental bisa di tambahkan santan cair lagi,masak hingga meletup2 angkat dan masukkan ke dalam botol kecap agar memudahkan saat menuang adonan nanti.
1. Dengan cetakan cucing &gt;&gt; Masukan adonan hijau ke dlm cetakan yg sudah diolesi minyak sayur sebanyak 3/4 bagian lalu masukan 1 sdt adonan putih. - • dengan cetakan Jasmine &gt;&gt; sendokan adonan putih ke bagian tengah cetakan lalu tuang adonan hijau
1. Kukus selama 20 menit, pake cetakan Jasmine 25 menit, angkat. - Tunggu kue agak dingin sebentar lalu keluarkan dari cetakan, siap dihidangkan.




Demikianlah cara membuat kue nona manis yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
