---
description: "Resep : Kue Nona Manis/Cantik Manis Cepat"
title: "Resep : Kue Nona Manis/Cantik Manis Cepat"
slug: 333-resep-kue-nona-manis-cantik-manis-cepat
date: 2020-09-28T08:10:13.575Z
image: https://img-global.cpcdn.com/recipes/d83890833b73791f/680x482cq70/kue-nona-maniscantik-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d83890833b73791f/680x482cq70/kue-nona-maniscantik-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d83890833b73791f/680x482cq70/kue-nona-maniscantik-manis-foto-resep-utama.jpg
author: Edwin Martin
ratingvalue: 4.8
reviewcount: 49093
recipeingredient:
- " 1 Bahan"
- "3 butir telur ayam"
- "2 gelas santan"
- "2 gelas terigu"
- "1 gelas gula pasir"
- " 2 Bahan"
- "2 gelas santan dibelender bersama daun pandan secukupnya"
- "1/2 gelas maizena"
- "1/2 gelas gula pasir"
- "1/2 sdt garam"
- " 3 Bahan"
- "2 gelas santan kental"
- "2 sdm gula pasir"
- "2 sdm terigu"
- "1/2 sdt garam"
recipeinstructions:
- "Bahan 2: campur santan pandan, gula pasir dan maizena. Masak diatas kompor sambil diaduk terus sampai meletup-letup. Angkat, biarkan sampai hangat"
- "Bahan 1: kocok telur dan gula sampai mengembang. Masukkan terigu, kocok lagi. Tuang santan lalu aduk sampai rata"
- "Campurkan adonan 1 dan 2, gunakan mixer hingga tercampur rata. Sisihkan"
- "Panaskan dandang untuk mengukus. Jangan lupa lapisi tutup panci dengan kain bersih agar uapnya tdk menetes"
- "Bahan 3: campur santan kental, gula, garam dan terigu. Aduk hingga rata dan tdk bergelindir. Masak sambil terus diaduk agar santan tdk pecah. Setelah mendidih angkat segera dari kompor"
- "Siapkan cetakan kue talam yg sudah diolesi minyak. Tuang adonan pandan hingga hampir penuh lalu beri tengahnya adonan putih menggunakan sendok"
- "Kukus selama 10-15 menit atau hingga matang"
- "Angkat dari kukusan. Tunggu hingga dingin agar mudah dilepas"
- "Siap dinikmati bersama teh hangat😊"
categories:
- Recipe
tags:
- kue
- nona
- maniscantik

katakunci: kue nona maniscantik 
nutrition: 254 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Dinner

---


![Kue Nona Manis/Cantik Manis](https://img-global.cpcdn.com/recipes/d83890833b73791f/680x482cq70/kue-nona-maniscantik-manis-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas hingga enak. Ciri khas makanan Indonesia kue nona manis/cantik manis yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Kue Nona Manis/Cantik Manis untuk keluarga. Momen makan bersama keluarga sudah menjadi budaya, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang bisa anda praktekkan salah satunya kue nona manis/cantik manis yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep kue nona manis/cantik manis tanpa harus bersusah payah.
Seperti resep Kue Nona Manis/Cantik Manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis/Cantik Manis:

1. Harap siapkan  1 Bahan
1. Siapkan 3 butir telur ayam
1. Harap siapkan 2 gelas santan
1. Jangan lupa 2 gelas terigu
1. Siapkan 1 gelas gula pasir
1. Dibutuhkan  2 Bahan
1. Tambah 2 gelas santan (dibelender bersama daun pandan secukupnya)
1. Harus ada 1/2 gelas maizena
1. Jangan lupa 1/2 gelas gula pasir
1. Dibutuhkan 1/2 sdt garam
1. Siapkan  3 Bahan
1. Jangan lupa 2 gelas santan kental
1. Dibutuhkan 2 sdm gula pasir
1. Jangan lupa 2 sdm terigu
1. Dibutuhkan 1/2 sdt garam




<!--inarticleads2-->

##### Langkah membuat  Kue Nona Manis/Cantik Manis:

1. Bahan 2: campur santan pandan, gula pasir dan maizena. Masak diatas kompor sambil diaduk terus sampai meletup-letup. Angkat, biarkan sampai hangat
1. Bahan 1: kocok telur dan gula sampai mengembang. Masukkan terigu, kocok lagi. Tuang santan lalu aduk sampai rata
1. Campurkan adonan 1 dan 2, gunakan mixer hingga tercampur rata. Sisihkan
1. Panaskan dandang untuk mengukus. Jangan lupa lapisi tutup panci dengan kain bersih agar uapnya tdk menetes
1. Bahan 3: campur santan kental, gula, garam dan terigu. Aduk hingga rata dan tdk bergelindir. Masak sambil terus diaduk agar santan tdk pecah. Setelah mendidih angkat segera dari kompor
1. Siapkan cetakan kue talam yg sudah diolesi minyak. Tuang adonan pandan hingga hampir penuh lalu beri tengahnya adonan putih menggunakan sendok
1. Kukus selama 10-15 menit atau hingga matang
1. Angkat dari kukusan. Tunggu hingga dingin agar mudah dilepas
1. Siap dinikmati bersama teh hangat😊




Demikianlah cara membuat kue nona manis/cantik manis yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan teruji, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
