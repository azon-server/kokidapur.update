---
description: "Step-by-Step untuk membuat Ayam Saus Padang🌶🌶 Favorite"
title: "Step-by-Step untuk membuat Ayam Saus Padang🌶🌶 Favorite"
slug: 94-step-by-step-untuk-membuat-ayam-saus-padang-favorite
date: 2021-02-10T01:43:26.665Z
image: https://img-global.cpcdn.com/recipes/aa91bc342adf0095/680x482cq70/ayam-saus-padang🌶🌶-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/aa91bc342adf0095/680x482cq70/ayam-saus-padang🌶🌶-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/aa91bc342adf0095/680x482cq70/ayam-saus-padang🌶🌶-foto-resep-utama.jpg
author: Amy Jenkins
ratingvalue: 4.3
reviewcount: 18262
recipeingredient:
- "1/2 kg ayam"
- "Secukupnya bumbu racik ayam utk marinasi ungkep sebentar"
- "1/2 siung bawang bombai dirajang"
- "1 ruas jahe d geprek"
- "1 batang bawang daun"
- "3 lbr daun jeruk"
- "3 sdm saus sambal"
- "2 sdm saus tomat"
- "11/2 sdm saus tiram"
- "1 sdm minyak wijen"
- "1 sdm peres garam bila kurang blh ditambah"
- "1/2 sdt gula putih"
- "10 buah rawit dibiarkan utuh"
- "1/2 sdt air jeruk nipis atau lemon"
- "150 ml air"
- "Secukupnya minyak goreng"
- " Bahan yang dihaluskan "
- "15 biji cabe merah kriting"
- "2 siung bawang putih"
- "5 siung bawang merah"
- "1 ruas kunyit"
recipeinstructions:
- "Cuci bersih ayam, kalau bisa kasih air jeruk nipis biar ga amis. Lalu tambahkan bumbu racik ayak utk marinasi. Ungkep sekitar 10 menit"
- "Blender smua bumbu halus"
- "Panaskan minyak dan tumis bumbu halus..setelah berubah warna tambahkan irisan bawang daun dan bawang bombai rajang sampai wangi. Tambahkan smua bahan."
- "Masukkan ayam dan biarkan bumbu meresap..tambahkan air. Koreksi rasa"
- "Bila dirasa smua sudah cukup angkat masakan dan sajikan.."
categories:
- Recipe
tags:
- ayam
- saus
- padang

katakunci: ayam saus padang 
nutrition: 188 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT36M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Saus Padang🌶🌶](https://img-global.cpcdn.com/recipes/aa91bc342adf0095/680x482cq70/ayam-saus-padang🌶🌶-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau enak. Ciri khas makanan Nusantara ayam saus padang🌶🌶 yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Ayam Saus Padang🌶🌶 untuk keluarga. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang dapat anda buat salah satunya ayam saus padang🌶🌶 yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep ayam saus padang🌶🌶 tanpa harus bersusah payah.
Seperti resep Ayam Saus Padang🌶🌶 yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Saus Padang🌶🌶:

1. Diperlukan 1/2 kg ayam
1. Siapkan Secukupnya bumbu racik ayam utk marinasi (ungkep sebentar)
1. Jangan lupa 1/2 siung bawang bombai dirajang
1. Siapkan 1 ruas jahe d geprek
1. Tambah 1 batang bawang daun
1. Tambah 3 lbr daun jeruk
1. Siapkan 3 sdm saus sambal
1. Harap siapkan 2 sdm saus tomat
1. Harap siapkan 11/2 sdm saus tiram
1. Harus ada 1 sdm minyak wijen
1. Jangan lupa 1 sdm peres garam, bila kurang blh ditambah
1. Jangan lupa 1/2 sdt gula putih
1. Harus ada 10 buah rawit dibiarkan utuh
1. Harap siapkan 1/2 sdt air jeruk nipis atau lemon
1. Harap siapkan 150 ml air
1. Siapkan Secukupnya minyak goreng
1. Siapkan  Bahan yang dihaluskan :
1. Dibutuhkan 15 biji cabe merah kriting
1. Dibutuhkan 2 siung bawang putih
1. Harap siapkan 5 siung bawang merah
1. Tambah 1 ruas kunyit




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Saus Padang🌶🌶:

1. Cuci bersih ayam, kalau bisa kasih air jeruk nipis biar ga amis. Lalu tambahkan bumbu racik ayak utk marinasi. Ungkep sekitar 10 menit
1. Blender smua bumbu halus
1. Panaskan minyak dan tumis bumbu halus..setelah berubah warna tambahkan irisan bawang daun dan bawang bombai rajang sampai wangi. Tambahkan smua bahan.
1. Masukkan ayam dan biarkan bumbu meresap..tambahkan air. Koreksi rasa
1. Bila dirasa smua sudah cukup angkat masakan dan sajikan..




Demikianlah cara membuat ayam saus padang🌶🌶 yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
