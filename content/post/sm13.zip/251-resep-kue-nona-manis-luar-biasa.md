---
description: "Resep : Kue Nona Manis Luar biasa"
title: "Resep : Kue Nona Manis Luar biasa"
slug: 251-resep-kue-nona-manis-luar-biasa
date: 2020-11-13T07:11:45.590Z
image: https://img-global.cpcdn.com/recipes/9d4863916cedbd50/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9d4863916cedbd50/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9d4863916cedbd50/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Scott Baker
ratingvalue: 4.2
reviewcount: 42124
recipeingredient:
- " Bahan A"
- "1 butir telur kocok lepas"
- "125 gr gula pasir sesuai selera"
- "250 ml santan kental"
- "125 gr terigu"
- " Bahan B"
- "125 ml santan kental"
- "125 ml air pandan 6 lbr daun pandan yg diblender"
- "60 gr gula pasir sesuai selera"
- "30 gr maizena"
- "Sejumput garam"
- "secukupnya Pasta pandan"
- " Bahan C putih "
- "250 ml santan"
- "1 1/2 sdm terigu"
- "1 sdm gula pasir"
- "1/2 sdt garam"
recipeinstructions:
- "Adonan A : satukan semua bahan kecuali telor. Aduk rata sampai gula larut, lalu masukkan telor, aduk dgn whisk lalu saring dan sisihkan"
- "Adonan B : campur semua bahan jadi satu dalam wadah, saring kemudian masak dengan api kecil, hingga meletup-letup, sisihkan"
- "Adonan putih (C) : satukan semua bahan, aduk2 lalu saring dan masak hingga meletup- letup, biarkan hangat kemudian masukkan kedlm plastik segitiga"
- "Panaskan kukusan dgn tutup dialasi serbet bersih"
- "Olesi cetakan kue talam dengan minyak agar tidak lengket"
- "Satukan bahan B ke bahan A, disebut adonan hijau"
- "Isi cetakan dgn adonan hijau 3/4 cetakan, lalu semprotkan adonan putih ditengah sambil ditekan"
- "Kukus dgn api sedang kurleb 15 menit. Tunggu dingin baru dikeluarkan dari cetakan"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 125 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Dinner

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/9d4863916cedbd50/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau empuk. Ciri khas masakan Nusantara kue nona manis yang penuh dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kedekatan rumah tangga bisa didapat dengan cara sederhana. Salah satunya adalah memasak Kue Nona Manis untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang bisa anda coba salah satunya kue nona manis yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue Nona Manis:

1. Harus ada  Bahan A:
1. Diperlukan 1 butir telur kocok lepas
1. Harap siapkan 125 gr gula pasir/ sesuai selera
1. Jangan lupa 250 ml santan kental
1. Tambah 125 gr terigu
1. Dibutuhkan  Bahan B:
1. Dibutuhkan 125 ml santan kental
1. Harus ada 125 ml air pandan (6 lbr daun pandan yg diblender)
1. Dibutuhkan 60 gr gula pasir/ sesuai selera
1. Harap siapkan 30 gr maizena
1. Tambah Sejumput garam
1. Jangan lupa secukupnya Pasta pandan
1. Dibutuhkan  Bahan C (putih) :
1. Diperlukan 250 ml santan
1. Dibutuhkan 1 1/2 sdm terigu
1. Harap siapkan 1 sdm gula pasir
1. Siapkan 1/2 sdt garam




<!--inarticleads2-->

##### Langkah membuat  Kue Nona Manis:

1. Adonan A : satukan semua bahan kecuali telor. Aduk rata sampai gula larut, lalu masukkan telor, aduk dgn whisk lalu saring dan sisihkan
1. Adonan B : campur semua bahan jadi satu dalam wadah, saring kemudian masak dengan api kecil, hingga meletup-letup, sisihkan
1. Adonan putih (C) : satukan semua bahan, aduk2 lalu saring dan masak hingga meletup- letup, biarkan hangat kemudian masukkan kedlm plastik segitiga
1. Panaskan kukusan dgn tutup dialasi serbet bersih
1. Olesi cetakan kue talam dengan minyak agar tidak lengket
1. Satukan bahan B ke bahan A, disebut adonan hijau
1. Isi cetakan dgn adonan hijau 3/4 cetakan, lalu semprotkan adonan putih ditengah sambil ditekan
1. Kukus dgn api sedang kurleb 15 menit. Tunggu dingin baru dikeluarkan dari cetakan




Demikianlah cara membuat kue nona manis yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
