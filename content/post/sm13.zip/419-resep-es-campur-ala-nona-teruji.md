---
description: "Resep : Es campur ala nona Teruji"
title: "Resep : Es campur ala nona Teruji"
slug: 419-resep-es-campur-ala-nona-teruji
date: 2021-02-08T04:19:25.673Z
image: https://img-global.cpcdn.com/recipes/86c32dc1c3a119a8/680x482cq70/es-campur-ala-nona-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/86c32dc1c3a119a8/680x482cq70/es-campur-ala-nona-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/86c32dc1c3a119a8/680x482cq70/es-campur-ala-nona-foto-resep-utama.jpg
author: Delia Gutierrez
ratingvalue: 4
reviewcount: 29242
recipeingredient:
- "2 buah alpukat matang"
- "100 gr nanas"
- "100 gr cendol"
- "100 gr tape singkong"
- "100 gr cao hitam bisa di ganti dengan agar2"
- "100 gr kolang kaling"
- "sesuai selera roti tawar"
- " susu kental manis"
- "serut es batu"
- "sesuai selera sirup gula  sirup marjan"
recipeinstructions:
- "Potong dadu buah nanas, alpukat,kolang kaling dan cao/agar2. iris tipis tape singkong(sesuai selera), iris roti tawar(sesuai selera)"
- "Siapkan mangkok campurkan semua bahan yg tertera diatas dan masukkan ke dalam mangkok. tuangkan es batu serut dia atas bahan tersebut lalu tuang sirup gula dan susu kental manis di atasnya..."
categories:
- Recipe
tags:
- es
- campur
- ala

katakunci: es campur ala 
nutrition: 195 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Dinner

---


![Es campur ala nona](https://img-global.cpcdn.com/recipes/86c32dc1c3a119a8/680x482cq70/es-campur-ala-nona-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang harus kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti es campur ala nona yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan ciri khas yang merupakan keragaman Kita

Kehangatan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Es campur ala nona untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.

Lihat juga resep Es Campur, Es Campur Jadoel enak lainnya. Es campur (Indonesian for &#34;mixed ice&#34;) is an Indonesian cold and sweet dessert concoction of fruit cocktails, coconut, tapioca pearls, grass jellies, etc. served in shaved ice, syrup and condensed milk. In Indonesia, es campur is sold from humble traveling trolley to restaurants. Es campur tidak hanya ada di Jawa saja, tapi juga ada di Sumatera dan Kalimantan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi resep yang bisa anda praktekkan salah satunya es campur ala nona yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep es campur ala nona tanpa harus bersusah payah.
Seperti resep Es campur ala nona yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 10 bahan dan 2 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Es campur ala nona:

1. Jangan lupa 2 buah alpukat matang
1. Jangan lupa 100 gr nanas
1. Tambah 100 gr cendol
1. Siapkan 100 gr tape singkong
1. Harus ada 100 gr cao hitam (bisa di ganti dengan agar2)
1. Siapkan 100 gr kolang kaling
1. Harap siapkan sesuai selera roti tawar
1. Harus ada  susu kental manis
1. Harap siapkan serut es batu
1. Harus ada sesuai selera sirup gula / sirup marjan


Salah satunya es campur, siapa sih yang bisa menolak takjil satu ini? Daripada kamu beli terus di luar, kamu bisa lebih hemat dengan membuatnya sendiri. Bahkan bagi kamu yang tinggal di kost, resep es campur di bawah ini bisa dipraktikkan. Minuman Khas Jogja, Minuman Jajanan Jogja, Minuman dari yogyakarta. 

<!--inarticleads2-->

##### Cara membuat  Es campur ala nona:

1. Potong dadu buah nanas, alpukat,kolang kaling dan cao/agar2. iris tipis tape singkong(sesuai selera), iris roti tawar(sesuai selera)
1. Siapkan mangkok campurkan semua bahan yg tertera diatas dan masukkan ke dalam mangkok. tuangkan es batu serut dia atas bahan tersebut lalu tuang sirup gula dan susu kental manis di atasnya...


Bahkan bagi kamu yang tinggal di kost, resep es campur di bawah ini bisa dipraktikkan. Minuman Khas Jogja, Minuman Jajanan Jogja, Minuman dari yogyakarta. Kalau di Jogja namanya &#34; menggosrok Es &#34;. Siang yang terasa panas, sangat pas untuk menikmatinya. Es campur adalah salah satu minuman khas Indonesia yang cara membuat nya dengan mencampurkan berbagai jenis bahan dalam sirup manis. 

Demikianlah cara membuat es campur ala nona yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan terbukti, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
