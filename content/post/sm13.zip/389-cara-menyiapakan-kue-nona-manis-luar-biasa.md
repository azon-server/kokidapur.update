---
description: "Cara menyiapakan Kue Nona Manis Luar biasa"
title: "Cara menyiapakan Kue Nona Manis Luar biasa"
slug: 389-cara-menyiapakan-kue-nona-manis-luar-biasa
date: 2020-10-08T00:45:14.018Z
image: https://img-global.cpcdn.com/recipes/086bbf02deb83d8a/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/086bbf02deb83d8a/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/086bbf02deb83d8a/680x482cq70/kue-nona-manis-foto-resep-utama.jpg
author: Callie Dixon
ratingvalue: 4.8
reviewcount: 19644
recipeingredient:
- "250 ml santan"
- "3 sdm terigu"
- "1/2 sdt garam"
- "1 Bahan"
- "50 ml santan"
- "75 ml air pandan jus pandan lalu saring untuk mendapatkan airnya"
- "40 gr gula pasir"
- "1 sdm maizena"
- "1 sdt perisa pandan"
- " Pewarna hijau"
- "2 Bahan"
- "125 ml santan"
- "1 btr telur"
- "40 gr gula pasir"
- "80 gr   4 sdm tepung terigu"
- "3 Bahan"
recipeinstructions:
- "Siapkan dan campurkan bahan 1 lalu masak dengan api kecil hingga mengental. Lalu sisihkan"
- "Siapkan dan campurkan bahan 2 lalu masak api kecil hingga mengental. Lalu sisihkan"
- "Siapkan dan campurkan bahan 3 lalu aduk dengan ballon whisk. Setelah itu masukkan bahan 2 ke bahan 3 aduk hingga merata. Bila kurang hijau atau kurang wangi. Masukkan pewarna hijau secukupnya. Setelah adonan jadi, tuang menggunakan gelas takar ke dalam cetakan kue talam. Lalu ambil bahan 1 menggunakan sendok makan atau pipping bag dan tuangkan ke tengah adonan hijau. Panaskan steamer atau dandang jangan lupa tutupnya di ikat dengan kain. Setelah itu kukus +- 10 menit."
- "Angkat dan dinginkan. Keluarkan kue dari cetakan setelah dingin"
categories:
- Recipe
tags:
- kue
- nona
- manis

katakunci: kue nona manis 
nutrition: 192 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dinner

---


![Kue Nona Manis](https://img-global.cpcdn.com/recipes/086bbf02deb83d8a/680x482cq70/kue-nona-manis-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti kue nona manis yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Indonesia

Keharmonisan keluarga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Kue Nona Manis untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang bisa anda buat salah satunya kue nona manis yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep kue nona manis tanpa harus bersusah payah.
Berikut ini resep Kue Nona Manis yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Nona Manis:

1. Diperlukan 250 ml santan
1. Siapkan 3 sdm terigu
1. Harus ada 1/2 sdt garam
1. Diperlukan 1 Bahan
1. Harus ada 50 ml santan
1. Diperlukan 75 ml air pandan (jus pandan lalu saring untuk mendapatkan airnya)
1. Siapkan 40 gr gula pasir
1. Siapkan 1 sdm maizena
1. Jangan lupa 1 sdt perisa pandan
1. Diperlukan  Pewarna hijau
1. Siapkan 2 Bahan
1. Diperlukan 125 ml santan
1. Diperlukan 1 btr telur
1. Tambah 40 gr gula pasir
1. Harap siapkan 80 gr / +- 4 sdm tepung terigu
1. Diperlukan 3 Bahan




<!--inarticleads2-->

##### Bagaimana membuat  Kue Nona Manis:

1. Siapkan dan campurkan bahan 1 lalu masak dengan api kecil hingga mengental. Lalu sisihkan
1. Siapkan dan campurkan bahan 2 lalu masak api kecil hingga mengental. Lalu sisihkan
1. Siapkan dan campurkan bahan 3 lalu aduk dengan ballon whisk. Setelah itu masukkan bahan 2 ke bahan 3 aduk hingga merata. Bila kurang hijau atau kurang wangi. Masukkan pewarna hijau secukupnya. Setelah adonan jadi, tuang menggunakan gelas takar ke dalam cetakan kue talam. Lalu ambil bahan 1 menggunakan sendok makan atau pipping bag dan tuangkan ke tengah adonan hijau. Panaskan steamer atau dandang jangan lupa tutupnya di ikat dengan kain. Setelah itu kukus +- 10 menit.
1. Angkat dan dinginkan. Keluarkan kue dari cetakan setelah dingin




Demikianlah cara membuat kue nona manis yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
