---
description: "Steps membuat Udang Saus Padang Sempurna"
title: "Steps membuat Udang Saus Padang Sempurna"
slug: 66-steps-membuat-udang-saus-padang-sempurna
date: 2020-11-23T12:24:39.740Z
image: https://img-global.cpcdn.com/recipes/b41a9a6bb33785db/680x482cq70/udang-saus-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b41a9a6bb33785db/680x482cq70/udang-saus-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b41a9a6bb33785db/680x482cq70/udang-saus-padang-foto-resep-utama.jpg
author: Rodney Edwards
ratingvalue: 4.1
reviewcount: 6672
recipeingredient:
- "750 gram udang"
- "2 buah jagung manis"
- "3 helai daun bawang"
- "1 buah bawang bombay"
- "2 buah tomat merah"
- "4 sdm saus tomat"
- "4 sdm saus pedas"
- "1 buah jeruk nipislemon"
- "3 lembar daun salam"
- " Minyak goreng"
- "1 sdm tepung maizena"
- " Garam gula pasir dan lada bubuk"
- " Bumbu halus"
- "10 bawang merah"
- "10 bawang putih"
- "10 cabe merah keriting"
- "8 cabe merah rawit"
- "3 cm jahe"
- "5 cm kunyit"
recipeinstructions:
- "Bersihkan udang, ambil bagian atas kepalanya karna kotoran udang ada di kepala, kulit jangan dibuang agar tidak menciut saat dimasak. Cuci bersih dan beri perasan jeruk nipis/lemon, diamkan kurang lebih 15-20 menit."
- "Cuci bersih bahan&#34;pelengkap dan bahan&#34; utk bumbu halus."
- "Haluskan : bawang merah, bawang putih, cabe keriting, cabe rawit, kunyit dan jahe serta tambahkan minyak goreng agar mudah halus saat diblender. Optional bisa diuleg atau diblender."
- "Haluskan 2 buah tomat dan tambahkan sedikit air"
- "Iris tipis bawamg bombay, iris kasar daun bawang dan potong menjadi beberapa bagian jagung manis"
- "Panaskan wajan dengan minyak secukupnya dengan api sedang, masukan irisan bawang bombay, tumis hingga harum dan layu. Setelah layu, masukan bumbu yg sudah dihaluskan, aduk perlahan hingga warna berubah menjadi orange tua (tandanya sudah matang, agar tidak langu). Tambahkan tomat yg sudah di jus, dan masukan bumbu&#34; seperti garam, gula pasir, lada, saus tomat dan saus pedas. Aduk perlahan hingga mendidih."
- "Setelah saus mendidih, tambhkan air secukupnya dan masukan potongan jagung. Diamkan sampai kurang lebih 3 menit"
- "Masukan perlahan udang yg sudah direndam dgn jeruk nipis/lemon, pastikan seluruh udang terendam dalam saus. Aduk sesekali sampai saus agak menyusut dan meresap ke dalam udang dan jagung. Cek rasa, bisa disesuaikan utk asin manis dan pedasnya. Jika dirasa sudah cukup, masukan irisan daun bawang."
- "Aduk aduk sampai daun bawang tercampur dalam saus. Tuangkan sedikit air yg sudah dicampur dgn tepung maizena. Aduk perlahan sampai saus terlihat mengental. Jika dirasa cukup, matikan api dan siap utk disajikan dengan nasi hangat, tambah krupuk makin endul."
categories:
- Recipe
tags:
- udang
- saus
- padang

katakunci: udang saus padang 
nutrition: 205 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dessert

---


![Udang Saus Padang](https://img-global.cpcdn.com/recipes/b41a9a6bb33785db/680x482cq70/udang-saus-padang-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga enak. Ciri masakan Indonesia udang saus padang yang penuh dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Keharmonisan rumah tangga bisa didapat dengan cara simple. Salah satunya adalah membuat makanan Udang Saus Padang untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang bisa anda praktekkan salah satunya udang saus padang yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep udang saus padang tanpa harus bersusah payah.
Berikut ini resep Udang Saus Padang yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Udang Saus Padang:

1. Harus ada 750 gram udang
1. Harap siapkan 2 buah jagung manis
1. Harap siapkan 3 helai daun bawang
1. Harap siapkan 1 buah bawang bombay
1. Harus ada 2 buah tomat merah
1. Dibutuhkan 4 sdm saus tomat
1. Diperlukan 4 sdm saus pedas
1. Dibutuhkan 1 buah jeruk nipis/lemon
1. Tambah 3 lembar daun salam
1. Siapkan  Minyak goreng
1. Siapkan 1 sdm tepung maizena
1. Tambah  Garam, gula pasir dan lada bubuk
1. Siapkan  Bumbu halus
1. Diperlukan 10 bawang merah
1. Siapkan 10 bawang putih
1. Dibutuhkan 10 cabe merah keriting
1. Harap siapkan 8 cabe merah rawit
1. Tambah 3 cm jahe
1. Jangan lupa 5 cm kunyit




<!--inarticleads2-->

##### Instruksi membuat  Udang Saus Padang:

1. Bersihkan udang, ambil bagian atas kepalanya karna kotoran udang ada di kepala, kulit jangan dibuang agar tidak menciut saat dimasak. Cuci bersih dan beri perasan jeruk nipis/lemon, diamkan kurang lebih 15-20 menit.
1. Cuci bersih bahan&#34;pelengkap dan bahan&#34; utk bumbu halus.
1. Haluskan : bawang merah, bawang putih, cabe keriting, cabe rawit, kunyit dan jahe serta tambahkan minyak goreng agar mudah halus saat diblender. Optional bisa diuleg atau diblender.
1. Haluskan 2 buah tomat dan tambahkan sedikit air
1. Iris tipis bawamg bombay, iris kasar daun bawang dan potong menjadi beberapa bagian jagung manis
1. Panaskan wajan dengan minyak secukupnya dengan api sedang, masukan irisan bawang bombay, tumis hingga harum dan layu. Setelah layu, masukan bumbu yg sudah dihaluskan, aduk perlahan hingga warna berubah menjadi orange tua (tandanya sudah matang, agar tidak langu). Tambahkan tomat yg sudah di jus, dan masukan bumbu&#34; seperti garam, gula pasir, lada, saus tomat dan saus pedas. Aduk perlahan hingga mendidih.
1. Setelah saus mendidih, tambhkan air secukupnya dan masukan potongan jagung. Diamkan sampai kurang lebih 3 menit
1. Masukan perlahan udang yg sudah direndam dgn jeruk nipis/lemon, pastikan seluruh udang terendam dalam saus. Aduk sesekali sampai saus agak menyusut dan meresap ke dalam udang dan jagung. Cek rasa, bisa disesuaikan utk asin manis dan pedasnya. Jika dirasa sudah cukup, masukan irisan daun bawang.
1. Aduk aduk sampai daun bawang tercampur dalam saus. Tuangkan sedikit air yg sudah dicampur dgn tepung maizena. Aduk perlahan sampai saus terlihat mengental. Jika dirasa cukup, matikan api dan siap utk disajikan dengan nasi hangat, tambah krupuk makin endul.




Demikianlah cara membuat udang saus padang yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan terbukti, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
