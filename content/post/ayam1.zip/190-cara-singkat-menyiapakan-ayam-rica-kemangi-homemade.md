---
description: "Cara singkat menyiapakan Ayam rica kemangi Homemade"
title: "Cara singkat menyiapakan Ayam rica kemangi Homemade"
slug: 190-cara-singkat-menyiapakan-ayam-rica-kemangi-homemade
date: 2021-01-09T03:00:27.432Z
image: https://img-global.cpcdn.com/recipes/cc6612372baee1ae/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cc6612372baee1ae/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cc6612372baee1ae/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Ollie Willis
ratingvalue: 4.2
reviewcount: 44511
recipeingredient:
- "8 bh potongan ayam"
- "1/2 bt jeruk nipis"
- "1/2 sdt garam"
- " Bumbu uleg"
- "6 bh bawang merah"
- "3 bh bawang putih"
- "2 bh kemiri bakar sebentar"
- "5 bh cabe merah besar"
- "2 bh cabe rawit merah"
- "3 cm kunyit"
- " Bumbu tambahan"
- "2 bh daun salam"
- "2 cm jahe"
- "3 bh daun jeruk"
- "1 bh serai"
- "4 cm lengkuas"
- "1/2 sdt garam"
- "1/2 sdt merica"
- "1/2 sdt gula jawa"
- "1/4 sdt gula pasir"
- "1 bh daun bawang iris tipis"
- "1 genggam daun kemangi"
recipeinstructions:
- "Campur ayam dengan air jeruk nipis, cuci sebentar dan tiriskan. Tambahkan garam dan ratakan. Goreng setengah matang. Sisihkan."
- "Tumis bumbu uleg hingga wangi, tambahkan 1gelas air, masukkan jahe, serai, lengkuas, salam, daun jeruk, garam, merica, gula jawa, gula pasir hingga larut. Tambahkan ayam yang disisihkan. Tunggu agak mengental, koreksi rasa. Tambahkan sedikit air lagi, hingga semua bumbu meresap ke dalam ayam."
- "Masukkan daun bawang dan kemangi. Sebentar saja. Begitu layu, angkat dan siap dihidangkan."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 124 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/cc6612372baee1ae/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis atau empuk. Karasteristik masakan Nusantara ayam rica kemangi yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.


Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. RESEP AYAM RICA RICA KEMANGI YANG SUPER ENAK hai assalammualikum teman teman. kali ini saya berbagi resep olahan ayam. bahan bahanya. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera.

Kehangatan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica kemangi untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang bisa anda coba salah satunya ayam rica kemangi yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica kemangi:

1. Harus ada 8 bh potongan ayam
1. Diperlukan 1/2 bt jeruk nipis
1. Jangan lupa 1/2 sdt garam
1. Jangan lupa  Bumbu uleg
1. Harap siapkan 6 bh bawang merah
1. Siapkan 3 bh bawang putih
1. Siapkan 2 bh kemiri, bakar sebentar
1. Harus ada 5 bh cabe merah besar
1. Tambah 2 bh cabe rawit merah
1. Tambah 3 cm kunyit
1. Dibutuhkan  Bumbu tambahan
1. Jangan lupa 2 bh daun salam
1. Jangan lupa 2 cm jahe
1. Dibutuhkan 3 bh daun jeruk
1. Tambah 1 bh serai
1. Siapkan 4 cm lengkuas
1. Harus ada 1/2 sdt garam
1. Harus ada 1/2 sdt merica
1. Siapkan 1/2 sdt gula jawa
1. Harus ada 1/4 sdt gula pasir
1. Jangan lupa 1 bh daun bawang iris tipis
1. Tambah 1 genggam daun kemangi


Ayam rica-rica pedas kemangi adalah salah satunya. Rasanya yang pedas, manis dan gurih, membuatnya banyak di gemari banyak kalangan, dari anak-anak sampai orang tua. Cara Membuat Ayam Rica Rica Kemangi. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. 

<!--inarticleads2-->

##### Instruksi membuat  Ayam rica kemangi:

1. Campur ayam dengan air jeruk nipis, cuci sebentar dan tiriskan. Tambahkan garam dan ratakan. Goreng setengah matang. Sisihkan.
1. Tumis bumbu uleg hingga wangi, tambahkan 1gelas air, masukkan jahe, serai, lengkuas, salam, daun jeruk, garam, merica, gula jawa, gula pasir hingga larut. Tambahkan ayam yang disisihkan. Tunggu agak mengental, koreksi rasa. Tambahkan sedikit air lagi, hingga semua bumbu meresap ke dalam ayam.
1. Masukkan daun bawang dan kemangi. Sebentar saja. Begitu layu, angkat dan siap dihidangkan.


Cara Membuat Ayam Rica Rica Kemangi. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. 

Demikianlah cara membuat ayam rica kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
