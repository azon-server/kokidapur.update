---
description: "Step-by-Step menyiapakan Ayam Goreng Manis Pedas terupdate"
title: "Step-by-Step menyiapakan Ayam Goreng Manis Pedas terupdate"
slug: 458-step-by-step-menyiapakan-ayam-goreng-manis-pedas-terupdate
date: 2021-01-10T17:19:01.471Z
image: https://img-global.cpcdn.com/recipes/80782b5c742ca3cf/751x532cq70/ayam-goreng-manis-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/80782b5c742ca3cf/751x532cq70/ayam-goreng-manis-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/80782b5c742ca3cf/751x532cq70/ayam-goreng-manis-pedas-foto-resep-utama.jpg
author: John Gibson
ratingvalue: 4.1
reviewcount: 49069
recipeingredient:
- "8-12 pot paha ayam"
- " Air utk merebus ayam"
- " Lada sckpnya"
- " Garam sckpnya"
- "1 sachet sasa bumbu lumur ayam special"
- "2 ruas jahe geprek"
- "1 cabe merah besar iris"
- "2 daun bawang iris"
- "3-4 lbr daun jeruk iris"
- "1 stick gulpas"
- " Kaljam sckpnya"
- "6 sdm kecap manis"
- "3 sdm saos tomat qu pke saos cabe belibis"
- " Minyak sckpnya"
- " Bahanbumbu halus "
- "2 cabe merah besar"
- "5 cabe rawit merah bisa di  ato di  sesuai selera"
- " Air sckpnya"
- "7 bamer"
- "2-3 baput"
- "3 kemiri"
recipeinstructions:
- "Didihkan air tmbhkn grm n lada, msukan ayam, rebus smp tdk ada darahnya. Angkat tiriskan, marinasi dg sasa bumbu lumur ayam special. Diamkn 15 mnit/ smalaman di dlm lemari es. Bsok bru ditindak lanjuti."
- "Keluarkan ayam dr lemari es. Goreng smp matang, angkat, tiriskan sisihkn."
- "Halukan/ blender bumbu halus, sisihkan. Dan iris bahan yg hrus diiris, sisihkan. Geprek jahe, sisihkn."
- "Siapkan bahan lainnya. Kmd panaskn minyak dlm frypan."
- "Tumis bumbu halus smp harum dn matang, tmbhkn bumbu iris n jahe, aduk rata, tumis sebentar tmbhkn kecap n saos, aduk rata."
- "Stlh trcampur rata tmbhkn grm, gula n kaljam tes rasa. Kmd masukan ayam, ratakan bumbu pd ayam, spy ayam trlumuri bumbu dg baik. Aduk2 trus prlahan smp menyusut airnya."
- "Stlh menyusut, matikan kompor. Dan siap disajikan."
- "Catt: Klo ayam tdk direbus lbih dl, sbaiknya dimarinasi dg air jeruk nipis n garam, kmd masukan ke dlm lemari es slm 15 mnit. Baru kmd digoreng smp matang dg api sedang."
categories:
- Recipe
tags:
- ayam
- goreng
- manis

katakunci: ayam goreng manis 
nutrition: 235 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Goreng Manis Pedas](https://img-global.cpcdn.com/recipes/80782b5c742ca3cf/751x532cq70/ayam-goreng-manis-pedas-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga renyah. Karasteristik makanan Indonesia ayam goreng manis pedas yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam Goreng Manis Pedas untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang bisa anda praktekkan salah satunya ayam goreng manis pedas yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep ayam goreng manis pedas tanpa harus bersusah payah.
Berikut ini resep Ayam Goreng Manis Pedas yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 21 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Manis Pedas:

1. Diperlukan 8-12 pot paha ayam
1. Diperlukan  Air utk merebus ayam
1. Harus ada  Lada sckpnya
1. Tambah  Garam sckpnya
1. Siapkan 1 sachet sasa bumbu lumur ayam special
1. Harus ada 2 ruas jahe geprek
1. Dibutuhkan 1 cabe merah besar iris
1. Tambah 2 daun bawang iris
1. Siapkan 3-4 lbr daun jeruk iris
1. Dibutuhkan 1 stick gulpas
1. Diperlukan  Kaljam sckpnya
1. Tambah 6 sdm kecap manis
1. Jangan lupa 3 sdm saos tomat (qu pke saos cabe belibis)
1. Siapkan  Minyak sckpnya
1. Jangan lupa  Bahan/bumbu halus :
1. Jangan lupa 2 cabe merah besar
1. Tambah 5 cabe rawit merah (bisa di + ato di -) sesuai selera
1. Diperlukan  Air sckpnya
1. Harap siapkan 7 bamer
1. Tambah 2-3 baput
1. Dibutuhkan 3 kemiri




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Manis Pedas:

1. Didihkan air tmbhkn grm n lada, msukan ayam, rebus smp tdk ada darahnya. Angkat tiriskan, marinasi dg sasa bumbu lumur ayam special. Diamkn 15 mnit/ smalaman di dlm lemari es. Bsok bru ditindak lanjuti.
1. Keluarkan ayam dr lemari es. Goreng smp matang, angkat, tiriskan sisihkn.
1. Halukan/ blender bumbu halus, sisihkan. Dan iris bahan yg hrus diiris, sisihkan. Geprek jahe, sisihkn.
1. Siapkan bahan lainnya. Kmd panaskn minyak dlm frypan.
1. Tumis bumbu halus smp harum dn matang, tmbhkn bumbu iris n jahe, aduk rata, tumis sebentar tmbhkn kecap n saos, aduk rata.
1. Stlh trcampur rata tmbhkn grm, gula n kaljam tes rasa. Kmd masukan ayam, ratakan bumbu pd ayam, spy ayam trlumuri bumbu dg baik. Aduk2 trus prlahan smp menyusut airnya.
1. Stlh menyusut, matikan kompor. Dan siap disajikan.
1. Catt: Klo ayam tdk direbus lbih dl, sbaiknya dimarinasi dg air jeruk nipis n garam, kmd masukan ke dlm lemari es slm 15 mnit. Baru kmd digoreng smp matang dg api sedang.




Demikianlah cara membuat ayam goreng manis pedas yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan cepat, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
