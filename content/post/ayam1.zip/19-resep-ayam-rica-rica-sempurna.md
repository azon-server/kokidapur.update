---
description: "Resep : Ayam Rica Rica Sempurna"
title: "Resep : Ayam Rica Rica Sempurna"
slug: 19-resep-ayam-rica-rica-sempurna
date: 2020-11-06T08:25:39.075Z
image: https://img-global.cpcdn.com/recipes/01a5bc743c21332f/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/01a5bc743c21332f/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/01a5bc743c21332f/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: George Mendez
ratingvalue: 4
reviewcount: 28642
recipeingredient:
- "1 ekor ayam"
- "7 ikat daun kemangi"
- "Potong kasar "
- " Lengkuas 1 yang besar"
- " Jahe 2 ruas"
- "4 buah Kemiri"
- " Sereh secukupnya makin banyak makin enak  potong halus"
- "15 buah bawang merah"
- "10 buah bawang putih"
- " Daun jeruk secukupnya potong lurus kecil kecil"
- " Cabe rawit hijau kl yang suka pedas ulek kasar"
recipeinstructions:
- "Cuci ayam dan beri sedikit jeruk nipis (biar amisnya hilang)"
- "Bersihkan bahan-bahan yang akan dipotong kasar"
- "Untuk sereh dan daun jeruk potongnya seperti ini ya"
- "Tumis semua bahan kasar sampai wangi"
- "Setelah wangi, masukkan ayam dan aduk rata.. kemudian tambahkan air dan garam."
- "Jangan lupa ditutup, biar ayam empuk.."
- "Koreksi rasa."
- "Apabila ayam sudah empuk dan air sudah menyusut. Taburi dengan daun kemangi. Tunggu sebentar, angkat lalu sajikan.."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 102 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/01a5bc743c21332f/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas dan gurih. Ciri khas kuliner Indonesia ayam rica rica yang kaya dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica Rica untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang bisa anda praktekkan salah satunya ayam rica rica yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 8 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica:

1. Siapkan 1 ekor ayam
1. Jangan lupa 7 ikat daun kemangi
1. Siapkan Potong kasar :
1. Harus ada  Lengkuas (1 yang besar)
1. Harus ada  Jahe (2 ruas)
1. Siapkan 4 buah Kemiri
1. Harap siapkan  Sereh (secukupnya) makin banyak, makin enak 😉, potong halus
1. Harus ada 15 buah bawang merah
1. Harap siapkan 10 buah bawang putih
1. Siapkan  Daun jeruk (secukupnya) potong lurus kecil kecil
1. Siapkan  Cabe rawit hijau (kl yang suka pedas), ulek kasar




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Rica:

1. Cuci ayam dan beri sedikit jeruk nipis (biar amisnya hilang)
1. Bersihkan bahan-bahan yang akan dipotong kasar
1. Untuk sereh dan daun jeruk potongnya seperti ini ya
1. Tumis semua bahan kasar sampai wangi
1. Setelah wangi, masukkan ayam dan aduk rata.. kemudian tambahkan air dan garam.
1. Jangan lupa ditutup, biar ayam empuk..
1. Koreksi rasa.
1. Apabila ayam sudah empuk dan air sudah menyusut. Taburi dengan daun kemangi. Tunggu sebentar, angkat lalu sajikan..




Demikianlah cara membuat ayam rica rica yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
