---
description: "Cara untuk membuat Ayam Rica-Rica Manado (Ayam Woku) minggu ini"
title: "Cara untuk membuat Ayam Rica-Rica Manado (Ayam Woku) minggu ini"
slug: 2-cara-untuk-membuat-ayam-rica-rica-manado-ayam-woku-minggu-ini
date: 2020-10-31T12:29:03.459Z
image: https://img-global.cpcdn.com/recipes/be1e18c84adb0d97/751x532cq70/ayam-rica-rica-manado-ayam-woku-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/be1e18c84adb0d97/751x532cq70/ayam-rica-rica-manado-ayam-woku-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/be1e18c84adb0d97/751x532cq70/ayam-rica-rica-manado-ayam-woku-foto-resep-utama.jpg
author: Irene Powers
ratingvalue: 4.1
reviewcount: 35303
recipeingredient:
- "3 potong sayap ayam bagi jdi 2"
- " Kemangi"
- "3 lembar daun jeruk daun kecil2"
- "2 lembar daun salam"
- "1 buah Tomat"
- "1 batang sereh geprek"
- " Gula Merah"
- " Royco"
- " Air"
- " Garam"
- " bumbu halus"
- "3 siung Bawang putih"
- "4 atau 5 siung Bawang Merah"
- "7 buah Cabai keriting"
- "2 buah cabai rawit merah"
- "sedikit Garam untuk menghaluskan bumbu ulekan"
- " Kemiri"
- "Sedikit jahe"
- "Sedikit kunyit"
recipeinstructions:
- "Potong sayap ayam menjadi 2 bagian, cuci bersih."
- "Haluskan semua bumbu halus, bisa diuleg atau diblender"
- "Siapkan minyak diwajan, masukkan bumbu halus (api sedang)."
- "Lalu masukkan daun salam, daun jeruk, sereh yg sudah digeprek."
- "Tumis sampai harum."
- "Masukkan air secukupnya (agak banyak karna sekalian untuk merebus ayam)"
- "Masukkan ayam yg sudah dipotong"
- "Beri royco ayam."
- "Tunggu sampai ayam benar benar matang &amp; empuk."
- "Tambahkan gula merah secukupnya."
- "Icip rasa, jika kurang bisa ditambahkan bumbu yg kurang."
- "Asatkan sedikit airnya."
- "Jika ayam sudah matang &amp; air sedikit asat, masukkan daun kemangi"
- "Tunggu hingga daun kemangi matang."
- "Ayam woku siap dihidangkan😊"
categories:
- Recipe
tags:
- ayam
- ricarica
- manado

katakunci: ayam ricarica manado 
nutrition: 228 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica-Rica Manado (Ayam Woku)](https://img-global.cpcdn.com/recipes/be1e18c84adb0d97/751x532cq70/ayam-rica-rica-manado-ayam-woku-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan enak. Ciri khas masakan Nusantara ayam rica-rica manado (ayam woku) yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Keharmonisan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica-Rica Manado (Ayam Woku) untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang dapat anda contoh salah satunya ayam rica-rica manado (ayam woku) yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep ayam rica-rica manado (ayam woku) tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Manado (Ayam Woku) yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 15 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica Manado (Ayam Woku):

1. Siapkan 3 potong sayap ayam (bagi jdi 2)
1. Harus ada  Kemangi
1. Harus ada 3 lembar daun jeruk (daun kecil2)
1. Harap siapkan 2 lembar daun salam
1. Siapkan 1 buah Tomat
1. Harus ada 1 batang sereh (geprek)
1. Harap siapkan  Gula Merah
1. Dibutuhkan  Royco
1. Tambah  Air
1. Tambah  Garam
1. Diperlukan  bumbu halus
1. Siapkan 3 siung Bawang putih
1. Tambah 4 atau 5 siung Bawang Merah
1. Dibutuhkan 7 buah Cabai keriting
1. Harus ada 2 buah cabai rawit merah
1. Diperlukan sedikit Garam (untuk menghaluskan bumbu ulekan)
1. Harap siapkan  Kemiri
1. Diperlukan Sedikit jahe
1. Diperlukan Sedikit kunyit




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-Rica Manado (Ayam Woku):

1. Potong sayap ayam menjadi 2 bagian, cuci bersih.
1. Haluskan semua bumbu halus, bisa diuleg atau diblender
1. Siapkan minyak diwajan, masukkan bumbu halus (api sedang).
1. Lalu masukkan daun salam, daun jeruk, sereh yg sudah digeprek.
1. Tumis sampai harum.
1. Masukkan air secukupnya (agak banyak karna sekalian untuk merebus ayam)
1. Masukkan ayam yg sudah dipotong
1. Beri royco ayam.
1. Tunggu sampai ayam benar benar matang &amp; empuk.
1. Tambahkan gula merah secukupnya.
1. Icip rasa, jika kurang bisa ditambahkan bumbu yg kurang.
1. Asatkan sedikit airnya.
1. Jika ayam sudah matang &amp; air sedikit asat, masukkan daun kemangi
1. Tunggu hingga daun kemangi matang.
1. Ayam woku siap dihidangkan😊




Demikianlah cara membuat ayam rica-rica manado (ayam woku) yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
