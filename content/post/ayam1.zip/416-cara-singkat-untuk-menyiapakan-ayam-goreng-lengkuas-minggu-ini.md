---
description: "Cara singkat untuk menyiapakan Ayam Goreng Lengkuas minggu ini"
title: "Cara singkat untuk menyiapakan Ayam Goreng Lengkuas minggu ini"
slug: 416-cara-singkat-untuk-menyiapakan-ayam-goreng-lengkuas-minggu-ini
date: 2020-10-23T13:53:18.804Z
image: https://img-global.cpcdn.com/recipes/93236d1bedd75366/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/93236d1bedd75366/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/93236d1bedd75366/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Viola Norris
ratingvalue: 5
reviewcount: 9347
recipeingredient:
- "1/2 ekor ayam potong sesuai selera"
- "5 lembar daun salam"
- "3 lembar daun jeruk purut"
- "2 bonggol besar lengkuas besar diparut"
- " Gula lada dan penyedap rasa ayam"
- " Bumbu halus"
- "7 siung bawang putih"
- "5 butir bawang merah"
- "1 ruas jahe"
- "1 ruas besar kunyit"
- "2 batang serai boleh digepek klo ini saya haluskan juga"
- "3 butir kemiri"
recipeinstructions:
- "Campur semuanya jadi satu di panci, saya menggunakan panci presto, utk airnya saya isi sampai setengah panci. Ketika sdh dipresto, tunggu sampai bunyi mendesis, dari bunyi mendesis itu saya masak selama 25 menit dgn api sedang."
- "Setelah 25 menit, pindahkan ayam ke wadah lain, lalu bumbunya dipindah ke wajan, lalu masak diatas kompor sampai susut airnya"
- "Gorengnya ayamnya sampai berwarna keemasan, kemudian dilanjutkan dgn menggoreng bumbunya, aduh agak tidak menggumpal, angkat ketika warna sdh coklat, tiriskan."
categories:
- Recipe
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 237 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT43M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Goreng Lengkuas](https://img-global.cpcdn.com/recipes/93236d1bedd75366/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas hingga empuk. Karasteristik kuliner Indonesia ayam goreng lengkuas yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah memasak Ayam Goreng Lengkuas untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang bisa anda contoh salah satunya ayam goreng lengkuas yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep ayam goreng lengkuas tanpa harus bersusah payah.
Seperti resep Ayam Goreng Lengkuas yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 12 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Lengkuas:

1. Harus ada 1/2 ekor ayam, potong sesuai selera
1. Dibutuhkan 5 lembar daun salam
1. Jangan lupa 3 lembar daun jeruk purut
1. Jangan lupa 2 bonggol besar lengkuas besar diparut
1. Diperlukan  Gula, lada, dan penyedap rasa ayam
1. Tambah  Bumbu halus
1. Harap siapkan 7 siung bawang putih
1. Harus ada 5 butir bawang merah
1. Dibutuhkan 1 ruas jahe
1. Harap siapkan 1 ruas besar kunyit
1. Siapkan 2 batang serai, boleh digepek, klo ini saya haluskan juga
1. Tambah 3 butir kemiri




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Goreng Lengkuas:

1. Campur semuanya jadi satu di panci, saya menggunakan panci presto, utk airnya saya isi sampai setengah panci. Ketika sdh dipresto, tunggu sampai bunyi mendesis, dari bunyi mendesis itu saya masak selama 25 menit dgn api sedang.
1. Setelah 25 menit, pindahkan ayam ke wadah lain, lalu bumbunya dipindah ke wajan, lalu masak diatas kompor sampai susut airnya
1. Gorengnya ayamnya sampai berwarna keemasan, kemudian dilanjutkan dgn menggoreng bumbunya, aduh agak tidak menggumpal, angkat ketika warna sdh coklat, tiriskan.




Demikianlah cara membuat ayam goreng lengkuas yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan terbukti, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
