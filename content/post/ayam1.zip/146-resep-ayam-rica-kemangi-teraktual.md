---
description: "Resep : Ayam Rica Kemangi teraktual"
title: "Resep : Ayam Rica Kemangi teraktual"
slug: 146-resep-ayam-rica-kemangi-teraktual
date: 2020-10-31T08:21:05.484Z
image: https://img-global.cpcdn.com/recipes/5dd8a41dd6bea65b/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5dd8a41dd6bea65b/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5dd8a41dd6bea65b/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Roxie Ferguson
ratingvalue: 4.9
reviewcount: 3853
recipeingredient:
- "4 ekor ayam"
- "4 ikat kemangi"
- "1 ruas lengkuas geprek"
- "1 btg sereh geprek"
- "5 lmbr daun jeruk"
- "1 btg daun bawang iris"
- "Secukupnya garam kaldu jamur"
- "Secukupnya air"
- " Bumbu Halus "
- "5 siung bawang merah"
- "2 siung bawang putih"
- "6 bh cabe merah kriting"
- "15 bh cabe rawit setan optional"
- "2 btr kemiri"
- "Secukupnya jahe  kunyit"
- "Secukupnya gula merah"
recipeinstructions:
- "Siapkan wajan dan panaskan minyak"
- "Masukan bumbu halus, lengkuas, sereh, dan daun jeruk.. masak hingga harum"
- "Jika sdh harum masukan potongan ayam yg sdh di bersihkan, lalu beri air secukupnya"
- "Diamkan hingga ayam matang dan empuk, jika sdh mpuk beri garam dan kaldu jamur.."
- "Aduk&#34;hingga tercampur rata lalu cicipi, stlh rasa nya ok.. masukan kemangi dan daun bawang.. aduk&#34; lagi sebentar lalu matikan kompor.."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 247 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/5dd8a41dd6bea65b/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau empuk. Ciri khas kuliner Indonesia ayam rica kemangi yang penuh dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica Kemangi untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang bisa anda praktekkan salah satunya ayam rica kemangi yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 16 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Dibutuhkan 4 ekor ayam
1. Harap siapkan 4 ikat kemangi
1. Diperlukan 1 ruas lengkuas (geprek)
1. Siapkan 1 btg sereh (geprek)
1. Harap siapkan 5 lmbr daun jeruk
1. Diperlukan 1 btg daun bawang (iris)
1. Jangan lupa Secukupnya garam, kaldu jamur
1. Tambah Secukupnya air
1. Siapkan  Bumbu Halus :
1. Harus ada 5 siung bawang merah
1. Jangan lupa 2 siung bawang putih
1. Diperlukan 6 bh cabe merah kriting
1. Jangan lupa 15 bh cabe rawit setan (optional)
1. Dibutuhkan 2 btr kemiri
1. Siapkan Secukupnya jahe &amp; kunyit
1. Harus ada Secukupnya gula merah




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Kemangi:

1. Siapkan wajan dan panaskan minyak
1. Masukan bumbu halus, lengkuas, sereh, dan daun jeruk.. masak hingga harum
1. Jika sdh harum masukan potongan ayam yg sdh di bersihkan, lalu beri air secukupnya
1. Diamkan hingga ayam matang dan empuk, jika sdh mpuk beri garam dan kaldu jamur..
1. Aduk&#34;hingga tercampur rata lalu cicipi, stlh rasa nya ok.. masukan kemangi dan daun bawang.. aduk&#34; lagi sebentar lalu matikan kompor..




Demikianlah cara membuat ayam rica kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan terbukti, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
