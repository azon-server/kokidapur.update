---
description: "Cara membuat Ayam Rica Rica Kemangi Homemade"
title: "Cara membuat Ayam Rica Rica Kemangi Homemade"
slug: 51-cara-membuat-ayam-rica-rica-kemangi-homemade
date: 2020-09-12T00:53:23.145Z
image: https://img-global.cpcdn.com/recipes/c964aaaf094c7173/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c964aaaf094c7173/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c964aaaf094c7173/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Isabelle Collins
ratingvalue: 4.2
reviewcount: 31740
recipeingredient:
- "5 potong Ayam"
- "10 buah cabe merah"
- " Kemiri"
- "5 bawang merah"
- "3 bawang putih"
- "Seruas kunyit jahe lengkuas"
- " Sereh daun jeruk daun salam"
- " Kacang panjang opsional"
- " Kemangi"
- " Garam gula dan kaldu jamur"
recipeinstructions:
- "Haluskan bawang merah, bawang putih, cabe merah, kemiri dan kunyit. Tumis bumbunya lalu masukkan sereh, jahe, lengkuas, daun jeruk dan daun salam"
- "Setelah harum masukkan ayam aduk2 dan masukkan air (sesuaikan aja) tunggu mendidih masukkan garam, gula, kaldu jamur"
- "Masukkan kacang panjang, aduk2 koreksi rasa.. sekiranya sudah mau masak tambahkan kemangi aduk2 sebentar dan sajikan!"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 200 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/c964aaaf094c7173/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau renyah. Ciri khas makanan Nusantara ayam rica rica kemangi yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica Rica Kemangi untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang dapat anda praktekkan salah satunya ayam rica rica kemangi yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi:

1. Diperlukan 5 potong Ayam
1. Tambah 10 buah cabe merah
1. Jangan lupa  Kemiri
1. Harap siapkan 5 bawang merah
1. Dibutuhkan 3 bawang putih
1. Tambah Seruas kunyit, jahe, lengkuas
1. Diperlukan  Sereh, daun jeruk, daun salam
1. Diperlukan  Kacang panjang (opsional)
1. Tambah  Kemangi
1. Harap siapkan  Garam, gula, dan kaldu jamur




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Rica Kemangi:

1. Haluskan bawang merah, bawang putih, cabe merah, kemiri dan kunyit. Tumis bumbunya lalu masukkan sereh, jahe, lengkuas, daun jeruk dan daun salam
1. Setelah harum masukkan ayam aduk2 dan masukkan air (sesuaikan aja) tunggu mendidih masukkan garam, gula, kaldu jamur
1. Masukkan kacang panjang, aduk2 koreksi rasa.. sekiranya sudah mau masak tambahkan kemangi aduk2 sebentar dan sajikan!




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
