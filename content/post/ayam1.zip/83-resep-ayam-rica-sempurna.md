---
description: "Resep : Ayam rica Sempurna"
title: "Resep : Ayam rica Sempurna"
slug: 83-resep-ayam-rica-sempurna
date: 2020-08-28T07:03:02.544Z
image: https://img-global.cpcdn.com/recipes/d53453245e4acd3c/751x532cq70/ayam-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d53453245e4acd3c/751x532cq70/ayam-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d53453245e4acd3c/751x532cq70/ayam-rica-foto-resep-utama.jpg
author: Roger Sandoval
ratingvalue: 5
reviewcount: 38570
recipeingredient:
- "1/2 kg ayam potong"
- "10 siung cabai rawit merah"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "1 ruas lengkuas"
- "1 ruas kunyit"
- "1 ruas jahe"
- "2 lembar daun salam"
- "1 batang serai"
- "1/2 gula merah"
- "1/2 sendok teh merica bubuk"
- "1/2 sendok teh gula pasir"
- "1/2 sendok teh garam"
- " Royco  penyedap"
- " Minyak goreng"
recipeinstructions:
- "Rebus ayam yg sudah di potong dan di cuci bersih, tambahkan 1 sendok teh garam dan 2 lembar daun salam. Jika sudah mendidih tiriskan"
- "Haluskan bumbu dengan cara apapun kecuali lengkuas, daun salam dan serai."
- "Panaskan minyak dan tumis bumbu halus lalu masukan lengkuas, daun salam dan serai. Tumis hingga harum dan berubah warna"
- "Masukkan ayam yg sudah di rebus lalu tambahkan 2 gelas air dan gula merah."
- "Tunggu hingga air berkurang dan bumbu meresap"
categories:
- Recipe
tags:
- ayam
- rica

katakunci: ayam rica 
nutrition: 266 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam rica](https://img-global.cpcdn.com/recipes/d53453245e4acd3c/751x532cq70/ayam-rica-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara

Resep Ayam Rica Rica Bahan: Daging Ayam Lemon juice Chicken powder Garam. Bawang merah Bawang putih Cabe Jahe Serai Daun jeruk purut Daun kucai. Resep ayam rica-rica ini dikenal berasal dari daerah Manado, Sulawesi Utara yang memiliki cita rasa pedas dan enak. Inilah rahasia bumbu masakan ayam rica rica dan petunjuk cara membuat rica rica ayam.

Kedekatan rumah tangga dapat ditemukan dengan cara mudah. Salah satunya adalah memasak Ayam rica untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang dapat anda buat salah satunya ayam rica yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep ayam rica tanpa harus bersusah payah.
Berikut ini resep Ayam rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica:

1. Diperlukan 1/2 kg ayam potong
1. Jangan lupa 10 siung cabai rawit merah
1. Siapkan 6 siung bawang merah
1. Jangan lupa 4 siung bawang putih
1. Diperlukan 1 ruas lengkuas
1. Harap siapkan 1 ruas kunyit
1. Tambah 1 ruas jahe
1. Harap siapkan 2 lembar daun salam
1. Harus ada 1 batang serai
1. Dibutuhkan 1/2 gula merah
1. Jangan lupa 1/2 sendok teh merica bubuk
1. Jangan lupa 1/2 sendok teh gula pasir
1. Diperlukan 1/2 sendok teh garam
1. Harus ada  Royco / penyedap
1. Harap siapkan  Minyak goreng


Resep Ayam Rica Rica - Kalau kita sudah mendengar kata-kata tentang bumbu rica-rica, sudah pasti pikiran kita akan tertuju pada masakan khas Manado. Cara pembuatan ayam rica-rica tidaklah sulit. Dibutuhkan bahan-bahan seperti daun jeruk, serai, dan daun pandan agar aromanya menjadi kuat dan khas. Tak hanya ayam, anda juga bisa memasak. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica:

1. Rebus ayam yg sudah di potong dan di cuci bersih, tambahkan 1 sendok teh garam dan 2 lembar daun salam. Jika sudah mendidih tiriskan
1. Haluskan bumbu dengan cara apapun kecuali lengkuas, daun salam dan serai.
1. Panaskan minyak dan tumis bumbu halus lalu masukan lengkuas, daun salam dan serai. Tumis hingga harum dan berubah warna
1. Masukkan ayam yg sudah di rebus lalu tambahkan 2 gelas air dan gula merah.
1. Tunggu hingga air berkurang dan bumbu meresap


Dibutuhkan bahan-bahan seperti daun jeruk, serai, dan daun pandan agar aromanya menjadi kuat dan khas. Tak hanya ayam, anda juga bisa memasak. Ayam rica rica is originated in the city of Manado in the island of Sulawesi. Manado style chicken that is known for its super hot spicy taste. Learn how to make tasty ayam rica rica with a pressure. 

Demikianlah cara membuat ayam rica yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
