---
description: "Panduan untuk menyiapakan Ayam Rica Rica Favorite"
title: "Panduan untuk menyiapakan Ayam Rica Rica Favorite"
slug: 56-panduan-untuk-menyiapakan-ayam-rica-rica-favorite
date: 2020-12-13T17:30:10.174Z
image: https://img-global.cpcdn.com/recipes/f886aba43b0bb1ce/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f886aba43b0bb1ce/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f886aba43b0bb1ce/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: John Leonard
ratingvalue: 4.6
reviewcount: 41692
recipeingredient:
- "1 ekor ayam potong 12"
- " Jeruk nipis"
- " Kunyit bubuk"
- " BUMBU HALUS"
- "5 siung bawang merah"
- "5 siung bawang putih"
- "1 ons cabe keriting sesuai selera"
- "1/2 ons cabe rawit sesuai selera"
- "2 cm jahe"
- "1 ruas kunyit"
- "2 ruas lengkuas"
- "4 buah kemiri"
- " BUMBU KASAR"
- "2 ikat daun kemangi"
- "2 tangkai daun bawang"
- "3 batang serai digeprek"
- "1 lembar daun pandan disimpul"
- "5 lembar daun salam"
- "5 lembar daun jeruk nipis iris kecil2"
- "Sejumput garam"
- "Sejumput kaldu ayam"
recipeinstructions:
- "Siapkan bahan-bahan"
- "Baluri ayam dengan kunyit bubuk, air jeruk nipis, dan sedikit garam diamkan sekitar 10 menit"
- "Lalu goreng ayam setengah kering dan tiriskan."
- "Tumis bumbu halus sampai wangi, lalu masukkan daun jeruk, daun salam, daun pandan, dan serai."
- "Kemudian masukkan ayam yg sudah digoreng setengah kering tadi, aduk hingga merata lalu masukkan air secukupnya, masukkan sejumput garam, dan kaldu ayam. Aduk hingga merata lalu koreksi rasa. Masak ayam hingga empuk dan matang kurang lebih 30 menit."
- "Setelah ayam empuk dan air asat, masukkan daun kemangi dan daun bawang lalu aduk hingga layu. Kemudian koreksi rasa lg, jika dirasa masih ad yg kurang garam atau kaldu boleh ditambah."
- "Ayam rica rica pun siap disajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 226 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/f886aba43b0bb1ce/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga empuk. Ciri khas kuliner Indonesia ayam rica rica yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga dapat diperoleh dengan cara simple. Diantaranya adalah memasak Ayam Rica Rica untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang dapat anda buat salah satunya ayam rica rica yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 21 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica:

1. Siapkan 1 ekor ayam potong 12
1. Harus ada  Jeruk nipis
1. Tambah  Kunyit bubuk
1. Diperlukan  BUMBU HALUS:
1. Jangan lupa 5 siung bawang merah
1. Harap siapkan 5 siung bawang putih
1. Jangan lupa 1 ons cabe keriting (sesuai selera)
1. Jangan lupa 1/2 ons cabe rawit (sesuai selera)
1. Siapkan 2 cm jahe
1. Tambah 1 ruas kunyit
1. Harap siapkan 2 ruas lengkuas
1. Harus ada 4 buah kemiri
1. Harus ada  BUMBU KASAR:
1. Harap siapkan 2 ikat daun kemangi
1. Diperlukan 2 tangkai daun bawang
1. Siapkan 3 batang serai digeprek
1. Dibutuhkan 1 lembar daun pandan disimpul
1. Dibutuhkan 5 lembar daun salam
1. Tambah 5 lembar daun jeruk nipis iris kecil2
1. Harus ada Sejumput garam
1. Harus ada Sejumput kaldu ayam




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica:

1. Siapkan bahan-bahan
1. Baluri ayam dengan kunyit bubuk, air jeruk nipis, dan sedikit garam diamkan sekitar 10 menit
1. Lalu goreng ayam setengah kering dan tiriskan.
1. Tumis bumbu halus sampai wangi, lalu masukkan daun jeruk, daun salam, daun pandan, dan serai.
1. Kemudian masukkan ayam yg sudah digoreng setengah kering tadi, aduk hingga merata lalu masukkan air secukupnya, masukkan sejumput garam, dan kaldu ayam. Aduk hingga merata lalu koreksi rasa. Masak ayam hingga empuk dan matang kurang lebih 30 menit.
1. Setelah ayam empuk dan air asat, masukkan daun kemangi dan daun bawang lalu aduk hingga layu. Kemudian koreksi rasa lg, jika dirasa masih ad yg kurang garam atau kaldu boleh ditambah.
1. Ayam rica rica pun siap disajikan




Demikianlah cara membuat ayam rica rica yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat simple dan terbukti, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
