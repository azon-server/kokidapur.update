---
description: "Resep : Ayam Goreng Bumbu Empal Sempurna"
title: "Resep : Ayam Goreng Bumbu Empal Sempurna"
slug: 434-resep-ayam-goreng-bumbu-empal-sempurna
date: 2020-11-27T17:42:39.166Z
image: https://img-global.cpcdn.com/recipes/e29dad3f0bcdb025/751x532cq70/ayam-goreng-bumbu-empal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e29dad3f0bcdb025/751x532cq70/ayam-goreng-bumbu-empal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e29dad3f0bcdb025/751x532cq70/ayam-goreng-bumbu-empal-foto-resep-utama.jpg
author: Ellen Austin
ratingvalue: 4.9
reviewcount: 30125
recipeingredient:
- "600 gr ayam saya 480 gr"
- "1 cm lengkuas"
- "40 gr gula merah  2 sdm"
- "2 daun salam"
- "1 sdm air asam jawa"
- "250 ml air"
- " Garam"
- "Secukupnya minyak"
- " Bumbu halus"
- "4 bawang merah saya duo bawang halus"
- "3 bawang putih saya duo bawang halus"
- "1 sdt ketumbar"
recipeinstructions:
- "Tumis bumbu halus dengan sedikit minyak. Masukkan daun salam dan lengkuas. Kemudian, masukkan ayam. Masak ayam, bolak balik, hingga berubah warna."
- "Tambahkan 250 ml air, gula merah, asam jawa, garam. Masak sambil ayam sesekali dibalik-balik dan bumbu menyusut."
- "Setelah bumbu menyusut, angkat ayam. Kemudian goreng. Siap disajikan."
categories:
- Recipe
tags:
- ayam
- goreng
- bumbu

katakunci: ayam goreng bumbu 
nutrition: 188 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT35M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Goreng Bumbu Empal](https://img-global.cpcdn.com/recipes/e29dad3f0bcdb025/751x532cq70/ayam-goreng-bumbu-empal-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas dan gurih. Karasteristik makanan Indonesia ayam goreng bumbu empal yang kaya dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kedekatan keluarga dapat didapat dengan cara mudah. Salah satunya adalah memasak Ayam Goreng Bumbu Empal untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda contoh salah satunya ayam goreng bumbu empal yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep ayam goreng bumbu empal tanpa harus bersusah payah.
Seperti resep Ayam Goreng Bumbu Empal yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Bumbu Empal:

1. Tambah 600 gr ayam (saya: 480 gr)
1. Tambah 1 cm lengkuas
1. Harap siapkan 40 gr gula merah (-+ 2 sdm)
1. Harap siapkan 2 daun salam
1. Jangan lupa 1 sdm air asam jawa
1. Dibutuhkan 250 ml air
1. Jangan lupa  Garam
1. Tambah Secukupnya minyak
1. Harus ada  Bumbu halus:
1. Siapkan 4 bawang merah (saya: duo bawang halus)
1. Tambah 3 bawang putih (saya: duo bawang halus)
1. Tambah 1 sdt ketumbar




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Bumbu Empal:

1. Tumis bumbu halus dengan sedikit minyak. Masukkan daun salam dan lengkuas. Kemudian, masukkan ayam. Masak ayam, bolak balik, hingga berubah warna.
1. Tambahkan 250 ml air, gula merah, asam jawa, garam. Masak sambil ayam sesekali dibalik-balik dan bumbu menyusut.
1. Setelah bumbu menyusut, angkat ayam. Kemudian goreng. Siap disajikan.




Demikianlah cara membuat ayam goreng bumbu empal yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan terbukti, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
