---
description: "Cara singkat untuk menyiapakan Ayam rica rica Teruji"
title: "Cara singkat untuk menyiapakan Ayam rica rica Teruji"
slug: 158-cara-singkat-untuk-menyiapakan-ayam-rica-rica-teruji
date: 2021-01-07T02:33:54.341Z
image: https://img-global.cpcdn.com/recipes/77ab5262647d5a0b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/77ab5262647d5a0b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/77ab5262647d5a0b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Brian Wong
ratingvalue: 4.6
reviewcount: 32957
recipeingredient:
- "1/2 kg Ayam aku pakai fillet"
- "2 batang daun bawang"
- "2 ikat daun kemangi"
- "1 sdt garam"
- "1 sdt gula"
- "1/2 sdt kaldu ayam"
- " Bumbu halus"
- "5 siung bawang putih"
- "7 cabe merah"
- "9 cabe rawit lebih atau kurang sesuai selera"
- "1 ruas kunyit bakar"
- "2 butir kemiri sangrai"
recipeinstructions:
- "Cuci ayam,potong sesuai selera. Sisihkan"
- "Haluskan bahan bumbu halus. Kalau sy tidak terlalu halus biar ada teksturnya. Tumis dengan sedikit minyak sampai harum."
- "Masukan daun bawang,tumis sebentar. Masukan ayam,tumis sebentar sampai wangi lalu masukan 1 gelas air. Masak sampai ayam matang."
- "Beri bumbu garam,gula dan kaldu lalu daun kemangi. Tumis sampai rata dan masak sampai air menyusut dan mengental. Angkat"
- "Sajikan deh"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 113 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica rica](https://img-global.cpcdn.com/recipes/77ab5262647d5a0b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas atau renyah. Ciri makanan Nusantara ayam rica rica yang penuh dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan keluarga dapat diperoleh dengan cara simple. Diantaranya adalah memasak Ayam rica rica untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang dapat anda coba salah satunya ayam rica rica yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam rica rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica:

1. Tambah 1/2 kg Ayam (aku pakai fillet)
1. Harus ada 2 batang daun bawang
1. Diperlukan 2 ikat daun kemangi
1. Harus ada 1 sdt garam
1. Jangan lupa 1 sdt gula
1. Harap siapkan 1/2 sdt kaldu ayam
1. Tambah  Bumbu halus:
1. Diperlukan 5 siung bawang putih
1. Jangan lupa 7 cabe merah
1. Tambah 9 cabe rawit lebih atau kurang sesuai selera
1. Diperlukan 1 ruas kunyit bakar
1. Jangan lupa 2 butir kemiri sangrai




<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica:

1. Cuci ayam,potong sesuai selera. Sisihkan
1. Haluskan bahan bumbu halus. Kalau sy tidak terlalu halus biar ada teksturnya. Tumis dengan sedikit minyak sampai harum.
1. Masukan daun bawang,tumis sebentar. Masukan ayam,tumis sebentar sampai wangi lalu masukan 1 gelas air. Masak sampai ayam matang.
1. Beri bumbu garam,gula dan kaldu lalu daun kemangi. Tumis sampai rata dan masak sampai air menyusut dan mengental. Angkat
1. Sajikan deh




Demikianlah cara membuat ayam rica rica yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan terbukti, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
