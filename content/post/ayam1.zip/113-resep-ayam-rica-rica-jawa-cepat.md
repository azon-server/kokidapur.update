---
description: "Resep : Ayam rica rica jawa Cepat"
title: "Resep : Ayam rica rica jawa Cepat"
slug: 113-resep-ayam-rica-rica-jawa-cepat
date: 2020-09-01T06:48:05.711Z
image: https://img-global.cpcdn.com/recipes/98ca6693605b5b29/751x532cq70/ayam-rica-rica-jawa-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/98ca6693605b5b29/751x532cq70/ayam-rica-rica-jawa-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/98ca6693605b5b29/751x532cq70/ayam-rica-rica-jawa-foto-resep-utama.jpg
author: Michael Hughes
ratingvalue: 4.5
reviewcount: 5677
recipeingredient:
- "1/2 kg ayam potong agak kecil"
- "7 butir bawang merah"
- "4 butir bawang putih"
- "10 cabe merah keriting"
- "7 biji cabe rawit setan"
- "3 butir kemiri"
- "1 lembar daun jeruksalam"
- "1 batang serai memarkan"
- "1 ruas jari lengkuas memarkan"
- "2-3 sdm kecap bngo"
- "Secukupnya garam gula penyedap merica"
recipeinstructions:
- "Rebus ayam kemudian tiriskan,"
- "Haluskan bawang merah putih, cabe, kemiri kemudian tumis beserta daun jeruk+salam+lengkuas+serai"
- "Setelah bumbu matang masukkan ayam dan aduk², tunggu sebentar kemudian tambahkan air+garam+gula+penyedap aduk² tunggu sampai menyusut"
- "Jika sudah menyusut, tambahkan kecap manis dan air lagi, aduk² lagi dan tunggu sampai air menyusut, tambahkan merica bubuk secukupnya aja"
- "Kalo suka tekstur rica kering, aduk² sampai benar² air menyusut, kalo saya lebih suka yg agak nyemek gini ya bun, mantap bangett..."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 166 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam rica rica jawa](https://img-global.cpcdn.com/recipes/98ca6693605b5b29/751x532cq70/ayam-rica-rica-jawa-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica rica jawa yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa keistimewahan yang merupakan keragaman Kita

Kehangatan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam rica rica jawa untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis makanan yang bisa anda coba salah satunya ayam rica rica jawa yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep ayam rica rica jawa tanpa harus bersusah payah.
Seperti resep Ayam rica rica jawa yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica jawa:

1. Jangan lupa 1/2 kg ayam potong² agak kecil
1. Harus ada 7 butir bawang merah
1. Siapkan 4 butir bawang putih
1. Siapkan 10 cabe merah keriting
1. Tambah 7 biji cabe rawit setan
1. Dibutuhkan 3 butir kemiri
1. Dibutuhkan 1 lembar daun jeruk+salam
1. Harus ada 1 batang serai memarkan
1. Harus ada 1 ruas jari lengkuas memarkan
1. Dibutuhkan 2-3 sdm kecap b*ngo
1. Siapkan Secukupnya garam gula penyedap merica




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica rica jawa:

1. Rebus ayam kemudian tiriskan,
1. Haluskan bawang merah putih, cabe, kemiri kemudian tumis beserta daun jeruk+salam+lengkuas+serai
1. Setelah bumbu matang masukkan ayam dan aduk², tunggu sebentar kemudian tambahkan air+garam+gula+penyedap aduk² tunggu sampai menyusut
1. Jika sudah menyusut, tambahkan kecap manis dan air lagi, aduk² lagi dan tunggu sampai air menyusut, tambahkan merica bubuk secukupnya aja
1. Kalo suka tekstur rica kering, aduk² sampai benar² air menyusut, kalo saya lebih suka yg agak nyemek gini ya bun, mantap bangett...




Demikianlah cara membuat ayam rica rica jawa yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
