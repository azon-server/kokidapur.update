---
description: "Bagaimana membuat Ayam goreng crispy simple no ribet Homemade"
title: "Bagaimana membuat Ayam goreng crispy simple no ribet Homemade"
slug: 456-bagaimana-membuat-ayam-goreng-crispy-simple-no-ribet-homemade
date: 2020-09-02T09:38:02.523Z
image: https://img-global.cpcdn.com/recipes/155b4325c6acba77/751x532cq70/ayam-goreng-crispy-simple-no-ribet-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/155b4325c6acba77/751x532cq70/ayam-goreng-crispy-simple-no-ribet-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/155b4325c6acba77/751x532cq70/ayam-goreng-crispy-simple-no-ribet-foto-resep-utama.jpg
author: Randy Holland
ratingvalue: 4.4
reviewcount: 20761
recipeingredient:
- "1/2 kg ayam yg sudah di marinasi           lihat resep"
- "500 gr tepung terigu serbagunasegitiga"
- "100 gr tepung maizena"
- "2 sachet kaldu bubuk rycomasko"
- "1 sdt garam halus"
- "2 sdt merica bubuk"
- "1/2 sdt bawang putih bubuk"
- " Air putih untuk celupan 1liter  secukup nya"
recipeinstructions:
- "Siapkan wadah lalu campur semua bahan kering jadi satu dan aduk hingga rata,jangan lupa siapkan air dan saringan untuk celup basah"
- "Masukan ayam yg sudah di marinasi, pada wadah yg berisi tepung guling2 kan hingga tercampur rata dengan cara mengeruk tepung dari bawah dan balikan ayam dengan dua telapak tangan,jadi pastikan wadah nya aga luas ya😂"
- "Setelah ayam terbaluri sempurna di tahap penepungan ke 1,masukan ayam pada saringan/wadah berlubang,celup kan pada air hingga ayam terendam,tapi cukup sebentar aja ya jangan terlalu lama nanti malah rontok semua tepung nya😂,angkat dan tiriskan, lalu masukan kembali ayam pada wadah tepung kering untuk proses penepungan ke 2"
- "Cara penepungan ke 2 sama seperti penepungan pertama,biasanya saya cukup 2 kali penepungan saja,tapi jika ingin dapat tepung yg lebih tebal boleh ko di tambah 1x proses penepungan nya😄dan ini lah hasil 2x penepungan siap untuk di goreng"
- "Pakai minyak goreng aga banyak ya supaya ayam terendam,dan matang merata,panaskan minyak hingga benar2 panas,lalu masukan ayam goreng dengan api besar selama 5 menit,setelah 5menit barulah kecilkan api kompor,goreng hingga matang dan cukup 1xbalik saja yah supaya tepung tidak patah2 😅"
- "Dan jadiii lahhhh ayam goreng crspy simple nya,sambil di praktekin ya bun,kalau di baca aja pasti terlihat ribet+panjang,tapi kalau udah di praktekin simple ko 😄selamat mencoba"
- "Note: untuk hasil kribo pada saat proses penepungan gunakan cara mengeruk tepung dari bawah ke atas dan lakukan beberapa kali hingga ayam tertutup rata, gunakan minyak yg panas dan api besar agar pada saat 5 menit awal menggoreng guna nya untuk membuat tekstur krispy di tepung kuat dan merekah,setelah 5 menit baru kecilkan api di anjurkan hanya boleh membalik 1kali saja ya agar krispy tepung tidak patah,goreng dengan minyak yg banyak yaa,agar ayam matang merata sekian resep nya selamat mencoba😆"
- "Lembut dan meresap bumbu pada daging nya,tapi krunchy dan renyah tepung di luarnya"
categories:
- Recipe
tags:
- ayam
- goreng
- crispy

katakunci: ayam goreng crispy 
nutrition: 168 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam goreng crispy simple no ribet](https://img-global.cpcdn.com/recipes/155b4325c6acba77/751x532cq70/ayam-goreng-crispy-simple-no-ribet-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang dapat kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam goreng crispy simple no ribet yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa keistimewahan yang merupakan keragaman Kita

Kehangatan rumah tangga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam goreng crispy simple no ribet untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang bisa anda praktekkan salah satunya ayam goreng crispy simple no ribet yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam goreng crispy simple no ribet tanpa harus bersusah payah.
Berikut ini resep Ayam goreng crispy simple no ribet yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 8 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam goreng crispy simple no ribet:

1. Tambah 1/2 kg ayam yg sudah di marinasi           (lihat resep)
1. Harap siapkan 500 gr tepung terigu serbaguna(segitiga)
1. Siapkan 100 gr tepung maizena
1. Dibutuhkan 2 sachet kaldu bubuk r*yco/mas*ko
1. Harap siapkan 1 sdt garam halus
1. Jangan lupa 2 sdt merica bubuk
1. Siapkan 1/2 sdt bawang putih bubuk
1. Jangan lupa  Air putih untuk celupan 1liter / secukup nya




<!--inarticleads2-->

##### Langkah membuat  Ayam goreng crispy simple no ribet:

1. Siapkan wadah lalu campur semua bahan kering jadi satu dan aduk hingga rata,jangan lupa siapkan air dan saringan untuk celup basah
1. Masukan ayam yg sudah di marinasi, pada wadah yg berisi tepung guling2 kan hingga tercampur rata dengan cara mengeruk tepung dari bawah dan balikan ayam dengan dua telapak tangan,jadi pastikan wadah nya aga luas ya😂
1. Setelah ayam terbaluri sempurna di tahap penepungan ke 1,masukan ayam pada saringan/wadah berlubang,celup kan pada air hingga ayam terendam,tapi cukup sebentar aja ya jangan terlalu lama nanti malah rontok semua tepung nya😂,angkat dan tiriskan, lalu masukan kembali ayam pada wadah tepung kering untuk proses penepungan ke 2
1. Cara penepungan ke 2 sama seperti penepungan pertama,biasanya saya cukup 2 kali penepungan saja,tapi jika ingin dapat tepung yg lebih tebal boleh ko di tambah 1x proses penepungan nya😄dan ini lah hasil 2x penepungan siap untuk di goreng
1. Pakai minyak goreng aga banyak ya supaya ayam terendam,dan matang merata,panaskan minyak hingga benar2 panas,lalu masukan ayam goreng dengan api besar selama 5 menit,setelah 5menit barulah kecilkan api kompor,goreng hingga matang dan cukup 1xbalik saja yah supaya tepung tidak patah2 😅
1. Dan jadiii lahhhh ayam goreng crspy simple nya,sambil di praktekin ya bun,kalau di baca aja pasti terlihat ribet+panjang,tapi kalau udah di praktekin simple ko 😄selamat mencoba
1. Note: untuk hasil kribo pada saat proses penepungan gunakan cara mengeruk tepung dari bawah ke atas dan lakukan beberapa kali hingga ayam tertutup rata, gunakan minyak yg panas dan api besar agar pada saat 5 menit awal menggoreng guna nya untuk membuat tekstur krispy di tepung kuat dan merekah,setelah 5 menit baru kecilkan api di anjurkan hanya boleh membalik 1kali saja ya agar krispy tepung tidak patah,goreng dengan minyak yg banyak yaa,agar ayam matang merata sekian resep nya selamat mencoba😆
1. Lembut dan meresap bumbu pada daging nya,tapi krunchy dan renyah tepung di luarnya




Demikianlah cara membuat ayam goreng crispy simple no ribet yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan terbukti, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
