---
description: "Panduan untuk menyiapakan Ayam rica2 pedas Sempurna"
title: "Panduan untuk menyiapakan Ayam rica2 pedas Sempurna"
slug: 222-panduan-untuk-menyiapakan-ayam-rica2-pedas-sempurna
date: 2020-12-07T23:23:11.700Z
image: https://img-global.cpcdn.com/recipes/e42be5946ab7b9df/751x532cq70/ayam-rica2-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e42be5946ab7b9df/751x532cq70/ayam-rica2-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e42be5946ab7b9df/751x532cq70/ayam-rica2-pedas-foto-resep-utama.jpg
author: Winifred Porter
ratingvalue: 4.9
reviewcount: 15693
recipeingredient:
- "1/2 kg ayam potong2"
- " Bumbu halus"
- "5 siung bamer"
- "4 siung baput"
- "6 buah cabemerah"
- "9 buah cabai rawit"
- "3 butir kemiri sangrai"
- "1 ruas jahe"
- " Bumbu tambahan cemplung"
- "2 ruas serai"
- "3 lbr daun salam"
- "1 ruas lengkuas"
- "10 buh cabai rawit"
- "1 ikat kemangi"
- "Secukupnya garam"
- "Secukupnya gula pasir"
- "Secukupnya penyedap"
- "1 gelas belimbing air"
- "3 SDM kecp manis"
recipeinstructions:
- "Potong2 ayam cuci bersih dan rebus sebentar dengan daun salam. Setelah di rebus kemudin tiriskan dan goreng sebentar saja supaya layu dan ga amis."
- "Tumis bumbu halus hingga harum, masukan daun salam,sereh,lengkuas aduk2 hingga harum kemudian masukan 1 gelas air dan jika sudah mendidih masukan ayam."
- "Aduk2 hingga rata, msukan garam,penyedap,gula,dan kecap aduk2 hingga bumbu meresap."
- "Koreksi rasa jika bumbu sudah benar2 tinggal sedikit masukan kemangi dan aduk2 sebentar kemudian angkat dan sajikan."
categories:
- Recipe
tags:
- ayam
- rica2
- pedas

katakunci: ayam rica2 pedas 
nutrition: 204 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam rica2 pedas](https://img-global.cpcdn.com/recipes/e42be5946ab7b9df/751x532cq70/ayam-rica2-pedas-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas dan gurih. Ciri khas masakan Nusantara ayam rica2 pedas yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Ayam rica2 pedas untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang dapat anda coba salah satunya ayam rica2 pedas yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica2 pedas tanpa harus bersusah payah.
Seperti resep Ayam rica2 pedas yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica2 pedas:

1. Jangan lupa 1/2 kg ayam potong2
1. Jangan lupa  Bumbu halus
1. Jangan lupa 5 siung bamer
1. Tambah 4 siung baput
1. Harus ada 6 buah cabemerah
1. Harap siapkan 9 buah cabai rawit
1. Diperlukan 3 butir kemiri sangrai
1. Jangan lupa 1 ruas jahe
1. Harap siapkan  Bumbu tambahan (cemplung)
1. Dibutuhkan 2 ruas serai
1. Siapkan 3 lbr daun salam
1. Dibutuhkan 1 ruas lengkuas
1. Dibutuhkan 10 buh cabai rawit
1. Dibutuhkan 1 ikat kemangi
1. Tambah Secukupnya garam
1. Siapkan Secukupnya gula pasir
1. Dibutuhkan Secukupnya penyedap
1. Diperlukan 1 gelas belimbing air
1. Tambah 3 SDM kecp manis




<!--inarticleads2-->

##### Cara membuat  Ayam rica2 pedas:

1. Potong2 ayam cuci bersih dan rebus sebentar dengan daun salam. Setelah di rebus kemudin tiriskan dan goreng sebentar saja supaya layu dan ga amis.
1. Tumis bumbu halus hingga harum, masukan daun salam,sereh,lengkuas aduk2 hingga harum kemudian masukan 1 gelas air dan jika sudah mendidih masukan ayam.
1. Aduk2 hingga rata, msukan garam,penyedap,gula,dan kecap aduk2 hingga bumbu meresap.
1. Koreksi rasa jika bumbu sudah benar2 tinggal sedikit masukan kemangi dan aduk2 sebentar kemudian angkat dan sajikan.




Demikianlah cara membuat ayam rica2 pedas yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan terbukti, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
