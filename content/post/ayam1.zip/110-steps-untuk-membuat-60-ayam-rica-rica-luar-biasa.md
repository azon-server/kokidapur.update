---
description: "Steps untuk membuat 60. Ayam Rica Rica Luar biasa"
title: "Steps untuk membuat 60. Ayam Rica Rica Luar biasa"
slug: 110-steps-untuk-membuat-60-ayam-rica-rica-luar-biasa
date: 2020-12-20T10:19:08.221Z
image: https://img-global.cpcdn.com/recipes/a3d6b3d4f3c729ca/751x532cq70/60-ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a3d6b3d4f3c729ca/751x532cq70/60-ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a3d6b3d4f3c729ca/751x532cq70/60-ayam-rica-rica-foto-resep-utama.jpg
author: Troy Young
ratingvalue: 4.1
reviewcount: 36525
recipeingredient:
- "2 potong ayam bagian dada potong kecil2"
- "1/2 ikat daun kemangi ambil daunnya"
- " Bumbu halus"
- "5 bh bamer"
- "2 bh baput"
- "7 bh cabe merah kriting"
- "5 bh cabe rawit"
- "1/4 sdt kunyit bubuk"
- "1/2 sdt lada bubuk"
- "1/4 sdt ketumbar bubuk"
- "2 butir kemiri"
- "Secukupnya garam"
- " Bumbu lain"
- "1 ruas jahe geprek"
- "1/2 tangkai serai geprek"
- "2 lbr daun salam"
- "3 lbr daun jeruk"
- "1 ruas lengkuas geprek"
- "600 ml air"
- "Secukupnya garam dan penyedap"
- " Minyak untuk numis"
recipeinstructions:
- "Cuci bersih ayam, sisihkan. Tumis bumbu halus dan semua bumbu tambahan lainnya hingga harum."
- "Tambahkan air, aduk dan tunggu hingga mendidih. Masukkan ayam, aduk. Biarkan hingga ayam matang dan kuah agak menyusut / menyerap."
- "Ketika air tinggal dikit, sebelum menyusut, tambahkan garam dan penyedap, tes rasa. Aduk dan tunggu hingga air menyusut."
- "Tambahkan kemangi, aduk rata. Matikan kompor, sajikan ayam rica rica."
categories:
- Recipe
tags:
- 60
- ayam
- rica

katakunci: 60 ayam rica 
nutrition: 230 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Dessert

---


![60. Ayam Rica Rica](https://img-global.cpcdn.com/recipes/a3d6b3d4f3c729ca/751x532cq70/60-ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan enak. Ciri kuliner Nusantara 60. ayam rica rica yang kaya dengan bumbu memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kedekatan keluarga dapat didapat dengan cara mudah. Diantaranya adalah memasak 60. Ayam Rica Rica untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang bisa anda buat salah satunya 60. ayam rica rica yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep 60. ayam rica rica tanpa harus bersusah payah.
Berikut ini resep 60. Ayam Rica Rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 21 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 60. Ayam Rica Rica:

1. Dibutuhkan 2 potong ayam bagian dada, potong kecil2
1. Dibutuhkan 1/2 ikat daun kemangi, ambil daunnya
1. Harap siapkan  Bumbu halus:
1. Tambah 5 bh bamer
1. Harus ada 2 bh baput
1. Siapkan 7 bh cabe merah kriting
1. Jangan lupa 5 bh cabe rawit
1. Dibutuhkan 1/4 sdt kunyit bubuk
1. Harap siapkan 1/2 sdt lada bubuk
1. Jangan lupa 1/4 sdt ketumbar bubuk
1. Harus ada 2 butir kemiri
1. Harus ada Secukupnya garam
1. Tambah  Bumbu lain:
1. Tambah 1 ruas jahe geprek
1. Harus ada 1/2 tangkai serai geprek
1. Harap siapkan 2 lbr daun salam
1. Harap siapkan 3 lbr daun jeruk
1. Harus ada 1 ruas lengkuas geprek
1. Harus ada 600 ml air
1. Jangan lupa Secukupnya garam dan penyedap
1. Jangan lupa  Minyak untuk numis




<!--inarticleads2-->

##### Langkah membuat  60. Ayam Rica Rica:

1. Cuci bersih ayam, sisihkan. Tumis bumbu halus dan semua bumbu tambahan lainnya hingga harum.
1. Tambahkan air, aduk dan tunggu hingga mendidih. Masukkan ayam, aduk. Biarkan hingga ayam matang dan kuah agak menyusut / menyerap.
1. Ketika air tinggal dikit, sebelum menyusut, tambahkan garam dan penyedap, tes rasa. Aduk dan tunggu hingga air menyusut.
1. Tambahkan kemangi, aduk rata. Matikan kompor, sajikan ayam rica rica.




Demikianlah cara membuat 60. ayam rica rica yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan terbukti, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
