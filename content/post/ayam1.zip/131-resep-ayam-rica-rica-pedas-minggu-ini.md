---
description: "Resep : Ayam rica rica pedas minggu ini"
title: "Resep : Ayam rica rica pedas minggu ini"
slug: 131-resep-ayam-rica-rica-pedas-minggu-ini
date: 2020-09-12T15:54:06.385Z
image: https://img-global.cpcdn.com/recipes/9ad99f42c619faee/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9ad99f42c619faee/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9ad99f42c619faee/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
author: Stanley Dawson
ratingvalue: 5
reviewcount: 3631
recipeingredient:
- "1 ekor ayam potong 8"
- "8 biji bawang merah"
- "5 biji bawang putih"
- "5 lembar daun jeruk"
- "1 buah sereh digeprek"
- "2 biji Kemiri"
- "secukupnya Lada"
- "secukupnya Ketumbar"
- "secukupnya Garam gula dan penyedap rasa"
- "1 ruas Kunyit dan jahe masing masing"
recipeinstructions:
- "Rebus ayam sebentar, atau boleh digoreng ayam sebentar saja."
- "Haluskan bumbu bumbu diatas kecuali daun jeruk dan sereh"
- "Siapkan minyak goreng sedikit panaskan masukan bumbu yg sudah dihaluskan, masukan juga daun jeruk dan sereh geprek dl, tumis sampai harum"
- "Setelah harum, masukan ayam dan air secukupnya, tambahkan gula, garam dan penyedap rasa, dan diamkan sampai matang/air tinggal sedikit. Sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 184 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica rica pedas](https://img-global.cpcdn.com/recipes/9ad99f42c619faee/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica rica pedas yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa ciri khas yang merupakan keragaman Nusantara

Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam rica rica pedas untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang bisa anda buat salah satunya ayam rica rica pedas yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica rica pedas tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica pedas yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica pedas:

1. Jangan lupa 1 ekor ayam potong 8
1. Harus ada 8 biji bawang merah
1. Dibutuhkan 5 biji bawang putih
1. Tambah 5 lembar daun jeruk
1. Harap siapkan 1 buah sereh digeprek
1. Harap siapkan 2 biji Kemiri
1. Dibutuhkan secukupnya Lada
1. Harap siapkan secukupnya Ketumbar
1. Harus ada secukupnya Garam, gula dan penyedap rasa
1. Harap siapkan 1 ruas Kunyit dan jahe masing masing




<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica pedas:

1. Rebus ayam sebentar, atau boleh digoreng ayam sebentar saja.
1. Haluskan bumbu bumbu diatas kecuali daun jeruk dan sereh
1. Siapkan minyak goreng sedikit panaskan masukan bumbu yg sudah dihaluskan, masukan juga daun jeruk dan sereh geprek dl, tumis sampai harum
1. Setelah harum, masukan ayam dan air secukupnya, tambahkan gula, garam dan penyedap rasa, dan diamkan sampai matang/air tinggal sedikit. Sajikan




Demikianlah cara membuat ayam rica rica pedas yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
