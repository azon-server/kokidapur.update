---
description: "Resep : Ayam Rica (1) Cepat"
title: "Resep : Ayam Rica (1) Cepat"
slug: 216-resep-ayam-rica-1-cepat
date: 2020-11-18T00:03:52.484Z
image: https://img-global.cpcdn.com/recipes/9824ace10a62ad2b/751x532cq70/ayam-rica-1-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9824ace10a62ad2b/751x532cq70/ayam-rica-1-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9824ace10a62ad2b/751x532cq70/ayam-rica-1-foto-resep-utama.jpg
author: Nannie Zimmerman
ratingvalue: 4.7
reviewcount: 7959
recipeingredient:
- "6 potongan ayam dgn ukuran kecil"
- "3 siung bawang putih"
- "5 buah cabe rawit merah"
- "1/2 buah bawang bombay ukuran sedang"
- "1/2 buah tomat ukuran kecil potong kotak"
- "1 batang daun bawang iris kasar"
- "1/2 sdm saos tiram"
- "1/2 sdm saos sambal"
- "1/2 sdm saos tomat"
- "1/2 gelas air"
- "Sejumput garam"
- "Sejumput merica"
recipeinstructions:
- "Goreng ayam sampai berwarna keemasan. Sisihkan."
- "Iris bawang bombay, bawang putih daun bawang, cabe rawit &amp; tomat."
- "Tumis bawang putih &amp; bawang bombay. Lalu masukkan cabe &amp; tomat. Masak sampai layu."
- "Tambahkan saos tiram, saos sambal &amp; saoa tomat. Aduk rata lalu tambahkan air. Kemudian masukkan daun bawang."
- "Masak sampai agak layu, lalu masukkan ayam yg td sdh di goreng. Masukkan juga garam, penyedap rasa &amp; merica. Masak sampai air agak menyusut. Salin di piring saji."
categories:
- Recipe
tags:
- ayam
- rica
- 1

katakunci: ayam rica 1 
nutrition: 260 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica (1)](https://img-global.cpcdn.com/recipes/9824ace10a62ad2b/751x532cq70/ayam-rica-1-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang patut kita jaga karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica (1) yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa keistimewahan yang merupakan keragaman Indonesia



Kedekatan rumah tangga bisa didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica (1) untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda buat salah satunya ayam rica (1) yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica (1) tanpa harus bersusah payah.
Seperti resep Ayam Rica (1) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 12 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica (1):

1. Harap siapkan 6 potongan ayam dgn ukuran kecil
1. Dibutuhkan 3 siung bawang putih
1. Dibutuhkan 5 buah cabe rawit merah
1. Diperlukan 1/2 buah bawang bombay ukuran sedang
1. Harap siapkan 1/2 buah tomat ukuran kecil, potong kotak
1. Jangan lupa 1 batang daun bawang, iris kasar
1. Harap siapkan 1/2 sdm saos tiram
1. Harus ada 1/2 sdm saos sambal
1. Diperlukan 1/2 sdm saos tomat
1. Harap siapkan 1/2 gelas air
1. Diperlukan Sejumput garam
1. Harus ada Sejumput merica




<!--inarticleads2-->

##### Cara membuat  Ayam Rica (1):

1. Goreng ayam sampai berwarna keemasan. Sisihkan.
1. Iris bawang bombay, bawang putih daun bawang, cabe rawit &amp; tomat.
1. Tumis bawang putih &amp; bawang bombay. Lalu masukkan cabe &amp; tomat. Masak sampai layu.
1. Tambahkan saos tiram, saos sambal &amp; saoa tomat. Aduk rata lalu tambahkan air. Kemudian masukkan daun bawang.
1. Masak sampai agak layu, lalu masukkan ayam yg td sdh di goreng. Masukkan juga garam, penyedap rasa &amp; merica. Masak sampai air agak menyusut. Salin di piring saji.




Demikianlah cara membuat ayam rica (1) yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
