---
description: "Steps membuat Ayam Ungkep (untuk ayam goreng) Cepat"
title: "Steps membuat Ayam Ungkep (untuk ayam goreng) Cepat"
slug: 322-steps-membuat-ayam-ungkep-untuk-ayam-goreng-cepat
date: 2020-08-28T11:15:00.239Z
image: https://img-global.cpcdn.com/recipes/86a5b344c7d59c08/751x532cq70/ayam-ungkep-untuk-ayam-goreng-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/86a5b344c7d59c08/751x532cq70/ayam-ungkep-untuk-ayam-goreng-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/86a5b344c7d59c08/751x532cq70/ayam-ungkep-untuk-ayam-goreng-foto-resep-utama.jpg
author: Nell Wise
ratingvalue: 4.1
reviewcount: 34389
recipeingredient:
- "1 ekor Ayam ukuran sedang"
- "1 ruas besar Jahe"
- "1 ruas besar Lengkuas"
- "1 1/2 ruas besar Kunyit"
- "10 Bawang putih"
- "4 Bawang merah"
- "2 batang Sereh"
- "4 lembar Daun salam"
- "4 lembar Daun jeruk"
recipeinstructions:
- "Potong ayam menjadi 10 bagian, cuci hingga bersih, kemudian kasih air jeruk nipis sisihkan"
- "Bersihkan bumbu, potong2 bawang merah, bawang putih, jahe, lengkuas dan kunyit kemudian blender"
- "Taruh ayam di atas wajan, masukkan daun salam, daun jeruk, sereh yang sudah digeprek dan bumbu halus. Kasih garam 2 sdt munjung"
- "Ayam dan bumbu diaduk rata, tutup wajan dan nyalakan api. Tidak usah kasih air ya. Nanti airnya keluar sendiri dari ayamnya"
- "Setelah bumbu meresap dan airnya sudah mengering, angkat ayamnya, dinginkan sebentar dan siap masuk kulkas. Dapat di goreng saat mau makan."
categories:
- Recipe
tags:
- ayam
- ungkep
- untuk

katakunci: ayam ungkep untuk 
nutrition: 177 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Ungkep (untuk ayam goreng)](https://img-global.cpcdn.com/recipes/86a5b344c7d59c08/751x532cq70/ayam-ungkep-untuk-ayam-goreng-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang setidaknya kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam ungkep (untuk ayam goreng) yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan keistimewahan yang merupakan keragaman Kita

Kehangatan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Ungkep (untuk ayam goreng) untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang dapat anda buat salah satunya ayam ungkep (untuk ayam goreng) yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep ayam ungkep (untuk ayam goreng) tanpa harus bersusah payah.
Berikut ini resep Ayam Ungkep (untuk ayam goreng) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 9 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Ungkep (untuk ayam goreng):

1. Harap siapkan 1 ekor Ayam ukuran sedang
1. Harus ada 1 ruas besar Jahe
1. Tambah 1 ruas besar Lengkuas
1. Tambah 1 1/2 ruas besar Kunyit
1. Jangan lupa 10 Bawang putih
1. Dibutuhkan 4 Bawang merah
1. Siapkan 2 batang Sereh
1. Tambah 4 lembar Daun salam
1. Tambah 4 lembar Daun jeruk




<!--inarticleads2-->

##### Cara membuat  Ayam Ungkep (untuk ayam goreng):

1. Potong ayam menjadi 10 bagian, cuci hingga bersih, kemudian kasih air jeruk nipis sisihkan
1. Bersihkan bumbu, potong2 bawang merah, bawang putih, jahe, lengkuas dan kunyit kemudian blender
1. Taruh ayam di atas wajan, masukkan daun salam, daun jeruk, sereh yang sudah digeprek dan bumbu halus. Kasih garam 2 sdt munjung
1. Ayam dan bumbu diaduk rata, tutup wajan dan nyalakan api. Tidak usah kasih air ya. Nanti airnya keluar sendiri dari ayamnya
1. Setelah bumbu meresap dan airnya sudah mengering, angkat ayamnya, dinginkan sebentar dan siap masuk kulkas. Dapat di goreng saat mau makan.




Demikianlah cara membuat ayam ungkep (untuk ayam goreng) yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan terbukti, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
