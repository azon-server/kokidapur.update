---
description: "Langkah menyiapakan Ayam rica-rica kemangi minggu ini"
title: "Langkah menyiapakan Ayam rica-rica kemangi minggu ini"
slug: 111-langkah-menyiapakan-ayam-rica-rica-kemangi-minggu-ini
date: 2020-08-26T13:42:07.170Z
image: https://img-global.cpcdn.com/recipes/5c2a007f00314a27/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5c2a007f00314a27/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5c2a007f00314a27/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Samuel Schultz
ratingvalue: 4.8
reviewcount: 26862
recipeingredient:
- "500 grm ayam"
- "900 ml santan"
- "1 ikat kemangi"
- "2 btg serai"
- "3 lmbr daun jeruk"
- "1 lmbr daun salam"
- " Minyak untuk menggoreng"
- " Bumbu halus "
- "5 butir bawang merah"
- "3 siung bawang putih"
- "3 buah cabe merah"
- "10 buah cabe rawit"
- "3 butir kemiri sangrai"
- "2 cm kunyit"
- "2 cm jahe"
- "1/2 sdt ketumbar"
recipeinstructions:
- "Cuci bersih ayam kemudian rebus hingga setengah matang angkat dan tiriskn"
- "Goreng ayam tidak sampai garing kemudian sisihkan."
- "Blender bumbu halus kemudia masak di atas wajan dan masukkan serai,daun salam,daun jeruk dan masak hingga tanak."
- "Masukkan ayam ke dalam bumbu masukkan garam,gula dan penyedap rasa dan tmbahkan santan."
- "Masak hingga kuah santan agak menyusut perbarui rasa dan masukkan kemangi yang sudah di cuci dan di siangi."
- "Aduk hingga agak layu kemanginya ayam rica siap di sajikan."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 199 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/5c2a007f00314a27/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau empuk. Ciri kuliner Nusantara ayam rica-rica kemangi yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kedekatan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah memasak Ayam rica-rica kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang dapat anda coba salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica kemangi:

1. Harap siapkan 500 grm ayam
1. Diperlukan 900 ml santan
1. Tambah 1 ikat kemangi
1. Tambah 2 btg serai
1. Tambah 3 lmbr daun jeruk
1. Dibutuhkan 1 lmbr daun salam
1. Dibutuhkan  Minyak untuk menggoreng
1. Jangan lupa  Bumbu halus :
1. Harus ada 5 butir bawang merah
1. Diperlukan 3 siung bawang putih
1. Harap siapkan 3 buah cabe merah
1. Jangan lupa 10 buah cabe rawit
1. Diperlukan 3 butir kemiri sangrai
1. Jangan lupa 2 cm kunyit
1. Tambah 2 cm jahe
1. Harap siapkan 1/2 sdt ketumbar




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica-rica kemangi:

1. Cuci bersih ayam kemudian rebus hingga setengah matang angkat dan tiriskn
1. Goreng ayam tidak sampai garing kemudian sisihkan.
1. Blender bumbu halus kemudia masak di atas wajan dan masukkan serai,daun salam,daun jeruk dan masak hingga tanak.
1. Masukkan ayam ke dalam bumbu masukkan garam,gula dan penyedap rasa dan tmbahkan santan.
1. Masak hingga kuah santan agak menyusut perbarui rasa dan masukkan kemangi yang sudah di cuci dan di siangi.
1. Aduk hingga agak layu kemanginya ayam rica siap di sajikan.




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
