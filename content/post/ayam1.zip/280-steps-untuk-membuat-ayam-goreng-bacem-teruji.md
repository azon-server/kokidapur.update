---
description: "Steps untuk membuat Ayam Goreng Bacem Teruji"
title: "Steps untuk membuat Ayam Goreng Bacem Teruji"
slug: 280-steps-untuk-membuat-ayam-goreng-bacem-teruji
date: 2020-08-07T04:35:23.308Z
image: https://img-global.cpcdn.com/recipes/58e992f87fc6c349/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/58e992f87fc6c349/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/58e992f87fc6c349/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg
author: Sadie Jordan
ratingvalue: 5
reviewcount: 8183
recipeingredient:
- " Ayam pejantan potong jadi 8 bagian"
- "1,5 sdm ketumbar sy pake bubuk"
- "2 lembar Daun salam"
- "2 ruas laos geprek"
- "4 sdm Kecap manis"
- "1 sdm Saos tiram"
- "1 buah Gula merah rajang"
- "secukupnya Garam Kaldu Ayam dan merica"
- " Kemiri saya skip"
- " Bumbu Halusblender"
- "6 siung Bawang putih"
- "5 siung bawang merah"
- "3 potong cabe bisa skip"
recipeinstructions:
- "Cuci bersih ayam. Masukan ke dalam wajan yg diisi air. Takaran Air sampai ayamnya terendam. Masukan bumbu halus, gula merah, ketumbar, daun salam, laos.. Masak sampai air asat separo porsi"
- "Setelah mendidih dan agak asat, beri kecap, saos tiram, garam, kaldu dan merica secukupnya. Masak sampai kuah mengental"
- "Setelah kuah jadi kental, goreng ayam dengan minyak panas... Siap disantap pakai nasi hangat... Yummy..😚"
categories:
- Recipe
tags:
- ayam
- goreng
- bacem

katakunci: ayam goreng bacem 
nutrition: 158 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Goreng Bacem](https://img-global.cpcdn.com/recipes/58e992f87fc6c349/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas atau gurih. Ciri khas masakan Indonesia ayam goreng bacem yang penuh dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan rumah tangga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam Goreng Bacem untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang dapat anda praktekkan salah satunya ayam goreng bacem yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep ayam goreng bacem tanpa harus bersusah payah.
Berikut ini resep Ayam Goreng Bacem yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 13 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Bacem:

1. Dibutuhkan  Ayam pejantan potong jadi 8 bagian
1. Harap siapkan 1,5 sdm ketumbar (sy pake bubuk)
1. Dibutuhkan 2 lembar Daun salam
1. Diperlukan 2 ruas laos geprek
1. Harus ada 4 sdm Kecap manis
1. Diperlukan 1 sdm Saos tiram
1. Tambah 1 buah Gula merah (rajang)
1. Harap siapkan secukupnya Garam, Kaldu Ayam, dan merica
1. Tambah  Kemiri (saya skip)
1. Dibutuhkan  Bumbu Halus/blender
1. Siapkan 6 siung Bawang putih
1. Harus ada 5 siung bawang merah
1. Tambah 3 potong cabe (bisa skip)




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Bacem:

1. Cuci bersih ayam. Masukan ke dalam wajan yg diisi air. Takaran Air sampai ayamnya terendam. Masukan bumbu halus, gula merah, ketumbar, daun salam, laos.. Masak sampai air asat separo porsi
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Goreng Bacem">1. Setelah mendidih dan agak asat, beri kecap, saos tiram, garam, kaldu dan merica secukupnya. Masak sampai kuah mengental
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Goreng Bacem">1. Setelah kuah jadi kental, goreng ayam dengan minyak panas... Siap disantap pakai nasi hangat... Yummy..😚




Demikianlah cara membuat ayam goreng bacem yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan cepat, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
