---
description: "Resep : Ayam Goreng Kalasan teraktual"
title: "Resep : Ayam Goreng Kalasan teraktual"
slug: 258-resep-ayam-goreng-kalasan-teraktual
date: 2020-08-21T06:45:16.022Z
image: https://img-global.cpcdn.com/recipes/ea10ede2493907c3/751x532cq70/ayam-goreng-kalasan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ea10ede2493907c3/751x532cq70/ayam-goreng-kalasan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ea10ede2493907c3/751x532cq70/ayam-goreng-kalasan-foto-resep-utama.jpg
author: Barry Moody
ratingvalue: 4.3
reviewcount: 8817
recipeingredient:
- "1 ekor ayam potong 12 harusnya ayam kampung tp sy pakai negri"
- " Bumbu yg dihaluskan"
- "7 siung bawang putih"
- "4 bawang merah"
- "4 butir kemiri"
- "5 cm Lengkuas"
- "3 cm Jahe"
- " Bahan lain"
- "2 batang sereh"
- "3 daun jeruk"
- "3 daun salam"
- "1 sdm Ketumbar bubuk"
- "1/2 sdt Kunyit bubuk"
- "1/2 sdt Merica"
- "2 sdt Garam"
- "2 sdt gula"
- "1500 CC santan dari kelapa yg diperas dari air kelapanya"
recipeinstructions:
- "Bersihkan ayam. Lumuri dengan 2 buah jeruk nipis dan 1 sdm garam. Diamkan kurang lebih 30 menit. Setelah 30 menit. Cuci kembali ayam. Sisihkan dulu."
- "Haluskan semua bumbu yg untuk dihaluskan. Sisihkan dulu."
- "Masukan semua bumbu halus, sereh, daun salam, daun jeruk ketumbar, lada, kunyit, gula, ayam. Masak dengan api sedang sampai mendidih. Setelah mendidih, tutup panci, kecilkan api, masak 30 menit. Jangan buka tutup panci. Setelah 30 menit buka tutup panci. Kemudian tutup lagi, masak lagi 15 menit. Jangan lupa, masaknya pakai api yg kecil, supaya airnya tak cepat habis karena dimasaknya hampir 45 menit."
- "Setelah 45 menit, goreng dng minyak panas. Siap sajikan."
categories:
- Recipe
tags:
- ayam
- goreng
- kalasan

katakunci: ayam goreng kalasan 
nutrition: 291 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT35M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Goreng Kalasan](https://img-global.cpcdn.com/recipes/ea10ede2493907c3/751x532cq70/ayam-goreng-kalasan-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita jaga karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam goreng kalasan yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara

Kehangatan rumah tangga dapat ditemukan dengan cara simple. Salah satunya adalah membuat makanan Ayam Goreng Kalasan untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang bisa anda coba salah satunya ayam goreng kalasan yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep ayam goreng kalasan tanpa harus bersusah payah.
Seperti resep Ayam Goreng Kalasan yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Kalasan:

1. Diperlukan 1 ekor ayam potong 12 (harusnya ayam kampung, tp sy pakai negri)
1. Diperlukan  Bumbu yg dihaluskan:
1. Harus ada 7 siung bawang putih
1. Diperlukan 4 bawang merah
1. Harap siapkan 4 butir kemiri
1. Dibutuhkan 5 cm Lengkuas
1. Tambah 3 cm Jahe
1. Tambah  Bahan lain
1. Harus ada 2 batang sereh
1. Dibutuhkan 3 daun jeruk
1. Siapkan 3 daun salam
1. Dibutuhkan 1 sdm Ketumbar bubuk
1. Tambah 1/2 sdt Kunyit bubuk
1. Siapkan 1/2 sdt Merica
1. Harus ada 2 sdt Garam
1. Harap siapkan 2 sdt gula
1. Dibutuhkan 1500 CC santan dari kelapa yg diperas dari air kelapanya




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Kalasan:

1. Bersihkan ayam. Lumuri dengan 2 buah jeruk nipis dan 1 sdm garam. Diamkan kurang lebih 30 menit. Setelah 30 menit. Cuci kembali ayam. Sisihkan dulu.
1. Haluskan semua bumbu yg untuk dihaluskan. Sisihkan dulu.
1. Masukan semua bumbu halus, sereh, daun salam, daun jeruk ketumbar, lada, kunyit, gula, ayam. Masak dengan api sedang sampai mendidih. Setelah mendidih, tutup panci, kecilkan api, masak 30 menit. Jangan buka tutup panci. Setelah 30 menit buka tutup panci. Kemudian tutup lagi, masak lagi 15 menit. Jangan lupa, masaknya pakai api yg kecil, supaya airnya tak cepat habis karena dimasaknya hampir 45 menit.
1. Setelah 45 menit, goreng dng minyak panas. Siap sajikan.




Demikianlah cara membuat ayam goreng kalasan yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan teruji, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
