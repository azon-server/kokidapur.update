---
description: "Resep : Ayam Rica-Rica Jawa Teruji"
title: "Resep : Ayam Rica-Rica Jawa Teruji"
slug: 115-resep-ayam-rica-rica-jawa-teruji
date: 2020-11-23T22:51:37.893Z
image: https://img-global.cpcdn.com/recipes/24ba4bdceb626eca/751x532cq70/ayam-rica-rica-jawa-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/24ba4bdceb626eca/751x532cq70/ayam-rica-rica-jawa-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/24ba4bdceb626eca/751x532cq70/ayam-rica-rica-jawa-foto-resep-utama.jpg
author: Jeffrey Ferguson
ratingvalue: 4.6
reviewcount: 33619
recipeingredient:
- "1 ekor ayam kampung ukuran sedang potongpotong"
- "Secukupnya air"
- "2 sdm santan instan saya skip"
- "5 sdm kecap manis"
- "1/2 sdt lada bubuk"
- "1 sdt garam atau sesuai selera"
- "1 sdt kaldu jamur atau sesuai selera"
- " Bumbu Halus "
- "15 siung bawang merah"
- "7 siung bawang putih"
- "5 butir kemiri goreng"
- "3 cm jahe"
- "2 cm kunyit"
- "4 cm kencur"
- "3 buah cabe merah"
- "Secukupnya cabe rawit kalau suka pedas"
- "Secukupnya minyak goreng untuk menghaluskan bumbu"
- " Bumbu Cemplung "
- "1 lembar daun salam"
- "5 lembar daun jeruk buang tulang daunnya"
- "3 batang serai geprek"
- "1 jempol laos geprek"
- "1/2 sdm gula merah"
recipeinstructions:
- "Haluskan bumbu halus di food chopper/processor"
- "Tumis bumbu halus dan bumbu cemplung hingga wangi dan matang"
- "Masukkan lada bubuk"
- "Masukkan kecap manis disekeliling minyak bumbu. Tunggu sampai kecap berbuih. Aduk rata"
- "Masukkan ayam. Aduk hingga rata terbalut bumbu"
- "Masukkan air, garam, santan jika pakai. Aduk rata. Kecilkan api. Masak hingga air menyusut dan bumbu meresap. Terakhir masukkan kaldu jamur. Koreksi rasa"
- "Angkat dan hidangkan bisa dengan taburan bawang goreng"
categories:
- Recipe
tags:
- ayam
- ricarica
- jawa

katakunci: ayam ricarica jawa 
nutrition: 161 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT54M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica-Rica Jawa](https://img-global.cpcdn.com/recipes/24ba4bdceb626eca/751x532cq70/ayam-rica-rica-jawa-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan renyah. Ciri khas masakan Indonesia ayam rica-rica jawa yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kehangatan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam Rica-Rica Jawa untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang dapat anda buat salah satunya ayam rica-rica jawa yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica-rica jawa tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Jawa yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 23 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Jawa:

1. Diperlukan 1 ekor ayam kampung ukuran sedang, potong-potong
1. Dibutuhkan Secukupnya air
1. Harus ada 2 sdm santan instan (saya skip)
1. Siapkan 5 sdm kecap manis
1. Siapkan 1/2 sdt lada bubuk
1. Siapkan 1 sdt garam (atau sesuai selera)
1. Diperlukan 1 sdt kaldu jamur (atau sesuai selera)
1. Jangan lupa  Bumbu Halus :
1. Tambah 15 siung bawang merah
1. Harus ada 7 siung bawang putih
1. Tambah 5 butir kemiri, goreng
1. Tambah 3 cm jahe
1. Jangan lupa 2 cm kunyit
1. Tambah 4 cm kencur
1. Dibutuhkan 3 buah cabe merah
1. Jangan lupa Secukupnya cabe rawit (kalau suka pedas)
1. Siapkan Secukupnya minyak goreng untuk menghaluskan bumbu
1. Tambah  Bumbu Cemplung :
1. Tambah 1 lembar daun salam
1. Jangan lupa 5 lembar daun jeruk, buang tulang daunnya
1. Harap siapkan 3 batang serai, geprek
1. Jangan lupa 1 jempol laos, geprek
1. Tambah 1/2 sdm gula merah




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica Jawa:

1. Haluskan bumbu halus di food chopper/processor
1. Tumis bumbu halus dan bumbu cemplung hingga wangi dan matang
1. Masukkan lada bubuk
1. Masukkan kecap manis disekeliling minyak bumbu. Tunggu sampai kecap berbuih. Aduk rata
1. Masukkan ayam. Aduk hingga rata terbalut bumbu
1. Masukkan air, garam, santan jika pakai. Aduk rata. Kecilkan api. Masak hingga air menyusut dan bumbu meresap. Terakhir masukkan kaldu jamur. Koreksi rasa
1. Angkat dan hidangkan bisa dengan taburan bawang goreng




Demikianlah cara membuat ayam rica-rica jawa yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
