---
description: "Cara singkat untuk membuat Ayam Rica Kemangi Teruji"
title: "Cara singkat untuk membuat Ayam Rica Kemangi Teruji"
slug: 30-cara-singkat-untuk-membuat-ayam-rica-kemangi-teruji
date: 2021-01-13T11:36:26.953Z
image: https://img-global.cpcdn.com/recipes/917ddee9ca5aeb2f/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/917ddee9ca5aeb2f/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/917ddee9ca5aeb2f/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Millie Poole
ratingvalue: 4.9
reviewcount: 19413
recipeingredient:
- "2 potong ayam bagian dada saja"
- "Secukupnya daun kemangi"
- " Cabe rawit 5 buah potongpotong jadi 2 bagian saja"
- "3 cm jahe geprek"
- "3 cm lengkuas geprek"
- "1 gelas air matang"
- "Secukupnya merica bubuk gula pasir garam sesuai selera"
- " Bumbu halus uleg"
- "3 buah cabe keriting merah uleg kasar"
- "1 buah cabe merah besar uleg kasar"
- "5 siung bawang merah"
- "4 siung bawang putih"
recipeinstructions:
- "Potong ayam agak kecil kecil lalu rebus dg 1 bawang putih geprek dan 1/2 sdt garam, rebus sebentar lalu sisihkan"
- "Tumis bumbu halus dan cabe rawit sampai harum, tambah 1 gelas air matang, aduk rata"
- "Masukkan ayam yg sudah direbus tadi, aduk hingga tercampur bumbu, tambahkan merica, gula dan garam secukupnya (sesuai selera)"
- "Cek rasa apakah sudah pas atau belum, kalau belum bs tambah lagi gula/garam, jika sudah pas masukkan kemangi"
- "Tunggu hingga kemangi layu dan kuah menyusut, jika sudah matikan api lalu sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 105 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/917ddee9ca5aeb2f/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita jaga karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica kemangi yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Nusantara



Keharmonisan keluarga bisa ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica Kemangi untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang dapat anda contoh salah satunya ayam rica kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Dibutuhkan 2 potong ayam bagian dada saja
1. Diperlukan Secukupnya daun kemangi
1. Harus ada  Cabe rawit 5 buah potong-potong jadi 2 bagian saja
1. Jangan lupa 3 cm jahe geprek
1. Tambah 3 cm lengkuas geprek
1. Harap siapkan 1 gelas air matang
1. Jangan lupa Secukupnya merica bubuk, gula pasir, garam (sesuai selera)
1. Dibutuhkan  Bumbu halus uleg
1. Harap siapkan 3 buah cabe keriting merah uleg kasar
1. Jangan lupa 1 buah cabe merah besar uleg kasar
1. Tambah 5 siung bawang merah
1. Jangan lupa 4 siung bawang putih




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Kemangi:

1. Potong ayam agak kecil kecil lalu rebus dg 1 bawang putih geprek dan 1/2 sdt garam, rebus sebentar lalu sisihkan
1. Tumis bumbu halus dan cabe rawit sampai harum, tambah 1 gelas air matang, aduk rata
1. Masukkan ayam yg sudah direbus tadi, aduk hingga tercampur bumbu, tambahkan merica, gula dan garam secukupnya (sesuai selera)
1. Cek rasa apakah sudah pas atau belum, kalau belum bs tambah lagi gula/garam, jika sudah pas masukkan kemangi
1. Tunggu hingga kemangi layu dan kuah menyusut, jika sudah matikan api lalu sajikan




Demikianlah cara membuat ayam rica kemangi yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
