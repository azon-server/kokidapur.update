---
description: "Bagaimana untuk membuat Ayam Rica Kemangi (resep mertua ❤) Sempurna"
title: "Bagaimana untuk membuat Ayam Rica Kemangi (resep mertua ❤) Sempurna"
slug: 33-bagaimana-untuk-membuat-ayam-rica-kemangi-resep-mertua-sempurna
date: 2020-09-29T20:01:31.276Z
image: https://img-global.cpcdn.com/recipes/8bf3c17925fe646d/751x532cq70/ayam-rica-kemangi-resep-mertua-❤-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8bf3c17925fe646d/751x532cq70/ayam-rica-kemangi-resep-mertua-❤-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8bf3c17925fe646d/751x532cq70/ayam-rica-kemangi-resep-mertua-❤-foto-resep-utama.jpg
author: Bobby Reese
ratingvalue: 4.9
reviewcount: 48710
recipeingredient:
- "300 gr ayam"
- " Daun kemangi"
- " Daun jeruk"
- " Bumbu Blender"
- "4 bawang merah"
- "6 bawang putih"
- "3 cabe rawit merah"
- "4 cabe keriting merah"
- "1 butir kemiri"
- "jempol Jahe sekuku"
- "jempol Kunyit sekuku"
- "1/2 batang serai"
recipeinstructions:
- "Goreng ayam sebentar (kata mertua ku, kalo ayam kampung enaknya ga ush goreng dulu, tapi kalo ayam biasa enaknya digoreng dulu sebentar) setelah digoreng tiriskan."
- "Cincang daun jeruk lalu sisihkan"
- "Blender semua bumbu. Lalu tumis sebentar bumbunya dan beri air. Masukan garam gula merica dan totole. Koreksi rasa. Setelah rasa pas, masukan ayamnya lalu masak sampai air berkurang. Lalu masukan daun kemangi. Dan taburkan daun jeruk cincang diatasnya aduk2 sebentar di atas api. Dan ayam rica-rica siap disajikan 😊"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 129 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica Kemangi (resep mertua ❤)](https://img-global.cpcdn.com/recipes/8bf3c17925fe646d/751x532cq70/ayam-rica-kemangi-resep-mertua-❤-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau renyah. Ciri makanan Indonesia ayam rica kemangi (resep mertua ❤) yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan keluarga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica Kemangi (resep mertua ❤) untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang bisa anda praktekkan salah satunya ayam rica kemangi (resep mertua ❤) yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica kemangi (resep mertua ❤) tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi (resep mertua ❤) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi (resep mertua ❤):

1. Harus ada 300 gr ayam
1. Harap siapkan  Daun kemangi
1. Harap siapkan  Daun jeruk
1. Dibutuhkan  Bumbu Blender
1. Jangan lupa 4 bawang merah
1. Harus ada 6 bawang putih
1. Diperlukan 3 cabe rawit merah
1. Jangan lupa 4 cabe keriting merah
1. Harus ada 1 butir kemiri
1. Diperlukan jempol Jahe sekuku
1. Diperlukan jempol Kunyit sekuku
1. Jangan lupa 1/2 batang serai




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Kemangi (resep mertua ❤):

1. Goreng ayam sebentar (kata mertua ku, kalo ayam kampung enaknya ga ush goreng dulu, tapi kalo ayam biasa enaknya digoreng dulu sebentar) setelah digoreng tiriskan.
1. Cincang daun jeruk lalu sisihkan
1. Blender semua bumbu. Lalu tumis sebentar bumbunya dan beri air. Masukan garam gula merica dan totole. Koreksi rasa. Setelah rasa pas, masukan ayamnya lalu masak sampai air berkurang. Lalu masukan daun kemangi. Dan taburkan daun jeruk cincang diatasnya aduk2 sebentar di atas api. Dan ayam rica-rica siap disajikan 😊




Demikianlah cara membuat ayam rica kemangi (resep mertua ❤) yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan terbukti, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
