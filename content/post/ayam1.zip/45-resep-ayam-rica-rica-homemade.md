---
description: "Resep : Ayam Rica-rica Homemade"
title: "Resep : Ayam Rica-rica Homemade"
slug: 45-resep-ayam-rica-rica-homemade
date: 2020-12-11T23:53:07.663Z
image: https://img-global.cpcdn.com/recipes/84c3ae4201c78fdd/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/84c3ae4201c78fdd/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/84c3ae4201c78fdd/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Isabel Jacobs
ratingvalue: 5
reviewcount: 8681
recipeingredient:
- " Bahan Utama"
- "1/2 ekor ayam"
- " Jeruk nipislemon"
- "secukupnya Garam"
- " Bumbu Halus"
- "3 siung bawang merah"
- "2 siung bawang putih"
- "1 ruas jari jahe"
- "3 buah kemiri"
- "5 buah cabe keriting"
- "7 buah cabe rawit"
- " Aromatic"
- "1 batang sereh"
- "1 lembar daun salam"
- "3 lembar daun jeruk"
- " Lainnya"
- "1 sdt Kunyit bubuk"
- "Sesuai selera Garam"
- "1 sdt Gula pasir"
- "1 ruas jari gula merah"
- "1 sdt Kaldu Jamur"
- "300 mL air"
- "3 sdm Minyak goreng untuk menumis bumbu"
recipeinstructions:
- "Potong-potong ayam sesuai selera kemudian beri perasan jeruk nipis atau lemon serta digarami secukupnya. Aduk sampai merata dan diamkan sambil menyiapkan bumbu-bumbu."
- "Haluskan bumbu halus (kalau saya lebih suka pke chopper aja supaya masih ada teksturnya. Kemudian tumis dan masukan sereh, daun jeruk dan daun salam serta kunyit bubuk. Aduk rata hingga wangi dan matang."
- "Setelah bumbu matang, masukkan ayam dan aduk-aduk hingga bumbu tercampur rata. Beri garam dan gula pasir."
- "Setelah daging ayam terlihat memutih, tambahkan 300 mL air dan masak hingga mendidih. Jika sudah mendidih, tambahkan gula merah dan kaldu jamur. Sesekali diaduk hingga airnya asat. Jangan lupa untuk koreksi rasa"
- "Jika air sudah asat siap untuk dihidangkan. Selamat memasak. Terima kasih"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 186 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT41M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica-rica](https://img-global.cpcdn.com/recipes/84c3ae4201c78fdd/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang patut kita lestarikan karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica-rica yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan keistimewahan yang merupakan keragaman Indonesia

Keharmonisan keluarga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica-rica untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi makanan yang dapat anda buat salah satunya ayam rica-rica yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 23 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica:

1. Harus ada  Bahan Utama
1. Harap siapkan 1/2 ekor ayam
1. Jangan lupa  Jeruk nipis/lemon
1. Jangan lupa secukupnya Garam
1. Jangan lupa  Bumbu Halus
1. Dibutuhkan 3 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Harap siapkan 1 ruas jari jahe
1. Diperlukan 3 buah kemiri
1. Tambah 5 buah cabe keriting
1. Tambah 7 buah cabe rawit
1. Dibutuhkan  Aromatic
1. Harap siapkan 1 batang sereh
1. Harap siapkan 1 lembar daun salam
1. Siapkan 3 lembar daun jeruk
1. Harus ada  Lainnya
1. Dibutuhkan 1 sdt Kunyit bubuk
1. Tambah Sesuai selera Garam
1. Diperlukan 1 sdt Gula pasir
1. Tambah 1 ruas jari gula merah
1. Harap siapkan 1 sdt Kaldu Jamur
1. Tambah 300 mL air
1. Diperlukan 3 sdm Minyak goreng untuk menumis bumbu




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-rica:

1. Potong-potong ayam sesuai selera kemudian beri perasan jeruk nipis atau lemon serta digarami secukupnya. Aduk sampai merata dan diamkan sambil menyiapkan bumbu-bumbu.
1. Haluskan bumbu halus (kalau saya lebih suka pke chopper aja supaya masih ada teksturnya. Kemudian tumis dan masukan sereh, daun jeruk dan daun salam serta kunyit bubuk. Aduk rata hingga wangi dan matang.
1. Setelah bumbu matang, masukkan ayam dan aduk-aduk hingga bumbu tercampur rata. Beri garam dan gula pasir.
1. Setelah daging ayam terlihat memutih, tambahkan 300 mL air dan masak hingga mendidih. Jika sudah mendidih, tambahkan gula merah dan kaldu jamur. Sesekali diaduk hingga airnya asat. Jangan lupa untuk koreksi rasa
1. Jika air sudah asat siap untuk dihidangkan. Selamat memasak. Terima kasih




Demikianlah cara membuat ayam rica-rica yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat gampang dan teruji, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
