---
description: "Resep : Ayam Rica diet tanpa minyak (210 kkal/porsi) teraktual"
title: "Resep : Ayam Rica diet tanpa minyak (210 kkal/porsi) teraktual"
slug: 162-resep-ayam-rica-diet-tanpa-minyak-210-kkal-porsi-teraktual
date: 2020-12-07T14:10:22.584Z
image: https://img-global.cpcdn.com/recipes/ab2650ede9034ded/751x532cq70/ayam-rica-diet-tanpa-minyak-210-kkalporsi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ab2650ede9034ded/751x532cq70/ayam-rica-diet-tanpa-minyak-210-kkalporsi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ab2650ede9034ded/751x532cq70/ayam-rica-diet-tanpa-minyak-210-kkalporsi-foto-resep-utama.jpg
author: Vernon Moreno
ratingvalue: 4.7
reviewcount: 21023
recipeingredient:
- "200 gram ayam"
- "1 batang sereh geprek"
- "1 cm jahe geprek"
- "1 cm lengkuas geprek"
- "1 lembar daun salam"
- "1 lembar daun jeruk"
- "secukupnya Kemangi"
- "100 ml air"
- "secukupnya Garam kaldu jamur"
- " Bumbu Halus"
- "2 bawang merah"
- "1 bawang putih"
- "1/2 butir kemiri"
- "1 cm kunyit"
- "sesuai selera Cabe merah keriting"
- "sesuai selera Cabe rawit"
recipeinstructions:
- "Siap kan bahan2 dan bumbu halusnya"
- "Didihkan 100 ml air diatas teflon anti lengket (ini penting karena kita menumis nggak pake minyak),, lalu tumis bumbu halus, jahe, lengkuas, sereh, daun salam dan daun jeruk dengan air hingga bau langu nya hilang, harum dan air menyusut"
- "Setelah tumisan menjadi lebih harum dan airnya berkurang, masukkan ayam, tambahkan garam dan kaldu jamur..tumis2 hingga ayam matang (tidak saya tambah air..karena ayam juga akan mengeluarkan air)"
- "Jika ayam sudah matang, cicipi rasa..keluarkan sereh, jahe, lengkuas, daun salam dan daun jeruk (optional yah..supaya lebih mudah aja makannya..hehe) lalu masukkan daun kemangi, aduk2 dan sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- diet

katakunci: ayam rica diet 
nutrition: 112 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica diet tanpa minyak (210 kkal/porsi)](https://img-global.cpcdn.com/recipes/ab2650ede9034ded/751x532cq70/ayam-rica-diet-tanpa-minyak-210-kkalporsi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang patut kita lestarikan karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica diet tanpa minyak (210 kkal/porsi) yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan keistimewahan yang merupakan keragaman Kita



Kedekatan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam Rica diet tanpa minyak (210 kkal/porsi) untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis makanan yang dapat anda buat salah satunya ayam rica diet tanpa minyak (210 kkal/porsi) yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica diet tanpa minyak (210 kkal/porsi) tanpa harus bersusah payah.
Seperti resep Ayam Rica diet tanpa minyak (210 kkal/porsi) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica diet tanpa minyak (210 kkal/porsi):

1. Harap siapkan 200 gram ayam
1. Diperlukan 1 batang sereh geprek
1. Siapkan 1 cm jahe geprek
1. Diperlukan 1 cm lengkuas geprek
1. Jangan lupa 1 lembar daun salam
1. Jangan lupa 1 lembar daun jeruk
1. Jangan lupa secukupnya Kemangi
1. Dibutuhkan 100 ml air
1. Harus ada secukupnya Garam, kaldu jamur
1. Siapkan  Bumbu Halus
1. Dibutuhkan 2 bawang merah
1. Harap siapkan 1 bawang putih
1. Siapkan 1/2 butir kemiri
1. Siapkan 1 cm kunyit
1. Jangan lupa sesuai selera Cabe merah keriting
1. Jangan lupa sesuai selera Cabe rawit




<!--inarticleads2-->

##### Cara membuat  Ayam Rica diet tanpa minyak (210 kkal/porsi):

1. Siap kan bahan2 dan bumbu halusnya
1. Didihkan 100 ml air diatas teflon anti lengket (ini penting karena kita menumis nggak pake minyak),, lalu tumis bumbu halus, jahe, lengkuas, sereh, daun salam dan daun jeruk dengan air hingga bau langu nya hilang, harum dan air menyusut
1. Setelah tumisan menjadi lebih harum dan airnya berkurang, masukkan ayam, tambahkan garam dan kaldu jamur..tumis2 hingga ayam matang (tidak saya tambah air..karena ayam juga akan mengeluarkan air)
1. Jika ayam sudah matang, cicipi rasa..keluarkan sereh, jahe, lengkuas, daun salam dan daun jeruk (optional yah..supaya lebih mudah aja makannya..hehe) lalu masukkan daun kemangi, aduk2 dan sajikan




Demikianlah cara membuat ayam rica diet tanpa minyak (210 kkal/porsi) yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan teruji, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
