---
description: "Step-by-Step untuk membuat Ayam Goreng Lengkuas minggu ini"
title: "Step-by-Step untuk membuat Ayam Goreng Lengkuas minggu ini"
slug: 381-step-by-step-untuk-membuat-ayam-goreng-lengkuas-minggu-ini
date: 2020-08-14T22:02:47.457Z
image: https://img-global.cpcdn.com/recipes/efa643597c022009/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/efa643597c022009/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/efa643597c022009/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Cora Terry
ratingvalue: 4.4
reviewcount: 47291
recipeingredient:
- "1 ekor ayam kampung"
- "3 laos besar parut"
- "2 batang serai"
- "4 daun salam"
- "4 daun jeruk"
- "600 ml air"
- "Secukupnya garam"
- "Secukupnya penyedap"
- "Secukupnya gula"
- " Bumbu Halus"
- "2 sdm ketumbar"
- "1 sdt merica"
- "6 siung bawang putih"
- "4 butir kemiri"
- "2 ruas jahe"
- "2 ruas kunyit"
recipeinstructions:
- "Bersihkan ayam, siapkan wajan beri sdikit minyak tumis bumbu halus, laos, kemudian masukan daun2 dan serai, tunggu hingga harum kemudian masukan air masukan ayam beri garam dan penyedap.. tunggu hingga susut sesekali di aduk.."
- "Di wajan lain, panaskan minyak. Goreng ayam, goreng nya sampe ayamnya kerendem minyak ya biar mateng nya merata dan ga lengket di wajan. Kalo udah ke coklatan angkat dan sajikan.."
categories:
- Recipe
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 139 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Goreng Lengkuas](https://img-global.cpcdn.com/recipes/efa643597c022009/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga empuk. Karasteristik makanan Indonesia ayam goreng lengkuas yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga bisa didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Goreng Lengkuas untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang dapat anda buat salah satunya ayam goreng lengkuas yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam goreng lengkuas tanpa harus bersusah payah.
Berikut ini resep Ayam Goreng Lengkuas yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 2 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Lengkuas:

1. Jangan lupa 1 ekor ayam kampung
1. Harus ada 3 laos besar parut
1. Dibutuhkan 2 batang serai
1. Dibutuhkan 4 daun salam
1. Siapkan 4 daun jeruk
1. Diperlukan 600 ml air
1. Tambah Secukupnya garam
1. Dibutuhkan Secukupnya penyedap
1. Jangan lupa Secukupnya gula
1. Tambah  Bumbu Halus
1. Harap siapkan 2 sdm ketumbar
1. Harap siapkan 1 sdt merica
1. Harap siapkan 6 siung bawang putih
1. Harus ada 4 butir kemiri
1. Diperlukan 2 ruas jahe
1. Dibutuhkan 2 ruas kunyit




<!--inarticleads2-->

##### Langkah membuat  Ayam Goreng Lengkuas:

1. Bersihkan ayam, siapkan wajan beri sdikit minyak tumis bumbu halus, laos, kemudian masukan daun2 dan serai, tunggu hingga harum kemudian masukan air masukan ayam beri garam dan penyedap.. tunggu hingga susut sesekali di aduk..
1. Di wajan lain, panaskan minyak. Goreng ayam, goreng nya sampe ayamnya kerendem minyak ya biar mateng nya merata dan ga lengket di wajan. Kalo udah ke coklatan angkat dan sajikan..




Demikianlah cara membuat ayam goreng lengkuas yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
