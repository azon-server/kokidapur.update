---
description: "Resep : Ayam rica rica teraktual"
title: "Resep : Ayam rica rica teraktual"
slug: 226-resep-ayam-rica-rica-teraktual
date: 2020-12-21T04:26:30.725Z
image: https://img-global.cpcdn.com/recipes/4b765af62f6a7635/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4b765af62f6a7635/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4b765af62f6a7635/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Hattie Turner
ratingvalue: 4.4
reviewcount: 15762
recipeingredient:
- "1/2 kg ayam"
- "3 buah cabe merah besar buang bijinya"
- "5 buah cabe keriting buang bijinya"
- "5 cabe rawit"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "4 buah kemiri sangrai"
- "secukupnya Merica"
- "1/2 sdt gula pasirgaram secukupya"
- "3 sdt santan kara"
- "2 serai 1 ruas jahe 3 daun jeruk"
- " Air asem  penyedap rasa"
- " Cabe hijau potong serong"
recipeinstructions:
- "Ayam potong kecil kasih air jeruk diamkan sebentar baru cuci bersih"
- "Gongso ayam sebentar agak setengah masak angkat tiriskan"
- "Ulek bawang merah.bawang putih jahe.kemiri sangrai tambahkan cabe merah besar.cabe keriting dan cabe rawit masukkan gula dan garam ulek sampai halus"
- "Tumis bumbu sampai harum masukkan ayam serai daun jeruk tambahkan gula merah dan santan tambahkan air secukupnya"
- "Tambahkan penyedap rasa dan caba hijau"
- "Angkat.siap di sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 163 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica rica](https://img-global.cpcdn.com/recipes/4b765af62f6a7635/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga enak. Ciri khas kuliner Indonesia ayam rica rica yang penuh dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan keluarga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Ayam rica rica untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang dapat anda coba salah satunya ayam rica rica yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam rica rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica:

1. Harap siapkan 1/2 kg ayam
1. Jangan lupa 3 buah cabe merah besar buang bijinya
1. Diperlukan 5 buah cabe keriting buang bijinya
1. Diperlukan 5 cabe rawit
1. Tambah 10 siung bawang merah
1. Siapkan 5 siung bawang putih
1. Harap siapkan 4 buah kemiri sangrai
1. Siapkan secukupnya Merica
1. Harap siapkan 1/2 sdt gula pasir/garam secukupya
1. Harap siapkan 3 sdt santan kara
1. Jangan lupa 2 serai. 1 ruas jahe 3 daun jeruk
1. Harus ada  Air asem / penyedap rasa
1. Harus ada  Cabe hijau potong serong




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica rica:

1. Ayam potong kecil kasih air jeruk diamkan sebentar baru cuci bersih
1. Gongso ayam sebentar agak setengah masak angkat tiriskan
1. Ulek bawang merah.bawang putih jahe.kemiri sangrai tambahkan cabe merah besar.cabe keriting dan cabe rawit masukkan gula dan garam ulek sampai halus
1. Tumis bumbu sampai harum masukkan ayam serai daun jeruk tambahkan gula merah dan santan tambahkan air secukupnya
1. Tambahkan penyedap rasa dan caba hijau
1. Angkat.siap di sajikan




Demikianlah cara membuat ayam rica rica yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
