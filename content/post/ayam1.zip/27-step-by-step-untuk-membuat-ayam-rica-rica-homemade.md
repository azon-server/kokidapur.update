---
description: "Step-by-Step untuk membuat Ayam Rica Rica Homemade"
title: "Step-by-Step untuk membuat Ayam Rica Rica Homemade"
slug: 27-step-by-step-untuk-membuat-ayam-rica-rica-homemade
date: 2020-12-11T19:22:07.363Z
image: https://img-global.cpcdn.com/recipes/0f419c45ec379c58/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0f419c45ec379c58/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0f419c45ec379c58/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Bettie McBride
ratingvalue: 4.8
reviewcount: 38812
recipeingredient:
- "1 ekor ayam"
- "3 bh bawang putih Diiris"
- "6 bh bawang merah Diiris"
- "10 lmbr daun jeruk diiris kecil2"
- "3 btg serai diiris sesuai selera boleh pnjg atau diiris kecil2"
- "1 bh daun pandan"
- "8 bh Bawang Merah Dihaluskan"
- "5 Cm Jahe dihaluskan"
- "10 bj Cabe Rawit Merah dihaluskan"
- "15 bj Cabe keriting Merah dihaluskan"
- "1 Bh Jeruk Nipis"
recipeinstructions:
- "Potong Ayam sesuai selera"
- "Tumis bawang putih terlebih dahulu yg sudah diiris sampai kecoklatan"
- "Masukan bawang merah tumis sampai wangi dan berubah warna"
- "Masukan daun jeruk,serai dan daun pandan... Tumis sampai wangi."
- "Kasih Garam 1 ½ sdt,merica,penyedap (semua sesuai selera)"
- "Masukan potongan ayam (kl aku ayamnya sudah direbus dan digoreng setengah matang biar higienis)ditumis sampai wangi"
- "Masukan bumbu yg sudah dihaluskan seperti bawang merah,jahe,cabe (kl aku pakai blender)"
- "Aduk terus sampai wangi keluar dan tutup sebentar yah... Ditutup biar wanginya sll wangi..."
- "Lalu matikan kompor"
- "Peraskan jeruk nipis 1bh"
- "Cicipi rasa dan hidangkan bersama keluargaa anda... Thanks"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 234 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/0f419c45ec379c58/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas hingga empuk. Ciri khas makanan Indonesia ayam rica rica yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kehangatan rumah tangga bisa didapat dengan cara simple. Salah satunya adalah memasak Ayam Rica Rica untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang bisa anda coba salah satunya ayam rica rica yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep ayam rica rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 11 bahan dan 11 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica:

1. Diperlukan 1 ekor ayam
1. Siapkan 3 bh bawang putih (Diiris)
1. Siapkan 6 bh bawang merah (Diiris)
1. Harus ada 10 lmbr daun jeruk (diiris kecil2)
1. Harus ada 3 btg serai (diiris sesuai selera) boleh pnjg atau diiris kecil2
1. Harus ada 1 bh daun pandan
1. Siapkan 8 bh Bawang Merah (Dihaluskan)
1. Tambah 5 Cm Jahe (dihaluskan)
1. Tambah 10 bj Cabe Rawit Merah (dihaluskan)
1. Jangan lupa 15 bj Cabe keriting Merah (dihaluskan)
1. Diperlukan 1 Bh Jeruk Nipis




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Rica:

1. Potong Ayam sesuai selera
1. Tumis bawang putih terlebih dahulu yg sudah diiris sampai kecoklatan
1. Masukan bawang merah tumis sampai wangi dan berubah warna
1. Masukan daun jeruk,serai dan daun pandan... Tumis sampai wangi.
1. Kasih Garam 1 ½ sdt,merica,penyedap (semua sesuai selera)
1. Masukan potongan ayam (kl aku ayamnya sudah direbus dan digoreng setengah matang biar higienis)ditumis sampai wangi
1. Masukan bumbu yg sudah dihaluskan seperti bawang merah,jahe,cabe (kl aku pakai blender)
1. Aduk terus sampai wangi keluar dan tutup sebentar yah... Ditutup biar wanginya sll wangi...
1. Lalu matikan kompor
1. Peraskan jeruk nipis 1bh
1. Cicipi rasa dan hidangkan bersama keluargaa anda... Thanks




Demikianlah cara membuat ayam rica rica yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
