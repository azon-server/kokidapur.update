---
description: "Resep : Ayam Rica - Rica Cepat"
title: "Resep : Ayam Rica - Rica Cepat"
slug: 153-resep-ayam-rica-rica-cepat
date: 2020-12-01T02:28:46.087Z
image: https://img-global.cpcdn.com/recipes/8f597045cc07630d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8f597045cc07630d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8f597045cc07630d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Harold Taylor
ratingvalue: 4.1
reviewcount: 32929
recipeingredient:
- "1 ekor ayam kebetulan dapet tinggal bagian paha semua"
- "1/2 bawang bombay"
- "9 cabe merah keriting"
- "5 buah cabe rawit"
- "4 bawang putih"
- "9 bawang merah"
- "1/2 sendok teh Garam"
- "1/2 sendok teh kaldu jamur"
- "1/2 sendok teh Gula"
- "1 sendok makan Saus tiram"
- "2 sendok makan kecap manis"
- "1/2 ruas jahe"
- "1/2 ruas lengkuas"
- "5 lembar daun jeruk"
- "3 buah sereh iris"
recipeinstructions:
- "Cuci bersih ayam yang sudah dipotong, karena campaign dari cookpad #masaksetiapbagian ceker ayamnya tidak aku tinggal ditukang ayam. Ikut kita rebus untuk kaldu."
- "Sambil merebus ayam sebentar, blender bumbu cabe merah, 2 cabe rawit, bawang merah, bawah putih. Blender kasar ya moms. Oia moms ayamnya bisa moms goreng terlebih dahulu, atau tidak digoreng juga tidak apa-apa. Diresep ini aku goreng ayamnya setengah matang."
- "Setelah semua siap, tumis bumbu yang sudah diblender sampai harum kasih sedikit air, kemudian masukan daun jeruk, salam, lengkuas, jahe dan sereh yg diris tumis sampai harum. Kemudian masukan ayam yang sudah digoreng setengah matang."
- "Tambahakan air sedikit aja ya moms, kemudian masukan garam, gula, kaldu jamur, saus tiram dan kecap manis. Aduk sampai merata sambil diicipi. Kemudian iris 2 buah cabe rawit. Taburi diatasnya. Ayam rica-rica siap disantap dengan nasi hangat"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 292 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica - Rica](https://img-global.cpcdn.com/recipes/8f597045cc07630d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga enak. Karasteristik kuliner Nusantara ayam rica - rica yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan rumah tangga dapat diperoleh dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica - Rica untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang bisa anda coba salah satunya ayam rica - rica yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica - rica tanpa harus bersusah payah.
Seperti resep Ayam Rica - Rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica - Rica:

1. Tambah 1 ekor ayam, kebetulan dapet tinggal bagian paha semua
1. Harus ada 1/2 bawang bombay
1. Harus ada 9 cabe merah keriting
1. Dibutuhkan 5 buah cabe rawit
1. Harus ada 4 bawang putih
1. Jangan lupa 9 bawang merah
1. Harus ada 1/2 sendok teh Garam
1. Diperlukan 1/2 sendok teh kaldu jamur
1. Harus ada 1/2 sendok teh Gula
1. Tambah 1 sendok makan Saus tiram
1. Dibutuhkan 2 sendok makan kecap manis
1. Jangan lupa 1/2 ruas jahe
1. Dibutuhkan 1/2 ruas lengkuas
1. Dibutuhkan 5 lembar daun jeruk
1. Harap siapkan 3 buah sereh iris




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica - Rica:

1. Cuci bersih ayam yang sudah dipotong, karena campaign dari cookpad #masaksetiapbagian ceker ayamnya tidak aku tinggal ditukang ayam. Ikut kita rebus untuk kaldu.
1. Sambil merebus ayam sebentar, blender bumbu cabe merah, 2 cabe rawit, bawang merah, bawah putih. Blender kasar ya moms. Oia moms ayamnya bisa moms goreng terlebih dahulu, atau tidak digoreng juga tidak apa-apa. Diresep ini aku goreng ayamnya setengah matang.
1. Setelah semua siap, tumis bumbu yang sudah diblender sampai harum kasih sedikit air, kemudian masukan daun jeruk, salam, lengkuas, jahe dan sereh yg diris tumis sampai harum. Kemudian masukan ayam yang sudah digoreng setengah matang.
1. Tambahakan air sedikit aja ya moms, kemudian masukan garam, gula, kaldu jamur, saus tiram dan kecap manis. Aduk sampai merata sambil diicipi. Kemudian iris 2 buah cabe rawit. Taburi diatasnya. Ayam rica-rica siap disantap dengan nasi hangat




Demikianlah cara membuat ayam rica - rica yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
