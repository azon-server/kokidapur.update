---
description: "Bagaimana membuat Ayam Rica Rica teraktual"
title: "Bagaimana membuat Ayam Rica Rica teraktual"
slug: 238-bagaimana-membuat-ayam-rica-rica-teraktual
date: 2020-12-18T10:27:30.520Z
image: https://img-global.cpcdn.com/recipes/edad9686e3646f43/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/edad9686e3646f43/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/edad9686e3646f43/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Adeline Bowman
ratingvalue: 4.7
reviewcount: 8681
recipeingredient:
- "1/2 ekor ayam"
- " Jeruk nipis"
- " Kunyit bubuk  kunyit digiling halus"
- " Bumbu halus"
- "1 ruas jahe"
- "2 butir kemiri"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "1 buah tomat ukuran kecil"
- "5 buah cabai rawit"
- "5 sdm cabai merah giling kasar"
- " Bumbu kering"
- "3 lembar daun salam"
- "4 lembar daun jeruk"
- "1 batang serai digeprek"
- " Bumbu tambahan"
- " Garam"
- " Gula"
- "1 batang daun bawang diiris kasar"
recipeinstructions:
- "Lumuri ayam dengan garam, perasan jeruk nipis dan kunyit. Diamkan sebentar, lalu digoreng (boleh goreng hingga matang kecoklatan atau goreng setengah matang)"
- "Uleg kasar semua bumbu halus kecuali cabai merah. (Bisa dengan blender, blender hingga halus kemiri dan jahe, baru masukkan sisa bumbu halus lainnya dan diblender sebentar jangan sampai terlalu halus)"
- "Tumis semua bumbu yang sudah diuleg dan masukkan cabai merah"
- "Masukkan bumbu kering. Tumis hingga semua bumbu matang."
- "Masukkan ayam yg sudah digoreng tadi kedalam tumisan bumbu. Aduk hingga merata. Kemudian tambahkan air sedikit (kira kira ayam setengah terendam)"
- "Masukkan garam gula (coba 1sdt dulu). Masak hingga air surut, koreksi rasa."
- "Masukkan potongan daun bawang (bisa juga ganti dengan seikat daun kemangi). Aduk aduk sebentar, matikan api. Sajikan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 271 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT43M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/edad9686e3646f43/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica rica yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan keistimewahan yang merupakan keragaman Indonesia



Kehangatan keluarga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica Rica untuk orang di rumah. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang dapat anda praktekkan salah satunya ayam rica rica yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 19 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica:

1. Jangan lupa 1/2 ekor ayam
1. Dibutuhkan  Jeruk nipis
1. Harus ada  Kunyit bubuk / kunyit digiling halus
1. Siapkan  Bumbu halus
1. Tambah 1 ruas jahe
1. Diperlukan 2 butir kemiri
1. Dibutuhkan 5 siung bawang merah
1. Harus ada 3 siung bawang putih
1. Jangan lupa 1 buah tomat ukuran kecil
1. Harus ada 5 buah cabai rawit
1. Jangan lupa 5 sdm cabai merah giling kasar
1. Jangan lupa  Bumbu kering
1. Jangan lupa 3 lembar daun salam
1. Diperlukan 4 lembar daun jeruk
1. Dibutuhkan 1 batang serai digeprek
1. Jangan lupa  Bumbu tambahan
1. Diperlukan  Garam
1. Dibutuhkan  Gula
1. Diperlukan 1 batang daun bawang diiris kasar




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Rica:

1. Lumuri ayam dengan garam, perasan jeruk nipis dan kunyit. Diamkan sebentar, lalu digoreng (boleh goreng hingga matang kecoklatan atau goreng setengah matang)
1. Uleg kasar semua bumbu halus kecuali cabai merah. (Bisa dengan blender, blender hingga halus kemiri dan jahe, baru masukkan sisa bumbu halus lainnya dan diblender sebentar jangan sampai terlalu halus)
1. Tumis semua bumbu yang sudah diuleg dan masukkan cabai merah
1. Masukkan bumbu kering. Tumis hingga semua bumbu matang.
1. Masukkan ayam yg sudah digoreng tadi kedalam tumisan bumbu. Aduk hingga merata. Kemudian tambahkan air sedikit (kira kira ayam setengah terendam)
1. Masukkan garam gula (coba 1sdt dulu). Masak hingga air surut, koreksi rasa.
1. Masukkan potongan daun bawang (bisa juga ganti dengan seikat daun kemangi). Aduk aduk sebentar, matikan api. Sajikan.




Demikianlah cara membuat ayam rica rica yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan teruji, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
