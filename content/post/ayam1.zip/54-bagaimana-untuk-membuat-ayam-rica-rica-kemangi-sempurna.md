---
description: "Bagaimana untuk membuat Ayam Rica-Rica Kemangi Sempurna"
title: "Bagaimana untuk membuat Ayam Rica-Rica Kemangi Sempurna"
slug: 54-bagaimana-untuk-membuat-ayam-rica-rica-kemangi-sempurna
date: 2020-10-02T15:56:33.988Z
image: https://img-global.cpcdn.com/recipes/d289ac8f7d557a20/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d289ac8f7d557a20/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d289ac8f7d557a20/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Mabelle Morton
ratingvalue: 4.6
reviewcount: 12230
recipeingredient:
- "1 ekor ayam kampung"
- "2 buah jeruk nipis"
- " Bahan Bumbu"
- "6 siung bawang putih"
- "10 biji bawang merah"
- "10-15 cabe rawit selera"
- "1 ruas jahe"
- "1 ruas kunyit"
- " Lengkuas sedikit saja"
- "2 batang sereh"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- " Bahan Pelengkap"
- "3 pohon kemangi ambil daunnya saja"
- "2 batang daun bawang"
- "3 sdm minyak goreng"
- "1 sdm garam"
- "1 sdt gula"
- "1 sdm kaldu bubuk"
- "1 sdt merica"
recipeinstructions:
- "Potong ayam sesuai selera (saya potong kecil² supaya bumbu cepat meresap) lalu lumuri dgn jeruk nipis dan garam. Diamkan selama kurang lebih 15 menit."
- "Setelah ayam dicuci bersih, goreng ayam sebentar diatas teflon. Ini selera ya, tdk digoreng jg gapapa. Setelah digoreng, lalu tiriskan."
- "Blender semua bahan bumbu, kecuali sereh, daun salam, daun jeruk dan lengkuas."
- "Setelah bumbu halus, panaskan minyak goreng, masukkan bumbu halus beserta lengkuas dan batang sereh yg sudah di geprek, daun salam dan daun jeruk. Aduk sebentar sampai wangi. Lalu tambahkan sedikit air."
- "Setelah itu, masukkan ayam. Aduk sampai bumbu tercampur rata. Diamkan sebentar supaya bumbu meresap dan air mulai menyusut."
- "Setelah air menyusut dan ayam empuk, masukkan kemangi dan daun bawang. Aduk sebentar lalu matikan api."
- "Ayam rica-rica siap dihidangkan bersama nasi hangat dan lalapan mentimun/selada."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 250 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/d289ac8f7d557a20/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga renyah. Ciri khas masakan Indonesia ayam rica-rica kemangi yang penuh dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica-Rica Kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang dapat anda contoh salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 20 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica Kemangi:

1. Jangan lupa 1 ekor ayam kampung
1. Jangan lupa 2 buah jeruk nipis
1. Dibutuhkan  Bahan Bumbu
1. Tambah 6 siung bawang putih
1. Harap siapkan 10 biji bawang merah
1. Harap siapkan 10-15 cabe rawit (selera)
1. Siapkan 1 ruas jahe
1. Harap siapkan 1 ruas kunyit
1. Siapkan  Lengkuas sedikit saja
1. Siapkan 2 batang sereh
1. Diperlukan 2 lembar daun salam
1. Diperlukan 2 lembar daun jeruk
1. Diperlukan  Bahan Pelengkap
1. Harus ada 3 pohon kemangi, ambil daunnya saja
1. Siapkan 2 batang daun bawang
1. Siapkan 3 sdm minyak goreng
1. Jangan lupa 1 sdm garam
1. Diperlukan 1 sdt gula
1. Jangan lupa 1 sdm kaldu bubuk
1. Tambah 1 sdt merica




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica Kemangi:

1. Potong ayam sesuai selera (saya potong kecil² supaya bumbu cepat meresap) lalu lumuri dgn jeruk nipis dan garam. Diamkan selama kurang lebih 15 menit.
1. Setelah ayam dicuci bersih, goreng ayam sebentar diatas teflon. Ini selera ya, tdk digoreng jg gapapa. Setelah digoreng, lalu tiriskan.
1. Blender semua bahan bumbu, kecuali sereh, daun salam, daun jeruk dan lengkuas.
1. Setelah bumbu halus, panaskan minyak goreng, masukkan bumbu halus beserta lengkuas dan batang sereh yg sudah di geprek, daun salam dan daun jeruk. Aduk sebentar sampai wangi. Lalu tambahkan sedikit air.
1. Setelah itu, masukkan ayam. Aduk sampai bumbu tercampur rata. Diamkan sebentar supaya bumbu meresap dan air mulai menyusut.
1. Setelah air menyusut dan ayam empuk, masukkan kemangi dan daun bawang. Aduk sebentar lalu matikan api.
1. Ayam rica-rica siap dihidangkan bersama nasi hangat dan lalapan mentimun/selada.




Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
