---
description: "Resep : AYAM RICA-RICA Sempurna"
title: "Resep : AYAM RICA-RICA Sempurna"
slug: 50-resep-ayam-rica-rica-sempurna
date: 2020-10-08T10:28:42.461Z
image: https://img-global.cpcdn.com/recipes/1e3b1ac545ba0caa/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1e3b1ac545ba0caa/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1e3b1ac545ba0caa/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Estella Barnes
ratingvalue: 4.6
reviewcount: 16167
recipeingredient:
- "1 ekor ayam berat 13kg"
- " Bumbu halus"
- "7 biji cabe rawit"
- "5 siung bawang merah"
- "4 siung bawang putih"
- "3 biji kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
- "2 batang serai"
- "1 buah tomat ukuran sedang"
- " Pelengkap"
- " Daun bawang"
- " Daun jeruk"
- " Daun kemangi"
- "secukupnya Minyak goreng"
- "secukupnya Lada"
- "secukupnya Air asam jawa"
- "secukupnya Garamgulakaldu jamur"
- "secukupnya Air"
recipeinstructions:
- "Bersihkan ayam.. lalu rebus sebentar saja"
- "Panas kan minyak... tumis bumbu halus sampai harum"
- "Masukan ayam aduk merata biarkan sejenak sampai agak meresap bumbunya ya"
- "Lalu masukan air secukupnya"
- "Terakhir masukan air asam, daun kemangi, seledri, daun bawang dan penyedap"
- "Koreksi rasa..angkat."
- "Selamat mencoba"
- ""
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 200 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Dinner

---


![AYAM RICA-RICA](https://img-global.cpcdn.com/recipes/1e3b1ac545ba0caa/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau gurih. Ciri kuliner Indonesia ayam rica-rica yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa didapat dengan cara simple. Diantaranya adalah memasak AYAM RICA-RICA untuk orang di rumah. Momen makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang bisa anda coba salah satunya ayam rica-rica yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep AYAM RICA-RICA yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat AYAM RICA-RICA:

1. Diperlukan 1 ekor ayam berat 1,3kg
1. Harap siapkan  Bumbu halus👇
1. Siapkan 7 biji cabe rawit
1. Diperlukan 5 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Harus ada 3 biji kemiri
1. Siapkan 1 ruas jahe
1. Diperlukan 1 ruas kunyit
1. Siapkan 2 batang serai
1. Tambah 1 buah tomat ukuran sedang
1. Siapkan  Pelengkap
1. Dibutuhkan  Daun bawang
1. Diperlukan  Daun jeruk
1. Tambah  Daun kemangi
1. Jangan lupa secukupnya Minyak goreng
1. Diperlukan secukupnya Lada
1. Jangan lupa secukupnya Air asam jawa
1. Diperlukan secukupnya Garam,gula,kaldu jamur
1. Jangan lupa secukupnya Air




<!--inarticleads2-->

##### Cara membuat  AYAM RICA-RICA:

1. Bersihkan ayam.. lalu rebus sebentar saja
1. Panas kan minyak... tumis bumbu halus sampai harum
1. Masukan ayam aduk merata biarkan sejenak sampai agak meresap bumbunya ya
1. Lalu masukan air secukupnya
1. Terakhir masukan air asam, daun kemangi, seledri, daun bawang dan penyedap
1. Koreksi rasa..angkat.
1. Selamat mencoba
1. 




Demikianlah cara membuat ayam rica-rica yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
