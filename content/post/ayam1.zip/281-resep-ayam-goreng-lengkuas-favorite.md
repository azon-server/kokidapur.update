---
description: "Resep : Ayam Goreng Lengkuas Favorite"
title: "Resep : Ayam Goreng Lengkuas Favorite"
slug: 281-resep-ayam-goreng-lengkuas-favorite
date: 2020-11-17T06:03:48.115Z
image: https://img-global.cpcdn.com/recipes/6c89dd530b79288f/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6c89dd530b79288f/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6c89dd530b79288f/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Carlos Rhodes
ratingvalue: 5
reviewcount: 35035
recipeingredient:
- "1/2 kg ayam"
- "1 btg sereh"
- "2 lbr daun salam"
- "150 gr lengkuas blender parut"
- "100 ml air"
- "1 btr telur"
- " Bahan halus"
- "3 siung bawang putih"
- "2 cm kunyit"
- "2 cm jahe"
- "2 btr kemiri"
- "1 sdt ketumbar"
- "1/2 sdt merica"
- "1 sdt garam"
- "1 sdt kaldu bubuk"
recipeinstructions:
- "Blender halus semua bahan yang dibutuhkan. Lengkuasnya di blender terpisah, atau boleh juga diparut."
- "Masukkan ayam, salam, sereh ke dalam panci."
- "Masukkan bahan tadi, lengkuas dan garam kaldu bubuk."
- "Tambahkan air, aduk terus sampai air kesat."
- "Jika air sudah berkurang, tirikan lagi dengan saringan. Dinginkan."
- "Kocok telur. Masukkan ke ayam tadi. Aduk rata."
- "Pisahkan ayam dengan res2an lengkuasnya. Opsional sih. Boleh juga ga dipisahin."
- "Panaskan minyak banyak. Goreng ayam sebentar. Angkat. lakukan sampai ayam habis."
- "Setelah itu terakhir goreng res2an lengkuasnya. Aduk terus sampai warna kecoklatan."
- "Taburkan diatas ayam goreng yg tadi sudah matang."
- "Rasanya maknyossss.. apalagi ditemenin nasi anget."
categories:
- Recipe
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 252 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Goreng Lengkuas](https://img-global.cpcdn.com/recipes/6c89dd530b79288f/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam goreng lengkuas yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Kita



Kehangatan rumah tangga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Ayam Goreng Lengkuas untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang dapat anda contoh salah satunya ayam goreng lengkuas yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya saat ini kamu bisa dengan gampang menemukan resep ayam goreng lengkuas tanpa harus bersusah payah.
Berikut ini resep Ayam Goreng Lengkuas yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 11 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Lengkuas:

1. Diperlukan 1/2 kg ayam
1. Tambah 1 btg sereh
1. Jangan lupa 2 lbr daun salam
1. Harap siapkan 150 gr lengkuas (blender/ parut)
1. Tambah 100 ml air
1. Harus ada 1 btr telur
1. Diperlukan  Bahan halus:
1. Harus ada 3 siung bawang putih
1. Siapkan 2 cm kunyit
1. Siapkan 2 cm jahe
1. Diperlukan 2 btr kemiri
1. Jangan lupa 1 sdt ketumbar
1. Jangan lupa 1/2 sdt merica
1. Tambah 1 sdt garam
1. Harap siapkan 1 sdt kaldu bubuk




<!--inarticleads2-->

##### Langkah membuat  Ayam Goreng Lengkuas:

1. Blender halus semua bahan yang dibutuhkan. Lengkuasnya di blender terpisah, atau boleh juga diparut.
1. Masukkan ayam, salam, sereh ke dalam panci.
1. Masukkan bahan tadi, lengkuas dan garam kaldu bubuk.
1. Tambahkan air, aduk terus sampai air kesat.
1. Jika air sudah berkurang, tirikan lagi dengan saringan. Dinginkan.
1. Kocok telur. Masukkan ke ayam tadi. Aduk rata.
1. Pisahkan ayam dengan res2an lengkuasnya. Opsional sih. Boleh juga ga dipisahin.
1. Panaskan minyak banyak. Goreng ayam sebentar. Angkat. lakukan sampai ayam habis.
1. Setelah itu terakhir goreng res2an lengkuasnya. Aduk terus sampai warna kecoklatan.
1. Taburkan diatas ayam goreng yg tadi sudah matang.
1. Rasanya maknyossss.. apalagi ditemenin nasi anget.




Demikianlah cara membuat ayam goreng lengkuas yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan cepat, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
