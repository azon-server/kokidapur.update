---
description: "Resep : Ayam Rica Cepat"
title: "Resep : Ayam Rica Cepat"
slug: 8-resep-ayam-rica-cepat
date: 2020-11-25T09:45:15.188Z
image: https://img-global.cpcdn.com/recipes/23a8e7d21d5d74f8/751x532cq70/ayam-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/23a8e7d21d5d74f8/751x532cq70/ayam-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/23a8e7d21d5d74f8/751x532cq70/ayam-rica-foto-resep-utama.jpg
author: Kenneth Martin
ratingvalue: 4.9
reviewcount: 14275
recipeingredient:
- "300 gr ayam fillet potong dadu"
- "2 lembar daun salam"
- "1 ruas lengkuas"
- "2 sdm kecap"
- " Bumbu Halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "2 sdt garam"
- "1 sdt gula"
- "3 buah cabe rawit merah"
- "5 buah cabe merah keriting"
- "1 ruas kunyit"
recipeinstructions:
- "Tumis bumbu halus, daun salam, dan laos hingga wangi"
- "Masukkan kecap, aduk rata"
- "Masukkan ayam, aduk rata kemudian tambahkan sedikit air. Masak hingga air menyusut"
categories:
- Recipe
tags:
- ayam
- rica

katakunci: ayam rica 
nutrition: 101 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica](https://img-global.cpcdn.com/recipes/23a8e7d21d5d74f8/751x532cq70/ayam-rica-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang setidaknya kita lestarikan karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa keistimewahan yang merupakan keragaman Nusantara



Kedekatan keluarga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Ayam Rica untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang dapat anda contoh salah satunya ayam rica yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep ayam rica tanpa harus bersusah payah.
Seperti resep Ayam Rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 12 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica:

1. Jangan lupa 300 gr ayam fillet (potong dadu)
1. Harus ada 2 lembar daun salam
1. Dibutuhkan 1 ruas lengkuas
1. Diperlukan 2 sdm kecap
1. Dibutuhkan  Bumbu Halus
1. Jangan lupa 5 siung bawang merah
1. Jangan lupa 3 siung bawang putih
1. Siapkan 2 sdt garam
1. Dibutuhkan 1 sdt gula
1. Harus ada 3 buah cabe rawit merah
1. Dibutuhkan 5 buah cabe merah keriting
1. Dibutuhkan 1 ruas kunyit




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica:

1. Tumis bumbu halus, daun salam, dan laos hingga wangi
1. Masukkan kecap, aduk rata
1. Masukkan ayam, aduk rata kemudian tambahkan sedikit air. Masak hingga air menyusut




Demikianlah cara membuat ayam rica yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
