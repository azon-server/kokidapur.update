---
description: "Cara untuk membuat Ayam Rica-rica Cepat"
title: "Cara untuk membuat Ayam Rica-rica Cepat"
slug: 59-cara-untuk-membuat-ayam-rica-rica-cepat
date: 2020-10-13T15:36:22.423Z
image: https://img-global.cpcdn.com/recipes/60e59ad8f449627a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/60e59ad8f449627a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/60e59ad8f449627a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Ricardo Adams
ratingvalue: 4.3
reviewcount: 31442
recipeingredient:
- "1 ekor ayam potong 14 buang kulitnya"
- "2 batang serai memarkan"
- "3 lembar daun jeruk"
- "3 cm lengkuas memarkan"
- "3 cm jahe memarkan"
- "secukupnya garam"
- "Secukupnya penyedap rasa"
- "2 sdm kecap manis"
- "1 sdt perasan jeruk nipis"
- "1 sdm gula merah"
- " Kemangi"
- "secukupnya air"
- " Bumbu halus"
- "15 buah cabai rawit merah"
- "5 buah cabai merah besar"
- "5 siung bawang putih"
- "10 siung bawang merah"
- "1 buah tomat"
recipeinstructions:
- "Panaskan minyak lalu goreng ayam sampai 1/2 matang, sisihkan"
- "Haluskan bumbu kemudian tumis sampai harum"
- "Tambahkan bahan2 lainnya"
- "Masukkan ayam dan tambahkan air, aduk rata"
- "Masak sampai ayam matang dan bumbu meresap"
- "Koreksi rasa lalu masukkan kemangi"
- "Masak sebentar sambil diaduk"
- "Siap disajikan"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 264 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica-rica](https://img-global.cpcdn.com/recipes/60e59ad8f449627a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang setidaknya kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica-rica yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan ciri khas yang merupakan keragaman Indonesia



Kedekatan keluarga bisa didapat dengan cara mudah. Salah satunya adalah memasak Ayam Rica-rica untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang bisa anda coba salah satunya ayam rica-rica yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica:

1. Dibutuhkan 1 ekor ayam, potong 14 buang kulitnya
1. Jangan lupa 2 batang serai, memarkan
1. Harus ada 3 lembar daun jeruk
1. Harap siapkan 3 cm lengkuas, memarkan
1. Siapkan 3 cm jahe, memarkan
1. Harap siapkan secukupnya garam
1. Harap siapkan Secukupnya penyedap rasa
1. Tambah 2 sdm kecap manis
1. Harus ada 1 sdt perasan jeruk nipis
1. Harus ada 1 sdm gula merah
1. Harus ada  Kemangi
1. Harus ada secukupnya air
1. Diperlukan  Bumbu halus:
1. Harus ada 15 buah cabai rawit merah
1. Jangan lupa 5 buah cabai merah besar
1. Siapkan 5 siung bawang putih
1. Harap siapkan 10 siung bawang merah
1. Tambah 1 buah tomat




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-rica:

1. Panaskan minyak lalu goreng ayam sampai 1/2 matang, sisihkan
1. Haluskan bumbu kemudian tumis sampai harum
1. Tambahkan bahan2 lainnya
1. Masukkan ayam dan tambahkan air, aduk rata
1. Masak sampai ayam matang dan bumbu meresap
1. Koreksi rasa lalu masukkan kemangi
1. Masak sebentar sambil diaduk
1. Siap disajikan




Demikianlah cara membuat ayam rica-rica yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
