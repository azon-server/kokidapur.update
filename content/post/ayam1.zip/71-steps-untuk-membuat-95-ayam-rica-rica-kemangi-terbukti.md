---
description: "Steps untuk membuat 95. Ayam Rica-Rica Kemangi Terbukti"
title: "Steps untuk membuat 95. Ayam Rica-Rica Kemangi Terbukti"
slug: 71-steps-untuk-membuat-95-ayam-rica-rica-kemangi-terbukti
date: 2021-01-01T23:19:53.003Z
image: https://img-global.cpcdn.com/recipes/d701e73905430287/751x532cq70/95-ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d701e73905430287/751x532cq70/95-ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d701e73905430287/751x532cq70/95-ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Eugenia Crawford
ratingvalue: 4.9
reviewcount: 45463
recipeingredient:
- " Ayam potong baluri kunyit bubuk air jeruk nispis  garam"
- " Bumbu Halus"
- "1 ons cabe kriting"
- "1/2 ons cabe rawit me 7 biji aja gk berani mkn pedas "
- "5 siung bawang merah"
- "5 siung bawang putih"
- "2 cm jahe"
- "Sedikit kunyit"
- "3 butir kemiri"
- "2 cm lengkuas"
- " Bahan Kasar"
- "3 batang serai geprak"
- "1 lembar daun pandan simpul"
- "5 lembar daun salam"
- "5 lembar daun jeruk iris halus"
- "2 ikat kemangi petiki"
- "Secukupnya garam dan penyedap rasa"
- "secukupnya Air matang"
recipeinstructions:
- "Rebus ayam untuk membuang amis. Kemudian marinasi. Lalu goreng ayam setengah matang."
- "Blender semua bahan bumbu halus lalu tmis bumbu halus sampai wangi masukan daun jeruk, daun salam, daun pandan dan serai."
- "Kemudiam masukan ayam yg sudah digoreng setengah matang tadi. Aduk2 sampai bumbu tercampur rata. Tambahkan air secukupnya"
- "Masukan garam dan penyedap secukupnya. Masak sampai ayam empuk kurang lebih stgah jam."
- "Setelah ayam empuk dan kuah mengering masukan daun kemangi dan daun bawang, aduk hingga layu. Ayam rica rica siap dihidangkan dengan nasi panas bersama lalapan."
categories:
- Recipe
tags:
- 95
- ayam
- ricarica

katakunci: 95 ayam ricarica 
nutrition: 218 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Dinner

---


![95. Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/d701e73905430287/751x532cq70/95-ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti 95. ayam rica-rica kemangi yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan keistimewahan yang merupakan keragaman Indonesia

Kehangatan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan 95. Ayam Rica-Rica Kemangi untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang dapat anda buat salah satunya 95. ayam rica-rica kemangi yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep 95. ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep 95. Ayam Rica-Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 95. Ayam Rica-Rica Kemangi:

1. Jangan lupa  Ayam potong (baluri kunyit bubuk, air jeruk nispis &amp; garam)
1. Diperlukan  Bumbu Halus
1. Harap siapkan 1 ons cabe kriting
1. Harap siapkan 1/2 ons cabe rawit (me: 7 biji aja.. gk berani mkn pedas 🤭)
1. Harap siapkan 5 siung bawang merah
1. Diperlukan 5 siung bawang putih
1. Harus ada 2 cm jahe
1. Harap siapkan Sedikit kunyit
1. Tambah 3 butir kemiri
1. Siapkan 2 cm lengkuas
1. Jangan lupa  Bahan Kasar
1. Jangan lupa 3 batang serai geprak
1. Dibutuhkan 1 lembar daun pandan simpul
1. Jangan lupa 5 lembar daun salam
1. Jangan lupa 5 lembar daun jeruk iris halus
1. Harap siapkan 2 ikat kemangi, petiki
1. Diperlukan Secukupnya garam dan penyedap rasa
1. Jangan lupa secukupnya Air matang




<!--inarticleads2-->

##### Langkah membuat  95. Ayam Rica-Rica Kemangi:

1. Rebus ayam untuk membuang amis. Kemudian marinasi. Lalu goreng ayam setengah matang.
1. Blender semua bahan bumbu halus lalu tmis bumbu halus sampai wangi masukan daun jeruk, daun salam, daun pandan dan serai.
1. Kemudiam masukan ayam yg sudah digoreng setengah matang tadi. Aduk2 sampai bumbu tercampur rata. Tambahkan air secukupnya
1. Masukan garam dan penyedap secukupnya. Masak sampai ayam empuk kurang lebih stgah jam.
1. Setelah ayam empuk dan kuah mengering masukan daun kemangi dan daun bawang, aduk hingga layu. Ayam rica rica siap dihidangkan dengan nasi panas bersama lalapan.




Demikianlah cara membuat 95. ayam rica-rica kemangi yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
