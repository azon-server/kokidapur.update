---
description: "Resep : Ayam Goreng Saus Pedas Favorite"
title: "Resep : Ayam Goreng Saus Pedas Favorite"
slug: 256-resep-ayam-goreng-saus-pedas-favorite
date: 2020-11-11T18:29:07.691Z
image: https://img-global.cpcdn.com/recipes/e9d79ece6de200cc/751x532cq70/ayam-goreng-saus-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e9d79ece6de200cc/751x532cq70/ayam-goreng-saus-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e9d79ece6de200cc/751x532cq70/ayam-goreng-saus-pedas-foto-resep-utama.jpg
author: Myrtle Luna
ratingvalue: 4.2
reviewcount: 31731
recipeingredient:
- "7 bh Sayap ayam bersihkan"
- " Tepung pelapis"
- "200 gr Tepung Terigu"
- "2 sdm Tepung Maizena"
- "100 ml Air"
- "Secukupnya Minyak untuk menggoreng"
- "Secukupnya Garam"
- " Saus"
- "1 sdm minyak wijen"
- "2 siung Bawang putih cincang halus"
- "1 sdt Jahe parut"
- "60 ml air"
- "3 sdm gula"
- "3 sdm Saus Sambal sesuai selera"
- "1 sdm Soy Sauce  Kecap asin"
recipeinstructions:
- "Saus: tumis minyak wijen, bawang putih dan jahe sampai harum. Masukkan gula, soy sauce, saus sambal dan air, masak sebentar sampai gula larut dan saus mendidih. Angkat dan sisihkan."
- "Dalam wadah, campur tepung terigu, maizena, dan garam, aduk rata. Tambahkan air sedikit-sedikit, aduk sampai rata. Masukan sayap ayam dan aduk rata."
- "Goreng sayap ayam sampai kekuningan (1/2 matang) angkat dan tiriskan. Setelah ditiriskan masak kembali ayam sampai berwarna golden brown. Angkat dan tiriskan."
- "Masukkan ayam goreng ke dalam saus, aduk rata. Ayam Goreng Saus Pedas siap dinikmati"
categories:
- Recipe
tags:
- ayam
- goreng
- saus

katakunci: ayam goreng saus 
nutrition: 156 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Goreng Saus Pedas](https://img-global.cpcdn.com/recipes/e9d79ece6de200cc/751x532cq70/ayam-goreng-saus-pedas-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga empuk. Karasteristik masakan Nusantara ayam goreng saus pedas yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak Ayam Goreng Saus Pedas untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang dapat anda coba salah satunya ayam goreng saus pedas yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep ayam goreng saus pedas tanpa harus bersusah payah.
Seperti resep Ayam Goreng Saus Pedas yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Saus Pedas:

1. Siapkan 7 bh Sayap ayam, bersihkan
1. Jangan lupa  Tepung pelapis:
1. Siapkan 200 gr Tepung Terigu
1. Siapkan 2 sdm Tepung Maizena
1. Harus ada 100 ml Air
1. Tambah Secukupnya Minyak untuk menggoreng
1. Dibutuhkan Secukupnya Garam
1. Harap siapkan  Saus:
1. Siapkan 1 sdm minyak wijen
1. Siapkan 2 siung Bawang putih, cincang halus
1. Jangan lupa 1 sdt Jahe, parut
1. Diperlukan 60 ml air
1. Dibutuhkan 3 sdm gula
1. Tambah 3 sdm Saus Sambal. sesuai selera
1. Jangan lupa 1 sdm Soy Sauce / Kecap asin




<!--inarticleads2-->

##### Cara membuat  Ayam Goreng Saus Pedas:

1. Saus: tumis minyak wijen, bawang putih dan jahe sampai harum. Masukkan gula, soy sauce, saus sambal dan air, masak sebentar sampai gula larut dan saus mendidih. Angkat dan sisihkan.
1. Dalam wadah, campur tepung terigu, maizena, dan garam, aduk rata. Tambahkan air sedikit-sedikit, aduk sampai rata. Masukan sayap ayam dan aduk rata.
1. Goreng sayap ayam sampai kekuningan (1/2 matang) angkat dan tiriskan. Setelah ditiriskan masak kembali ayam sampai berwarna golden brown. Angkat dan tiriskan.
1. Masukkan ayam goreng ke dalam saus, aduk rata. Ayam Goreng Saus Pedas siap dinikmati




Demikianlah cara membuat ayam goreng saus pedas yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan cepat, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
