---
description: "Langkah membuat Ayam Rica Rica Luar biasa"
title: "Langkah membuat Ayam Rica Rica Luar biasa"
slug: 195-langkah-membuat-ayam-rica-rica-luar-biasa
date: 2021-01-05T02:22:56.882Z
image: https://img-global.cpcdn.com/recipes/e78721ee98a4b9be/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e78721ee98a4b9be/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e78721ee98a4b9be/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Maurice Patterson
ratingvalue: 4.3
reviewcount: 29308
recipeingredient:
- " Bahan Utama"
- "1 ekor Ayam"
- " Bumbu marinasi"
- " Perasan air jeruk nipis"
- "1 sdm Garam"
- "5 lembar daun jeruk diiris"
- " Bumbu uleg kasar"
- "secukupnya Cabe rawit merah"
- "secukupnya Cabe merah keriting"
- "2 buah Cabe merah besar"
- "segenggam Bawang merah"
- "segenggam Bawang putih"
- "1/2 ruas jari Jahe"
- " Bumbu kasar"
- "4 lembar daun salam"
- "2 sereh geprek"
- "1/2 tomat"
- " Tambahan"
- " Totole"
- " Garam"
- " Gula"
- " Lada"
recipeinstructions:
- "Cuci bersih ayam, dan langsung ditaburi bumbu marinasi. Tunggu 30 menit, masukin kulkas."
- "Setelah 30 menit, goreng ayam sampai matang. Jangan terlalu kering, nanti ayamnya keras. (Api wajib kecil, masukin ayam pas minyak panas banget ya)."
- "Uleg bumbu/blender kasar juga boleh. Setelah itu tumis bumbu dengan minyak sampai harum. Masukkan tomat, daun salam, sereh totole, garam, lada dan gula. Koreksi rasa"
- "Bila rasa sudah sesuai bisa masukkan ayam dan diaduk merata. Setelah rata, bisa dinikmati dengan nasi panas langsungg🤤🤤"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 233 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/e78721ee98a4b9be/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau enak. Ciri khas kuliner Indonesia ayam rica rica yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kedekatan rumah tangga dapat diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam Rica Rica untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang bisa anda contoh salah satunya ayam rica rica yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep ayam rica rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica:

1. Harap siapkan  Bahan Utama
1. Jangan lupa 1 ekor Ayam
1. Jangan lupa  Bumbu marinasi
1. Siapkan  Perasan air jeruk nipis
1. Harus ada 1 sdm Garam
1. Harap siapkan 5 lembar daun jeruk diiris
1. Jangan lupa  Bumbu uleg kasar
1. Diperlukan secukupnya Cabe rawit merah
1. Siapkan secukupnya Cabe merah keriting
1. Diperlukan 2 buah Cabe merah besar
1. Diperlukan segenggam Bawang merah
1. Siapkan segenggam Bawang putih
1. Tambah 1/2 ruas jari Jahe
1. Dibutuhkan  Bumbu kasar
1. Harus ada 4 lembar daun salam
1. Jangan lupa 2 sereh geprek
1. Siapkan 1/2 tomat
1. Diperlukan  Tambahan
1. Diperlukan  Totole
1. Dibutuhkan  Garam
1. Harus ada  Gula
1. Jangan lupa  Lada




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica:

1. Cuci bersih ayam, dan langsung ditaburi bumbu marinasi. Tunggu 30 menit, masukin kulkas.
1. Setelah 30 menit, goreng ayam sampai matang. Jangan terlalu kering, nanti ayamnya keras. (Api wajib kecil, masukin ayam pas minyak panas banget ya).
1. Uleg bumbu/blender kasar juga boleh. Setelah itu tumis bumbu dengan minyak sampai harum. Masukkan tomat, daun salam, sereh totole, garam, lada dan gula. Koreksi rasa
1. Bila rasa sudah sesuai bisa masukkan ayam dan diaduk merata. Setelah rata, bisa dinikmati dengan nasi panas langsungg🤤🤤




Demikianlah cara membuat ayam rica rica yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
