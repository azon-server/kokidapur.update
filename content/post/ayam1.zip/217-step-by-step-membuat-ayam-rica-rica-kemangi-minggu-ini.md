---
description: "Step-by-Step membuat Ayam Rica-rica Kemangi minggu ini"
title: "Step-by-Step membuat Ayam Rica-rica Kemangi minggu ini"
slug: 217-step-by-step-membuat-ayam-rica-rica-kemangi-minggu-ini
date: 2020-08-20T04:03:37.007Z
image: https://img-global.cpcdn.com/recipes/a7810060acd15532/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a7810060acd15532/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a7810060acd15532/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Isaac Bowen
ratingvalue: 4.1
reviewcount: 42166
recipeingredient:
- "1/4 Daging ayam"
- " Daun Kemangi"
- "2 siung bawang merah"
- "2 siung bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "4 buah Kemiri"
- "5 buah cabe merah keriting"
- "3 buah cabe rawit merah"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 batang sereh digeprek"
- "1 buah jeruk nipis"
- "1 sdt garam"
- "2 sdt kaldu bubuk"
- "1/4 Bks lada bubuk"
- "4 sdm minyak goreng"
- "secukupnya Air"
recipeinstructions:
- "Potong ayam menjaji 4 bagian"
- "Marinasi ayam menggunakan jeruk nipis dan sedikit garam, diamkan selama 10 menit."
- "Tambahkan air, dan ungkep ayam sebentar. Jika sudah terlihat matang sisihkan (air kaldunya simpan)"
- "Haluskan bawang merah, bawang putih, kemiri, kunyit, jahe, cabe merah dan cabe rawit."
- "Panaskan wajan, dan tumis bumbu beserta sereh, daun salam dan daun jeruk sampe harum."
- "Masukan air kaldu yang tadi di simpan, setelah mendidih masukan ayam. Masukan juga bumbu penyedap seperti, garam, kaldu bubuk dan merica."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 286 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/a7810060acd15532/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan gurih. Ciri kuliner Nusantara ayam rica-rica kemangi yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Kehangatan rumah tangga bisa didapat dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica-rica Kemangi untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian masakan yang dapat anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica Kemangi:

1. Harus ada 1/4 Daging ayam
1. Harus ada  Daun Kemangi
1. Jangan lupa 2 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Tambah 1 ruas jahe
1. Harus ada 1 ruas kunyit
1. Tambah 4 buah Kemiri
1. Jangan lupa 5 buah cabe merah keriting
1. Harap siapkan 3 buah cabe rawit merah
1. Siapkan 2 lembar daun salam
1. Diperlukan 2 lembar daun jeruk
1. Harus ada 1 batang sereh (digeprek)
1. Diperlukan 1 buah jeruk nipis
1. Tambah 1 sdt garam
1. Dibutuhkan 2 sdt kaldu bubuk
1. Dibutuhkan 1/4 Bks lada bubuk
1. Tambah 4 sdm minyak goreng
1. Diperlukan secukupnya Air


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Cara membuat  Ayam Rica-rica Kemangi:

1. Potong ayam menjaji 4 bagian
1. Marinasi ayam menggunakan jeruk nipis dan sedikit garam, diamkan selama 10 menit.
1. Tambahkan air, dan ungkep ayam sebentar. Jika sudah terlihat matang sisihkan (air kaldunya simpan)
1. Haluskan bawang merah, bawang putih, kemiri, kunyit, jahe, cabe merah dan cabe rawit.
1. Panaskan wajan, dan tumis bumbu beserta sereh, daun salam dan daun jeruk sampe harum.
1. Masukan air kaldu yang tadi di simpan, setelah mendidih masukan ayam. Masukan juga bumbu penyedap seperti, garam, kaldu bubuk dan merica.


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan cepat, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
