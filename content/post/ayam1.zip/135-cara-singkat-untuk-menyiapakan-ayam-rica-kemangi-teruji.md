---
description: "Cara singkat untuk menyiapakan Ayam rica kemangi Teruji"
title: "Cara singkat untuk menyiapakan Ayam rica kemangi Teruji"
slug: 135-cara-singkat-untuk-menyiapakan-ayam-rica-kemangi-teruji
date: 2020-08-15T23:06:22.352Z
image: https://img-global.cpcdn.com/recipes/bbd8e729baa7e083/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bbd8e729baa7e083/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bbd8e729baa7e083/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Dale Joseph
ratingvalue: 4.2
reviewcount: 26634
recipeingredient:
- "1 kg Ayam dada boneless"
- " Bumbu halus"
- "10 Cabe merah"
- "15 Cabe rawit"
- "5 Kemiri sangrai"
- "1 cm Kunyit"
- "12 Bawang merah"
- "6 Bawang putih"
- "1 buah Tomat"
- " Minyak goreng untuk tumis"
- " Bumbu pelengkap"
- "2 lbr Salam"
- "2 Serai"
- "3 Daun jeruk"
- "3 tangkai Daun bawang"
- "3 ikat Kemangi"
- " Garam"
- " Gula"
recipeinstructions:
- "Potong dadu ayam dada boneless"
- "Tumis bumbu halus dan masukkan serai daun salam serta daun jeruk, masukan garam 2sdt, 2 sdt gula tunggu bumbu wangi"
- "Masukkan potongan ayam ke bumbu tumis"
- "Masak sampai bumbu menyusut dan koreksi rasa saat sudah menyusut... menghindari rasa keasinan apabila di coba saat air masih banyak"
- "Tambahkan kemangi dan daun bawang aduk sampai layu.."
- "Siap di santap..bisa dilengkapi dengan sayuran rebus untuk menghadirkan vitamin dan serat yg lengkap tetapi tdk merubah rasa"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 273 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/bbd8e729baa7e083/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang setidaknya kita lestarikan karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica kemangi yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Nusantara

Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. RESEP AYAM RICA RICA KEMANGI YANG SUPER ENAK hai assalammualikum teman teman. kali ini saya berbagi resep olahan ayam. bahan bahanya. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera.

Keharmonisan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam rica kemangi untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi budaya, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang dapat anda contoh salah satunya ayam rica kemangi yang merupakan resep favorite yang mudah dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi:

1. Dibutuhkan 1 kg Ayam dada boneless
1. Dibutuhkan  Bumbu halus
1. Siapkan 10 Cabe merah
1. Harap siapkan 15 Cabe rawit
1. Siapkan 5 Kemiri sangrai
1. Harus ada 1 cm Kunyit
1. Siapkan 12 Bawang merah
1. Dibutuhkan 6 Bawang putih
1. Diperlukan 1 buah Tomat
1. Jangan lupa  Minyak goreng untuk tumis
1. Siapkan  Bumbu pelengkap
1. Diperlukan 2 lbr Salam
1. Dibutuhkan 2 Serai
1. Dibutuhkan 3 Daun jeruk
1. Harus ada 3 tangkai Daun bawang
1. Siapkan 3 ikat Kemangi
1. Dibutuhkan  Garam
1. Harap siapkan  Gula


Ayam rica-rica pedas kemangi adalah salah satunya. Rasanya yang pedas, manis dan gurih, membuatnya banyak di gemari banyak kalangan, dari anak-anak sampai orang tua. Cara Membuat Ayam Rica Rica Kemangi. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. 

<!--inarticleads2-->

##### Cara membuat  Ayam rica kemangi:

1. Potong dadu ayam dada boneless
1. Tumis bumbu halus dan masukkan serai daun salam serta daun jeruk, masukan garam 2sdt, 2 sdt gula tunggu bumbu wangi
1. Masukkan potongan ayam ke bumbu tumis
1. Masak sampai bumbu menyusut dan koreksi rasa saat sudah menyusut... menghindari rasa keasinan apabila di coba saat air masih banyak
1. Tambahkan kemangi dan daun bawang aduk sampai layu..
1. Siap di santap..bisa dilengkapi dengan sayuran rebus untuk menghadirkan vitamin dan serat yg lengkap tetapi tdk merubah rasa


Cara Membuat Ayam Rica Rica Kemangi. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. 

Demikianlah cara membuat ayam rica kemangi yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
