---
description: "Langkah untuk menyiapakan Ayam Goreng Lengkuas Cepat"
title: "Langkah untuk menyiapakan Ayam Goreng Lengkuas Cepat"
slug: 430-langkah-untuk-menyiapakan-ayam-goreng-lengkuas-cepat
date: 2020-12-18T22:54:35.487Z
image: https://img-global.cpcdn.com/recipes/18aef2f6c947fbef/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/18aef2f6c947fbef/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/18aef2f6c947fbef/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Randy Atkins
ratingvalue: 4.5
reviewcount: 4041
recipeingredient:
- "500 gr paha ayam bersihkan marinasi dgn air perasan jeruk nipis kurleb 5 menit cuci bersih lagi sisihkan"
- " Bumbu Halus "
- "3 siung bawang putih"
- "6 siung bawang merah"
- "3 butir kemiri"
- "1 ruas jari kunyit"
- "1 ruas jari jahe"
- " Bumbu Pelengkap "
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 batang serai geprek"
- "2 sdt garam"
- "75 gr lengkuas parut"
recipeinstructions:
- "Rebus ayam dgn bumbu halus dan bumbu pelengkap.."
- "Masak hingga bumbu asat / habis."
- "Goreng ayam hingga kecoklatan, lalu ambil bumbu sisa, buang serai dan daun salam. goreng bumbu hingga kecoklatan dan tabur diatas ayam goreng. sajikan"
categories:
- Recipe
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 178 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Goreng Lengkuas](https://img-global.cpcdn.com/recipes/18aef2f6c947fbef/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam goreng lengkuas yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa ciri khas yang merupakan keragaman Kita

Kehangatan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam Goreng Lengkuas untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang dapat anda coba salah satunya ayam goreng lengkuas yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep ayam goreng lengkuas tanpa harus bersusah payah.
Seperti resep Ayam Goreng Lengkuas yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Lengkuas:

1. Siapkan 500 gr paha ayam, bersihkan, marinasi dgn air perasan jeruk nipis kurleb 5 menit. cuci bersih lagi, sisihkan
1. Diperlukan  Bumbu Halus :
1. Jangan lupa 3 siung bawang putih
1. Jangan lupa 6 siung bawang merah
1. Harap siapkan 3 butir kemiri
1. Tambah 1 ruas jari kunyit
1. Diperlukan 1 ruas jari jahe
1. Siapkan  Bumbu Pelengkap :
1. Siapkan 2 lembar daun salam
1. Harus ada 3 lembar daun jeruk
1. Jangan lupa 1 batang serai, geprek
1. Harus ada 2 sdt garam
1. Siapkan 75 gr lengkuas, parut




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Goreng Lengkuas:

1. Rebus ayam dgn bumbu halus dan bumbu pelengkap..
1. Masak hingga bumbu asat / habis.
1. Goreng ayam hingga kecoklatan, lalu ambil bumbu sisa, buang serai dan daun salam. goreng bumbu hingga kecoklatan dan tabur diatas ayam goreng. sajikan




Demikianlah cara membuat ayam goreng lengkuas yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan cepat, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
