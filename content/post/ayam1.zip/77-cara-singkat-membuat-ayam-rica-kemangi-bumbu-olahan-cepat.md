---
description: "Cara singkat membuat Ayam rica kemangi bumbu olahan Cepat"
title: "Cara singkat membuat Ayam rica kemangi bumbu olahan Cepat"
slug: 77-cara-singkat-membuat-ayam-rica-kemangi-bumbu-olahan-cepat
date: 2021-02-02T19:52:45.604Z
image: https://img-global.cpcdn.com/recipes/bf42d31bf3f95597/751x532cq70/ayam-rica-kemangi-bumbu-olahan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bf42d31bf3f95597/751x532cq70/ayam-rica-kemangi-bumbu-olahan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bf42d31bf3f95597/751x532cq70/ayam-rica-kemangi-bumbu-olahan-foto-resep-utama.jpg
author: Flora McCoy
ratingvalue: 4.4
reviewcount: 8935
recipeingredient:
- "1/2 ekor ayam sudah digoreng setengah masak"
- "3 batang kemangi"
- "1 gelas duralex air biasa"
- "7 sdm minyak goreng"
- " Bahan Halus"
- "5 siung bawang merah"
- "2 siung bawang putih hrusnya 3 Tp khabisan bawang putih"
- "2 biji kemiri"
- "1 ruas kunyit"
- "1 ruas jahe"
- "3 biji cabe kriting"
- "13 biji cabe rawit"
- "1 buah tomat ukuran sedang"
- "1/2 sdt lada bubuk"
- " Bahan cemplung"
- "1 batang serai"
- "2 helai daun salam"
- " Bumbu Rasa"
- "2 sdt garam tidak penuh"
- "2 sdt royco ayam"
- "1 sdm gula pasir tidak penuh"
recipeinstructions:
- "Panaskan minyak dgn api sedang. Kemudian tumis bahan halus bersamaan daun salam dan serai hingga keluar aroma wangi bumbunya"
- "Masukkan ayam, bumbu rasa dan air, aduk sebentar sekiranya semua ayam terendam merata. Tunggu skitar 3 menit, kemudian aduk lagi. Ulangi mengaduk setelah 3 menit hingga air mulai menyusut"
- "Jika sdh menyusut, cek rasa. Jika sudah pas, masukkan daun kemangi yg sudah dibersihkan. Aduk lagi hingga daun kemanginya layu."
- "Jika sudah layu, matikan kompor. Dan ayam rica kemangi bumbu olahan siap disajikan😁"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 161 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica kemangi bumbu olahan](https://img-global.cpcdn.com/recipes/bf42d31bf3f95597/751x532cq70/ayam-rica-kemangi-bumbu-olahan-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica kemangi bumbu olahan yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Indonesia

Kehangatan rumah tangga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam rica kemangi bumbu olahan untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang bisa anda contoh salah satunya ayam rica kemangi bumbu olahan yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica kemangi bumbu olahan tanpa harus bersusah payah.
Berikut ini resep Ayam rica kemangi bumbu olahan yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 21 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica kemangi bumbu olahan:

1. Diperlukan 1/2 ekor ayam (sudah digoreng setengah masak)
1. Siapkan 3 batang kemangi
1. Tambah 1 gelas duralex air biasa
1. Tambah 7 sdm minyak goreng
1. Harus ada  Bahan Halus
1. Harap siapkan 5 siung bawang merah
1. Harap siapkan 2 siung bawang putih (hrusnya 3. Tp khabisan bawang putih😅)
1. Dibutuhkan 2 biji kemiri
1. Diperlukan 1 ruas kunyit
1. Tambah 1 ruas jahe
1. Harus ada 3 biji cabe kriting
1. Siapkan 13 biji cabe rawit
1. Dibutuhkan 1 buah tomat ukuran sedang
1. Harus ada 1/2 sdt lada bubuk
1. Harap siapkan  Bahan cemplung
1. Dibutuhkan 1 batang serai
1. Diperlukan 2 helai daun salam
1. Diperlukan  Bumbu Rasa
1. Dibutuhkan 2 sdt garam (tidak penuh)
1. Harus ada 2 sdt royco ayam
1. Harap siapkan 1 sdm gula pasir (tidak penuh)




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica kemangi bumbu olahan:

1. Panaskan minyak dgn api sedang. Kemudian tumis bahan halus bersamaan daun salam dan serai hingga keluar aroma wangi bumbunya
1. Masukkan ayam, bumbu rasa dan air, aduk sebentar sekiranya semua ayam terendam merata. Tunggu skitar 3 menit, kemudian aduk lagi. Ulangi mengaduk setelah 3 menit hingga air mulai menyusut
1. Jika sdh menyusut, cek rasa. Jika sudah pas, masukkan daun kemangi yg sudah dibersihkan. Aduk lagi hingga daun kemanginya layu.
1. Jika sudah layu, matikan kompor. Dan ayam rica kemangi bumbu olahan siap disajikan😁




Demikianlah cara membuat ayam rica kemangi bumbu olahan yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
