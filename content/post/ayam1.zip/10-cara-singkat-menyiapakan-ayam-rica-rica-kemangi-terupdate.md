---
description: "Cara singkat menyiapakan Ayam Rica-Rica Kemangi terupdate"
title: "Cara singkat menyiapakan Ayam Rica-Rica Kemangi terupdate"
slug: 10-cara-singkat-menyiapakan-ayam-rica-rica-kemangi-terupdate
date: 2020-12-14T07:43:19.682Z
image: https://img-global.cpcdn.com/recipes/c5d0fdf24024715e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c5d0fdf24024715e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c5d0fdf24024715e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Martin Hale
ratingvalue: 5
reviewcount: 12430
recipeingredient:
- "1/2 ekor ayam"
- "4 ikat kemangi petik"
- "2 btg sereh geprek"
- "2 lbr daun salam"
- "7 lbr daun jeruk"
- " Lengkuas secukupnya geprek"
- " Air perasan jeruk nipis sedikit saja"
- "5 bh cabe rawit merah utuh bisa diskip"
- "secukupnya Gula merah"
- "secukupnya Kaldu jamur bubuk"
- "secukupnya Garam"
- "secukupnya Air"
- " Bumbu yg Dihaluskan"
- "6 btr bawang merah"
- "3 btr bawang putih"
- "9 bh cabe merah keriting"
- "12 bh cabe rawit merah"
- "2 btr kemiri sangrai"
- "2 ruas jahe"
- "2 ruas kunyit"
recipeinstructions:
- "Goreng sebentar semua bahan bumbu halus kecuali kemiri &amp; kunyit. Setelah digoreng, diamkan sebentar lalu blender bersama kemiri, kunyit, dan minyak sedikit"
- "Tumis bumbu yg telah dihaluskan bersama dg sereh, lengkuas, daun salam, &amp; daun jeruk sampai harum"
- "Masukan kaldu jamur, garam, dan gula merah, tumis kembali hingga matang"
- "Masukan ayam, masak hingga bumbu merata"
- "Masukan air, aduk-aduk dan diamkan sebentar"
- "Masukan air perasan jeruk nipis, icip untuk koreksi rasa, masukan cabe rawit merah, masak kembali hingga air meresap"
- "Masukan kemangi, aduk-aduk, dan SELESAI 😊"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 109 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/c5d0fdf24024715e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis dan empuk. Karasteristik masakan Nusantara ayam rica-rica kemangi yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga dapat didapat dengan cara simple. Salah satunya adalah memasak Ayam Rica-Rica Kemangi untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang bisa anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 20 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Kemangi:

1. Harus ada 1/2 ekor ayam
1. Tambah 4 ikat kemangi, petik
1. Tambah 2 btg sereh, geprek
1. Jangan lupa 2 lbr daun salam
1. Siapkan 7 lbr daun jeruk
1. Jangan lupa  Lengkuas secukupnya, geprek
1. Siapkan  Air perasan jeruk nipis (sedikit saja)
1. Jangan lupa 5 bh cabe rawit merah utuh (bisa diskip)
1. Jangan lupa secukupnya Gula merah
1. Harap siapkan secukupnya Kaldu jamur bubuk
1. Diperlukan secukupnya Garam
1. Tambah secukupnya Air
1. Diperlukan  Bumbu yg Dihaluskan
1. Dibutuhkan 6 btr bawang merah
1. Siapkan 3 btr bawang putih
1. Jangan lupa 9 bh cabe merah keriting
1. Siapkan 12 bh cabe rawit merah
1. Harus ada 2 btr kemiri, sangrai
1. Harus ada 2 ruas jahe
1. Harap siapkan 2 ruas kunyit




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica Kemangi:

1. Goreng sebentar semua bahan bumbu halus kecuali kemiri &amp; kunyit. Setelah digoreng, diamkan sebentar lalu blender bersama kemiri, kunyit, dan minyak sedikit
1. Tumis bumbu yg telah dihaluskan bersama dg sereh, lengkuas, daun salam, &amp; daun jeruk sampai harum
1. Masukan kaldu jamur, garam, dan gula merah, tumis kembali hingga matang
1. Masukan ayam, masak hingga bumbu merata
1. Masukan air, aduk-aduk dan diamkan sebentar
1. Masukan air perasan jeruk nipis, icip untuk koreksi rasa, masukan cabe rawit merah, masak kembali hingga air meresap
1. Masukan kemangi, aduk-aduk, dan SELESAI 😊




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
