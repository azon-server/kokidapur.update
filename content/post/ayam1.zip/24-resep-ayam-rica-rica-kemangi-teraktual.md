---
description: "Resep : Ayam rica-rica kemangi teraktual"
title: "Resep : Ayam rica-rica kemangi teraktual"
slug: 24-resep-ayam-rica-rica-kemangi-teraktual
date: 2020-11-15T20:34:26.151Z
image: https://img-global.cpcdn.com/recipes/236fcd038fbb6a4c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/236fcd038fbb6a4c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/236fcd038fbb6a4c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Chase Simon
ratingvalue: 4.6
reviewcount: 35516
recipeingredient:
- "1/2 ekor ayam"
- "3 ikat daun kemangi"
- "2 lembar daun salam 1 lembar umenumis 1 lemar u di ungkep"
- "5 lemar daun jeruk 3 umenumis 2 u di ungkep"
- "2 batang sereh geprek 1 umenumis 1 udi ungkep"
- "1 buah kunyit"
- "1 buah jahe"
- " BUMBU HALUS "
- "20 buah cabai jablay"
- "10 siung bawang putih"
- "3 siung bawang putih"
- "3 buah kemiri"
- "Sedikit kencur"
- "1 buah tomat"
- " Penyedap rasa garam gula micin kaldu ayam"
recipeinstructions:
- "Ungkep ayam kurang lebih 20menit sampai ayam empuk"
- "Lalu goreng ayam stengah matang"
- "Tumis semua bumbu halus sampai wangi masukan daun jeruk, daun salam, sereh dan tomat tambahkan sedikit air sisa rebusan tadi"
- "Lalu masukan ayam aduk-aduk tambahkan penyedap rasa (garam, gula, micin, kaldu ayam)"
- "Masak ayam sampai air nya menyusut lalu terakhir masukan kemangi"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 168 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/236fcd038fbb6a4c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica-rica kemangi yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan keistimewahan yang merupakan keragaman Indonesia

Kedekatan keluarga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica-rica kemangi untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang bisa anda buat salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica kemangi:

1. Siapkan 1/2 ekor ayam
1. Dibutuhkan 3 ikat daun kemangi
1. Dibutuhkan 2 lembar daun salam (1 lembar u/menumis, 1 lemar u/ di ungkep
1. Jangan lupa 5 lemar daun jeruk (3 u/menumis, 2 u/ di ungkep)
1. Siapkan 2 batang sereh geprek (1 u/menumis, 1 u/di ungkep)
1. Dibutuhkan 1 buah kunyit
1. Harap siapkan 1 buah jahe
1. Diperlukan  BUMBU HALUS :
1. Harap siapkan 20 buah cabai jablay
1. Diperlukan 10 siung bawang putih
1. Siapkan 3 siung bawang putih
1. Harus ada 3 buah kemiri
1. Harap siapkan Sedikit kencur
1. Jangan lupa 1 buah tomat
1. Diperlukan  Penyedap rasa (garam, gula, micin, kaldu ayam)




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica-rica kemangi:

1. Ungkep ayam kurang lebih 20menit sampai ayam empuk
1. Lalu goreng ayam stengah matang
1. Tumis semua bumbu halus sampai wangi masukan daun jeruk, daun salam, sereh dan tomat tambahkan sedikit air sisa rebusan tadi
1. Lalu masukan ayam aduk-aduk tambahkan penyedap rasa (garam, gula, micin, kaldu ayam)
1. Masak ayam sampai air nya menyusut lalu terakhir masukan kemangi




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
