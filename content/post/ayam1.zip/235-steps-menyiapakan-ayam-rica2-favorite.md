---
description: "Steps menyiapakan Ayam rica2 Favorite"
title: "Steps menyiapakan Ayam rica2 Favorite"
slug: 235-steps-menyiapakan-ayam-rica2-favorite
date: 2020-09-08T01:15:23.838Z
image: https://img-global.cpcdn.com/recipes/2fd4bd88da492783/751x532cq70/ayam-rica2-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2fd4bd88da492783/751x532cq70/ayam-rica2-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2fd4bd88da492783/751x532cq70/ayam-rica2-foto-resep-utama.jpg
author: Floyd Pittman
ratingvalue: 4.9
reviewcount: 24466
recipeingredient:
- "1 ekor ayam pejantan  ayam kampung"
- " A Bumbu blender agak kasar "
- "10 cabai keriting merah"
- "10 cabai rawit merah"
- "8 bawang merah"
- " B Bumbu ulek halus "
- "4 kemiri sangrai"
- " C Bumbu cemplung "
- "5 butir bawang merah iris tipis"
- "2 ruas jari jahe"
- "2 ruas jari lengkuas"
- "1 buah serai"
- "1 sdt kunyit bubuk agar warna lebih kinclong"
- " D Bumbu daun "
- "2 lbr daun pandan simpul"
- "5 lbr daun jeruk sobek2"
- " Bumbu penyedap  1 sdt garam 1 sdt kaldu jamur"
- "500 ml kaldu ayam atau air biasa"
- " Masukan terakhir "
- "seikat daun kemangi"
- "1 buah jeruk nipis peras airnya"
recipeinstructions:
- "Cuci hingga bersih ayam, tiriskan. Tambahkan 1 sendok teh garam dan air jeruk nipis, remas dan marinasi selama 15 menit."
- "Goreng ayam dengan sedikit minyak, hingga setengah matang / permukaan sedikit kecoklatan. Tiriskan dan sisihkan."
- "Tumis semua bahan hingga harum, Masukan ayam, aduk rata dan tambahkan 500 ml air kaldu agar ayam tidak kering. Masukan garam, kaldu jamur (gula). Masak hingga mendidih, kecilkan api masak hingga ayam matang (sekitar 20 menit). Tambahkan air jika proses masak belum selesai"
- "Sesaat sebelum matikan api, tambahkan kemangi dan air jeruk nipis. Siap dihidangkan. Jangan masak terlalu kering, sisahkan sedikit kuah agar nyemek2 istilahnya"
categories:
- Recipe
tags:
- ayam
- rica2

katakunci: ayam rica2 
nutrition: 104 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica2](https://img-global.cpcdn.com/recipes/2fd4bd88da492783/751x532cq70/ayam-rica2-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang patut kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica2 yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Indonesia

Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica. Resep ayam rica rica merupakan masakan selera pedas dari daerah manado. Kita masak Ayam Rica-Rica aja yuk.

Kehangatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam rica2 untuk keluarga. Momen makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang dapat anda praktekkan salah satunya ayam rica2 yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica2 tanpa harus bersusah payah.
Berikut ini resep Ayam rica2 yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 21 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica2:

1. Harap siapkan 1 ekor ayam pejantan / ayam kampung
1. Jangan lupa  A. Bumbu blender agak kasar :
1. Jangan lupa 10 cabai keriting merah
1. Tambah 10 cabai rawit merah
1. Harus ada 8 bawang merah
1. Harus ada  B. Bumbu ulek halus :
1. Jangan lupa 4 kemiri (sangrai)
1. Tambah  C. Bumbu cemplung :
1. Dibutuhkan 5 butir bawang merah, iris tipis
1. Harap siapkan 2 ruas jari jahe
1. Tambah 2 ruas jari lengkuas
1. Dibutuhkan 1 buah serai
1. Diperlukan 1 sdt kunyit bubuk (agar warna lebih kinclong)
1. Jangan lupa  D. Bumbu daun :
1. Siapkan 2 lbr daun pandan, simpul
1. Dibutuhkan 5 lbr daun jeruk, sobek2
1. Tambah  Bumbu penyedap : 1 sdt garam, 1 sdt kaldu jamur
1. Siapkan 500 ml kaldu ayam (atau air biasa)
1. Diperlukan  Masukan terakhir :
1. Harap siapkan seikat daun kemangi
1. Siapkan 1 buah jeruk nipis, peras airnya


Tak hanya ayam, anda juga bisa memasak. Satu di antaranya adalah menu rica-rica ayam. Rica-rica merupakan olahan khas Manado yang memiliki rasa pedas dan gurih. Rica-rica (or sometimes simply called rica) is a type of Southeast Asian hot and spicy bumbu (spice mixture) found in Manado cuisine of North Sulawesi, Indonesia. 

<!--inarticleads2-->

##### Cara membuat  Ayam rica2:

1. Cuci hingga bersih ayam, tiriskan. Tambahkan 1 sendok teh garam dan air jeruk nipis, remas dan marinasi selama 15 menit.
1. Goreng ayam dengan sedikit minyak, hingga setengah matang / permukaan sedikit kecoklatan. Tiriskan dan sisihkan.
1. Tumis semua bahan hingga harum, Masukan ayam, aduk rata dan tambahkan 500 ml air kaldu agar ayam tidak kering. Masukan garam, kaldu jamur (gula). Masak hingga mendidih, kecilkan api masak hingga ayam matang (sekitar 20 menit). Tambahkan air jika proses masak belum selesai
1. Sesaat sebelum matikan api, tambahkan kemangi dan air jeruk nipis. Siap dihidangkan. Jangan masak terlalu kering, sisahkan sedikit kuah agar nyemek2 istilahnya


Rica-rica merupakan olahan khas Manado yang memiliki rasa pedas dan gurih. Rica-rica (or sometimes simply called rica) is a type of Southeast Asian hot and spicy bumbu (spice mixture) found in Manado cuisine of North Sulawesi, Indonesia. Rica-rica uses much chopped or ground red and green chili peppers, bird&#39;s eye chili, shallots, garlic, ginger, and a pinch of salt and sugar. Bumbu rica-rica khas Manado bisa dipadukan dengan aneka bahan, seperti ayam. Ayam rica-rica adalah salah satu makanan pedas dari kota Manado, ibukota provinsi Sulawesi Utara. 

Demikianlah cara membuat ayam rica2 yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan terbukti, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
