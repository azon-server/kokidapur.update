---
description: "Resep : Ayam Rica-Rica minggu ini"
title: "Resep : Ayam Rica-Rica minggu ini"
slug: 219-resep-ayam-rica-rica-minggu-ini
date: 2020-11-02T12:40:45.570Z
image: https://img-global.cpcdn.com/recipes/907770010c66f8a4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/907770010c66f8a4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/907770010c66f8a4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Theodore Ramos
ratingvalue: 4.7
reviewcount: 25815
recipeingredient:
- "1 kg Ayam"
- "4 lembar Daun Salam"
- "2 batang Sereh"
- "3 sdm Kecap Manis"
- "Secukupnya Garam"
- "Secukupnya Gula"
- "Secukupnya Penyedap optional"
- "Secukupnya Minyak untuk menumis"
- "Secukupnya Air"
- " Bumbu Halus"
- "10 siung Bawang Putih"
- "7 siung Bawang Merah"
- "5 buah Cabai Rawit Merah jumlahnya sesuai selera"
- "5 buah Cabai Merah Besar jumlahnya sesuai selera"
- "1 ruas besar Kunyit"
- "1 ruas Jahe"
- "10 butir Kemiri"
- "1/2 sdt Merica"
- "1 ruas kecil Lengkuas iris tipis"
- "10 lembar Daun Jeruk"
recipeinstructions:
- "Haluskan semua bahan Bumbu Halus."
- "Tumis Bumbu Halus, Daun Salam dan Sereh hingga harum dan layu."
- "Masukkan Ayam, aduk hingga rata. Kemudian masukan Air secukupnya, aduk kembali."
- "Tambahkan Kecap Manis, Garam, Gula dan Penyedap."
- "Kemudian masak hingga ayam matang."
- "Setelah ayam matang. Angkat dan Sajikan."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 163 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/907770010c66f8a4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang harus kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica-rica yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Kita



Kedekatan keluarga dapat didapat dengan cara mudah. Diantaranya adalah memasak Ayam Rica-Rica untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang bisa anda buat salah satunya ayam rica-rica yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica:

1. Diperlukan 1 kg Ayam
1. Tambah 4 lembar Daun Salam
1. Dibutuhkan 2 batang Sereh
1. Harap siapkan 3 sdm Kecap Manis
1. Harus ada Secukupnya Garam
1. Dibutuhkan Secukupnya Gula
1. Harap siapkan Secukupnya Penyedap (optional)
1. Harus ada Secukupnya Minyak untuk menumis
1. Harus ada Secukupnya Air
1. Jangan lupa  Bumbu Halus:
1. Diperlukan 10 siung Bawang Putih
1. Harap siapkan 7 siung Bawang Merah
1. Harap siapkan 5 buah Cabai Rawit Merah (jumlahnya sesuai selera)
1. Harap siapkan 5 buah Cabai Merah Besar (jumlahnya sesuai selera)
1. Harap siapkan 1 ruas besar Kunyit
1. Diperlukan 1 ruas Jahe
1. Jangan lupa 10 butir Kemiri
1. Tambah 1/2 sdt Merica
1. Tambah 1 ruas kecil Lengkuas, iris tipis
1. Diperlukan 10 lembar Daun Jeruk




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-Rica:

1. Haluskan semua bahan Bumbu Halus.
1. Tumis Bumbu Halus, Daun Salam dan Sereh hingga harum dan layu.
1. Masukkan Ayam, aduk hingga rata. Kemudian masukan Air secukupnya, aduk kembali.
1. Tambahkan Kecap Manis, Garam, Gula dan Penyedap.
1. Kemudian masak hingga ayam matang.
1. Setelah ayam matang. Angkat dan Sajikan.




Demikianlah cara membuat ayam rica-rica yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan cepat, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
