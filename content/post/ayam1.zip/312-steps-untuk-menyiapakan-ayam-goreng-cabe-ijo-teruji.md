---
description: "Steps untuk menyiapakan Ayam Goreng Cabe Ijo Teruji"
title: "Steps untuk menyiapakan Ayam Goreng Cabe Ijo Teruji"
slug: 312-steps-untuk-menyiapakan-ayam-goreng-cabe-ijo-teruji
date: 2020-08-10T23:01:11.935Z
image: https://img-global.cpcdn.com/recipes/943ee5821fa556fc/751x532cq70/ayam-goreng-cabe-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/943ee5821fa556fc/751x532cq70/ayam-goreng-cabe-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/943ee5821fa556fc/751x532cq70/ayam-goreng-cabe-ijo-foto-resep-utama.jpg
author: Leah Ruiz
ratingvalue: 4.2
reviewcount: 29930
recipeingredient:
- "1/2 ekor ayampotong2"
- "Secukupnya garam dan kaldu bubuk"
- " Bumbu marinasi ayam "
- "3 siung bwg putih"
- "1/2 ruas jahe"
- "Secukupnya garam"
- " Bumbu halus "
- "10 bh cabe ijo besar"
- "Secukupnya cabe rawit ijo"
- "3 siung bwg putih"
- "3 siung bwg merah"
- "2 bh tomat ijo kecil"
recipeinstructions:
- "Lumuri ayam dengan bumbu marinasi diamkan 30menit (aku 1jam). Kemudian goreng dengan api kecil supaya matang merata."
- "Rebus bumbu halus lalu ulek kasar. Kemudian tumis beri garam dan kaldu bubuk,tes rasa yaa."
- "Masukkan ayam goreng kedalam bumbu,aduk rata. Sajikan."
categories:
- Recipe
tags:
- ayam
- goreng
- cabe

katakunci: ayam goreng cabe 
nutrition: 124 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Goreng Cabe Ijo](https://img-global.cpcdn.com/recipes/943ee5821fa556fc/751x532cq70/ayam-goreng-cabe-ijo-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau enak. Karasteristik kuliner Nusantara ayam goreng cabe ijo yang kaya dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Keharmonisan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Goreng Cabe Ijo untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang bisa anda coba salah satunya ayam goreng cabe ijo yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam goreng cabe ijo tanpa harus bersusah payah.
Berikut ini resep Ayam Goreng Cabe Ijo yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Cabe Ijo:

1. Diperlukan 1/2 ekor ayam,potong2
1. Harap siapkan Secukupnya garam dan kaldu bubuk
1. Harap siapkan  Bumbu marinasi ayam :
1. Harus ada 3 siung bwg putih
1. Tambah 1/2 ruas jahe
1. Siapkan Secukupnya garam
1. Siapkan  Bumbu halus :
1. Siapkan 10 bh cabe ijo besar
1. Diperlukan Secukupnya cabe rawit ijo
1. Diperlukan 3 siung bwg putih
1. Dibutuhkan 3 siung bwg merah
1. Siapkan 2 bh tomat ijo kecil




<!--inarticleads2-->

##### Langkah membuat  Ayam Goreng Cabe Ijo:

1. Lumuri ayam dengan bumbu marinasi diamkan 30menit (aku 1jam). Kemudian goreng dengan api kecil supaya matang merata.
1. Rebus bumbu halus lalu ulek kasar. Kemudian tumis beri garam dan kaldu bubuk,tes rasa yaa.
1. Masukkan ayam goreng kedalam bumbu,aduk rata. Sajikan.




Demikianlah cara membuat ayam goreng cabe ijo yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan terbukti, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
