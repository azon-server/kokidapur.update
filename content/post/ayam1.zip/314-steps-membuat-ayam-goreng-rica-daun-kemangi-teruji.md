---
description: "Steps membuat Ayam Goreng Rica Daun Kemangi Teruji"
title: "Steps membuat Ayam Goreng Rica Daun Kemangi Teruji"
slug: 314-steps-membuat-ayam-goreng-rica-daun-kemangi-teruji
date: 2021-01-16T04:26:29.984Z
image: https://img-global.cpcdn.com/recipes/136d826f42a57334/751x532cq70/ayam-goreng-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/136d826f42a57334/751x532cq70/ayam-goreng-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/136d826f42a57334/751x532cq70/ayam-goreng-rica-daun-kemangi-foto-resep-utama.jpg
author: Georgie Barnes
ratingvalue: 4.1
reviewcount: 10318
recipeingredient:
- "1/2 ekor ayam ungkep dulu pake bumbu instan setelah itu goreng agak kering"
- "3 ikat daun kemangi petik daunnya saja"
- "1 buah tomat iris dadu"
- "4 tangkai daun bawang potong"
- "1/2 bagian lemon"
- "1 batang Sereh"
- " Bumbu halus"
- "4 siung bawang merah"
- "3 siung bawang putih"
- "10 cabe rawit keriting"
- "2 cabe merah"
- "10 cabe rawit jika kurang pedas boleh di tambahkan sesuai selera"
recipeinstructions:
- "Tuang minyak. Tunggu hingga panas. Tumis sereh dan bumbu halus hingga harum, masukan daun bawang."
- "Tambahan garam, gula pasir, Penyedap rasa, koreksi rasa sesuai selera."
- "Masukan ayam yang sudah di goreng ke dalam bumbu. Tambah perasan lemon sedikit saja. Tambhahkan air sedikit saja. Tunggu sampe agak surut airnya"
- "Masukan tomat dan juga daun kemangi. Oseng sebentar dan matikan api."
- "Selesai dan siap di nikmati dengan nasi hangat"
categories:
- Recipe
tags:
- ayam
- goreng
- rica

katakunci: ayam goreng rica 
nutrition: 267 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT53M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Goreng Rica Daun Kemangi](https://img-global.cpcdn.com/recipes/136d826f42a57334/751x532cq70/ayam-goreng-rica-daun-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau renyah. Karasteristik kuliner Nusantara ayam goreng rica daun kemangi yang kaya dengan bumbu memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kedekatan rumah tangga dapat diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam Goreng Rica Daun Kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang bisa anda coba salah satunya ayam goreng rica daun kemangi yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep ayam goreng rica daun kemangi tanpa harus bersusah payah.
Seperti resep Ayam Goreng Rica Daun Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 12 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Rica Daun Kemangi:

1. Harap siapkan 1/2 ekor ayam (ungkep dulu pake bumbu instan, setelah itu goreng agak kering)
1. Diperlukan 3 ikat daun kemangi (petik daunnya saja)
1. Dibutuhkan 1 buah tomat (iris dadu)
1. Diperlukan 4 tangkai daun bawang (potong)
1. Tambah 1/2 bagian lemon
1. Harap siapkan 1 batang Sereh
1. Jangan lupa  Bumbu halus
1. Harus ada 4 siung bawang merah
1. Harus ada 3 siung bawang putih
1. Harus ada 10 cabe rawit keriting
1. Jangan lupa 2 cabe merah
1. Tambah 10 cabe rawit (jika kurang pedas boleh di tambahkan sesuai selera)




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Goreng Rica Daun Kemangi:

1. Tuang minyak. Tunggu hingga panas. Tumis sereh dan bumbu halus hingga harum, masukan daun bawang.
1. Tambahan garam, gula pasir, Penyedap rasa, koreksi rasa sesuai selera.
1. Masukan ayam yang sudah di goreng ke dalam bumbu. Tambah perasan lemon sedikit saja. Tambhahkan air sedikit saja. Tunggu sampe agak surut airnya
1. Masukan tomat dan juga daun kemangi. Oseng sebentar dan matikan api.
1. Selesai dan siap di nikmati dengan nasi hangat




Demikianlah cara membuat ayam goreng rica daun kemangi yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan teruji, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
