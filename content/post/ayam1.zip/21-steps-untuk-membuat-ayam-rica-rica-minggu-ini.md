---
description: "Steps untuk membuat Ayam rica-rica minggu ini"
title: "Steps untuk membuat Ayam rica-rica minggu ini"
slug: 21-steps-untuk-membuat-ayam-rica-rica-minggu-ini
date: 2020-09-14T03:13:13.908Z
image: https://img-global.cpcdn.com/recipes/31a71d73b4478561/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/31a71d73b4478561/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/31a71d73b4478561/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Derek Sharp
ratingvalue: 4.9
reviewcount: 15821
recipeingredient:
- "300 gr dada ayam fillet bisa diganti bagian ayam lainnyapotong dadu"
- "2 ruas jari kunyithaluskan"
- "1 sdt garam"
- "2 ruas jari lengkuasgeprek"
- "1 batang seraigeprek"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "2 batang daun bawangiris"
- "2 sdt gula"
- "1 sdt garam"
- "1/2 sdt merica"
- "secukupnya Air"
- " Bumbu halus blender"
- "3 siung bawang putih"
- "5 siung bawang merah"
- "10 buah cabe merah"
- "6 buah rawit merah"
- "1 ruas jahe"
- "2 butir kemiri"
recipeinstructions:
- "Lumuri ayam dengan garam+kunyit,aduk rata dan diamkan selama 15-20 menit, lalu goreng hingga kuning keemasan,angkat dan sisihkan"
- "Tumis bumbu halus hingga wangi"
- "Masukkan serai+daun jeruk+daun salam+lengkuas,aduk rata"
- "Masukkan air,masak hingga mendidih lalu masukkan ayam,aduk rata"
- "Taburi gula +garam+merica,aduk rata dan masak hingga air menyusut dan bumbu meresap. angkat dan sajikan dengan taburan irisan daun bawang😊"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 197 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam rica-rica](https://img-global.cpcdn.com/recipes/31a71d73b4478561/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga empuk. Ciri kuliner Indonesia ayam rica-rica yang kaya dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga bisa diperoleh dengan cara sederhana. Diantaranya adalah memasak Ayam rica-rica untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

Resep Ayam Rica Rica Bahan: Daging Ayam Lemon juice Chicken powder Garam. Bawang merah Bawang putih Cabe Jahe Serai Daun jeruk purut Daun kucai. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang dapat anda contoh salah satunya ayam rica-rica yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam rica-rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica:

1. Jangan lupa 300 gr dada ayam fillet (bisa diganti bagian ayam lainnya),potong dadu
1. Jangan lupa 2 ruas jari kunyit,haluskan
1. Dibutuhkan 1 sdt garam
1. Diperlukan 2 ruas jari lengkuas,geprek
1. Siapkan 1 batang serai,geprek
1. Dibutuhkan 2 lembar daun jeruk
1. Tambah 2 lembar daun salam
1. Diperlukan 2 batang daun bawang,iris
1. Diperlukan 2 sdt gula
1. Siapkan 1 sdt garam
1. Dibutuhkan 1/2 sdt merica
1. Diperlukan secukupnya Air
1. Dibutuhkan  Bumbu halus (blender):
1. Diperlukan 3 siung bawang putih
1. Dibutuhkan 5 siung bawang merah
1. Dibutuhkan 10 buah cabe merah
1. Siapkan 6 buah rawit merah
1. Siapkan 1 ruas jahe
1. Tambah 2 butir kemiri


Cara pembuatan ayam rica-rica tidaklah sulit. Dibutuhkan bahan-bahan seperti daun jeruk, serai, dan daun pandan agar aromanya menjadi kuat dan khas. Tak hanya ayam, anda juga bisa memasak. Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica-rica:

1. Lumuri ayam dengan garam+kunyit,aduk rata dan diamkan selama 15-20 menit, lalu goreng hingga kuning keemasan,angkat dan sisihkan
1. Tumis bumbu halus hingga wangi
1. Masukkan serai+daun jeruk+daun salam+lengkuas,aduk rata
1. Masukkan air,masak hingga mendidih lalu masukkan ayam,aduk rata
1. Taburi gula +garam+merica,aduk rata dan masak hingga air menyusut dan bumbu meresap. angkat dan sajikan dengan taburan irisan daun bawang😊


Tak hanya ayam, anda juga bisa memasak. Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. I really don&#39;t know how it was started but if you take away chili peppers from my life… I&#39;m gone! Chef S Table Ayam Rica Rica. Mukbang Nasi Sama Soup Dan Ayam Rica Makanenakindonesia. 

Demikianlah cara membuat ayam rica-rica yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan teruji, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
