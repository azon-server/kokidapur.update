---
description: "Langkah membuat Ayam Goreng Laos Sempurna"
title: "Langkah membuat Ayam Goreng Laos Sempurna"
slug: 419-langkah-membuat-ayam-goreng-laos-sempurna
date: 2021-01-28T02:08:46.724Z
image: https://img-global.cpcdn.com/recipes/d769538626ce5aeb/751x532cq70/ayam-goreng-laos-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d769538626ce5aeb/751x532cq70/ayam-goreng-laos-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d769538626ce5aeb/751x532cq70/ayam-goreng-laos-foto-resep-utama.jpg
author: Dylan Page
ratingvalue: 5
reviewcount: 39994
recipeingredient:
- "1/2 kg ayam"
- "4 bawang putih"
- "5 bawang merah"
- "3 buah lengkuas utuh pilih yg agak muda"
- "1 sdt ketumbar"
- "2 kemiri sangrai dulu"
- "4 cm kunyit"
- "3 cm jahe"
- "1 sdt lada bubuk"
- "1/2 sdm garam sesui selera"
- " Bumbu cemplung"
- "1 batang sereh"
- "3 lembar daun jeruk sobek"
- "2 lembar daun salam"
recipeinstructions:
- "Haluskan semua bumbu. Lengkuas bisa di parut/blender biar tangan ga capek ya bun😁"
- "Siapkan wajan, masukkan potongan ayam. Bumbu halus dan bumbu cemplung."
- "Tambahkan air sampai semua ayam terendam. Kemudian tutup wajan. Cek sesekalinya bun, ungkep sampai air menyusut."
- "Apabila air sudah menyusut, goreng ayam dalam minyak panas. Goreng juga sisa bumbu ungkep kemudian tabirkan diatas ayam goreng."
- "Ayam goreng siap dinikmati."
categories:
- Recipe
tags:
- ayam
- goreng
- laos

katakunci: ayam goreng laos 
nutrition: 187 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT56M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Goreng Laos](https://img-global.cpcdn.com/recipes/d769538626ce5aeb/751x532cq70/ayam-goreng-laos-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga empuk. Karasteristik kuliner Indonesia ayam goreng laos yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Keharmonisan keluarga dapat didapat dengan cara mudah. Salah satunya adalah memasak Ayam Goreng Laos untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang dapat anda buat salah satunya ayam goreng laos yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep ayam goreng laos tanpa harus bersusah payah.
Seperti resep Ayam Goreng Laos yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Laos:

1. Diperlukan 1/2 kg ayam
1. Diperlukan 4 bawang putih
1. Diperlukan 5 bawang merah
1. Jangan lupa 3 buah lengkuas utuh (pilih yg agak muda)
1. Siapkan 1 sdt ketumbar
1. Dibutuhkan 2 kemiri (sangrai dulu)
1. Tambah 4 cm kunyit
1. Diperlukan 3 cm jahe
1. Tambah 1 sdt lada bubuk
1. Siapkan 1/2 sdm garam (sesui selera)
1. Dibutuhkan  Bumbu cemplung
1. Diperlukan 1 batang sereh
1. Jangan lupa 3 lembar daun jeruk, sobek²
1. Dibutuhkan 2 lembar daun salam




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Laos:

1. Haluskan semua bumbu. Lengkuas bisa di parut/blender biar tangan ga capek ya bun😁
1. Siapkan wajan, masukkan potongan ayam. Bumbu halus dan bumbu cemplung.
1. Tambahkan air sampai semua ayam terendam. Kemudian tutup wajan. Cek sesekalinya bun, ungkep sampai air menyusut.
1. Apabila air sudah menyusut, goreng ayam dalam minyak panas. Goreng juga sisa bumbu ungkep kemudian tabirkan diatas ayam goreng.
1. Ayam goreng siap dinikmati.




Demikianlah cara membuat ayam goreng laos yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat mudah dan teruji, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
