---
description: "Langkah untuk menyiapakan 34.1~ Ayam Goreng Lengkuas Homemade"
title: "Langkah untuk menyiapakan 34.1~ Ayam Goreng Lengkuas Homemade"
slug: 368-langkah-untuk-menyiapakan-341-ayam-goreng-lengkuas-homemade
date: 2021-01-07T08:21:51.578Z
image: https://img-global.cpcdn.com/recipes/109041f11e4f137e/751x532cq70/341-ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/109041f11e4f137e/751x532cq70/341-ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/109041f11e4f137e/751x532cq70/341-ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Isabelle Harris
ratingvalue: 4.2
reviewcount: 25694
recipeingredient:
- "9 potong ayam"
- "150 gr lengkuas parut"
- " Bumbu halus"
- "12 siung bawang merah"
- "6 siung bawang putih"
- "4 biji kemiri"
- "2 buah kunyit seukuran 2 ruas jari"
- "1 ruas jahe"
- "1 sdm ketumbar bubuk"
- "Secukupnya air"
- " Bumbu Ungkep"
- "3 lembar daun salam sobek2"
- "6 lembar daun jeruk sobek2"
- "2 batang sereh geprek"
- "2 sdm garam"
- "1.5 sdm gula"
- "Secukupnya merica bubuk"
- "500 ml air secukupnya"
recipeinstructions:
- "Cuci bersih ayam, saya pakai paha ayam 9 potong"
- "Masukkan air, bumbu halus, ayam, daun salam, daun jeruk, sereh, dan lengkuas parut. Aduk rata"
- "Beri gula, garam, merica bubuk dan penyedap rasa. Masak dengan api sedang cenderung kecil hingga air menyusut."
- "Saring air ungkepan dan ampas lengkuas. Pisahkan. Goreng untuk taburan ayamnya."
- "Goreng ayam dan sajikan dengan taburan lengkuas goreng"
categories:
- Recipe
tags:
- 341
- ayam
- goreng

katakunci: 341 ayam goreng 
nutrition: 138 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT46M"
recipeyield: "2"
recipecategory: Dessert

---


![34.1~ Ayam Goreng Lengkuas](https://img-global.cpcdn.com/recipes/109041f11e4f137e/751x532cq70/341-ayam-goreng-lengkuas-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga empuk. Ciri khas kuliner Nusantara 34.1~ ayam goreng lengkuas yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan keluarga bisa diperoleh dengan cara simple. Diantaranya adalah membuat makanan 34.1~ Ayam Goreng Lengkuas untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda praktekkan salah satunya 34.1~ ayam goreng lengkuas yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep 34.1~ ayam goreng lengkuas tanpa harus bersusah payah.
Seperti resep 34.1~ Ayam Goreng Lengkuas yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 34.1~ Ayam Goreng Lengkuas:

1. Diperlukan 9 potong ayam
1. Siapkan 150 gr lengkuas (parut)
1. Diperlukan  Bumbu halus
1. Harus ada 12 siung bawang merah
1. Diperlukan 6 siung bawang putih
1. Jangan lupa 4 biji kemiri
1. Harap siapkan 2 buah kunyit seukuran 2 ruas jari
1. Dibutuhkan 1 ruas jahe
1. Harus ada 1 sdm ketumbar bubuk
1. Dibutuhkan Secukupnya air
1. Harap siapkan  Bumbu Ungkep
1. Harus ada 3 lembar daun salam (sobek2)
1. Tambah 6 lembar daun jeruk (sobek2)
1. Dibutuhkan 2 batang sereh (geprek)
1. Diperlukan 2 sdm garam
1. Dibutuhkan 1.5 sdm gula
1. Harap siapkan Secukupnya merica bubuk
1. Jangan lupa 500 ml air (secukupnya)




<!--inarticleads2-->

##### Bagaimana membuat  34.1~ Ayam Goreng Lengkuas:

1. Cuci bersih ayam, saya pakai paha ayam 9 potong
1. Masukkan air, bumbu halus, ayam, daun salam, daun jeruk, sereh, dan lengkuas parut. Aduk rata
1. Beri gula, garam, merica bubuk dan penyedap rasa. Masak dengan api sedang cenderung kecil hingga air menyusut.
1. Saring air ungkepan dan ampas lengkuas. Pisahkan. Goreng untuk taburan ayamnya.
1. Goreng ayam dan sajikan dengan taburan lengkuas goreng




Demikianlah cara membuat 34.1~ ayam goreng lengkuas yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan terbukti, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
