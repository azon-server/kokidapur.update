---
description: "Resep : Ayam rica rica kemangi Favorite"
title: "Resep : Ayam rica rica kemangi Favorite"
slug: 151-resep-ayam-rica-rica-kemangi-favorite
date: 2020-10-21T07:55:12.155Z
image: https://img-global.cpcdn.com/recipes/c49b580a86e5e3c4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c49b580a86e5e3c4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c49b580a86e5e3c4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Scott Pierce
ratingvalue: 4.6
reviewcount: 10477
recipeingredient:
- "1/2 ekor ayam boiler"
- "1 ikat kemangi"
- " Bumbu semua di ulek ya kecuali lengkuas"
- "3 siung bawang putih dan 5 siung bawang merah"
- "1/2 cm jahe"
- "1/4 kunyit"
- " Lengkuas ukuran sedanggeprek"
- "25 cabe rawitsesuai selera"
- "10 cabe merahboleh lebih"
- "2 buah Tobat boleh di skip"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
recipeinstructions:
- "Potong ayam menjadi 4 bagian"
- "Didihkan air rebus ayam hingga matang (tanpa bumbu)"
- "Goreng ayam asal (jangan sampai kuning)"
- "Tumis bumbu halus,masukkan lengkuas yg sdh di geprek,daun salam,daun jeruk"
- "Tambahkan garam,royco,dan gula(masakan sy kebanyakan pake gula karena biar rasa asin,gurih nya seimbang)"
- "Masukkan ayam,tambahkan sedikit air,"
- "Air sdh mulai mengering koreksi rasa,"
- "Terakhir masukkan kemangi,yg sdh di cuci bersih."
- "Ayam rica rica siap di sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 160 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/c49b580a86e5e3c4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau gurih. Ciri kuliner Nusantara ayam rica rica kemangi yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam rica rica kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang bisa anda contoh salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 9 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Harap siapkan 1/2 ekor ayam boiler
1. Siapkan 1 ikat kemangi,
1. Harus ada  Bumbu semua di ulek ya kecuali lengkuas
1. Harap siapkan 3 siung bawang putih dan 5 siung bawang merah
1. Diperlukan 1/2 cm jahe,
1. Dibutuhkan 1/4 kunyit
1. Jangan lupa  Lengkuas ukuran sedang(geprek)
1. Diperlukan 25 cabe rawit(sesuai selera)
1. Diperlukan 10 cabe merah(boleh lebih)
1. Diperlukan 2 buah Tobat (boleh di skip)
1. Harus ada 3 lembar daun salam
1. Diperlukan 3 lembar daun jeruk




<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica kemangi:

1. Potong ayam menjadi 4 bagian
1. Didihkan air rebus ayam hingga matang (tanpa bumbu)
1. Goreng ayam asal (jangan sampai kuning)
1. Tumis bumbu halus,masukkan lengkuas yg sdh di geprek,daun salam,daun jeruk
1. Tambahkan garam,royco,dan gula(masakan sy kebanyakan pake gula karena biar rasa asin,gurih nya seimbang)
1. Masukkan ayam,tambahkan sedikit air,
1. Air sdh mulai mengering koreksi rasa,
1. Terakhir masukkan kemangi,yg sdh di cuci bersih.
1. Ayam rica rica siap di sajikan




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan cepat, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
