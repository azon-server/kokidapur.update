---
description: "Steps membuat Ayam Rica Rica Kemangi Luar biasa"
title: "Steps membuat Ayam Rica Rica Kemangi Luar biasa"
slug: 204-steps-membuat-ayam-rica-rica-kemangi-luar-biasa
date: 2020-08-20T16:51:06.320Z
image: https://img-global.cpcdn.com/recipes/b45ed06922704b0a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b45ed06922704b0a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b45ed06922704b0a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Logan Ball
ratingvalue: 4.7
reviewcount: 48771
recipeingredient:
- " Ayam Tepung"
- "6 sdm Tepung Maizena"
- "3 sdm Tepung Beras"
- "500 gram Ayam saya pakai ayam dada dipotong kecil"
- " Bumbu Ulek Kasar"
- "10 buah Cabai Merah Keriting"
- "5 buah Cabai Rawit"
- "6 siung Bawang Merah"
- "3 siung Bawang Putih"
- " Bumbu Kasar"
- "4 lembar Daun Jeruk dibuang tulangnya iris tipis"
- "3 lembar Daun Salam"
- "1 batang Sereh digeprek"
- " Bumbu Pelengkap"
- " Garam"
- " Gula Merah"
- " Penyedap rasa"
- "10 ml Air"
- "1 ikat Daun Kemangi"
recipeinstructions:
- "Tambahkan garam pada ayam, lalu diamkan selama 15 menit."
- "Campurkan Tepung Maizena dan Tepung Beras, ditambah dengan garam dan penyedap secukupnya."
- "Lumuri ayam dengan campuran tepung maizena, lalu goreng hingga matang."
- "Ulek bumbu halus kasar, lalu tumis menggunakan api sedang."
- "Tambahkan 10 ml air"
- "Tambahkan garam, gula merah dan penyedap rasa sesuai selera."
- "Masukkan bumbu kasar, hingga air surut."
- "Masukkan ayam ke dalam bumbu, aduk hingga rata."
- "Tambahkan daun kemangi, aduk rata. Diamkan hingga bumbu meresap kurang lebih 3 menit."
- "Ayam siap disajikaaan 🎉"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 224 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/b45ed06922704b0a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau enak. Ciri kuliner Indonesia ayam rica rica kemangi yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kehangatan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica Rica Kemangi untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang bisa anda buat salah satunya ayam rica rica kemangi yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 10 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi:

1. Harap siapkan  Ayam Tepung
1. Harus ada 6 sdm Tepung Maizena
1. Harus ada 3 sdm Tepung Beras
1. Dibutuhkan 500 gram Ayam (saya pakai ayam dada, dipotong kecil)
1. Dibutuhkan  Bumbu Ulek Kasar
1. Diperlukan 10 buah Cabai Merah Keriting
1. Jangan lupa 5 buah Cabai Rawit
1. Dibutuhkan 6 siung Bawang Merah
1. Dibutuhkan 3 siung Bawang Putih
1. Diperlukan  Bumbu Kasar
1. Diperlukan 4 lembar Daun Jeruk dibuang tulangnya, iris tipis
1. Dibutuhkan 3 lembar Daun Salam
1. Tambah 1 batang Sereh digeprek
1. Dibutuhkan  Bumbu Pelengkap
1. Tambah  Garam
1. Harus ada  Gula Merah
1. Diperlukan  Penyedap rasa
1. Harap siapkan 10 ml Air
1. Diperlukan 1 ikat Daun Kemangi




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Rica Kemangi:

1. Tambahkan garam pada ayam, lalu diamkan selama 15 menit.
1. Campurkan Tepung Maizena dan Tepung Beras, ditambah dengan garam dan penyedap secukupnya.
1. Lumuri ayam dengan campuran tepung maizena, lalu goreng hingga matang.
1. Ulek bumbu halus kasar, lalu tumis menggunakan api sedang.
1. Tambahkan 10 ml air
1. Tambahkan garam, gula merah dan penyedap rasa sesuai selera.
1. Masukkan bumbu kasar, hingga air surut.
1. Masukkan ayam ke dalam bumbu, aduk hingga rata.
1. Tambahkan daun kemangi, aduk rata. Diamkan hingga bumbu meresap kurang lebih 3 menit.
1. Ayam siap disajikaaan 🎉




Demikianlah cara membuat ayam rica rica kemangi yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat simple dan teruji, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
