---
description: "Steps untuk membuat Ayam rica-rica terupdate"
title: "Steps untuk membuat Ayam rica-rica terupdate"
slug: 116-steps-untuk-membuat-ayam-rica-rica-terupdate
date: 2020-08-09T14:07:55.349Z
image: https://img-global.cpcdn.com/recipes/d1173918d1cfab57/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d1173918d1cfab57/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d1173918d1cfab57/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Julian Glover
ratingvalue: 5
reviewcount: 9357
recipeingredient:
- "1/2 kg ayam potong kecil"
- " Bumbu halus"
- "5 buah cabe merah"
- "5 buah cabe rawit merah"
- "8 siung bawang merah"
- "2 siung bawang putih"
- "1 ruas jari jahe"
- "1 ruas jari kunyit"
- "5 buah kemiri"
- "1 ruas jari lengkuas"
- "1/2 batang serehputihnya saja"
- "1/2 sdt ketumbar bubuk"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "1 ikat daun kemangi"
recipeinstructions:
- "Rebus ayam terlebih dahulu"
- "Tumis bumbu halus hingga harum, masukkan daun jeruk dan salam"
- "Masukkan ayam dan beri sedikit air, masukkan garam, gula, penyedap rasa,, masak hingga air agak menyusut"
- "Koreksi rasa,, masukkan daun kemangi dan matang"
- "Siapkan dengan nasi hangat👍"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 155 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT43M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica-rica](https://img-global.cpcdn.com/recipes/d1173918d1cfab57/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang setidaknya kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica-rica yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara



Kedekatan keluarga bisa didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam rica-rica untuk orang di rumah. Momen makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang dapat anda buat salah satunya ayam rica-rica yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam rica-rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 15 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica:

1. Jangan lupa 1/2 kg ayam potong kecil
1. Siapkan  Bumbu halus:
1. Harap siapkan 5 buah cabe merah
1. Harus ada 5 buah cabe rawit merah
1. Tambah 8 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Tambah 1 ruas jari jahe
1. Tambah 1 ruas jari kunyit
1. Tambah 5 buah kemiri
1. Tambah 1 ruas jari lengkuas
1. Harap siapkan 1/2 batang sereh(putihnya saja)
1. Jangan lupa 1/2 sdt ketumbar bubuk
1. Jangan lupa 2 lembar daun jeruk
1. Harus ada 2 lembar daun salam
1. Diperlukan 1 ikat daun kemangi




<!--inarticleads2-->

##### Langkah membuat  Ayam rica-rica:

1. Rebus ayam terlebih dahulu
1. Tumis bumbu halus hingga harum, masukkan daun jeruk dan salam
1. Masukkan ayam dan beri sedikit air, masukkan garam, gula, penyedap rasa,, masak hingga air agak menyusut
1. Koreksi rasa,, masukkan daun kemangi dan matang
1. Siapkan dengan nasi hangat👍




Demikianlah cara membuat ayam rica-rica yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan terbukti, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
