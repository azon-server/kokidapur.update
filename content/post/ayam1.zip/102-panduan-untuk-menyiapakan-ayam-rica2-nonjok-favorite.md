---
description: "Panduan untuk menyiapakan Ayam rica2 nonjok Favorite"
title: "Panduan untuk menyiapakan Ayam rica2 nonjok Favorite"
slug: 102-panduan-untuk-menyiapakan-ayam-rica2-nonjok-favorite
date: 2020-11-17T07:22:28.434Z
image: https://img-global.cpcdn.com/recipes/d4bd489156f8d0d0/751x532cq70/ayam-rica2-nonjok-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d4bd489156f8d0d0/751x532cq70/ayam-rica2-nonjok-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d4bd489156f8d0d0/751x532cq70/ayam-rica2-nonjok-foto-resep-utama.jpg
author: Matthew George
ratingvalue: 4
reviewcount: 12139
recipeingredient:
- "1 kg ayam"
- "7 butir Bawang merah"
- "5 siung Bawang putih"
- "1/4 kg Cabe setan"
- " Cabe besar 5 aja"
- "5 butir Kemiri"
- "secukupnya Kunyitjahelaos"
- " Daun salamdaun jeruk"
- " Sere"
- " Ketumbarmerica"
- " Daun kemangi"
recipeinstructions:
- "Potong ayam menjadi Beberapa bagian, lalu Cuci Bersih sisihkan"
- "Blander semua Bumbu, kecuali daun jeruk,sere,salam Laos dan kemangi"
- "Lalu setelah bumbu dihaluskan, tulus sampai bumbu Terasa wangi dan sedap,setelah tu masukan Laos yg sudah digeprek, dan daun jeruk, daun salam.. Kemudian setelah matang, masukan Ayam aduk2 sampai tercampur rata,kemudian Beri air dan tutup.."
- "Setelah setengah matang, masuk ana sere, tapi sebelumnya iris2 dulu ya si sere kecil2 aja.. Masak hingga matang,, setelah dirasa matang.. Masukan daun kemangi dan siap dihidangkan. Selamat mencoba.."
categories:
- Recipe
tags:
- ayam
- rica2
- nonjok

katakunci: ayam rica2 nonjok 
nutrition: 208 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT58M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam rica2 nonjok](https://img-global.cpcdn.com/recipes/d4bd489156f8d0d0/751x532cq70/ayam-rica2-nonjok-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita jaga karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica2 nonjok yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Kita

Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica. Rasa pedas, gurih dan empuk daging ayamnya terbukti sangat cocok disajikan bersama nasi dalam. Assalamualaikum sahabatku semuanya trma ksih yg sllu mndukung chanelku smga klian smua tambah sukses selalu doaku yg trbaik untuk kalian smua,,Aamiin.

Kedekatan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ayam rica2 nonjok untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang bisa anda coba salah satunya ayam rica2 nonjok yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep ayam rica2 nonjok tanpa harus bersusah payah.
Berikut ini resep Ayam rica2 nonjok yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 11 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica2 nonjok:

1. Tambah 1 kg ayam
1. Dibutuhkan 7 butir Bawang merah
1. Harap siapkan 5 siung Bawang putih
1. Dibutuhkan 1/4 kg Cabe setan
1. Dibutuhkan  Cabe besar 5 aja
1. Diperlukan 5 butir Kemiri
1. Harap siapkan secukupnya Kunyit,jahe,laos
1. Diperlukan  Daun salam,daun jeruk
1. Tambah  Sere
1. Tambah  Ketumbar,merica
1. Harap siapkan  Daun kemangi


Inilah rahasia bumbu masakan ayam rica rica dan petunjuk cara membuat rica rica ayam. Resep ayam rica rica merupakan masakan selera pedas Resep rica rica sendiri sebenarnya tidak harus menggunakan bahan daging ayam saja. Cita rasa pedas menjadi ciri khas resep yang tergabung. Tips Ayam Rica Rica yang Sambalnya Medok dan Mantap ala restoran. 

<!--inarticleads2-->

##### Instruksi membuat  Ayam rica2 nonjok:

1. Potong ayam menjadi Beberapa bagian, lalu Cuci Bersih sisihkan
1. Blander semua Bumbu, kecuali daun jeruk,sere,salam Laos dan kemangi
1. Lalu setelah bumbu dihaluskan, tulus sampai bumbu Terasa wangi dan sedap,setelah tu masukan Laos yg sudah digeprek, dan daun jeruk, daun salam.. Kemudian setelah matang, masukan Ayam aduk2 sampai tercampur rata,kemudian Beri air dan tutup..
1. Setelah setengah matang, masuk ana sere, tapi sebelumnya iris2 dulu ya si sere kecil2 aja.. Masak hingga matang,, setelah dirasa matang.. Masukan daun kemangi dan siap dihidangkan. Selamat mencoba..


Cita rasa pedas menjadi ciri khas resep yang tergabung. Tips Ayam Rica Rica yang Sambalnya Medok dan Mantap ala restoran. Untuk cabai, kita bisa menggunakan kombinasi cabai rawit, cabai keriting dan cabai merah besar. Kalau suka rica yang pedas, perbanyak saja jumlah cabai rawitnya. Bumbu rica-rica khas Manado bisa dipadukan dengan aneka bahan, seperti ayam. 

Demikianlah cara membuat ayam rica2 nonjok yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
