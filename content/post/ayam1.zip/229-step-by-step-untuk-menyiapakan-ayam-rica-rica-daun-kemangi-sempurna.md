---
description: "Step-by-Step untuk menyiapakan Ayam rica rica daun kemangi Sempurna"
title: "Step-by-Step untuk menyiapakan Ayam rica rica daun kemangi Sempurna"
slug: 229-step-by-step-untuk-menyiapakan-ayam-rica-rica-daun-kemangi-sempurna
date: 2020-10-14T07:28:04.952Z
image: https://img-global.cpcdn.com/recipes/e3e34915e9f22d00/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e3e34915e9f22d00/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e3e34915e9f22d00/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Ellen Griffin
ratingvalue: 4.4
reviewcount: 43232
recipeingredient:
- "500 gr ayam bagian dadatulangkulit"
- " bawang merah"
- " bawang putih"
- "3 buah cabe merah"
- "sesuai selera cabe rawit"
- "3 ruas jahe ukuran kecil"
- "1 ruas lengkuas ukuran sedang"
- "3 ruas kunyit ukuran kecil"
- "1 batang daun sereh"
- "3 lembar daun jeruk"
- "1 lembar daun salam"
- "2 ikat daun kemangi"
- " gula"
- " garam"
- " air"
recipeinstructions:
- "Cuci bersih ayam yang sudah di potong menjadi kecil, kemudian rebus dengan panci tertutup supaya cepat empuk (rebus kurang lebih sekitar 20-30 menit) angkat lalu tiriskan"
- "Haluskan semua bahan, kecuali jahe, lengkuas, daun sereh di geprek"
- "Panaskan minyak sedikit, kemudian masukkan semua bumbu yang sudah dihaluskan, tumis sampai wangi lalu masukkan jahe, lengkuas, daun salam, dan daun sereh, tumis kembali sampai semua bumbu tercampur"
- "Tambahkan air secukupnya, kemudian masukkan ayam yang sudah di rebus tadi, beri garam dan gula, aduk rata tunggu sampai mendidih"
- "Masukkan daun kemangi, aduk merata sampai semua bumbu meresap ke ayam, tunggu air sampai agak menyusut sedikit, koreksi rasa lalu siap disajikan 😁"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 109 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica rica daun kemangi](https://img-global.cpcdn.com/recipes/e3e34915e9f22d00/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis dan enak. Ciri khas makanan Nusantara ayam rica rica daun kemangi yang penuh dengan rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kehangatan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam rica rica daun kemangi untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang dapat anda coba salah satunya ayam rica rica daun kemangi yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica rica daun kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica daun kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica daun kemangi:

1. Jangan lupa 500 gr ayam, bagian dada/tulang/kulit
1. Harap siapkan  bawang merah
1. Siapkan  bawang putih
1. Jangan lupa 3 buah cabe merah
1. Harap siapkan sesuai selera cabe rawit
1. Harus ada 3 ruas jahe ukuran kecil
1. Dibutuhkan 1 ruas lengkuas ukuran sedang
1. Dibutuhkan 3 ruas kunyit ukuran kecil
1. Tambah 1 batang daun sereh
1. Harus ada 3 lembar daun jeruk
1. Siapkan 1 lembar daun salam
1. Dibutuhkan 2 ikat daun kemangi
1. Siapkan  gula
1. Diperlukan  garam
1. Tambah  air




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica rica daun kemangi:

1. Cuci bersih ayam yang sudah di potong menjadi kecil, kemudian rebus dengan panci tertutup supaya cepat empuk (rebus kurang lebih sekitar 20-30 menit) angkat lalu tiriskan
1. Haluskan semua bahan, kecuali jahe, lengkuas, daun sereh di geprek
1. Panaskan minyak sedikit, kemudian masukkan semua bumbu yang sudah dihaluskan, tumis sampai wangi lalu masukkan jahe, lengkuas, daun salam, dan daun sereh, tumis kembali sampai semua bumbu tercampur
1. Tambahkan air secukupnya, kemudian masukkan ayam yang sudah di rebus tadi, beri garam dan gula, aduk rata tunggu sampai mendidih
1. Masukkan daun kemangi, aduk merata sampai semua bumbu meresap ke ayam, tunggu air sampai agak menyusut sedikit, koreksi rasa lalu siap disajikan 😁




Demikianlah cara membuat ayam rica rica daun kemangi yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan cepat, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
