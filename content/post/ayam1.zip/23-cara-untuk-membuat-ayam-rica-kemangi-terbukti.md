---
description: "Cara untuk membuat Ayam rica kemangi Terbukti"
title: "Cara untuk membuat Ayam rica kemangi Terbukti"
slug: 23-cara-untuk-membuat-ayam-rica-kemangi-terbukti
date: 2020-09-25T17:36:38.362Z
image: https://img-global.cpcdn.com/recipes/7969cf0328000380/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7969cf0328000380/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7969cf0328000380/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Blanche Wright
ratingvalue: 4.9
reviewcount: 20436
recipeingredient:
- "1 ekor ayam"
- " Jeruk nipis"
- "secukupnya Kemangi"
- "8 cabai merah keriting"
- "5 cabai rawit merah opsional kalau mau ekstra pedas"
- "8 bawang merah"
- "5 bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "4 kemiri"
- "1 lb daun jeruk"
- "1 lb daun salam"
- "2 batang serai"
- " Garam"
- "1 Bks Royco"
recipeinstructions:
- "Cuci bersih ayam Baluri ayam dengan jeruk nipis, diamkan selama 10 menit lalu cuci bersih kembali"
- "Blender halus, kemiri, cabai, duo bawang, jahe dan kunyit lalu tumis dengan minyak panas hingga harum"
- "Iris tipis daun jeruk dan sereh, masukkan ke dalam tumisan bumbu halus tambahkan daun salam, Royco dan garam lalu koreksi rasa"
- "Jika bumbu sudah matang masukan ayam aduk hingga seluruh ayam terkena bumbu lalu beri air hingga ayam terendam"
- "Diamkan hingga air menyusut, sesekali aduk ayam agar matang merata"
- "Setelah hampir matang masukan kemangi dan tunggu hingga layu, selesai"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 189 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/7969cf0328000380/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang patut kita jaga karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica kemangi yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa ciri khas yang merupakan keragaman Indonesia

Kedekatan rumah tangga bisa ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam rica kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang dapat anda coba salah satunya ayam rica kemangi yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi:

1. Dibutuhkan 1 ekor ayam
1. Dibutuhkan  Jeruk nipis
1. Tambah secukupnya Kemangi
1. Harap siapkan 8 cabai merah keriting
1. Dibutuhkan 5 cabai rawit merah (opsional kalau mau ekstra pedas)
1. Jangan lupa 8 bawang merah
1. Diperlukan 5 bawang putih
1. Harap siapkan 1 ruas jahe
1. Harap siapkan 1 ruas kunyit
1. Diperlukan 4 kemiri
1. Siapkan 1 lb daun jeruk
1. Diperlukan 1 lb daun salam
1. Dibutuhkan 2 batang serai
1. Harus ada  Garam
1. Tambah 1 Bks Royco




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica kemangi:

1. Cuci bersih ayam Baluri ayam dengan jeruk nipis, diamkan selama 10 menit lalu cuci bersih kembali
1. Blender halus, kemiri, cabai, duo bawang, jahe dan kunyit lalu tumis dengan minyak panas hingga harum
1. Iris tipis daun jeruk dan sereh, masukkan ke dalam tumisan bumbu halus tambahkan daun salam, Royco dan garam lalu koreksi rasa
1. Jika bumbu sudah matang masukan ayam aduk hingga seluruh ayam terkena bumbu lalu beri air hingga ayam terendam
1. Diamkan hingga air menyusut, sesekali aduk ayam agar matang merata
1. Setelah hampir matang masukan kemangi dan tunggu hingga layu, selesai




Demikianlah cara membuat ayam rica kemangi yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat simple dan teruji, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
