---
description: "Cara singkat menyiapakan Ayam Rica Rica Luar biasa"
title: "Cara singkat menyiapakan Ayam Rica Rica Luar biasa"
slug: 150-cara-singkat-menyiapakan-ayam-rica-rica-luar-biasa
date: 2020-09-10T11:41:28.716Z
image: https://img-global.cpcdn.com/recipes/345523f77c64a666/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/345523f77c64a666/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/345523f77c64a666/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Ralph Patterson
ratingvalue: 4.8
reviewcount: 36948
recipeingredient:
- "1/2 ekor ayam"
- "1 sereh"
- "1 daun kunyit"
- "1 salam"
- "2 daun jeruk"
- "1 ruas lengkuas"
- "3 ikat kemangi"
- "1 daun bawang"
- "1/2 sdm gula"
- "1,5 sdt garam"
- "1/2 sdt kaldu jamur"
- " Bumbu halus"
- "5 bawang merah"
- "3 bawang putih"
- "1 ruas kunyit"
- "2 cabe merah besar"
- "5 cabe merah keriting"
- "5 cabe rawit merah"
- "1 ruas jahe"
- "3 kemiri"
recipeinstructions:
- "Siapkan bahan, haluskan bumbu halus, lalu tumis dengan sedikit minyak sampai harum."
- "Masukkan bumbu utuh biarkan layu sebentar lalu masukkan ayam dan disusul air."
- "Beri garam gula kalau perlu kaldu bubuk, lalu masak sampai ayam empuk dan bumbu meresap, boleh tambahkan air lagi.Lalu masukkan kemangi dan daun bawang, aduk sebentar, cek rasa, angkat. Siap dinikmati."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 268 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT31M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/345523f77c64a666/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica rica yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Indonesia



Keharmonisan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica Rica untuk keluarga. Momen makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda praktekkan salah satunya ayam rica rica yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica:

1. Dibutuhkan 1/2 ekor ayam
1. Siapkan 1 sereh
1. Tambah 1 daun kunyit
1. Harus ada 1 salam
1. Siapkan 2 daun jeruk
1. Harap siapkan 1 ruas lengkuas
1. Harus ada 3 ikat kemangi
1. Dibutuhkan 1 daun bawang
1. Diperlukan 1/2 sdm gula
1. Tambah 1,5 sdt garam
1. Siapkan 1/2 sdt kaldu jamur
1. Siapkan  Bumbu halus
1. Siapkan 5 bawang merah
1. Diperlukan 3 bawang putih
1. Dibutuhkan 1 ruas kunyit
1. Jangan lupa 2 cabe merah besar
1. Siapkan 5 cabe merah keriting
1. Diperlukan 5 cabe rawit merah
1. Tambah 1 ruas jahe
1. Harus ada 3 kemiri




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Rica:

1. Siapkan bahan, haluskan bumbu halus, lalu tumis dengan sedikit minyak sampai harum.
1. Masukkan bumbu utuh biarkan layu sebentar lalu masukkan ayam dan disusul air.
1. Beri garam gula kalau perlu kaldu bubuk, lalu masak sampai ayam empuk dan bumbu meresap, boleh tambahkan air lagi.Lalu masukkan kemangi dan daun bawang, aduk sebentar, cek rasa, angkat. Siap dinikmati.




Demikianlah cara membuat ayam rica rica yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan teruji, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
