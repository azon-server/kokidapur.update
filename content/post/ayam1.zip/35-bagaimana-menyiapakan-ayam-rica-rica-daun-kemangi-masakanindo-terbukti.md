---
description: "Bagaimana menyiapakan Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo Terbukti"
title: "Bagaimana menyiapakan Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo Terbukti"
slug: 35-bagaimana-menyiapakan-ayam-rica-rica-daun-kemangi-masakanindo-terbukti
date: 2020-09-07T13:19:57.568Z
image: https://img-global.cpcdn.com/recipes/55574b38704c0a24/751x532cq70/ayam-rica-rica-daun-kemangi-🇮🇩-masakanindo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/55574b38704c0a24/751x532cq70/ayam-rica-rica-daun-kemangi-🇮🇩-masakanindo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/55574b38704c0a24/751x532cq70/ayam-rica-rica-daun-kemangi-🇮🇩-masakanindo-foto-resep-utama.jpg
author: Seth Atkins
ratingvalue: 4.8
reviewcount: 46049
recipeingredient:
- "300 gr dada ayam dapat 5 potong"
- " Bumbu halus"
- "6 siung bawang merah"
- "2 siung bawang putih"
- "10 buah cabe merah keriting"
- "5 buah cabe rawit merah"
- "2 butir kemiri"
- "1 ruas kunyit"
- "1 ruas jahe aku skip"
- " Bahan tumis"
- "1 batang serai geprek"
- "5 lembar daun jeruk"
- "1 ruas lengkuas"
- "Secukupnya air matang"
- "1 ikat kemangi boleh lebih"
- "1 lembar daun bawang iris"
- "1 sdm gula merah"
- "1 sdt kaldu jamur"
- "1 sdt gula garam sesuaikan ya"
recipeinstructions:
- "Rebus ayam / goreng. Kalau mau mentahan, direbus bersamaan dengan bumbu tumis juga bisa. Kalo aku direbus dulu😉"
- "Blender bahan Bumbu Halus"
- "Panaskan minyak. Tumis Bahan tumis. Lalu tuang Bumbu halus. Masak bersamaan hingga harum, tambahkan sedikit air, gula merah, garam dan penyedap."
- "Masukkan ayam dan daun kemangi. Aduk2 hingga tercampur semua. Tambahkan daun bawang iris. Aduk rata, masak hingga air surut."
- "Test rasa. Kalau kurang, tambah gula garam ya."
- "Siap dihidangkan🥰 medok banget warnanya btw. Tapi pedesnya gak seberapa. Karena aku banyakin cabe keriting, bukan rawitnya."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 171 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo](https://img-global.cpcdn.com/recipes/55574b38704c0a24/751x532cq70/ayam-rica-rica-daun-kemangi-🇮🇩-masakanindo-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica rica daun kemangi 🇮🇩 #masakanindo yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Kita



Kedekatan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah memasak Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda contoh salah satunya ayam rica rica daun kemangi 🇮🇩 #masakanindo yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica rica daun kemangi 🇮🇩 #masakanindo tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo:

1. Jangan lupa 300 gr dada ayam (dapat 5 potong)
1. Harus ada  Bumbu halus
1. Siapkan 6 siung bawang merah
1. Tambah 2 siung bawang putih
1. Harus ada 10 buah cabe merah keriting
1. Jangan lupa 5 buah cabe rawit merah
1. Jangan lupa 2 butir kemiri
1. Diperlukan 1 ruas kunyit
1. Harap siapkan 1 ruas jahe (aku skip)
1. Jangan lupa  Bahan tumis
1. Jangan lupa 1 batang serai (geprek)
1. Harus ada 5 lembar daun jeruk
1. Jangan lupa 1 ruas lengkuas
1. Harap siapkan Secukupnya air matang
1. Siapkan 1 ikat kemangi (boleh lebih)
1. Harus ada 1 lembar daun bawang iris
1. Harus ada 1 sdm gula merah
1. Dibutuhkan 1 sdt kaldu jamur
1. Dibutuhkan 1 sdt gula garam (sesuaikan ya)




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo:

1. Rebus ayam / goreng. Kalau mau mentahan, direbus bersamaan dengan bumbu tumis juga bisa. Kalo aku direbus dulu😉
1. Blender bahan Bumbu Halus
1. Panaskan minyak. Tumis Bahan tumis. Lalu tuang Bumbu halus. Masak bersamaan hingga harum, tambahkan sedikit air, gula merah, garam dan penyedap.
1. Masukkan ayam dan daun kemangi. Aduk2 hingga tercampur semua. Tambahkan daun bawang iris. Aduk rata, masak hingga air surut.
1. Test rasa. Kalau kurang, tambah gula garam ya.
1. Siap dihidangkan🥰 medok banget warnanya btw. Tapi pedesnya gak seberapa. Karena aku banyakin cabe keriting, bukan rawitnya.




Demikianlah cara membuat ayam rica rica daun kemangi 🇮🇩 #masakanindo yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat gampang dan terbukti, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
