---
description: "Resep : Lauk : Ayam Rica-rica tanpa Minyak Homemade"
title: "Resep : Lauk : Ayam Rica-rica tanpa Minyak Homemade"
slug: 154-resep-lauk-ayam-rica-rica-tanpa-minyak-homemade
date: 2020-09-23T18:05:59.972Z
image: https://img-global.cpcdn.com/recipes/844ce0568b78fc55/751x532cq70/lauk-ayam-rica-rica-tanpa-minyak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/844ce0568b78fc55/751x532cq70/lauk-ayam-rica-rica-tanpa-minyak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/844ce0568b78fc55/751x532cq70/lauk-ayam-rica-rica-tanpa-minyak-foto-resep-utama.jpg
author: Ina Gordon
ratingvalue: 4.5
reviewcount: 18063
recipeingredient:
- "200 gr ayam"
- "1 batang sereh geprek"
- "1 cm lengkuas"
- "1 cm jahe geprek"
- "1 lembar daun salam"
- "1 lembar daun jeruk pilih yg membentuk angka 8"
- "secukupnya Kemangi"
- "100 ml air"
- "secukupnya Kaldu jamur"
- " Bumbu Halus ditumbukdiblender"
- "2 siung bawang merah"
- "1 siung bawang putih"
- "1/2 butir kemiri"
- "1 cm kunyit"
- "sesuai selera Cabai merah keriting"
- "sesuai selera Cabai rawit"
- " Cabai perenggi 1 buah me"
recipeinstructions:
- "Masak air hingga matang menggunakan teflon anti lengket."
- "Masukkan bumbu halus, sereh, daun salam, daun jeruk, lengkuas, jahe. Masak hingga harum dan air sedikit berkurang."
- "Masukkan ayam. Aduk2. Masak hingga ayam matang (tidak perlu tambah air). Tambahkan kaldu jamur. Cek rasa. Air benar-benar mengental."
- "Masukkan daun kemangi, aduk-aduk."
- "Setelah matang, sip, dan mantap. Eh. Matikan kompor dan siap plating."
- "Santap ketika hangat. Cocok dimakan dengan nasi merah untuk diet. Pakai nasi bisa 2x makan. Makan langsung bisa langsung habis hihi."
categories:
- Recipe
tags:
- lauk
- 
- ayam

katakunci: lauk  ayam 
nutrition: 120 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dinner

---


![Lauk : Ayam Rica-rica tanpa Minyak](https://img-global.cpcdn.com/recipes/844ce0568b78fc55/751x532cq70/lauk-ayam-rica-rica-tanpa-minyak-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan empuk. Karasteristik makanan Nusantara lauk : ayam rica-rica tanpa minyak yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.


Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica. Rasa pedas, gurih dan empuk daging ayamnya terbukti sangat cocok disajikan bersama nasi dalam. Ayam Rica Rica Tanpa Minyak - Menu Diet Sehat Alami Biasanya masakan ayam rica rica dimasak tak lepas dari minyak goreng, namun dalam edisi menu diet sehat.

Kehangatan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah memasak Lauk : Ayam Rica-rica tanpa Minyak untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang bisa anda coba salah satunya lauk : ayam rica-rica tanpa minyak yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep lauk : ayam rica-rica tanpa minyak tanpa harus bersusah payah.
Berikut ini resep Lauk : Ayam Rica-rica tanpa Minyak yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Lauk : Ayam Rica-rica tanpa Minyak:

1. Diperlukan 200 gr ayam
1. Jangan lupa 1 batang sereh (geprek)
1. Dibutuhkan 1 cm lengkuas
1. Siapkan 1 cm jahe (geprek)
1. Dibutuhkan 1 lembar daun salam
1. Jangan lupa 1 lembar daun jeruk (pilih yg membentuk angka 8)
1. Tambah secukupnya Kemangi
1. Jangan lupa 100 ml air
1. Siapkan secukupnya Kaldu jamur
1. Diperlukan  Bumbu Halus (ditumbuk/diblender)
1. Siapkan 2 siung bawang merah
1. Harap siapkan 1 siung bawang putih
1. Harus ada 1/2 butir kemiri
1. Harap siapkan 1 cm kunyit
1. Diperlukan sesuai selera Cabai merah keriting
1. Jangan lupa sesuai selera Cabai rawit
1. Diperlukan  Cabai perenggi 1 buah (me)


Dengan resep sederhana berikut ini, kamu bisa membuat resep ayam rica-rica khas Manado di rumah. Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Dengan aroma yang menggoda dibumbui dengan rempah-rempah pilihan. 

<!--inarticleads2-->

##### Cara membuat  Lauk : Ayam Rica-rica tanpa Minyak:

1. Masak air hingga matang menggunakan teflon anti lengket.
1. Masukkan bumbu halus, sereh, daun salam, daun jeruk, lengkuas, jahe. Masak hingga harum dan air sedikit berkurang.
1. Masukkan ayam. Aduk2. Masak hingga ayam matang (tidak perlu tambah air). Tambahkan kaldu jamur. Cek rasa. Air benar-benar mengental.
1. Masukkan daun kemangi, aduk-aduk.
1. Setelah matang, sip, dan mantap. Eh. Matikan kompor dan siap plating.
1. Santap ketika hangat. Cocok dimakan dengan nasi merah untuk diet. Pakai nasi bisa 2x makan. Makan langsung bisa langsung habis hihi.


Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Dengan aroma yang menggoda dibumbui dengan rempah-rempah pilihan. Ayam rica-rica ini biasanya disajikan sebagai lauk bersama nasi putih. Masukkan telur yang sudah digoreng, aduk rata. Tambahkan air, lalu masak hingga bumbu meresap. 

Demikianlah cara membuat lauk : ayam rica-rica tanpa minyak yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan teruji, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
