---
description: "Steps menyiapakan Ayam rica - rica terupdate"
title: "Steps menyiapakan Ayam rica - rica terupdate"
slug: 18-steps-menyiapakan-ayam-rica-rica-terupdate
date: 2020-11-14T09:35:56.521Z
image: https://img-global.cpcdn.com/recipes/2dd5e6993fbdca8a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2dd5e6993fbdca8a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2dd5e6993fbdca8a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Jeremiah Barnes
ratingvalue: 4.5
reviewcount: 30365
recipeingredient:
- "1 ekor ayampotongcuci bersih beri perasan jeruk nipis  garam"
- "5 lembar daun jeruk"
- "1 batang serai geprek"
- "2 ikat daun kemangi sy skip"
- "secukupnya Garam"
- " Bumbu Halus"
- "10 buah cabe merah keriting sesuai selera sy 4 cb mrh besar"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "1 buah tomat"
- "Seruas jahe"
- "Seruas kunyit"
- "2 sendok teh ketumbar sangrai dulu"
- "50 gram gula merah"
- "8 buah cabe rawit merah biarkan utuh sy skip"
- "secukupnya Air"
recipeinstructions:
- "Goreng ayam sampai berwarna kecoklatan tapi jangan sampai kering, sisihkan"
- "Tumis bumbu halus lalu masukkan sere, daun jeruk, kemudian masukkan ayam aduk rata beri garam dan beri air secukupnya"
- "Biarkan mendidih dengan api sedang, masak sampai ayam empuk dan air menyusut, lalu koreksi rasa"
- "Matikan api, angkat ayam"
- "Sajikan dengan nasi putih hangat"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 114 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica - rica](https://img-global.cpcdn.com/recipes/2dd5e6993fbdca8a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga empuk. Ciri makanan Indonesia ayam rica - rica yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Ayam rica - rica untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang dapat anda buat salah satunya ayam rica - rica yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep ayam rica - rica tanpa harus bersusah payah.
Berikut ini resep Ayam rica - rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica - rica:

1. Siapkan 1 ekor ayam,potong²cuci bersih beri perasan jeruk nipis &amp; garam
1. Harap siapkan 5 lembar daun jeruk
1. Dibutuhkan 1 batang serai, geprek
1. Diperlukan 2 ikat daun kemangi, sy skip
1. Tambah secukupnya Garam
1. Harap siapkan  Bumbu Halus
1. Dibutuhkan 10 buah cabe merah keriting (sesuai selera), sy 4 cb mrh besar
1. Harus ada 8 siung bawang merah
1. Jangan lupa 5 siung bawang putih
1. Tambah 1 buah tomat
1. Harus ada Seruas jahe
1. Tambah Seruas kunyit
1. Dibutuhkan 2 sendok teh ketumbar sangrai dulu
1. Diperlukan 50 gram gula merah
1. Harus ada 8 buah cabe rawit merah (biarkan utuh), sy skip
1. Jangan lupa secukupnya Air




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica - rica:

1. Goreng ayam sampai berwarna kecoklatan tapi jangan sampai kering, sisihkan
1. Tumis bumbu halus lalu masukkan sere, daun jeruk, kemudian masukkan ayam aduk rata beri garam dan beri air secukupnya
1. Biarkan mendidih dengan api sedang, masak sampai ayam empuk dan air menyusut, lalu koreksi rasa
1. Matikan api, angkat ayam
1. Sajikan dengan nasi putih hangat




Demikianlah cara membuat ayam rica - rica yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
