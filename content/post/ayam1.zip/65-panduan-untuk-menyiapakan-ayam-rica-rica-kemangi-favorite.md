---
description: "Panduan untuk menyiapakan Ayam Rica-rica Kemangi Favorite"
title: "Panduan untuk menyiapakan Ayam Rica-rica Kemangi Favorite"
slug: 65-panduan-untuk-menyiapakan-ayam-rica-rica-kemangi-favorite
date: 2020-09-12T22:32:01.799Z
image: https://img-global.cpcdn.com/recipes/f0b137ae18b5a89e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f0b137ae18b5a89e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f0b137ae18b5a89e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Louisa Kelly
ratingvalue: 4.4
reviewcount: 42817
recipeingredient:
- "1/2 kg Ayam Potong"
- "1/2 potong jeruk nipis"
- " bumbu halus"
- "3 buah bawang putih"
- "5 buah bawang merah"
- "5 buah cabe merah besar"
- "10 buah cabe rawit kecil sesuai selera"
- "1/2 cm jahe"
- "Sedikit kunyit"
- "3 buah kemiri"
- " bahan tumis"
- "secukupnya Garam"
- "secukupnya Gula"
- " Penyedap rasa"
- "4 lembar daun jeruk"
- "2 buah sereh digeprek"
- "1/2 ruas lengkuas"
- "2 lembar daun salam"
- "1 ikat daun kemangi"
recipeinstructions:
- "Cuci bersih ayam, kemudian lumuri ayam dengan jeruk nipis. Diamkan selama 5-10 menit.kemudian goreng setengah matang."
- "Blender semua bumbu halus, kemudian tambahan minyak, tumis bumbu hingga wangi.masukkan bahan tumis, aduk rata hingga bumbu matang pekat."
- "Kemudian masukkan ayam potong, aduk sebentar. Tambahkan air secukupnya. Setelah itu tambahkan gula, garam dan penyedap rasa."
- "Tutup sebentar biarkan meresap. Setelah meresap koreksi rasa, matikan kompor dan masukkan daun kemangi."
- "Siap untuk dinikmati..."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 163 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/f0b137ae18b5a89e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan keistimewahan yang merupakan keragaman Indonesia

Kehangatan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica-rica Kemangi untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang bisa anda buat salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Kemangi:

1. Diperlukan 1/2 kg Ayam Potong
1. Tambah 1/2 potong jeruk nipis
1. Tambah  bumbu halus
1. Tambah 3 buah bawang putih
1. Dibutuhkan 5 buah bawang merah
1. Harap siapkan 5 buah cabe merah besar
1. Siapkan 10 buah cabe rawit kecil (sesuai selera)
1. Harus ada 1/2 cm jahe
1. Tambah Sedikit kunyit
1. Jangan lupa 3 buah kemiri
1. Harap siapkan  bahan tumis
1. Siapkan secukupnya Garam
1. Jangan lupa secukupnya Gula
1. Jangan lupa  Penyedap rasa
1. Harap siapkan 4 lembar daun jeruk
1. Siapkan 2 buah sereh (digeprek)
1. Dibutuhkan 1/2 ruas lengkuas
1. Harus ada 2 lembar daun salam
1. Harus ada 1 ikat daun kemangi




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-rica Kemangi:

1. Cuci bersih ayam, kemudian lumuri ayam dengan jeruk nipis. Diamkan selama 5-10 menit.kemudian goreng setengah matang.
1. Blender semua bumbu halus, kemudian tambahan minyak, tumis bumbu hingga wangi.masukkan bahan tumis, aduk rata hingga bumbu matang pekat.
1. Kemudian masukkan ayam potong, aduk sebentar. Tambahkan air secukupnya. Setelah itu tambahkan gula, garam dan penyedap rasa.
1. Tutup sebentar biarkan meresap. Setelah meresap koreksi rasa, matikan kompor dan masukkan daun kemangi.
1. Siap untuk dinikmati...




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
