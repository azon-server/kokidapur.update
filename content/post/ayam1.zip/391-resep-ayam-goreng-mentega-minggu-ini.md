---
description: "Resep : Ayam Goreng Mentega minggu ini"
title: "Resep : Ayam Goreng Mentega minggu ini"
slug: 391-resep-ayam-goreng-mentega-minggu-ini
date: 2020-08-28T09:18:59.060Z
image: https://img-global.cpcdn.com/recipes/4780b90c80a09138/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4780b90c80a09138/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4780b90c80a09138/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg
author: Hilda Grant
ratingvalue: 4.3
reviewcount: 12668
recipeingredient:
- "500 gram ayam potong sesuai selera"
- "3 sdm mentegamargarine"
- "2 siung bawang putih cincang halus"
- "  Bumbu marinasi"
- "2 siung bawang putih parut"
- "1/4 sdt lada bubuk"
- "1 sdt garam"
- "  Bahan pelapis"
- "Secukupnya tepung bumbu"
- "  Bahan saus"
- "2 sdm kecap inggris saya skip"
- "2 sdm saus tiram"
- "2 sdm kecap asin"
- "1 sdm kecap manis"
- "2 sdm saos tomat"
- "1 sdt gula pasir"
- "Secukupnya kaldu bubuk dan merica bubuk"
- "100 ml air"
- "1 sdm maizena larutkan dengan sedikit air"
recipeinstructions:
- "Lumuri ayam dengan bumbu marinasi. Diamkan minimal 10 menit. Sisihkan."
- "Lumuri ayam dengan tepung bumbu hingga ayam rata tertutup tepung. Tidak perlu terlalu tebal tepungnya. Goreng dalam minyak banyak dan panas hingga matang, kuning keemasan."
- "Tumis 3 siung bawang putih hingga harum tambahkan semua saus dan air. Biarkan mendidih. Tambahkan larutan maizena, aduk hingga mengental, koreksi rasa."
- "Masukkan ayam goreng. Aduk hingga ayam tersalut saus. Taburi daun bawang. Angkat sajikan."
- "Tips: supaya lebih gurih pada saat menggoreng, tambahkan 1 sdm mentega pada minyak."
categories:
- Recipe
tags:
- ayam
- goreng
- mentega

katakunci: ayam goreng mentega 
nutrition: 204 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Goreng Mentega](https://img-global.cpcdn.com/recipes/4780b90c80a09138/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga empuk. Ciri masakan Nusantara ayam goreng mentega yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam Goreng Mentega untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang bisa anda buat salah satunya ayam goreng mentega yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep ayam goreng mentega tanpa harus bersusah payah.
Seperti resep Ayam Goreng Mentega yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Mentega:

1. Tambah 500 gram ayam, potong sesuai selera
1. Jangan lupa 3 sdm mentega/margarine
1. Diperlukan 2 siung bawang putih, cincang halus
1. Siapkan  📌 Bumbu marinasi:
1. Harap siapkan 2 siung bawang putih parut
1. Jangan lupa 1/4 sdt lada bubuk
1. Harap siapkan 1 sdt garam
1. Tambah  📌 Bahan pelapis:
1. Diperlukan Secukupnya tepung bumbu
1. Harap siapkan  📌 Bahan saus:
1. Harus ada 2 sdm kecap inggris (saya skip)
1. Diperlukan 2 sdm saus tiram
1. Jangan lupa 2 sdm kecap asin
1. Tambah 1 sdm kecap manis
1. Dibutuhkan 2 sdm saos tomat
1. Harus ada 1 sdt gula pasir
1. Dibutuhkan Secukupnya kaldu bubuk dan merica bubuk
1. Dibutuhkan 100 ml air
1. Jangan lupa 1 sdm maizena larutkan dengan sedikit air




<!--inarticleads2-->

##### Langkah membuat  Ayam Goreng Mentega:

1. Lumuri ayam dengan bumbu marinasi. Diamkan minimal 10 menit. Sisihkan.
1. Lumuri ayam dengan tepung bumbu hingga ayam rata tertutup tepung. Tidak perlu terlalu tebal tepungnya. Goreng dalam minyak banyak dan panas hingga matang, kuning keemasan.
1. Tumis 3 siung bawang putih hingga harum tambahkan semua saus dan air. Biarkan mendidih. Tambahkan larutan maizena, aduk hingga mengental, koreksi rasa.
1. Masukkan ayam goreng. Aduk hingga ayam tersalut saus. Taburi daun bawang. Angkat sajikan.
1. Tips: supaya lebih gurih pada saat menggoreng, tambahkan 1 sdm mentega pada minyak.




Demikianlah cara membuat ayam goreng mentega yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
