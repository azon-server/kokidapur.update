---
description: "Resep : Ayam Rica Rica Kemangi Teruji"
title: "Resep : Ayam Rica Rica Kemangi Teruji"
slug: 232-resep-ayam-rica-rica-kemangi-teruji
date: 2020-08-11T04:35:00.097Z
image: https://img-global.cpcdn.com/recipes/8b111a508e776f2c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8b111a508e776f2c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8b111a508e776f2c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Sophia Oliver
ratingvalue: 4
reviewcount: 6933
recipeingredient:
- "1 ekor ayam potong 8"
- " Bumbu halus "
- "5 siung bawang merah ukuran besar"
- "3 siung bawang putih ukuran besar"
- "10 buah cabe rawit merah ukuran besar bisa ganti cabe merah"
- "Sejempol kunyit"
- "Seruas jahe"
- " Ketumbar 1sd saya pakai yang bubuk"
- " Bahan pelengkap"
- "1 buah tomat potong kecil kecil"
- "2 lbr daun jeruk"
- "1 btg sere saya potong 2 kemudian di geprek"
- "Sejempol lengkuas di geprek"
- "1 genggam kemangi"
recipeinstructions:
- "Blender halus bumbu di atas lalu tumis bersama bahan pelengkap hingga harum dan menyatu"
- "Masukkan ayam lalu aduk aduk sampai bumbu Merata"
- "Tambahkan air sampai ayam tenggelam lalu masukkan tomat"
- "Masak hingga ayam empuk dan tomat hancur lalu tambahkan kemangi (saya pakai kemangi serbuk, akan lebih bagus kalau pakai kemangi utuh),garam,gula,kaldu jamur. Tunggu hingga layu dan air menyusut.."
- "Buang sereh dan lengkuas, masakan siap untuk disajikan.. 💕"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 272 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/8b111a508e776f2c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau renyah. Ciri kuliner Nusantara ayam rica rica kemangi yang penuh dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam Rica Rica Kemangi untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang bisa anda buat salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi:

1. Dibutuhkan 1 ekor ayam potong 8
1. Dibutuhkan  Bumbu halus :
1. Diperlukan 5 siung bawang merah ukuran besar
1. Harap siapkan 3 siung bawang putih ukuran besar
1. Siapkan 10 buah cabe rawit merah ukuran besar (bisa ganti cabe merah)
1. Harus ada Sejempol kunyit
1. Siapkan Seruas jahe
1. Harus ada  Ketumbar 1sd (saya pakai yang bubuk)
1. Harus ada  Bahan pelengkap
1. Dibutuhkan 1 buah tomat potong kecil kecil
1. Tambah 2 lbr daun jeruk
1. Dibutuhkan 1 btg sere (saya potong 2 kemudian di geprek)
1. Siapkan Sejempol lengkuas di geprek
1. Diperlukan 1 genggam kemangi




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Rica Kemangi:

1. Blender halus bumbu di atas lalu tumis bersama bahan pelengkap hingga harum dan menyatu
1. Masukkan ayam lalu aduk aduk sampai bumbu Merata
1. Tambahkan air sampai ayam tenggelam lalu masukkan tomat
1. Masak hingga ayam empuk dan tomat hancur lalu tambahkan kemangi (saya pakai kemangi serbuk, akan lebih bagus kalau pakai kemangi utuh),garam,gula,kaldu jamur. Tunggu hingga layu dan air menyusut..
1. Buang sereh dan lengkuas, masakan siap untuk disajikan.. 💕




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
