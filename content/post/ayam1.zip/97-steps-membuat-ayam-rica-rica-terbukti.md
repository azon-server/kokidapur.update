---
description: "Steps membuat Ayam Rica-Rica Terbukti"
title: "Steps membuat Ayam Rica-Rica Terbukti"
slug: 97-steps-membuat-ayam-rica-rica-terbukti
date: 2020-11-11T15:53:39.882Z
image: https://img-global.cpcdn.com/recipes/ad978b01f8e440c9/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ad978b01f8e440c9/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ad978b01f8e440c9/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Douglas Drake
ratingvalue: 4.6
reviewcount: 17147
recipeingredient:
- "500 gr ayam bagian paha dan sayap"
- "1 buah sereh geprek"
- "2 cm lengkuas geprek"
- "3 lembar daun salam"
- "2 sdt garam"
- "1/2 sdt gula"
- "2 sdt kaldu jamur"
- "secukupnya Minyak"
- "secukupnya Air"
- " Bumbu Halus "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "5 buah cabe merah"
- "15 buah cabe rawit"
- "2 cm kunyit"
- "2 cm jahe"
- "2 butir kemiri"
- " Tambahan "
- "1 ikat kemangi dipetik daunnya"
recipeinstructions:
- "Potong ayam sesuai selera, kucuri dengan jeruk kunci/nipis sekitar 10 menit, lalu rebus hingga empuk"
- "Goreng ayam setengah matang, lalu tiriskan"
- "Tumis bumbu halus hingga harum, masukkan sereh, lengkuas, daun salam, garam, gula, kaldu jamur"
- "Masukkan ayam, masak hingga meresap lalu tambahkan kemangi, aduk dan tes rasa"
- "Angkat dan sajikan selagi hangat, bumbu khas nusantara maknyos 😄"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 204 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/ad978b01f8e440c9/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica-rica yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan keistimewahan yang merupakan keragaman Kita



Kehangatan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica-Rica untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang dapat anda praktekkan salah satunya ayam rica-rica yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica:

1. Tambah 500 gr ayam (bagian paha dan sayap)
1. Siapkan 1 buah sereh, geprek
1. Harus ada 2 cm lengkuas, geprek
1. Jangan lupa 3 lembar daun salam
1. Harap siapkan 2 sdt garam
1. Jangan lupa 1/2 sdt gula
1. Harus ada 2 sdt kaldu jamur
1. Harus ada secukupnya Minyak
1. Tambah secukupnya Air
1. Siapkan  Bumbu Halus :
1. Jangan lupa 5 siung bawang merah
1. Harus ada 3 siung bawang putih
1. Harap siapkan 5 buah cabe merah
1. Harap siapkan 15 buah cabe rawit
1. Jangan lupa 2 cm kunyit
1. Siapkan 2 cm jahe
1. Tambah 2 butir kemiri
1. Diperlukan  Tambahan :
1. Tambah 1 ikat kemangi, dipetik daunnya




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-Rica:

1. Potong ayam sesuai selera, kucuri dengan jeruk kunci/nipis sekitar 10 menit, lalu rebus hingga empuk
1. Goreng ayam setengah matang, lalu tiriskan
1. Tumis bumbu halus hingga harum, masukkan sereh, lengkuas, daun salam, garam, gula, kaldu jamur
1. Masukkan ayam, masak hingga meresap lalu tambahkan kemangi, aduk dan tes rasa
1. Angkat dan sajikan selagi hangat, bumbu khas nusantara maknyos 😄




Demikianlah cara membuat ayam rica-rica yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan teruji, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
