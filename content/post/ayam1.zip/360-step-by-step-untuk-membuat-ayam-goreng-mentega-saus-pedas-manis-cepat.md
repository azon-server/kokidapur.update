---
description: "Step-by-Step untuk membuat Ayam goreng mentega (saus pedas manis) Cepat"
title: "Step-by-Step untuk membuat Ayam goreng mentega (saus pedas manis) Cepat"
slug: 360-step-by-step-untuk-membuat-ayam-goreng-mentega-saus-pedas-manis-cepat
date: 2020-08-31T16:43:22.510Z
image: https://img-global.cpcdn.com/recipes/bb001d7ffa79fd1e/751x532cq70/ayam-goreng-mentega-saus-pedas-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bb001d7ffa79fd1e/751x532cq70/ayam-goreng-mentega-saus-pedas-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bb001d7ffa79fd1e/751x532cq70/ayam-goreng-mentega-saus-pedas-manis-foto-resep-utama.jpg
author: Lizzie Logan
ratingvalue: 4
reviewcount: 10233
recipeingredient:
- "4 potong paha atas bawah ayam"
- "2 buah Bawang bombay di iris tipistipis"
- "1 buah Wortel besar dipotong sesuai selera"
- "5 siung bawang putih di cincang halus"
- "2 buah jeruk nipis"
- "1 sendok makan garam"
- "1 Sachet kecil merica bubuk"
- "5 sendok makan Saus tomat"
- "5 sendok makan saus sambal"
- "6 sendok makan kecap manis"
- "4 sendok makan kecap inggris"
- "3 siung baby paprika hanya optional kalau tidak dipakai juga gapapa moms"
- "1 sendok teh Kaldu jamur totole optional juga ya moms"
- " Mentega blueband"
recipeinstructions:
- "4 potong ayam di peras dengan jeruk nipis + balurkan garam biasa (himalayan salt juga boleh) lalu di diamkan 10menit."
- "Masukan minyak ke dalam panci sekiranya goreng ayam nya bisa tenggelam (biar merata sempurna). lalu bolak balik hingga warna ke emasan. Lalu jika sudah keemasan, saya tambahkan blueband di atas ayam tsb agar rasa blueband nya menyerap di daging dalam ayam."
- "Setelah ayam matang, tiriskan. Lalu masukan blueband 3 sendok ke dalam panci, dan tumis bawang putih + bawang bombay + baby paprika hingga wangi."
- "Setelah wangi, masukan campuran bumbu (Saus sambal, Saus tomat, Kecap inggris, Kecap manis, Merica 1 sachet) lalu aduk sampai merata. Setelah merata masukn wortel dan tambahkan air (saya 2gelas full air 500ml takarannya) lalu masukan wortel, dan masak hingga worlet setengah empuk."
- "Setelah semuanya sudah tercampur, beri air lagi 100ml lalu tuangkan, dan masukan ayam yang sudah di goreng ke dalam panci. masak hingga kuah berubah menjadi sedikit kental (jangan lupa cobaiin rasanya ya mom, takutnya selera masing2 beda jadi kalau ada yg kurang bisa di tambah). Lalu saya tuang kaldu jamur totole sedikit (ini optional). Lalu tunggu sampai mengental, dan matikan kompor."
- "Jadi deh, silahkan mencoba🤍 dijamin rasanya nagih.."
categories:
- Recipe
tags:
- ayam
- goreng
- mentega

katakunci: ayam goreng mentega 
nutrition: 182 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT31M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam goreng mentega (saus pedas manis)](https://img-global.cpcdn.com/recipes/bb001d7ffa79fd1e/751x532cq70/ayam-goreng-mentega-saus-pedas-manis-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam goreng mentega (saus pedas manis) yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa ciri khas yang merupakan keragaman Kita

Kedekatan keluarga bisa didapat dengan cara simple. Salah satunya adalah memasak Ayam goreng mentega (saus pedas manis) untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.

Resep Sedap Ayam Goreng Mentega Asam Manis Pedas Bikin Nagih, Menu Super Sedap Ayam Goreng Spesial Rasa Melintir, Cara Masak Daging Ayam Sedap Untuk. Ceritanya mau bikin ayam goreng mentega, tapi disini kuahnya di tambahin agar lebih banyak + di bikin saus pedas manis sekalian. untuk resep tinggal contoh di bawah ya!🤗 selamat mencoba🤍. Resep ayam goreng mentega adalah salah satu resep bentuk olahan ayam goreng yang paling banyak difavoritkan baik oleh anak-anak Resep pertama yang akan kita berikan adalah ayam goreng saus mentega. Menu masakan yang satu ini sangat mudah dibuat dan anda hanya perlu.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang bisa anda contoh salah satunya ayam goreng mentega (saus pedas manis) yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep ayam goreng mentega (saus pedas manis) tanpa harus bersusah payah.
Seperti resep Ayam goreng mentega (saus pedas manis) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 14 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam goreng mentega (saus pedas manis):

1. Harap siapkan 4 potong paha atas bawah ayam
1. Diperlukan 2 buah Bawang bombay (di iris tipis-tipis)
1. Diperlukan 1 buah Wortel besar (dipotong sesuai selera)
1. Siapkan 5 siung bawang putih (di cincang halus)
1. Tambah 2 buah jeruk nipis
1. Diperlukan 1 sendok makan garam
1. Jangan lupa 1 Sachet kecil merica bubuk
1. Siapkan 5 sendok makan Saus tomat
1. Harap siapkan 5 sendok makan saus sambal
1. Tambah 6 sendok makan kecap manis
1. Diperlukan 4 sendok makan kecap inggris
1. Harus ada 3 siung baby paprika (hanya optional, kalau tidak dipakai juga gapapa moms)
1. Harus ada 1 sendok teh Kaldu jamur totole (optional juga ya moms)
1. Diperlukan  Mentega (blueband)


Ayam goreng saus mentega adalah menu klasik yang bisa dijumpai di banyak tempat makan dan restoran di Indonesia. Rahasia yang membuat menu klasik ini tetap digemari orang Indonesia karena rasanya yang gurih, enak, ditambah aroma mentega dan rasa manis yang khas sehingga laris di. Resep ayam goreng saus mentega ini seperti biasanya menggunakan daging ayam sebagai bahan utamanya disertai beberapa bahan bumbu sederhana, seperti : jahe, bawang putih, bawang bombay, saus tiram, beberapa macam kecap, dan bahan bahan lainnya, inilah bahan dan bumbu masakan. Sajian ayam goreng bumbu pedas manis yang gurih adalah hidangan utama yang enak. 

<!--inarticleads2-->

##### Cara membuat  Ayam goreng mentega (saus pedas manis):

1. 4 potong ayam di peras dengan jeruk nipis + balurkan garam biasa (himalayan salt juga boleh) lalu di diamkan 10menit.
1. Masukan minyak ke dalam panci sekiranya goreng ayam nya bisa tenggelam (biar merata sempurna). lalu bolak balik hingga warna ke emasan. Lalu jika sudah keemasan, saya tambahkan blueband di atas ayam tsb agar rasa blueband nya menyerap di daging dalam ayam.
1. Setelah ayam matang, tiriskan. Lalu masukan blueband 3 sendok ke dalam panci, dan tumis bawang putih + bawang bombay + baby paprika hingga wangi.
1. Setelah wangi, masukan campuran bumbu (Saus sambal, Saus tomat, Kecap inggris, Kecap manis, Merica 1 sachet) lalu aduk sampai merata. Setelah merata masukn wortel dan tambahkan air (saya 2gelas full air 500ml takarannya) lalu masukan wortel, dan masak hingga worlet setengah empuk.
1. Setelah semuanya sudah tercampur, beri air lagi 100ml lalu tuangkan, dan masukan ayam yang sudah di goreng ke dalam panci. masak hingga kuah berubah menjadi sedikit kental (jangan lupa cobaiin rasanya ya mom, takutnya selera masing2 beda jadi kalau ada yg kurang bisa di tambah). Lalu saya tuang kaldu jamur totole sedikit (ini optional). Lalu tunggu sampai mengental, dan matikan kompor.
1. Jadi deh, silahkan mencoba🤍 dijamin rasanya nagih..


Resep ayam goreng saus mentega ini seperti biasanya menggunakan daging ayam sebagai bahan utamanya disertai beberapa bahan bumbu sederhana, seperti : jahe, bawang putih, bawang bombay, saus tiram, beberapa macam kecap, dan bahan bahan lainnya, inilah bahan dan bumbu masakan. Sajian ayam goreng bumbu pedas manis yang gurih adalah hidangan utama yang enak. Ayam goreng mentega terkenal memiliki cita rasa gurih nan lezat, namun pembuatannya simpel. Yuk, ikuti kreasi resep dan cara membuatnya! Masukkan kecap manis, kecap inggris, saus tomat, saus tiram, garam, dan merica. 

Demikianlah cara membuat ayam goreng mentega (saus pedas manis) yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat gampang dan terbukti, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
