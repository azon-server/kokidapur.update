---
description: "Panduan untuk membuat Ayam goreng lengkuas kremes Favorite"
title: "Panduan untuk membuat Ayam goreng lengkuas kremes Favorite"
slug: 394-panduan-untuk-membuat-ayam-goreng-lengkuas-kremes-favorite
date: 2020-10-15T12:38:43.383Z
image: https://img-global.cpcdn.com/recipes/a1df89ef784ffdde/751x532cq70/ayam-goreng-lengkuas-kremes-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a1df89ef784ffdde/751x532cq70/ayam-goreng-lengkuas-kremes-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a1df89ef784ffdde/751x532cq70/ayam-goreng-lengkuas-kremes-foto-resep-utama.jpg
author: Billy Ellis
ratingvalue: 4.2
reviewcount: 3341
recipeingredient:
- "5 potong ayam cuci bersih"
- " Bumbu halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "1 ruas jari kunyit"
- "1 ruas jari jahe"
- "1 sdm ketumbar bubuk"
- "1 sdt lada putih bubuk"
- " Bahan tambahan"
- "Segenggam kelapa parut"
- "2 bonggol lengkuas muda parut"
- "2 lembar daun salam"
- "2 batang serai ambil bagian putihnya geprek"
- "Secukupnya garam dan kaldu jamur"
- " Secukupnya air"
- " Minyak goreng"
recipeinstructions:
- "Blender bumbu halus. Panaskan sedikit minyak. Tumis bumbu halus, serai dan daun salam hingga wangi."
- "Tambahkan air secukupnya, masukan ayam, lengkuas parut, garam dan kaldu bubuk. Aduk hingga rata. Masak hingga air menyusut sambil sesekali di aduk. Saring bumbu dari air sisa ungkep ayam. Tiriskan"
- "Panaskan minyak agak banyak. Goreng ayam berserta bumbu dan kelapa parut hingga kecoklatan dengan api sedang. Angkat, saring bumbu dan ayam dari minyak. Tiriskan dan sajikan. Enak kremesannya"
categories:
- Recipe
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 116 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam goreng lengkuas kremes](https://img-global.cpcdn.com/recipes/a1df89ef784ffdde/751x532cq70/ayam-goreng-lengkuas-kremes-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas atau enak. Karasteristik kuliner Indonesia ayam goreng lengkuas kremes yang kaya dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga dapat didapat dengan cara mudah. Salah satunya adalah memasak Ayam goreng lengkuas kremes untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

Video Saya kali ini tentang cara memasak Ayam Goreng Kremes Lengkuas yang Enak dan Gurih yang sangat mudah untuk dimasak DiRumah #resepayamgorengkremes. Jika dilihat, sekilas olahan ayam goreng yang satu ini mirip sekali dengan ayam goreng serundeng kelapa dan juga ayam goreng kremes yang terbuat Tapi siapa sangka, ayam goreng yang bertabur kremesan ini terbuat dari parutan lengkuas yang dimasak sedemikian rupa sehingga memiliki. Selain menu Ayam Goreng Kremes yang menjadi favorit para Klurukers, menu sehat andalan lainnya seperti Sayur Asem ini juga menjadi incaran karena kesegaran kelezatanya, dengan paduan sayuran segar dan rasa kuah asemnya yang nendang serta rasa manis &amp; gurihnya yang pas. Hidangan ayam goreng kalasan kremes adalah sajian yang enak dan lezat.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang dapat anda praktekkan salah satunya ayam goreng lengkuas kremes yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam goreng lengkuas kremes tanpa harus bersusah payah.
Berikut ini resep Ayam goreng lengkuas kremes yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam goreng lengkuas kremes:

1. Harap siapkan 5 potong ayam (cuci bersih)
1. Harap siapkan  Bumbu halus:
1. Tambah 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Harap siapkan 1 ruas jari kunyit
1. Tambah 1 ruas jari jahe
1. Harus ada 1 sdm ketumbar bubuk
1. Jangan lupa 1 sdt lada putih bubuk
1. Harus ada  Bahan tambahan:
1. Siapkan Segenggam kelapa parut
1. Harus ada 2 bonggol lengkuas muda (parut)
1. Dibutuhkan 2 lembar daun salam
1. Dibutuhkan 2 batang serai (ambil bagian putihnya, geprek)
1. Diperlukan Secukupnya garam dan kaldu jamur
1. Harus ada  Secukupnya air
1. Jangan lupa  Minyak goreng


Mulai dari ayam goreng kremes, ayam goreng kalasan, ayam goreng palekko, sampai sayam goreng ala Korea dan Jepang (karaage). Ayam goreng ini penampilannya mirip dengan ayam goreng lengkuas, hanya saja menggunakan lebih banyak kemiri dan rempah lainnya. Setelah dicampur, masukkan ayam dan masak menggunakan api kecil. Ambil sisa kaldu yang ada untuk digunakan kremes nantinya. 

<!--inarticleads2-->

##### Cara membuat  Ayam goreng lengkuas kremes:

1. Blender bumbu halus. Panaskan sedikit minyak. Tumis bumbu halus, serai dan daun salam hingga wangi.
1. Tambahkan air secukupnya, masukan ayam, lengkuas parut, garam dan kaldu bubuk. Aduk hingga rata. Masak hingga air menyusut sambil sesekali di aduk. Saring bumbu dari air sisa ungkep ayam. Tiriskan
1. Panaskan minyak agak banyak. Goreng ayam berserta bumbu dan kelapa parut hingga kecoklatan dengan api sedang. Angkat, saring bumbu dan ayam dari minyak. Tiriskan dan sajikan. Enak kremesannya


Setelah dicampur, masukkan ayam dan masak menggunakan api kecil. Ambil sisa kaldu yang ada untuk digunakan kremes nantinya. Dalam panci, masukkan ayam, bumbu halus, daun salam, lengkuas, garam, dan air. Ayam goreng kremes tentu bukan suatu makanan yang asing bagi anda. Rasanya yang gurih dan kriuk kremesnya yang krunci, tentu akan membuat lidah anda bergoyang. 

Demikianlah cara membuat ayam goreng lengkuas kremes yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
