---
description: "Resep : Ayam Goreng Tepung Homemade"
title: "Resep : Ayam Goreng Tepung Homemade"
slug: 282-resep-ayam-goreng-tepung-homemade
date: 2020-08-10T09:50:44.972Z
image: https://img-global.cpcdn.com/recipes/d3320f49ff7caea8/751x532cq70/ayam-goreng-tepung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d3320f49ff7caea8/751x532cq70/ayam-goreng-tepung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d3320f49ff7caea8/751x532cq70/ayam-goreng-tepung-foto-resep-utama.jpg
author: Eugenia Graham
ratingvalue: 4.9
reviewcount: 3046
recipeingredient:
- "1/2 ekor ayam"
- "150 gr tepung bumbu serbaguna"
- "1 butir telur"
- "1 sdt garam"
- "1/2 sdt lada boleh skip kalo tidak mau pedes"
recipeinstructions:
- "Cuci bersih ayam lalu lumuri dengan jeruk nipis diamkan 5menit lalu bilas. Marinasi ayam dengan memberi 1sdt garam,1sdm tepung bumbu dan lada pada lalu aduk rata sisihkan. Siapkan kocokan telur di mangkok dan wadah tepung kering yang ada tutupnya."
- "Celupkan ayam kedalam kocokan telur lalu masukkan kedalam wadah tepung (jangan banyak2 1-2potong saja) lalu tutup dan kocok2 ayam agar tepung menempel sempurna keseluruh ayam"
- "Goreng Ayam dalam minyak panas, usahakan ayam tertutup minyak semua agar matangnya merata. Balik ayam hanya sekali aja, supaya tidak banyak minyak yang menempel.."
- "Kalau sudah matang, angkat dan tiriskan. Ayam goreng tepung siap disajikan untuk keluarga tercinta."
categories:
- Recipe
tags:
- ayam
- goreng
- tepung

katakunci: ayam goreng tepung 
nutrition: 263 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT37M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Goreng Tepung](https://img-global.cpcdn.com/recipes/d3320f49ff7caea8/751x532cq70/ayam-goreng-tepung-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga renyah. Ciri khas makanan Indonesia ayam goreng tepung yang penuh dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah memasak Ayam Goreng Tepung untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang bisa anda contoh salah satunya ayam goreng tepung yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam goreng tepung tanpa harus bersusah payah.
Berikut ini resep Ayam Goreng Tepung yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Tepung:

1. Siapkan 1/2 ekor ayam
1. Siapkan 150 gr tepung bumbu serbaguna
1. Jangan lupa 1 butir telur
1. Tambah 1 sdt garam
1. Tambah 1/2 sdt lada (boleh skip kalo tidak mau pedes)




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Goreng Tepung:

1. Cuci bersih ayam lalu lumuri dengan jeruk nipis diamkan 5menit lalu bilas. Marinasi ayam dengan memberi 1sdt garam,1sdm tepung bumbu dan lada pada lalu aduk rata sisihkan. Siapkan kocokan telur di mangkok dan wadah tepung kering yang ada tutupnya.
1. Celupkan ayam kedalam kocokan telur lalu masukkan kedalam wadah tepung (jangan banyak2 1-2potong saja) lalu tutup dan kocok2 ayam agar tepung menempel sempurna keseluruh ayam
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Goreng Tepung">1. Goreng Ayam dalam minyak panas, usahakan ayam tertutup minyak semua agar matangnya merata. Balik ayam hanya sekali aja, supaya tidak banyak minyak yang menempel..
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Goreng Tepung">1. Kalau sudah matang, angkat dan tiriskan. Ayam goreng tepung siap disajikan untuk keluarga tercinta.




Demikianlah cara membuat ayam goreng tepung yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan cepat, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
