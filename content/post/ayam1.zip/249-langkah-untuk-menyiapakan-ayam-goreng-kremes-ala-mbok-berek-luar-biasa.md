---
description: "Langkah untuk menyiapakan Ayam Goreng Kremes ala Mbok Berek Luar biasa"
title: "Langkah untuk menyiapakan Ayam Goreng Kremes ala Mbok Berek Luar biasa"
slug: 249-langkah-untuk-menyiapakan-ayam-goreng-kremes-ala-mbok-berek-luar-biasa
date: 2020-09-26T23:49:30.352Z
image: https://img-global.cpcdn.com/recipes/5b1e70410b2ed475/751x532cq70/ayam-goreng-kremes-ala-mbok-berek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5b1e70410b2ed475/751x532cq70/ayam-goreng-kremes-ala-mbok-berek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5b1e70410b2ed475/751x532cq70/ayam-goreng-kremes-ala-mbok-berek-foto-resep-utama.jpg
author: Hallie Patton
ratingvalue: 4.4
reviewcount: 12438
recipeingredient:
- "1 ekor ayam kampungayam pejantan potong 4 bagian"
- "2 lembar daun salam"
- "1 batang serai memarkan"
- "1 bungkus kecil santan kara larutkan dgn 2 gelas air"
- " bisa diganti santan dr 12 butir kelapa"
- "1 sdt gula pasir"
- "Secukupnya garam"
- "Secukupnya minyak goreng untuk menggoreng"
- " Bumbu Halus"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "1/2 sdm ketumbar"
- "1 cm kunyit optional"
- "4 butir kemiri"
- " Bahan Kremes"
- "300 ml air sisa rebusan ayam"
- "2 SDM munjung tepung beras"
- "125 gr tepung sagu"
- "1 butir kuning telur"
- "1/2 sdt baking powder"
recipeinstructions:
- "Campur santan bersama bumbu halus, serai, daun salam, garam &amp; gula. Aduk rata"
- "Masukkan ayam. Masak dgn api kecil sampai santan menyusut &amp; bumbu meresap. Sisakan air rebusan ayamnya"
- "Angkat dan Sisihkan ayam. Kemudian saring air rebusan ayam &amp; takar sampai 300 ml. Sisihkan untuk kremesan"
- "Buat kremesan: Aduk semua bahan kecuali baking powder, panaskan minyak dalam wajan, sambil menunggu minyak panas masukkan baking powder ke dalam adonan, aduk rata"
- "Panaskan minyak goreng, celup ayam ke adonan kremes lalu goreng dgn api sedang sampai matang. Angkat dan tiriskan. Sisihkan"
- "Pastikan minyak sudah benar-benar panas, aduk-aduk adonan kremes menggunakan telapak tangan, ambil adonan dengan tangan, kucurkan adonan dengan bantuan jari tangan dengan gerakan berputar di atas wajan"
- "Setelah adonan masuk, akan menyebar sendiri. Setelah mulai kokoh balik adonan, lipat, terus goreng sampai kecokelatan. Angkat &amp; tiriskan dgn tissue dapur agar minyak terserap"
- "Lalu taburkan kremesan di atas ayam goreng. Dan ayam goreng kremes Siap disajikan dgn sambel &amp; lalapan"
categories:
- Recipe
tags:
- ayam
- goreng
- kremes

katakunci: ayam goreng kremes 
nutrition: 104 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Goreng Kremes ala Mbok Berek](https://img-global.cpcdn.com/recipes/5b1e70410b2ed475/751x532cq70/ayam-goreng-kremes-ala-mbok-berek-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang setidaknya kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam goreng kremes ala mbok berek yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa keistimewahan yang merupakan keragaman Kita



Keharmonisan keluarga bisa didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Goreng Kremes ala Mbok Berek untuk orang di rumah. Momen makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang bisa anda coba salah satunya ayam goreng kremes ala mbok berek yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep ayam goreng kremes ala mbok berek tanpa harus bersusah payah.
Seperti resep Ayam Goreng Kremes ala Mbok Berek yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Kremes ala Mbok Berek:

1. Dibutuhkan 1 ekor ayam kampung/ayam pejantan (potong 4 bagian)
1. Diperlukan 2 lembar daun salam
1. Jangan lupa 1 batang serai (memarkan)
1. Harap siapkan 1 bungkus kecil santan kara larutkan dgn 2 gelas air
1. Harus ada  (bisa diganti santan dr 1/2 butir kelapa)
1. Dibutuhkan 1 sdt gula pasir
1. Tambah Secukupnya garam
1. Harap siapkan Secukupnya minyak goreng untuk menggoreng
1. Tambah  Bumbu Halus:
1. Harap siapkan 6 siung bawang merah
1. Dibutuhkan 4 siung bawang putih
1. Harus ada 1/2 sdm ketumbar
1. Harus ada 1 cm kunyit (optional)
1. Dibutuhkan 4 butir kemiri
1. Harap siapkan  Bahan Kremes:
1. Diperlukan 300 ml air sisa rebusan ayam
1. Jangan lupa 2 SDM munjung tepung beras
1. Siapkan 125 gr tepung sagu
1. Diperlukan 1 butir kuning telur
1. Harus ada 1/2 sdt baking powder




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Kremes ala Mbok Berek:

1. Campur santan bersama bumbu halus, serai, daun salam, garam &amp; gula. Aduk rata
1. Masukkan ayam. Masak dgn api kecil sampai santan menyusut &amp; bumbu meresap. Sisakan air rebusan ayamnya
1. Angkat dan Sisihkan ayam. Kemudian saring air rebusan ayam &amp; takar sampai 300 ml. Sisihkan untuk kremesan
1. Buat kremesan: Aduk semua bahan kecuali baking powder, panaskan minyak dalam wajan, sambil menunggu minyak panas masukkan baking powder ke dalam adonan, aduk rata
1. Panaskan minyak goreng, celup ayam ke adonan kremes lalu goreng dgn api sedang sampai matang. Angkat dan tiriskan. Sisihkan
1. Pastikan minyak sudah benar-benar panas, aduk-aduk adonan kremes menggunakan telapak tangan, ambil adonan dengan tangan, kucurkan adonan dengan bantuan jari tangan dengan gerakan berputar di atas wajan
1. Setelah adonan masuk, akan menyebar sendiri. Setelah mulai kokoh balik adonan, lipat, terus goreng sampai kecokelatan. Angkat &amp; tiriskan dgn tissue dapur agar minyak terserap
1. Lalu taburkan kremesan di atas ayam goreng. Dan ayam goreng kremes Siap disajikan dgn sambel &amp; lalapan




Demikianlah cara membuat ayam goreng kremes ala mbok berek yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
