---
description: "Steps untuk membuat Ayam Goreng Ungkep #MagicomSeries Terbukti"
title: "Steps untuk membuat Ayam Goreng Ungkep #MagicomSeries Terbukti"
slug: 468-steps-untuk-membuat-ayam-goreng-ungkep-magicomseries-terbukti
date: 2021-01-31T05:19:22.366Z
image: https://img-global.cpcdn.com/recipes/5c79de6f3684db4c/751x532cq70/ayam-goreng-ungkep-magicomseries-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5c79de6f3684db4c/751x532cq70/ayam-goreng-ungkep-magicomseries-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5c79de6f3684db4c/751x532cq70/ayam-goreng-ungkep-magicomseries-foto-resep-utama.jpg
author: Harriet Ruiz
ratingvalue: 4.3
reviewcount: 22858
recipeingredient:
- "  Bahan I"
- "1 kg ayam potong2"
- "3 lmbr Daun salam"
- "5 lmbr Daun jeruk purut"
- "1 btg Sereh geprek"
- "1/2 sdm garam kasar"
- "1 sdt garam halus"
- " Air utk merebus ayam sblm diungkep"
- "  Bahan II "
- "1 sdm minyak goreng"
- "1 bks bumbu instan pasta"
- "7 siung bawang putih"
- "3 siung bawang merah"
- "1/2 bks ketumbar bubuk"
- "1/2 sdm garam kasar"
- "1 sdt garam halus"
- "100 ml air utk merebus ayam saat diungkep"
recipeinstructions:
- "Dalam magicom didihkan air, setelah itu masukan daun salam, daun jeruk, sereh, garam kasar, garam halus. Lalu masukan ayam, masak selama 5 menit. Angkat n buang airnya. Lalu bilas ayam dgn air biasa sebanyak 2 kali. Tiriskan n sisihkan."
- "Lanjut dlm magicom masukan minyak, bumbu instan pasta, ketumbar bubuk, ayam tadi beserta daun2nya, bawang merah, bawang putih, beri garam kasar+halus lagi+100 ml air. Campur aduk ayamnya hgg tertutup bumbu ungkep."
- "Lalu klik tombol Cook. Masak hgg air menyusut. Jika sdh bawang2 empuk lalu penyet2. Lalu klik tombol Warm."
- "Ayam ungkep siap digoreng atau diolah lagi sesuai selera. Untuk menggoreng ayamnya, saya pakai 1 sdm minyak+ 1 sdm margarin. Lalu persisi ayam 1xCook. Sajikan. Nb: Jangan curi foto resep karya saya!"
categories:
- Recipe
tags:
- ayam
- goreng
- ungkep

katakunci: ayam goreng ungkep 
nutrition: 260 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT37M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Goreng Ungkep #MagicomSeries](https://img-global.cpcdn.com/recipes/5c79de6f3684db4c/751x532cq70/ayam-goreng-ungkep-magicomseries-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan empuk. Ciri khas kuliner Nusantara ayam goreng ungkep #magicomseries yang penuh dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam Goreng Ungkep #MagicomSeries untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis makanan yang dapat anda coba salah satunya ayam goreng ungkep #magicomseries yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep ayam goreng ungkep #magicomseries tanpa harus bersusah payah.
Seperti resep Ayam Goreng Ungkep #MagicomSeries yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Ungkep #MagicomSeries:

1. Harap siapkan  🍗 Bahan I:
1. Jangan lupa 1 kg ayam, potong2
1. Dibutuhkan 3 lmbr Daun salam
1. Harus ada 5 lmbr Daun jeruk purut
1. Harap siapkan 1 btg Sereh, geprek
1. Jangan lupa 1/2 sdm garam kasar
1. Siapkan 1 sdt garam halus
1. Harus ada  Air utk merebus ayam sblm diungkep
1. Harap siapkan  🍗 Bahan II :
1. Tambah 1 sdm minyak goreng
1. Siapkan 1 bks bumbu instan pasta
1. Harap siapkan 7 siung bawang putih
1. Siapkan 3 siung bawang merah
1. Harus ada 1/2 bks ketumbar bubuk
1. Harap siapkan 1/2 sdm garam kasar
1. Harus ada 1 sdt garam halus
1. Dibutuhkan 100 ml air utk merebus ayam saat diungkep




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Ungkep #MagicomSeries:

1. Dalam magicom didihkan air, setelah itu masukan daun salam, daun jeruk, sereh, garam kasar, garam halus. Lalu masukan ayam, masak selama 5 menit. Angkat n buang airnya. Lalu bilas ayam dgn air biasa sebanyak 2 kali. Tiriskan n sisihkan.
1. Lanjut dlm magicom masukan minyak, bumbu instan pasta, ketumbar bubuk, ayam tadi beserta daun2nya, bawang merah, bawang putih, beri garam kasar+halus lagi+100 ml air. Campur aduk ayamnya hgg tertutup bumbu ungkep.
1. Lalu klik tombol Cook. Masak hgg air menyusut. Jika sdh bawang2 empuk lalu penyet2. Lalu klik tombol Warm.
1. Ayam ungkep siap digoreng atau diolah lagi sesuai selera. Untuk menggoreng ayamnya, saya pakai 1 sdm minyak+ 1 sdm margarin. Lalu persisi ayam 1xCook. Sajikan. Nb: Jangan curi foto resep karya saya!




Demikianlah cara membuat ayam goreng ungkep #magicomseries yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan cepat, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
