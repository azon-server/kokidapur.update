---
description: "Cara singkat untuk menyiapakan Ayam Rica Cepat"
title: "Cara singkat untuk menyiapakan Ayam Rica Cepat"
slug: 124-cara-singkat-untuk-menyiapakan-ayam-rica-cepat
date: 2020-09-19T13:29:37.400Z
image: https://img-global.cpcdn.com/recipes/3655db980d141b71/751x532cq70/ayam-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3655db980d141b71/751x532cq70/ayam-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3655db980d141b71/751x532cq70/ayam-rica-foto-resep-utama.jpg
author: Violet Santos
ratingvalue: 4.4
reviewcount: 14867
recipeingredient:
- "1/2 kg ayam"
- " Lengkuas geprek"
- "2 batang sereh geprek"
- "3 lembar daun jeruk"
- "1 ikat kemangi"
- " Bumbu halus"
- "5 butir bawang merah"
- "3 butir bawang putih"
- "3 butir kemiri"
- "15 biji Cabe kriting"
- "3 biji cabe rawit"
- "1 sdt merica"
recipeinstructions:
- "Potong&#34; Ayam sesuai selera, cuci bersih,,"
- "Ulek/blender bumbu halus,"
- "Panaskan minyak, tumis bumbu halus+cemlung hingga harum,masukan ayam, aduk,tutup biarkan hingga minyaknya kluar,beri air, masak hingga empuk, beri garam, roiko, gula, biarkan air agak menyurut, beri taburan kemangi, aduk sebentar angkat,, siap di sajikan..."
categories:
- Recipe
tags:
- ayam
- rica

katakunci: ayam rica 
nutrition: 214 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica](https://img-global.cpcdn.com/recipes/3655db980d141b71/751x532cq70/ayam-rica-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa ciri khas yang merupakan keragaman Nusantara



Keharmonisan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica untuk keluarga. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang bisa anda contoh salah satunya ayam rica yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep ayam rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica:

1. Tambah 1/2 kg ayam
1. Jangan lupa  Lengkuas geprek
1. Jangan lupa 2 batang sereh geprek
1. Siapkan 3 lembar daun jeruk
1. Tambah 1 ikat kemangi
1. Harap siapkan  Bumbu halus:
1. Diperlukan 5 butir bawang merah
1. Dibutuhkan 3 butir bawang putih
1. Tambah 3 butir kemiri
1. Harap siapkan 15 biji Cabe kriting
1. Siapkan 3 biji cabe rawit
1. Harap siapkan 1 sdt merica




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica:

1. Potong&#34; Ayam sesuai selera, cuci bersih,,
1. Ulek/blender bumbu halus,
1. Panaskan minyak, tumis bumbu halus+cemlung hingga harum,masukan ayam, aduk,tutup biarkan hingga minyaknya kluar,beri air, masak hingga empuk, beri garam, roiko, gula, biarkan air agak menyurut, beri taburan kemangi, aduk sebentar angkat,, siap di sajikan...




Demikianlah cara membuat ayam rica yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
