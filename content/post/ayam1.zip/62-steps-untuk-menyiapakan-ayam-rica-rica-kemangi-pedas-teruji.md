---
description: "Steps untuk menyiapakan Ayam rica rica kemangi pedas Teruji"
title: "Steps untuk menyiapakan Ayam rica rica kemangi pedas Teruji"
slug: 62-steps-untuk-menyiapakan-ayam-rica-rica-kemangi-pedas-teruji
date: 2020-10-21T17:25:51.889Z
image: https://img-global.cpcdn.com/recipes/6dff6933be852f07/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6dff6933be852f07/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6dff6933be852f07/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
author: Marvin Townsend
ratingvalue: 4.3
reviewcount: 35084
recipeingredient:
- "1 ekor ayam potong sesuai selera"
- "2 ikat kemangi petik daunnya"
- "4 btang daun bawang"
- "5 lembar daun jeruk"
- "3 btang serai geprek"
- " Garam gula dan kaldu bubuk"
- " Bumbu halus"
- "16 bawang merah"
- "8 siung bawang putih"
- "4 biji Lombok merah"
- "4 biji cabe ijo"
- "10 biji cabe keriting"
- "15 biji cabe rawit"
- "1 jari telunjuk kunyit"
- "1 jari telunjuk jahe"
- "6 butir kemiri sangrai"
- "secukupnya Air"
recipeinstructions:
- "Cuci bersih ayam(tiriskan dan sisihkan)"
- "Tumis bumbu halus sampai harum dan matang...kemudian masukkan ayam dan tambahkan sedikit air"
- "Masukkan bumbu2 kemudian koreksi rasa dan masak ayam sampai matang dan empuk"
- "Masukkan daun bawang dan kemangi aduk rata"
- "Rica rica ayam kemangi pedas pun sudah bisa disajikan😁"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 101 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT49M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam rica rica kemangi pedas](https://img-global.cpcdn.com/recipes/6dff6933be852f07/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang harus kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica rica kemangi pedas yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara

Kedekatan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica rica kemangi pedas untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

Rica-rica dalam bahasa Manado (Sulawesi Utara) berarti pedas atau cabe. dalam proses masaknya beraneka ragam. Masakan kali ini dengan menambah daun kemangi. Lihat juga resep Ayam Rica Kemangi Pedas Nampol enak lainnya. Bawang putih, cincang•cabe rawit merah (sesukanya, tergantung mau level berapa tingkat kepedasannya)•bawang bombay, cincang•ayam paha dan dada beli di Superindo (saya.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda praktekkan salah satunya ayam rica rica kemangi pedas yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep ayam rica rica kemangi pedas tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi pedas yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi pedas:

1. Dibutuhkan 1 ekor ayam potong sesuai selera
1. Harap siapkan 2 ikat kemangi petik daunnya
1. Diperlukan 4 btang daun bawang
1. Harap siapkan 5 lembar daun jeruk
1. Harap siapkan 3 btang serai geprek
1. Siapkan  Garam gula dan kaldu bubuk
1. Dibutuhkan  Bumbu halus:
1. Jangan lupa 16 bawang merah
1. Siapkan 8 siung bawang putih
1. Diperlukan 4 biji Lombok merah
1. Tambah 4 biji cabe ijo
1. Harus ada 10 biji cabe keriting
1. Diperlukan 15 biji cabe rawit
1. Dibutuhkan 1 jari telunjuk kunyit
1. Jangan lupa 1 jari telunjuk jahe
1. Diperlukan 6 butir kemiri sangrai
1. Siapkan secukupnya Air


Resep ayam rica rica merupakan masakan selera pedas Resep rica rica sendiri sebenarnya tidak harus menggunakan bahan daging ayam saja. Cita rasa pedas menjadi ciri khas resep yang tergabung. Resep Ayam Rica - Rica Pedas Enak dan Spesial Untuk Keluarga - Asal muasal dari resep ayam rica-rica ini berasal dari daerah Manado - Sul. Rica merupakan bahasa Manado yang berarti pedas, bisa dimaknai bahwa kuliner ini merupakan ayam yang diberi bumbu pedas. 

<!--inarticleads2-->

##### Cara membuat  Ayam rica rica kemangi pedas:

1. Cuci bersih ayam(tiriskan dan sisihkan)
1. Tumis bumbu halus sampai harum dan matang...kemudian masukkan ayam dan tambahkan sedikit air
1. Masukkan bumbu2 kemudian koreksi rasa dan masak ayam sampai matang dan empuk
1. Masukkan daun bawang dan kemangi aduk rata
1. Rica rica ayam kemangi pedas pun sudah bisa disajikan😁


Resep Ayam Rica - Rica Pedas Enak dan Spesial Untuk Keluarga - Asal muasal dari resep ayam rica-rica ini berasal dari daerah Manado - Sul. Rica merupakan bahasa Manado yang berarti pedas, bisa dimaknai bahwa kuliner ini merupakan ayam yang diberi bumbu pedas. Nah, untuk membuat resep Ayam Rica Kemangi khas Manado ini, tentu ada beberapa hal yang harus diperhatikan. Bumbu rica-rica khas Manado bisa dipadukan dengan aneka bahan, seperti ayam. Coba membuat ayam panggang bumbu rica-rica berdasarkan resep ini. 

Demikianlah cara membuat ayam rica rica kemangi pedas yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
