---
description: "Bagaimana untuk membuat Ayam goreng ketumbar (air fryer) teraktual"
title: "Bagaimana untuk membuat Ayam goreng ketumbar (air fryer) teraktual"
slug: 257-bagaimana-untuk-membuat-ayam-goreng-ketumbar-air-fryer-teraktual
date: 2020-12-17T20:28:48.938Z
image: https://img-global.cpcdn.com/recipes/05f2eef7d7d3428b/751x532cq70/ayam-goreng-ketumbar-air-fryer-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/05f2eef7d7d3428b/751x532cq70/ayam-goreng-ketumbar-air-fryer-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/05f2eef7d7d3428b/751x532cq70/ayam-goreng-ketumbar-air-fryer-foto-resep-utama.jpg
author: Mable Kim
ratingvalue: 4.3
reviewcount: 9523
recipeingredient:
- "1 ekor Ayam"
- "2 sendok Bubuk ketumbar"
- "3 sendok Gula jawa"
- "3 siung Bawang putih"
- " Garam"
recipeinstructions:
- "Potong ayam dan cuci ayam. Lalu tiriskan.potong bawang putih dan cincang halus"
- "Keringkan sedikit ayamnya lalu campurkan bubuk ketumbar, gula jawa, garam, dan bawang putih ke ayam.dan aduk sambil pijat2 hingga bumbu merata dan lebih gampang meresap."
- "Lalu biasanya ayam berbumbu aku simpan di kulkas semalaman. Dan bsk tinggal di airfryer saja"
categories:
- Recipe
tags:
- ayam
- goreng
- ketumbar

katakunci: ayam goreng ketumbar 
nutrition: 285 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam goreng ketumbar (air fryer)](https://img-global.cpcdn.com/recipes/05f2eef7d7d3428b/751x532cq70/ayam-goreng-ketumbar-air-fryer-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam goreng ketumbar (air fryer) yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Kita

Keharmonisan rumah tangga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam goreng ketumbar (air fryer) untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang dapat anda contoh salah satunya ayam goreng ketumbar (air fryer) yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep ayam goreng ketumbar (air fryer) tanpa harus bersusah payah.
Seperti resep Ayam goreng ketumbar (air fryer) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam goreng ketumbar (air fryer):

1. Harus ada 1 ekor Ayam
1. Jangan lupa 2 sendok Bubuk ketumbar
1. Jangan lupa 3 sendok Gula jawa
1. Siapkan 3 siung Bawang putih
1. Tambah  Garam




<!--inarticleads2-->

##### Bagaimana membuat  Ayam goreng ketumbar (air fryer):

1. Potong ayam dan cuci ayam. Lalu tiriskan.potong bawang putih dan cincang halus
1. Keringkan sedikit ayamnya lalu campurkan bubuk ketumbar, gula jawa, garam, dan bawang putih ke ayam.dan aduk sambil pijat2 hingga bumbu merata dan lebih gampang meresap.
1. Lalu biasanya ayam berbumbu aku simpan di kulkas semalaman. Dan bsk tinggal di airfryer saja




Demikianlah cara membuat ayam goreng ketumbar (air fryer) yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
