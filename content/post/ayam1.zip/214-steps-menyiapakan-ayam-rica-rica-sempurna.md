---
description: "Steps menyiapakan Ayam Rica - Rica Sempurna"
title: "Steps menyiapakan Ayam Rica - Rica Sempurna"
slug: 214-steps-menyiapakan-ayam-rica-rica-sempurna
date: 2020-09-04T15:28:12.784Z
image: https://img-global.cpcdn.com/recipes/bf4211a35314c2fd/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bf4211a35314c2fd/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bf4211a35314c2fd/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Chase Abbott
ratingvalue: 4.3
reviewcount: 3666
recipeingredient:
- "1 ekor ayam potong 10"
- "500 gram ceker ayam"
- "5 siung bawang putih ulek kasar"
- "1 ruas jari jahe geprek"
- "1 ruas jari lengkuas geprek"
- "3 batang serai geprek"
- "7 lembar daun jeruk"
- "250 gram cabe setan campur cabe merah besar ulek kasar"
- "5 buah tomat hijau iris2"
- "1 sachet penyedap rasa ayam"
- "1 sdm gula palm"
- "1 sdt garam"
- "1 sdm gula pasir tambahan krn krucil mau"
- "150 gram daun kemangi"
- "100 ml air"
- "3 sdm minyak untuk menumis"
recipeinstructions:
- "Rebus ayam dan ceker sampai empuk dengan 1 sdm garam serai jahe lengkuas geprek daun salam sambil siapkan smua bumbu2nya"
- "Ulek bawang putih kasar ulek cabe kasar dan iris2 tomat ijo"
- "Tumis bawang putih sampai harum, masukkan jahe kengkuas serai daun jeruk aduk2 sampai harum kemudian masukkan cabe yang sudah diulek kasar aduk2 sampai layu, lalu masukkan tomat dan air, aduk rata sampai matang layu semua"
- "Masukkan ayam dan bumbu2 penyedap garam dan gula, test rasa kmd aduk2 biarkan sampai matang dan airnya surut. Kemudian terakhir saat mau diangkat, masukkan daun kemangi dan aduk rata jangan sampai hitam"
- "Angkat dan siap sajikan dengan nasi hangat dijamin nikmat😍😋🙏🏻"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 124 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT30M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica - Rica](https://img-global.cpcdn.com/recipes/bf4211a35314c2fd/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang harus kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica - rica yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Indonesia

Kehangatan rumah tangga dapat diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica - Rica untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang bisa anda praktekkan salah satunya ayam rica - rica yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica - rica tanpa harus bersusah payah.
Seperti resep Ayam Rica - Rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 16 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica - Rica:

1. Jangan lupa 1 ekor ayam potong 10
1. Diperlukan 500 gram ceker ayam
1. Harap siapkan 5 siung bawang putih ulek kasar
1. Jangan lupa 1 ruas jari jahe geprek
1. Dibutuhkan 1 ruas jari lengkuas geprek
1. Jangan lupa 3 batang serai geprek
1. Diperlukan 7 lembar daun jeruk
1. Dibutuhkan 250 gram cabe setan campur cabe merah besar ulek kasar
1. Harap siapkan 5 buah tomat hijau iris2
1. Dibutuhkan 1 sachet penyedap rasa ayam
1. Harap siapkan 1 sdm gula palm
1. Siapkan 1 sdt garam
1. Dibutuhkan 1 sdm gula pasir (tambahan krn krucil mau🤭)
1. Tambah 150 gram daun kemangi
1. Diperlukan 100 ml air
1. Tambah 3 sdm minyak untuk menumis




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica - Rica:

1. Rebus ayam dan ceker sampai empuk dengan 1 sdm garam serai jahe lengkuas geprek daun salam sambil siapkan smua bumbu2nya
1. Ulek bawang putih kasar ulek cabe kasar dan iris2 tomat ijo
1. Tumis bawang putih sampai harum, masukkan jahe kengkuas serai daun jeruk aduk2 sampai harum kemudian masukkan cabe yang sudah diulek kasar aduk2 sampai layu, lalu masukkan tomat dan air, aduk rata sampai matang layu semua
1. Masukkan ayam dan bumbu2 penyedap garam dan gula, test rasa kmd aduk2 biarkan sampai matang dan airnya surut. Kemudian terakhir saat mau diangkat, masukkan daun kemangi dan aduk rata jangan sampai hitam
1. Angkat dan siap sajikan dengan nasi hangat dijamin nikmat😍😋🙏🏻




Demikianlah cara membuat ayam rica - rica yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan teruji, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
