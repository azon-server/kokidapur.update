---
description: "Cara singkat untuk membuat Ayam Goreng Lengkuas teraktual"
title: "Cara singkat untuk membuat Ayam Goreng Lengkuas teraktual"
slug: 424-cara-singkat-untuk-membuat-ayam-goreng-lengkuas-teraktual
date: 2020-08-10T03:15:34.747Z
image: https://img-global.cpcdn.com/recipes/4aa1fdf12cc83718/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4aa1fdf12cc83718/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4aa1fdf12cc83718/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Kate Torres
ratingvalue: 4.8
reviewcount: 5411
recipeingredient:
- "1 kg Ayam"
- " Bumbu Halus"
- "5 siung Bawang Merah"
- "2 siung Bawang Putih"
- "1,5 sdt Kunyit Bubuk"
- "1 sdt Ketumbar Bubuk"
- "3 biji Kemiri"
- " Bumbu Cemplung"
- "2 buah Serai"
- "6 lembar Daun Jeruk"
- "200 gr Laos di Serut"
- "Secukupnya Air"
- "Secukupnya Kaldu Bubuk Garam dan Gula"
recipeinstructions:
- "Rebus Smua Bumbu Halus dan Cemplung dan Laos, Lalu Masukkan Ayam. Saya Tambahin Tahu dan Tempe. Rebus Hingga Matang, Dengan Api Kecil Sedang Sampai Air Menyusut."
- "Setelah Lunak Matikan Kompor, Goreng Ayam Hingga Kecoklatan. Saya Goreng Terpisah Bumbunya Agar Tidak Gosong."
- "Setelah Matang Lalu Tata Di Atas Piring, Siap Di Santap Bersama Lalapan dan Sambal."
categories:
- Recipe
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 128 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT56M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Goreng Lengkuas](https://img-global.cpcdn.com/recipes/4aa1fdf12cc83718/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga enak. Ciri khas kuliner Nusantara ayam goreng lengkuas yang kaya dengan bumbu memberikan kesan tersendiri bahkan untuk warga luar yang berkunjung.




Keharmonisan rumah tangga bisa diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam Goreng Lengkuas untuk orang di rumah. Momen makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang dapat anda praktekkan salah satunya ayam goreng lengkuas yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep ayam goreng lengkuas tanpa harus bersusah payah.
Berikut ini resep Ayam Goreng Lengkuas yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 13 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Lengkuas:

1. Jangan lupa 1 kg Ayam
1. Harap siapkan  Bumbu Halus
1. Dibutuhkan 5 siung Bawang Merah
1. Jangan lupa 2 siung Bawang Putih
1. Siapkan 1,5 sdt Kunyit Bubuk
1. Harap siapkan 1 sdt Ketumbar Bubuk
1. Diperlukan 3 biji Kemiri
1. Jangan lupa  Bumbu Cemplung
1. Diperlukan 2 buah Serai
1. Dibutuhkan 6 lembar Daun Jeruk
1. Harap siapkan 200 gr Laos, di Serut
1. Siapkan Secukupnya Air
1. Siapkan Secukupnya Kaldu Bubuk, Garam dan Gula




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Lengkuas:

1. Rebus Smua Bumbu Halus dan Cemplung dan Laos, Lalu Masukkan Ayam. Saya Tambahin Tahu dan Tempe. Rebus Hingga Matang, Dengan Api Kecil Sedang Sampai Air Menyusut.
1. Setelah Lunak Matikan Kompor, Goreng Ayam Hingga Kecoklatan. Saya Goreng Terpisah Bumbunya Agar Tidak Gosong.
1. Setelah Matang Lalu Tata Di Atas Piring, Siap Di Santap Bersama Lalapan dan Sambal.




Demikianlah cara membuat ayam goreng lengkuas yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
