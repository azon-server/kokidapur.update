---
description: "Resep : Ayam Rica Pedas (Menu Diet) Cepat"
title: "Resep : Ayam Rica Pedas (Menu Diet) Cepat"
slug: 221-resep-ayam-rica-pedas-menu-diet-cepat
date: 2021-02-02T05:30:58.147Z
image: https://img-global.cpcdn.com/recipes/df550c43e231644e/751x532cq70/ayam-rica-pedas-menu-diet-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/df550c43e231644e/751x532cq70/ayam-rica-pedas-menu-diet-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/df550c43e231644e/751x532cq70/ayam-rica-pedas-menu-diet-foto-resep-utama.jpg
author: Andre Romero
ratingvalue: 4.6
reviewcount: 14714
recipeingredient:
- "140 gr dada ayam tanpa kulit"
- "1 sdt saos tiram"
- "1 sdt saos tomat"
- "1 sdt saos sambal"
- "1 batang kecil daun bawang potongpotong"
- "500 ml Air kurleb"
- " Gula garam sedikit saja sesuai selera tanpa garam sudah asin"
- "1 sdt minyak canolaVCOkelapa dll"
- " Bumbu rajang"
- "1 butir bawang putih"
- "1/4 bawang bombai"
- "3 butir cabe rawit sesuai selera"
recipeinstructions:
- "Marinase dada ayam terlebih dahulu dengan sedikit kecap dan merica. Biarkan 30 menitan agar meresap."
- "Tumis bumbu rajang dengan minyak hingga wangi (pilih minyak sehat dan gunakan sedikit saja). Masukkan ayam, tumis sebentar."
- "Beri saos tiram, tomat dan sambal, masukkan daun bawang. Aduk sebentar sembari tambahkan air. Masak hingga bumbu cukup meresap dan mengental."
- "Matikan kompor dan siap santap 🤗"
categories:
- Recipe
tags:
- ayam
- rica
- pedas

katakunci: ayam rica pedas 
nutrition: 212 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica Pedas (Menu Diet)](https://img-global.cpcdn.com/recipes/df550c43e231644e/751x532cq70/ayam-rica-pedas-menu-diet-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang harus kita lestarikan karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica pedas (menu diet) yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan ciri khas yang merupakan keragaman Nusantara

Kehangatan rumah tangga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam Rica Pedas (Menu Diet) untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda coba salah satunya ayam rica pedas (menu diet) yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep ayam rica pedas (menu diet) tanpa harus bersusah payah.
Seperti resep Ayam Rica Pedas (Menu Diet) yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Pedas (Menu Diet):

1. Harus ada 140 gr dada ayam tanpa kulit
1. Tambah 1 sdt saos tiram
1. Diperlukan 1 sdt saos tomat
1. Harus ada 1 sdt saos sambal
1. Dibutuhkan 1 batang kecil daun bawang, potong-potong
1. Siapkan 500 ml Air kurleb
1. Dibutuhkan  Gula, garam sedikit saja sesuai selera (tanpa garam sudah asin)
1. Tambah 1 sdt minyak canola/VCO/kelapa dll
1. Diperlukan  Bumbu rajang:
1. Siapkan 1 butir bawang putih
1. Diperlukan 1/4 bawang bombai
1. Tambah 3 butir cabe rawit (sesuai selera)




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Pedas (Menu Diet):

1. Marinase dada ayam terlebih dahulu dengan sedikit kecap dan merica. Biarkan 30 menitan agar meresap.
1. Tumis bumbu rajang dengan minyak hingga wangi (pilih minyak sehat dan gunakan sedikit saja). Masukkan ayam, tumis sebentar.
1. Beri saos tiram, tomat dan sambal, masukkan daun bawang. Aduk sebentar sembari tambahkan air. Masak hingga bumbu cukup meresap dan mengental.
1. Matikan kompor dan siap santap 🤗




Demikianlah cara membuat ayam rica pedas (menu diet) yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
