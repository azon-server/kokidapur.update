---
description: "Bagaimana untuk menyiapakan Ayam Rica Rica tanpa Kemangi Homemade"
title: "Bagaimana untuk menyiapakan Ayam Rica Rica tanpa Kemangi Homemade"
slug: 0-bagaimana-untuk-menyiapakan-ayam-rica-rica-tanpa-kemangi-homemade
date: 2021-02-04T11:04:54.098Z
image: https://img-global.cpcdn.com/recipes/51e8b54fa4f8fb9a/751x532cq70/ayam-rica-rica-tanpa-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/51e8b54fa4f8fb9a/751x532cq70/ayam-rica-rica-tanpa-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/51e8b54fa4f8fb9a/751x532cq70/ayam-rica-rica-tanpa-kemangi-foto-resep-utama.jpg
author: Hattie Farmer
ratingvalue: 4.9
reviewcount: 45460
recipeingredient:
- "1/2 ekor Ayam"
- "1 batang Daun bawang potong kecilkecil"
- "secukupnya Gula sesuai selera"
- "secukupnya Garam  sesuai selera"
- "1 batang Sereh Digeprek"
- "secukupnya Minyak untuk goreng"
- "secukupnya Air"
- " Bumbu halus"
- "4 buah Kemiri"
- "1 ruas kunyit"
- "15 buah cabai rawit"
- "2 buah cabai merah besar"
- "5 siung bawang merah"
- "3 siung bawang putih"
recipeinstructions:
- "Haluskan semua bumbu halus di ulek/blender kasar, saat blender dikasih air sedikit."
- "Cuci ayam lalu taro di wadah,Balurin ayam sedikit garam dan perasan air lemon (tunggu 5 menit an)"
- "Panas kan minyak secukupnya dengan api sedang"
- "Jika minyak sudah cukup panas, tumis bumbu halus yang sudah di ulek/blender dan masukin Sereh yang sudah di geprek. Tumis sampai harum."
- "Jika sudah harum masukin ayamnya dan dimasak sampai setengah matang (luarnya berubah warna putih) agar bumbunya juga meresap ke dalam ayam."
- "Kalau udah setengah matang ayamnya, masukin air secukupnya sampai ayam terendam."
- "Aduk agar bumbunya tidak gosong lalu ditutup pancinya agar air nya cepet surut."
- "Jika sudah sedikit surut airnya,masukin gula dan garam secukupnya (sesuai selera)"
- "Di aduk dan ditutup lagi pancinya (dilakukan berulang sampai airnya surut mengental) jangan sampai surut banget tapi yaa bund biar ada bumbunya lebih mantep."
- "Ayamnya sudah matang taburin daun bawang lalu matiin kompornya dan aduk sekali lagi."
- "Koreksi rasanya jika sudah pas bisa langsung disajikan Ayamnya bundd.."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 114 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica Rica tanpa Kemangi](https://img-global.cpcdn.com/recipes/51e8b54fa4f8fb9a/751x532cq70/ayam-rica-rica-tanpa-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica rica tanpa kemangi yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa ciri khas yang merupakan keragaman Indonesia

Keharmonisan rumah tangga bisa didapat dengan cara simple. Diantaranya adalah memasak Ayam Rica Rica tanpa Kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Resep Cara Membuat Ayam Goreng Lengkuas Yang Enak Dan Gurih.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang bisa anda contoh salah satunya ayam rica rica tanpa kemangi yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep ayam rica rica tanpa kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica tanpa Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 11 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica tanpa Kemangi:

1. Dibutuhkan 1/2 ekor Ayam
1. Diperlukan 1 batang Daun bawang potong kecil-kecil
1. Harap siapkan secukupnya Gula (sesuai selera)
1. Diperlukan secukupnya Garam  (sesuai selera)
1. Tambah 1 batang Sereh (Digeprek)
1. Diperlukan secukupnya Minyak untuk goreng
1. Siapkan secukupnya Air
1. Siapkan  Bumbu halus
1. Siapkan 4 buah Kemiri
1. Harus ada 1 ruas kunyit
1. Diperlukan 15 buah cabai rawit
1. Dibutuhkan 2 buah cabai merah besar
1. Dibutuhkan 5 siung bawang merah
1. Harus ada 3 siung bawang putih


Namun sekarang sudah banyak resep masakan rica rica ini, seperti : ayam rica rica kemangi, resep rica rica ceker, resep. Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Dengan aroma yang menggoda dibumbui dengan. 

<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica tanpa Kemangi:

1. Haluskan semua bumbu halus di ulek/blender kasar, saat blender dikasih air sedikit.
1. Cuci ayam lalu taro di wadah,Balurin ayam sedikit garam dan perasan air lemon (tunggu 5 menit an)
1. Panas kan minyak secukupnya dengan api sedang
1. Jika minyak sudah cukup panas, tumis bumbu halus yang sudah di ulek/blender dan masukin Sereh yang sudah di geprek. Tumis sampai harum.
1. Jika sudah harum masukin ayamnya dan dimasak sampai setengah matang (luarnya berubah warna putih) agar bumbunya juga meresap ke dalam ayam.
1. Kalau udah setengah matang ayamnya, masukin air secukupnya sampai ayam terendam.
1. Aduk agar bumbunya tidak gosong lalu ditutup pancinya agar air nya cepet surut.
1. Jika sudah sedikit surut airnya,masukin gula dan garam secukupnya (sesuai selera)
1. Di aduk dan ditutup lagi pancinya (dilakukan berulang sampai airnya surut mengental) jangan sampai surut banget tapi yaa bund biar ada bumbunya lebih mantep.
1. Ayamnya sudah matang taburin daun bawang lalu matiin kompornya dan aduk sekali lagi.
1. Koreksi rasanya jika sudah pas bisa langsung disajikan Ayamnya bundd..


Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Dengan aroma yang menggoda dibumbui dengan. Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi. Rica-rica sendiri bisa terbuat dari berbagai bahan utama, namun yang paling populer adalah ayam. Selain mudah didapat, daging ayam juga relatif lebih murah jika dibandingkan dengan bahan-bahan lain seperti daging entok dan sebagainya. 

Demikianlah cara membuat ayam rica rica tanpa kemangi yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan teruji, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
