---
description: "Bagaimana menyiapakan Ayam rica rica cabe ijo Luar biasa"
title: "Bagaimana menyiapakan Ayam rica rica cabe ijo Luar biasa"
slug: 17-bagaimana-menyiapakan-ayam-rica-rica-cabe-ijo-luar-biasa
date: 2021-01-24T16:03:28.180Z
image: https://img-global.cpcdn.com/recipes/fd373d6f0abb4fb7/751x532cq70/ayam-rica-rica-cabe-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fd373d6f0abb4fb7/751x532cq70/ayam-rica-rica-cabe-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fd373d6f0abb4fb7/751x532cq70/ayam-rica-rica-cabe-ijo-foto-resep-utama.jpg
author: Walter Miles
ratingvalue: 4.8
reviewcount: 13283
recipeingredient:
- "1/2 kg ayam"
- "15 buah cabe ijo"
- "1 batang daun sereh"
- "4 lembar daun jeruk"
- "2 lembar daun salam"
- "1 buah tomat"
- "1 ruas lengkuas geprek"
- "1 sdm garam"
- "1 sdt gula"
- " Sejuput micin"
- " Bumbu halus"
- "5 buah cabe rawit"
- "2 buah cabe merah"
- "4 siung bawang putih"
- "5 siung bawang merah"
- "4 butir kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
recipeinstructions:
- "Siapakan semua bahan, cuci bersih ayam potong2 sesuai selera"
- "Blender bumbu halus, siapkan wajan masak bumbu halus sampai meletup2, masukan daun sereh, daun salam, dan lengkuas geprek masak sampai harum masukan ayam aduk2 hingga tercampur rata"
- "Kemudian masukan 500ml air, tutup sampai meletup2, tambahkan irisan tomat, cabe ijo, garam, gula, micin, aduk2 sebentar, tutup kembali sampai air asat dan bumbu meresap"
- "Setelah air asat, matikan kompor dan siap di santap dg nasi hangat lebih mantap, selesai selamat mencoba semuanya 💛"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 141 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica rica cabe ijo](https://img-global.cpcdn.com/recipes/fd373d6f0abb4fb7/751x532cq70/ayam-rica-rica-cabe-ijo-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica rica cabe ijo yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Indonesia

Kedekatan keluarga dapat diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam rica rica cabe ijo untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang bisa anda buat salah satunya ayam rica rica cabe ijo yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica rica cabe ijo tanpa harus bersusah payah.
Seperti resep Ayam rica rica cabe ijo yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica cabe ijo:

1. Harus ada 1/2 kg ayam
1. Harus ada 15 buah cabe ijo
1. Siapkan 1 batang daun sereh
1. Jangan lupa 4 lembar daun jeruk
1. Tambah 2 lembar daun salam
1. Tambah 1 buah tomat
1. Harap siapkan 1 ruas lengkuas (geprek)
1. Harap siapkan 1 sdm garam
1. Tambah 1 sdt gula
1. Jangan lupa  Sejuput micin
1. Diperlukan  Bumbu halus
1. Tambah 5 buah cabe rawit
1. Siapkan 2 buah cabe merah
1. Jangan lupa 4 siung bawang putih
1. Diperlukan 5 siung bawang merah
1. Harus ada 4 butir kemiri
1. Harus ada 1 ruas jahe
1. Jangan lupa 1 ruas kunyit




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica rica cabe ijo:

1. Siapakan semua bahan, cuci bersih ayam potong2 sesuai selera
1. Blender bumbu halus, siapkan wajan masak bumbu halus sampai meletup2, masukan daun sereh, daun salam, dan lengkuas geprek masak sampai harum masukan ayam aduk2 hingga tercampur rata
1. Kemudian masukan 500ml air, tutup sampai meletup2, tambahkan irisan tomat, cabe ijo, garam, gula, micin, aduk2 sebentar, tutup kembali sampai air asat dan bumbu meresap
1. Setelah air asat, matikan kompor dan siap di santap dg nasi hangat lebih mantap, selesai selamat mencoba semuanya 💛




Demikianlah cara membuat ayam rica rica cabe ijo yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
