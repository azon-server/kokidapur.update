---
description: "Cara singkat untuk membuat Ayam Rica Rica Kemangi Luar biasa"
title: "Cara singkat untuk membuat Ayam Rica Rica Kemangi Luar biasa"
slug: 206-cara-singkat-untuk-membuat-ayam-rica-rica-kemangi-luar-biasa
date: 2020-08-27T06:01:47.066Z
image: https://img-global.cpcdn.com/recipes/9d4f02d8c5a58c15/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9d4f02d8c5a58c15/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9d4f02d8c5a58c15/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Nathan Hall
ratingvalue: 4.1
reviewcount: 13215
recipeingredient:
- "1/2 Kg Ayam"
- "1 Batang Serai"
- "4 Lembar daun Jeruk"
- "2 Buah Tomat potongpotong"
- "15 Buah Cabai Rawit Merah"
- "1 Mangkok Kemangi"
- "1 Sdm Gula Merah"
- "1/2 Sdm Garam"
- "1 Sdt Kaldu Ayam Bubuk Royco"
- "300 Ml Air"
- " Bumbu yang dihaluskan"
- "6 Buah Cabai Merah Keriting"
- "7 Siung Bawang Merah"
- "4 Siung Bawang Putih"
- "1 Sdt Ketumbar Halus"
- "1 Ruas Kunyit"
- "1 Ruas Jahe"
- " Minyak untuk menumis"
recipeinstructions:
- "Goreng ayam hingga kecoklatan lalu angkat dan tiriskan."
- "Tumis bumbu yang dihaluskan lalu masukkan daun jeruk dan serai. Masak sampai harum lalu masukkan tomat dan gula merah. Aduk sampai rata lalu masukkan ayam, air, garam dan kaldu bubuk (Bisa ditambah gula pasir jika suka)."
- "Setelah air agak menyusut masukkan cabai rawit dan daun kemangi aduk sampai rata, cek juga rasanya."
- "Sajikan Ayam Rica Rica Kemangi selagi hangat. Selamat mencoba."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 261 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT39M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/9d4f02d8c5a58c15/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau enak. Ciri khas masakan Indonesia ayam rica rica kemangi yang kaya dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica Rica Kemangi untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang bisa anda contoh salah satunya ayam rica rica kemangi yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi:

1. Siapkan 1/2 Kg Ayam
1. Siapkan 1 Batang Serai
1. Jangan lupa 4 Lembar daun Jeruk
1. Siapkan 2 Buah Tomat, potong-potong
1. Dibutuhkan 15 Buah Cabai Rawit Merah
1. Jangan lupa 1 Mangkok Kemangi
1. Harus ada 1 Sdm Gula Merah
1. Dibutuhkan 1/2 Sdm Garam
1. Tambah 1 Sdt Kaldu Ayam Bubuk (Royco)
1. Diperlukan 300 Ml Air
1. Diperlukan  Bumbu yang dihaluskan*
1. Harus ada 6 Buah Cabai Merah Keriting
1. Harap siapkan 7 Siung Bawang Merah
1. Harus ada 4 Siung Bawang Putih
1. Jangan lupa 1 Sdt Ketumbar Halus
1. Diperlukan 1 Ruas Kunyit
1. Diperlukan 1 Ruas Jahe
1. Harus ada  Minyak untuk menumis




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica Kemangi:

1. Goreng ayam hingga kecoklatan lalu angkat dan tiriskan.
1. Tumis bumbu yang dihaluskan lalu masukkan daun jeruk dan serai. Masak sampai harum lalu masukkan tomat dan gula merah. Aduk sampai rata lalu masukkan ayam, air, garam dan kaldu bubuk (Bisa ditambah gula pasir jika suka).
1. Setelah air agak menyusut masukkan cabai rawit dan daun kemangi aduk sampai rata, cek juga rasanya.
1. Sajikan Ayam Rica Rica Kemangi selagi hangat. Selamat mencoba.




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan teruji, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
