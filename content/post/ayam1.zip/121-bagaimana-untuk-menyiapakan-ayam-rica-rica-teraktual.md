---
description: "Bagaimana untuk menyiapakan Ayam rica rica teraktual"
title: "Bagaimana untuk menyiapakan Ayam rica rica teraktual"
slug: 121-bagaimana-untuk-menyiapakan-ayam-rica-rica-teraktual
date: 2020-10-02T11:14:22.808Z
image: https://img-global.cpcdn.com/recipes/c6b442637cb7c5db/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c6b442637cb7c5db/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c6b442637cb7c5db/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Douglas Roberson
ratingvalue: 4.1
reviewcount: 17372
recipeingredient:
- "1 kg ayam"
- "30 buah Cabai setan"
- "8 buah Cabai merah keriting"
- "8 siungBawang merah"
- "4 siung Bawang putih"
- "3 ikat Kemangi"
- "1 buah tomat matang"
- "2 ruas kunyit"
- "2 ruas jahe geprek"
- "secukupnya Garam"
- "secukupnya Air"
recipeinstructions:
- "Blender semua bumbu,kecuali jahe"
- "Panaskan minyak dlm wajan,tumis bumbu hingga matang"
- "Masukkan ayam,aduk sebentar,jgn sampe gosong"
- "Masukkan air,masak hingga bumbu meresap dan air tinggal sedikit"
- "Masukkan kemangi,garam atau kaldu bubuk,aduk sampai air habis"
- "Setelah matang hidangkan dengan nasi hangat...❤️❤️😊"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 228 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica rica](https://img-global.cpcdn.com/recipes/c6b442637cb7c5db/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau renyah. Ciri khas masakan Nusantara ayam rica rica yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica. Resep Ayam Rica Rica Bahan: Daging Ayam Lemon juice Chicken powder Garam. Bawang merah Bawang putih Cabe Jahe Serai Daun jeruk purut Daun kucai.

Kedekatan rumah tangga bisa didapat dengan cara simple. Salah satunya adalah memasak Ayam rica rica untuk orang di rumah. Momen makan bersama orang tua sudah menjadi budaya, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang dapat anda buat salah satunya ayam rica rica yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica rica tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 11 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica:

1. Dibutuhkan 1 kg ayam
1. Jangan lupa 30 buah Cabai setan
1. Siapkan 8 buah Cabai merah keriting
1. Harus ada 8 siungBawang merah
1. Dibutuhkan 4 siung Bawang putih
1. Dibutuhkan 3 ikat Kemangi
1. Harus ada 1 buah tomat matang
1. Siapkan 2 ruas kunyit
1. Harus ada 2 ruas jahe geprek
1. Harap siapkan secukupnya Garam
1. Siapkan secukupnya Air


Lihat juga resep Ayam Rica Kemangi (resep mertua ❤) enak lainnya. Resep Ayam Rica Rica - Kalau kita sudah mendengar kata-kata tentang bumbu rica-rica, sudah pasti pikiran kita akan tertuju pada masakan khas Manado. Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas. 

<!--inarticleads2-->

##### Cara membuat  Ayam rica rica:

1. Blender semua bumbu,kecuali jahe
1. Panaskan minyak dlm wajan,tumis bumbu hingga matang
1. Masukkan ayam,aduk sebentar,jgn sampe gosong
1. Masukkan air,masak hingga bumbu meresap dan air tinggal sedikit
1. Masukkan kemangi,garam atau kaldu bubuk,aduk sampai air habis
1. Setelah matang hidangkan dengan nasi hangat...❤️❤️😊


Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas. Cara pembuatan ayam rica-rica tidaklah sulit. Dibutuhkan bahan-bahan seperti daun jeruk, serai, dan daun pandan agar aromanya menjadi kuat dan khas. Tak hanya ayam, anda juga bisa memasak. 

Demikianlah cara membuat ayam rica rica yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
