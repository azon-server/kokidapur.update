---
description: "Steps menyiapakan 48. Ayam Rica Kemangi Kuah Kuning Favorite"
title: "Steps menyiapakan 48. Ayam Rica Kemangi Kuah Kuning Favorite"
slug: 105-steps-menyiapakan-48-ayam-rica-kemangi-kuah-kuning-favorite
date: 2020-12-06T09:08:00.960Z
image: https://img-global.cpcdn.com/recipes/008db8d0ec9c67e0/751x532cq70/48-ayam-rica-kemangi-kuah-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/008db8d0ec9c67e0/751x532cq70/48-ayam-rica-kemangi-kuah-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/008db8d0ec9c67e0/751x532cq70/48-ayam-rica-kemangi-kuah-kuning-foto-resep-utama.jpg
author: Ernest Allen
ratingvalue: 4.4
reviewcount: 28335
recipeingredient:
- "1/2 kg ayam potong kecilsesuai selera"
- "1 ikat daun kemangi"
- "1 batang daun bawang iris"
- "1 buah tomat potong2"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 cm lengkuas geprek"
- "1 batang serai geprek"
- "3 sdt kaldu bubuk"
- "1 sdt garam"
- "1 sdt kecap manis"
- "1 sdt gula pasir sesuai selera"
- "300 ml air sesuai selera"
- " Bumbu halus "
- "4 siung bawang putih"
- "8 siung bawang merah"
- "3 butir kemiri"
- "1 sdt ketumbar bubuk"
- "1 cm kunyit"
- "1 cm jahe"
- "10 buah cabe rawit sesuai selera"
- "1 buah cabe keriting aslinya 6"
recipeinstructions:
- "Siapkan semua bahan, blender semua bumbu halus."
- "Tumis bumbu halus dengan sedikit minyak hingga harum, masukkan daun salam, daun jeruk dan serai. Tumis2 sebentar, masukkan daging ayam. Tumis lagi sampai agak berubah warna."
- "Tambahkan air, masak sampai daging ayam matang dan air agak menyusut. (saya suka agak berkuah jd airnya lumayan banyak). Masukkan tomat, kaldu bubuk, garam, gula pasir dan kecap. Koreksi rasa. Jika sudah pas, masukkan kemangi dan daun bawang. Aduk rata."
- "Masak sampai kemangi layu dan harum. Siap disajikan 😇"
categories:
- Recipe
tags:
- 48
- ayam
- rica

katakunci: 48 ayam rica 
nutrition: 270 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT54M"
recipeyield: "3"
recipecategory: Dessert

---


![48. Ayam Rica Kemangi Kuah Kuning](https://img-global.cpcdn.com/recipes/008db8d0ec9c67e0/751x532cq70/48-ayam-rica-kemangi-kuah-kuning-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti 48. ayam rica kemangi kuah kuning yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa keistimewahan yang merupakan keragaman Indonesia



Kedekatan rumah tangga bisa diperoleh dengan cara mudah. Salah satunya adalah memasak 48. Ayam Rica Kemangi Kuah Kuning untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang bisa anda coba salah satunya 48. ayam rica kemangi kuah kuning yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep 48. ayam rica kemangi kuah kuning tanpa harus bersusah payah.
Berikut ini resep 48. Ayam Rica Kemangi Kuah Kuning yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 22 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 48. Ayam Rica Kemangi Kuah Kuning:

1. Tambah 1/2 kg ayam, potong kecil/sesuai selera
1. Jangan lupa 1 ikat daun kemangi
1. Dibutuhkan 1 batang daun bawang, iris
1. Jangan lupa 1 buah tomat, potong2
1. Harap siapkan 2 lembar daun salam
1. Harus ada 2 lembar daun jeruk
1. Dibutuhkan 1 cm lengkuas, geprek
1. Harap siapkan 1 batang serai, geprek
1. Jangan lupa 3 sdt kaldu bubuk
1. Dibutuhkan 1 sdt garam
1. Dibutuhkan 1 sdt kecap manis
1. Diperlukan 1 sdt gula pasir (sesuai selera)
1. Tambah 300 ml air (sesuai selera)
1. Siapkan  Bumbu halus :
1. Diperlukan 4 siung bawang putih
1. Diperlukan 8 siung bawang merah
1. Tambah 3 butir kemiri
1. Harus ada 1 sdt ketumbar bubuk
1. Diperlukan 1 cm kunyit
1. Harap siapkan 1 cm jahe
1. Jangan lupa 10 buah cabe rawit (sesuai selera)
1. Tambah 1 buah cabe keriting (aslinya 6)




<!--inarticleads2-->

##### Cara membuat  48. Ayam Rica Kemangi Kuah Kuning:

1. Siapkan semua bahan, blender semua bumbu halus.
1. Tumis bumbu halus dengan sedikit minyak hingga harum, masukkan daun salam, daun jeruk dan serai. Tumis2 sebentar, masukkan daging ayam. Tumis lagi sampai agak berubah warna.
1. Tambahkan air, masak sampai daging ayam matang dan air agak menyusut. (saya suka agak berkuah jd airnya lumayan banyak). Masukkan tomat, kaldu bubuk, garam, gula pasir dan kecap. Koreksi rasa. Jika sudah pas, masukkan kemangi dan daun bawang. Aduk rata.
1. Masak sampai kemangi layu dan harum. Siap disajikan 😇




Demikianlah cara membuat 48. ayam rica kemangi kuah kuning yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan terbukti, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
