---
description: "Step-by-Step untuk menyiapakan Ayam rica rica kemangi Terbukti"
title: "Step-by-Step untuk menyiapakan Ayam rica rica kemangi Terbukti"
slug: 103-step-by-step-untuk-menyiapakan-ayam-rica-rica-kemangi-terbukti
date: 2020-09-22T03:44:06.571Z
image: https://img-global.cpcdn.com/recipes/95350e31e400a2fc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/95350e31e400a2fc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/95350e31e400a2fc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Lena Simmons
ratingvalue: 4
reviewcount: 45055
recipeingredient:
- "1 kg ayam"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "20 buah cabe rawit"
- "8 buah cabe merah"
- "2 lbr daun salam"
- "1 Batang sereh"
- "2 sdm kunyit bubuk"
- "1 ruas laos"
- "5 bh kemiri"
- "1 ikat daun kemangi"
- " Gula garam penyedap rasa"
recipeinstructions:
- "Potong ayam menjadi beberapa bagian, cuci bersih lalu digoreng garing"
- "Haluskan bumbu : 6 siung bawang merah 4 siung bawang putih, 5 buah kemiri"
- "8 buah cabe merah, 20 buah cabe rawit, 1 ruas lengkuas, 2 sdm kunyit bubuk"
- "Tumis bumbu kedalam minyak panas"
- "Masukkan daun salam dan sereh tambahkan air"
- "Masukkan ayam yg sdh digoreng tambahkan gula garam dan penyedap rasa"
- "Masak hingga tanak, lalu masukkan kemangi saat akan diangkat dari kompor"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 126 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/95350e31e400a2fc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang dapat kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica rica kemangi yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa keistimewahan yang merupakan keragaman Indonesia

Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Inilah rahasia bumbu masakan ayam rica rica dan petunjuk cara membuat rica rica ayam.

Kedekatan rumah tangga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Ayam rica rica kemangi untuk keluarga. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang dapat anda praktekkan salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Siapkan 1 kg ayam
1. Harus ada 6 siung bawang merah,
1. Dibutuhkan 4 siung bawang putih,
1. Harus ada 20 buah cabe rawit,
1. Diperlukan 8 buah cabe merah,
1. Dibutuhkan 2 lbr daun salam,
1. Tambah 1 Batang sereh
1. Harap siapkan 2 sdm kunyit bubuk,
1. Harap siapkan 1 ruas laos,
1. Harus ada 5 bh kemiri
1. Jangan lupa 1 ikat daun kemangi
1. Dibutuhkan  Gula garam penyedap rasa


It is made up of chicken that cooked in spicy red and green chili pepper. The origin of this dish is from Minahasan cuisine of North Sulawesi. Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. 

<!--inarticleads2-->

##### Cara membuat  Ayam rica rica kemangi:

1. Potong ayam menjadi beberapa bagian, cuci bersih lalu digoreng garing
1. Haluskan bumbu : 6 siung bawang merah 4 siung bawang putih, 5 buah kemiri
1. 8 buah cabe merah, 20 buah cabe rawit, 1 ruas lengkuas, 2 sdm kunyit bubuk
1. Tumis bumbu kedalam minyak panas
1. Masukkan daun salam dan sereh tambahkan air
1. Masukkan ayam yg sdh digoreng tambahkan gula garam dan penyedap rasa
1. Masak hingga tanak, lalu masukkan kemangi saat akan diangkat dari kompor


Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. 

Demikianlah cara membuat ayam rica rica kemangi yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
