---
description: "Resep : Ayam Goreng Rawit Kemangi ala Mama Fifian terupdate"
title: "Resep : Ayam Goreng Rawit Kemangi ala Mama Fifian terupdate"
slug: 278-resep-ayam-goreng-rawit-kemangi-ala-mama-fifian-terupdate
date: 2020-08-18T00:16:11.761Z
image: https://img-global.cpcdn.com/recipes/6b86a4dc281002d0/751x532cq70/ayam-goreng-rawit-kemangi-ala-mama-fifian-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6b86a4dc281002d0/751x532cq70/ayam-goreng-rawit-kemangi-ala-mama-fifian-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6b86a4dc281002d0/751x532cq70/ayam-goreng-rawit-kemangi-ala-mama-fifian-foto-resep-utama.jpg
author: Lola Page
ratingvalue: 4.2
reviewcount: 6127
recipeingredient:
- "1 ekor karkas ayam broiler 8 potong"
- " Bumbu halus"
- "3 buah bawang putih"
- "7 buah bawang merah"
- "15 buah cabe rawit campur"
- "3 buah cabe merah besar"
- " Pelengkap"
- "2 btg sereh"
- "3 lbr daun salam"
- "5 lbr daun jeruk"
- "1 sdt garam"
- "1 sdt gula merahputih"
- "1 iket serawung kemangi"
recipeinstructions:
- "Siapkan bahan. Cuci bersih ayam stlh dimarinasi dg lemon dan garam. Rebus air 500 ml, masukkan ayam yg ssh bersih untuk direbus sekitar 15 menit. Lalu goreng, tiriskan"
- "Kupas bawang putih,bawang merah, cuci bersama cabe, haluskan"
- "Tumis bumbu sampai harum, tambahkan bumbu pelengkap, tambahkan ayam yg sdh digoreng, aduk rata masak dg api kecil sekitar 5 menit, tambahkan gula dan garam"
- "Setelah agak kering, cek rasa, matikan kompor. Beri daun kemangi yg sdh dibersihkan dan perasan lemon."
- "Sajikan"
categories:
- Recipe
tags:
- ayam
- goreng
- rawit

katakunci: ayam goreng rawit 
nutrition: 163 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT35M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Goreng Rawit Kemangi ala Mama Fifian](https://img-global.cpcdn.com/recipes/6b86a4dc281002d0/751x532cq70/ayam-goreng-rawit-kemangi-ala-mama-fifian-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam goreng rawit kemangi ala mama fifian yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa kesan tersendiri yang merupakan keragaman Indonesia



Kehangatan rumah tangga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Ayam Goreng Rawit Kemangi ala Mama Fifian untuk keluarga. Momen makan bersama orang tua sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang dapat anda buat salah satunya ayam goreng rawit kemangi ala mama fifian yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep ayam goreng rawit kemangi ala mama fifian tanpa harus bersusah payah.
Seperti resep Ayam Goreng Rawit Kemangi ala Mama Fifian yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 13 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Rawit Kemangi ala Mama Fifian:

1. Harus ada 1 ekor karkas ayam broiler (8 potong)
1. Dibutuhkan  Bumbu halus:
1. Siapkan 3 buah bawang putih
1. Diperlukan 7 buah bawang merah
1. Jangan lupa 15 buah cabe rawit campur
1. Dibutuhkan 3 buah cabe merah besar
1. Dibutuhkan  Pelengkap:
1. Tambah 2 btg sereh
1. Jangan lupa 3 lbr daun salam
1. Harus ada 5 lbr daun jeruk
1. Tambah 1 sdt garam
1. Tambah 1 sdt gula merah/putih
1. Harap siapkan 1 iket serawung/ kemangi




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Goreng Rawit Kemangi ala Mama Fifian:

1. Siapkan bahan. Cuci bersih ayam stlh dimarinasi dg lemon dan garam. Rebus air 500 ml, masukkan ayam yg ssh bersih untuk direbus sekitar 15 menit. Lalu goreng, tiriskan
1. Kupas bawang putih,bawang merah, cuci bersama cabe, haluskan
1. Tumis bumbu sampai harum, tambahkan bumbu pelengkap, tambahkan ayam yg sdh digoreng, aduk rata masak dg api kecil sekitar 5 menit, tambahkan gula dan garam
1. Setelah agak kering, cek rasa, matikan kompor. Beri daun kemangi yg sdh dibersihkan dan perasan lemon.
1. Sajikan




Demikianlah cara membuat ayam goreng rawit kemangi ala mama fifian yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
