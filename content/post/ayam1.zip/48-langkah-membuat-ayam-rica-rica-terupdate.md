---
description: "Langkah membuat Ayam Rica - Rica terupdate"
title: "Langkah membuat Ayam Rica - Rica terupdate"
slug: 48-langkah-membuat-ayam-rica-rica-terupdate
date: 2020-09-14T18:29:29.996Z
image: https://img-global.cpcdn.com/recipes/64765387baaaefbb/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/64765387baaaefbb/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/64765387baaaefbb/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Bradley Stevenson
ratingvalue: 4.6
reviewcount: 16335
recipeingredient:
- "1 kg ayam"
- "6 batang sereh digeprek"
- "2 cm lengkuas geprek"
- "2 cm jahe geprek"
- "6 lembar daun jeruk"
- "6 lembar daun salam"
- "3 buah tomat optional"
- "1 bungkus masako"
- "secukupnya Garam"
- " Bumbu halus "
- "2 cm kunyit"
- "12 siung bawang merah"
- "6 bawang putih"
- " Cabe merah 20 biji atau sesuai selera"
- "6 butir kemiri"
- "1 bungkus ladaku blh dikurangi"
- " Ketumbar secukupnya blh pake yg halus"
- "secukupnya Daun kemangi"
- "1 buah jeruk nipis utk ayam"
- "secukupnya Gula pasir"
recipeinstructions:
- "Bersihkan dan potong ayam, kalau saya sukanya agak kecil2 supanya bumbu lebih meresap. Cuci bersih kasih garam dan jeruk nipis. Diamkan sktr 10 mnt. Lalu goreng sbntr"
- "Tumis bumbu halus sampai wangi kemudian masukkan bumbu geprek"
- "Masukkan ayam lalu beri air secukupnya. Kalau mau agak basah ksh agak byk."
- "Diamkan dgn api kecil sktr 20 mnt atau smp air menyusut, terakhir masukkan kemangi yg sdh dicuci bersih."
- "Siap disajikan"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 281 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica - Rica](https://img-global.cpcdn.com/recipes/64765387baaaefbb/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica - rica yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa keistimewahan yang merupakan keragaman Indonesia



Keharmonisan rumah tangga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Ayam Rica - Rica untuk orang di rumah. Momen makan bersama keluarga sudah menjadi kultur, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang dapat anda coba salah satunya ayam rica - rica yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica - rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica - Rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 20 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica - Rica:

1. Harus ada 1 kg ayam
1. Tambah 6 batang sereh digeprek
1. Siapkan 2 cm lengkuas geprek
1. Dibutuhkan 2 cm jahe geprek
1. Tambah 6 lembar daun jeruk
1. Harus ada 6 lembar daun salam
1. Tambah 3 buah tomat (optional)
1. Harap siapkan 1 bungkus masako
1. Diperlukan secukupnya Garam
1. Siapkan  Bumbu halus :
1. Harus ada 2 cm kunyit
1. Harap siapkan 12 siung bawang merah
1. Jangan lupa 6 bawang putih
1. Siapkan  Cabe merah 20 biji atau sesuai selera
1. Jangan lupa 6 butir kemiri
1. Jangan lupa 1 bungkus ladaku blh dikurangi
1. Diperlukan  Ketumbar secukupnya, blh pake yg halus
1. Harap siapkan secukupnya Daun kemangi
1. Tambah 1 buah jeruk nipis utk ayam
1. Dibutuhkan secukupnya Gula pasir




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica - Rica:

1. Bersihkan dan potong ayam, kalau saya sukanya agak kecil2 supanya bumbu lebih meresap. Cuci bersih kasih garam dan jeruk nipis. Diamkan sktr 10 mnt. Lalu goreng sbntr
1. Tumis bumbu halus sampai wangi kemudian masukkan bumbu geprek
1. Masukkan ayam lalu beri air secukupnya. Kalau mau agak basah ksh agak byk.
1. Diamkan dgn api kecil sktr 20 mnt atau smp air menyusut, terakhir masukkan kemangi yg sdh dicuci bersih.
1. Siap disajikan




Demikianlah cara membuat ayam rica - rica yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
