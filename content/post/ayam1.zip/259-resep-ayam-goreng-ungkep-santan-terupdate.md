---
description: "Resep : Ayam Goreng Ungkep Santan terupdate"
title: "Resep : Ayam Goreng Ungkep Santan terupdate"
slug: 259-resep-ayam-goreng-ungkep-santan-terupdate
date: 2020-11-03T10:32:57.051Z
image: https://img-global.cpcdn.com/recipes/d5c4dcfb8317de83/751x532cq70/ayam-goreng-ungkep-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d5c4dcfb8317de83/751x532cq70/ayam-goreng-ungkep-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d5c4dcfb8317de83/751x532cq70/ayam-goreng-ungkep-santan-foto-resep-utama.jpg
author: Marcus Sherman
ratingvalue: 4.1
reviewcount: 30881
recipeingredient:
- "1 kg ayam saya gak sampai sekilo menyesuaikan stok"
- "2 lembar daun salam"
- "1 batang sereh memarkan"
- "1 bungkus santan kara 65 ml  air jadi 400 ml"
- "1 sdt gula pasir"
- "1 sdt garam"
- "1 sdt kaldu ayam"
- " Bumbu halus"
- "5 siung bawang merah"
- "5 siung bawang putih saya cuma 3 siung"
- "1 sdt ketumbar sangrai saya gak disangrai"
- "2 ruas kunyit saya 1 sdt bubuk kunyit"
- "4 butir kemiri saya 3 butir aja"
recipeinstructions:
- "Ayam, santan, bahan cemplung dan bumbu halus dicampur satu, masak dengan api kecil sampai air menyusut dan kuah mengental"
- "Ayam ungkep bisa ditaroh di wadah untuk stok lauk di kulkas atau bisa langsung digoreng"
categories:
- Recipe
tags:
- ayam
- goreng
- ungkep

katakunci: ayam goreng ungkep 
nutrition: 109 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Goreng Ungkep Santan](https://img-global.cpcdn.com/recipes/d5c4dcfb8317de83/751x532cq70/ayam-goreng-ungkep-santan-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang setidaknya kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam goreng ungkep santan yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan ciri khas yang merupakan keragaman Kita



Kehangatan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah memasak Ayam Goreng Ungkep Santan untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi budaya, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang dapat anda coba salah satunya ayam goreng ungkep santan yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep ayam goreng ungkep santan tanpa harus bersusah payah.
Seperti resep Ayam Goreng Ungkep Santan yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 13 bahan dan 2 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Ungkep Santan:

1. Harap siapkan 1 kg ayam (saya gak sampai sekilo, menyesuaikan stok)
1. Diperlukan 2 lembar daun salam
1. Tambah 1 batang sereh memarkan
1. Dibutuhkan 1 bungkus santan kara 65 ml + air jadi 400 ml
1. Jangan lupa 1 sdt gula pasir
1. Tambah 1 sdt garam
1. Diperlukan 1 sdt kaldu ayam
1. Tambah  Bumbu halus
1. Tambah 5 siung bawang merah
1. Jangan lupa 5 siung bawang putih (saya cuma 3 siung)
1. Tambah 1 sdt ketumbar sangrai (saya gak disangrai)
1. Tambah 2 ruas kunyit (saya 1 sdt bubuk kunyit)
1. Dibutuhkan 4 butir kemiri (saya 3 butir aja)




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Ungkep Santan:

1. Ayam, santan, bahan cemplung dan bumbu halus dicampur satu, masak dengan api kecil sampai air menyusut dan kuah mengental
1. Ayam ungkep bisa ditaroh di wadah untuk stok lauk di kulkas atau bisa langsung digoreng




Demikianlah cara membuat ayam goreng ungkep santan yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan cepat, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
