---
description: "Panduan untuk membuat Ayam Rica-Rica terupdate"
title: "Panduan untuk membuat Ayam Rica-Rica terupdate"
slug: 183-panduan-untuk-membuat-ayam-rica-rica-terupdate
date: 2020-11-15T17:38:32.640Z
image: https://img-global.cpcdn.com/recipes/06a536e18f899955/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/06a536e18f899955/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/06a536e18f899955/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Jack Ellis
ratingvalue: 4.3
reviewcount: 34541
recipeingredient:
- "12 potong ayam"
- "1 buah jeruk nipislemon"
- "500 ml air untuk merebus ayam"
- "350 ml air"
- "10 sdm minyak goreng secukupnya untuk menggoreng bumbu"
- " Bumbu Halus "
- "15 siung bawang merah atau 12 siung ukuran besar"
- "10 siung bawang putih atau 8 siung ukuran besar"
- "4 buah kemiri sangraigoreng"
- "1 jempol kunyit"
- "1/2 jempol jahe"
- "25 buah cabe merah keriting sesuaikan selera"
- " Bumbu pelengkapbumbu Cemplung "
- "1 ikat uk sedang daun kemangi petiki"
- "4 lembar daun salam"
- "6 lembar daun jeruk"
- "1 batang sereh geprek"
- "1 jempol lengkuas geprek"
- "2 sdt garam secukupnya"
- "1 sdt kaldu bubuk"
- "4 sdt gula pasir secukupnya"
recipeinstructions:
- "Siapkan bahan dan bumbu. Cuci ayam sampai bersih, lumuri dengan air jeruk nipis. Diamkan ±10 menit. Lalu bilas lagi sampai bersih. Rebus ayam ± 15 menit saja sampai keluar buih/busa kotornya. siram dengan air bersih, lalu tiriskan. Sisihkan."
- "Siapkan bumbu. Ulek/blender semua bumbu halus. (Lupa photo setelah dihaluskan 🙏)."
- "Siapkan wajan untuk memasak. Panaskan minyak. Tumis bumbu halus bersama daun salam, daun jeruk, sereh dan lengkuas sampai harum dan agak kering. Kemudian masukkan ayam aduk rata sampai terlumuri bumbu, masak ± 2 menit."
- "Tambahkan air. Beri garam, kaldu bubuk dan gula pasir. Aduk rata. Masak sampai ayam ½ matang dan kuah setengah menyusut. Kemudian masukkan daun kemangi, aduk rata. Masak lagi sampai ayam empuk."
- "Setelah kuah menyusut dan mengental cicipi dan koreksi rasa. Jika dirasa ayamnya masih kurang empuk, boleh tambahkan lagi air secukupnya. Masak kembali sampai ayam empuk. Setelah ayam matang / empuk dan kuah mengental, rasa pun sudah pas matikan api."
- "Ayam Rica-Rica siap dihidangkan dengan menu lainnya 🤩."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 209 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/06a536e18f899955/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan gurih. Ciri khas kuliner Indonesia ayam rica-rica yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica-Rica untuk keluarga. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian masakan yang dapat anda praktekkan salah satunya ayam rica-rica yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 21 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica:

1. Jangan lupa 12 potong ayam
1. Tambah 1 buah jeruk nipis/lemon
1. Siapkan 500 ml air untuk merebus ayam
1. Jangan lupa 350 ml air
1. Tambah 10 sdm minyak goreng (secukupnya) untuk menggoreng bumbu
1. Jangan lupa  ✓Bumbu Halus :
1. Dibutuhkan 15 siung bawang merah (atau 12 siung ukuran besar)
1. Tambah 10 siung bawang putih (atau 8 siung ukuran besar)
1. Jangan lupa 4 buah kemiri sangrai/goreng
1. Diperlukan 1 jempol kunyit
1. Harap siapkan 1/2 jempol jahe
1. Jangan lupa 25 buah cabe merah keriting (sesuaikan selera)
1. Siapkan  ✓Bumbu pelengkap/bumbu Cemplung :
1. Siapkan 1 ikat uk. sedang daun kemangi, petiki
1. Jangan lupa 4 lembar daun salam
1. Tambah 6 lembar daun jeruk
1. Harus ada 1 batang sereh, geprek
1. Tambah 1 jempol lengkuas, geprek
1. Harap siapkan 2 sdt garam (secukupnya)
1. Dibutuhkan 1 sdt kaldu bubuk
1. Dibutuhkan 4 sdt gula pasir (secukupnya)




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-Rica:

1. Siapkan bahan dan bumbu. Cuci ayam sampai bersih, lumuri dengan air jeruk nipis. Diamkan ±10 menit. Lalu bilas lagi sampai bersih. Rebus ayam ± 15 menit saja sampai keluar buih/busa kotornya. siram dengan air bersih, lalu tiriskan. Sisihkan.
1. Siapkan bumbu. Ulek/blender semua bumbu halus. (Lupa photo setelah dihaluskan 🙏).
1. Siapkan wajan untuk memasak. Panaskan minyak. Tumis bumbu halus bersama daun salam, daun jeruk, sereh dan lengkuas sampai harum dan agak kering. Kemudian masukkan ayam aduk rata sampai terlumuri bumbu, masak ± 2 menit.
1. Tambahkan air. Beri garam, kaldu bubuk dan gula pasir. Aduk rata. Masak sampai ayam ½ matang dan kuah setengah menyusut. Kemudian masukkan daun kemangi, aduk rata. Masak lagi sampai ayam empuk.
1. Setelah kuah menyusut dan mengental cicipi dan koreksi rasa. Jika dirasa ayamnya masih kurang empuk, boleh tambahkan lagi air secukupnya. Masak kembali sampai ayam empuk. Setelah ayam matang / empuk dan kuah mengental, rasa pun sudah pas matikan api.
1. Ayam Rica-Rica siap dihidangkan dengan menu lainnya 🤩.




Demikianlah cara membuat ayam rica-rica yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan terbukti, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
