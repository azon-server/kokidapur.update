---
description: "Resep : Ayam Bumbu Rujak Luar biasa"
title: "Resep : Ayam Bumbu Rujak Luar biasa"
slug: 480-resep-ayam-bumbu-rujak-luar-biasa
date: 2021-01-28T09:49:29.054Z
image: https://img-global.cpcdn.com/recipes/199cc166ade92d45/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/199cc166ade92d45/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/199cc166ade92d45/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
author: Eunice Paul
ratingvalue: 4.6
reviewcount: 28387
recipeingredient:
- "10 potong ayam"
- "1 batang serei geprek"
- "2 cm lengkuas geprek"
- "3 lembar daun salam"
- "5 lembar daun jeruk"
- "1 keping gula merah"
- "2 sendok makan air asam jawa"
- "65 ml santan saya pakai santan kara"
- " Garam secukupnya saya pakai 5sendok takar 1 gr"
- "450 ml Air"
- " Penyedap rasa secukupnya saya pakai Masako sapi"
- " Bumbu Halus"
- "4 siung bawang putih"
- "8 siung bawang merah"
- "3 butir kemiri sangrai"
- "1 jempol jahe"
- "2 cm kunyit"
- "8 buah cabai keriting sesuai selera"
- "15 buah cabai rawit sesuai selera"
recipeinstructions:
- "Cuci bersih ayam, lumuri dengan jeruk nipis, tunggu kurang lebih 10 menit, bilas, lalu rebus dengan air mendidih"
- "Tumis bumbu halus hingga harum, masukkan serei, lengkuas, daun salam dan daun jeruk. Masak hingga matang"
- "Tambahkan santan, gula merah, garam, air asam jawa, penyedap dan air. Koreksi rasa."
- "Masukkan ayam, ungkep hingga air surut. Ayam bisa lgsg dimakan atau dibakar lagi."
categories:
- Recipe
tags:
- ayam
- bumbu
- rujak

katakunci: ayam bumbu rujak 
nutrition: 132 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Bumbu Rujak](https://img-global.cpcdn.com/recipes/199cc166ade92d45/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas atau empuk. Karasteristik makanan Nusantara ayam bumbu rujak yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Keharmonisan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah memasak Ayam Bumbu Rujak untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang dapat anda praktekkan salah satunya ayam bumbu rujak yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep ayam bumbu rujak tanpa harus bersusah payah.
Seperti resep Ayam Bumbu Rujak yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 19 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Bumbu Rujak:

1. Diperlukan 10 potong ayam
1. Harus ada 1 batang serei, geprek
1. Jangan lupa 2 cm lengkuas, geprek
1. Jangan lupa 3 lembar daun salam
1. Harus ada 5 lembar daun jeruk
1. Tambah 1 keping gula merah
1. Siapkan 2 sendok makan air asam jawa
1. Jangan lupa 65 ml santan (saya pakai santan kara)
1. Harap siapkan  Garam secukupnya (saya pakai 5@sendok takar 1 gr)
1. Diperlukan 450 ml Air
1. Jangan lupa  Penyedap rasa secukupnya (saya pakai Masako sapi)
1. Dibutuhkan  Bumbu Halus
1. Harap siapkan 4 siung bawang putih
1. Jangan lupa 8 siung bawang merah
1. Harap siapkan 3 butir kemiri sangrai
1. Dibutuhkan 1 jempol jahe
1. Dibutuhkan 2 cm kunyit
1. Diperlukan 8 buah cabai keriting (sesuai selera)
1. Dibutuhkan 15 buah cabai rawit (sesuai selera)




<!--inarticleads2-->

##### Langkah membuat  Ayam Bumbu Rujak:

1. Cuci bersih ayam, lumuri dengan jeruk nipis, tunggu kurang lebih 10 menit, bilas, lalu rebus dengan air mendidih
1. Tumis bumbu halus hingga harum, masukkan serei, lengkuas, daun salam dan daun jeruk. Masak hingga matang
1. Tambahkan santan, gula merah, garam, air asam jawa, penyedap dan air. Koreksi rasa.
1. Masukkan ayam, ungkep hingga air surut. Ayam bisa lgsg dimakan atau dibakar lagi.




Demikianlah cara membuat ayam bumbu rujak yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
