---
description: "Langkah untuk membuat 96. Ayam rica-rica Luar biasa"
title: "Langkah untuk membuat 96. Ayam rica-rica Luar biasa"
slug: 152-langkah-untuk-membuat-96-ayam-rica-rica-luar-biasa
date: 2020-10-05T00:02:35.896Z
image: https://img-global.cpcdn.com/recipes/078931f2cca82fd2/751x532cq70/96-ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/078931f2cca82fd2/751x532cq70/96-ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/078931f2cca82fd2/751x532cq70/96-ayam-rica-rica-foto-resep-utama.jpg
author: Gertrude McCoy
ratingvalue: 4.2
reviewcount: 48006
recipeingredient:
- "300 gr ayam"
- "200 ml air"
- "1 batang serai memarkan"
- "2 lembar daun slam"
- "2 lmbar daun jeruk"
- "1 jempol lengkuas geprek"
- "Sejumput kaldu bubuk"
- "1 sdt garam"
- "1 sdm gulpas"
- "3 sdm minyak goreng"
- " Bumbu halus"
- "8 buah cabe merah keriting"
- "15 buah cabe rawit"
- "3 siung baput"
- "4 butir bamer"
- "1 butir kemiri"
- "1/2 sdm ketumbar"
- "1 ruas kunyit"
- "1 ruas jahe"
recipeinstructions:
- "Pertama potong2 ayam cuci bersih tiriskan"
- "Ke-2 halus kan 2cabe, bamer, baput, kemiri, ketumbar, kunyit &amp; jahe. Setelah halus panaskan minyak goreng, masukkan bumbu halus tambahkan juga daun salam, serai, daun jeruk tumis hingga harum"
- "Ke-3 setelah harum masukkan ayam, air bumbui dengan garam, gulpas &amp; kaldu bubuk. Jangan lupa tes rasa"
- "Ke-4 masak hingga air menyusut &amp; mengental. Matikan kompor siap di hidangkan. Di nikmati dengan nasi hangatl, 😄"
categories:
- Recipe
tags:
- 96
- ayam
- ricarica

katakunci: 96 ayam ricarica 
nutrition: 183 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT35M"
recipeyield: "2"
recipecategory: Dinner

---


![96. Ayam rica-rica](https://img-global.cpcdn.com/recipes/078931f2cca82fd2/751x532cq70/96-ayam-rica-rica-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti 96. ayam rica-rica yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa keistimewahan yang merupakan keragaman Kita

Kedekatan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak 96. Ayam rica-rica untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang bisa anda coba salah satunya 96. ayam rica-rica yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep 96. ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep 96. Ayam rica-rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat 96. Ayam rica-rica:

1. Diperlukan 300 gr ayam
1. Siapkan 200 ml air
1. Harap siapkan 1 batang serai (memarkan)
1. Harus ada 2 lembar daun slam
1. Tambah 2 lmbar daun jeruk
1. Tambah 1 jempol lengkuas geprek
1. Tambah Sejumput kaldu bubuk
1. Diperlukan 1 sdt garam
1. Harap siapkan 1 sdm gulpas
1. Jangan lupa 3 sdm minyak goreng
1. Harus ada  Bumbu halus;
1. Tambah 8 buah cabe merah keriting
1. Dibutuhkan 15 buah cabe rawit
1. Tambah 3 siung baput
1. Diperlukan 4 butir bamer
1. Diperlukan 1 butir kemiri
1. Tambah 1/2 sdm ketumbar
1. Harap siapkan 1 ruas kunyit
1. Jangan lupa 1 ruas jahe




<!--inarticleads2-->

##### Cara membuat  96. Ayam rica-rica:

1. Pertama potong2 ayam cuci bersih tiriskan
1. Ke-2 halus kan 2cabe, bamer, baput, kemiri, ketumbar, kunyit &amp; jahe. Setelah halus panaskan minyak goreng, masukkan bumbu halus tambahkan juga daun salam, serai, daun jeruk tumis hingga harum
1. Ke-3 setelah harum masukkan ayam, air bumbui dengan garam, gulpas &amp; kaldu bubuk. Jangan lupa tes rasa
1. Ke-4 masak hingga air menyusut &amp; mengental. Matikan kompor siap di hidangkan. Di nikmati dengan nasi hangatl, 😄




Demikianlah cara membuat 96. ayam rica-rica yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
