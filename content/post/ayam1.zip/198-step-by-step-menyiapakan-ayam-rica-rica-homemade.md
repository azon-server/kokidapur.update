---
description: "Step-by-Step menyiapakan Ayam Rica Rica Homemade"
title: "Step-by-Step menyiapakan Ayam Rica Rica Homemade"
slug: 198-step-by-step-menyiapakan-ayam-rica-rica-homemade
date: 2020-11-07T14:07:28.166Z
image: https://img-global.cpcdn.com/recipes/2adc3c180bf74271/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2adc3c180bf74271/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2adc3c180bf74271/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Loretta Massey
ratingvalue: 4
reviewcount: 30430
recipeingredient:
- "1 ekor ayam potong 12"
- "sejempol Jahe"
- "2 btg serai geprek"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 buah tomat besar"
- "1 siung daun bawang"
- "1 ikat kemangi kl saya skip krn bwt anak"
- "secukupnya Garamgula dan penyedap"
- " Bumbu Halus "
- "6 siung bawang merah"
- "4 siung bawang putih"
- "2 butir kemiri"
- "6 buah cabe  sesuai selera"
- "secukupnya Air"
recipeinstructions:
- "Cuci bersih ayam lalu lumurin air perasan air jeruk diemkan slm kurleb 10menit lalu cuci bersih rebus sebentar ksih jahe yg sudah geprek. Rebus sebentar matikan kompor."
- "Tumiskan bumbu halus lalu masukkan daun salam, serai dan daun jeruk (disobek) lalu tuang air rebusan td sedikit lalu aduk masukkan garam,gula dan penyedap"
- "Masukkan ayam aduk koreksi rasa masukkan tomat dan daun bawang lalu tggu hingga mateng lalu masukkan kemangi. Aduk matikan kompor sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 274 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/2adc3c180bf74271/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang setidaknya kita jaga karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica rica yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Kita

Kedekatan rumah tangga dapat ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica Rica untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang dapat anda buat salah satunya ayam rica rica yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam rica rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 15 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica:

1. Siapkan 1 ekor ayam potong 12
1. Tambah sejempol Jahe
1. Diperlukan 2 btg serai geprek
1. Tambah 2 lembar daun salam
1. Dibutuhkan 3 lembar daun jeruk
1. Dibutuhkan 1 buah tomat besar
1. Tambah 1 siung daun bawang
1. Harus ada 1 ikat kemangi (kl saya skip krn bwt anak²)
1. Harap siapkan secukupnya Garam,gula, dan penyedap
1. Harus ada  Bumbu Halus :
1. Diperlukan 6 siung bawang merah
1. Harus ada 4 siung bawang putih
1. Siapkan 2 butir kemiri
1. Harus ada 6 buah cabe / sesuai selera
1. Tambah secukupnya Air




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica:

1. Cuci bersih ayam lalu lumurin air perasan air jeruk diemkan slm kurleb 10menit lalu cuci bersih rebus sebentar ksih jahe yg sudah geprek. Rebus sebentar matikan kompor.
1. Tumiskan bumbu halus lalu masukkan daun salam, serai dan daun jeruk (disobek) lalu tuang air rebusan td sedikit lalu aduk masukkan garam,gula dan penyedap
1. Masukkan ayam aduk koreksi rasa masukkan tomat dan daun bawang lalu tggu hingga mateng lalu masukkan kemangi. Aduk matikan kompor sajikan




Demikianlah cara membuat ayam rica rica yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
