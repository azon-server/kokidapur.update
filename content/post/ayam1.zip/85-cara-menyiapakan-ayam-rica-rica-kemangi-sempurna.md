---
description: "Cara menyiapakan Ayam rica rica kemangi Sempurna"
title: "Cara menyiapakan Ayam rica rica kemangi Sempurna"
slug: 85-cara-menyiapakan-ayam-rica-rica-kemangi-sempurna
date: 2020-11-30T13:54:31.754Z
image: https://img-global.cpcdn.com/recipes/487b5054e66b7d5f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/487b5054e66b7d5f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/487b5054e66b7d5f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Arthur Schwartz
ratingvalue: 4.9
reviewcount: 32907
recipeingredient:
- "5 potong ayam"
- "1 ikat kemangi"
- "4 daun jeruk"
- "1 sereh"
- "2 ruas lengkuas"
- "1 tomat"
- "1 masako"
- "1 jeruk nipis"
- " Bahan halus"
- "5 bawang merah"
- "3 bawang putih"
- "20 cabe rawit"
- "6 cabe merah"
- "2 ruas kunyit"
- "1 ruas jahe"
- "3 kemiri"
recipeinstructions:
- "5 potong ayam, dipotong jadi 3 bagian lagi, cuci bersih lalu beri perasan jeruk nipis, sisihkan"
- "Siapkan bumbu halus dan blender. Tomat di potong², kemangi ambil daunnya saja"
- "Panaskan minyak, tumis bumbu halus hingga harum, masukkan tomat, daun jeruk, sereh geprek dan lengkuas geprek, tumis sampai bumbu berwarna pekat."
- "Masukkan ayam, aduk sampai benar² rata. Tambahkan air sedikit, aduk sampai tercampur rata, tutup masakan dan diamkan sejenak sampai ayam empuk."
- "Masukkan kemangi dan masako, aduk sebentar. Masakan sudah siap dinikmati bersama nasi hangat 😉"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 246 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/487b5054e66b7d5f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas dan gurih. Ciri kuliner Indonesia ayam rica rica kemangi yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam rica rica kemangi untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis makanan yang bisa anda contoh salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi:

1. Siapkan 5 potong ayam
1. Harus ada 1 ikat kemangi
1. Jangan lupa 4 daun jeruk
1. Siapkan 1 sereh
1. Tambah 2 ruas lengkuas
1. Harap siapkan 1 tomat
1. Dibutuhkan 1 masako
1. Dibutuhkan 1 jeruk nipis
1. Tambah  Bahan halus
1. Jangan lupa 5 bawang merah
1. Tambah 3 bawang putih
1. Dibutuhkan 20 cabe rawit
1. Diperlukan 6 cabe merah
1. Jangan lupa 2 ruas kunyit
1. Tambah 1 ruas jahe
1. Harap siapkan 3 kemiri




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica rica kemangi:

1. 5 potong ayam, dipotong jadi 3 bagian lagi, cuci bersih lalu beri perasan jeruk nipis, sisihkan
1. Siapkan bumbu halus dan blender. Tomat di potong², kemangi ambil daunnya saja
1. Panaskan minyak, tumis bumbu halus hingga harum, masukkan tomat, daun jeruk, sereh geprek dan lengkuas geprek, tumis sampai bumbu berwarna pekat.
1. Masukkan ayam, aduk sampai benar² rata. Tambahkan air sedikit, aduk sampai tercampur rata, tutup masakan dan diamkan sejenak sampai ayam empuk.
1. Masukkan kemangi dan masako, aduk sebentar. Masakan sudah siap dinikmati bersama nasi hangat 😉




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat gampang dan terbukti, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
