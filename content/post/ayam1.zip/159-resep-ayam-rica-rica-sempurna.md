---
description: "Resep : Ayam Rica Rica Sempurna"
title: "Resep : Ayam Rica Rica Sempurna"
slug: 159-resep-ayam-rica-rica-sempurna
date: 2020-09-28T08:59:59.049Z
image: https://img-global.cpcdn.com/recipes/c80cd2bd0dd9d86a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c80cd2bd0dd9d86a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c80cd2bd0dd9d86a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Mary Brock
ratingvalue: 4.6
reviewcount: 38396
recipeingredient:
- "1 ekor Ayam"
- "1 buah jeruk nipis"
- " Kaldu bubuk optional"
- " Minyak secukupnya untuk menggoreng ayam"
- "2 lembar Daun salam"
- "3 lembar Daun jeruk iris tipis"
- "1 tangkai Daun bawang iris sedang"
- "2 ikat kecil Daun kemangi sesuai selera"
- "1 batang Sereh geprek"
- "200 ml Air"
- " Bumbu yang dihaluskan "
- "10 buah Cabai merah keriting"
- "8 buah Cabai rawit sesuai selera"
- "5 siung Bawang merah"
- "2 siung Bawang putih"
- "3 butir kemiri"
- "1 ruas jari Kunyit"
- "1 ruas jari lengkuas"
- "1 ruas jari jahe"
- "1 sdt Garam"
- "1  2 sdt Gula putih"
- " Kaldu bubuk rasa ayam optional"
recipeinstructions:
- "Potong ayam menjadi 10 bagian. Bersihkan. Lumuri dengan air jeruk nipis dan kaldu bubuk (optional), diamkan 30 menit. Lalu goreng 1/2 matang, angkat tiriskan."
- "Siapkan bumbu-bumbu. Haluskan, diulek atau diblender. Tumis bumbu halus (ambil 2 sendok makan minyak bekas goreng ayam), masukkan daun salam, serai dan daun jeruk, tumis sampai harum. Masukkan ayam, aduk rata dengan bumbu."
- "Tuang air dan tambahkan garam, gula putih dan kaldu bubuk, ratakan. Masak ayam sampai air kering (sesekali ayam diaduk), sebelum diangkat masukkan daun kemangi dan daun bawang, aduk rata, tes rasa. Ayam rica-rica siap disantap."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 151 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/c80cd2bd0dd9d86a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau gurih. Ciri khas kuliner Indonesia ayam rica rica yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica Rica untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis makanan yang bisa anda praktekkan salah satunya ayam rica rica yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica:

1. Jangan lupa 1 ekor Ayam
1. Harap siapkan 1 buah jeruk nipis
1. Harus ada  Kaldu bubuk (optional)
1. Dibutuhkan  Minyak secukupnya untuk menggoreng ayam
1. Dibutuhkan 2 lembar Daun salam
1. Tambah 3 lembar Daun jeruk (iris tipis)
1. Diperlukan 1 tangkai Daun bawang (iris sedang)
1. Jangan lupa 2 ikat kecil Daun kemangi (sesuai selera)
1. Diperlukan 1 batang Sereh (geprek)
1. Harus ada 200 ml Air
1. Diperlukan  Bumbu yang dihaluskan :
1. Harap siapkan 10 buah Cabai merah keriting
1. Harus ada 8 buah Cabai rawit (sesuai selera)
1. Dibutuhkan 5 siung Bawang merah
1. Jangan lupa 2 siung Bawang putih
1. Dibutuhkan 3 butir kemiri
1. Diperlukan 1 ruas jari Kunyit
1. Siapkan 1 ruas jari lengkuas
1. Diperlukan 1 ruas jari jahe
1. Harap siapkan 1 sdt Garam
1. Diperlukan 1 / 2 sdt Gula putih
1. Diperlukan  Kaldu bubuk rasa ayam (optional)




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica:

1. Potong ayam menjadi 10 bagian. Bersihkan. Lumuri dengan air jeruk nipis dan kaldu bubuk (optional), diamkan 30 menit. Lalu goreng 1/2 matang, angkat tiriskan.
1. Siapkan bumbu-bumbu. Haluskan, diulek atau diblender. Tumis bumbu halus (ambil 2 sendok makan minyak bekas goreng ayam), masukkan daun salam, serai dan daun jeruk, tumis sampai harum. Masukkan ayam, aduk rata dengan bumbu.
1. Tuang air dan tambahkan garam, gula putih dan kaldu bubuk, ratakan. Masak ayam sampai air kering (sesekali ayam diaduk), sebelum diangkat masukkan daun kemangi dan daun bawang, aduk rata, tes rasa. Ayam rica-rica siap disantap.




Demikianlah cara membuat ayam rica rica yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan teruji, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
