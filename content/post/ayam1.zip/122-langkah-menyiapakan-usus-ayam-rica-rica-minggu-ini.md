---
description: "Langkah menyiapakan Usus ayam rica-rica minggu ini"
title: "Langkah menyiapakan Usus ayam rica-rica minggu ini"
slug: 122-langkah-menyiapakan-usus-ayam-rica-rica-minggu-ini
date: 2021-01-08T02:51:10.307Z
image: https://img-global.cpcdn.com/recipes/fc2b6b9a33d1d47c/751x532cq70/usus-ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fc2b6b9a33d1d47c/751x532cq70/usus-ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fc2b6b9a33d1d47c/751x532cq70/usus-ayam-rica-rica-foto-resep-utama.jpg
author: Virgie Quinn
ratingvalue: 4.5
reviewcount: 22804
recipeingredient:
- "300 g usus ayam"
- "1/2 sdt garam"
- "3 lembar daun jeruk"
- "1000 ml air untuk merebus"
- "2 lembar daun salam"
- "1 cm lengkuas dimemarkan"
- "1 batang serai dimemarkan"
- "3 lembar daun jeruk"
- "3/4 sdt garam"
- "1/2 sdt gula pasir"
- "2 sdm minyak untuk menumis"
- " Minyak untuk menggoreng"
- " Bumbu tumbuk Kasar "
- "8 butir bawang merah"
- "2 siung bawang putih"
- "4 buah cabai merah keriting"
- "3 buah cabai merah besar"
- "2 buah cabai"
- "1 buah tomat"
recipeinstructions:
- "Rebus usus ayam, garam dan daun jeruk sampai matang. Angkat. Tiriskan. Goreng dalam minyak yang sudah dipanaskan sampai kuning kecoklatan. Tiriskan."
- "Panaskan minyak, tumis bumbu tumbuk kasar, daun salam, lengkuas, serai, dan daun jeruk hingga harum. Masukkan usus. Aduk rata. Tambahkan garam dan gula pasir. Aduk rata. Masak hingga bumbu meresap."
- "Angkat dan sajikan."
categories:
- Recipe
tags:
- usus
- ayam
- ricarica

katakunci: usus ayam ricarica 
nutrition: 297 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Dinner

---


![Usus ayam rica-rica](https://img-global.cpcdn.com/recipes/fc2b6b9a33d1d47c/751x532cq70/usus-ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan empuk. Ciri kuliner Nusantara usus ayam rica-rica yang kaya dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica. Rasa pedas, gurih dan empuk daging ayamnya terbukti sangat cocok disajikan bersama nasi dalam. Cara membuat masakan ayam rica rica sebenarnya hampir sama dengan resep ayam pedas lainnya, hanya takran dan bahan bumbunya saja yang sedikit berbeda.

Keharmonisan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Usus ayam rica-rica untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang bisa anda buat salah satunya usus ayam rica-rica yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep usus ayam rica-rica tanpa harus bersusah payah.
Seperti resep Usus ayam rica-rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Usus ayam rica-rica:

1. Dibutuhkan 300 g usus ayam
1. Harus ada 1/2 sdt garam
1. Tambah 3 lembar daun jeruk
1. Jangan lupa 1000 ml air untuk merebus
1. Harap siapkan 2 lembar daun salam
1. Jangan lupa 1 cm lengkuas, dimemarkan
1. Harus ada 1 batang serai, dimemarkan
1. Siapkan 3 lembar daun jeruk
1. Jangan lupa 3/4 sdt garam
1. Tambah 1/2 sdt gula pasir
1. Dibutuhkan 2 sdm minyak untuk menumis
1. Tambah  Minyak untuk menggoreng
1. Siapkan  Bumbu tumbuk Kasar ::
1. Harap siapkan 8 butir bawang merah
1. Siapkan 2 siung bawang putih
1. Dibutuhkan 4 buah cabai merah keriting
1. Tambah 3 buah cabai merah besar
1. Harap siapkan 2 buah cabai
1. Jangan lupa 1 buah tomat


The origin of this dish is from Minahasan cuisine of North Sulawesi. Kita masak Ayam Rica-Rica aja yuk. Tapi biar lebih nikmat kita tambahi rasa manis sedikit. Nah, saya sudah memasak Daging Ayam menjadi Ayam Rica-Rica Pedas Manis. 

<!--inarticleads2-->

##### Langkah membuat  Usus ayam rica-rica:

1. Rebus usus ayam, garam dan daun jeruk sampai matang. Angkat. Tiriskan. Goreng dalam minyak yang sudah dipanaskan sampai kuning kecoklatan. Tiriskan.
1. Panaskan minyak, tumis bumbu tumbuk kasar, daun salam, lengkuas, serai, dan daun jeruk hingga harum. Masukkan usus. Aduk rata. Tambahkan garam dan gula pasir. Aduk rata. Masak hingga bumbu meresap.
1. Angkat dan sajikan.


Tapi biar lebih nikmat kita tambahi rasa manis sedikit. Nah, saya sudah memasak Daging Ayam menjadi Ayam Rica-Rica Pedas Manis. Kira-kira kalo Mi Fans semuanya diberikan bahan dasar Daging Ayam, mau dimasak apa? This Ayam (chicken) can be pre-cooked and placed on the grill and served with the rica rica (the spicy sauce). Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. 

Demikianlah cara membuat usus ayam rica-rica yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat gampang dan teruji, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
