---
description: "Panduan membuat Ayam rica rica pedaass kemangiii Sempurna"
title: "Panduan membuat Ayam rica rica pedaass kemangiii Sempurna"
slug: 155-panduan-membuat-ayam-rica-rica-pedaass-kemangiii-sempurna
date: 2020-10-03T10:08:58.119Z
image: https://img-global.cpcdn.com/recipes/6780ea3e98911f94/751x532cq70/ayam-rica-rica-pedaass-kemangiii-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6780ea3e98911f94/751x532cq70/ayam-rica-rica-pedaass-kemangiii-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6780ea3e98911f94/751x532cq70/ayam-rica-rica-pedaass-kemangiii-foto-resep-utama.jpg
author: Allen Brady
ratingvalue: 4.1
reviewcount: 19243
recipeingredient:
- "1/2 ayam"
- "1 ruas lengkuas geprek"
- "1 ruas jahe geprek"
- "1 sereh geprek"
- "2 daun Jeruk"
- " Sec Daun bawang"
- " Kemangi"
- "1 Tomat"
- " Sec gula"
- " Sec garam"
- " Sec penyedap rasa"
- " Bumbu halus"
- "5 bawang merah"
- "3 bawang putih"
- "22 cabe rawit selera"
- "3 cabe merah"
- "1 ruas kunyit"
- "4 kemiri"
recipeinstructions:
- "Bersihkan ayam lalu potong sesuai selera beri garam kunyit iris dan bawang putih agar tidak bau amiss"
- "Blender bumbu halus iris bahan di geprek dan daun bawang,tomat"
- "Panaskan minyak masukan bumbu halus tadi dan masukan sereh,Laos,jahe,daun jeruk, gula pasir,garam dan penyedap rasa setelah bumbu berubah warna(matang) masukan ayam tadi oseng terlebih dahulu baru beri air sec agar ayam matang dan empuk"
- "Setelah itu tutup agar meresap dan bukaa koreksi rasa jika sudah masukan daun bawang,tomat tunggu lagi Sampai airnya berkurang"
- "Taraa ayam rica-rica pedas kemangi siap disantap rasanya aahhhh mantab🤭🤩"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 190 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica rica pedaass kemangiii](https://img-global.cpcdn.com/recipes/6780ea3e98911f94/751x532cq70/ayam-rica-rica-pedaass-kemangiii-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica rica pedaass kemangiii yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa keistimewahan yang merupakan keragaman Nusantara

Rica-rica dalam bahasa Manado (Sulawesi Utara) berarti pedas atau cabe. dalam proses masaknya beraneka ragam. Masakan kali ini dengan menambah daun kemangi. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica.

Kehangatan keluarga dapat diperoleh dengan cara simple. Diantaranya adalah membuat makanan Ayam rica rica pedaass kemangiii untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang dapat anda buat salah satunya ayam rica rica pedaass kemangiii yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep ayam rica rica pedaass kemangiii tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica pedaass kemangiii yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica pedaass kemangiii:

1. Harus ada 1/2 ayam
1. Harus ada 1 ruas lengkuas (geprek)
1. Dibutuhkan 1 ruas jahe (geprek)
1. Harap siapkan 1 sereh (geprek)
1. Harus ada 2 daun Jeruk
1. Siapkan  Sec Daun bawang
1. Jangan lupa  Kemangi
1. Siapkan 1 Tomat
1. Tambah  Sec gula
1. Tambah  Sec garam
1. Dibutuhkan  Sec penyedap rasa
1. Harus ada  Bumbu halus
1. Harus ada 5 bawang merah
1. Diperlukan 3 bawang putih
1. Tambah 22 cabe rawit (selera)
1. Dibutuhkan 3 cabe merah
1. Siapkan 1 ruas kunyit
1. Harap siapkan 4 kemiri


Bumbu rica-rica khas Manado bisa dipadukan dengan aneka bahan, seperti ayam. Coba membuat ayam panggang bumbu rica-rica berdasarkan resep ini. Cara pembuatan ayam rica-rica tidaklah sulit. Dibutuhkan bahan-bahan seperti daun jeruk, serai, dan daun pandan agar aromanya menjadi kuat dan khas. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica pedaass kemangiii:

1. Bersihkan ayam lalu potong sesuai selera beri garam kunyit iris dan bawang putih agar tidak bau amiss
1. Blender bumbu halus iris bahan di geprek dan daun bawang,tomat
1. Panaskan minyak masukan bumbu halus tadi dan masukan sereh,Laos,jahe,daun jeruk, gula pasir,garam dan penyedap rasa setelah bumbu berubah warna(matang) masukan ayam tadi oseng terlebih dahulu baru beri air sec agar ayam matang dan empuk
1. Setelah itu tutup agar meresap dan bukaa koreksi rasa jika sudah masukan daun bawang,tomat tunggu lagi Sampai airnya berkurang
1. Taraa ayam rica-rica pedas kemangi siap disantap rasanya aahhhh mantab🤭🤩


Cara pembuatan ayam rica-rica tidaklah sulit. Dibutuhkan bahan-bahan seperti daun jeruk, serai, dan daun pandan agar aromanya menjadi kuat dan khas. Tak hanya ayam, anda juga bisa memasak bebek atau telur dengan bumbu rica-rica ini. Sebenarnya, untuk membuat rica-rica ayam itu hampir sama dengan kita mengolah ayam pedas lainnya, mungkin saja jumlah bumbu yang digunakan lebih bervariasi seperti: cabai, kunyit, serai, bawang merah dan sebagainya. Selain itu, cara membuat makanan lezat ini dengan cara digoreng. 

Demikianlah cara membuat ayam rica rica pedaass kemangiii yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
