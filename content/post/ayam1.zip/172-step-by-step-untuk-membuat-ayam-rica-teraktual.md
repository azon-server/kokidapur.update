---
description: "Step-by-Step untuk membuat Ayam Rica teraktual"
title: "Step-by-Step untuk membuat Ayam Rica teraktual"
slug: 172-step-by-step-untuk-membuat-ayam-rica-teraktual
date: 2020-12-23T18:33:50.826Z
image: https://img-global.cpcdn.com/recipes/de1146df94709b73/751x532cq70/ayam-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/de1146df94709b73/751x532cq70/ayam-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/de1146df94709b73/751x532cq70/ayam-rica-foto-resep-utama.jpg
author: Harriett Peters
ratingvalue: 4.7
reviewcount: 46454
recipeingredient:
- "1/2 kg ayam potong2"
- "12 buah cabai merah keriting"
- "6 butir bawang merah"
- "2 siung bawang putih"
- "1 ruas kecil jahe geprek"
- "1/2 ruas kunyit geprek"
- "3 butir kemiri haluskan"
- "2 buah tomat"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1/2 ruas lengkuas geprek"
- "1 batang serai"
- "1 sdt garam"
- "1/2 buah gula merah"
- "1 sdm gula pasir"
- "1/2 sdt kaldu bubuk"
- "1/4 sdt merica"
- "1 sdm kecap manis"
- "Secukupnya daun kemangi"
- "Secukupnya daun bawang"
- "2 gelas air"
recipeinstructions:
- "Haluskan semua bumbu kecuali daun jeruk, daun salam, lengkuas, dan serai. Tumis semua bumbu bersamaan hingga harum."
- "Tambahkan tomat yang sudah dipotong-potong, aduk rata hingga tomat layu dan hancur."
- "Masukkan ayam. Aduk rata hingga 1/2 kering lalu beri air 1 gelas. Setelah mendidih masukkan gula, garam, merica dan kaldu bubuk. Besarkan api. Aduk sesekali hingga air menyusut."
- "Koreksi rasa. Tambahkan kecap manis. Terakhir masukkan daun kemangi dan daun bawang. Aduk sebentar lalu matikan api."
- "Angkat dan sajikan."
categories:
- Recipe
tags:
- ayam
- rica

katakunci: ayam rica 
nutrition: 175 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Rica](https://img-global.cpcdn.com/recipes/de1146df94709b73/751x532cq70/ayam-rica-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang dapat kita lestarikan karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Indonesia

Keharmonisan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah memasak Ayam Rica untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang bisa anda praktekkan salah satunya ayam rica yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep ayam rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica:

1. Tambah 1/2 kg ayam, potong2
1. Harus ada 12 buah cabai merah keriting
1. Harap siapkan 6 butir bawang merah
1. Harap siapkan 2 siung bawang putih
1. Jangan lupa 1 ruas kecil jahe, geprek
1. Dibutuhkan 1/2 ruas kunyit, geprek
1. Harap siapkan 3 butir kemiri, haluskan
1. Dibutuhkan 2 buah tomat
1. Siapkan 2 lembar daun salam
1. Jangan lupa 2 lembar daun jeruk
1. Tambah 1/2 ruas lengkuas, geprek
1. Tambah 1 batang serai
1. Jangan lupa 1 sdt garam
1. Jangan lupa 1/2 buah gula merah
1. Harap siapkan 1 sdm gula pasir
1. Siapkan 1/2 sdt kaldu bubuk
1. Siapkan 1/4 sdt merica
1. Harap siapkan 1 sdm kecap manis
1. Dibutuhkan Secukupnya daun kemangi
1. Harus ada Secukupnya daun bawang
1. Jangan lupa 2 gelas air




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica:

1. Haluskan semua bumbu kecuali daun jeruk, daun salam, lengkuas, dan serai. Tumis semua bumbu bersamaan hingga harum.
1. Tambahkan tomat yang sudah dipotong-potong, aduk rata hingga tomat layu dan hancur.
1. Masukkan ayam. Aduk rata hingga 1/2 kering lalu beri air 1 gelas. Setelah mendidih masukkan gula, garam, merica dan kaldu bubuk. Besarkan api. Aduk sesekali hingga air menyusut.
1. Koreksi rasa. Tambahkan kecap manis. Terakhir masukkan daun kemangi dan daun bawang. Aduk sebentar lalu matikan api.
1. Angkat dan sajikan.




Demikianlah cara membuat ayam rica yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
