---
description: "Step-by-Step untuk membuat Ayam Rica-rica Terbukti"
title: "Step-by-Step untuk membuat Ayam Rica-rica Terbukti"
slug: 15-step-by-step-untuk-membuat-ayam-rica-rica-terbukti
date: 2020-09-05T18:57:24.388Z
image: https://img-global.cpcdn.com/recipes/27abe66e83cdea84/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/27abe66e83cdea84/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/27abe66e83cdea84/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Lula Watts
ratingvalue: 4.9
reviewcount: 5004
recipeingredient:
- "4 potong ayam"
- "8 siung bawang merah"
- "1 batang Daun Bawang"
- "2 lembar daun jeruk"
- "1 buah tomat"
- "secukupnya Garam"
- "secukupnya Kaldu"
- "secukupnya Air"
- "secukupnya Minyak"
- " Bumbu halus"
- "3 siung bawang putih"
- "1 batang sereh"
- "1 ruas kunyit"
- "1 ruas jahe"
- "15 cabe merah keriting"
- "5 cabe rawit merah"
recipeinstructions:
- "Bersihkan ayam kemudian beri perasan jeruk nipis dan garam, lalu diamkan sebentar"
- "Rebus ayam terlebih dahulu agar menghilangkan darah di dalam tulang"
- "Cincang bawang merah, kemudian haluskan bumbu. Setelah itu tumis bawang merah terlebih dahulu, apabila sudah sedikit layu, kemudian masukan bumbu yang sudah dihaluskan."
- "Setelah menumis masukan tomat, daun bawang dan daun jeruk, kemudian masukan ayam, oseng2 sebentar lalu tambahkan air"
- "Bumbui kembali dengan kaldu dan garam, koreksi rasa, lalu sajikan..."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 130 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica-rica](https://img-global.cpcdn.com/recipes/27abe66e83cdea84/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga gurih. Ciri makanan Indonesia ayam rica-rica yang penuh dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kedekatan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica-rica untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang dapat anda buat salah satunya ayam rica-rica yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica:

1. Siapkan 4 potong ayam
1. Harus ada 8 siung bawang merah
1. Diperlukan 1 batang Daun Bawang
1. Jangan lupa 2 lembar daun jeruk
1. Dibutuhkan 1 buah tomat
1. Harus ada secukupnya Garam
1. Jangan lupa secukupnya Kaldu
1. Dibutuhkan secukupnya Air
1. Harap siapkan secukupnya Minyak
1. Harap siapkan  Bumbu halus
1. Diperlukan 3 siung bawang putih
1. Dibutuhkan 1 batang sereh
1. Harap siapkan 1 ruas kunyit
1. Jangan lupa 1 ruas jahe
1. Tambah 15 cabe merah keriting
1. Harap siapkan 5 cabe rawit merah




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-rica:

1. Bersihkan ayam kemudian beri perasan jeruk nipis dan garam, lalu diamkan sebentar
1. Rebus ayam terlebih dahulu agar menghilangkan darah di dalam tulang
1. Cincang bawang merah, kemudian haluskan bumbu. Setelah itu tumis bawang merah terlebih dahulu, apabila sudah sedikit layu, kemudian masukan bumbu yang sudah dihaluskan.
1. Setelah menumis masukan tomat, daun bawang dan daun jeruk, kemudian masukan ayam, oseng2 sebentar lalu tambahkan air
1. Bumbui kembali dengan kaldu dan garam, koreksi rasa, lalu sajikan...




Demikianlah cara membuat ayam rica-rica yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
