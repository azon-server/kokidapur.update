---
description: "Cara menyiapakan Ayam rica rica kemangi terupdate"
title: "Cara menyiapakan Ayam rica rica kemangi terupdate"
slug: 60-cara-menyiapakan-ayam-rica-rica-kemangi-terupdate
date: 2020-08-09T07:46:23.511Z
image: https://img-global.cpcdn.com/recipes/e9e4e53b8aff3da7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e9e4e53b8aff3da7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e9e4e53b8aff3da7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Joshua McDaniel
ratingvalue: 4.9
reviewcount: 21032
recipeingredient:
- "500 gr daging ayam marinasi dengan 1 ruas kunyit  12 sdt garam  3siung bawang putih uleg halus diamkan 15 menit"
- "1 ikat daun kemangi"
- "3 btg daun bawang diiris"
- "250 ml air"
- " Bumbu halus"
- "7 siung bawang putih"
- "8 siung bawang merah"
- "1 ruas jahe"
- "4 cabe rawit"
- "2 btr kemiri100 gr cabe merah besar"
- " Bumbu cemplung"
- "2 btg serai digeprek"
- "1 ruas lengkuas digeprek"
- "7 lmbr daun jeruk purut"
- "3 lembar daun salam"
- "1 sdt garam"
- "1 sdt kaldu bubuk"
- "2 sdt gula pasir"
recipeinstructions:
- "Haluskan bumbu saya pakai cooper bisa juga diuleg"
- "Goreng ayam yg sudah dimarinasi 1/2 matang saja angkat tiriskan"
- "Panaskan minyak masukkan bumbu halus, bumbu cemplung, tumis hingga bumbu tanak"
- "Masukkan ayam goreng aduk rata"
- "Masukkan air aduk rata lalu tutup masak dengan api kecil hingga kuah agak menyusut"
- "Masukkan garam, kaldu bubuk, gula pasir aduk rata"
- "Masukkan daun bawang aduk rata"
- "Masukkan daun kemangi aduk sebentar lalu matikan kompor"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 133 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/e9e4e53b8aff3da7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang harus kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica rica kemangi yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa keistimewahan yang merupakan keragaman Kita

Kehangatan keluarga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Ayam rica rica kemangi untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.

Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Inilah rahasia bumbu masakan ayam rica rica dan petunjuk cara membuat rica rica ayam.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang dapat anda buat salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 8 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Tambah 500 gr daging ayam marinasi dengan (1 ruas kunyit + 1/2 sdt garam + 3siung bawang putih uleg halus) diamkan 15 menit
1. Tambah 1 ikat daun kemangi
1. Diperlukan 3 btg daun bawang diiris
1. Tambah 250 ml air
1. Jangan lupa  Bumbu halus
1. Harus ada 7 siung bawang putih
1. Tambah 8 siung bawang merah
1. Dibutuhkan 1 ruas jahe
1. Harus ada 4 cabe rawit
1. Siapkan 2 btr kemiri100 gr cabe merah besar
1. Harap siapkan  Bumbu cemplung
1. Tambah 2 btg serai digeprek
1. Harus ada 1 ruas lengkuas digeprek
1. Dibutuhkan 7 lmbr daun jeruk purut
1. Jangan lupa 3 lembar daun salam
1. Jangan lupa 1 sdt garam
1. Harap siapkan 1 sdt kaldu bubuk
1. Tambah 2 sdt gula pasir


It is made up of chicken that cooked in spicy red and green chili pepper. The origin of this dish is from Minahasan cuisine of North Sulawesi. Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica rica kemangi:

1. Haluskan bumbu saya pakai cooper bisa juga diuleg
1. Goreng ayam yg sudah dimarinasi 1/2 matang saja angkat tiriskan
1. Panaskan minyak masukkan bumbu halus, bumbu cemplung, tumis hingga bumbu tanak
1. Masukkan ayam goreng aduk rata
1. Masukkan air aduk rata lalu tutup masak dengan api kecil hingga kuah agak menyusut
1. Masukkan garam, kaldu bubuk, gula pasir aduk rata
1. Masukkan daun bawang aduk rata
1. Masukkan daun kemangi aduk sebentar lalu matikan kompor


Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. 

Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan terbukti, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
