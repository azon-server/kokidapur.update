---
description: "Langkah untuk menyiapakan Ayam goreng mentega Terbukti"
title: "Langkah untuk menyiapakan Ayam goreng mentega Terbukti"
slug: 333-langkah-untuk-menyiapakan-ayam-goreng-mentega-terbukti
date: 2021-01-17T23:04:55.052Z
image: https://img-global.cpcdn.com/recipes/625e1708c198870c/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/625e1708c198870c/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/625e1708c198870c/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg
author: Ernest Cannon
ratingvalue: 4
reviewcount: 38616
recipeingredient:
- "1 kg ayam"
- "1 bh jeruk nipis"
- "1.5 sdt garam"
- "1 sdt lada putih bubuk"
- "1 sdm bawang bubuk"
- "500 ml minyak goreng"
- "2 sdm mentega"
- " Bahan tumisan"
- "3 sdm mentega"
- "1 bh bawang bombay"
- "10 siung bawang putih"
- "400 ml air putih"
- "5 sdm kecap"
- "1 sdm saos tiram"
- "1 buah tomat dijus  saos tomat botolan"
- "1 sdt garam sesuai selera"
- "1 sdr gula pasir sesuai selera"
- "1 sdt lada putih bubuk"
- "1/2 sdt lada hitam bubuk"
- "3 batang daun bawang"
recipeinstructions:
- "Cuci bersih ayam kemudian lumuri dengan jeruk nipis dan diamkan sekitar 10 menit sembari menyiapkan bahan2 lainnya."
- "Setelah itu bilas kembali ayam dan marinasi dengan garam, bawang bubuk dan lada putih bubuk. Diamkan kembali sekitar 15 menit sembari memanaskan minyak goreng."
- "Setelah itu goreng ayam dengan minyak banyak hingga matang."
- "Tumis bawang bombay dan bawang putih dengan margarin hingga harum dan masukkan ayam kemudian beri air. Dan masukkan bumbu yg lain, kecuali bawang daun. Tunggu hingga mendidih dan tes rasa. Jika dirasa sudah pas kecilkan api dan biarkan hingga air sedikit menyusut. Sesaat sebelum diangkat masukkan bawang daun."
- "Ayam siap dihidangkan. Bisa ditambahkan cabe iris juga kalo mau versi pedas."
- "Selamat mencoba 🤗"
categories:
- Recipe
tags:
- ayam
- goreng
- mentega

katakunci: ayam goreng mentega 
nutrition: 228 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam goreng mentega](https://img-global.cpcdn.com/recipes/625e1708c198870c/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga enak. Ciri khas kuliner Indonesia ayam goreng mentega yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam goreng mentega untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang dapat anda buat salah satunya ayam goreng mentega yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam goreng mentega tanpa harus bersusah payah.
Seperti resep Ayam goreng mentega yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam goreng mentega:

1. Jangan lupa 1 kg ayam
1. Tambah 1 bh jeruk nipis
1. Harus ada 1.5 sdt garam
1. Diperlukan 1 sdt lada putih bubuk
1. Siapkan 1 sdm bawang bubuk
1. Tambah 500 ml minyak goreng
1. Tambah 2 sdm mentega
1. Harus ada  Bahan tumisan
1. Jangan lupa 3 sdm mentega
1. Harus ada 1 bh bawang bombay
1. Harap siapkan 10 siung bawang putih
1. Jangan lupa 400 ml air putih
1. Harap siapkan 5 sdm kecap
1. Dibutuhkan 1 sdm saos tiram
1. Jangan lupa 1 buah tomat dijus / saos tomat botolan
1. Siapkan 1 sdt garam (sesuai selera)
1. Tambah 1 sdr gula pasir (sesuai selera)
1. Dibutuhkan 1 sdt lada putih bubuk
1. Diperlukan 1/2 sdt lada hitam bubuk
1. Harap siapkan 3 batang daun bawang




<!--inarticleads2-->

##### Cara membuat  Ayam goreng mentega:

1. Cuci bersih ayam kemudian lumuri dengan jeruk nipis dan diamkan sekitar 10 menit sembari menyiapkan bahan2 lainnya.
1. Setelah itu bilas kembali ayam dan marinasi dengan garam, bawang bubuk dan lada putih bubuk. Diamkan kembali sekitar 15 menit sembari memanaskan minyak goreng.
1. Setelah itu goreng ayam dengan minyak banyak hingga matang.
1. Tumis bawang bombay dan bawang putih dengan margarin hingga harum dan masukkan ayam kemudian beri air. Dan masukkan bumbu yg lain, kecuali bawang daun. Tunggu hingga mendidih dan tes rasa. Jika dirasa sudah pas kecilkan api dan biarkan hingga air sedikit menyusut. Sesaat sebelum diangkat masukkan bawang daun.
1. Ayam siap dihidangkan. Bisa ditambahkan cabe iris juga kalo mau versi pedas.
1. Selamat mencoba 🤗




Demikianlah cara membuat ayam goreng mentega yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
