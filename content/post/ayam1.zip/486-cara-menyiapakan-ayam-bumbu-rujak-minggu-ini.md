---
description: "Cara menyiapakan Ayam Bumbu Rujak minggu ini"
title: "Cara menyiapakan Ayam Bumbu Rujak minggu ini"
slug: 486-cara-menyiapakan-ayam-bumbu-rujak-minggu-ini
date: 2020-11-27T15:04:22.032Z
image: https://img-global.cpcdn.com/recipes/69f6fc3ec2e737ce/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/69f6fc3ec2e737ce/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/69f6fc3ec2e737ce/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
author: Julia Scott
ratingvalue: 4.4
reviewcount: 28787
recipeingredient:
- " BAHAN "
- "1 ekor ayam ukuran sedang rebus sebentar"
- "500-700 ml santan perasan pertama dari 12 butir kelapa besar"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "1 ruas lengkuas geprek"
- "1 helai serai geprek"
- "secukupnya Gula merah"
- "secukupnya Garam"
- "2 sdm air asam jawa"
- " BUMBU HALUS "
- "12 cabe keriting"
- "6 cabe rawit"
- "10 siung bawang merah"
- "6 siung bawang putih"
- "6 butir kemiri sangrai sebentar"
- "1 ruas kunyit"
- "1 ruas jahe"
recipeinstructions:
- "Siapkan semua bahan. Ayam dibersihkan, beri jeruk dan garam diamkan lalu cuci bersih ayam kemudian rebas sebentar saja."
- "Tumis bumbu halus sampai benar benar tanek. Masukkan sereh, salam, daun jeruk dan lengkuas. Tumis bumbu hingga wangi dan matang kemudian masukkan ayam aduk sampai rata."
- "Masukkan santan cair aduk aduk, bumbui dengan gula, garam, air asam jawa, masak sampai bumbu meresap dan mengental (proses masak saya tutup hingga kuah mengental)"
- "Panggang ayam, lalu oles dengan sisa bumbu ayam. Kalau kuah belum pedas bisa tambahkan cabai pada proses penghalusan bumbu ya moms. (saya tidak saya panggang, saya makan begini aja moms 😁👍👍)"
categories:
- Recipe
tags:
- ayam
- bumbu
- rujak

katakunci: ayam bumbu rujak 
nutrition: 222 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT46M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Bumbu Rujak](https://img-global.cpcdn.com/recipes/69f6fc3ec2e737ce/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan enak. Karasteristik kuliner Indonesia ayam bumbu rujak yang kaya dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam Bumbu Rujak untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda praktekkan salah satunya ayam bumbu rujak yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep ayam bumbu rujak tanpa harus bersusah payah.
Berikut ini resep Ayam Bumbu Rujak yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Bumbu Rujak:

1. Jangan lupa  BAHAN :
1. Tambah 1 ekor ayam ukuran sedang rebus sebentar
1. Siapkan 500-700 ml santan perasan pertama dari 1/2 butir kelapa besar
1. Harap siapkan 3 lembar daun salam
1. Tambah 3 lembar daun jeruk
1. Harus ada 1 ruas lengkuas geprek
1. Siapkan 1 helai serai geprek
1. Harus ada secukupnya Gula merah
1. Harus ada secukupnya Garam
1. Harap siapkan 2 sdm air asam jawa
1. Dibutuhkan  BUMBU HALUS :
1. Tambah 12 cabe keriting
1. Diperlukan 6 cabe rawit
1. Diperlukan 10 siung bawang merah
1. Harap siapkan 6 siung bawang putih
1. Jangan lupa 6 butir kemiri sangrai sebentar
1. Dibutuhkan 1 ruas kunyit
1. Diperlukan 1 ruas jahe




<!--inarticleads2-->

##### Langkah membuat  Ayam Bumbu Rujak:

1. Siapkan semua bahan. Ayam dibersihkan, beri jeruk dan garam diamkan lalu cuci bersih ayam kemudian rebas sebentar saja.
1. Tumis bumbu halus sampai benar benar tanek. Masukkan sereh, salam, daun jeruk dan lengkuas. Tumis bumbu hingga wangi dan matang kemudian masukkan ayam aduk sampai rata.
1. Masukkan santan cair aduk aduk, bumbui dengan gula, garam, air asam jawa, masak sampai bumbu meresap dan mengental (proses masak saya tutup hingga kuah mengental)
1. Panggang ayam, lalu oles dengan sisa bumbu ayam. Kalau kuah belum pedas bisa tambahkan cabai pada proses penghalusan bumbu ya moms. (saya tidak saya panggang, saya makan begini aja moms 😁👍👍)




Demikianlah cara membuat ayam bumbu rujak yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
