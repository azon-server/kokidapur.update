---
description: "Resep : Ayam Rica Kemangi Pedas Nampol Sempurna"
title: "Resep : Ayam Rica Kemangi Pedas Nampol Sempurna"
slug: 9-resep-ayam-rica-kemangi-pedas-nampol-sempurna
date: 2020-10-23T21:43:04.409Z
image: https://img-global.cpcdn.com/recipes/570084f62e65ff09/751x532cq70/ayam-rica-kemangi-pedas-nampol-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/570084f62e65ff09/751x532cq70/ayam-rica-kemangi-pedas-nampol-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/570084f62e65ff09/751x532cq70/ayam-rica-kemangi-pedas-nampol-foto-resep-utama.jpg
author: Harriett Lucas
ratingvalue: 4.2
reviewcount: 48701
recipeingredient:
- "4 potong ayam bagian apa ja boleh lebih enak paha dan sayap"
- "1 ikat kemangi"
- " Daun bawang"
- " Bumbu Halus"
- "2 Cabai merah besar"
- "10 cabai rawit"
- "5 bawang merah"
- "3 bawang putih"
- "4 butir kemiri"
- "1 ruas kunyit"
- "1 ruas kencur"
- "1 serai"
- "2 gelas Air"
recipeinstructions:
- "Haluskan semua bumbu halus pakai cobek aja. Trus tumis ke minyak yg panas."
- "Kalau bumbunya dah matang dan mengeluarkan aroma sedap, masukin ayamnya yg telah dicuci bersih."
- "Jangan buru2 dikasih air dulu ya bund. Tunggu bagian luar ayamnya setengah matang. Tandanya daging luar dah berwarna putih. Ini supaya bumbunya meresap dan kaldu ayamnya keluar."
- "Nah kalau penampakannya dah kayak foto diatas, baru kasih air. Tunggu sampai mendidih, tambahin cabai utuh klo suka."
- "Kalau sudah mendidih dan kuahnya dah menyusut, tambahin daun bawang, garam ½ sdt, kaldu jamur 1 sdm, gula ½ sdm..Aduk2 sampai bumbu larut."
- "Koreksi rasanya, dan tambahin kemangi. Aduk2..matikan api kompor. Selesai.."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 143 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Kemangi Pedas Nampol](https://img-global.cpcdn.com/recipes/570084f62e65ff09/751x532cq70/ayam-rica-kemangi-pedas-nampol-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau empuk. Karasteristik masakan Indonesia ayam rica kemangi pedas nampol yang penuh dengan rempah-rempah memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kedekatan keluarga bisa didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica Kemangi Pedas Nampol untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang bisa anda buat salah satunya ayam rica kemangi pedas nampol yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica kemangi pedas nampol tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi Pedas Nampol yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 13 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi Pedas Nampol:

1. Jangan lupa 4 potong ayam (bagian apa ja boleh, lebih enak paha dan sayap)
1. Jangan lupa 1 ikat kemangi
1. Diperlukan  Daun bawang
1. Harus ada  Bumbu Halus
1. Diperlukan 2 Cabai merah besar
1. Diperlukan 10 cabai rawit
1. Siapkan 5 bawang merah
1. Diperlukan 3 bawang putih
1. Diperlukan 4 butir kemiri
1. Siapkan 1 ruas kunyit
1. Harus ada 1 ruas kencur
1. Dibutuhkan 1 serai
1. Siapkan 2 gelas Air




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Kemangi Pedas Nampol:

1. Haluskan semua bumbu halus pakai cobek aja. Trus tumis ke minyak yg panas.
1. Kalau bumbunya dah matang dan mengeluarkan aroma sedap, masukin ayamnya yg telah dicuci bersih.
1. Jangan buru2 dikasih air dulu ya bund. Tunggu bagian luar ayamnya setengah matang. Tandanya daging luar dah berwarna putih. Ini supaya bumbunya meresap dan kaldu ayamnya keluar.
1. Nah kalau penampakannya dah kayak foto diatas, baru kasih air. Tunggu sampai mendidih, tambahin cabai utuh klo suka.
1. Kalau sudah mendidih dan kuahnya dah menyusut, tambahin daun bawang, garam ½ sdt, kaldu jamur 1 sdm, gula ½ sdm..Aduk2 sampai bumbu larut.
1. Koreksi rasanya, dan tambahin kemangi. Aduk2..matikan api kompor. Selesai..




Demikianlah cara membuat ayam rica kemangi pedas nampol yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan terbukti, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
