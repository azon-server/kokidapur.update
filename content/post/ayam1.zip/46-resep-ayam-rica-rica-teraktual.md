---
description: "Resep : Ayam Rica - Rica teraktual"
title: "Resep : Ayam Rica - Rica teraktual"
slug: 46-resep-ayam-rica-rica-teraktual
date: 2020-12-26T11:13:21.196Z
image: https://img-global.cpcdn.com/recipes/65109912faf9fb59/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/65109912faf9fb59/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/65109912faf9fb59/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Francisco Carter
ratingvalue: 4.3
reviewcount: 8674
recipeingredient:
- "7 potong ayam ukuran sedang cuci bersih"
- " Bumbu ulek "
- "3 siung bawang merah"
- "10 buah cabai rawit merah"
- "2 siung bawang putih"
- "8 buah cabai merah keriting"
- "2 butir kemiri"
- "1 ruas jari kunyit"
- "1/4 buah bagian tomat"
- "1/2 sdt garam"
- " Bumbu lainnya "
- "1 batang sereh"
- "1 lembar daun jeruk"
- "1/2 buah jeruk nipis"
- "1 lembar salam"
- "1 ruas jari jahe"
- "secukupnya Kaldu jamur"
- "1/2 sdt gula pasir"
recipeinstructions:
- "Panaskan minyak goreng, goreng ayam yg sudah dicuci bersih hingga matang. Sisihkan"
- "Ulek semua bumbu halus, geprek jahe dan sereh. Sisihkan."
- "Panaskan minyak goreng kembali, tumis bumbu halus beserta jahe, sereh, salam dan daun jeruk, tumis hingga harum dan berubah warna"
- "Setelah itu masukkan kaldu jamur dan gula pasir, aduk rata"
- "Masukkan ayam yg sudah digoreng aduk kembali"
- "Beri perasan jeruk nipis dan tambahkan air secukupnya, aduk rata kembali"
- "Tutup wajan biarkan mendidih dan bumbu meresap sampai air menyusut"
- "Setelah air menyusut, aduk rata kembali, jangan lupa tes rasa, jika sudah sesuai selera, angkat dan siap disajikan. Terima kasih"
- "Selamat mencoba 😉 klo penyuka pedas dijamin nambah. Gak cukup makan 1 potong ayam.."
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 167 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica - Rica](https://img-global.cpcdn.com/recipes/65109912faf9fb59/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica - rica yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa keistimewahan yang merupakan keragaman Nusantara

Kedekatan rumah tangga dapat ditemukan dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica - Rica untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang bisa anda contoh salah satunya ayam rica - rica yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep ayam rica - rica tanpa harus bersusah payah.
Seperti resep Ayam Rica - Rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica - Rica:

1. Siapkan 7 potong ayam ukuran sedang, cuci bersih
1. Dibutuhkan  Bumbu ulek :
1. Harap siapkan 3 siung bawang merah
1. Siapkan 10 buah cabai rawit merah
1. Siapkan 2 siung bawang putih
1. Tambah 8 buah cabai merah keriting
1. Jangan lupa 2 butir kemiri
1. Tambah 1 ruas jari kunyit
1. Harap siapkan 1/4 buah bagian tomat
1. Siapkan 1/2 sdt garam
1. Dibutuhkan  Bumbu lainnya :
1. Diperlukan 1 batang sereh
1. Dibutuhkan 1 lembar daun jeruk
1. Harap siapkan 1/2 buah jeruk nipis
1. Dibutuhkan 1 lembar salam
1. Dibutuhkan 1 ruas jari jahe
1. Tambah secukupnya Kaldu jamur
1. Tambah 1/2 sdt gula pasir




<!--inarticleads2-->

##### Cara membuat  Ayam Rica - Rica:

1. Panaskan minyak goreng, goreng ayam yg sudah dicuci bersih hingga matang. Sisihkan
1. Ulek semua bumbu halus, geprek jahe dan sereh. Sisihkan.
1. Panaskan minyak goreng kembali, tumis bumbu halus beserta jahe, sereh, salam dan daun jeruk, tumis hingga harum dan berubah warna
1. Setelah itu masukkan kaldu jamur dan gula pasir, aduk rata
1. Masukkan ayam yg sudah digoreng aduk kembali
1. Beri perasan jeruk nipis dan tambahkan air secukupnya, aduk rata kembali
1. Tutup wajan biarkan mendidih dan bumbu meresap sampai air menyusut
1. Setelah air menyusut, aduk rata kembali, jangan lupa tes rasa, jika sudah sesuai selera, angkat dan siap disajikan. Terima kasih
1. Selamat mencoba 😉 klo penyuka pedas dijamin nambah. Gak cukup makan 1 potong ayam..




Demikianlah cara membuat ayam rica - rica yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan cepat, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
