---
description: "Resep : Ayam rica-rica kemangi Favorite"
title: "Resep : Ayam rica-rica kemangi Favorite"
slug: 189-resep-ayam-rica-rica-kemangi-favorite
date: 2021-01-19T15:33:00.418Z
image: https://img-global.cpcdn.com/recipes/1d4c564ddde0f1cf/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1d4c564ddde0f1cf/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1d4c564ddde0f1cf/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Tommy Weber
ratingvalue: 4.3
reviewcount: 13797
recipeingredient:
- "1/2 ekor ayam"
- "2 batang kemangi"
- "8 bawang merah"
- "4 bawang putih"
- "5 cabai keriting"
- "30 cabai rawit jablay"
- "1 buah tomat"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 batang serai"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 ruas lengkuas"
- "2 kemiri"
- "secukupnya Garam"
- "secukupnya Gula pasir"
- "secukupnya Penyedap rasa"
- "200 ml air"
recipeinstructions:
- "Cuci ayam hingga bersih lalu taburi penyedap rasa sedikit, marinasi 5 menit lalu goreng setengah matang"
- "Haluskan semua bahan, sisakan 15 cabai rawit jablay untuk taburan, geprek sereh, lengkuas"
- "Tumis bumbu halus lalu tambahkan garam, gula dan penyedap rasa"
- "Masukkan ayam aduk hingga rata, jika sudah agak menyerap masukkan kemangi dan cabai rawit, tambahkan sedikit air, biar kan hingga menyerap, koreksi rasa"
- "Ayam rica kemangi siap di hidangkan untuk lauk makan siang atau malam"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 262 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT58M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/1d4c564ddde0f1cf/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas hingga gurih. Ciri khas masakan Indonesia ayam rica-rica kemangi yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Kedekatan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam rica-rica kemangi untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang bisa anda buat salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica kemangi:

1. Harus ada 1/2 ekor ayam
1. Dibutuhkan 2 batang kemangi
1. Harap siapkan 8 bawang merah
1. Jangan lupa 4 bawang putih
1. Harus ada 5 cabai keriting
1. Diperlukan 30 cabai rawit jablay
1. Tambah 1 buah tomat
1. Harap siapkan 1 ruas jahe
1. Jangan lupa 1 ruas kunyit
1. Diperlukan 1 batang serai
1. Diperlukan 2 lembar daun salam
1. Siapkan 2 lembar daun jeruk
1. Jangan lupa 1 ruas lengkuas
1. Harap siapkan 2 kemiri
1. Harap siapkan secukupnya Garam
1. Dibutuhkan secukupnya Gula pasir
1. Diperlukan secukupnya Penyedap rasa
1. Diperlukan 200 ml air


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica-rica kemangi:

1. Cuci ayam hingga bersih lalu taburi penyedap rasa sedikit, marinasi 5 menit lalu goreng setengah matang
1. Haluskan semua bahan, sisakan 15 cabai rawit jablay untuk taburan, geprek sereh, lengkuas
1. Tumis bumbu halus lalu tambahkan garam, gula dan penyedap rasa
1. Masukkan ayam aduk hingga rata, jika sudah agak menyerap masukkan kemangi dan cabai rawit, tambahkan sedikit air, biar kan hingga menyerap, koreksi rasa
1. Ayam rica kemangi siap di hidangkan untuk lauk makan siang atau malam


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan teruji, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
