---
description: "Steps membuat Ayam Rica Jawa teraktual"
title: "Steps membuat Ayam Rica Jawa teraktual"
slug: 86-steps-membuat-ayam-rica-jawa-teraktual
date: 2020-10-16T18:03:45.423Z
image: https://img-global.cpcdn.com/recipes/2a7bb5445e3b890d/751x532cq70/ayam-rica-jawa-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2a7bb5445e3b890d/751x532cq70/ayam-rica-jawa-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2a7bb5445e3b890d/751x532cq70/ayam-rica-jawa-foto-resep-utama.jpg
author: Christina Haynes
ratingvalue: 4.7
reviewcount: 17904
recipeingredient:
- "1 kg ayam potong sesuai selera"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 batang serai"
- " Bumbu Halus "
- "7 siung bawang putih"
- "2 butir bawang merah"
- "12 cabe rawit"
- "3 cabe merah besar"
- "1/2 cm kunyit"
- "5 butir kemiri sangrai"
- "1/2 sdt ketumbar bubuk"
- "1/2 sdt merica"
- "2 sdm kecap bangau"
- "Secukupnya garam dan gula"
- "Secukupnya air"
recipeinstructions:
- "Tumis bumbu halus, daun salam, daun jeruk dgn sdkt minyak sampai harum."
- "Masukkan ayam, kecap dan air. Aduk rata. Tambahkan garam dan gula."
- "Masak ayam sampai bumbunya meresap, jika airnya kurang bisa di tambahkan (sesuaikan dengan kekentalan kuah yg diinginkan, saya lbh suka agak kering). Koreksi rasa."
- "Sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- jawa

katakunci: ayam rica jawa 
nutrition: 262 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica Jawa](https://img-global.cpcdn.com/recipes/2a7bb5445e3b890d/751x532cq70/ayam-rica-jawa-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang harus kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica jawa yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia

Keharmonisan rumah tangga dapat diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Rica Jawa untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang dapat anda buat salah satunya ayam rica jawa yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica jawa tanpa harus bersusah payah.
Seperti resep Ayam Rica Jawa yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Jawa:

1. Siapkan 1 kg ayam, potong sesuai selera
1. Tambah 2 lembar daun salam
1. Harus ada 2 lembar daun jeruk
1. Harap siapkan 1 batang serai
1. Siapkan  Bumbu Halus :
1. Dibutuhkan 7 siung bawang putih
1. Harus ada 2 butir bawang merah
1. Jangan lupa 12 cabe rawit
1. Siapkan 3 cabe merah besar
1. Diperlukan 1/2 cm kunyit
1. Siapkan 5 butir kemiri, sangrai
1. Tambah 1/2 sdt ketumbar bubuk
1. Siapkan 1/2 sdt merica
1. Tambah 2 sdm kecap bangau
1. Harus ada Secukupnya garam dan gula
1. Harus ada Secukupnya air




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Jawa:

1. Tumis bumbu halus, daun salam, daun jeruk dgn sdkt minyak sampai harum.
1. Masukkan ayam, kecap dan air. Aduk rata. Tambahkan garam dan gula.
1. Masak ayam sampai bumbunya meresap, jika airnya kurang bisa di tambahkan (sesuaikan dengan kekentalan kuah yg diinginkan, saya lbh suka agak kering). Koreksi rasa.
1. Sajikan




Demikianlah cara membuat ayam rica jawa yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
