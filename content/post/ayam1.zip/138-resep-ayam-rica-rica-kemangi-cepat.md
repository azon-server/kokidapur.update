---
description: "Resep : Ayam rica rica kemangi Cepat"
title: "Resep : Ayam rica rica kemangi Cepat"
slug: 138-resep-ayam-rica-rica-kemangi-cepat
date: 2020-11-14T12:02:57.990Z
image: https://img-global.cpcdn.com/recipes/99a36fb1d5ebc3ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/99a36fb1d5ebc3ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/99a36fb1d5ebc3ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Danny Peters
ratingvalue: 4.5
reviewcount: 27058
recipeingredient:
- "1/2 kg ayam"
- " Bumbu halus"
- "5 siung bawang putih"
- "5 siung bawang merah"
- "20 buah cabe merah keriting"
- "5-10 buah cabe rawit"
- "1 butir kemiri sangrai dulu"
- "Sedikit ketumbar"
- " Bahan cemplung "
- "1 ruas lengkuas"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "1 batang serai"
- "1 buah tomat"
- " "
- "1 ikat daun kemangi"
- "1 batang daun bawang"
- "Secukupnya garam"
- "Secukupnya gula merah"
- "Secukupnya gula putih"
- "Secukupnya lada bubuk"
- "Secukupnya penyedap rasa"
recipeinstructions:
- "Cuci bersih ayam. Kemudian goreng sebentar setengah matang dengan dilumuri bubuk bawang putih. Ketumbar. kunyit dan garam"
- "Kemudian haluskan semua bumbu halus. Kemudian tumis beserta bahan cemplung sampai harum dan matang"
- "Setelah harum dan matang tambahkan air sebanyak 1½gelas belimbing. Masukan pula ayamnya. Tambahkan juga bumbu penyedap lainnya seperti garam dll."
- "Masan hingga sampai sedikit menyusut. Lalu masukan daun bawang iris dan kemangi"
- "Masak hingga benar2 matang dan airnya menyusut"
- "Koreksi rasa dahulu.dirasa cukup. Angkat dan sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 132 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/99a36fb1d5ebc3ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan enak. Ciri khas kuliner Nusantara ayam rica rica kemangi yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kehangatan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah membuat makanan Ayam rica rica kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Inilah rahasia bumbu masakan ayam rica rica dan petunjuk cara membuat rica rica ayam.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda praktekkan salah satunya ayam rica rica kemangi yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi:

1. Tambah 1/2 kg ayam
1. Tambah  Bumbu halus:
1. Diperlukan 5 siung bawang putih
1. Harap siapkan 5 siung bawang merah
1. Harap siapkan 20 buah cabe merah keriting
1. Tambah 5-10 buah cabe rawit
1. Harus ada 1 butir kemiri (sangrai dulu)
1. Diperlukan Sedikit ketumbar
1. Tambah  Bahan cemplung :
1. Jangan lupa 1 ruas lengkuas
1. Harap siapkan 3 lembar daun salam
1. Tambah 3 lembar daun jeruk
1. Harap siapkan 1 batang serai
1. Jangan lupa 1 buah tomat
1. Dibutuhkan  ~~~
1. Harap siapkan 1 ikat daun kemangi
1. Tambah 1 batang daun bawang
1. Harap siapkan Secukupnya garam
1. Diperlukan Secukupnya gula merah
1. Siapkan Secukupnya gula putih
1. Harap siapkan Secukupnya lada bubuk
1. Harus ada Secukupnya penyedap rasa


It is made up of chicken that cooked in spicy red and green chili pepper. The origin of this dish is from Minahasan cuisine of North Sulawesi. Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica rica kemangi:

1. Cuci bersih ayam. Kemudian goreng sebentar setengah matang dengan dilumuri bubuk bawang putih. Ketumbar. kunyit dan garam
1. Kemudian haluskan semua bumbu halus. Kemudian tumis beserta bahan cemplung sampai harum dan matang
1. Setelah harum dan matang tambahkan air sebanyak 1½gelas belimbing. Masukan pula ayamnya. Tambahkan juga bumbu penyedap lainnya seperti garam dll.
1. Masan hingga sampai sedikit menyusut. Lalu masukan daun bawang iris dan kemangi
1. Masak hingga benar2 matang dan airnya menyusut
1. Koreksi rasa dahulu.dirasa cukup. Angkat dan sajikan


Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. 

Demikianlah cara membuat ayam rica rica kemangi yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
