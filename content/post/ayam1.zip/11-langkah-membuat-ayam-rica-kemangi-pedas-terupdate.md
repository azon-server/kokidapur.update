---
description: "Langkah membuat Ayam Rica Kemangi Pedas terupdate"
title: "Langkah membuat Ayam Rica Kemangi Pedas terupdate"
slug: 11-langkah-membuat-ayam-rica-kemangi-pedas-terupdate
date: 2020-09-24T00:01:12.015Z
image: https://img-global.cpcdn.com/recipes/c800002b655ead49/751x532cq70/ayam-rica-kemangi-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c800002b655ead49/751x532cq70/ayam-rica-kemangi-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c800002b655ead49/751x532cq70/ayam-rica-kemangi-pedas-foto-resep-utama.jpg
author: Minnie Campbell
ratingvalue: 5
reviewcount: 31727
recipeingredient:
- "1 ekor ayam 8 potong"
- " Bumbu Halus"
- "15 Bawang Merah"
- "8 Bawang Putih"
- "1 Kelingking Kunyit"
- "2 Jempol Jahe"
- "1 Jempol Lengkuas"
- "2 Kemiri sudah disangrai"
- " Bahan cabe"
- "8 Cabe Gendut karena kebetulan ga ada cabe keriting"
- "18 Cabe Rawit Domba sesuai selera"
- " Bahan Lainnya"
- "5 Sereh digeprek"
- "15 Lembar Daun Jeruk"
- "3 Ikat daun kemangi"
- " Garam kaldu ayam gula merica sesuai selera"
- " Jeruk lemon"
recipeinstructions:
- "Cuci bersih ayam, balurkan perasan jeruk lemon dan diamkan beberapa saat."
- "Didihkan air, rebus ayam (saya 30 menit). Siapkan bahan halus, cuci bersih kemudian blender seluruh bahan halus."
- "Angkat ayam yg sudah direbus kemudian pindahkan ke wajan dan marinasi menggunakan bumbu halus (15 menit). Nyalakan kompor, tambahkan air, minyak, sereh, daun jeruk, garam, kaldu ayam, dan merica. Tunggu sampai airnya sat."
- "Masukan bahan cabe yang telah diblender, garam, gula, kaldu ayam, dan merica. Setelah semuanya merata masukkan daun kemangi dan masak sebentar. Selesai.... aromanya wangi banget🔥🔥"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 249 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica Kemangi Pedas](https://img-global.cpcdn.com/recipes/c800002b655ead49/751x532cq70/ayam-rica-kemangi-pedas-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang setidaknya kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica kemangi pedas yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan keistimewahan yang merupakan keragaman Nusantara



Kehangatan keluarga bisa didapat dengan cara mudah. Diantaranya adalah memasak Ayam Rica Kemangi Pedas untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang bisa anda praktekkan salah satunya ayam rica kemangi pedas yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep ayam rica kemangi pedas tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi Pedas yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi Pedas:

1. Dibutuhkan 1 ekor ayam (8 potong)
1. Tambah  Bumbu Halus
1. Diperlukan 15 Bawang Merah
1. Diperlukan 8 Bawang Putih
1. Harus ada 1 Kelingking Kunyit
1. Harap siapkan 2 Jempol Jahe
1. Tambah 1 Jempol Lengkuas
1. Dibutuhkan 2 Kemiri (sudah disangrai)
1. Diperlukan  Bahan cabe
1. Tambah 8 Cabe Gendut (karena kebetulan ga ada cabe keriting)
1. Siapkan 18 Cabe Rawit Domba (sesuai selera)
1. Dibutuhkan  Bahan Lainnya
1. Siapkan 5 Sereh (digeprek)
1. Harus ada 15 Lembar Daun Jeruk
1. Harus ada 3 Ikat daun kemangi
1. Tambah  Garam, kaldu ayam, gula, merica (sesuai selera)
1. Siapkan  Jeruk lemon




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Kemangi Pedas:

1. Cuci bersih ayam, balurkan perasan jeruk lemon dan diamkan beberapa saat.
1. Didihkan air, rebus ayam (saya 30 menit). Siapkan bahan halus, cuci bersih kemudian blender seluruh bahan halus.
1. Angkat ayam yg sudah direbus kemudian pindahkan ke wajan dan marinasi menggunakan bumbu halus (15 menit). Nyalakan kompor, tambahkan air, minyak, sereh, daun jeruk, garam, kaldu ayam, dan merica. Tunggu sampai airnya sat.
1. Masukan bahan cabe yang telah diblender, garam, gula, kaldu ayam, dan merica. Setelah semuanya merata masukkan daun kemangi dan masak sebentar. Selesai.... aromanya wangi banget🔥🔥




Demikianlah cara membuat ayam rica kemangi pedas yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
