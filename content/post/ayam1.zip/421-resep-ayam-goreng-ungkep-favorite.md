---
description: "Resep : Ayam Goreng Ungkep Favorite"
title: "Resep : Ayam Goreng Ungkep Favorite"
slug: 421-resep-ayam-goreng-ungkep-favorite
date: 2020-12-15T11:50:00.668Z
image: https://img-global.cpcdn.com/recipes/5dca83d7b61c851d/751x532cq70/ayam-goreng-ungkep-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5dca83d7b61c851d/751x532cq70/ayam-goreng-ungkep-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5dca83d7b61c851d/751x532cq70/ayam-goreng-ungkep-foto-resep-utama.jpg
author: Harold Cannon
ratingvalue: 4.2
reviewcount: 16167
recipeingredient:
- "1/4 ekor ayam"
- "1 batang serai"
- "2 lembar daun salam"
- "1/2 potong jeruk nipis"
- "1/2 lembar daun jeruk saya skip stok habis"
- " Bumbu Halus "
- "5 bawang merah"
- "3 bawang putih"
- "1 ruas kunyit"
- "1 ruas jahe"
- "1 ruas laos"
- "1 buah kemiri"
- "1-2 sdm ketumbar bubuk sesuai selera"
- "1/2 sdm garam"
- "1/2 sdt penyedap"
recipeinstructions:
- "Cuci bersih ayam, kemudian lumuri dengan jeruk nipis.. diamkan sebentar, kemudian bilas lagi dengan air"
- "Haluskan semua bumbu"
- "Siapkan wajan atau panci kecil beri minyak 2 sdm, kemudian tuangkan bumbu halus... tambahlan serai, daun salam dan daun jeruk (jika ada).. tumis sebentar aja"
- "Tambahkan ayam, aduk bumbu hingga merata dengan ayam... kemudian tambahkan 1/2 gelas kecil air (disesuaikan). Kemudian tutup"
- "Sesekali aduk, agar bumbu meresap dengan merata, diamkan hingga kuah menyusut dan kental"
- "Ayam siap di goreng,,,"
- "Jangan terlalu lama gorengnya, cukup sampai warna kuning keemasan (sedikit coklat) kalau yang suka garing... sok atuh bisa agak lama"
- "Angkat, tiriskan, siap disajikan dengan nasi hangat"
categories:
- Recipe
tags:
- ayam
- goreng
- ungkep

katakunci: ayam goreng ungkep 
nutrition: 250 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT59M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Goreng Ungkep](https://img-global.cpcdn.com/recipes/5dca83d7b61c851d/751x532cq70/ayam-goreng-ungkep-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam goreng ungkep yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan keistimewahan yang merupakan keragaman Indonesia



Kedekatan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam Goreng Ungkep untuk keluarga. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang bisa anda contoh salah satunya ayam goreng ungkep yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep ayam goreng ungkep tanpa harus bersusah payah.
Seperti resep Ayam Goreng Ungkep yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Ungkep:

1. Harap siapkan 1/4 ekor ayam
1. Jangan lupa 1 batang serai
1. Harap siapkan 2 lembar daun salam
1. Diperlukan 1/2 potong jeruk nipis
1. Jangan lupa 1/2 lembar daun jeruk (saya skip stok habis)
1. Jangan lupa  Bumbu Halus :
1. Diperlukan 5 bawang merah
1. Tambah 3 bawang putih
1. Dibutuhkan 1 ruas kunyit
1. Dibutuhkan 1 ruas jahe
1. Harap siapkan 1 ruas laos
1. Diperlukan 1 buah kemiri
1. Harap siapkan 1-2 sdm ketumbar bubuk (sesuai selera)
1. Harus ada 1/2 sdm garam
1. Harus ada 1/2 sdt penyedap




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Goreng Ungkep:

1. Cuci bersih ayam, kemudian lumuri dengan jeruk nipis.. diamkan sebentar, kemudian bilas lagi dengan air
1. Haluskan semua bumbu
1. Siapkan wajan atau panci kecil beri minyak 2 sdm, kemudian tuangkan bumbu halus... tambahlan serai, daun salam dan daun jeruk (jika ada).. tumis sebentar aja
1. Tambahkan ayam, aduk bumbu hingga merata dengan ayam... kemudian tambahkan 1/2 gelas kecil air (disesuaikan). Kemudian tutup
1. Sesekali aduk, agar bumbu meresap dengan merata, diamkan hingga kuah menyusut dan kental
1. Ayam siap di goreng,,,
1. Jangan terlalu lama gorengnya, cukup sampai warna kuning keemasan (sedikit coklat) kalau yang suka garing... sok atuh bisa agak lama
1. Angkat, tiriskan, siap disajikan dengan nasi hangat




Demikianlah cara membuat ayam goreng ungkep yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
