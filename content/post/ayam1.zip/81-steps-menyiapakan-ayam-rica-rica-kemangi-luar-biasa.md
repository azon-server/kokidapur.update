---
description: "Steps menyiapakan Ayam Rica-rica Kemangi Luar biasa"
title: "Steps menyiapakan Ayam Rica-rica Kemangi Luar biasa"
slug: 81-steps-menyiapakan-ayam-rica-rica-kemangi-luar-biasa
date: 2021-01-23T06:32:00.427Z
image: https://img-global.cpcdn.com/recipes/00bd827261d1c0d9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/00bd827261d1c0d9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/00bd827261d1c0d9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Vincent Bates
ratingvalue: 4.9
reviewcount: 4115
recipeingredient:
- "1/2 kg Daging ayam paha atas"
- "1 ikat Kemangi siangi  cuci"
- "1 buah Jeruk nipis"
- "2 batang Serai geprek"
- "2 lembar Daun salam tambahan sy"
- "5 lembar Daun jeruk"
- "1 ruas Lengkuas geprek"
- "1 batang Daun bawang iris"
- "1 sdm Gula merah"
- "Secukupnya Garam  Kaldu ayam bubuk"
- "Secukupnya Air"
- "Secukupnya Minyak goreng utk menumis"
- " Bumbu halus "
- "6 buah Bawang merah"
- "2 siung Bawang putih"
- "6 buah Cabe merah keriting"
- "10 buah Cabe rawit domba"
- "2 buah Kemiri"
- "1 ruas Jahe"
- "1 ruas Kunyit"
recipeinstructions:
- "Beri perasan jeruk nipis pada daging ayam. Diamkan selama 30 menit. Cuci bersih dan potong2 sesuai selera."
- "Panaskan minyak goreng, tumis bumbu halus, serai, daun salam, daun jeruk, dan lengkuas hingga harum. Masukkan daging ayam, masak hingga berubah warna kemudian tambah air hingga menutupi daging ayam."
- "Masukkan garam, kaldu ayam bubuk, dan gula merah. Aduk rata. Masak hingga air mengental dan daging empuk. Koreksi rasa."
- "Terakhir masukkan kemangi dan daun bawang. Matikan api kompor. Ayam rica-rica kemangi siap disajikan 🥰🥰"
- "Makan sama nasi panas aja udh nikmaaat bangeettt 😋😋"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 231 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/00bd827261d1c0d9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau gurih. Karasteristik makanan Nusantara ayam rica-rica kemangi yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah memasak Ayam Rica-rica Kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang dapat anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica Kemangi:

1. Tambah 1/2 kg Daging ayam (paha atas)
1. Siapkan 1 ikat Kemangi, siangi &amp; cuci
1. Jangan lupa 1 buah Jeruk nipis
1. Harap siapkan 2 batang Serai, geprek
1. Tambah 2 lembar Daun salam (tambahan sy)
1. Tambah 5 lembar Daun jeruk
1. Jangan lupa 1 ruas Lengkuas, geprek
1. Dibutuhkan 1 batang Daun bawang, iris
1. Harap siapkan 1 sdm Gula merah
1. Siapkan Secukupnya Garam &amp; Kaldu ayam bubuk
1. Jangan lupa Secukupnya Air
1. Tambah Secukupnya Minyak goreng (utk menumis)
1. Jangan lupa  Bumbu halus :
1. Diperlukan 6 buah Bawang merah
1. Diperlukan 2 siung Bawang putih
1. Jangan lupa 6 buah Cabe merah keriting
1. Diperlukan 10 buah Cabe rawit domba
1. Tambah 2 buah Kemiri
1. Diperlukan 1 ruas Jahe
1. Diperlukan 1 ruas Kunyit


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-rica Kemangi:

1. Beri perasan jeruk nipis pada daging ayam. Diamkan selama 30 menit. Cuci bersih dan potong2 sesuai selera.
1. Panaskan minyak goreng, tumis bumbu halus, serai, daun salam, daun jeruk, dan lengkuas hingga harum. Masukkan daging ayam, masak hingga berubah warna kemudian tambah air hingga menutupi daging ayam.
1. Masukkan garam, kaldu ayam bubuk, dan gula merah. Aduk rata. Masak hingga air mengental dan daging empuk. Koreksi rasa.
1. Terakhir masukkan kemangi dan daun bawang. Matikan api kompor. Ayam rica-rica kemangi siap disajikan 🥰🥰
1. Makan sama nasi panas aja udh nikmaaat bangeettt 😋😋


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan terbukti, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
