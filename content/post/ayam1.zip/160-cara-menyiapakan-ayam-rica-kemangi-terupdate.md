---
description: "Cara menyiapakan Ayam rica kemangi terupdate"
title: "Cara menyiapakan Ayam rica kemangi terupdate"
slug: 160-cara-menyiapakan-ayam-rica-kemangi-terupdate
date: 2020-09-11T12:47:49.008Z
image: https://img-global.cpcdn.com/recipes/1a6b69d71b2dd347/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1a6b69d71b2dd347/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1a6b69d71b2dd347/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Lee Terry
ratingvalue: 4.9
reviewcount: 27829
recipeingredient:
- "5 potong ayam paha atas"
- "3 ikat kemangi"
- "1 btg sereh geprek"
- "1 ruas jari lengkuas geprek"
- "7 lbr daun jeruk"
- "1 btg daun bawang iris"
- "Secukupnya air"
- "Secukupnya garam  kaldu jamur"
- " Bumbu halus "
- "6 siung bamer"
- "2 siung baput"
- "6 buah cabe merah kriting"
- "13 buah cabe rawit merah optional"
- "2 btr kemiri"
- "Secukupnya jahe  kunyit"
- "1 sdm gula merah"
recipeinstructions:
- "Cuci bersih ayam beri perasan jeruk nipis diamkan sesaat"
- "Goreng baput bamer cabe jahe hingga layu lalu blender bumbu halus. Tumis bumbu halus hingga harum masukan sereh, lengkuas &amp; d.jeruk"
- "Masukan ayam sampai berubah warna tuang air secukupnya masak sampai mendidih kuahnya tes rasa beri garam &amp; kaldu jamur. Masak sampai kuah mengental juga empuk ayamnya matang"
- "Setelah ayam matang matikan api kompor masukan daun bawang juga kemangi"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 164 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/1a6b69d71b2dd347/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau empuk. Karasteristik kuliner Indonesia ayam rica kemangi yang penuh dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah membuat makanan Ayam rica kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang dapat anda praktekkan salah satunya ayam rica kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica kemangi:

1. Siapkan 5 potong ayam (paha atas)
1. Harus ada 3 ikat kemangi
1. Dibutuhkan 1 btg sereh (geprek)
1. Dibutuhkan 1 ruas jari lengkuas (geprek)
1. Siapkan 7 lbr daun jeruk
1. Dibutuhkan 1 btg daun bawang (iris)
1. Diperlukan Secukupnya air
1. Siapkan Secukupnya garam &amp; kaldu jamur
1. Dibutuhkan  Bumbu halus :
1. Tambah 6 siung bamer
1. Jangan lupa 2 siung baput
1. Harap siapkan 6 buah cabe merah kriting
1. Harap siapkan 13 buah cabe rawit merah (optional)
1. Siapkan 2 btr kemiri
1. Dibutuhkan Secukupnya jahe &amp; kunyit
1. Jangan lupa 1 sdm gula merah




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica kemangi:

1. Cuci bersih ayam beri perasan jeruk nipis diamkan sesaat
1. Goreng baput bamer cabe jahe hingga layu lalu blender bumbu halus. Tumis bumbu halus hingga harum masukan sereh, lengkuas &amp; d.jeruk
1. Masukan ayam sampai berubah warna tuang air secukupnya masak sampai mendidih kuahnya tes rasa beri garam &amp; kaldu jamur. Masak sampai kuah mengental juga empuk ayamnya matang
1. Setelah ayam matang matikan api kompor masukan daun bawang juga kemangi




Demikianlah cara membuat ayam rica kemangi yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan teruji, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
