---
description: "Step-by-Step menyiapakan Ayam Goreng Pedas Manis Teruji"
title: "Step-by-Step menyiapakan Ayam Goreng Pedas Manis Teruji"
slug: 436-step-by-step-menyiapakan-ayam-goreng-pedas-manis-teruji
date: 2020-12-15T07:02:39.458Z
image: https://img-global.cpcdn.com/recipes/53f5523f035030e3/751x532cq70/ayam-goreng-pedas-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/53f5523f035030e3/751x532cq70/ayam-goreng-pedas-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/53f5523f035030e3/751x532cq70/ayam-goreng-pedas-manis-foto-resep-utama.jpg
author: Terry Patton
ratingvalue: 4.7
reviewcount: 9835
recipeingredient:
- "500 Gram Dada Ayam Fillet potong2 sesuai selera"
- "1 Butir Telur"
- "4 Sdm Tepung Terigu me  cakra"
- "2 Sdm Tepung Maizena"
- "100 Ml Air"
- "1 Sdt Bawang Putih Bubuk"
- "1/2 Sdt Baking Powder"
- " Bahan Pelapis "
- "6 Sdm Tepung Terigu me  cakra"
- "2 Sdm Tepung Maizena"
- "1 Sdt Penyedap"
- "1/2 Sdt Garam"
- " Saus Pedas Manis "
- "2 Sdm Mentega"
- "1 Butir Bawang Bombay"
- "4 Sdm Kecap Manis"
- "2 Sdm Saus Tiram"
- "2 Sdm Saus Tomat"
- "5 Sdm Saus Sambal"
- "1/2 Sdm Merica"
- "1/2 Sdm Kaldu Jamur"
- "1/2 Sdm Paprika Bubuk"
- "Secukupnya Gula Pasir"
recipeinstructions:
- "Campurkan ayam, telur, terigu, maizena, air, bawang putih dan baking powder. Aduk sampai rata, simpan di kulkas 2-3 jam"
- "Campur bahan pelapis. Gulingkan ayam bahan pelapis sambil agak diremas2 supaya tepung menempel. Goreng ayam sampai kekuningan"
- "Panaskan mentega, tumis bawang bombay sampai harum kemudian masukkan bahan saus. Aduk2 sampai agak mengental, test rasa. Matikan apinya"
- "Tunggu sampai saus tidak terlalu panas. masukkan ayam lalu aduk2 sampai merata"
categories:
- Recipe
tags:
- ayam
- goreng
- pedas

katakunci: ayam goreng pedas 
nutrition: 110 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT55M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Goreng Pedas Manis](https://img-global.cpcdn.com/recipes/53f5523f035030e3/751x532cq70/ayam-goreng-pedas-manis-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau enak. Ciri kuliner Nusantara ayam goreng pedas manis yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah memasak Ayam Goreng Pedas Manis untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang dapat anda praktekkan salah satunya ayam goreng pedas manis yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep ayam goreng pedas manis tanpa harus bersusah payah.
Seperti resep Ayam Goreng Pedas Manis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 23 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Pedas Manis:

1. Tambah 500 Gram Dada Ayam Fillet, potong2 sesuai selera
1. Dibutuhkan 1 Butir Telur
1. Jangan lupa 4 Sdm Tepung Terigu (me : cakra)
1. Harap siapkan 2 Sdm Tepung Maizena
1. Jangan lupa 100 Ml Air
1. Harap siapkan 1 Sdt Bawang Putih Bubuk
1. Dibutuhkan 1/2 Sdt Baking Powder
1. Tambah  Bahan Pelapis :
1. Tambah 6 Sdm Tepung Terigu (me : cakra)
1. Diperlukan 2 Sdm Tepung Maizena
1. Diperlukan 1 Sdt Penyedap
1. Harap siapkan 1/2 Sdt Garam
1. Tambah  Saus Pedas Manis :
1. Harus ada 2 Sdm Mentega
1. Siapkan 1 Butir Bawang Bombay
1. Tambah 4 Sdm Kecap Manis
1. Dibutuhkan 2 Sdm Saus Tiram
1. Tambah 2 Sdm Saus Tomat
1. Siapkan 5 Sdm Saus Sambal
1. Siapkan 1/2 Sdm Merica
1. Harus ada 1/2 Sdm Kaldu Jamur
1. Harus ada 1/2 Sdm Paprika Bubuk
1. Diperlukan Secukupnya Gula Pasir




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Goreng Pedas Manis:

1. Campurkan ayam, telur, terigu, maizena, air, bawang putih dan baking powder. Aduk sampai rata, simpan di kulkas 2-3 jam
1. Campur bahan pelapis. Gulingkan ayam bahan pelapis sambil agak diremas2 supaya tepung menempel. Goreng ayam sampai kekuningan
1. Panaskan mentega, tumis bawang bombay sampai harum kemudian masukkan bahan saus. Aduk2 sampai agak mengental, test rasa. Matikan apinya
1. Tunggu sampai saus tidak terlalu panas. masukkan ayam lalu aduk2 sampai merata




Demikianlah cara membuat ayam goreng pedas manis yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
