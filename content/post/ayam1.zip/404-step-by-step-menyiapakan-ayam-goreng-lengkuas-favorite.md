---
description: "Step-by-Step menyiapakan Ayam goreng lengkuas Favorite"
title: "Step-by-Step menyiapakan Ayam goreng lengkuas Favorite"
slug: 404-step-by-step-menyiapakan-ayam-goreng-lengkuas-favorite
date: 2020-08-18T17:28:34.778Z
image: https://img-global.cpcdn.com/recipes/8ebcc9bfa3450ad5/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8ebcc9bfa3450ad5/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8ebcc9bfa3450ad5/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Aaron Bridges
ratingvalue: 4.9
reviewcount: 45278
recipeingredient:
- "1 kg daging ayam"
- "5 cm Lengkuas"
- "2 cm Jahe"
- "2 batang Serai"
- "5 lembar Daun jeruk"
- "3 lembar Daun salam"
- "3 buah Bawang merah"
- "5 buah Bawang putih"
- "2 cm Kunyit"
- "secukupnya Penyedap"
- " Air"
recipeinstructions:
- "Cuci bersih ayam,tiriskan"
- "Haluskan bawang merah,bawang putih,kemiri,"
- "Parut lengkuas,jahe,kunyit"
- "Rebus ayam dgn bumbu sampe air agak menyusut"
- "Tiriskan daging ayam"
- "Goreng ayam beserta bumbu"
- "Happy cooking,jgn lupa foto recook"
categories:
- Recipe
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 181 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam goreng lengkuas](https://img-global.cpcdn.com/recipes/8ebcc9bfa3450ad5/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan renyah. Ciri makanan Indonesia ayam goreng lengkuas yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam goreng lengkuas untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang bisa anda praktekkan salah satunya ayam goreng lengkuas yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep ayam goreng lengkuas tanpa harus bersusah payah.
Berikut ini resep Ayam goreng lengkuas yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 11 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam goreng lengkuas:

1. Siapkan 1 kg daging ayam
1. Jangan lupa 5 cm Lengkuas
1. Dibutuhkan 2 cm Jahe
1. Dibutuhkan 2 batang Serai
1. Diperlukan 5 lembar Daun jeruk
1. Jangan lupa 3 lembar Daun salam
1. Harap siapkan 3 buah Bawang merah
1. Dibutuhkan 5 buah Bawang putih
1. Siapkan 2 cm Kunyit
1. Diperlukan secukupnya Penyedap
1. Harap siapkan  Air




<!--inarticleads2-->

##### Instruksi membuat  Ayam goreng lengkuas:

1. Cuci bersih ayam,tiriskan
1. Haluskan bawang merah,bawang putih,kemiri,
1. Parut lengkuas,jahe,kunyit
1. Rebus ayam dgn bumbu sampe air agak menyusut
1. Tiriskan daging ayam
1. Goreng ayam beserta bumbu
1. Happy cooking,jgn lupa foto recook




Demikianlah cara membuat ayam goreng lengkuas yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
