---
description: "Langkah menyiapakan 6. Ayam goreng lengkuas Terbukti"
title: "Langkah menyiapakan 6. Ayam goreng lengkuas Terbukti"
slug: 479-langkah-menyiapakan-6-ayam-goreng-lengkuas-terbukti
date: 2020-09-07T14:36:43.687Z
image: https://img-global.cpcdn.com/recipes/8bbc2da11156af79/751x532cq70/6-ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8bbc2da11156af79/751x532cq70/6-ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8bbc2da11156af79/751x532cq70/6-ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Alta Cummings
ratingvalue: 4.9
reviewcount: 47098
recipeingredient:
- "1/2 ekor ayam Saya goreng 2 kali Sisanya baru digoreng nanti"
- "1 batang besar lengkuas Parut"
- " Bumbu halus "
- "5 siung bawang merah"
- "2 siung bawang putih"
- "2 kemiri"
- " Ketumbar"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 sdt garam"
- " Minyak untuk menggoreng"
- "1 batang sereh"
- " Daun salam"
- "1 sdt Kaldu jamur"
recipeinstructions:
- "Bersihkan ayam cuci hingga bersih di air yang mengalir"
- "Haluskan bumbu. Panaskan minyak di wajan kemudian masukkan bumbu halus. Tumis dan masukan lengkuas parut, sereh dan daun salam."
- "Masukan air secukupnya, masukan kaldu bubuk dan masukan ayam."
- "Ungkep ayam sampai bumbu meresap. Cek rasa jika dirasa masih kurang asin tambahkan garam."
- "Setelah bumbu meresap pisahkan ayam dan bumbu."
- "Goreng ayam diminyak yang panas hingga kecoklatan. Angkat tiriskan kemudian goreng bumbu rempahnya."
- "Angkat dan sajikan."
categories:
- Recipe
tags:
- 6
- ayam
- goreng

katakunci: 6 ayam goreng 
nutrition: 270 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT35M"
recipeyield: "2"
recipecategory: Lunch

---


![6. Ayam goreng lengkuas](https://img-global.cpcdn.com/recipes/8bbc2da11156af79/751x532cq70/6-ayam-goreng-lengkuas-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang setidaknya kita lestarikan karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti 6. ayam goreng lengkuas yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Kita

Keharmonisan keluarga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan 6. Ayam goreng lengkuas untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian masakan yang dapat anda buat salah satunya 6. ayam goreng lengkuas yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep 6. ayam goreng lengkuas tanpa harus bersusah payah.
Berikut ini resep 6. Ayam goreng lengkuas yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat 6. Ayam goreng lengkuas:

1. Harus ada 1/2 ekor ayam. Saya goreng 2 kali. Sisanya baru digoreng nanti
1. Jangan lupa 1 batang besar lengkuas. Parut
1. Dibutuhkan  Bumbu halus :
1. Harus ada 5 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Harap siapkan 2 kemiri
1. Harus ada  Ketumbar
1. Harus ada 1 ruas jahe
1. Dibutuhkan 1 ruas kunyit
1. Dibutuhkan 1 sdt garam
1. Harap siapkan  Minyak untuk menggoreng
1. Diperlukan 1 batang sereh
1. Dibutuhkan  Daun salam
1. Siapkan 1 sdt Kaldu jamur




<!--inarticleads2-->

##### Instruksi membuat  6. Ayam goreng lengkuas:

1. Bersihkan ayam cuci hingga bersih di air yang mengalir
1. Haluskan bumbu. Panaskan minyak di wajan kemudian masukkan bumbu halus. Tumis dan masukan lengkuas parut, sereh dan daun salam.
1. Masukan air secukupnya, masukan kaldu bubuk dan masukan ayam.
1. Ungkep ayam sampai bumbu meresap. Cek rasa jika dirasa masih kurang asin tambahkan garam.
1. Setelah bumbu meresap pisahkan ayam dan bumbu.
1. Goreng ayam diminyak yang panas hingga kecoklatan. Angkat tiriskan kemudian goreng bumbu rempahnya.
1. Angkat dan sajikan.




Demikianlah cara membuat 6. ayam goreng lengkuas yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
