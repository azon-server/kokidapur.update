---
description: "Cara singkat untuk membuat Ayam rica-rica daun kemangi Cepat"
title: "Cara singkat untuk membuat Ayam rica-rica daun kemangi Cepat"
slug: 13-cara-singkat-untuk-membuat-ayam-rica-rica-daun-kemangi-cepat
date: 2020-11-10T20:21:55.684Z
image: https://img-global.cpcdn.com/recipes/8295ee86d391737a/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8295ee86d391737a/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8295ee86d391737a/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Linnie McDaniel
ratingvalue: 4.2
reviewcount: 11555
recipeingredient:
- "1/2 ekor ayam boiler"
- "1 bh jeruk nipis"
- "3 ikat kemangi"
- "1 btg serai geprek"
- "seruas lengkuas geprek"
- "7 lbr daun jeruk"
- "1 btg daun bawang"
- "Secukupnya air"
- " Garam kaldu jamur"
- "1 sdm gula merah disisir"
- " Bumbu halus "
- "6 bh bamer"
- "2 siung baput"
- "8 bh cabe merah"
- "20 bh cabe rawit selera"
- "2 btr kemiri"
- "Sejempol jahe  kunyit"
recipeinstructions:
- "Cuci bersih ayam, beri perasan jeruk nipis diamkan 1 jam -/+."
- "Goreng cabe merah, rawit, baput, bamer, hingga layu. Lalu blender halus bersama bumbu lainnya."
- "Beri minyak aga banyak, -/+ 5 sdm.. panaskan. Masukan bumbu halus. Lanjut masukan serai, lengkuas, daun jeruk. Tumis hingga wangi. Lalu masukan gula merah. Aduk hingga tercampur."
- "Beri sedikit air -/+ stengah gelas kecil. Lalu masukan garam &amp; kaldu. Cek rasa. Masukan ayam. Masak hingga matang. Balik sisi ya klo airnya g rata dgn ayamnya. Menit akhir stelah ayam sdh matang. Masukan daun bawang &amp; kemangi. Sajikan."
categories:
- Recipe
tags:
- ayam
- ricarica
- daun

katakunci: ayam ricarica daun 
nutrition: 254 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam rica-rica daun kemangi](https://img-global.cpcdn.com/recipes/8295ee86d391737a/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica-rica daun kemangi yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan ciri khas yang merupakan keragaman Indonesia



Keharmonisan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Ayam rica-rica daun kemangi untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang dapat anda coba salah satunya ayam rica-rica daun kemangi yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica-rica daun kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica daun kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica daun kemangi:

1. Diperlukan 1/2 ekor ayam boiler
1. Siapkan 1 bh jeruk nipis
1. Dibutuhkan 3 ikat kemangi
1. Tambah 1 btg serai (geprek)
1. Harus ada seruas lengkuas (geprek)
1. Dibutuhkan 7 lbr daun jeruk
1. Dibutuhkan 1 btg daun bawang
1. Harus ada Secukupnya air
1. Dibutuhkan  Garam, kaldu jamur
1. Diperlukan 1 sdm gula merah (disisir)
1. Tambah  Bumbu halus :
1. Dibutuhkan 6 bh bamer
1. Siapkan 2 siung baput
1. Tambah 8 bh cabe merah
1. Dibutuhkan 20 bh cabe rawit *selera
1. Siapkan 2 btr kemiri
1. Tambah Sejempol jahe &amp; kunyit




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica-rica daun kemangi:

1. Cuci bersih ayam, beri perasan jeruk nipis diamkan 1 jam -/+.
1. Goreng cabe merah, rawit, baput, bamer, hingga layu. Lalu blender halus bersama bumbu lainnya.
1. Beri minyak aga banyak, -/+ 5 sdm.. panaskan. Masukan bumbu halus. Lanjut masukan serai, lengkuas, daun jeruk. Tumis hingga wangi. Lalu masukan gula merah. Aduk hingga tercampur.
1. Beri sedikit air -/+ stengah gelas kecil. Lalu masukan garam &amp; kaldu. Cek rasa. Masukan ayam. Masak hingga matang. Balik sisi ya klo airnya g rata dgn ayamnya. Menit akhir stelah ayam sdh matang. Masukan daun bawang &amp; kemangi. Sajikan.




Demikianlah cara membuat ayam rica-rica daun kemangi yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat gampang dan cepat, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
