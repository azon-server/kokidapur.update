---
description: "Resep : Ayam bumbu rujak teraktual"
title: "Resep : Ayam bumbu rujak teraktual"
slug: 494-resep-ayam-bumbu-rujak-teraktual
date: 2020-12-05T06:18:31.463Z
image: https://img-global.cpcdn.com/recipes/cc8e9f48b49423af/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cc8e9f48b49423af/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cc8e9f48b49423af/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
author: Lucinda Bush
ratingvalue: 4.5
reviewcount: 37984
recipeingredient:
- "1 ekor ayam kecil dipotong 4"
- "2 lbr Daun salam"
- "4 lbr Daun jeruk"
- " Jeruk nipis"
- "Secukupnya garam"
- "1 keping kecil gula aren"
- "Secukupnya air asam jawa"
- "250 ml santan kental"
- " Bumbu halus"
- "6 bh cabe merah keriting"
- "10 bh cabe rawit"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "1 sdt terasi"
recipeinstructions:
- "Potong ayam dan cuci bersih lalu lumuri dengan lemon dan garam, tumis bumbu halus dengan daun jeruk dan daun salam hingga tanak lalu masukkan santan"
- "Setelah santan mendidih masukkan air asam jawa dan gula merah masak hingga mendidih lalu masukkan ayam"
- "Masak ayam sampai kuahnya menyusut, jangan lupa dikoreksi rasa dan ayam dibalik2 supaya tidak gosong bawahnya"
- "Ayam siap untuk dibakar atau dihidangkan langsung juga enak"
categories:
- Recipe
tags:
- ayam
- bumbu
- rujak

katakunci: ayam bumbu rujak 
nutrition: 125 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam bumbu rujak](https://img-global.cpcdn.com/recipes/cc8e9f48b49423af/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam bumbu rujak yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Kita

Kehangatan keluarga dapat didapat dengan cara simple. Diantaranya adalah membuat makanan Ayam bumbu rujak untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang dapat anda coba salah satunya ayam bumbu rujak yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep ayam bumbu rujak tanpa harus bersusah payah.
Seperti resep Ayam bumbu rujak yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam bumbu rujak:

1. Dibutuhkan 1 ekor ayam kecil dipotong 4
1. Diperlukan 2 lbr Daun salam
1. Siapkan 4 lbr Daun jeruk
1. Diperlukan  Jeruk nipis
1. Diperlukan Secukupnya garam
1. Harap siapkan 1 keping kecil gula aren
1. Harus ada Secukupnya air asam jawa
1. Harap siapkan 250 ml santan kental
1. Diperlukan  Bumbu halus
1. Dibutuhkan 6 bh cabe merah keriting
1. Harus ada 10 bh cabe rawit
1. Tambah 8 siung bawang merah
1. Dibutuhkan 4 siung bawang putih
1. Siapkan 1 sdt terasi




<!--inarticleads2-->

##### Langkah membuat  Ayam bumbu rujak:

1. Potong ayam dan cuci bersih lalu lumuri dengan lemon dan garam, tumis bumbu halus dengan daun jeruk dan daun salam hingga tanak lalu masukkan santan
1. Setelah santan mendidih masukkan air asam jawa dan gula merah masak hingga mendidih lalu masukkan ayam
1. Masak ayam sampai kuahnya menyusut, jangan lupa dikoreksi rasa dan ayam dibalik2 supaya tidak gosong bawahnya
1. Ayam siap untuk dibakar atau dihidangkan langsung juga enak




Demikianlah cara membuat ayam bumbu rujak yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
