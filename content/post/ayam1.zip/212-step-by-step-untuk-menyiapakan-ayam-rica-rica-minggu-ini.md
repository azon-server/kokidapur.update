---
description: "Step-by-Step untuk menyiapakan Ayam Rica Rica minggu ini"
title: "Step-by-Step untuk menyiapakan Ayam Rica Rica minggu ini"
slug: 212-step-by-step-untuk-menyiapakan-ayam-rica-rica-minggu-ini
date: 2020-10-11T08:35:30.373Z
image: https://img-global.cpcdn.com/recipes/1c04ac253aba4c87/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1c04ac253aba4c87/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1c04ac253aba4c87/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Kyle Hunter
ratingvalue: 4.5
reviewcount: 41001
recipeingredient:
- "1 ekor ayam pejantan"
- "1 jeruk nipis"
- "100 ml air"
- "2 Sereh geprek"
- "4 Daun Salam"
- "2 Daun Jeruk"
- "1 Daun Pandan"
- "1 sdt garam"
- "1/2 sdt kaldu jamur"
- "1/2 sdt gula pasir aku skip"
- " BAHAN PELENGKAP "
- "iris Daun bawang"
- "iris Daun jeruk"
- " Kemangi aku skip"
- " BUMBU HALUS "
- "10 bh cabe merah"
- "5 cabe rawit aku skip"
- "5 bawang merah"
- "5 bawang putih"
- "3 kemiri goreng atau sangrai"
- "2 ruas lengkuas"
- "2 ruas jahe"
- "1 ruas kunyit"
recipeinstructions:
- "Lumuri ayam dengan jeruk nipis, lalu goreng setengah matang."
- "Blender Bumbu Halus, boleh agak kasar yahh.."
- "Tumis bumbu halus sampai harummm dan matang, masukan daun salam, daun pandan, sereh dan daun jeruk."
- "Masukan ayam yang sudah di goreng setengah matang, lalu aduk merata, kemudian tambahkan air secukupnya."
- "Masak ayam sampai matang dan empuk, dan airnya sudah mulai menyusut. Lalu tambahkan garam dan kaldu jamur, kalau mau pakai gula silahkan saja yah. Koreksi rasa."
- "Terakhir tambahkan daun bawang, daun jeruk iris dan kemangi, ternyata kemangiku ga bisa dipakai jadi aku skip. Tapi rasanya tetep enak dann kaya rasa bangetttttt.....bisa ngabisin nasi. 😄😄"
- "Ayam rica rica siap untuk disajikan. Duh ini tuh enak kalo menurutkuu.. bikin yuk..."
- "Ayam nya lembut, karena aku pake pejantan jadi bumbu nya meresapp, kalau mau pake ayam negeri or kampung boleh ajah yah selera masing2.."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 293 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/1c04ac253aba4c87/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis dan enak. Karasteristik kuliner Nusantara ayam rica rica yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kehangatan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah memasak Ayam Rica Rica untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi makanan yang bisa anda buat salah satunya ayam rica rica yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 23 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica:

1. Harus ada 1 ekor ayam pejantan
1. Harap siapkan 1 jeruk nipis
1. Jangan lupa 100 ml air
1. Siapkan 2 Sereh geprek
1. Harus ada 4 Daun Salam
1. Dibutuhkan 2 Daun Jeruk
1. Dibutuhkan 1 Daun Pandan
1. Diperlukan 1 sdt garam
1. Diperlukan 1/2 sdt kaldu jamur
1. Siapkan 1/2 sdt gula pasir (aku skip)
1. Diperlukan  BAHAN PELENGKAP :
1. Harus ada iris Daun bawang
1. Dibutuhkan iris Daun jeruk
1. Diperlukan  Kemangi (aku skip)
1. Harus ada  BUMBU HALUS :
1. Harap siapkan 10 bh cabe merah
1. Dibutuhkan 5 cabe rawit (aku skip)
1. Jangan lupa 5 bawang merah
1. Harap siapkan 5 bawang putih
1. Tambah 3 kemiri goreng atau sangrai
1. Dibutuhkan 2 ruas lengkuas
1. Tambah 2 ruas jahe
1. Tambah 1 ruas kunyit




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Rica:

1. Lumuri ayam dengan jeruk nipis, lalu goreng setengah matang.
1. Blender Bumbu Halus, boleh agak kasar yahh..
1. Tumis bumbu halus sampai harummm dan matang, masukan daun salam, daun pandan, sereh dan daun jeruk.
1. Masukan ayam yang sudah di goreng setengah matang, lalu aduk merata, kemudian tambahkan air secukupnya.
1. Masak ayam sampai matang dan empuk, dan airnya sudah mulai menyusut. Lalu tambahkan garam dan kaldu jamur, kalau mau pakai gula silahkan saja yah. Koreksi rasa.
1. Terakhir tambahkan daun bawang, daun jeruk iris dan kemangi, ternyata kemangiku ga bisa dipakai jadi aku skip. Tapi rasanya tetep enak dann kaya rasa bangetttttt.....bisa ngabisin nasi. 😄😄
1. Ayam rica rica siap untuk disajikan. Duh ini tuh enak kalo menurutkuu.. bikin yuk...
1. Ayam nya lembut, karena aku pake pejantan jadi bumbu nya meresapp, kalau mau pake ayam negeri or kampung boleh ajah yah selera masing2..




Demikianlah cara membuat ayam rica rica yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
