---
description: "Panduan membuat Ayam Goreng Saos Teriyaki Sempurna"
title: "Panduan membuat Ayam Goreng Saos Teriyaki Sempurna"
slug: 268-panduan-membuat-ayam-goreng-saos-teriyaki-sempurna
date: 2020-09-26T01:49:21.373Z
image: https://img-global.cpcdn.com/recipes/961e954000825da4/751x532cq70/ayam-goreng-saos-teriyaki-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/961e954000825da4/751x532cq70/ayam-goreng-saos-teriyaki-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/961e954000825da4/751x532cq70/ayam-goreng-saos-teriyaki-foto-resep-utama.jpg
author: Gary Stevens
ratingvalue: 5
reviewcount: 45291
recipeingredient:
- "5 bh Sayap Ayam bersihkan potong 2 bagian"
- "1 sdm Wijen"
- "2 bh Bunga lawang"
- "1 bh Pucuk Gantigegantigantiganti"
- "1 btr Telur"
- "1 bgn Tepung Beras"
- "2 bgn Tepung Bumbu"
- "1/2 bks Saos Teriyaki instan saya pakai merk pronas"
- "1 sdm Kecap manis"
- "1 sdm Saos Tomat"
- "1/2 sdm Saos Tiram"
- "1 sdt Gula pasir"
- "Secukupnya Kaldu bubuk optional"
- "1 btg Daun bawangseledri"
recipeinstructions:
- "Rebus ayam dengan pucuk ganti dan bunga lawang untuk menghilangkan bau amis sampai setengah matang. Angkat, tiriskan."
- "Sangrai wijen sampai keemasan."
- "Siapkan tepung bumbu dicampur dengan tepung beras (2:1) dan telur kocok. Balurkan ayam ke tepung kering, kemudian balurkan telur, kemudian kembali ke tepung kering lagi, renas-remas sampai merata."
- "Goreng ayam sampai matang. Sisihkan."
- "Tumis bumbu halus sampai harum. Tambahkan saos teriyaki. Aduk rata."
- "Tambahkan kecap, saos tomat, dan saos tiram. Beri gula pasir. Cek rasa. Bila dirasa perlu tambah kaldu bubuk silahkan ditambahkan. Masak sampai mendidih. Masukkan ayam goreng. Aduk sampai merata."
- "Angkat ayam dari wajan. Taburi dengan wijen dan daun bawang/seledri. Sajikan."
categories:
- Recipe
tags:
- ayam
- goreng
- saos

katakunci: ayam goreng saos 
nutrition: 123 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Goreng Saos Teriyaki](https://img-global.cpcdn.com/recipes/961e954000825da4/751x532cq70/ayam-goreng-saos-teriyaki-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau renyah. Ciri kuliner Indonesia ayam goreng saos teriyaki yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah membuat makanan Ayam Goreng Saos Teriyaki untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang dapat anda buat salah satunya ayam goreng saos teriyaki yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep ayam goreng saos teriyaki tanpa harus bersusah payah.
Seperti resep Ayam Goreng Saos Teriyaki yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Saos Teriyaki:

1. Siapkan 5 bh Sayap Ayam, bersihkan, potong 2 bagian
1. Tambah 1 sdm Wijen
1. Harus ada 2 bh Bunga lawang
1. Tambah 1 bh Pucuk Ganti/geganti/ganti-ganti
1. Dibutuhkan 1 btr Telur
1. Jangan lupa 1 bgn Tepung Beras
1. Harap siapkan 2 bgn Tepung Bumbu
1. Tambah 1/2 bks Saos Teriyaki instan (saya pakai merk pronas)
1. Siapkan 1 sdm Kecap manis
1. Tambah 1 sdm Saos Tomat
1. Harus ada 1/2 sdm Saos Tiram
1. Diperlukan 1 sdt Gula pasir
1. Harus ada Secukupnya Kaldu bubuk (optional)
1. Siapkan 1 btg Daun bawang/seledri




<!--inarticleads2-->

##### Langkah membuat  Ayam Goreng Saos Teriyaki:

1. Rebus ayam dengan pucuk ganti dan bunga lawang untuk menghilangkan bau amis sampai setengah matang. Angkat, tiriskan.
1. Sangrai wijen sampai keemasan.
1. Siapkan tepung bumbu dicampur dengan tepung beras (2:1) dan telur kocok. Balurkan ayam ke tepung kering, kemudian balurkan telur, kemudian kembali ke tepung kering lagi, renas-remas sampai merata.
1. Goreng ayam sampai matang. Sisihkan.
1. Tumis bumbu halus sampai harum. Tambahkan saos teriyaki. Aduk rata.
1. Tambahkan kecap, saos tomat, dan saos tiram. Beri gula pasir. Cek rasa. Bila dirasa perlu tambah kaldu bubuk silahkan ditambahkan. Masak sampai mendidih. Masukkan ayam goreng. Aduk sampai merata.
1. Angkat ayam dari wajan. Taburi dengan wijen dan daun bawang/seledri. Sajikan.




Demikianlah cara membuat ayam goreng saos teriyaki yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
