---
description: "Resep : Ayam Rica-Rica 🌶️ Terbukti"
title: "Resep : Ayam Rica-Rica 🌶️ Terbukti"
slug: 64-resep-ayam-rica-rica-terbukti
date: 2020-11-03T12:08:07.986Z
image: https://img-global.cpcdn.com/recipes/8e966cd1065dc3e0/751x532cq70/ayam-rica-rica-🌶️-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8e966cd1065dc3e0/751x532cq70/ayam-rica-rica-🌶️-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8e966cd1065dc3e0/751x532cq70/ayam-rica-rica-🌶️-foto-resep-utama.jpg
author: Edith Turner
ratingvalue: 5
reviewcount: 44512
recipeingredient:
- "600 gr ayam potong sesuai selera"
- "2 ikat kemangi petiki daunnya"
- "1 btg daun bawang"
- "3 lbr daun jeruk"
- "2 lbr daun salam"
- "2 btg sereh geprek"
- "2 ruas lengkuas geprek"
- "1/2 sdm kaldu bubuk"
- "2 sdt gula pasir"
- "1 sdt garam"
- "400 ml air"
- " Bumbu marinasi"
- "1 bh jeruk nipis"
- "1 sdt garam"
- "1 sdt kunyit bubuk"
- " Bumbu halus"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "3 bh kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
- "12 bh cabe merah keriting"
- "10 bh cabe rawit merah"
recipeinstructions:
- "Pertama ayam saya marinasi terlebih dahulu dgn perasan air jeruk nipis, diamkan selama10 menit lalu bilas. Selanjutnya marinasi ayam dgn garam dan kunyit bubuk, aduk rata lalu diamkan selama kurleb 30 menit hingga bumbunya meresap."
- "Panaskan minyak kemudian goreng ayam hingga berwarna kecoklatan, gunakan api sedang. Angkat dan tiriskan. Sisihkan."
- "Siapkan bumbu halus kemudian tumis bumbu dengan sedikit minyak sisa menggoreng ayam. Masukkan sereh, salam, daun jeruk, dan lengkuas lalu tumis bumbu hingga harum dan matangnya tanak agar tidak mudah basi. Masukkan air lalu gula, garam, dan kaldu bubuk, aduk sebentar lalu masukkan ayam goreng."
- "Masak ayam hingga kuahnya mulai menyusut, jangan lupa koreksi rasanya. Terakhir masukkan kemangi dan daun bawang lalu aduk rata sebentar aja. Angkat dan sajikan"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 199 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica-Rica 🌶️](https://img-global.cpcdn.com/recipes/8e966cd1065dc3e0/751x532cq70/ayam-rica-rica-🌶️-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga gurih. Ciri masakan Indonesia ayam rica-rica 🌶️ yang penuh dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Ayam Rica-Rica 🌶️ untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang bisa anda praktekkan salah satunya ayam rica-rica 🌶️ yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep ayam rica-rica 🌶️ tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica 🌶️ yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 23 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica 🌶️:

1. Harap siapkan 600 gr ayam, potong sesuai selera
1. Harus ada 2 ikat kemangi, petiki daunnya
1. Tambah 1 btg daun bawang
1. Tambah 3 lbr daun jeruk
1. Harap siapkan 2 lbr daun salam
1. Jangan lupa 2 btg sereh, geprek
1. Harap siapkan 2 ruas lengkuas, geprek
1. Tambah 1/2 sdm kaldu bubuk
1. Siapkan 2 sdt gula pasir
1. Harap siapkan 1 sdt garam
1. Harap siapkan 400 ml air
1. Siapkan  Bumbu marinasi:
1. Harap siapkan 1 bh jeruk nipis
1. Harus ada 1 sdt garam
1. Dibutuhkan 1 sdt kunyit bubuk
1. Harap siapkan  Bumbu halus:
1. Jangan lupa 6 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Harap siapkan 3 bh kemiri
1. Dibutuhkan 1 ruas jahe
1. Harus ada 1 ruas kunyit
1. Tambah 12 bh cabe merah keriting
1. Tambah 10 bh cabe rawit merah




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-Rica 🌶️:

1. Pertama ayam saya marinasi terlebih dahulu dgn perasan air jeruk nipis, diamkan selama10 menit lalu bilas. Selanjutnya marinasi ayam dgn garam dan kunyit bubuk, aduk rata lalu diamkan selama kurleb 30 menit hingga bumbunya meresap.
1. Panaskan minyak kemudian goreng ayam hingga berwarna kecoklatan, gunakan api sedang. Angkat dan tiriskan. Sisihkan.
1. Siapkan bumbu halus kemudian tumis bumbu dengan sedikit minyak sisa menggoreng ayam. Masukkan sereh, salam, daun jeruk, dan lengkuas lalu tumis bumbu hingga harum dan matangnya tanak agar tidak mudah basi. Masukkan air lalu gula, garam, dan kaldu bubuk, aduk sebentar lalu masukkan ayam goreng.
1. Masak ayam hingga kuahnya mulai menyusut, jangan lupa koreksi rasanya. Terakhir masukkan kemangi dan daun bawang lalu aduk rata sebentar aja. Angkat dan sajikan




Demikianlah cara membuat ayam rica-rica 🌶️ yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
