---
description: "Resep : Ayam Goreng Bumbu Hitam ala Madura teraktual"
title: "Resep : Ayam Goreng Bumbu Hitam ala Madura teraktual"
slug: 240-resep-ayam-goreng-bumbu-hitam-ala-madura-teraktual
date: 2020-10-19T09:02:23.534Z
image: https://img-global.cpcdn.com/recipes/8000f2db0357af12/751x532cq70/ayam-goreng-bumbu-hitam-ala-madura-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8000f2db0357af12/751x532cq70/ayam-goreng-bumbu-hitam-ala-madura-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8000f2db0357af12/751x532cq70/ayam-goreng-bumbu-hitam-ala-madura-foto-resep-utama.jpg
author: Evan Kelly
ratingvalue: 4.9
reviewcount: 18121
recipeingredient:
- "250 gr ayam"
- " Merica Bubuk"
- "Secukupnya garam dan kaldu bubuk"
- "3 lbr daun jeruk biarkan utuh"
- " Bumbu Halus "
- "4 buah cabe merah keriting"
- "10 buah cabe rawit saya mix merah dan hijau"
- "6 butir bawang merah"
- "3 siung bawang putih"
- "1/2 ruas kunyit"
- "2 cm jahe"
- "1 btg sereh ambil putihnya geprek"
- "1/2 ruas lengkuas"
- "1 sdt ketumbar"
recipeinstructions:
- "Cuci bersih ayam, kucuri jeruk nipis, diamkan 15 menit, lalu bilas lagi. Sisihkan. Haluskan bumbu halus."
- "Siapkan wajan, tumis bumbu halus bersama daun jeruk sebentar, lalu tambahkan air, masukkan ayam, lalu masak ayam sampai empuk, bumbu meresap sempurna dan air menyusut."
- "Pisahkan ayam dengan bumbunya. Sisihkan. Goreng ayam hingga matang, lakukan sampai habis. Tiriskan, sisihkan dulu. Matikan kompor."
- "Nyalakan kompor kembali dgn api kecil, goreng bumbu ayam td dgn minyak bekas menggoreng ayam, tambahkan merica, garam dan kaldu bubuk. Masak hingga teksturnya mengering dan warnanya menghitam, awas jgn sampai gosong, krn bakalan pahit rasanya. Tiriskan. Penyajian : Taruh ayam di piring saji, lalu beri bumbu hitam diatasnya. Sajikan dgn nasi hangat dan lalap kesukaan."
categories:
- Recipe
tags:
- ayam
- goreng
- bumbu

katakunci: ayam goreng bumbu 
nutrition: 175 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Goreng Bumbu Hitam ala Madura](https://img-global.cpcdn.com/recipes/8000f2db0357af12/751x532cq70/ayam-goreng-bumbu-hitam-ala-madura-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga empuk. Ciri khas masakan Nusantara ayam goreng bumbu hitam ala madura yang penuh dengan rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kehangatan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Goreng Bumbu Hitam ala Madura untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang bisa anda contoh salah satunya ayam goreng bumbu hitam ala madura yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep ayam goreng bumbu hitam ala madura tanpa harus bersusah payah.
Berikut ini resep Ayam Goreng Bumbu Hitam ala Madura yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 14 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Bumbu Hitam ala Madura:

1. Siapkan 250 gr ayam
1. Tambah  Merica Bubuk
1. Diperlukan Secukupnya garam dan kaldu bubuk
1. Siapkan 3 lbr daun jeruk, biarkan utuh
1. Dibutuhkan  Bumbu Halus :
1. Harus ada 4 buah cabe merah keriting
1. Harap siapkan 10 buah cabe rawit (saya mix merah dan hijau)
1. Siapkan 6 butir bawang merah
1. Tambah 3 siung bawang putih
1. Harus ada 1/2 ruas kunyit
1. Tambah 2 cm jahe
1. Jangan lupa 1 btg sereh, ambil putihnya, geprek
1. Siapkan 1/2 ruas lengkuas
1. Tambah 1 sdt ketumbar




<!--inarticleads2-->

##### Cara membuat  Ayam Goreng Bumbu Hitam ala Madura:

1. Cuci bersih ayam, kucuri jeruk nipis, diamkan 15 menit, lalu bilas lagi. Sisihkan. Haluskan bumbu halus.
1. Siapkan wajan, tumis bumbu halus bersama daun jeruk sebentar, lalu tambahkan air, masukkan ayam, lalu masak ayam sampai empuk, bumbu meresap sempurna dan air menyusut.
1. Pisahkan ayam dengan bumbunya. Sisihkan. Goreng ayam hingga matang, lakukan sampai habis. Tiriskan, sisihkan dulu. Matikan kompor.
1. Nyalakan kompor kembali dgn api kecil, goreng bumbu ayam td dgn minyak bekas menggoreng ayam, tambahkan merica, garam dan kaldu bubuk. Masak hingga teksturnya mengering dan warnanya menghitam, awas jgn sampai gosong, krn bakalan pahit rasanya. Tiriskan. Penyajian : Taruh ayam di piring saji, lalu beri bumbu hitam diatasnya. Sajikan dgn nasi hangat dan lalap kesukaan.




Demikianlah cara membuat ayam goreng bumbu hitam ala madura yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat gampang dan cepat, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
