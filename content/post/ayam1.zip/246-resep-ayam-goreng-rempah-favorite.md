---
description: "Resep : Ayam Goreng Rempah Favorite"
title: "Resep : Ayam Goreng Rempah Favorite"
slug: 246-resep-ayam-goreng-rempah-favorite
date: 2020-08-22T23:49:35.290Z
image: https://img-global.cpcdn.com/recipes/934daf517e4176ab/751x532cq70/ayam-goreng-rempah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/934daf517e4176ab/751x532cq70/ayam-goreng-rempah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/934daf517e4176ab/751x532cq70/ayam-goreng-rempah-foto-resep-utama.jpg
author: Lucy Bryan
ratingvalue: 4.5
reviewcount: 22891
recipeingredient:
- "10 Potong Ayam saya ayam negri bagian dada dan paha beli merk Sogood"
- "1 Sdm Cuka"
- "1 Sdm Santan Instan"
- "2 sdt garam saya 4sdt garam"
- "1 sdt kaldu ayam bubuk"
- "1 sdt merica"
- " Bumbu Halus "
- "2 batang serai"
- "4 cm jahe"
- "3 lembar daun jeruk"
- "1 ruas kunyit"
- "2 sdt ketumbar butir sangrai"
- "2 sdt jinten kasar kalau saya bubuk 1 sdt"
- "5 Siung bawang putih"
- "5 Siung bawang merah"
- "1 buah cabai merah besar saya skip"
- "150 ml air"
- " Bahan Pelapis "
- "1 butir telur"
- "2-3 Sdm Maizena saya 3 Sdm"
- "2-3 Sdm Tepung beras saya 3 Sdm"
- " Bahan lainnya "
- " Minyak untuk menggoreng"
recipeinstructions:
- "Haluskan bumbu halus, saring, ambil airnya saja."
- "Masukkan air bumbu halus kedalam ayam, masukkan santan, cuka, garam, kaldu ayam bubuk, dan merica lalu aduk rata kemudian diamkan 1-2 jam di suhu ruang atau semalaman di dalam kulkas (saya semalaman di freezer)."
- "Bila ayam beku, keluarkan dulu hingga cair, lalu masukkan telur, tepung maizena, dan tepung beras kemudian aduk rata dan tambahkan ayam dan bumbu marinasi lalu aduk rata."
- "Siapkan minyak untuk menggoreng, goreng ayam dengan api sedang. Untuk biar ada kremes kriuk-kriuknya campurkan air marinasi dan air (1:1) kemudian tuang ½ - 1 sendok sayur ke dalam pan kemudian aduk-aduk, ulangi proses ini 2-3 kali. Goreng hingga kuning keemasan kemudian kecilkan api dan goreng hingga cokelat keemasan. Sajikan"
categories:
- Recipe
tags:
- ayam
- goreng
- rempah

katakunci: ayam goreng rempah 
nutrition: 282 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Goreng Rempah](https://img-global.cpcdn.com/recipes/934daf517e4176ab/751x532cq70/ayam-goreng-rempah-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang dapat kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam goreng rempah yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Indonesia

Kedekatan keluarga dapat ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam Goreng Rempah untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang bisa anda buat salah satunya ayam goreng rempah yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep ayam goreng rempah tanpa harus bersusah payah.
Seperti resep Ayam Goreng Rempah yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 23 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Rempah:

1. Dibutuhkan 10 Potong Ayam (saya ayam negri bagian dada dan paha beli merk Sogood)
1. Dibutuhkan 1 Sdm Cuka
1. Jangan lupa 1 Sdm Santan Instan
1. Dibutuhkan 2 sdt garam (saya 4sdt garam)
1. Diperlukan 1 sdt kaldu ayam bubuk
1. Harus ada 1 sdt merica
1. Dibutuhkan  Bumbu Halus :
1. Tambah 2 batang serai
1. Jangan lupa 4 cm jahe
1. Siapkan 3 lembar daun jeruk
1. Harus ada 1 ruas kunyit
1. Harap siapkan 2 sdt ketumbar butir sangrai
1. Dibutuhkan 2 sdt jinten kasar (kalau saya bubuk 1 sdt)
1. Siapkan 5 Siung bawang putih
1. Siapkan 5 Siung bawang merah
1. Diperlukan 1 buah cabai merah besar (saya skip)
1. Diperlukan 150 ml air
1. Siapkan  Bahan Pelapis :
1. Diperlukan 1 butir telur
1. Jangan lupa 2-3 Sdm Maizena (saya 3 Sdm)
1. Siapkan 2-3 Sdm Tepung beras (saya 3 Sdm)
1. Harus ada  Bahan lainnya :
1. Jangan lupa  Minyak untuk menggoreng




<!--inarticleads2-->

##### Langkah membuat  Ayam Goreng Rempah:

1. Haluskan bumbu halus, saring, ambil airnya saja.
1. Masukkan air bumbu halus kedalam ayam, masukkan santan, cuka, garam, kaldu ayam bubuk, dan merica lalu aduk rata kemudian diamkan 1-2 jam di suhu ruang atau semalaman di dalam kulkas (saya semalaman di freezer).
1. Bila ayam beku, keluarkan dulu hingga cair, lalu masukkan telur, tepung maizena, dan tepung beras kemudian aduk rata dan tambahkan ayam dan bumbu marinasi lalu aduk rata.
1. Siapkan minyak untuk menggoreng, goreng ayam dengan api sedang. Untuk biar ada kremes kriuk-kriuknya campurkan air marinasi dan air (1:1) kemudian tuang ½ - 1 sendok sayur ke dalam pan kemudian aduk-aduk, ulangi proses ini 2-3 kali. Goreng hingga kuning keemasan kemudian kecilkan api dan goreng hingga cokelat keemasan. Sajikan




Demikianlah cara membuat ayam goreng rempah yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
