---
description: "Panduan menyiapakan Usus Ayam Rica - Rica Cepat"
title: "Panduan menyiapakan Usus Ayam Rica - Rica Cepat"
slug: 142-panduan-menyiapakan-usus-ayam-rica-rica-cepat
date: 2020-11-16T11:03:52.655Z
image: https://img-global.cpcdn.com/recipes/a22a6ae74fba3279/751x532cq70/usus-ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a22a6ae74fba3279/751x532cq70/usus-ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a22a6ae74fba3279/751x532cq70/usus-ayam-rica-rica-foto-resep-utama.jpg
author: Johanna Andrews
ratingvalue: 5
reviewcount: 36637
recipeingredient:
- "1/2 kg usus ayam"
- "1 biji jeruk nipis"
- "1 batang sereh memarkan"
- "2 lembar daun jeruk"
- "1 lembar daun salam"
- " minyak goreng"
- "secukupnya garam"
- "secukupnya kaldu jamur"
- " Bumbu Halus "
- "5 siung bawang merah"
- "3 siungbawang putih"
- "1 buah cabe merah besar"
- "10 buah cabe rawit"
- "1 buah tomat"
recipeinstructions:
- "Bersihkan usus ayam kemudian peras dengan 1 biji jeruk nipis diamkan 15 menit cuci bersih kemudian rebus sampai matang"
- "Jika sudah di rasa cukup matang matikan api cuci bersih kemudian potong2"
- "Haluskan bawang meeah, bawang putih tomat dan cabe merah besar dan cabe rawit sampai halus."
- "Jika sudah halus tumis bumbu dengan minyak horeng secukupnya sampai harum kemudian masukan sereh, Daun jeruk dan daun salam. aduk rata"
- "Kemudian masukan usus ayam aduk rata beri sedikit air aduk rata masukan garam dan kaldu jamur tunggu air meyusut dan meresap cek rasa dan matikan api."
- "Usus ayam rica2 siap di santap dengan nasi hangat"
categories:
- Recipe
tags:
- usus
- ayam
- rica

katakunci: usus ayam rica 
nutrition: 236 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Dinner

---


![Usus Ayam Rica - Rica](https://img-global.cpcdn.com/recipes/a22a6ae74fba3279/751x532cq70/usus-ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan empuk. Ciri masakan Indonesia usus ayam rica - rica yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Usus Ayam Rica - Rica untuk keluarga. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang dapat anda coba salah satunya usus ayam rica - rica yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep usus ayam rica - rica tanpa harus bersusah payah.
Berikut ini resep Usus Ayam Rica - Rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 14 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Usus Ayam Rica - Rica:

1. Harap siapkan 1/2 kg usus ayam
1. Siapkan 1 biji jeruk nipis
1. Tambah 1 batang sereh memarkan
1. Harap siapkan 2 lembar daun jeruk
1. Harus ada 1 lembar daun salam
1. Diperlukan  minyak goreng
1. Tambah secukupnya garam
1. Dibutuhkan secukupnya kaldu jamur
1. Harap siapkan  Bumbu Halus :
1. Siapkan 5 siung bawang merah
1. Harus ada 3 siungbawang putih
1. Jangan lupa 1 buah cabe merah besar
1. Siapkan 10 buah cabe rawit
1. Siapkan 1 buah tomat




<!--inarticleads2-->

##### Langkah membuat  Usus Ayam Rica - Rica:

1. Bersihkan usus ayam kemudian peras dengan 1 biji jeruk nipis diamkan 15 menit cuci bersih kemudian rebus sampai matang
1. Jika sudah di rasa cukup matang matikan api cuci bersih kemudian potong2
1. Haluskan bawang meeah, bawang putih tomat dan cabe merah besar dan cabe rawit sampai halus.
1. Jika sudah halus tumis bumbu dengan minyak horeng secukupnya sampai harum kemudian masukan sereh, Daun jeruk dan daun salam. aduk rata
1. Kemudian masukan usus ayam aduk rata beri sedikit air aduk rata masukan garam dan kaldu jamur tunggu air meyusut dan meresap cek rasa dan matikan api.
1. Usus ayam rica2 siap di santap dengan nasi hangat




Demikianlah cara membuat usus ayam rica - rica yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
