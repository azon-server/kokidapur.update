---
description: "Step-by-Step untuk membuat Ayam rica rica kemangi Sempurna"
title: "Step-by-Step untuk membuat Ayam rica rica kemangi Sempurna"
slug: 193-step-by-step-untuk-membuat-ayam-rica-rica-kemangi-sempurna
date: 2020-10-31T14:00:36.689Z
image: https://img-global.cpcdn.com/recipes/8c99fc0d70f44364/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8c99fc0d70f44364/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8c99fc0d70f44364/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Mabelle Boone
ratingvalue: 4.4
reviewcount: 4254
recipeingredient:
- "1 ekor ayam potong kecil"
- "6 lembar daun jeruk potong tipis2"
- "2 batang serai memarkan"
- "3 lembar daun salam"
- "2 ikat kemangi petik daunnya saja"
- "2 ruas lengkuas memarkan"
- "2 ruas jahe memarkan"
- " Garam"
- " Penyedap jamur  kaldu bubuk sesuai selera"
- "6 buah cabe rawit merah bulat boleh ditambah sesuai selera"
- " Bumbu halus"
- "20 cabe merah keriting"
- "9 cabe rawit merah"
- "8 siung bawang merah"
- "3 siung bawang putih"
- "2 ruas kunyit kupas"
recipeinstructions:
- "Cuci bersih ayam, kemudian goreng di minyak panas sampai ayam agak sedikit kecoklatan / setengah matang. Jika sudah kecoklatan, angkat dan tiriskan."
- "Tumis bumbu halus dengan api kecil hingga wangi, masukan lengkuas, jahe, daun jeruk, daun salam, dan batang serai. Tumis kembali hingga wangi."
- "Masukan ayam yang tadi sudah digoreng kedalam tumisan bumbu, masukan garam dan penyedap, aduk hingga ayam tercampur dengan bumbu cabe. Tambahkan sedikit saja air supaya lebih mudah tercampur."
- "Setelah tercampur rata, masukan cabe rawit merah bulat untuk variasi jika ingin menambah rasa pedas, tumis kembali. Setelah semua tercampur rata, masukan daun kemangi, tumis hingga agak layu. Matikan api. Rica rica siap disantap...selamat mencoba bun 🥰🥰🥰"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 191 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/8c99fc0d70f44364/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica rica kemangi yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Indonesia

Kedekatan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam rica rica kemangi untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Inilah rahasia bumbu masakan ayam rica rica dan petunjuk cara membuat rica rica ayam.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang bisa anda praktekkan salah satunya ayam rica rica kemangi yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi:

1. Harap siapkan 1 ekor ayam, potong kecil
1. Dibutuhkan 6 lembar daun jeruk, potong tipis2
1. Tambah 2 batang serai, memarkan
1. Harus ada 3 lembar daun salam
1. Dibutuhkan 2 ikat kemangi, petik daunnya saja
1. Harap siapkan 2 ruas lengkuas, memarkan
1. Harap siapkan 2 ruas jahe, memarkan
1. Diperlukan  Garam
1. Diperlukan  Penyedap jamur / kaldu bubuk (sesuai selera)
1. Harap siapkan 6 buah cabe rawit merah bulat (boleh ditambah sesuai selera)
1. Dibutuhkan  Bumbu halus
1. Dibutuhkan 20 cabe merah keriting
1. Siapkan 9 cabe rawit merah
1. Dibutuhkan 8 siung bawang merah
1. Harap siapkan 3 siung bawang putih
1. Harap siapkan 2 ruas kunyit, kupas


It is made up of chicken that cooked in spicy red and green chili pepper. The origin of this dish is from Minahasan cuisine of North Sulawesi. Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. 

<!--inarticleads2-->

##### Cara membuat  Ayam rica rica kemangi:

1. Cuci bersih ayam, kemudian goreng di minyak panas sampai ayam agak sedikit kecoklatan / setengah matang. Jika sudah kecoklatan, angkat dan tiriskan.
1. Tumis bumbu halus dengan api kecil hingga wangi, masukan lengkuas, jahe, daun jeruk, daun salam, dan batang serai. Tumis kembali hingga wangi.
1. Masukan ayam yang tadi sudah digoreng kedalam tumisan bumbu, masukan garam dan penyedap, aduk hingga ayam tercampur dengan bumbu cabe. Tambahkan sedikit saja air supaya lebih mudah tercampur.
1. Setelah tercampur rata, masukan cabe rawit merah bulat untuk variasi jika ingin menambah rasa pedas, tumis kembali. Setelah semua tercampur rata, masukan daun kemangi, tumis hingga agak layu. Matikan api. Rica rica siap disantap...selamat mencoba bun 🥰🥰🥰


Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. 

Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
