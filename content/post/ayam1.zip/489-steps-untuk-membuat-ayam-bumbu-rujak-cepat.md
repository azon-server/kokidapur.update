---
description: "Steps untuk membuat Ayam bumbu rujak Cepat"
title: "Steps untuk membuat Ayam bumbu rujak Cepat"
slug: 489-steps-untuk-membuat-ayam-bumbu-rujak-cepat
date: 2020-09-22T09:47:43.171Z
image: https://img-global.cpcdn.com/recipes/10911b3378972ad3/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/10911b3378972ad3/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/10911b3378972ad3/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
author: Douglas Miles
ratingvalue: 4.5
reviewcount: 18035
recipeingredient:
- "1 kg ayam potong sesuai selera bersihkan"
- "2 lembar daun jeruk"
- "5 cm serai"
- "5 cm asem jawa larutkan dalam air panas"
- "1 sdm kecap"
- " Bahan marinasi haluskan"
- "5 siung bawang putih"
- "1 sdt jahe bubuk"
- "1/2 sdt kunyit bubuk"
- "1 sdt ketumbar bubuk"
- "secukupnya garam"
- "secukupnya gula"
- "150 ml air"
- " Bumbu halus"
- "6 siung bawang merah kecil"
- "4 siung bawang putih"
- "4 cabai merah besar"
- "6 cabai rawit"
recipeinstructions:
- "Tumis bumbu marinasi, masukkan ayam, tuang sedikit air. Aduk rata dan tutup. Masak sampai bumbu meresap, angkat ayam."
- "Tumis bumbu halus. Masukkan gula merah, garam, dan daun jeruk. Tuang air asem jawa. Masak sampai mendidih."
- "Tambahkan kecap dan gula merah, aduk rata. Masukkan ayam yang sudah di marinasi tanpa di goreng(bisa digoreng dulu jika suka). Aduk rata dan masak sampai matang."
- "Setelah matang dan bumbu meresap pada ayam bisa langsung di sajikan atau bisa di bakar terlebih dahulu."
categories:
- Recipe
tags:
- ayam
- bumbu
- rujak

katakunci: ayam bumbu rujak 
nutrition: 233 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam bumbu rujak](https://img-global.cpcdn.com/recipes/10911b3378972ad3/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam bumbu rujak yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan ciri khas yang merupakan keragaman Nusantara

Keharmonisan rumah tangga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Ayam bumbu rujak untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang dapat anda praktekkan salah satunya ayam bumbu rujak yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam bumbu rujak tanpa harus bersusah payah.
Seperti resep Ayam bumbu rujak yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam bumbu rujak:

1. Harap siapkan 1 kg ayam potong sesuai selera bersihkan
1. Harap siapkan 2 lembar daun jeruk
1. Tambah 5 cm serai
1. Harap siapkan 5 cm asem jawa larutkan dalam air panas
1. Harap siapkan 1 sdm kecap
1. Dibutuhkan  Bahan marinasi: (haluskan)
1. Tambah 5 siung bawang putih
1. Dibutuhkan 1 sdt jahe bubuk
1. Jangan lupa 1/2 sdt kunyit bubuk
1. Diperlukan 1 sdt ketumbar bubuk
1. Harus ada secukupnya garam
1. Dibutuhkan secukupnya gula
1. Harus ada 150 ml air
1. Jangan lupa  Bumbu halus:
1. Harap siapkan 6 siung bawang merah (kecil)
1. Siapkan 4 siung bawang putih
1. Diperlukan 4 cabai merah besar
1. Tambah 6 cabai rawit




<!--inarticleads2-->

##### Instruksi membuat  Ayam bumbu rujak:

1. Tumis bumbu marinasi, masukkan ayam, tuang sedikit air. Aduk rata dan tutup. Masak sampai bumbu meresap, angkat ayam.
1. Tumis bumbu halus. Masukkan gula merah, garam, dan daun jeruk. Tuang air asem jawa. Masak sampai mendidih.
1. Tambahkan kecap dan gula merah, aduk rata. Masukkan ayam yang sudah di marinasi tanpa di goreng(bisa digoreng dulu jika suka). Aduk rata dan masak sampai matang.
1. Setelah matang dan bumbu meresap pada ayam bisa langsung di sajikan atau bisa di bakar terlebih dahulu.




Demikianlah cara membuat ayam bumbu rujak yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan teruji, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
