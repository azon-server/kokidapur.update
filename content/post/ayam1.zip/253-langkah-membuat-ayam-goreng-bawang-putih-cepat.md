---
description: "Langkah membuat Ayam goreng bawang putih Cepat"
title: "Langkah membuat Ayam goreng bawang putih Cepat"
slug: 253-langkah-membuat-ayam-goreng-bawang-putih-cepat
date: 2020-11-25T06:14:46.830Z
image: https://img-global.cpcdn.com/recipes/f19fae956aa1cdd2/751x532cq70/ayam-goreng-bawang-putih-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f19fae956aa1cdd2/751x532cq70/ayam-goreng-bawang-putih-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f19fae956aa1cdd2/751x532cq70/ayam-goreng-bawang-putih-foto-resep-utama.jpg
author: Charlie Garza
ratingvalue: 4.3
reviewcount: 6860
recipeingredient:
- "1/2 kg sayap ayam belah jadi 2 buang ujungnya"
- " Jeruk nipis"
- "1 bonggol bawang putih"
- " Bahan adonan"
- "3 bawang merah"
- "6 bawang putih"
- "Secukupnya garamgulamerica"
- "Secukupnya ketumbar halus"
- "Secukupnya kunyit halus"
- "1 ruas jahe"
- "3 sdm maizena"
- "1 butir telur"
recipeinstructions:
- "Bersihkan ayam, kasih jeruk nipis. Diamkan 15 menit. Bilas"
- "Campur bahan adonan, haluskan/blender. masukkan ayam yg sdh dibilas. Marinasi di kulkas minimal 30menit"
- "Kupas bonggol bawang putih (bonggolnya aja yg keras dibuang, kulitnya ngga usah dikupas), geprek, balut dg sedikit garam."
- "Panaskan minyak, goreng bawang putih dulu sampe kecoklatan, baru ayamnya bisa digoreng. Jadi minyaknya ada bau harum dari si bawang. Atau bisa di goreng barengan tp bawang putih jgn lupa diangkat dulu karena cepat gosong."
- "Pakai api kecil dari awal sampai akhir, karena ayam nggak diungkep, jadi biar dalemnya mateng. Bumbu marinasi jgn dibuang, pas goreng ayamnya tambahkan pakai sendok diatasnya nanti jadinya nempel2 gitu krispy tebel."
- "Pakai bawang cutting lebih rekomended lg buat yg suka bawang, soalnya aromanya bakal nendang drpd pakai bawang putih biasa."
categories:
- Recipe
tags:
- ayam
- goreng
- bawang

katakunci: ayam goreng bawang 
nutrition: 111 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam goreng bawang putih](https://img-global.cpcdn.com/recipes/f19fae956aa1cdd2/751x532cq70/ayam-goreng-bawang-putih-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam goreng bawang putih yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara

Keharmonisan keluarga dapat diperoleh dengan cara simple. Salah satunya adalah memasak Ayam goreng bawang putih untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang bisa anda buat salah satunya ayam goreng bawang putih yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep ayam goreng bawang putih tanpa harus bersusah payah.
Berikut ini resep Ayam goreng bawang putih yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 12 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam goreng bawang putih:

1. Dibutuhkan 1/2 kg sayap ayam, belah jadi 2, buang ujungnya
1. Harap siapkan  Jeruk nipis
1. Tambah 1 bonggol bawang putih
1. Tambah  Bahan adonan
1. Tambah 3 bawang merah
1. Harus ada 6 bawang putih
1. Dibutuhkan Secukupnya garam,gula,merica
1. Harap siapkan Secukupnya ketumbar halus
1. Tambah Secukupnya kunyit halus
1. Jangan lupa 1 ruas jahe
1. Tambah 3 sdm maizena
1. Siapkan 1 butir telur




<!--inarticleads2-->

##### Bagaimana membuat  Ayam goreng bawang putih:

1. Bersihkan ayam, kasih jeruk nipis. Diamkan 15 menit. Bilas
1. Campur bahan adonan, haluskan/blender. masukkan ayam yg sdh dibilas. Marinasi di kulkas minimal 30menit
1. Kupas bonggol bawang putih (bonggolnya aja yg keras dibuang, kulitnya ngga usah dikupas), geprek, balut dg sedikit garam.
1. Panaskan minyak, goreng bawang putih dulu sampe kecoklatan, baru ayamnya bisa digoreng. Jadi minyaknya ada bau harum dari si bawang. Atau bisa di goreng barengan tp bawang putih jgn lupa diangkat dulu karena cepat gosong.
1. Pakai api kecil dari awal sampai akhir, karena ayam nggak diungkep, jadi biar dalemnya mateng. Bumbu marinasi jgn dibuang, pas goreng ayamnya tambahkan pakai sendok diatasnya nanti jadinya nempel2 gitu krispy tebel.
1. Pakai bawang cutting lebih rekomended lg buat yg suka bawang, soalnya aromanya bakal nendang drpd pakai bawang putih biasa.




Demikianlah cara membuat ayam goreng bawang putih yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
