---
description: "Cara singkat untuk membuat Ayam rica kemangi Homemade"
title: "Cara singkat untuk membuat Ayam rica kemangi Homemade"
slug: 20-cara-singkat-untuk-membuat-ayam-rica-kemangi-homemade
date: 2021-01-13T08:22:59.938Z
image: https://img-global.cpcdn.com/recipes/23de41188d65059d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/23de41188d65059d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/23de41188d65059d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Sara Potter
ratingvalue: 4.9
reviewcount: 24092
recipeingredient:
- "5 potong ayam"
- "1 bh jeruk nipis"
- "1 bh tomat potong kecil"
- "1 ruas jahe digeprek"
- "1 ruas lengkuas digeprek"
- "1 bh sereh digeprek"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "3 ikat daun kemangi"
- "1 batang daun bawang"
- " Bumbu halus"
- "20 bh cabe merah keriting"
- "15 bh cabe rawit merah"
- "10 bh bawang merah"
- "5 bh bawang putih"
- "3 bh kemiri"
- "Sedikit kunyit"
- "Secukupnya garam gula"
recipeinstructions:
- "Cuci bersih ayam, lalu lumuri dengan perasan air jeruk nipis, diamkan sebentar.."
- "Goreng ayam setengah matang, sisihkan.."
- "Tumis bumbu halus hingga harum, lalu masukan daun salam, daun jeruk, jahe, lengkuas, sereh.. tumis lagi hingga matang.."
- "Tambahkan ayam dan sedikit air, aduk rata dengan api kecil hingga bumbu meresap"
- "Masukan gula, garam, daun kemangi, tomat, aduk rata.."
- "Cek rasa.. dan siap disajikan ☺️"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 103 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/23de41188d65059d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan empuk. Ciri kuliner Indonesia ayam rica kemangi yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. RESEP AYAM RICA RICA KEMANGI YANG SUPER ENAK hai assalammualikum teman teman. kali ini saya berbagi resep olahan ayam. bahan bahanya. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera.

Keharmonisan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam rica kemangi untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang bisa anda buat salah satunya ayam rica kemangi yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi:

1. Diperlukan 5 potong ayam
1. Dibutuhkan 1 bh jeruk nipis
1. Harus ada 1 bh tomat potong kecil
1. Dibutuhkan 1 ruas jahe digeprek
1. Harap siapkan 1 ruas lengkuas digeprek
1. Jangan lupa 1 bh sereh digeprek
1. Tambah 3 lembar daun salam
1. Siapkan 3 lembar daun jeruk
1. Dibutuhkan 3 ikat daun kemangi
1. Dibutuhkan 1 batang daun bawang
1. Jangan lupa  Bumbu halus::
1. Diperlukan 20 bh cabe merah keriting
1. Harus ada 15 bh cabe rawit merah
1. Tambah 10 bh bawang merah
1. Siapkan 5 bh bawang putih
1. Jangan lupa 3 bh kemiri
1. Dibutuhkan Sedikit kunyit
1. Diperlukan Secukupnya garam gula


Ayam rica-rica pedas kemangi adalah salah satunya. Rasanya yang pedas, manis dan gurih, membuatnya banyak di gemari banyak kalangan, dari anak-anak sampai orang tua. Cara Membuat Ayam Rica Rica Kemangi. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica kemangi:

1. Cuci bersih ayam, lalu lumuri dengan perasan air jeruk nipis, diamkan sebentar..
1. Goreng ayam setengah matang, sisihkan..
1. Tumis bumbu halus hingga harum, lalu masukan daun salam, daun jeruk, jahe, lengkuas, sereh.. tumis lagi hingga matang..
1. Tambahkan ayam dan sedikit air, aduk rata dengan api kecil hingga bumbu meresap
1. Masukan gula, garam, daun kemangi, tomat, aduk rata..
1. Cek rasa.. dan siap disajikan ☺️


Cara Membuat Ayam Rica Rica Kemangi. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. 

Demikianlah cara membuat ayam rica kemangi yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
