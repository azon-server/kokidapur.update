---
description: "Cara menyiapakan Ayam Rica Rica Kemangi Favorite"
title: "Cara menyiapakan Ayam Rica Rica Kemangi Favorite"
slug: 93-cara-menyiapakan-ayam-rica-rica-kemangi-favorite
date: 2020-11-26T18:52:13.593Z
image: https://img-global.cpcdn.com/recipes/5709beb1e5fe12a9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5709beb1e5fe12a9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5709beb1e5fe12a9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Ruth Lindsey
ratingvalue: 4.8
reviewcount: 29177
recipeingredient:
- "8 potong ayam"
- " Jeruk nipis"
- " Garam"
- " Gula"
- " Lada"
- " Kaldu jamur non msg"
- "2 Sereh geprek"
- "2 cm Laos geprek"
- "2 ikat Kemangi petiki"
- "4 bh Daun jeruk sobek"
- "2 lbr Daun salam"
- " Minyak goreng"
- " Air"
- " Bumbu halus "
- "5 siung Bawang merah"
- "3 siung bawang putih"
- "2 cm Kunyit"
- "2 cm jahe"
- "2 butir kemiri"
- "8 bh cabe merah keriting"
- "5 bh rawit merah"
recipeinstructions:
- "Cuci bersih ayam, marinasi dg air jeruk nipis. Bilas. Pisahkan."
- "Tumis bumbu halus dg minyak goreng bersama sereh, laos, daun jeruk, daun salam hingga wangi"
- "Setelah wangi, masukkan ayam. Aduk rata bolak balik. Biarkan meresap. Lalu tambahkan air secukupnya. Sy kira2 2 gelas air."
- "Tambahkan garam, gula, lada, kaldu jamur. Aduk rata. Biarkan kuah menyusut dan mengental. Pastikan ayam matang."
- "Sesaat sblm diangkat masukkan kemangi. Lalu matikan api. Siap dihidangkan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 291 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/5709beb1e5fe12a9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica rica kemangi yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa ciri khas yang merupakan keragaman Kita



Keharmonisan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica Rica Kemangi untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang dapat anda contoh salah satunya ayam rica rica kemangi yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 21 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Harap siapkan 8 potong ayam
1. Harap siapkan  Jeruk nipis
1. Harap siapkan  Garam
1. Jangan lupa  Gula
1. Diperlukan  Lada
1. Jangan lupa  Kaldu jamur non msg
1. Diperlukan 2 Sereh, geprek
1. Siapkan 2 cm Laos, geprek
1. Diperlukan 2 ikat Kemangi, petiki
1. Jangan lupa 4 bh Daun jeruk, sobek
1. Jangan lupa 2 lbr Daun salam
1. Diperlukan  Minyak goreng
1. Harus ada  Air
1. Dibutuhkan  Bumbu halus :
1. Dibutuhkan 5 siung Bawang merah
1. Harap siapkan 3 siung bawang putih
1. Harus ada 2 cm Kunyit
1. Siapkan 2 cm jahe
1. Harap siapkan 2 butir kemiri
1. Jangan lupa 8 bh cabe merah keriting
1. Diperlukan 5 bh rawit merah




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Rica Kemangi:

1. Cuci bersih ayam, marinasi dg air jeruk nipis. Bilas. Pisahkan.
1. Tumis bumbu halus dg minyak goreng bersama sereh, laos, daun jeruk, daun salam hingga wangi
1. Setelah wangi, masukkan ayam. Aduk rata bolak balik. Biarkan meresap. Lalu tambahkan air secukupnya. Sy kira2 2 gelas air.
1. Tambahkan garam, gula, lada, kaldu jamur. Aduk rata. Biarkan kuah menyusut dan mengental. Pastikan ayam matang.
1. Sesaat sblm diangkat masukkan kemangi. Lalu matikan api. Siap dihidangkan




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan cepat, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
