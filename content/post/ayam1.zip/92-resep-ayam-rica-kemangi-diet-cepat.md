---
description: "Resep : Ayam rica kemangi (diet) Cepat"
title: "Resep : Ayam rica kemangi (diet) Cepat"
slug: 92-resep-ayam-rica-kemangi-diet-cepat
date: 2020-09-30T16:50:29.253Z
image: https://img-global.cpcdn.com/recipes/59e83bd16ba6f69d/751x532cq70/ayam-rica-kemangi-diet-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/59e83bd16ba6f69d/751x532cq70/ayam-rica-kemangi-diet-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/59e83bd16ba6f69d/751x532cq70/ayam-rica-kemangi-diet-foto-resep-utama.jpg
author: Lora Rodgers
ratingvalue: 4
reviewcount: 27914
recipeingredient:
- "120 gr Dada ayam tanpa kulit"
- "1 daun jeruk"
- "1 daun salam"
- "1 cm jahe"
- "1 cm lengkuas"
- "1/2 batang sereh"
- " garam  kaldu jamur"
- " gula diabetamil"
- "secukupnya kemangi"
- "1/4 buah tomat"
- " bumbu halus "
- "2 bawang merah"
- "1 bawang putih"
- "1/2 butir kemiri"
- "4 cabe merah keriting"
- "5 cabe rawit"
- "2 cm kunyit"
recipeinstructions:
- "Potong ayam sesuai selera prefer kecil&#34; biar cepet mateng"
- "Blender atau ulek bumbu halus kemudian tumis dengan air kurang lebih 100 -150 ml"
- "Kemudian masukkan sereh, daun salam, jahe, daun jeruk, dan lengkuas"
- "Tunggu hingga menyusut sedikit airnya dan masukkan ayam yg sudah di potong&#34;"
- "Setelah ayam sudah mulai putih / pucat tambahkan garam, gula diet dan totole aduk hingga matang"
- "Kemudian tambahkan tomat dan daun kemangi"
- "Ayam siap dihidangkan"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 129 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica kemangi (diet)](https://img-global.cpcdn.com/recipes/59e83bd16ba6f69d/751x532cq70/ayam-rica-kemangi-diet-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan enak. Karasteristik masakan Indonesia ayam rica kemangi (diet) yang penuh dengan rempah memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Keharmonisan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam rica kemangi (diet) untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang dapat anda coba salah satunya ayam rica kemangi (diet) yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep ayam rica kemangi (diet) tanpa harus bersusah payah.
Berikut ini resep Ayam rica kemangi (diet) yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica kemangi (diet):

1. Diperlukan 120 gr Dada ayam tanpa kulit
1. Harus ada 1 daun jeruk
1. Tambah 1 daun salam
1. Tambah 1 cm jahe
1. Jangan lupa 1 cm lengkuas
1. Jangan lupa 1/2 batang sereh
1. Dibutuhkan  garam / kaldu jamur
1. Diperlukan  gula diabetamil
1. Dibutuhkan secukupnya kemangi
1. Siapkan 1/4 buah tomat
1. Dibutuhkan  bumbu halus :
1. Diperlukan 2 bawang merah
1. Diperlukan 1 bawang putih
1. Dibutuhkan 1/2 butir kemiri
1. Jangan lupa 4 cabe merah keriting
1. Dibutuhkan 5 cabe rawit
1. Dibutuhkan 2 cm kunyit




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica kemangi (diet):

1. Potong ayam sesuai selera prefer kecil&#34; biar cepet mateng
1. Blender atau ulek bumbu halus kemudian tumis dengan air kurang lebih 100 -150 ml
1. Kemudian masukkan sereh, daun salam, jahe, daun jeruk, dan lengkuas
1. Tunggu hingga menyusut sedikit airnya dan masukkan ayam yg sudah di potong&#34;
1. Setelah ayam sudah mulai putih / pucat tambahkan garam, gula diet dan totole aduk hingga matang
1. Kemudian tambahkan tomat dan daun kemangi
1. Ayam siap dihidangkan
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam rica kemangi (diet)">



Demikianlah cara membuat ayam rica kemangi (diet) yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan teruji, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
