---
description: "Step-by-Step menyiapakan Ayam Rica Rica teraktual"
title: "Step-by-Step menyiapakan Ayam Rica Rica teraktual"
slug: 205-step-by-step-menyiapakan-ayam-rica-rica-teraktual
date: 2020-09-23T09:16:15.414Z
image: https://img-global.cpcdn.com/recipes/22e4712ecdb00406/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/22e4712ecdb00406/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/22e4712ecdb00406/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Georgie Moore
ratingvalue: 4.8
reviewcount: 39998
recipeingredient:
- "1/2 kg ayampotong"
- "5 lmbr daun jeruk"
- "4 siung bawang merahiris"
- "1 lmbr daun pandan"
- "1/2 bh jeruk nipisperas airnya"
- "300 ml air"
- "segenggam daun kemangi"
- "secukupnya garam"
- "secukupnya minyak goreng"
- " Bumbu ulek kasar "
- "20 bh cabe merah keriting"
- "10 bh cabe rawit"
- "7 siung bawang merah"
- "2 cm jahe"
- "2 btng seraiputihnya sajairis dulu"
recipeinstructions:
- "Cuci bersih ayam,lumuri garam/air jeruk nipis,diamkan 10 menit,bilas kembali. Panaskan minyak goreng,lalu goreng ayam setengah matang saja. Angkat &amp; tiriskan minyaknya."
- "Panaskan kembali minyak (bekas menggoreng ayam),tumis bumbu ulek sampai matang &amp; harum. Tambahkan irisan bawang merah,daun pandan &amp; daun jeruk,aduk² sampai layu."
- "Masukkan ayam,aduk rata. Tuang air,bumbui garam &amp; beri perasan air jeruk nipis. Masak sampai kuahnya menyusut,jgn lupa koreksi rasanya. Terakhir masukkan daun kemangi,aduk rata,masak sebentar saja."
- "Angkat &amp; siap disajikan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 276 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/22e4712ecdb00406/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan enak. Karasteristik kuliner Indonesia ayam rica rica yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Ayam Rica Rica untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang dapat anda contoh salah satunya ayam rica rica yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica:

1. Harap siapkan 1/2 kg ayam,potong²
1. Harus ada 5 lmbr daun jeruk
1. Jangan lupa 4 siung bawang merah,iris
1. Tambah 1 lmbr daun pandan
1. Dibutuhkan 1/2 bh jeruk nipis,peras airnya
1. Diperlukan 300 ml air
1. Harap siapkan segenggam daun kemangi
1. Tambah secukupnya garam
1. Tambah secukupnya minyak goreng
1. Tambah  Bumbu ulek kasar :
1. Jangan lupa 20 bh cabe merah keriting
1. Siapkan 10 bh cabe rawit
1. Diperlukan 7 siung bawang merah
1. Diperlukan 2 cm jahe
1. Jangan lupa 2 btng serai,putihnya saja,iris dulu




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica:

1. Cuci bersih ayam,lumuri garam/air jeruk nipis,diamkan 10 menit,bilas kembali. Panaskan minyak goreng,lalu goreng ayam setengah matang saja. Angkat &amp; tiriskan minyaknya.
1. Panaskan kembali minyak (bekas menggoreng ayam),tumis bumbu ulek sampai matang &amp; harum. Tambahkan irisan bawang merah,daun pandan &amp; daun jeruk,aduk² sampai layu.
1. Masukkan ayam,aduk rata. Tuang air,bumbui garam &amp; beri perasan air jeruk nipis. Masak sampai kuahnya menyusut,jgn lupa koreksi rasanya. Terakhir masukkan daun kemangi,aduk rata,masak sebentar saja.
1. Angkat &amp; siap disajikan.




Demikianlah cara membuat ayam rica rica yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat simple dan cepat, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
