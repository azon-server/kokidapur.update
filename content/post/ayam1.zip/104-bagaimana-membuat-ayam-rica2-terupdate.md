---
description: "Bagaimana membuat Ayam rica2 terupdate"
title: "Bagaimana membuat Ayam rica2 terupdate"
slug: 104-bagaimana-membuat-ayam-rica2-terupdate
date: 2020-10-15T16:36:33.370Z
image: https://img-global.cpcdn.com/recipes/f9c281a879b2d800/751x532cq70/ayam-rica2-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f9c281a879b2d800/751x532cq70/ayam-rica2-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f9c281a879b2d800/751x532cq70/ayam-rica2-foto-resep-utama.jpg
author: Ella Silva
ratingvalue: 4.9
reviewcount: 9883
recipeingredient:
- "1 kg ayam"
- "10 buah cabe merah"
- "5 cabe rawitsesuai selera"
- "5 siung bawang merah"
- "4 siung bawang putih"
- "sedikit Kunir"
- "sedikit Jahe"
- "1 buah Tomat"
- " Sereh dan daun salam"
- " Kecap secukup nya"
- " Air secukup nya"
- "secukupnya Minyak"
- " Garam"
- " Gula"
- " Penyedap rasa"
- " Kecap"
recipeinstructions:
- "Cuci ayam smpai bersih,rebus smpai setengah matang"
- "Haluskan cabe,barmer,bawang putih,tomat,jahe,kunir,rawit"
- "Tumis bumbu halus sampai harum,kemudian masukan air"
- "Masukan ayam yg sudah di rebus,trus smpe air nya meresap ya bund.."
- "Klo air nya uda mulai ngentel,masukin garem,penyedap rasa,gula,kecap,cek rasa."
- "Klo air nya udh mulai asat kasih sereh sma salam nya,tpi jgn smpe asat bgt ya bund.."
- "Selamat mencoba.."
categories:
- Recipe
tags:
- ayam
- rica2

katakunci: ayam rica2 
nutrition: 178 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam rica2](https://img-global.cpcdn.com/recipes/f9c281a879b2d800/751x532cq70/ayam-rica2-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas dan gurih. Ciri khas makanan Nusantara ayam rica2 yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica. Resep ayam rica rica merupakan masakan selera pedas dari daerah manado. Kita masak Ayam Rica-Rica aja yuk.

Kedekatan rumah tangga dapat ditemukan dengan cara mudah. Salah satunya adalah memasak Ayam rica2 untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang dapat anda contoh salah satunya ayam rica2 yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep ayam rica2 tanpa harus bersusah payah.
Seperti resep Ayam rica2 yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica2:

1. Harus ada 1 kg ayam
1. Tambah 10 buah cabe merah
1. Diperlukan 5 cabe rawit(sesuai selera)
1. Jangan lupa 5 siung bawang merah
1. Harap siapkan 4 siung bawang putih
1. Dibutuhkan sedikit Kunir
1. Siapkan sedikit Jahe
1. Dibutuhkan 1 buah Tomat
1. Harus ada  Sereh dan daun salam
1. Jangan lupa  Kecap secukup nya
1. Harap siapkan  Air secukup nya
1. Dibutuhkan secukupnya Minyak
1. Dibutuhkan  Garam
1. Jangan lupa  Gula
1. Diperlukan  Penyedap rasa
1. Diperlukan  Kecap


Tak hanya ayam, anda juga bisa memasak. Satu di antaranya adalah menu rica-rica ayam. Rica-rica merupakan olahan khas Manado yang memiliki rasa pedas dan gurih. Rica-rica (or sometimes simply called rica) is a type of Southeast Asian hot and spicy bumbu (spice mixture) found in Manado cuisine of North Sulawesi, Indonesia. 

<!--inarticleads2-->

##### Instruksi membuat  Ayam rica2:

1. Cuci ayam smpai bersih,rebus smpai setengah matang
1. Haluskan cabe,barmer,bawang putih,tomat,jahe,kunir,rawit
1. Tumis bumbu halus sampai harum,kemudian masukan air
1. Masukan ayam yg sudah di rebus,trus smpe air nya meresap ya bund..
1. Klo air nya uda mulai ngentel,masukin garem,penyedap rasa,gula,kecap,cek rasa.
1. Klo air nya udh mulai asat kasih sereh sma salam nya,tpi jgn smpe asat bgt ya bund..
1. Selamat mencoba..


Rica-rica merupakan olahan khas Manado yang memiliki rasa pedas dan gurih. Rica-rica (or sometimes simply called rica) is a type of Southeast Asian hot and spicy bumbu (spice mixture) found in Manado cuisine of North Sulawesi, Indonesia. Rica-rica uses much chopped or ground red and green chili peppers, bird&#39;s eye chili, shallots, garlic, ginger, and a pinch of salt and sugar. Bumbu rica-rica khas Manado bisa dipadukan dengan aneka bahan, seperti ayam. Ayam rica-rica adalah salah satu makanan pedas dari kota Manado, ibukota provinsi Sulawesi Utara. 

Demikianlah cara membuat ayam rica2 yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
