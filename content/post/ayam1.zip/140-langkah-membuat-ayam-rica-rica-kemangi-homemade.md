---
description: "Langkah membuat Ayam Rica  Rica Kemangi Homemade"
title: "Langkah membuat Ayam Rica  Rica Kemangi Homemade"
slug: 140-langkah-membuat-ayam-rica-rica-kemangi-homemade
date: 2020-11-11T17:40:43.105Z
image: https://img-global.cpcdn.com/recipes/58f9de339fbdc915/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/58f9de339fbdc915/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/58f9de339fbdc915/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Lillian Simpson
ratingvalue: 4
reviewcount: 22996
recipeingredient:
- "4 potong ayam ukuran besar"
- " Air perasan lemonjeruk nipis"
- "2 ikat kemangi"
- " Bumbu halus"
- "6 siung bawang merah"
- "2 siung bawang putih"
- "10 buah cabai keriting"
- "3 buah cabai rawit sesuai selera"
- "2 butir kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
- " Bumbu tambahan"
- "1 batang serai di geprek"
- "1 ruas lengkuas di geprek"
- "4 lembar daun jeruk"
- "Sedikit gula merah"
- " Garam"
- " Kaldu bubuk"
- "1 batang Daun bawang"
recipeinstructions:
- "Balurkan ayam dengan air perasan lemon/jeruk nipis"
- "Goreng bawang merah, bawang putih dan cabai hingga layu. Lalu haluskan bersama bumbu halus lainnya"
- "Tumis bumbu halus hingga wangi, tambahkan gula merah secukupnya, masukkan serai, lengkuas dan daun jeruk."
- "Masukkan ayam. Tumis hingga berubah warna"
- "Tambahkan air secukupnya. Lalu biarkan masak hingga matang"
- "Lalu masukkan kemangi dan daun bawang. Masak hingga sayuran layu"
- "Jadi deh!!!"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 262 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica  Rica Kemangi](https://img-global.cpcdn.com/recipes/58f9de339fbdc915/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica  rica kemangi yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Indonesia

Kedekatan rumah tangga dapat didapat dengan cara mudah. Salah satunya adalah memasak Ayam Rica  Rica Kemangi untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang bisa anda coba salah satunya ayam rica  rica kemangi yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica  rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica  Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica  Rica Kemangi:

1. Harus ada 4 potong ayam ukuran besar
1. Jangan lupa  Air perasan lemon/jeruk nipis
1. Harap siapkan 2 ikat kemangi
1. Harus ada  Bumbu halus
1. Diperlukan 6 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Harap siapkan 10 buah cabai keriting
1. Harap siapkan 3 buah cabai rawit (sesuai selera)
1. Siapkan 2 butir kemiri
1. Tambah 1 ruas jahe
1. Dibutuhkan 1 ruas kunyit
1. Harus ada  Bumbu tambahan
1. Diperlukan 1 batang serai di geprek
1. Harap siapkan 1 ruas lengkuas di geprek
1. Diperlukan 4 lembar daun jeruk
1. Harap siapkan Sedikit gula merah
1. Jangan lupa  Garam
1. Harus ada  Kaldu bubuk
1. Tambah 1 batang Daun bawang




<!--inarticleads2-->

##### Cara membuat  Ayam Rica  Rica Kemangi:

1. Balurkan ayam dengan air perasan lemon/jeruk nipis
1. Goreng bawang merah, bawang putih dan cabai hingga layu. Lalu haluskan bersama bumbu halus lainnya
1. Tumis bumbu halus hingga wangi, tambahkan gula merah secukupnya, masukkan serai, lengkuas dan daun jeruk.
1. Masukkan ayam. Tumis hingga berubah warna
1. Tambahkan air secukupnya. Lalu biarkan masak hingga matang
1. Lalu masukkan kemangi dan daun bawang. Masak hingga sayuran layu
1. Jadi deh!!!




Demikianlah cara membuat ayam rica  rica kemangi yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan terbukti, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
