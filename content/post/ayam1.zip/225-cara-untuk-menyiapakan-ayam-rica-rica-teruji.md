---
description: "Cara untuk menyiapakan Ayam Rica- Rica Teruji"
title: "Cara untuk menyiapakan Ayam Rica- Rica Teruji"
slug: 225-cara-untuk-menyiapakan-ayam-rica-rica-teruji
date: 2020-12-31T16:21:18.170Z
image: https://img-global.cpcdn.com/recipes/61b2712829cafe6f/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/61b2712829cafe6f/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/61b2712829cafe6f/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Gregory Rhodes
ratingvalue: 4.6
reviewcount: 30028
recipeingredient:
- "1/2 ekor ayam"
- "1 buah tomat potong kecil"
- "1/2 siung bawang bombay rajang"
- "2 siung bawang putih rajang"
- "1 batang daun bawang iris tipis"
- "20 buah cabai rawit merah iris tipis"
- "2 sdm saos sambal"
- "2 sdm saos tomat"
- "2 sdm saos tiram"
- "2 sdm kecap manis"
- "1/2 sdt ketumbar"
- "1/2 sdt garam"
- "1/2 sdt gula"
- "1 buah jeruk nipis"
- " minyak untuk menggoreng"
- "50 ml air"
- " Bumbu marinasi"
- "2 sdm kecap manis"
- "1 sdt kaldu bubuk"
- "1 sdt merica"
recipeinstructions:
- "Potong ayam kecil2, cuci bersih lumuri dengan jeruk nipis, rendam selama 5-10 menit, cuci kembali, masukkan bumbu marinasi simpan selama 30 menit."
- "Goreng matang ayam, sisihkan"
- "Tumis bawang bombay, bawang putih, daun bawang, tomat dan cabai hingga setengah matang lalu masukkan saos tiram, saos sambal, saos tomat, kecap manis, ketumbar, gula dan garam, aduk rata."
- "Masukkan ayam, tambahkan air, masak hingga bumbu meresap dengan kekentalan yang diinginkan, cek rasa, angkat dan sajikan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 257 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica- Rica](https://img-global.cpcdn.com/recipes/61b2712829cafe6f/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis dan empuk. Karasteristik makanan Indonesia ayam rica- rica yang penuh dengan rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kehangatan keluarga bisa ditemukan dengan cara simple. Diantaranya adalah memasak Ayam Rica- Rica untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda coba salah satunya ayam rica- rica yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica- rica tanpa harus bersusah payah.
Seperti resep Ayam Rica- Rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica- Rica:

1. Siapkan 1/2 ekor ayam
1. Jangan lupa 1 buah tomat, potong kecil
1. Tambah 1/2 siung bawang bombay, rajang
1. Tambah 2 siung bawang putih rajang
1. Jangan lupa 1 batang daun bawang, iris tipis
1. Harus ada 20 buah cabai rawit merah, iris tipis
1. Harus ada 2 sdm saos sambal
1. Dibutuhkan 2 sdm saos tomat
1. Harap siapkan 2 sdm saos tiram
1. Dibutuhkan 2 sdm kecap manis
1. Jangan lupa 1/2 sdt ketumbar
1. Tambah 1/2 sdt garam
1. Dibutuhkan 1/2 sdt gula
1. Diperlukan 1 buah jeruk nipis
1. Siapkan  minyak untuk menggoreng
1. Siapkan 50 ml air
1. Harus ada  Bumbu marinasi
1. Tambah 2 sdm kecap manis
1. Tambah 1 sdt kaldu bubuk
1. Dibutuhkan 1 sdt merica




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica- Rica:

1. Potong ayam kecil2, cuci bersih lumuri dengan jeruk nipis, rendam selama 5-10 menit, cuci kembali, masukkan bumbu marinasi simpan selama 30 menit.
1. Goreng matang ayam, sisihkan
1. Tumis bawang bombay, bawang putih, daun bawang, tomat dan cabai hingga setengah matang lalu masukkan saos tiram, saos sambal, saos tomat, kecap manis, ketumbar, gula dan garam, aduk rata.
1. Masukkan ayam, tambahkan air, masak hingga bumbu meresap dengan kekentalan yang diinginkan, cek rasa, angkat dan sajikan.




Demikianlah cara membuat ayam rica- rica yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan terbukti, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
