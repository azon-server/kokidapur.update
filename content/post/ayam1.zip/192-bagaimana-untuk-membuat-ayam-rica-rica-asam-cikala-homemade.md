---
description: "Bagaimana untuk membuat Ayam rica-rica asam cikala Homemade"
title: "Bagaimana untuk membuat Ayam rica-rica asam cikala Homemade"
slug: 192-bagaimana-untuk-membuat-ayam-rica-rica-asam-cikala-homemade
date: 2020-12-15T02:09:26.849Z
image: https://img-global.cpcdn.com/recipes/5a0899cebb077a86/751x532cq70/ayam-rica-rica-asam-cikala-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5a0899cebb077a86/751x532cq70/ayam-rica-rica-asam-cikala-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5a0899cebb077a86/751x532cq70/ayam-rica-rica-asam-cikala-foto-resep-utama.jpg
author: Alfred Houston
ratingvalue: 4.5
reviewcount: 34170
recipeingredient:
- "1 ekor ayam kampung potong2 menjadi 6 bagian"
- "3 ikat daun kemangi ambil daunnya dan buang batangnya"
- "2 lembar daun salam"
- "4 lembar daun jeruk"
- "1 batang serai geprek"
- "3 batang daun bawangpre irisiris"
- "6 buah asam cikala jika tidak suka masam bisa dikurangi"
- " jeruk nipiscuka untuk mencuci ayam"
- "secukupnya air matang"
- "secukupnya garam"
- "secukupnya kaldu ayamsapijamur"
- "secukupnya gula"
- " bahan halus"
- "12 buah bawang merah"
- "6 buah bawang putih"
- "10 buah cabe merah keriting"
- "10 buah cabe rawit caplak"
- "1/2 butir kemiri"
- "1 ruas kunyit"
- "1 ruas lengkuas"
- "1 ruas jahe"
recipeinstructions:
- "Cuci semua bahan, jangan lupa cuci ayam dan baluri air jeruk/cuka lalu cuci dengan bersih lalu rebus ayam sebentar dan tiriskan"
- "Tumis bumbu halus, masukan serai daun salam daun jeruk dan asam cikala ke dalam wajan. aduk rata dan tumis sampai 1/2 matang"
- "Jika bumbu sudah 1/2 matang masukkan ayam, aduk2 sampai bumbu merata dan tambahkan air matang sambil menambahkan gula garam dan kaldu ayam/sapi/jamur. aduk rata semuanya, biarkan sampai mendidih"
- "Jika sudah mendidih dan meresap, masukkan daun bawang tunggu sampai matang sambil aduk masakan jika sudah mau sat kuahnya masukkan daun kemangi aduk hingga merata dan angkat 😊 selamat mencoba moms ❤️"
categories:
- Recipe
tags:
- ayam
- ricarica
- asam

katakunci: ayam ricarica asam 
nutrition: 292 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam rica-rica asam cikala](https://img-global.cpcdn.com/recipes/5a0899cebb077a86/751x532cq70/ayam-rica-rica-asam-cikala-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang setidaknya kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica-rica asam cikala yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Kita

Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica. Rasa pedas, gurih dan empuk daging ayamnya terbukti sangat cocok disajikan bersama nasi dalam. Resep rica rica sendiri sebenarnya tidak harus menggunakan bahan daging ayam saja.

Keharmonisan rumah tangga dapat diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Ayam rica-rica asam cikala untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang dapat anda contoh salah satunya ayam rica-rica asam cikala yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica-rica asam cikala tanpa harus bersusah payah.
Seperti resep Ayam rica-rica asam cikala yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica asam cikala:

1. Jangan lupa 1 ekor ayam kampung (potong2 menjadi 6 bagian)
1. Siapkan 3 ikat daun kemangi (ambil daunnya dan buang batangnya)
1. Harap siapkan 2 lembar daun salam
1. Diperlukan 4 lembar daun jeruk
1. Jangan lupa 1 batang serai (geprek)
1. Siapkan 3 batang daun bawang/pre (iris-iris)
1. Siapkan 6 buah asam cikala (jika tidak suka masam bisa dikurangi)
1. Harus ada  jeruk nipis/cuka (untuk mencuci ayam)
1. Harap siapkan secukupnya air matang
1. Dibutuhkan secukupnya garam
1. Harus ada secukupnya kaldu ayam/sapi/jamur
1. Harus ada secukupnya gula
1. Tambah  bahan halus
1. Harap siapkan 12 buah bawang merah
1. Harap siapkan 6 buah bawang putih
1. Harap siapkan 10 buah cabe merah keriting
1. Harus ada 10 buah cabe rawit caplak
1. Harus ada 1/2 butir kemiri
1. Harus ada 1 ruas kunyit
1. Harap siapkan 1 ruas lengkuas
1. Siapkan 1 ruas jahe


Cara memasak ayam rica-rica tidaklah susah. [RESEP ANDALAN] GURAMI ASAM MANIS ala LC. Ayam rica-rica (Indonesian for chicken rica-rica) is an Indonesian hot and spicy chicken dish. It is made up of chicken that cooked in spicy red and green chili pepper. The origin of this dish is from Minahasan cuisine of North Sulawesi. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica-rica asam cikala:

1. Cuci semua bahan, jangan lupa cuci ayam dan baluri air jeruk/cuka lalu cuci dengan bersih lalu rebus ayam sebentar dan tiriskan
1. Tumis bumbu halus, masukan serai daun salam daun jeruk dan asam cikala ke dalam wajan. aduk rata dan tumis sampai 1/2 matang
1. Jika bumbu sudah 1/2 matang masukkan ayam, aduk2 sampai bumbu merata dan tambahkan air matang sambil menambahkan gula garam dan kaldu ayam/sapi/jamur. aduk rata semuanya, biarkan sampai mendidih
1. Jika sudah mendidih dan meresap, masukkan daun bawang tunggu sampai matang sambil aduk masakan jika sudah mau sat kuahnya masukkan daun kemangi aduk hingga merata dan angkat 😊 selamat mencoba moms ❤️


It is made up of chicken that cooked in spicy red and green chili pepper. The origin of this dish is from Minahasan cuisine of North Sulawesi. Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Dengan aroma yang menggoda dibumbui dengan. 

Demikianlah cara membuat ayam rica-rica asam cikala yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan cepat, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
