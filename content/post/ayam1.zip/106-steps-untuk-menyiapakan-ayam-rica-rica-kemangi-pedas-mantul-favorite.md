---
description: "Steps untuk menyiapakan Ayam Rica - Rica Kemangi Pedas Mantul Favorite"
title: "Steps untuk menyiapakan Ayam Rica - Rica Kemangi Pedas Mantul Favorite"
slug: 106-steps-untuk-menyiapakan-ayam-rica-rica-kemangi-pedas-mantul-favorite
date: 2020-10-20T19:01:36.140Z
image: https://img-global.cpcdn.com/recipes/d15711c86b6dfa3f/751x532cq70/ayam-rica-rica-kemangi-pedas-mantul-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d15711c86b6dfa3f/751x532cq70/ayam-rica-rica-kemangi-pedas-mantul-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d15711c86b6dfa3f/751x532cq70/ayam-rica-rica-kemangi-pedas-mantul-foto-resep-utama.jpg
author: Garrett Hogan
ratingvalue: 4.7
reviewcount: 21591
recipeingredient:
- "1/2 kg Ayam potong dada dan sayap sesuai selera"
- "1/2 potong jeruk limau"
- " Bumbu Halus"
- "3 buah bawang putih"
- "4 buah bawang merah"
- "5 buah cabe merah besar"
- "10 cabe rawit sesuai selera"
- "1/2 cm Jahe"
- "Sedikit kunyit"
- "3 buah kemiri"
- " Bahan cemplung"
- "secukupnya Garam"
- "secukupnya Gula"
- " Merica secukupny"
- " penyedap rasa"
- "4 lembar daun jeruk"
- "2 daun sereh geprek"
- "1/2 ruas lengkuas"
- "2 lembar daun salam"
- "4 buah cabe hijau boleh skip"
- "1 ikat daun kemangi"
- "1 buah daun bawang"
- " Air matang"
recipeinstructions:
- "Cuci bersih ayam, kemudian lumuri ayam dgn jeruk limau, beri penyedap rasa, garam, ketumbar (bubuk) dan merica (bubuk) untuk marinasi yang simpel. Diamkan dikulkas 5-10 menit. Kemudian goreng setengah matang."
- "Potong- potong bumbu halus untuk di blender/diulek sesuai selera. Kemudian tambahkan minyak, tumis bumbu hingga wangi, masukkan bumbu cemplung tadi aduk rata."
- "Kemudian masukkan ayam potong, aduk sebentar, tambahkan air secukupnya. Setelah itu tambahkan garam, gula, penyedap rasa, dan merica."
- "Tutup sebentar biarkan meresap. Masukkan daun bawang, cabe hijau, cabe rawit utuh dan kemangi aduk rata, kemudian biarkan hingga meresap dan matang."
- "Koreksi rasa, siapkan mangkok ukuran sedang kemudian sajikan 😍. siap untuk dinikmati"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 294 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica - Rica Kemangi Pedas Mantul](https://img-global.cpcdn.com/recipes/d15711c86b6dfa3f/751x532cq70/ayam-rica-rica-kemangi-pedas-mantul-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica - rica kemangi pedas mantul yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa kesan tersendiri yang merupakan keragaman Indonesia



Kedekatan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Rica - Rica Kemangi Pedas Mantul untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang bisa anda buat salah satunya ayam rica - rica kemangi pedas mantul yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep ayam rica - rica kemangi pedas mantul tanpa harus bersusah payah.
Berikut ini resep Ayam Rica - Rica Kemangi Pedas Mantul yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 23 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica - Rica Kemangi Pedas Mantul:

1. Diperlukan 1/2 kg Ayam potong (dada dan sayap) sesuai selera
1. Jangan lupa 1/2 potong jeruk limau
1. Harus ada  Bumbu Halus
1. Dibutuhkan 3 buah bawang putih
1. Jangan lupa 4 buah bawang merah
1. Harap siapkan 5 buah cabe merah besar
1. Siapkan 10 cabe rawit (sesuai selera)
1. Tambah 1/2 cm Jahe
1. Tambah Sedikit kunyit
1. Harap siapkan 3 buah kemiri
1. Siapkan  Bahan cemplung
1. Diperlukan secukupnya Garam
1. Harus ada secukupnya Gula
1. Siapkan  Merica secukupny
1. Harus ada  penyedap rasa
1. Dibutuhkan 4 lembar daun jeruk
1. Diperlukan 2 daun sereh geprek
1. Jangan lupa 1/2 ruas lengkuas
1. Harap siapkan 2 lembar daun salam
1. Diperlukan 4 buah cabe hijau (boleh skip)
1. Diperlukan 1 ikat daun kemangi
1. Siapkan 1 buah daun bawang
1. Harus ada  Air matang




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica - Rica Kemangi Pedas Mantul:

1. Cuci bersih ayam, kemudian lumuri ayam dgn jeruk limau, beri penyedap rasa, garam, ketumbar (bubuk) dan merica (bubuk) untuk marinasi yang simpel. Diamkan dikulkas 5-10 menit. Kemudian goreng setengah matang.
1. Potong- potong bumbu halus untuk di blender/diulek sesuai selera. Kemudian tambahkan minyak, tumis bumbu hingga wangi, masukkan bumbu cemplung tadi aduk rata.
1. Kemudian masukkan ayam potong, aduk sebentar, tambahkan air secukupnya. Setelah itu tambahkan garam, gula, penyedap rasa, dan merica.
1. Tutup sebentar biarkan meresap. Masukkan daun bawang, cabe hijau, cabe rawit utuh dan kemangi aduk rata, kemudian biarkan hingga meresap dan matang.
1. Koreksi rasa, siapkan mangkok ukuran sedang kemudian sajikan 😍. siap untuk dinikmati




Demikianlah cara membuat ayam rica - rica kemangi pedas mantul yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
