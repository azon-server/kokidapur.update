---
description: "Cara menyiapakan Ayam Goreng Ungkep teraktual"
title: "Cara menyiapakan Ayam Goreng Ungkep teraktual"
slug: 309-cara-menyiapakan-ayam-goreng-ungkep-teraktual
date: 2020-11-21T20:42:23.261Z
image: https://img-global.cpcdn.com/recipes/884433e6deae8484/751x532cq70/ayam-goreng-ungkep-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/884433e6deae8484/751x532cq70/ayam-goreng-ungkep-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/884433e6deae8484/751x532cq70/ayam-goreng-ungkep-foto-resep-utama.jpg
author: Myrtie Ingram
ratingvalue: 4.8
reviewcount: 6525
recipeingredient:
- "1/2 kg ayam potong sesuai selera cuci bersih"
- "1 batang sereh geprek"
- "3 lembar daun jeruk"
- "secukupnya Air"
- " Bumbu halus"
- "5 siung bawang merah"
- "4 siung bawang putih"
- "2 ruas jari kunyit"
- "1 ruas jari lengkuas"
- "secukupnya Ketumbar"
- "3 butir kemiri utuh"
- " Garam secukupnya me  34 sdt"
- " Penyedap secukupnya jika tidak suka boleh diskip"
recipeinstructions:
- "Haluskan semua bumbu halus. Bisa diblender/diulek."
- "Dalam wajan, masukkan bumbu halus. Tambahkan air (dikira-kira saja sampai semua ayam terendam). Nyalakan api kompor."
- "Masukkan sereh, daun jeruk, garam dan penyedap aduk rata. Icipi rasanya jika sudah pas masukkan ayamnya."
- "Ungkep (diamkan) hingga bumbu meresap dan sesekali balik ayamnya agar bumbu tercampur merata."
- "Setelah airnya mulai berkurang, aduk-aduk biar ayam tidak gosong."
- "Ketika airnya sudah menyusut &amp; ayamnya sudah matang. Matikan kompornya."
- "Ayam Ungkep siap digoreng. Goreng ayam dalam minyak panas hingga matang."
- "Ayam Goreng Ungkep siap dinikmati bersama nasi hangat. Bisa dihidangkan juga bersama sambal &amp; lalapan pasti lebih mantul. 🙂"
- "Jika ingin dibuat stock dimasak besok. Masukkan ayam ungkep ke dalam tepak/box. Tunggu sampai dingin ya... baru tepaknya ditutup dan masukkan di freezer kulkas. 🙂 Jika mau menggoreng tinggal keluarkan dari freezer, tunggu sampai tidak beku dan siap digoreng. Selamat mencoba. 🙂"
categories:
- Recipe
tags:
- ayam
- goreng
- ungkep

katakunci: ayam goreng ungkep 
nutrition: 194 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Goreng Ungkep](https://img-global.cpcdn.com/recipes/884433e6deae8484/751x532cq70/ayam-goreng-ungkep-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga renyah. Karasteristik kuliner Indonesia ayam goreng ungkep yang kaya dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga bisa diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Ayam Goreng Ungkep untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang bisa anda coba salah satunya ayam goreng ungkep yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep ayam goreng ungkep tanpa harus bersusah payah.
Berikut ini resep Ayam Goreng Ungkep yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Ungkep:

1. Siapkan 1/2 kg ayam, potong sesuai selera, cuci bersih
1. Jangan lupa 1 batang sereh, geprek
1. Harap siapkan 3 lembar daun jeruk
1. Dibutuhkan secukupnya Air
1. Harap siapkan  🔻Bumbu halus🔻
1. Harus ada 5 siung bawang merah
1. Diperlukan 4 siung bawang putih
1. Siapkan 2 ruas jari kunyit
1. Dibutuhkan 1 ruas jari lengkuas
1. Dibutuhkan secukupnya Ketumbar
1. Dibutuhkan 3 butir kemiri utuh
1. Tambah  Garam secukupnya (me : 3/4 sdt)
1. Harap siapkan  Penyedap secukupnya, jika tidak suka boleh diskip




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Ungkep:

1. Haluskan semua bumbu halus. Bisa diblender/diulek.
1. Dalam wajan, masukkan bumbu halus. Tambahkan air (dikira-kira saja sampai semua ayam terendam). Nyalakan api kompor.
1. Masukkan sereh, daun jeruk, garam dan penyedap aduk rata. Icipi rasanya jika sudah pas masukkan ayamnya.
1. Ungkep (diamkan) hingga bumbu meresap dan sesekali balik ayamnya agar bumbu tercampur merata.
1. Setelah airnya mulai berkurang, aduk-aduk biar ayam tidak gosong.
1. Ketika airnya sudah menyusut &amp; ayamnya sudah matang. Matikan kompornya.
1. Ayam Ungkep siap digoreng. Goreng ayam dalam minyak panas hingga matang.
1. Ayam Goreng Ungkep siap dinikmati bersama nasi hangat. Bisa dihidangkan juga bersama sambal &amp; lalapan pasti lebih mantul. 🙂
1. Jika ingin dibuat stock dimasak besok. Masukkan ayam ungkep ke dalam tepak/box. Tunggu sampai dingin ya... baru tepaknya ditutup dan masukkan di freezer kulkas. 🙂 Jika mau menggoreng tinggal keluarkan dari freezer, tunggu sampai tidak beku dan siap digoreng. Selamat mencoba. 🙂




Demikianlah cara membuat ayam goreng ungkep yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
