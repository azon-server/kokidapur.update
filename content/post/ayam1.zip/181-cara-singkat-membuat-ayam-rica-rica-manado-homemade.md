---
description: "Cara singkat membuat Ayam rica-rica Manado Homemade"
title: "Cara singkat membuat Ayam rica-rica Manado Homemade"
slug: 181-cara-singkat-membuat-ayam-rica-rica-manado-homemade
date: 2020-12-20T04:58:29.402Z
image: https://img-global.cpcdn.com/recipes/5cb28d28296f7bed/751x532cq70/ayam-rica-rica-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5cb28d28296f7bed/751x532cq70/ayam-rica-rica-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5cb28d28296f7bed/751x532cq70/ayam-rica-rica-manado-foto-resep-utama.jpg
author: Clyde Santiago
ratingvalue: 5
reviewcount: 2971
recipeingredient:
- "1 ekor ayam"
- " bumbu halus "
- "1 ons cabe merah keriting"
- "10 buah cabe rawit merah"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "3 butir kemiri"
- "1 ruas lengkuas"
- " bumbu cemplung "
- "3 batang sereh geprek"
- "1 ikat daun pandan ikat simpul"
- "5 lembar daun salam"
- "5 lembar daun jeruk iris"
- "2 batang daun bawang iris"
- "1 ikat kemangi"
- "secukupnya Garam gula dan kaldu jamur"
recipeinstructions:
- "Cuci bersih ayam. Lumuri kunyit bubuk, air jeruk nipis dan garam. Diamkan 10 menit. Goreng setengah mateng. Sisihkan"
- "Siapkan bumbu halus dan bumbu cemplung"
- "Tumis bumbu halus. Kemudian masukkan bumbu cemplung. Masukkan ayam, beri sedikit air. Koreksi rasa"
- "Masak hingga air menyusut. Siap disajikan 😅"
categories:
- Recipe
tags:
- ayam
- ricarica
- manado

katakunci: ayam ricarica manado 
nutrition: 220 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica-rica Manado](https://img-global.cpcdn.com/recipes/5cb28d28296f7bed/751x532cq70/ayam-rica-rica-manado-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica-rica manado yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan keistimewahan yang merupakan keragaman Indonesia



Kedekatan keluarga dapat didapat dengan cara simple. Diantaranya adalah membuat makanan Ayam rica-rica Manado untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda praktekkan salah satunya ayam rica-rica manado yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam rica-rica manado tanpa harus bersusah payah.
Seperti resep Ayam rica-rica Manado yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica Manado:

1. Jangan lupa 1 ekor ayam
1. Jangan lupa  🌻bumbu halus :
1. Diperlukan 1 ons cabe merah keriting
1. Jangan lupa 10 buah cabe rawit merah
1. Jangan lupa 6 siung bawang merah
1. Jangan lupa 4 siung bawang putih
1. Siapkan 1 ruas jahe
1. Tambah 1 ruas kunyit
1. Diperlukan 3 butir kemiri
1. Harap siapkan 1 ruas lengkuas
1. Tambah  🌻bumbu cemplung :
1. Dibutuhkan 3 batang sereh (geprek)
1. Harus ada 1 ikat daun pandan (ikat simpul)
1. Jangan lupa 5 lembar daun salam
1. Diperlukan 5 lembar daun jeruk (iris)
1. Diperlukan 2 batang daun bawang (iris)
1. Tambah 1 ikat kemangi
1. Harap siapkan secukupnya Garam, gula dan kaldu jamur




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica-rica Manado:

1. Cuci bersih ayam. Lumuri kunyit bubuk, air jeruk nipis dan garam. Diamkan 10 menit. Goreng setengah mateng. Sisihkan
1. Siapkan bumbu halus dan bumbu cemplung
1. Tumis bumbu halus. Kemudian masukkan bumbu cemplung. Masukkan ayam, beri sedikit air. Koreksi rasa
1. Masak hingga air menyusut. Siap disajikan 😅




Demikianlah cara membuat ayam rica-rica manado yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan cepat, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
