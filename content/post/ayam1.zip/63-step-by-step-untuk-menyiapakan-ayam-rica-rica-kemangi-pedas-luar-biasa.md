---
description: "Step-by-Step untuk menyiapakan Ayam Rica Rica Kemangi Pedas Luar biasa"
title: "Step-by-Step untuk menyiapakan Ayam Rica Rica Kemangi Pedas Luar biasa"
slug: 63-step-by-step-untuk-menyiapakan-ayam-rica-rica-kemangi-pedas-luar-biasa
date: 2020-12-07T20:33:58.785Z
image: https://img-global.cpcdn.com/recipes/f3c0b0e15b3eccba/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f3c0b0e15b3eccba/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f3c0b0e15b3eccba/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
author: Katharine Hicks
ratingvalue: 4
reviewcount: 9288
recipeingredient:
- "6 Potong Ayam"
- "2 ikat daun kemangi"
recipeinstructions:
- "Potong Ayam menjadi 6 bagian"
- "Didihkan air Rebus ayam selama 10 menit supaya empuk dan agak lunak dan tambahkan sedikit jahe di geprek agar ayam tidak terlalu amis"
- "Bumbu Pelengkap : Daun Salam 2 lembar, Daun jeruk 2 lembar, lenkuas seruas jari di geprek, jahe seruas jari, daun sereh 2 ruas di geprek, kunyit 1 ruas jari di bakar, Bahan Bahan Dihaluskan : Cabai keriting 7 pcs cabai rawit 10 pcs bawang merah 9 siung bawang putih 3 siung kemiri 4 di sangrai ketumbar di sangrai merica bubuk masako ayam mecin garam gula"
- "Tumis bumbu yang sudah di haluskan sampai sudah tercium wangi aroma nya kemudian masukan ayam yang sudah di rebus beri sedikt air tambahkan bumbu penyedap setelah itu koreksi rasa"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 175 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica Rica Kemangi Pedas](https://img-global.cpcdn.com/recipes/f3c0b0e15b3eccba/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau renyah. Ciri khas kuliner Nusantara ayam rica rica kemangi pedas yang penuh dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan keluarga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Ayam Rica Rica Kemangi Pedas untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang bisa anda contoh salah satunya ayam rica rica kemangi pedas yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep ayam rica rica kemangi pedas tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi Pedas yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 2 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi Pedas:

1. Diperlukan 6 Potong Ayam
1. Dibutuhkan 2 ikat daun kemangi




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Rica Kemangi Pedas:

1. Potong Ayam menjadi 6 bagian
1. Didihkan air Rebus ayam selama 10 menit supaya empuk dan agak lunak dan tambahkan sedikit jahe di geprek agar ayam tidak terlalu amis
1. Bumbu Pelengkap : Daun Salam 2 lembar, Daun jeruk 2 lembar, lenkuas seruas jari di geprek, jahe seruas jari, daun sereh 2 ruas di geprek, kunyit 1 ruas jari di bakar, Bahan Bahan Dihaluskan : Cabai keriting 7 pcs cabai rawit 10 pcs bawang merah 9 siung bawang putih 3 siung kemiri 4 di sangrai ketumbar di sangrai merica bubuk masako ayam mecin garam gula
1. Tumis bumbu yang sudah di haluskan sampai sudah tercium wangi aroma nya kemudian masukan ayam yang sudah di rebus beri sedikt air tambahkan bumbu penyedap setelah itu koreksi rasa




Demikianlah cara membuat ayam rica rica kemangi pedas yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan terbukti, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
