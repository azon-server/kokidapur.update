---
description: "Resep : Ayam Goreng Serundeng terupdate"
title: "Resep : Ayam Goreng Serundeng terupdate"
slug: 361-resep-ayam-goreng-serundeng-terupdate
date: 2021-01-02T19:06:42.914Z
image: https://img-global.cpcdn.com/recipes/fe5712e12febab5c/751x532cq70/ayam-goreng-serundeng-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fe5712e12febab5c/751x532cq70/ayam-goreng-serundeng-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fe5712e12febab5c/751x532cq70/ayam-goreng-serundeng-foto-resep-utama.jpg
author: Mildred McCoy
ratingvalue: 4.3
reviewcount: 43023
recipeingredient:
- "500 gr ayam bagian paha marinasi dengan jeruk nipis dan garam secukupnya selama 10 menit kemudian bilas kembali"
- "100 gr kelapa parut"
- "1 batang serai digeprek"
- "2 lembar daun jeruk"
- "2 ruas lengkuas digeprek"
- "2 lembar daun salam"
- "1/4 sdt lada bubuk"
- "1/2 sdt kaldu bubuk"
- "Secukupnya garam"
- "Secukupnya minyak goreng untuk menumis"
- "Secukupnya air"
- " Bumbu Halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "2 ruas kunyit"
- "2 ruas Jahe"
- "1 sdt ketumbar"
- "2 buah kemiri"
- " Pelengkap"
- " Lalapan optional"
- " Sambal tomat optional"
recipeinstructions:
- "Siapkan bahan yang akan digunakan"
- "Tumis bumbu halus, lengkuas, serai, daun salam dan daun jeruk sampai harum. Kemudian masukkan ayam, aduk rata, masak sebentar sampai daging ayam berubah warna agak putih"
- "Kemudian tambahkan lada bubuk, kaldu bubuk, secukupnya air dan garam, aduk rata, koreksi rasa. Jika sudah pas masukkan kelapa parut"
- "Masak sampai ayam matang dan kuahnya habis, sesekali diaduk. Kemudian pisahkan ayam dari bumbunya"
- "Goreng ayam sampai berwarna golden brown, angkat dan tiriskan"
- "Kemudian goreng bumbu sampai berwarna golden brown, sambil diaduk-aduk agar tidak gosong dan matangnya merata. Angkat dan tiriskan"
- "Penyajian: Tata ayam goreng di piring saji, kemudian taburkan serundeng yang sudah digoreng. Ayam Goreng Serundeng siap disajikan dengan sambal dan lalapan"
categories:
- Recipe
tags:
- ayam
- goreng
- serundeng

katakunci: ayam goreng serundeng 
nutrition: 274 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT60M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Goreng Serundeng](https://img-global.cpcdn.com/recipes/fe5712e12febab5c/751x532cq70/ayam-goreng-serundeng-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita lestarikan karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam goreng serundeng yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa ciri khas yang merupakan keragaman Indonesia



Kedekatan rumah tangga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam Goreng Serundeng untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang bisa anda buat salah satunya ayam goreng serundeng yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep ayam goreng serundeng tanpa harus bersusah payah.
Seperti resep Ayam Goreng Serundeng yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Serundeng:

1. Siapkan 500 gr ayam bagian paha, (marinasi dengan jeruk nipis dan garam secukupnya selama 10 menit, kemudian bilas kembali)
1. Harus ada 100 gr kelapa parut
1. Jangan lupa 1 batang serai, digeprek
1. Tambah 2 lembar daun jeruk
1. Harus ada 2 ruas lengkuas, digeprek
1. Harus ada 2 lembar daun salam
1. Dibutuhkan 1/4 sdt lada bubuk
1. Dibutuhkan 1/2 sdt kaldu bubuk
1. Diperlukan Secukupnya garam
1. Harap siapkan Secukupnya minyak goreng untuk menumis
1. Harap siapkan Secukupnya air
1. Tambah  Bumbu Halus:
1. Jangan lupa 5 siung bawang merah
1. Tambah 3 siung bawang putih
1. Dibutuhkan 2 ruas kunyit
1. Tambah 2 ruas Jahe
1. Jangan lupa 1 sdt ketumbar
1. Dibutuhkan 2 buah kemiri
1. Tambah  Pelengkap
1. Dibutuhkan  Lalapan (optional)
1. Siapkan  Sambal tomat (optional)




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Goreng Serundeng:

1. Siapkan bahan yang akan digunakan
1. Tumis bumbu halus, lengkuas, serai, daun salam dan daun jeruk sampai harum. Kemudian masukkan ayam, aduk rata, masak sebentar sampai daging ayam berubah warna agak putih
1. Kemudian tambahkan lada bubuk, kaldu bubuk, secukupnya air dan garam, aduk rata, koreksi rasa. Jika sudah pas masukkan kelapa parut
1. Masak sampai ayam matang dan kuahnya habis, sesekali diaduk. Kemudian pisahkan ayam dari bumbunya
1. Goreng ayam sampai berwarna golden brown, angkat dan tiriskan
1. Kemudian goreng bumbu sampai berwarna golden brown, sambil diaduk-aduk agar tidak gosong dan matangnya merata. Angkat dan tiriskan
1. Penyajian: Tata ayam goreng di piring saji, kemudian taburkan serundeng yang sudah digoreng. Ayam Goreng Serundeng siap disajikan dengan sambal dan lalapan




Demikianlah cara membuat ayam goreng serundeng yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
