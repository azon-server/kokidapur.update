---
description: "Langkah untuk menyiapakan Ayam rica-rica Favorite"
title: "Langkah untuk menyiapakan Ayam rica-rica Favorite"
slug: 166-langkah-untuk-menyiapakan-ayam-rica-rica-favorite
date: 2020-10-09T13:46:25.457Z
image: https://img-global.cpcdn.com/recipes/658a35344af63ec3/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/658a35344af63ec3/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/658a35344af63ec3/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Thomas Long
ratingvalue: 4.4
reviewcount: 30754
recipeingredient:
- "1 ekor ayam potong 10"
- "Sesuai selera daun bawang bisa juga pakai kemangi"
- " Bumbu halus "
- "1 ruas Kunyit"
- "6 buah Cabe merah"
- "4 buah Cabe rawit setan kalau suka pedas"
- "3 butir kemiri"
- "8 siung Bawang merah"
- "4 siung Bawang putih"
- "1 ruas jahe"
- " Bumbu tabur "
- "Secukupnya garam"
- "Secukupnya penyedap saya pakai kaldu jamur"
- " Bumbu tumis "
- "1 batang sereh geprek"
- "3 lembar daun jeruk"
- "1 ruas lengkuas"
recipeinstructions:
- "Haluskan bumbu dengan blender."
- "Cuci ayam hingga bersih."
- "Panaskan minyak, tumis bumbu hingga harum."
- "Geprek sereh dan jahe. Lalu masukan daun jeruk dan bumbu yang sudah digeprek. Setelah harum, masukan ayam."
- "Beri sedikit air, masak dengan api yang membesar."
- "Aduk2 sampai bumbu merata. Tutup agar ayam cepat matang dan empuk."
- "Sajikan :))"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 117 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT37M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam rica-rica](https://img-global.cpcdn.com/recipes/658a35344af63ec3/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau enak. Karasteristik makanan Nusantara ayam rica-rica yang kaya dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah memasak Ayam rica-rica untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang dapat anda praktekkan salah satunya ayam rica-rica yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica:

1. Siapkan 1 ekor ayam (potong 10)
1. Jangan lupa Sesuai selera daun bawang (bisa juga pakai kemangi)
1. Jangan lupa  Bumbu halus :
1. Harap siapkan 1 ruas Kunyit
1. Harap siapkan 6 buah Cabe merah
1. Harus ada 4 buah Cabe rawit setan (kalau suka pedas)
1. Tambah 3 butir kemiri
1. Jangan lupa 8 siung Bawang merah
1. Harus ada 4 siung Bawang putih
1. Siapkan 1 ruas jahe
1. Dibutuhkan  Bumbu tabur :
1. Tambah Secukupnya garam
1. Diperlukan Secukupnya penyedap (saya pakai kaldu jamur)
1. Dibutuhkan  Bumbu tumis :
1. Harap siapkan 1 batang sereh (geprek)
1. Siapkan 3 lembar daun jeruk
1. Siapkan 1 ruas lengkuas




<!--inarticleads2-->

##### Cara membuat  Ayam rica-rica:

1. Haluskan bumbu dengan blender.
1. Cuci ayam hingga bersih.
1. Panaskan minyak, tumis bumbu hingga harum.
1. Geprek sereh dan jahe. Lalu masukan daun jeruk dan bumbu yang sudah digeprek. Setelah harum, masukan ayam.
1. Beri sedikit air, masak dengan api yang membesar.
1. Aduk2 sampai bumbu merata. Tutup agar ayam cepat matang dan empuk.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam rica-rica"><img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam rica-rica">1. Sajikan :))




Demikianlah cara membuat ayam rica-rica yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
