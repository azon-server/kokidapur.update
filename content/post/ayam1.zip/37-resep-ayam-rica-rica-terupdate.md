---
description: "Resep : Ayam Rica-rica terupdate"
title: "Resep : Ayam Rica-rica terupdate"
slug: 37-resep-ayam-rica-rica-terupdate
date: 2021-01-04T06:25:44.008Z
image: https://img-global.cpcdn.com/recipes/bf29900c88c973fb/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bf29900c88c973fb/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bf29900c88c973fb/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Dennis Carpenter
ratingvalue: 4.8
reviewcount: 48739
recipeingredient:
- "5 potong ayam ukuran besar bisa 1 ekor ayam ukuran sedang"
- "2 daun salam"
- "6 daun jeruk"
- "1 Serai"
- "2 ruas lengkuas geprek"
- "1 ruas jahe geprek"
- "2 ikat kemangi"
- "1 sdm gula merah"
- "Secukupnya garam kaldu bubuk"
- " Bumbu Halus"
- "4 siung bawang putih"
- "10 siung bawang merah"
- "80 gram cabe kriting"
- "2 kemiri sangrai"
- "1 ruas kunyit"
recipeinstructions:
- "Tumis bumbu halus hingga harum. Masukkan jahe, lengkuas, daun jeruk, daun salam dan serai. Aduk2 hingga harum."
- "Masukkan ayam ke dalam tumisan bumbu. Biarkan beberapa saat. Aduk2. Masukkan air kedalamnya. Masukkan garam, gula merah dan kaldu bubuk."
- "Masak hingga bumbu meresap dan air menyusut. Koreksi rasa. Masukkan daun kemangi, aduk sebentar dan matikan api. Segera pindahkan ke wadah saji. Ayam rica2 siap dinikmati."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 296 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica-rica](https://img-global.cpcdn.com/recipes/bf29900c88c973fb/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga renyah. Karasteristik makanan Nusantara ayam rica-rica yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga dapat diperoleh dengan cara simple. Diantaranya adalah memasak Ayam Rica-rica untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda praktekkan salah satunya ayam rica-rica yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 15 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica:

1. Dibutuhkan 5 potong ayam ukuran besar (bisa 1 ekor ayam ukuran sedang)
1. Dibutuhkan 2 daun salam
1. Dibutuhkan 6 daun jeruk
1. Dibutuhkan 1 Serai
1. Dibutuhkan 2 ruas lengkuas geprek
1. Diperlukan 1 ruas jahe geprek
1. Siapkan 2 ikat kemangi
1. Diperlukan 1 sdm gula merah
1. Dibutuhkan Secukupnya garam, kaldu bubuk
1. Dibutuhkan  Bumbu Halus
1. Diperlukan 4 siung bawang putih
1. Jangan lupa 10 siung bawang merah
1. Jangan lupa 80 gram cabe kriting
1. Harap siapkan 2 kemiri sangrai
1. Harap siapkan 1 ruas kunyit




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-rica:

1. Tumis bumbu halus hingga harum. Masukkan jahe, lengkuas, daun jeruk, daun salam dan serai. Aduk2 hingga harum.
1. Masukkan ayam ke dalam tumisan bumbu. Biarkan beberapa saat. Aduk2. Masukkan air kedalamnya. Masukkan garam, gula merah dan kaldu bubuk.
1. Masak hingga bumbu meresap dan air menyusut. Koreksi rasa. Masukkan daun kemangi, aduk sebentar dan matikan api. Segera pindahkan ke wadah saji. Ayam rica2 siap dinikmati.




Demikianlah cara membuat ayam rica-rica yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
