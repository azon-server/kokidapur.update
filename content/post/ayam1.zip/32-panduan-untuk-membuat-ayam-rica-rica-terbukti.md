---
description: "Panduan untuk membuat Ayam Rica-Rica Terbukti"
title: "Panduan untuk membuat Ayam Rica-Rica Terbukti"
slug: 32-panduan-untuk-membuat-ayam-rica-rica-terbukti
date: 2020-11-20T17:58:13.961Z
image: https://img-global.cpcdn.com/recipes/a7378a7593d5548d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a7378a7593d5548d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a7378a7593d5548d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Ricky Steele
ratingvalue: 4.7
reviewcount: 2266
recipeingredient:
- "400 g ayam potong jadi 6"
- "1 ruas jahe digeprek"
- "1 sdm gula merah sisir saya pake gula merah cair"
- "1 sdm kecap manis"
- "1/2 sdt merica bubuk"
- "1 sdt garam"
- "1/2 sdt kaldu bubuk organik"
- "3 sdm minyak goreng untuk menumis"
- "Secukupnya air"
- " Bumbu Halus"
- "4 siung bawang merah"
- "3 siung bawang putih"
- "6 buah cabe keriting merah"
- "2 buah cabe setan boleh diskip jika tidak suka terlalu pedas"
- "2 cm kunyit kupas kulitnya"
- "50 ml air"
- " Bahan Cemplung"
- "3 cm lengkuas digeprek"
- "1 batang serai digeprak"
- "2 lembar daun salam"
recipeinstructions:
- "Cuci bersih ayam. Rebus ayam bersama air dan jahe. Buangi gumpalan keruh yang ada dipermukaan air saat merebus ayam. Rebus sampai setengah matang (ini saya lakukan karena ayamnya dari freezer/tidak fresh, jika ayamnya fresh bisa direndam perasan jeruk nipis kemudian lanjutkan ke langkah no. 2). Matikan api kompor, kemudian buang jahenya. Sisihkan!"
- "Cuci bersih semua bahan bumbu halus, kecuali air. Potong-potong, kemudian haluskan dengan blender bersama air."
- "Siapkan bahan cemplung. Panaskan minyak goreng. Masukkan bumbu halus. Tumis sampai air susut dan baunya harum. Masukkan bumbu cemplung."
- "Masukkan ayamnya. Aduk sebentar, kemudian tambahkan air kaldu rebusan ayam sampai ayamnya terendam semua. Tambahkan gula merah dan kecap manis."
- "Masak sampai airnya agak susut dan bumbu meresap ke ayam. Matikan api kompor. Pindahkan ke wadah dan siap disajikan. Selamat mencoba 😉🥰"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 135 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/a7378a7593d5548d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas atau empuk. Karasteristik masakan Indonesia ayam rica-rica yang kaya dengan bumbu memberikan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Keharmonisan keluarga dapat diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam Rica-Rica untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang dapat anda buat salah satunya ayam rica-rica yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica:

1. Diperlukan 400 g ayam (potong jadi 6)
1. Harap siapkan 1 ruas jahe (digeprek)
1. Harus ada 1 sdm gula merah sisir (saya pake gula merah cair)
1. Dibutuhkan 1 sdm kecap manis
1. Diperlukan 1/2 sdt merica bubuk
1. Dibutuhkan 1 sdt garam
1. Jangan lupa 1/2 sdt kaldu bubuk organik
1. Jangan lupa 3 sdm minyak goreng untuk menumis
1. Dibutuhkan Secukupnya air
1. Dibutuhkan  Bumbu Halus:
1. Diperlukan 4 siung bawang merah
1. Jangan lupa 3 siung bawang putih
1. Jangan lupa 6 buah cabe keriting merah
1. Harus ada 2 buah cabe setan (boleh diskip jika tidak suka terlalu pedas)
1. Siapkan 2 cm kunyit (kupas kulitnya)
1. Harap siapkan 50 ml air
1. Dibutuhkan  Bahan Cemplung:
1. Harus ada 3 cm lengkuas (digeprek)
1. Harap siapkan 1 batang serai (digeprak)
1. Diperlukan 2 lembar daun salam




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica:

1. Cuci bersih ayam. Rebus ayam bersama air dan jahe. Buangi gumpalan keruh yang ada dipermukaan air saat merebus ayam. Rebus sampai setengah matang (ini saya lakukan karena ayamnya dari freezer/tidak fresh, jika ayamnya fresh bisa direndam perasan jeruk nipis kemudian lanjutkan ke langkah no. 2). Matikan api kompor, kemudian buang jahenya. Sisihkan!
1. Cuci bersih semua bahan bumbu halus, kecuali air. Potong-potong, kemudian haluskan dengan blender bersama air.
1. Siapkan bahan cemplung. Panaskan minyak goreng. Masukkan bumbu halus. Tumis sampai air susut dan baunya harum. Masukkan bumbu cemplung.
1. Masukkan ayamnya. Aduk sebentar, kemudian tambahkan air kaldu rebusan ayam sampai ayamnya terendam semua. Tambahkan gula merah dan kecap manis.
1. Masak sampai airnya agak susut dan bumbu meresap ke ayam. Matikan api kompor. Pindahkan ke wadah dan siap disajikan. Selamat mencoba 😉🥰




Demikianlah cara membuat ayam rica-rica yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan teruji, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
