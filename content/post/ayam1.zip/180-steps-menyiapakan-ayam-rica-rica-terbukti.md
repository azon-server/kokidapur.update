---
description: "Steps menyiapakan Ayam Rica-Rica Terbukti"
title: "Steps menyiapakan Ayam Rica-Rica Terbukti"
slug: 180-steps-menyiapakan-ayam-rica-rica-terbukti
date: 2020-12-20T22:09:19.244Z
image: https://img-global.cpcdn.com/recipes/b6e590348ab66be4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b6e590348ab66be4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b6e590348ab66be4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Lelia Nunez
ratingvalue: 4.4
reviewcount: 10635
recipeingredient:
- "500 gr Ayam"
- "1 buah Jeruk nipis"
- "2 sdt kunyit bubuk"
- "1 sdt garam"
- "4 lembar Daun Jeruk purut"
- "2 lembar daun salam1 batang sereh"
- " Bumbu Halus "
- "10 cabe Rawit"
- "1 btg sereh"
- "2 cm Lengkuas"
- "2 cm Jahe"
- "2 cm Kunyit"
- "20 ml Air"
- " Bumbu tambahan"
- "1 sdt garam"
- "1 sdt Kaldu bubuk"
- "1/2 sdt merica bubuk"
- "2 sdm kecap manis"
recipeinstructions:
- "Bersihkan ayam, lumuri dgn Kunyit, garam, perasan jeruk nipis"
- "Rebus ayam sampai daging empuk. Kurang lebih 15 menit. Lalu tiriskan."
- "Siapkan semua bahan yg ingin dihaluskan, seperti : baput, Bamer, Jahe, cabe rawit, kunyit, lengkuas. Masukan sedikit minyk. Jika bahan kurang hancur, tambahkan sedikit air. lalu blender hingga halus."
- "Panaskan wajan, masukan bumbu yg sudah di haluskan, jika sdh wangi. Masukan sereh yg sdh di geprek. Aduk dan tunggu hingga bumbu wangi."
- "Nah, tambahkan daun jeruk, dan daun salam. Aduk-aduk sebentar. Tuangkan ayam yg sudah ditiriskan tadi. Dan aduk lagi sampai bumbu merata"
- "Tambahkan garam, Kaldu bubuk, merica bubuk, dan kecap manis. sambil icip2 rasa bumbu. Jika sudah pas, diamkan sebentar hingga bumbu meresap."
- "Aduk-aduk lagi. Matikan kompor, dan ayam rica-rica, siap di hidangkan"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 146 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/b6e590348ab66be4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica-rica yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Kita

Keharmonisan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica-Rica untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang bisa anda contoh salah satunya ayam rica-rica yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica:

1. Dibutuhkan 500 gr Ayam
1. Diperlukan 1 buah Jeruk nipis
1. Siapkan 2 sdt kunyit bubuk
1. Siapkan 1 sdt garam
1. Harap siapkan 4 lembar Daun Jeruk purut
1. Dibutuhkan 2 lembar daun salam1 batang sereh
1. Tambah  Bumbu Halus :
1. Siapkan 10 cabe Rawit
1. Jangan lupa 1 btg sereh
1. Jangan lupa 2 cm Lengkuas
1. Harus ada 2 cm Jahe
1. Harap siapkan 2 cm Kunyit
1. Tambah 20 ml Air
1. Harus ada  Bumbu tambahan
1. Dibutuhkan 1 sdt garam
1. Dibutuhkan 1 sdt Kaldu bubuk
1. Siapkan 1/2 sdt merica bubuk
1. Jangan lupa 2 sdm kecap manis




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica:

1. Bersihkan ayam, lumuri dgn Kunyit, garam, perasan jeruk nipis
1. Rebus ayam sampai daging empuk. Kurang lebih 15 menit. Lalu tiriskan.
1. Siapkan semua bahan yg ingin dihaluskan, seperti : baput, Bamer, Jahe, cabe rawit, kunyit, lengkuas. Masukan sedikit minyk. Jika bahan kurang hancur, tambahkan sedikit air. lalu blender hingga halus.
1. Panaskan wajan, masukan bumbu yg sudah di haluskan, jika sdh wangi. Masukan sereh yg sdh di geprek. Aduk dan tunggu hingga bumbu wangi.
1. Nah, tambahkan daun jeruk, dan daun salam. Aduk-aduk sebentar. Tuangkan ayam yg sudah ditiriskan tadi. Dan aduk lagi sampai bumbu merata
1. Tambahkan garam, Kaldu bubuk, merica bubuk, dan kecap manis. sambil icip2 rasa bumbu. Jika sudah pas, diamkan sebentar hingga bumbu meresap.
1. Aduk-aduk lagi. Matikan kompor, dan ayam rica-rica, siap di hidangkan




Demikianlah cara membuat ayam rica-rica yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
