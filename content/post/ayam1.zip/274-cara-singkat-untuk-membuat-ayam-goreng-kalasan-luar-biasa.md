---
description: "Cara singkat untuk membuat Ayam Goreng Kalasan Luar biasa"
title: "Cara singkat untuk membuat Ayam Goreng Kalasan Luar biasa"
slug: 274-cara-singkat-untuk-membuat-ayam-goreng-kalasan-luar-biasa
date: 2021-01-30T09:47:24.932Z
image: https://img-global.cpcdn.com/recipes/e0349d701dfe92fc/751x532cq70/ayam-goreng-kalasan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e0349d701dfe92fc/751x532cq70/ayam-goreng-kalasan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e0349d701dfe92fc/751x532cq70/ayam-goreng-kalasan-foto-resep-utama.jpg
author: Bruce Thomas
ratingvalue: 4.5
reviewcount: 21936
recipeingredient:
- "1 kg ayam paha"
- "800-1 lt air kelapa"
- "1 buah jeruk nipis"
- " Bumbu halus"
- "10 siung bawang merah"
- "7 siung bawang putih"
- "1 ruas lengkuas"
- "1 sdt merica"
- " Bumbu cemplung"
- "3 lembar daun salam"
- "5 lembar daun jeruk"
- "1 serai"
- " Bumbu lain"
- "200 gr gula merah sisir"
- "1 sdm gula pasir"
- "3 sdm kecap manis"
- "Secukupnya garam dan kaldu bubuk"
recipeinstructions:
- "Cuci ayam lalu lumuri dengan perasan jeruk nipis. Setelah 15 menit cuci lagi hingga bersih."
- "Haluskan bumbu."
- "Lumuri ayam dengan bumbu halus. Marinasi selama kurang lebih 30 menit."
- "Didihkan air kelapa dengan daun salam, daun jeruk dan serai."
- "Masukkan ayam yang sudah di marinasi. Tunggu ayam sampai empuk."
- "Tambahkan gula jawa, kecap, garam, kaldu bubuk."
- "Aduk pelan-pelan. Hingga merata dan menyusut airnya."
- "Goreng dalam minyak panas hingga matang. Sesekali di balik jangan sampai gosong, krn ini banyak mengandung gula."
- "Angkat. Tiriskan. Sajikan dengan sambal dan lalapan."
categories:
- Recipe
tags:
- ayam
- goreng
- kalasan

katakunci: ayam goreng kalasan 
nutrition: 149 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Goreng Kalasan](https://img-global.cpcdn.com/recipes/e0349d701dfe92fc/751x532cq70/ayam-goreng-kalasan-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau enak. Karasteristik kuliner Nusantara ayam goreng kalasan yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Ayam Goreng Kalasan untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang bisa anda buat salah satunya ayam goreng kalasan yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan cepat menemukan resep ayam goreng kalasan tanpa harus bersusah payah.
Berikut ini resep Ayam Goreng Kalasan yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 9 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Kalasan:

1. Harus ada 1 kg ayam (paha)
1. Harap siapkan 800-1 lt air kelapa
1. Harus ada 1 buah jeruk nipis
1. Dibutuhkan  Bumbu halus
1. Harap siapkan 10 siung bawang merah
1. Diperlukan 7 siung bawang putih
1. Tambah 1 ruas lengkuas
1. Jangan lupa 1 sdt merica
1. Harus ada  Bumbu cemplung
1. Harus ada 3 lembar daun salam
1. Tambah 5 lembar daun jeruk
1. Siapkan 1 serai
1. Jangan lupa  Bumbu lain
1. Tambah 200 gr gula merah (sisir)
1. Jangan lupa 1 sdm gula pasir
1. Jangan lupa 3 sdm kecap manis
1. Jangan lupa Secukupnya garam dan kaldu bubuk




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Kalasan:

1. Cuci ayam lalu lumuri dengan perasan jeruk nipis. Setelah 15 menit cuci lagi hingga bersih.
1. Haluskan bumbu.
1. Lumuri ayam dengan bumbu halus. Marinasi selama kurang lebih 30 menit.
1. Didihkan air kelapa dengan daun salam, daun jeruk dan serai.
1. Masukkan ayam yang sudah di marinasi. Tunggu ayam sampai empuk.
1. Tambahkan gula jawa, kecap, garam, kaldu bubuk.
1. Aduk pelan-pelan. Hingga merata dan menyusut airnya.
1. Goreng dalam minyak panas hingga matang. Sesekali di balik jangan sampai gosong, krn ini banyak mengandung gula.
1. Angkat. Tiriskan. Sajikan dengan sambal dan lalapan.




Demikianlah cara membuat ayam goreng kalasan yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan terbukti, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
