---
description: "Bagaimana untuk menyiapakan Ayam Rica - rica (ala Mamer) Sempurna"
title: "Bagaimana untuk menyiapakan Ayam Rica - rica (ala Mamer) Sempurna"
slug: 74-bagaimana-untuk-menyiapakan-ayam-rica-rica-ala-mamer-sempurna
date: 2020-11-09T23:33:45.208Z
image: https://img-global.cpcdn.com/recipes/ad139867207f7863/751x532cq70/ayam-rica-rica-ala-mamer-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ad139867207f7863/751x532cq70/ayam-rica-rica-ala-mamer-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ad139867207f7863/751x532cq70/ayam-rica-rica-ala-mamer-foto-resep-utama.jpg
author: Christina Page
ratingvalue: 4.1
reviewcount: 48242
recipeingredient:
- "  Bahan "
- "500 gr ayam"
- "Secukupnya air jeruk nipis"
- "500 ml air secukupnya"
- "Secukupnya minyak gr utk menumis"
- "  Bumbu Cemplung "
- "3 lbr daun jeruk buang tulang daun"
- "1 lbr daun kunyit optional ikat"
- "2 lbr daun salam"
- "1 bh Sere digeprek ikat"
- "1 genggam daun kemangi"
- "  Bumbu seasoning "
- "2 sdt Secukupnya garam"
- "1 sdt Secukupnya kaldu bubuk jamurayam"
- "1/2 sdt merica putih bubuk"
- "1/2 sdt gula optional"
- "  Bumbu Halus "
- "6 bh bawang merah"
- "4 siung bawang putih"
- "5 bh kemiri disangrai"
- "10 bh cabe rawit merah sesuai selera sebagian biarkan utuh"
- "3 bh cabai merah keriting"
- "2 ruas jari kunyit"
- "2 ruas jari jahe"
- "2 ruas jari lengkuas"
recipeinstructions:
- "Cuci ayam, potong2 sesuai selera (sy potong2 kecil), lumuri dgn air jeruk nipis, remas2, diamkan sekitar 15 mnt. Kmdn cuci bersih kembali dan tiriskan."
- "Panaskan wajan, beri minyak gr secukupnya. Tumis bumbu halus hingga harum, tambahkan bumbu cemplung (daun jeruk, daun kunyit, daun salam, serai), kecuali kemangi. Masak kembali hingga matang."
- "Tambahkan ayam, aduk rata. Stlh ayam berubah warna, tuang air, bumbui garam, merica, kaldu bubuk, gula. Aduk rata &amp; masak sekitar 30 mnt dgn api kecil - sedang."
- "Setelah air menyusut dan ayam matang, masukkan daun kemangi, aduk rata, koreksi rasa. Matikan kompor."
- "Tata di piring dan siap disajikan 😉"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 189 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica - rica (ala Mamer)](https://img-global.cpcdn.com/recipes/ad139867207f7863/751x532cq70/ayam-rica-rica-ala-mamer-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang dapat kita lestarikan karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica - rica (ala mamer) yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa kesan tersendiri yang merupakan keragaman Indonesia



Kedekatan keluarga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Ayam Rica - rica (ala Mamer) untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang dapat anda buat salah satunya ayam rica - rica (ala mamer) yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica - rica (ala mamer) tanpa harus bersusah payah.
Seperti resep Ayam Rica - rica (ala Mamer) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 25 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica - rica (ala Mamer):

1. Tambah  🌠 Bahan :
1. Dibutuhkan 500 gr ayam
1. Harap siapkan Secukupnya air jeruk nipis
1. Siapkan 500 ml air (secukupnya)
1. Jangan lupa Secukupnya minyak gr utk menumis
1. Harus ada  🌠 Bumbu Cemplung :
1. Dibutuhkan 3 lbr daun jeruk, buang tulang daun
1. Siapkan 1 lbr daun kunyit (optional), ikat
1. Tambah 2 lbr daun salam
1. Dibutuhkan 1 bh Sere, digeprek, ikat
1. Jangan lupa 1 genggam daun kemangi
1. Tambah  🌠 Bumbu (seasoning) :
1. Harus ada 2 sdt (Secukupnya) garam
1. Harap siapkan 1 sdt (Secukupnya) kaldu bubuk (jamur/ayam)
1. Dibutuhkan 1/2 sdt merica putih bubuk
1. Dibutuhkan 1/2 sdt gula (optional)
1. Harus ada  🌠 Bumbu Halus :
1. Harap siapkan 6 bh bawang merah
1. Harap siapkan 4 siung bawang putih
1. Siapkan 5 bh kemiri, disangrai
1. Dibutuhkan 10 bh cabe rawit merah (sesuai selera), sebagian biarkan utuh
1. Harap siapkan 3 bh cabai merah keriting
1. Diperlukan 2 ruas jari kunyit
1. Jangan lupa 2 ruas jari jahe
1. Tambah 2 ruas jari lengkuas




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica - rica (ala Mamer):

1. Cuci ayam, potong2 sesuai selera (sy potong2 kecil), lumuri dgn air jeruk nipis, remas2, diamkan sekitar 15 mnt. Kmdn cuci bersih kembali dan tiriskan.
1. Panaskan wajan, beri minyak gr secukupnya. Tumis bumbu halus hingga harum, tambahkan bumbu cemplung (daun jeruk, daun kunyit, daun salam, serai), kecuali kemangi. Masak kembali hingga matang.
1. Tambahkan ayam, aduk rata. Stlh ayam berubah warna, tuang air, bumbui garam, merica, kaldu bubuk, gula. Aduk rata &amp; masak sekitar 30 mnt dgn api kecil - sedang.
1. Setelah air menyusut dan ayam matang, masukkan daun kemangi, aduk rata, koreksi rasa. Matikan kompor.
1. Tata di piring dan siap disajikan 😉




Demikianlah cara membuat ayam rica - rica (ala mamer) yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
