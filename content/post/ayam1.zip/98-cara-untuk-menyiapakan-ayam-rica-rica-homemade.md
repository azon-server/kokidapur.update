---
description: "Cara untuk menyiapakan Ayam Rica-Rica Homemade"
title: "Cara untuk menyiapakan Ayam Rica-Rica Homemade"
slug: 98-cara-untuk-menyiapakan-ayam-rica-rica-homemade
date: 2020-10-07T06:38:59.517Z
image: https://img-global.cpcdn.com/recipes/ab7c51b787a646fa/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ab7c51b787a646fa/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ab7c51b787a646fa/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Allen Zimmerman
ratingvalue: 5
reviewcount: 13650
recipeingredient:
- "6-9 potong ayam"
- "4 ikat kemangi petik daunnya"
- "200 ml air"
- "1/2 sdt garam"
- "1 sdt kaldu ayam bubuk"
- "1 batang daun bawang"
- " Bumbu Halus"
- "10 cabe merah besar"
- "3 cabe merah keriting"
- "4 bawang putih"
- "10 bawang merah"
- "2 kemiri sudah disangrai"
- "1 cm kunyit"
- "1 sdm gula merah"
- " Bumbu Pelengkap"
- "2 daun salam"
- "6 daun jeruk"
- "3 cm lengkoas geprek"
- "2 cm jahe geprek"
- "1 sereh geprek"
recipeinstructions:
- "Haluskan semua bumbu halus. Tumis bumbu halus, tambahkan bumbu pelengkap. Tumis sampai harum, kemudian masukkan garam dan kaldu bubuk. Aduk rata."
- "Masukkan ayam, masak sebentar sampai ayam berubah warna. Masukkan air, aduk rata."
- "Jika air sudah mendidih, tutup wajannya, masak dengan api kecil selama 30 menit supaya ayam empuk dan bumbu meresap."
- "Setelah 30 menit, icip, koreksi rasa. Kemudian masukkan kemangi dan daun bawang. Masak hingga layu. Selesai, sajikan 🤗"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 270 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/ab7c51b787a646fa/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang harus kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica-rica yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan keistimewahan yang merupakan keragaman Indonesia



Keharmonisan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica-Rica untuk keluarga. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang dapat anda buat salah satunya ayam rica-rica yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica:

1. Jangan lupa 6-9 potong ayam
1. Harus ada 4 ikat kemangi, petik daunnya
1. Dibutuhkan 200 ml air
1. Harap siapkan 1/2 sdt garam
1. Tambah 1 sdt kaldu ayam bubuk
1. Tambah 1 batang daun bawang
1. Jangan lupa  Bumbu Halus:
1. Harus ada 10 cabe merah besar
1. Tambah 3 cabe merah keriting
1. Diperlukan 4 bawang putih
1. Jangan lupa 10 bawang merah
1. Dibutuhkan 2 kemiri, sudah disangrai
1. Dibutuhkan 1 cm kunyit
1. Harap siapkan 1 sdm gula merah
1. Tambah  Bumbu Pelengkap:
1. Harap siapkan 2 daun salam
1. Dibutuhkan 6 daun jeruk
1. Jangan lupa 3 cm lengkoas, geprek
1. Siapkan 2 cm jahe, geprek
1. Harap siapkan 1 sereh, geprek




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica:

1. Haluskan semua bumbu halus. Tumis bumbu halus, tambahkan bumbu pelengkap. Tumis sampai harum, kemudian masukkan garam dan kaldu bubuk. Aduk rata.
1. Masukkan ayam, masak sebentar sampai ayam berubah warna. Masukkan air, aduk rata.
1. Jika air sudah mendidih, tutup wajannya, masak dengan api kecil selama 30 menit supaya ayam empuk dan bumbu meresap.
1. Setelah 30 menit, icip, koreksi rasa. Kemudian masukkan kemangi dan daun bawang. Masak hingga layu. Selesai, sajikan 🤗




Demikianlah cara membuat ayam rica-rica yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan teruji, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
