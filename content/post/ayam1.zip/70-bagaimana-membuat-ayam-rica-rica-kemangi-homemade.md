---
description: "Bagaimana membuat Ayam rica rica kemangi Homemade"
title: "Bagaimana membuat Ayam rica rica kemangi Homemade"
slug: 70-bagaimana-membuat-ayam-rica-rica-kemangi-homemade
date: 2020-09-23T00:43:33.573Z
image: https://img-global.cpcdn.com/recipes/31b25ff97e88ea6d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/31b25ff97e88ea6d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/31b25ff97e88ea6d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Dominic Evans
ratingvalue: 4.8
reviewcount: 26578
recipeingredient:
- "1 ekor ayam"
- " Bumbu halus"
- "15 cabai rawit merah"
- "10 cabai merah keriting"
- "10 siung bawang merah"
- "6 siung bawang putih"
- "4 butir kemiri"
- "2 cm jahe"
- "2 cm kunyit"
- "5 lembar daun jeruk"
- "4 lembar daun salam"
- "3 ikat kemangi"
- "2 serai memarkan"
recipeinstructions:
- "Potong daging ayam sesuai selera beri garam dan perasan jeruk nipis lalu cuci bersih"
- "Goreng ayam sampai berwarna kecokelatan 1/2 matang jangan sampai kering"
- "Tumis bumbu halus masukkan serai, daun jeruk,dan daun salam aduk2 sampai tercium harum lalu masukkan ayam aduk rata beri garam, gula dan penyedap dan beri air secukupnya"
- ""
- "Tunggu sampai mendidih dengan api sedang masak sampai ayam empuk, koreksi rasa Lalu masukkn daun kemangi"
- "Ayam rica rica kemangi siap dihidangkan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 288 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/31b25ff97e88ea6d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica rica kemangi yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa ciri khas yang merupakan keragaman Kita



Kehangatan rumah tangga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica rica kemangi untuk keluarga. kebiasaan makan bersama anak sudah menjadi budaya, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang dapat anda contoh salah satunya ayam rica rica kemangi yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Jangan lupa 1 ekor ayam
1. Diperlukan  Bumbu halus
1. Diperlukan 15 cabai rawit merah
1. Tambah 10 cabai merah keriting
1. Siapkan 10 siung bawang merah
1. Harap siapkan 6 siung bawang putih
1. Harap siapkan 4 butir kemiri
1. Dibutuhkan 2 cm jahe
1. Dibutuhkan 2 cm kunyit
1. Diperlukan 5 lembar daun jeruk
1. Harus ada 4 lembar daun salam
1. Dibutuhkan 3 ikat kemangi
1. Diperlukan 2 serai memarkan




<!--inarticleads2-->

##### Cara membuat  Ayam rica rica kemangi:

1. Potong daging ayam sesuai selera beri garam dan perasan jeruk nipis lalu cuci bersih
1. Goreng ayam sampai berwarna kecokelatan - 1/2 matang jangan sampai kering
1. Tumis bumbu halus masukkan serai, daun jeruk,dan daun salam aduk2 sampai tercium harum lalu masukkan ayam aduk rata beri garam, gula dan penyedap dan beri air secukupnya
1. 
1. Tunggu sampai mendidih dengan api sedang masak sampai ayam empuk, koreksi rasa - Lalu masukkn daun kemangi
1. Ayam rica rica kemangi siap dihidangkan




Demikianlah cara membuat ayam rica rica kemangi yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
