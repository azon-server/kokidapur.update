---
description: "Resep : Ayam Bumbu Rujak Homemade"
title: "Resep : Ayam Bumbu Rujak Homemade"
slug: 495-resep-ayam-bumbu-rujak-homemade
date: 2020-08-13T19:03:06.305Z
image: https://img-global.cpcdn.com/recipes/ea26fce764a20afd/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ea26fce764a20afd/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ea26fce764a20afd/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
author: Scott Underwood
ratingvalue: 4.6
reviewcount: 32421
recipeingredient:
- "1/2 ekor ayam"
- "1 buah serai"
- "1 ruas lengkuas"
- "2 lembar daun salam"
- "4 lembar daun jeruk"
- "1 ruas jahe"
- "Secukupnya gula dan garam"
- "100 ml Larutan Air Asam Jawa"
- "1 buah tomat ukuran besar"
- "10 buah cabai rawit"
- "1 bungkus santan instan saya pakai Kara"
- "secukupnya Air"
- " Bumbu Halus"
- "7 siung bawang merah"
- "5 siung bawang putih"
- "4 butir kemiri"
- "5 buah cabai merah"
- "1 ruas Kunyit"
- "1/2 sdt ketumbar bubuk"
recipeinstructions:
- "Cuci bersih ayam, kemudian tiriskan."
- "Blender bumbu sampai halus. Kemudian geprek serei, lengkuas dan jahe."
- "Tumis bumbu halus dengan sedikit minyak sampai wangi. Setelah wangi masukkan serei, lengkuas, dan jahe yang telah di geprek. Aduk-aduk sebentar lalu masukkan daun salam dan daun jeruk."
- "Setelah itu masukkan ayam. Tambahkan air secukupnya dan masak sampai kuah mendidih."
- "Setelah kuah mendidih, tambahkan larutan air asam Jawa, santan instan, gula dan garam. Masukkan juga cabai rawit dan potongan tomat. Aduk-aduk sampai mendidih kembali."
- "Koreksi rasa apakah sudah sesuai dengan selera. Bila sudah, tunggu sampai kuah menyusut dan mengental."
- "Ayam Bumbu Rujak siap disajikan"
categories:
- Recipe
tags:
- ayam
- bumbu
- rujak

katakunci: ayam bumbu rujak 
nutrition: 147 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Bumbu Rujak](https://img-global.cpcdn.com/recipes/ea26fce764a20afd/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang harus kita jaga karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam bumbu rujak yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan ciri khas yang merupakan keragaman Nusantara

Kedekatan keluarga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Ayam Bumbu Rujak untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang dapat anda buat salah satunya ayam bumbu rujak yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep ayam bumbu rujak tanpa harus bersusah payah.
Berikut ini resep Ayam Bumbu Rujak yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 19 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Bumbu Rujak:

1. Tambah 1/2 ekor ayam
1. Jangan lupa 1 buah serai
1. Tambah 1 ruas lengkuas
1. Siapkan 2 lembar daun salam
1. Diperlukan 4 lembar daun jeruk
1. Tambah 1 ruas jahe
1. Diperlukan Secukupnya gula dan garam
1. Siapkan 100 ml Larutan Air Asam Jawa
1. Tambah 1 buah tomat ukuran besar
1. Jangan lupa 10 buah cabai rawit
1. Diperlukan 1 bungkus santan instan (saya pakai Kara)
1. Diperlukan secukupnya Air
1. Harap siapkan  Bumbu Halus:
1. Siapkan 7 siung bawang merah
1. Diperlukan 5 siung bawang putih
1. Siapkan 4 butir kemiri
1. Dibutuhkan 5 buah cabai merah
1. Siapkan 1 ruas Kunyit
1. Tambah 1/2 sdt ketumbar bubuk




<!--inarticleads2-->

##### Langkah membuat  Ayam Bumbu Rujak:

1. Cuci bersih ayam, kemudian tiriskan.
1. Blender bumbu sampai halus. Kemudian geprek serei, lengkuas dan jahe.
1. Tumis bumbu halus dengan sedikit minyak sampai wangi. Setelah wangi masukkan serei, lengkuas, dan jahe yang telah di geprek. Aduk-aduk sebentar lalu masukkan daun salam dan daun jeruk.
1. Setelah itu masukkan ayam. Tambahkan air secukupnya dan masak sampai kuah mendidih.
1. Setelah kuah mendidih, tambahkan larutan air asam Jawa, santan instan, gula dan garam. Masukkan juga cabai rawit dan potongan tomat. Aduk-aduk sampai mendidih kembali.
1. Koreksi rasa apakah sudah sesuai dengan selera. Bila sudah, tunggu sampai kuah menyusut dan mengental.
1. Ayam Bumbu Rujak siap disajikan




Demikianlah cara membuat ayam bumbu rujak yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
