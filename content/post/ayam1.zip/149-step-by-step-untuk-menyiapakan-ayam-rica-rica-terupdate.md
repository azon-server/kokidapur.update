---
description: "Step-by-Step untuk menyiapakan Ayam Rica Rica terupdate"
title: "Step-by-Step untuk menyiapakan Ayam Rica Rica terupdate"
slug: 149-step-by-step-untuk-menyiapakan-ayam-rica-rica-terupdate
date: 2020-11-18T06:36:38.976Z
image: https://img-global.cpcdn.com/recipes/c8eaf65a4d30f698/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c8eaf65a4d30f698/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c8eaf65a4d30f698/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Larry Lee
ratingvalue: 4
reviewcount: 17025
recipeingredient:
- "500 gr daging ayam"
- "1/2 tsp kunyit bubuk"
- "1/2 tsp garam"
- " Bumbu rempah"
- "2 lbr daun salam"
- "2 lbr daun jeruk"
- "1 btg sereh geprek"
- "1 ruas lengkuas iris"
- "1 btg daun bawang iris"
- "Secukupnya kemangi optional"
- "1 tsp garam"
- "1 tsp kaldu bubuk"
- "400 ml air"
- "Sejumput gula pasir"
- " Bumbu halus"
- "6 siung bw merah"
- "3 siung bw putih"
- "2 btr kemiri sangrai"
- "1/2 ruas jari jahe"
- "15 bh cabe merah"
- "8 bh cabe rawit"
recipeinstructions:
- "Bersihkan daging ayam, tambahkan garam dan kunyit bubuk (kunyit dihaluskan) aduk rata kemudian marinate selama 15 menit agar bumbu meresap lalu goreng hingga matang, angkat dan tiriskan"
- "Panaskan minyak, masukkan bumbu yang sudah dihaluskan (tidak usah terlalu halus) lalu masukkan bumbu rempah, tumis bumbu hingga matang"
- "Tambahkan air lalu masukkan ayam yang sudah digoreng, tambahkan garam, kaldu bubuk, merica dan gula pasir kemudian aduk rata dan masak hingga matang (bumbu menyerap ke daging ayam)"
- "Setelah air dan bumbu menyusut tambahkan daun bawang dan kemangi aduk rata sebentar lalu sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 275 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/c8eaf65a4d30f698/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica rica yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa ciri khas yang merupakan keragaman Indonesia



Kehangatan keluarga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica Rica untuk orang di rumah. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang dapat anda contoh salah satunya ayam rica rica yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 21 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica:

1. Diperlukan 500 gr daging ayam
1. Jangan lupa 1/2 tsp kunyit bubuk
1. Dibutuhkan 1/2 tsp garam
1. Tambah  Bumbu rempah:
1. Harap siapkan 2 lbr daun salam
1. Harus ada 2 lbr daun jeruk
1. Tambah 1 btg sereh (geprek)
1. Harus ada 1 ruas lengkuas (iris)
1. Harus ada 1 btg daun bawang (iris)
1. Jangan lupa Secukupnya kemangi (optional)
1. Jangan lupa 1 tsp garam
1. Harap siapkan 1 tsp kaldu bubuk
1. Dibutuhkan 400 ml air
1. Jangan lupa Sejumput gula pasir
1. Diperlukan  Bumbu halus:
1. Jangan lupa 6 siung bw merah
1. Dibutuhkan 3 siung bw putih
1. Harap siapkan 2 btr kemiri (sangrai)
1. Jangan lupa 1/2 ruas jari jahe
1. Dibutuhkan 15 bh cabe merah
1. Tambah 8 bh cabe rawit




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Rica:

1. Bersihkan daging ayam, tambahkan garam dan kunyit bubuk (kunyit dihaluskan) aduk rata kemudian marinate selama 15 menit agar bumbu meresap lalu goreng hingga matang, angkat dan tiriskan
1. Panaskan minyak, masukkan bumbu yang sudah dihaluskan (tidak usah terlalu halus) lalu masukkan bumbu rempah, tumis bumbu hingga matang
1. Tambahkan air lalu masukkan ayam yang sudah digoreng, tambahkan garam, kaldu bubuk, merica dan gula pasir kemudian aduk rata dan masak hingga matang (bumbu menyerap ke daging ayam)
1. Setelah air dan bumbu menyusut tambahkan daun bawang dan kemangi aduk rata sebentar lalu sajikan




Demikianlah cara membuat ayam rica rica yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan terbukti, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
