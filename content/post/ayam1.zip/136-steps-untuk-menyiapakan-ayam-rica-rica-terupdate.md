---
description: "Steps untuk menyiapakan Ayam rica-rica terupdate"
title: "Steps untuk menyiapakan Ayam rica-rica terupdate"
slug: 136-steps-untuk-menyiapakan-ayam-rica-rica-terupdate
date: 2020-08-27T02:51:27.481Z
image: https://img-global.cpcdn.com/recipes/15c067e66b7bb173/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/15c067e66b7bb173/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/15c067e66b7bb173/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Eleanor Lambert
ratingvalue: 4.2
reviewcount: 38891
recipeingredient:
- "1/2 ekor ayam"
- "1 batang serai"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 ruas lengkuas dimemarkan"
- " Bumbu halus"
- "8 buah cabe merah"
- "10 buah cabe rawit"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "2 butir kemiri"
- " Bahan ungkep ayam bumbu racik instan"
- "1 sdt garam"
- "1 sdt gula pasir"
- "1 sdt kaldu bubukpenyedap"
- "2 ikat daun kemangi ambil daunnya"
- "500 ml air"
- " Minyak untuk goreng"
recipeinstructions:
- "Cuci bersih ayam yg telah dipotong,lalu marinasi ayam dengan bumbu racik instan diamkan selama 10-15 menit.panaskan minyak dalam wajan lalu goreng ayam hingga matang.sisihkan"
- "Panaskan sedikit minyak bekas menggoreng ayam tadi lalu tumis bumbu halus masukkan daun salam,daun jeruk,sereh,&amp; lengkuas masak hingga bumbu benar2 matang &amp; tercium harum"
- "Setelah bumbu matang masukkan ayam goreng tadi aduk rata dengan bumbu lalu tambahkan air.masak hingga air mendidih lalu beri garam,gula,&amp; kaldu bubuk/penyedap (optinal) aduk rata kembali masak hingga air menyusut dan bumbu meresap ke dalam ayam tes rasa."
- "Sesaat sebelum dimatikan kompor &amp; ayam sudah matang masukkan daun kemangi aduk2 sebentar saja agar tetap segar lalu matikan api.sajikan ayam selagi hangat bersama nasi putih hangat."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 203 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT60M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam rica-rica](https://img-global.cpcdn.com/recipes/15c067e66b7bb173/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica-rica yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan ciri khas yang merupakan keragaman Kita

Resep Ayam Rica Rica Bahan: Daging Ayam Lemon juice Chicken powder Garam. Bawang merah Bawang putih Cabe Jahe Serai Daun jeruk purut Daun kucai. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica.

Kedekatan keluarga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam rica-rica untuk orang di rumah. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang dapat anda buat salah satunya ayam rica-rica yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya sekarang ini anda bisa dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica:

1. Tambah 1/2 ekor ayam
1. Siapkan 1 batang serai
1. Harus ada 2 lembar daun salam
1. Siapkan 3 lembar daun jeruk
1. Dibutuhkan 1 ruas lengkuas dimemarkan
1. Diperlukan  Bumbu halus:
1. Dibutuhkan 8 buah cabe merah
1. Tambah 10 buah cabe rawit
1. Tambah 8 siung bawang merah
1. Harap siapkan 4 siung bawang putih
1. Siapkan 1 ruas jahe
1. Siapkan 1 ruas kunyit
1. Dibutuhkan 2 butir kemiri
1. Tambah  Bahan ungkep ayam: bumbu racik (instan)
1. Jangan lupa 1 sdt garam
1. Dibutuhkan 1 sdt gula pasir
1. Harus ada 1 sdt kaldu bubuk/penyedap
1. Harap siapkan 2 ikat daun kemangi ambil daunnya
1. Tambah 500 ml air
1. Siapkan  Minyak untuk goreng


Cara pembuatan ayam rica-rica tidaklah sulit. Dibutuhkan bahan-bahan seperti daun jeruk, serai, dan daun pandan agar aromanya menjadi kuat dan khas. Tak hanya ayam, anda juga bisa memasak. Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. 

<!--inarticleads2-->

##### Instruksi membuat  Ayam rica-rica:

1. Cuci bersih ayam yg telah dipotong,lalu marinasi ayam dengan bumbu racik instan diamkan selama 10-15 menit.panaskan minyak dalam wajan lalu goreng ayam hingga matang.sisihkan
1. Panaskan sedikit minyak bekas menggoreng ayam tadi lalu tumis bumbu halus masukkan daun salam,daun jeruk,sereh,&amp; lengkuas masak hingga bumbu benar2 matang &amp; tercium harum
1. Setelah bumbu matang masukkan ayam goreng tadi aduk rata dengan bumbu lalu tambahkan air.masak hingga air mendidih lalu beri garam,gula,&amp; kaldu bubuk/penyedap (optinal) aduk rata kembali masak hingga air menyusut dan bumbu meresap ke dalam ayam tes rasa.
1. Sesaat sebelum dimatikan kompor &amp; ayam sudah matang masukkan daun kemangi aduk2 sebentar saja agar tetap segar lalu matikan api.sajikan ayam selagi hangat bersama nasi putih hangat.


Tak hanya ayam, anda juga bisa memasak. Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. I really don&#39;t know how it was started but if you take away chili peppers from my life… I&#39;m gone! Chef S Table Ayam Rica Rica. Mukbang Nasi Sama Soup Dan Ayam Rica Makanenakindonesia. 

Demikianlah cara membuat ayam rica-rica yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
