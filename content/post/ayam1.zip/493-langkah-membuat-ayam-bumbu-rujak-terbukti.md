---
description: "Langkah membuat Ayam bumbu rujak Terbukti"
title: "Langkah membuat Ayam bumbu rujak Terbukti"
slug: 493-langkah-membuat-ayam-bumbu-rujak-terbukti
date: 2020-12-23T04:49:15.319Z
image: https://img-global.cpcdn.com/recipes/5b6c78bf803538c0/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5b6c78bf803538c0/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5b6c78bf803538c0/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
author: Chris Rogers
ratingvalue: 4.6
reviewcount: 43683
recipeingredient:
- "4 ekor paha ayam bisa di ganti bagian ayam sesuai selera"
- "1 batang serai"
- "4 lembar daun jeruk"
- "4 lembar daun salam"
- "1 helai daun pandan"
- "250 ml santan cair"
- "1000 ml air  kalo kurang bisa di tambah"
- "4 sdm gula bisa di tambah"
- "1 sdm garam bisa di tambah"
- " Minyak untuk menumis"
- "2 lembar daun pisang opsi bisa pake bisa enggak"
- " BUMBU HALUS"
- "4 siung bawang merah"
- "4 siung bawang putih"
- "5 cabe merah besar"
- "5 cabe merah kecil"
- "1 sdm terasi"
- "2 sdm ketumbar"
- "3 butir kemiri"
- "1 inci lengkuas"
- "1 buah tomat"
- "Sedikit air"
recipeinstructions:
- "Cuci bersih paha ayam lalu sisihkan"
- "Blender halus bumbu yaitu bawang merah, bawang putih, kemiri, ketumbar, lengkuas, cabe merah besar dan kecil lalu tomat dan tambahkan sedikit air lalu blender sampai halus, setelah halus sisihkan"
- "Panaskan minyak, setelah minyak panas masukan bumbu blender halus lalu aduk aduk,"
- "Lalu masukan serai yg sudah di geprek, daun salam, daun jeruk dan daun pandan yg sudah di simpulkan lalu aduk sampai semua tercampur rata dan tumis bumbu sampai bumbu matang"
- "Setelah bumbu matang, selanjutnya masukan paha ayam nya lalu aduk sampai semua tercampur rata dengan bumbu"
- "Setelah tercampur rata lalu tambahkan santan cair lalu aduk kembali agar santan tidak pecah"
- "Setelah itu tambahkan air biasa, lalu aduk kembali dan tambahkan garam dan gula lalu aduk kembali dan biyarkan air mendidih dan meresap"
- "Jangan lupa sesekali icip rasa dan aduk lalu biyarkan air nya meresap"
- "Setelah air meresap dan rasanya pas lalu angkat panci nya dan sisihkan"
- "Selanjutnya panaskan teflon krn di sini aku punya daun pisang jadi aku alasi atas teflon dengan daun pisang ini opsi aja bisa pake apa gak karena aku suka aja bau daun pisang,"
- "Setelah teflon panas selanjutnya masukan paha ayam nya lalu bakar sesuai warna yg di inginkan, jangan lupa di bolak balik agar warna kematangan nya lebih merata dan jangan lupa olesi dengan bumbu sisa ayam nya tadi, kalo sudah pas rasanya angkat dan hidangkan"
- "Ayam bumbu rujak siap di makan, cocok pake nasi putih enak banget, selamat mencoba"
categories:
- Recipe
tags:
- ayam
- bumbu
- rujak

katakunci: ayam bumbu rujak 
nutrition: 156 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam bumbu rujak](https://img-global.cpcdn.com/recipes/5b6c78bf803538c0/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang harus kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam bumbu rujak yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan keistimewahan yang merupakan keragaman Indonesia



Kehangatan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah memasak Ayam bumbu rujak untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang bisa anda contoh salah satunya ayam bumbu rujak yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam bumbu rujak tanpa harus bersusah payah.
Berikut ini resep Ayam bumbu rujak yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 12 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam bumbu rujak:

1. Siapkan 4 ekor paha ayam (bisa di ganti bagian ayam sesuai selera)
1. Harus ada 1 batang serai
1. Harus ada 4 lembar daun jeruk
1. Harus ada 4 lembar daun salam
1. Siapkan 1 helai daun pandan
1. Dibutuhkan 250 ml santan cair
1. Tambah 1000 ml air ( kalo kurang bisa di tambah
1. Siapkan 4 sdm gula (bisa di tambah)
1. Jangan lupa 1 sdm garam (bisa di tambah)
1. Jangan lupa  Minyak untuk menumis
1. Harus ada 2 lembar daun pisang (opsi bisa pake bisa enggak)
1. Dibutuhkan  ●BUMBU HALUS
1. Harap siapkan 4 siung bawang merah
1. Harus ada 4 siung bawang putih
1. Siapkan 5 cabe merah besar
1. Harap siapkan 5 cabe merah kecil
1. Dibutuhkan 1 sdm terasi
1. Tambah 2 sdm ketumbar
1. Siapkan 3 butir kemiri
1. Siapkan 1 inci lengkuas
1. Dibutuhkan 1 buah tomat
1. Diperlukan Sedikit air




<!--inarticleads2-->

##### Langkah membuat  Ayam bumbu rujak:

1. Cuci bersih paha ayam lalu sisihkan
1. Blender halus bumbu yaitu bawang merah, bawang putih, kemiri, ketumbar, lengkuas, cabe merah besar dan kecil lalu tomat dan tambahkan sedikit air lalu blender sampai halus, setelah halus sisihkan
1. Panaskan minyak, setelah minyak panas masukan bumbu blender halus lalu aduk aduk,
1. Lalu masukan serai yg sudah di geprek, daun salam, daun jeruk dan daun pandan yg sudah di simpulkan lalu aduk sampai semua tercampur rata dan tumis bumbu sampai bumbu matang
1. Setelah bumbu matang, selanjutnya masukan paha ayam nya lalu aduk sampai semua tercampur rata dengan bumbu
1. Setelah tercampur rata lalu tambahkan santan cair lalu aduk kembali agar santan tidak pecah
1. Setelah itu tambahkan air biasa, lalu aduk kembali dan tambahkan garam dan gula lalu aduk kembali dan biyarkan air mendidih dan meresap
1. Jangan lupa sesekali icip rasa dan aduk lalu biyarkan air nya meresap
1. Setelah air meresap dan rasanya pas lalu angkat panci nya dan sisihkan
1. Selanjutnya panaskan teflon krn di sini aku punya daun pisang jadi aku alasi atas teflon dengan daun pisang ini opsi aja bisa pake apa gak karena aku suka aja bau daun pisang,
1. Setelah teflon panas selanjutnya masukan paha ayam nya lalu bakar sesuai warna yg di inginkan, jangan lupa di bolak balik agar warna kematangan nya lebih merata dan jangan lupa olesi dengan bumbu sisa ayam nya tadi, kalo sudah pas rasanya angkat dan hidangkan
1. Ayam bumbu rujak siap di makan, cocok pake nasi putih enak banget, selamat mencoba




Demikianlah cara membuat ayam bumbu rujak yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan teruji, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
