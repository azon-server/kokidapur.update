---
description: "Steps membuat Ayam rica kemangi Teruji"
title: "Steps membuat Ayam rica kemangi Teruji"
slug: 109-steps-membuat-ayam-rica-kemangi-teruji
date: 2020-09-22T04:13:04.863Z
image: https://img-global.cpcdn.com/recipes/72224a535d4e7bf4/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/72224a535d4e7bf4/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/72224a535d4e7bf4/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Christopher Berry
ratingvalue: 4.5
reviewcount: 3572
recipeingredient:
- "1/2 ekor ayam"
- "2 iket kemangi"
- "7 siung bawang merah"
- "3 siung bawang putih"
- "2 buah cabai merah"
- "11 buah cabai rawit  sesuai selera"
- "2 keping kemiri"
- "1/2 ruas kunyit"
- "1/2 ruas jahe"
- "1 ruas lengkuas geprek"
- "2 batang serai geprek"
- "4 lembar daun jeruk buang batang"
- "secukupnya Gula garam  penyedap rasa"
- "secukupnya Air sisa rebusan ayam  air masak ya"
recipeinstructions:
- "Potong ayam jadi beberapa bagian (sesuai selera ya ukurannya) lalu rebus sampai empuk, sisa air rebusan jgn dibuang ya buat kaldu"
- "Setelah empuk tiriskan ayam lalu goreng setengah matang ya..."
- "Ulek / blender semua bumbu kecuali lengkuas, serai dan daun jeruk yah"
- "Panaskan minyak lalu tumis bumbu yang sudah di haluskan,masukkan serai,lengkuas dan daun jeruk (robek dlu yah biar lbh wangi) aduk sampai tanak"
- "Setelah harum, masukkan air rebusan ayam secukupnya, tunggu mendidih"
- "Masukkan ayam yang sudah di goreng setengah matang tadi, beri gula,garam dan penyedap rasa secukupnya (test rasa)"
- "Ungkep sebentar smpai bumbu menyusut lalu masukkan kemangi.. Aduk sebentar lalu angkat.."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 235 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/72224a535d4e7bf4/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang patut kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica kemangi yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan ciri khas yang merupakan keragaman Indonesia



Kedekatan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah memasak Ayam rica kemangi untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang dapat anda contoh salah satunya ayam rica kemangi yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 14 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi:

1. Harus ada 1/2 ekor ayam
1. Diperlukan 2 iket kemangi
1. Dibutuhkan 7 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Harap siapkan 2 buah cabai merah
1. Harap siapkan 11 buah cabai rawit / sesuai selera
1. Siapkan 2 keping kemiri
1. Tambah 1/2 ruas kunyit
1. Harap siapkan 1/2 ruas jahe
1. Siapkan 1 ruas lengkuas geprek
1. Tambah 2 batang serai geprek
1. Harus ada 4 lembar daun jeruk buang batang
1. Harus ada secukupnya Gula, garam &amp; penyedap rasa
1. Diperlukan secukupnya Air sisa rebusan ayam / air masak ya




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica kemangi:

1. Potong ayam jadi beberapa bagian (sesuai selera ya ukurannya) lalu rebus sampai empuk, sisa air rebusan jgn dibuang ya buat kaldu
1. Setelah empuk tiriskan ayam lalu goreng setengah matang ya...
1. Ulek / blender semua bumbu kecuali lengkuas, serai dan daun jeruk yah
1. Panaskan minyak lalu tumis bumbu yang sudah di haluskan,masukkan serai,lengkuas dan daun jeruk (robek dlu yah biar lbh wangi) aduk sampai tanak
1. Setelah harum, masukkan air rebusan ayam secukupnya, tunggu mendidih
1. Masukkan ayam yang sudah di goreng setengah matang tadi, beri gula,garam dan penyedap rasa secukupnya (test rasa)
1. Ungkep sebentar smpai bumbu menyusut lalu masukkan kemangi.. Aduk sebentar lalu angkat..




Demikianlah cara membuat ayam rica kemangi yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan cepat, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
