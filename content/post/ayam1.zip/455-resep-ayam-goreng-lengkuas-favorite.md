---
description: "Resep : Ayam goreng lengkuas Favorite"
title: "Resep : Ayam goreng lengkuas Favorite"
slug: 455-resep-ayam-goreng-lengkuas-favorite
date: 2021-01-06T04:15:44.345Z
image: https://img-global.cpcdn.com/recipes/df029b1a3236bb2f/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/df029b1a3236bb2f/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/df029b1a3236bb2f/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Cora Farmer
ratingvalue: 4.8
reviewcount: 12161
recipeingredient:
- "1 kg ayam"
- "3 lembar daun salam"
- "1 batang serai"
- " lengkuas di parut"
- "4 siung bawang putih"
- "3 siung bawang merah"
- "secukupnya kunyit bubuk ketumbar bubuk kaldu ayam"
- "1 sdt garam"
recipeinstructions:
- "Cuci bersih ayam, lalu haluskan bumbu.. untuk lengkuas kadang saya geprek dulu baru diparut. karna suka keras hehe"
- "Lalu ungkep ayam, masak hingga air ungkepan menyusut."
- "Setelah ayam diungkep lalu panaskan minyak, setelah itu goreng bersama lengkuasnya.. hmm sedap"
categories:
- Recipe
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 137 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT49M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam goreng lengkuas](https://img-global.cpcdn.com/recipes/df029b1a3236bb2f/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam goreng lengkuas yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Kita



Keharmonisan keluarga bisa didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam goreng lengkuas untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang bisa anda contoh salah satunya ayam goreng lengkuas yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam goreng lengkuas tanpa harus bersusah payah.
Seperti resep Ayam goreng lengkuas yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 8 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam goreng lengkuas:

1. Jangan lupa 1 kg ayam
1. Diperlukan 3 lembar daun salam
1. Jangan lupa 1 batang serai
1. Diperlukan  lengkuas di parut
1. Harus ada 4 siung bawang putih
1. Harap siapkan 3 siung bawang merah
1. Diperlukan secukupnya kunyit bubuk, ketumbar bubuk, kaldu ayam
1. Harap siapkan 1 sdt garam




<!--inarticleads2-->

##### Langkah membuat  Ayam goreng lengkuas:

1. Cuci bersih ayam, lalu haluskan bumbu.. untuk lengkuas kadang saya geprek dulu baru diparut. karna suka keras hehe
1. Lalu ungkep ayam, masak hingga air ungkepan menyusut.
1. Setelah ayam diungkep lalu panaskan minyak, setelah itu goreng bersama lengkuasnya.. hmm sedap




Demikianlah cara membuat ayam goreng lengkuas yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan teruji, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
