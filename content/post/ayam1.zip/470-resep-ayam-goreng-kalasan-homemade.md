---
description: "Resep : Ayam Goreng Kalasan Homemade"
title: "Resep : Ayam Goreng Kalasan Homemade"
slug: 470-resep-ayam-goreng-kalasan-homemade
date: 2020-10-13T01:36:50.504Z
image: https://img-global.cpcdn.com/recipes/24ffb6a3bb99e92c/751x532cq70/ayam-goreng-kalasan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/24ffb6a3bb99e92c/751x532cq70/ayam-goreng-kalasan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/24ffb6a3bb99e92c/751x532cq70/ayam-goreng-kalasan-foto-resep-utama.jpg
author: Della Fernandez
ratingvalue: 4.4
reviewcount: 40856
recipeingredient:
- "1 ekor Ayam broilerkampung"
- " Air jeruk nipis"
- "800 ml Air kelapa"
- " Bumbu Halus"
- "1 sdm Ketumbar bubuk"
- "8 btr Bawang merah"
- "4 btr Bawang putih"
- "4 btr kemiri"
- "1 sdt kunyit bubuk"
- "2 ruas lengkuas"
- " Bumbu Pelengkap"
- "2 batang sereh geprek"
- "4 lembar daun salam"
- "6 lembar daun jeruk"
- "1 sdt Garam"
- "Secukupnya Gula pasirGula merah"
- "Secukupnya totolepenyedap rasa"
recipeinstructions:
- "Siapkan bahan. Lumuri Ayam dengan air jeruk nipis. Diamkan 10-15 menit. Bilas"
- "Haluskan bumbu halus kemudian tumis bumbu halus dengan sereh, daun Salam, dan daun jeruk hingga harum."
- "Masukkan air kelapa, masak hingga mendidih. Masukkan Ayam, garam, gula dan totole.koreksi rasa. Masak hingga Ayam empuk. Kalo air habis tapi Ayam belum empuk, tambahkan air lagi ya. Pakai air biasa saja kalo air kelapa habis."
- "Setelah Ayam empuk, angkat sisihkan. Biarkan dingin. Goreng ayam hingga berwarna kuning keemasan dengan api sedang. Sajikan bersama sambal Ayam Goreng kalasan. 🥰🥰🥰           (lihat resep)"
categories:
- Recipe
tags:
- ayam
- goreng
- kalasan

katakunci: ayam goreng kalasan 
nutrition: 275 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Goreng Kalasan](https://img-global.cpcdn.com/recipes/24ffb6a3bb99e92c/751x532cq70/ayam-goreng-kalasan-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas atau renyah. Ciri makanan Indonesia ayam goreng kalasan yang penuh dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan rumah tangga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam Goreng Kalasan untuk keluarga. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang bisa anda buat salah satunya ayam goreng kalasan yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep ayam goreng kalasan tanpa harus bersusah payah.
Berikut ini resep Ayam Goreng Kalasan yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Kalasan:

1. Harap siapkan 1 ekor Ayam broiler/kampung
1. Harap siapkan  Air jeruk nipis
1. Diperlukan 800 ml Air kelapa
1. Diperlukan  Bumbu Halus
1. Dibutuhkan 1 sdm Ketumbar bubuk
1. Harus ada 8 btr Bawang merah
1. Jangan lupa 4 btr Bawang putih
1. Harus ada 4 btr kemiri
1. Jangan lupa 1 sdt kunyit bubuk
1. Diperlukan 2 ruas lengkuas
1. Dibutuhkan  Bumbu Pelengkap
1. Siapkan 2 batang sereh geprek
1. Siapkan 4 lembar daun salam
1. Dibutuhkan 6 lembar daun jeruk
1. Dibutuhkan 1 sdt Garam
1. Harus ada Secukupnya Gula pasir/Gula merah
1. Dibutuhkan Secukupnya totole/penyedap rasa




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Kalasan:

1. Siapkan bahan. Lumuri Ayam dengan air jeruk nipis. Diamkan 10-15 menit. Bilas
1. Haluskan bumbu halus kemudian tumis bumbu halus dengan sereh, daun Salam, dan daun jeruk hingga harum.
1. Masukkan air kelapa, masak hingga mendidih. Masukkan Ayam, garam, gula dan totole.koreksi rasa. Masak hingga Ayam empuk. Kalo air habis tapi Ayam belum empuk, tambahkan air lagi ya. Pakai air biasa saja kalo air kelapa habis.
1. Setelah Ayam empuk, angkat sisihkan. Biarkan dingin. Goreng ayam hingga berwarna kuning keemasan dengan api sedang. Sajikan bersama sambal Ayam Goreng kalasan. 🥰🥰🥰 -           (lihat resep)




Demikianlah cara membuat ayam goreng kalasan yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
