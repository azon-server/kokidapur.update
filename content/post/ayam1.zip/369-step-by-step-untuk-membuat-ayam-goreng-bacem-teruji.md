---
description: "Step-by-Step untuk membuat Ayam Goreng Bacem Teruji"
title: "Step-by-Step untuk membuat Ayam Goreng Bacem Teruji"
slug: 369-step-by-step-untuk-membuat-ayam-goreng-bacem-teruji
date: 2020-12-18T00:13:02.346Z
image: https://img-global.cpcdn.com/recipes/dd1849ecd5f9015a/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dd1849ecd5f9015a/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dd1849ecd5f9015a/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg
author: William Ward
ratingvalue: 4.3
reviewcount: 19488
recipeingredient:
- "500 gr paha ayam"
- "2 lembar daun salam"
- "4 lembar daun jeruk"
- "1 batang serai"
- "2 cm lengkuas"
- "1 keping gula merah"
- "1 sdm garam"
- "5 sdm kecap manis"
- "600 ml air"
- "8 buah tahu tambahan"
- " Bumbu yang dihaluskan "
- "1 sdm ketumbar"
- "4 butir kemiri"
- "6 siung bawang putih"
- "1 cm jahe"
- "1 cm kencur"
recipeinstructions:
- "Cuci bersih paha ayam, lau siapkan bumbu. Haluskan bawang putih, ketumbar, kemiri, jahe dan kencur, saya haluskan menggunakan bkender."
- "Lalu masukkan bumbu yang tadi sudah diblender, tambahkan daun salam, serai, daun jeruk, gula merah, garam dan air, masak hingga mendidih."
- "Lalu masukkan paha ayam, dan beri kecap, aduk rata lalu cicipi, kemudian masukkan tahu, tutup wajan."
- "Masak hingga ayam matang dan kuah menyusut, matikan api, diamkan hingga dingin, karena untuk lauk tumpeng keesokkan harinya, maka ayam dan tahu saya masukkan kedalam wadah tertutup, lalu simpam dikulkas, untuk digoreng besok disajikan bersama tumpeng, jika akan digunakan untuk lauk tumpeng, goreng sebentar hingga kecoklatan."
categories:
- Recipe
tags:
- ayam
- goreng
- bacem

katakunci: ayam goreng bacem 
nutrition: 261 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Goreng Bacem](https://img-global.cpcdn.com/recipes/dd1849ecd5f9015a/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam goreng bacem yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Nusantara



Kehangatan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Ayam Goreng Bacem untuk keluarga. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang bisa anda buat salah satunya ayam goreng bacem yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam goreng bacem tanpa harus bersusah payah.
Seperti resep Ayam Goreng Bacem yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Bacem:

1. Jangan lupa 500 gr paha ayam
1. Diperlukan 2 lembar daun salam
1. Diperlukan 4 lembar daun jeruk
1. Harap siapkan 1 batang serai
1. Harap siapkan 2 cm lengkuas
1. Diperlukan 1 keping gula merah
1. Tambah 1 sdm garam
1. Harap siapkan 5 sdm kecap manis
1. Jangan lupa 600 ml air
1. Jangan lupa 8 buah tahu (tambahan)
1. Siapkan  Bumbu yang dihaluskan :
1. Harus ada 1 sdm ketumbar
1. Harus ada 4 butir kemiri
1. Dibutuhkan 6 siung bawang putih
1. Tambah 1 cm jahe
1. Harap siapkan 1 cm kencur




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Bacem:

1. Cuci bersih paha ayam, lau siapkan bumbu. Haluskan bawang putih, ketumbar, kemiri, jahe dan kencur, saya haluskan menggunakan bkender.
1. Lalu masukkan bumbu yang tadi sudah diblender, tambahkan daun salam, serai, daun jeruk, gula merah, garam dan air, masak hingga mendidih.
1. Lalu masukkan paha ayam, dan beri kecap, aduk rata lalu cicipi, kemudian masukkan tahu, tutup wajan.
1. Masak hingga ayam matang dan kuah menyusut, matikan api, diamkan hingga dingin, karena untuk lauk tumpeng keesokkan harinya, maka ayam dan tahu saya masukkan kedalam wadah tertutup, lalu simpam dikulkas, untuk digoreng besok disajikan bersama tumpeng, jika akan digunakan untuk lauk tumpeng, goreng sebentar hingga kecoklatan.




Demikianlah cara membuat ayam goreng bacem yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan teruji, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
