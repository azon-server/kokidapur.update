---
description: "Cara singkat untuk membuat Ayam Goreng Lengkuas Kremes teraktual"
title: "Cara singkat untuk membuat Ayam Goreng Lengkuas Kremes teraktual"
slug: 289-cara-singkat-untuk-membuat-ayam-goreng-lengkuas-kremes-teraktual
date: 2020-12-05T02:32:21.306Z
image: https://img-global.cpcdn.com/recipes/d10e9ba645103df6/751x532cq70/ayam-goreng-lengkuas-kremes-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d10e9ba645103df6/751x532cq70/ayam-goreng-lengkuas-kremes-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d10e9ba645103df6/751x532cq70/ayam-goreng-lengkuas-kremes-foto-resep-utama.jpg
author: Ruby Banks
ratingvalue: 4.2
reviewcount: 32839
recipeingredient:
- " Bahan utama"
- "1 ekor ayam potong jadi 8 "
- " Bumbu halus"
- "3 siung bawang putih"
- "4 siung bawang merah"
- "1 butir kemiri lebih juga boleh"
- "2 cm jahe"
- "1/2 sdt kunyit bubuk"
- "1/2 sdt garam"
- "1/2 sdt lada"
- " Bahan lainnya"
- "2 batang serai"
- "3 lembar daun jeruk daun salam jg bs"
- "2 cm lengkuas parut"
- "1 sdm minyak kelapa utk menumis"
- "100 ml kaldu ayam lihat resep saya"
- "250 ml minyak goreng"
- " Pelengkap"
- "5 lembar daun selada"
- "1 piring nasi merah"
recipeinstructions:
- "Siapkan bahan. Cuci bersih ayam, haluskan bumbu menggunakan uleg."
- "Tuang minyak kelapa, tumis bumbu halus hingga harum. Tambahkan serai, daun jeruk, dan lengkuas parut. Masukkan ayam dan kaldu, masak 10 menit hingga bumbu meresap."
- "Setelah bumbu meresap, Anda bisa menyimpan dalam kulkas jadi bisa di goreng kapan saja. Goreng dengan api kecil selama 10 menit. Sajikan dengan nasi merah. Enjoyed my lunch. So yummy 🤤"
categories:
- Recipe
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 271 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Goreng Lengkuas Kremes](https://img-global.cpcdn.com/recipes/d10e9ba645103df6/751x532cq70/ayam-goreng-lengkuas-kremes-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga empuk. Ciri masakan Nusantara ayam goreng lengkuas kremes yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kedekatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Goreng Lengkuas Kremes untuk orang di rumah. Momen makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang dapat anda contoh salah satunya ayam goreng lengkuas kremes yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep ayam goreng lengkuas kremes tanpa harus bersusah payah.
Seperti resep Ayam Goreng Lengkuas Kremes yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Lengkuas Kremes:

1. Harap siapkan  Bahan utama:
1. Siapkan 1 ekor ayam (potong jadi 8) 🐓
1. Dibutuhkan  Bumbu halus:
1. Jangan lupa 3 siung bawang putih
1. Tambah 4 siung bawang merah
1. Harus ada 1 butir kemiri (lebih juga boleh)
1. Siapkan 2 cm jahe
1. Jangan lupa 1/2 sdt kunyit bubuk
1. Siapkan 1/2 sdt garam
1. Tambah 1/2 sdt lada
1. Dibutuhkan  Bahan lainnya:
1. Jangan lupa 2 batang serai
1. Harap siapkan 3 lembar daun jeruk (daun salam jg bs)
1. Harus ada 2 cm lengkuas (parut)
1. Jangan lupa 1 sdm minyak kelapa utk menumis
1. Harap siapkan 100 ml kaldu ayam (lihat resep saya)
1. Siapkan 250 ml minyak goreng
1. Siapkan  Pelengkap:
1. Harap siapkan 5 lembar daun selada
1. Tambah 1 piring nasi merah




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Goreng Lengkuas Kremes:

1. Siapkan bahan. Cuci bersih ayam, haluskan bumbu menggunakan uleg.
1. Tuang minyak kelapa, tumis bumbu halus hingga harum. Tambahkan serai, daun jeruk, dan lengkuas parut. Masukkan ayam dan kaldu, masak 10 menit hingga bumbu meresap.
1. Setelah bumbu meresap, Anda bisa menyimpan dalam kulkas jadi bisa di goreng kapan saja. Goreng dengan api kecil selama 10 menit. Sajikan dengan nasi merah. Enjoyed my lunch. So yummy 🤤




Demikianlah cara membuat ayam goreng lengkuas kremes yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
