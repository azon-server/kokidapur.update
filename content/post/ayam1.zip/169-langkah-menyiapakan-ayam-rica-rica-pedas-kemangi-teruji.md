---
description: "Langkah menyiapakan Ayam Rica-rica Pedas Kemangi Teruji"
title: "Langkah menyiapakan Ayam Rica-rica Pedas Kemangi Teruji"
slug: 169-langkah-menyiapakan-ayam-rica-rica-pedas-kemangi-teruji
date: 2020-12-01T07:58:11.543Z
image: https://img-global.cpcdn.com/recipes/0fbe6bc28195c770/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0fbe6bc28195c770/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0fbe6bc28195c770/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
author: Katie Mullins
ratingvalue: 5
reviewcount: 40923
recipeingredient:
- "1/2 ekor ayam yg sudah direbus dan dipotong sesuai selera tanpa direbus juga boleh"
- "3 lembar daun salam"
- "3 lembar daun jeruk purut"
- "2 batang serai geprek"
- "5 cm lengkuas geprek"
- "1 genggam daunh kemangi"
- "1 lembar daun kunyit"
- "1 batang daun bawang"
- " Bumbu halus "
- "7 siung bawang merah"
- "3 siung bawang putih"
- "6 cm kunyit"
- "6 cm jahe"
- "4 butir kemiri sangrai"
- "1 sdm ketumbar sangrai"
- " Cabe rawit secukupnya bisa banyak bila mau pedes banget"
- "2 buah tomat"
- "500 ml air masak"
- " Minyak goreng utk menumis bumbu"
- "sesuai selera Garam dan penyedap rasa ayam"
recipeinstructions:
- "Siapkan semua bumbu. Ayam saya rebus sekitaran 10 menit dan tiriskan lalu potong sesuai selera. Ketumbar dan kemiri saya sangrai dan tumbuk. Kemudian bumbu halus saya blender."
- "Tumis bumbu hingga wangi dan berubah warna, masukan ayam dan aduk sebentar. Kemudian tuang air hingga menutupi ayam dan beri garam dan penyedap rasa. Aduk hingga rata dan diamkan sekitar 5 menit. Kemudian masukan kemangi, daun kunyit, dan daun bawang. Masak hingga air menyusut."
- "Masukan tomat dan aduk sebentar dan koreksi rasa. Setelah matang dan air menyusut maka ayam rica pedas kemangi siap dihidangkan."
- "Resep ini mudah banget dicobain moms. Enak deh. Dan ayam rica-rica kemangi benar nikmat dan yummy. 🥰🥰🥰🥰"
categories:
- Recipe
tags:
- ayam
- ricarica
- pedas

katakunci: ayam ricarica pedas 
nutrition: 132 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica-rica Pedas Kemangi](https://img-global.cpcdn.com/recipes/0fbe6bc28195c770/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica-rica pedas kemangi yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa keistimewahan yang merupakan keragaman Nusantara

Keharmonisan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica-rica Pedas Kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang bisa anda praktekkan salah satunya ayam rica-rica pedas kemangi yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam rica-rica pedas kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Pedas Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 20 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Pedas Kemangi:

1. Tambah 1/2 ekor ayam yg sudah direbus dan dipotong sesuai selera (tanpa direbus juga boleh)
1. Harus ada 3 lembar daun salam
1. Siapkan 3 lembar daun jeruk purut
1. Dibutuhkan 2 batang serai geprek
1. Harap siapkan 5 cm lengkuas, geprek
1. Jangan lupa 1 genggam daunh kemangi
1. Dibutuhkan 1 lembar daun kunyit
1. Siapkan 1 batang daun bawang
1. Jangan lupa  Bumbu halus :
1. Siapkan 7 siung bawang merah
1. Dibutuhkan 3 siung bawang putih
1. Tambah 6 cm kunyit
1. Harap siapkan 6 cm jahe
1. Siapkan 4 butir kemiri sangrai
1. Siapkan 1 sdm ketumbar sangrai
1. Dibutuhkan  Cabe rawit secukupnya (bisa banyak bila mau pedes banget)
1. Harus ada 2 buah tomat
1. Jangan lupa 500 ml air masak
1. Diperlukan  Minyak goreng utk menumis bumbu
1. Jangan lupa sesuai selera Garam dan penyedap rasa ayam




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-rica Pedas Kemangi:

1. Siapkan semua bumbu. Ayam saya rebus sekitaran 10 menit dan tiriskan lalu potong sesuai selera. Ketumbar dan kemiri saya sangrai dan tumbuk. Kemudian bumbu halus saya blender.
1. Tumis bumbu hingga wangi dan berubah warna, masukan ayam dan aduk sebentar. Kemudian tuang air hingga menutupi ayam dan beri garam dan penyedap rasa. Aduk hingga rata dan diamkan sekitar 5 menit. Kemudian masukan kemangi, daun kunyit, dan daun bawang. Masak hingga air menyusut.
1. Masukan tomat dan aduk sebentar dan koreksi rasa. Setelah matang dan air menyusut maka ayam rica pedas kemangi siap dihidangkan.
1. Resep ini mudah banget dicobain moms. Enak deh. Dan ayam rica-rica kemangi benar nikmat dan yummy. 🥰🥰🥰🥰




Demikianlah cara membuat ayam rica-rica pedas kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan terbukti, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
