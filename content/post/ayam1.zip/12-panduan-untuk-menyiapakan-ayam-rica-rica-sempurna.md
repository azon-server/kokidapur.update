---
description: "Panduan untuk menyiapakan Ayam Rica-Rica Sempurna"
title: "Panduan untuk menyiapakan Ayam Rica-Rica Sempurna"
slug: 12-panduan-untuk-menyiapakan-ayam-rica-rica-sempurna
date: 2020-09-26T00:19:59.601Z
image: https://img-global.cpcdn.com/recipes/360b274ba8751abf/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/360b274ba8751abf/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/360b274ba8751abf/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Bradley Palmer
ratingvalue: 4.9
reviewcount: 25541
recipeingredient:
- "1/2 Ekor Ayam"
- "8 Siung Bawang Merah"
- "5 Siung Bawang Putih"
- "1 Lengkuas Memarkan"
- "2 Daun jeruk  2 Daun Salam"
- "1 Sereh Memarkan"
- "3 Buah Kemiri"
- "Secukupnya Lada Bubuk"
- "Secukupnya Air"
- " Garam"
- " Gula pasir"
- " Penyedap Rasa me Kaldu Jamur Totole"
- "5 Cabe Caplak"
- "8 Cabe Merah"
- "2-3 Sdm Kecap Bango"
recipeinstructions:
- "Potong Ayam terlebih dahulu, cuci, lalu rebus hingga mendidih dan sisihkan"
- "Haluskan pakai blender bahan berikut bawang putih, bawang merah, kemiri, cabe. Lalu tumis sampai matang"
- "Masukkan ayam yang telah di rebus sebentar lalu tambahkan air secukupnya. Tambahkan garam, gula, penyedap rasa hingga air menyusut"
- "Lalu tambahkan air lagi sampai menyusut, tambahkan kecap dan masukkan lada bubuk secukupnya. Koreksi rasa"
- "Ayam Rica-Rica siap dihidangkan menggunakan nasi panas"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 227 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/360b274ba8751abf/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica-rica yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Indonesia



Kedekatan keluarga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica-Rica untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang bisa anda contoh salah satunya ayam rica-rica yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica:

1. Tambah 1/2 Ekor Ayam
1. Dibutuhkan 8 Siung Bawang Merah
1. Tambah 5 Siung Bawang Putih
1. Jangan lupa 1 Lengkuas (Memarkan)
1. Dibutuhkan 2 Daun jeruk + 2 Daun Salam
1. Dibutuhkan 1 Sereh (Memarkan)
1. Siapkan 3 Buah Kemiri
1. Harap siapkan Secukupnya Lada Bubuk
1. Jangan lupa Secukupnya Air
1. Dibutuhkan  Garam
1. Siapkan  Gula pasir
1. Dibutuhkan  Penyedap Rasa (me: Kaldu Jamur Totole)
1. Harap siapkan 5 Cabe Caplak
1. Harap siapkan 8 Cabe Merah
1. Diperlukan 2-3 Sdm Kecap Bango




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica:

1. Potong Ayam terlebih dahulu, cuci, lalu rebus hingga mendidih dan sisihkan
1. Haluskan pakai blender bahan berikut bawang putih, bawang merah, kemiri, cabe. Lalu tumis sampai matang
1. Masukkan ayam yang telah di rebus sebentar lalu tambahkan air secukupnya. Tambahkan garam, gula, penyedap rasa hingga air menyusut
1. Lalu tambahkan air lagi sampai menyusut, tambahkan kecap dan masukkan lada bubuk secukupnya. Koreksi rasa
1. Ayam Rica-Rica siap dihidangkan menggunakan nasi panas




Demikianlah cara membuat ayam rica-rica yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
