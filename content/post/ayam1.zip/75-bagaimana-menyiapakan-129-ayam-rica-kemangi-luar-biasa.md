---
description: "Bagaimana menyiapakan (1.29) Ayam Rica Kemangi Luar biasa"
title: "Bagaimana menyiapakan (1.29) Ayam Rica Kemangi Luar biasa"
slug: 75-bagaimana-menyiapakan-129-ayam-rica-kemangi-luar-biasa
date: 2020-10-02T03:22:38.651Z
image: https://img-global.cpcdn.com/recipes/55e72c9d8e7acfb6/751x532cq70/129-ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/55e72c9d8e7acfb6/751x532cq70/129-ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/55e72c9d8e7acfb6/751x532cq70/129-ayam-rica-kemangi-foto-resep-utama.jpg
author: Carolyn Simon
ratingvalue: 4.7
reviewcount: 38477
recipeingredient:
- "500 gr daging ayam fillet me SoesariRokerij potong dadu"
- "2 ikat kemangi petiki daunnya"
- "50 gr gula meraharen"
- "1 sdt garam sesuaikan selera"
- " Bumbu Cemplung"
- "1 batang sereh bag putih geprek"
- "5 lembar daun jeruk buang tulang daun"
- "10 buah cabe rawit"
- " Bumbu Halus"
- "8 buah cabe merah keriting"
- "2 buah cabe merah besar"
- "5 buah cabe rawit"
- "10 siung bawang merah"
- "4 buah bawang putih"
- "2 buah tomat"
- "2 sdt ketumbar sangrai"
- "2 sdm minyak"
recipeinstructions:
- "Tumis bumbu halus hingga harum"
- "Masukkan bumbu cemplung, masak hingga bumbu matang (berwarna lebih gelap dan harum)"
- "Masukkan ayam fillet + gula + garam, aduk rata, tes rasa, masak hingga bumbu meresap"
- "Matikan api, masukkan daun kemangi, aduk rata"
- "Sajikan"
- "Gula Aren yg digunakan"
categories:
- Recipe
tags:
- 129
- ayam
- rica

katakunci: 129 ayam rica 
nutrition: 185 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT56M"
recipeyield: "3"
recipecategory: Dinner

---


![(1.29) Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/55e72c9d8e7acfb6/751x532cq70/129-ayam-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang harus kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti (1.29) ayam rica kemangi yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Kita

Kehangatan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan (1.29) Ayam Rica Kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang bisa anda buat salah satunya (1.29) ayam rica kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep (1.29) ayam rica kemangi tanpa harus bersusah payah.
Seperti resep (1.29) Ayam Rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat (1.29) Ayam Rica Kemangi:

1. Tambah 500 gr daging ayam fillet (me: @SoesariRokerij), potong dadu
1. Jangan lupa 2 ikat kemangi, petiki daunnya
1. Diperlukan 50 gr gula merah/aren
1. Harus ada 1 sdt garam (sesuaikan selera)
1. Dibutuhkan  Bumbu Cemplung:
1. Tambah 1 batang sereh bag. putih, geprek
1. Harus ada 5 lembar daun jeruk, buang tulang daun
1. Harus ada 10 buah cabe rawit
1. Tambah  Bumbu Halus:
1. Dibutuhkan 8 buah cabe merah keriting
1. Harap siapkan 2 buah cabe merah besar
1. Siapkan 5 buah cabe rawit
1. Diperlukan 10 siung bawang merah
1. Tambah 4 buah bawang putih
1. Siapkan 2 buah tomat
1. Harus ada 2 sdt ketumbar, sangrai
1. Jangan lupa 2 sdm minyak




<!--inarticleads2-->

##### Langkah membuat  (1.29) Ayam Rica Kemangi:

1. Tumis bumbu halus hingga harum
1. Masukkan bumbu cemplung, masak hingga bumbu matang (berwarna lebih gelap dan harum)
1. Masukkan ayam fillet + gula + garam, aduk rata, tes rasa, masak hingga bumbu meresap
1. Matikan api, masukkan daun kemangi, aduk rata
1. Sajikan
1. Gula Aren yg digunakan




Demikianlah cara membuat (1.29) ayam rica kemangi yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
