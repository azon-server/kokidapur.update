---
description: "Cara singkat untuk membuat Ayam Rica Rica Kemangi Luar biasa"
title: "Cara singkat untuk membuat Ayam Rica Rica Kemangi Luar biasa"
slug: 68-cara-singkat-untuk-membuat-ayam-rica-rica-kemangi-luar-biasa
date: 2020-08-19T22:21:05.556Z
image: https://img-global.cpcdn.com/recipes/e5ec23a440247769/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e5ec23a440247769/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e5ec23a440247769/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Allie Holloway
ratingvalue: 4.5
reviewcount: 5881
recipeingredient:
- "1/2 ekor ayam kampung"
- "Segenggam daun kemangi"
- " Minyak untuk menumis"
- "secukupnya Air"
- " Bumbu Non Halus"
- "1 batang sereh geprek"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- " Bumbu Halus"
- "17 buah cabe rawit pedas sesuai selera"
- "5 buah cabe merah keriting"
- "4 siung bawang putih"
- "7 siung bawang merah"
- "2 buah kemiri"
- "1 ruas jahe"
- "2 ruas lengkuas"
- "1 sdm bubuk kunyit kurang lebih segitu"
- "1 sdt bubuk ketumbar opsional"
- "1 sdt lada bubuk opsional"
- " Bumbu Tambahan"
- "Secukupnya Garam"
- "secukupnya Gula"
- "secukupnya Kaldu ayam  me masako ayam seujung sendok teh"
- "2 sdm Kecap manis kurang lebih  opsional"
recipeinstructions:
- "Bersihkan ayam lalu potong2 sesuai selera kemudian rebus dulu sekitar +- 1 jam lalu tiriskan, tujuannya supaya ayam gak alot karena tekstur ayam kampung beda sama ayam negri, kalo pake ayam negri langkah ini bisa kalian skip"
- "Haluskan bumbu halus kemudian tumis dengan minyak panas lalu masukkan sereh, daun salam dan daun jeruk. Tumis hingga wangi."
- "Tambahkan air secukupnya ke bumbu yg sedang ditumis (bisa pake air rebusan ayam sebelumnya/air biasa) tunggu hingga mendidih kemudian masukkan ayamnya."
- "Masukkan garam, gula, kaldu ayam, dan kecap, masak hingga ayam empuk"
- "Setelah itu cek rasa, jika dirasa sudah pas semua matikan api dan masukkan daun kemangi yang sudah dicuci bersih kemudian diaduk dan siap disajikan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 187 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/e5ec23a440247769/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica rica kemangi yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Indonesia

Keharmonisan keluarga bisa didapat dengan cara sederhana. Salah satunya adalah memasak Ayam Rica Rica Kemangi untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang dapat anda buat salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 24 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi:

1. Siapkan 1/2 ekor ayam kampung
1. Siapkan Segenggam daun kemangi
1. Dibutuhkan  Minyak untuk menumis
1. Siapkan secukupnya Air
1. Harap siapkan  Bumbu Non Halus
1. Tambah 1 batang sereh geprek
1. Diperlukan 2 lembar daun salam
1. Harus ada 3 lembar daun jeruk
1. Siapkan  Bumbu Halus
1. Siapkan 17 buah cabe rawit (pedas sesuai selera)
1. Siapkan 5 buah cabe merah keriting
1. Jangan lupa 4 siung bawang putih
1. Harap siapkan 7 siung bawang merah
1. Siapkan 2 buah kemiri
1. Tambah 1 ruas jahe
1. Harus ada 2 ruas lengkuas
1. Siapkan 1 sdm bubuk kunyit (kurang lebih segitu)
1. Jangan lupa 1 sdt bubuk ketumbar (opsional)
1. Dibutuhkan 1 sdt lada bubuk (opsional)
1. Dibutuhkan  Bumbu Tambahan
1. Harus ada Secukupnya Garam
1. Siapkan secukupnya Gula
1. Harus ada secukupnya Kaldu ayam  (me: masako ayam seujung sendok teh)
1. Harap siapkan 2 sdm Kecap manis kurang lebih  (opsional)




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Rica Kemangi:

1. Bersihkan ayam lalu potong2 sesuai selera kemudian rebus dulu sekitar +- 1 jam lalu tiriskan, tujuannya supaya ayam gak alot karena tekstur ayam kampung beda sama ayam negri, kalo pake ayam negri langkah ini bisa kalian skip
1. Haluskan bumbu halus kemudian tumis dengan minyak panas lalu masukkan sereh, daun salam dan daun jeruk. Tumis hingga wangi.
1. Tambahkan air secukupnya ke bumbu yg sedang ditumis (bisa pake air rebusan ayam sebelumnya/air biasa) tunggu hingga mendidih kemudian masukkan ayamnya.
1. Masukkan garam, gula, kaldu ayam, dan kecap, masak hingga ayam empuk
1. Setelah itu cek rasa, jika dirasa sudah pas semua matikan api dan masukkan daun kemangi yang sudah dicuci bersih kemudian diaduk dan siap disajikan.




Demikianlah cara membuat ayam rica rica kemangi yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
