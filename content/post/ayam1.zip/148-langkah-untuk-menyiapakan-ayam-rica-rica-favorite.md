---
description: "Langkah untuk menyiapakan Ayam Rica-rica Favorite"
title: "Langkah untuk menyiapakan Ayam Rica-rica Favorite"
slug: 148-langkah-untuk-menyiapakan-ayam-rica-rica-favorite
date: 2020-08-06T22:15:57.062Z
image: https://img-global.cpcdn.com/recipes/d780e63cabbfac20/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d780e63cabbfac20/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d780e63cabbfac20/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Clarence Jones
ratingvalue: 4
reviewcount: 39315
recipeingredient:
- "1/2 kg ayam"
- "4 batang sereh geprek"
- "2 siung bawang putih geprek"
- "5 lembar daun salam"
- "5 lembar daun kunyit"
- "2 ruas jahe geprek"
- "2 ruas lengkuas geprek"
- "1 ikat daun kemangi"
- " Bumbu Halus"
- "1/2 ruas kunyit"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "2 butir kemiri"
- "15 bh cabai rawit"
- "7 bh cabai merah besar"
- " Bahan Tambahan"
- "1 bh jeruk nipis"
- "1/4 sdt garam"
- "1/2 sdt gula pasir"
- "1/4 sdt kaldu bubuk"
- "secukupnya Air"
- " Minyak goreng"
recipeinstructions:
- "Cuci bersih ayam, kemudian beri jeruk nipis. Diamkan sebentar, cuci bersih kembali."
- "Rebus ayam bersama jahe, bawang putih, dan sereh untuk menghilangkan bau amis. Tiriskan, lalu goreng ayam yang sudah direbus."
- "Panaskan minyak goreng secukupnya, tumis bumbu halus hingga harum. Tambahkan jahe lengkuas sereh daun salam dan daun jeruk. Tumis bumbu hingga harum Tambahkan air secukupnya."
- "Bumbui dengan garam, gula pasir dan kaldu bubuk titik aduk rata, koreksi rasa. Kemudian masukkan ayam aduk rata Masak hingga air menyusut. Bila air sudah menyusut masukkan kemangi aduk rata sebentar lalu mati kan api.siap disajikan"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 131 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica-rica](https://img-global.cpcdn.com/recipes/d780e63cabbfac20/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica-rica yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia



Kedekatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Rica-rica untuk keluarga. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang bisa anda praktekkan salah satunya ayam rica-rica yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica:

1. Siapkan 1/2 kg ayam
1. Harus ada 4 batang sereh, geprek
1. Diperlukan 2 siung bawang putih, geprek
1. Diperlukan 5 lembar daun salam
1. Jangan lupa 5 lembar daun kunyit
1. Jangan lupa 2 ruas jahe, geprek
1. Siapkan 2 ruas lengkuas, geprek
1. Tambah 1 ikat daun kemangi
1. Tambah  Bumbu Halus
1. Harus ada 1/2 ruas kunyit
1. Jangan lupa 6 siung bawang merah
1. Harus ada 3 siung bawang putih
1. Jangan lupa 2 butir kemiri
1. Siapkan 15 bh cabai rawit
1. Harus ada 7 bh cabai merah besar
1. Dibutuhkan  Bahan Tambahan
1. Harap siapkan 1 bh jeruk nipis
1. Harus ada 1/4 sdt garam
1. Diperlukan 1/2 sdt gula pasir
1. Tambah 1/4 sdt kaldu bubuk
1. Tambah secukupnya Air
1. Diperlukan  Minyak goreng




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-rica:

1. Cuci bersih ayam, kemudian beri jeruk nipis. Diamkan sebentar, cuci bersih kembali.
1. Rebus ayam bersama jahe, bawang putih, dan sereh untuk menghilangkan bau amis. Tiriskan, lalu goreng ayam yang sudah direbus.
1. Panaskan minyak goreng secukupnya, tumis bumbu halus hingga harum. Tambahkan jahe lengkuas sereh daun salam dan daun jeruk. Tumis bumbu hingga harum Tambahkan air secukupnya.
1. Bumbui dengan garam, gula pasir dan kaldu bubuk titik aduk rata, koreksi rasa. Kemudian masukkan ayam aduk rata Masak hingga air menyusut. Bila air sudah menyusut masukkan kemangi aduk rata sebentar lalu mati kan api.siap disajikan




Demikianlah cara membuat ayam rica-rica yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan terbukti, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
