---
description: "Resep : Ayam Goreng Bacem Homemade"
title: "Resep : Ayam Goreng Bacem Homemade"
slug: 414-resep-ayam-goreng-bacem-homemade
date: 2021-01-13T11:01:58.137Z
image: https://img-global.cpcdn.com/recipes/7cc1dcc94eb19c85/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7cc1dcc94eb19c85/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7cc1dcc94eb19c85/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg
author: Effie Neal
ratingvalue: 4.5
reviewcount: 42673
recipeingredient:
- "8 buah paha ayam"
- "8 siung bawang putih"
- "10 buah kemiri"
- "1 sdm ketumbar biji"
- "2 batang sere"
- "3 cm jahe"
- "3 cm lengkuas"
- "3 cm kencur"
- "5 lembar daun jeruk"
- "3 lembar daun salam"
- "1000 ml air"
- "1 sdm garam"
- "2 sdm gula"
- "5 sdm kecap manis"
- "250 ml minyak goreng"
recipeinstructions:
- "Siapkan bumbu dan blender bawnag putih, kemiri dan ketumbar, kencur dan jahe."
- "Masukkan dalam penggorengan, beri air, lengkuas, sere, salam, daun jeruk, lengkuas, garam, gula."
- "Setelah mendidih masukan ayam dan beri kecap kemudian tutup."
- "Biarkan sampai mendidih dan agak mengering airnya."
- "Goreng ayam diminyak yang sudah dipanaskan."
- "Ayam goreng siap disajikan."
categories:
- Recipe
tags:
- ayam
- goreng
- bacem

katakunci: ayam goreng bacem 
nutrition: 241 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT49M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Goreng Bacem](https://img-global.cpcdn.com/recipes/7cc1dcc94eb19c85/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau renyah. Ciri masakan Nusantara ayam goreng bacem yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga dapat ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam Goreng Bacem untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang dapat anda praktekkan salah satunya ayam goreng bacem yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep ayam goreng bacem tanpa harus bersusah payah.
Seperti resep Ayam Goreng Bacem yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Bacem:

1. Tambah 8 buah paha ayam
1. Tambah 8 siung bawang putih
1. Jangan lupa 10 buah kemiri
1. Siapkan 1 sdm ketumbar biji
1. Tambah 2 batang sere
1. Dibutuhkan 3 cm jahe
1. Siapkan 3 cm lengkuas
1. Siapkan 3 cm kencur
1. Jangan lupa 5 lembar daun jeruk
1. Jangan lupa 3 lembar daun salam
1. Dibutuhkan 1000 ml air
1. Tambah 1 sdm garam
1. Siapkan 2 sdm gula
1. Jangan lupa 5 sdm kecap manis
1. Dibutuhkan 250 ml minyak goreng




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Bacem:

1. Siapkan bumbu dan blender bawnag putih, kemiri dan ketumbar, kencur dan jahe.
1. Masukkan dalam penggorengan, beri air, lengkuas, sere, salam, daun jeruk, lengkuas, garam, gula.
1. Setelah mendidih masukan ayam dan beri kecap kemudian tutup.
1. Biarkan sampai mendidih dan agak mengering airnya.
1. Goreng ayam diminyak yang sudah dipanaskan.
1. Ayam goreng siap disajikan.




Demikianlah cara membuat ayam goreng bacem yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
