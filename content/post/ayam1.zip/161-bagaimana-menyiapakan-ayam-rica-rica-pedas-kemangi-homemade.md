---
description: "Bagaimana menyiapakan Ayam Rica-Rica Pedas Kemangi Homemade"
title: "Bagaimana menyiapakan Ayam Rica-Rica Pedas Kemangi Homemade"
slug: 161-bagaimana-menyiapakan-ayam-rica-rica-pedas-kemangi-homemade
date: 2020-10-04T12:25:20.078Z
image: https://img-global.cpcdn.com/recipes/70fe4d1a847382bb/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/70fe4d1a847382bb/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/70fe4d1a847382bb/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
author: Bryan Curry
ratingvalue: 4.1
reviewcount: 46181
recipeingredient:
- "6 potong ayam"
- "sesuai selera Tempe dipotong kecil2"
- "2 daun jeruk"
- "1 daun salam"
- "1 ikat kemangi"
- "1 batang sereh digeprek"
- " Gula"
- " Totole kaldu jamur"
- " Bumbu halus"
- "5 bawang merah"
- "2 bawang putih"
- "1 ruas jahe"
- "1 ruas laos"
- " Kunyit secukupnya saya pake kunyit bubuk desaku"
- " Ketumbar sedikit saya pake ketumbar bubuk desaku"
- "5 cabe rawit kecil"
- "1 cabe merah besar"
- "secukupnya Garam"
recipeinstructions:
- "Rebus ayam terlebih dahulu (saya merebusnya dikasih garam sedikit)"
- "Didihkan air, rebus ayam hingga matang. Lalu tiriskan"
- "Bahan2 yang dihaluskan (bawang merah, bawang putih, jahe, laos, kunyit, ketumbar, garam). Boleh diulek boleh pake blender"
- "Panaskan wajan, beri minyak sedikit. Lalu tumis bumbu halus. Masukkan daun jeruk, daun salam, dan sereh. Tumis hingga harum."
- "Setelah harum, beri air secukupnya. Masukkan tempe yg sudah dipotong. Didihkan hingga tempe matang"
- "Lalu masukkan ayam yang sudah direbus. Beri garam, gula, totole. Koreksi rasa. Tunggu hingga bumbu meresap ke dalam ayam dan tempe. Terakhir masukkan daun kemangi. Lalu aduk hingga merata."
categories:
- Recipe
tags:
- ayam
- ricarica
- pedas

katakunci: ayam ricarica pedas 
nutrition: 280 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica-Rica Pedas Kemangi](https://img-global.cpcdn.com/recipes/70fe4d1a847382bb/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang harus kita jaga karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica-rica pedas kemangi yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan ciri khas yang merupakan keragaman Indonesia

Keharmonisan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica-Rica Pedas Kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang bisa anda praktekkan salah satunya ayam rica-rica pedas kemangi yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica-rica pedas kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Pedas Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Pedas Kemangi:

1. Diperlukan 6 potong ayam
1. Tambah sesuai selera Tempe dipotong kecil2
1. Diperlukan 2 daun jeruk
1. Dibutuhkan 1 daun salam
1. Jangan lupa 1 ikat kemangi
1. Diperlukan 1 batang sereh digeprek
1. Dibutuhkan  Gula
1. Tambah  Totole kaldu jamur
1. Diperlukan  Bumbu halus
1. Tambah 5 bawang merah
1. Dibutuhkan 2 bawang putih
1. Tambah 1 ruas jahe
1. Tambah 1 ruas laos
1. Tambah  Kunyit secukupnya (saya pake kunyit bubuk desaku)
1. Harus ada  Ketumbar sedikit (saya pake ketumbar bubuk desaku)
1. Harus ada 5 cabe rawit kecil
1. Diperlukan 1 cabe merah besar
1. Tambah secukupnya Garam




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-Rica Pedas Kemangi:

1. Rebus ayam terlebih dahulu (saya merebusnya dikasih garam sedikit)
1. Didihkan air, rebus ayam hingga matang. Lalu tiriskan
1. Bahan2 yang dihaluskan (bawang merah, bawang putih, jahe, laos, kunyit, ketumbar, garam). Boleh diulek boleh pake blender
1. Panaskan wajan, beri minyak sedikit. Lalu tumis bumbu halus. Masukkan daun jeruk, daun salam, dan sereh. Tumis hingga harum.
1. Setelah harum, beri air secukupnya. Masukkan tempe yg sudah dipotong. Didihkan hingga tempe matang
1. Lalu masukkan ayam yang sudah direbus. Beri garam, gula, totole. Koreksi rasa. Tunggu hingga bumbu meresap ke dalam ayam dan tempe. Terakhir masukkan daun kemangi. Lalu aduk hingga merata.




Demikianlah cara membuat ayam rica-rica pedas kemangi yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan teruji, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
