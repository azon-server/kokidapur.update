---
description: "Cara membuat Ayam rica rica kemangi terupdate"
title: "Cara membuat Ayam rica rica kemangi terupdate"
slug: 197-cara-membuat-ayam-rica-rica-kemangi-terupdate
date: 2021-02-01T18:40:37.961Z
image: https://img-global.cpcdn.com/recipes/e631b4fd3eb1e1d4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e631b4fd3eb1e1d4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e631b4fd3eb1e1d4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Etta Gomez
ratingvalue: 4.9
reviewcount: 36351
recipeingredient:
- "1/2 kg sayap ayam"
- " Bumbu uleg "
- "3 siung bawang putih"
- "6 siung bawang merah"
- "1 tangkai sereh"
- "1,5 ruas kunyit"
- "1 ruas Jahe"
- "1 ruas lengkuas"
- "1 sdt ketumbar"
- "2 buah kemiri"
- "5 butir merica"
- "2 lembar daun jeruk"
- "1 lembar daun salam"
- "1 buah jeruk nipis"
- " Kecap manis"
- " Lada bubuk"
- " Garam"
- " Gula"
recipeinstructions:
- "Bersihkan ayam, dibawah air mengalir, goreng sebentar"
- "Haluskan semua bumbu kecuali sereh dan daun salam"
- "Panaskan minyak, tumis bumbu yang sudah diuleg kemudian tambahkan sereh dan daun salam, memarkan sereh dan remas remas daun salam ya"
- "Jika sudah tercium aroma sedap tambahkan air secukupnya hingga ayam terendam"
- "Jika sudah mendidih, tambahkan garam, lada bubuk, penyedap rasa, kecap dan gula"
- "Aduk rata hingga tercamput semua, tunggu hingga air menyusut.. Koreksi rasa dan sajikan dengan Cinta ❤"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 290 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/e631b4fd3eb1e1d4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang dapat kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica rica kemangi yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan ciri khas yang merupakan keragaman Indonesia



Kedekatan rumah tangga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam rica rica kemangi untuk keluarga. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang dapat anda praktekkan salah satunya ayam rica rica kemangi yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi:

1. Harus ada 1/2 kg sayap ayam
1. Tambah  Bumbu uleg ;
1. Jangan lupa 3 siung bawang putih
1. Siapkan 6 siung bawang merah
1. Tambah 1 tangkai sereh
1. Siapkan 1,5 ruas kunyit
1. Jangan lupa 1 ruas Jahe
1. Harus ada 1 ruas lengkuas
1. Harap siapkan 1 sdt ketumbar
1. Dibutuhkan 2 buah kemiri
1. Tambah 5 butir merica
1. Siapkan 2 lembar daun jeruk
1. Harus ada 1 lembar daun salam
1. Harap siapkan 1 buah jeruk nipis
1. Siapkan  Kecap manis
1. Diperlukan  Lada bubuk
1. Tambah  Garam
1. Dibutuhkan  Gula




<!--inarticleads2-->

##### Cara membuat  Ayam rica rica kemangi:

1. Bersihkan ayam, dibawah air mengalir, goreng sebentar
1. Haluskan semua bumbu kecuali sereh dan daun salam
1. Panaskan minyak, tumis bumbu yang sudah diuleg kemudian tambahkan sereh dan daun salam, memarkan sereh dan remas remas daun salam ya
1. Jika sudah tercium aroma sedap tambahkan air secukupnya hingga ayam terendam
1. Jika sudah mendidih, tambahkan garam, lada bubuk, penyedap rasa, kecap dan gula
1. Aduk rata hingga tercamput semua, tunggu hingga air menyusut.. Koreksi rasa dan sajikan dengan Cinta ❤




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
