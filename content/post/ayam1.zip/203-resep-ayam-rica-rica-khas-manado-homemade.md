---
description: "Resep : Ayam Rica-Rica Khas Manado Homemade"
title: "Resep : Ayam Rica-Rica Khas Manado Homemade"
slug: 203-resep-ayam-rica-rica-khas-manado-homemade
date: 2020-08-10T00:54:05.967Z
image: https://img-global.cpcdn.com/recipes/ea686990db8b4218/751x532cq70/ayam-rica-rica-khas-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ea686990db8b4218/751x532cq70/ayam-rica-rica-khas-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ea686990db8b4218/751x532cq70/ayam-rica-rica-khas-manado-foto-resep-utama.jpg
author: Cora Hicks
ratingvalue: 4.9
reviewcount: 15872
recipeingredient:
- "1 ekor Ayam"
- " Bumbu Marinasi"
- "2 buah Jeruk Nipis"
- "1 sdm Garam"
- "1 sdm Kunyit Bubuk  2 ruas jari Kunyit Segar yg dihaluskan"
- " Bumbu Halus"
- "1 ons Cabai Merah  Keriting"
- "1/2 ons Cabai Rawit"
- "5 siung Bawang Merah"
- "5 siung Bawang Putih"
- "1 ruas jari Jahe"
- "1 ruas jari Kunyit"
- "1 ruas jari Lengkuas"
- "3 butir Kemiri"
- " Bumbu Pelengkap"
- "3 batang Serai geprek"
- "1 lembar Daun Pandan simpulkan"
- "5 lembar Daun Salam"
- "5 lembar Daun Jeruk iris tipis"
- "2 batang Daun Bawang"
- "2 ikat Daun Kemangi petiki"
- " Bahan Tambahan"
- "1 sdt Garam"
- "1/2 sdt Kaldu"
- "1 sdm Gula Pasir"
- "400 ml Air"
- "5 sdm Minyak Goreng"
recipeinstructions:
- "Marinasi Ayam selama 10 menit. Lalu goreng setengah kering, tiriskan"
- "Tumis bumbu halus dan masukkan bumbu pelengkapnya (kecuali daun kemangi) hingga harum"
- "Beri Air dan masukkan ayam gorengnya"
- "Beri gula, garam, dan kaldunya. Koreksi rasa, masak hingga kuahnya meresap dan asat, baru masukkan daun kemangi aduk sebentar dan matikan api (gunakan api sedang)"
- "Siap disajikan dan Selamat Menikmati"
categories:
- Recipe
tags:
- ayam
- ricarica
- khas

katakunci: ayam ricarica khas 
nutrition: 252 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica-Rica Khas Manado](https://img-global.cpcdn.com/recipes/ea686990db8b4218/751x532cq70/ayam-rica-rica-khas-manado-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica-rica khas manado yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa keistimewahan yang merupakan keragaman Kita

Kedekatan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Rica-Rica Khas Manado untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang dapat anda contoh salah satunya ayam rica-rica khas manado yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam rica-rica khas manado tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Khas Manado yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 27 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Khas Manado:

1. Harap siapkan 1 ekor Ayam
1. Diperlukan  Bumbu Marinasi
1. Harap siapkan 2 buah Jeruk Nipis
1. Jangan lupa 1 sdm Garam
1. Tambah 1 sdm Kunyit Bubuk / 2 ruas jari Kunyit Segar yg dihaluskan
1. Dibutuhkan  Bumbu Halus
1. Diperlukan 1 ons Cabai Merah / Keriting
1. Dibutuhkan 1/2 ons Cabai Rawit
1. Tambah 5 siung Bawang Merah
1. Diperlukan 5 siung Bawang Putih
1. Siapkan 1 ruas jari Jahe
1. Dibutuhkan 1 ruas jari Kunyit
1. Dibutuhkan 1 ruas jari Lengkuas
1. Tambah 3 butir Kemiri
1. Tambah  Bumbu Pelengkap
1. Harap siapkan 3 batang Serai (geprek)
1. Tambah 1 lembar Daun Pandan (simpulkan)
1. Siapkan 5 lembar Daun Salam
1. Harus ada 5 lembar Daun Jeruk (iris tipis)
1. Dibutuhkan 2 batang Daun Bawang
1. Harus ada 2 ikat Daun Kemangi (petiki)
1. Siapkan  Bahan Tambahan
1. Harus ada 1 sdt Garam
1. Siapkan 1/2 sdt Kaldu
1. Siapkan 1 sdm Gula Pasir
1. Dibutuhkan 400 ml Air
1. Jangan lupa 5 sdm Minyak Goreng




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-Rica Khas Manado:

1. Marinasi Ayam selama 10 menit. Lalu goreng setengah kering, tiriskan
1. Tumis bumbu halus dan masukkan bumbu pelengkapnya (kecuali daun kemangi) hingga harum
1. Beri Air dan masukkan ayam gorengnya
1. Beri gula, garam, dan kaldunya. Koreksi rasa, masak hingga kuahnya meresap dan asat, baru masukkan daun kemangi aduk sebentar dan matikan api (gunakan api sedang)
1. Siap disajikan dan Selamat Menikmati




Demikianlah cara membuat ayam rica-rica khas manado yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat gampang dan cepat, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
