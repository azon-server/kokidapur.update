---
description: "Step-by-Step untuk membuat Ayam rica-rica kemangi Teruji"
title: "Step-by-Step untuk membuat Ayam rica-rica kemangi Teruji"
slug: 120-step-by-step-untuk-membuat-ayam-rica-rica-kemangi-teruji
date: 2020-11-16T02:51:07.135Z
image: https://img-global.cpcdn.com/recipes/090d3daa66c1fffc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/090d3daa66c1fffc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/090d3daa66c1fffc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Francis Ramsey
ratingvalue: 4.1
reviewcount: 2103
recipeingredient:
- "1 kg ayam"
- "secukupnya Jeruk nipis"
- "3 ikat Kemangi"
- "7 lembar Daun jeruk"
- "1 batang Sereh"
- " Lengkuas 1 ruas geprek"
- "secukupnya Garam gula  penyedap"
- " Air untuk mengungkep ayam"
- " Bumbu halus "
- "3 Cabe merah besar"
- "5 Cabe keriting"
- " Cabe rawit merah 5 optional kalau suka pedas"
- "8 Bawang merah"
- "4 Bawang putih"
- "secukupnya Jahe  kunyit"
- "3 butir Kemiri"
- " Minyak goreng untuk menumis bumbu"
recipeinstructions:
- "Potong ayam sesuai selera, cuci dan bersihkan lalu lumuri dengan jeruk nipis diamkan -+ 10menit lalu bilas sampai bersih"
- "Haluskan semua bumbu lalu masukkan juga bumbu tambahan daun jeruk, sereh, lengkuas dan tumis hingga harum"
- "Setelah itu masukan ayam kedalam bumbu tumis tadi, lalu aduk2 dan beri air sampai ayam terendam, ungkep sampai matang dan tambahkan garam, gula, penyedap, tes rasa"
- "Kalau air sudah agak menyusut dan ayam sudah matang, campurkan daun kemangi lalu aduk sampai rata"
- "Ayam siap d sajikan.. Selamat mencoba 😊"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 169 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/090d3daa66c1fffc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica-rica kemangi yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Kita

Kehangatan keluarga bisa didapat dengan cara simple. Diantaranya adalah membuat makanan Ayam rica-rica kemangi untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang bisa anda coba salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica kemangi:

1. Jangan lupa 1 kg ayam
1. Dibutuhkan secukupnya Jeruk nipis
1. Siapkan 3 ikat Kemangi
1. Siapkan 7 lembar Daun jeruk
1. Dibutuhkan 1 batang Sereh
1. Tambah  Lengkuas 1 ruas (geprek)
1. Dibutuhkan secukupnya Garam, gula &amp; penyedap
1. Tambah  Air untuk mengungkep ayam
1. Dibutuhkan  Bumbu halus :
1. Tambah 3 Cabe merah besar
1. Jangan lupa 5 Cabe keriting
1. Tambah  Cabe rawit merah 5 (optional kalau suka pedas)
1. Harus ada 8 Bawang merah
1. Jangan lupa 4 Bawang putih
1. Jangan lupa secukupnya Jahe &amp; kunyit
1. Harus ada 3 butir Kemiri
1. Dibutuhkan  Minyak goreng untuk menumis bumbu




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica-rica kemangi:

1. Potong ayam sesuai selera, cuci dan bersihkan lalu lumuri dengan jeruk nipis diamkan -+ 10menit lalu bilas sampai bersih
1. Haluskan semua bumbu lalu masukkan juga bumbu tambahan daun jeruk, sereh, lengkuas dan tumis hingga harum
1. Setelah itu masukan ayam kedalam bumbu tumis tadi, lalu aduk2 dan beri air sampai ayam terendam, ungkep sampai matang dan tambahkan garam, gula, penyedap, tes rasa
1. Kalau air sudah agak menyusut dan ayam sudah matang, campurkan daun kemangi lalu aduk sampai rata
1. Ayam siap d sajikan.. Selamat mencoba 😊




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
