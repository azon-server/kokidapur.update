---
description: "Steps membuat Ayam rica rica Sempurna"
title: "Steps membuat Ayam rica rica Sempurna"
slug: 118-steps-membuat-ayam-rica-rica-sempurna
date: 2020-12-14T06:51:43.098Z
image: https://img-global.cpcdn.com/recipes/e6d820cd74c7d31b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e6d820cd74c7d31b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e6d820cd74c7d31b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Elijah Grant
ratingvalue: 4.9
reviewcount: 29934
recipeingredient:
- " Ayam potong paha sayap dada sesuai selera"
- " bumbu marinir ayam"
- "2 sdm garam"
- "1/2 sdt kunyit bubuk"
- " bumbu halus"
- "4-5 siung bawang merah"
- "12 cabe merah kecil"
- "5 siung bawang putih"
- "1 inci jahe"
- "2 kemiri"
- " bahan tambahan"
- "1 batang serai"
- " I inci lengkuas"
- "secukupnya Daun bawang"
- "2-3 lembar daun jeruk"
- "secukupnya Daun kemangi"
- "secukupnya Garam"
- " Gula"
- "500 ml air"
recipeinstructions:
- "Ayam yg sudah di potong dan bersih kan selanjutnya kita marinir dengan garam dan kunyit bubuk lalu aduk aduk dan diamkan dulu sebelum nanti kita goreng"
- "Selanjutnya aku blender halus jahe dan kemiri dan tambahkan sedikit air"
- "Lalu setelah jahe dan kemiri halus selanjutnya aku masukan bawang merah, bawang putih, cabe dan aku blender Kasar saja"
- "Selanjutnya potong daun bawang kecil kecil dan geprek serai nya dan siapkan lengkuas nya juga lalu potong daun jeruk dan buang tangkai nya"
- "Selanjutnya aku panaskan minyak dan goreng ayam sampai matang tapi jangan sampai kering kalo sudah matang angkat dan tiriskan"
- "Selanjutnya aku tumis bumbunya dan aku aduk aduk sampai bau harum"
- "Lalu aku masukan serai yg sudah di geprek dan lengkuas serta masukan juga daun jeruk nya aduk aduk sampai bau harum dan bumbu matang"
- "Dan selanjutnya aku masukan ayamnya dan aku aduk aduk setelah itu aku tambahkan juga air nya aduk aduk kembali dan aku tambahkan juga garam dan gula nya lalu aduk aduk agar semua tercampur rata lalu biyarkan air sampai meresap"
- "Setelah air meresap aku masukan daun bawang dan daun kemangi lalu aduk aduk kembali dan aku matikan kompor agar kemangi tidak lembek"
- "Dan selanjutnya kita hidangkan semoga bermanfaat yah"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 199 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam rica rica](https://img-global.cpcdn.com/recipes/e6d820cd74c7d31b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis atau enak. Ciri khas kuliner Indonesia ayam rica rica yang penuh dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam rica rica untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang bisa anda contoh salah satunya ayam rica rica yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam rica rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 10 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica:

1. Jangan lupa  Ayam potong (paha, sayap, dada) sesuai selera
1. Harap siapkan  bumbu marinir ayam
1. Diperlukan 2 sdm garam
1. Dibutuhkan 1/2 sdt kunyit bubuk
1. Dibutuhkan  bumbu halus
1. Harap siapkan 4-5 siung bawang merah
1. Tambah 12 cabe merah kecil
1. Diperlukan 5 siung bawang putih
1. Dibutuhkan 1 inci jahe
1. Jangan lupa 2 kemiri
1. Dibutuhkan  bahan tambahan
1. Diperlukan 1 batang serai
1. Tambah  I inci lengkuas
1. Tambah secukupnya Daun bawang
1. Diperlukan 2-3 lembar daun jeruk
1. Harus ada secukupnya Daun kemangi
1. Jangan lupa secukupnya Garam
1. Dibutuhkan  Gula
1. Harus ada 500 ml air




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica rica:

1. Ayam yg sudah di potong dan bersih kan selanjutnya kita marinir dengan garam dan kunyit bubuk lalu aduk aduk dan diamkan dulu sebelum nanti kita goreng
1. Selanjutnya aku blender halus jahe dan kemiri dan tambahkan sedikit air
1. Lalu setelah jahe dan kemiri halus selanjutnya aku masukan bawang merah, bawang putih, cabe dan aku blender Kasar saja
1. Selanjutnya potong daun bawang kecil kecil dan geprek serai nya dan siapkan lengkuas nya juga lalu potong daun jeruk dan buang tangkai nya
1. Selanjutnya aku panaskan minyak dan goreng ayam sampai matang tapi jangan sampai kering kalo sudah matang angkat dan tiriskan
1. Selanjutnya aku tumis bumbunya dan aku aduk aduk sampai bau harum
1. Lalu aku masukan serai yg sudah di geprek dan lengkuas serta masukan juga daun jeruk nya aduk aduk sampai bau harum dan bumbu matang
1. Dan selanjutnya aku masukan ayamnya dan aku aduk aduk setelah itu aku tambahkan juga air nya aduk aduk kembali dan aku tambahkan juga garam dan gula nya lalu aduk aduk agar semua tercampur rata lalu biyarkan air sampai meresap
1. Setelah air meresap aku masukan daun bawang dan daun kemangi lalu aduk aduk kembali dan aku matikan kompor agar kemangi tidak lembek
1. Dan selanjutnya kita hidangkan semoga bermanfaat yah




Demikianlah cara membuat ayam rica rica yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
