---
description: "Bagaimana menyiapakan Ayam Rica Pedas Manis Favorite"
title: "Bagaimana menyiapakan Ayam Rica Pedas Manis Favorite"
slug: 26-bagaimana-menyiapakan-ayam-rica-pedas-manis-favorite
date: 2020-10-23T05:17:27.303Z
image: https://img-global.cpcdn.com/recipes/34a5cb022f09220b/751x532cq70/ayam-rica-pedas-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/34a5cb022f09220b/751x532cq70/ayam-rica-pedas-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/34a5cb022f09220b/751x532cq70/ayam-rica-pedas-manis-foto-resep-utama.jpg
author: Bessie Alvarez
ratingvalue: 4
reviewcount: 8466
recipeingredient:
- "1/2 kg ayam cocok yang bagian sayap kepala ceker"
- "4 siung besar Bawang merah"
- "3 siung besar Bawang putih"
- "4 cabe merah besar kriting memberi warna merah dan rasa pedas"
- "10 cabe rawit kecil"
- "1 ruas kunir"
- "2 butir kemiri ukuran kecil"
- "3 lembar daun salam"
- "2 lembar daun jeruk purut"
- " Merica dan pala bubuk"
- "5 SDM kecap manis bisa lebih tergantung selera"
- "1 SDT garam"
- "1 SDT penyedap"
- " Bawang goreng merah penyajian"
recipeinstructions:
- "Potong bagian ayam menjadi ukuran kecil. Ayam Rica nikmat jika dimakan berukuran kecil. Misal satu sayap dipotong menjadi 2-3 bagian."
- "Rebus ayam mentah untuk membuang lemak kotor. Beri sedikit garam. Sebaiknya ayam yang mentah jangan di cuci terlebih dahulu, perebusan ayam gunanya untuk membuang zat kotoran pada ayam mentah."
- "Haluskan bumbu kecuali daun salam, daun jeruk purut karna untuk menumis bumbu."
- "Setelah ayam empuk angkat dan tiriskan."
- "Tumis bumbu yg sudah di haluskan. Masukan daun salam dan daun jeruk purut. Tumis hingga harum. Jika harum Tambahan air 200ml, kecap, garam, penyedap rasa, merica dan pala bubuk."
- "Masukan ayam kedalam bumbu, masak hingga bumbu meresap."
- "Sajikan ayam bersama bawang goreng."
categories:
- Recipe
tags:
- ayam
- rica
- pedas

katakunci: ayam rica pedas 
nutrition: 149 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT55M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Pedas Manis](https://img-global.cpcdn.com/recipes/34a5cb022f09220b/751x532cq70/ayam-rica-pedas-manis-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica pedas manis yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan ciri khas yang merupakan keragaman Indonesia

Kedekatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica Pedas Manis untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang dapat anda praktekkan salah satunya ayam rica pedas manis yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan gampang menemukan resep ayam rica pedas manis tanpa harus bersusah payah.
Seperti resep Ayam Rica Pedas Manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Pedas Manis:

1. Harus ada 1/2 kg ayam (cocok yang bagian sayap, kepala, ceker)
1. Diperlukan 4 siung besar Bawang merah
1. Siapkan 3 siung besar Bawang putih
1. Harus ada 4 cabe merah besar kriting (memberi warna merah dan rasa pedas)
1. Tambah 10 cabe rawit kecil
1. Harap siapkan 1 ruas kunir
1. Harus ada 2 butir kemiri ukuran kecil
1. Harap siapkan 3 lembar daun salam
1. Diperlukan 2 lembar daun jeruk purut
1. Diperlukan  Merica dan pala bubuk
1. Harap siapkan 5 SDM kecap manis bisa lebih tergantung selera
1. Dibutuhkan 1 SDT garam
1. Siapkan 1 SDT penyedap
1. Dibutuhkan  Bawang goreng merah penyajian




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Pedas Manis:

1. Potong bagian ayam menjadi ukuran kecil. Ayam Rica nikmat jika dimakan berukuran kecil. Misal satu sayap dipotong menjadi 2-3 bagian.
1. Rebus ayam mentah untuk membuang lemak kotor. Beri sedikit garam. Sebaiknya ayam yang mentah jangan di cuci terlebih dahulu, perebusan ayam gunanya untuk membuang zat kotoran pada ayam mentah.
1. Haluskan bumbu kecuali daun salam, daun jeruk purut karna untuk menumis bumbu.
1. Setelah ayam empuk angkat dan tiriskan.
1. Tumis bumbu yg sudah di haluskan. Masukan daun salam dan daun jeruk purut. Tumis hingga harum. Jika harum Tambahan air 200ml, kecap, garam, penyedap rasa, merica dan pala bubuk.
1. Masukan ayam kedalam bumbu, masak hingga bumbu meresap.
1. Sajikan ayam bersama bawang goreng.




Demikianlah cara membuat ayam rica pedas manis yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan teruji, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
