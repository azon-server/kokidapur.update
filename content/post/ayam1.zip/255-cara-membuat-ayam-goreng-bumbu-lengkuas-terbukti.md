---
description: "Cara membuat Ayam Goreng Bumbu Lengkuas Terbukti"
title: "Cara membuat Ayam Goreng Bumbu Lengkuas Terbukti"
slug: 255-cara-membuat-ayam-goreng-bumbu-lengkuas-terbukti
date: 2020-09-19T22:27:39.166Z
image: https://img-global.cpcdn.com/recipes/13873e7adf5cba70/751x532cq70/ayam-goreng-bumbu-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/13873e7adf5cba70/751x532cq70/ayam-goreng-bumbu-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/13873e7adf5cba70/751x532cq70/ayam-goreng-bumbu-lengkuas-foto-resep-utama.jpg
author: Barbara Lucas
ratingvalue: 4.7
reviewcount: 18516
recipeingredient:
- "1 ekor ayam potong 8"
- "100 gr lengkuas parut"
- "3 lembar daun salam remat2"
- "6 lembar daun jeruk remat2"
- "2 batang sereh geprek"
- "1,5 sdm garam"
- "1 sdm gula"
- " Air kelapa dari 1 butir kelapa"
- " Bumbu halus "
- "12 siung bawang merah"
- "6 siung bawang putih"
- "4 biji kemiri"
- "2 ruas kunyit"
- "1 ruas jahe"
- "1 sdm ketumbar"
- "1 sdt merica"
recipeinstructions:
- "Haluskan bumbu halus, sisihkan"
- "Taruh dalam panci ayam, bumbu halus, parutan lengkuas, sere, daun salam, daun jeruk, air kelapa, garam dan gula lalu ungkep hingga bumbu meresap dan ayam empuk, gunakan api sedang cenderung kecil, di resep asli memisahkan antara lengkuas parutnya dengan ayam, aq enggak, udah terlanjur 🤭, aq jadiin satu lgsg 😁"
- "Panaskan minyak, ambil beberapa potong ayam lalu goreng hingga kuning kecoklatan, angkat"
- "Ayam goreng bumbu lengkuas siap disajikan dengan sambal(resep terlampir) + lalapan, beserta nasi hangat 😋           (lihat resep)"
categories:
- Recipe
tags:
- ayam
- goreng
- bumbu

katakunci: ayam goreng bumbu 
nutrition: 181 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT56M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Goreng Bumbu Lengkuas](https://img-global.cpcdn.com/recipes/13873e7adf5cba70/751x532cq70/ayam-goreng-bumbu-lengkuas-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang harus kita jaga karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam goreng bumbu lengkuas yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Indonesia



Kedekatan keluarga dapat didapat dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Goreng Bumbu Lengkuas untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang dapat anda coba salah satunya ayam goreng bumbu lengkuas yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep ayam goreng bumbu lengkuas tanpa harus bersusah payah.
Berikut ini resep Ayam Goreng Bumbu Lengkuas yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Bumbu Lengkuas:

1. Diperlukan 1 ekor ayam, potong 8
1. Tambah 100 gr lengkuas (parut)
1. Tambah 3 lembar daun salam, remat2
1. Siapkan 6 lembar daun jeruk, remat2
1. Siapkan 2 batang sereh, geprek
1. Jangan lupa 1,5 sdm garam
1. Tambah 1 sdm gula
1. Diperlukan  Air kelapa dari 1 butir kelapa
1. Diperlukan  Bumbu halus :
1. Jangan lupa 12 siung bawang merah
1. Jangan lupa 6 siung bawang putih
1. Jangan lupa 4 biji kemiri
1. Diperlukan 2 ruas kunyit
1. Diperlukan 1 ruas jahe
1. Siapkan 1 sdm ketumbar
1. Harus ada 1 sdt merica




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Goreng Bumbu Lengkuas:

1. Haluskan bumbu halus, sisihkan
1. Taruh dalam panci ayam, bumbu halus, parutan lengkuas, sere, daun salam, daun jeruk, air kelapa, garam dan gula lalu ungkep hingga bumbu meresap dan ayam empuk, gunakan api sedang cenderung kecil, di resep asli memisahkan antara lengkuas parutnya dengan ayam, aq enggak, udah terlanjur 🤭, aq jadiin satu lgsg 😁
1. Panaskan minyak, ambil beberapa potong ayam lalu goreng hingga kuning kecoklatan, angkat
1. Ayam goreng bumbu lengkuas siap disajikan dengan sambal(resep terlampir) + lalapan, beserta nasi hangat 😋 -           (lihat resep)




Demikianlah cara membuat ayam goreng bumbu lengkuas yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan teruji, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
