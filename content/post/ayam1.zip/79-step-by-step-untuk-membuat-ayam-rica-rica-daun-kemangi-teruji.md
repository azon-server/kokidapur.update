---
description: "Step-by-Step untuk membuat Ayam rica-rica daun kemangi Teruji"
title: "Step-by-Step untuk membuat Ayam rica-rica daun kemangi Teruji"
slug: 79-step-by-step-untuk-membuat-ayam-rica-rica-daun-kemangi-teruji
date: 2020-12-04T19:30:11.525Z
image: https://img-global.cpcdn.com/recipes/6f0f4c938cbed18e/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6f0f4c938cbed18e/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6f0f4c938cbed18e/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Willie Holmes
ratingvalue: 4.4
reviewcount: 18371
recipeingredient:
- "1/2 kg ayam"
- "1 ikat daun kemangi petik sesuai selera"
- "2 daun salam"
- "1 ruas lengkuas yg digeprek"
- "2 lembar daun jeruk"
- "1 sereh yg digeprek"
- "1 sdm gula jawa"
- "secukupnya Garam dan kaldu ayam"
- " Air kaldu ayam"
- "1 gelas kecil Air"
- " Bumbu halus"
- "6 bawang merah"
- "4 bawang putih"
- "1 kemiri"
- "1 cm jahe"
- "1 cm kunyit"
- "Sdt keyumbar"
recipeinstructions:
- "Haluskan bumbu halus dengan minyak"
- "Tumis bumbu halus dan tambahkan daun salam, lengkuas, daun jeruk, sereh..tumis hingga tanak"
- "Masukan ayam dan aduk2 hingga ayam berubah menjadi putih"
- "Tambahkan 250ml air / sesuai selera, kemudian tunggu hingga mendidih"
- "Masukan gula jawa, garam dan kaldu ayam sesuai selera"
- "Aduk² dan tunggu hingga air agak menyusut"
- "Tambahkan daun kemangi, aduk2 sebentar dan matikan api"
- "Tambahkan bawang merah goreng dan siap disajikan"
categories:
- Recipe
tags:
- ayam
- ricarica
- daun

katakunci: ayam ricarica daun 
nutrition: 103 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam rica-rica daun kemangi](https://img-global.cpcdn.com/recipes/6f0f4c938cbed18e/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang harus kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica-rica daun kemangi yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan keistimewahan yang merupakan keragaman Indonesia



Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah membuat makanan Ayam rica-rica daun kemangi untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi makanan yang bisa anda contoh salah satunya ayam rica-rica daun kemangi yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep ayam rica-rica daun kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica daun kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica daun kemangi:

1. Dibutuhkan 1/2 kg ayam
1. Dibutuhkan 1 ikat daun kemangi, petik sesuai selera
1. Dibutuhkan 2 daun salam
1. Dibutuhkan 1 ruas lengkuas yg digeprek
1. Jangan lupa 2 lembar daun jeruk
1. Dibutuhkan 1 sereh yg digeprek
1. Siapkan 1 sdm gula jawa
1. Harus ada secukupnya Garam dan kaldu ayam
1. Diperlukan  Air kaldu ayam
1. Harap siapkan 1 gelas kecil Air
1. Harap siapkan  Bumbu halus
1. Siapkan 6 bawang merah
1. Jangan lupa 4 bawang putih
1. Diperlukan 1 kemiri
1. Harus ada 1 cm jahe
1. Dibutuhkan 1 cm kunyit
1. Tambah Sdt keyumbar




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica-rica daun kemangi:

1. Haluskan bumbu halus dengan minyak
1. Tumis bumbu halus dan tambahkan daun salam, lengkuas, daun jeruk, sereh..tumis hingga tanak
1. Masukan ayam dan aduk2 hingga ayam berubah menjadi putih
1. Tambahkan 250ml air / sesuai selera, kemudian tunggu hingga mendidih
1. Masukan gula jawa, garam dan kaldu ayam sesuai selera
1. Aduk² dan tunggu hingga air agak menyusut
1. Tambahkan daun kemangi, aduk2 sebentar dan matikan api
1. Tambahkan bawang merah goreng dan siap disajikan




Demikianlah cara membuat ayam rica-rica daun kemangi yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
