---
description: "Resep : Ayam Rica - Rica teraktual"
title: "Resep : Ayam Rica - Rica teraktual"
slug: 42-resep-ayam-rica-rica-teraktual
date: 2020-09-08T08:53:10.235Z
image: https://img-global.cpcdn.com/recipes/ef371d90e966c57b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ef371d90e966c57b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ef371d90e966c57b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Viola Lyons
ratingvalue: 4.2
reviewcount: 13081
recipeingredient:
- "500 gram (4 potong) ayam"
- "1 buah jeruk nipis"
- "400 ml air untuk rebusan pertama"
- "1 sdt garam"
- "1 batang serai geprek"
- "1 jempol lengkuas geprek"
- "2 jempol jahe geprek"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "1 sdt kaldu jamur"
- "1 sdt garam"
- "15 gram gula merah"
- "1 ikat daun kemangi"
- "3 sdm minyak untuk menumis"
- "300 ml air"
- " Bumbu halus"
- "16 cabe rawit"
- "5 siung bawang merah"
- "4 siung bawang putih"
- "4 biji kemiri"
- "1 telunjuk kunyit"
- "1 sdm minyak"
recipeinstructions:
- "Abis sharing sm ratu bekebon, jd pake cabe hasil bekebon🥰 lumuri ayam dengan air jeruk nipis lalu cuci bersih kemudian rebus kasih garam dan buang airnya"
- "Siapkan semua bahan dan bumbu. Blender bumbu halus, sy blender cabe setelah yg lain halus, krn biar cabe teksturnya kasar."
- "Tumis bumbu halus, daun jeruk, serei, daun salam, lengkuas, dan jahe sampai masak."
- "Lalu tambahkan ayam, aduk-aduk rata sampai tercampur. Tambahkan air, kaldu jamur, gula dan garam secukupnya. masak sampai airnya tinggal sedikit."
- "Kalau sudah sedikit airnya, masukkan kemangi.. Masak sebentar aja.. Karna nanti kemangi jadi terlalu lembek. Kemidian angkat"
- "Dan siap sajikan dengan nasi hangat😋"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 120 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica - Rica](https://img-global.cpcdn.com/recipes/ef371d90e966c57b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang harus kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica - rica yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Kita



Kehangatan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah memasak Ayam Rica - Rica untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang dapat anda contoh salah satunya ayam rica - rica yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam rica - rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica - Rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 22 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica - Rica:

1. Jangan lupa 500 gram (4 potong) ayam
1. Harap siapkan 1 buah jeruk nipis
1. Harus ada 400 ml air untuk rebusan pertama
1. Tambah 1 sdt garam
1. Harus ada 1 batang serai geprek
1. Jangan lupa 1 jempol lengkuas geprek
1. Siapkan 2 jempol jahe geprek
1. Jangan lupa 2 lembar daun jeruk
1. Diperlukan 2 lembar daun salam
1. Siapkan 1 sdt kaldu jamur
1. Jangan lupa 1 sdt garam
1. Diperlukan 15 gram gula merah
1. Siapkan 1 ikat daun kemangi
1. Diperlukan 3 sdm minyak untuk menumis
1. Diperlukan 300 ml air
1. Dibutuhkan  Bumbu halus
1. Harus ada 16 cabe rawit
1. Jangan lupa 5 siung bawang merah
1. Harap siapkan 4 siung bawang putih
1. Jangan lupa 4 biji kemiri
1. Jangan lupa 1 telunjuk kunyit
1. Siapkan 1 sdm minyak




<!--inarticleads2-->

##### Cara membuat  Ayam Rica - Rica:

1. Abis sharing sm ratu bekebon, jd pake cabe hasil bekebon🥰 lumuri ayam dengan air jeruk nipis lalu cuci bersih kemudian rebus kasih garam dan buang airnya
1. Siapkan semua bahan dan bumbu. Blender bumbu halus, sy blender cabe setelah yg lain halus, krn biar cabe teksturnya kasar.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Rica - Rica">1. Tumis bumbu halus, daun jeruk, serei, daun salam, lengkuas, dan jahe sampai masak.
1. Lalu tambahkan ayam, aduk-aduk rata sampai tercampur. Tambahkan air, kaldu jamur, gula dan garam secukupnya. - masak sampai airnya tinggal sedikit.
1. Kalau sudah sedikit airnya, masukkan kemangi.. Masak sebentar aja.. Karna nanti kemangi jadi terlalu lembek. Kemidian angkat
1. Dan siap sajikan dengan nasi hangat😋




Demikianlah cara membuat ayam rica - rica yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
