---
description: "Langkah untuk membuat Ayam Goreng Tepung Favorite"
title: "Langkah untuk membuat Ayam Goreng Tepung Favorite"
slug: 324-langkah-untuk-membuat-ayam-goreng-tepung-favorite
date: 2020-10-06T17:05:40.763Z
image: https://img-global.cpcdn.com/recipes/ac00e2c7d1e7bbde/751x532cq70/ayam-goreng-tepung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ac00e2c7d1e7bbde/751x532cq70/ayam-goreng-tepung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ac00e2c7d1e7bbde/751x532cq70/ayam-goreng-tepung-foto-resep-utama.jpg
author: Evelyn Hudson
ratingvalue: 4.6
reviewcount: 15855
recipeingredient:
- "250 gr sayap ayam potong jadi dua"
- "secukupnya Jeruk lemonnipis"
- "2 bawang putih parut"
- " Jahe sedikit parut"
- "secukupnya Garam merica"
- " Bahan basah"
- "1 butir putih telur"
- "3 sdm tepung bumbu serbaguna"
- "1 sdm tepung maizena"
- "25-50 cc air"
- "1/4 sdt baking powder"
- " Bahan kering"
- "Secukupnya tepung bumbu serbaguna  tepung maizena 31"
recipeinstructions:
- "Kerat-kerat kulit ayam supaya bumbu marinasi meresap, kucuri air perasan jeruk lemon/nipis diamkan 10 menit lalu bilas."
- "Marinasi dengan parutan bawang putih, jahe, garam dan merica selama 15 menit."
- "Campur bahan basah lalu masukkan ayam yg sudah dimarinasi, aduk rata dan diamkan sebentar."
- "Gulingkan ke tepung kering dan cubit-cubit sedikit kemudian goreng dalam minyak yg banyak dan panas menggunakan api sedang cenderung kecil."
- "Goreng kedua sisi setengah matang, lalu angkat sebentar kemudian goreng lagi untuk kedua kali supaya lebih krispi. Sajikan hangat."
- "Note: jika ingin lapisan tepung lebih tebal caranya ayam yg sudah dimarinasi gulingkan ke tepung kering &gt; adonan basah &gt; tepung kering lagi dan dicubit-cubit agak banyak supaya kriting."
categories:
- Recipe
tags:
- ayam
- goreng
- tepung

katakunci: ayam goreng tepung 
nutrition: 279 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT54M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Goreng Tepung](https://img-global.cpcdn.com/recipes/ac00e2c7d1e7bbde/751x532cq70/ayam-goreng-tepung-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang harus kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam goreng tepung yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan keistimewahan yang merupakan keragaman Indonesia



Kedekatan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah memasak Ayam Goreng Tepung untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang bisa anda contoh salah satunya ayam goreng tepung yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam goreng tepung tanpa harus bersusah payah.
Seperti resep Ayam Goreng Tepung yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 13 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Tepung:

1. Harap siapkan 250 gr sayap ayam, potong jadi dua
1. Dibutuhkan secukupnya Jeruk lemon/nipis
1. Harap siapkan 2 bawang putih, parut
1. Diperlukan  Jahe sedikit, parut
1. Diperlukan secukupnya Garam, merica
1. Dibutuhkan  Bahan basah:
1. Dibutuhkan 1 butir putih telur
1. Dibutuhkan 3 sdm tepung bumbu serbaguna
1. Siapkan 1 sdm tepung maizena
1. Jangan lupa 25-50 cc air
1. Harus ada 1/4 sdt baking powder
1. Diperlukan  Bahan kering:
1. Harus ada Secukupnya tepung bumbu serbaguna : tepung maizena 3:1




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Tepung:

1. Kerat-kerat kulit ayam supaya bumbu marinasi meresap, kucuri air perasan jeruk lemon/nipis diamkan 10 menit lalu bilas.
1. Marinasi dengan parutan bawang putih, jahe, garam dan merica selama 15 menit.
1. Campur bahan basah lalu masukkan ayam yg sudah dimarinasi, aduk rata dan diamkan sebentar.
1. Gulingkan ke tepung kering dan cubit-cubit sedikit kemudian goreng dalam minyak yg banyak dan panas menggunakan api sedang cenderung kecil.
1. Goreng kedua sisi setengah matang, lalu angkat sebentar kemudian goreng lagi untuk kedua kali supaya lebih krispi. Sajikan hangat.
1. Note: jika ingin lapisan tepung lebih tebal caranya ayam yg sudah dimarinasi gulingkan ke tepung kering &gt; adonan basah &gt; tepung kering lagi dan dicubit-cubit agak banyak supaya kriting.




Demikianlah cara membuat ayam goreng tepung yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
