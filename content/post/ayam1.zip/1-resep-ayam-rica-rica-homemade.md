---
description: "Resep : Ayam Rica-Rica Homemade"
title: "Resep : Ayam Rica-Rica Homemade"
slug: 1-resep-ayam-rica-rica-homemade
date: 2020-12-06T10:56:27.346Z
image: https://img-global.cpcdn.com/recipes/a4610e7a732e8c9c/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a4610e7a732e8c9c/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a4610e7a732e8c9c/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Pauline Ramirez
ratingvalue: 5
reviewcount: 27373
recipeingredient:
- "1 ekor Ayam sy 12 ekor"
- "1/2 Buah jeruk nipis ambil airnya"
- "2 cm Kunyit haluskan"
- "1/4 sdt Garam"
- " Bumbu Halus "
- "1 ons Cabe Kriting sy pakai 7 Buah"
- "1/2 ons cabe Rawit sy pakai 6 Buah"
- "5 siung bawang merah"
- "5 siung bawang putih sy cuma pakai 3 siung besar2"
- "2 cm jahe"
- "2 cm kunyit"
- "3 Butir kemiri"
- "2 cm Lengkuas sy skip lagi ga Punya"
- " Bumbu Kasar "
- "3 batang serai"
- "1 lembar daun pandan"
- "5 lembar daun sala"
- "5 lembar daun jeruk"
- "2 ikat daun kemangi sy skip krn ga Punya"
- "2 batang daun bawang tambahan dari Saya"
- "Secukupnya garam"
- "Sejumput Gula pasir tambahan dari Saya"
- "Secukupnya penyedap Rasa sy skip"
- "Secukupnya air matang"
- "Secukupnya Minyak goreng"
recipeinstructions:
- "Potong2 Ayam, kemudian cuci bersih, lumuri dengan kunyit yg sudah dihaluskan (bs pakai kunyit bubuk) air jeruk nipis (1 sdm) dan Garam, diamkan selama 15 Menit supaya menyerap. Setelah itu goreng ayam 1/2 Kering, sisihkan."
- "Siapkan Bumbu yang Akan di haluskan kemudian cuci bersih, Setelah itu haluskan dengan Blender, sisihkan. Siapkan bumbu Kasar, simpul daun pandan, potong2 kasar daun jeruk dan daun bawang."
- "Siapkan wajan dan beri sedikit minyak kemudian tumis bumbu halus sampai Harum kemudian masukkan, daun salam, daun pandan dan sereh, masak sampai Harum. Masukkan ayam aduk rata."
- "Beri air, masak hingga air sedikit menyusut, tambahkan Garam dan gula, aduk rata masak hingga tercampur rata, masak lagi hingga air menyusut banyak. Setelah air menyusut tambahkan daun jeruk dan daun bawang."
- "Aduk rata, masak lagi sebentar, koreksi Rasa, kemudian angkat, siap di sajikan dengan Nasi hangat, Selamat mencoba 😉🙏"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 209 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/a4610e7a732e8c9c/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang setidaknya kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica-rica yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Kita

Kedekatan keluarga bisa didapat dengan cara simple. Diantaranya adalah memasak Ayam Rica-Rica untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang bisa anda contoh salah satunya ayam rica-rica yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 25 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica:

1. Harap siapkan 1 ekor Ayam (sy 1/2 ekor)
1. Tambah 1/2 Buah jeruk nipis (ambil airnya)
1. Tambah 2 cm Kunyit (haluskan)
1. Dibutuhkan 1/4 sdt Garam
1. Harus ada  Bumbu Halus :
1. Tambah 1 ons Cabe Kriting (sy pakai 7 Buah)
1. Diperlukan 1/2 ons cabe Rawit (sy pakai 6 Buah)
1. Harus ada 5 siung bawang merah
1. Diperlukan 5 siung bawang putih (sy cuma pakai 3 siung besar2)
1. Jangan lupa 2 cm jahe
1. Diperlukan 2 cm kunyit
1. Dibutuhkan 3 Butir kemiri
1. Siapkan 2 cm Lengkuas (sy skip lagi ga Punya)
1. Jangan lupa  Bumbu Kasar :
1. Dibutuhkan 3 batang serai
1. Harus ada 1 lembar daun pandan
1. Harus ada 5 lembar daun sala
1. Jangan lupa 5 lembar daun jeruk
1. Dibutuhkan 2 ikat daun kemangi (sy skip krn ga Punya)
1. Siapkan 2 batang daun bawang (tambahan dari Saya)
1. Harus ada Secukupnya garam
1. Siapkan Sejumput Gula pasir (tambahan dari Saya)
1. Harap siapkan Secukupnya penyedap Rasa (sy skip)
1. Jangan lupa Secukupnya air matang
1. Harus ada Secukupnya Minyak goreng




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica:

1. Potong2 Ayam, kemudian cuci bersih, lumuri dengan kunyit yg sudah dihaluskan (bs pakai kunyit bubuk) air jeruk nipis (1 sdm) dan Garam, diamkan selama 15 Menit supaya menyerap. Setelah itu goreng ayam 1/2 Kering, sisihkan.
1. Siapkan Bumbu yang Akan di haluskan kemudian cuci bersih, Setelah itu haluskan dengan Blender, sisihkan. Siapkan bumbu Kasar, simpul daun pandan, potong2 kasar daun jeruk dan daun bawang.
1. Siapkan wajan dan beri sedikit minyak kemudian tumis bumbu halus sampai Harum kemudian masukkan, daun salam, daun pandan dan sereh, masak sampai Harum. Masukkan ayam aduk rata.
1. Beri air, masak hingga air sedikit menyusut, tambahkan Garam dan gula, aduk rata masak hingga tercampur rata, masak lagi hingga air menyusut banyak. Setelah air menyusut tambahkan daun jeruk dan daun bawang.
1. Aduk rata, masak lagi sebentar, koreksi Rasa, kemudian angkat, siap di sajikan dengan Nasi hangat, Selamat mencoba 😉🙏




Demikianlah cara membuat ayam rica-rica yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan teruji, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
