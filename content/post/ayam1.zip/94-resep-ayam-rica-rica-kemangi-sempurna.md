---
description: "Resep : Ayam rica-rica kemangi Sempurna"
title: "Resep : Ayam rica-rica kemangi Sempurna"
slug: 94-resep-ayam-rica-rica-kemangi-sempurna
date: 2020-08-13T03:53:10.584Z
image: https://img-global.cpcdn.com/recipes/05d55bed5d5765ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/05d55bed5d5765ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/05d55bed5d5765ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Essie Thomas
ratingvalue: 4.9
reviewcount: 43709
recipeingredient:
- "1/2 kg ayam"
- "4 lembar daun jeruk"
- "1 batang serai"
- "1 lembar daun kunyit"
- "Secukupnya daun kemangi"
- "1 buah tomat"
- "1 ruas lengkuas geprek"
- " Bumbu"
- "8 buah cabai merah"
- "6 buah cabai rawit"
- "5 siung bawang merah"
- "2 siung bawang putih"
- "4 buah kemiri geprek"
- "1 sdt bubuk kunyit"
- "1 sdt jahe dan bawang putih yg sudah digiling"
recipeinstructions:
- "Goreng ayam hingga kecoklatan"
- "Blender bumbunya hingga halus"
- "Tumis bumbu hingga harum masukan tomat serai lengkuas daun kunyit daun jeruk"
- "Aduk semuanya hingga rata beri air secukupnya"
- "Masukan ayam lalu beri garam dan kaldu bubuk secukupnya lalu masukan daun kemangi"
- "Masak hingga bumbu meresap ke ayam dan kering"
- "Ayam rica-rica kemangi siap dinikmati🤩"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 284 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/05d55bed5d5765ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga empuk. Ciri khas makanan Indonesia ayam rica-rica kemangi yang penuh dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kehangatan keluarga bisa didapat dengan cara sederhana. Salah satunya adalah memasak Ayam rica-rica kemangi untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang bisa anda buat salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica kemangi:

1. Jangan lupa 1/2 kg ayam
1. Dibutuhkan 4 lembar daun jeruk
1. Dibutuhkan 1 batang serai
1. Dibutuhkan 1 lembar daun kunyit
1. Dibutuhkan Secukupnya daun kemangi
1. Siapkan 1 buah tomat
1. Siapkan 1 ruas lengkuas geprek
1. Diperlukan  Bumbu
1. Harap siapkan 8 buah cabai merah
1. Siapkan 6 buah cabai rawit
1. Jangan lupa 5 siung bawang merah
1. Tambah 2 siung bawang putih
1. Diperlukan 4 buah kemiri geprek
1. Jangan lupa 1 sdt bubuk kunyit
1. Jangan lupa 1 sdt jahe dan bawang putih yg sudah digiling




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica-rica kemangi:

1. Goreng ayam hingga kecoklatan
1. Blender bumbunya hingga halus
1. Tumis bumbu hingga harum masukan tomat serai lengkuas daun kunyit daun jeruk
1. Aduk semuanya hingga rata beri air secukupnya
1. Masukan ayam lalu beri garam dan kaldu bubuk secukupnya lalu masukan daun kemangi
1. Masak hingga bumbu meresap ke ayam dan kering
1. Ayam rica-rica kemangi siap dinikmati🤩




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat gampang dan teruji, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
