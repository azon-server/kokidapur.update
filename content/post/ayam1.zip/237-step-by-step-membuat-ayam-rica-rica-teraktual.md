---
description: "Step-by-Step membuat Ayam rica - rica teraktual"
title: "Step-by-Step membuat Ayam rica - rica teraktual"
slug: 237-step-by-step-membuat-ayam-rica-rica-teraktual
date: 2020-08-10T06:10:08.399Z
image: https://img-global.cpcdn.com/recipes/283ffb7ce867e242/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/283ffb7ce867e242/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/283ffb7ce867e242/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Mabelle Bates
ratingvalue: 4.3
reviewcount: 19629
recipeingredient:
- "1/2 ekor ayam"
- " Jeruk nipis"
- " Bahan halus "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "2 buah cabe besar"
- "5 cabe rawit"
- " Pelengkap "
- "1 lembar daun salam"
- "3 lembar daun jeruk"
- " Serai geprok"
recipeinstructions:
- "Potong ayam beberapa bagian lalu cuci bersih, lumuri jeruk nipis lalu bilas kembali dan siapkan bahan lain nya"
- "Blender bumbu halus kemudian tumis"
- "Tumis daun salam, daun jeruk dan serai sampai harum,kemudian masukkan air kurleb 400ml"
- "Masukkan ayam lalu ungkep kurleb 15menit"
- "Jika dirasa sdh empuk tambahkan gula garam secukupnya.Aduk rata dan koreksi rasa. Ayam rica - rica siap dihidangkan"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 184 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam rica - rica](https://img-global.cpcdn.com/recipes/283ffb7ce867e242/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau renyah. Ciri kuliner Nusantara ayam rica - rica yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga bisa diperoleh dengan cara sederhana. Diantaranya adalah memasak Ayam rica - rica untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica. Resep Ayam Rica Rica Bahan: Daging Ayam Lemon juice Chicken powder Garam. Bawang merah Bawang putih Cabe Jahe Serai Daun jeruk purut Daun kucai.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang dapat anda praktekkan salah satunya ayam rica - rica yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica - rica tanpa harus bersusah payah.
Berikut ini resep Ayam rica - rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica - rica:

1. Harus ada 1/2 ekor ayam
1. Dibutuhkan  Jeruk nipis
1. Diperlukan  Bahan halus :
1. Diperlukan 5 siung bawang merah
1. Jangan lupa 3 siung bawang putih
1. Harus ada 2 buah cabe besar
1. Harus ada 5 cabe rawit
1. Jangan lupa  Pelengkap :
1. Tambah 1 lembar daun salam
1. Harus ada 3 lembar daun jeruk
1. Diperlukan  Serai geprok


Cara pembuatan ayam rica-rica tidaklah sulit. Dibutuhkan bahan-bahan seperti daun jeruk, serai, dan daun pandan agar aromanya menjadi kuat dan khas. Tak hanya ayam, anda juga bisa memasak. Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica - rica:

1. Potong ayam beberapa bagian lalu cuci bersih, lumuri jeruk nipis lalu bilas kembali dan siapkan bahan lain nya
1. Blender bumbu halus kemudian tumis
1. Tumis daun salam, daun jeruk dan serai sampai harum,kemudian masukkan air kurleb 400ml
1. Masukkan ayam lalu ungkep kurleb 15menit
1. Jika dirasa sdh empuk tambahkan gula garam secukupnya.Aduk rata dan koreksi rasa. Ayam rica - rica siap dihidangkan


Tak hanya ayam, anda juga bisa memasak. Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas. Kita masak Ayam Rica-Rica aja yuk. Tapi biar lebih nikmat kita tambahi rasa manis sedikit. 

Demikianlah cara membuat ayam rica - rica yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
