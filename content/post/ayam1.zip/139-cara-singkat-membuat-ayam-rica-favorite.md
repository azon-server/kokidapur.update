---
description: "Cara singkat membuat Ayam Rica Favorite"
title: "Cara singkat membuat Ayam Rica Favorite"
slug: 139-cara-singkat-membuat-ayam-rica-favorite
date: 2020-11-04T11:57:16.743Z
image: https://img-global.cpcdn.com/recipes/ae991bfbd9128cf6/751x532cq70/ayam-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ae991bfbd9128cf6/751x532cq70/ayam-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ae991bfbd9128cf6/751x532cq70/ayam-rica-foto-resep-utama.jpg
author: Beulah Vaughn
ratingvalue: 4.2
reviewcount: 37207
recipeingredient:
- "1/2 ayam potong potong cuci"
- " Bumbu halus"
- "4 kemiri"
- "2 bawang putih"
- "8 bawang merah sy gapake habis"
- "1/2 bawang bombay"
- "1 ruas jahe"
- " Cabai"
- " Bumbu lain"
- "2 daun salam"
- "5 daun jeruk buang tulangnya"
- "3 cm kunyit"
- " Lengkuas geprek"
- " Serai geprek"
- " Cabai rawit pedas gelondongan"
- " Mrica bubuk"
- " Royco Kaldu ayam bubuk"
- "Secukupnya garam"
- "1 sdt gula jawa pasir"
- " Daun bawang Onclang"
- "Segenggam daun kemangi"
- " Brambang goreng"
recipeinstructions:
- "Haluskan bumbu halus, tumis beserta daun jeruk serai lengkuas, masukkan ayam dan 1 gelas air. Oya cabainya sy terakhir krn masak buat sikecil jg."
- "Masukkan kaldu bubuk garam mrica, gula masak hingga agak susut airnya, tambahkan ulegan cabai dan cabai glondongan, aduk hingga menyusut airnya. Cek rasa, (disini sy sisihkan buat sikecil yg ga pedes dan sy tambahkan santan untuk sikecil)."
- "Beri 1 sdm minyak, potongan daun bawang+ kemangi, aduk rata, segera matikan kompor."
- "Sajikan dgn taburan bawang merah goreng."
categories:
- Recipe
tags:
- ayam
- rica

katakunci: ayam rica 
nutrition: 194 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT31M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica](https://img-global.cpcdn.com/recipes/ae991bfbd9128cf6/751x532cq70/ayam-rica-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang harus kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan ciri khas yang merupakan keragaman Indonesia



Kedekatan rumah tangga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak Ayam Rica untuk keluarga. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang bisa anda coba salah satunya ayam rica yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica tanpa harus bersusah payah.
Seperti resep Ayam Rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 22 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica:

1. Harus ada 1/2 ayam, potong potong cuci
1. Siapkan  Bumbu halus
1. Harap siapkan 4 kemiri
1. Jangan lupa 2 bawang putih
1. Tambah 8 bawang merah (sy gapake habis😂)
1. Harus ada 1/2 bawang bombay
1. Harus ada 1 ruas jahe
1. Dibutuhkan  Cabai
1. Dibutuhkan  Bumbu lain
1. Harus ada 2 daun salam
1. Dibutuhkan 5 daun jeruk buang tulangnya
1. Harap siapkan 3 cm kunyit
1. Diperlukan  Lengkuas, geprek
1. Dibutuhkan  Serai, geprek
1. Jangan lupa  Cabai rawit pedas gelondongan
1. Jangan lupa  Mrica bubuk
1. Siapkan  Royco/ Kaldu ayam bubuk
1. Harus ada Secukupnya garam
1. Diperlukan 1 sdt gula jawa/ pasir
1. Dibutuhkan  Daun bawang/ Onclang
1. Tambah Segenggam daun kemangi
1. Harus ada  Brambang goreng




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica:

1. Haluskan bumbu halus, tumis beserta daun jeruk serai lengkuas, masukkan ayam dan 1 gelas air. Oya cabainya sy terakhir krn masak buat sikecil jg.
1. Masukkan kaldu bubuk garam mrica, gula masak hingga agak susut airnya, tambahkan ulegan cabai dan cabai glondongan, aduk hingga menyusut airnya. Cek rasa, (disini sy sisihkan buat sikecil yg ga pedes dan sy tambahkan santan untuk sikecil).
1. Beri 1 sdm minyak, potongan daun bawang+ kemangi, aduk rata, segera matikan kompor.
1. Sajikan dgn taburan bawang merah goreng.




Demikianlah cara membuat ayam rica yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
