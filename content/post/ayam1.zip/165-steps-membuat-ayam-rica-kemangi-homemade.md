---
description: "Steps membuat Ayam Rica Kemangi Homemade"
title: "Steps membuat Ayam Rica Kemangi Homemade"
slug: 165-steps-membuat-ayam-rica-kemangi-homemade
date: 2020-10-13T18:56:14.010Z
image: https://img-global.cpcdn.com/recipes/7de92ab039fcae18/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7de92ab039fcae18/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7de92ab039fcae18/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Lillie Higgins
ratingvalue: 4.6
reviewcount: 31629
recipeingredient:
- "1 ekor Ayam potong 10 bagian"
- "2 genggam Daun Kemangi"
- " Bumbu dihaluskan "
- "8 siung Bawang merah"
- "3 siung Bawang putih"
- "14 buah Cabe merah keriting"
- "3 butir Kemiri sangrai"
- " Bumbu Ungkep "
- "2 batang Sereh geprek"
- "2 ruas jari Jahe ulek kasar"
- "3 ruas jari Kunyit ulek kasar"
- "1 buah Tomat ulek kasar"
- "3 siung Bawang merah"
- "3 siung Bawang putih"
- "3 lembar Daun salam"
- "3 lembar Daun jeruk"
- "Secukupnya Gula garam lada dan penyedap rasa"
- "Segelas Air"
recipeinstructions:
- "Siapkan semua bahan beserta bumbu halus dan bumbu ungkep nya."
- "Tumis bumbu ungkep hingga harum. Masukkan ayam. Aduk hingga bumbu rata di ayamnya. Baru masukkan air. Beri gula, garam, lada dan penyedap rasa. Cicipi rasa. Masak hingga airnya surut dan bumbu meresap."
- "Tumis bumbu yang di haluskan hingga harum. Masukkan ke dalam ayam yang sudah di ungkep beserta daun kemanginya. Masak hingga semua tercampur rata dan mengental bumbunya."
- "Ketika sudah terlihat mengental semua. Matikan apinya dan sajikan hangat 😍"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 282 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/7de92ab039fcae18/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga renyah. Ciri masakan Nusantara ayam rica kemangi yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga bisa didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica Kemangi untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang bisa anda buat salah satunya ayam rica kemangi yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Siapkan 1 ekor Ayam potong 10 bagian
1. Jangan lupa 2 genggam Daun Kemangi
1. Diperlukan  Bumbu dihaluskan :
1. Tambah 8 siung Bawang merah
1. Harus ada 3 siung Bawang putih
1. Dibutuhkan 14 buah Cabe merah keriting
1. Harus ada 3 butir Kemiri, sangrai
1. Harus ada  Bumbu Ungkep :
1. Harus ada 2 batang Sereh, geprek
1. Harus ada 2 ruas jari Jahe, ulek kasar
1. Harap siapkan 3 ruas jari Kunyit, ulek kasar
1. Diperlukan 1 buah Tomat, ulek kasar
1. Diperlukan 3 siung Bawang merah
1. Harus ada 3 siung Bawang putih
1. Jangan lupa 3 lembar Daun salam
1. Harus ada 3 lembar Daun jeruk
1. Tambah Secukupnya Gula, garam, lada dan penyedap rasa
1. Tambah Segelas Air




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Kemangi:

1. Siapkan semua bahan beserta bumbu halus dan bumbu ungkep nya.
1. Tumis bumbu ungkep hingga harum. Masukkan ayam. Aduk hingga bumbu rata di ayamnya. Baru masukkan air. Beri gula, garam, lada dan penyedap rasa. Cicipi rasa. Masak hingga airnya surut dan bumbu meresap.
1. Tumis bumbu yang di haluskan hingga harum. Masukkan ke dalam ayam yang sudah di ungkep beserta daun kemanginya. Masak hingga semua tercampur rata dan mengental bumbunya.
1. Ketika sudah terlihat mengental semua. Matikan apinya dan sajikan hangat 😍




Demikianlah cara membuat ayam rica kemangi yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
