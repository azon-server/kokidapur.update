---
description: "Resep : Ayam Goreng Sambal Ijo Sempurna"
title: "Resep : Ayam Goreng Sambal Ijo Sempurna"
slug: 445-resep-ayam-goreng-sambal-ijo-sempurna
date: 2020-11-21T03:46:24.172Z
image: https://img-global.cpcdn.com/recipes/90f45eebe554a49d/751x532cq70/ayam-goreng-sambal-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/90f45eebe554a49d/751x532cq70/ayam-goreng-sambal-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/90f45eebe554a49d/751x532cq70/ayam-goreng-sambal-ijo-foto-resep-utama.jpg
author: Agnes Perez
ratingvalue: 4.3
reviewcount: 26974
recipeingredient:
- "1/2 ekor Ayam"
- "1 ikat Kemangi"
- "2 buah Mentimun"
- "Secukupnya Kol"
- " Bahan Bumbu Ungkep "
- "6 siung Bawang Merah"
- "3 siung Bawang Putih"
- "1 buah Kunyit"
- "Sejempol Jahe"
- "1 sdm Ketumbar Bubuk"
- "1 buah Daun Salam"
- "Secukupnya Garam"
- "1 sdm Minyak Goreng"
- " Bahan Sambal Ijo "
- "Secukupnya Cabe Ijo sesuai selera"
- "5 siung Bawang Merah"
- "3 siung Bawang Putih"
- "3 buah Tomat Hijau"
- "Secukupnya Garam"
- "Secukupnya Gula"
- "Secukupnya Minyak Goreng"
recipeinstructions:
- "Siapkan semua bahan. Cuci bersih ayam serta bahan lainnya."
- "Siapkan bahan bumbu, cabe ijo, tomat hijau, bawang merah dan bawang putih, lalu rebus. Rebusan tidak usah terlalu lama, angkat lalu ulek rebusan cabai, tambahkan gula dan garam secukupnya. Panaskan minyak kemudian masukkan sambal ijo nya, aduk rata. Tes rasa. Angkat jika sudah terlihat matang ya."
- "Tuang bumbu ungkep yang sudah di haluskan (aku pake blender) dan daun salam di wajan/panci yang sudah di siapkan ayamnya. Tambahkan air. Tunggu sampai bumbu meresap dan air ungkepan berkurang."
- "Jika sudah selesai ungkepannya, angkat dan tiriskan. Karena ayamnya aku potong 6 buah dan aku hanya goreng 2 buah Sajam Jadi sisa ayam aku simpan dalam wadah dan masukkan ke dalam kulkas."
- "Goreng ayam hingga matang kecoklatan. Tiriskan."
- "Tata ayam dan lalapan di piring, kemudian tambahkan sambal ijonya. Dan ayam goreng sambal ijo siap dinikmati 😍."
categories:
- Recipe
tags:
- ayam
- goreng
- sambal

katakunci: ayam goreng sambal 
nutrition: 172 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Goreng Sambal Ijo](https://img-global.cpcdn.com/recipes/90f45eebe554a49d/751x532cq70/ayam-goreng-sambal-ijo-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga gurih. Ciri masakan Indonesia ayam goreng sambal ijo yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam Goreng Sambal Ijo untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi resep yang bisa anda buat salah satunya ayam goreng sambal ijo yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep ayam goreng sambal ijo tanpa harus bersusah payah.
Seperti resep Ayam Goreng Sambal Ijo yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 21 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Sambal Ijo:

1. Harap siapkan 1/2 ekor Ayam
1. Diperlukan 1 ikat Kemangi
1. Harap siapkan 2 buah Mentimun
1. Siapkan Secukupnya Kol
1. Jangan lupa  Bahan Bumbu Ungkep :
1. Tambah 6 siung Bawang Merah
1. Siapkan 3 siung Bawang Putih
1. Harap siapkan 1 buah Kunyit
1. Harus ada Sejempol Jahe
1. Diperlukan 1 sdm Ketumbar Bubuk
1. Tambah 1 buah Daun Salam
1. Diperlukan Secukupnya Garam
1. Diperlukan 1 sdm Minyak Goreng
1. Siapkan  Bahan Sambal Ijo :
1. Dibutuhkan Secukupnya Cabe Ijo (sesuai selera)
1. Harap siapkan 5 siung Bawang Merah
1. Tambah 3 siung Bawang Putih
1. Dibutuhkan 3 buah Tomat Hijau
1. Dibutuhkan Secukupnya Garam
1. Diperlukan Secukupnya Gula
1. Jangan lupa Secukupnya Minyak Goreng




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Sambal Ijo:

1. Siapkan semua bahan. Cuci bersih ayam serta bahan lainnya.
1. Siapkan bahan bumbu, cabe ijo, tomat hijau, bawang merah dan bawang putih, lalu rebus. Rebusan tidak usah terlalu lama, angkat lalu ulek rebusan cabai, tambahkan gula dan garam secukupnya. Panaskan minyak kemudian masukkan sambal ijo nya, aduk rata. Tes rasa. Angkat jika sudah terlihat matang ya.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Goreng Sambal Ijo">1. Tuang bumbu ungkep yang sudah di haluskan (aku pake blender) dan daun salam di wajan/panci yang sudah di siapkan ayamnya. Tambahkan air. Tunggu sampai bumbu meresap dan air ungkepan berkurang.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Goreng Sambal Ijo">1. Jika sudah selesai ungkepannya, angkat dan tiriskan. Karena ayamnya aku potong 6 buah dan aku hanya goreng 2 buah Sajam Jadi sisa ayam aku simpan dalam wadah dan masukkan ke dalam kulkas.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Goreng Sambal Ijo"><img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Goreng Sambal Ijo">1. Goreng ayam hingga matang kecoklatan. Tiriskan.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Goreng Sambal Ijo">1. Tata ayam dan lalapan di piring, kemudian tambahkan sambal ijonya. Dan ayam goreng sambal ijo siap dinikmati 😍.




Demikianlah cara membuat ayam goreng sambal ijo yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan terbukti, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
