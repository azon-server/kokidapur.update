---
description: "Resep : Ayam rica special Luar biasa"
title: "Resep : Ayam rica special Luar biasa"
slug: 96-resep-ayam-rica-special-luar-biasa
date: 2020-10-19T04:05:57.576Z
image: https://img-global.cpcdn.com/recipes/de2cff17d10e7e27/751x532cq70/ayam-rica-special-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/de2cff17d10e7e27/751x532cq70/ayam-rica-special-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/de2cff17d10e7e27/751x532cq70/ayam-rica-special-foto-resep-utama.jpg
author: Alan Stevenson
ratingvalue: 4.5
reviewcount: 45018
recipeingredient:
- "2 potong ayam di rebus dulu ya bund"
- "1 sere di geprek"
- "secukupnya Kemangi"
- "1 ruas lengkuas di geprek"
- " Bumbu halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "10 cabe rawit kecil"
- "1 ruas kunyit"
- "1/2 ruas jahe"
- "2 kemiri"
- " Bumbu pelengkap"
- " Garam masako kecap saori gula pasir secukupnya semua"
recipeinstructions:
- "Tumis bumbu halus, tumis sampai harum masukkan sere, lengkuas dan ayam, tunggu sampai harum."
- "Masukkan sedikit air, masukan bumbu pelengkap, tunggu air menyusut dan koreksi rasa."
- "Terakhir masukan kemangi, jika rasa sudah pas, tunggu kemangi layu lalu sajikan."
- "Jangan lupa pakai taburan cinta ya bun, biar suami dan putra putri makin lahap 😁 canda ya bund 🤭"
categories:
- Recipe
tags:
- ayam
- rica
- special

katakunci: ayam rica special 
nutrition: 116 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica special](https://img-global.cpcdn.com/recipes/de2cff17d10e7e27/751x532cq70/ayam-rica-special-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan enak. Ciri khas makanan Nusantara ayam rica special yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan rumah tangga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam rica special untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang bisa anda coba salah satunya ayam rica special yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica special tanpa harus bersusah payah.
Berikut ini resep Ayam rica special yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 13 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica special:

1. Siapkan 2 potong ayam (di rebus dulu ya bund)
1. Diperlukan 1 sere di geprek
1. Diperlukan secukupnya Kemangi
1. Harap siapkan 1 ruas lengkuas di geprek
1. Diperlukan  Bumbu halus
1. Siapkan 5 siung bawang merah
1. Harap siapkan 3 siung bawang putih
1. Diperlukan 10 cabe rawit kecil
1. Diperlukan 1 ruas kunyit
1. Diperlukan 1/2 ruas jahe
1. Diperlukan 2 kemiri
1. Dibutuhkan  Bumbu pelengkap
1. Dibutuhkan  Garam, masako, kecap, saori, gula pasir (secukupnya semua)




<!--inarticleads2-->

##### Langkah membuat  Ayam rica special:

1. Tumis bumbu halus, tumis sampai harum masukkan sere, lengkuas dan ayam, tunggu sampai harum.
1. Masukkan sedikit air, masukan bumbu pelengkap, tunggu air menyusut dan koreksi rasa.
1. Terakhir masukan kemangi, jika rasa sudah pas, tunggu kemangi layu lalu sajikan.
1. Jangan lupa pakai taburan cinta ya bun, biar suami dan putra putri makin lahap 😁 canda ya bund 🤭




Demikianlah cara membuat ayam rica special yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan cepat, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
