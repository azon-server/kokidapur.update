---
description: "Cara membuat Ayam Rica-Rica Kemangi Terbukti"
title: "Cara membuat Ayam Rica-Rica Kemangi Terbukti"
slug: 143-cara-membuat-ayam-rica-rica-kemangi-terbukti
date: 2020-09-05T19:06:56.505Z
image: https://img-global.cpcdn.com/recipes/11e4867b3d2ff2a5/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/11e4867b3d2ff2a5/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/11e4867b3d2ff2a5/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Clifford Page
ratingvalue: 4
reviewcount: 13100
recipeingredient:
- "1 Ekor Ayam Anggaran 700800gr"
- "7 Cabe Rawit Utuh Untuk Dimasak Utuh2x Sama Ayamnya Nanti"
- "1 Batang Sereh"
- "2 Lembar Daun Salam"
- "3 Lembar Daun Jeruk"
- "1 Buah Jeruk Nipis"
- "Sesuai Selera Daun Kemangi"
- " Bumbu Halus"
- "10 Cabe Merah Keriting"
- "10 Cabe Rawit"
- "10 Bawang Merah"
- "5 Bawang Putih"
- "3 Kemiri"
- "2 Ruas Jari Kunyit"
- "1 Ruas Jari Jahe"
- "Secukupnya Air"
- " Seasoning"
- " Kaldu Ayam Bubuk Garam Gula Lada Sesuai Selera"
recipeinstructions:
- "Potong2x ayam sesuai selera, kalau aku ayamnya dipotong 10..."
- "Haluskan semua bahan bumbu halus, kemudian tumis sampai tanak dan bau langunya hilang. Jangan lupa masukan Sereh, Salam dan Daun Jeruknya..."
- "Setelah bumbu matang, masukan 300ml air, didihkan, kemudian masukan ayamnya..."
- "Tambahkan seasoning seperti Kaldu ayam bubuk, Garam, Lada, Gula sesuai selera, koreksi rasanya kemudian aduk rata..."
- "Masak sampai ayamnya matang dan airnya menyusut, kemudian masukan Kemanginya, aduk sebentar aja kemudian matikan apinya..."
- "Terakhir peras Air Jeruk Nipis dan aduk rata lagi, lalu Ayam Rica-ricanya siap untuk disajikan...."
- "Semoga Suka Sama Resepnya ya... Untuk Yang Recook di Instagram Jgn Lupa Hashtag #ResepDariWonderland atau Langsung aja Tag ke @dapurdiwonderland"
- "Makasih... Selamat Mencoba... 😁😁"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 292 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/11e4867b3d2ff2a5/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan renyah. Ciri makanan Nusantara ayam rica-rica kemangi yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica-Rica Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang dapat anda contoh salah satunya ayam rica-rica kemangi yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Kemangi:

1. Diperlukan 1 Ekor Ayam Anggaran 700-800gr
1. Tambah 7 Cabe Rawit Utuh (Untuk Dimasak Utuh2x Sama Ayamnya Nanti)
1. Harap siapkan 1 Batang Sereh
1. Harap siapkan 2 Lembar Daun Salam
1. Siapkan 3 Lembar Daun Jeruk
1. Siapkan 1 Buah Jeruk Nipis
1. Diperlukan Sesuai Selera Daun Kemangi
1. Harap siapkan  Bumbu Halus
1. Tambah 10 Cabe Merah Keriting
1. Tambah 10 Cabe Rawit
1. Tambah 10 Bawang Merah
1. Dibutuhkan 5 Bawang Putih
1. Dibutuhkan 3 Kemiri
1. Jangan lupa 2 Ruas Jari Kunyit
1. Siapkan 1 Ruas Jari Jahe
1. Jangan lupa Secukupnya Air
1. Tambah  Seasoning
1. Harus ada  Kaldu Ayam Bubuk, Garam, Gula, Lada (Sesuai Selera)




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica Kemangi:

1. Potong2x ayam sesuai selera, kalau aku ayamnya dipotong 10...
1. Haluskan semua bahan bumbu halus, kemudian tumis sampai tanak dan bau langunya hilang. Jangan lupa masukan Sereh, Salam dan Daun Jeruknya...
1. Setelah bumbu matang, masukan 300ml air, didihkan, kemudian masukan ayamnya...
1. Tambahkan seasoning seperti Kaldu ayam bubuk, Garam, Lada, Gula sesuai selera, koreksi rasanya kemudian aduk rata...
1. Masak sampai ayamnya matang dan airnya menyusut, kemudian masukan Kemanginya, aduk sebentar aja kemudian matikan apinya...
1. Terakhir peras Air Jeruk Nipis dan aduk rata lagi, lalu Ayam Rica-ricanya siap untuk disajikan....
1. Semoga Suka Sama Resepnya ya... Untuk Yang Recook di Instagram Jgn Lupa Hashtag #ResepDariWonderland atau Langsung aja Tag ke @dapurdiwonderland
1. Makasih... Selamat Mencoba... 😁😁




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan terbukti, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
