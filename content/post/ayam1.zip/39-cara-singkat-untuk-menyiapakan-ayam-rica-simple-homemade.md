---
description: "Cara singkat untuk menyiapakan Ayam rica simple Homemade"
title: "Cara singkat untuk menyiapakan Ayam rica simple Homemade"
slug: 39-cara-singkat-untuk-menyiapakan-ayam-rica-simple-homemade
date: 2020-11-29T04:13:21.266Z
image: https://img-global.cpcdn.com/recipes/8e809a03080b32c7/751x532cq70/ayam-rica-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8e809a03080b32c7/751x532cq70/ayam-rica-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8e809a03080b32c7/751x532cq70/ayam-rica-simple-foto-resep-utama.jpg
author: Cordelia Kennedy
ratingvalue: 4.8
reviewcount: 8344
recipeingredient:
- "1 ekor ayam"
- " Bumbu halus"
- "8 Bawang Merah"
- "5 Bawang Putih"
- " Jahe seruas jempol"
- " Lengkuas seruas jempol"
- "3 kemiri sangrai"
- " Bumbu kasar"
- " Cabe rawit sesuai keinginan"
- "1 batang serai iris iris"
- "3 daun jeruk buang batang tengah setelah itu iris iris"
- "2 daun salam Tidak usah diris"
- "2 Irisan buah jeruk dipakai setelah ayam matang"
- " Bahan pelengkap"
- "Sdt ladamerica bubuk"
- "Sdt ketumbar bubuk"
- "secukupnya Garam"
- "secukupnya Kecap"
- "Secukupnya gula"
- "Secukupnya air"
recipeinstructions:
- "Potong ayam menjadi kecil kecil"
- "Didihkan air, rebus ayam hingga matang dan sisihkan"
- "Panaskan minyak, Tumis bumbu iris sampai wangi dan setelah itu langsung masukan bumbu halus"
- "Semua bumbu sudah matang masukan ayam, dan masukkan bumbu pelengkap (masak ayam dengan api kecil biar bumbu meresap)"
- "Tunggu air menyusut sesuai keinginan. Tambahkan perasaan air jeruk 2 iris"
- "Cek rasa. Siap dihidangkan sama nasi hangat♥️"
categories:
- Recipe
tags:
- ayam
- rica
- simple

katakunci: ayam rica simple 
nutrition: 245 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica simple](https://img-global.cpcdn.com/recipes/8e809a03080b32c7/751x532cq70/ayam-rica-simple-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga renyah. Ciri khas masakan Nusantara ayam rica simple yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam rica simple untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang dapat anda coba salah satunya ayam rica simple yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep ayam rica simple tanpa harus bersusah payah.
Berikut ini resep Ayam rica simple yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica simple:

1. Harap siapkan 1 ekor ayam
1. Siapkan  Bumbu halus
1. Diperlukan 8 Bawang Merah
1. Tambah 5 Bawang Putih
1. Siapkan  Jahe (seruas jempol)
1. Harus ada  Lengkuas (seruas jempol)
1. Dibutuhkan 3 kemiri sangrai
1. Tambah  Bumbu kasar
1. Diperlukan  Cabe rawit (sesuai keinginan)
1. Tambah 1 batang serai (iris iris)
1. Jangan lupa 3 daun jeruk (buang batang tengah setelah itu iris iris)
1. Dibutuhkan 2 daun salam (Tidak usah diris)
1. Dibutuhkan 2 Irisan buah jeruk (dipakai setelah ayam matang)
1. Harap siapkan  Bahan pelengkap
1. Jangan lupa Sdt lada/merica bubuk
1. Harus ada Sdt ketumbar bubuk
1. Harus ada secukupnya Garam
1. Harap siapkan secukupnya Kecap
1. Diperlukan Secukupnya gula
1. Jangan lupa Secukupnya air




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica simple:

1. Potong ayam menjadi kecil kecil
1. Didihkan air, rebus ayam hingga matang dan sisihkan
1. Panaskan minyak, Tumis bumbu iris sampai wangi dan setelah itu langsung masukan bumbu halus
1. Semua bumbu sudah matang masukan ayam, dan masukkan bumbu pelengkap (masak ayam dengan api kecil biar bumbu meresap)
1. Tunggu air menyusut sesuai keinginan. Tambahkan perasaan air jeruk 2 iris
1. Cek rasa. Siap dihidangkan sama nasi hangat♥️




Demikianlah cara membuat ayam rica simple yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
