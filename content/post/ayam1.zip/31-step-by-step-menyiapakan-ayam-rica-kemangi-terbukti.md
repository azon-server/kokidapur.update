---
description: "Step-by-Step menyiapakan Ayam rica kemangi Terbukti"
title: "Step-by-Step menyiapakan Ayam rica kemangi Terbukti"
slug: 31-step-by-step-menyiapakan-ayam-rica-kemangi-terbukti
date: 2021-01-23T21:44:36.375Z
image: https://img-global.cpcdn.com/recipes/ff594703b5ac9a60/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ff594703b5ac9a60/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ff594703b5ac9a60/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Max Fernandez
ratingvalue: 4.8
reviewcount: 47221
recipeingredient:
- "1/2 kg ayam potongan paha"
- " Bumbu halus"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "10 buah cabai rawit"
- "1 buah cabai merah besar"
- "2 butir kemiri"
- "1 cm kunyit"
- " Bumbu cemplung"
- "1/2 ikat kemangi"
- "2 batang sereh"
- "3 lbr daun salam"
- "5 lbr daun jeruk"
- "2 cm lengkuas dikeprak"
- "2 cm jahe dikeprak"
- " Gula"
- " Garam"
- " Penyedap"
recipeinstructions:
- "Siapkan ayam yang sudah dipotong beberapa bagian. Cuci dan marinasi dengan jeruk nipis, sisihkan"
- "Siapkan bumbu halus dan bumbu cemplung"
- "Tumis bumbu halus beserta daun jeruk, sereh, salam, lengkuas dan jahe. Tumis hingga harum dan matang sempurna (biasanya minyak sudah terpisah dari bumbu)."
- "Tambahkan air secukupnya dan masukkan ayam yang telah di marinasi. Tunggu hingga mendidih dan bumbu surut kurang lebih 20 menit dengan api kecil."
- "Koreksi rasa, jika sudah pas masukkan kemangi. Bolak balik sebentar hingga kemangi layu, angkat dan siap disajikan."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 187 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT44M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/ff594703b5ac9a60/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica kemangi yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Indonesia



Keharmonisan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam rica kemangi untuk orang di rumah. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang bisa anda buat salah satunya ayam rica kemangi yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi:

1. Harus ada 1/2 kg ayam potongan paha
1. Siapkan  Bumbu halus
1. Jangan lupa 6 siung bawang merah
1. Harus ada 3 siung bawang putih
1. Tambah 10 buah cabai rawit
1. Harap siapkan 1 buah cabai merah besar
1. Jangan lupa 2 butir kemiri
1. Harap siapkan 1 cm kunyit
1. Diperlukan  Bumbu cemplung
1. Harus ada 1/2 ikat kemangi
1. Jangan lupa 2 batang sereh
1. Harus ada 3 lbr daun salam
1. Dibutuhkan 5 lbr daun jeruk
1. Dibutuhkan 2 cm lengkuas dikeprak
1. Harap siapkan 2 cm jahe dikeprak
1. Diperlukan  Gula
1. Jangan lupa  Garam
1. Diperlukan  Penyedap




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica kemangi:

1. Siapkan ayam yang sudah dipotong beberapa bagian. Cuci dan marinasi dengan jeruk nipis, sisihkan
1. Siapkan bumbu halus dan bumbu cemplung
1. Tumis bumbu halus beserta daun jeruk, sereh, salam, lengkuas dan jahe. Tumis hingga harum dan matang sempurna (biasanya minyak sudah terpisah dari bumbu).
1. Tambahkan air secukupnya dan masukkan ayam yang telah di marinasi. Tunggu hingga mendidih dan bumbu surut kurang lebih 20 menit dengan api kecil.
1. Koreksi rasa, jika sudah pas masukkan kemangi. Bolak balik sebentar hingga kemangi layu, angkat dan siap disajikan.




Demikianlah cara membuat ayam rica kemangi yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan teruji, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
