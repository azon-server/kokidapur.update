---
description: "Bagaimana menyiapakan Ayam rica-rica kemangi Teruji"
title: "Bagaimana menyiapakan Ayam rica-rica kemangi Teruji"
slug: 61-bagaimana-menyiapakan-ayam-rica-rica-kemangi-teruji
date: 2020-11-08T05:42:05.462Z
image: https://img-global.cpcdn.com/recipes/350af9a22f60ab8d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/350af9a22f60ab8d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/350af9a22f60ab8d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Willie Keller
ratingvalue: 4.8
reviewcount: 43882
recipeingredient:
- "500 gr daging ayam"
- "1 ikat kemangi petik daun nya"
- "1 batang daun bawang potong2 me skip"
- "3 lembar daun bawang"
- "1 batang sere geprek"
- "1 ruas lengkuas geprek"
- "secukupnya Garam gula pasir penyedap"
- "500 ml air  selera saja"
- " Bumbu halus"
- "10 cabe merah keriting"
- "10 cabe rawit merah"
- "5 siung bawang merah"
- "3 Siung bawang putih"
- "3 butir kemiri sangrai"
- "1 ruas kunyit"
- "1 ruas jahe"
recipeinstructions:
- "Potong-potong daging ayam sesuai selera,cuci bersih,beri perasan jeruk nipis diamkan sebentar lalu cuci bersih"
- "Tumis bumbu halus, daun jeruk,sere dan lengkuas hingga harum,lalu masukan ayam nya,aduk hingga ayam berubah warna"
- "Lalu masukan air,aduk rata hingga airnya macak²,masukan gula pasir,garam, penyadap secukupnya tes rasa"
- "Setelah airnya menyusut,dan lima menit sebelum d angkat,masukan potongan daun bawang dan kemangi,aduk sebentar saja lalu angkat dan siap d sajikan"
- "Selamat mencoba"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 191 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/350af9a22f60ab8d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica-rica kemangi yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Nusantara

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Kedekatan rumah tangga bisa ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam rica-rica kemangi untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang dapat anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica kemangi:

1. Diperlukan 500 gr daging ayam
1. Harap siapkan 1 ikat kemangi petik daun nya
1. Harap siapkan 1 batang daun bawang potong2 (me skip?
1. Tambah 3 lembar daun bawang
1. Diperlukan 1 batang sere geprek
1. Dibutuhkan 1 ruas lengkuas geprek
1. Harus ada secukupnya Garam, gula pasir, penyedap
1. Siapkan 500 ml air / selera saja
1. Tambah  Bumbu halus
1. Dibutuhkan 10 cabe merah keriting
1. Dibutuhkan 10 cabe rawit merah
1. Harap siapkan 5 siung bawang merah
1. Tambah 3 Siung bawang putih
1. Jangan lupa 3 butir kemiri sangrai
1. Dibutuhkan 1 ruas kunyit
1. Dibutuhkan 1 ruas jahe


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica-rica kemangi:

1. Potong-potong daging ayam sesuai selera,cuci bersih,beri perasan jeruk nipis diamkan sebentar lalu cuci bersih
1. Tumis bumbu halus, daun jeruk,sere dan lengkuas hingga harum,lalu masukan ayam nya,aduk hingga ayam berubah warna
1. Lalu masukan air,aduk rata hingga airnya macak²,masukan gula pasir,garam, penyadap secukupnya tes rasa
1. Setelah airnya menyusut,dan lima menit sebelum d angkat,masukan potongan daun bawang dan kemangi,aduk sebentar saja lalu angkat dan siap d sajikan
1. Selamat mencoba


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat mudah dan terbukti, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
