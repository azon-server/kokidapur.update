---
description: "Langkah untuk membuat Ayam Bumbu Rujak Cepat"
title: "Langkah untuk membuat Ayam Bumbu Rujak Cepat"
slug: 490-langkah-untuk-membuat-ayam-bumbu-rujak-cepat
date: 2020-12-25T23:11:37.879Z
image: https://img-global.cpcdn.com/recipes/40aa883eed473e95/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/40aa883eed473e95/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/40aa883eed473e95/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
author: Theodore Moran
ratingvalue: 4.8
reviewcount: 14639
recipeingredient:
- "1 ekor ayam"
- "2 buah jeruk nipis"
- "50 gr gula merah"
- "1/2 sdt garam"
- "1 sdm gula putih"
- "2 batang sereh geprek"
- "1 batang laos geprek"
- "5 lembar daun salam"
- "6 lembar daun jeruk"
- "1 sdt kaldu bubuk"
- "3 sdm kecap manis"
- "700 ml santan  saya pakai ini"
- " Bumbu halus"
- "7 butir bawang merah"
- "4 siung bawang putih"
- "2 ruas jahe"
- "3 ruas kunyit  saya tambahin"
- "1 buah cabe  suka suka"
recipeinstructions:
- "Siapkan bahan, haluskan bumbu. Cuci bersih ayam dan beri perasan jeruk nipis. Diamkan 30 menit. Cuci bersih kembali."
- "Tumis bumbu halus, masukkan ayam dan santan, aduk aduk"
- "Tambahkan semua bahan yg lain, masak sampai kuah meresap dan angkat"
- "Bakar diatas arang sebentar dan oles bumbu kuah ungkepan. Angkat dan hidangkan"
categories:
- Recipe
tags:
- ayam
- bumbu
- rujak

katakunci: ayam bumbu rujak 
nutrition: 156 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Bumbu Rujak](https://img-global.cpcdn.com/recipes/40aa883eed473e95/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas hingga renyah. Ciri kuliner Nusantara ayam bumbu rujak yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga dapat ditemukan dengan cara mudah. Salah satunya adalah memasak Ayam Bumbu Rujak untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang bisa anda buat salah satunya ayam bumbu rujak yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep ayam bumbu rujak tanpa harus bersusah payah.
Seperti resep Ayam Bumbu Rujak yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Bumbu Rujak:

1. Harus ada 1 ekor ayam
1. Dibutuhkan 2 buah jeruk nipis
1. Harus ada 50 gr gula merah
1. Siapkan 1/2 sdt garam
1. Harus ada 1 sdm gula putih
1. Diperlukan 2 batang sereh geprek
1. Harus ada 1 batang laos geprek
1. Diperlukan 5 lembar daun salam
1. Siapkan 6 lembar daun jeruk
1. Jangan lupa 1 sdt kaldu bubuk
1. Tambah 3 sdm kecap manis
1. Harus ada 700 ml santan * saya pakai ini
1. Siapkan  Bumbu halus
1. Tambah 7 butir bawang merah
1. Diperlukan 4 siung bawang putih
1. Siapkan 2 ruas jahe
1. Harap siapkan 3 ruas kunyit * saya tambahin
1. Harus ada 1 buah cabe * suka suka




<!--inarticleads2-->

##### Cara membuat  Ayam Bumbu Rujak:

1. Siapkan bahan, haluskan bumbu. Cuci bersih ayam dan beri perasan jeruk nipis. Diamkan 30 menit. Cuci bersih kembali.
1. Tumis bumbu halus, masukkan ayam dan santan, aduk aduk
1. Tambahkan semua bahan yg lain, masak sampai kuah meresap dan angkat
1. Bakar diatas arang sebentar dan oles bumbu kuah ungkepan. Angkat dan hidangkan




Demikianlah cara membuat ayam bumbu rujak yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
