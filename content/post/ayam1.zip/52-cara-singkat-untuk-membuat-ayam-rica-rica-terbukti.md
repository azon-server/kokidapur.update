---
description: "Cara singkat untuk membuat Ayam Rica Rica Terbukti"
title: "Cara singkat untuk membuat Ayam Rica Rica Terbukti"
slug: 52-cara-singkat-untuk-membuat-ayam-rica-rica-terbukti
date: 2020-12-31T23:40:13.962Z
image: https://img-global.cpcdn.com/recipes/05d9e52562f3fde7/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/05d9e52562f3fde7/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/05d9e52562f3fde7/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Myra Wells
ratingvalue: 4.1
reviewcount: 9419
recipeingredient:
- "1/2 kg ayam"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "1 batang serai"
- "1 ruas lengkuas"
- "Secukupnya gula"
- "Secukupnya garam"
- "Secukupnya kaldu bubuk"
- "2 gelas air"
- "Sedikit jeruk nipis"
- " Bumbu Halus "
- "1/2 sdt kunyit bubuk"
- "5 buah cabe merah"
- "15 buah cabe rawit"
- "2 butir kemiri"
- "4 siung bawang putih"
- "8 siung bawang merah"
recipeinstructions:
- "Potong dan cuci bersih ayam. Beri perasan jeruk nipis dan garam. Lalu goreng sebentar. Haluskan bumbu dan geprek serai serta lengkuas."
- "Tumis bumbu halus masukkan serai,lengkuas,daun salam dan daun jeruk."
- "Masukkan air,kaldu bubuk,gula dan garam. Kemudian masukkan ayam goreng."
- "Biarkan masak sampai kuah menyusut. Ayam rica rica siap disajikan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 112 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT50M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/05d9e52562f3fde7/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga enak. Karasteristik kuliner Indonesia ayam rica rica yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Keharmonisan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah memasak Ayam Rica Rica untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang bisa anda praktekkan salah satunya ayam rica rica yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica:

1. Dibutuhkan 1/2 kg ayam
1. Harap siapkan 2 lembar daun jeruk
1. Siapkan 2 lembar daun salam
1. Harap siapkan 1 batang serai
1. Harus ada 1 ruas lengkuas
1. Harus ada Secukupnya gula
1. Dibutuhkan Secukupnya garam
1. Harus ada Secukupnya kaldu bubuk
1. Harap siapkan 2 gelas air
1. Jangan lupa Sedikit jeruk nipis
1. Dibutuhkan  Bumbu Halus :
1. Harap siapkan 1/2 sdt kunyit bubuk
1. Diperlukan 5 buah cabe merah
1. Diperlukan 15 buah cabe rawit
1. Diperlukan 2 butir kemiri
1. Siapkan 4 siung bawang putih
1. Siapkan 8 siung bawang merah




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica:

1. Potong dan cuci bersih ayam. Beri perasan jeruk nipis dan garam. Lalu goreng sebentar. Haluskan bumbu dan geprek serai serta lengkuas.
1. Tumis bumbu halus masukkan serai,lengkuas,daun salam dan daun jeruk.
1. Masukkan air,kaldu bubuk,gula dan garam. Kemudian masukkan ayam goreng.
1. Biarkan masak sampai kuah menyusut. Ayam rica rica siap disajikan.




Demikianlah cara membuat ayam rica rica yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
