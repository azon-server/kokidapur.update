---
description: "Cara singkat untuk membuat Ayam Bumbu Rujak Favorite"
title: "Cara singkat untuk membuat Ayam Bumbu Rujak Favorite"
slug: 485-cara-singkat-untuk-membuat-ayam-bumbu-rujak-favorite
date: 2021-01-03T11:03:32.621Z
image: https://img-global.cpcdn.com/recipes/e1b14ead5d202358/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e1b14ead5d202358/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e1b14ead5d202358/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg
author: Jackson Ferguson
ratingvalue: 4.2
reviewcount: 38111
recipeingredient:
- "6 potong ayam"
- "2 lembar daun jeruk"
- "1 ruas jari Lengkuas"
- "1 batang serai"
- " Santan secukupnya 1 bungkus kara kecil"
- "secukupnya Gula Merah"
- "secukupnya Kecap agak banyak"
- "secukupnya Garam"
- " Air secukupnya 300500ml"
- " Bumbu halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "5 buah cabai merah"
- "1-2 buah cabai kecil"
- "1 sdt kunyit"
- "2 biji kemiri yg sudah di oseng"
- "1 sdt ketumbar"
- "1 sdt jahe"
recipeinstructions:
- "Blender semua bumbu halus"
- "Tumis dengan minyak sedikit bumbu halus di teflon yg cekung agak besar atau panci. Masukkan serei, daun jeruk, lengkuas"
- "Masukkan ayam, air, kecap, gula merah, garam. Tunggu hingga sedikit mengering"
- "Masukkan santan, masak sampai menyusut dan agak berminyak"
- "Bisa langsung disajikan atau di bakar lagi di atas teflon"
categories:
- Recipe
tags:
- ayam
- bumbu
- rujak

katakunci: ayam bumbu rujak 
nutrition: 162 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Bumbu Rujak](https://img-global.cpcdn.com/recipes/e1b14ead5d202358/751x532cq70/ayam-bumbu-rujak-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau renyah. Karasteristik masakan Indonesia ayam bumbu rujak yang penuh dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga bisa didapat dengan cara simple. Diantaranya adalah membuat makanan Ayam Bumbu Rujak untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang bisa anda coba salah satunya ayam bumbu rujak yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya saat ini kamu bisa dengan gampang menemukan resep ayam bumbu rujak tanpa harus bersusah payah.
Berikut ini resep Ayam Bumbu Rujak yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Bumbu Rujak:

1. Harus ada 6 potong ayam
1. Dibutuhkan 2 lembar daun jeruk
1. Siapkan 1 ruas jari Lengkuas
1. Dibutuhkan 1 batang serai
1. Dibutuhkan  Santan secukupnya (1 bungkus kara kecil)
1. Tambah secukupnya Gula Merah
1. Jangan lupa secukupnya Kecap (agak banyak)
1. Dibutuhkan secukupnya Garam
1. Siapkan  Air secukupnya (300-500ml)
1. Dibutuhkan  Bumbu halus
1. Harus ada 5 siung bawang merah
1. Tambah 3 siung bawang putih
1. Dibutuhkan 5 buah cabai merah
1. Tambah 1-2 buah cabai kecil
1. Diperlukan 1 sdt kunyit
1. Siapkan 2 biji kemiri yg sudah di oseng
1. Harus ada 1 sdt ketumbar
1. Siapkan 1 sdt jahe




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Bumbu Rujak:

1. Blender semua bumbu halus
1. Tumis dengan minyak sedikit bumbu halus di teflon yg cekung agak besar atau panci. Masukkan serei, daun jeruk, lengkuas
1. Masukkan ayam, air, kecap, gula merah, garam. Tunggu hingga sedikit mengering
1. Masukkan santan, masak sampai menyusut dan agak berminyak
1. Bisa langsung disajikan atau di bakar lagi di atas teflon




Demikianlah cara membuat ayam bumbu rujak yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
