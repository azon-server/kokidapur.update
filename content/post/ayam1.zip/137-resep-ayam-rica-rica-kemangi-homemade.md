---
description: "Resep : Ayam rica rica kemangi Homemade"
title: "Resep : Ayam rica rica kemangi Homemade"
slug: 137-resep-ayam-rica-rica-kemangi-homemade
date: 2020-09-24T03:37:20.783Z
image: https://img-global.cpcdn.com/recipes/fb922f84ed590e1c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fb922f84ed590e1c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fb922f84ed590e1c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Jimmy McLaughlin
ratingvalue: 4.2
reviewcount: 48088
recipeingredient:
- "1 ekor ayamsaya pakai paha semua"
- "1 sdt garam"
- "1 1/2 sdm air jeruk nipis"
- " Bumbu halus"
- "10 butir bawang merah"
- "5 siung bawang putih"
- "15 cabai merah"
- "7 cabai rawit"
- "2 cm jahe"
- "1 buah tomat"
- " Bahan yang di cemplung"
- "2 batang serai ambil putihnya memarkan"
- "1 batang serai ambil putihnya iris tipis"
- "6 daun jeruk buang tulangnya robek kasar"
- "1 ikat kemangi petikin daun nya"
- "1/2 sdt garam"
- "1/2 sdt gula"
- "1/2 sdt kaldu jamur"
- "Sedikit air"
recipeinstructions:
- "Ayam, potong menjadi 10 bagian. Cuci bersih ayam. Tusuk2 ayam dengan garpu, agar bumbu lebih meresap. Lumuri dengan garam dan jeruk nipis. Diamkan selama 20 menit. Bilas. Lalu goreng ayam, sampai matang, jgn kering ya. Sisihkan"
- "Panaskan minyak, tumis bumbu halus, sampai matang dan harum.Masukkan bumbu cemplung"
- "Lalu masukkan ayam aduk rata. Tambahkan air dan gula pasir. Masak sampai semua bumbu mengental, masukkan kemangi, biarkan bumbu meresap. Matikan api"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 237 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/fb922f84ed590e1c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita jaga karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica rica kemangi yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Indonesia

Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Inilah rahasia bumbu masakan ayam rica rica dan petunjuk cara membuat rica rica ayam.

Kedekatan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah memasak Ayam rica rica kemangi untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang dapat anda coba salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 19 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Dibutuhkan 1 ekor ayam*saya pakai paha semua
1. Harap siapkan 1 sdt garam
1. Harus ada 1 1/2 sdm air jeruk nipis
1. Diperlukan  Bumbu halus
1. Harap siapkan 10 butir bawang merah
1. Tambah 5 siung bawang putih
1. Dibutuhkan 15 cabai merah
1. Harus ada 7 cabai rawit
1. Dibutuhkan 2 cm jahe
1. Diperlukan 1 buah tomat
1. Siapkan  Bahan yang di cemplung
1. Diperlukan 2 batang serai ambil putihnya, memarkan
1. Tambah 1 batang serai, ambil putihnya iris tipis
1. Dibutuhkan 6 daun jeruk, buang tulangnya robek kasar
1. Diperlukan 1 ikat kemangi, petikin daun nya
1. Diperlukan 1/2 sdt garam
1. Tambah 1/2 sdt gula
1. Dibutuhkan 1/2 sdt kaldu jamur
1. Harap siapkan Sedikit air


It is made up of chicken that cooked in spicy red and green chili pepper. The origin of this dish is from Minahasan cuisine of North Sulawesi. Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica kemangi:

1. Ayam, potong menjadi 10 bagian. Cuci bersih ayam. Tusuk2 ayam dengan garpu, agar bumbu lebih meresap. Lumuri dengan garam dan jeruk nipis. Diamkan selama 20 menit. Bilas. Lalu goreng ayam, sampai matang, jgn kering ya. Sisihkan
1. Panaskan minyak, tumis bumbu halus, sampai matang dan harum.Masukkan bumbu cemplung
1. Lalu masukkan ayam aduk rata. Tambahkan air dan gula pasir. Masak sampai semua bumbu mengental, masukkan kemangi, biarkan bumbu meresap. Matikan api


Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. 

Demikianlah cara membuat ayam rica rica kemangi yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
