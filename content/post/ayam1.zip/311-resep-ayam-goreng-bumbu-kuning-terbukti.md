---
description: "Resep : Ayam Goreng Bumbu Kuning Terbukti"
title: "Resep : Ayam Goreng Bumbu Kuning Terbukti"
slug: 311-resep-ayam-goreng-bumbu-kuning-terbukti
date: 2020-09-13T03:15:24.468Z
image: https://img-global.cpcdn.com/recipes/0823ff5fa7978ffc/751x532cq70/ayam-goreng-bumbu-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0823ff5fa7978ffc/751x532cq70/ayam-goreng-bumbu-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0823ff5fa7978ffc/751x532cq70/ayam-goreng-bumbu-kuning-foto-resep-utama.jpg
author: Fanny Townsend
ratingvalue: 4.3
reviewcount: 33840
recipeingredient:
- "1 1/2 ekor Ayam"
- "200 mL Santan re Kara"
- "200 mL Air"
- "2 buah Jeruk Nipis"
- "3 ruas Lengkuas"
- "6 lembar Daun Salam"
- "7 lembar Daun Jeruk"
- "5 batang Sereh"
- "Secukupnya Garam"
- "Secukupnya Kaldu Sapi"
- "Secukupnya Minyak Goreng untuk menumis"
- " Bumbu Halus"
- "5 siung Bawang Putih"
- "20 siung Bawang Merah"
- "3 ruas Kunyit"
- "7 butir Kemiri"
- "3 ruas Jahe"
recipeinstructions:
- "Bersihkan ayam, cuci hingga bersih kemudian marinasi dengan jeruk nipis dan garam untuk menghilangkan bau amis pada ayam. Diamkan 10 menit"
- "Haluskan bawang merah, bawang putih, kunyit, kemiri dan jahe. Sedangkan sereh dan lengkuas cukup digeprek saja."
- "Panaskan secukupnya minyak goreng dan tumis bumbu yang sudah dihaluskan sampai harum dan matang (kuning kecoklatan). Setelah itu, masukkan sereh, daun salam, daun jeruk dan lengkuas."
- "Setelah bumbu matang secara keseluruhan, masukan 200 mL santan, aduk sampai bumbu-santan menyatu. Supaya tidak terlalu kental, tambahkan air secara bertahap, kemudian aduk hingga merata. Jika dirasa masih terlalu kental, tambahkan airnya kembali.   Tambahkan secukupnya garam dan kaldu sapi. Setelah rasa sudah ok, tunggu hingga mendidih."
- "Setelah mendidih masukan ayam kedalam rebusan bumbu. Rebus hingga airnya menyusut."
- "Ayam sudah siap untuk digoreng dan disajikan kapanpun. Jangan lupa untuk simpan di freezer supaya tetap awet.  Selamat mencoba!"
categories:
- Recipe
tags:
- ayam
- goreng
- bumbu

katakunci: ayam goreng bumbu 
nutrition: 151 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Goreng Bumbu Kuning](https://img-global.cpcdn.com/recipes/0823ff5fa7978ffc/751x532cq70/ayam-goreng-bumbu-kuning-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang patut kita jaga karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam goreng bumbu kuning yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan keistimewahan yang merupakan keragaman Kita

Keharmonisan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah memasak Ayam Goreng Bumbu Kuning untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi makanan yang bisa anda praktekkan salah satunya ayam goreng bumbu kuning yang merupakan resep favorite yang mudah dengan kreasi sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep ayam goreng bumbu kuning tanpa harus bersusah payah.
Seperti resep Ayam Goreng Bumbu Kuning yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Bumbu Kuning:

1. Dibutuhkan 1 1/2 ekor Ayam
1. Jangan lupa 200 mL Santan (re: Kara)
1. Harap siapkan 200 mL Air
1. Tambah 2 buah Jeruk Nipis
1. Jangan lupa 3 ruas Lengkuas
1. Harus ada 6 lembar Daun Salam
1. Jangan lupa 7 lembar Daun Jeruk
1. Siapkan 5 batang Sereh
1. Dibutuhkan Secukupnya Garam
1. Jangan lupa Secukupnya Kaldu Sapi
1. Tambah Secukupnya Minyak Goreng (untuk menumis)
1. Dibutuhkan  Bumbu Halus
1. Siapkan 5 siung Bawang Putih
1. Harus ada 20 siung Bawang Merah
1. Harus ada 3 ruas Kunyit
1. Siapkan 7 butir Kemiri
1. Jangan lupa 3 ruas Jahe




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Bumbu Kuning:

1. Bersihkan ayam, cuci hingga bersih kemudian marinasi dengan jeruk nipis dan garam untuk menghilangkan bau amis pada ayam. Diamkan 10 menit
1. Haluskan bawang merah, bawang putih, kunyit, kemiri dan jahe. Sedangkan sereh dan lengkuas cukup digeprek saja.
1. Panaskan secukupnya minyak goreng dan tumis bumbu yang sudah dihaluskan sampai harum dan matang (kuning kecoklatan). Setelah itu, masukkan sereh, daun salam, daun jeruk dan lengkuas.
1. Setelah bumbu matang secara keseluruhan, masukan 200 mL santan, aduk sampai bumbu-santan menyatu. Supaya tidak terlalu kental, tambahkan air secara bertahap, kemudian aduk hingga merata. Jika dirasa masih terlalu kental, tambahkan airnya kembali.  -  - Tambahkan secukupnya garam dan kaldu sapi. Setelah rasa sudah ok, tunggu hingga mendidih.
1. Setelah mendidih masukan ayam kedalam rebusan bumbu. Rebus hingga airnya menyusut.
1. Ayam sudah siap untuk digoreng dan disajikan kapanpun. Jangan lupa untuk simpan di freezer supaya tetap awet. -  - Selamat mencoba!




Demikianlah cara membuat ayam goreng bumbu kuning yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan cepat, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
