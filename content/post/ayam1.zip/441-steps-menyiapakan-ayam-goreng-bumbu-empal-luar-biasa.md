---
description: "Steps menyiapakan Ayam Goreng Bumbu Empal Luar biasa"
title: "Steps menyiapakan Ayam Goreng Bumbu Empal Luar biasa"
slug: 441-steps-menyiapakan-ayam-goreng-bumbu-empal-luar-biasa
date: 2020-09-05T05:40:11.955Z
image: https://img-global.cpcdn.com/recipes/1553025a63af833a/751x532cq70/ayam-goreng-bumbu-empal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1553025a63af833a/751x532cq70/ayam-goreng-bumbu-empal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1553025a63af833a/751x532cq70/ayam-goreng-bumbu-empal-foto-resep-utama.jpg
author: Lela Meyer
ratingvalue: 4.9
reviewcount: 46009
recipeingredient:
- "6 potong Ayam asli pake paha ayam"
- "250 ml air"
- "40 gr gula merah"
- "1 sdm air Asam jawa"
- "1 cm Lengkuas"
- "1 lembar daun salam"
- "Secukupnya garam"
- "Secukupnya Minyak untuk menumis dan menggoreng ayam"
- " Bumbu Halus"
- "4 siung bawang merah"
- "3 siung bawang putih"
- "1 sdt ketumbar"
recipeinstructions:
- "Cuci bersih ayam kemudian beri air jeruk nipis diamkan beberapa saat. Siampakn bumbu2.."
- "Haluskan Bawang Putih, bawang merah dan ketumbar. Panaskan wajan beri minyak kemudian tumis bumbu halus hingga Harum, masukkan daun salam dan daun salam, aduk rata.."
- "Masukkan ayam, aduk hingga berubah warna, kemudian tambahkan air, gula merah, gma dan air Asam."
- "Masak hingga Kuah mengental dan bumbu menyerap ke ayam. Matikan api."
- "Panaskan minyak goreng dalam wajan, goreng sebentar (gunakan api kecil saja) angkat siap disajikan. Selamat mencoba 😉🙏🏼"
categories:
- Recipe
tags:
- ayam
- goreng
- bumbu

katakunci: ayam goreng bumbu 
nutrition: 169 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Goreng Bumbu Empal](https://img-global.cpcdn.com/recipes/1553025a63af833a/751x532cq70/ayam-goreng-bumbu-empal-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan empuk. Ciri kuliner Indonesia ayam goreng bumbu empal yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Goreng Bumbu Empal untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang dapat anda praktekkan salah satunya ayam goreng bumbu empal yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep ayam goreng bumbu empal tanpa harus bersusah payah.
Seperti resep Ayam Goreng Bumbu Empal yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 12 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Bumbu Empal:

1. Diperlukan 6 potong Ayam {asli pake paha ayam)
1. Jangan lupa 250 ml air
1. Harap siapkan 40 gr gula merah
1. Jangan lupa 1 sdm air Asam jawa
1. Diperlukan 1 cm Lengkuas
1. Dibutuhkan 1 lembar daun salam
1. Siapkan Secukupnya garam
1. Diperlukan Secukupnya Minyak (untuk menumis dan menggoreng ayam)
1. Tambah  Bumbu Halus
1. Dibutuhkan 4 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Harap siapkan 1 sdt ketumbar




<!--inarticleads2-->

##### Cara membuat  Ayam Goreng Bumbu Empal:

1. Cuci bersih ayam kemudian beri air jeruk nipis diamkan beberapa saat. Siampakn bumbu2..
1. Haluskan Bawang Putih, bawang merah dan ketumbar. Panaskan wajan beri minyak kemudian tumis bumbu halus hingga Harum, masukkan daun salam dan daun salam, aduk rata..
1. Masukkan ayam, aduk hingga berubah warna, kemudian tambahkan air, gula merah, gma dan air Asam.
1. Masak hingga Kuah mengental dan bumbu menyerap ke ayam. Matikan api.
1. Panaskan minyak goreng dalam wajan, goreng sebentar (gunakan api kecil saja) angkat siap disajikan. Selamat mencoba 😉🙏🏼




Demikianlah cara membuat ayam goreng bumbu empal yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan terbukti, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
