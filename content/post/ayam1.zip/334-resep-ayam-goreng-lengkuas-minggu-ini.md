---
description: "Resep : Ayam goreng lengkuas minggu ini"
title: "Resep : Ayam goreng lengkuas minggu ini"
slug: 334-resep-ayam-goreng-lengkuas-minggu-ini
date: 2020-11-27T04:42:04.937Z
image: https://img-global.cpcdn.com/recipes/721067b06014b2aa/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/721067b06014b2aa/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/721067b06014b2aa/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Donald Torres
ratingvalue: 4.8
reviewcount: 16508
recipeingredient:
- "1 kg ayam potong2 jadi 10"
- " lengkuas pilih yang gak keras 5bj seukuran jari"
- " bumbu halus"
- "6 btr bawang putih"
- " garam"
- "1/2 jari kunyit"
recipeinstructions:
- "Bersihkan ayam"
- "Parut lengkuas"
- "Haluskan bumbu halus"
- "Campur ayam dan bumbu halus beserta lengkuas parut kasih air secukupnya"
- "Ungkep ayam yg sudah dicampur bumbu sampai air menyusut"
- "Koreksi rasa"
- "Setelah menyusut airnya, matikan kompor"
- "Goreng ayam beserta bumbunya"
- "Siap disajikan"
categories:
- Recipe
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 127 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam goreng lengkuas](https://img-global.cpcdn.com/recipes/721067b06014b2aa/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam goreng lengkuas yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Nusantara



Keharmonisan keluarga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam goreng lengkuas untuk keluarga. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang bisa anda contoh salah satunya ayam goreng lengkuas yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep ayam goreng lengkuas tanpa harus bersusah payah.
Berikut ini resep Ayam goreng lengkuas yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam goreng lengkuas:

1. Harus ada 1 kg ayam potong2 jadi 10
1. Tambah  lengkuas pilih yang gak keras 5bj seukuran jari
1. Jangan lupa  bumbu halus
1. Tambah 6 btr bawang putih
1. Tambah  garam
1. Tambah 1/2 jari kunyit




<!--inarticleads2-->

##### Cara membuat  Ayam goreng lengkuas:

1. Bersihkan ayam
1. Parut lengkuas
1. Haluskan bumbu halus
1. Campur ayam dan bumbu halus beserta lengkuas parut kasih air secukupnya
1. Ungkep ayam yg sudah dicampur bumbu sampai air menyusut
1. Koreksi rasa
1. Setelah menyusut airnya, matikan kompor
1. Goreng ayam beserta bumbunya
1. Siap disajikan




Demikianlah cara membuat ayam goreng lengkuas yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
