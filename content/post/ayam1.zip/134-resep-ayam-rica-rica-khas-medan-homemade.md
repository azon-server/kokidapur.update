---
description: "Resep : Ayam rica-rica khas medan Homemade"
title: "Resep : Ayam rica-rica khas medan Homemade"
slug: 134-resep-ayam-rica-rica-khas-medan-homemade
date: 2020-10-11T04:11:29.350Z
image: https://img-global.cpcdn.com/recipes/3273777b3f6ca285/751x532cq70/ayam-rica-rica-khas-medan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3273777b3f6ca285/751x532cq70/ayam-rica-rica-khas-medan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3273777b3f6ca285/751x532cq70/ayam-rica-rica-khas-medan-foto-resep-utama.jpg
author: Harry Robbins
ratingvalue: 4.4
reviewcount: 44024
recipeingredient:
- "400 gram ayam"
- " Bumbu"
- "10 biji cabe merah keriting"
- "15 cabe rawit"
- "3 siung bawang putih"
- "7 siung bawang Merah"
- "Seujung jari kunyit"
- "1 cm jahe"
- "2 cm lengkuas"
- "2 lembar kecil daun pandan"
- "2 daun salam"
- "2 lembar daun jeruk"
- "2 biji kemiri"
- " Daun kemangi skip tak punya"
- "1 lt air"
- "2 sdm minyak goreng"
- "1 sdt garam"
- "1 sdt gula"
- "1/2 sdt penyedap"
- "1/2 tomat"
- "1 sdm bawang merah goreng"
recipeinstructions:
- "Siapkan bahan"
- "Giling bumbunya kecuali daun pandan,daun salam dan daun jeruk"
- "Tumis bumbunya masukin daun salam daun pandan daun jeruk lengkuas sampai harum kemudian masukkan ayamnya tambah air biarkan sampai ayam matang dan tanak"
- "Masukin irisan tomat garam gula penyedap tes rasanya....😘😘😘 angkat taburi bawang merah sajikan"
categories:
- Recipe
tags:
- ayam
- ricarica
- khas

katakunci: ayam ricarica khas 
nutrition: 114 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT57M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam rica-rica khas medan](https://img-global.cpcdn.com/recipes/3273777b3f6ca285/751x532cq70/ayam-rica-rica-khas-medan-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga renyah. Karasteristik masakan Indonesia ayam rica-rica khas medan yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kedekatan keluarga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam rica-rica khas medan untuk keluarga. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi makanan yang bisa anda contoh salah satunya ayam rica-rica khas medan yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep ayam rica-rica khas medan tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica khas medan yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 21 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica khas medan:

1. Harap siapkan 400 gram ayam
1. Tambah  Bumbu:
1. Jangan lupa 10 biji cabe merah keriting
1. Siapkan 15 cabe rawit
1. Harus ada 3 siung bawang putih
1. Siapkan 7 siung bawang Merah
1. Harus ada Seujung jari kunyit
1. Dibutuhkan 1 cm jahe
1. Dibutuhkan 2 cm lengkuas
1. Harap siapkan 2 lembar kecil daun pandan
1. Harap siapkan 2 daun salam
1. Siapkan 2 lembar daun jeruk
1. Harap siapkan 2 biji kemiri
1. Jangan lupa  Daun kemangi (skip) tak punya
1. Harus ada 1 lt air
1. Tambah 2 sdm minyak goreng
1. Harus ada 1 sdt garam
1. Dibutuhkan 1 sdt gula
1. Siapkan 1/2 sdt penyedap
1. Diperlukan 1/2 tomat
1. Siapkan 1 sdm bawang merah goreng




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica-rica khas medan:

1. Siapkan bahan
1. Giling bumbunya kecuali daun pandan,daun salam dan daun jeruk
1. Tumis bumbunya masukin daun salam daun pandan daun jeruk lengkuas sampai harum kemudian masukkan ayamnya tambah air biarkan sampai ayam matang dan tanak
1. Masukin irisan tomat garam gula penyedap tes rasanya....😘😘😘 angkat taburi bawang merah sajikan




Demikianlah cara membuat ayam rica-rica khas medan yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan cepat, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
