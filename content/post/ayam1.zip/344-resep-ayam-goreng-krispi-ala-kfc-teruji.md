---
description: "Resep : Ayam Goreng Krispi ala KFC Teruji"
title: "Resep : Ayam Goreng Krispi ala KFC Teruji"
slug: 344-resep-ayam-goreng-krispi-ala-kfc-teruji
date: 2020-11-22T08:52:08.998Z
image: https://img-global.cpcdn.com/recipes/c74404b195bf3685/751x532cq70/ayam-goreng-krispi-ala-kfc-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c74404b195bf3685/751x532cq70/ayam-goreng-krispi-ala-kfc-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c74404b195bf3685/751x532cq70/ayam-goreng-krispi-ala-kfc-foto-resep-utama.jpg
author: Mollie Paul
ratingvalue: 4.8
reviewcount: 44552
recipeingredient:
- " Bahan marinasi ayam"
- "1 buah dada ayam buang tulang dibagi 5 bagian memanjang"
- "1/2 sachet bumbu marinasi ayam desaku"
- "1 sdt merica bubuk"
- " Bahan tepung kering"
- "115 gr tepung terigu protein sedang"
- "20 gr tepung tapioka"
- "1 sdt garam"
- "2 sdt merica bubuk"
- "1/2 sdt baking powder tambahan saya"
- " Bahan pelapis"
- " Ambil 5 sdm dari campuran tepung kering"
- "8 sdm air"
recipeinstructions:
- "Marinasi ayam. Diamkan dalam kulkas bawah 2 jam (saya setengah hari). Jika tidak menemukan bumbu marinasi ayam, bisa diganti bumbu racik ayam goreng."
- "Buat adonan tepung kering. Campur rata. Ambil 5 sdm dan campur dengan air untuk mendapatkan adonan pelapis."
- "Ambil ayam yg sudah dimarinasi. Gulingkan di adonan basah, kemudian di adonan kering sambil dicubit2. Lakukan sampai selesai."
- "Jika ada sisa adonan, lapisi ayam sekali lagi jadi menghasilkan tepung yg tebal. Cara sama dengan langkah nomor 3."
- "Goreng dengan minyak yg panas (hampir berasap) api kecil saja sehingga tidak mudah gosong. Goreng sampai ayam matang bewarna kuning kecokelatan di kedua sisi. Tanda jika sudah matang, minyak tidak mengeluarkan busa lagi (sudah jernih). Angkat dan tiriskan."
- "Sajikan dengan nasi putih hangat, saus sambal dan saus tomat. Selamat mencoba 😀"
categories:
- Recipe
tags:
- ayam
- goreng
- krispi

katakunci: ayam goreng krispi 
nutrition: 129 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Goreng Krispi ala KFC](https://img-global.cpcdn.com/recipes/c74404b195bf3685/751x532cq70/ayam-goreng-krispi-ala-kfc-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas dan renyah. Ciri khas kuliner Nusantara ayam goreng krispi ala kfc yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Goreng Krispi ala KFC untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang bisa anda buat salah satunya ayam goreng krispi ala kfc yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep ayam goreng krispi ala kfc tanpa harus bersusah payah.
Berikut ini resep Ayam Goreng Krispi ala KFC yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 13 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Krispi ala KFC:

1. Siapkan  Bahan marinasi ayam
1. Siapkan 1 buah dada ayam (buang tulang, dibagi 5 bagian memanjang)
1. Dibutuhkan 1/2 sachet bumbu marinasi ayam desaku
1. Dibutuhkan 1 sdt merica bubuk
1. Siapkan  Bahan tepung kering
1. Siapkan 115 gr tepung terigu protein sedang
1. Diperlukan 20 gr tepung tapioka
1. Diperlukan 1 sdt garam
1. Dibutuhkan 2 sdt merica bubuk
1. Tambah 1/2 sdt baking powder (tambahan saya)
1. Tambah  Bahan pelapis
1. Tambah  Ambil 5 sdm dari campuran tepung kering
1. Tambah 8 sdm air




<!--inarticleads2-->

##### Langkah membuat  Ayam Goreng Krispi ala KFC:

1. Marinasi ayam. Diamkan dalam kulkas bawah 2 jam (saya setengah hari). Jika tidak menemukan bumbu marinasi ayam, bisa diganti bumbu racik ayam goreng.
1. Buat adonan tepung kering. Campur rata. Ambil 5 sdm dan campur dengan air untuk mendapatkan adonan pelapis.
1. Ambil ayam yg sudah dimarinasi. Gulingkan di adonan basah, kemudian di adonan kering sambil dicubit2. Lakukan sampai selesai.
1. Jika ada sisa adonan, lapisi ayam sekali lagi jadi menghasilkan tepung yg tebal. Cara sama dengan langkah nomor 3.
1. Goreng dengan minyak yg panas (hampir berasap) api kecil saja sehingga tidak mudah gosong. Goreng sampai ayam matang bewarna kuning kecokelatan di kedua sisi. Tanda jika sudah matang, minyak tidak mengeluarkan busa lagi (sudah jernih). Angkat dan tiriskan.
1. Sajikan dengan nasi putih hangat, saus sambal dan saus tomat. Selamat mencoba 😀




Demikianlah cara membuat ayam goreng krispi ala kfc yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat gampang dan teruji, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
