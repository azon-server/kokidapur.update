---
description: "Langkah untuk membuat Ayam Rica Pedas minggu ini"
title: "Langkah untuk membuat Ayam Rica Pedas minggu ini"
slug: 147-langkah-untuk-membuat-ayam-rica-pedas-minggu-ini
date: 2020-11-01T14:24:30.603Z
image: https://img-global.cpcdn.com/recipes/9f56c179b30056cb/751x532cq70/ayam-rica-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9f56c179b30056cb/751x532cq70/ayam-rica-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9f56c179b30056cb/751x532cq70/ayam-rica-pedas-foto-resep-utama.jpg
author: Beatrice Stone
ratingvalue: 4.9
reviewcount: 22240
recipeingredient:
- "5 potong ayam"
- "secukupnya daun Kemangi"
- "1 batang sereh geprek"
- "3 cm lengkuas geprek"
- "5 lembar daun jeruk"
- "3 lembar daun salam"
- "2 batang daun bawang"
- "1 buah tomat iris kecil"
- " Bumbu halus "
- "10 buah cabe rawit"
- "10 buah cabe keriting"
- "5 buah bawang merah"
- "2 buah bawang putih"
- "4 cm jahe"
- "3 buah kemiri"
- "secukupnya Minyak untuk menumis"
- "1 sdt garam"
- "1 sdm kaldu"
- "1 sdt gula putih"
recipeinstructions:
- "Potong ayam menjadi 2 bagian, lalu rebus sebentar. Angkat lalu tiriskan."
- "Goreng ayam sebentar jgn terlalu garing. Lalu angkat dan tiriskan."
- "Panaskan minyak lalu masukkan bumbu yg sudah di haluskan. Lalu masukkan kembali daun jeruk, salam serem dan lengkoas aduk hingga merata. Tunggu sampai bumbu stgh matang lalu masukkan kemangi. Lalu aduk kembali."
- "Masukkan penyedap rasa dan cicipi. Lalu masukkan ayam yg sudah di goreng tadi. Aduk sebentar. Masukkan kembali daun bawang dan irisan tomat. Aduk merata dan tunggu sebentar."
- "Lalu angkat. Ayam rica pedas siap dihidangkan."
categories:
- Recipe
tags:
- ayam
- rica
- pedas

katakunci: ayam rica pedas 
nutrition: 246 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica Pedas](https://img-global.cpcdn.com/recipes/9f56c179b30056cb/751x532cq70/ayam-rica-pedas-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang patut kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica pedas yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan ciri khas yang merupakan keragaman Indonesia

Kedekatan rumah tangga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam Rica Pedas untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang dapat anda coba salah satunya ayam rica pedas yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep ayam rica pedas tanpa harus bersusah payah.
Seperti resep Ayam Rica Pedas yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Pedas:

1. Tambah 5 potong ayam
1. Harus ada secukupnya daun Kemangi
1. Tambah 1 batang sereh geprek
1. Dibutuhkan 3 cm lengkuas geprek
1. Jangan lupa 5 lembar daun jeruk
1. Jangan lupa 3 lembar daun salam
1. Jangan lupa 2 batang daun bawang
1. Diperlukan 1 buah tomat iris kecil
1. Dibutuhkan  Bumbu halus :
1. Harap siapkan 10 buah cabe rawit
1. Harus ada 10 buah cabe keriting
1. Harus ada 5 buah bawang merah
1. Dibutuhkan 2 buah bawang putih
1. Jangan lupa 4 cm jahe
1. Diperlukan 3 buah kemiri
1. Harap siapkan secukupnya Minyak untuk menumis
1. Harus ada 1 sdt garam
1. Jangan lupa 1 sdm kaldu
1. Diperlukan 1 sdt gula putih




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Pedas:

1. Potong ayam menjadi 2 bagian, lalu rebus sebentar. Angkat lalu tiriskan.
1. Goreng ayam sebentar jgn terlalu garing. Lalu angkat dan tiriskan.
1. Panaskan minyak lalu masukkan bumbu yg sudah di haluskan. Lalu masukkan kembali daun jeruk, salam serem dan lengkoas aduk hingga merata. Tunggu sampai bumbu stgh matang lalu masukkan kemangi. Lalu aduk kembali.
1. Masukkan penyedap rasa dan cicipi. Lalu masukkan ayam yg sudah di goreng tadi. Aduk sebentar. Masukkan kembali daun bawang dan irisan tomat. Aduk merata dan tunggu sebentar.
1. Lalu angkat. Ayam rica pedas siap dihidangkan.




Demikianlah cara membuat ayam rica pedas yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan teruji, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
