---
description: "Cara singkat menyiapakan Ayam rica-rica teraktual"
title: "Cara singkat menyiapakan Ayam rica-rica teraktual"
slug: 126-cara-singkat-menyiapakan-ayam-rica-rica-teraktual
date: 2020-09-26T02:57:34.376Z
image: https://img-global.cpcdn.com/recipes/ef2cd48d9630e90b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ef2cd48d9630e90b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ef2cd48d9630e90b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Lola Weaver
ratingvalue: 4.5
reviewcount: 38703
recipeingredient:
- "250 gr dada ayam filet"
- "2 lembar daun jeruk"
- "1 batang serai"
- "2 lembar daun salam"
- "1 ruas laos"
- "10 sdm minyak goreng"
- "1 1/2 sdm gula"
- "1 sdt garam"
- "Sejumput micin"
- "Sejumput penyedap rasa"
- "200 ml Air"
- " Bumbu halus"
- "10 biji cabai rawit merah"
- "5 biji cabai merah besar"
- "5 siung bawang merah"
- "4 siung bawang putih"
- "1 cm jahe"
- "2 cm kunyit"
- "1 sdt merica"
recipeinstructions:
- "Potong dadu daging ayam."
- "Haluskan cabai, bawang merah, bawang putih, jahe, kunyit dan merica"
- "Geprak laos dan serai"
- "Panaskan minyak. Kemudian tumis bumbu halus, serai, daun salam, laos dan daun jeruk sampai harum"
- "Masukkan ayam yang sudah di potong -potong tadi."
- "Beri air. Tunggu sampai mendidih. Masukkan garam, gula, micin dan penyedap rasa."
- "Tunggu sampai sedikit surut airnya dan daging sudah empuk."
- "Angkat dan sajikan."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 143 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam rica-rica](https://img-global.cpcdn.com/recipes/ef2cd48d9630e90b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau gurih. Ciri makanan Indonesia ayam rica-rica yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan keluarga bisa diperoleh dengan cara simple. Diantaranya adalah membuat makanan Ayam rica-rica untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang dapat anda buat salah satunya ayam rica-rica yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam rica-rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 8 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica:

1. Dibutuhkan 250 gr dada ayam filet
1. Jangan lupa 2 lembar daun jeruk
1. Siapkan 1 batang serai
1. Jangan lupa 2 lembar daun salam
1. Harap siapkan 1 ruas laos
1. Siapkan 10 sdm minyak goreng
1. Jangan lupa 1 1/2 sdm gula
1. Tambah 1 sdt garam
1. Tambah Sejumput micin
1. Diperlukan Sejumput penyedap rasa
1. Siapkan 200 ml Air
1. Harus ada  Bumbu halus:
1. Jangan lupa 10 biji cabai rawit merah
1. Siapkan 5 biji cabai merah besar
1. Harus ada 5 siung bawang merah
1. Tambah 4 siung bawang putih
1. Tambah 1 cm jahe
1. Siapkan 2 cm kunyit
1. Diperlukan 1 sdt merica




<!--inarticleads2-->

##### Langkah membuat  Ayam rica-rica:

1. Potong dadu daging ayam.
1. Haluskan cabai, bawang merah, bawang putih, jahe, kunyit dan merica
1. Geprak laos dan serai
1. Panaskan minyak. Kemudian tumis bumbu halus, serai, daun salam, laos dan daun jeruk sampai harum
1. Masukkan ayam yang sudah di potong -potong tadi.
1. Beri air. Tunggu sampai mendidih. Masukkan garam, gula, micin dan penyedap rasa.
1. Tunggu sampai sedikit surut airnya dan daging sudah empuk.
1. Angkat dan sajikan.




Demikianlah cara membuat ayam rica-rica yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan teruji, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
