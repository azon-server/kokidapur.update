---
description: "Resep : Ayam Goreng Krispy Cepat"
title: "Resep : Ayam Goreng Krispy Cepat"
slug: 418-resep-ayam-goreng-krispy-cepat
date: 2020-08-29T03:03:34.326Z
image: https://img-global.cpcdn.com/recipes/b7c6634b1c16d567/751x532cq70/ayam-goreng-krispy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b7c6634b1c16d567/751x532cq70/ayam-goreng-krispy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b7c6634b1c16d567/751x532cq70/ayam-goreng-krispy-foto-resep-utama.jpg
author: Alexander Alexander
ratingvalue: 4.7
reviewcount: 29958
recipeingredient:
- "6 potong Ayam"
- "1/2 Buah perasan jeruk sy 1 buah"
- " Bahan Marinasi"
- "3 siung bawang putih"
- "1/2 sdt lada bubuk"
- "1 sdt Garam"
- "1,5 sdm air"
- " Bahan Tepung"
- "250 gr Terigu pro sedang sy skip"
- "150 gr Tepung Kobe super crispy kentucky sy 1 Bungkus besar"
- "1 sdm susu bubuk"
- " Bahan celupan"
- "3 sdm Tepung Kobe super crispy chicken"
- "12 sdm air matang"
recipeinstructions:
- "Cuci ayam hingga bersih kemudian beri air jeruk nipis dan garam di remas2 diamkan 15-30 Menit kemudian cuci bersih lagi. Siapkan wadah masukkan ayam tambahkan bumbu Marinasi, aduk rata (sy sambil remas2 biar menyerap) kemudian simpan dalam kulkas semalaman (sy cuma 3 jam)"
- "Siapkan bahan celupan dan bahan tepung. Masukkan ayam ke bahan tepung Kering."
- "Kemudian masukkan kedalam adonan tepung Basah. Angkat masukkan ke tepung Kering lagi, angkat masukkan ke tepung Basah dan pindah ketepung Kering lagi. Lakukan hingga ayam habis. Jangan lupa saat memasukkan ayam ke bahan tepung Kering sambil di cubit2 dan kibas supaya hasilnya kriting."
- "Manaskan minyak, goreng ayam hingga kuning ke coklatan (balik2 ayam supaya matang kedua sisinya. Angkat tiriskan. Siap di sajikan 😉. Selamat mencoba 🙏"
categories:
- Recipe
tags:
- ayam
- goreng
- krispy

katakunci: ayam goreng krispy 
nutrition: 116 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Goreng Krispy](https://img-global.cpcdn.com/recipes/b7c6634b1c16d567/751x532cq70/ayam-goreng-krispy-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga renyah. Ciri khas masakan Indonesia ayam goreng krispy yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam Goreng Krispy untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang dapat anda coba salah satunya ayam goreng krispy yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep ayam goreng krispy tanpa harus bersusah payah.
Berikut ini resep Ayam Goreng Krispy yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Krispy:

1. Tambah 6 potong Ayam
1. Jangan lupa 1/2 Buah perasan jeruk (sy 1 buah)
1. Dibutuhkan  Bahan Marinasi
1. Tambah 3 siung bawang putih
1. Siapkan 1/2 sdt lada bubuk
1. Harap siapkan 1 sdt Garam
1. Harap siapkan 1,5 sdm air
1. Tambah  Bahan Tepung
1. Dibutuhkan 250 gr Terigu pro sedang (sy skip)
1. Harap siapkan 150 gr Tepung Kobe super crispy kentucky (sy 1 Bungkus besar)
1. Diperlukan 1 sdm susu bubuk
1. Siapkan  Bahan celupan
1. Dibutuhkan 3 sdm Tepung Kobe super crispy chicken
1. Harus ada 12 sdm air matang




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Krispy:

1. Cuci ayam hingga bersih kemudian beri air jeruk nipis dan garam di remas2 diamkan 15-30 Menit kemudian cuci bersih lagi. Siapkan wadah masukkan ayam tambahkan bumbu Marinasi, aduk rata (sy sambil remas2 biar menyerap) kemudian simpan dalam kulkas semalaman (sy cuma 3 jam)
1. Siapkan bahan celupan dan bahan tepung. Masukkan ayam ke bahan tepung Kering.
1. Kemudian masukkan kedalam adonan tepung Basah. Angkat masukkan ke tepung Kering lagi, angkat masukkan ke tepung Basah dan pindah ketepung Kering lagi. Lakukan hingga ayam habis. Jangan lupa saat memasukkan ayam ke bahan tepung Kering sambil di cubit2 dan kibas supaya hasilnya kriting.
1. Manaskan minyak, goreng ayam hingga kuning ke coklatan (balik2 ayam supaya matang kedua sisinya. Angkat tiriskan. Siap di sajikan 😉. Selamat mencoba 🙏




Demikianlah cara membuat ayam goreng krispy yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
