---
description: "Resep : Ayam goreng lengkuas Luar biasa"
title: "Resep : Ayam goreng lengkuas Luar biasa"
slug: 410-resep-ayam-goreng-lengkuas-luar-biasa
date: 2020-11-10T14:26:09.314Z
image: https://img-global.cpcdn.com/recipes/69cdc4fbe31afb8f/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/69cdc4fbe31afb8f/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/69cdc4fbe31afb8f/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Nathaniel Vasquez
ratingvalue: 4.5
reviewcount: 16165
recipeingredient:
- "1 kg paha ayam"
- "250-300 gr lengkuas parut"
- "1 batang sereh"
- "2 lembar daun salam"
- "3 lembar daun jeruk sobeksobek"
- "200 ml air untuk merebus ayam  secukupnya air"
- " Bumbu halus"
- "6 siung bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1/2 sdt lada bubuk"
- "1 sdm ketumbar"
- "Secukupnya garam"
- " Pelengkap"
- "1 butir telur"
- " Minyak goreng"
recipeinstructions:
- "Marinasi ayam dengan mencampurkan lengkuas parut dan bumbu halus (simpan di kulkas kurleb 1 jam)"
- "Keluarkan dari kulkas. Lalu rebus dengan menambahkan air, daun jeruk, daun salam dan sereh sampai matang dan empuk. Saya menggunakan api kecil selama 25 menit."
- "Setelah empuk, matikan kompor. Pisahkan dulu ayam dari bumbunya lalu biarkan bumbu di dalam panci dingin. Sereh dan daun salam bisa dibuang saja ya, sisakan daun jeruk untuk nanti ikut digoreng."
- "Kocok telur lalu tuang ke dalam bumbu aduk rata. Masukkan lagi ayamnya balur dengan bumbu, boleh juga dicelup-celup ke bumbunya lalu goreng ayamnya sampai matang, kalau bisa bumbunya tidak banyak yang ikut digoreng ya nanti bumbu akan digoreng terpisah."
- "Setelah ayam matang, angkat dan tiriskan. Goreng sisa bumbu sampai kecoklatan dan kering. Angkat lalu tiriskan. Setelah minyaknya tiris maka tuang di atas ayam goreng. Sajikan."
categories:
- Recipe
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 169 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam goreng lengkuas](https://img-global.cpcdn.com/recipes/69cdc4fbe31afb8f/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan renyah. Ciri makanan Indonesia ayam goreng lengkuas yang penuh dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam goreng lengkuas untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

Resep &#39;ayam goreng lengkuas&#39; paling teruji. Salah satunya adalah resep ayam goreng lengkuas bumbu Padang dan juga ayam goreng Resep Ayam Goreng Lengkuas - By @linagui.kitchen. Bahan dan Bumbu Ayam Goreng  Ayam goreng memang menjadi salah satu menu hidangan favorit, baik bagi anak-anak Yup, lengkuas ini bisa kamu parut, campurkan dengan bumbu lumuran ayam lainnya kemudian goreng. Sekilas mirip Ayam Goreng ditaburi serundeng dan serundeng ini berasal dari lengkuas yang diparut.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang bisa anda praktekkan salah satunya ayam goreng lengkuas yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep ayam goreng lengkuas tanpa harus bersusah payah.
Seperti resep Ayam goreng lengkuas yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam goreng lengkuas:

1. Siapkan 1 kg paha ayam
1. Diperlukan 250-300 gr lengkuas, parut
1. Jangan lupa 1 batang sereh
1. Jangan lupa 2 lembar daun salam
1. Jangan lupa 3 lembar daun jeruk, sobek-sobek
1. Jangan lupa 200 ml air untuk merebus ayam / secukupnya air
1. Siapkan  Bumbu halus:
1. Harus ada 6 siung bawang putih
1. Jangan lupa 1 ruas jahe
1. Tambah 1 ruas kunyit
1. Tambah 1/2 sdt lada bubuk
1. Jangan lupa 1 sdm ketumbar
1. Jangan lupa Secukupnya garam
1. Dibutuhkan  Pelengkap:
1. Harus ada 1 butir telur
1. Harap siapkan  Minyak goreng


Tidak heran, daging ayam yang kenyal dan nikmat itu. Resep Ayam Goreng Lengkuas, Tambah Sambal Lebih Nikmat! Ayam Goreng Lengkuas, satu variasi resep klasik bagi mereka yang mencari selingan selain serundeng ataupun kremes. Begitu banyak resep memasak ayam, salah satunya dalam artikel ini adalah ayam goreng lengkuas. 

<!--inarticleads2-->

##### Cara membuat  Ayam goreng lengkuas:

1. Marinasi ayam dengan mencampurkan lengkuas parut dan bumbu halus (simpan di kulkas kurleb 1 jam)
1. Keluarkan dari kulkas. Lalu rebus dengan menambahkan air, daun jeruk, daun salam dan sereh sampai matang dan empuk. Saya menggunakan api kecil selama 25 menit.
1. Setelah empuk, matikan kompor. Pisahkan dulu ayam dari bumbunya lalu biarkan bumbu di dalam panci dingin. Sereh dan daun salam bisa dibuang saja ya, sisakan daun jeruk untuk nanti ikut digoreng.
1. Kocok telur lalu tuang ke dalam bumbu aduk rata. Masukkan lagi ayamnya balur dengan bumbu, boleh juga dicelup-celup ke bumbunya lalu goreng ayamnya sampai matang, kalau bisa bumbunya tidak banyak yang ikut digoreng ya nanti bumbu akan digoreng terpisah.
1. Setelah ayam matang, angkat dan tiriskan. - Goreng sisa bumbu sampai kecoklatan dan kering. Angkat lalu tiriskan. Setelah minyaknya tiris maka tuang di atas ayam goreng. - Sajikan.


Ayam Goreng Lengkuas, satu variasi resep klasik bagi mereka yang mencari selingan selain serundeng ataupun kremes. Begitu banyak resep memasak ayam, salah satunya dalam artikel ini adalah ayam goreng lengkuas. Resep ayam lainnya yang tak kalah populer adalah ayam goreng kremes, yang biasanya disajikan di. Simple dan Anti Gagal Hi guys… Kali ini The Hasan Video membagikan resep simple yang lezat. Resep Ayam Goreng Lengkuas, Ayam Goreng Kalasan. 

Demikianlah cara membuat ayam goreng lengkuas yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
