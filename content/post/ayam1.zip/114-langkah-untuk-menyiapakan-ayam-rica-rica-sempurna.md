---
description: "Langkah untuk menyiapakan Ayam Rica Rica Sempurna"
title: "Langkah untuk menyiapakan Ayam Rica Rica Sempurna"
slug: 114-langkah-untuk-menyiapakan-ayam-rica-rica-sempurna
date: 2020-11-27T19:37:11.063Z
image: https://img-global.cpcdn.com/recipes/db61ba5def712174/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/db61ba5def712174/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/db61ba5def712174/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Luella Lee
ratingvalue: 4.9
reviewcount: 14162
recipeingredient:
- "1 kg ayam saya 750 gram potong potong"
- "1 jeruk nipisambil airnya"
- "1 ikat kemangi saya ganti daun melinjo"
- "1 ikat daun bawang saya 2 batangiris"
- "7 cabe rawit utuh tambahan saya"
- "2 sereh geprek"
- "1 ruas jari lengkuasgeprek"
- "Secukupnya garam"
- "Secukupnya penyedap rasa"
- "Secukupnya gula pasir"
- " Bumbu Halus"
- "20 cabe rawit 5 cabe merah saya 10 cabe rawit"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "2 kemiri"
- "2 ruas jari jahe"
- "2 ruas jari kunyit"
- "1/2 ruas jari lengkuas"
- "2 sereh"
recipeinstructions:
- "Siapakan bahan, Potong ayam sesuai selera lalu bersihkan dan beri air perasan jeruk nipis diamkan 10 menit, sisihkan."
- "Tumis Bumbu halus, lengkuas dan sereh sampai harum. Kemudian masukan ayam, oseng hingga tercampur rata lalu tambahkan air 1 gelas, tambahkan penyedap rasa, tutup wajan dan masak hingga air susut setengah."
- "Masukkan daun melinjo, tutup kembali sebentar. Terakhir masukkan daun bawang, cabe,garam dan gula, masak hingga air menyusut. Koreksi rasa dan angkat"
- "Sajikan dengan nasi hangat"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 255 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/db61ba5def712174/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang harus kita lestarikan karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica rica yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan kesan tersendiri yang merupakan keragaman Kita



Kedekatan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Rica Rica untuk keluarga. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang dapat anda buat salah satunya ayam rica rica yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica:

1. Tambah 1 kg ayam, saya 750 gram (potong potong)
1. Harus ada 1 jeruk nipis-ambil airnya
1. Harus ada 1 ikat kemangi (saya ganti daun melinjo)
1. Jangan lupa 1 ikat daun bawang (saya 2 batang)-iris
1. Dibutuhkan 7 cabe rawit utuh (tambahan saya)
1. Harap siapkan 2 sereh -geprek
1. Jangan lupa 1 ruas jari lengkuas-geprek
1. Tambah Secukupnya garam
1. Jangan lupa Secukupnya penyedap rasa
1. Diperlukan Secukupnya gula pasir
1. Tambah  Bumbu Halus:
1. Dibutuhkan 20 cabe rawit 5 cabe merah (saya 10 cabe rawit)
1. Diperlukan 8 siung bawang merah
1. Dibutuhkan 5 siung bawang putih
1. Diperlukan 2 kemiri
1. Dibutuhkan 2 ruas jari jahe
1. Siapkan 2 ruas jari kunyit
1. Tambah 1/2 ruas jari lengkuas
1. Siapkan 2 sereh




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Rica:

1. Siapakan bahan, Potong ayam sesuai selera lalu bersihkan dan beri air perasan jeruk nipis diamkan 10 menit, sisihkan.
1. Tumis Bumbu halus, lengkuas dan sereh sampai harum. Kemudian masukan ayam, oseng hingga tercampur rata lalu tambahkan air 1 gelas, tambahkan penyedap rasa, tutup wajan dan masak hingga air susut setengah.
1. Masukkan daun melinjo, tutup kembali sebentar. Terakhir masukkan daun bawang, cabe,garam dan gula, masak hingga air menyusut. Koreksi rasa dan angkat
1. Sajikan dengan nasi hangat




Demikianlah cara membuat ayam rica rica yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
