---
description: "Resep : Ayam Rica Kemangi terupdate"
title: "Resep : Ayam Rica Kemangi terupdate"
slug: 90-resep-ayam-rica-kemangi-terupdate
date: 2020-10-19T21:54:55.756Z
image: https://img-global.cpcdn.com/recipes/32946253ab16d3f7/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/32946253ab16d3f7/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/32946253ab16d3f7/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Lillie Adkins
ratingvalue: 4.8
reviewcount: 27873
recipeingredient:
- "1 ekor ayam kampung potong 14"
- "2 buah jeruk nipis"
- " Bumbu halus"
- "12 buah cabe merah keriting"
- "4 butir kemiri"
- "10 siung bawang merah"
- "4 siung bawang putih"
- "1 ruas kunyit"
- " Bahan pelengkap"
- "800 ml air"
- "4 lembar daun jeruk iris"
- "1/2 lembar daun kunyit iris"
- "2 tangkai sereh iris"
- "2 lembar daun bawang iris"
- "1 buah tomat potong"
- "2 ruas lengkuas geprek"
- "1 ruas jahe geprek"
- "2 sdt garam"
- "6 buah cabe rawit setan"
- "4 ikat kemangi"
recipeinstructions:
- "Cuci bersih ayam lalu lumuri air perasan jeruk nipis pakai 1 buah, sisanya sisihkan dulu. Biarkan 30 menit, sambil siapkan bahan lainnya. Blender bumbu halus lalu tumis dengan sedikit minyak, masukkan daun jeruk, daun kunyit, jahe, lengkuas, sereh. Masak sampai bumbu halus berubah warna dan harum."
- "Masukkan ayam, aduk rata. Kemudian tuang air, aduk rata. Tutup wajannya dan masak sampai ayam empuk kurleb 50 menit."
- "Setelah ayam empuk, masukkan kemangi lalu aduk rata. Masukkan tomat, daun bawang, cabe rawit setan dan tambahkan garam. Koreksi rasa. Beri perasan jeruk nipis 1/2 buah atau bisa disesuaikan. Setelah rasanya pas, matikan kompor dan sajikan."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 282 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/32946253ab16d3f7/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang dapat kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica kemangi yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Nusantara



Kehangatan keluarga dapat didapat dengan cara mudah. Diantaranya adalah memasak Ayam Rica Kemangi untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang dapat anda contoh salah satunya ayam rica kemangi yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Tambah 1 ekor ayam kampung, potong 14
1. Dibutuhkan 2 buah jeruk nipis
1. Diperlukan  Bumbu halus:
1. Harus ada 12 buah cabe merah keriting
1. Dibutuhkan 4 butir kemiri
1. Siapkan 10 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Harus ada 1 ruas kunyit
1. Jangan lupa  Bahan pelengkap:
1. Harus ada 800 ml air
1. Tambah 4 lembar daun jeruk, iris
1. Jangan lupa 1/2 lembar daun kunyit, iris
1. Jangan lupa 2 tangkai sereh, iris
1. Jangan lupa 2 lembar daun bawang, iris
1. Tambah 1 buah tomat, potong
1. Siapkan 2 ruas lengkuas, geprek
1. Diperlukan 1 ruas jahe, geprek
1. Dibutuhkan 2 sdt garam
1. Tambah 6 buah cabe rawit setan
1. Harus ada 4 ikat kemangi




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Kemangi:

1. Cuci bersih ayam lalu lumuri air perasan jeruk nipis pakai 1 buah, sisanya sisihkan dulu. Biarkan 30 menit, sambil siapkan bahan lainnya. Blender bumbu halus lalu tumis dengan sedikit minyak, masukkan daun jeruk, daun kunyit, jahe, lengkuas, sereh. Masak sampai bumbu halus berubah warna dan harum.
1. Masukkan ayam, aduk rata. Kemudian tuang air, aduk rata. Tutup wajannya dan masak sampai ayam empuk kurleb 50 menit.
1. Setelah ayam empuk, masukkan kemangi lalu aduk rata. Masukkan tomat, daun bawang, cabe rawit setan dan tambahkan garam. Koreksi rasa. Beri perasan jeruk nipis 1/2 buah atau bisa disesuaikan. Setelah rasanya pas, matikan kompor dan sajikan.




Demikianlah cara membuat ayam rica kemangi yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan teruji, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
