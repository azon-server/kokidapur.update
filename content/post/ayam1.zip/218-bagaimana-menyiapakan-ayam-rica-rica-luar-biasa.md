---
description: "Bagaimana menyiapakan Ayam Rica-Rica Luar biasa"
title: "Bagaimana menyiapakan Ayam Rica-Rica Luar biasa"
slug: 218-bagaimana-menyiapakan-ayam-rica-rica-luar-biasa
date: 2020-12-26T15:43:35.847Z
image: https://img-global.cpcdn.com/recipes/782ee8a5ce9660b2/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/782ee8a5ce9660b2/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/782ee8a5ce9660b2/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Cory Luna
ratingvalue: 4
reviewcount: 37543
recipeingredient:
- "200 gram Dada Ayam"
- "Secukupnya Kunyit Bubuk"
- "Secukupnya Air Jeruk Nipis"
- "Secukupnya Garam"
- "5 buah Cabe Merah Keriting"
- "5 buah Cabe Rawit Merah"
- "3 siung Bawang Merah"
- "2 siung Bawang Putih"
- "1 cm Jahe"
- "1 cm Kunyit"
- "2 butir Kemiri"
- "2 cm Lengkuas"
- "3 batang Serai Geprek"
- "1 lembar Daun Pandan"
- "2 lembar Daun Salam"
- "2 lembar Daun Jeruk"
- "Secukupnya Gula Pasir"
- "Secukupnya Kaldu Ayam Bubuk Me Royco Ayam"
- "Secukupnya Minyak Goreng"
- "Secukupnya Air"
recipeinstructions:
- "Cuci bersih ayam dengan air mengalir, tiriskan, potong dadu. Baluri dengan kunyit bubuk, air jeruk nipis, dan garam. Diamkan selama 15 menit."
- "Panaskan minyak goreng, goreng ayam hingga setengah matang."
- "Blender kasar cabe merah keriting, cabe rawit merah, bawang merah, bawang putih, jahe, kunyit, kemiri, dan lengkuas dengan menambahkan sedikit minyak."
- "Tumis bumbu halus hingga matang dan harum. Kemudian tambahkan serai, daun pandan, daun salam, dan daun jeruk. Tumis kembali hingga layu. Masukkan ayam kemudian tumis kembali hingga matang."
- "Tambahkan sedikit air, garam, gula pasir, dan kaldu ayam bubuk. Koreksi rasa. Sisihkan."
- "Ayam rica-rica siap untuk dihidangkan."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 206 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/782ee8a5ce9660b2/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang harus kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica-rica yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Kita



Keharmonisan rumah tangga dapat didapat dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Rica-Rica untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang bisa anda coba salah satunya ayam rica-rica yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica:

1. Harap siapkan 200 gram Dada Ayam
1. Diperlukan Secukupnya Kunyit Bubuk
1. Siapkan Secukupnya Air Jeruk Nipis
1. Dibutuhkan Secukupnya Garam
1. Harus ada 5 buah Cabe Merah Keriting
1. Tambah 5 buah Cabe Rawit Merah
1. Diperlukan 3 siung Bawang Merah
1. Diperlukan 2 siung Bawang Putih
1. Tambah 1 cm Jahe
1. Harus ada 1 cm Kunyit
1. Dibutuhkan 2 butir Kemiri
1. Tambah 2 cm Lengkuas
1. Harus ada 3 batang Serai Geprek
1. Dibutuhkan 1 lembar Daun Pandan
1. Dibutuhkan 2 lembar Daun Salam
1. Harap siapkan 2 lembar Daun Jeruk
1. Harap siapkan Secukupnya Gula Pasir
1. Jangan lupa Secukupnya Kaldu Ayam Bubuk (Me: Royco Ayam)
1. Tambah Secukupnya Minyak Goreng
1. Siapkan Secukupnya Air




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica:

1. Cuci bersih ayam dengan air mengalir, tiriskan, potong dadu. Baluri dengan kunyit bubuk, air jeruk nipis, dan garam. Diamkan selama 15 menit.
1. Panaskan minyak goreng, goreng ayam hingga setengah matang.
1. Blender kasar cabe merah keriting, cabe rawit merah, bawang merah, bawang putih, jahe, kunyit, kemiri, dan lengkuas dengan menambahkan sedikit minyak.
1. Tumis bumbu halus hingga matang dan harum. Kemudian tambahkan serai, daun pandan, daun salam, dan daun jeruk. Tumis kembali hingga layu. Masukkan ayam kemudian tumis kembali hingga matang.
1. Tambahkan sedikit air, garam, gula pasir, dan kaldu ayam bubuk. Koreksi rasa. Sisihkan.
1. Ayam rica-rica siap untuk dihidangkan.




Demikianlah cara membuat ayam rica-rica yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
