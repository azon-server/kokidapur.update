---
description: "Resep : Ayam Goreng Ungkep Bumbu Kuning Teruji"
title: "Resep : Ayam Goreng Ungkep Bumbu Kuning Teruji"
slug: 448-resep-ayam-goreng-ungkep-bumbu-kuning-teruji
date: 2020-10-03T05:34:30.451Z
image: https://img-global.cpcdn.com/recipes/280bfb3ca2ac129a/751x532cq70/ayam-goreng-ungkep-bumbu-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/280bfb3ca2ac129a/751x532cq70/ayam-goreng-ungkep-bumbu-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/280bfb3ca2ac129a/751x532cq70/ayam-goreng-ungkep-bumbu-kuning-foto-resep-utama.jpg
author: Nelle Romero
ratingvalue: 4.4
reviewcount: 15151
recipeingredient:
- "1 kg ayam dipotong jadi 12"
- "1/2 papan tempe potong sesuai selera tambahan dari saya"
- "1 buah jeruk nipis"
- "500 ml air"
- " Bumbu Halus"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "1.5 sdt kunyit bubuk"
- "1 sdm ketumbar bubuk"
- "5 butir kemiri"
- "1 sdt kaldu bubuk"
- " Bahan Cemplung"
- "3 lembar daun jeruk"
- "2 sereh geprek"
- "5 cm lengkuas resep asli 2 cm parut"
recipeinstructions:
- "Cuci bersih ayam, buang lendir, beri air jeruk nipis baluri merata dan diamkan 15 menit"
- "Buat bumbu halus lalu tuang ke dalam wajan"
- "Masukkan potongan ayam ke dalam wajan dan baluri dengan bumbu halus lalu nyalakan kompor"
- "Tuang air dan masukkan bahan cemplung, tutup wajan, setelah air terlihat mulai menyusut dan ayam berubah warna masukkan tempe, lanjutkan ungkep ayam dan tempe hingga air susut"
- "Penampakan ayam yang sudah diungkep, digoreng langsung atau bisa disimpan di frizer, sajikan ayam dan tempe dengan sambal 🤗"
categories:
- Recipe
tags:
- ayam
- goreng
- ungkep

katakunci: ayam goreng ungkep 
nutrition: 291 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Goreng Ungkep Bumbu Kuning](https://img-global.cpcdn.com/recipes/280bfb3ca2ac129a/751x532cq70/ayam-goreng-ungkep-bumbu-kuning-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis dan gurih. Ciri khas masakan Indonesia ayam goreng ungkep bumbu kuning yang kaya dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kehangatan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah memasak Ayam Goreng Ungkep Bumbu Kuning untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang bisa anda buat salah satunya ayam goreng ungkep bumbu kuning yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep ayam goreng ungkep bumbu kuning tanpa harus bersusah payah.
Berikut ini resep Ayam Goreng Ungkep Bumbu Kuning yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Ungkep Bumbu Kuning:

1. Siapkan 1 kg ayam dipotong jadi 12
1. Dibutuhkan 1/2 papan tempe, potong sesuai selera (tambahan dari saya)
1. Harap siapkan 1 buah jeruk nipis
1. Harap siapkan 500 ml air
1. Jangan lupa  Bumbu Halus:
1. Tambah 8 siung bawang merah
1. Tambah 5 siung bawang putih
1. Jangan lupa 1.5 sdt kunyit bubuk
1. Harus ada 1 sdm ketumbar bubuk
1. Dibutuhkan 5 butir kemiri
1. Diperlukan 1 sdt kaldu bubuk
1. Dibutuhkan  Bahan Cemplung:
1. Dibutuhkan 3 lembar daun jeruk
1. Diperlukan 2 sereh geprek
1. Jangan lupa 5 cm lengkuas (resep asli 2 cm), parut




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Goreng Ungkep Bumbu Kuning:

1. Cuci bersih ayam, buang lendir, beri air jeruk nipis baluri merata dan diamkan 15 menit
1. Buat bumbu halus lalu tuang ke dalam wajan
1. Masukkan potongan ayam ke dalam wajan dan baluri dengan bumbu halus lalu nyalakan kompor
1. Tuang air dan masukkan bahan cemplung, tutup wajan, setelah air terlihat mulai menyusut dan ayam berubah warna masukkan tempe, lanjutkan ungkep ayam dan tempe hingga air susut
1. Penampakan ayam yang sudah diungkep, digoreng langsung atau bisa disimpan di frizer, sajikan ayam dan tempe dengan sambal 🤗




Demikianlah cara membuat ayam goreng ungkep bumbu kuning yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
