---
description: "Resep : Ayam Goreng Lengkuas teraktual"
title: "Resep : Ayam Goreng Lengkuas teraktual"
slug: 294-resep-ayam-goreng-lengkuas-teraktual
date: 2020-11-12T15:25:52.502Z
image: https://img-global.cpcdn.com/recipes/8bf44d520e3df084/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8bf44d520e3df084/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8bf44d520e3df084/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Clyde Coleman
ratingvalue: 4.5
reviewcount: 18539
recipeingredient:
- "10 buah paha ayam"
- "100 gr lengkuas muda"
- "  bahan dihaluskan "
- "7 siung bawang putih"
- "1 sdm ketumbar"
- "1 jempol jahe"
- "4 lembar daun jeruk"
- " baham cemplung "
- "2 lembar daun salam"
- "2 batang sere"
- "1/2 sdm garam"
- "200 ml air"
- "200 ml minyak goreng"
recipeinstructions:
- "Siapkan bahan.. blender bahan yang dihaluskan."
- "Parut lengkuas."
- "Tata ayam di pengorengan..siram bumbu halus."
- "Masukkan air, garam dan lengkuas parut."
- "Campur rata, masukkan bumbu ceplung..hidupkan kompor dan tutup."
- "Sesekali diaduk biar merata bumbunya. Ungkep sampai ayam matang dan air mengering."
- "Panaskan minyak dan goreng ayam sampai matang."
- "Tiriskan..Ayam siap disajikan."
categories:
- Recipe
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 167 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Goreng Lengkuas](https://img-global.cpcdn.com/recipes/8bf44d520e3df084/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam goreng lengkuas yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Kita



Kedekatan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam Goreng Lengkuas untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang bisa anda praktekkan salah satunya ayam goreng lengkuas yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep ayam goreng lengkuas tanpa harus bersusah payah.
Seperti resep Ayam Goreng Lengkuas yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 13 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Lengkuas:

1. Diperlukan 10 buah paha ayam
1. Diperlukan 100 gr lengkuas muda
1. Harap siapkan  🧄🧄 bahan dihaluskan :
1. Siapkan 7 siung bawang putih
1. Harap siapkan 1 sdm ketumbar
1. Tambah 1 jempol jahe
1. Tambah 4 lembar daun jeruk
1. Dibutuhkan  🍃🍂baham cemplung :
1. Harap siapkan 2 lembar daun salam
1. Tambah 2 batang sere
1. Diperlukan 1/2 sdm garam
1. Harus ada 200 ml air
1. Dibutuhkan 200 ml minyak goreng




<!--inarticleads2-->

##### Langkah membuat  Ayam Goreng Lengkuas:

1. Siapkan bahan.. blender bahan yang dihaluskan.
1. Parut lengkuas.
1. Tata ayam di pengorengan..siram bumbu halus.
1. Masukkan air, garam dan lengkuas parut.
1. Campur rata, masukkan bumbu ceplung..hidupkan kompor dan tutup.
1. Sesekali diaduk biar merata bumbunya. Ungkep sampai ayam matang dan air mengering.
1. Panaskan minyak dan goreng ayam sampai matang.
1. Tiriskan..Ayam siap disajikan.




Demikianlah cara membuat ayam goreng lengkuas yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan terbukti, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
