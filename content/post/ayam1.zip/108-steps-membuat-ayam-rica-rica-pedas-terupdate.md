---
description: "Steps membuat Ayam Rica-Rica Pedas terupdate"
title: "Steps membuat Ayam Rica-Rica Pedas terupdate"
slug: 108-steps-membuat-ayam-rica-rica-pedas-terupdate
date: 2021-01-15T13:36:40.201Z
image: https://img-global.cpcdn.com/recipes/9e9e7eb9d4f393b6/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9e9e7eb9d4f393b6/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9e9e7eb9d4f393b6/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
author: Lettie James
ratingvalue: 4.2
reviewcount: 45319
recipeingredient:
- "1/2 kg Ayam saya bagian paha"
- "3 lembar daun jeruk"
- "2 lembar daun salam"
- "1 batang serai"
- "2 sdm kecap manis"
- " Laos digeprek"
- " Gula"
- " Garam"
- " Kaldu Jamur"
- " Bumbu Halus"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "5 butir kemiri"
- "1 ruas jahe"
- "1 ruas kencur"
- "1/2 sdt ketumbar"
- "15-20 cabai merah keriting"
- "5-10 cabai rawit domba sesuai selera"
recipeinstructions:
- "Masukkan semua bumbu halus ke dalam blender. Beri sedikit minyak untuk memudahkan, dan tambahkan sedikit garam supaya tidak bau langu cabai. Kemudian blender sampai halus."
- "Potong kecil-kecil ayam atau sesuai selera. Cuci bersih."
- "Siapkan wajan dan beri minyak goreng. Panaskan."
- "Jika sudah panas, masukkan bumbu halus. Tumis sampai wangi. Masukkan laos geprek, serai geprek, daun salam, dan daun jeruk. Tumis kembali sampai layu."
- "Masukkan ayam, aduk-aduk sampai rata. Kemudian masukkan kurang lebih 500ml air."
- "Tunggu sampai mendidih dan agak menyusut airnya."
- "Masukkan gula, garam, kaldu jamur dan kecap manis. Koreksi rasa."
- "Diamkan sampai air agak surut (atau sesuai selera jika ingin lebih berkuah)."
- "Rica-rica siap dihidangkan."
categories:
- Recipe
tags:
- ayam
- ricarica
- pedas

katakunci: ayam ricarica pedas 
nutrition: 163 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica-Rica Pedas](https://img-global.cpcdn.com/recipes/9e9e7eb9d4f393b6/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang harus kita jaga karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica-rica pedas yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Kita



Kedekatan rumah tangga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica-Rica Pedas untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian masakan yang bisa anda contoh salah satunya ayam rica-rica pedas yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica-rica pedas tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Pedas yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Pedas:

1. Diperlukan 1/2 kg Ayam (saya bagian paha)
1. Siapkan 3 lembar daun jeruk
1. Jangan lupa 2 lembar daun salam
1. Diperlukan 1 batang serai
1. Dibutuhkan 2 sdm kecap manis
1. Harus ada  Laos (digeprek)
1. Harus ada  Gula
1. Siapkan  Garam
1. Harap siapkan  Kaldu Jamur
1. Harap siapkan  Bumbu Halus
1. Harus ada 10 siung bawang merah
1. Harus ada 5 siung bawang putih
1. Harus ada 5 butir kemiri
1. Harap siapkan 1 ruas jahe
1. Diperlukan 1 ruas kencur
1. Tambah 1/2 sdt ketumbar
1. Diperlukan 15-20 cabai merah keriting
1. Diperlukan 5-10 cabai rawit domba (sesuai selera)




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-Rica Pedas:

1. Masukkan semua bumbu halus ke dalam blender. Beri sedikit minyak untuk memudahkan, dan tambahkan sedikit garam supaya tidak bau langu cabai. Kemudian blender sampai halus.
1. Potong kecil-kecil ayam atau sesuai selera. Cuci bersih.
1. Siapkan wajan dan beri minyak goreng. Panaskan.
1. Jika sudah panas, masukkan bumbu halus. Tumis sampai wangi. Masukkan laos geprek, serai geprek, daun salam, dan daun jeruk. Tumis kembali sampai layu.
1. Masukkan ayam, aduk-aduk sampai rata. Kemudian masukkan kurang lebih 500ml air.
1. Tunggu sampai mendidih dan agak menyusut airnya.
1. Masukkan gula, garam, kaldu jamur dan kecap manis. Koreksi rasa.
1. Diamkan sampai air agak surut (atau sesuai selera jika ingin lebih berkuah).
1. Rica-rica siap dihidangkan.




Demikianlah cara membuat ayam rica-rica pedas yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan cepat, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
