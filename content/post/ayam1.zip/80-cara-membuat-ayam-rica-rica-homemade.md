---
description: "Cara membuat Ayam rica-rica Homemade"
title: "Cara membuat Ayam rica-rica Homemade"
slug: 80-cara-membuat-ayam-rica-rica-homemade
date: 2020-09-03T04:07:17.510Z
image: https://img-global.cpcdn.com/recipes/a4b698c4877700ba/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a4b698c4877700ba/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a4b698c4877700ba/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Adam Fernandez
ratingvalue: 4.1
reviewcount: 28698
recipeingredient:
- "1/2 ekor ayam"
- "1 buah tomat"
- "2 cabai besar"
- "5 lembar daun jeruk purut"
- "1 buah jeruk nipis"
- "1 Batang sereh dedeh digeprek"
- "1 ruas jahe digeprek"
- "1 ruas lengkuas digeprek"
- "1 ruas kunyit"
- "4 siung bawang merah"
- "2 siung bawang putih"
- "Secukupnya garam micindan royco"
- " Semangkuk air dingin"
recipeinstructions:
- "Siapkan bahan-bahan"
- "Bersihkan ayam, potong kecil-kecil, cuci kembali lalu tiriskan. Setelah itu taburi dengan jeruk nipis."
- "Ulek bawang merah, bawang putih dan kunyit."
- "Iris cabai, tomat, dan bawang merah (ini untuk ditumis ya)"
- "Siapkan wajan, masukkan minyak secukupnya. Lalu tumis bawang merah"
- "Masukkan bumbu halus yang sudah diulek tadi, tambahkan sereh, jahe, dan lengkuas geprek. Dan tambahkan sedikit air."
- "Masukkan ayam, daun jeruk purut, tomat, irisan cabai, dan tambahkan air secukupnya."
- "Terakhir tambahkan garam, micin, dan royco ayam secukupnya. Setelah matang, bisa langsung disajikan. 😄"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 161 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam rica-rica](https://img-global.cpcdn.com/recipes/a4b698c4877700ba/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau renyah. Karasteristik masakan Indonesia ayam rica-rica yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica-rica untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang bisa anda contoh salah satunya ayam rica-rica yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 8 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica:

1. Siapkan 1/2 ekor ayam
1. Harap siapkan 1 buah tomat
1. Harap siapkan 2 cabai besar
1. Jangan lupa 5 lembar daun jeruk purut
1. Siapkan 1 buah jeruk nipis
1. Dibutuhkan 1 Batang sereh dedeh digeprek
1. Siapkan 1 ruas jahe digeprek
1. Jangan lupa 1 ruas lengkuas digeprek
1. Harap siapkan 1 ruas kunyit
1. Jangan lupa 4 siung bawang merah
1. Harus ada 2 siung bawang putih
1. Siapkan Secukupnya garam, micin,dan royco
1. Harap siapkan  Semangkuk air dingin




<!--inarticleads2-->

##### Cara membuat  Ayam rica-rica:

1. Siapkan bahan-bahan
1. Bersihkan ayam, potong kecil-kecil, cuci kembali lalu tiriskan. Setelah itu taburi dengan jeruk nipis.
1. Ulek bawang merah, bawang putih dan kunyit.
1. Iris cabai, tomat, dan bawang merah (ini untuk ditumis ya)
1. Siapkan wajan, masukkan minyak secukupnya. Lalu tumis bawang merah
1. Masukkan bumbu halus yang sudah diulek tadi, tambahkan sereh, jahe, dan lengkuas geprek. Dan tambahkan sedikit air.
1. Masukkan ayam, daun jeruk purut, tomat, irisan cabai, dan tambahkan air secukupnya.
1. Terakhir tambahkan garam, micin, dan royco ayam secukupnya. Setelah matang, bisa langsung disajikan. 😄




Demikianlah cara membuat ayam rica-rica yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan terbukti, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
