---
description: "Resep : Ayam Rica-Rica terupdate"
title: "Resep : Ayam Rica-Rica terupdate"
slug: 227-resep-ayam-rica-rica-terupdate
date: 2021-01-03T03:41:14.673Z
image: https://img-global.cpcdn.com/recipes/2986277087ddda2b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2986277087ddda2b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2986277087ddda2b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Arthur Kelly
ratingvalue: 4.2
reviewcount: 14501
recipeingredient:
- "1/2 kg ayam"
- "Secukupnya minyak menumis"
- "Secukupnya air"
- " Bumbu Tabur"
- "1 sdt garam"
- "1 sdm gula"
- "1/2 sdt micin optional"
- " Bumbu Halus"
- "5 siung bawang putih"
- "7 siung bawang merah"
- "2 buah cabe besar"
- "10 buah cabe rawit"
- "1 buah tomat"
- "1 ruas jahe"
- "1 ruas kunyit"
- " Daun Aromatik"
- "1 buah serai geprek"
- "3 lembar daun jeruk"
- "1 ruas lengkuas geprek"
- "1 genggam daun kemangi"
recipeinstructions:
- "Siapkan bahan. Blender sampai halus."
- "Panaskan minyak, tumis bumbu halus dengan daun jeruk, lengkuas dan serai. Masukkan ayam, aduk secara merata. Lalu tambahkan air dan bumbu tabur. Tutup wajan, biarkan ayam mateng dan air menyusut"
- "Terakhir masukkan daun kemangi. Koreksi rasa. Sajikan👌"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 265 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT31M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/2986277087ddda2b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang harus kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica-rica yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara



Kehangatan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak Ayam Rica-Rica untuk keluarga. kebersamaan makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang bisa anda coba salah satunya ayam rica-rica yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 20 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica:

1. Tambah 1/2 kg ayam
1. Harus ada Secukupnya minyak (menumis)
1. Jangan lupa Secukupnya air
1. Harap siapkan  Bumbu Tabur
1. Harus ada 1 sdt garam
1. Dibutuhkan 1 sdm gula
1. Jangan lupa 1/2 sdt micin (optional)
1. Jangan lupa  Bumbu Halus
1. Siapkan 5 siung bawang putih
1. Jangan lupa 7 siung bawang merah
1. Diperlukan 2 buah cabe besar
1. Harap siapkan 10 buah cabe rawit
1. Harap siapkan 1 buah tomat
1. Dibutuhkan 1 ruas jahe
1. Siapkan 1 ruas kunyit
1. Dibutuhkan  Daun Aromatik
1. Harus ada 1 buah serai (geprek)
1. Siapkan 3 lembar daun jeruk
1. Tambah 1 ruas lengkuas (geprek)
1. Diperlukan 1 genggam daun kemangi




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-Rica:

1. Siapkan bahan. Blender sampai halus.
1. Panaskan minyak, tumis bumbu halus dengan daun jeruk, lengkuas dan serai. Masukkan ayam, aduk secara merata. Lalu tambahkan air dan bumbu tabur. Tutup wajan, biarkan ayam mateng dan air menyusut
1. Terakhir masukkan daun kemangi. Koreksi rasa. Sajikan👌




Demikianlah cara membuat ayam rica-rica yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
