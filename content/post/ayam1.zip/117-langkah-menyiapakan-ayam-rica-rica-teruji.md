---
description: "Langkah menyiapakan Ayam Rica-Rica Teruji"
title: "Langkah menyiapakan Ayam Rica-Rica Teruji"
slug: 117-langkah-menyiapakan-ayam-rica-rica-teruji
date: 2020-08-30T20:42:29.987Z
image: https://img-global.cpcdn.com/recipes/f2825427bf778195/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f2825427bf778195/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f2825427bf778195/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Josie Delgado
ratingvalue: 5
reviewcount: 28797
recipeingredient:
- "10 potong ayam yang sudah di cuci bersih dan di beri jeruk nipis diamkan 2030 menit"
- "3 lembar daun jeruk"
- "1 lembar daun kunyit iris"
- "1 batang sere geprek atau iris bagian putihnya saja"
- "Seruas lengkuas di geprek"
- "1 buah tomat iris"
- "1 batang daun bawang iris"
- "1 buah jeruk nipis"
- " Minyak untuk menumis"
- "secukupnya Air"
- "secukupnya Garam"
- "secukupnya Kaldu jamur"
- " Bumbu halus"
- "11 buah cabe merah boleh di tambah atau dikurangi sesuai selera"
- "15 cabe buah rawit boleh di tambah atau di kurangi sesuai selera"
- "9 siung bawang merah"
- "3 siung bawang putih"
- "3 butir kemiri"
- "Seruas jahe"
- "1/2 ruas kunyit"
recipeinstructions:
- "Cuci bersih ayam yang sudah di lumuri jeruk nipis"
- "Panaskan minyak, masukkan bumbu halus tumis sampai wangi lalu tambahkan daun jeruk, sere dan lengkuas."
- "Lalu masukkan ayam aduk rata, tambahkan air secukupnya dengan menggunakan api kecil. Masukkan daun kunyit aduk rata."
- "Setelah air menyusut tambahkan garam dan kaldu jamur, dan tambahkan daun bawang serta tomat. Aduk hingga rata. Sajikan dan selamat menikmati ya.."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 189 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/f2825427bf778195/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang dapat kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica-rica yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Kita

Kehangatan keluarga dapat diperoleh dengan cara simple. Salah satunya adalah memasak Ayam Rica-Rica untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang dapat anda contoh salah satunya ayam rica-rica yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica:

1. Jangan lupa 10 potong ayam yang sudah di cuci bersih dan di beri jeruk nipis diamkan 20-30 menit
1. Diperlukan 3 lembar daun jeruk
1. Diperlukan 1 lembar daun kunyit iris
1. Tambah 1 batang sere geprek atau iris bagian putihnya saja
1. Diperlukan Seruas lengkuas di geprek
1. Diperlukan 1 buah tomat iris
1. Tambah 1 batang daun bawang iris
1. Harus ada 1 buah jeruk nipis
1. Tambah  Minyak untuk menumis
1. Jangan lupa secukupnya Air
1. Siapkan secukupnya Garam
1. Diperlukan secukupnya Kaldu jamur
1. Tambah  Bumbu halus
1. Siapkan 11 buah cabe merah boleh di tambah atau dikurangi sesuai selera
1. Harus ada 15 cabe buah rawit boleh di tambah atau di kurangi sesuai selera
1. Siapkan 9 siung bawang merah
1. Diperlukan 3 siung bawang putih
1. Dibutuhkan 3 butir kemiri
1. Harus ada Seruas jahe
1. Tambah 1/2 ruas kunyit




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-Rica:

1. Cuci bersih ayam yang sudah di lumuri jeruk nipis
1. Panaskan minyak, masukkan bumbu halus tumis sampai wangi lalu tambahkan daun jeruk, sere dan lengkuas.
1. Lalu masukkan ayam aduk rata, tambahkan air secukupnya dengan menggunakan api kecil. Masukkan daun kunyit aduk rata.
1. Setelah air menyusut tambahkan garam dan kaldu jamur, dan tambahkan daun bawang serta tomat. Aduk hingga rata. Sajikan dan selamat menikmati ya..




Demikianlah cara membuat ayam rica-rica yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
