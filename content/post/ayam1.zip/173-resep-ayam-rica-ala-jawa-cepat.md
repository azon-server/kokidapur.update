---
description: "Resep : Ayam Rica ala Jawa Cepat"
title: "Resep : Ayam Rica ala Jawa Cepat"
slug: 173-resep-ayam-rica-ala-jawa-cepat
date: 2020-10-24T13:21:47.951Z
image: https://img-global.cpcdn.com/recipes/dcecd055c4a966e6/751x532cq70/ayam-rica-ala-jawa-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dcecd055c4a966e6/751x532cq70/ayam-rica-ala-jawa-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dcecd055c4a966e6/751x532cq70/ayam-rica-ala-jawa-foto-resep-utama.jpg
author: David Edwards
ratingvalue: 4.8
reviewcount: 8618
recipeingredient:
- "1/2 kg ayam potongpotong kecil"
- "2 buah kentang potong 8"
- "3 lembar daun salam"
- "2 batang sereh geprek"
- "3 Sdm kecap manis"
- "3 sdm air asam jawa dari sekitar 57butir biji asam"
- " Gula dan garam"
- " Bumbu Halus"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "4 butir kemiri"
- "5 cabe merah keriting"
- "10 cabe rawit merah"
- "2 ruas jahe"
recipeinstructions:
- "Siapkan bumbu dan ayam, tumis bumbu hingga wangi dan matang."
- "Apabila tumisan bumbu sudah matang masukkan ayam dan kentang, aduk hingga merata. Tuang 1 gelas air matang, kecap, gula dan garam."
- "Masak hingga air surut, setelah air surut, masukkan air asam jawa, masak kembali dan koreksi rasa, setelah rasa sesuai selera, matikan kompor dan sajikan dengan nasi hangat."
categories:
- Recipe
tags:
- ayam
- rica
- ala

katakunci: ayam rica ala 
nutrition: 128 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica ala Jawa](https://img-global.cpcdn.com/recipes/dcecd055c4a966e6/751x532cq70/ayam-rica-ala-jawa-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang patut kita jaga karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica ala jawa yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan keistimewahan yang merupakan keragaman Kita

Kedekatan keluarga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam Rica ala Jawa untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang bisa anda contoh salah satunya ayam rica ala jawa yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica ala jawa tanpa harus bersusah payah.
Seperti resep Ayam Rica ala Jawa yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 14 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica ala Jawa:

1. Harus ada 1/2 kg ayam (potong-potong kecil)
1. Siapkan 2 buah kentang potong 8
1. Harap siapkan 3 lembar daun salam
1. Tambah 2 batang sereh geprek
1. Jangan lupa 3 Sdm kecap manis
1. Tambah 3 sdm air asam jawa (dari sekitar 5-7butir biji asam)
1. Tambah  Gula dan garam
1. Diperlukan  Bumbu Halus
1. Harus ada 6 siung bawang merah
1. Dibutuhkan 3 siung bawang putih
1. Dibutuhkan 4 butir kemiri
1. Jangan lupa 5 cabe merah keriting
1. Harus ada 10 cabe rawit merah
1. Tambah 2 ruas jahe




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica ala Jawa:

1. Siapkan bumbu dan ayam, tumis bumbu hingga wangi dan matang.
1. Apabila tumisan bumbu sudah matang masukkan ayam dan kentang, aduk hingga merata. Tuang 1 gelas air matang, kecap, gula dan garam.
1. Masak hingga air surut, setelah air surut, masukkan air asam jawa, masak kembali dan koreksi rasa, setelah rasa sesuai selera, matikan kompor dan sajikan dengan nasi hangat.




Demikianlah cara membuat ayam rica ala jawa yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan teruji, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
