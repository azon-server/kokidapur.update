---
description: "Cara singkat untuk membuat Ayam goreng saos mentega Terbukti"
title: "Cara singkat untuk membuat Ayam goreng saos mentega Terbukti"
slug: 269-cara-singkat-untuk-membuat-ayam-goreng-saos-mentega-terbukti
date: 2020-09-15T14:55:06.513Z
image: https://img-global.cpcdn.com/recipes/81a29dec478065c1/751x532cq70/ayam-goreng-saos-mentega-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/81a29dec478065c1/751x532cq70/ayam-goreng-saos-mentega-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/81a29dec478065c1/751x532cq70/ayam-goreng-saos-mentega-foto-resep-utama.jpg
author: Theresa Walsh
ratingvalue: 4.6
reviewcount: 9498
recipeingredient:
- "500 gr ayam potong kecil"
- "3 helai daun bawang"
- " Bahan merinasi yang dihaluskan "
- "3 bawang putih"
- "1/2 sdt merica bubuk"
- "1/2 sdt garam"
- "1/2 sdt kaldu jamur"
- " Bahan saos mentega"
- "1 bawang bombay"
- "4 bawang putih"
- "1 sdm kecap asin"
- "1/2 sdm saos tiram"
- "1/2 sdm gula pasir"
- "1 sdm minyak wijen"
- "3 sdm mentega"
- "1/2 gelas air"
recipeinstructions:
- "Potong ayam kecil lalu campurkan dengan bumbu merinasi yg sudah dihaluskan sambil diremas remas, biarkan kurleb 30 menit"
- "Setelah 30 menit lalu goreng ayam sampai golden brown... Sisihkan"
- "Potong bawang Bombay bentuk panjang, dan cincang halus bawang putih lalu tumis sampai harum dan layu."
- "Masukan sedikit air ke tumisan bawang juga mentega, saos2, gula, garam kaldu jamur dan minyak wijen biarkan agak mendidih, lalu masukan ayam yang sudah digoreng aduk2 bentar, dan biarkan meresap terakhir masukan daun bawang aduk2 sampi layu..., Matang deh ayam goreng saos mentega...🧑‍🍳"
categories:
- Recipe
tags:
- ayam
- goreng
- saos

katakunci: ayam goreng saos 
nutrition: 137 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT55M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam goreng saos mentega](https://img-global.cpcdn.com/recipes/81a29dec478065c1/751x532cq70/ayam-goreng-saos-mentega-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan empuk. Ciri kuliner Indonesia ayam goreng saos mentega yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Ayam goreng saos mentega untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang dapat anda praktekkan salah satunya ayam goreng saos mentega yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep ayam goreng saos mentega tanpa harus bersusah payah.
Seperti resep Ayam goreng saos mentega yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam goreng saos mentega:

1. Harap siapkan 500 gr ayam potong kecil
1. Dibutuhkan 3 helai daun bawang
1. Harap siapkan  Bahan merinasi yang dihaluskan ;
1. Harap siapkan 3 bawang putih
1. Dibutuhkan 1/2 sdt merica bubuk
1. Harus ada 1/2 sdt garam
1. Harus ada 1/2 sdt kaldu jamur
1. Dibutuhkan  Bahan saos mentega;
1. Dibutuhkan 1 bawang bombay
1. Dibutuhkan 4 bawang putih
1. Jangan lupa 1 sdm kecap asin
1. Harap siapkan 1/2 sdm saos tiram
1. Siapkan 1/2 sdm gula pasir
1. Tambah 1 sdm minyak wijen
1. Siapkan 3 sdm mentega
1. Diperlukan 1/2 gelas air




<!--inarticleads2-->

##### Instruksi membuat  Ayam goreng saos mentega:

1. Potong ayam kecil lalu campurkan dengan bumbu merinasi yg sudah dihaluskan sambil diremas remas, biarkan kurleb 30 menit
1. Setelah 30 menit lalu goreng ayam sampai golden brown... Sisihkan
1. Potong bawang Bombay bentuk panjang, dan cincang halus bawang putih lalu tumis sampai harum dan layu.
1. Masukan sedikit air ke tumisan bawang juga mentega, saos2, gula, garam kaldu jamur dan minyak wijen biarkan agak mendidih, lalu masukan ayam yang sudah digoreng aduk2 bentar, dan biarkan meresap terakhir masukan daun bawang aduk2 sampi layu..., Matang deh ayam goreng saos mentega...🧑‍🍳




Demikianlah cara membuat ayam goreng saos mentega yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan teruji, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
