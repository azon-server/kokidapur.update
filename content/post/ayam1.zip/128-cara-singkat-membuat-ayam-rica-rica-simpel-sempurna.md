---
description: "Cara singkat membuat Ayam rica rica simpel Sempurna"
title: "Cara singkat membuat Ayam rica rica simpel Sempurna"
slug: 128-cara-singkat-membuat-ayam-rica-rica-simpel-sempurna
date: 2020-10-04T16:25:32.858Z
image: https://img-global.cpcdn.com/recipes/df0ba687259b0685/751x532cq70/ayam-rica-rica-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/df0ba687259b0685/751x532cq70/ayam-rica-rica-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/df0ba687259b0685/751x532cq70/ayam-rica-rica-simpel-foto-resep-utama.jpg
author: Abbie Mills
ratingvalue: 5
reviewcount: 5785
recipeingredient:
- "1/2 ekor ayam"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "1/2 bawang bombai"
- "1/2 tomat"
- "9 buah cabe rawit merah tergantung selera"
- "2 lembar daun jeruk"
- "1 sachet royco disesuaikan"
- " Garam disesuaikan"
- " Marinasi ayam"
- "1/2 sdt royco"
- "1/2 sdt kunyit bubuk"
- "1/2 sdt ketumbar bubuk"
- " Garam"
recipeinstructions:
- "Cuci bersih ayam, lalu marinasi ayam dengan bumbu marinasi"
- "Setelah di marinasi 15 menit goreng ayam sampai kecoklatan"
- "Siapkan bumbu untuk rica rica, uleg kasar bawang merah, bawang putih dan cabai"
- "Setelah di uleg kasar, tumis bawang bombai sampai harum lalu masukkan bumbu, daun jeruk, dan tomat tumis hingga matang"
- "Setelah bumbu matang masukkan sedikit air, lalu tambahkan penyedap, garam, gula, cicipi rasanya jika sudah pas masukkan ayam yang sudah di goreng sebelumnya, masak hingga air kering,"
- "Ayam rica rica siap di sajikan bunda🥰🥰"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 170 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT46M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam rica rica simpel](https://img-global.cpcdn.com/recipes/df0ba687259b0685/751x532cq70/ayam-rica-rica-simpel-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas dan empuk. Ciri khas makanan Nusantara ayam rica rica simpel yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ayam rica rica simpel untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda praktekkan salah satunya ayam rica rica simpel yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica rica simpel tanpa harus bersusah payah.
Seperti resep Ayam rica rica simpel yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica simpel:

1. Jangan lupa 1/2 ekor ayam
1. Harap siapkan 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Tambah 1/2 bawang bombai
1. Siapkan 1/2 tomat
1. Harap siapkan 9 buah cabe rawit merah (tergantung selera)
1. Siapkan 2 lembar daun jeruk
1. Siapkan 1 sachet royco (disesuaikan)
1. Harus ada  Garam (disesuaikan)
1. Diperlukan  Marinasi ayam
1. Diperlukan 1/2 sdt royco
1. Tambah 1/2 sdt kunyit bubuk
1. Harus ada 1/2 sdt ketumbar bubuk
1. Diperlukan  Garam




<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica simpel:

1. Cuci bersih ayam, lalu marinasi ayam dengan bumbu marinasi
1. Setelah di marinasi 15 menit goreng ayam sampai kecoklatan
1. Siapkan bumbu untuk rica rica, uleg kasar bawang merah, bawang putih dan cabai
1. Setelah di uleg kasar, tumis bawang bombai sampai harum lalu masukkan bumbu, daun jeruk, dan tomat tumis hingga matang
1. Setelah bumbu matang masukkan sedikit air, lalu tambahkan penyedap, garam, gula, cicipi rasanya jika sudah pas masukkan ayam yang sudah di goreng sebelumnya, masak hingga air kering,
1. Ayam rica rica siap di sajikan bunda🥰🥰




Demikianlah cara membuat ayam rica rica simpel yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
