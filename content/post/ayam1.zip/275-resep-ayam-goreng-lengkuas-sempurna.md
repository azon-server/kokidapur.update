---
description: "Resep : Ayam Goreng Lengkuas 👩‍🍳 Sempurna"
title: "Resep : Ayam Goreng Lengkuas 👩‍🍳 Sempurna"
slug: 275-resep-ayam-goreng-lengkuas-sempurna
date: 2020-08-12T07:53:07.889Z
image: https://img-global.cpcdn.com/recipes/7d0421a6b51f7645/751x532cq70/ayam-goreng-lengkuas-👩🍳-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7d0421a6b51f7645/751x532cq70/ayam-goreng-lengkuas-👩🍳-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7d0421a6b51f7645/751x532cq70/ayam-goreng-lengkuas-👩🍳-foto-resep-utama.jpg
author: Connor Clark
ratingvalue: 4.5
reviewcount: 26076
recipeingredient:
- "9 ekor potongan ayam bagian paha dung2"
- "150 gr lengkuas diparut"
- " Bumbu halus"
- "15 siung bawang merah"
- "6 siung bawang putih"
- "1 sdm ketumbar"
- "4 butir kemiri"
- "2 buah kunyit"
- "1 ruas jahe"
- "Secukupnya air"
- "3 lembar daun salam mehanya 2"
- "2 lembar daun jeruk sobek2"
- "2 batang sereh"
- "1/2 sdt merica"
- "2 sdm garam"
- "1/2 sdt gula pasir"
- " kaldu bubuk"
- "500 ml air"
recipeinstructions:
- "Siapkan semua bahan-bahannya. Cuci bersih ayam."
- "Masukkan bumbu halus, ayam, daun salam, daun jeruk, sereh, dan lengkuas aduk rata. (Saya tumis sebentar)"
- "Beri air lalu masukkan ayam, aduk rata. Beri garam, merica, kaldu bubuk. Masak dengan api cenderung kecil hingga air menyusut. Lalu saring air ungkepan dan ampas lengkuasnya di goreng untuk taburan."
- "Goreng semua ayam dengan minyak panas dengan api sedang."
- "Ayam goreng lengkuas siap disajikan dengan taburan lengkuas goreng."
categories:
- Recipe
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 155 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Goreng Lengkuas 👩‍🍳](https://img-global.cpcdn.com/recipes/7d0421a6b51f7645/751x532cq70/ayam-goreng-lengkuas-👩🍳-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang harus kita jaga karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam goreng lengkuas 👩‍🍳 yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan ciri khas yang merupakan keragaman Kita

Kedekatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Goreng Lengkuas 👩‍🍳 untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang dapat anda coba salah satunya ayam goreng lengkuas 👩‍🍳 yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu bisa dengan gampang menemukan resep ayam goreng lengkuas 👩‍🍳 tanpa harus bersusah payah.
Seperti resep Ayam Goreng Lengkuas 👩‍🍳 yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Lengkuas 👩‍🍳:

1. Harus ada 9 ekor potongan ayam bagian paha dung2
1. Tambah 150 gr lengkuas (diparut)
1. Diperlukan  Bumbu halus:
1. Tambah 15 siung bawang merah
1. Tambah 6 siung bawang putih
1. Tambah 1 sdm ketumbar
1. Siapkan 4 butir kemiri
1. Harus ada 2 buah kunyit
1. Jangan lupa 1 ruas jahe
1. Jangan lupa Secukupnya air
1. Harap siapkan 3 lembar daun salam (me:hanya 2)
1. Dibutuhkan 2 lembar daun jeruk (sobek2)
1. Tambah 2 batang sereh
1. Harus ada 1/2 sdt merica
1. Dibutuhkan 2 sdm garam
1. Dibutuhkan 1/2 sdt gula pasir
1. Harus ada  kaldu bubuk
1. Jangan lupa 500 ml air




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Lengkuas 👩‍🍳:

1. Siapkan semua bahan-bahannya. Cuci bersih ayam.
1. Masukkan bumbu halus, ayam, daun salam, daun jeruk, sereh, dan lengkuas aduk rata. (Saya tumis sebentar)
1. Beri air lalu masukkan ayam, aduk rata. Beri garam, merica, kaldu bubuk. Masak dengan api cenderung kecil hingga air menyusut. Lalu saring air ungkepan dan ampas lengkuasnya di goreng untuk taburan.
1. Goreng semua ayam dengan minyak panas dengan api sedang.
1. Ayam goreng lengkuas siap disajikan dengan taburan lengkuas goreng.




Demikianlah cara membuat ayam goreng lengkuas 👩‍🍳 yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
