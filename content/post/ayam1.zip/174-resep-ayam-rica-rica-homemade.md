---
description: "Resep : Ayam Rica-rica Homemade"
title: "Resep : Ayam Rica-rica Homemade"
slug: 174-resep-ayam-rica-rica-homemade
date: 2020-11-10T03:52:08.013Z
image: https://img-global.cpcdn.com/recipes/f01cd4c777fb1dec/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f01cd4c777fb1dec/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f01cd4c777fb1dec/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Elmer Mills
ratingvalue: 4.8
reviewcount: 47582
recipeingredient:
- "500 gram potongan ayam"
- "1 sdm air jeruk nipis"
- "secukupnya Garam"
- "4 sdm minyak utk menumis"
- "2 batang daun bawang potong2"
- "1 buah tomat cincang halus"
- "2 cm jahe memarkan"
- "secukupnya gula"
- " Bumbu halus "
- "8 buah bawang merah"
- "5 siung bawang putih"
- "2 buah cabe merah besar"
- "10 buah cabe rawit sy skip"
- "1 cm kunyit"
- "secukupnya Garam"
- "250 ml air"
recipeinstructions:
- "Lumuri ayam dg jeruk dan garam, diamkan selama 15 menit. Tumis bumbu hingga wangi. Masukkan daun bawang, tomat cincang, jahe, gula dan garam. Aduk rata"
- "Masukkan ayam, aduk sampai berubah warna."
- "Tambahkan air. Aduk terus sampai bumbu meresap dan ayam matang. Boleh tambahkan air jika kurang"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 201 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica-rica](https://img-global.cpcdn.com/recipes/f01cd4c777fb1dec/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica-rica yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa keistimewahan yang merupakan keragaman Kita

Resep Ayam Rica Rica Bahan: Daging Ayam Lemon juice Chicken powder Garam. Bawang merah Bawang putih Cabe Jahe Serai Daun jeruk purut Daun kucai. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica.

Keharmonisan keluarga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica-rica untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda praktekkan salah satunya ayam rica-rica yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica:

1. Harus ada 500 gram potongan ayam
1. Jangan lupa 1 sdm air jeruk nipis
1. Jangan lupa secukupnya Garam
1. Jangan lupa 4 sdm minyak utk menumis
1. Tambah 2 batang daun bawang, potong2
1. Dibutuhkan 1 buah tomat, cincang halus
1. Siapkan 2 cm jahe, memarkan
1. Tambah secukupnya gula
1. Jangan lupa  Bumbu halus :
1. Diperlukan 8 buah bawang merah
1. Harus ada 5 siung bawang putih
1. Jangan lupa 2 buah cabe merah besar
1. Jangan lupa 10 buah cabe rawit (sy skip)
1. Jangan lupa 1 cm kunyit
1. Dibutuhkan secukupnya Garam
1. Harap siapkan 250 ml air


Cara pembuatan ayam rica-rica tidaklah sulit. Dibutuhkan bahan-bahan seperti daun jeruk, serai, dan daun pandan agar aromanya menjadi kuat dan khas. Tak hanya ayam, anda juga bisa memasak. Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. 

<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-rica:

1. Lumuri ayam dg jeruk dan garam, diamkan selama 15 menit. Tumis bumbu hingga wangi. Masukkan daun bawang, tomat cincang, jahe, gula dan garam. Aduk rata
1. Masukkan ayam, aduk sampai berubah warna.
1. Tambahkan air. Aduk terus sampai bumbu meresap dan ayam matang. Boleh tambahkan air jika kurang


Tak hanya ayam, anda juga bisa memasak. Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. I really don&#39;t know how it was started but if you take away chili peppers from my life… I&#39;m gone! Chef S Table Ayam Rica Rica. Mukbang Nasi Sama Soup Dan Ayam Rica Makanenakindonesia. 

Demikianlah cara membuat ayam rica-rica yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
