---
description: "Bagaimana untuk membuat (17) Ayam Rica-rica Homemade"
title: "Bagaimana untuk membuat (17) Ayam Rica-rica Homemade"
slug: 187-bagaimana-untuk-membuat-17-ayam-rica-rica-homemade
date: 2020-08-08T02:52:25.363Z
image: https://img-global.cpcdn.com/recipes/135a97cac79ddfad/751x532cq70/17-ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/135a97cac79ddfad/751x532cq70/17-ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/135a97cac79ddfad/751x532cq70/17-ayam-rica-rica-foto-resep-utama.jpg
author: Cornelia Allison
ratingvalue: 4.8
reviewcount: 10846
recipeingredient:
- "1/2 ekor ayam"
- "2 lembar daun pandan yg muda iris2"
- "8 lembar daun jeruk buang tulang iris2"
- "2 batang daun bawang iris2"
- "1 batang serai geprek"
- "Secukupnya gula garam merica dan kaldu jamur"
- "Secukupnya air matang"
- " Bumbu dihaluskan"
- "7 siung bawang merah"
- "4 siung bawang putih"
- "3 butir kemiri sangrai"
- "8 buah cabe rawit merah"
- "3 buah cabe merah keriting"
- "1 ruas jari jahe"
- "1 ruas jari lengkuas"
- "2 ruas jari kunyit"
- "1 buah tomat ukuran sedang"
recipeinstructions:
- "Cuci ayam sampai bersih. Lalu oreng ayam sebentar (jangan sampai kering) sisihkan"
- "Tumis bumbu halus dan batang serai sampai harum. Lalu masukkan daun pandan dan daun jeruk, aduk rata masak sampai bumbu matang."
- "Lalu tuang air, biarkan sampai mendidih, beri gula, garam, merica dan kaldu jamur, aduk rata. Kemudian masukkan ayam, aduk rata kembali, masak sampai bumbu meresap. Terakhir masukkan irisan daun bawang, tes rasa."
- "Angkat lalu sajikan."
categories:
- Recipe
tags:
- 17
- ayam
- ricarica

katakunci: 17 ayam ricarica 
nutrition: 289 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Dessert

---


![(17) Ayam Rica-rica](https://img-global.cpcdn.com/recipes/135a97cac79ddfad/751x532cq70/17-ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga renyah. Ciri makanan Indonesia (17) ayam rica-rica yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah memasak (17) Ayam Rica-rica untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang dapat anda praktekkan salah satunya (17) ayam rica-rica yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep (17) ayam rica-rica tanpa harus bersusah payah.
Seperti resep (17) Ayam Rica-rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat (17) Ayam Rica-rica:

1. Harap siapkan 1/2 ekor ayam
1. Dibutuhkan 2 lembar daun pandan yg muda, iris2
1. Harus ada 8 lembar daun jeruk, buang tulang, iris2
1. Diperlukan 2 batang daun bawang, iris2
1. Siapkan 1 batang serai, geprek
1. Dibutuhkan Secukupnya gula, garam, merica, dan kaldu jamur
1. Jangan lupa Secukupnya air matang
1. Harap siapkan  🌶Bumbu dihaluskan:
1. Harus ada 7 siung bawang merah
1. Harus ada 4 siung bawang putih
1. Dibutuhkan 3 butir kemiri sangrai
1. Harus ada 8 buah cabe rawit merah
1. Siapkan 3 buah cabe merah keriting
1. Harap siapkan 1 ruas jari jahe
1. Jangan lupa 1 ruas jari lengkuas
1. Tambah 2 ruas jari kunyit
1. Harap siapkan 1 buah tomat ukuran sedang




<!--inarticleads2-->

##### Langkah membuat  (17) Ayam Rica-rica:

1. Cuci ayam sampai bersih. Lalu oreng ayam sebentar (jangan sampai kering) sisihkan
1. Tumis bumbu halus dan batang serai sampai harum. Lalu masukkan daun pandan dan daun jeruk, aduk rata masak sampai bumbu matang.
1. Lalu tuang air, biarkan sampai mendidih, beri gula, garam, merica dan kaldu jamur, aduk rata. Kemudian masukkan ayam, aduk rata kembali, masak sampai bumbu meresap. Terakhir masukkan irisan daun bawang, tes rasa.
1. Angkat lalu sajikan.




Demikianlah cara membuat (17) ayam rica-rica yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan terbukti, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
