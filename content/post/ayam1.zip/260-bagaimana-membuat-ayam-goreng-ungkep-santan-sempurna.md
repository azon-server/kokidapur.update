---
description: "Bagaimana membuat Ayam Goreng Ungkep Santan Sempurna"
title: "Bagaimana membuat Ayam Goreng Ungkep Santan Sempurna"
slug: 260-bagaimana-membuat-ayam-goreng-ungkep-santan-sempurna
date: 2020-10-05T22:22:12.244Z
image: https://img-global.cpcdn.com/recipes/d5c4dcfb8317de83/751x532cq70/ayam-goreng-ungkep-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d5c4dcfb8317de83/751x532cq70/ayam-goreng-ungkep-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d5c4dcfb8317de83/751x532cq70/ayam-goreng-ungkep-santan-foto-resep-utama.jpg
author: Leila Thornton
ratingvalue: 4.8
reviewcount: 25880
recipeingredient:
- "1 kg ayam saya gak sampai sekilo menyesuaikan stok"
- "2 lembar daun salam"
- "1 batang sereh memarkan"
- "1 bungkus santan kara 65 ml  air jadi 400 ml"
- "1 sdt gula pasir"
- "1 sdt garam"
- "1 sdt kaldu ayam"
- " Bumbu halus"
- "5 siung bawang merah"
- "5 siung bawang putih saya cuma 3 siung"
- "1 sdt ketumbar sangrai saya gak disangrai"
- "2 ruas kunyit saya 1 sdt bubuk kunyit"
- "4 butir kemiri saya 3 butir aja"
recipeinstructions:
- "Ayam, santan, bahan cemplung dan bumbu halus dicampur satu, masak dengan api kecil sampai air menyusut dan kuah mengental"
- "Ayam ungkep bisa ditaroh di wadah untuk stok lauk di kulkas atau bisa langsung digoreng"
categories:
- Recipe
tags:
- ayam
- goreng
- ungkep

katakunci: ayam goreng ungkep 
nutrition: 193 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT59M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Goreng Ungkep Santan](https://img-global.cpcdn.com/recipes/d5c4dcfb8317de83/751x532cq70/ayam-goreng-ungkep-santan-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam goreng ungkep santan yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa kesan tersendiri yang merupakan keragaman Nusantara

Kedekatan rumah tangga bisa diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam Goreng Ungkep Santan untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang dapat anda praktekkan salah satunya ayam goreng ungkep santan yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam goreng ungkep santan tanpa harus bersusah payah.
Seperti resep Ayam Goreng Ungkep Santan yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 2 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Ungkep Santan:

1. Dibutuhkan 1 kg ayam (saya gak sampai sekilo, menyesuaikan stok)
1. Siapkan 2 lembar daun salam
1. Dibutuhkan 1 batang sereh memarkan
1. Harus ada 1 bungkus santan kara 65 ml + air jadi 400 ml
1. Diperlukan 1 sdt gula pasir
1. Diperlukan 1 sdt garam
1. Diperlukan 1 sdt kaldu ayam
1. Diperlukan  Bumbu halus
1. Siapkan 5 siung bawang merah
1. Tambah 5 siung bawang putih (saya cuma 3 siung)
1. Dibutuhkan 1 sdt ketumbar sangrai (saya gak disangrai)
1. Jangan lupa 2 ruas kunyit (saya 1 sdt bubuk kunyit)
1. Tambah 4 butir kemiri (saya 3 butir aja)




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Ungkep Santan:

1. Ayam, santan, bahan cemplung dan bumbu halus dicampur satu, masak dengan api kecil sampai air menyusut dan kuah mengental
1. Ayam ungkep bisa ditaroh di wadah untuk stok lauk di kulkas atau bisa langsung digoreng




Demikianlah cara membuat ayam goreng ungkep santan yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
