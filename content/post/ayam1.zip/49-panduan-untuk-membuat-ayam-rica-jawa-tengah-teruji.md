---
description: "Panduan untuk membuat Ayam rica jawa tengah Teruji"
title: "Panduan untuk membuat Ayam rica jawa tengah Teruji"
slug: 49-panduan-untuk-membuat-ayam-rica-jawa-tengah-teruji
date: 2020-12-31T09:42:10.921Z
image: https://img-global.cpcdn.com/recipes/eebc8b9951b8dc01/751x532cq70/ayam-rica-jawa-tengah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/eebc8b9951b8dc01/751x532cq70/ayam-rica-jawa-tengah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/eebc8b9951b8dc01/751x532cq70/ayam-rica-jawa-tengah-foto-resep-utama.jpg
author: Alta Jackson
ratingvalue: 4.2
reviewcount: 14321
recipeingredient:
- "1/2 ekor ayam tepong dan sayap"
- "4 siung bawang putih"
- "7 siung bawang merah"
- "1 ruas lengkuas"
- "1 ruas jahe"
- "1 ruas kunyit"
- "2 butir kemiri"
- "10 cabe rawit"
- " Garam"
- " Gula"
- " Totolekaldu jamur"
- "1 batang serai"
- "1 daun bawang"
- " Kecap manis"
- "Secukupnya air"
- "1 buah tomat"
- "1 daun salam"
- " Jeruk nipis"
recipeinstructions:
- "Cuci bersih ayam lalu lumuri dengan jeruk nipis untuk menghilangkan bau amis.diamkan 5 menit.lalu cuci bersih lagi."
- "Haluskan semua bumbu cabe rawit,bawang merah,bawang putih,kunyit dan kemiri.bisa di blender biar praktis.geprek laos dan jahe."
- "Panaskan minyak lalu tumis bumbu halus dan jahe serta laos hingga harum masukkan daun salam.tumis hingga layu dan harum.masukkan air secukupnya."
- "Bumbui dengan garam,gula,dan totole.koreksi rasa.masukkan ayam sampai mendidih dan tercampur dengan bumbu.tunggu sampai ayam empuk.masukkan tomat dan kecap."
- "Koreksi rasa,yang suka pedes bisa ditambahin cabe rawit potong.potongan terakhir masukkan daun bawang yang sudah dipotong. Sajikan dengan nasi panas dan kerupuk.yummy...."
categories:
- Recipe
tags:
- ayam
- rica
- jawa

katakunci: ayam rica jawa 
nutrition: 244 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica jawa tengah](https://img-global.cpcdn.com/recipes/eebc8b9951b8dc01/751x532cq70/ayam-rica-jawa-tengah-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau enak. Ciri khas kuliner Indonesia ayam rica jawa tengah yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Ayam rica jawa tengah untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang bisa anda buat salah satunya ayam rica jawa tengah yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica jawa tengah tanpa harus bersusah payah.
Seperti resep Ayam rica jawa tengah yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica jawa tengah:

1. Diperlukan 1/2 ekor ayam (tepong dan sayap)
1. Harus ada 4 siung bawang putih
1. Diperlukan 7 siung bawang merah
1. Dibutuhkan 1 ruas lengkuas
1. Diperlukan 1 ruas jahe
1. Siapkan 1 ruas kunyit
1. Siapkan 2 butir kemiri
1. Harus ada 10 cabe rawit
1. Harap siapkan  Garam
1. Harus ada  Gula
1. Jangan lupa  Totole/kaldu jamur
1. Diperlukan 1 batang serai
1. Harap siapkan 1 daun bawang
1. Siapkan  Kecap manis
1. Tambah Secukupnya air
1. Harap siapkan 1 buah tomat
1. Harap siapkan 1 daun salam
1. Tambah  Jeruk nipis




<!--inarticleads2-->

##### Langkah membuat  Ayam rica jawa tengah:

1. Cuci bersih ayam lalu lumuri dengan jeruk nipis untuk menghilangkan bau amis.diamkan 5 menit.lalu cuci bersih lagi.
1. Haluskan semua bumbu cabe rawit,bawang merah,bawang putih,kunyit dan kemiri.bisa di blender biar praktis.geprek laos dan jahe.
1. Panaskan minyak lalu tumis bumbu halus dan jahe serta laos hingga harum masukkan daun salam.tumis hingga layu dan harum.masukkan air secukupnya.
1. Bumbui dengan garam,gula,dan totole.koreksi rasa.masukkan ayam sampai mendidih dan tercampur dengan bumbu.tunggu sampai ayam empuk.masukkan tomat dan kecap.
1. Koreksi rasa,yang suka pedes bisa ditambahin cabe rawit potong.potongan terakhir masukkan daun bawang yang sudah dipotong. Sajikan dengan nasi panas dan kerupuk.yummy....




Demikianlah cara membuat ayam rica jawa tengah yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan teruji, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
