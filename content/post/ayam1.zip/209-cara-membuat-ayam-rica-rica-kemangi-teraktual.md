---
description: "Cara membuat Ayam Rica Rica Kemangi teraktual"
title: "Cara membuat Ayam Rica Rica Kemangi teraktual"
slug: 209-cara-membuat-ayam-rica-rica-kemangi-teraktual
date: 2020-08-09T12:46:55.635Z
image: https://img-global.cpcdn.com/recipes/457277078f4f31b3/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/457277078f4f31b3/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/457277078f4f31b3/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Rena Riley
ratingvalue: 5
reviewcount: 1681
recipeingredient:
- "1 ekor Ayam kmpg utuh"
- " Bumbu Halus"
- "8 bawang merah"
- "2 bawang putih"
- "10 cabe Rawit"
- "10 Cabe Kriting"
- " Bahan Uleg"
- "2 bh kemiri yg sdh dsangrai"
- "2 ruas kunyit"
- " Bahan geprek"
- "1 ruas laos"
- "1 ruas jahe"
- "2 Bh Daun salam"
- "2 Bh Daun jeruk"
- "1 bh Daun sere"
- "4 sdm minyak goreng utk menumis"
- "1 ikat Daun kemangi"
- "1 sdt gula"
- "1 sdt gram"
- "secukupnya kaldu ayampenyedap rasa"
- "200 ml air"
recipeinstructions:
- "Potong2 ayam dan cuci bersih ayam lalu sisihkan"
- "Blender bumbu halusss diatas lalu sisihkan kemudian uleg bumbu uleg kemiri dan kunyit sisihkan"
- "Siapkan minyak tunggu hingga panas kemudian masukkan bumbu halus dan bahan uleg ke dalam minyak tumis hingga harum lalu masukkan daun salam, serai,jahe, laos kemudian ayam tumis hingga merata"
- "Kemudian tambahkan air kemudian gula, garam dan kaldu cek rasa sesuai selera tunggu hingga mendidih dn air menyusut kemudian matikan api masukkan daun kemangi.ayam rica2 sudah siap dinikmati"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 113 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/457277078f4f31b3/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan empuk. Ciri khas makanan Indonesia ayam rica rica kemangi yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica Rica Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang dapat anda coba salah satunya ayam rica rica kemangi yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Siapkan 1 ekor Ayam kmpg utuh
1. Harap siapkan  Bumbu Halus
1. Harap siapkan 8 bawang merah
1. Jangan lupa 2 bawang putih
1. Harus ada 10 cabe Rawit
1. Harus ada 10 Cabe Kriting
1. Siapkan  Bahan Uleg
1. Dibutuhkan 2 bh kemiri yg sdh dsangrai
1. Diperlukan 2 ruas kunyit
1. Tambah  Bahan geprek
1. Harus ada 1 ruas laos
1. Jangan lupa 1 ruas jahe
1. Tambah 2 Bh Daun salam
1. Siapkan 2 Bh Daun jeruk
1. Siapkan 1 bh Daun sere
1. Harap siapkan 4 sdm minyak goreng utk menumis
1. Diperlukan 1 ikat Daun kemangi
1. Diperlukan 1 sdt gula
1. Dibutuhkan 1 sdt gram
1. Siapkan secukupnya kaldu ayam/penyedap rasa
1. Diperlukan 200 ml air




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica Kemangi:

1. Potong2 ayam dan cuci bersih ayam lalu sisihkan
1. Blender bumbu halusss diatas lalu sisihkan kemudian uleg bumbu uleg kemiri dan kunyit sisihkan
1. Siapkan minyak tunggu hingga panas kemudian masukkan bumbu halus dan bahan uleg ke dalam minyak tumis hingga harum lalu masukkan daun salam, serai,jahe, laos kemudian ayam tumis hingga merata
1. Kemudian tambahkan air kemudian gula, garam dan kaldu cek rasa sesuai selera tunggu hingga mendidih dn air menyusut kemudian matikan api masukkan daun kemangi.ayam rica2 sudah siap dinikmati




Demikianlah cara membuat ayam rica rica kemangi yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
