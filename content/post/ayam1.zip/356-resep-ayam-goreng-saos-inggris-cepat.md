---
description: "Resep : Ayam Goreng Saos Inggris Cepat"
title: "Resep : Ayam Goreng Saos Inggris Cepat"
slug: 356-resep-ayam-goreng-saos-inggris-cepat
date: 2021-01-03T11:04:03.090Z
image: https://img-global.cpcdn.com/recipes/dfca0f69dc9e2c37/751x532cq70/ayam-goreng-saos-inggris-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dfca0f69dc9e2c37/751x532cq70/ayam-goreng-saos-inggris-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dfca0f69dc9e2c37/751x532cq70/ayam-goreng-saos-inggris-foto-resep-utama.jpg
author: Sophia Warner
ratingvalue: 4.6
reviewcount: 11920
recipeingredient:
- "300 g Ayam saya pake middle wing"
- "3 siung Bawang putih geprek"
- "1 butir Bawang bombay iris"
- "1 sdm Margarin"
- "6 sdm Saos inggris"
- "3 sdm Kecap manis"
- "secukupnya Garam gula pasir lada bubuk dan kaldu jamur"
recipeinstructions:
- "Bumbui ayam dengan garam dan lada bubuk, diamkan sebentar. Lalu goreng ayam hingga matang, angkat dan sisihkan."
- "Tumis bawang putih dan bombay dengan margarin hingga layu dan harum. Lalu masukkan ayam goreng, aduk rata."
- "Masukkan saos inggris, kecap manis, gula, garam, lada bubuk dan kaldu jamur, aduk rata dan jangan lupa tes rasa ya. Beri air sedikit bila perlu. Masak dengan api kecil hingga bumbu meresap ke ayam. Matikan api dan sajikan."
categories:
- Recipe
tags:
- ayam
- goreng
- saos

katakunci: ayam goreng saos 
nutrition: 188 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Goreng Saos Inggris](https://img-global.cpcdn.com/recipes/dfca0f69dc9e2c37/751x532cq70/ayam-goreng-saos-inggris-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam goreng saos inggris yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa ciri khas yang merupakan keragaman Indonesia

Keharmonisan keluarga bisa didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam Goreng Saos Inggris untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang bisa anda coba salah satunya ayam goreng saos inggris yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep ayam goreng saos inggris tanpa harus bersusah payah.
Seperti resep Ayam Goreng Saos Inggris yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 7 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Saos Inggris:

1. Diperlukan 300 g Ayam (saya pake middle wing)
1. Jangan lupa 3 siung Bawang putih, geprek
1. Diperlukan 1 butir Bawang bombay, iris
1. Siapkan 1 sdm Margarin
1. Siapkan 6 sdm Saos inggris
1. Jangan lupa 3 sdm Kecap manis
1. Diperlukan secukupnya Garam, gula pasir, lada bubuk dan kaldu jamur




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Saos Inggris:

1. Bumbui ayam dengan garam dan lada bubuk, diamkan sebentar. Lalu goreng ayam hingga matang, angkat dan sisihkan.
1. Tumis bawang putih dan bombay dengan margarin hingga layu dan harum. Lalu masukkan ayam goreng, aduk rata.
1. Masukkan saos inggris, kecap manis, gula, garam, lada bubuk dan kaldu jamur, aduk rata dan jangan lupa tes rasa ya. Beri air sedikit bila perlu. Masak dengan api kecil hingga bumbu meresap ke ayam. Matikan api dan sajikan.




Demikianlah cara membuat ayam goreng saos inggris yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
