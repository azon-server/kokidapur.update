---
description: "Cara menyiapakan Ayam rica kemangi Luar biasa"
title: "Cara menyiapakan Ayam rica kemangi Luar biasa"
slug: 55-cara-menyiapakan-ayam-rica-kemangi-luar-biasa
date: 2021-01-17T21:47:39.462Z
image: https://img-global.cpcdn.com/recipes/ddb9acf88a0961fa/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ddb9acf88a0961fa/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ddb9acf88a0961fa/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Marie Allison
ratingvalue: 4
reviewcount: 32832
recipeingredient:
- "1/2 ekor ayam potong sesuai selera"
- "1 buah jeruk nipis"
- "1 buah tomat potongpotong"
- "Seruas jahe geprek"
- " Daun salam"
- " Daun jeruk"
- "Sebatang sereh"
- " Daun kunyit saya skip  gk ada stok"
- " Lengkuas geprek"
- "3 ikat daun kemangisaya suka banyak kemangi"
- "1 batang daun bawang"
- " Bumbu halussaya uleg sedikit kasar"
- "8 buah cabe rawit merah"
- "6 buah cabe merah"
- "6 butir bawang merah"
- "3 siung bawang putih"
- "3 butir kemiri sangrai"
- "sedikit Kunyit"
- "secukupnya Garam gula"
recipeinstructions:
- "Cuci bersih ayam dan lumuri dengan air perasan jeruk nipis dan garam, diamkan sebentar"
- "Goreng ayam setengah matang, sisihkan."
- "Tumis bumbu halus aduk masukkan daun jeruk, salam, sereh lengkuas jahe.tumis sampai harum dan matang"
- "Masukkan ayam aduk rata tambahkan sedikit air, masak dengan api kecil sampai bumbu meresap"
- "Masukkan gula garam,daun bawang, tomat,daun kemangi.aduk rata,tes rasa.angkat sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 168 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/ddb9acf88a0961fa/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas hingga enak. Ciri khas masakan Indonesia ayam rica kemangi yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga dapat didapat dengan cara mudah. Salah satunya adalah memasak Ayam rica kemangi untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis makanan yang bisa anda praktekkan salah satunya ayam rica kemangi yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi:

1. Harap siapkan 1/2 ekor ayam potong sesuai selera
1. Harus ada 1 buah jeruk nipis
1. Siapkan 1 buah tomat potong-potong
1. Harap siapkan Seruas jahe geprek
1. Siapkan  Daun salam
1. Dibutuhkan  Daun jeruk
1. Harus ada Sebatang sereh
1. Tambah  Daun kunyit (saya skip / gk ada stok)
1. Siapkan  Lengkuas geprek
1. Jangan lupa 3 ikat daun kemangi(saya suka banyak kemangi)
1. Tambah 1 batang daun bawang
1. Dibutuhkan  Bumbu halus(saya uleg sedikit kasar):
1. Siapkan 8 buah cabe rawit merah
1. Diperlukan 6 buah cabe merah
1. Jangan lupa 6 butir bawang merah
1. Harus ada 3 siung bawang putih
1. Harus ada 3 butir kemiri sangrai
1. Diperlukan sedikit Kunyit
1. Jangan lupa secukupnya Garam gula




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica kemangi:

1. Cuci bersih ayam dan lumuri dengan air perasan jeruk nipis dan garam, diamkan sebentar
1. Goreng ayam setengah matang, sisihkan.
1. Tumis bumbu halus aduk masukkan daun jeruk, salam, sereh lengkuas jahe.tumis sampai harum dan matang
1. Masukkan ayam aduk rata tambahkan sedikit air, masak dengan api kecil sampai bumbu meresap
1. Masukkan gula garam,daun bawang, tomat,daun kemangi.aduk rata,tes rasa.angkat sajikan




Demikianlah cara membuat ayam rica kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan terbukti, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
