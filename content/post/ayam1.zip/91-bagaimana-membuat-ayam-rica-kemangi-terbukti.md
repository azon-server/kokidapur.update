---
description: "Bagaimana membuat Ayam Rica Kemangi Terbukti"
title: "Bagaimana membuat Ayam Rica Kemangi Terbukti"
slug: 91-bagaimana-membuat-ayam-rica-kemangi-terbukti
date: 2020-10-01T14:54:06.136Z
image: https://img-global.cpcdn.com/recipes/ad37edc013c5307d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ad37edc013c5307d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ad37edc013c5307d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Beulah Mason
ratingvalue: 4.7
reviewcount: 4770
recipeingredient:
- "1/2 ekor ayam potong kecil kecil atau sesuai selera"
- " Bumbu halus "
- "4 siung bawang merah"
- "2 siung bawang putih sy pakai baceman bawang"
- " Sekitar 2 cm kunyit"
- " Sekitar 2 cm jahe"
- "2 buah kemiri"
- "5 Cabe kriting 2 cabe rawit"
- "Sejumput ketumbar"
- "1 sdt garam gula pasir penyedap dan lada bubuk"
- " Bahan pelengkap  lengkuas dan sereh geprekdaun salam kemangi"
- "1 gelas air matang"
recipeinstructions:
- "Cuci bersih ayam dan potong2 sesuai selera"
- "Tumis bumbu yang dihaluskan sampai wangi. Masukkan sereh, lengkuas, dan daun salam"
- "Masukkan ayam aduk2 rata sampai ayam berubah warna, tambahkan air 1 gelas belimbing boleh lebih, masak sampai air menyusut tambahkan daun kemangi, tes rasa."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 290 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/ad37edc013c5307d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica kemangi yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Nusantara

Keharmonisan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah memasak Ayam Rica Kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang bisa anda praktekkan salah satunya ayam rica kemangi yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 12 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Diperlukan 1/2 ekor ayam, potong kecil kecil atau sesuai selera
1. Harap siapkan  Bumbu halus :
1. Diperlukan 4 siung bawang merah
1. Dibutuhkan 2 siung bawang putih (sy pakai baceman bawang)
1. Diperlukan  Sekitar 2 cm kunyit
1. Diperlukan  Sekitar 2 cm jahe
1. Tambah 2 buah kemiri
1. Siapkan 5 Cabe kriting, 2 cabe rawit
1. Harap siapkan Sejumput ketumbar
1. Tambah 1 sdt garam, gula pasir, penyedap dan lada bubuk
1. Siapkan  Bahan pelengkap : lengkuas dan sereh geprek,daun salam, kemangi
1. Jangan lupa 1 gelas air matang




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Kemangi:

1. Cuci bersih ayam dan potong2 sesuai selera
1. Tumis bumbu yang dihaluskan sampai wangi. Masukkan sereh, lengkuas, dan daun salam
1. Masukkan ayam aduk2 rata sampai ayam berubah warna, tambahkan air 1 gelas belimbing boleh lebih, masak sampai air menyusut tambahkan daun kemangi, tes rasa.




Demikianlah cara membuat ayam rica kemangi yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
