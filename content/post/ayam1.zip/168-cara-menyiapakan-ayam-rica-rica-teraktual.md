---
description: "Cara menyiapakan Ayam Rica-Rica teraktual"
title: "Cara menyiapakan Ayam Rica-Rica teraktual"
slug: 168-cara-menyiapakan-ayam-rica-rica-teraktual
date: 2020-12-21T07:33:15.215Z
image: https://img-global.cpcdn.com/recipes/b4862b7ee93b4f8a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b4862b7ee93b4f8a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b4862b7ee93b4f8a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Adeline Stephens
ratingvalue: 4.5
reviewcount: 41580
recipeingredient:
- "1 ekor ayam dipotong 16cuci bersihlumuri 1sdt seasalt"
- "2 buah jeruk nipisambil airnya"
- "1 ruas jahe cuci bersihmemarkan"
- "1 ikat kemangisiangi cuci bersih"
- "25 lbr daun jeruk"
- "2 lbr daun pandan ikat"
- "2 lbr daun kunyit ikat"
- "5 batang seraimemarkan"
- "1 sdt kaldu ayam non msg"
- "500 ml air"
- " BUMBU"
- "150 gram cabe merah besarbuang bijinyacuci bersih"
- "10 buah cabe rawit merah"
- "35 buah bawang merah"
- "1 ruas kunyit bakar kupas"
- "5 batang serai ambil putihnyapotong"
- "1 sdt seasalt"
recipeinstructions:
- "Cuci bersih ayam, lumuri air jeruk nipis.Masukkan kulkas sementara itu ulek kunyit,seasalt, bawang merah, serai, cabe rawit dan cabe merah."
- "Panaskan minyak tumis bumbu ulek tadi,tambahkan serai,daun kunyit,daun pandan, daun jeruk, jahe.Aduk terus hingga harum lalu masukkan ayam.Aduk terus hingga ayam berubah warna lalu tambahkan kaldu ayam dan air.Masak dengan api sedang sambil sesekali diaduk hingga air tinggal sedikit,masukkan setengah bagian daun kemangi, aduk lalu matikan api.Cicipi rasanya.Tata di piring saji lalu taburi daun kemangi.Sajikan hangat."
- "Happy Cooking."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 249 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/b4862b7ee93b4f8a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau enak. Karasteristik masakan Indonesia ayam rica-rica yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan keluarga bisa didapat dengan cara simple. Salah satunya adalah memasak Ayam Rica-Rica untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang dapat anda praktekkan salah satunya ayam rica-rica yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica:

1. Tambah 1 ekor ayam dipotong 16,cuci bersih,lumuri 1sdt seasalt
1. Siapkan 2 buah jeruk nipis,ambil airnya
1. Jangan lupa 1 ruas jahe, cuci bersih,memarkan
1. Dibutuhkan 1 ikat kemangi,siangi, cuci bersih
1. Siapkan 25 lbr daun jeruk
1. Siapkan 2 lbr daun pandan, ikat
1. Harap siapkan 2 lbr daun kunyit, ikat
1. Siapkan 5 batang serai,memarkan
1. Diperlukan 1 sdt kaldu ayam non msg
1. Siapkan 500 ml air
1. Dibutuhkan  BUMBU:
1. Jangan lupa 150 gram cabe merah besar,buang bijinya,cuci bersih
1. Dibutuhkan 10 buah cabe rawit merah
1. Harus ada 35 buah bawang merah
1. Diperlukan 1 ruas kunyit, bakar, kupas
1. Jangan lupa 5 batang serai, ambil putihnya,potong&#34;
1. Jangan lupa 1 sdt seasalt




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica:

1. Cuci bersih ayam, lumuri air jeruk nipis.Masukkan kulkas sementara itu ulek kunyit,seasalt, bawang merah, serai, cabe rawit dan cabe merah.
1. Panaskan minyak tumis bumbu ulek tadi,tambahkan serai,daun kunyit,daun pandan, daun jeruk, jahe.Aduk terus hingga harum lalu masukkan ayam.Aduk terus hingga ayam berubah warna lalu tambahkan kaldu ayam dan air.Masak dengan api sedang sambil sesekali diaduk hingga air tinggal sedikit,masukkan setengah bagian daun kemangi, aduk lalu matikan api.Cicipi rasanya.Tata di piring saji lalu taburi daun kemangi.Sajikan hangat.
1. Happy Cooking.




Demikianlah cara membuat ayam rica-rica yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
