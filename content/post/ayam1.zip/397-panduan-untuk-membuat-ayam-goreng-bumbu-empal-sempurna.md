---
description: "Panduan untuk membuat Ayam Goreng Bumbu Empal Sempurna"
title: "Panduan untuk membuat Ayam Goreng Bumbu Empal Sempurna"
slug: 397-panduan-untuk-membuat-ayam-goreng-bumbu-empal-sempurna
date: 2020-09-12T02:25:30.443Z
image: https://img-global.cpcdn.com/recipes/ad6b06b0f0cc7faf/751x532cq70/ayam-goreng-bumbu-empal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ad6b06b0f0cc7faf/751x532cq70/ayam-goreng-bumbu-empal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ad6b06b0f0cc7faf/751x532cq70/ayam-goreng-bumbu-empal-foto-resep-utama.jpg
author: Margaret Strickland
ratingvalue: 4.3
reviewcount: 13691
recipeingredient:
- "8 potong paha ayam atas bawah"
- "1/2 buah jeruk nipis"
- "1 sdt garam"
- "125 ml air"
- " "
- "1 jempol lengkuas geprek"
- "1 keping (40 gram) gula merah"
- "125 ml air"
- "2 lembar daun salam"
- "2 sdt garam"
- "1 sdm air asam jawa"
- "2 sdm minyak untuk menumis"
- " Bumbu halus"
- "4 siung bawang merah"
- "3 siung bawang putih"
- "1 sdt ketumbar"
- " Minyak untuk menggoreng"
recipeinstructions:
- "Siapkan semua bahan dan bumbu. Ayam cuci bersih kucuri air jeruk nipis dan lumuri garam, cuci kembali, dan rebus, buang airnya. Blender bumbu halus kemudian tumis hingga harum"
- "Tambahkan lengkuas dan daun salam, masukkan ayam, aduk rata hingga berubah warna, tambahkan air, air asam jawa, gula dan garam, biarkan ungkep dengan api kecil dan airnya menyusut"
- "Panaskan minyak dan goreng ayam hingga kecoklatan"
- "Angkat tiriskan dan siap sajikan🙏"
categories:
- Recipe
tags:
- ayam
- goreng
- bumbu

katakunci: ayam goreng bumbu 
nutrition: 271 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Goreng Bumbu Empal](https://img-global.cpcdn.com/recipes/ad6b06b0f0cc7faf/751x532cq70/ayam-goreng-bumbu-empal-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam goreng bumbu empal yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Nusantara



Kehangatan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam Goreng Bumbu Empal untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang dapat anda coba salah satunya ayam goreng bumbu empal yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep ayam goreng bumbu empal tanpa harus bersusah payah.
Seperti resep Ayam Goreng Bumbu Empal yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Bumbu Empal:

1. Harap siapkan 8 potong paha ayam atas bawah
1. Tambah 1/2 buah jeruk nipis
1. Dibutuhkan 1 sdt garam
1. Tambah 125 ml air
1. Jangan lupa  ——————————————
1. Siapkan 1 jempol lengkuas geprek
1. Harap siapkan 1 keping (40 gram) gula merah
1. Diperlukan 125 ml air
1. Tambah 2 lembar daun salam
1. Harap siapkan 2 sdt garam
1. Siapkan 1 sdm air asam jawa
1. Dibutuhkan 2 sdm minyak untuk menumis
1. Dibutuhkan  Bumbu halus
1. Tambah 4 siung bawang merah
1. Dibutuhkan 3 siung bawang putih
1. Dibutuhkan 1 sdt ketumbar
1. Jangan lupa  Minyak untuk menggoreng




<!--inarticleads2-->

##### Langkah membuat  Ayam Goreng Bumbu Empal:

1. Siapkan semua bahan dan bumbu. Ayam cuci bersih kucuri air jeruk nipis dan lumuri garam, cuci kembali, dan rebus, buang airnya. Blender bumbu halus kemudian tumis hingga harum
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Goreng Bumbu Empal">1. Tambahkan lengkuas dan daun salam, masukkan ayam, aduk rata hingga berubah warna, tambahkan air, air asam jawa, gula dan garam, biarkan ungkep dengan api kecil dan airnya menyusut
1. Panaskan minyak dan goreng ayam hingga kecoklatan
1. Angkat tiriskan dan siap sajikan🙏




Demikianlah cara membuat ayam goreng bumbu empal yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan cepat, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
