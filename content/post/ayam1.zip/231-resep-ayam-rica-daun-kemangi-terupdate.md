---
description: "Resep : Ayam rica² daun kemangi terupdate"
title: "Resep : Ayam rica² daun kemangi terupdate"
slug: 231-resep-ayam-rica-daun-kemangi-terupdate
date: 2021-01-04T22:51:08.924Z
image: https://img-global.cpcdn.com/recipes/80ce77a882171fd3/751x532cq70/ayam-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/80ce77a882171fd3/751x532cq70/ayam-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/80ce77a882171fd3/751x532cq70/ayam-rica-daun-kemangi-foto-resep-utama.jpg
author: Bryan Griffith
ratingvalue: 4.7
reviewcount: 7285
recipeingredient:
- "1 ekor ayam potong 10"
- " Bumbu ungkep "
- "1 ruas jari kunyit"
- "1 ruas jari jahe"
- "3 buat kemiri"
- "3 buah bawang merah"
- "3 buah bawang putih"
- "2 lbr sereh geprek"
- "1 buah lengkuas geprek"
- "3 buah daun salam"
- "2 buah daun jeruk sobek"
- " Bumbu halus "
- "10 buah cabe merah keriting"
- "2 buah cabe merah besar"
- "5 buah cabe rawit merah"
- "1 buah tomat"
- "3 buah bawang merah"
- "3 buah bawang putih"
- "secukupnya Garam"
- "secukupnya Gula putih"
- "3 ikat daun kemangi lebih banyak lebih nikmat"
recipeinstructions:
- "Cuci ayam hingga bersih, rebus ayam dgn bumbu ungkep. Matikan api jika sudah empuk dan air tiris."
- "Panaskan minyak goreng, tumis bumbu yang sudah dihaluskan hingga harum, tambahkan gula putih dan air sedikit lalu masukkan ayam yang sudah diungkep tadi, aduk² supaya bumbu meresap dan merata."
- "Jika air sudah tiris, tambahkan daun kemangi sambil diaduk hingga merata."
- "Koreksi rasa, matikan api. Angkat dan sajikan👌"
categories:
- Recipe
tags:
- ayam
- rica
- daun

katakunci: ayam rica daun 
nutrition: 262 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam rica² daun kemangi](https://img-global.cpcdn.com/recipes/80ce77a882171fd3/751x532cq70/ayam-rica-daun-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan empuk. Ciri masakan Nusantara ayam rica² daun kemangi yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah memasak Ayam rica² daun kemangi untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang bisa anda praktekkan salah satunya ayam rica² daun kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep ayam rica² daun kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica² daun kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica² daun kemangi:

1. Tambah 1 ekor ayam (potong 10)
1. Harap siapkan  Bumbu ungkep :
1. Harap siapkan 1 ruas jari kunyit
1. Diperlukan 1 ruas jari jahe
1. Harap siapkan 3 buat kemiri
1. Siapkan 3 buah bawang merah
1. Diperlukan 3 buah bawang putih
1. Siapkan 2 lbr sereh (geprek)
1. Siapkan 1 buah lengkuas (geprek)
1. Harap siapkan 3 buah daun salam
1. Harus ada 2 buah daun jeruk (sobek²)
1. Diperlukan  Bumbu halus :
1. Harap siapkan 10 buah cabe merah keriting
1. Siapkan 2 buah cabe merah besar
1. Harap siapkan 5 buah cabe rawit merah
1. Dibutuhkan 1 buah tomat
1. Harap siapkan 3 buah bawang merah
1. Tambah 3 buah bawang putih
1. Jangan lupa secukupnya Garam
1. Dibutuhkan secukupnya Gula putih
1. Harus ada 3 ikat daun kemangi (lebih banyak lebih nikmat)




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica² daun kemangi:

1. Cuci ayam hingga bersih, rebus ayam dgn bumbu ungkep. Matikan api jika sudah empuk dan air tiris.
1. Panaskan minyak goreng, tumis bumbu yang sudah dihaluskan hingga harum, tambahkan gula putih dan air sedikit lalu masukkan ayam yang sudah diungkep tadi, aduk² supaya bumbu meresap dan merata.
1. Jika air sudah tiris, tambahkan daun kemangi sambil diaduk hingga merata.
1. Koreksi rasa, matikan api. Angkat dan sajikan👌




Demikianlah cara membuat ayam rica² daun kemangi yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan teruji, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
