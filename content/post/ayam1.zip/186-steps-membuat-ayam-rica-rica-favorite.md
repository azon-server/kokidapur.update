---
description: "Steps membuat Ayam Rica-Rica Favorite"
title: "Steps membuat Ayam Rica-Rica Favorite"
slug: 186-steps-membuat-ayam-rica-rica-favorite
date: 2020-12-13T17:00:04.980Z
image: https://img-global.cpcdn.com/recipes/56638a2867f22637/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/56638a2867f22637/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/56638a2867f22637/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Tommy McKenzie
ratingvalue: 4.9
reviewcount: 46882
recipeingredient:
- " Bumbu marinasi"
- "1/2 ekor ayam"
- "1 buah jeruk nipis"
- "1/2 sdt lada bubuk"
- " Bumbu tumis"
- "Secukupnya minyak"
- "5 lembar daun jeruk"
- "1 batang sereh lagi gak ada"
- "1 ruas lengkuas geprek"
- "1/2 sdm garam"
- "1 sdm gula"
- "1 sdt lada bubuk"
- "1 sdt kaldu jamur"
- "2 buah tomat hijau"
- " Bumbu halus 1"
- "20 cabe rawit"
- "5 buah cabe hijau"
- " Bumbu halus 2"
- "2 ruas kunyit"
- "1 ruas jahe"
- "5 siung bawang merah"
- "3 siung bawang putih"
recipeinstructions:
- "Cuci bersih ayam lalu beri perasan jeruk nipis dan lada bubuk, tunggu sampai sekitar 10 menit lalu goreng, sisihkan."
- "Blender bumbu halus 1, sisihkan. Blender bumbu halus 2, sisihkan"
- "Tuang minyak secukupnya, masukkan bumbu halus 2, daun jeruk dan lengkuas, tumis hingga harum"
- "Masukkan bumbu halus 1 lalu masukkan ayam yg sudah d goreng, beri air sedikit, aduk-aduk lalu tambahkan garam, gula, lada bubuk dan kaldu jamur. Jangan lupa tes rasa"
- "Terakhir masukkan tomat hijau yg telah dipotong-potong. Sajikan"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 119 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/56638a2867f22637/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau renyah. Karasteristik makanan Indonesia ayam rica-rica yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan rumah tangga bisa didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica-Rica untuk keluarga. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis makanan yang bisa anda praktekkan salah satunya ayam rica-rica yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 22 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica:

1. Harus ada  Bumbu marinasi
1. Siapkan 1/2 ekor ayam
1. Siapkan 1 buah jeruk nipis
1. Tambah 1/2 sdt lada bubuk
1. Tambah  Bumbu tumis
1. Dibutuhkan Secukupnya minyak
1. Dibutuhkan 5 lembar daun jeruk
1. Harus ada 1 batang sereh (lagi gak ada)
1. Siapkan 1 ruas lengkuas geprek
1. Siapkan 1/2 sdm garam
1. Tambah 1 sdm gula
1. Harus ada 1 sdt lada bubuk
1. Jangan lupa 1 sdt kaldu jamur
1. Diperlukan 2 buah tomat hijau
1. Siapkan  Bumbu halus 1
1. Dibutuhkan 20 cabe rawit
1. Siapkan 5 buah cabe hijau
1. Tambah  Bumbu halus 2
1. Diperlukan 2 ruas kunyit
1. Tambah 1 ruas jahe
1. Harap siapkan 5 siung bawang merah
1. Tambah 3 siung bawang putih




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica:

1. Cuci bersih ayam lalu beri perasan jeruk nipis dan lada bubuk, tunggu sampai sekitar 10 menit lalu goreng, sisihkan.
1. Blender bumbu halus 1, sisihkan. Blender bumbu halus 2, sisihkan
1. Tuang minyak secukupnya, masukkan bumbu halus 2, daun jeruk dan lengkuas, tumis hingga harum
1. Masukkan bumbu halus 1 lalu masukkan ayam yg sudah d goreng, beri air sedikit, aduk-aduk lalu tambahkan garam, gula, lada bubuk dan kaldu jamur. Jangan lupa tes rasa
1. Terakhir masukkan tomat hijau yg telah dipotong-potong. Sajikan




Demikianlah cara membuat ayam rica-rica yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan terbukti, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
