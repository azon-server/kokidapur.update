---
description: "Resep : Ayam Goreng Daun Jeruk teraktual"
title: "Resep : Ayam Goreng Daun Jeruk teraktual"
slug: 365-resep-ayam-goreng-daun-jeruk-teraktual
date: 2020-08-29T03:47:57.943Z
image: https://img-global.cpcdn.com/recipes/55e3f0f13952c2f5/751x532cq70/ayam-goreng-daun-jeruk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/55e3f0f13952c2f5/751x532cq70/ayam-goreng-daun-jeruk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/55e3f0f13952c2f5/751x532cq70/ayam-goreng-daun-jeruk-foto-resep-utama.jpg
author: Brent Santos
ratingvalue: 4.7
reviewcount: 34579
recipeingredient:
- "1 ekor Ayam Broiler 12kg"
- "800 ml Air"
- "secukupnya Garam"
- "secukupnya Kaldu ayam bubuk"
- " Bumbu halus "
- "10 siung bawang putih"
- "10 butir Kemiri"
- "2 ruas kunyit"
- "1 sdm ketumbar biji"
- "5 lembar daun Jeruk"
- " Bumbu rempah "
- "2 batang serai"
- "1 ruas lengkuas"
- "1 ruas Jahe"
recipeinstructions:
- "Potong ayam sesuai selera, sisihkan. Siapkan bumbu halus dan bumbu rempah, sisihkan."
- "Campur air, garam dan bumbu halus. Masak hingga mendidih, masukkan ayam potong dan bumbu rempah. Masak hingga ayam matang dan air menyusut. Masak dengan api kecil agar bumbu meresap dan daging empuk."
- "Pindahkan kedalam wadah tertutup dan simpan kedalam kulkas jika ayam sudah dingin. (Siap digoreng besok, dan bisa juga langsung digoreng)"
- "Goreng hingga kecoklatan, angkat dan tiriskan. Ayam goreng siap disajikan"
categories:
- Recipe
tags:
- ayam
- goreng
- daun

katakunci: ayam goreng daun 
nutrition: 263 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Goreng Daun Jeruk](https://img-global.cpcdn.com/recipes/55e3f0f13952c2f5/751x532cq70/ayam-goreng-daun-jeruk-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang harus kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam goreng daun jeruk yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Nusantara



Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Ayam Goreng Daun Jeruk untuk orang di rumah. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang bisa anda praktekkan salah satunya ayam goreng daun jeruk yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep ayam goreng daun jeruk tanpa harus bersusah payah.
Berikut ini resep Ayam Goreng Daun Jeruk yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 14 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Daun Jeruk:

1. Diperlukan 1 ekor Ayam Broiler (1.2kg)
1. Jangan lupa 800 ml Air
1. Siapkan secukupnya Garam
1. Dibutuhkan secukupnya Kaldu ayam bubuk
1. Tambah  Bumbu halus :
1. Tambah 10 siung bawang putih
1. Jangan lupa 10 butir Kemiri
1. Jangan lupa 2 ruas kunyit
1. Dibutuhkan 1 sdm ketumbar biji
1. Harap siapkan 5 lembar daun Jeruk
1. Diperlukan  Bumbu rempah :
1. Tambah 2 batang serai
1. Harap siapkan 1 ruas lengkuas
1. Diperlukan 1 ruas Jahe




<!--inarticleads2-->

##### Cara membuat  Ayam Goreng Daun Jeruk:

1. Potong ayam sesuai selera, sisihkan. Siapkan bumbu halus dan bumbu rempah, sisihkan.
1. Campur air, garam dan bumbu halus. Masak hingga mendidih, masukkan ayam potong dan bumbu rempah. Masak hingga ayam matang dan air menyusut. Masak dengan api kecil agar bumbu meresap dan daging empuk.
1. Pindahkan kedalam wadah tertutup dan simpan kedalam kulkas jika ayam sudah dingin. (Siap digoreng besok, dan bisa juga langsung digoreng)
1. Goreng hingga kecoklatan, angkat dan tiriskan. Ayam goreng siap disajikan




Demikianlah cara membuat ayam goreng daun jeruk yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan teruji, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
