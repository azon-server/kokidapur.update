---
description: "Panduan untuk menyiapakan Ayam goreng tepung asam manis Homemade"
title: "Panduan untuk menyiapakan Ayam goreng tepung asam manis Homemade"
slug: 279-panduan-untuk-menyiapakan-ayam-goreng-tepung-asam-manis-homemade
date: 2020-09-04T12:57:44.988Z
image: https://img-global.cpcdn.com/recipes/dc275749034bfdce/751x532cq70/ayam-goreng-tepung-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dc275749034bfdce/751x532cq70/ayam-goreng-tepung-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dc275749034bfdce/751x532cq70/ayam-goreng-tepung-asam-manis-foto-resep-utama.jpg
author: Devin Blair
ratingvalue: 4.9
reviewcount: 28580
recipeingredient:
- "438 gr dada ayam boneless kurang lebih ya berat dada ayamnya krn tergantung dapatnya"
- "1 buah wortel iris korek api"
- "1 buah ketimun buang biji dan iris korek api"
- "1/4 buah nanas iris korek api aku pakai nanas honi"
- "5 cabe rawit merah iris tipis bsa diganti paprikacabe merah besar"
- " Bahan marinasi ayam haluskan"
- "3 siung bawang putih"
- "1/4 sdt merica"
- "1/4 sdt garam"
- " Bahan tepung"
- "12 sdm tepung terigu"
- "3 sdm tepung tapioka"
- "1 sdt kaldu jamur"
- "1/4 sdt merica bubuk"
- "1/2 sdt garam"
- " Bahan saus asam manis"
- "5 sdm saus tomat"
- "4 sdm saus sambal bsa dikurangi klo tdk suka pedas"
- "1 sdm saus tiram"
- "1.5 sdm gula pasir"
- "Sejumput garam"
- "1/4 sdt kaldu jamur"
- " Bahan tumis"
- "4 siung bawang putih cincang kasar"
- "1 siung bawang bombay iris memanjang"
- "2 sdm minyak sayur"
- "200-300 ml air"
- "1/2 sdt tepung maizena larutkan"
recipeinstructions:
- "Cuci bersih dada ayam beri perasa jeruk nipis diamkan 10 min lalu cuci bersih lg tiriskan. Kemudian iris ayam sesuai selera kalau aku agak tipis, lalu marinasi ayam dgn bumbu marinasi taruh di chiller dan diamkan selama 30 menit"
- "Campur semua bahan tepung jd satu (tepung kering) lalu pisahkan 3 sdm di wadah terpisah untuk tepung basahnya. Ambil ayam marinasi dan masukkan 3 sdm bumbu basah td ke dalam ayam marinasi dan aduk smp tercampur rata, setelah tercampur rata masukkan ayam ke dalam tepung kering, campur smp semua ayam dibaluri tepung (kadang suka ada irisan ayam yg nempel), sisihkan"
- "Panaskan minyak lalu goreng ayam yg sdh dibaluri tepung td (api sedang), minyaknya agak banyak ya biar matangnya rata. Kalau aku gorengnya dibagi 2, stlh matang tiriskan ayam, sisihkan. Tips. Kalau goreng 2x jgn lupa minyak gorengan yg pertama disaring dlu biar remahan dan sisa tepungnya bersih jd gorengan selanjutnya warnanya bagus &amp; rata"
- "Untuk tumisan, panaskan 2 sdm minyak sayur dan tumis bawang putih &amp; bawang bombay stlh harum beri air, masukkan wortel masak smp wortel 1/2 matang lalu masukkan cabai rawit iris &amp; semua bahan saus asam manis lalu aduk smp rata, masukkan nanas &amp; timun aduk dan cek rasa jika sdh pas rasanya matikan kompor"
- "Ambil ayam tepung yg sdh ditiriskan td lalu masukkan ke dalam saus asam manis, aduk smp tercampur rata (kalau aku tgu si saus asam manis suhunya turun stlh hangat baru aku masukkan ayam tepung biar pas dimakan ayamnya msh krenyes-krenyes)"
- "Ayam goreng tepung asam manis siap disantap bersama nasi hangat 🤤"
categories:
- Recipe
tags:
- ayam
- goreng
- tepung

katakunci: ayam goreng tepung 
nutrition: 175 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT52M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam goreng tepung asam manis](https://img-global.cpcdn.com/recipes/dc275749034bfdce/751x532cq70/ayam-goreng-tepung-asam-manis-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau enak. Ciri khas makanan Nusantara ayam goreng tepung asam manis yang kaya dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam goreng tepung asam manis untuk keluarga. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang dapat anda buat salah satunya ayam goreng tepung asam manis yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep ayam goreng tepung asam manis tanpa harus bersusah payah.
Seperti resep Ayam goreng tepung asam manis yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 28 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam goreng tepung asam manis:

1. Jangan lupa 438 gr dada ayam boneless (kurang lebih ya berat dada ayamnya krn tergantung dapatnya)
1. Jangan lupa 1 buah wortel iris korek api
1. Harap siapkan 1 buah ketimun buang biji dan iris korek api
1. Dibutuhkan 1/4 buah nanas iris korek api (aku pakai nanas honi)
1. Dibutuhkan 5 cabe rawit merah iris tipis (bsa diganti paprika/cabe merah besar)
1. Dibutuhkan  Bahan marinasi ayam (haluskan)
1. Harus ada 3 siung bawang putih
1. Siapkan 1/4 sdt merica
1. Diperlukan 1/4 sdt garam
1. Harus ada  Bahan tepung
1. Tambah 12 sdm tepung terigu
1. Diperlukan 3 sdm tepung tapioka
1. Dibutuhkan 1 sdt kaldu jamur
1. Harus ada 1/4 sdt merica bubuk
1. Dibutuhkan 1/2 sdt garam
1. Tambah  Bahan saus asam manis
1. Diperlukan 5 sdm saus tomat
1. Jangan lupa 4 sdm saus sambal (bsa dikurangi klo tdk suka pedas)
1. Harap siapkan 1 sdm saus tiram
1. Jangan lupa 1.5 sdm gula pasir
1. Siapkan Sejumput garam
1. Harus ada 1/4 sdt kaldu jamur
1. Diperlukan  Bahan tumis
1. Jangan lupa 4 siung bawang putih (cincang kasar)
1. Harus ada 1 siung bawang bombay (iris memanjang)
1. Harap siapkan 2 sdm minyak sayur
1. Jangan lupa 200-300 ml air
1. Siapkan 1/2 sdt tepung maizena (larutkan)




<!--inarticleads2-->

##### Langkah membuat  Ayam goreng tepung asam manis:

1. Cuci bersih dada ayam beri perasa jeruk nipis diamkan 10 min lalu cuci bersih lg tiriskan. Kemudian iris ayam sesuai selera kalau aku agak tipis, lalu marinasi ayam dgn bumbu marinasi taruh di chiller dan diamkan selama 30 menit
1. Campur semua bahan tepung jd satu (tepung kering) lalu pisahkan 3 sdm di wadah terpisah untuk tepung basahnya. Ambil ayam marinasi dan masukkan 3 sdm bumbu basah td ke dalam ayam marinasi dan aduk smp tercampur rata, setelah tercampur rata masukkan ayam ke dalam tepung kering, campur smp semua ayam dibaluri tepung (kadang suka ada irisan ayam yg nempel), sisihkan
1. Panaskan minyak lalu goreng ayam yg sdh dibaluri tepung td (api sedang), minyaknya agak banyak ya biar matangnya rata. Kalau aku gorengnya dibagi 2, stlh matang tiriskan ayam, sisihkan. Tips. Kalau goreng 2x jgn lupa minyak gorengan yg pertama disaring dlu biar remahan dan sisa tepungnya bersih jd gorengan selanjutnya warnanya bagus &amp; rata
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam goreng tepung asam manis">1. Untuk tumisan, panaskan 2 sdm minyak sayur dan tumis bawang putih &amp; bawang bombay stlh harum beri air, masukkan wortel masak smp wortel 1/2 matang lalu masukkan cabai rawit iris &amp; semua bahan saus asam manis lalu aduk smp rata, masukkan nanas &amp; timun aduk dan cek rasa jika sdh pas rasanya matikan kompor
1. Ambil ayam tepung yg sdh ditiriskan td lalu masukkan ke dalam saus asam manis, aduk smp tercampur rata (kalau aku tgu si saus asam manis suhunya turun stlh hangat baru aku masukkan ayam tepung biar pas dimakan ayamnya msh krenyes-krenyes)
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam goreng tepung asam manis">1. Ayam goreng tepung asam manis siap disantap bersama nasi hangat 🤤




Demikianlah cara membuat ayam goreng tepung asam manis yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan teruji, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
