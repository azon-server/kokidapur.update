---
description: "Resep : Ayam Goreng Lengkuas teraktual"
title: "Resep : Ayam Goreng Lengkuas teraktual"
slug: 467-resep-ayam-goreng-lengkuas-teraktual
date: 2020-11-24T10:34:53.028Z
image: https://img-global.cpcdn.com/recipes/dca192a2f7da0d73/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dca192a2f7da0d73/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dca192a2f7da0d73/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Myrtle Fuller
ratingvalue: 5
reviewcount: 37057
recipeingredient:
- "500 gr ayam"
- "2 genggam tangan lengkuas parut"
- "1.5 sdt garam"
- "1.5 sdt gula"
- "1 sdt kaldu bubuk non msg"
- "2 daun salam"
- "2 batang sereh geprek"
- " Bumbu halus "
- "6 bawang merah"
- "4 bawang putih"
- "2 kemiri sangrai dl"
- "1 ruas kunyit"
- "1/2 ruas jahe"
- "1/2 sdm ketumbar bubuk"
recipeinstructions:
- "Parut lengkuas muda kurleb 2 genggam tangan"
- "Blender bumbu halus"
- "Masukkan bumbu halus, daun salam, sereh, gulgar, kaldu. Tumis hingga wangi, tambahkan air"
- "Masukkan ayam, tutup wajan smp air menyusut. Tiriskan ayam dan bumbunya (dipisah)"
- "Goreng ayam hingga kecoklatan"
- "Goreng bumbu yg tersisa dgn minyak bekas goreng ayam. Saring dan tiriskan"
- "Tabur bumbu diatas ayam. Ayam ungkep siap dihidangkan bersama nasi hangat dan sambal😍"
categories:
- Recipe
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 177 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Goreng Lengkuas](https://img-global.cpcdn.com/recipes/dca192a2f7da0d73/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau gurih. Ciri khas makanan Indonesia ayam goreng lengkuas yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Goreng Lengkuas untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang bisa anda contoh salah satunya ayam goreng lengkuas yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep ayam goreng lengkuas tanpa harus bersusah payah.
Seperti resep Ayam Goreng Lengkuas yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 14 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Lengkuas:

1. Harap siapkan 500 gr ayam
1. Harap siapkan 2 genggam tangan lengkuas parut
1. Harap siapkan 1.5 sdt garam
1. Harus ada 1.5 sdt gula
1. Harus ada 1 sdt kaldu bubuk non msg
1. Harus ada 2 daun salam
1. Diperlukan 2 batang sereh geprek
1. Tambah  Bumbu halus :
1. Harap siapkan 6 bawang merah
1. Harap siapkan 4 bawang putih
1. Harus ada 2 kemiri (sangrai dl)
1. Dibutuhkan 1 ruas kunyit
1. Dibutuhkan 1/2 ruas jahe
1. Tambah 1/2 sdm ketumbar bubuk




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Lengkuas:

1. Parut lengkuas muda kurleb 2 genggam tangan
1. Blender bumbu halus
1. Masukkan bumbu halus, daun salam, sereh, gulgar, kaldu. Tumis hingga wangi, tambahkan air
1. Masukkan ayam, tutup wajan smp air menyusut. Tiriskan ayam dan bumbunya (dipisah)
1. Goreng ayam hingga kecoklatan
1. Goreng bumbu yg tersisa dgn minyak bekas goreng ayam. Saring dan tiriskan
1. Tabur bumbu diatas ayam. Ayam ungkep siap dihidangkan bersama nasi hangat dan sambal😍




Demikianlah cara membuat ayam goreng lengkuas yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
