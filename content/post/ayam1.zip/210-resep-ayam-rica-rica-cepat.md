---
description: "Resep : Ayam rica-rica Cepat"
title: "Resep : Ayam rica-rica Cepat"
slug: 210-resep-ayam-rica-rica-cepat
date: 2020-09-04T20:23:19.871Z
image: https://img-global.cpcdn.com/recipes/b52bca4cf69ab450/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b52bca4cf69ab450/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b52bca4cf69ab450/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Connor Cummings
ratingvalue: 4.9
reviewcount: 5298
recipeingredient:
- "1 ekor ayam potong sesuai selera jangan terlalu besar"
- "1 jeruk nipis"
- "3 ikat daun kemangi"
- " Daun bawang"
- "1 buah bawang bombay"
- " Daun salam daun jeruk"
- "2 batang sereh memarkan"
- "1 ruas lengkuas"
- " Garam gula merica penyedap rasa"
- "1 sdm saus sambal optional"
- " Bumbu halus"
- "10 siung bawah merah"
- "3 siung bawah putih"
- "1 ruas jahe"
- "1 ruas kunyit bakar sebentar"
- "1 tomat ukuran sedang"
- "2 butir kemiri"
- "sesuai selera Cabe keriting"
recipeinstructions:
- "Bersihkan ayam, beri perasan jeruk diamkan sejenak, kemudian cuci bersih. Siapkan bumbu halus"
- "Tumis bumbu halus bersama bumbu dapur sampai harum. Kemudian masukan ayam, beri gula, garam, merica. Beri air secukupnya. Bisa ditambah saus cabe jika mau. Aduk rata.Tunggu hingga air tersisa sedikit. Matikan api."
- "Jika ingin hasil yang maksimal, biasanya saya akan biarkan terlebih dahulu agar bumbu meresap. Jika saya masak pagi, saya akan hidangkan malam hari. Jika saya masak malam, saya akan hidangkan untuk pagi hari."
- "Setelah bumbu meresap, masak kembali, beri minyak goreng secukupnya, dan masukan irisan bawang bombay. Aduk rata. Koreksi rasa."
- "Setelah bawang bombay layu, masukan daun kemangi dan daun bawang. Aduk sebentar, matikan api. Hidangkan dengan nasi panas."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 284 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica-rica](https://img-global.cpcdn.com/recipes/b52bca4cf69ab450/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang setidaknya kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica-rica yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Kita

Kehangatan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah membuat makanan Ayam rica-rica untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda praktekkan salah satunya ayam rica-rica yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica:

1. Tambah 1 ekor ayam potong sesuai selera (jangan terlalu besar)
1. Tambah 1 jeruk nipis
1. Harap siapkan 3 ikat daun kemangi
1. Harus ada  Daun bawang
1. Tambah 1 buah bawang bombay
1. Harap siapkan  Daun salam, daun jeruk
1. Diperlukan 2 batang sereh, memarkan
1. Diperlukan 1 ruas lengkuas
1. Harap siapkan  Garam, gula, merica, penyedap rasa
1. Tambah 1 sdm saus sambal (optional)
1. Siapkan  Bumbu halus
1. Jangan lupa 10 siung bawah merah
1. Diperlukan 3 siung bawah putih
1. Siapkan 1 ruas jahe
1. Dibutuhkan 1 ruas kunyit, bakar sebentar
1. Harap siapkan 1 tomat ukuran sedang
1. Tambah 2 butir kemiri
1. Jangan lupa sesuai selera Cabe keriting




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica-rica:

1. Bersihkan ayam, beri perasan jeruk diamkan sejenak, kemudian cuci bersih. Siapkan bumbu halus
1. Tumis bumbu halus bersama bumbu dapur sampai harum. Kemudian masukan ayam, beri gula, garam, merica. Beri air secukupnya. Bisa ditambah saus cabe jika mau. Aduk rata.Tunggu hingga air tersisa sedikit. Matikan api.
1. Jika ingin hasil yang maksimal, biasanya saya akan biarkan terlebih dahulu agar bumbu meresap. Jika saya masak pagi, saya akan hidangkan malam hari. Jika saya masak malam, saya akan hidangkan untuk pagi hari.
1. Setelah bumbu meresap, masak kembali, beri minyak goreng secukupnya, dan masukan irisan bawang bombay. Aduk rata. Koreksi rasa.
1. Setelah bawang bombay layu, masukan daun kemangi dan daun bawang. Aduk sebentar, matikan api. Hidangkan dengan nasi panas.




Demikianlah cara membuat ayam rica-rica yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan terbukti, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
