---
description: "Steps untuk membuat Indonesia Spicy Chicken (ayam rica rica Jokja) Cepat"
title: "Steps untuk membuat Indonesia Spicy Chicken (ayam rica rica Jokja) Cepat"
slug: 99-steps-untuk-membuat-indonesia-spicy-chicken-ayam-rica-rica-jokja-cepat
date: 2020-11-18T17:57:53.695Z
image: https://img-global.cpcdn.com/recipes/04d8e0d6e888aa95/751x532cq70/indonesia-spicy-chicken-ayam-rica-rica-jokja-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/04d8e0d6e888aa95/751x532cq70/indonesia-spicy-chicken-ayam-rica-rica-jokja-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/04d8e0d6e888aa95/751x532cq70/indonesia-spicy-chicken-ayam-rica-rica-jokja-foto-resep-utama.jpg
author: Ora Becker
ratingvalue: 4.6
reviewcount: 31841
recipeingredient:
- "3/4 kilos chicken me  chicken wing cut in two pieces"
- " White cabbage optional"
- " Tomato optional"
- " Sweet soy sauce"
- "500 ml water"
- " Spice paste"
- "10 cloves garlic crushed"
- "1/3 UK Union"
- "1/2 tsp ground corriender"
- "1 tsp table salt"
- "1/2 ground white pepper"
- "1/2 tsp ground tumeric"
- "5 kemiri nutsroaster"
- "1 tbsp palm sugar sliced"
- "10 red birds eye chili"
- "1 tbsp cooking oil"
recipeinstructions:
- "Put altogether the sauce ingredients in mortal and pestle until smoth"
- "Heat 1 tbsp cooking oil in a wok over medium heat and saute the spice paste until fragrant"
- "Add chicken wings, water and bring to boil and cover with lid."
- "Add sweet soy sauce and simmer for about 40-60 mins until chicken wings are cooked and spice sauce thickened"
- "You can add vegetables : white cabbage and tomato"
- "Dish out and serve immediately whilst hot."
categories:
- Recipe
tags:
- indonesia
- spicy
- chicken

katakunci: indonesia spicy chicken 
nutrition: 245 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT53M"
recipeyield: "4"
recipecategory: Lunch

---


![Indonesia Spicy Chicken (ayam rica rica Jokja)](https://img-global.cpcdn.com/recipes/04d8e0d6e888aa95/751x532cq70/indonesia-spicy-chicken-ayam-rica-rica-jokja-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau renyah. Ciri khas makanan Indonesia indonesia spicy chicken (ayam rica rica jokja) yang kaya dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Indonesia Spicy Chicken (ayam rica rica Jokja) untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang bisa anda contoh salah satunya indonesia spicy chicken (ayam rica rica jokja) yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep indonesia spicy chicken (ayam rica rica jokja) tanpa harus bersusah payah.
Seperti resep Indonesia Spicy Chicken (ayam rica rica Jokja) yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Indonesia Spicy Chicken (ayam rica rica Jokja):

1. Dibutuhkan 3/4 kilos chicken (me : chicken wing, cut in two pieces)
1. Jangan lupa  White cabbage (optional)
1. Dibutuhkan  Tomato (optional)
1. Harus ada  Sweet soy sauce
1. Harap siapkan 500 ml water
1. Siapkan  Spice paste
1. Dibutuhkan 10 cloves garlic, crushed
1. Tambah 1/3 UK Union
1. Dibutuhkan 1/2 tsp ground corriender
1. Jangan lupa 1 tsp table salt
1. Harus ada 1/2 ground white pepper
1. Tambah 1/2 tsp ground tumeric
1. Harap siapkan 5 kemiri nuts,roaster
1. Dibutuhkan 1 tbsp palm sugar, sliced
1. Tambah 10 red bird&#39;s eye chili
1. Harus ada 1 tbsp cooking oil




<!--inarticleads2-->

##### Cara membuat  Indonesia Spicy Chicken (ayam rica rica Jokja):

1. Put altogether the sauce ingredients in mortal and pestle until smoth
1. Heat 1 tbsp cooking oil in a wok over medium heat and saute the spice paste until fragrant
1. Add chicken wings, water and bring to boil and cover with lid.
1. Add sweet soy sauce and simmer for about 40-60 mins until chicken wings are cooked and spice sauce thickened
1. You can add vegetables : white cabbage and tomato
1. Dish out and serve immediately whilst hot.




Demikianlah cara membuat indonesia spicy chicken (ayam rica rica jokja) yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
