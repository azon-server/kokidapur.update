---
description: "Resep : Ayam rica rica Favorite"
title: "Resep : Ayam rica rica Favorite"
slug: 100-resep-ayam-rica-rica-favorite
date: 2020-09-08T12:57:12.645Z
image: https://img-global.cpcdn.com/recipes/65a26600abb1556e/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/65a26600abb1556e/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/65a26600abb1556e/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Marion Kelly
ratingvalue: 4.5
reviewcount: 11006
recipeingredient:
- "500 gr ayambagian paha atas"
- "Segenggam kemangi"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "7 buah cabe keriting"
- "4 buah rawit"
- "1 cm kunyit"
- "2 cm jahe geprek"
- "1 buah sereh geprek"
- "200 m air"
- "sesuai selera Gula dan garam"
recipeinstructions:
- "Bersihkan ayam..pilih bagian paha atas krna lebih lembut dan mudah menyerap bumbu"
- "Haluskan semua bumbu kecuali jahe dan sereh"
- "Tumis bumbu halus Tips : sebelum menumis ketika minyak panas, masukan terlebih dahulu jahe dan sereh agar minyak menyerap aroma nya"
- "Setelah jumbu matang dan beraroma masukan ayam.. aduk sampe bumbu merata.."
- "Setelah bumbu merata, masukan air masak hingga ayam matang dan air menyusut Tips : tutup wajan agar lebih cepat"
- "Setelah air susut, masukan kemangi matikan api.. aduk rata.. Done ^^"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 114 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica rica](https://img-global.cpcdn.com/recipes/65a26600abb1556e/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis atau empuk. Karasteristik kuliner Indonesia ayam rica rica yang penuh dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan keluarga bisa didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam rica rica untuk keluarga. Momen makan bersama orang tua sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang dapat anda contoh salah satunya ayam rica rica yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam rica rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica:

1. Diperlukan 500 gr ayam,bagian paha atas
1. Siapkan Segenggam kemangi
1. Tambah 6 siung bawang merah
1. Harus ada 3 siung bawang putih
1. Harap siapkan 7 buah cabe keriting
1. Harus ada 4 buah rawit
1. Jangan lupa 1 cm kunyit
1. Harap siapkan 2 cm jahe geprek
1. Harap siapkan 1 buah sereh geprek
1. Tambah 200 m air
1. Dibutuhkan sesuai selera Gula dan garam




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica rica:

1. Bersihkan ayam..pilih bagian paha atas krna lebih lembut dan mudah menyerap bumbu
1. Haluskan semua bumbu kecuali jahe dan sereh
1. Tumis bumbu halus Tips : sebelum menumis ketika minyak panas, masukan terlebih dahulu jahe dan sereh agar minyak menyerap aroma nya
1. Setelah jumbu matang dan beraroma masukan ayam.. aduk sampe bumbu merata..
1. Setelah bumbu merata, masukan air masak hingga ayam matang dan air menyusut Tips : tutup wajan agar lebih cepat
1. Setelah air susut, masukan kemangi matikan api.. aduk rata.. Done ^^




Demikianlah cara membuat ayam rica rica yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan cepat, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
