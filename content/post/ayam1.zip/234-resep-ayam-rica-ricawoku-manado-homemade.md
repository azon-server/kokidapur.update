---
description: "Resep : Ayam Rica -Rica[woku] manado Homemade"
title: "Resep : Ayam Rica -Rica[woku] manado Homemade"
slug: 234-resep-ayam-rica-ricawoku-manado-homemade
date: 2020-11-17T03:54:30.465Z
image: https://img-global.cpcdn.com/recipes/d775172bb1db4686/751x532cq70/ayam-rica-ricawoku-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d775172bb1db4686/751x532cq70/ayam-rica-ricawoku-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d775172bb1db4686/751x532cq70/ayam-rica-ricawoku-manado-foto-resep-utama.jpg
author: Lula Collins
ratingvalue: 4.5
reviewcount: 4322
recipeingredient:
- "300 gr ayam potong sesuai selera saya potong kecil kecil"
- "Secukupnya minyak goreng untuk menumis"
- "500 ml air"
- " Bumbu yg di haluskan"
- "7 buah cabe merah"
- "9 buah cabe rawit merah"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "2 butir kemiri"
- "1 ruas jempol jahe"
- "1/2 ruas jempol kunyit"
- "Secukupnya garamgula dan kaldu jamur"
- " Bumbu cemplung"
- "1 batang sereh"
- "4 lembar daun jeruk"
- "1 lembar daun salam"
- "2 genggam daun kemangi"
- "1/2 potong tomat hijau"
- "1/2 potong tomat merah"
- "3 lembar daun bawang iris kecilkecil"
- " Bumbu marinasi ayam"
- "Secukupnya garam"
- "Secukupnya kunyit bubuk"
- "Secukupnya bawang putih bubuk"
- "Secukupnya merica bubuk"
recipeinstructions:
- "Cuci bersih ayam kemudian bumbuin dg bumbu marinasi kemudian diamkan sekitar 10-15 menit,setelah itu goreng ayam sebentar hingga setengah matang angkat dan sisishkan"
- "Kemudian ulek bumbu yg di haluskan, bisa juga menggunakan blender(saya pake ulekan)"
- "Masukan minyak goreng kedalam wajan tunggu hingga minyak panas,kemudian masukan bumbu halus tadi beserta daun jeruk,sereh,daun salam,tunggu sampai matang dan wangi"
- "Kemudian setelah bumbu halus matang,masukan ayam aduk hingga rata,kemudian masukan air,tunggu hingga kuah mendididh,kemudian masukan garam,gula dan kaldu jamur"
- "Setelah air agak menyusut masukan daun kemangi,dan tomat kemudian masukan daun bawang,"
- "Kemudian tes rasa,dan biarkan sampai air agak mengering,Dan ayam benar2 matang,setelah matang angkat dan sajikan,"
categories:
- Recipe
tags:
- ayam
- rica
- ricawoku

katakunci: ayam rica ricawoku 
nutrition: 245 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT30M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica -Rica[woku] manado](https://img-global.cpcdn.com/recipes/d775172bb1db4686/751x532cq70/ayam-rica-ricawoku-manado-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica -rica[woku] manado yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Nusantara

Kedekatan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah memasak Ayam Rica -Rica[woku] manado untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang bisa anda buat salah satunya ayam rica -rica[woku] manado yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica -rica[woku] manado tanpa harus bersusah payah.
Berikut ini resep Ayam Rica -Rica[woku] manado yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 25 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica -Rica[woku] manado:

1. Tambah 300 gr ayam potong sesuai selera (saya potong kecil- kecil)
1. Tambah Secukupnya minyak goreng untuk menumis
1. Diperlukan 500 ml air
1. Harus ada  Bumbu yg di haluskan
1. Harus ada 7 buah cabe merah
1. Harap siapkan 9 buah cabe rawit merah
1. Diperlukan 6 siung bawang merah
1. Tambah 4 siung bawang putih
1. Harap siapkan 2 butir kemiri
1. Diperlukan 1 ruas jempol jahe
1. Dibutuhkan 1/2 ruas jempol kunyit
1. Jangan lupa Secukupnya garam,gula dan kaldu jamur
1. Harus ada  Bumbu cemplung
1. Dibutuhkan 1 batang sereh
1. Harus ada 4 lembar daun jeruk
1. Diperlukan 1 lembar daun salam
1. Harus ada 2 genggam daun kemangi
1. Harus ada 1/2 potong tomat hijau
1. Harus ada 1/2 potong tomat merah
1. Jangan lupa 3 lembar daun bawang iris kecil-kecil
1. Harus ada  Bumbu marinasi ayam
1. Diperlukan Secukupnya garam
1. Siapkan Secukupnya kunyit bubuk
1. Harus ada Secukupnya bawang putih bubuk
1. Diperlukan Secukupnya merica bubuk




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica -Rica[woku] manado:

1. Cuci bersih ayam kemudian bumbuin dg bumbu marinasi kemudian diamkan sekitar 10-15 menit,setelah itu goreng ayam sebentar hingga setengah matang angkat dan sisishkan
1. Kemudian ulek bumbu yg di haluskan, bisa juga menggunakan blender(saya pake ulekan)
1. Masukan minyak goreng kedalam wajan tunggu hingga minyak panas,kemudian masukan bumbu halus tadi beserta daun jeruk,sereh,daun salam,tunggu sampai matang dan wangi
1. Kemudian setelah bumbu halus matang,masukan ayam aduk hingga rata,kemudian masukan air,tunggu hingga kuah mendididh,kemudian masukan garam,gula dan kaldu jamur
1. Setelah air agak menyusut masukan daun kemangi,dan tomat kemudian masukan daun bawang,
1. Kemudian tes rasa,dan biarkan sampai air agak mengering,Dan ayam benar2 matang,setelah matang angkat dan sajikan,




Demikianlah cara membuat ayam rica -rica[woku] manado yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
