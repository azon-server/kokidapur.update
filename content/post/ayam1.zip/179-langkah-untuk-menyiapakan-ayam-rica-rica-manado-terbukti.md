---
description: "Langkah untuk menyiapakan Ayam rica rica manado Terbukti"
title: "Langkah untuk menyiapakan Ayam rica rica manado Terbukti"
slug: 179-langkah-untuk-menyiapakan-ayam-rica-rica-manado-terbukti
date: 2020-12-29T05:33:10.898Z
image: https://img-global.cpcdn.com/recipes/3101f10f1922ed7d/751x532cq70/ayam-rica-rica-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3101f10f1922ed7d/751x532cq70/ayam-rica-rica-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3101f10f1922ed7d/751x532cq70/ayam-rica-rica-manado-foto-resep-utama.jpg
author: Beatrice Parker
ratingvalue: 4.7
reviewcount: 40336
recipeingredient:
- "1 ekor Ayam dan hati ayam"
- " Bumbu halus"
- "10 siung bawang merah"
- "15 siung bawang putih"
- "2 butir kemiri"
- "Sejempol jahe"
- " Bahan kering"
- "3  7lembar daun jeruk disobekblender alus"
- " Kunyit bubuk"
- "3 btg sereh geprek"
- " Cabe keriting  cabe rawit"
- " Kemangi"
- "2 sdm Minyak  tumis"
- "secukupnya Garam"
- "sejumput Gula"
- " Penyedap rasa"
- "1 sdm saos asin"
- "300 ml Air"
recipeinstructions:
- "Cuci bersih semua bahan"
- "Tumis bumbu halus bersmaan 3 daun jeruk n sereh masukkan jg kunyit bubuk"
- "Aduk api kecil sampai rata lalu masukkan ayam aduk rata tambahkan air dan semua bumbu penyedap grm gula saos lalu tutup dan biarkan airnya meresap ke daging 20-30mnt api kecil ato smpe menyusut"
- "Masukkan cabe utuh dan kemangi aduk rata lalu angkat siap di sajikan. Selamat mencoba😊"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 147 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica rica manado](https://img-global.cpcdn.com/recipes/3101f10f1922ed7d/751x532cq70/ayam-rica-rica-manado-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau gurih. Ciri khas masakan Nusantara ayam rica rica manado yang penuh dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan keluarga dapat ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam rica rica manado untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang dapat anda contoh salah satunya ayam rica rica manado yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica rica manado tanpa harus bersusah payah.
Seperti resep Ayam rica rica manado yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica manado:

1. Diperlukan 1 ekor Ayam dan hati ayam
1. Harus ada  Bumbu halus
1. Tambah 10 siung bawang merah
1. Harus ada 15 siung bawang putih
1. Harap siapkan 2 butir kemiri
1. Tambah Sejempol jahe
1. Tambah  Bahan kering
1. Harus ada 3 + 7lembar daun jeruk disobek/blender alus
1. Tambah  Kunyit bubuk
1. Siapkan 3 btg sereh geprek
1. Siapkan  Cabe keriting / cabe rawit
1. Harap siapkan  Kemangi
1. Dibutuhkan 2 sdm Minyak  tumis
1. Jangan lupa secukupnya Garam
1. Harap siapkan sejumput Gula
1. Siapkan  Penyedap rasa
1. Tambah 1 sdm saos asin
1. Harus ada 300 ml Air




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica rica manado:

1. Cuci bersih semua bahan
1. Tumis bumbu halus bersmaan 3 daun jeruk n sereh masukkan jg kunyit bubuk
1. Aduk api kecil sampai rata lalu masukkan ayam aduk rata tambahkan air dan semua bumbu penyedap grm gula saos lalu tutup dan biarkan airnya meresap ke daging 20-30mnt api kecil ato smpe menyusut
1. Masukkan cabe utuh dan kemangi aduk rata lalu angkat siap di sajikan. Selamat mencoba😊




Demikianlah cara membuat ayam rica rica manado yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
