---
description: "Step-by-Step membuat Ayam Goreng Cabe Ijo teraktual"
title: "Step-by-Step membuat Ayam Goreng Cabe Ijo teraktual"
slug: 291-step-by-step-membuat-ayam-goreng-cabe-ijo-teraktual
date: 2020-08-18T23:08:11.104Z
image: https://img-global.cpcdn.com/recipes/aa32295fd363baf2/751x532cq70/ayam-goreng-cabe-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/aa32295fd363baf2/751x532cq70/ayam-goreng-cabe-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/aa32295fd363baf2/751x532cq70/ayam-goreng-cabe-ijo-foto-resep-utama.jpg
author: Gabriel Ward
ratingvalue: 4
reviewcount: 15012
recipeingredient:
- "300 gr Ayam Fillet"
- "Secukupnya Lada"
- "Secukupnya Garam"
- " Bahan Sambal"
- "150 gr Cabai Keriting Hijau"
- "10 biji Cabai Rawit Merah"
- "6 buah Bawang Putih"
- "1/2 Terasi dibakar"
recipeinstructions:
- "Marinasi ayam dengan Garam dan Lada diamkan dikulkas selama 1 jam"
- "Panaskan minyak lalu goreng ayam dengan api kecil hingga matang lalu tiriskan"
- "Setelah ayam diangkat, goreng semua bahan sambal kecuali terasi. Goreng selama 3 menit"
- "Lalu ulek semua bahan sambal"
categories:
- Recipe
tags:
- ayam
- goreng
- cabe

katakunci: ayam goreng cabe 
nutrition: 120 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Goreng Cabe Ijo](https://img-global.cpcdn.com/recipes/aa32295fd363baf2/751x532cq70/ayam-goreng-cabe-ijo-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan empuk. Ciri makanan Indonesia ayam goreng cabe ijo yang kaya dengan rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kedekatan keluarga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Goreng Cabe Ijo untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang bisa anda coba salah satunya ayam goreng cabe ijo yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep ayam goreng cabe ijo tanpa harus bersusah payah.
Berikut ini resep Ayam Goreng Cabe Ijo yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 8 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Cabe Ijo:

1. Dibutuhkan 300 gr Ayam Fillet
1. Siapkan Secukupnya Lada
1. Tambah Secukupnya Garam
1. Diperlukan  Bahan Sambal
1. Dibutuhkan 150 gr Cabai Keriting Hijau
1. Diperlukan 10 biji Cabai Rawit Merah
1. Jangan lupa 6 buah Bawang Putih
1. Siapkan 1/2 Terasi (dibakar)




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Goreng Cabe Ijo:

1. Marinasi ayam dengan Garam dan Lada diamkan dikulkas selama 1 jam
1. Panaskan minyak lalu goreng ayam dengan api kecil hingga matang lalu tiriskan
1. Setelah ayam diangkat, goreng semua bahan sambal kecuali terasi. Goreng selama 3 menit
1. Lalu ulek semua bahan sambal




Demikianlah cara membuat ayam goreng cabe ijo yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan teruji, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
