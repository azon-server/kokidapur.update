---
description: "Steps membuat Ayam Rica-rica Kemangi Luar biasa"
title: "Steps membuat Ayam Rica-rica Kemangi Luar biasa"
slug: 228-steps-membuat-ayam-rica-rica-kemangi-luar-biasa
date: 2021-01-27T18:12:40.640Z
image: https://img-global.cpcdn.com/recipes/92c2b61eb5624e99/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/92c2b61eb5624e99/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/92c2b61eb5624e99/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Glen Mathis
ratingvalue: 4.8
reviewcount: 5790
recipeingredient:
- "1 ekor ayam potong sedang"
- "1 buah jeruk nipis"
- "1 ikat kemangi"
- "1 buah tomat"
- "2 batang sereh"
- "1 ruas lengkuas"
- "1 ruas jahe"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "100 ml air matang"
- " Bumbu halus"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "1 ruas kunyit"
- "3 butir kemiri"
- "6 buah cabe merah keriting"
- "1/2 sdt ketumbar"
- "1/2 sdt lada bubuk"
- "1 sdt kaldu bubuk"
- "Secukupnya garam  gula"
recipeinstructions:
- "Cuci bersih ayam, beri perasan jeruk nipis, kemudian diamkan selama 10 menit, lalu cuci bersih kembali. Goreng ayam setengah matang."
- "Blender bumbu halus, kemudian tumis sampai harum. Masukan daun salam, daun jeruk, lengkuas, jahe &amp; sereh yg Sdh di geprek. Tunggu sampai bumbu sedikit mengental. Masukan ayam, tambahkan sedikit air, garam, gula &amp; kaldu ayam bubuk aduk rata,."
- "Masukan tomat &amp; kemangi, aduk rata kembali sebentar saja lalu koreksi rasa. Setelah pas matikan api &amp; Siap disajikan."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 153 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/92c2b61eb5624e99/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau renyah. Karasteristik makanan Indonesia ayam rica-rica kemangi yang penuh dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Rica-rica Kemangi untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang bisa anda contoh salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica Kemangi:

1. Jangan lupa 1 ekor ayam potong sedang
1. Harap siapkan 1 buah jeruk nipis
1. Tambah 1 ikat kemangi
1. Siapkan 1 buah tomat
1. Diperlukan 2 batang sereh
1. Siapkan 1 ruas lengkuas
1. Diperlukan 1 ruas jahe
1. Jangan lupa 2 lembar daun salam
1. Dibutuhkan 3 lembar daun jeruk
1. Siapkan 100 ml air matang
1. Diperlukan  Bumbu halus:
1. Harap siapkan 6 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Jangan lupa 1 ruas kunyit
1. Jangan lupa 3 butir kemiri
1. Tambah 6 buah cabe merah keriting
1. Tambah 1/2 sdt ketumbar
1. Harap siapkan 1/2 sdt lada bubuk
1. Jangan lupa 1 sdt kaldu bubuk
1. Diperlukan Secukupnya garam &amp; gula




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-rica Kemangi:

1. Cuci bersih ayam, beri perasan jeruk nipis, kemudian diamkan selama 10 menit, lalu cuci bersih kembali. Goreng ayam setengah matang.
1. Blender bumbu halus, kemudian tumis sampai harum. Masukan daun salam, daun jeruk, lengkuas, jahe &amp; sereh yg Sdh di geprek. Tunggu sampai bumbu sedikit mengental. Masukan ayam, tambahkan sedikit air, garam, gula &amp; kaldu ayam bubuk aduk rata,.
1. Masukan tomat &amp; kemangi, aduk rata kembali sebentar saja lalu koreksi rasa. Setelah pas matikan api &amp; Siap disajikan.




Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
