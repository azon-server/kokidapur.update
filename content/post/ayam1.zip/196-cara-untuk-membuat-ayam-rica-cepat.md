---
description: "Cara untuk membuat Ayam rica Cepat"
title: "Cara untuk membuat Ayam rica Cepat"
slug: 196-cara-untuk-membuat-ayam-rica-cepat
date: 2020-11-13T00:27:52.136Z
image: https://img-global.cpcdn.com/recipes/d8c6b053817efed8/751x532cq70/ayam-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d8c6b053817efed8/751x532cq70/ayam-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d8c6b053817efed8/751x532cq70/ayam-rica-foto-resep-utama.jpg
author: Tony Campbell
ratingvalue: 4.9
reviewcount: 32018
recipeingredient:
- "1/2 ekor ayam bagian paha"
- "3 lbr daun jeruk"
- "2 lbr daun salam"
- "1 btg serai potong 3 bagian"
- "200 ml air"
- "Secukupnya gula dan garam"
- "Secukupnya minyak goreng untuk menumis"
- " Bumbu halus"
- "7 bh cabai rawit merah"
- "3 bh cabai kering"
- "3 siung bawang putih"
- "3 siung bawang merah"
- "2 bh kemiri"
- "3 cm jahe"
- "1 sdt kunyit bubuk"
recipeinstructions:
- "Tumis bumbu halus, tambahkan daun salam, daun jeruk, serai, gula dan garam"
- "Masukkan ayam, lalu tambahkan air, aduk rata, masak hingga airnya menyusut"
- "Ayam Rica siap dinikmati dengan nasi hangat"
categories:
- Recipe
tags:
- ayam
- rica

katakunci: ayam rica 
nutrition: 100 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica](https://img-global.cpcdn.com/recipes/d8c6b053817efed8/751x532cq70/ayam-rica-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas dan gurih. Karasteristik kuliner Indonesia ayam rica yang kaya dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah memasak Ayam rica untuk keluarga. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang bisa anda buat salah satunya ayam rica yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep ayam rica tanpa harus bersusah payah.
Seperti resep Ayam rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica:

1. Tambah 1/2 ekor ayam (bagian paha)
1. Dibutuhkan 3 lbr daun jeruk
1. Siapkan 2 lbr daun salam
1. Harus ada 1 btg serai (potong 3 bagian)
1. Dibutuhkan 200 ml air
1. Dibutuhkan Secukupnya gula dan garam
1. Jangan lupa Secukupnya minyak goreng untuk menumis
1. Siapkan  Bumbu halus
1. Tambah 7 bh cabai rawit merah
1. Jangan lupa 3 bh cabai kering
1. Diperlukan 3 siung bawang putih
1. Dibutuhkan 3 siung bawang merah
1. Harus ada 2 bh kemiri
1. Harus ada 3 cm jahe
1. Siapkan 1 sdt kunyit bubuk




<!--inarticleads2-->

##### Langkah membuat  Ayam rica:

1. Tumis bumbu halus, tambahkan daun salam, daun jeruk, serai, gula dan garam
1. Masukkan ayam, lalu tambahkan air, aduk rata, masak hingga airnya menyusut
1. Ayam Rica siap dinikmati dengan nasi hangat




Demikianlah cara membuat ayam rica yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
