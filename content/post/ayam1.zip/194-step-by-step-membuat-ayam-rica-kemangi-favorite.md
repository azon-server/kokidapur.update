---
description: "Step-by-Step membuat Ayam Rica Kemangi Favorite"
title: "Step-by-Step membuat Ayam Rica Kemangi Favorite"
slug: 194-step-by-step-membuat-ayam-rica-kemangi-favorite
date: 2020-08-26T20:47:40.409Z
image: https://img-global.cpcdn.com/recipes/625f1026f12c3a19/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/625f1026f12c3a19/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/625f1026f12c3a19/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Herman Perkins
ratingvalue: 4
reviewcount: 21910
recipeingredient:
- "4 potong Ayam ukuran sedang"
- "1 ikat Daun Kemangi petiki daunnya"
- " BumbuBumbu"
- "5 siung Bawang Merah"
- "3 siung Bawang Putih"
- "10 buah Cabe Merah"
- "10 buah Cabe Rawit Merah"
- "2 lembar Daun Salam"
- "3 lembar Daun Jeruk"
- "1 batang Serai geprek"
- "2 cm Lengkuas geprek"
- "Secukupnya gula  garam"
- "250 ml air"
- " Minyak untuk menumis"
recipeinstructions:
- "Goreng ayam sampai berkulit dan agak kering, sisihkan"
- "Haluskan Duo Bawang, Cabe Merah, &amp; Cabe Rawit merah"
- "Tumis bumbu yang sudah dihaluskan, tambahkan daun salam, daun jeruk, serai, dan lengkuas. Tumis sampai harum"
- "Masukkan ayam, tumis ±3 menit.. Masukkan air, masak sampai bumbu meresap dan air menyusut."
- "Masukkan gula &amp; garam, tes rasa."
- "Masukkan Daun Kemangi, masak sampai daun layu."
- "Angkat dan sajikan."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 146 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/625f1026f12c3a19/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas dan renyah. Ciri khas masakan Indonesia ayam rica kemangi yang penuh dengan rempah-rempah memberikan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kehangatan keluarga bisa ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica Kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda praktekkan salah satunya ayam rica kemangi yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Siapkan 4 potong Ayam ukuran sedang
1. Tambah 1 ikat Daun Kemangi, petiki daunnya
1. Harus ada  Bumbu-Bumbu
1. Jangan lupa 5 siung Bawang Merah
1. Diperlukan 3 siung Bawang Putih
1. Harus ada 10 buah Cabe Merah
1. Tambah 10 buah Cabe Rawit Merah
1. Diperlukan 2 lembar Daun Salam
1. Harap siapkan 3 lembar Daun Jeruk
1. Tambah 1 batang Serai, geprek
1. Diperlukan 2 cm Lengkuas, geprek
1. Dibutuhkan Secukupnya gula &amp; garam
1. Tambah 250 ml air
1. Siapkan  Minyak untuk menumis




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Kemangi:

1. Goreng ayam sampai berkulit dan agak kering, sisihkan
1. Haluskan Duo Bawang, Cabe Merah, &amp; Cabe Rawit merah
1. Tumis bumbu yang sudah dihaluskan, tambahkan daun salam, daun jeruk, serai, dan lengkuas. Tumis sampai harum
1. Masukkan ayam, tumis ±3 menit.. Masukkan air, masak sampai bumbu meresap dan air menyusut.
1. Masukkan gula &amp; garam, tes rasa.
1. Masukkan Daun Kemangi, masak sampai daun layu.
1. Angkat dan sajikan.




Demikianlah cara membuat ayam rica kemangi yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
