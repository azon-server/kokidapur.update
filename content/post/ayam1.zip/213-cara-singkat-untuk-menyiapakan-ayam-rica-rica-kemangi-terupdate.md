---
description: "Cara singkat untuk menyiapakan Ayam Rica Rica Kemangi terupdate"
title: "Cara singkat untuk menyiapakan Ayam Rica Rica Kemangi terupdate"
slug: 213-cara-singkat-untuk-menyiapakan-ayam-rica-rica-kemangi-terupdate
date: 2021-01-21T23:49:57.241Z
image: https://img-global.cpcdn.com/recipes/155e0f30aaaca26f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/155e0f30aaaca26f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/155e0f30aaaca26f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Teresa Walton
ratingvalue: 4.4
reviewcount: 2267
recipeingredient:
- "1 ekor ayam potong sesuai selera"
- "1 ikat daun kemangi"
- "3 lembar daun jeruk"
- "3 lembar daun salam"
- "1 batang serai geprek"
- "10 buah cabe rawit sy pakai utuhaslinya halus"
- "secukupnya Garam merica gula dan kaldu"
- " Bumbu Halus "
- "1 ruas lengkuas"
- "1 ruas jahe"
- "1 ruas kunyit"
- "6 butir bawang merah"
- "3 siung bawang putih"
- "2 butir kemiri"
- "10 buah cabe merah sesuai selera"
recipeinstructions:
- "Cuci bersih ayam, tambahkan air perasan jeruk nipis sedikit, diamkan sktr 15 menit agar tidak bau amis. Cuci bersih lagi. Rebus ayam sebentar untuk menghilangkan kotoran dan ayam cepat empuk. Tiriskan."
- "Panaskan sedikit minyak, tumis daun jeruk,daun salam dan serai hingga harum. Tambahkan bumbu halus, tumis hingga wangi."
- "Masukkan ayam, tambahkan garam, gula, merica dan kaldu. Aduk rata. Tambahkan sedikit air. Aduk rata."
- "Jika ayam sudah empuk dan air menyusut tambahkan daun kemangi. Aduk sebentar. Koreksi rasa. Sajikan."
- "Hmm enaaak sekali 💖💖."
- "Note : disini saya pakai daging ayam bagian dada dan beberapa ceker ayam. Tapi untuk satu ayam utuh juga bisa atau disesuaikan dgn selera masing2."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 158 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/155e0f30aaaca26f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang harus kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica rica kemangi yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa kesan tersendiri yang merupakan keragaman Indonesia



Keharmonisan rumah tangga dapat diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica Rica Kemangi untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang bisa anda coba salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya saat ini kamu bisa dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi:

1. Harap siapkan 1 ekor ayam, potong sesuai selera
1. Tambah 1 ikat daun kemangi
1. Tambah 3 lembar daun jeruk
1. Dibutuhkan 3 lembar daun salam
1. Harap siapkan 1 batang serai, geprek
1. Dibutuhkan 10 buah cabe rawit (sy pakai utuh)aslinya halus
1. Tambah secukupnya Garam, merica, gula dan kaldu
1. Diperlukan  Bumbu Halus :
1. Jangan lupa 1 ruas lengkuas
1. Harus ada 1 ruas jahe
1. Dibutuhkan 1 ruas kunyit
1. Harus ada 6 butir bawang merah
1. Tambah 3 siung bawang putih
1. Siapkan 2 butir kemiri
1. Diperlukan 10 buah cabe merah (sesuai selera)




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica Kemangi:

1. Cuci bersih ayam, tambahkan air perasan jeruk nipis sedikit, diamkan sktr 15 menit agar tidak bau amis. Cuci bersih lagi. Rebus ayam sebentar untuk menghilangkan kotoran dan ayam cepat empuk. Tiriskan.
1. Panaskan sedikit minyak, tumis daun jeruk,daun salam dan serai hingga harum. Tambahkan bumbu halus, tumis hingga wangi.
1. Masukkan ayam, tambahkan garam, gula, merica dan kaldu. Aduk rata. Tambahkan sedikit air. Aduk rata.
1. Jika ayam sudah empuk dan air menyusut tambahkan daun kemangi. Aduk sebentar. Koreksi rasa. Sajikan.
1. Hmm enaaak sekali 💖💖.
1. Note : disini saya pakai daging ayam bagian dada dan beberapa ceker ayam. Tapi untuk satu ayam utuh juga bisa atau disesuaikan dgn selera masing2.




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan cepat, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
