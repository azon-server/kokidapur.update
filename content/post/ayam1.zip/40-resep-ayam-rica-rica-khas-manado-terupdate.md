---
description: "Resep : Ayam Rica-rica Khas Manado terupdate"
title: "Resep : Ayam Rica-rica Khas Manado terupdate"
slug: 40-resep-ayam-rica-rica-khas-manado-terupdate
date: 2020-09-15T18:59:37.700Z
image: https://img-global.cpcdn.com/recipes/dd248eebce971413/751x532cq70/ayam-rica-rica-khas-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dd248eebce971413/751x532cq70/ayam-rica-rica-khas-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dd248eebce971413/751x532cq70/ayam-rica-rica-khas-manado-foto-resep-utama.jpg
author: Douglas Dawson
ratingvalue: 4.6
reviewcount: 5743
recipeingredient:
- "1 ekor ayam potong kecil"
- "1 ikat kemangisiangi ambil daunnya aja"
- "1 lembar daun pandanikat simpul"
- "5 lembar daun jeruk purutiris halus"
- "2 batang daun bawangiris"
- "2 cm laosgeprek"
- "4 batang seraiukuran kecil geprek"
- "1 sdt Garam"
- "1/2 sdt royco"
- " Minyak goreng"
- " Air"
- " Bumbu yang dihaluskan "
- "1 ons cabe merah"
- "1/2 ons cabe rawit"
- "50 gr bawang merah"
- "50 gr bawang putih"
- "3 buah kemiri"
- "2 cm jahe"
recipeinstructions:
- "Siapkan semua bahan,cuci bersih dan tiriskan semua bahan.iris daun bawang dan daun jeruk purut,petiki daun kemangi,geprek laos dan serai."
- "Bumbui ayam dengan garam, kunyit bubuk,jeruk nipis(aku jeruk sambel) selama kurang lebih 10 menit, goreng setengah masak., tiriskan."
- "Choper/haluskan bumbu,beri sedikit minyak goreng. panaskan minyak goreng,tumis sampai wangi."
- "Tambahkan pandan, daun salam, serai dan laos, masukan ayam yg sudah digoreng, aduk hingga rata, masukan air secukupnya. Tambahkan garam,kunyit bubuk dan penyedap secukupnya, masak sampai ayam empuk sekitar 20 menit."
- "Setelah ayam empuk dan kuah mengering masukan daun kemangi dan daun bawang, aduk hingga layu."
- "Tes rasa, pindah ke piring saji."
categories:
- Recipe
tags:
- ayam
- ricarica
- khas

katakunci: ayam ricarica khas 
nutrition: 147 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica-rica Khas Manado](https://img-global.cpcdn.com/recipes/dd248eebce971413/751x532cq70/ayam-rica-rica-khas-manado-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan empuk. Karasteristik kuliner Indonesia ayam rica-rica khas manado yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.


Rica-rica dalam bahasa Manado (Sulawesi Utara) berarti pedas atau cabe. dalam proses masaknya beraneka ragam. Masakan kali ini dengan menambah daun kemangi. LIHAT VIDEO KUALITAS FULL HD Berlangganan video baru setiap Hari KAMIS dan SENIN Ayam Rica Rica Khas Manado Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar.

Kehangatan rumah tangga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica-rica Khas Manado untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang bisa anda buat salah satunya ayam rica-rica khas manado yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep ayam rica-rica khas manado tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica Khas Manado yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Khas Manado:

1. Tambah 1 ekor ayam, potong kecil
1. Harap siapkan 1 ikat kemangi,siangi ambil daunnya aja
1. Diperlukan 1 lembar daun pandan,ikat simpul
1. Tambah 5 lembar daun jeruk purut,iris halus
1. Diperlukan 2 batang daun bawang,iris
1. Dibutuhkan 2 cm laos,geprek
1. Harus ada 4 batang serai(ukuran kecil), geprek
1. Siapkan 1 sdt Garam
1. Siapkan 1/2 sdt royco
1. Jangan lupa  Minyak goreng
1. Diperlukan  Air
1. Diperlukan  Bumbu yang dihaluskan :
1. Diperlukan 1 ons cabe merah
1. Jangan lupa 1/2 ons cabe rawit
1. Diperlukan 50 gr bawang merah
1. Dibutuhkan 50 gr bawang putih
1. Diperlukan 3 buah kemiri
1. Harus ada 2 cm jahe


Apalagi ayam rica-ricanya yang cenderung pedas. Rasanya mantap, bikin sulit untuk melupakan kenikmatannya. Kali ini IDN Times akan rekomendasikan resep ayam rica-rica khas Manado dan cara membuatnya yang enak. Resep rica rica sendiri sebenarnya tidak harus menggunakan bahan daging ayam saja. 

<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-rica Khas Manado:

1. Siapkan semua bahan,cuci bersih dan tiriskan semua bahan.iris daun bawang dan daun jeruk purut,petiki daun kemangi,geprek laos dan serai.
1. Bumbui ayam dengan garam, kunyit bubuk,jeruk nipis(aku jeruk sambel) selama kurang lebih 10 menit, goreng setengah masak., tiriskan.
1. Choper/haluskan bumbu,beri sedikit minyak goreng. panaskan minyak goreng,tumis sampai wangi.
1. Tambahkan pandan, daun salam, serai dan laos, masukan ayam yg sudah digoreng, aduk hingga rata, masukan air secukupnya. Tambahkan garam,kunyit bubuk dan penyedap secukupnya, masak sampai ayam empuk sekitar 20 menit.
1. Setelah ayam empuk dan kuah mengering masukan daun kemangi dan daun bawang, aduk hingga layu.
1. Tes rasa, pindah ke piring saji.


Kali ini IDN Times akan rekomendasikan resep ayam rica-rica khas Manado dan cara membuatnya yang enak. Resep rica rica sendiri sebenarnya tidak harus menggunakan bahan daging ayam saja. Cita rasa pedas menjadi ciri khas resep yang tergabung dalam masakan indonesia yang satu ini. Dengan demikian siapapun dapat mencoba membuat masakan rica rica ala manado ini. Rica-rica ini menggunakan bumbu rempah-rempah sehingga sangat aman dan nyaman dimakan dengan menggunakan nasi yang masih hangat. 

Demikianlah cara membuat ayam rica-rica khas manado yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan terbukti, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
