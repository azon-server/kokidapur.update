---
description: "Bagaimana membuat Ayam Rica-Rica Pedes Cepat"
title: "Bagaimana membuat Ayam Rica-Rica Pedes Cepat"
slug: 233-bagaimana-membuat-ayam-rica-rica-pedes-cepat
date: 2020-10-05T17:15:24.046Z
image: https://img-global.cpcdn.com/recipes/e45805f90980b01b/751x532cq70/ayam-rica-rica-pedes-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e45805f90980b01b/751x532cq70/ayam-rica-rica-pedes-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e45805f90980b01b/751x532cq70/ayam-rica-rica-pedes-foto-resep-utama.jpg
author: Margaret Gilbert
ratingvalue: 4.8
reviewcount: 21011
recipeingredient:
- "300 gr ayam kampung"
- " Bumbu Halus"
- "5 cabe besar"
- "4 siung bawang merah"
- "3 siung bawang putih"
- "10 cabe rawit"
- "1 butir kemiri"
- "3 iris jahe"
- "3 iris kunyit"
- " Minyakmertega secukypnya"
- " Bumbu Cemplung"
- "1 batamg sereh"
- "2 lembar dau jeruk"
- "2 lembar daun salam"
- "1/4 sdt Kaldu bubuk"
- "secukupnya Garam"
- "1/4 sdt gula"
recipeinstructions:
- "Bersihkan dan cuci bersih ayam lalu rebis hingga empuk."
- "Kupas dan cuci bersih bumbu dan haluskan."
- "Cuci bersih sereh, daun jeruk, daun salam, sisihkan"
- "Gongso /sangrai bumbu hingga harum baunya, sisihkan."
- "Goreng ayam tapi tidak sampe garing lalu masukkah ke bumbu yang sudah digongso masak sampe 10 menit, masukkan sereh, daun jeruk, daun salam kaldu bubuk, garam, gula dan cek rasa."
- "RICA&#34; AYAM PEDAS siap disantap SELAMAT MENIKMATI"
categories:
- Recipe
tags:
- ayam
- ricarica
- pedes

katakunci: ayam ricarica pedes 
nutrition: 248 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT39M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica-Rica Pedes](https://img-global.cpcdn.com/recipes/e45805f90980b01b/751x532cq70/ayam-rica-rica-pedes-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang harus kita lestarikan karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica-rica pedes yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Indonesia

Keharmonisan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah memasak Ayam Rica-Rica Pedes untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang bisa anda buat salah satunya ayam rica-rica pedes yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep ayam rica-rica pedes tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica Pedes yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Pedes:

1. Jangan lupa 300 gr ayam kampung
1. Harap siapkan  Bumbu Halus
1. Diperlukan 5 cabe besar
1. Diperlukan 4 siung bawang merah
1. Tambah 3 siung bawang putih
1. Siapkan 10 cabe rawit
1. Jangan lupa 1 butir kemiri
1. Dibutuhkan 3 iris jahe
1. Diperlukan 3 iris kunyit
1. Diperlukan  Minyak/mertega secukypnya
1. Diperlukan  Bumbu Cemplung
1. Dibutuhkan 1 batamg sereh
1. Tambah 2 lembar dau jeruk
1. Tambah 2 lembar daun salam
1. Dibutuhkan 1/4 sdt Kaldu bubuk
1. Jangan lupa secukupnya Garam
1. Harus ada 1/4 sdt gula




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-Rica Pedes:

1. Bersihkan dan cuci bersih ayam lalu rebis hingga empuk.
1. Kupas dan cuci bersih bumbu dan haluskan.
1. Cuci bersih sereh, daun jeruk, daun salam, sisihkan
1. Gongso /sangrai bumbu hingga harum baunya, sisihkan.
1. Goreng ayam tapi tidak sampe garing lalu masukkah ke bumbu yang sudah digongso masak sampe 10 menit, masukkan sereh, daun jeruk, daun salam kaldu bubuk, garam, gula dan cek rasa.
1. RICA&#34; AYAM PEDAS siap disantap SELAMAT MENIKMATI




Demikianlah cara membuat ayam rica-rica pedes yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
