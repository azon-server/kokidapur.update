---
description: "Resep : Ayam Rica-Rica Cepat"
title: "Resep : Ayam Rica-Rica Cepat"
slug: 47-resep-ayam-rica-rica-cepat
date: 2020-12-29T10:00:28.712Z
image: https://img-global.cpcdn.com/recipes/b5740a70cd6d1467/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b5740a70cd6d1467/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b5740a70cd6d1467/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Sue Gonzales
ratingvalue: 4.7
reviewcount: 12398
recipeingredient:
- "350 gr Sayap Ayam dipotong 2 bebas sesuai selera"
- "2 lembar Daun Salam"
- "1 batang Serai Geprek"
- "1 sdm Gula Jawa sisir halus"
- "1 sdm Kecap Manis"
- "Secukupnya Garam Lada Penyedap Rasa"
- "250 ml Air secukupnya dan minyak untuk menumis"
- " Bumbu Halus"
- "3 siung Bawang Merah"
- "2 siung Bawang Putih"
- "7 buah Cabai Merah Keriting"
- "2 buah Cabai Rawit Besar skip kalau nggak pengen terlalu pedas"
- "2 cm Kunyit"
recipeinstructions:
- "Potong ayam sesuai yang diinginkan, cuci bersih, sisihkan"
- "Cuci bersih bahan bumbu halus, haluskan (blender/uleg). Setelah halus, panaskan minyak di wajan untuk menumis, masukkan bumbu halus, daun salam, dan sereh, tumis sampai harum"
- "Setelah harum, masukkan potongan ayam ke dalam tumisan, aduk rata"
- "Tambahkan secukupnya air (sampai daging cukup terendam), garam, lada, penyedap, kecap manis dan gula jawa, aduk rata. Tutup dan biarkan sampai ayam matang dan kuah menyusut. Aduk sesekali sambil koreksi rasa"
- "Voila! Sajikan dan siap dinikmati dengan nasi hangat"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 253 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/b5740a70cd6d1467/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga gurih. Ciri makanan Nusantara ayam rica-rica yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Rica-Rica untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang bisa anda buat salah satunya ayam rica-rica yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 13 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica:

1. Siapkan 350 gr Sayap Ayam dipotong 2 (bebas, sesuai selera)
1. Siapkan 2 lembar Daun Salam
1. Tambah 1 batang Serai Geprek
1. Siapkan 1 sdm Gula Jawa (sisir halus)
1. Siapkan 1 sdm Kecap Manis
1. Dibutuhkan Secukupnya Garam, Lada, Penyedap Rasa
1. Harap siapkan 250 ml Air (secukupnya) dan minyak untuk menumis
1. Jangan lupa  Bumbu Halus
1. Harus ada 3 siung Bawang Merah
1. Harap siapkan 2 siung Bawang Putih
1. Tambah 7 buah Cabai Merah Keriting
1. Siapkan 2 buah Cabai Rawit Besar (skip kalau nggak pengen terlalu pedas)
1. Jangan lupa 2 cm Kunyit




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica:

1. Potong ayam sesuai yang diinginkan, cuci bersih, sisihkan
1. Cuci bersih bahan bumbu halus, haluskan (blender/uleg). Setelah halus, panaskan minyak di wajan untuk menumis, masukkan bumbu halus, daun salam, dan sereh, tumis sampai harum
1. Setelah harum, masukkan potongan ayam ke dalam tumisan, aduk rata
1. Tambahkan secukupnya air (sampai daging cukup terendam), garam, lada, penyedap, kecap manis dan gula jawa, aduk rata. Tutup dan biarkan sampai ayam matang dan kuah menyusut. Aduk sesekali sambil koreksi rasa
1. Voila! Sajikan dan siap dinikmati dengan nasi hangat




Demikianlah cara membuat ayam rica-rica yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
