---
description: "Resep : Ayam Bumbu Rujak alla Jerry MCI7 Cepat"
title: "Resep : Ayam Bumbu Rujak alla Jerry MCI7 Cepat"
slug: 484-resep-ayam-bumbu-rujak-alla-jerry-mci7-cepat
date: 2020-10-24T11:44:55.474Z
image: https://img-global.cpcdn.com/recipes/4bfe553e0e63aa13/751x532cq70/ayam-bumbu-rujak-alla-jerry-mci7-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4bfe553e0e63aa13/751x532cq70/ayam-bumbu-rujak-alla-jerry-mci7-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4bfe553e0e63aa13/751x532cq70/ayam-bumbu-rujak-alla-jerry-mci7-foto-resep-utama.jpg
author: Elmer Ortega
ratingvalue: 4.8
reviewcount: 28044
recipeingredient:
- "1 ekor ayam"
- "12 buah cabe kriting"
- "5 buah cabe rawit"
- "5 biji kemiri"
- "1 sdt ketumbar bubuk"
- "1 sdt terasi"
- "5 lembar daun jeruk"
- "3 batang sereh"
- "1 saset kara santan"
- "1 sdt asam jawa"
- "Secukupnya gula jawa"
- "Secukupnya garam"
- "Secukupnya penyedap"
recipeinstructions:
- "Potong ayam menjadi 8 bagian, atau sesuai selera"
- "Haluskan cabe kriting, rawit, kemiri, bawang merah, dan bawang putih. Bisa di blender atau di ulek"
- "Tumis bumbunya, kemudian masukan ketumbar, daun jeruk, dan sereh"
- "Kalau bumbu sudah harum tambahkan air secukupnya, kira-kira bisa merendam semua ayam"
- "Masukan ayamnya kemudian aduk rata, tambahkan garam, gula merah, terasi, asam jawa, penyedap dan santan. Jangan lupa koreksi rasa"
- "Masak ayam hingga matang, sampai bumbu mengental sempurna"
- "Jika sudah matang bisa dipangang di teflon atau agar lebih enak bisa di bara api"
- "Sambil dipanggang diolesi bumbu yang tersisa dan bisa ditambah kecap manis sesuai selera"
- "Selamat mencoba guys!!"
categories:
- Recipe
tags:
- ayam
- bumbu
- rujak

katakunci: ayam bumbu rujak 
nutrition: 288 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Bumbu Rujak alla Jerry MCI7](https://img-global.cpcdn.com/recipes/4bfe553e0e63aa13/751x532cq70/ayam-bumbu-rujak-alla-jerry-mci7-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang harus kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam bumbu rujak alla jerry mci7 yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa ciri khas yang merupakan keragaman Indonesia



Keharmonisan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Bumbu Rujak alla Jerry MCI7 untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda buat salah satunya ayam bumbu rujak alla jerry mci7 yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep ayam bumbu rujak alla jerry mci7 tanpa harus bersusah payah.
Berikut ini resep Ayam Bumbu Rujak alla Jerry MCI7 yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Bumbu Rujak alla Jerry MCI7:

1. Siapkan 1 ekor ayam
1. Harap siapkan 12 buah cabe kriting
1. Diperlukan 5 buah cabe rawit
1. Dibutuhkan 5 biji kemiri
1. Jangan lupa 1 sdt ketumbar bubuk
1. Harus ada 1 sdt terasi
1. Dibutuhkan 5 lembar daun jeruk
1. Diperlukan 3 batang sereh
1. Jangan lupa 1 saset kara (santan)
1. Dibutuhkan 1 sdt asam jawa
1. Harus ada Secukupnya gula jawa
1. Harus ada Secukupnya garam
1. Siapkan Secukupnya penyedap




<!--inarticleads2-->

##### Langkah membuat  Ayam Bumbu Rujak alla Jerry MCI7:

1. Potong ayam menjadi 8 bagian, atau sesuai selera
1. Haluskan cabe kriting, rawit, kemiri, bawang merah, dan bawang putih. Bisa di blender atau di ulek
1. Tumis bumbunya, kemudian masukan ketumbar, daun jeruk, dan sereh
1. Kalau bumbu sudah harum tambahkan air secukupnya, kira-kira bisa merendam semua ayam
1. Masukan ayamnya kemudian aduk rata, tambahkan garam, gula merah, terasi, asam jawa, penyedap dan santan. Jangan lupa koreksi rasa
1. Masak ayam hingga matang, sampai bumbu mengental sempurna
1. Jika sudah matang bisa dipangang di teflon atau agar lebih enak bisa di bara api
1. Sambil dipanggang diolesi bumbu yang tersisa dan bisa ditambah kecap manis sesuai selera
1. Selamat mencoba guys!!




Demikianlah cara membuat ayam bumbu rujak alla jerry mci7 yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
