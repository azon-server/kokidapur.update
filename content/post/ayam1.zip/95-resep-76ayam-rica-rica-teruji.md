---
description: "Resep : 76.Ayam Rica Rica Teruji"
title: "Resep : 76.Ayam Rica Rica Teruji"
slug: 95-resep-76ayam-rica-rica-teruji
date: 2020-09-29T14:29:46.669Z
image: https://img-global.cpcdn.com/recipes/d182b079ee557bbd/751x532cq70/76ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d182b079ee557bbd/751x532cq70/76ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d182b079ee557bbd/751x532cq70/76ayam-rica-rica-foto-resep-utama.jpg
author: Esther Caldwell
ratingvalue: 4.7
reviewcount: 27892
recipeingredient:
- "500 gram ayam"
- "1 ikat kemangi petik daunnya"
- "2 batang sere"
- "2 lembar daun salam"
- "1 lembar daun jeruk"
- "1/2 ruas jari lengkuas geprek"
- "5 buah cabe setan utuh"
- "1/2 buah jeruk nipis buat membalur ayam"
- "1 sdm garam"
- "1/2 sdt kaldu bubuk"
- "1/2 sdt gula pasir bisa diskip"
- "300 ml air"
- "2 sdm minyak goreng untuk menumis"
- " Bumbu Halus "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "5 buah cabe merah keriting"
- "1/2 ruas jari kunyit"
- "1 ruas jari jahe"
- "2 butir kemiri"
recipeinstructions:
- "Bersihkan ayam, lumuri jeruk nipis biarkan sebentar bilas dengan air mengalir tiriskan"
- "Cuci kemangi dan bahan2 lainnya"
- "Blender bumbu halus, pertama yang saya blend adalah kemiri dan kunyit dengan sedikit air hingga bener2 halus, saya tuang dulu ketempat lain, lanjut bawang merah, bawang putih, cabe dan jahe (me;blend kasar) tumis bumbu halus hingga harum"
- "Masukkan ayam, aduk hingga ayam berubah warna, tambahkan lengkuas geprek, sere geprek, daun salam dan daun jeruk,,, tambahkan air bumbui dengan garam, kaldu bubuk dan gula,,,"
- "Tutup ayam kecilkan api, biarkan air menyusut (jangan terlalu habis ya airnya) tes rasa bila ada yang dirasa kurang, terakhir masukkan daun kemangi,,, matikan api,,, alhamdulillaah siap jadi temen nasi hangat"
categories:
- Recipe
tags:
- 76ayam
- rica
- rica

katakunci: 76ayam rica rica 
nutrition: 143 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Dinner

---


![76.Ayam Rica Rica](https://img-global.cpcdn.com/recipes/d182b079ee557bbd/751x532cq70/76ayam-rica-rica-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti 76.ayam rica rica yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan keistimewahan yang merupakan keragaman Indonesia

Kedekatan keluarga bisa didapat dengan cara sederhana. Salah satunya adalah memasak 76.Ayam Rica Rica untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang bisa anda buat salah satunya 76.ayam rica rica yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep 76.ayam rica rica tanpa harus bersusah payah.
Berikut ini resep 76.Ayam Rica Rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 20 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat 76.Ayam Rica Rica:

1. Jangan lupa 500 gram ayam
1. Tambah 1 ikat kemangi petik daunnya
1. Diperlukan 2 batang sere
1. Dibutuhkan 2 lembar daun salam
1. Jangan lupa 1 lembar daun jeruk
1. Diperlukan 1/2 ruas jari lengkuas geprek
1. Jangan lupa 5 buah cabe setan utuh
1. Dibutuhkan 1/2 buah jeruk nipis buat membalur ayam
1. Jangan lupa 1 sdm garam
1. Harus ada 1/2 sdt kaldu bubuk
1. Harap siapkan 1/2 sdt gula pasir (bisa diskip)
1. Tambah 300 ml air
1. Jangan lupa 2 sdm minyak goreng untuk menumis
1. Siapkan  Bumbu Halus :
1. Siapkan 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Diperlukan 5 buah cabe merah keriting
1. Tambah 1/2 ruas jari kunyit
1. Jangan lupa 1 ruas jari jahe
1. Tambah 2 butir kemiri




<!--inarticleads2-->

##### Langkah membuat  76.Ayam Rica Rica:

1. Bersihkan ayam, lumuri jeruk nipis biarkan sebentar bilas dengan air mengalir tiriskan
1. Cuci kemangi dan bahan2 lainnya
1. Blender bumbu halus, pertama yang saya blend adalah kemiri dan kunyit dengan sedikit air hingga bener2 halus, saya tuang dulu ketempat lain, lanjut bawang merah, bawang putih, cabe dan jahe (me;blend kasar) tumis bumbu halus hingga harum
1. Masukkan ayam, aduk hingga ayam berubah warna, tambahkan lengkuas geprek, sere geprek, daun salam dan daun jeruk,,, tambahkan air bumbui dengan garam, kaldu bubuk dan gula,,,
1. Tutup ayam kecilkan api, biarkan air menyusut (jangan terlalu habis ya airnya) tes rasa bila ada yang dirasa kurang, terakhir masukkan daun kemangi,,, matikan api,,, alhamdulillaah siap jadi temen nasi hangat




Demikianlah cara membuat 76.ayam rica rica yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan terbukti, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
