---
description: "Resep : Ayam goreng lengkuas plus sambel lombok ijo Sempurna"
title: "Resep : Ayam goreng lengkuas plus sambel lombok ijo Sempurna"
slug: 350-resep-ayam-goreng-lengkuas-plus-sambel-lombok-ijo-sempurna
date: 2020-11-16T09:26:13.231Z
image: https://img-global.cpcdn.com/recipes/041d4a4da11c6b50/751x532cq70/ayam-goreng-lengkuas-plus-sambel-lombok-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/041d4a4da11c6b50/751x532cq70/ayam-goreng-lengkuas-plus-sambel-lombok-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/041d4a4da11c6b50/751x532cq70/ayam-goreng-lengkuas-plus-sambel-lombok-ijo-foto-resep-utama.jpg
author: Luis Green
ratingvalue: 4.6
reviewcount: 40070
recipeingredient:
- "750 gr ayam"
- "250 ml air"
- "Secukupnya minyak goreng"
- "100 gr lengkuas parutchopper"
- " Bumbu halus"
- "5 siung bawang putih"
- "3 butir kemiri"
- "1 ruas kunyit"
- "1 ruas jahe"
- " Bumbu cemplung"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "2 sdt garam"
- "2 sdt gula pasir"
- "2 sdt penyedap"
- "1 sdt merica bubuk"
- "1 sdt ketumbar bubuk"
- "1 sdt kaldu bubuk"
- " Sambel ijo"
- "5 siung bawang merah"
- "2 siung bawang putih"
- "15 cabe ijo sesuai selera"
- "Secukupnya gula jawa garam"
- " Lalapan sesuai selera"
- " Timun"
- " Tomat"
- " Kubiskol"
recipeinstructions:
- "Siapkan ayam dan bumbu. Utk lengkuas bisa diparut atau hancurkan dgn chopper. Tumis parutan lengkuas, daun salam, daun jeruk. Setelah wangi, masukkan bumbu halus. Aduk rata"
- "Masukkan ayam lalu beri air. Bumbui dgn bumbu cemplung (selain daun salam &amp; daun jeruk)"
- "Setelah mendidih tes rasa. Masak sampai air menyusut"
- "Lalu buat sambalnya. Goreng dulu bawmer bawput cabe. Lalu ulek sampai halus. Beri gula jawa dan garam secukupnya"
- "Setelah sambal jadi, goreng ayamnya. Sembari menunggu ayam matang, siapkan lalapan. Saya pake timun,tomat &amp; kubis"
- "Utk remukan lengkuasnya bisa digoreng bareng ayam atau setelah ayam ya moms. Lalu bubuhkan diatas ayam gorengnya. Sudah jadi deh ayam goreng lengkuas + sambel ijo + lalapannya ^_^"
categories:
- Recipe
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 265 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam goreng lengkuas plus sambel lombok ijo](https://img-global.cpcdn.com/recipes/041d4a4da11c6b50/751x532cq70/ayam-goreng-lengkuas-plus-sambel-lombok-ijo-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga enak. Ciri khas masakan Nusantara ayam goreng lengkuas plus sambel lombok ijo yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga bisa diperoleh dengan cara simple. Diantaranya adalah membuat makanan Ayam goreng lengkuas plus sambel lombok ijo untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang dapat anda praktekkan salah satunya ayam goreng lengkuas plus sambel lombok ijo yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep ayam goreng lengkuas plus sambel lombok ijo tanpa harus bersusah payah.
Berikut ini resep Ayam goreng lengkuas plus sambel lombok ijo yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 27 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam goreng lengkuas plus sambel lombok ijo:

1. Siapkan 750 gr ayam
1. Tambah 250 ml air
1. Tambah Secukupnya minyak goreng
1. Dibutuhkan 100 gr lengkuas (parut/chopper)
1. Dibutuhkan  Bumbu halus
1. Harap siapkan 5 siung bawang putih
1. Dibutuhkan 3 butir kemiri
1. Harus ada 1 ruas kunyit
1. Dibutuhkan 1 ruas jahe
1. Harap siapkan  Bumbu cemplung
1. Jangan lupa 2 lembar daun salam
1. Harus ada 3 lembar daun jeruk
1. Harus ada 2 sdt garam
1. Harap siapkan 2 sdt gula pasir
1. Dibutuhkan 2 sdt penyedap
1. Tambah 1 sdt merica bubuk
1. Dibutuhkan 1 sdt ketumbar bubuk
1. Harus ada 1 sdt kaldu bubuk
1. Harus ada  Sambel ijo
1. Dibutuhkan 5 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Dibutuhkan 15 cabe ijo (sesuai selera)
1. Dibutuhkan Secukupnya gula jawa, garam
1. Jangan lupa  Lalapan (sesuai selera)
1. Harus ada  Timun
1. Tambah  Tomat
1. Harus ada  Kubis/kol




<!--inarticleads2-->

##### Langkah membuat  Ayam goreng lengkuas plus sambel lombok ijo:

1. Siapkan ayam dan bumbu. Utk lengkuas bisa diparut atau hancurkan dgn chopper. Tumis parutan lengkuas, daun salam, daun jeruk. Setelah wangi, masukkan bumbu halus. Aduk rata
1. Masukkan ayam lalu beri air. Bumbui dgn bumbu cemplung (selain daun salam &amp; daun jeruk)
1. Setelah mendidih tes rasa. Masak sampai air menyusut
1. Lalu buat sambalnya. Goreng dulu bawmer bawput cabe. Lalu ulek sampai halus. Beri gula jawa dan garam secukupnya
1. Setelah sambal jadi, goreng ayamnya. Sembari menunggu ayam matang, siapkan lalapan. Saya pake timun,tomat &amp; kubis
1. Utk remukan lengkuasnya bisa digoreng bareng ayam atau setelah ayam ya moms. Lalu bubuhkan diatas ayam gorengnya. Sudah jadi deh ayam goreng lengkuas + sambel ijo + lalapannya ^_^




Demikianlah cara membuat ayam goreng lengkuas plus sambel lombok ijo yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan cepat, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
