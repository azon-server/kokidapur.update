---
description: "Cara singkat untuk menyiapakan Kepala Ayam Goreng Lengkuas Homemade"
title: "Cara singkat untuk menyiapakan Kepala Ayam Goreng Lengkuas Homemade"
slug: 461-cara-singkat-untuk-menyiapakan-kepala-ayam-goreng-lengkuas-homemade
date: 2020-08-30T06:59:47.661Z
image: https://img-global.cpcdn.com/recipes/7a1f0fdc3b19f901/751x532cq70/kepala-ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7a1f0fdc3b19f901/751x532cq70/kepala-ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7a1f0fdc3b19f901/751x532cq70/kepala-ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Beatrice Briggs
ratingvalue: 4.9
reviewcount: 1779
recipeingredient:
- "5 kepala ayam"
- "3 lembar daun jeruk"
- "secukupnya Garam"
- "secukupnya Air"
- " Minyak goreng"
- " Bumbu Haluskan"
- "3 siung bawang merah"
- "2 siung bawang putih"
- "1 ruas kecil kunyit"
- "1 ruas jahe"
- "2 butir kemiri"
- "1 ruas besar lengkuas"
- "1/2 sdm ketumbar"
recipeinstructions:
- "Siangi kepala ayam dan cuci bersih (boleh kasih perasan jeruk nipis/lemon)"
- "Haluskan bumbu (saya blender)"
- "Masukkan kepala ayam dan bumbu kedalam wajan, masukkan daun jeruk, tambahkan sedikit air, masak hingga air surut dan bumbu meresap."
- "Goreng kepala ayam dalam minyak panas dengan api sedang, jika sudah hampir matang masukkan sisa bumbu ungkep dan goreng bersama kepala ayam hingga matang secara bersamaan untuk mendapatkan tekstur crispy dari lengkuas."
categories:
- Recipe
tags:
- kepala
- ayam
- goreng

katakunci: kepala ayam goreng 
nutrition: 214 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT31M"
recipeyield: "1"
recipecategory: Lunch

---


![Kepala Ayam Goreng Lengkuas](https://img-global.cpcdn.com/recipes/7a1f0fdc3b19f901/751x532cq70/kepala-ayam-goreng-lengkuas-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti kepala ayam goreng lengkuas yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan ciri khas yang merupakan keragaman Kita

Kehangatan keluarga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Kepala Ayam Goreng Lengkuas untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang dapat anda buat salah satunya kepala ayam goreng lengkuas yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep kepala ayam goreng lengkuas tanpa harus bersusah payah.
Seperti resep Kepala Ayam Goreng Lengkuas yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kepala Ayam Goreng Lengkuas:

1. Jangan lupa 5 kepala ayam
1. Harus ada 3 lembar daun jeruk
1. Diperlukan secukupnya Garam
1. Jangan lupa secukupnya Air
1. Harus ada  Minyak goreng
1. Tambah  #Bumbu Haluskan#
1. Siapkan 3 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Harap siapkan 1 ruas kecil kunyit
1. Diperlukan 1 ruas jahe
1. Diperlukan 2 butir kemiri
1. Tambah 1 ruas besar lengkuas
1. Siapkan 1/2 sdm ketumbar




<!--inarticleads2-->

##### Cara membuat  Kepala Ayam Goreng Lengkuas:

1. Siangi kepala ayam dan cuci bersih (boleh kasih perasan jeruk nipis/lemon)
1. Haluskan bumbu (saya blender)
1. Masukkan kepala ayam dan bumbu kedalam wajan, masukkan daun jeruk, tambahkan sedikit air, masak hingga air surut dan bumbu meresap.
1. Goreng kepala ayam dalam minyak panas dengan api sedang, jika sudah hampir matang masukkan sisa bumbu ungkep dan goreng bersama kepala ayam hingga matang secara bersamaan untuk mendapatkan tekstur crispy dari lengkuas.




Demikianlah cara membuat kepala ayam goreng lengkuas yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan cepat, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
