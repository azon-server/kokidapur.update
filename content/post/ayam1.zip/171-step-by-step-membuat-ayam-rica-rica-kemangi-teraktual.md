---
description: "Step-by-Step membuat Ayam Rica-rica Kemangi teraktual"
title: "Step-by-Step membuat Ayam Rica-rica Kemangi teraktual"
slug: 171-step-by-step-membuat-ayam-rica-rica-kemangi-teraktual
date: 2020-08-14T17:57:03.088Z
image: https://img-global.cpcdn.com/recipes/2b2c178f78d8d7fb/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2b2c178f78d8d7fb/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2b2c178f78d8d7fb/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Ray Salazar
ratingvalue: 4.8
reviewcount: 34071
recipeingredient:
- "1/2 ekor ayam"
- "1/2 buah jeruk nipis"
- "1 sdt garam"
- "2 batang sereh"
- "4 lembar daun jeruk iris tipis"
- "1 lembar daun kunyit iris tipis saya skip"
- "1 buah tomat merah"
- "1 batang daun bawang"
- "1/2 ikat daun kemangi"
- "Secukupnya air"
- " Bumbu halus"
- "4 buah cabe merah keriting"
- "8 buah cabe rawit merah"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "4 butir kemiri"
- "2 ruas jari kunyit"
- "2 ruas jari lengkuas"
- "1 ruas jari jahe"
- "Secukupnya minyak goreng"
- " Bumbubumbu lain"
- "1 sdm gula pasir"
- "1 sdm garam"
- "1 sdt penyedap rasa"
- "1/2 sdt lada bubuk"
recipeinstructions:
- "Cuci bersih ayam, lumuri dengan air perasan jeruk nipis dan garam, diamkan sekitar 30 menit."
- "Potong-potong bahan bumbu halus, lalu blend dengan minyak hingga halus. Jahe dan lengkuas saya blend juga tidak digeprek, supaya tidak ikut dikira daging ayam saat dimakan wkwk."
- "Masukkan bumbu kedalam wajan, lalu masak sebentar hingga minyaknya keluar."
- "Masukkan sereh dan irisan daun jeruk. Tumis hingga harum."
- "Lalu masukkan ayam, beri air secukupnya. Masukkan gula, garam, lada, penyedap. Tes rasa. Tutup wajan lalu masak dengan api kecil hingga air menyusut."
- "Setelah air menyusut, masukkan berurutan : potongan cabe rawit (optional), tomat dan daun bawang, terakhir masukkan daun kemangi sesaat sebelum diangkat."
- "Aduk hingga rata dan air semakin menyusut. Siap dihidangkan. Selamat mencoba 😉"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 192 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/2b2c178f78d8d7fb/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang dapat kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica-rica kemangi yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa keistimewahan yang merupakan keragaman Kita

Kedekatan keluarga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica-rica Kemangi untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang dapat anda buat salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 25 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Kemangi:

1. Tambah 1/2 ekor ayam
1. Jangan lupa 1/2 buah jeruk nipis
1. Jangan lupa 1 sdt garam
1. Siapkan 2 batang sereh
1. Siapkan 4 lembar daun jeruk iris tipis
1. Harus ada 1 lembar daun kunyit iris tipis (saya skip)
1. Harus ada 1 buah tomat merah
1. Jangan lupa 1 batang daun bawang
1. Siapkan 1/2 ikat daun kemangi
1. Dibutuhkan Secukupnya air
1. Siapkan  Bumbu halus
1. Diperlukan 4 buah cabe merah keriting
1. Tambah 8 buah cabe rawit merah
1. Harus ada 8 siung bawang merah
1. Dibutuhkan 4 siung bawang putih
1. Harap siapkan 4 butir kemiri
1. Diperlukan 2 ruas jari kunyit
1. Diperlukan 2 ruas jari lengkuas
1. Tambah 1 ruas jari jahe
1. Harus ada Secukupnya minyak goreng
1. Jangan lupa  Bumbu-bumbu lain
1. Harus ada 1 sdm gula pasir
1. Dibutuhkan 1 sdm garam
1. Diperlukan 1 sdt penyedap rasa
1. Harap siapkan 1/2 sdt lada bubuk




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-rica Kemangi:

1. Cuci bersih ayam, lumuri dengan air perasan jeruk nipis dan garam, diamkan sekitar 30 menit.
1. Potong-potong bahan bumbu halus, lalu blend dengan minyak hingga halus. Jahe dan lengkuas saya blend juga tidak digeprek, supaya tidak ikut dikira daging ayam saat dimakan wkwk.
1. Masukkan bumbu kedalam wajan, lalu masak sebentar hingga minyaknya keluar.
1. Masukkan sereh dan irisan daun jeruk. Tumis hingga harum.
1. Lalu masukkan ayam, beri air secukupnya. Masukkan gula, garam, lada, penyedap. Tes rasa. Tutup wajan lalu masak dengan api kecil hingga air menyusut.
1. Setelah air menyusut, masukkan berurutan : potongan cabe rawit (optional), tomat dan daun bawang, terakhir masukkan daun kemangi sesaat sebelum diangkat.
1. Aduk hingga rata dan air semakin menyusut. Siap dihidangkan. Selamat mencoba 😉




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan cepat, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
