---
description: "Resep : Ayam goreng ala kfc Cepat"
title: "Resep : Ayam goreng ala kfc Cepat"
slug: 305-resep-ayam-goreng-ala-kfc-cepat
date: 2020-08-07T03:47:57.940Z
image: https://img-global.cpcdn.com/recipes/cf087ad247706be8/751x532cq70/ayam-goreng-ala-kfc-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cf087ad247706be8/751x532cq70/ayam-goreng-ala-kfc-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cf087ad247706be8/751x532cq70/ayam-goreng-ala-kfc-foto-resep-utama.jpg
author: Annie Stewart
ratingvalue: 4.3
reviewcount: 31197
recipeingredient:
- " Marinasi"
- "1/2 kg ayam"
- "500 ml air"
- "1 Sdm royco"
- "1/2 sdt garam"
- "1/2 jeruk nipis ukuran sedang"
- " Bumbu basah"
- "5 bawang putih"
- "1 ruas jahe"
- "1/2 sachet susu dancow"
- "1 sdt royco atau diganti dg 1 sdm knor 1 sdt vetsin"
- " Bumbu kering"
- "400 gram terigu cakra"
- "100 gr maezena"
- "2 sdm royco"
- "1 sdm garam"
- "1 sdt mrica bubuk"
- "1 sdt soda kue"
- "1 sdt bp"
- " Semangkuk air es"
recipeinstructions:
- "Campur bahan marinasi jd 1, masukkn kedalam plastik, ikat, diamkan di kulkas 24 jam"
- "Ambil ayam marinasi taruh dimangkok,tambahkn bumbu basah, dicampur, sampai rata, diamkan dikulkas sebentar"
- "Campur bumbu kering samai rata"
- "Siapkan semangkuk air es"
- "Panaskan minyak agak banyak, biar ayam ga nempel dibawah...klo sudah panas kecilkan api, goreng ayam....dg cara...masukkan ayam ke bahan kering kering, kemangkuk es, ke bahan kering lagi, goreng sampai matang kekuningan dalam minyak panas dan api kecil"
categories:
- Recipe
tags:
- ayam
- goreng
- ala

katakunci: ayam goreng ala 
nutrition: 251 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam goreng ala kfc](https://img-global.cpcdn.com/recipes/cf087ad247706be8/751x532cq70/ayam-goreng-ala-kfc-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam goreng ala kfc yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan keistimewahan yang merupakan keragaman Nusantara

Kehangatan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah memasak Ayam goreng ala kfc untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang bisa anda contoh salah satunya ayam goreng ala kfc yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep ayam goreng ala kfc tanpa harus bersusah payah.
Seperti resep Ayam goreng ala kfc yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 20 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam goreng ala kfc:

1. Jangan lupa  Marinasi
1. Jangan lupa 1/2 kg ayam
1. Harap siapkan 500 ml air
1. Siapkan 1 Sdm royco
1. Tambah 1/2 sdt garam
1. Jangan lupa 1/2 jeruk nipis ukuran sedang
1. Jangan lupa  Bumbu basah
1. Siapkan 5 bawang putih
1. Dibutuhkan 1 ruas jahe
1. Harap siapkan 1/2 sachet susu dancow
1. Jangan lupa 1 sdt royco (atau diganti dg 1 sdm knor+ 1 sdt vetsin)
1. Tambah  Bumbu kering
1. Siapkan 400 gram terigu cakra
1. Dibutuhkan 100 gr maezena
1. Siapkan 2 sdm royco
1. Jangan lupa 1 sdm garam
1. Diperlukan 1 sdt mrica bubuk
1. Tambah 1 sdt soda kue
1. Diperlukan 1 sdt bp
1. Jangan lupa  Semangkuk air es




<!--inarticleads2-->

##### Cara membuat  Ayam goreng ala kfc:

1. Campur bahan marinasi jd 1, masukkn kedalam plastik, ikat, diamkan di kulkas 24 jam
1. Ambil ayam marinasi taruh dimangkok,tambahkn bumbu basah, dicampur, sampai rata, diamkan dikulkas sebentar
1. Campur bumbu kering samai rata
1. Siapkan semangkuk air es
1. Panaskan minyak agak banyak, biar ayam ga nempel dibawah...klo sudah panas kecilkan api, goreng ayam....dg cara...masukkan ayam ke bahan kering kering, kemangkuk es, ke bahan kering lagi, goreng sampai matang kekuningan dalam minyak panas dan api kecil




Demikianlah cara membuat ayam goreng ala kfc yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan terbukti, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
