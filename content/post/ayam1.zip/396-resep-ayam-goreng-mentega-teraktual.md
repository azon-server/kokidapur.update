---
description: "Resep : Ayam Goreng Mentega teraktual"
title: "Resep : Ayam Goreng Mentega teraktual"
slug: 396-resep-ayam-goreng-mentega-teraktual
date: 2020-11-11T11:26:26.821Z
image: https://img-global.cpcdn.com/recipes/0d97a0251c54c642/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0d97a0251c54c642/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0d97a0251c54c642/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg
author: Harold Romero
ratingvalue: 4.6
reviewcount: 32899
recipeingredient:
- "1 ekor ayam negri potong 8"
- "1,5 buah jeruk nipis lemon"
- "1 Sdm kecap hitam premium premium dark soy sauce"
- " Bumbu Tumis "
- "3 Sdm mentega"
- "3 siung bawang Putih"
- "3 iris jahe"
- "1 buah bawang bombay besar"
- "1/2-1 Sdm kecap hitam premium"
- "5 Sdm kecap manis"
- "1/2 sdt Merica"
- "1/2 Sdt Kaldu jamur"
- "secukupnya garam"
- "secukupnya gula"
recipeinstructions:
- "Bersihkan Ayam, sayat-sayat, beri perasan jeruk 1/2 buah dan garam (kalau ada garam krosak), cuci gosok ayam agar lendir hilang lalu bilas."
- "Setelah ayam bersih, beri 3/4 perasan jeruk nipis dan kecap asin dark soy sauce 1 sdm. Diamkan kurang lebih 1 jam dalam kulkas (chiller)"
- "Goreng ayam dengan minyak banyak dan api sedang-besar hingga kering"
- "Tumis bawang putih, bawang bombay setengah dan jahe dengan mentega hingga harum. Masukkan kecap, dan bumbu lainnya, aduk rata. Masukkan ayam, beri perasan 1/4 buah jeruk nipis, masak dengan api kecil hingga kuah menyusut dan bumbu meresap. Setengah matang Masukkan sisa bombay. Masak hingga kuah mengental. Sajikan"
categories:
- Recipe
tags:
- ayam
- goreng
- mentega

katakunci: ayam goreng mentega 
nutrition: 238 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Goreng Mentega](https://img-global.cpcdn.com/recipes/0d97a0251c54c642/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang setidaknya kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam goreng mentega yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa keistimewahan yang merupakan keragaman Indonesia



Keharmonisan rumah tangga bisa didapat dengan cara sederhana. Diantaranya adalah memasak Ayam Goreng Mentega untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang dapat anda coba salah satunya ayam goreng mentega yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep ayam goreng mentega tanpa harus bersusah payah.
Seperti resep Ayam Goreng Mentega yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 14 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Mentega:

1. Jangan lupa 1 ekor ayam negri, potong 8
1. Harap siapkan 1,5 buah jeruk nipis/ lemon
1. Diperlukan 1 Sdm kecap hitam premium (premium dark soy sauce)
1. Tambah  Bumbu Tumis :
1. Dibutuhkan 3 Sdm mentega
1. Jangan lupa 3 siung bawang Putih
1. Harap siapkan 3 iris jahe
1. Tambah 1 buah bawang bombay besar
1. Tambah 1/2-1 Sdm kecap hitam premium
1. Siapkan 5 Sdm kecap manis
1. Harus ada 1/2 sdt Merica
1. Dibutuhkan 1/2 Sdt Kaldu jamur
1. Diperlukan secukupnya garam
1. Harus ada secukupnya gula




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Mentega:

1. Bersihkan Ayam, sayat-sayat, beri perasan jeruk 1/2 buah dan garam (kalau ada garam krosak), cuci gosok ayam agar lendir hilang lalu bilas.
1. Setelah ayam bersih, beri 3/4 perasan jeruk nipis dan kecap asin dark soy sauce 1 sdm. Diamkan kurang lebih 1 jam dalam kulkas (chiller)
1. Goreng ayam dengan minyak banyak dan api sedang-besar hingga kering
1. Tumis bawang putih, bawang bombay setengah dan jahe dengan mentega hingga harum. Masukkan kecap, dan bumbu lainnya, aduk rata. Masukkan ayam, beri perasan 1/4 buah jeruk nipis, masak dengan api kecil hingga kuah menyusut dan bumbu meresap. Setengah matang Masukkan sisa bombay. Masak hingga kuah mengental. Sajikan




Demikianlah cara membuat ayam goreng mentega yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan terbukti, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
