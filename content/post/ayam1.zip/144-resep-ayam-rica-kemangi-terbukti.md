---
description: "Resep : Ayam Rica Kemangi Terbukti"
title: "Resep : Ayam Rica Kemangi Terbukti"
slug: 144-resep-ayam-rica-kemangi-terbukti
date: 2020-09-14T15:20:00.711Z
image: https://img-global.cpcdn.com/recipes/e1712c41e44b44ec/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e1712c41e44b44ec/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e1712c41e44b44ec/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Jennie McDonald
ratingvalue: 4.6
reviewcount: 46246
recipeingredient:
- "1/2 ekor ayam"
- " Bumbu halus"
- "3 cabe merah besar"
- "15 cabe rawit"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "2 butir kemiri"
- "1/2 ruas jari jahe"
- "1/4 ruas jari kunyit"
- " Bumbu Pelengkap"
- "2 batang sereh memarkan"
- "1 ruas jari lengkuas memarkan"
- "1/4 keping gula merah"
- "secukupnya Garam gula pasir penyedap rasa"
- "secukupnya Air"
- "1/2 ikat kemangi"
recipeinstructions:
- "Bersihkan ayam. Sisihkan"
- "Uleg bumbu halus. Lalu tumis hingga harum. Masukkan bumbu pelengkap kecuali kemangi. Lalu masukkan ayam. Aduk aduk hingga bumbu rata. Masukkan air sedikit."
- "Tutup ayam hingga air menyusut. Test rasa. Kalo sudah pas masukkan kemangi. Aduk aduk kembali. &amp; ayam Rica kemangi siap disantap. Rasanya muantaap ciiin.. 😁😁😁"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 242 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/e1712c41e44b44ec/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga enak. Karasteristik makanan Indonesia ayam rica kemangi yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.


Keharmonisan keluarga dapat didapat dengan cara simple. Salah satunya adalah memasak Ayam Rica Kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang dapat anda praktekkan salah satunya ayam rica kemangi yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 16 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Tambah 1/2 ekor ayam
1. Diperlukan  Bumbu halus
1. Harus ada 3 cabe merah besar
1. Harus ada 15 cabe rawit
1. Siapkan 5 siung bawang merah
1. Diperlukan 3 siung bawang putih
1. Dibutuhkan 2 butir kemiri
1. Tambah 1/2 ruas jari jahe
1. Tambah 1/4 ruas jari kunyit
1. Siapkan  Bumbu Pelengkap
1. Tambah 2 batang sereh memarkan
1. Jangan lupa 1 ruas jari lengkuas memarkan
1. Tambah 1/4 keping gula merah
1. Dibutuhkan secukupnya Garam, gula pasir, penyedap rasa
1. Diperlukan secukupnya Air
1. Jangan lupa 1/2 ikat kemangi




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Kemangi:

1. Bersihkan ayam. Sisihkan
1. Uleg bumbu halus. Lalu tumis hingga harum. Masukkan bumbu pelengkap kecuali kemangi. Lalu masukkan ayam. Aduk aduk hingga bumbu rata. Masukkan air sedikit.
1. Tutup ayam hingga air menyusut. Test rasa. Kalo sudah pas masukkan kemangi. Aduk aduk kembali. &amp; ayam Rica kemangi siap disantap. Rasanya muantaap ciiin.. 😁😁😁




Demikianlah cara membuat ayam rica kemangi yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
