---
description: "Bagaimana untuk menyiapakan Ayam Goreng Cabe Ijo minggu ini"
title: "Bagaimana untuk menyiapakan Ayam Goreng Cabe Ijo minggu ini"
slug: 415-bagaimana-untuk-menyiapakan-ayam-goreng-cabe-ijo-minggu-ini
date: 2020-11-07T14:41:08.742Z
image: https://img-global.cpcdn.com/recipes/7e508495a88dfd6b/751x532cq70/ayam-goreng-cabe-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7e508495a88dfd6b/751x532cq70/ayam-goreng-cabe-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7e508495a88dfd6b/751x532cq70/ayam-goreng-cabe-ijo-foto-resep-utama.jpg
author: Virgie Marsh
ratingvalue: 4.9
reviewcount: 11728
recipeingredient:
- "1 kg paha ayam dan dada"
- " Bumbu ungkep ayam blender"
- "4 bawang putih"
- "2 bawang merah"
- "3 ruas jahe"
- "3 ruas lengkuas"
- "2 batang daun jeruk"
- "50 ml Minyak"
- " Sambal Cabe ijo"
- "5 cabe ijo besar"
- "6 cabe rawit ijo"
- "1 tomat ijo"
- "5 bawang merah"
- " Pelengkap"
- " Daun jeruk"
- " Royco sapi"
- " Garam"
- " Masako ayam"
- " Ladaku"
recipeinstructions:
- "Blender semua bumbu ungkep, pakai minyak ya jangan pakai air karena lebih enak. Masukkan bumbu ke ayam, garam, masako dan ladaku lalu ungkep kurang lebih 14 menit atau seharian didalam kulkas ya supaya bumbu lebih meresap. Lalu goreng ayam sesuai selera. Kalau saya sedikit kering"
- "Rebus bumbu cabe ijo selama 5 menit. Lalu blender kasar semua bumbu beserta 1/2 air rebusan"
- "Bumbu yang sudah di blender lalu ditumis tanpa minyak untuk mengeluarkan semua airnya. Setelah air menyusut, baru masukan minyak dan daun jeruk. Beri garam, ladaku, royco sapi. Kalau saya suka tipe sambal yang sedikit kering."
- "Setelah sambal jadi, masukkan ayam goreng. Aduk hingga merata. Sudah selesai, selamat mencoba 🤍"
categories:
- Recipe
tags:
- ayam
- goreng
- cabe

katakunci: ayam goreng cabe 
nutrition: 295 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Goreng Cabe Ijo](https://img-global.cpcdn.com/recipes/7e508495a88dfd6b/751x532cq70/ayam-goreng-cabe-ijo-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau enak. Ciri kuliner Nusantara ayam goreng cabe ijo yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga dapat diperoleh dengan cara simple. Diantaranya adalah membuat makanan Ayam Goreng Cabe Ijo untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang dapat anda buat salah satunya ayam goreng cabe ijo yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep ayam goreng cabe ijo tanpa harus bersusah payah.
Berikut ini resep Ayam Goreng Cabe Ijo yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 19 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Cabe Ijo:

1. Tambah 1 kg paha ayam dan dada
1. Siapkan  Bumbu ungkep ayam blender
1. Jangan lupa 4 bawang putih
1. Tambah 2 bawang merah
1. Tambah 3 ruas jahe
1. Siapkan 3 ruas lengkuas
1. Tambah 2 batang daun jeruk
1. Harap siapkan 50 ml Minyak
1. Diperlukan  Sambal Cabe ijo
1. Jangan lupa 5 cabe ijo besar
1. Diperlukan 6 cabe rawit ijo
1. Diperlukan 1 tomat ijo
1. Harap siapkan 5 bawang merah
1. Jangan lupa  Pelengkap
1. Siapkan  Daun jeruk
1. Diperlukan  Royco sapi
1. Harap siapkan  Garam
1. Harap siapkan  Masako ayam
1. Siapkan  Ladaku




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Goreng Cabe Ijo:

1. Blender semua bumbu ungkep, pakai minyak ya jangan pakai air karena lebih enak. Masukkan bumbu ke ayam, garam, masako dan ladaku lalu ungkep kurang lebih 14 menit atau seharian didalam kulkas ya supaya bumbu lebih meresap. Lalu goreng ayam sesuai selera. Kalau saya sedikit kering
1. Rebus bumbu cabe ijo selama 5 menit. Lalu blender kasar semua bumbu beserta 1/2 air rebusan
1. Bumbu yang sudah di blender lalu ditumis tanpa minyak untuk mengeluarkan semua airnya. Setelah air menyusut, baru masukan minyak dan daun jeruk. Beri garam, ladaku, royco sapi. Kalau saya suka tipe sambal yang sedikit kering.
1. Setelah sambal jadi, masukkan ayam goreng. Aduk hingga merata. Sudah selesai, selamat mencoba 🤍




Demikianlah cara membuat ayam goreng cabe ijo yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
