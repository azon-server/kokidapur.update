---
description: "Resep : Ayam rica-rica pedas Luar biasa"
title: "Resep : Ayam rica-rica pedas Luar biasa"
slug: 123-resep-ayam-rica-rica-pedas-luar-biasa
date: 2020-10-04T19:26:25.863Z
image: https://img-global.cpcdn.com/recipes/f6f391e6b2cf0b5c/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f6f391e6b2cf0b5c/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f6f391e6b2cf0b5c/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
author: Genevieve Cross
ratingvalue: 4.2
reviewcount: 40003
recipeingredient:
- "300 gram ayam saya pakai bagian sayap dan dada"
- "secukupnya perasan jeruk nipis"
- "secukupnya merica dan garam"
- " Bahan bumbu halus"
- "7 siung bawang merah ukuran besar"
- "5 siung bawang putih"
- "10 buah cabai merah keriting"
- "5 buah cabai rawit merah"
- "2 butir kemiri"
- "2 ruas jari jahe"
- "secukupnya merica"
- "secukupnya garam"
- "secukupnya gula pasir"
- "secukupnya penyedap rasa"
- " Bahan tumisan"
- "secukupnya minyak goreng"
- "1 lembar daun salam"
- "2 lembar daun jeruk"
- "2 ruas jari lengkuas"
- " Bahan tambahan"
- "irisan daun bawang"
- " bawang goreng"
recipeinstructions:
- "Lumuri ayam dengan perasan jeruk nipis, taburi garam, dan diamkan 15 menit. Lalu goreng ayam hingga berwarna kuning keemasan."
- "Haluskan semua bahan bumbu halus. Lalu tumis dengan semua bahan tumisan hingga harum. Tambahkan air, masukkan ayam goreng, aduk hingga rata. koreksi rasa."
- "Masak hingga asat dan bumbu menyerap kedalam ayam. Sajikan dengan taburan bawang goreng dan juga irisan daun bawang. Ayam rica rica pedas siap disantapp❤️✨"
categories:
- Recipe
tags:
- ayam
- ricarica
- pedas

katakunci: ayam ricarica pedas 
nutrition: 300 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT36M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam rica-rica pedas](https://img-global.cpcdn.com/recipes/f6f391e6b2cf0b5c/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita jaga karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica-rica pedas yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara

Lihat juga resep Ayam Rica Kemangi (resep mertua ❤) enak lainnya. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica. Rasa pedas, gurih dan empuk daging ayamnya terbukti sangat cocok disajikan bersama nasi dalam.

Keharmonisan keluarga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Ayam rica-rica pedas untuk keluarga. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang bisa anda praktekkan salah satunya ayam rica-rica pedas yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep ayam rica-rica pedas tanpa harus bersusah payah.
Seperti resep Ayam rica-rica pedas yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 22 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica pedas:

1. Jangan lupa 300 gram ayam (saya pakai bagian sayap dan dada)
1. Siapkan secukupnya perasan jeruk nipis
1. Jangan lupa secukupnya merica dan garam
1. Jangan lupa  Bahan bumbu halus
1. Jangan lupa 7 siung bawang merah ukuran besar
1. Diperlukan 5 siung bawang putih
1. Dibutuhkan 10 buah cabai merah keriting
1. Dibutuhkan 5 buah cabai rawit merah
1. Harap siapkan 2 butir kemiri
1. Siapkan 2 ruas jari jahe
1. Tambah secukupnya merica
1. Siapkan secukupnya garam
1. Diperlukan secukupnya gula pasir
1. Harus ada secukupnya penyedap rasa
1. Harus ada  Bahan tumisan
1. Tambah secukupnya minyak goreng
1. Harap siapkan 1 lembar daun salam
1. Diperlukan 2 lembar daun jeruk
1. Diperlukan 2 ruas jari lengkuas
1. Diperlukan  Bahan tambahan
1. Diperlukan irisan daun bawang
1. Jangan lupa  bawang goreng


Atau punya koleksi foto makanan yang berbahan dasar Daging Ayam juga, share dong fotonya di kolom komentar. Bahan bumbu ayam rica rica yang digunakan sebenarnya cukup simple dan sederhana, seperti : kunyit, jahe, serai, cabai merah, bawang putih, dan beberapa bumbu lainnya. Inilah bumbu rica rica selengkapnya. selengkapnya silahkan dilihat dalam Aplikasi resep ayam rica rica seafood berikut ini. Ayam rica-rica ini di berikan bumbu khas indonesia yang pastinya akan memberikan cita rasa yang sangat nikmat bagi penggila pedas. 

<!--inarticleads2-->

##### Cara membuat  Ayam rica-rica pedas:

1. Lumuri ayam dengan perasan jeruk nipis, taburi garam, dan diamkan 15 menit. Lalu goreng ayam hingga berwarna kuning keemasan.
1. Haluskan semua bahan bumbu halus. Lalu tumis dengan semua bahan tumisan hingga harum. Tambahkan air, masukkan ayam goreng, aduk hingga rata. koreksi rasa.
1. Masak hingga asat dan bumbu menyerap kedalam ayam. Sajikan dengan taburan bawang goreng dan juga irisan daun bawang. Ayam rica rica pedas siap disantapp❤️✨


Inilah bumbu rica rica selengkapnya. selengkapnya silahkan dilihat dalam Aplikasi resep ayam rica rica seafood berikut ini. Ayam rica-rica ini di berikan bumbu khas indonesia yang pastinya akan memberikan cita rasa yang sangat nikmat bagi penggila pedas. Nah buat anda yang suka sekali dengan masakan yang pedas-pedas maka resep yang satu ini adalah pilihannya. Resep Ayam Rica - Rica Pedas Enak dan Spesial Untuk Keluarga - Asal muasal dari resep ayam rica-rica ini berasal dari daerah Manado - Sul. Ayam rica-rica merupakan salah satu masakan khas Manado, Sulawesi Utara, yang terkenal dengan cita rasa pedasnya. 

Demikianlah cara membuat ayam rica-rica pedas yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
