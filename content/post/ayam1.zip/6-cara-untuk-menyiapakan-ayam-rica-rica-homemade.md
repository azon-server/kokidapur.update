---
description: "Cara untuk menyiapakan Ayam rica rica Homemade"
title: "Cara untuk menyiapakan Ayam rica rica Homemade"
slug: 6-cara-untuk-menyiapakan-ayam-rica-rica-homemade
date: 2020-11-14T19:56:27.491Z
image: https://img-global.cpcdn.com/recipes/881d8955290939a2/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/881d8955290939a2/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/881d8955290939a2/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Rena Cunningham
ratingvalue: 4.3
reviewcount: 48772
recipeingredient:
- "1/2 kg ayam"
- "1 Iket kemangi"
- " Bumbu ulek"
- " 5 buah bawang merah"
- "2 buah bawang putih"
- "5 buah cabe merah besar"
- "2 buah kemiri sangrai"
- " Jahe"
- " Bumbu geprekcemplung"
- " Lengkuasserehdaun salamdaun jeruk"
- " Garamgulpaspenyedap"
recipeinstructions:
- "Cuci bersih ayam, marinasi dengan garam dan kunyit bubuk,diamkan 10 menit,sambil kita siapkan bumbu bumbu"
- "Goreng ayam setengah matang,angkat tiriskan"
- "Ulek bumbu halus, lalu tumis hingga harum,tambahkan daun salam,daun jeruk,salam,sereh,lengkuas, garam,gula, penyedap"
- "Kemudian masukin ayam, beri sedikit air,aduk rata masak hingga air menyusut"
- "Kemudian masukan daun kemangi,aduk rata lalu angkat dan hidangkan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 227 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam rica rica](https://img-global.cpcdn.com/recipes/881d8955290939a2/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga enak. Ciri makanan Indonesia ayam rica rica yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam rica rica untuk orang di rumah. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang dapat anda praktekkan salah satunya ayam rica rica yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan cepat menemukan resep ayam rica rica tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 11 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica:

1. Jangan lupa 1/2 kg ayam
1. Diperlukan 1 Iket kemangi
1. Siapkan  Bumbu ulek
1. Harap siapkan  5 buah bawang merah
1. Siapkan 2 buah bawang putih
1. Siapkan 5 buah cabe merah besar
1. Diperlukan 2 buah kemiri sangrai
1. Tambah  Jahe
1. Tambah  Bumbu geprek/cemplung
1. Tambah  Lengkuas,sereh,daun salam,daun jeruk
1. Tambah  Garam,gulpas,penyedap




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica rica:

1. Cuci bersih ayam, marinasi dengan garam dan kunyit bubuk,diamkan 10 menit,sambil kita siapkan bumbu bumbu
1. Goreng ayam setengah matang,angkat tiriskan
1. Ulek bumbu halus, lalu tumis hingga harum,tambahkan daun salam,daun jeruk,salam,sereh,lengkuas, garam,gula, penyedap
1. Kemudian masukin ayam, beri sedikit air,aduk rata masak hingga air menyusut
1. Kemudian masukan daun kemangi,aduk rata lalu angkat dan hidangkan




Demikianlah cara membuat ayam rica rica yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
