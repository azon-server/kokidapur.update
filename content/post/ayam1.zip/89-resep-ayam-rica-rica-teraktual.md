---
description: "Resep : Ayam rica -rica teraktual"
title: "Resep : Ayam rica -rica teraktual"
slug: 89-resep-ayam-rica-rica-teraktual
date: 2020-08-26T11:54:37.293Z
image: https://img-global.cpcdn.com/recipes/a314336f5dc3e6cc/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a314336f5dc3e6cc/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a314336f5dc3e6cc/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Chad Vega
ratingvalue: 4
reviewcount: 34296
recipeingredient:
- "1 ekor ayam ukran sedangpotong 10"
- "400 ml Air"
- "2 lembar daun jeruk buang tulang daun biar wangi di sobek"
- "3 ikat kemangi"
- "2 btg serai"
- "1 cm lengkuas"
- "1 cm jahe"
- "1 sdt kaldu jamur"
- " Bumbu Halus"
- "9 buah cabe merah keriting"
- "5 buah cabe rawit option saja"
- "7 siung bawang merah"
- "5 siung bawang putih"
- "4 butir kemiri"
- "1 cm kunyit"
recipeinstructions:
- "Tumis bumbu halus, daun jeruk, serei, daun salam, lengkuas, dan jahe sampai masak.  Lalu tambahkan ayam, aduk-aduk rata sampai tercampur"
- "Tambahkan air, kaldu jamur dan garam secukupnya. masak sampai airnya tinggal sedikit.. Kalau sudah dikit airnya, masukkan kemangi..(Yang kemangi masaknya g usah lembek)"
- "Siap disantap, bisa khilaf memang ini. Aku kurangi cabenya karena biar anak-anak bisa ikutan menikmati"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 164 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT54M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica -rica](https://img-global.cpcdn.com/recipes/a314336f5dc3e6cc/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang patut kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica -rica yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa ciri khas yang merupakan keragaman Kita

Kedekatan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah memasak Ayam rica -rica untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang bisa anda contoh salah satunya ayam rica -rica yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep ayam rica -rica tanpa harus bersusah payah.
Seperti resep Ayam rica -rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 15 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica -rica:

1. Diperlukan 1 ekor ayam ukran sedang(potong 10)
1. Siapkan 400 ml Air
1. Jangan lupa 2 lembar daun jeruk (buang tulang daun, biar wangi di sobek)
1. Harap siapkan 3 ikat kemangi
1. Diperlukan 2 btg serai
1. Jangan lupa 1 cm lengkuas
1. Harap siapkan 1 cm jahe
1. Jangan lupa 1 sdt kaldu jamur
1. Siapkan  Bumbu Halus
1. Dibutuhkan 9 buah cabe merah keriting
1. Diperlukan 5 buah cabe rawit (option saja)
1. Dibutuhkan 7 siung bawang merah
1. Siapkan 5 siung bawang putih
1. Dibutuhkan 4 butir kemiri
1. Tambah 1 cm kunyit




<!--inarticleads2-->

##### Cara membuat  Ayam rica -rica:

1. Tumis bumbu halus, daun jeruk, serei, daun salam, lengkuas, dan jahe sampai masak.  - Lalu tambahkan ayam, aduk-aduk rata sampai tercampur
1. Tambahkan air, kaldu jamur dan garam secukupnya. - masak sampai airnya tinggal sedikit.. - Kalau sudah dikit airnya, masukkan kemangi..(Yang kemangi masaknya g usah lembek)
1. Siap disantap, bisa khilaf memang ini. Aku kurangi cabenya karena biar anak-anak bisa ikutan menikmati




Demikianlah cara membuat ayam rica -rica yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
