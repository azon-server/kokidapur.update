---
description: "Panduan untuk menyiapakan Ayam Rica Kemangi Cepat"
title: "Panduan untuk menyiapakan Ayam Rica Kemangi Cepat"
slug: 156-panduan-untuk-menyiapakan-ayam-rica-kemangi-cepat
date: 2020-10-09T11:03:25.079Z
image: https://img-global.cpcdn.com/recipes/5b512e02c7c8e3b0/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5b512e02c7c8e3b0/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5b512e02c7c8e3b0/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Connor Welch
ratingvalue: 5
reviewcount: 45459
recipeingredient:
- " Bahan utama"
- "10 potong ayam"
- "1 buah lemon untuk marinasi"
- "1 ikat kemangi petik daunnya"
- " Bahan yang dihaluskandirajang"
- "6 siung bawang merah"
- "1 siung bawang putih"
- "5 buah cabe merah atau tambah rawit bila suka pedas"
- "1 cm jahe"
- "3 cm kunyit"
- "1 batang sereh memarkan"
- "2 lembar daun salam"
- "3 lembar daun jeruk iris2"
recipeinstructions:
- "Bersihkan ayam. Lumuri dengan perasan jeruk nipis. Simpan di kulkas selama 15 menit. Petik daun kemangi, sisinkan."
- "Siapkan bumbu yg akan dihaluskan/diiris."
- "Haluskan bawang, kunyit, jahe, cabe, dengan ulekan atau blender. Iris daun jeruk, memarkan sereh. Sisihkan bersama daun salam."
- "Siapkan minyak panas di wajan. Tumis bumbu halus hingga harum. Kemudian masukkan daun salam, daun jeruj,.dan sereh. Lanjutkan tumis sampai harum/matang."
- "Masukkan potongan ayam, aduk2 masak hingga kira2 dagingnya sudah tidak terlihat merah atau bumbu meresap. Beri air secukupnya. Tambakan garam dan gula pasir. Test rasa. Tutup wajan dan masak sampai kuah ayam sedikit mengering/meresap dan dagingnya empuk."
- "Setelah daging empuk dan rasa sudah oke, masukkan daun kemangi, aduk2 sebentar, lalu matikan kompor."
- "Ayam Rica Kemangi siap dinikmati."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 176 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/5b512e02c7c8e3b0/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica kemangi yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa kesan tersendiri yang merupakan keragaman Nusantara

Keharmonisan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica Kemangi untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang dapat anda contoh salah satunya ayam rica kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Harus ada  Bahan utama
1. Tambah 10 potong ayam
1. Jangan lupa 1 buah lemon untuk marinasi
1. Tambah 1 ikat kemangi, petik daunnya
1. Siapkan  Bahan yang dihaluskan/dirajang
1. Tambah 6 siung bawang merah
1. Diperlukan 1 siung bawang putih
1. Diperlukan 5 buah cabe merah, atau tambah rawit bila suka pedas
1. Dibutuhkan 1 cm jahe
1. Tambah 3 cm kunyit
1. Diperlukan 1 batang sereh, memarkan
1. Harus ada 2 lembar daun salam
1. Jangan lupa 3 lembar daun jeruk, iris2




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Kemangi:

1. Bersihkan ayam. Lumuri dengan perasan jeruk nipis. Simpan di kulkas selama 15 menit. Petik daun kemangi, sisinkan.
1. Siapkan bumbu yg akan dihaluskan/diiris.
1. Haluskan bawang, kunyit, jahe, cabe, dengan ulekan atau blender. Iris daun jeruk, memarkan sereh. Sisihkan bersama daun salam.
1. Siapkan minyak panas di wajan. Tumis bumbu halus hingga harum. Kemudian masukkan daun salam, daun jeruj,.dan sereh. Lanjutkan tumis sampai harum/matang.
1. Masukkan potongan ayam, aduk2 masak hingga kira2 dagingnya sudah tidak terlihat merah atau bumbu meresap. Beri air secukupnya. Tambakan garam dan gula pasir. Test rasa. Tutup wajan dan masak sampai kuah ayam sedikit mengering/meresap dan dagingnya empuk.
1. Setelah daging empuk dan rasa sudah oke, masukkan daun kemangi, aduk2 sebentar, lalu matikan kompor.
1. Ayam Rica Kemangi siap dinikmati.




Demikianlah cara membuat ayam rica kemangi yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat mudah dan cepat, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
