---
description: "Step-by-Step menyiapakan Ayam goreng cabe hijau minggu ini"
title: "Step-by-Step menyiapakan Ayam goreng cabe hijau minggu ini"
slug: 321-step-by-step-menyiapakan-ayam-goreng-cabe-hijau-minggu-ini
date: 2020-09-13T20:37:58.453Z
image: https://img-global.cpcdn.com/recipes/4075ab271d32d1d5/751x532cq70/ayam-goreng-cabe-hijau-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4075ab271d32d1d5/751x532cq70/ayam-goreng-cabe-hijau-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4075ab271d32d1d5/751x532cq70/ayam-goreng-cabe-hijau-foto-resep-utama.jpg
author: Christine Craig
ratingvalue: 4.4
reviewcount: 14853
recipeingredient:
- "1/2 ekor ayampotong2"
- " bumbu marinasi ayam"
- "8 butir bawang merah"
- "4 butir bawang putih"
- "1/2 ruas jahe"
- "3 sdm saos tiram"
- "1/2 sdt garam"
- " sambal hijau"
- "15 cabe hijau besar"
- "5 cabe hijau kecil"
- "8 butir bawang merah"
- "4 bawang putih"
- "2 batang daun bawang"
- "5 lembar daun jeruk"
- "2 lembar daun salam"
- "1/2 sdt terasi"
- "1 batang seraigeprek"
- "1 ruas laosgeprek"
- " minyak goreng utk menumis"
- "secukupnya garam"
- "secukupnya gula pasir"
recipeinstructions:
- "Bumbui ayam dengan bahan marinasi tadi,biarkan didalam kulkal selama minimal 1 jam atau semalam juga boleh. Sisihkan"
- "Ulek kasar atau bisa dimasukkan ke chopper,bawang merah,bawang putih,daun bawang dan cabe hijau."
- "Panaskan sedikit minyak,tumis ulekan cabe tadi hingga harum."
- "Masukkan daun salam,daun jeruk,serai,terasi,laos,garam dan gula. Aduk."
- "Masak sampai bau langunya hilang dan matang,koreksi rasa."
- "Goreng ayam,sampai matang kecoklatan."
- "Masukkan ayam yg sudah digoreng td kedalam sambal yg dimasak. Masak sebentar saja. Matikan api dan angkat."
categories:
- Recipe
tags:
- ayam
- goreng
- cabe

katakunci: ayam goreng cabe 
nutrition: 155 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam goreng cabe hijau](https://img-global.cpcdn.com/recipes/4075ab271d32d1d5/751x532cq70/ayam-goreng-cabe-hijau-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga renyah. Ciri makanan Nusantara ayam goreng cabe hijau yang penuh dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga dapat didapat dengan cara mudah. Diantaranya adalah memasak Ayam goreng cabe hijau untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang bisa anda contoh salah satunya ayam goreng cabe hijau yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep ayam goreng cabe hijau tanpa harus bersusah payah.
Berikut ini resep Ayam goreng cabe hijau yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam goreng cabe hijau:

1. Harus ada 1/2 ekor ayam,potong2
1. Harus ada  bumbu marinasi ayam
1. Dibutuhkan 8 butir bawang merah
1. Harus ada 4 butir bawang putih
1. Dibutuhkan 1/2 ruas jahe
1. Jangan lupa 3 sdm saos tiram
1. Diperlukan 1/2 sdt garam
1. Siapkan  sambal hijau
1. Harus ada 15 cabe hijau besar
1. Siapkan 5 cabe hijau kecil
1. Dibutuhkan 8 butir bawang merah
1. Tambah 4 bawang putih
1. Dibutuhkan 2 batang daun bawang
1. Diperlukan 5 lembar daun jeruk
1. Dibutuhkan 2 lembar daun salam
1. Dibutuhkan 1/2 sdt terasi
1. Tambah 1 batang serai,geprek
1. Jangan lupa 1 ruas laos,geprek
1. Diperlukan  minyak goreng utk menumis
1. Tambah secukupnya garam
1. Dibutuhkan secukupnya gula pasir




<!--inarticleads2-->

##### Cara membuat  Ayam goreng cabe hijau:

1. Bumbui ayam dengan bahan marinasi tadi,biarkan didalam kulkal selama minimal 1 jam atau semalam juga boleh. Sisihkan
1. Ulek kasar atau bisa dimasukkan ke chopper,bawang merah,bawang putih,daun bawang dan cabe hijau.
1. Panaskan sedikit minyak,tumis ulekan cabe tadi hingga harum.
1. Masukkan daun salam,daun jeruk,serai,terasi,laos,garam dan gula. Aduk.
1. Masak sampai bau langunya hilang dan matang,koreksi rasa.
1. Goreng ayam,sampai matang kecoklatan.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam goreng cabe hijau">1. Masukkan ayam yg sudah digoreng td kedalam sambal yg dimasak. Masak sebentar saja. Matikan api dan angkat.




Demikianlah cara membuat ayam goreng cabe hijau yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
