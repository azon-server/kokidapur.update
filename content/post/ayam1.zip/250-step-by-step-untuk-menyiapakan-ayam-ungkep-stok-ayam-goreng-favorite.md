---
description: "Step-by-Step untuk menyiapakan Ayam Ungkep (Stok Ayam Goreng) Favorite"
title: "Step-by-Step untuk menyiapakan Ayam Ungkep (Stok Ayam Goreng) Favorite"
slug: 250-step-by-step-untuk-menyiapakan-ayam-ungkep-stok-ayam-goreng-favorite
date: 2020-08-25T13:38:04.458Z
image: https://img-global.cpcdn.com/recipes/42692453d68d4026/751x532cq70/ayam-ungkep-stok-ayam-goreng-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/42692453d68d4026/751x532cq70/ayam-ungkep-stok-ayam-goreng-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/42692453d68d4026/751x532cq70/ayam-ungkep-stok-ayam-goreng-foto-resep-utama.jpg
author: Chad Hopkins
ratingvalue: 4.2
reviewcount: 13091
recipeingredient:
- "1 ekor ayam"
- "2 batang sereh digeprek"
- "3 lembar daun salam"
- "6 siung bawang putih"
- "3 buah kemiri"
- "1 sdm ketumbar bubuk"
- "1,5 sdm kunyit bubuk"
- "2 ruas jahe"
- "1 ruas lengkuas"
- "1 sdm garam"
- "Secukupnya kaldu bubuk"
recipeinstructions:
- "Potong ayam menjadi 10 bagian"
- "Haluskan baput, kemiri, laos, dan jahe"
- "Susun sereh dan daun salam di dasar wajan. Kemudian, tuang bumbu halus"
- "Masukkan garam, kunyit bubuk, dan ketumbar bubuk"
- "Tata ayam di atas bumbu dan nyalakkan kompor."
- "Masukkan air sedikit demi sedikit agar bumbu timbul dan merata, hingga ayam terendam."
- "Rebus dengan api kecil ke sedang hingga air hampir menyusut seluruhnya +- 1 jam. Pindahkan ayam ke wadah tertutup dan simpan di freezer sebagai stok."
- "Sisa bumbu ungkep dapat langsung digunakan untuk menggoreng tempe"
categories:
- Recipe
tags:
- ayam
- ungkep
- stok

katakunci: ayam ungkep stok 
nutrition: 100 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT40M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Ungkep (Stok Ayam Goreng)](https://img-global.cpcdn.com/recipes/42692453d68d4026/751x532cq70/ayam-ungkep-stok-ayam-goreng-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam ungkep (stok ayam goreng) yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Kita



Kedekatan rumah tangga bisa diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam Ungkep (Stok Ayam Goreng) untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang dapat anda contoh salah satunya ayam ungkep (stok ayam goreng) yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam ungkep (stok ayam goreng) tanpa harus bersusah payah.
Berikut ini resep Ayam Ungkep (Stok Ayam Goreng) yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 11 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Ungkep (Stok Ayam Goreng):

1. Jangan lupa 1 ekor ayam
1. Harap siapkan 2 batang sereh (digeprek)
1. Jangan lupa 3 lembar daun salam
1. Harap siapkan 6 siung bawang putih
1. Diperlukan 3 buah kemiri
1. Siapkan 1 sdm ketumbar bubuk
1. Jangan lupa 1,5 sdm kunyit bubuk
1. Tambah 2 ruas jahe
1. Harap siapkan 1 ruas lengkuas
1. Siapkan 1 sdm garam
1. Harap siapkan Secukupnya kaldu bubuk




<!--inarticleads2-->

##### Instruksi membuat  Ayam Ungkep (Stok Ayam Goreng):

1. Potong ayam menjadi 10 bagian
1. Haluskan baput, kemiri, laos, dan jahe
1. Susun sereh dan daun salam di dasar wajan. Kemudian, tuang bumbu halus
1. Masukkan garam, kunyit bubuk, dan ketumbar bubuk
1. Tata ayam di atas bumbu dan nyalakkan kompor.
1. Masukkan air sedikit demi sedikit agar bumbu timbul dan merata, hingga ayam terendam.
1. Rebus dengan api kecil ke sedang hingga air hampir menyusut seluruhnya +- 1 jam. Pindahkan ayam ke wadah tertutup dan simpan di freezer sebagai stok.
1. Sisa bumbu ungkep dapat langsung digunakan untuk menggoreng tempe




Demikianlah cara membuat ayam ungkep (stok ayam goreng) yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan teruji, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
