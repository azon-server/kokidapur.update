---
description: "Cara singkat untuk menyiapakan 24. Ayam Rica Kemangi teraktual"
title: "Cara singkat untuk menyiapakan 24. Ayam Rica Kemangi teraktual"
slug: 84-cara-singkat-untuk-menyiapakan-24-ayam-rica-kemangi-teraktual
date: 2020-11-20T23:29:41.966Z
image: https://img-global.cpcdn.com/recipes/92f6fd87936a00a9/751x532cq70/24-ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/92f6fd87936a00a9/751x532cq70/24-ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/92f6fd87936a00a9/751x532cq70/24-ayam-rica-kemangi-foto-resep-utama.jpg
author: Irene Bass
ratingvalue: 5
reviewcount: 3887
recipeingredient:
- "1/2 kg ayam kampung muda"
- "1 papan kecil tempe"
- "Segenggam kemangi"
- " Kecap"
- " Garam"
- " Gula Kaldu jamur"
- " Air"
- " Bumbu halus "
- "3 siung bawang putih"
- "5 siung bawang merah"
- "8 buah cabe merah kriting"
- "5 buah cabe setan"
- "1 ruas jahe"
- "3 buah kemiri"
- "1 sdt ketumbar"
- "1/2 sdt merica"
- " Bumbu cemplung "
- "1 batang serai geprek"
- "1 helai daun jeruk wangi"
recipeinstructions:
- "Cuci bersih ayam lalu rebus sebentar. Setelah matang tiriskan."
- "Potong tempe sesuai selera."
- "Rebus juga bawang merah, bawang putih &amp; cabe. Setalah itu tiriskan."
- "Ulek bumbu yg direbus tadi. Tambahkan jahe, kemiri, ketumbar, &amp; merica. Ulek hingga halus."
- "Panaskan minyak, goreng tempe &amp; ayam hingga terlihat layu saja, jadi jangan lama². Tiriskan."
- "Siapkan wajan beri sedikit minyak. Tumis bumbu ulek, tambahkan juga daun jeruk &amp; serai. Tumis hingga harum. Tambahkan ir, didihkan."
- "Masukkan ayam &amp; tempe. Beri garam, gula &amp; kaldu jamur."
- "Setelah air menyusut masukkan potongan tomat, kemangi &amp; beri sedikit kecap. Koreksi rasa."
- "Biarkan sebentar, lalu mati kompor. Ayam rica kemangi siap disajikan."
categories:
- Recipe
tags:
- 24
- ayam
- rica

katakunci: 24 ayam rica 
nutrition: 173 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Dessert

---


![24. Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/92f6fd87936a00a9/751x532cq70/24-ayam-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti 24. ayam rica kemangi yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Kita



Kehangatan keluarga bisa diperoleh dengan cara sederhana. Diantaranya adalah memasak 24. Ayam Rica Kemangi untuk orang di rumah. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang dapat anda coba salah satunya 24. ayam rica kemangi yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep 24. ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep 24. Ayam Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat 24. Ayam Rica Kemangi:

1. Jangan lupa 1/2 kg ayam kampung muda
1. Diperlukan 1 papan kecil tempe
1. Diperlukan Segenggam kemangi
1. Tambah  Kecap
1. Harus ada  Garam
1. Harus ada  Gula Kaldu jamur
1. Tambah  Air
1. Siapkan  Bumbu halus :
1. Jangan lupa 3 siung bawang putih
1. Harus ada 5 siung bawang merah
1. Harap siapkan 8 buah cabe merah kriting
1. Diperlukan 5 buah cabe setan
1. Diperlukan 1 ruas jahe
1. Siapkan 3 buah kemiri
1. Tambah 1 sdt ketumbar
1. Tambah 1/2 sdt merica
1. Tambah  Bumbu cemplung :
1. Harap siapkan 1 batang serai (geprek)
1. Diperlukan 1 helai daun jeruk wangi




<!--inarticleads2-->

##### Cara membuat  24. Ayam Rica Kemangi:

1. Cuci bersih ayam lalu rebus sebentar. Setelah matang tiriskan.
1. Potong tempe sesuai selera.
1. Rebus juga bawang merah, bawang putih &amp; cabe. Setalah itu tiriskan.
1. Ulek bumbu yg direbus tadi. Tambahkan jahe, kemiri, ketumbar, &amp; merica. Ulek hingga halus.
1. Panaskan minyak, goreng tempe &amp; ayam hingga terlihat layu saja, jadi jangan lama². Tiriskan.
1. Siapkan wajan beri sedikit minyak. Tumis bumbu ulek, tambahkan juga daun jeruk &amp; serai. Tumis hingga harum. Tambahkan ir, didihkan.
1. Masukkan ayam &amp; tempe. Beri garam, gula &amp; kaldu jamur.
1. Setelah air menyusut masukkan potongan tomat, kemangi &amp; beri sedikit kecap. Koreksi rasa.
1. Biarkan sebentar, lalu mati kompor. Ayam rica kemangi siap disajikan.




Demikianlah cara membuat 24. ayam rica kemangi yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan cepat, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
