---
description: "Resep : Ayam rica - rica teraktual"
title: "Resep : Ayam rica - rica teraktual"
slug: 170-resep-ayam-rica-rica-teraktual
date: 2020-09-21T22:38:21.033Z
image: https://img-global.cpcdn.com/recipes/3029488eb2b0e18d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3029488eb2b0e18d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3029488eb2b0e18d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Mason Peterson
ratingvalue: 4.2
reviewcount: 28761
recipeingredient:
- "5 potong Ayam negeri"
- "1 ikat Kemangi"
- "2 buah Tomat"
- " Bumbu halus "
- "10 siung Bawang merah"
- "4 siung Bawang putih"
- "2 butir Kemiri"
- "1 jari Kunyit"
- "10 buah Cabe rawit"
- "5 buah Cabe keriting"
- " Daun salam dan daun jeruk"
- " Lengkuas dan sereh"
- "secukupnya Air"
recipeinstructions:
- "Rebus dulu ayamnya, lalu ulek atau blender Bumbu halus lalu tumis sampai harum lalu masukkan daun jeruk, daun salam, lengkuas dan sereh lalu tuangkan ayam potong aduk rata kemudian masukkan air aduk rata"
- "Selanjutnya masukkan daun kemangi aduk rata sampai air menyusut Kemudian masukkan tomat yg sudah di iris2, aduk rata, masukkan kaldu jamur dan garam icip rasa.."
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 241 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica - rica](https://img-global.cpcdn.com/recipes/3029488eb2b0e18d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica - rica yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Indonesia

Kehangatan rumah tangga bisa didapat dengan cara sederhana. Salah satunya adalah memasak Ayam rica - rica untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang dapat anda buat salah satunya ayam rica - rica yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep ayam rica - rica tanpa harus bersusah payah.
Berikut ini resep Ayam rica - rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 2 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica - rica:

1. Siapkan 5 potong Ayam negeri
1. Harus ada 1 ikat Kemangi
1. Dibutuhkan 2 buah Tomat
1. Siapkan  Bumbu halus :
1. Diperlukan 10 siung Bawang merah
1. Dibutuhkan 4 siung Bawang putih
1. Diperlukan 2 butir Kemiri
1. Harus ada 1 jari Kunyit
1. Dibutuhkan 10 buah Cabe rawit
1. Harus ada 5 buah Cabe keriting
1. Jangan lupa  Daun salam dan daun jeruk
1. Harus ada  Lengkuas dan sereh
1. Siapkan secukupnya Air




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica - rica:

1. Rebus dulu ayamnya, lalu ulek atau blender Bumbu halus lalu tumis sampai harum lalu masukkan daun jeruk, daun salam, lengkuas dan sereh lalu tuangkan ayam potong aduk rata kemudian masukkan air aduk rata
1. Selanjutnya masukkan daun kemangi aduk rata sampai air menyusut Kemudian masukkan tomat yg sudah di iris2, aduk rata, masukkan kaldu jamur dan garam icip rasa..




Demikianlah cara membuat ayam rica - rica yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan terbukti, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
