---
description: "Langkah untuk membuat Ayam Goreng Ungkep Sempurna"
title: "Langkah untuk membuat Ayam Goreng Ungkep Sempurna"
slug: 471-langkah-untuk-membuat-ayam-goreng-ungkep-sempurna
date: 2021-02-02T18:44:03.848Z
image: https://img-global.cpcdn.com/recipes/c31c1b562edaae65/751x532cq70/ayam-goreng-ungkep-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c31c1b562edaae65/751x532cq70/ayam-goreng-ungkep-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c31c1b562edaae65/751x532cq70/ayam-goreng-ungkep-foto-resep-utama.jpg
author: Alfred Steele
ratingvalue: 4.7
reviewcount: 45146
recipeingredient:
- "700 gram ayam potong dan cuci bersih"
- "3 lembar daun salam"
- "2 lembar daun jeruk"
- "1 batang serai memarkan"
- "850 ml air"
- "Secukupnya garam gulpas dan kaldu bubuk"
- "Secukupnya minyak untuk menggoreng"
- " Bumbu halus"
- "4 siung bawang putih"
- "3 siung bawang merah"
- "2 cm kunyit"
- "2 cm jahe"
- "5 cm lengkuas"
- "1 sdt ketumbar"
- "3 buah kemiri"
recipeinstructions:
- "Haluskan semua bumbu halus."
- "Siapkan wajan lalu masukkan bumbu halus tadi, daun salam, daun jeruk, serai, dan ayam. Bumbui juga dgn garam, sedikit gulpas, dan kaldu bubuk. Aduk rata."
- "Tutup dan masak dgn api sedang selama kurang lebih 20 menit."
- "Tiriskan ayam. Goreng dgn minyak panas hingga kuning kecoklatan. Angkat dan tiriskan. Ayam siap untuk disajikan ❤️ selamat mencoba 😘"
categories:
- Recipe
tags:
- ayam
- goreng
- ungkep

katakunci: ayam goreng ungkep 
nutrition: 251 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Goreng Ungkep](https://img-global.cpcdn.com/recipes/c31c1b562edaae65/751x532cq70/ayam-goreng-ungkep-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau gurih. Ciri khas makanan Indonesia ayam goreng ungkep yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam Goreng Ungkep untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang dapat anda buat salah satunya ayam goreng ungkep yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam goreng ungkep tanpa harus bersusah payah.
Seperti resep Ayam Goreng Ungkep yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 15 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Ungkep:

1. Harap siapkan 700 gram ayam, potong dan cuci bersih
1. Harus ada 3 lembar daun salam
1. Dibutuhkan 2 lembar daun jeruk
1. Siapkan 1 batang serai, memarkan
1. Diperlukan 850 ml air
1. Jangan lupa Secukupnya garam, gulpas, dan kaldu bubuk
1. Siapkan Secukupnya minyak untuk menggoreng
1. Dibutuhkan  Bumbu halus:
1. Dibutuhkan 4 siung bawang putih
1. Diperlukan 3 siung bawang merah
1. Diperlukan 2 cm kunyit
1. Siapkan 2 cm jahe
1. Harap siapkan 5 cm lengkuas
1. Siapkan 1 sdt ketumbar
1. Diperlukan 3 buah kemiri




<!--inarticleads2-->

##### Cara membuat  Ayam Goreng Ungkep:

1. Haluskan semua bumbu halus.
1. Siapkan wajan lalu masukkan bumbu halus tadi, daun salam, daun jeruk, serai, dan ayam. Bumbui juga dgn garam, sedikit gulpas, dan kaldu bubuk. Aduk rata.
1. Tutup dan masak dgn api sedang selama kurang lebih 20 menit.
1. Tiriskan ayam. Goreng dgn minyak panas hingga kuning kecoklatan. Angkat dan tiriskan. Ayam siap untuk disajikan ❤️ selamat mencoba 😘




Demikianlah cara membuat ayam goreng ungkep yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
