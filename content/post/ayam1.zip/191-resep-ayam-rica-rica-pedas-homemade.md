---
description: "Resep : Ayam Rica-rica Pedas Homemade"
title: "Resep : Ayam Rica-rica Pedas Homemade"
slug: 191-resep-ayam-rica-rica-pedas-homemade
date: 2020-08-25T19:38:50.659Z
image: https://img-global.cpcdn.com/recipes/b8444443b7f03759/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b8444443b7f03759/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b8444443b7f03759/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
author: Millie Hawkins
ratingvalue: 4.5
reviewcount: 34615
recipeingredient:
- "2 siung Bawang putih cincang"
- "10 butir cabe rawit merah sesukanya tergantung mau level berapa tingkat kepedasannya"
- "1/2 siung bawang bombay cincang"
- "5 potongan ayam paha dan dada beli di Superindo saya potongpotong jadi agak kecil"
- "1 buah tomat potong kecilkecil"
- " Saus tomat saus sambal dan saus tiram campurkan takaran sesuai selera saja ya soalnya saya lupa"
- "1/2 sdm kecap asin"
- "1/2 sdm gula pasir"
- "1 sdt mericalada bubuk"
- "1 sdm kecap manis"
- "1 gelas air"
- "secukupnya Garam"
recipeinstructions:
- "Sebelumnya ayam yang sudah dipotong-potong di marinate dengan bumbu-bumbu: kecap dan lada secukupnya (disesuaikan dengan jumlah ayamnya). Diamkan di dalam kulkas selama beberapa menit (3o-60 menit). Setelah bumbu meresap, goreng ayam sampai matang."
- "Panaskan minyak dalam wajan. Tumis bawang putih dan bawang bombay sampai harum. Usahakan bawang putih jangan sampai gosong yaa.."
- "Masukkan cabe rawit. Masak hingga harum. Masukkan potongan tomat."
- "Masukkan campuran saus tomat, saus sambal dan saus tiram. Masak hingga tercampur rata. Masukkan kecap asin, gula pasir, merica dan kecap manis. Lalu tambahkan air. Masak sebentar. Tambahkan sedikit garam."
- "Masukkan ayamnya yang sudah di goreng sebelumnya. Campurkan hingga tercampur rata pada seluruh ayamnya. Tambahkan daun bawang agar lebih sedap. Hidangkan."
categories:
- Recipe
tags:
- ayam
- ricarica
- pedas

katakunci: ayam ricarica pedas 
nutrition: 137 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica-rica Pedas](https://img-global.cpcdn.com/recipes/b8444443b7f03759/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan enak. Karasteristik makanan Nusantara ayam rica-rica pedas yang penuh dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan rumah tangga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Ayam Rica-rica Pedas untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang bisa anda contoh salah satunya ayam rica-rica pedas yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam rica-rica pedas tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Pedas yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Pedas:

1. Tambah 2 siung Bawang putih, cincang
1. Diperlukan 10 butir cabe rawit merah (sesukanya, tergantung mau level berapa tingkat kepedasannya)
1. Dibutuhkan 1/2 siung bawang bombay, cincang
1. Diperlukan 5 potongan ayam paha dan dada beli di Superindo (saya potong-potong jadi agak kecil)
1. Harap siapkan 1 buah tomat, potong kecil-kecil
1. Tambah  Saus tomat, saus sambal dan saus tiram, campurkan (takaran sesuai selera saja ya, soalnya saya lupa)
1. Jangan lupa 1/2 sdm kecap asin
1. Jangan lupa 1/2 sdm gula pasir
1. Dibutuhkan 1 sdt merica/lada bubuk
1. Tambah 1 sdm kecap manis
1. Siapkan 1 gelas air
1. Siapkan secukupnya Garam




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-rica Pedas:

1. Sebelumnya ayam yang sudah dipotong-potong di marinate dengan bumbu-bumbu: kecap dan lada secukupnya (disesuaikan dengan jumlah ayamnya). Diamkan di dalam kulkas selama beberapa menit (3o-60 menit). Setelah bumbu meresap, goreng ayam sampai matang.
1. Panaskan minyak dalam wajan. Tumis bawang putih dan bawang bombay sampai harum. Usahakan bawang putih jangan sampai gosong yaa..
1. Masukkan cabe rawit. Masak hingga harum. Masukkan potongan tomat.
1. Masukkan campuran saus tomat, saus sambal dan saus tiram. Masak hingga tercampur rata. Masukkan kecap asin, gula pasir, merica dan kecap manis. Lalu tambahkan air. Masak sebentar. Tambahkan sedikit garam.
1. Masukkan ayamnya yang sudah di goreng sebelumnya. Campurkan hingga tercampur rata pada seluruh ayamnya. Tambahkan daun bawang agar lebih sedap. Hidangkan.




Demikianlah cara membuat ayam rica-rica pedas yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan cepat, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
