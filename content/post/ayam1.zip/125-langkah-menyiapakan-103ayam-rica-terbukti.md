---
description: "Langkah menyiapakan 103.Ayam Rica Terbukti"
title: "Langkah menyiapakan 103.Ayam Rica Terbukti"
slug: 125-langkah-menyiapakan-103ayam-rica-terbukti
date: 2021-01-16T20:19:54.882Z
image: https://img-global.cpcdn.com/recipes/624ae7dfc716b40e/751x532cq70/103ayam-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/624ae7dfc716b40e/751x532cq70/103ayam-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/624ae7dfc716b40e/751x532cq70/103ayam-rica-foto-resep-utama.jpg
author: Nina Jordan
ratingvalue: 4.3
reviewcount: 13837
recipeingredient:
- "1 ayam pejantan potong 12"
- "1 jeruk nipis ambil airnya"
- "3 sereh geprek"
- "6 daun jeruk"
- "3 daun salam"
- "3 batang daun bawang iris 1 cm"
- "1 sdt garam"
- "1 sdt kaldu jamur"
- "1 jempol gula merah iris"
- "1 sdt ketumbur"
- "2 sdm minyak sayur untuk menumis"
- "Secukupnya air"
- " Bumbu halus "
- "12 siung bawang putih"
- "6 siung bawang merah"
- "6 btr kemiri"
- "10 cabe rawit"
- "6 cabe keriting"
- "1 ruas jari kunyit"
- "1 ruas jari jahe"
- "1 ruas jari lengkuas"
recipeinstructions:
- "Cuci.bersih ayam lalu beri perasan jeruk nipis,diamkan 10 menit kemudian cuci kembali."
- "Panaskan minyak,tumis bumbu halus hingga wangi. Masukkan sereh,daun salam,daun bawang,aduk rata beri 3 sdm air lalu tambahkan garam,gula merah dan kaldu. Masak hingga mendidih."
- "Masukkan ayam,aduk rata lalu tambahkan air secukupnya, masak hingga air menyusut sebagian lalu tambahkan daun bawang. Aduk rata,koreksi rasa,masak hingga kental dan ayam mengeluarkan minyak."
- "Ayam rica siap di hidangkan."
categories:
- Recipe
tags:
- 103ayam
- rica

katakunci: 103ayam rica 
nutrition: 275 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Dinner

---


![103.Ayam Rica](https://img-global.cpcdn.com/recipes/624ae7dfc716b40e/751x532cq70/103ayam-rica-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang setidaknya kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti 103.ayam rica yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa ciri khas yang merupakan keragaman Indonesia



Kedekatan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan 103.Ayam Rica untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang dapat anda contoh salah satunya 103.ayam rica yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep 103.ayam rica tanpa harus bersusah payah.
Berikut ini resep 103.Ayam Rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 21 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 103.Ayam Rica:

1. Dibutuhkan 1 ayam pejantan, potong 12
1. Siapkan 1 jeruk nipis ambil airnya
1. Harus ada 3 sereh, geprek
1. Siapkan 6 daun jeruk
1. Siapkan 3 daun salam
1. Jangan lupa 3 batang daun bawang, iris 1 cm
1. Dibutuhkan 1 sdt garam
1. Diperlukan 1 sdt kaldu jamur
1. Siapkan 1 jempol gula merah, iris
1. Harus ada 1 sdt ketumbur
1. Dibutuhkan 2 sdm minyak sayur untuk menumis
1. Harus ada Secukupnya air
1. Diperlukan  Bumbu halus :
1. Harap siapkan 12 siung bawang putih
1. Jangan lupa 6 siung bawang merah
1. Jangan lupa 6 btr kemiri
1. Jangan lupa 10 cabe rawit
1. Dibutuhkan 6 cabe keriting
1. Dibutuhkan 1 ruas jari kunyit
1. Harap siapkan 1 ruas jari jahe
1. Siapkan 1 ruas jari lengkuas




<!--inarticleads2-->

##### Bagaimana membuat  103.Ayam Rica:

1. Cuci.bersih ayam lalu beri perasan jeruk nipis,diamkan 10 menit kemudian cuci kembali.
1. Panaskan minyak,tumis bumbu halus hingga wangi. Masukkan sereh,daun salam,daun bawang,aduk rata beri 3 sdm air lalu tambahkan garam,gula merah dan kaldu. Masak hingga mendidih.
1. Masukkan ayam,aduk rata lalu tambahkan air secukupnya, masak hingga air menyusut sebagian lalu tambahkan daun bawang. Aduk rata,koreksi rasa,masak hingga kental dan ayam mengeluarkan minyak.
1. Ayam rica siap di hidangkan.




Demikianlah cara membuat 103.ayam rica yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan cepat, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
