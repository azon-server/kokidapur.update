---
description: "Langkah untuk membuat Ayam Goreng Kanton Halal Favorite"
title: "Langkah untuk membuat Ayam Goreng Kanton Halal Favorite"
slug: 449-langkah-untuk-membuat-ayam-goreng-kanton-halal-favorite
date: 2020-11-20T08:28:36.782Z
image: https://img-global.cpcdn.com/recipes/eae53a66f220feda/751x532cq70/ayam-goreng-kanton-halal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/eae53a66f220feda/751x532cq70/ayam-goreng-kanton-halal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/eae53a66f220feda/751x532cq70/ayam-goreng-kanton-halal-foto-resep-utama.jpg
author: Hilda Parsons
ratingvalue: 4.5
reviewcount: 20176
recipeingredient:
- "1 ekor ayam broiler ukuran 08  09 kg"
- " Bumbu Halus Gerus"
- "3 siung bawang putih"
- "1/2 butir bawang bombay"
- "1/2 cm jahe"
- "1 sdm bubuk ngohiong"
- "1 sdt lada bubuk"
- "1 sdt angkak boleh skip rendam air tiriskan"
- " Bumbu Cemplung "
- "1 helai daun jeruk sobek sobek"
- "1 sdm minyak wijen"
- "1 sdm saus tiram"
- "3 sdm kecap asin"
- "1 sdm gula pasir"
- "1 tangkai bawang prei iris 12 cm"
- "1 sdt garam"
recipeinstructions:
- "Bersihkan ayam. Potong jadi 4 bagian (2 dada, 2 paha)."
- "Tusuk tusuk ayam dengan garpu agar bumbu nantinya lebih meresap. Tak perlu kuatir dagingnya akan rusak karena ditusuk. Letakkan dalam wadah setelah ditusuk."
- "Haluskan bumbu halus. Boleh dengan uleg/ chopper/ blender. Kemudian masukkan ke dalam wadah ayam untuk marinasi."
- "Campurkan bumbu halus, bumbu cemplung &amp; ayam. Lumuri bolak balik, simpan di kulkas (refrigerator) setidaknya 3 jam."
- "Siapkan panci rebus yang besarnya cukup pas untuk ukuran ayam. Masukkan ayam yang telah dimarinasi &amp; sisa bumbu marinasi ke dalamnya, isi air hingga ayam terendam. Rebus api sedang agak kecil selama 30 menit."
- "Sekali sekali balik agar bagian yang tak terbenam dapat terendam air bergantian. Setelah total 30 menit, matikan. Tiriskan sebentar."
- "Siapkan oven, nyalakan api sedang."
- "Letakkan ayam di wadah tahan panas, atau wadah teflon. Boleh juga di loyang aluminium yang sudah dioles sedikit mentega/ dialasi baking paper."
- "Oven 30 menit, matikan. Kita perlu mengoven supaya bagian luar agak kering."
- "Boleh langsung dihidangkan dari hasil oven, atau digoreng dulu. Kalau aku, lebih suka digoreng dulu api agak kecil agar lebih renyah."
- "Oh ya, menghidangkannya dipotong potong dulu selebar 3 cm ya. Kalau aku potongnya pake pisau daging, ayamnya ditaruh di atas talenan. Dan setelah dipotong, atur kembali di piring sesuai bentuknya semula agar lebih indah."
- "Boleh juga hidangkan dengan Sambal Tauco, garam ngohiong, selada/ timun, dan kerupuk."
categories:
- Recipe
tags:
- ayam
- goreng
- kanton

katakunci: ayam goreng kanton 
nutrition: 203 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Goreng Kanton Halal](https://img-global.cpcdn.com/recipes/eae53a66f220feda/751x532cq70/ayam-goreng-kanton-halal-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang patut kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam goreng kanton halal yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa keistimewahan yang merupakan keragaman Indonesia

Kedekatan keluarga bisa diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam Goreng Kanton Halal untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang dapat anda praktekkan salah satunya ayam goreng kanton halal yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep ayam goreng kanton halal tanpa harus bersusah payah.
Seperti resep Ayam Goreng Kanton Halal yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 12 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Goreng Kanton Halal:

1. Tambah 1 ekor ayam broiler ukuran 0,8 - 0,9 kg
1. Siapkan  Bumbu Halus/ Gerus
1. Jangan lupa 3 siung bawang putih
1. Dibutuhkan 1/2 butir bawang bombay
1. Diperlukan 1/2 cm jahe
1. Dibutuhkan 1 sdm bubuk ngohiong
1. Siapkan 1 sdt lada bubuk
1. Tambah 1 sdt angkak (boleh skip), rendam air, tiriskan
1. Harus ada  Bumbu Cemplung :
1. Tambah 1 helai daun jeruk, sobek sobek
1. Harus ada 1 sdm minyak wijen
1. Jangan lupa 1 sdm saus tiram
1. Diperlukan 3 sdm kecap asin
1. Harap siapkan 1 sdm gula pasir
1. Siapkan 1 tangkai bawang prei iris 1/2 cm
1. Dibutuhkan 1 sdt garam




<!--inarticleads2-->

##### Cara membuat  Ayam Goreng Kanton Halal:

1. Bersihkan ayam. Potong jadi 4 bagian (2 dada, 2 paha).
1. Tusuk tusuk ayam dengan garpu agar bumbu nantinya lebih meresap. Tak perlu kuatir dagingnya akan rusak karena ditusuk. Letakkan dalam wadah setelah ditusuk.
1. Haluskan bumbu halus. Boleh dengan uleg/ chopper/ blender. Kemudian masukkan ke dalam wadah ayam untuk marinasi.
1. Campurkan bumbu halus, bumbu cemplung &amp; ayam. Lumuri bolak balik, simpan di kulkas (refrigerator) setidaknya 3 jam.
1. Siapkan panci rebus yang besarnya cukup pas untuk ukuran ayam. Masukkan ayam yang telah dimarinasi &amp; sisa bumbu marinasi ke dalamnya, isi air hingga ayam terendam. Rebus api sedang agak kecil selama 30 menit.
1. Sekali sekali balik agar bagian yang tak terbenam dapat terendam air bergantian. Setelah total 30 menit, matikan. Tiriskan sebentar.
1. Siapkan oven, nyalakan api sedang.
1. Letakkan ayam di wadah tahan panas, atau wadah teflon. Boleh juga di loyang aluminium yang sudah dioles sedikit mentega/ dialasi baking paper.
1. Oven 30 menit, matikan. Kita perlu mengoven supaya bagian luar agak kering.
1. Boleh langsung dihidangkan dari hasil oven, atau digoreng dulu. Kalau aku, lebih suka digoreng dulu api agak kecil agar lebih renyah.
1. Oh ya, menghidangkannya dipotong potong dulu selebar 3 cm ya. Kalau aku potongnya pake pisau daging, ayamnya ditaruh di atas talenan. Dan setelah dipotong, atur kembali di piring sesuai bentuknya semula agar lebih indah.
1. Boleh juga hidangkan dengan Sambal Tauco, garam ngohiong, selada/ timun, dan kerupuk.




Demikianlah cara membuat ayam goreng kanton halal yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan terbukti, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
