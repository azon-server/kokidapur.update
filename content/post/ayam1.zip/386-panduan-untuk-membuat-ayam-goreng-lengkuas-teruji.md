---
description: "Panduan untuk membuat Ayam Goreng Lengkuas Teruji"
title: "Panduan untuk membuat Ayam Goreng Lengkuas Teruji"
slug: 386-panduan-untuk-membuat-ayam-goreng-lengkuas-teruji
date: 2020-08-08T04:09:13.480Z
image: https://img-global.cpcdn.com/recipes/83377d3db23c6ddb/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/83377d3db23c6ddb/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/83377d3db23c6ddb/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Maria May
ratingvalue: 4.9
reviewcount: 2968
recipeingredient:
- "1 kg sayap ayam"
- " Bahan Marinasi Ayam "
- "1 sdm garam"
- "1 buah jeruk ambil airnya  bisa di ganti cuka"
- "Secukupnya penyedap rasa"
- " Bahan Lengkuas "
- "120 gr lengkuas diparut"
- "8 siung bawang putih uleg"
- "50 ml air kelapa"
- "1 butir telur"
- "1 sdt kaldu bubuk ayam"
- "1 sdt garam"
- "2 ruas kunyit uleg"
- "1 sdm margarin"
- " Bahan Ungkep "
- "20 lembar daun salam"
recipeinstructions:
- "Marinasi ayam nya dulu yaa, sebelumnya udah dicuci dulu. Diamkan ayam marinasi selama 1 jam simpan kulkas, setelah itu di ungkep sampe matang, nanti dia ngeluarin air sendiri abis itu tetep diungkep sampe air asat. Tips nya : siapkan wajan anti lengket, tata daun salam taruh ayam di atasnya lalu tutup lagi pakai daun salam nya"
- "Siapkan bahan lengkuas..campur semua bahan ya..tuang sedikit2 air kelapa cukup sampe nyemek2 aja gitu"
- "Tunggu ayam ungkep tadi dingin ya, baru di balurin ke bahan lengkuas, taruh dalam wadah simpan di kulkas minimal 1 jam biar bumbu meresap..abis itu goreng, jadi ini bisa di simpan ya, jadi sewaktu2 tinggal goreng deh😚"
- "Serius ini enak bgt apalagi temennya nasi gurih..hhmmmm"
- "Yummy 🤤"
- "Selamat mencoba"
categories:
- Recipe
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 230 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Goreng Lengkuas](https://img-global.cpcdn.com/recipes/83377d3db23c6ddb/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam goreng lengkuas yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Indonesia

Kedekatan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Goreng Lengkuas untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang bisa anda praktekkan salah satunya ayam goreng lengkuas yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep ayam goreng lengkuas tanpa harus bersusah payah.
Berikut ini resep Ayam Goreng Lengkuas yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Lengkuas:

1. Jangan lupa 1 kg sayap ayam
1. Tambah  Bahan Marinasi Ayam :
1. Harus ada 1 sdm garam
1. Dibutuhkan 1 buah jeruk ambil airnya / bisa di ganti cuka
1. Siapkan Secukupnya penyedap rasa
1. Dibutuhkan  Bahan Lengkuas :
1. Harus ada 120 gr lengkuas diparut
1. Dibutuhkan 8 siung bawang putih (uleg)
1. Siapkan 50 ml air kelapa
1. Siapkan 1 butir telur
1. Harap siapkan 1 sdt kaldu bubuk ayam
1. Siapkan 1 sdt garam
1. Tambah 2 ruas kunyit (uleg)
1. Jangan lupa 1 sdm margarin
1. Jangan lupa  Bahan Ungkep :
1. Harus ada 20 lembar daun salam




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Goreng Lengkuas:

1. Marinasi ayam nya dulu yaa, sebelumnya udah dicuci dulu. Diamkan ayam marinasi selama 1 jam simpan kulkas, setelah itu di ungkep sampe matang, nanti dia ngeluarin air sendiri abis itu tetep diungkep sampe air asat. Tips nya : siapkan wajan anti lengket, tata daun salam taruh ayam di atasnya lalu tutup lagi pakai daun salam nya
1. Siapkan bahan lengkuas..campur semua bahan ya..tuang sedikit2 air kelapa cukup sampe nyemek2 aja gitu
1. Tunggu ayam ungkep tadi dingin ya, baru di balurin ke bahan lengkuas, taruh dalam wadah simpan di kulkas minimal 1 jam biar bumbu meresap..abis itu goreng, jadi ini bisa di simpan ya, jadi sewaktu2 tinggal goreng deh😚
1. Serius ini enak bgt apalagi temennya nasi gurih..hhmmmm
1. Yummy 🤤
1. Selamat mencoba




Demikianlah cara membuat ayam goreng lengkuas yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan teruji, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
