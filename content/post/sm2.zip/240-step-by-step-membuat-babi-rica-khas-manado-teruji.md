---
description: "Step-by-Step membuat Babi Rica Khas Manado Teruji"
title: "Step-by-Step membuat Babi Rica Khas Manado Teruji"
slug: 240-step-by-step-membuat-babi-rica-khas-manado-teruji
date: 2021-01-08T16:44:38.064Z
image: https://img-global.cpcdn.com/recipes/7e95687c3023afe7/751x532cq70/babi-rica-khas-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7e95687c3023afe7/751x532cq70/babi-rica-khas-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7e95687c3023afe7/751x532cq70/babi-rica-khas-manado-foto-resep-utama.jpg
author: Lillian Dixon
ratingvalue: 5
reviewcount: 31494
recipeingredient:
- "250 gr Daging babi samcan"
- "Secukupnya daun kemangi petik"
- "1 bh bw pre iris"
- "2 lbr daun jeruk lbh enak daun jeruk Manadosulawesi"
- "1 bh sereh geprek"
- " Bumbu halus "
- "5 btr bawang putih"
- "3 btr bawang merah"
- "1 ruas kunyit"
- "1 ruas jahe"
- "7 bh cabe merah keriting"
- "5 bh cabe rawit sesuai selera pedas"
- "secukupnya garam gula pasir kaldu bubuk"
- " minyak untuk menumis"
recipeinstructions:
- "Presto daging babi hingga empuk. Bole dipotong2 dulu atau dibiarkan utuh juga bole, potongnya belakangan. Kalo aku suka dipotong2 dulu sih. Tiriskan STLH tekanan dlm panci presto turun."
- "Panaskan Minyak, masukkan sereh, disusul masukkan bumbu halus dan daun jeruk. Tumis hingga harum dan daun jeruk agak layu"
- "Selanjutnya masukkan babi, aduk rata. Beri sedikit air. Bumbui dgn garam, gula dan kaldu bubuk. Masukkan pula bawang pre dan daun kemangi. Didihkan"
- "Cicipi rasanya dan bila sudah pas, matikan api dan siap dihidangkan"
- "Nb : babi rica akan lebih sedap bila di nikmati keesokan harinya Krn bumbu lbh meresap ke dagingnya"
- "Note : bisa disimpan di freezer dan dipanaskan sejenak bila akan dikonsumsi. Tetep enak kok"
categories:
- Recipe
tags:
- babi
- rica
- khas

katakunci: babi rica khas 
nutrition: 105 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Dessert

---


![Babi Rica Khas Manado](https://img-global.cpcdn.com/recipes/7e95687c3023afe7/751x532cq70/babi-rica-khas-manado-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang harus kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti babi rica khas manado yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Nusantara



Kehangatan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah memasak Babi Rica Khas Manado untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang bisa anda buat salah satunya babi rica khas manado yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep babi rica khas manado tanpa harus bersusah payah.
Seperti resep Babi Rica Khas Manado yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Babi Rica Khas Manado:

1. Jangan lupa 250 gr Daging babi (samcan)
1. Diperlukan Secukupnya daun kemangi, petik
1. Harap siapkan 1 bh bw pre, iris
1. Tambah 2 lbr daun jeruk (lbh enak daun jeruk Manado/sulawesi)
1. Harus ada 1 bh sereh, geprek
1. Diperlukan  Bumbu halus :
1. Harus ada 5 btr bawang putih
1. Dibutuhkan 3 btr bawang merah
1. Harus ada 1 ruas kunyit
1. Dibutuhkan 1 ruas jahe
1. Dibutuhkan 7 bh cabe merah keriting
1. Harus ada 5 bh cabe rawit (sesuai selera pedas)
1. Harus ada secukupnya garam, gula pasir, kaldu bubuk
1. Dibutuhkan  minyak untuk menumis




<!--inarticleads2-->

##### Instruksi membuat  Babi Rica Khas Manado:

1. Presto daging babi hingga empuk. Bole dipotong2 dulu atau dibiarkan utuh juga bole, potongnya belakangan. Kalo aku suka dipotong2 dulu sih. Tiriskan STLH tekanan dlm panci presto turun.
1. Panaskan Minyak, masukkan sereh, disusul masukkan bumbu halus dan daun jeruk. Tumis hingga harum dan daun jeruk agak layu
1. Selanjutnya masukkan babi, aduk rata. Beri sedikit air. Bumbui dgn garam, gula dan kaldu bubuk. Masukkan pula bawang pre dan daun kemangi. Didihkan
1. Cicipi rasanya dan bila sudah pas, matikan api dan siap dihidangkan
1. Nb : babi rica akan lebih sedap bila di nikmati keesokan harinya Krn bumbu lbh meresap ke dagingnya
1. Note : bisa disimpan di freezer dan dipanaskan sejenak bila akan dikonsumsi. Tetep enak kok




Demikianlah cara membuat babi rica khas manado yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan teruji, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
