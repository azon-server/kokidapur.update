---
description: "Langkah membuat Timlo Solo Homemade"
title: "Langkah membuat Timlo Solo Homemade"
slug: 50-langkah-membuat-timlo-solo-homemade
date: 2020-09-26T07:33:26.486Z
image: https://img-global.cpcdn.com/recipes/aaa05cb6bfee6277/751x532cq70/timlo-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/aaa05cb6bfee6277/751x532cq70/timlo-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/aaa05cb6bfee6277/751x532cq70/timlo-solo-foto-resep-utama.jpg
author: Jeremy Lawson
ratingvalue: 4.6
reviewcount: 26680
recipeingredient:
- " Untuk kaldu dan ayam"
- "1/2 ekor ayam kampung ukuran sedang saya gunakan 2 bagian dada 2 sayap dan cakar"
- "1 buah bawang bombay"
- "3 siung bawang putih utuh tidak perlu dikupas"
- "2 batang daun bawang ikat"
- "1-2 iris jahe memarkan"
- "2-3 sdt kaldu ayam atau jamur bubuk"
- "1 butir biji pala belah dua"
- "1-2 sdt gula pasir"
- "secukupnya Garam dan merica"
- " Bumbu halus"
- "6 siung bawang putih"
- "4 butir kemiri"
- " Untuk kulit sosis solo"
- "100 gram tepung terigu serba guna"
- "200 mL air"
- "2 butir telur"
- "1/2 sdt garam"
- "1 butir telur extra kocok lepas dengan sedikit garam untuk lem saat menggulung dan melumuri sosis solo sebelum digoreng"
- " Bahan pelengkap"
- "6 buah ati ampela rebus hingga empuk dalam air garam dan goreng"
- " Soon rendam dan rebus sebentar"
- " Sambal rebus"
- " Optional wortel dan jamur kuping hitam"
- " Bawang goreng"
- " Telur pindang resep pernah saya share"
- " Kecap manis"
- " Kerupuk atau keripik kentang"
recipeinstructions:
- "Buat kaldu dengan merebus ayam bersama bawang putih utuh, bawang bombay, daun bawang dan garam. Rebus hingga empuk. Tiriskan daging. - Tumis bumbu halus dengan sedikit minyak atau margarin hingga harum. Tuang kaldu tadi. Masukkan biji pala dan jahe. Rebus sebentar selama 5-10 menit. Bumbuhi dengan garam, merica, gula dan kaldu bubuk. Matikan api. - Untuk kulit sosis solo: campur rata adonan. Goreng satu persatu di atas teflon. Sama seperti membuat kulit risoles. Gulung dan lem dengan telur."
- "Saya dapat 10 kulit sosis solo. Siapkan wajan dan panaskan minyak, lumuri dengan telur kemudian goreng gulungan kulit sosis solo hingga cokelat keemasan. Tiriskan. - Di wajan yang sama, goreng ayam kampung dan ati ampela yang sudah direbus. Tiriskan dan suwir ayam. Boleh tidak digoreng kalau mau lebih sehat tetapi menurut saya enak digoreng. - Siapkan bahan pelengkap. Rebus soon, optional wortel dan jamur. Buat sambal dan telur pindang."
- "Untuk menyajikan, dalam mangkuk masukkan soon, sosis solo, telur pindang, ati ampela dan optional wortel dan jamur. Tuang kuah panas dan beri taburan bawang goreng. - Sajikan selagi panas dengan nasi putih, sambal, kecap manis dan kerupuk."
categories:
- Recipe
tags:
- timlo
- solo

katakunci: timlo solo 
nutrition: 113 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Dessert

---


![Timlo Solo](https://img-global.cpcdn.com/recipes/aaa05cb6bfee6277/751x532cq70/timlo-solo-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau empuk. Ciri makanan Indonesia timlo solo yang penuh dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga dapat diperoleh dengan cara mudah. Diantaranya adalah memasak Timlo Solo untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang bisa anda praktekkan salah satunya timlo solo yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep timlo solo tanpa harus bersusah payah.
Seperti resep Timlo Solo yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 28 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Timlo Solo:

1. Diperlukan  Untuk kaldu dan ayam:
1. Diperlukan 1/2 ekor ayam kampung ukuran sedang (saya gunakan 2 bagian dada, 2 sayap dan cakar)
1. Tambah 1 buah bawang bombay
1. Dibutuhkan 3 siung bawang putih utuh, tidak perlu dikupas
1. Tambah 2 batang daun bawang, ikat
1. Harap siapkan 1-2 iris jahe, memarkan
1. Siapkan 2-3 sdt kaldu ayam atau jamur bubuk
1. Harap siapkan 1 butir biji pala, belah dua
1. Dibutuhkan 1-2 sdt gula pasir
1. Siapkan secukupnya Garam dan merica
1. Harap siapkan  Bumbu halus:
1. Diperlukan 6 siung bawang putih
1. Siapkan 4 butir kemiri
1. Tambah  Untuk kulit sosis solo:
1. Harap siapkan 100 gram tepung terigu serba guna
1. Harus ada 200 mL air
1. Tambah 2 butir telur
1. Dibutuhkan 1/2 sdt garam
1. Diperlukan 1 butir telur extra, kocok lepas dengan sedikit garam untuk lem saat menggulung dan melumuri sosis solo sebelum digoreng
1. Jangan lupa  Bahan pelengkap:
1. Harus ada 6 buah ati ampela, rebus hingga empuk dalam air garam dan goreng
1. Harap siapkan  Soon, rendam dan rebus sebentar
1. Jangan lupa  Sambal rebus
1. Dibutuhkan  Optional: wortel dan jamur kuping hitam
1. Harap siapkan  Bawang goreng
1. Tambah  Telur pindang (resep pernah saya share)
1. Dibutuhkan  Kecap manis
1. Dibutuhkan  Kerupuk atau keripik kentang




<!--inarticleads2-->

##### Cara membuat  Timlo Solo:

1. Buat kaldu dengan merebus ayam bersama bawang putih utuh, bawang bombay, daun bawang dan garam. Rebus hingga empuk. Tiriskan daging. - - Tumis bumbu halus dengan sedikit minyak atau margarin hingga harum. Tuang kaldu tadi. Masukkan biji pala dan jahe. Rebus sebentar selama 5-10 menit. Bumbuhi dengan garam, merica, gula dan kaldu bubuk. Matikan api. - - Untuk kulit sosis solo: campur rata adonan. Goreng satu persatu di atas teflon. Sama seperti membuat kulit risoles. Gulung dan lem dengan telur.
1. Saya dapat 10 kulit sosis solo. Siapkan wajan dan panaskan minyak, lumuri dengan telur kemudian goreng gulungan kulit sosis solo hingga cokelat keemasan. Tiriskan. - - Di wajan yang sama, goreng ayam kampung dan ati ampela yang sudah direbus. Tiriskan dan suwir ayam. Boleh tidak digoreng kalau mau lebih sehat tetapi menurut saya enak digoreng. - - Siapkan bahan pelengkap. Rebus soon, optional wortel dan jamur. Buat sambal dan telur pindang.
1. Untuk menyajikan, dalam mangkuk masukkan soon, sosis solo, telur pindang, ati ampela dan optional wortel dan jamur. Tuang kuah panas dan beri taburan bawang goreng. - - Sajikan selagi panas dengan nasi putih, sambal, kecap manis dan kerupuk.




Demikianlah cara membuat timlo solo yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan cepat, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
