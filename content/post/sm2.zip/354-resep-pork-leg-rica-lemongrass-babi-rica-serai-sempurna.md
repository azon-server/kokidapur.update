---
description: "Resep : Pork Leg Rica Lemongrass (Babi Rica Serai) Sempurna"
title: "Resep : Pork Leg Rica Lemongrass (Babi Rica Serai) Sempurna"
slug: 354-resep-pork-leg-rica-lemongrass-babi-rica-serai-sempurna
date: 2021-01-23T23:51:03.339Z
image: https://img-global.cpcdn.com/recipes/c0a648e92bded650/751x532cq70/pork-leg-rica-lemongrass-babi-rica-serai-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c0a648e92bded650/751x532cq70/pork-leg-rica-lemongrass-babi-rica-serai-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c0a648e92bded650/751x532cq70/pork-leg-rica-lemongrass-babi-rica-serai-foto-resep-utama.jpg
author: Lula Washington
ratingvalue: 5
reviewcount: 3945
recipeingredient:
- "1 potong kaki babi"
- "5-7 cabai merah keriting"
- "10-15 buah cabai rawit merah sesuaikan dengan selera pedas anda"
- "8 siung bawang putih sebagian untuk merebus kaki babi"
- "7 siung bawang merah"
- "5 ruas jahe kupas sebagian untuk merebus kaki babi"
- "3 batang seraisereh"
- "4 lembar daun jeruk"
- "secukupnya garamgula pasir"
- "secukupnya minyak kelapa untuk menumis"
recipeinstructions:
- "Potong kaki babi menjadi ukuran lebih kecil. Karena struktur tulang yg sangat keras, anda bisa minta tolong pada penjual saat membeli kaki babi.  Bersihkan dari serpihan tulang yang tersisa, cuci bersih dengan air mengalir lalu tiriskan.  Panaskan air hingga benar-benar mendidih, masukkan 4 siung bawang putih-geprek, 2 ruas jahe kupas-geprek, lalu masukkan potongan kaki babi. Tutup rebus hingga tingkat lunak yang diinginkan. Jika air habis, tambahkan air panas (jangan gunakan air dingin karena dapat membuat rebusan menjadi alot kembali)."
- "Haluskan bawang merah (semua), bawang putih (4 siung), cabai rawit (semua), cabai merah (semua) dan 1 ruas jahe. Jika menggunakan blender, disarankan blender kasar saja, jangan terlalu halus."
- "Panaskan wajan, tambahkan 2 sdm minyak kelapa. Jangan lupa, tambahkan minyak saat panas wajan sudah merata.  Tumis bumbu halus, tambahkan sereh/serai-geprek, daun jeruk (disobek di bagian tengah/tulang daun agar harumnya lebih terasa), jahe-geprek. Tambahkan garam dan gula pasir secukupnya."
- "Masukkan kaki babi yang sudah direbus dan dipotong lebih kecil ke dalam tumisan. Campur rata, masak dengan api kecil.   Bisa tambahkan sedikit air (+50ml), aduk rata, tutup. Masak hingga air habis. Proses ini untuk membuat rasa rempah lebih meresap, jadi bisa sesekali diaduk."
- "Jika air sudah habis, aduk sekali lagi, matikan api.   Jika suka, tambahkan potongan kecil kulit jeruk limau/lemon cui. Supaya rasa pedas masakan beraroma lebih segar.  Terkadang saya menambahkan daun kemangi petik, lalu dicampur rata. Sisa panas masakan akan membuat aroma kulit jeruk dan daun kemangi membuat masakan lebih menggoda..hahaaa :))"
categories:
- Recipe
tags:
- pork
- leg
- rica

katakunci: pork leg rica 
nutrition: 213 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dinner

---


![Pork Leg Rica Lemongrass (Babi Rica Serai)](https://img-global.cpcdn.com/recipes/c0a648e92bded650/751x532cq70/pork-leg-rica-lemongrass-babi-rica-serai-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga gurih. Ciri khas masakan Indonesia pork leg rica lemongrass (babi rica serai) yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah memasak Pork Leg Rica Lemongrass (Babi Rica Serai) untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang dapat anda coba salah satunya pork leg rica lemongrass (babi rica serai) yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep pork leg rica lemongrass (babi rica serai) tanpa harus bersusah payah.
Berikut ini resep Pork Leg Rica Lemongrass (Babi Rica Serai) yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 10 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Pork Leg Rica Lemongrass (Babi Rica Serai):

1. Jangan lupa 1 potong kaki babi
1. Dibutuhkan 5-7 cabai merah keriting
1. Harus ada 10-15 buah cabai rawit merah (sesuaikan dengan selera pedas anda)
1. Siapkan 8 siung bawang putih (sebagian untuk merebus kaki babi)
1. Harus ada 7 siung bawang merah
1. Dibutuhkan 5 ruas jahe kupas (sebagian untuk merebus kaki babi
1. Tambah 3 batang serai/sereh
1. Harap siapkan 4 lembar daun jeruk
1. Tambah secukupnya garam+gula pasir
1. Tambah secukupnya minyak kelapa untuk menumis




<!--inarticleads2-->

##### Cara membuat  Pork Leg Rica Lemongrass (Babi Rica Serai):

1. Potong kaki babi menjadi ukuran lebih kecil. Karena struktur tulang yg sangat keras, anda bisa minta tolong pada penjual saat membeli kaki babi. -  - Bersihkan dari serpihan tulang yang tersisa, cuci bersih dengan air mengalir lalu tiriskan. -  - Panaskan air hingga benar-benar mendidih, masukkan 4 siung bawang putih-geprek, 2 ruas jahe kupas-geprek, lalu masukkan potongan kaki babi. Tutup rebus hingga tingkat lunak yang diinginkan. Jika air habis, tambahkan air panas (jangan gunakan air dingin karena dapat membuat rebusan menjadi alot kembali).
1. Haluskan bawang merah (semua), bawang putih (4 siung), cabai rawit (semua), cabai merah (semua) dan 1 ruas jahe. Jika menggunakan blender, disarankan blender kasar saja, jangan terlalu halus.
1. Panaskan wajan, tambahkan 2 sdm minyak kelapa. Jangan lupa, tambahkan minyak saat panas wajan sudah merata. -  - Tumis bumbu halus, tambahkan sereh/serai-geprek, daun jeruk (disobek di bagian tengah/tulang daun agar harumnya lebih terasa), jahe-geprek. Tambahkan garam dan gula pasir secukupnya.
1. Masukkan kaki babi yang sudah direbus dan dipotong lebih kecil ke dalam tumisan. Campur rata, masak dengan api kecil.  -  - Bisa tambahkan sedikit air (+50ml), aduk rata, tutup. Masak hingga air habis. Proses ini untuk membuat rasa rempah lebih meresap, jadi bisa sesekali diaduk.
1. Jika air sudah habis, aduk sekali lagi, matikan api.  -  - Jika suka, tambahkan potongan kecil kulit jeruk limau/lemon cui. Supaya rasa pedas masakan beraroma lebih segar. -  - Terkadang saya menambahkan daun kemangi petik, lalu dicampur rata. Sisa panas masakan akan membuat aroma kulit jeruk dan daun kemangi membuat masakan lebih menggoda..hahaaa :))




Demikianlah cara membuat pork leg rica lemongrass (babi rica serai) yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan cepat, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
