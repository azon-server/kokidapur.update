---
description: "Step-by-Step membuat Jelita Cake Low Budget (2 telur) Homemade"
title: "Step-by-Step membuat Jelita Cake Low Budget (2 telur) Homemade"
slug: 6-step-by-step-membuat-jelita-cake-low-budget-2-telur-homemade
date: 2020-08-28T03:46:59.276Z
image: https://img-global.cpcdn.com/recipes/cd4e7f656cb60649/751x532cq70/jelita-cake-low-budget-2-telur-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cd4e7f656cb60649/751x532cq70/jelita-cake-low-budget-2-telur-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cd4e7f656cb60649/751x532cq70/jelita-cake-low-budget-2-telur-foto-resep-utama.jpg
author: Don Erickson
ratingvalue: 4.1
reviewcount: 11626
recipeingredient:
- "2 butir telur ayam"
- "4 sdm gula pasir jika suka manis bisa di tambah"
- "1 sdm sp resep aslinya tbm"
- "6 sdm tepung terigu"
- "1/2 sdt vanili saya skip"
- "1 sdm susu bubuk saya skip"
- "2 sdm full margarine yg blm di cairkan lalu cairkan dan suhu ruang"
- " pewarna makanan merah hijaucokelat"
- " Alat tambahan  Tusuk sate"
recipeinstructions:
- "Mixer telur, gula, dan sp dari kecepatan rendah ke tinggi sampai putih kental berjejak."
- "Tambahkan tepung lalu mixer dgn kecepatan rendah/aduk dgn spatula hingga tercampur rata."
- "Sisihkan sedikit adonan utk melukis. Dan beri warna sesuai selera. Sisihkan dahulu."
- "Tuangkan margarin cair kedalam sisa adonan tadi. Aduk lipat dengan spatula hingga tercampur rata dan tdk ada margarin yg mengendap didasar adonan."
- "Siapkan cetakan yg sdh diolesi margarin dan dilapisi kertas roti. (kalau bisa loyangnya seperti ini ya, jangan kebesaran nnti bolunya tipis). Tuang adonan ke dalam loyang, dan hentakan 2 kali."
- "Mulai melukis sesuai imajinasi masing-masing. Sembari melukis panaskan oven selama 10 menit di api sedang."
- "Kemudian, panggang bolu selama 25-30 menit di api sedang cenderung kecil. (saya pake otang) saya taruh di rak paling bawah. Tes tusuk utk mengecek kematangannya."
- "Jika sdh matang tunggu dingin dan keluarkan dari loyang. Untuk memberi efek garis-garis, bolu bisa ditelungkupkan di atas bakaran."
- "Siap di santap. Tekstur bolu super lembut yaaa."
categories:
- Recipe
tags:
- jelita
- cake
- low

katakunci: jelita cake low 
nutrition: 164 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT43M"
recipeyield: "3"
recipecategory: Dessert

---


![Jelita Cake Low Budget (2 telur)](https://img-global.cpcdn.com/recipes/cd4e7f656cb60649/751x532cq70/jelita-cake-low-budget-2-telur-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang setidaknya kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti jelita cake low budget (2 telur) yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan ciri khas yang merupakan keragaman Kita

Keharmonisan keluarga dapat ditemukan dengan cara simple. Salah satunya adalah membuat makanan Jelita Cake Low Budget (2 telur) untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang dapat anda buat salah satunya jelita cake low budget (2 telur) yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep jelita cake low budget (2 telur) tanpa harus bersusah payah.
Seperti resep Jelita Cake Low Budget (2 telur) yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Jelita Cake Low Budget (2 telur):

1. Harap siapkan 2 butir telur ayam
1. Harap siapkan 4 sdm gula pasir (jika suka manis bisa di tambah)
1. Diperlukan 1 sdm sp (resep aslinya tbm)
1. Harap siapkan 6 sdm tepung terigu
1. Jangan lupa 1/2 sdt vanili (saya skip)
1. Dibutuhkan 1 sdm susu bubuk (saya skip)
1. Tambah 2 sdm full margarine yg blm di cairkan. (lalu cairkan dan suhu ruang)
1. Siapkan  pewarna makanan (merah, hijau,cokelat)
1. Diperlukan  Alat tambahan : Tusuk sate




<!--inarticleads2-->

##### Cara membuat  Jelita Cake Low Budget (2 telur):

1. Mixer telur, gula, dan sp dari kecepatan rendah ke tinggi sampai putih kental berjejak.
1. Tambahkan tepung lalu mixer dgn kecepatan rendah/aduk dgn spatula hingga tercampur rata.
1. Sisihkan sedikit adonan utk melukis. Dan beri warna sesuai selera. Sisihkan dahulu.
1. Tuangkan margarin cair kedalam sisa adonan tadi. Aduk lipat dengan spatula hingga tercampur rata dan tdk ada margarin yg mengendap didasar adonan.
1. Siapkan cetakan yg sdh diolesi margarin dan dilapisi kertas roti. (kalau bisa loyangnya seperti ini ya, jangan kebesaran nnti bolunya tipis). Tuang adonan ke dalam loyang, dan hentakan 2 kali.
1. Mulai melukis sesuai imajinasi masing-masing. Sembari melukis panaskan oven selama 10 menit di api sedang.
1. Kemudian, panggang bolu selama 25-30 menit di api sedang cenderung kecil. (saya pake otang) saya taruh di rak paling bawah. Tes tusuk utk mengecek kematangannya.
1. Jika sdh matang tunggu dingin dan keluarkan dari loyang. Untuk memberi efek garis-garis, bolu bisa ditelungkupkan di atas bakaran.
1. Siap di santap. Tekstur bolu super lembut yaaa.




Demikianlah cara membuat jelita cake low budget (2 telur) yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan teruji, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
