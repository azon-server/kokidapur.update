---
description: "Resep : Babi rica kemangi Teruji"
title: "Resep : Babi rica kemangi Teruji"
slug: 303-resep-babi-rica-kemangi-teruji
date: 2020-10-24T09:43:54.851Z
image: https://img-global.cpcdn.com/recipes/011d4b059cea418c/751x532cq70/babi-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/011d4b059cea418c/751x532cq70/babi-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/011d4b059cea418c/751x532cq70/babi-rica-kemangi-foto-resep-utama.jpg
author: Francis Barrett
ratingvalue: 4.9
reviewcount: 49234
recipeingredient:
- "1/2 kg daging babi"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "5 buah kemiri yg sdh di sangrai"
- "1 ruas kunyit"
- "1/2 ruas jahe"
- "sesuai selera Cabe rawit"
- "2 batang sereh ambil bagian putihnya"
- "3 lembar daun jeruk"
- "2 ikat daun kemangi"
- "2 batang daun bawang"
- "1 lembar daun kunyit yg masih muda"
- "1 lembar daun pandan di buat simpul"
- " Garam"
recipeinstructions:
- "Haluskan (sy pake blender), bawang merah, bawang putih, sereh, kunyit, jahe, kemiri dan cabe, kalo di blender tambahkan sedikit minyak goreng"
- "Iris halus daun kunyit dan daun bawang"
- "Bersihkan daun kemangi"
- "Ganti telenan, hanti pisau, potong daging sesuai selera, sy potong seukuran potongan daging utk sate"
- "Tumis bumbu halus, bila sudah harum, masukkan daun kunyit, daun jeruk, daun bawang dan daun pandan, bila sdh layu masukkan daging, tambahkan garam secukupnya, bila sudah masak matikan api masukkan daun kemangi"
- "Pindahkan ke piring saji"
categories:
- Recipe
tags:
- babi
- rica
- kemangi

katakunci: babi rica kemangi 
nutrition: 276 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Dinner

---


![Babi rica kemangi](https://img-global.cpcdn.com/recipes/011d4b059cea418c/751x532cq70/babi-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang patut kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti babi rica kemangi yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Nusantara

Kedekatan keluarga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak Babi rica kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang dapat anda buat salah satunya babi rica kemangi yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep babi rica kemangi tanpa harus bersusah payah.
Berikut ini resep Babi rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 14 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Babi rica kemangi:

1. Jangan lupa 1/2 kg daging babi
1. Jangan lupa 10 siung bawang merah
1. Jangan lupa 5 siung bawang putih
1. Tambah 5 buah kemiri yg sdh di sangrai
1. Dibutuhkan 1 ruas kunyit
1. Harap siapkan 1/2 ruas jahe
1. Harus ada sesuai selera Cabe rawit
1. Diperlukan 2 batang sereh, ambil bagian putihnya
1. Tambah 3 lembar daun jeruk
1. Harus ada 2 ikat daun kemangi
1. Tambah 2 batang daun bawang
1. Diperlukan 1 lembar daun kunyit yg masih muda
1. Dibutuhkan 1 lembar daun pandan di buat simpul
1. Diperlukan  Garam




<!--inarticleads2-->

##### Bagaimana membuat  Babi rica kemangi:

1. Haluskan (sy pake blender), bawang merah, bawang putih, sereh, kunyit, jahe, kemiri dan cabe, kalo di blender tambahkan sedikit minyak goreng
1. Iris halus daun kunyit dan daun bawang
1. Bersihkan daun kemangi
1. Ganti telenan, hanti pisau, potong daging sesuai selera, sy potong seukuran potongan daging utk sate
1. Tumis bumbu halus, bila sudah harum, masukkan daun kunyit, daun jeruk, daun bawang dan daun pandan, bila sdh layu masukkan daging, tambahkan garam secukupnya, bila sudah masak matikan api masukkan daun kemangi
1. Pindahkan ke piring saji




Demikianlah cara membuat babi rica kemangi yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan teruji, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
