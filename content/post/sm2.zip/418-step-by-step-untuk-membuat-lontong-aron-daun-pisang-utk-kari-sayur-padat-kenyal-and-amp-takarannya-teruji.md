---
description: "Step-by-Step untuk membuat Lontong Aron Daun Pisang Utk Kari/Sayur Padat Kenyal&amp;amp;Takarannya Teruji"
title: "Step-by-Step untuk membuat Lontong Aron Daun Pisang Utk Kari/Sayur Padat Kenyal&amp;amp;Takarannya Teruji"
slug: 418-step-by-step-untuk-membuat-lontong-aron-daun-pisang-utk-kari-sayur-padat-kenyal-and-amp-takarannya-teruji
date: 2021-02-20T11:04:32.804Z
image: https://img-global.cpcdn.com/recipes/a898e59ab839ce35/751x532cq70/lontong-aron-daun-pisang-utk-karisayur-padat-kenyaltakarannya-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a898e59ab839ce35/751x532cq70/lontong-aron-daun-pisang-utk-karisayur-padat-kenyaltakarannya-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a898e59ab839ce35/751x532cq70/lontong-aron-daun-pisang-utk-karisayur-padat-kenyaltakarannya-foto-resep-utama.jpg
author: Troy Love
ratingvalue: 4.3
reviewcount: 2271
recipeingredient:
- "1 kg beras"
- "2500 ml air jika ingin lontong yang lembek tambah hingga 3 ltr"
- "1 sdm peres garam"
- "3 sdm air kapur sirih hanya bagian yang bening"
- " Daun pisang yang panjang"
- "Lidi potong serong untuk menyemat"
recipeinstructions:
- "Cuci beras lalu tiriskan"
- "Tuang beras, air, garam dan larutan kapur sirih dalam panci/citel, rebus hingga air terserap habis"
- "Angkat beras aron, aduk aduk hingga beras aron dingin"
- "Bungkus beras dengan daun pisang (diisi hingga penuh dan dipadatkan), semat dengan lidi. Gunakan daun berlapis dua atau lebih agar lontong tidak bleber (robek)"
- "Rebus lontong dengan posisi berdiri menggunakan api kecil selama 3 jam sejak air mendidih. Air perebus harus merendam lontong."
- "Setelah api dimatikan, angkat lontong dan tiriskan dengan posisi berdiri"
- "Cara saya membuat air larutan kapur sirih: 1/4 sdt kapur sirih dari pasar dituang ke dalam botol bekas selai lalu dituang air hingga penuh, biarkan mengendap, ambil beberapa sendok makan hanya bagian atas yang beningnya saja. Saya bisa menggunakan kapur sirih yang sama untuk berkali kali pengambilan air kapur sirih bening"
categories:
- Recipe
tags:
- lontong
- aron
- daun

katakunci: lontong aron daun 
nutrition: 208 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Lunch

---


![Lontong Aron Daun Pisang Utk Kari/Sayur Padat Kenyal&amp;Takarannya](https://img-global.cpcdn.com/recipes/a898e59ab839ce35/751x532cq70/lontong-aron-daun-pisang-utk-karisayur-padat-kenyaltakarannya-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas hingga renyah. Karasteristik makanan Indonesia lontong aron daun pisang utk kari/sayur padat kenyal&amp;takarannya yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kedekatan keluarga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Lontong Aron Daun Pisang Utk Kari/Sayur Padat Kenyal&amp;Takarannya untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang dapat anda contoh salah satunya lontong aron daun pisang utk kari/sayur padat kenyal&amp;takarannya yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep lontong aron daun pisang utk kari/sayur padat kenyal&amp;takarannya tanpa harus bersusah payah.
Berikut ini resep Lontong Aron Daun Pisang Utk Kari/Sayur Padat Kenyal&amp;Takarannya yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 6 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Lontong Aron Daun Pisang Utk Kari/Sayur Padat Kenyal&amp;Takarannya:

1. Diperlukan 1 kg beras
1. Jangan lupa 2500 ml air (jika ingin lontong yang lembek tambah hingga 3 ltr)
1. Tambah 1 sdm peres garam
1. Tambah 3 sdm air kapur sirih (hanya bagian yang bening)
1. Harap siapkan  Daun pisang yang panjang
1. Tambah Lidi potong serong untuk menyemat




<!--inarticleads2-->

##### Bagaimana membuat  Lontong Aron Daun Pisang Utk Kari/Sayur Padat Kenyal&amp;Takarannya:

1. Cuci beras lalu tiriskan
1. Tuang beras, air, garam dan larutan kapur sirih dalam panci/citel, rebus hingga air terserap habis
1. Angkat beras aron, aduk aduk hingga beras aron dingin
1. Bungkus beras dengan daun pisang (diisi hingga penuh dan dipadatkan), semat dengan lidi. Gunakan daun berlapis dua atau lebih agar lontong tidak bleber (robek)
1. Rebus lontong dengan posisi berdiri menggunakan api kecil selama 3 jam sejak air mendidih. Air perebus harus merendam lontong.
1. Setelah api dimatikan, angkat lontong dan tiriskan dengan posisi berdiri
1. Cara saya membuat air larutan kapur sirih: 1/4 sdt kapur sirih dari pasar dituang ke dalam botol bekas selai lalu dituang air hingga penuh, biarkan mengendap, ambil beberapa sendok makan hanya bagian atas yang beningnya saja. Saya bisa menggunakan kapur sirih yang sama untuk berkali kali pengambilan air kapur sirih bening




Demikianlah cara membuat lontong aron daun pisang utk kari/sayur padat kenyal&amp;takarannya yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
