---
description: "Resep : Cake board merah putih 🇮🇩🇮🇩 minggu ini"
title: "Resep : Cake board merah putih 🇮🇩🇮🇩 minggu ini"
slug: 9-resep-cake-board-merah-putih-minggu-ini
date: 2020-11-06T13:04:44.677Z
image: https://img-global.cpcdn.com/recipes/1c07ed7ea1b57679/751x532cq70/cake-board-merah-putih-🇮🇩🇮🇩-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1c07ed7ea1b57679/751x532cq70/cake-board-merah-putih-🇮🇩🇮🇩-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1c07ed7ea1b57679/751x532cq70/cake-board-merah-putih-🇮🇩🇮🇩-foto-resep-utama.jpg
author: Johnny Cunningham
ratingvalue: 5
reviewcount: 36640
recipeingredient:
- "4 butir telur"
- "150 gram gula pasir"
- "1 sdt SP boleh 1 sdm"
- "150 gram tepung terigu"
- "30 gram susu bubuk"
- "1 sachet vanilli bubuk resep asli 12 batang vanilla bean"
- "1/4 sdt garam"
- "1 bks santan instant 65 ml"
- "150 cc minyak goreng"
- "3 sdm kental manis"
- "Secukupnya pewarna makanan merah"
- " Buttercream"
- "500 gram mentega putih"
- "300 gram gula halus"
- "1 sachet vanilli bubuk resep asli 1 sdt vanilla extrack"
- "1 sdm susu cair"
recipeinstructions:
- "Siapkan bahan2"
- "Olesi loyang dengan karlo atau olesi dengan margarin dan taburi tepung tipis2,alasi dengan kertas roti.ayak tepung terigu,susu bubuk,vanilli bubuk dan garam.aduk rata minyak,santan dan kental manis"
- "Mixer telur,gula pasir dan SP hingga putih kental berjejak.mixer dengan speed rendah dulu hingga tercampur rata baru naikan speed secara bertahap.saya mixer kira2 8 menit"
- "Masukan campuran tepung,mixer speed rendah asal tercampur rata"
- "Tuang campuran minyak sedikit demi sedikit sambil diaduk balik perlahan dengan spatula"
- "Bagi adonan menjadi 2 bagian.beri pewarna merah di satu bagian adonan"
- "Tuang setengah bagian warna putih ke loyang.kukus selama 15 menit pake api sedang supaya permukaan cake tidak bergelombang.kukusan sudah dipanaskan sebelumnya hingga beruap.alasi tutup kukusan dengan serbet bersih.test tusuk adonan pake lidi kalo tidak lengket berati sudah matang.lakukan hal yang sama hingga selesai.jadi setiap warna dibagi 2 hasilnya ada 4 layer cake"
- "Setelah matang angkat,keluarkan dari loyang,lepaskan kertas rotinya dan dinginkan suhu ruang.loyangnya dioles lagi dengan karlo dan alasi kertas roti lagi untuk mengukus cake selanjutnya"
- "Cara membuat buttercream:mixer mentega putih hingga mengembang.tambahkan gula halus dan susu cair.mixer lagi hingga creamy dan ringan"
- "Penyelesain:cetak setiap layer cake dengan cutting cake (saya cetak pake kertas.karena panjang dan lebar cake 14 cm jadi saya buat lebar setiap potongan cake 2 cm) olesi bagian dalam cake dengan buttercream"
- "Susun cake dengan warna selang seling.olesi permukaan cake dengan buttercream,letakan layer selanjutnya dengan warna selang seling.lakukan hingga selesai.olesi seluruh permukaan cake dengan buttercream.beri hiasan sesuai selera.masukan ke kulkas selama 2 jam supaya set baru potong2"
- "Sajikan.ini buatan pertama😍"
- "Ini buatanku yang kedua😍"
categories:
- Recipe
tags:
- cake
- board
- merah

katakunci: cake board merah 
nutrition: 114 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Lunch

---


![Cake board merah putih 🇮🇩🇮🇩](https://img-global.cpcdn.com/recipes/1c07ed7ea1b57679/751x532cq70/cake-board-merah-putih-🇮🇩🇮🇩-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang dapat kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti cake board merah putih 🇮🇩🇮🇩 yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan ciri khas yang merupakan keragaman Nusantara

Kehangatan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Cake board merah putih 🇮🇩🇮🇩 untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang bisa anda contoh salah satunya cake board merah putih 🇮🇩🇮🇩 yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep cake board merah putih 🇮🇩🇮🇩 tanpa harus bersusah payah.
Seperti resep Cake board merah putih 🇮🇩🇮🇩 yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 13 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Cake board merah putih 🇮🇩🇮🇩:

1. Tambah 4 butir telur
1. Jangan lupa 150 gram gula pasir
1. Diperlukan 1 sdt SP (boleh 1 sdm)
1. Diperlukan 150 gram tepung terigu
1. Jangan lupa 30 gram susu bubuk
1. Jangan lupa 1 sachet vanilli bubuk (resep asli 1/2 batang vanilla bean)
1. Jangan lupa 1/4 sdt garam
1. Tambah 1 bks santan instant 65 ml
1. Harap siapkan 150 cc minyak goreng
1. Dibutuhkan 3 sdm kental manis
1. Diperlukan Secukupnya pewarna makanan merah
1. Jangan lupa  Buttercream:
1. Dibutuhkan 500 gram mentega putih
1. Harus ada 300 gram gula halus
1. Jangan lupa 1 sachet vanilli bubuk (resep asli 1 sdt vanilla extrack)
1. Harap siapkan 1 sdm susu cair




<!--inarticleads2-->

##### Instruksi membuat  Cake board merah putih 🇮🇩🇮🇩:

1. Siapkan bahan2
1. Olesi loyang dengan karlo atau olesi dengan margarin dan taburi tepung tipis2,alasi dengan kertas roti.ayak tepung terigu,susu bubuk,vanilli bubuk dan garam.aduk rata minyak,santan dan kental manis
1. Mixer telur,gula pasir dan SP hingga putih kental berjejak.mixer dengan speed rendah dulu hingga tercampur rata baru naikan speed secara bertahap.saya mixer kira2 8 menit
1. Masukan campuran tepung,mixer speed rendah asal tercampur rata
1. Tuang campuran minyak sedikit demi sedikit sambil diaduk balik perlahan dengan spatula
1. Bagi adonan menjadi 2 bagian.beri pewarna merah di satu bagian adonan
1. Tuang setengah bagian warna putih ke loyang.kukus selama 15 menit pake api sedang supaya permukaan cake tidak bergelombang.kukusan sudah dipanaskan sebelumnya hingga beruap.alasi tutup kukusan dengan serbet bersih.test tusuk adonan pake lidi kalo tidak lengket berati sudah matang.lakukan hal yang sama hingga selesai.jadi setiap warna dibagi 2 hasilnya ada 4 layer cake
1. Setelah matang angkat,keluarkan dari loyang,lepaskan kertas rotinya dan dinginkan suhu ruang.loyangnya dioles lagi dengan karlo dan alasi kertas roti lagi untuk mengukus cake selanjutnya
1. Cara membuat buttercream:mixer mentega putih hingga mengembang.tambahkan gula halus dan susu cair.mixer lagi hingga creamy dan ringan
1. Penyelesain:cetak setiap layer cake dengan cutting cake (saya cetak pake kertas.karena panjang dan lebar cake 14 cm jadi saya buat lebar setiap potongan cake 2 cm) olesi bagian dalam cake dengan buttercream
1. Susun cake dengan warna selang seling.olesi permukaan cake dengan buttercream,letakan layer selanjutnya dengan warna selang seling.lakukan hingga selesai.olesi seluruh permukaan cake dengan buttercream.beri hiasan sesuai selera.masukan ke kulkas selama 2 jam supaya set baru potong2
1. Sajikan.ini buatan pertama😍
1. Ini buatanku yang kedua😍




Demikianlah cara membuat cake board merah putih 🇮🇩🇮🇩 yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
