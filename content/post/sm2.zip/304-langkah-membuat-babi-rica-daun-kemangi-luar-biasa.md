---
description: "Langkah membuat Babi rica daun kemangi Luar biasa"
title: "Langkah membuat Babi rica daun kemangi Luar biasa"
slug: 304-langkah-membuat-babi-rica-daun-kemangi-luar-biasa
date: 2020-12-22T04:53:14.147Z
image: https://img-global.cpcdn.com/recipes/18f50b1573d77839/751x532cq70/babi-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/18f50b1573d77839/751x532cq70/babi-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/18f50b1573d77839/751x532cq70/babi-rica-daun-kemangi-foto-resep-utama.jpg
author: Eva Bridges
ratingvalue: 4.7
reviewcount: 10869
recipeingredient:
- "1 Kg Daging Babi"
- " Bumbu Halus "
- "7 Siung Bawang Merah"
- "6 Siung Bawang Putih"
- "3 cm Kunyit"
- "Secukupnya Lengkuas"
- "10 buah Cabe Merah Keriting"
- "5 buah Cabe Rawit Kalau mau pedes bisa ditambahin lagi"
- " Bahan Lainnya "
- " Garam"
- " Gula"
- "5 Buah Daun Salam"
- "5 Buah Daun Jeruk"
- "3 Buah Serai di Geprek"
- " Daun Kemangi"
recipeinstructions:
- "Tumis bumbu halus sampai wangi"
- "Masukkan Daun Salam, Daun jeruk dan Sereh"
- "Masukkan babi dan tambahkan air sedikit2 kemudian masak babi sampai empuk"
- "Masukkan daun kemangi"
- "Babi Rica siap dihidangkan"
categories:
- Recipe
tags:
- babi
- rica
- daun

katakunci: babi rica daun 
nutrition: 273 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Lunch

---


![Babi rica daun kemangi](https://img-global.cpcdn.com/recipes/18f50b1573d77839/751x532cq70/babi-rica-daun-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan gurih. Ciri makanan Nusantara babi rica daun kemangi yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kedekatan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Babi rica daun kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang dapat anda praktekkan salah satunya babi rica daun kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep babi rica daun kemangi tanpa harus bersusah payah.
Berikut ini resep Babi rica daun kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Babi rica daun kemangi:

1. Siapkan 1 Kg Daging Babi
1. Jangan lupa  Bumbu Halus :
1. Tambah 7 Siung Bawang Merah
1. Jangan lupa 6 Siung Bawang Putih
1. Harus ada 3 cm Kunyit
1. Diperlukan Secukupnya Lengkuas
1. Diperlukan 10 buah Cabe Merah Keriting
1. Tambah 5 buah Cabe Rawit (Kalau mau pedes bisa ditambahin lagi)
1. Siapkan  Bahan Lainnya :
1. Harap siapkan  Garam
1. Jangan lupa  Gula
1. Tambah 5 Buah Daun Salam
1. Siapkan 5 Buah Daun Jeruk
1. Dibutuhkan 3 Buah Serai di Geprek
1. Dibutuhkan  Daun Kemangi




<!--inarticleads2-->

##### Instruksi membuat  Babi rica daun kemangi:

1. Tumis bumbu halus sampai wangi
1. Masukkan Daun Salam, Daun jeruk dan Sereh
1. Masukkan babi dan tambahkan air sedikit2 kemudian masak babi sampai empuk
1. Masukkan daun kemangi
1. Babi Rica siap dihidangkan




Demikianlah cara membuat babi rica daun kemangi yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan teruji, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
