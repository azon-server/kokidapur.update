---
description: "Panduan untuk membuat Babi rica pedas ala Inggris teraktual"
title: "Panduan untuk membuat Babi rica pedas ala Inggris teraktual"
slug: 290-panduan-untuk-membuat-babi-rica-pedas-ala-inggris-teraktual
date: 2020-09-15T15:04:05.505Z
image: https://img-global.cpcdn.com/recipes/ad11313e3271de03/751x532cq70/babi-rica-pedas-ala-inggris-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ad11313e3271de03/751x532cq70/babi-rica-pedas-ala-inggris-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ad11313e3271de03/751x532cq70/babi-rica-pedas-ala-inggris-foto-resep-utama.jpg
author: Chris White
ratingvalue: 5
reviewcount: 19818
recipeingredient:
- "1 kg daging babi pork chops"
- "2 bawang merah besar 15 siung bawang merah shallot"
- "10 siung bawang putih garlic"
- "15 lombok merah hijau selera"
- "1 ruas lengkuas galangal"
- "1 ruas jahe"
- "1 butir kemiri"
- "1 sdm bubuk kunyit"
- "1 sdt bubuk ketumbar coriander"
- "1 sdt merica hitam black pepper"
- "2 batang serai onion grass"
- "4 lembar daun jeruk kefir lime leaves iris tipis2"
- "2 daun salam bayleaves"
- " Daun kemangi saya skip krn di UK tidak ada kalau pakai mint ga cocok"
- "secukupnya Garam dan gula"
- "Sedikit minyak goreng"
- "250 ml air bersih"
recipeinstructions:
- "Potong daging babi berbentuk dadu kecil (ukuran terserah selera)"
- "Ulek atau blender semua bumbu kecuali serai dan daun salam"
- "Panaskan minyak di wajan, masukkan bumbu yg telah dihaluskan + daun salam + serai, tumis sebentar sampai wangi."
- "Masukkan daging babi yang telah dipotong2, tumis, baru setelah itu masukkan air, beri garam gula secukupnya, tunggu sampai matang dan air berkurang"
- "Voila!!! Jadi deh, hidangkan dengan nasi yg masih panas.. wuenak tenan"
categories:
- Recipe
tags:
- babi
- rica
- pedas

katakunci: babi rica pedas 
nutrition: 149 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT60M"
recipeyield: "1"
recipecategory: Dessert

---


![Babi rica pedas ala Inggris](https://img-global.cpcdn.com/recipes/ad11313e3271de03/751x532cq70/babi-rica-pedas-ala-inggris-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang patut kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti babi rica pedas ala inggris yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa ciri khas yang merupakan keragaman Nusantara



Keharmonisan rumah tangga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Babi rica pedas ala Inggris untuk keluarga. kebersamaan makan bersama anak sudah menjadi budaya, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang bisa anda contoh salah satunya babi rica pedas ala inggris yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep babi rica pedas ala inggris tanpa harus bersusah payah.
Seperti resep Babi rica pedas ala Inggris yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Babi rica pedas ala Inggris:

1. Dibutuhkan 1 kg daging babi (pork chops)
1. Jangan lupa 2 bawang merah besar/ 15 siung bawang merah (shallot)
1. Siapkan 10 siung bawang putih (garlic)
1. Harus ada 15 lombok merah /hijau (selera)
1. Tambah 1 ruas lengkuas (galangal)
1. Harus ada 1 ruas jahe
1. Harap siapkan 1 butir kemiri
1. Dibutuhkan 1 sdm bubuk kunyit
1. Jangan lupa 1 sdt bubuk ketumbar (coriander?
1. Jangan lupa 1 sdt merica hitam (black pepper)
1. Harap siapkan 2 batang serai (onion grass)
1. Tambah 4 lembar daun jeruk (kefir lime leaves) iris tipis2
1. Diperlukan 2 daun salam (bayleaves)
1. Dibutuhkan  Daun kemangi (saya skip krn di UK tidak ada, kalau pakai mint ga cocok)
1. Diperlukan secukupnya Garam dan gula
1. Harus ada Sedikit minyak goreng
1. Harus ada 250 ml air bersih




<!--inarticleads2-->

##### Bagaimana membuat  Babi rica pedas ala Inggris:

1. Potong daging babi berbentuk dadu kecil (ukuran terserah selera)
1. Ulek atau blender semua bumbu kecuali serai dan daun salam
1. Panaskan minyak di wajan, masukkan bumbu yg telah dihaluskan + daun salam + serai, tumis sebentar sampai wangi.
1. Masukkan daging babi yang telah dipotong2, tumis, baru setelah itu masukkan air, beri garam gula secukupnya, tunggu sampai matang dan air berkurang
1. Voila!!! Jadi deh, hidangkan dengan nasi yg masih panas.. wuenak tenan




Demikianlah cara membuat babi rica pedas ala inggris yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan terbukti, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
