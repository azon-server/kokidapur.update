---
description: "Cara singkat untuk membuat Thai green tea ala dum dum Sempurna"
title: "Cara singkat untuk membuat Thai green tea ala dum dum Sempurna"
slug: 80-cara-singkat-untuk-membuat-thai-green-tea-ala-dum-dum-sempurna
date: 2020-12-17T22:21:42.748Z
image: https://img-global.cpcdn.com/recipes/ce64d9f2f279602b/751x532cq70/thai-green-tea-ala-dum-dum-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ce64d9f2f279602b/751x532cq70/thai-green-tea-ala-dum-dum-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ce64d9f2f279602b/751x532cq70/thai-green-tea-ala-dum-dum-foto-resep-utama.jpg
author: Delia Graham
ratingvalue: 4.2
reviewcount: 44665
recipeingredient:
- "500 ml air"
- "3 sendok makan serbuk teh green tea aku pakai merk chatrame"
- " susu kental manis optional"
- "3 sendok makan gula"
- " susu cair optional"
- " es batu"
recipeinstructions:
- "Didihkan air dalam api sedang, setelah mendidih masuk kan bubuk teh selama 2menit"
- "Setelah mendidih, pisahkan air teh dengan ampas nya"
- "Masuk kan air teh ke dalam cangkir kira2 setengah cangkir, (aku pakai cangkir ukuran sedang)"
- "Masukkan susu kental manis dan gula, aduk rata"
- "Terakhir masukan es batu, sus cair (aduk lagi). jadi deeeeh thai green tea rumahan rasa dum dum. ala.akyuuuuu"
categories:
- Recipe
tags:
- thai
- green
- tea

katakunci: thai green tea 
nutrition: 209 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dessert

---


![Thai green tea ala dum dum](https://img-global.cpcdn.com/recipes/ce64d9f2f279602b/751x532cq70/thai-green-tea-ala-dum-dum-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan renyah. Ciri khas masakan Nusantara thai green tea ala dum dum yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kehangatan keluarga bisa didapat dengan cara sederhana. Salah satunya adalah memasak Thai green tea ala dum dum untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang dapat anda praktekkan salah satunya thai green tea ala dum dum yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep thai green tea ala dum dum tanpa harus bersusah payah.
Berikut ini resep Thai green tea ala dum dum yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 6 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Thai green tea ala dum dum:

1. Harus ada 500 ml air
1. Tambah 3 sendok makan serbuk teh green tea (aku pakai merk chatrame)
1. Dibutuhkan  susu kental manis (optional)
1. Harus ada 3 sendok makan gula
1. Harus ada  susu cair (optional)
1. Harus ada  es batu




<!--inarticleads2-->

##### Instruksi membuat  Thai green tea ala dum dum:

1. Didihkan air dalam api sedang, setelah mendidih masuk kan bubuk teh selama 2menit
1. Setelah mendidih, pisahkan air teh dengan ampas nya
1. Masuk kan air teh ke dalam cangkir kira2 setengah cangkir, (aku pakai cangkir ukuran sedang)
1. Masukkan susu kental manis dan gula, aduk rata
1. Terakhir masukan es batu, sus cair (aduk lagi). jadi deeeeh thai green tea rumahan rasa dum dum. ala.akyuuuuu




Demikianlah cara membuat thai green tea ala dum dum yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
