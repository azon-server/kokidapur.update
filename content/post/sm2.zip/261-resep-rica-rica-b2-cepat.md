---
description: "Resep : Rica-rica B2 Cepat"
title: "Resep : Rica-rica B2 Cepat"
slug: 261-resep-rica-rica-b2-cepat
date: 2020-11-30T08:43:47.419Z
image: https://img-global.cpcdn.com/recipes/5172db84518d5ca7/751x532cq70/rica-rica-b2-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5172db84518d5ca7/751x532cq70/rica-rica-b2-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5172db84518d5ca7/751x532cq70/rica-rica-b2-foto-resep-utama.jpg
author: Francis Shelton
ratingvalue: 5
reviewcount: 13445
recipeingredient:
- "1 kg daging B2"
- " Bumbu halus"
- "5 butir kemiri"
- "20 biji cabe rawit"
- "6 biji cabe merah"
- "18 bawang merah"
- "13 bawang putih"
- "2 ruas jari kunyit"
- "1/2 gelas minyak goreng"
- " Bumbu lainnya"
- "2 air gelas"
- "3 daun jeruk"
- "4 daun salam"
- "2 ruas jari Laos"
- "3 sereh"
- "3 batang daun bawang"
- "2 buah tomat"
- "2 ikat kemangi"
recipeinstructions:
- "Rebus dahulu dagingnya sampai matang, buang airnya.. lalu potong sesuai selera"
- "Siapkan bumbu halus, cuci, lalu blender semua bumbu halus dicampur dengan minyak. Blender sampai hancur."
- "Siapkan bumbu yang lainnya (lengkuas, jahe,sereh) digeprek."
- "Cuci semua bahan tambahan sampai bersih. Iris bahan-bahan tambahan (daun bawang, tomat). Pisahkan daun kemangi dari batangnya."
- "Tumis semua bumbu yang sudah dihaluskan dan masukan (sereh, lengkuas, jahe, daun salam, daun jeruk). Tumis sampai harum dan agak matang."
- "Selanjutnya masukan daging, aduk hingga rata, dan tambahkan air 2 gelas. Masukan bumbu penyedap."
- "Tunggu sampai matang, jikalau sudah mau matang lalu masukan bahan-bahan yang sudah disiapkan (daun bawang, tomat, kemangi). Jikalau sudah angkat, dan pindahkan kewadah bersih."
- "SELAMAT MENCOBA😁"
categories:
- Recipe
tags:
- ricarica
- b2

katakunci: ricarica b2 
nutrition: 238 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Dessert

---


![Rica-rica B2](https://img-global.cpcdn.com/recipes/5172db84518d5ca7/751x532cq70/rica-rica-b2-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti rica-rica b2 yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Nusantara

Keharmonisan keluarga bisa didapat dengan cara simple. Diantaranya adalah memasak Rica-rica B2 untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang bisa anda coba salah satunya rica-rica b2 yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep rica-rica b2 tanpa harus bersusah payah.
Berikut ini resep Rica-rica B2 yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Rica-rica B2:

1. Harus ada 1 kg daging B2
1. Harap siapkan  Bumbu halus:
1. Siapkan 5 butir kemiri
1. Harap siapkan 20 biji cabe rawit
1. Tambah 6 biji cabe merah
1. Tambah 18 bawang merah
1. Dibutuhkan 13 bawang putih
1. Harus ada 2 ruas jari kunyit
1. Tambah 1/2 gelas minyak goreng
1. Diperlukan  Bumbu lainnya:
1. Diperlukan 2 air gelas
1. Harap siapkan 3 daun jeruk
1. Diperlukan 4 daun salam
1. Dibutuhkan 2 ruas jari Laos
1. Tambah 3 sereh
1. Siapkan 3 batang daun bawang
1. Tambah 2 buah tomat
1. Dibutuhkan 2 ikat kemangi




<!--inarticleads2-->

##### Cara membuat  Rica-rica B2:

1. Rebus dahulu dagingnya sampai matang, buang airnya.. lalu potong sesuai selera
1. Siapkan bumbu halus, cuci, lalu blender semua bumbu halus dicampur dengan minyak. Blender sampai hancur.
1. Siapkan bumbu yang lainnya (lengkuas, jahe,sereh) digeprek.
1. Cuci semua bahan tambahan sampai bersih. Iris bahan-bahan tambahan (daun bawang, tomat). Pisahkan daun kemangi dari batangnya.
1. Tumis semua bumbu yang sudah dihaluskan dan masukan (sereh, lengkuas, jahe, daun salam, daun jeruk). Tumis sampai harum dan agak matang.
1. Selanjutnya masukan daging, aduk hingga rata, dan tambahkan air 2 gelas. Masukan bumbu penyedap.
1. Tunggu sampai matang, jikalau sudah mau matang lalu masukan bahan-bahan yang sudah disiapkan (daun bawang, tomat, kemangi). Jikalau sudah angkat, dan pindahkan kewadah bersih.
1. SELAMAT MENCOBA😁




Demikianlah cara membuat rica-rica b2 yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan teruji, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
