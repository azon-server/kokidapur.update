---
description: "Resep : Babi kentang rica terupdate"
title: "Resep : Babi kentang rica terupdate"
slug: 269-resep-babi-kentang-rica-terupdate
date: 2020-10-23T04:42:50.033Z
image: https://img-global.cpcdn.com/recipes/295f0a64c0317ded/751x532cq70/babi-kentang-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/295f0a64c0317ded/751x532cq70/babi-kentang-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/295f0a64c0317ded/751x532cq70/babi-kentang-rica-foto-resep-utama.jpg
author: Zachary Vega
ratingvalue: 4.5
reviewcount: 3348
recipeingredient:
- "1 kg babi 500 gram sengkel dan 500 gram daging"
- "3 kentang uk sedang"
- "4 lembar daun jeruk sobek"
- "3 lembar daun salam sobek"
- "3 batang sereh bagian putihnya digeprek"
- " Garam lada gula"
- " Air"
- " Minyak"
- " Bumbu halus"
- "12 bawang merah"
- "8 bawang putih"
- "4 butir kemiri"
- "2 ruas lengkuas"
- "2 ruas jahe"
- "2 ruas kunyit"
- "30 cabe rawit setan"
- "8 cabe keriting"
recipeinstructions:
- "Blender semua bahan bumbu halus dengan ditambahkan minyak. Blender jangan sampai halus banget"
- "Kentang dipotong kotak2 tidak terlalu kecil, digoreng sampai empuk. (tusuk pakai garpu, bila mudah ditusuk tanda kentang sudah empuk)"
- "Tumis bumbu halus, tambahkan daun salam, daun jeruk dan sereh sampai berubah warna dan wangi, masukan babi sampai semua terbalur bumbu dan berubah warna, tambahkan air, beri garam, lada dan gula secukupnya. Masak sampai babi empuk (tambah air bila babi belum empuk/air kering). Setelah babi empuk masukan kentang aduk2 rata, test rasa. Masak sampai airnya nyemek2. Siap dihidangkan"
categories:
- Recipe
tags:
- babi
- kentang
- rica

katakunci: babi kentang rica 
nutrition: 114 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Dinner

---


![Babi kentang rica](https://img-global.cpcdn.com/recipes/295f0a64c0317ded/751x532cq70/babi-kentang-rica-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti babi kentang rica yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa keistimewahan yang merupakan keragaman Kita



Kedekatan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Babi kentang rica untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis makanan yang bisa anda contoh salah satunya babi kentang rica yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep babi kentang rica tanpa harus bersusah payah.
Berikut ini resep Babi kentang rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Babi kentang rica:

1. Siapkan 1 kg babi (500 gram sengkel dan 500 gram daging)
1. Tambah 3 kentang uk sedang
1. Siapkan 4 lembar daun jeruk sobek
1. Harus ada 3 lembar daun salam sobek
1. Harap siapkan 3 batang sereh bagian putihnya digeprek
1. Harus ada  Garam, lada, gula
1. Dibutuhkan  Air
1. Harap siapkan  Minyak
1. Dibutuhkan  Bumbu halus:
1. Tambah 12 bawang merah
1. Diperlukan 8 bawang putih
1. Dibutuhkan 4 butir kemiri
1. Harus ada 2 ruas lengkuas
1. Dibutuhkan 2 ruas jahe
1. Tambah 2 ruas kunyit
1. Siapkan 30 cabe rawit setan
1. Siapkan 8 cabe keriting




<!--inarticleads2-->

##### Cara membuat  Babi kentang rica:

1. Blender semua bahan bumbu halus dengan ditambahkan minyak. Blender jangan sampai halus banget
1. Kentang dipotong kotak2 tidak terlalu kecil, digoreng sampai empuk. (tusuk pakai garpu, bila mudah ditusuk tanda kentang sudah empuk)
1. Tumis bumbu halus, tambahkan daun salam, daun jeruk dan sereh sampai berubah warna dan wangi, masukan babi sampai semua terbalur bumbu dan berubah warna, tambahkan air, beri garam, lada dan gula secukupnya. Masak sampai babi empuk (tambah air bila babi belum empuk/air kering). Setelah babi empuk masukan kentang aduk2 rata, test rasa. Masak sampai airnya nyemek2. Siap dihidangkan




Demikianlah cara membuat babi kentang rica yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
