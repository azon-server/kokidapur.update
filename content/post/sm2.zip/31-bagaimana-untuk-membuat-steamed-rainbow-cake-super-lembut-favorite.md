---
description: "Bagaimana untuk membuat Steamed Rainbow Cake Super Lembut Favorite"
title: "Bagaimana untuk membuat Steamed Rainbow Cake Super Lembut Favorite"
slug: 31-bagaimana-untuk-membuat-steamed-rainbow-cake-super-lembut-favorite
date: 2021-02-08T17:19:22.316Z
image: https://img-global.cpcdn.com/recipes/4a1241beeed01c1b/751x532cq70/steamed-rainbow-cake-super-lembut-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4a1241beeed01c1b/751x532cq70/steamed-rainbow-cake-super-lembut-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4a1241beeed01c1b/751x532cq70/steamed-rainbow-cake-super-lembut-foto-resep-utama.jpg
author: Lillie West
ratingvalue: 4.8
reviewcount: 6242
recipeingredient:
- " Bahan A "
- "4 butir telur"
- "150 gram gula pasir"
- "1 sdt sp"
- " Bahan B "
- "150 gram tepung terigu"
- "1/2 sdt baking powder"
- "1 saset susu bubuk full cream dancow"
- "1/2 sdt vanili bubuk"
- "Sejumput garam"
- " Bahan C "
- "6 sdm susu kental manis resep asli pake 1 saset"
- "1 bungkus kara 65 ml"
- "150 ml minyak sayur"
- " Pewarna makanan rainbow"
- " Hiasan "
- " Whipecreambuttercream"
- " Meises rainbow dll"
recipeinstructions:
- "Siapkan loyang (saya pakai loyang bulat ukuran 18×18). Siapkan 6 lembar kertas baking buat dasar loyang. Dan siapkan juga panci kukusan dgn tutup dibungkus serbet bersih."
- "Ayak Bahan B bahan kering. Campur Bahan C minyak, susu kental manis dan santan, sisihkan."
- "Mixer telur, gula dan sp sampai putih mengembang pucat."
- "Masukkan ayakan bahan kering selang seling dgn campuran minyak. Aduk balik rata sampai semua bahan tercampur."
- ""
- "Panaskan panci kukusan dgn api sedang."
- "Bagi adonan jadi 6 bagian. Beri masing2 warna."
- "Tuang warna merah pada loyang, lalu kukus selama 6-7 menit. Setelah matang angkat dan dinginkan. Kukus untuk warna yg lainnya."
- "Setelah matang angkat dan dinginkan. Hias sesuai selera. Selamat mencoba."
- ""
- ""
- "Hasilnya lembut bgt...wajib coba"
- "Rainbow cake pesanan....dalemnya rainbow ya hehe"
- ""
categories:
- Recipe
tags:
- steamed
- rainbow
- cake

katakunci: steamed rainbow cake 
nutrition: 295 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dinner

---


![Steamed Rainbow Cake Super Lembut](https://img-global.cpcdn.com/recipes/4a1241beeed01c1b/751x532cq70/steamed-rainbow-cake-super-lembut-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang harus kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti steamed rainbow cake super lembut yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa ciri khas yang merupakan keragaman Indonesia

Kehangatan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Steamed Rainbow Cake Super Lembut untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda buat salah satunya steamed rainbow cake super lembut yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep steamed rainbow cake super lembut tanpa harus bersusah payah.
Seperti resep Steamed Rainbow Cake Super Lembut yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 14 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Steamed Rainbow Cake Super Lembut:

1. Jangan lupa  Bahan A :
1. Dibutuhkan 4 butir telur
1. Harus ada 150 gram gula pasir
1. Jangan lupa 1 sdt sp
1. Jangan lupa  Bahan B :
1. Jangan lupa 150 gram tepung terigu
1. Siapkan 1/2 sdt baking powder
1. Tambah 1 saset susu bubuk full cream (dancow)
1. Tambah 1/2 sdt vanili bubuk
1. Dibutuhkan Sejumput garam
1. Diperlukan  Bahan C :
1. Jangan lupa 6 sdm susu kental manis (resep asli pake 1 saset)
1. Dibutuhkan 1 bungkus kara (65 ml)
1. Tambah 150 ml minyak sayur
1. Harus ada  Pewarna makanan rainbow
1. Diperlukan  Hiasan :
1. Diperlukan  Whipecream/buttercream
1. Tambah  Meises rainbow, dll




<!--inarticleads2-->

##### Cara membuat  Steamed Rainbow Cake Super Lembut:

1. Siapkan loyang (saya pakai loyang bulat ukuran 18×18). Siapkan 6 lembar kertas baking buat dasar loyang. Dan siapkan juga panci kukusan dgn tutup dibungkus serbet bersih.
1. Ayak Bahan B bahan kering. Campur Bahan C minyak, susu kental manis dan santan, sisihkan.
1. Mixer telur, gula dan sp sampai putih mengembang pucat.
1. Masukkan ayakan bahan kering selang seling dgn campuran minyak. Aduk balik rata sampai semua bahan tercampur.
1. 
1. Panaskan panci kukusan dgn api sedang.
1. Bagi adonan jadi 6 bagian. Beri masing2 warna.
1. Tuang warna merah pada loyang, lalu kukus selama 6-7 menit. Setelah matang angkat dan dinginkan. Kukus untuk warna yg lainnya.
1. Setelah matang angkat dan dinginkan. Hias sesuai selera. Selamat mencoba.
1. 
1. 
1. Hasilnya lembut bgt...wajib coba
1. Rainbow cake pesanan....dalemnya rainbow ya hehe
1. 




Demikianlah cara membuat steamed rainbow cake super lembut yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
