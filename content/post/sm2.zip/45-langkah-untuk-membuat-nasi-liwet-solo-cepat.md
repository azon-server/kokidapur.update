---
description: "Langkah untuk membuat Nasi Liwet Solo Cepat"
title: "Langkah untuk membuat Nasi Liwet Solo Cepat"
slug: 45-langkah-untuk-membuat-nasi-liwet-solo-cepat
date: 2020-10-22T08:18:15.990Z
image: https://img-global.cpcdn.com/recipes/5a2a42c17eaf84d5/751x532cq70/nasi-liwet-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5a2a42c17eaf84d5/751x532cq70/nasi-liwet-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5a2a42c17eaf84d5/751x532cq70/nasi-liwet-solo-foto-resep-utama.jpg
author: Helena Frank
ratingvalue: 4.2
reviewcount: 14874
recipeingredient:
- "400 gr beras 3 gelas takar"
- "65 ml santan instan"
- " Garam"
- "2 lbr daun salam"
- " Air"
- " Opor ayam"
- " Lihat resep sebelumnya yaa"
- " Sambal goreng labu siam"
- "2 buah labu siam iris korek api"
- "800 ml kuah opor"
- "700 ml air"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "5 buah cabe merah besar buang bijinya haluskan"
- "10 buah cabe rawit merahhijau"
- "2 lbr daun salam"
- "1 ruas lengkuas geprek"
- " Telur kukus"
- "3 butir telur"
- "100 ml kuah opor"
- " Garam"
- " Areh"
- "4 butir putih telur"
- "200 ml santan"
- " Garam"
recipeinstructions:
- "Untuk nasinya, sy masak pakai rice cooker. Cuci beras sampai bersih, beri daun salam dan garam, 65ml santan kental instan, beri air seperti memasak nasi putih. Nyalakan rice cooker."
- "Untuk ayamnya, lihat resep opor ayam dan telur yaa. Setelah opor matang, tiriskan ayam dan telurnya. Sisihkan kuahnya untuk sayur labu siam dan telur kukus"
- "Sambel goreng labu siam. Iris duo bawang, haluskan cabai merah. Cabe rawit biarkan utuh."
- "Tumis duo bawang, daun salam, lengkuas sampai harum. Tambahkan cabe merah yg sudah dihaluskan, tumis sampai matang. Setelah matang, tuang ke dalam kuah opor, didihkan."
- "Masukkan labu siam yg sudah diiris korek api. Beri garam, gula merah, kaldu bubuk. Masukkan cabe rawit utuh. Masak sampai matang. Sesuaikan rasa."
- "Telur kukus. Kocok lepas 3 butir telur, beri kuah opor, garam, aduk rata. Tuang ke dalam wadah tahan panas. Kukus sampai matang"
- "Areh. kocok putih telur, tambahkan santan dan garam, aduk rata. Masak di atas kompor sambil diaduk2 sampai matang."
- "Untuk penyajiannya, tata nasi di piring, tuang sambal goreng labu siam, beri ayam opor yg disuwir suwir, beri telur rebus, telur kukus dan areh. Yummmm"
categories:
- Recipe
tags:
- nasi
- liwet
- solo

katakunci: nasi liwet solo 
nutrition: 112 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Dessert

---


![Nasi Liwet Solo](https://img-global.cpcdn.com/recipes/5a2a42c17eaf84d5/751x532cq70/nasi-liwet-solo-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau renyah. Ciri khas masakan Indonesia nasi liwet solo yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Nasi Liwet Solo untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian masakan yang dapat anda praktekkan salah satunya nasi liwet solo yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep nasi liwet solo tanpa harus bersusah payah.
Seperti resep Nasi Liwet Solo yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 25 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nasi Liwet Solo:

1. Dibutuhkan 400 gr beras (3 gelas takar)
1. Diperlukan 65 ml santan instan
1. Tambah  Garam
1. Tambah 2 lbr daun salam
1. Harus ada  Air
1. Harus ada  Opor ayam:
1. Harap siapkan  Lihat resep sebelumnya yaa
1. Dibutuhkan  Sambal goreng labu siam
1. Dibutuhkan 2 buah labu siam, iris korek api
1. Siapkan 800 ml kuah opor
1. Jangan lupa 700 ml air
1. Harus ada 8 siung bawang merah
1. Dibutuhkan 4 siung bawang putih
1. Harap siapkan 5 buah cabe merah besar, buang bijinya, haluskan
1. Dibutuhkan 10 buah cabe rawit merah/hijau
1. Jangan lupa 2 lbr daun salam
1. Dibutuhkan 1 ruas lengkuas, geprek
1. Siapkan  Telur kukus
1. Siapkan 3 butir telur
1. Tambah 100 ml kuah opor
1. Dibutuhkan  Garam
1. Jangan lupa  Areh
1. Jangan lupa 4 butir putih telur
1. Jangan lupa 200 ml santan
1. Harap siapkan  Garam




<!--inarticleads2-->

##### Cara membuat  Nasi Liwet Solo:

1. Untuk nasinya, sy masak pakai rice cooker. Cuci beras sampai bersih, beri daun salam dan garam, 65ml santan kental instan, beri air seperti memasak nasi putih. Nyalakan rice cooker.
1. Untuk ayamnya, lihat resep opor ayam dan telur yaa. Setelah opor matang, tiriskan ayam dan telurnya. Sisihkan kuahnya untuk sayur labu siam dan telur kukus
1. Sambel goreng labu siam. Iris duo bawang, haluskan cabai merah. Cabe rawit biarkan utuh.
1. Tumis duo bawang, daun salam, lengkuas sampai harum. Tambahkan cabe merah yg sudah dihaluskan, tumis sampai matang. Setelah matang, tuang ke dalam kuah opor, didihkan.
1. Masukkan labu siam yg sudah diiris korek api. Beri garam, gula merah, kaldu bubuk. Masukkan cabe rawit utuh. Masak sampai matang. Sesuaikan rasa.
1. Telur kukus. Kocok lepas 3 butir telur, beri kuah opor, garam, aduk rata. Tuang ke dalam wadah tahan panas. Kukus sampai matang
1. Areh. kocok putih telur, tambahkan santan dan garam, aduk rata. Masak di atas kompor sambil diaduk2 sampai matang.
1. Untuk penyajiannya, tata nasi di piring, tuang sambal goreng labu siam, beri ayam opor yg disuwir suwir, beri telur rebus, telur kukus dan areh. Yummmm




Demikianlah cara membuat nasi liwet solo yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan teruji, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
