---
description: "Cara untuk membuat Rica Rica Manado versi Ferry&amp;#39;s Pawon terupdate"
title: "Cara untuk membuat Rica Rica Manado versi Ferry&amp;#39;s Pawon terupdate"
slug: 358-cara-untuk-membuat-rica-rica-manado-versi-ferry-and-39-s-pawon-terupdate
date: 2020-08-29T17:43:25.068Z
image: https://img-global.cpcdn.com/recipes/8599a72528c7895b/751x532cq70/rica-rica-manado-versi-ferrys-pawon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8599a72528c7895b/751x532cq70/rica-rica-manado-versi-ferrys-pawon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8599a72528c7895b/751x532cq70/rica-rica-manado-versi-ferrys-pawon-foto-resep-utama.jpg
author: Verna Adams
ratingvalue: 4
reviewcount: 5128
recipeingredient:
- "500 gr Daging babi bisa di ganti daging ayam sapi  kambing"
- "2 buah Tomat buang bag dalamnya kemudian cincang"
- "1 butir Jeruk nipis peras airnya"
- "5 helai Daun jeruk"
- "1 ikat Kemangi ambil daunnya"
- " Bumbu Yang Dihaluskan "
- "10 siung Bawang merah"
- "5 siung Bawang putih"
- "10 buah Cabai merah keriting"
- "20 buah Cabai rawit"
- "1 jari Jahe"
- "2 jari Kunyit"
- "4 batang Serai ambil bag yg putih"
- "2 sdm Garam sesuai selera"
- "1 sdm Gula sesuai selera"
recipeinstructions:
- "Cuci bersih daging,kemudian potong potong sesuai hati nurani.."
- "Tumis bumbu halus dengan minyak, setelah harum masukan tomat cincang dan daun jeruk.. kalau sudah terlihat layu masukkan daging.. tumis sampai daging berubah warna... setelah itu tambahkan air.."
- "Rebus hingga air susut,tes keempukan daging,jikalau msh keras tambah kan air lagi.. setelah daging empuk masukan daun kemangi dan perasan air jeruk nipis... tes rasa kira nya apa yg kurang (Ps : tes rasa di akhir setelah air susut biar ga terlalu manis atau asin pemirsa)"
- "Hmmm... dimakan pake nasi anget rasanya enak betul.. selamat mencoba..."
categories:
- Recipe
tags:
- rica
- rica
- manado

katakunci: rica rica manado 
nutrition: 300 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Dessert

---


![Rica Rica Manado versi Ferry&#39;s Pawon](https://img-global.cpcdn.com/recipes/8599a72528c7895b/751x532cq70/rica-rica-manado-versi-ferrys-pawon-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau renyah. Ciri khas makanan Indonesia rica rica manado versi ferry&#39;s pawon yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Rica Rica Manado versi Ferry&#39;s Pawon untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang bisa anda contoh salah satunya rica rica manado versi ferry&#39;s pawon yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep rica rica manado versi ferry&#39;s pawon tanpa harus bersusah payah.
Berikut ini resep Rica Rica Manado versi Ferry&#39;s Pawon yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Rica Rica Manado versi Ferry&#39;s Pawon:

1. Jangan lupa 500 gr Daging babi (bisa di ganti daging ayam, sapi / kambing)
1. Siapkan 2 buah Tomat (buang bag dalamnya kemudian cincang)
1. Diperlukan 1 butir Jeruk nipis (peras airnya)
1. Dibutuhkan 5 helai Daun jeruk
1. Jangan lupa 1 ikat Kemangi (ambil daunnya)
1. Dibutuhkan  Bumbu Yang Dihaluskan :
1. Dibutuhkan 10 siung Bawang merah
1. Tambah 5 siung Bawang putih
1. Jangan lupa 10 buah Cabai merah keriting
1. Diperlukan 20 buah Cabai rawit
1. Jangan lupa 1 jari Jahe
1. Harus ada 2 jari Kunyit
1. Dibutuhkan 4 batang Serai (ambil bag yg putih)
1. Diperlukan 2 sdm Garam (sesuai selera)
1. Harus ada 1 sdm Gula (sesuai selera)




<!--inarticleads2-->

##### Cara membuat  Rica Rica Manado versi Ferry&#39;s Pawon:

1. Cuci bersih daging,kemudian potong potong sesuai hati nurani..
1. Tumis bumbu halus dengan minyak, setelah harum masukan tomat cincang dan daun jeruk.. kalau sudah terlihat layu masukkan daging.. tumis sampai daging berubah warna... setelah itu tambahkan air..
1. Rebus hingga air susut,tes keempukan daging,jikalau msh keras tambah kan air lagi.. setelah daging empuk masukan daun kemangi dan perasan air jeruk nipis... tes rasa kira nya apa yg kurang (Ps : tes rasa di akhir setelah air susut biar ga terlalu manis atau asin pemirsa)
1. Hmmm... dimakan pake nasi anget rasanya enak betul.. selamat mencoba...




Demikianlah cara membuat rica rica manado versi ferry&#39;s pawon yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan teruji, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
