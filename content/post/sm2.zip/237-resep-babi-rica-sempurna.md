---
description: "Resep : Babi Rica Sempurna"
title: "Resep : Babi Rica Sempurna"
slug: 237-resep-babi-rica-sempurna
date: 2020-12-25T13:54:18.206Z
image: https://img-global.cpcdn.com/recipes/63803371517b9e5d/751x532cq70/babi-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/63803371517b9e5d/751x532cq70/babi-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/63803371517b9e5d/751x532cq70/babi-rica-foto-resep-utama.jpg
author: Don Ray
ratingvalue: 5
reviewcount: 40556
recipeingredient:
- "1/2 kg daging babi samcan"
- "8 siung bawang merah"
- "3 siung bawang putih"
- "1/2 sendok teh kunyit bubuk"
- "2 buah cabai merah besar"
- "10 biji cabe rawit"
- "2 batang serai memarkan"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 ikat kemangi"
- "1 sendok teh garam"
- "1/2 sendok teh merica"
- "1/2 sendok gula pasir"
- "2 cm jahe"
- "2 batang daun bawang"
- "500 cc air putih"
recipeinstructions:
- "Haluskan bawang merah, bawang putih, cabai merah, cabe rawit, jahe lalu tumis dengan minyak babi (sebelumnya lemak babi nya saya lelehkan dulu dan minyak itu di pakai menumis)"
- "Setelah harum masukkan serai, daun salam, daun jeruk, kunyit tumis hingga harum.. masukkan daging babi samcan hingga kecoklatan, tambahkan air 500cc masak hingga daging empuk dan air nya terserap, koreksi rasa"
- "Sebelum api dimatikan masukkan kemangi dan daun bawang aduk hingga rata hingga mendidih lalu matikan api.. babi rica siap dihidangkan"
categories:
- Recipe
tags:
- babi
- rica

katakunci: babi rica 
nutrition: 286 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Dinner

---


![Babi Rica](https://img-global.cpcdn.com/recipes/63803371517b9e5d/751x532cq70/babi-rica-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti babi rica yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan ciri khas yang merupakan keragaman Kita



Kehangatan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Babi Rica untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang bisa anda buat salah satunya babi rica yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep babi rica tanpa harus bersusah payah.
Seperti resep Babi Rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Babi Rica:

1. Diperlukan 1/2 kg daging babi (samcan)
1. Tambah 8 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Jangan lupa 1/2 sendok teh kunyit bubuk
1. Dibutuhkan 2 buah cabai merah besar
1. Jangan lupa 10 biji cabe rawit
1. Tambah 2 batang serai (memarkan)
1. Harus ada 2 lembar daun salam
1. Tambah 2 lembar daun jeruk
1. Jangan lupa 1 ikat kemangi
1. Siapkan 1 sendok teh garam
1. Dibutuhkan 1/2 sendok teh merica
1. Tambah 1/2 sendok gula pasir
1. Harap siapkan 2 cm jahe
1. Harap siapkan 2 batang daun bawang
1. Tambah 500 cc air putih




<!--inarticleads2-->

##### Cara membuat  Babi Rica:

1. Haluskan bawang merah, bawang putih, cabai merah, cabe rawit, jahe lalu tumis dengan minyak babi (sebelumnya lemak babi nya saya lelehkan dulu dan minyak itu di pakai menumis)
1. Setelah harum masukkan serai, daun salam, daun jeruk, kunyit tumis hingga harum.. masukkan daging babi samcan hingga kecoklatan, tambahkan air 500cc masak hingga daging empuk dan air nya terserap, koreksi rasa
1. Sebelum api dimatikan masukkan kemangi dan daun bawang aduk hingga rata hingga mendidih lalu matikan api.. babi rica siap dihidangkan




Demikianlah cara membuat babi rica yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
