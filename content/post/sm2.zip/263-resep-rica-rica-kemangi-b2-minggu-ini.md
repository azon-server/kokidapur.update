---
description: "Resep : Rica-rica Kemangi B2 minggu ini"
title: "Resep : Rica-rica Kemangi B2 minggu ini"
slug: 263-resep-rica-rica-kemangi-b2-minggu-ini
date: 2021-02-16T08:07:22.821Z
image: https://img-global.cpcdn.com/recipes/881b4fd9b2d5e7cb/751x532cq70/rica-rica-kemangi-b2-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/881b4fd9b2d5e7cb/751x532cq70/rica-rica-kemangi-b2-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/881b4fd9b2d5e7cb/751x532cq70/rica-rica-kemangi-b2-foto-resep-utama.jpg
author: Caroline Park
ratingvalue: 5
reviewcount: 3724
recipeingredient:
- "1/2 kg daging b2 khas dalam"
- "1/2 ikat daun kemangi"
- "2 batang sereh"
- " Bumbu yang dihaluskan"
- "1/4 kg cabai rawit sesuai selera"
- "4 lembar daun jeruk"
- "3 siung bawang putih"
- "3 siung bawang merah"
- "1/2 sdt merica bubuk"
- "1/2 sdt kunir bubuk"
- "4 sdm minyak sayur"
- "2 sdt garam"
- "1/2 sdt penyedap totole"
recipeinstructions:
- "Cuci bersih daging b2, potong dadu. Sisihkan"
- "Bumbu tumis bisa dicincang atau dirajang halus. Kecuali sereh"
- "Panaskan minyak, lalu masukkan bumbu yang sudah dihaluskan"
- "Setelah bumbu mulai harum, masukkan daging b2 &amp; daun kemangi.Didihkan 5 menit"
- "Ada cara rahasia dan irit untuk bikin daging jadi empuk. Setelah 5 menit daging b2 mendidih, matikan kompor. Tutup rapat wajan/panci, diamkan 15-20 menit (jangan dibuka sblum waktu tersebut). Setelah itu api kompor bisa dinyalakan lagi."
- "Aduk-aduk hingga bumbu meresap dan mendidih. Sesuaikan rasa dan selera. Selamat mencoba"
categories:
- Recipe
tags:
- ricarica
- kemangi
- b2

katakunci: ricarica kemangi b2 
nutrition: 280 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT37M"
recipeyield: "3"
recipecategory: Dinner

---


![Rica-rica Kemangi B2](https://img-global.cpcdn.com/recipes/881b4fd9b2d5e7cb/751x532cq70/rica-rica-kemangi-b2-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga empuk. Ciri masakan Indonesia rica-rica kemangi b2 yang penuh dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Rica-rica dalam bahasa Manado (Sulawesi Utara) berarti pedas atau cabe. dalam proses masaknya beraneka ragam. Masakan kali ini dengan menambah daun kemangi. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Resep ayam rica-rica kemangi di atas bisa kalian coba untuk dijadikan menu lauk di rumah.

Keharmonisan rumah tangga bisa didapat dengan cara sederhana. Salah satunya adalah memasak Rica-rica Kemangi B2 untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang dapat anda coba salah satunya rica-rica kemangi b2 yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep rica-rica kemangi b2 tanpa harus bersusah payah.
Berikut ini resep Rica-rica Kemangi B2 yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Rica-rica Kemangi B2:

1. Harap siapkan 1/2 kg daging b2 khas dalam
1. Dibutuhkan 1/2 ikat daun kemangi
1. Tambah 2 batang sereh
1. Harus ada  Bumbu yang dihaluskan
1. Tambah 1/4 kg cabai rawit (sesuai selera)
1. Siapkan 4 lembar daun jeruk
1. Diperlukan 3 siung bawang putih
1. Harap siapkan 3 siung bawang merah
1. Harap siapkan 1/2 sdt merica bubuk
1. Jangan lupa 1/2 sdt kunir bubuk
1. Harap siapkan 4 sdm minyak sayur
1. Harap siapkan 2 sdt garam
1. Jangan lupa 1/2 sdt penyedap (totole)


Resepnya sederhana dan mudah, khas Manado asli pakai daun kemangi. Wajib coba bagi pecinta makanan pedas. Rica-rica (or sometimes simply called rica) is a type of Southeast Asian hot and spicy bumbu (spice mixture) found in Manado cuisine of North Sulawesi, Indonesia. Rica-rica uses much chopped or ground red and green chili peppers, bird&#39;s eye chili, shallots, garlic, ginger. 

<!--inarticleads2-->

##### Langkah membuat  Rica-rica Kemangi B2:

1. Cuci bersih daging b2, potong dadu. Sisihkan
1. Bumbu tumis bisa dicincang atau dirajang halus. Kecuali sereh
1. Panaskan minyak, lalu masukkan bumbu yang sudah dihaluskan
1. Setelah bumbu mulai harum, masukkan daging b2 &amp; daun kemangi.Didihkan 5 menit
1. Ada cara rahasia dan irit untuk bikin daging jadi empuk. Setelah 5 menit daging b2 mendidih, matikan kompor. Tutup rapat wajan/panci, diamkan 15-20 menit (jangan dibuka sblum waktu tersebut). Setelah itu api kompor bisa dinyalakan lagi.
1. Aduk-aduk hingga bumbu meresap dan mendidih. Sesuaikan rasa dan selera. Selamat mencoba


Rica-rica (or sometimes simply called rica) is a type of Southeast Asian hot and spicy bumbu (spice mixture) found in Manado cuisine of North Sulawesi, Indonesia. Rica-rica uses much chopped or ground red and green chili peppers, bird&#39;s eye chili, shallots, garlic, ginger. Namun sekarang sudah banyak resep masakan rica rica ini, seperti : ayam rica rica kemangi, resep rica rica ceker, resep rica rica menthok, resep rica Bahan bumbu ayam rica rica yang digunakan sebenarnya cukup simple dan sederhana, seperti : kunyit, jahe, serai, cabai merah, bawang putih. Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Resep Masak Rica-Rica Ayam kampung Kemangi Pedas Подробнее. 

Demikianlah cara membuat rica-rica kemangi b2 yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
