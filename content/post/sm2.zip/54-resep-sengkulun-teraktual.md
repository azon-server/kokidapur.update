---
description: "Resep : Sengkulun teraktual"
title: "Resep : Sengkulun teraktual"
slug: 54-resep-sengkulun-teraktual
date: 2020-12-13T10:07:02.232Z
image: https://img-global.cpcdn.com/recipes/8fc17e895fed37c8/751x532cq70/sengkulun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8fc17e895fed37c8/751x532cq70/sengkulun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8fc17e895fed37c8/751x532cq70/sengkulun-foto-resep-utama.jpg
author: Bertie Wong
ratingvalue: 5
reviewcount: 2630
recipeingredient:
- "300 gram tepung ketan"
- "100 gram tepung kanji"
- "300 gram gula pasir"
- "1/2 sdm garam"
- "1/2 sdt vanili"
- "3-4 daun jeruk"
- "1/3 sdt pewarna makanan pink"
- "1 butir kelapa setengah tua diparut saat akan dimasak"
recipeinstructions:
- "Campur tepung terigu, tepung kanji, vanili, garam dan gula pasir bisa menggunakan garpu atau tangan."
- "Tambahkan parutan kelapa, aduk sampai rata. Masukkan daun jeruk dan campur (daun jeruk nantinya ikut dikukus bersama adonan semua)."
- "Bagi adonan menjadi dua, separuhnya beri pewarna makanan, separuhnya biarkan berwarna putih. Siapkan kukusan (tutupnya lapisi lap bersih agar air tidak menetes). Masukkan adonan berwarna pink terlebih dahulu, baru masukkan adonan berwarna putih, kukus selama 30 menit atau sampai matang, angkat dan sajikan."
categories:
- Recipe
tags:
- sengkulun

katakunci: sengkulun 
nutrition: 202 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Dinner

---


![Sengkulun](https://img-global.cpcdn.com/recipes/8fc17e895fed37c8/751x532cq70/sengkulun-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti sengkulun yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa ciri khas yang merupakan keragaman Indonesia



Kedekatan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak Sengkulun untuk orang di rumah. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang bisa anda contoh salah satunya sengkulun yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep sengkulun tanpa harus bersusah payah.
Berikut ini resep Sengkulun yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 8 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sengkulun:

1. Harus ada 300 gram tepung ketan
1. Jangan lupa 100 gram tepung kanji
1. Harap siapkan 300 gram gula pasir
1. Dibutuhkan 1/2 sdm garam
1. Jangan lupa 1/2 sdt vanili
1. Jangan lupa 3-4 daun jeruk
1. Harap siapkan 1/3 sdt pewarna makanan pink
1. Diperlukan 1 butir kelapa setengah tua (diparut saat akan dimasak)




<!--inarticleads2-->

##### Bagaimana membuat  Sengkulun:

1. Campur tepung terigu, tepung kanji, vanili, garam dan gula pasir bisa menggunakan garpu atau tangan.
1. Tambahkan parutan kelapa, aduk sampai rata. Masukkan daun jeruk dan campur (daun jeruk nantinya ikut dikukus bersama adonan semua).
1. Bagi adonan menjadi dua, separuhnya beri pewarna makanan, separuhnya biarkan berwarna putih. Siapkan kukusan (tutupnya lapisi lap bersih agar air tidak menetes). Masukkan adonan berwarna pink terlebih dahulu, baru masukkan adonan berwarna putih, kukus selama 30 menit atau sampai matang, angkat dan sajikan.




Demikianlah cara membuat sengkulun yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
