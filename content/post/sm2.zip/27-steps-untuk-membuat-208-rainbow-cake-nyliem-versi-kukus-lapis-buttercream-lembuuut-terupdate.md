---
description: "Steps untuk membuat 208. Rainbow Cake Ny.Liem versi Kukus Lapis ButterCream,Lembuuut terupdate"
title: "Steps untuk membuat 208. Rainbow Cake Ny.Liem versi Kukus Lapis ButterCream,Lembuuut terupdate"
slug: 27-steps-untuk-membuat-208-rainbow-cake-nyliem-versi-kukus-lapis-buttercream-lembuuut-terupdate
date: 2021-02-05T13:51:04.860Z
image: https://img-global.cpcdn.com/recipes/61c116d6c9ea2166/751x532cq70/208-rainbow-cake-nyliem-versi-kukus-lapis-buttercreamlembuuut-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/61c116d6c9ea2166/751x532cq70/208-rainbow-cake-nyliem-versi-kukus-lapis-buttercreamlembuuut-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/61c116d6c9ea2166/751x532cq70/208-rainbow-cake-nyliem-versi-kukus-lapis-buttercreamlembuuut-foto-resep-utama.jpg
author: Marian Wheeler
ratingvalue: 4.6
reviewcount: 22891
recipeingredient:
- "4 btr telur"
- "200 gr Gula Pasir"
- "1/2 sdt Essens Vanilla"
- "1 Sdm SP"
- "Sejumput Garam"
- "150 cc Minyak"
- "1 sct Santan Kara"
- "4 sdm SKM"
- " Pewarna makanan bebas merk"
- " Bahan Kering Campurkan dan Ayak"
- "150 gr Tepung Terigu Kunci BiruSegitiga Biru"
- "1 sachet Susu Dancow Bubuk"
- "1/3 sdt Baking Powder"
- " Resep Butter Cream  Kocok hingga mengembang"
- "200 gr Mentega Putih"
- "75 gr Gula Halus"
- "1 sdt Essens Vanilla"
- "30 ml Susu Kental Manis"
recipeinstructions:
- "Siapkan bahannya dulu. Agar tidak repot saat pengerjaan. Panaskan kukusan."
- "Mixer telu dan gula hingga gula larut kemudian masukkan essens vanilla dan garam. Masukkan SP aduk hingga berjejak."
- "Berjejak maksudnya seperti ini yaa."
- "Turunkan speed rendah (speed 1) masukkan bahan kering secara bertahap. Kemudian masukkan SKM dan santan mixer sebentar saja jangan terlalu lama oke. Matikan mixer."
- "Masukkan minyak aduk balik jangan terlalu kuat pelan-pelan biar adonan tidak bantat."
- "Bagi adonan menjadi 5-6bagian. Saya 5 saja. Beri pewarna makanan. Aduk2."
- "Kukusan harus sudah dipanaskan 15menit sebelumnya bungkus tutup dengan serbet atau kain. Ambil loyang lalu lapisi dengan kertas minyak. Kukus 1 warna dulu sekitar 6-7mnt yaa. Angkat lalu dinginkan. Ganti kertas baru tuang adonan selanjutnya dan terus seperti itu sampai adonan habis. Setelah dingin, Olesi butter cream."
- "Lakukan pengolesan sampai selesai yaa beri topping sesuai selera. Ratakan pinggirannya dengan pisau tajam."
- "Potong-potong cake sesuai selera ya. Sajikan. Selamat mencoba. Recommended😙😙"
categories:
- Recipe
tags:
- 208
- rainbow
- cake

katakunci: 208 rainbow cake 
nutrition: 217 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Lunch

---


![208. Rainbow Cake Ny.Liem versi Kukus Lapis ButterCream,Lembuuut](https://img-global.cpcdn.com/recipes/61c116d6c9ea2166/751x532cq70/208-rainbow-cake-nyliem-versi-kukus-lapis-buttercreamlembuuut-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas dan empuk. Ciri khas makanan Nusantara 208. rainbow cake ny.liem versi kukus lapis buttercream,lembuuut yang penuh dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan keluarga dapat diperoleh dengan cara mudah. Diantaranya adalah memasak 208. Rainbow Cake Ny.Liem versi Kukus Lapis ButterCream,Lembuuut untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang bisa anda praktekkan salah satunya 208. rainbow cake ny.liem versi kukus lapis buttercream,lembuuut yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep 208. rainbow cake ny.liem versi kukus lapis buttercream,lembuuut tanpa harus bersusah payah.
Seperti resep 208. Rainbow Cake Ny.Liem versi Kukus Lapis ButterCream,Lembuuut yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 208. Rainbow Cake Ny.Liem versi Kukus Lapis ButterCream,Lembuuut:

1. Tambah 4 btr telur
1. Dibutuhkan 200 gr Gula Pasir
1. Tambah 1/2 sdt Essens Vanilla
1. Tambah 1 Sdm SP
1. Dibutuhkan Sejumput Garam
1. Siapkan 150 cc Minyak
1. Harus ada 1 sct Santan Kara
1. Dibutuhkan 4 sdm SKM
1. Siapkan  Pewarna makanan, bebas merk
1. Harap siapkan  Bahan Kering, Campurkan dan Ayak:
1. Diperlukan 150 gr Tepung Terigu Kunci Biru/Segitiga Biru
1. Jangan lupa 1 sachet Susu Dancow Bubuk
1. Dibutuhkan 1/3 sdt Baking Powder
1. Jangan lupa  Resep Butter Cream : (Kocok hingga mengembang)
1. Harap siapkan 200 gr Mentega Putih
1. Jangan lupa 75 gr Gula Halus
1. Jangan lupa 1 sdt Essens Vanilla
1. Jangan lupa 30 ml Susu Kental Manis




<!--inarticleads2-->

##### Cara membuat  208. Rainbow Cake Ny.Liem versi Kukus Lapis ButterCream,Lembuuut:

1. Siapkan bahannya dulu. Agar tidak repot saat pengerjaan. Panaskan kukusan.
1. Mixer telu dan gula hingga gula larut kemudian masukkan essens vanilla dan garam. Masukkan SP aduk hingga berjejak.
1. Berjejak maksudnya seperti ini yaa.
1. Turunkan speed rendah (speed 1) masukkan bahan kering secara bertahap. Kemudian masukkan SKM dan santan mixer sebentar saja jangan terlalu lama oke. Matikan mixer.
1. Masukkan minyak aduk balik jangan terlalu kuat pelan-pelan biar adonan tidak bantat.
1. Bagi adonan menjadi 5-6bagian. Saya 5 saja. Beri pewarna makanan. Aduk2.
1. Kukusan harus sudah dipanaskan 15menit sebelumnya bungkus tutup dengan serbet atau kain. Ambil loyang lalu lapisi dengan kertas minyak. Kukus 1 warna dulu sekitar 6-7mnt yaa. Angkat lalu dinginkan. Ganti kertas baru tuang adonan selanjutnya dan terus seperti itu sampai adonan habis. Setelah dingin, Olesi butter cream.
1. Lakukan pengolesan sampai selesai yaa beri topping sesuai selera. Ratakan pinggirannya dengan pisau tajam.
1. Potong-potong cake sesuai selera ya. Sajikan. Selamat mencoba. Recommended😙😙




Demikianlah cara membuat 208. rainbow cake ny.liem versi kukus lapis buttercream,lembuuut yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
