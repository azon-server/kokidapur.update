---
description: "Langkah membuat Babi Rica Asli Manado (Bokek Rica) Homemade"
title: "Langkah membuat Babi Rica Asli Manado (Bokek Rica) Homemade"
slug: 244-langkah-membuat-babi-rica-asli-manado-bokek-rica-homemade
date: 2020-09-14T14:41:52.267Z
image: https://img-global.cpcdn.com/recipes/17d68be0e7a9bbce/751x532cq70/babi-rica-asli-manado-bokek-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/17d68be0e7a9bbce/751x532cq70/babi-rica-asli-manado-bokek-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/17d68be0e7a9bbce/751x532cq70/babi-rica-asli-manado-bokek-rica-foto-resep-utama.jpg
author: Antonio Lee
ratingvalue: 4.9
reviewcount: 24441
recipeingredient:
- "500 gr Daging Pork"
- "1 Daun bawang"
- "3 lembar daun jeruk"
- "3 lembar daun salam"
- "3 batang sereh"
- " Bumbu halus "
- "20 bj cabe rawit"
- "2 bj cabe merah"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 ruas lengkuas"
- "5 bj kemiri"
- "7 butir Bawang merah"
- "6 butir Bawang putih"
- "secukupnya garam"
- "secukupnya lada"
- "secukupnya air"
recipeinstructions:
- "Tumis bumbu halus + daun jeruk + sereh hingga wangi"
- "Masukkan daging pork"
- "Tambahkan air hingga wajan penuh"
- "Tunggu hingga daging empuk dan air meresap"
- "Masukkan daun salam dan daun bawang"
- "Tambahkan garam dan merica secukupnya"
- "Tes rasa"
- "Bokek Rica siap dihidangkan 😊😊😊"
categories:
- Recipe
tags:
- babi
- rica
- asli

katakunci: babi rica asli 
nutrition: 182 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT58M"
recipeyield: "1"
recipecategory: Dinner

---


![Babi Rica Asli Manado (Bokek Rica)](https://img-global.cpcdn.com/recipes/17d68be0e7a9bbce/751x532cq70/babi-rica-asli-manado-bokek-rica-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau renyah. Ciri khas masakan Indonesia babi rica asli manado (bokek rica) yang penuh dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan keluarga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Babi Rica Asli Manado (Bokek Rica) untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang bisa anda contoh salah satunya babi rica asli manado (bokek rica) yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep babi rica asli manado (bokek rica) tanpa harus bersusah payah.
Berikut ini resep Babi Rica Asli Manado (Bokek Rica) yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Babi Rica Asli Manado (Bokek Rica):

1. Harus ada 500 gr Daging Pork
1. Dibutuhkan 1 Daun bawang
1. Jangan lupa 3 lembar daun jeruk
1. Jangan lupa 3 lembar daun salam
1. Harus ada 3 batang sereh
1. Siapkan  Bumbu halus :
1. Tambah 20 bj cabe rawit
1. Diperlukan 2 bj cabe merah
1. Siapkan 1 ruas jahe
1. Tambah 1 ruas kunyit
1. Diperlukan 1 ruas lengkuas
1. Siapkan 5 bj kemiri
1. Harap siapkan 7 butir Bawang merah
1. Harap siapkan 6 butir Bawang putih
1. Harus ada secukupnya garam
1. Diperlukan secukupnya lada
1. Harus ada secukupnya air




<!--inarticleads2-->

##### Instruksi membuat  Babi Rica Asli Manado (Bokek Rica):

1. Tumis bumbu halus + daun jeruk + sereh hingga wangi
1. Masukkan daging pork
1. Tambahkan air hingga wajan penuh
1. Tunggu hingga daging empuk dan air meresap
1. Masukkan daun salam dan daun bawang
1. Tambahkan garam dan merica secukupnya
1. Tes rasa
1. Bokek Rica siap dihidangkan 😊😊😊




Demikianlah cara membuat babi rica asli manado (bokek rica) yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
