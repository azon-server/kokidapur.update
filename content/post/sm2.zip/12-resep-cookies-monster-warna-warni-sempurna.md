---
description: "Resep : Cookies monster warna warni🍪 Sempurna"
title: "Resep : Cookies monster warna warni🍪 Sempurna"
slug: 12-resep-cookies-monster-warna-warni-sempurna
date: 2020-09-13T09:06:12.216Z
image: https://img-global.cpcdn.com/recipes/fad49e17e21f8335/751x532cq70/cookies-monster-warna-warni🍪-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fad49e17e21f8335/751x532cq70/cookies-monster-warna-warni🍪-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fad49e17e21f8335/751x532cq70/cookies-monster-warna-warni🍪-foto-resep-utama.jpg
author: Sean Morrison
ratingvalue: 4.1
reviewcount: 46545
recipeingredient:
- " Bahan basah"
- "100 gram butter cair resep sebelumnya aku pake mentega"
- "70 gram brown sugargula palem kalo kalian gaada brown sugar gapapa ko pake gula putih semua tapi brown sugar gunanya bikin cookiesnya lebih empuk"
- "50 gram gula putih sesuai selera kalo mau manis tambah gula putihnya"
- "1 butir telor"
- "1 sdt vanila extra"
- " Pewarna makanan"
- " Bahan kering"
- "200 gram tepung terigu"
- "1 sdt baking soda"
- " Sedikitsejumput garam"
- " Toping aku pake nyamnyam chacha peanut chacha coklat sprinkle"
recipeinstructions:
- "Masukan semua bahan basah sesuai resep di atas kecuali pewarna, dimulai dari butter sampai terakhir vanilla, lalu kocok sampai semua bahan tercampur dan rata"
- "Diwadah lain masukan bahan kering yaitu terigu dan baking soda juga garam, lalu aduk agar baking soda dan garam tercampur"
- "Karna 1 bahan ini bisa jadi 2 adonan warna cookies, jadi bahan basahnya dibagi 2, lalu bahan kering juga dibagi menjadi masing2 100gram"
- "Campurkan bahan kering yg sudah dibagi tadi kedalam bahan basah yg sudah dibagi 2, sedikit dulu aja sekitar 3-4 sendok makan lalu aduk, beri pewarna lalu aduk kembali (aku masukin 5 tetes pewarna,tp sesuai selera kalian aja ya,kalo merasa kurang boleh tambah sampai 7tetes, jgn terlalu kebanyakan pewarna karna nanti jadi pait)"
- "Setelah diaduk dan warna nya rata, masukin sisa terigu tadi (bukan terigu yg udh dibagi 2 ya, kan ini dibikin jd 2 adonan)"
- "Setelah menjadi adonan tambahkan toping sprinkle (gapake juga gapapa) lalu aduk sampai tercampur pada adonan"
- "Siapkan loyang yg sudah diberi alas kertas roti, lalu bentuk adonan seperti ini, dan beri jarak tiap adonan (karna ini monster cookies jadi bentuk nya besar ya), tambahin topping diatasnya jgn lupa"
- "Panaskan oven terlebih dahulu sekitar 15-20 menit (karna aku pake oven kompor). Lalu panggang selama 20-25 menit, dan jgn lupa buat di balik2 dan pindah2 dari bawah keatas biar ga gosong bawah cookiesnya (kalo pake oven listrik gausah ya tinggal tunggu mateng aja😋)"
- "Setelah mateng lalu tiriskan deh, jadinya sebesar ini (maaf kalo penyampaian resepnya kurang jelas, boleh chat aku kalo mau tanya2)😊"
- "Selamat mencoba! Kasih tau aku ya kalo berhasil"
categories:
- Recipe
tags:
- cookies
- monster
- warna

katakunci: cookies monster warna 
nutrition: 154 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT53M"
recipeyield: "4"
recipecategory: Lunch

---


![Cookies monster warna warni🍪](https://img-global.cpcdn.com/recipes/fad49e17e21f8335/751x532cq70/cookies-monster-warna-warni🍪-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang patut kita jaga karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti cookies monster warna warni🍪 yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Kita

Kedekatan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah memasak Cookies monster warna warni🍪 untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang bisa anda coba salah satunya cookies monster warna warni🍪 yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep cookies monster warna warni🍪 tanpa harus bersusah payah.
Seperti resep Cookies monster warna warni🍪 yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 12 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Cookies monster warna warni🍪:

1. Harus ada  Bahan basah
1. Dibutuhkan 100 gram butter cair (resep sebelumnya aku pake mentega)
1. Harus ada 70 gram brown sugar/gula palem (kalo kalian gaada brown sugar gapapa ko pake gula putih semua, tapi brown sugar gunanya bikin cookiesnya lebih empuk)
1. Siapkan 50 gram gula putih/ sesuai selera (kalo mau manis tambah gula putihnya)
1. Diperlukan 1 butir telor
1. Dibutuhkan 1 sdt vanila extra
1. Harap siapkan  Pewarna makanan
1. Dibutuhkan  Bahan kering
1. Harap siapkan 200 gram tepung terigu
1. Diperlukan 1 sdt baking soda
1. Siapkan  Sedikit/sejumput garam
1. Diperlukan  Toping (aku pake nyamnyam, chacha peanut, chacha coklat, sprinkle)




<!--inarticleads2-->

##### Cara membuat  Cookies monster warna warni🍪:

1. Masukan semua bahan basah sesuai resep di atas kecuali pewarna, dimulai dari butter sampai terakhir vanilla, lalu kocok sampai semua bahan tercampur dan rata
1. Diwadah lain masukan bahan kering yaitu terigu dan baking soda juga garam, lalu aduk agar baking soda dan garam tercampur
1. Karna 1 bahan ini bisa jadi 2 adonan warna cookies, jadi bahan basahnya dibagi 2, lalu bahan kering juga dibagi menjadi masing2 100gram
1. Campurkan bahan kering yg sudah dibagi tadi kedalam bahan basah yg sudah dibagi 2, sedikit dulu aja sekitar 3-4 sendok makan lalu aduk, beri pewarna lalu aduk kembali (aku masukin 5 tetes pewarna,tp sesuai selera kalian aja ya,kalo merasa kurang boleh tambah sampai 7tetes, jgn terlalu kebanyakan pewarna karna nanti jadi pait)
1. Setelah diaduk dan warna nya rata, masukin sisa terigu tadi (bukan terigu yg udh dibagi 2 ya, kan ini dibikin jd 2 adonan)
1. Setelah menjadi adonan tambahkan toping sprinkle (gapake juga gapapa) lalu aduk sampai tercampur pada adonan
1. Siapkan loyang yg sudah diberi alas kertas roti, lalu bentuk adonan seperti ini, dan beri jarak tiap adonan (karna ini monster cookies jadi bentuk nya besar ya), tambahin topping diatasnya jgn lupa
1. Panaskan oven terlebih dahulu sekitar 15-20 menit (karna aku pake oven kompor). Lalu panggang selama 20-25 menit, dan jgn lupa buat di balik2 dan pindah2 dari bawah keatas biar ga gosong bawah cookiesnya (kalo pake oven listrik gausah ya tinggal tunggu mateng aja😋)
1. Setelah mateng lalu tiriskan deh, jadinya sebesar ini (maaf kalo penyampaian resepnya kurang jelas, boleh chat aku kalo mau tanya2)😊
1. Selamat mencoba! Kasih tau aku ya kalo berhasil




Demikianlah cara membuat cookies monster warna warni🍪 yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan terbukti, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
