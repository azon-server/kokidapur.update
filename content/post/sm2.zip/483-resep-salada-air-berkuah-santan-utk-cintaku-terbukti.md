---
description: "Resep : SALADA AIR BERKUAH SANTAN UTK CINTAKU Terbukti"
title: "Resep : SALADA AIR BERKUAH SANTAN UTK CINTAKU Terbukti"
slug: 483-resep-salada-air-berkuah-santan-utk-cintaku-terbukti
date: 2021-01-15T19:55:17.221Z
image: https://img-global.cpcdn.com/recipes/Recipe_2015_02_06_16_52_23_416_1ef8a46fa821e654f8e7/751x532cq70/salada-air-berkuah-santan-utk-cintaku-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/Recipe_2015_02_06_16_52_23_416_1ef8a46fa821e654f8e7/751x532cq70/salada-air-berkuah-santan-utk-cintaku-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/Recipe_2015_02_06_16_52_23_416_1ef8a46fa821e654f8e7/751x532cq70/salada-air-berkuah-santan-utk-cintaku-foto-resep-utama.jpg
author: Ina Quinn
ratingvalue: 4.9
reviewcount: 34675
recipeingredient:
- "200 gr (3 ikat) Salada air"
- "60 gr Jamur bulat"
- "60 gr Toge"
- "3 siung bawang putih"
- "1 sdm Ebi"
- "400 ml Santan"
- "secukupnya Garam"
- "secukupnya Gula pasir"
- "2 sdm Minyak goreng"
recipeinstructions:
- "Potong-potong salada air, cuci dan tiriskan. Jamur dicuci dan dibelah 2, kmdn sisihkan. Toge dicuci, tiriskan dan sisihkan"
- "Bawang putih diiris kecil-kecil/ dicincang. Ebi direndam dulu dengan air hangat sekitar 10 menit, tiriskan lalu iris keci-kecil/ dicincang."
- "Panaskan minyak, tumis bawang putih hingga harum lalu masukkan ebi, aduk hingga rata."
- "Masukkan jamur, aduk merata sampai setengah matang"
- "Masukan toge, aduk rata sesaat baru masukkan salada air, aduk-aduk hingga merata dan salada airnya layu."
- "Masukkan santan, aduk merata, tambahkan garam dan gula secukupnya, aduk-aduk kembali. Tunggu hingga mendidih, angkat dan sajikan."
categories:
- Recipe
tags:
- salada
- air
- berkuah

katakunci: salada air berkuah 
nutrition: 123 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT31M"
recipeyield: "4"
recipecategory: Lunch

---


![SALADA AIR BERKUAH SANTAN UTK CINTAKU](https://img-global.cpcdn.com/recipes/Recipe_2015_02_06_16_52_23_416_1ef8a46fa821e654f8e7/751x532cq70/salada-air-berkuah-santan-utk-cintaku-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga enak. Karasteristik makanan Nusantara salada air berkuah santan utk cintaku yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga bisa ditemukan dengan cara simple. Diantaranya adalah memasak SALADA AIR BERKUAH SANTAN UTK CINTAKU untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang bisa anda coba salah satunya salada air berkuah santan utk cintaku yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep salada air berkuah santan utk cintaku tanpa harus bersusah payah.
Berikut ini resep SALADA AIR BERKUAH SANTAN UTK CINTAKU yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 9 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat SALADA AIR BERKUAH SANTAN UTK CINTAKU:

1. Diperlukan 200 gr (3 ikat) Salada air
1. Dibutuhkan 60 gr Jamur bulat
1. Tambah 60 gr Toge
1. Jangan lupa 3 siung bawang putih
1. Harap siapkan 1 sdm Ebi
1. Harap siapkan 400 ml Santan
1. Jangan lupa secukupnya Garam
1. Harus ada secukupnya Gula pasir
1. Harus ada 2 sdm Minyak goreng




<!--inarticleads2-->

##### Instruksi membuat  SALADA AIR BERKUAH SANTAN UTK CINTAKU:

1. Potong-potong salada air, cuci dan tiriskan. Jamur dicuci dan dibelah 2, kmdn sisihkan. Toge dicuci, tiriskan dan sisihkan
1. Bawang putih diiris kecil-kecil/ dicincang. Ebi direndam dulu dengan air hangat sekitar 10 menit, tiriskan lalu iris keci-kecil/ dicincang.
1. Panaskan minyak, tumis bawang putih hingga harum lalu masukkan ebi, aduk hingga rata.
1. Masukkan jamur, aduk merata sampai setengah matang
1. Masukan toge, aduk rata sesaat baru masukkan salada air, aduk-aduk hingga merata dan salada airnya layu.
1. Masukkan santan, aduk merata, tambahkan garam dan gula secukupnya, aduk-aduk kembali. Tunggu hingga mendidih, angkat dan sajikan.




Demikianlah cara membuat salada air berkuah santan utk cintaku yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat gampang dan cepat, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
