---
description: "Cara singkat untuk menyiapakan Rica rica ayam Sempurna"
title: "Cara singkat untuk menyiapakan Rica rica ayam Sempurna"
slug: 366-cara-singkat-untuk-menyiapakan-rica-rica-ayam-sempurna
date: 2020-11-25T08:06:15.652Z
image: https://img-global.cpcdn.com/recipes/f4e1df87503b5f92/751x532cq70/rica-rica-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f4e1df87503b5f92/751x532cq70/rica-rica-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f4e1df87503b5f92/751x532cq70/rica-rica-ayam-foto-resep-utama.jpg
author: Janie Diaz
ratingvalue: 4.6
reviewcount: 20947
recipeingredient:
- "1/2 kg ayamikanporktahutempe bebas ya ayamnya aku rebus dulu untuk menghilangkan lemak"
- " Bumbu halus"
- "5 buah cabe kriting"
- "7 buah cabe rawit kalau buat anak cabenya bisa utuh aja masukan saat air sudah mendidih"
- "10 bawang merah"
- "2 siung bawang putih"
- "1 ruas jari jahe kunyit laos"
- "1 sdm gula"
- "1 sdt garam"
- " Kalo ada blender bisa dihaluskan sekalian sama bumbu halusnya kalo pake ulekan cukup di memarkan aja"
- "6 lembar daun jeruk"
- "2 batang sereh kecil"
- " Masukan untuk ditumis"
- " Bumbu halus sereh daun jeruk"
- "2 lembar daun salam"
- " Masukan setelah bumbu selesai ditumis"
- "1/2 sdt kalduroyco"
- "250 ml Air untuk merebus kira2 aja sampai ayam terendam"
- "6 sdm minyak untuk menumis"
- " Kemangi jika ada"
recipeinstructions:
- "Haluskan bumbu halus dengan ulekan, kalo menggunakan blender haluskan juga sereh dan daun jeruknya"
- "Panaskan minyak goreng, setelah itu tumis bumbu halus, sereh, daun jeruk, daun salam hingga wangi dan matang"
- "Masukan air, tunggu hingga panas, masukan ayam."
- "Biarkan air sampai asat/berkurang, jangan lupa koreksi rasa"
- "Kalau mau rica2 berkuah, biarkan hingga air berkurang sedikit lalu matikan, masukkan kemangi segar (jika ada)"
- "Kalau mau rica2 tanpa kuah, biarkan airnya hingga berkurang, sisakan sedikit agar rica2 tidak kering. Matikan api, masukan kemangi (jika ada)"
categories:
- Recipe
tags:
- rica
- rica
- ayam

katakunci: rica rica ayam 
nutrition: 126 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Dinner

---


![Rica rica ayam](https://img-global.cpcdn.com/recipes/f4e1df87503b5f92/751x532cq70/rica-rica-ayam-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti rica rica ayam yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia

Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica. Resep rica rica sendiri sebenarnya tidak harus menggunakan bahan daging ayam saja. Cita rasa pedas menjadi ciri khas resep yang tergabung dalam masakan indonesia yang satu ini.

Kehangatan keluarga dapat diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Rica rica ayam untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang bisa anda praktekkan salah satunya rica rica ayam yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep rica rica ayam tanpa harus bersusah payah.
Berikut ini resep Rica rica ayam yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Rica rica ayam:

1. Diperlukan 1/2 kg ayam/ikan/pork/tahu/tempe (bebas ya) ayamnya aku rebus dulu untuk menghilangkan lemak
1. Harus ada  Bumbu halus
1. Diperlukan 5 buah cabe kriting
1. Tambah 7 buah cabe rawit (kalau buat anak, cabenya bisa utuh aja, masukan saat air sudah mendidih)
1. Harus ada 10 bawang merah
1. Harus ada 2 siung bawang putih
1. Diperlukan 1 ruas jari jahe, kunyit, laos
1. Harap siapkan 1 sdm gula
1. Dibutuhkan 1 sdt garam
1. Jangan lupa  Kalo ada blender bisa dihaluskan sekalian sama bumbu halusnya, kalo pake ulekan cukup di memarkan aja
1. Dibutuhkan 6 lembar daun jeruk
1. Harap siapkan 2 batang sereh kecil
1. Tambah  Masukan untuk ditumis
1. Dibutuhkan  Bumbu halus, sereh, daun jeruk
1. Harap siapkan 2 lembar daun salam
1. Diperlukan  Masukan setelah bumbu selesai ditumis
1. Diperlukan 1/2 sdt kaldu/royco
1. Harus ada 250 ml Air untuk merebus (kira2 aja sampai ayam terendam)
1. Tambah 6 sdm minyak untuk menumis
1. Siapkan  Kemangi (jika ada)


Hampir semua orang menyukai olahan dari bahan utama daging ayam ini. Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas. Resep Ayam Rica Rica - Kalau kita sudah mendengar kata-kata tentang bumbu rica-rica, sudah pasti pikiran kita akan tertuju pada masakan khas Manado. 

<!--inarticleads2-->

##### Langkah membuat  Rica rica ayam:

1. Haluskan bumbu halus dengan ulekan, kalo menggunakan blender haluskan juga sereh dan daun jeruknya
1. Panaskan minyak goreng, setelah itu tumis bumbu halus, sereh, daun jeruk, daun salam hingga wangi dan matang
1. Masukan air, tunggu hingga panas, masukan ayam.
1. Biarkan air sampai asat/berkurang, jangan lupa koreksi rasa
1. Kalau mau rica2 berkuah, biarkan hingga air berkurang sedikit lalu matikan, masukkan kemangi segar (jika ada)
1. Kalau mau rica2 tanpa kuah, biarkan airnya hingga berkurang, sisakan sedikit agar rica2 tidak kering. Matikan api, masukan kemangi (jika ada)


Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas. Resep Ayam Rica Rica - Kalau kita sudah mendengar kata-kata tentang bumbu rica-rica, sudah pasti pikiran kita akan tertuju pada masakan khas Manado. Bumbu rica-rica cocok dimasak dengan ikan, daging sapi, atau ayam. Resep ayam rica rica - Ayam adalah bahan makanan yang menjadi favorit semua orang, bisa dipastikan kalau hampir semua masyarakat Indonesia menyukai makanan dengan bahan ayam. Menu Sepesial Rica&#34; Ayam &#39;Bu Har&#39;. 

Demikianlah cara membuat rica rica ayam yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
