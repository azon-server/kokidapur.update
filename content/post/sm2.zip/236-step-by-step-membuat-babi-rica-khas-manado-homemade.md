---
description: "Step-by-Step membuat Babi rica khas manado Homemade"
title: "Step-by-Step membuat Babi rica khas manado Homemade"
slug: 236-step-by-step-membuat-babi-rica-khas-manado-homemade
date: 2020-10-27T02:55:55.539Z
image: https://img-global.cpcdn.com/recipes/3bb52eb060137652/751x532cq70/babi-rica-khas-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3bb52eb060137652/751x532cq70/babi-rica-khas-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3bb52eb060137652/751x532cq70/babi-rica-khas-manado-foto-resep-utama.jpg
author: Craig Blair
ratingvalue: 4.6
reviewcount: 34640
recipeingredient:
- "0.5 kg samcan babi"
- "5 lbr Daun jeruk di potong kecil2"
- " Daun bawang potong kasar"
- "3 sereh di geprek"
- "1 ikat kemangi optional"
- " Lengkuas geprek"
- "5 Cabe setan"
- " Blender"
- "10 siung bawang merah"
- "3 siung bawang putih"
- "1 kunyit"
- "1 ruas jahe"
- "15 cabe rawit"
- "8 cabe merah"
- " Garam gula dan totole"
recipeinstructions:
- "Rebus samcan 5menit utk buang kotorannya, tiriskan dan potong sesuai selera"
- "Panaskan minyak, masukin bumbu blender + sereh, lengkuas, daun jeruk, tumis hingga harum"
- "Masukkan samcan dan daun bawang dan cabe setan, ongseng sampe bumbu meresap"
- "Masukin air dan beri garam gula dan totole(kaldujamur), koreksi rasa, masak hingga empuk dan kering (sesuai selera)"
- "Kalo mau pake kemangi, masukin nya terakhir ya saat babi udah empuk, tgl masukin dan ongseng bentar, selesai deh"
categories:
- Recipe
tags:
- babi
- rica
- khas

katakunci: babi rica khas 
nutrition: 113 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Dessert

---


![Babi rica khas manado](https://img-global.cpcdn.com/recipes/3bb52eb060137652/751x532cq70/babi-rica-khas-manado-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau renyah. Ciri masakan Indonesia babi rica khas manado yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Babi Rica&#34; adalah makanan khas Manado,bagi pecinta pedas Pas banget pedasnya,bisa bikin ngantuk hilang Silah&#39;kn mencoba good people. BABI RICA KHAS MANADO - RESEP MASAKANKlik Subscribe/ langganan untuk mendapatkan informasi Video terbaru indonesian food. Merry Christmas! 🎅 Masak dan makannya pas Natal. Daging babi yang dimasak dengan bumbu pedas khas Manado bikin lidah cetar bergetar dalam sekali suapan.

Kedekatan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Babi rica khas manado untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang dapat anda praktekkan salah satunya babi rica khas manado yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep babi rica khas manado tanpa harus bersusah payah.
Seperti resep Babi rica khas manado yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Babi rica khas manado:

1. Harap siapkan 0.5 kg samcan babi
1. Jangan lupa 5 lbr Daun jeruk di potong kecil2
1. Tambah  Daun bawang potong kasar
1. Siapkan 3 sereh di geprek
1. Dibutuhkan 1 ikat kemangi (optional)
1. Harus ada  Lengkuas geprek
1. Siapkan 5 Cabe setan
1. Tambah  Blender
1. Jangan lupa 10 siung bawang merah
1. Harus ada 3 siung bawang putih
1. Siapkan 1 kunyit
1. Harus ada 1 ruas jahe
1. Diperlukan 15 cabe rawit
1. Jangan lupa 8 cabe merah
1. Dibutuhkan  Garam gula dan totole


Sambal Roa atau Rica Roa Khas Manado yang Enak, Gurih dan Rasa Pedas yang sesuai dengan Selera orang Indonesia. Manado adalah salah satu kota yang mendapat julukan surga kuliner. Dalam bahasa Manado &#34;rica&#34; sendiri berarti pedas atau cabai, jadi untuk kamu penyuka makanan pedas boleh mengetes nyali dengan menyantap seporsi ayam rica-rica bersama nasi hangat. Resep asli Manado dari dapur orang Manado asli. 

<!--inarticleads2-->

##### Bagaimana membuat  Babi rica khas manado:

1. Rebus samcan 5menit utk buang kotorannya, tiriskan dan potong sesuai selera
1. Panaskan minyak, masukin bumbu blender + sereh, lengkuas, daun jeruk, tumis hingga harum
1. Masukkan samcan dan daun bawang dan cabe setan, ongseng sampe bumbu meresap
1. Masukin air dan beri garam gula dan totole(kaldujamur), koreksi rasa, masak hingga empuk dan kering (sesuai selera)
1. Kalo mau pake kemangi, masukin nya terakhir ya saat babi udah empuk, tgl masukin dan ongseng bentar, selesai deh


Dalam bahasa Manado &#34;rica&#34; sendiri berarti pedas atau cabai, jadi untuk kamu penyuka makanan pedas boleh mengetes nyali dengan menyantap seporsi ayam rica-rica bersama nasi hangat. Resep asli Manado dari dapur orang Manado asli. Resep Tinorangsak - Masakan Khas Manado. Kumpulan resep masakan online disini kami berbagi resep dan informasi kuliner. Cari kuliner babi di Manado yang enak dan harga terjangkau? 

Demikianlah cara membuat babi rica khas manado yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
