---
description: "Steps untuk membuat Babi Rica (Pedas) Teruji"
title: "Steps untuk membuat Babi Rica (Pedas) Teruji"
slug: 312-steps-untuk-membuat-babi-rica-pedas-teruji
date: 2020-09-11T07:56:27.608Z
image: https://img-global.cpcdn.com/recipes/31092fe037d7b4c9/751x532cq70/babi-rica-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/31092fe037d7b4c9/751x532cq70/babi-rica-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/31092fe037d7b4c9/751x532cq70/babi-rica-pedas-foto-resep-utama.jpg
author: Benjamin Fields
ratingvalue: 4.5
reviewcount: 3118
recipeingredient:
- " Bumbu Halus "
- "5 buah bawang merah"
- "4 buah bawang putih"
- "2 cm kunyit"
- "secukupnya Lengkuas"
- "10 buah cabe besar"
- "10 buah cabe rawit"
- " Bahan Lainnya "
- "1/2 kg pork belly"
- "secukupnya Garam"
- "5 buah daun salam"
- "5 buah daun jeruk"
- "2 buah Serai digeprek"
- "secukupnya Gula"
- "secukupnya Daun Kemangi"
recipeinstructions:
- "Tumis bumbu halus kemudian masukkan Pork Belly nya... tumis hingga wangi"
- "Kemudian masukkan daun salam, serai dan daun jeruk.."
- "Kemudian tambahkan garam dan gula... aduk hingga merata kemudian masukkan air.. Tunggu hingga air menyusut dan daging menjadi empuk"
- "Stelah empuk, masukkan daun kemangi... setelah layu, langsung dapat disajima"
categories:
- Recipe
tags:
- babi
- rica
- pedas

katakunci: babi rica pedas 
nutrition: 247 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Lunch

---


![Babi Rica (Pedas)](https://img-global.cpcdn.com/recipes/31092fe037d7b4c9/751x532cq70/babi-rica-pedas-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga renyah. Karasteristik masakan Indonesia babi rica (pedas) yang penuh dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan keluarga dapat didapat dengan cara mudah. Salah satunya adalah memasak Babi Rica (Pedas) untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang bisa anda coba salah satunya babi rica (pedas) yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep babi rica (pedas) tanpa harus bersusah payah.
Berikut ini resep Babi Rica (Pedas) yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Babi Rica (Pedas):

1. Harus ada  Bumbu Halus :
1. Siapkan 5 buah bawang merah
1. Harus ada 4 buah bawang putih
1. Siapkan 2 cm kunyit
1. Jangan lupa secukupnya Lengkuas
1. Dibutuhkan 10 buah cabe besar
1. Jangan lupa 10 buah cabe rawit
1. Siapkan  Bahan Lainnya :
1. Dibutuhkan 1/2 kg pork belly
1. Jangan lupa secukupnya Garam
1. Diperlukan 5 buah daun salam
1. Dibutuhkan 5 buah daun jeruk
1. Jangan lupa 2 buah Serai digeprek
1. Jangan lupa secukupnya Gula
1. Siapkan secukupnya Daun Kemangi




<!--inarticleads2-->

##### Langkah membuat  Babi Rica (Pedas):

1. Tumis bumbu halus kemudian masukkan Pork Belly nya... tumis hingga wangi
1. Kemudian masukkan daun salam, serai dan daun jeruk..
1. Kemudian tambahkan garam dan gula... aduk hingga merata kemudian masukkan air.. Tunggu hingga air menyusut dan daging menjadi empuk
1. Stelah empuk, masukkan daun kemangi... setelah layu, langsung dapat disajima




Demikianlah cara membuat babi rica (pedas) yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
