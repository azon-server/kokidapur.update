---
description: "Resep : Sop Buntut Istimewa (menu special utk buka puasa) Teruji"
title: "Resep : Sop Buntut Istimewa (menu special utk buka puasa) Teruji"
slug: 404-resep-sop-buntut-istimewa-menu-special-utk-buka-puasa-teruji
date: 2020-09-11T02:41:19.862Z
image: https://img-global.cpcdn.com/recipes/da6d28da10b24b11/751x532cq70/sop-buntut-istimewa-menu-special-utk-buka-puasa-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/da6d28da10b24b11/751x532cq70/sop-buntut-istimewa-menu-special-utk-buka-puasa-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/da6d28da10b24b11/751x532cq70/sop-buntut-istimewa-menu-special-utk-buka-puasa-foto-resep-utama.jpg
author: Annie Frazier
ratingvalue: 4.4
reviewcount: 46041
recipeingredient:
- "1 kg buntut sapi saya pakai angus oxtail beef"
- " Bumbu presto "
- "4 siung bawang putih utuh"
- "4 cm jahe digeprek"
- "secukupnya garam"
- "secukupnya air"
- " Bahan sop "
- "2 sdm bawang putih halus dari 6 bwg putih"
- "4 siung bwg merah goreng sampai seperti bwg merah goreng"
- "1/2 bawang bombay potong2 agak besar"
- "2 kapulaga"
- "2 butir cengkeh"
- "2 batang kayu manis"
- "secukupnya garam gula merica"
- "1 blok kaldu ayam"
- "3 wortel iris agak tebal"
- "secukupnya buncis"
- "secukupnya air"
- " daun bawang bagian putih untuk dimasak bersama sup"
- " daun bawang bagian hijau iris2 utk taburan"
- " tomat iris2"
- " bawang goreng emping dan sambal sebagai pelengkap"
recipeinstructions:
- "Presto buntut sapi dengan air, garam, 4 siung bawang putih utuh, 4 cm jahe yg sdh digeprek selama 1 jam jika mau empuk banget. Atau 45 menit. Saya presto selama 1 jam krn pengen yg empuk banget. Tergantung ketebalan daging ya. Kuah nya sisakan setengah untuk nanti."
- "Jika tdk ada presto bisa pakai panci. Buang air rebusan pertama jika sdh berbuih banyak. Lalu rebus lagi dengan bwg putih utuh, garam dan jahe geprek sampai benar2 empuk"
- "Goreng bwg merah sampai menyerupai bwg goreng angkat dan sisihkan, lalu minyaknya dipakai lagi utk menumis bawang putih halus, bwg bombay, kaldu ayam, kayumanis, cengkeh, kapulaga, merica, garam secukupnya sampai wangi. Lalu tambahkan air kaldu bekas rebusan daging (setengahnya saja) sisanya tambah air baru secukupnya. Beri bawang grg tadi dan gula secukupnya."
- "Tambah daun bawang bagian putihnya, masak sampai air mendidih lalu tambahkan buntut sapi yg sdh dipresto tadi lalu masukkan bersama2 wortel dan buncis. Masak sebentar koreksi rasa. Dan sajikan bersama irisan tomat, jeruk nipis, irisan daun bawang, dan bawang goreng"
categories:
- Recipe
tags:
- sop
- buntut
- istimewa

katakunci: sop buntut istimewa 
nutrition: 182 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Lunch

---


![Sop Buntut Istimewa (menu special utk buka puasa)](https://img-global.cpcdn.com/recipes/da6d28da10b24b11/751x532cq70/sop-buntut-istimewa-menu-special-utk-buka-puasa-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas atau gurih. Ciri khas masakan Indonesia sop buntut istimewa (menu special utk buka puasa) yang kaya dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan keluarga bisa didapat dengan cara simple. Diantaranya adalah memasak Sop Buntut Istimewa (menu special utk buka puasa) untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang bisa anda coba salah satunya sop buntut istimewa (menu special utk buka puasa) yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep sop buntut istimewa (menu special utk buka puasa) tanpa harus bersusah payah.
Seperti resep Sop Buntut Istimewa (menu special utk buka puasa) yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 22 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sop Buntut Istimewa (menu special utk buka puasa):

1. Dibutuhkan 1 kg buntut sapi (saya pakai angus oxtail beef)
1. Siapkan  Bumbu presto :
1. Diperlukan 4 siung bawang putih utuh
1. Diperlukan 4 cm jahe digeprek
1. Jangan lupa secukupnya garam
1. Harap siapkan secukupnya air
1. Siapkan  Bahan sop :
1. Tambah 2 sdm bawang putih halus (dari 6 bwg putih)
1. Harus ada 4 siung bwg merah goreng sampai seperti bwg merah goreng
1. Harus ada 1/2 bawang bombay potong2 agak besar
1. Harap siapkan 2 kapulaga
1. Siapkan 2 butir cengkeh
1. Harap siapkan 2 batang kayu manis
1. Harus ada secukupnya garam, gula, merica
1. Diperlukan 1 blok kaldu ayam
1. Harus ada 3 wortel iris agak tebal
1. Tambah secukupnya buncis
1. Tambah secukupnya air
1. Siapkan  daun bawang bagian putih (untuk dimasak bersama sup)
1. Jangan lupa  daun bawang bagian hijau iris2 utk taburan
1. Harap siapkan  tomat iris2
1. Dibutuhkan  bawang goreng, emping dan sambal sebagai pelengkap




<!--inarticleads2-->

##### Bagaimana membuat  Sop Buntut Istimewa (menu special utk buka puasa):

1. Presto buntut sapi dengan air, garam, 4 siung bawang putih utuh, 4 cm jahe yg sdh digeprek selama 1 jam jika mau empuk banget. Atau 45 menit. Saya presto selama 1 jam krn pengen yg empuk banget. Tergantung ketebalan daging ya. Kuah nya sisakan setengah untuk nanti.
1. Jika tdk ada presto bisa pakai panci. Buang air rebusan pertama jika sdh berbuih banyak. Lalu rebus lagi dengan bwg putih utuh, garam dan jahe geprek sampai benar2 empuk
1. Goreng bwg merah sampai menyerupai bwg goreng angkat dan sisihkan, lalu minyaknya dipakai lagi utk menumis bawang putih halus, bwg bombay, kaldu ayam, kayumanis, cengkeh, kapulaga, merica, garam secukupnya sampai wangi. Lalu tambahkan air kaldu bekas rebusan daging (setengahnya saja) sisanya tambah air baru secukupnya. Beri bawang grg tadi dan gula secukupnya.
1. Tambah daun bawang bagian putihnya, masak sampai air mendidih lalu tambahkan buntut sapi yg sdh dipresto tadi lalu masukkan bersama2 wortel dan buncis. Masak sebentar koreksi rasa. Dan sajikan bersama irisan tomat, jeruk nipis, irisan daun bawang, dan bawang goreng




Demikianlah cara membuat sop buntut istimewa (menu special utk buka puasa) yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
