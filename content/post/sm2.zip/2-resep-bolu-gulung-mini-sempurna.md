---
description: "Resep : Bolu Gulung Mini Sempurna"
title: "Resep : Bolu Gulung Mini Sempurna"
slug: 2-resep-bolu-gulung-mini-sempurna
date: 2020-11-18T05:47:28.814Z
image: https://img-global.cpcdn.com/recipes/10a35d0dbe774e63/751x532cq70/bolu-gulung-mini-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/10a35d0dbe774e63/751x532cq70/bolu-gulung-mini-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/10a35d0dbe774e63/751x532cq70/bolu-gulung-mini-foto-resep-utama.jpg
author: Hulda Haynes
ratingvalue: 4
reviewcount: 33280
recipeingredient:
- " Bahan A"
- "6 butir telur ukuran sedang"
- "200 gr gula pasir"
- "8 gr cake emulsifier aku SP"
- "1 sdt vanilli cair"
- " Bahan B"
- "180 tepung terigu protein rendah"
- "10 gr susu bubuk"
- "25 gr maizena resep asli 10 gr"
- "Sejumput garam"
- " Bahan C"
- "150 gr minyak goreng kualitas bagus"
- "2 sdm susu kental manis putih"
- " Pewarna makanan aku merah hijau orange"
- "sesuai selera Butter creamselai"
recipeinstructions:
- "Siapkan loyang uk. 22x22x7 oles margarin dan alasi dengan kertas roti. Sisihkan panaskan kukusan. Alasi tutup nya dengan kain bersih."
- "Dalam baskom Mikser semua bahan A. Sampai kental berjejak.matikan mikser"
- "Tambahkan Bahan B sambil di ayak. Aduk dengan spatula sampai rata. Kemudian masukkan Bahan C (minyak goreng &amp;susu kental manis). Aduk balik sampai tercampur rata"
- "Bagi adonan menjadi 3 bagian beri pewarna masing-masing."
- "Tuang 1 bagian adonan di atas loyang kukus selama 10 menit/sampai matang. Lakukan untuk semua adonan. Untuk adonan terakhir kukus selama 30 menit."
- "Setelah matang. angkat loyang,keluarkan kue dari loyang dinginkan sebentar lalu potong-potong kue tipis-tipis saja. Beri butter cream/selai sesuai selera lalu gulung perlahan. Lakukan sampai kue habis."
- "Dan kue siap untuk di sajikan."
- "Note:: kenapa aku pakai maizena nya lebih dari yang di resep kan. Karena setelah beberapa kali trial n error di dapat takaran yang pas adalah dengan menambahkan maizena sebanyak 15 gr lagi. Dan...alhamdulillah sesuai dengan tekstur yang lembut dan lentur tidak gampang pecah saat di gulung.."
categories:
- Recipe
tags:
- bolu
- gulung
- mini

katakunci: bolu gulung mini 
nutrition: 240 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT60M"
recipeyield: "2"
recipecategory: Dessert

---


![Bolu Gulung Mini](https://img-global.cpcdn.com/recipes/10a35d0dbe774e63/751x532cq70/bolu-gulung-mini-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga enak. Ciri khas masakan Nusantara bolu gulung mini yang kaya dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Bolu Gulung Mini untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang dapat anda contoh salah satunya bolu gulung mini yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep bolu gulung mini tanpa harus bersusah payah.
Berikut ini resep Bolu Gulung Mini yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Bolu Gulung Mini:

1. Harap siapkan  Bahan A:
1. Dibutuhkan 6 butir telur ukuran sedang
1. Diperlukan 200 gr gula pasir
1. Harap siapkan 8 gr cake emulsifier (aku SP)
1. Harus ada 1 sdt vanilli cair
1. Jangan lupa  Bahan B:
1. Tambah 180 tepung terigu protein rendah
1. Diperlukan 10 gr susu bubuk
1. Dibutuhkan 25 gr maizena (resep asli 10 gr)
1. Siapkan Sejumput garam
1. Dibutuhkan  Bahan C:
1. Dibutuhkan 150 gr minyak goreng kualitas bagus
1. Harus ada 2 sdm susu kental manis putih
1. Harus ada  Pewarna makanan (aku: merah, hijau, orange)
1. Siapkan sesuai selera Butter cream/selai




<!--inarticleads2-->

##### Langkah membuat  Bolu Gulung Mini:

1. Siapkan loyang uk. 22x22x7 oles margarin dan alasi dengan kertas roti. Sisihkan panaskan kukusan. Alasi tutup nya dengan kain bersih.
1. Dalam baskom Mikser semua bahan A. Sampai kental berjejak.matikan mikser
1. Tambahkan Bahan B sambil di ayak. Aduk dengan spatula sampai rata. Kemudian masukkan Bahan C (minyak goreng &amp;susu kental manis). Aduk balik sampai tercampur rata
1. Bagi adonan menjadi 3 bagian beri pewarna masing-masing.
1. Tuang 1 bagian adonan di atas loyang kukus selama 10 menit/sampai matang. Lakukan untuk semua adonan. Untuk adonan terakhir kukus selama 30 menit.
1. Setelah matang. angkat loyang,keluarkan kue dari loyang dinginkan sebentar lalu potong-potong kue tipis-tipis saja. Beri butter cream/selai sesuai selera lalu gulung perlahan. Lakukan sampai kue habis.
1. Dan kue siap untuk di sajikan.
1. Note:: kenapa aku pakai maizena nya lebih dari yang di resep kan. Karena setelah beberapa kali trial n error di dapat takaran yang pas adalah dengan menambahkan maizena sebanyak 15 gr lagi. Dan...alhamdulillah sesuai dengan tekstur yang lembut dan lentur tidak gampang pecah saat di gulung..




Demikianlah cara membuat bolu gulung mini yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat mudah dan terbukti, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
