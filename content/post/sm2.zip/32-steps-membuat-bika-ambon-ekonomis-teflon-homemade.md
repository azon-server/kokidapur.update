---
description: "Steps membuat Bika ambon ekonomis (teflon) Homemade"
title: "Steps membuat Bika ambon ekonomis (teflon) Homemade"
slug: 32-steps-membuat-bika-ambon-ekonomis-teflon-homemade
date: 2021-01-30T08:41:23.242Z
image: https://img-global.cpcdn.com/recipes/ad8cac08a2ef075f/751x532cq70/bika-ambon-ekonomis-teflon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ad8cac08a2ef075f/751x532cq70/bika-ambon-ekonomis-teflon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ad8cac08a2ef075f/751x532cq70/bika-ambon-ekonomis-teflon-foto-resep-utama.jpg
author: Vera Higgins
ratingvalue: 4.3
reviewcount: 29193
recipeingredient:
- "  Bahan A"
- "50 gram margarine cairkan"
- "1 sachet susu kental manis putih"
- "  Bahan B"
- "300 ml santan saya 1 kara kecil air total 300ml"
- "1 batang serai geprek"
- "4 lembar daun jeruk"
- "1 batang daun pandan Robek2"
- "1 ruas kunyit iris2 resep asli gak pake"
- "1/2 sdt vanili"
- " Pewarna makanan warna kuning telur saya 2 tetes"
- "  Bahan C"
- "150 gram tepung sagu tani"
- "100 gram tepung terigu"
- "1 sdt ragi instant"
- "  Bahan D"
- "4 butir telur"
- "150 gram gula halus saya gula pasir biasa"
- "1 sdt garam"
recipeinstructions:
- "Campur semua bahan B, aduk terus hingga mendidih, Matikan api dan dinginkan baru saring (pewarna makanan dan kunyit iris bisa di ganti sama kunyit bubuk yah, atau kunyit fresh nya jangan di iris tapi di ulek aja sampe alus biar ga usah pake pewarna lagi)"
- "Siapkan bahan C lalu campur dengan bahan B, aduk rata pake whisk sampe licin dan tidak bergerindil, diamkan 30 menit"
- "Kocok bahan D dengan mixer sampe gula larut, lalu campur dengan bahan A, setelah 30 menit baru campur kebahan yang didiamkan td, aduk rata"
- "Tuang ke dalam teflon yang sebelumnya sudah di panaskan, teflon harus benar2 sudah panas yah..."
- "Biarkan muncul gelembung2 dan busa di permukaan hilang dulu, baru di tutup teflon, tutupnya jangan rapet, diganjel aja pake sodet kayu. Test kematangan bila perlu (klo saya cukup di tekan2 pake jari permukaanya, ketauan udah mateng apa belumnya)"
- ""
- ""
- ""
categories:
- Recipe
tags:
- bika
- ambon
- ekonomis

katakunci: bika ambon ekonomis 
nutrition: 172 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Dinner

---


![Bika ambon ekonomis (teflon)](https://img-global.cpcdn.com/recipes/ad8cac08a2ef075f/751x532cq70/bika-ambon-ekonomis-teflon-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan renyah. Ciri kuliner Nusantara bika ambon ekonomis (teflon) yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kehangatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Bika ambon ekonomis (teflon) untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang bisa anda praktekkan salah satunya bika ambon ekonomis (teflon) yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep bika ambon ekonomis (teflon) tanpa harus bersusah payah.
Seperti resep Bika ambon ekonomis (teflon) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 19 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Bika ambon ekonomis (teflon):

1. Dibutuhkan  🌻 Bahan A:
1. Harus ada 50 gram margarine, cairkan
1. Tambah 1 sachet susu kental manis putih
1. Diperlukan  🌻 Bahan B:
1. Harap siapkan 300 ml santan (saya 1 kara kecil +air, total 300ml)
1. Tambah 1 batang serai, geprek
1. Harus ada 4 lembar daun jeruk
1. Jangan lupa 1 batang daun pandan, Robek2
1. Dibutuhkan 1 ruas kunyit, iris2 (resep asli gak pake)
1. Harus ada 1/2 sdt vanili
1. Diperlukan  Pewarna makanan warna kuning telur (saya 2 tetes)
1. Tambah  🌻 Bahan C:
1. Jangan lupa 150 gram tepung sagu tani
1. Dibutuhkan 100 gram tepung terigu
1. Jangan lupa 1 sdt ragi instant
1. Siapkan  🌻 Bahan D:
1. Harap siapkan 4 butir telur
1. Diperlukan 150 gram gula halus (saya gula pasir biasa)
1. Harap siapkan 1 sdt garam




<!--inarticleads2-->

##### Instruksi membuat  Bika ambon ekonomis (teflon):

1. Campur semua bahan B, aduk terus hingga mendidih, Matikan api dan dinginkan baru saring (pewarna makanan dan kunyit iris bisa di ganti sama kunyit bubuk yah, atau kunyit fresh nya jangan di iris tapi di ulek aja sampe alus biar ga usah pake pewarna lagi)
1. Siapkan bahan C lalu campur dengan bahan B, aduk rata pake whisk sampe licin dan tidak bergerindil, diamkan 30 menit
1. Kocok bahan D dengan mixer sampe gula larut, lalu campur dengan bahan A, setelah 30 menit baru campur kebahan yang didiamkan td, aduk rata
1. Tuang ke dalam teflon yang sebelumnya sudah di panaskan, teflon harus benar2 sudah panas yah...
1. Biarkan muncul gelembung2 dan busa di permukaan hilang dulu, baru di tutup teflon, tutupnya jangan rapet, diganjel aja pake sodet kayu. Test kematangan bila perlu (klo saya cukup di tekan2 pake jari permukaanya, ketauan udah mateng apa belumnya)
1. 
1. 
1. 




Demikianlah cara membuat bika ambon ekonomis (teflon) yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan teruji, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
