---
description: "Cara singkat untuk membuat Cake Wortel Gula Merah (Gula Habang) Luar biasa"
title: "Cara singkat untuk membuat Cake Wortel Gula Merah (Gula Habang) Luar biasa"
slug: 23-cara-singkat-untuk-membuat-cake-wortel-gula-merah-gula-habang-luar-biasa
date: 2020-10-24T16:03:44.311Z
image: https://img-global.cpcdn.com/recipes/ec4ef92bf7f4b959/751x532cq70/cake-wortel-gula-merah-gula-habang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ec4ef92bf7f4b959/751x532cq70/cake-wortel-gula-merah-gula-habang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ec4ef92bf7f4b959/751x532cq70/cake-wortel-gula-merah-gula-habang-foto-resep-utama.jpg
author: Erik Mendoza
ratingvalue: 4
reviewcount: 23516
recipeingredient:
- "  Bahan A "
- "150 Terigu"
- "100 Tepung Beras"
- "150 gr Gula Merah disisir halus"
- "200 gr Margarin"
- "4 btr Kuning Telur"
- "2 sdt BP"
- "1/2 sdt Bubuk Kayu Manis"
- " Pewarna Makanan kuning resep asli tdk pakai"
- "  Bahan B "
- "150 gr Wortel potongpotong"
- "100 ml Susu Cair 50ml SKM  50ml Air Masak"
- "  Bahan C "
- "4 btr Putih Telur"
- "50 gr Gula Pasir"
- "1/4 sdt Garam Halus"
- " Taburan "
- "Secukupnya Wijen"
- " Topping "
- "secukupnya SKM"
- "Secukupnya Mayones"
- "1 sayat Jeruk Nipis"
recipeinstructions:
- "Siapkan bahan yg dibutuhkan. ***beras kualitas bagus + kayu manis utuh aku blender halus lalu ayak. Sisihkan. Bahan B : (aku blender jadi 1 hingga halus merata seperti jus). Sisihkan."
- "Lanjut proses bahan A : mixer gula merah + margarin hingga lembut merata. Tambahkan 1 per 1 kuning telur &amp; mixer lg hingga tercampur rata."
- "Masukkan terigu, tepung beras + kayu manis, pewarna &amp; BP sambil diaduk perlahan. Kemudian masukkan jus wortel susu. Aduk rata lagi."
- "Proses bahan C : mixer putih telur &amp; garam 1/2 mengembang. Masukkan gula pasir sedikit-sedikit. Mixer lg hingga kembang. Kemudian campur bahan C dgn bahan A tadi. Aduk rata. Siapkan loyang (aku pakek loyang bolu kukus yg diberi kertas kue &amp; pakai loyang bulat/mangkuk stainless). Beri taburan wijen &amp; gula pasir. Panggang +/- 40menit, 180°c dgn api atas bawah (tergantung oven &amp; loyang masing2). Yg cup cakes nya cuma 15-20 menit kok."
- "Ini tampilan saat sudah jadi. Aku beri topping SKM + Mayones + Air Jeruk Nipis. So...nyammii &amp; manis lembut lho..."
categories:
- Recipe
tags:
- cake
- wortel
- gula

katakunci: cake wortel gula 
nutrition: 161 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Lunch

---


![Cake Wortel Gula Merah (Gula Habang)](https://img-global.cpcdn.com/recipes/ec4ef92bf7f4b959/751x532cq70/cake-wortel-gula-merah-gula-habang-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang patut kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti cake wortel gula merah (gula habang) yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa keistimewahan yang merupakan keragaman Indonesia

Keharmonisan rumah tangga bisa ditemukan dengan cara simple. Salah satunya adalah membuat makanan Cake Wortel Gula Merah (Gula Habang) untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang bisa anda praktekkan salah satunya cake wortel gula merah (gula habang) yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep cake wortel gula merah (gula habang) tanpa harus bersusah payah.
Seperti resep Cake Wortel Gula Merah (Gula Habang) yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 22 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Cake Wortel Gula Merah (Gula Habang):

1. Diperlukan  🎂 Bahan A :
1. Siapkan 150 Terigu
1. Jangan lupa 100 Tepung Beras***
1. Harus ada 150 gr Gula Merah, disisir halus
1. Siapkan 200 gr Margarin
1. Harus ada 4 btr Kuning Telur
1. Dibutuhkan 2 sdt BP
1. Dibutuhkan 1/2 sdt Bubuk Kayu Manis***
1. Harap siapkan  Pewarna Makanan (kuning), resep asli tdk pakai
1. Dibutuhkan  🎂 Bahan B :
1. Jangan lupa 150 gr Wortel, potong-potong
1. Diperlukan 100 ml Susu Cair (50ml SKM + 50ml Air Masak)
1. Harap siapkan  🎂 Bahan C :
1. Tambah 4 btr Putih Telur
1. Dibutuhkan 50 gr Gula Pasir
1. Diperlukan 1/4 sdt Garam Halus
1. Siapkan  Taburan :
1. Jangan lupa Secukupnya Wijen
1. Harus ada  Topping :
1. Harus ada secukupnya SKM
1. Harus ada Secukupnya Mayones
1. Siapkan 1 sayat Jeruk Nipis




<!--inarticleads2-->

##### Cara membuat  Cake Wortel Gula Merah (Gula Habang):

1. Siapkan bahan yg dibutuhkan. ***beras kualitas bagus + kayu manis utuh aku blender halus lalu ayak. Sisihkan. Bahan B : (aku blender jadi 1 hingga halus merata seperti jus). Sisihkan.
1. Lanjut proses bahan A : mixer gula merah + margarin hingga lembut merata. Tambahkan 1 per 1 kuning telur &amp; mixer lg hingga tercampur rata.
1. Masukkan terigu, tepung beras + kayu manis, pewarna &amp; BP sambil diaduk perlahan. Kemudian masukkan jus wortel susu. Aduk rata lagi.
1. Proses bahan C : mixer putih telur &amp; garam 1/2 mengembang. Masukkan gula pasir sedikit-sedikit. Mixer lg hingga kembang. Kemudian campur bahan C dgn bahan A tadi. Aduk rata. Siapkan loyang (aku pakek loyang bolu kukus yg diberi kertas kue &amp; pakai loyang bulat/mangkuk stainless). Beri taburan wijen &amp; gula pasir. Panggang +/- 40menit, 180°c dgn api atas bawah (tergantung oven &amp; loyang masing2). Yg cup cakes nya cuma 15-20 menit kok.
1. Ini tampilan saat sudah jadi. Aku beri topping SKM + Mayones + Air Jeruk Nipis. So...nyammii &amp; manis lembut lho...




Demikianlah cara membuat cake wortel gula merah (gula habang) yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
