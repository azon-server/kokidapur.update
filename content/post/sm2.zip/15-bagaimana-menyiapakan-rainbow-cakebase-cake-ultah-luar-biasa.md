---
description: "Bagaimana menyiapakan Rainbow Cake(Base Cake Ultah) Luar biasa"
title: "Bagaimana menyiapakan Rainbow Cake(Base Cake Ultah) Luar biasa"
slug: 15-bagaimana-menyiapakan-rainbow-cakebase-cake-ultah-luar-biasa
date: 2020-09-25T13:33:34.209Z
image: https://img-global.cpcdn.com/recipes/b8813a6843d82aae/751x532cq70/rainbow-cakebase-cake-ultah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b8813a6843d82aae/751x532cq70/rainbow-cakebase-cake-ultah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b8813a6843d82aae/751x532cq70/rainbow-cakebase-cake-ultah-foto-resep-utama.jpg
author: Ernest Ball
ratingvalue: 4.7
reviewcount: 31325
recipeingredient:
- " Bahan A"
- "6 butir telur"
- "250 gr gula pasir saya kurangi 20gr dr resep asli"
- "1 sdt sp"
- "1 sdt vanili essencme pasta susu"
- "1/2 sdt garam"
- " Bahan B"
- "225 gr tepung terigu me segi3 biru"
- "1,5 sdm susu bubuk full cream"
- "1,5 sdm santan bubuk"
- " Campur semua bahan lalu ayak"
- " Bahan C"
- "225 ml minyak goreng kualitas bagus"
- "60 gr susu kental manis putih"
- " Campur dan aduk rata"
- " Secukupnya pewarna makanan"
- " Ungu"
- " Biru"
- " Hijau"
- " Kuning"
- " Orange"
- " Merah"
recipeinstructions:
- "Campur tiap bahan sesuai deskripsi di atas👆"
- "Mixer bahan A sampai mengembang kental putih berjejak 👇"
- "Tuang bahan B Mixer speed rendah asal tercampur saja👇"
- "Bahan C campur dan aduk rata,tuang ke bahan A tadi.aduk balik pake spatula sampai homogen👇adonan masih kental ya😉"
- "Bagi jadi 6 sama banyak,beri pewarna makanan secukupnya 👇siapkan loyang diameter 20cm dasarnya alasi baking papper (pinggirannya jangan di oles apapun)"
- "Kukus tiap lapisan selama 7 menit dengan api sedang cenderung kecil,kukusan sudah dipanaskan sebelumnya sampai beruap banyak👇"
- "Tutup kukusan alasi kain bersih agar tidak ada air menetes ke kuenya👇kukus dari warna ungu,biru,hijau,kuning,orange terakhir merah😉 setelah warna terakhir kukus selama 35 menit/sampai matang(tes tusuk kue untuk memastikan matang!!!)"
- "Setelah matang langsung keluarkan dari loyang,biarkan suhu ruang lalu hias sesuai selera 😉"
categories:
- Recipe
tags:
- rainbow
- cakebase
- cake

katakunci: rainbow cakebase cake 
nutrition: 273 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Lunch

---


![Rainbow Cake(Base Cake Ultah)](https://img-global.cpcdn.com/recipes/b8813a6843d82aae/751x532cq70/rainbow-cakebase-cake-ultah-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau renyah. Karasteristik masakan Nusantara rainbow cake(base cake ultah) yang kaya dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan keluarga bisa didapat dengan cara simple. Salah satunya adalah memasak Rainbow Cake(Base Cake Ultah) untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang bisa anda contoh salah satunya rainbow cake(base cake ultah) yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep rainbow cake(base cake ultah) tanpa harus bersusah payah.
Seperti resep Rainbow Cake(Base Cake Ultah) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Rainbow Cake(Base Cake Ultah):

1. Siapkan  Bahan A
1. Dibutuhkan 6 butir telur
1. Dibutuhkan 250 gr gula pasir (saya kurangi 20gr dr resep asli)
1. Diperlukan 1 sdt sp
1. Jangan lupa 1 sdt vanili essenc(me pasta susu)
1. Dibutuhkan 1/2 sdt garam
1. Tambah  Bahan B
1. Harus ada 225 gr tepung terigu (me segi3 biru)
1. Harus ada 1,5 sdm susu bubuk full cream
1. Harap siapkan 1,5 sdm santan bubuk
1. Tambah  Campur semua bahan lalu ayak👆
1. Siapkan  Bahan C
1. Siapkan 225 ml minyak goreng kualitas bagus
1. Diperlukan 60 gr susu kental manis putih
1. Tambah  Campur dan aduk rata👆
1. Diperlukan  Secukupnya pewarna makanan
1. Harus ada  Ungu
1. Diperlukan  Biru
1. Harap siapkan  Hijau
1. Tambah  Kuning
1. Harus ada  Orange
1. Tambah  Merah




<!--inarticleads2-->

##### Cara membuat  Rainbow Cake(Base Cake Ultah):

1. Campur tiap bahan sesuai deskripsi di atas👆
1. Mixer bahan A sampai mengembang kental putih berjejak 👇
1. Tuang bahan B Mixer speed rendah asal tercampur saja👇
1. Bahan C campur dan aduk rata,tuang ke bahan A tadi.aduk balik pake spatula sampai homogen👇adonan masih kental ya😉
1. Bagi jadi 6 sama banyak,beri pewarna makanan secukupnya 👇siapkan loyang diameter 20cm dasarnya alasi baking papper (pinggirannya jangan di oles apapun)
1. Kukus tiap lapisan selama 7 menit dengan api sedang cenderung kecil,kukusan sudah dipanaskan sebelumnya sampai beruap banyak👇
1. Tutup kukusan alasi kain bersih agar tidak ada air menetes ke kuenya👇kukus dari warna ungu,biru,hijau,kuning,orange terakhir merah😉 setelah warna terakhir kukus selama 35 menit/sampai matang(tes tusuk kue untuk memastikan matang!!!)
1. Setelah matang langsung keluarkan dari loyang,biarkan suhu ruang lalu hias sesuai selera 😉




Demikianlah cara membuat rainbow cake(base cake ultah) yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
