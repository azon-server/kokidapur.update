---
description: "Step-by-Step menyiapakan Babi Rica-Rica Kemangi Homemade"
title: "Step-by-Step menyiapakan Babi Rica-Rica Kemangi Homemade"
slug: 309-step-by-step-menyiapakan-babi-rica-rica-kemangi-homemade
date: 2020-10-15T07:35:07.540Z
image: https://img-global.cpcdn.com/recipes/8b5990b9c816f285/751x532cq70/babi-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8b5990b9c816f285/751x532cq70/babi-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8b5990b9c816f285/751x532cq70/babi-rica-rica-kemangi-foto-resep-utama.jpg
author: Nathaniel Allen
ratingvalue: 4.4
reviewcount: 10425
recipeingredient:
- "500 gr daging babi potong dadu"
- "5 lmbr daun jeruk sobek"
- "1/2 sdm kecap manis"
- "1 bh tomat potong kasar"
- "Secukupnya Garam Gula Minyakkaldu jamur"
- " Bumbu halus "
- "10 siung bawang merah"
- "4 siung bawang putih"
- "5 bh cabe merah keriting"
- "5 bh cabe rawit merah"
- "5 cm kunyit"
- "5 cm jahe"
- "1 ruas lengkuas"
- "2 btg sereh ambil putihnya"
- " kalau mau pedas sedikit kurangi cabe rawit jd anak pun bs menyantapnya jg"
recipeinstructions:
- "Tumis bumbu halus, daun jeruk, hingga harum."
- "Masukkan dagingnya aduk rata, Tuang kedalam slow cooker dengan potongan tomat. Hingga empuk sesuai selera. Karena saya memakai slow cooker, saya tidak memakai air, karena akan keluar air dari tomat. Tambahkan gula, garam dan beri sdkit kecap manis. Aduk rata"
- "Terakhir masukan daun kemangi, aduk rata dan sajikan. Cocok disantap dengan tumis Ebi Daun Ubi ^,^"
categories:
- Recipe
tags:
- babi
- ricarica
- kemangi

katakunci: babi ricarica kemangi 
nutrition: 159 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Lunch

---


![Babi Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/8b5990b9c816f285/751x532cq70/babi-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti babi rica-rica kemangi yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa kesan tersendiri yang merupakan keragaman Indonesia



Kehangatan keluarga dapat diperoleh dengan cara simple. Diantaranya adalah memasak Babi Rica-Rica Kemangi untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang dapat anda praktekkan salah satunya babi rica-rica kemangi yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep babi rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Babi Rica-Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Babi Rica-Rica Kemangi:

1. Harus ada 500 gr daging babi, potong dadu
1. Siapkan 5 lmbr daun jeruk (sobek)
1. Jangan lupa 1/2 sdm kecap manis
1. Diperlukan 1 bh tomat, potong kasar
1. Tambah Secukupnya Garam Gula, Minyak,kaldu jamur
1. Diperlukan  Bumbu halus :
1. Harus ada 10 siung bawang merah
1. Tambah 4 siung bawang putih
1. Harus ada 5 bh cabe merah keriting
1. Jangan lupa 5 bh cabe rawit merah
1. Diperlukan 5 cm kunyit
1. Harap siapkan 5 cm jahe
1. Siapkan 1 ruas lengkuas
1. Harap siapkan 2 btg sereh, ambil putihnya
1. Harus ada  (kalau mau pedas sedikit, kurangi cabe rawit, jd anak&#34; pun bs menyantapnya jg




<!--inarticleads2-->

##### Bagaimana membuat  Babi Rica-Rica Kemangi:

1. Tumis bumbu halus, daun jeruk, hingga harum.
1. Masukkan dagingnya aduk rata, Tuang kedalam slow cooker dengan potongan tomat. Hingga empuk sesuai selera. Karena saya memakai slow cooker, saya tidak memakai air, karena akan keluar air dari tomat. - Tambahkan gula, garam dan beri sdkit kecap manis. Aduk rata
1. Terakhir masukan daun kemangi, aduk rata dan sajikan. - Cocok disantap dengan tumis Ebi Daun Ubi ^,^




Demikianlah cara membuat babi rica-rica kemangi yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
