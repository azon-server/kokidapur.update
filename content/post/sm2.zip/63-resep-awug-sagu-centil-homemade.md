---
description: "Resep : Awug sagu centil Homemade"
title: "Resep : Awug sagu centil Homemade"
slug: 63-resep-awug-sagu-centil-homemade
date: 2020-10-21T11:08:00.499Z
image: https://img-global.cpcdn.com/recipes/ff922be2d72a905a/751x532cq70/awug-sagu-centil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ff922be2d72a905a/751x532cq70/awug-sagu-centil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ff922be2d72a905a/751x532cq70/awug-sagu-centil-foto-resep-utama.jpg
author: Jesse Morales
ratingvalue: 4.6
reviewcount: 40418
recipeingredient:
- "250 gr sagu"
- " Setgah butir kepala parut agak muda"
- "200 gr gula pasir Me cm 150"
- "2,5 dm tepung tapioka"
- "dikit Garem"
- " Pandan"
- " Air untuk merebus"
recipeinstructions:
- "1 gayung airdanpandan panaskan smpai mendidih tambahkan sagu..rebus 10menit. Setelah itu matikan kompor dan tutup selama 5menit. Saring dan tiriskan. Sampai benar2 airnya abis ya mom."
- "Campur kelpa gulapasir garem tepung tapioka dan sagu td..setelah itu bungkusin sesuai selera...selamat mencoba mom.."
categories:
- Recipe
tags:
- awug
- sagu
- centil

katakunci: awug sagu centil 
nutrition: 220 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Dessert

---


![Awug sagu centil](https://img-global.cpcdn.com/recipes/ff922be2d72a905a/751x532cq70/awug-sagu-centil-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita jaga karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti awug sagu centil yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara

Keharmonisan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Awug sagu centil untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda coba salah satunya awug sagu centil yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep awug sagu centil tanpa harus bersusah payah.
Seperti resep Awug sagu centil yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 2 langkah dan 7 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Awug sagu centil:

1. Harus ada 250 gr sagu
1. Harap siapkan  Setgah butir kepala parut agak muda
1. Siapkan 200 gr gula pasir. Me cm 150
1. Tambah 2,5 dm tepung tapioka
1. Dibutuhkan dikit Garem
1. Dibutuhkan  Pandan
1. Harus ada  Air untuk merebus




<!--inarticleads2-->

##### Cara membuat  Awug sagu centil:

1. 1 gayung airdanpandan panaskan smpai mendidih tambahkan sagu..rebus 10menit. Setelah itu matikan kompor dan tutup selama 5menit. Saring dan tiriskan. Sampai benar2 airnya abis ya mom.
1. Campur kelpa gulapasir garem tepung tapioka dan sagu td..setelah itu bungkusin sesuai selera...selamat mencoba mom..




Demikianlah cara membuat awug sagu centil yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
