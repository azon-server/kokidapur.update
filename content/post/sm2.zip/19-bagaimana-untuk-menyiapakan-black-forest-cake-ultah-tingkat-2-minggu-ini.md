---
description: "Bagaimana untuk menyiapakan Black Forest Cake Ultah Tingkat 2 minggu ini"
title: "Bagaimana untuk menyiapakan Black Forest Cake Ultah Tingkat 2 minggu ini"
slug: 19-bagaimana-untuk-menyiapakan-black-forest-cake-ultah-tingkat-2-minggu-ini
date: 2020-08-26T02:03:33.815Z
image: https://img-global.cpcdn.com/recipes/be9b7317e31e66a3/751x532cq70/black-forest-cake-ultah-tingkat-2-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/be9b7317e31e66a3/751x532cq70/black-forest-cake-ultah-tingkat-2-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/be9b7317e31e66a3/751x532cq70/black-forest-cake-ultah-tingkat-2-foto-resep-utama.jpg
author: Georgie Peters
ratingvalue: 4.2
reviewcount: 29396
recipeingredient:
- " Bahan A "
- "10 butir telur buang putihnya 2 butir"
- "170 gr gula pasir kalo kurang suka manis pake 150gr"
- "1 sdm SP"
- "1/2 sdt vanilli"
- " Bahan B "
- "110 gr tepung terigu jadi 100gr saja bila coklat bbk 60gr"
- "50 gr coklat bubuk bila suka coklat bgt bisa 60gr"
- "40 gr tepung maizena"
- "1/4 sdt garam supaya lbh gurih"
- " Bahan C "
- "125 gr margarin lelehkan"
- "1-2 sdm pasta coklatpasta black forestwajib"
- " Bahan lain2 yg diperlukan "
- "Papan cake ukuran 2628"
- "250 gr Selai strawbery"
- "1 resep butter cream link ada dilangkah pembuatan"
- " Pewarna makanan merah cabe koepoeKoepoe"
- "25 gr fondan untuk membuat bunga"
- " Springkel untuk taburan"
- "3 buah Figuri hello kitty"
recipeinstructions:
- "Siapkan bahan2. Olesi loyang dengan carlo, aku pake loyang bulat ukuran d= 24 pake 2 loyang. Adonan jangan masuk 1 loyang ukuran 24 ya moms nanti bakal luber. Kalo tdk ada loyang 2 ya lakukan 2x ngoven."
- "Mixer bahan A (gunakan wadah lebih besar dari biasanya,aku pake baskom)sampai putih,kental &amp; berjejak (kira2 15 menit). Bila mixer diangkat adonan terbentuk runcing seperti gambar &amp; tdk mudah mengalir."
- "Masukan bahan B sambil diayak.lalu mixer menggunakan sped 1.asal campur. JANGAN OVER MIX. Matikan mixer"
- "Masukan bahan C lalu aduk balik dengan spatula.sampai rata &amp; tdk ada yg mengendap."
- "Tuang dalam loyang.lalu hentakan 3x supaya udara didlm keluar."
- "Oven selama 25-30 menit. Lakukan tes tusuk menggunakan lidi,kalo tdk ada yg menempel angkat. Aku pake oven tangkring ketika loyang bawah sudah matang. Loyang atas pindah ke rak bawah.oven sampai matang ya. HATI2 JANGAN KELAMAAN NANTI BOLU JADI KERING.Angkat. Lepaskan dari loyang dan dinginkan"
- "Membuat sirup simple(100ml air +3,5sdm gula pasir lalu rebus)tunggu dingin lalu oleskan pada bolu yg telah dingin. Tujuannya supaya tetap mois dan tdk seret saat dimakan. Lakukan setiap lapis bolu ya."
- "Semprotkan butter cream dan selai strawbery. Resep butter cream Ayo cek resep ini: Butter cream lembut, enak https://cookpad.com/id/resep/6203435-butter-cream-lembut-enak?token=JtXVZap1uHiYjsNGkJ5CFrEZ (1 resep butter cream pas untuk cake ultah tingkat ini)"
- "Tumpuk lg bolu ke2. Lalu olesi butter cream lg.ratakan sampai tertutup rapat."
- "Letakan loyang untuk bolu diatasnya,agak ditekan lembut (hanya untuk mengukur saja supaya tdk miring saat meletakan cake ke2) ini resep untuk cake ke 2 Ayo cek resep ini: Cake ultah Black forest d=18cm https://cookpad.com/id/resep/9316394-cake-ultah-black-forest-d18cm?token=bVgSMLGZz2B1wLrL7koMa5tf"
- "Beri sedotan pop ice tujuannya supaya bolu atasnya tdk amblas. Lalu letakan cake tingkat ke 2 yg telah dioles butter cream(sudah rapih). Dengan cara dibalik..gunakan pisau /spatula untuk menahan cake. Yg tadinya bagian atas cake ke2 diatas sekarang jadi dibawah. Lalu bagian atas oles lg dengan butter cream.rapihkan..semoga mengerti ya. Maaf Tdk bisa fto stepnya🙏 repot tangannya tdk bisa pegang hp😁"
- "Hias sesuai selera ya moms. Semoga bermanfaat😊"
categories:
- Recipe
tags:
- black
- forest
- cake

katakunci: black forest cake 
nutrition: 158 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Lunch

---


![Black Forest Cake Ultah Tingkat 2](https://img-global.cpcdn.com/recipes/be9b7317e31e66a3/751x532cq70/black-forest-cake-ultah-tingkat-2-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau empuk. Ciri makanan Indonesia black forest cake ultah tingkat 2 yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan Black Forest Cake Ultah Tingkat 2 untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang dapat anda praktekkan salah satunya black forest cake ultah tingkat 2 yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep black forest cake ultah tingkat 2 tanpa harus bersusah payah.
Seperti resep Black Forest Cake Ultah Tingkat 2 yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 12 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Black Forest Cake Ultah Tingkat 2:

1. Harus ada  Bahan A :
1. Harus ada 10 butir telur (buang putihnya 2 butir)
1. Harus ada 170 gr gula pasir (kalo kurang suka manis pake 150gr)
1. Diperlukan 1 sdm SP
1. Tambah 1/2 sdt vanilli
1. Tambah  Bahan B :
1. Jangan lupa 110 gr tepung terigu (jadi 100gr saja bila coklat bbk 60gr)
1. Diperlukan 50 gr coklat bubuk (bila suka coklat bgt bisa 60gr)
1. Diperlukan 40 gr tepung maizena
1. Dibutuhkan 1/4 sdt garam (supaya lbh gurih)
1. Harus ada  Bahan C :
1. Siapkan 125 gr margarin lelehkan
1. Jangan lupa 1-2 sdm pasta coklat/pasta black forest(wajib)
1. Dibutuhkan  Bahan lain2 yg diperlukan :
1. Tambah Papan cake ukuran 26/28
1. Dibutuhkan 250 gr Selai strawbery
1. Siapkan 1 resep butter cream (link ada dilangkah pembuatan)
1. Diperlukan  Pewarna makanan merah cabe koepoe-Koepoe
1. Harap siapkan 25 gr fondan (untuk membuat bunga)
1. Harus ada  Springkel (untuk taburan)
1. Tambah 3 buah Figuri hello kitty




<!--inarticleads2-->

##### Instruksi membuat  Black Forest Cake Ultah Tingkat 2:

1. Siapkan bahan2. Olesi loyang dengan carlo, aku pake loyang bulat ukuran d= 24 pake 2 loyang. Adonan jangan masuk 1 loyang ukuran 24 ya moms nanti bakal luber. Kalo tdk ada loyang 2 ya lakukan 2x ngoven.
1. Mixer bahan A (gunakan wadah lebih besar dari biasanya,aku pake baskom)sampai putih,kental &amp; berjejak (kira2 15 menit). Bila mixer diangkat adonan terbentuk runcing seperti gambar &amp; tdk mudah mengalir.
1. Masukan bahan B sambil diayak.lalu mixer menggunakan sped 1.asal campur. JANGAN OVER MIX. Matikan mixer
1. Masukan bahan C lalu aduk balik dengan spatula.sampai rata &amp; tdk ada yg mengendap.
1. Tuang dalam loyang.lalu hentakan 3x supaya udara didlm keluar.
1. Oven selama 25-30 menit. Lakukan tes tusuk menggunakan lidi,kalo tdk ada yg menempel angkat. Aku pake oven tangkring ketika loyang bawah sudah matang. Loyang atas pindah ke rak bawah.oven sampai matang ya. HATI2 JANGAN KELAMAAN NANTI BOLU JADI KERING.Angkat. Lepaskan dari loyang dan dinginkan
1. Membuat sirup simple(100ml air +3,5sdm gula pasir lalu rebus)tunggu dingin lalu oleskan pada bolu yg telah dingin. Tujuannya supaya tetap mois dan tdk seret saat dimakan. Lakukan setiap lapis bolu ya.
1. Semprotkan butter cream dan selai strawbery. Resep butter cream Ayo cek resep ini: Butter cream lembut, enak https://cookpad.com/id/resep/6203435-butter-cream-lembut-enak?token=JtXVZap1uHiYjsNGkJ5CFrEZ (1 resep butter cream pas untuk cake ultah tingkat ini)
1. Tumpuk lg bolu ke2. Lalu olesi butter cream lg.ratakan sampai tertutup rapat.
1. Letakan loyang untuk bolu diatasnya,agak ditekan lembut (hanya untuk mengukur saja supaya tdk miring saat meletakan cake ke2) ini resep untuk cake ke 2 Ayo cek resep ini: Cake ultah Black forest d=18cm https://cookpad.com/id/resep/9316394-cake-ultah-black-forest-d18cm?token=bVgSMLGZz2B1wLrL7koMa5tf
1. Beri sedotan pop ice tujuannya supaya bolu atasnya tdk amblas. Lalu letakan cake tingkat ke 2 yg telah dioles butter cream(sudah rapih). Dengan cara dibalik..gunakan pisau /spatula untuk menahan cake. Yg tadinya bagian atas cake ke2 diatas sekarang jadi dibawah. Lalu bagian atas oles lg dengan butter cream.rapihkan..semoga mengerti ya. Maaf Tdk bisa fto stepnya🙏 repot tangannya tdk bisa pegang hp😁
1. Hias sesuai selera ya moms. Semoga bermanfaat😊




Demikianlah cara membuat black forest cake ultah tingkat 2 yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan teruji, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
