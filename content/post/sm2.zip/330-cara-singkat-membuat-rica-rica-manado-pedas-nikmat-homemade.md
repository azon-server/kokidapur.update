---
description: "Cara singkat membuat Rica Rica Manado Pedas Nikmat Homemade"
title: "Cara singkat membuat Rica Rica Manado Pedas Nikmat Homemade"
slug: 330-cara-singkat-membuat-rica-rica-manado-pedas-nikmat-homemade
date: 2020-12-28T10:28:27.315Z
image: https://img-global.cpcdn.com/recipes/1557ec2786e85196/751x532cq70/rica-rica-manado-pedas-nikmat-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1557ec2786e85196/751x532cq70/rica-rica-manado-pedas-nikmat-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1557ec2786e85196/751x532cq70/rica-rica-manado-pedas-nikmat-foto-resep-utama.jpg
author: Earl Thompson
ratingvalue: 4.7
reviewcount: 6047
recipeingredient:
- "500 gr daging BabiSapiAyam potong potong lalu cuci bersih dan tiriskan"
- "1 ikat daun kemangi segar buang batang kerasnya cuci bersih dan tiriskan"
- "500 ml air"
- " Bumbu Halus"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "3 butir ketumbar"
- "1 ruas jari jahe"
- "1 ruas jari lengkuas"
- "3 ruas jari kunyit"
- "1 batang kecombrang muda iris halus memanjang seperti korek api kalau tidak suka boleh di skip ya"
- " Bumbu Kasar"
- "25 buah Cabai merah"
- "10 buah Cabai rawit merah jika suka lebih pedas bisa ditambahkan"
- " Bumbu Tabur"
- "Secukupnya garam halus"
- "1 sdt lada bubuk"
- "5 lembar daun jeruk"
- "2 lembar daun salam"
- "1 batang serai geprek"
- "1 ruas jari lengkuas geprek"
recipeinstructions:
- "Tumis bumbu halus, bumbu kasar hingga harum dan matang, lalu masukkan sereh, daun jeruk dan daun salam. Tumis hingga harum"
- "Masukkan daging kedalam tumisan bumbu, aduk aduk hingga daging setengah matang"
- "Setelah diaduk merata daging dan bumbu, tambah kan air sedikit demi sedikit"
- "Masukkan bumbu halus, koreksi rasa, masak hingga daging empuk, baru masukkan daun kemangi, aduk aduk sebentar saja supaya daun kemangi tidak terlalu layu. Angkat dan siap disajikan. 😍"
categories:
- Recipe
tags:
- rica
- rica
- manado

katakunci: rica rica manado 
nutrition: 274 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Dinner

---


![Rica Rica Manado Pedas Nikmat](https://img-global.cpcdn.com/recipes/1557ec2786e85196/751x532cq70/rica-rica-manado-pedas-nikmat-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas atau empuk. Karasteristik masakan Nusantara rica rica manado pedas nikmat yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga dapat didapat dengan cara mudah. Salah satunya adalah memasak Rica Rica Manado Pedas Nikmat untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang bisa anda coba salah satunya rica rica manado pedas nikmat yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep rica rica manado pedas nikmat tanpa harus bersusah payah.
Berikut ini resep Rica Rica Manado Pedas Nikmat yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Rica Rica Manado Pedas Nikmat:

1. Harap siapkan 500 gr daging Babi/Sapi/Ayam, potong potong lalu cuci bersih dan tiriskan
1. Harap siapkan 1 ikat daun kemangi segar, buang batang kerasnya, cuci bersih dan tiriskan
1. Diperlukan 500 ml air
1. Diperlukan  Bumbu Halus
1. Jangan lupa 8 siung bawang merah
1. Diperlukan 4 siung bawang putih
1. Tambah 3 butir ketumbar
1. Harap siapkan 1 ruas jari jahe
1. Dibutuhkan 1 ruas jari lengkuas
1. Diperlukan 3 ruas jari kunyit
1. Jangan lupa 1 batang kecombrang muda, iris halus memanjang seperti korek api (kalau tidak suka boleh di skip ya)
1. Siapkan  Bumbu Kasar
1. Tambah 25 buah Cabai merah
1. Dibutuhkan 10 buah Cabai rawit merah (jika suka lebih pedas bisa ditambahkan)
1. Dibutuhkan  Bumbu Tabur
1. Diperlukan Secukupnya garam halus
1. Siapkan 1 sdt lada bubuk
1. Siapkan 5 lembar daun jeruk
1. Tambah 2 lembar daun salam
1. Diperlukan 1 batang serai (geprek)
1. Diperlukan 1 ruas jari lengkuas (geprek)




<!--inarticleads2-->

##### Bagaimana membuat  Rica Rica Manado Pedas Nikmat:

1. Tumis bumbu halus, bumbu kasar hingga harum dan matang, lalu masukkan sereh, daun jeruk dan daun salam. Tumis hingga harum
1. Masukkan daging kedalam tumisan bumbu, aduk aduk hingga daging setengah matang
1. Setelah diaduk merata daging dan bumbu, tambah kan air sedikit demi sedikit
1. Masukkan bumbu halus, koreksi rasa, masak hingga daging empuk, baru masukkan daun kemangi, aduk aduk sebentar saja supaya daun kemangi tidak terlalu layu. Angkat dan siap disajikan. 😍




Demikianlah cara membuat rica rica manado pedas nikmat yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
