---
description: "Bagaimana menyiapakan Rica-Rica Babi (Non Halal) minggu ini"
title: "Bagaimana menyiapakan Rica-Rica Babi (Non Halal) minggu ini"
slug: 306-bagaimana-menyiapakan-rica-rica-babi-non-halal-minggu-ini
date: 2020-09-21T14:44:45.646Z
image: https://img-global.cpcdn.com/recipes/9ab4a862f7d7b9d4/751x532cq70/rica-rica-babi-non-halal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9ab4a862f7d7b9d4/751x532cq70/rica-rica-babi-non-halal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9ab4a862f7d7b9d4/751x532cq70/rica-rica-babi-non-halal-foto-resep-utama.jpg
author: Edith Summers
ratingvalue: 4.6
reviewcount: 2520
recipeingredient:
- "1/2 kg Samcan"
- " Bumbu halus "
- "4 siung bawang putih"
- "6 siung bawang merah"
- "8 buah cabai merah keriting"
- "1 ruas jahe"
- "1 buah tomat sedang"
- "1 ruas lengkuas dimemarkan"
- "6 lembar daun jeruk"
- "1 batang daun prei potong2"
- "secukupnya Garam merica royco"
- "secukupnya Air"
- "2 sdm margarin"
recipeinstructions:
- "Rebus sancam biar empuk, tiriskan n potong2 sesuai selera,klo saya potong kotak2 kecil"
- "Panaskan margarin, tumis bumbu halus hingga harum, tambahkan lengkuas dan daun jeruk, masak hingga harum, bumbui"
- "Kemudian masukkan sancam yang sudah dipotong2, aduk rata"
- "Tambahkan air secukupnya, tes rasa, jika sudah pas, masukkan daun prei, aduk rata, tunggu hingga air asat (klo saya suka rica yg kuag sedikit)"
- "Rica2 siap dihidangkan 😊"
categories:
- Recipe
tags:
- ricarica
- babi
- non

katakunci: ricarica babi non 
nutrition: 225 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Lunch

---


![Rica-Rica Babi (Non Halal)](https://img-global.cpcdn.com/recipes/9ab4a862f7d7b9d4/751x532cq70/rica-rica-babi-non-halal-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang patut kita jaga karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti rica-rica babi (non halal) yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Kita



Kehangatan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan Rica-Rica Babi (Non Halal) untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang bisa anda contoh salah satunya rica-rica babi (non halal) yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep rica-rica babi (non halal) tanpa harus bersusah payah.
Berikut ini resep Rica-Rica Babi (Non Halal) yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 13 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Rica-Rica Babi (Non Halal):

1. Siapkan 1/2 kg Samcan
1. Jangan lupa  Bumbu halus :
1. Dibutuhkan 4 siung bawang putih
1. Jangan lupa 6 siung bawang merah
1. Siapkan 8 buah cabai merah keriting
1. Dibutuhkan 1 ruas jahe
1. Siapkan 1 buah tomat sedang
1. Dibutuhkan 1 ruas lengkuas dimemarkan
1. Tambah 6 lembar daun jeruk
1. Siapkan 1 batang daun prei, potong2
1. Diperlukan secukupnya Garam, merica, royco
1. Siapkan secukupnya Air
1. Siapkan 2 sdm margarin




<!--inarticleads2-->

##### Langkah membuat  Rica-Rica Babi (Non Halal):

1. Rebus sancam biar empuk, tiriskan n potong2 sesuai selera,klo saya potong kotak2 kecil
1. Panaskan margarin, tumis bumbu halus hingga harum, tambahkan lengkuas dan daun jeruk, masak hingga harum, bumbui
1. Kemudian masukkan sancam yang sudah dipotong2, aduk rata
1. Tambahkan air secukupnya, tes rasa, jika sudah pas, masukkan daun prei, aduk rata, tunggu hingga air asat (klo saya suka rica yg kuag sedikit)
1. Rica2 siap dihidangkan 😊




Demikianlah cara membuat rica-rica babi (non halal) yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan terbukti, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
