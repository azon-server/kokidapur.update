---
description: "Cara membuat Babi Rica Rica terupdate"
title: "Cara membuat Babi Rica Rica terupdate"
slug: 289-cara-membuat-babi-rica-rica-terupdate
date: 2020-10-01T00:22:04.480Z
image: https://img-global.cpcdn.com/recipes/aa51655dc551f7f0/751x532cq70/babi-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/aa51655dc551f7f0/751x532cq70/babi-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/aa51655dc551f7f0/751x532cq70/babi-rica-rica-foto-resep-utama.jpg
author: Cora Casey
ratingvalue: 4
reviewcount: 3020
recipeingredient:
- "1/2 kilo samcam babi"
- "Seikat kemangi siangi"
- "Seikat daun bawang iris2"
- "4 batang sereh geprek"
- "5 lembar daun jeruk"
- "5 lembar daun salam"
- "Sejempol lengkuas geprek"
- " Bumbu halus"
- "10 butir bawang merah"
- "4 siung bawang putih"
- "Seruas jahe"
- "3 buah kecil kunyit"
- "20 biji cabe rawit"
- "5 buah cabe merah"
- "sesuai selera Garam dan gula"
- "1 sendok teh kaldu jamur"
recipeinstructions:
- "Panaskan air hingga mendidih, masukkan samcam hingga berubah warna dan buih2 kotornya mengambang. Angkat. Buang airnya dan potong2 samcam sesuai selera. Sisihkan"
- "Panaskan sedikit minyak, tumis bawang merah dan bawang putih halus hingga harum. Lalu masukkan sereh, lengkuas, daun jeruk, daun salam masak hingga harum. Masukkan kunyit dan jahe yang sudah diblender tumis lagi hingga matang dan tidak berbau langu. Masukkan cabe rawit dan cabe merah yang sudah dihaluskan, masak hingga bumbu matang."
- "Jika bumbu sudah matang, masukkan potongan samcam dan air hingga semua potongan daging terendam. Masak hingga daging empuk dan bumbu menyusut mengental. Jika sudah nyusut namun belum empuk tmbahkan lagi air."
- "Bumbui daging yang sudah empuk dan nyusut dengan garam, sedikit gula, dan kaldu jamur. Masukkan irisan daun bawang, aduk2 hingga rata. Sesaat sebelum matang masukkan daun kemangi. Babi rica rica siap untuk dihidangkan ♥️"
categories:
- Recipe
tags:
- babi
- rica
- rica

katakunci: babi rica rica 
nutrition: 177 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT53M"
recipeyield: "4"
recipecategory: Dessert

---


![Babi Rica Rica](https://img-global.cpcdn.com/recipes/aa51655dc551f7f0/751x532cq70/babi-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga enak. Ciri khas makanan Nusantara babi rica rica yang penuh dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Babi Rica Rica untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda coba salah satunya babi rica rica yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep babi rica rica tanpa harus bersusah payah.
Berikut ini resep Babi Rica Rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 16 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Babi Rica Rica:

1. Dibutuhkan 1/2 kilo samcam babi
1. Diperlukan Seikat kemangi, siangi
1. Dibutuhkan Seikat daun bawang, iris2
1. Jangan lupa 4 batang sereh, geprek
1. Siapkan 5 lembar daun jeruk
1. Tambah 5 lembar daun salam
1. Harus ada Sejempol lengkuas, geprek
1. Siapkan  Bumbu halus:
1. Dibutuhkan 10 butir bawang merah
1. Harus ada 4 siung bawang putih
1. Harap siapkan Seruas jahe
1. Siapkan 3 buah kecil kunyit
1. Siapkan 20 biji cabe rawit
1. Dibutuhkan 5 buah cabe merah
1. Diperlukan sesuai selera Garam dan gula
1. Harus ada 1 sendok teh kaldu jamur




<!--inarticleads2-->

##### Bagaimana membuat  Babi Rica Rica:

1. Panaskan air hingga mendidih, masukkan samcam hingga berubah warna dan buih2 kotornya mengambang. Angkat. Buang airnya dan potong2 samcam sesuai selera. Sisihkan
1. Panaskan sedikit minyak, tumis bawang merah dan bawang putih halus hingga harum. Lalu masukkan sereh, lengkuas, daun jeruk, daun salam masak hingga harum. Masukkan kunyit dan jahe yang sudah diblender tumis lagi hingga matang dan tidak berbau langu. Masukkan cabe rawit dan cabe merah yang sudah dihaluskan, masak hingga bumbu matang.
1. Jika bumbu sudah matang, masukkan potongan samcam dan air hingga semua potongan daging terendam. Masak hingga daging empuk dan bumbu menyusut mengental. Jika sudah nyusut namun belum empuk tmbahkan lagi air.
1. Bumbui daging yang sudah empuk dan nyusut dengan garam, sedikit gula, dan kaldu jamur. Masukkan irisan daun bawang, aduk2 hingga rata. Sesaat sebelum matang masukkan daun kemangi. Babi rica rica siap untuk dihidangkan ♥️




Demikianlah cara membuat babi rica rica yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
