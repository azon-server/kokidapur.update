---
description: "Langkah untuk menyiapakan Timlo Solo Cepat"
title: "Langkah untuk menyiapakan Timlo Solo Cepat"
slug: 38-langkah-untuk-menyiapakan-timlo-solo-cepat
date: 2021-01-24T17:11:52.315Z
image: https://img-global.cpcdn.com/recipes/60f89eebc7318e53/751x532cq70/timlo-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/60f89eebc7318e53/751x532cq70/timlo-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/60f89eebc7318e53/751x532cq70/timlo-solo-foto-resep-utama.jpg
author: Jon Love
ratingvalue: 4.2
reviewcount: 47608
recipeingredient:
- " Bumbu cemplung kaldu "
- "2 bh kapulaga"
- "1 cm kayu manis"
- "2 btr cengkeh"
- "1 bh bunga lawang"
- "1/8 sdt pala bubuk"
- "1/4 sdt merica bubuk"
- "1 ruas Jahe geprak"
- " Bumbu tumis Kaldu "
- "3 siung bawang merah haluskan skip"
- "3 siung besar bawang putih saya tambah dr resep asli 1 Cincang"
- " Bahan lain "
- "100 gram ayam untuk suwiran resep asli 200 gr"
- "1  5 liter air kaldu dari rebusan tulang sisa isian sosis solo"
- "1 sdm kaldu jamurbubuk"
- "secukupnya Garam dan gula"
- "1 btg daun bawang simpulkan"
- " Isian dan Pelengkap "
- "2 bh kentang Untuk dibuat kripik"
- "2 btg wortel blansir sebentar"
- "Segenggam jamur kuping rendam air"
- "1 bungkus kcl soun"
- "secukupnya bawang goreng Skip diganti sdkt irisan daun bawang"
- " Sambal kecal dari kecap dan irisan bawang putih cabe rawit"
- "sesuai selera Atau sambal rawit rebus"
- " Pindang Telur dan Rempelo ati"
- "2 btr telur ayam rebus"
- "2 pasang rempelo ati bersihkan"
- "1 siung bawang putih haluskan"
- "2 sdm kecap manis bisa ditambah sesuai selera"
- "4 lbr daun salam"
- "Secukupnya garam"
- " Sosis Solo"
- "1/2 resep sosis solo kukus resep asli digoreng           lihat resep"
recipeinstructions:
- "Buat sosis solo, buat 1/2 resep dari resep terlampir"
- "Buat kripik kentang, cuci bersih kentang. Belah 2 lalu iris tipis. Cuci bersih hingga air cucian bening. Beri garam 1 sdm diamkan sebentar lalu goreng dengan api kecil bertahap (sedikit-sedikit) hingga coklat keemasan. Angkat tiriskan."
- "Buat pindang telur dan rempelo ati, rebus sebentar rempelo ati sampai tidak ada darahnya, buang air rebusan, sisihkan. Rebus telur hingga matang, lalu kupas stlh dingin. Campurkan telur dan rempelo ati dalam panci dengan dibumbui bawang, garam, daun salam dan kecap hingga matang dan meresap. Cek rasa dan angkat"
- "Buat kaldunya, cuci bersih dada ayam dan sisa tulang isian sosis, beri garam dan air perasan jeruk nipis, remas-remas, diamkan beberapa saat, lalu cuci bersih kembali, tiriskan. Kemudian rebus ayam dalam air mendidih sebentar saja. Buang air rebusan pertama. Selanjutnya didihkan 1.5 lt air. masukkan ayam kembali, masak hingga mendidih."
- "Sementara menunggu rebusan ayam mendidih. tumis bawang putih hingga kering dan harum, angkat dan campur kedalam rebusan kaldu bersama bumbu cemplung kedalam rebusan ayam. didihkan Beri kaldu jamur, garam dan gula bubuk test rasa. Saring kaldu dan angkat ayam sdh matang dan suir-suir, sisihkan."
- "Terakhir buat isian dan pelengkap sementara menunggu kaldu matang, Rebus wortel yang sudah dipotong hingga matang, angkat dan tiriskan, jgn buang kaldu wortel untuk merendam soun, sampai soun lembut, potong sedikit dan tiriskan. Rebus hg me didih jamur kuping yg sudah dibersihkan dan dipotong2, angkat dan tiriskan."
- "Tata dimangkuk semua isian dan pelengkap, irisan sosis solo, pindang telur dan ati rempelo, soun, kentang goreng, ayam suir, wortel, jamur kuping, tuang kuahnya dan sajikan dengan nasi putih dan sambal kecal atau sambal rawit dan jeruk nipis. Selamat menikmati."
categories:
- Recipe
tags:
- timlo
- solo

katakunci: timlo solo 
nutrition: 279 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Dinner

---


![Timlo Solo](https://img-global.cpcdn.com/recipes/60f89eebc7318e53/751x532cq70/timlo-solo-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau renyah. Karasteristik masakan Nusantara timlo solo yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Keharmonisan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah memasak Timlo Solo untuk orang di rumah. Momen makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang dapat anda buat salah satunya timlo solo yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep timlo solo tanpa harus bersusah payah.
Berikut ini resep Timlo Solo yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 34 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Timlo Solo:

1. Diperlukan  Bumbu cemplung (kaldu) :
1. Diperlukan 2 bh kapulaga
1. Harap siapkan 1 cm kayu manis
1. Diperlukan 2 btr cengkeh
1. Dibutuhkan 1 bh bunga lawang
1. Siapkan 1/8 sdt pala bubuk
1. Diperlukan 1/4 sdt merica bubuk
1. Dibutuhkan 1 ruas Jahe geprak
1. Jangan lupa  Bumbu tumis (Kaldu) :
1. Siapkan 3 siung bawang merah haluskan (skip)
1. Jangan lupa 3 siung besar bawang putih (saya tambah dr resep asli 1) Cincang
1. Jangan lupa  Bahan lain :
1. Harap siapkan 100 gram ayam untuk suwiran (resep asli 200 gr)
1. Harus ada 1 , 5 liter air kaldu, dari rebusan tulang sisa isian sosis solo
1. Siapkan 1 sdm kaldu jamur/bubuk
1. Diperlukan secukupnya Garam dan gula
1. Diperlukan 1 btg daun bawang simpulkan
1. Tambah  Isian dan Pelengkap :
1. Diperlukan 2 bh kentang Untuk dibuat kripik
1. Diperlukan 2 btg wortel, blansir sebentar
1. Dibutuhkan Segenggam jamur kuping, rendam air
1. Tambah 1 bungkus kcl soun
1. Tambah secukupnya bawang goreng (Skip diganti sdkt irisan daun bawang)
1. Dibutuhkan  Sambal kecal, dari kecap dan irisan bawang putih, cabe rawit
1. Siapkan sesuai selera Atau sambal rawit rebus,
1. Jangan lupa  Pindang Telur dan Rempelo ati
1. Diperlukan 2 btr telur ayam, rebus
1. Tambah 2 pasang rempelo ati, bersihkan
1. Diperlukan 1 siung bawang putih, haluskan
1. Dibutuhkan 2 sdm kecap manis (bisa ditambah sesuai selera)
1. Harap siapkan 4 lbr daun salam
1. Diperlukan Secukupnya garam
1. Diperlukan  Sosis Solo
1. Siapkan 1/2 resep sosis solo kukus (resep asli digoreng)           (lihat resep)




<!--inarticleads2-->

##### Cara membuat  Timlo Solo:

1. Buat sosis solo, buat 1/2 resep dari resep terlampir
1. Buat kripik kentang, cuci bersih kentang. Belah 2 lalu iris tipis. Cuci bersih hingga air cucian bening. Beri garam 1 sdm diamkan sebentar lalu goreng dengan api kecil bertahap (sedikit-sedikit) hingga coklat keemasan. Angkat tiriskan.
1. Buat pindang telur dan rempelo ati, rebus sebentar rempelo ati sampai tidak ada darahnya, buang air rebusan, sisihkan. Rebus telur hingga matang, lalu kupas stlh dingin. Campurkan telur dan rempelo ati dalam panci dengan dibumbui bawang, garam, daun salam dan kecap hingga matang dan meresap. Cek rasa dan angkat
1. Buat kaldunya, cuci bersih dada ayam dan sisa tulang isian sosis, beri garam dan air perasan jeruk nipis, remas-remas, diamkan beberapa saat, lalu cuci bersih kembali, tiriskan. Kemudian rebus ayam dalam air mendidih sebentar saja. Buang air rebusan pertama. Selanjutnya didihkan 1.5 lt air. masukkan ayam kembali, masak hingga mendidih.
1. Sementara menunggu rebusan ayam mendidih. tumis bawang putih hingga kering dan harum, angkat dan campur kedalam rebusan kaldu bersama bumbu cemplung kedalam rebusan ayam. didihkan Beri kaldu jamur, garam dan gula bubuk test rasa. Saring kaldu dan angkat ayam sdh matang dan suir-suir, sisihkan.
1. Terakhir buat isian dan pelengkap sementara menunggu kaldu matang, Rebus wortel yang sudah dipotong hingga matang, angkat dan tiriskan, jgn buang kaldu wortel untuk merendam soun, sampai soun lembut, potong sedikit dan tiriskan. Rebus hg me didih jamur kuping yg sudah dibersihkan dan dipotong2, angkat dan tiriskan.
1. Tata dimangkuk semua isian dan pelengkap, irisan sosis solo, pindang telur dan ati rempelo, soun, kentang goreng, ayam suir, wortel, jamur kuping, tuang kuahnya dan sajikan dengan nasi putih dan sambal kecal atau sambal rawit dan jeruk nipis. Selamat menikmati.




Demikianlah cara membuat timlo solo yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan cepat, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
