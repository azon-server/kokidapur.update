---
description: "Panduan menyiapakan Air Kacang hijau(utk panas dalam) terupdate"
title: "Panduan menyiapakan Air Kacang hijau(utk panas dalam) terupdate"
slug: 457-panduan-menyiapakan-air-kacang-hijauutk-panas-dalam-terupdate
date: 2020-10-16T17:46:05.385Z
image: https://img-global.cpcdn.com/recipes/b36ff9198ed85551/751x532cq70/air-kacang-hijauutk-panas-dalam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b36ff9198ed85551/751x532cq70/air-kacang-hijauutk-panas-dalam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b36ff9198ed85551/751x532cq70/air-kacang-hijauutk-panas-dalam-foto-resep-utama.jpg
author: Isaiah Greene
ratingvalue: 4.9
reviewcount: 41297
recipeingredient:
- "3 genggam penuh kacang hijau"
- "1 helai pandan simpulkan"
- "Secukupnya gula merahselera manis masing2"
- " Air 12 panci rice cooker"
recipeinstructions:
- "Cuci bersih lalu rendam kacang hijau semalaman..agar ketika dimasak mudah pecah dan matang..sisihkan"
- "Rebus air,masukkan gula merah..tes rasa manisnya..jika sdh pas.matikan kompor..saring dl..buang pasir2nya..tuang kembali air gula merah kedalam rice cooker lalu masukkan pandan dan kacang hijau..atur ke mode &#34;cook&#34;..seperti memasak nasi..sesekali di cek..apkah sdh pecah..bila sdh matang sajikan."
- "Note: jangan ditinggal dlm mode cook..takutnya air kering dan gosong..td sy cb tggu apakah bs berubah ke mode warm sperti masak nasi,ga pindah2 jg..setelah sejam..jdnya sy matiin manual sndri..sy pakai ricecooker utk memudahkan sj..tips jika smbl mengerjakan hal lain 😊"
categories:
- Recipe
tags:
- air
- kacang
- hijauutk

katakunci: air kacang hijauutk 
nutrition: 113 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Lunch

---


![Air Kacang hijau(utk panas dalam)](https://img-global.cpcdn.com/recipes/b36ff9198ed85551/751x532cq70/air-kacang-hijauutk-panas-dalam-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti air kacang hijau(utk panas dalam) yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Indonesia



Keharmonisan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah memasak Air Kacang hijau(utk panas dalam) untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang bisa anda coba salah satunya air kacang hijau(utk panas dalam) yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep air kacang hijau(utk panas dalam) tanpa harus bersusah payah.
Berikut ini resep Air Kacang hijau(utk panas dalam) yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 4 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Air Kacang hijau(utk panas dalam):

1. Dibutuhkan 3 genggam penuh kacang hijau
1. Jangan lupa 1 helai pandan simpulkan
1. Diperlukan Secukupnya gula merah(selera manis masing2)
1. Tambah  Air 1/2 panci rice cooker




<!--inarticleads2-->

##### Cara membuat  Air Kacang hijau(utk panas dalam):

1. Cuci bersih lalu rendam kacang hijau semalaman..agar ketika dimasak mudah pecah dan matang..sisihkan
1. Rebus air,masukkan gula merah..tes rasa manisnya..jika sdh pas.matikan kompor..saring dl..buang pasir2nya..tuang kembali air gula merah kedalam rice cooker lalu masukkan pandan dan kacang hijau..atur ke mode &#34;cook&#34;..seperti memasak nasi..sesekali di cek..apkah sdh pecah..bila sdh matang sajikan.
1. Note: jangan ditinggal dlm mode cook..takutnya air kering dan gosong..td sy cb tggu apakah bs berubah ke mode warm sperti masak nasi,ga pindah2 jg..setelah sejam..jdnya sy matiin manual sndri..sy pakai ricecooker utk memudahkan sj..tips jika smbl mengerjakan hal lain 😊




Demikianlah cara membuat air kacang hijau(utk panas dalam) yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan cepat, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
