---
description: "Resep : Rica B2 🐷 (100% Non Halal) terupdate"
title: "Resep : Rica B2 🐷 (100% Non Halal) terupdate"
slug: 274-resep-rica-b2-100-non-halal-terupdate
date: 2021-01-05T23:56:35.734Z
image: https://img-global.cpcdn.com/recipes/aa3b7932786b9d5d/751x532cq70/rica-b2-🐷-100-non-halal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/aa3b7932786b9d5d/751x532cq70/rica-b2-🐷-100-non-halal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/aa3b7932786b9d5d/751x532cq70/rica-b2-🐷-100-non-halal-foto-resep-utama.jpg
author: Landon Reese
ratingvalue: 4
reviewcount: 24607
recipeingredient:
- "1/4 kg daging babi campur"
- "1 btg serai"
- "8 lbr daun jeruk"
- "3 lbr daun salam"
- "2 ruas lengkuas"
- " Kecap manis"
- "secukupnya Gula merah"
- " Garam"
- " Kaldu ayam bubuk"
- " Minyak untuk tumis"
- " Air"
- " Bumbu halus "
- "5 siung bawang putih"
- "6 siung bawang merah"
- "3 btr kemiri"
- "1/2 sdt ketumbar"
- "2 ruas kunyit"
- "1 sdt merica"
- "2 ruas jahe"
- "15 bj cabe marah kriting sesuai selera pedas"
recipeinstructions:
- "Rebus daging babi sampai empuk dan buang airnya"
- "Potong kecil2 atau sesuai selera, jika ingin cpt empuk potongnya tipis2 aja"
- "Siapkan bumbu halus lalu tumis sampai harum, dan masukkan juga serai, daun jeruk, daun salam, lengkuas"
- "Lalu beri air dan masukkan dagingnya"
- "Masukkan juga gula merah,kecap, kaldu ayam bubuk, dan garam (secukupnya semua ya)"
- "Tunggu sampai air asat dan mengental lalu cek rasa"
- "Siap disajikan dg nasi putih hangat😍"
categories:
- Recipe
tags:
- rica
- b2
- 

katakunci: rica b2  
nutrition: 107 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Dinner

---


![Rica B2 🐷 (100% Non Halal)](https://img-global.cpcdn.com/recipes/aa3b7932786b9d5d/751x532cq70/rica-b2-🐷-100-non-halal-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga renyah. Ciri khas makanan Nusantara rica b2 🐷 (100% non halal) yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Rica B2 🐷 (100% Non Halal) untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi makanan yang bisa anda contoh salah satunya rica b2 🐷 (100% non halal) yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep rica b2 🐷 (100% non halal) tanpa harus bersusah payah.
Berikut ini resep Rica B2 🐷 (100% Non Halal) yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Rica B2 🐷 (100% Non Halal):

1. Tambah 1/4 kg daging babi campur
1. Harus ada 1 btg serai
1. Tambah 8 lbr daun jeruk
1. Harap siapkan 3 lbr daun salam
1. Tambah 2 ruas lengkuas
1. Harap siapkan  Kecap manis
1. Harap siapkan secukupnya Gula merah
1. Siapkan  Garam
1. Dibutuhkan  Kaldu ayam bubuk
1. Siapkan  Minyak untuk tumis
1. Siapkan  Air
1. Harap siapkan  Bumbu halus :
1. Diperlukan 5 siung bawang putih
1. Diperlukan 6 siung bawang merah
1. Harap siapkan 3 btr kemiri
1. Harus ada 1/2 sdt ketumbar
1. Dibutuhkan 2 ruas kunyit
1. Tambah 1 sdt merica
1. Harus ada 2 ruas jahe
1. Siapkan 15 bj cabe marah kriting (sesuai selera pedas)




<!--inarticleads2-->

##### Langkah membuat  Rica B2 🐷 (100% Non Halal):

1. Rebus daging babi sampai empuk dan buang airnya
1. Potong kecil2 atau sesuai selera, jika ingin cpt empuk potongnya tipis2 aja
1. Siapkan bumbu halus lalu tumis sampai harum, dan masukkan juga serai, daun jeruk, daun salam, lengkuas
1. Lalu beri air dan masukkan dagingnya
1. Masukkan juga gula merah,kecap, kaldu ayam bubuk, dan garam (secukupnya semua ya)
1. Tunggu sampai air asat dan mengental lalu cek rasa
1. Siap disajikan dg nasi putih hangat😍




Demikianlah cara membuat rica b2 🐷 (100% non halal) yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
