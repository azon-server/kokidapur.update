---
description: "Steps membuat Salad Roll Cepat"
title: "Steps membuat Salad Roll Cepat"
slug: 100-steps-membuat-salad-roll-cepat
date: 2020-10-03T21:20:00.704Z
image: https://img-global.cpcdn.com/recipes/baa78a5785641aa8/751x532cq70/salad-roll-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/baa78a5785641aa8/751x532cq70/salad-roll-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/baa78a5785641aa8/751x532cq70/salad-roll-foto-resep-utama.jpg
author: Sally McCoy
ratingvalue: 4.3
reviewcount: 35409
recipeingredient:
- "2 buah wortel"
- "1/2 buah kol ungu"
- "1/2 buah lettuce"
- "3 buah timun timun jepangtimun biasa"
- "1/2 kg daging sapi"
- " Topping biji wijen"
- "Secukupnya margarine"
- "Secukupnya kecap asin"
- "Secukupnya garam"
- "Secukupnya penyedap rasa"
recipeinstructions:
- "Cuci bersih sayur-sayuran. Kemudian untuk timun diiris tipis-tipis menjadi beberapa lembaran. Untuk wortel diparut memanjang. Kemudian potong memanjang juga kol ungu dan lettuce"
- "Lelehkan margarine, kemudian masukkan daging sapi. Masak hingga daging sapi berubah warna menjadi kecoklatan, kemudian masukkan garam, kecap asin dan penyedap rasa (test rasa, sesuaikan dengan selera ya)"
- "Tumis lettuce dan kol ungu masing-masing hingga layu. Jika suka yang mentah step ini bisa dilewati ya"
- "Tata semua bahan diatas piring saji. Kemudian taburin biji wijen diatasnya sebagai pemanis. Salad roll siap dihidangkan dan dinikmati"
categories:
- Recipe
tags:
- salad
- roll

katakunci: salad roll 
nutrition: 195 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Lunch

---


![Salad Roll](https://img-global.cpcdn.com/recipes/baa78a5785641aa8/751x532cq70/salad-roll-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan enak. Ciri masakan Nusantara salad roll yang kaya dengan rempah menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kedekatan keluarga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Salad Roll untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang dapat anda praktekkan salah satunya salad roll yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep salad roll tanpa harus bersusah payah.
Seperti resep Salad Roll yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Salad Roll:

1. Dibutuhkan 2 buah wortel
1. Harus ada 1/2 buah kol ungu
1. Tambah 1/2 buah lettuce
1. Dibutuhkan 3 buah timun (timun jepang/timun biasa)
1. Siapkan 1/2 kg daging sapi
1. Diperlukan  Topping biji wijen
1. Diperlukan Secukupnya margarine
1. Jangan lupa Secukupnya kecap asin
1. Siapkan Secukupnya garam
1. Siapkan Secukupnya penyedap rasa




<!--inarticleads2-->

##### Cara membuat  Salad Roll:

1. Cuci bersih sayur-sayuran. Kemudian untuk timun diiris tipis-tipis menjadi beberapa lembaran. Untuk wortel diparut memanjang. Kemudian potong memanjang juga kol ungu dan lettuce
1. Lelehkan margarine, kemudian masukkan daging sapi. Masak hingga daging sapi berubah warna menjadi kecoklatan, kemudian masukkan garam, kecap asin dan penyedap rasa (test rasa, sesuaikan dengan selera ya)
1. Tumis lettuce dan kol ungu masing-masing hingga layu. Jika suka yang mentah step ini bisa dilewati ya
1. Tata semua bahan diatas piring saji. Kemudian taburin biji wijen diatasnya sebagai pemanis. Salad roll siap dihidangkan dan dinikmati




Demikianlah cara membuat salad roll yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
