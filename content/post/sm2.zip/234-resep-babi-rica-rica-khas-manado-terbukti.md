---
description: "Resep : Babi Rica-Rica Khas Manado Terbukti"
title: "Resep : Babi Rica-Rica Khas Manado Terbukti"
slug: 234-resep-babi-rica-rica-khas-manado-terbukti
date: 2020-11-17T06:24:23.330Z
image: https://img-global.cpcdn.com/recipes/c688e2ecb125dcb9/751x532cq70/babi-rica-rica-khas-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c688e2ecb125dcb9/751x532cq70/babi-rica-rica-khas-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c688e2ecb125dcb9/751x532cq70/babi-rica-rica-khas-manado-foto-resep-utama.jpg
author: Roy Larson
ratingvalue: 4.7
reviewcount: 21673
recipeingredient:
- "1/2 kg babi"
- " Bumbu halus "
- "15 bawang merah"
- "7 bawang putih"
- "2 ruas kunyit"
- "2 ruas lengkuas"
- "5 cabe merah besar buang bijinya"
- "Secukupnya Cabe rawit sesuaikan dgn selera kepedasan"
- "5 butir kemiri"
- " Bumbu Pelengkap "
- "5 batang serai geprek"
- "4 helai daun jeruk"
recipeinstructions:
- "Siapkan bumbu yg diperlukan. Sangrai sebentar bumbu halus lalu ulek/blender semuanya. Sisihkan. Lalu, potong2 daging babi sesuai selera."
- "Siapkan wajan yg berisi minyak panas. Lalu, tumis bumbu halus hingga tidak langu. Tambahkan pula serai dan daun jeruk."
- "Tips : Masukkan daging babi tanpa air. Aduk2 hingga daging babi mengeluarkan airnya sendiri. Ini bertujuan supaya tekstur dagingnya tidak &#39;gembur&#39; atau berair sehingga menghasilkan rasa daging yg &#39;kesat&#39; dan enak banget pokoknyaa ☺"
- "Jika daging babi sudah mulai asat, tambahkan air. Masukkan garam dan gula. Cek rasa, jika rasa sudah sesuai selera, sajikan."
categories:
- Recipe
tags:
- babi
- ricarica
- khas

katakunci: babi ricarica khas 
nutrition: 277 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Lunch

---


![Babi Rica-Rica Khas Manado](https://img-global.cpcdn.com/recipes/c688e2ecb125dcb9/751x532cq70/babi-rica-rica-khas-manado-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga gurih. Ciri masakan Nusantara babi rica-rica khas manado yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Keharmonisan keluarga bisa didapat dengan cara sederhana. Salah satunya adalah membuat makanan Babi Rica-Rica Khas Manado untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang bisa anda buat salah satunya babi rica-rica khas manado yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep babi rica-rica khas manado tanpa harus bersusah payah.
Berikut ini resep Babi Rica-Rica Khas Manado yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 12 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Babi Rica-Rica Khas Manado:

1. Dibutuhkan 1/2 kg babi
1. Siapkan  Bumbu halus :
1. Harap siapkan 15 bawang merah
1. Jangan lupa 7 bawang putih
1. Harus ada 2 ruas kunyit
1. Tambah 2 ruas lengkuas
1. Dibutuhkan 5 cabe merah besar (buang bijinya)
1. Diperlukan Secukupnya Cabe rawit (sesuaikan dgn selera kepedasan)
1. Harap siapkan 5 butir kemiri
1. Harus ada  Bumbu Pelengkap :
1. Jangan lupa 5 batang serai (geprek)
1. Harus ada 4 helai daun jeruk




<!--inarticleads2-->

##### Instruksi membuat  Babi Rica-Rica Khas Manado:

1. Siapkan bumbu yg diperlukan. Sangrai sebentar bumbu halus lalu ulek/blender semuanya. Sisihkan. Lalu, potong2 daging babi sesuai selera.
1. Siapkan wajan yg berisi minyak panas. Lalu, tumis bumbu halus hingga tidak langu. Tambahkan pula serai dan daun jeruk.
1. Tips : Masukkan daging babi tanpa air. Aduk2 hingga daging babi mengeluarkan airnya sendiri. Ini bertujuan supaya tekstur dagingnya tidak &#39;gembur&#39; atau berair sehingga menghasilkan rasa daging yg &#39;kesat&#39; dan enak banget pokoknyaa ☺
1. Jika daging babi sudah mulai asat, tambahkan air. Masukkan garam dan gula. Cek rasa, jika rasa sudah sesuai selera, sajikan.




Demikianlah cara membuat babi rica-rica khas manado yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
