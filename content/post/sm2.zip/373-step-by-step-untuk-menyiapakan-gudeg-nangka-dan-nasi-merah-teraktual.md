---
description: "Step-by-Step untuk menyiapakan Gudeg Nangka dan Nasi Merah teraktual"
title: "Step-by-Step untuk menyiapakan Gudeg Nangka dan Nasi Merah teraktual"
slug: 373-step-by-step-untuk-menyiapakan-gudeg-nangka-dan-nasi-merah-teraktual
date: 2020-12-15T00:05:31.206Z
image: https://img-global.cpcdn.com/recipes/4aca935cc819f098/751x532cq70/gudeg-nangka-dan-nasi-merah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4aca935cc819f098/751x532cq70/gudeg-nangka-dan-nasi-merah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4aca935cc819f098/751x532cq70/gudeg-nangka-dan-nasi-merah-foto-resep-utama.jpg
author: Marion Ortega
ratingvalue: 4.8
reviewcount: 21199
recipeingredient:
- "250 gr daging nangka muda kalengan nangka segar lebik ok lagi"
- "50 gr Lobak putih opsionalsaya ada sisa saja syg dibuang"
- "3 buah telurtelur puyuh yg sudah direbus"
- "200 gr santan kelapa saya ganti dgn krim susu untuk memasak"
- " Bumbu halus "
- "2-3 buah bawang merah"
- "1 buah bawang putih"
- "Sedikit garam dan gula"
- "1 buah kemiri"
- "Sedikit ketumbar"
- " Bumbu tambahan "
- "4 lembar daun jeruk"
- "3 lembar daun salam"
- "Sedikit lengkuas"
- "Secukupnya gula merah saya gula merahnya terbatas"
- "Secukupnya Garam"
- " Kecap manis sbg penambah rasa manis dari gula merah"
- "1 batang sereh saya lagi ga punya"
- " Nasi merah  beras merahberas merah beras putih"
recipeinstructions:
- "Siapkan alat dan bahan. Ulek atau blender bumbu halus, cuci beras merah dan masak (tips dan trik nya ada di resep selanjitnya). Rebus telur dan buang kulitnya"
- "Untuk nangka segar setelah dipotong2 kemudian direbus dulu sebentar sampai getahnya keluar dan buang airnya. Saya kebetulan pakai yg kalengan jadi hanya tingal dipotong2 saja"
- "Masukan potongan nangka didalam panci, nyalakan kompor. Masukan bumbu halus, daun salam, daun jeruk, sereh, lengkuas, gula merah, garam gula dan kecap. Terakhir masukan santan dan aduk2 sebentar supaya semua tercampur dan masak dengan api sedang atau kecil"
- "Setelah nangka agak matang masukan juga telur rebus, koreksi rasa gudeg dan biarkan lagi sampai nangkanya matang"
- "Karna saya pakai kalengan jadi lama masaknya relatif lebih cepat dari yang memakai nangka segar jadi bisa dicoba2 saja ya"
- "Gudeg siap disajikan dengan nasi merah dsb :)"
categories:
- Recipe
tags:
- gudeg
- nangka
- dan

katakunci: gudeg nangka dan 
nutrition: 178 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Lunch

---


![Gudeg Nangka dan Nasi Merah](https://img-global.cpcdn.com/recipes/4aca935cc819f098/751x532cq70/gudeg-nangka-dan-nasi-merah-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga gurih. Ciri khas kuliner Nusantara gudeg nangka dan nasi merah yang kaya dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan rumah tangga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Gudeg Nangka dan Nasi Merah untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang bisa anda buat salah satunya gudeg nangka dan nasi merah yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep gudeg nangka dan nasi merah tanpa harus bersusah payah.
Seperti resep Gudeg Nangka dan Nasi Merah yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Gudeg Nangka dan Nasi Merah:

1. Dibutuhkan 250 gr daging nangka muda kalengan (nangka segar lebik ok lagi)
1. Harus ada 50 gr Lobak putih (opsional,saya ada sisa saja syg dibuang)
1. Diperlukan 3 buah telur/telur puyuh yg sudah direbus
1. Diperlukan 200 gr santan kelapa (saya ganti dgn krim susu untuk memasak)
1. Tambah  Bumbu halus :
1. Jangan lupa 2-3 buah bawang merah
1. Harap siapkan 1 buah bawang putih
1. Harap siapkan Sedikit garam dan gula
1. Diperlukan 1 buah kemiri
1. Tambah Sedikit ketumbar
1. Tambah  Bumbu tambahan :
1. Siapkan 4 lembar daun jeruk
1. Siapkan 3 lembar daun salam
1. Diperlukan Sedikit lengkuas
1. Diperlukan Secukupnya gula merah (saya gula merahnya terbatas)
1. Siapkan Secukupnya Garam
1. Jangan lupa  Kecap manis (sbg penambah rasa manis dari gula merah)
1. Dibutuhkan 1 batang sereh (saya lagi ga punya)
1. Harus ada  Nasi merah : beras merah/beras merah+ beras putih




<!--inarticleads2-->

##### Langkah membuat  Gudeg Nangka dan Nasi Merah:

1. Siapkan alat dan bahan. Ulek atau blender bumbu halus, cuci beras merah dan masak (tips dan trik nya ada di resep selanjitnya). Rebus telur dan buang kulitnya
1. Untuk nangka segar setelah dipotong2 kemudian direbus dulu sebentar sampai getahnya keluar dan buang airnya. Saya kebetulan pakai yg kalengan jadi hanya tingal dipotong2 saja
1. Masukan potongan nangka didalam panci, nyalakan kompor. Masukan bumbu halus, daun salam, daun jeruk, sereh, lengkuas, gula merah, garam gula dan kecap. Terakhir masukan santan dan aduk2 sebentar supaya semua tercampur dan masak dengan api sedang atau kecil
1. Setelah nangka agak matang masukan juga telur rebus, koreksi rasa gudeg dan biarkan lagi sampai nangkanya matang
1. Karna saya pakai kalengan jadi lama masaknya relatif lebih cepat dari yang memakai nangka segar jadi bisa dicoba2 saja ya
1. Gudeg siap disajikan dengan nasi merah dsb :)




Demikianlah cara membuat gudeg nangka dan nasi merah yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan teruji, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
