---
description: "Resep : Rainbow cake kukus ala Ny.liem teraktual"
title: "Resep : Rainbow cake kukus ala Ny.liem teraktual"
slug: 26-resep-rainbow-cake-kukus-ala-nyliem-teraktual
date: 2020-09-08T10:53:54.114Z
image: https://img-global.cpcdn.com/recipes/3db2f39ffc4162ad/751x532cq70/rainbow-cake-kukus-ala-nyliem-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3db2f39ffc4162ad/751x532cq70/rainbow-cake-kukus-ala-nyliem-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3db2f39ffc4162ad/751x532cq70/rainbow-cake-kukus-ala-nyliem-foto-resep-utama.jpg
author: Lois Burke
ratingvalue: 4.9
reviewcount: 10511
recipeingredient:
- "4 butir telur ayam utuh"
- "120 gr gula pasir resep asli 190gr tapi menurut saya manis bgt"
- "1 sdm emulsifier SP"
- "150 gr terigu"
- "1 sachet susu bubuk dancow"
- "secukupnya Essens vanila"
- "1 sachet susu kental manis putih"
- "1 bks santan kental me kara"
- "150 ml minyak sayur"
- "Sejumput garam"
- "6 macam warna pewarna makanan me cap kupu2 warna ungu biru hijau kuning orange merah"
- " Resep butter cream ala makfrida"
- "250 gr mentega putih"
- "125 gr white cooking chocolatemelted"
- "1/2 kaleng carnation"
recipeinstructions:
- "Panaskan kukusan dg api kecil"
- "Mixer telur,gula,garam dan essens vanila sampai gula hancur/larut..lalu masukan SP kocok dg speed tinggi sampai mengembang,kental berjejak"
- "Turunkan speed(rendah) masukan terigu &amp;susu bubuk aduk sebentar masukan SKM dan santan mixer sebentar saja asal rata..matikan mixer"
- "Masukan minyak,aduk balik dg spatula..jika sudah rata bagi mnjadi 6 masing2 beri pewarna yg berbeda"
- "Tuang ke dlm loyang(saya 18*18/loyang loaf 20*10/loyang bulat diameter 18cm) selapis demi selapis yang pertama utk warna ungu kukus selama 10 menit angkat/kluarkan dari loyang dinginkan lalu tuang yg warna biru kukus selama 10 menit angkat lakukan hal yg sama utk warna hijau,kuning,orange,&amp; merah) atau kl mau sistem timpa juga boleh jadi kukus lapisan pertama selama 10menit lalu tuang warna kedua tutup lg kukus 10mnt bgtu seterusnya sampai adonan habis utk warna terakhir kukus 20mnt."
- "Susun selapis demi selapis olesi tiap lapisannya dg butter cream (saya di mulai dr warna ungu-biru-hijau-kuning-orange terakhir/paling atas warna merah)"
- "Hias sesuai selera 😊"
- "Cara membuat buttercream: kocok mentega putih sampai lembut masukan coklat putih leleh lalu carnatiaon mixer sampai lembut😉"
categories:
- Recipe
tags:
- rainbow
- cake
- kukus

katakunci: rainbow cake kukus 
nutrition: 208 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT46M"
recipeyield: "4"
recipecategory: Dessert

---


![Rainbow cake kukus ala Ny.liem](https://img-global.cpcdn.com/recipes/3db2f39ffc4162ad/751x532cq70/rainbow-cake-kukus-ala-nyliem-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang patut kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti rainbow cake kukus ala ny.liem yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan ciri khas yang merupakan keragaman Indonesia



Kedekatan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah membuat makanan Rainbow cake kukus ala Ny.liem untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang bisa anda coba salah satunya rainbow cake kukus ala ny.liem yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep rainbow cake kukus ala ny.liem tanpa harus bersusah payah.
Seperti resep Rainbow cake kukus ala Ny.liem yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 15 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Rainbow cake kukus ala Ny.liem:

1. Harus ada 4 butir telur ayam utuh
1. Tambah 120 gr gula pasir (resep asli 190gr tapi menurut saya manis bgt)
1. Siapkan 1 sdm emulsifier (SP)
1. Dibutuhkan 150 gr terigu
1. Tambah 1 sachet susu bubuk (dancow)
1. Harus ada secukupnya Essens vanila
1. Dibutuhkan 1 sachet susu kental manis putih
1. Harus ada 1 bks santan kental (me: kara)
1. Jangan lupa 150 ml minyak sayur
1. Dibutuhkan Sejumput garam
1. Harus ada 6 macam warna (pewarna makanan, me: cap kupu2 warna ungu, biru, hijau, kuning, orange, merah)
1. Dibutuhkan  Resep butter cream ala (makfrida):
1. Harus ada 250 gr mentega putih
1. Siapkan 125 gr white cooking chocolate,melted
1. Jangan lupa 1/2 kaleng carnation




<!--inarticleads2-->

##### Cara membuat  Rainbow cake kukus ala Ny.liem:

1. Panaskan kukusan dg api kecil
1. Mixer telur,gula,garam dan essens vanila sampai gula hancur/larut..lalu masukan SP kocok dg speed tinggi sampai mengembang,kental berjejak
1. Turunkan speed(rendah) masukan terigu &amp;susu bubuk aduk sebentar masukan SKM dan santan mixer sebentar saja asal rata..matikan mixer
1. Masukan minyak,aduk balik dg spatula..jika sudah rata bagi mnjadi 6 masing2 beri pewarna yg berbeda
1. Tuang ke dlm loyang(saya 18*18/loyang loaf 20*10/loyang bulat diameter 18cm) selapis demi selapis yang pertama utk warna ungu kukus selama 10 menit angkat/kluarkan dari loyang dinginkan lalu tuang yg warna biru kukus selama 10 menit angkat lakukan hal yg sama utk warna hijau,kuning,orange,&amp; merah) atau kl mau sistem timpa juga boleh jadi kukus lapisan pertama selama 10menit lalu tuang warna kedua tutup lg kukus 10mnt bgtu seterusnya sampai adonan habis utk warna terakhir kukus 20mnt.
1. Susun selapis demi selapis olesi tiap lapisannya dg butter cream (saya di mulai dr warna ungu-biru-hijau-kuning-orange terakhir/paling atas warna merah)
1. Hias sesuai selera 😊
1. Cara membuat buttercream: kocok mentega putih sampai lembut masukan coklat putih leleh lalu carnatiaon mixer sampai lembut😉




Demikianlah cara membuat rainbow cake kukus ala ny.liem yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan teruji, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
