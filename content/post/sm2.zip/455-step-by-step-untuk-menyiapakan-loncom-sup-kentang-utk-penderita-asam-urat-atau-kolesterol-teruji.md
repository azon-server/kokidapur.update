---
description: "Step-by-Step untuk menyiapakan Loncom / Sup Kentang (utk penderita asam urat atau kolesterol) Teruji"
title: "Step-by-Step untuk menyiapakan Loncom / Sup Kentang (utk penderita asam urat atau kolesterol) Teruji"
slug: 455-step-by-step-untuk-menyiapakan-loncom-sup-kentang-utk-penderita-asam-urat-atau-kolesterol-teruji
date: 2021-02-02T01:02:01.617Z
image: https://img-global.cpcdn.com/recipes/0bde24832772402d/751x532cq70/loncom-sup-kentang-utk-penderita-asam-urat-atau-kolesterol-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0bde24832772402d/751x532cq70/loncom-sup-kentang-utk-penderita-asam-urat-atau-kolesterol-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0bde24832772402d/751x532cq70/loncom-sup-kentang-utk-penderita-asam-urat-atau-kolesterol-foto-resep-utama.jpg
author: Leon Sharp
ratingvalue: 4.4
reviewcount: 38133
recipeingredient:
- "3 buah Kentang Ukuran sedang 300 gram"
- "1 umbi wortel ukuran kecil"
- "1 batang daun bawangloncang"
- "2 siung bawang merah"
- "1 siung bawang putih"
- "1 lbr daun jeruk hilangkan tulangnya"
- "1 ruas jahe kupas"
- "1/2 sdt merica bubuk bisa diganti cabe bila seleranya pedas"
- "2 sdm gula pasir"
- "1 sdt garam"
- "secukupnya air"
- "1 sdm minyak utk menumis saja"
recipeinstructions:
- "Kupas kentang, wortel, bawang merah, bawang putih, serta bersihkan batang daun bawang"
- "Cuci semua bahan yg telah dikupas tadi, kemudian dipotong-potong menurut selera---untuk bawang putih dan jahe sy geprek saja"
- "Panaskan minyak dlm wajan, tumis bawang merah, tunggu hingga agak mengering"
- "Lalu masukkan bawang putih yg sdh di geprek (dimemarkan)"
- "Masukkan potongan wortel &amp; daun bawang, tumis, setelah layu masukkan kentang--tumis sebentar"
- "Tuangkan air sampai kentang terendam"
- "Masukkan merica, garam, gula, jahe, daun jeruk, tunggu mendidih"
- "Lakukan tes rasa, tambahkan gula/garam bila perlu--tergantung selera masing2"
- "Didihkan sampai kentang matang"
- "Angkat &amp; sajikan"
- "Bila anda takut menggunakan minyak goreng biasa, ganti dengan minyak jagung cuma mahal 6x lipat harganya----pastikan anda mengurangi makanan yg digoreng (deep frying /terendam minyak)"
categories:
- Recipe
tags:
- loncom
- 
- sup

katakunci: loncom  sup 
nutrition: 174 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Dinner

---


![Loncom / Sup Kentang (utk penderita asam urat atau kolesterol)](https://img-global.cpcdn.com/recipes/0bde24832772402d/751x532cq70/loncom-sup-kentang-utk-penderita-asam-urat-atau-kolesterol-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti loncom / sup kentang (utk penderita asam urat atau kolesterol) yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Kita



Kehangatan keluarga dapat didapat dengan cara sederhana. Diantaranya adalah membuat makanan Loncom / Sup Kentang (utk penderita asam urat atau kolesterol) untuk keluarga. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang dapat anda contoh salah satunya loncom / sup kentang (utk penderita asam urat atau kolesterol) yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep loncom / sup kentang (utk penderita asam urat atau kolesterol) tanpa harus bersusah payah.
Berikut ini resep Loncom / Sup Kentang (utk penderita asam urat atau kolesterol) yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 11 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Loncom / Sup Kentang (utk penderita asam urat atau kolesterol):

1. Diperlukan 3 buah Kentang Ukuran sedang (300 gram)
1. Jangan lupa 1 umbi wortel ukuran kecil
1. Harap siapkan 1 batang daun bawang/loncang
1. Dibutuhkan 2 siung bawang merah
1. Siapkan 1 siung bawang putih
1. Siapkan 1 lbr daun jeruk (hilangkan tulangnya)
1. Diperlukan 1 ruas jahe, kupas
1. Dibutuhkan 1/2 sdt merica bubuk (bisa diganti cabe bila seleranya pedas)
1. Harus ada 2 sdm gula pasir
1. Siapkan 1 sdt garam
1. Tambah secukupnya air
1. Harus ada 1 sdm minyak utk menumis saja




<!--inarticleads2-->

##### Cara membuat  Loncom / Sup Kentang (utk penderita asam urat atau kolesterol):

1. Kupas kentang, wortel, bawang merah, bawang putih, serta bersihkan batang daun bawang
1. Cuci semua bahan yg telah dikupas tadi, kemudian dipotong-potong menurut selera---untuk bawang putih dan jahe sy geprek saja
1. Panaskan minyak dlm wajan, tumis bawang merah, tunggu hingga agak mengering
1. Lalu masukkan bawang putih yg sdh di geprek (dimemarkan)
1. Masukkan potongan wortel &amp; daun bawang, tumis, setelah layu masukkan kentang--tumis sebentar
1. Tuangkan air sampai kentang terendam
1. Masukkan merica, garam, gula, jahe, daun jeruk, tunggu mendidih
1. Lakukan tes rasa, tambahkan gula/garam bila perlu--tergantung selera masing2
1. Didihkan sampai kentang matang
1. Angkat &amp; sajikan
1. Bila anda takut menggunakan minyak goreng biasa, ganti dengan minyak jagung cuma mahal 6x lipat harganya----pastikan anda mengurangi makanan yg digoreng (deep frying /terendam minyak)




Demikianlah cara membuat loncom / sup kentang (utk penderita asam urat atau kolesterol) yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan teruji, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
