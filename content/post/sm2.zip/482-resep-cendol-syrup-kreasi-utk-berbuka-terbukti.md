---
description: "Resep : Cendol syrup kreasi utk berbuka Terbukti"
title: "Resep : Cendol syrup kreasi utk berbuka Terbukti"
slug: 482-resep-cendol-syrup-kreasi-utk-berbuka-terbukti
date: 2020-12-21T11:34:14.932Z
image: https://img-global.cpcdn.com/recipes/2010294_99fc331c1746d569/751x532cq70/cendol-syrup-kreasi-utk-berbuka-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2010294_99fc331c1746d569/751x532cq70/cendol-syrup-kreasi-utk-berbuka-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2010294_99fc331c1746d569/751x532cq70/cendol-syrup-kreasi-utk-berbuka-foto-resep-utama.jpg
author: Kenneth Houston
ratingvalue: 4.5
reviewcount: 26453
recipeingredient:
- "75 gram tepung hunkwe"
- "25 gram tepung beras"
- "50 ml air daun pandan"
- "700 ml air"
- "1/2 sdt garam"
- "3 tetes pewarna hijau"
- " kuah santan "
- "200 ml santan instan"
- "1/2 sdt garam"
- "2 lbr daun pandan"
- " syrup limonade pengganti kuah gula"
recipeinstructions:
- "Untuk cendol : larutkan tepung hunkwe, tepung beras, air dan garam aduk rata. Lalu tambahkan air daun pandan dan pewarna hijau aduk.  Masak dgn api sedang sambil diaduk terus hingga meletup lalu matikan api. Tuang ke cetakan cendol, tekan2 di atas baskom yg berisi air es."
- "Kuah santan : rebus santan, garam dan daun pandan sambil diaduk hingga mendidih. Untuk kuah gulanya saya ganti memakai syrup kurnia limonade sirop ( gak gitu suka gula merah)"
- "Sajikan cendol bersama sirup dan kuah santan dan es batu.."
categories:
- Recipe
tags:
- cendol
- syrup
- kreasi

katakunci: cendol syrup kreasi 
nutrition: 205 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT58M"
recipeyield: "1"
recipecategory: Dessert

---


![Cendol syrup kreasi utk berbuka](https://img-global.cpcdn.com/recipes/2010294_99fc331c1746d569/751x532cq70/cendol-syrup-kreasi-utk-berbuka-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang patut kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti cendol syrup kreasi utk berbuka yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan ciri khas yang merupakan keragaman Nusantara



Kehangatan rumah tangga dapat diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Cendol syrup kreasi utk berbuka untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang dapat anda coba salah satunya cendol syrup kreasi utk berbuka yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep cendol syrup kreasi utk berbuka tanpa harus bersusah payah.
Berikut ini resep Cendol syrup kreasi utk berbuka yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 11 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Cendol syrup kreasi utk berbuka:

1. Diperlukan 75 gram tepung hunkwe
1. Diperlukan 25 gram tepung beras
1. Harus ada 50 ml air daun pandan
1. Diperlukan 700 ml air
1. Tambah 1/2 sdt garam
1. Harus ada 3 tetes pewarna hijau
1. Harap siapkan  kuah santan :
1. Tambah 200 ml santan instan
1. Harap siapkan 1/2 sdt garam
1. Tambah 2 lbr daun pandan
1. Jangan lupa  syrup limonade pengganti kuah gula




<!--inarticleads2-->

##### Bagaimana membuat  Cendol syrup kreasi utk berbuka:

1. Untuk cendol : larutkan tepung hunkwe, tepung beras, air dan garam aduk rata. Lalu tambahkan air daun pandan dan pewarna hijau aduk.  - Masak dgn api sedang sambil diaduk terus hingga meletup lalu matikan api. - Tuang ke cetakan cendol, tekan2 di atas baskom yg berisi air es.
1. Kuah santan : rebus santan, garam dan daun pandan sambil diaduk hingga mendidih. Untuk kuah gulanya saya ganti memakai syrup kurnia limonade sirop ( gak gitu suka gula merah)
1. Sajikan cendol bersama sirup dan kuah santan dan es batu..




Demikianlah cara membuat cendol syrup kreasi utk berbuka yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
