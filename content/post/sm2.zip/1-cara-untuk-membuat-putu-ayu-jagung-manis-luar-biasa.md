---
description: "Cara untuk membuat Putu Ayu Jagung Manis Luar biasa"
title: "Cara untuk membuat Putu Ayu Jagung Manis Luar biasa"
slug: 1-cara-untuk-membuat-putu-ayu-jagung-manis-luar-biasa
date: 2021-01-24T02:48:26.230Z
image: https://img-global.cpcdn.com/recipes/45b4ac46dd8d45cc/751x532cq70/putu-ayu-jagung-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/45b4ac46dd8d45cc/751x532cq70/putu-ayu-jagung-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/45b4ac46dd8d45cc/751x532cq70/putu-ayu-jagung-manis-foto-resep-utama.jpg
author: Zachary Lopez
ratingvalue: 5
reviewcount: 21332
recipeingredient:
- "1 buah jagung manis berat sudah dipipil 120 gr kukus 10 menit"
- "50 ml santan instan"
- "2 butir telur"
- "130 gr gula pasir di resep asli 150 gr gula pasir"
- "1/2 sdt sp"
- "150 gram tepung terigu protein sedang ayak"
- "1/4 sdt vanili bubuk"
- "1/4 sdt garam"
- "4-5 tetes pewarna makanan kuning optional"
- " Topping aduk jadi 1 dan kukus 10 menit "
- "100 gr kelapa muda parut"
- "1/4 sdt garam"
recipeinstructions:
- "Blender jagung dengan santan sampai menjadi bubur jagung. Sisihkan."
- "Mixer dengan kecepatan tinggi telur, gula pasir dan sp sampai mengembang kental berjejak."
- "Masukkan tepung terigu yg sudah di ayak, garam dan vanili bubuk. Mixer asal rata dengan kecepatan rendah."
- "Masukkan bubur jagung dan pewarna makanan kuning, mixer asal rata. Ratakan adonan dengan spatula."
- "Panaskan kukusan dan lapisi tutup kukusan dengan serbet bersih. Olesi cetakan putu ayu dengan minyak lalu masukkan kelapa dan tekan-tekan agar padat lalu timpa adonan memenuhi cetakan. Kukus selama 15-20 menit hingga matang."
- "Angkat. Keluarkan dari cetakan. Siap disajikan."
categories:
- Recipe
tags:
- putu
- ayu
- jagung

katakunci: putu ayu jagung 
nutrition: 111 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dessert

---


![Putu Ayu Jagung Manis](https://img-global.cpcdn.com/recipes/45b4ac46dd8d45cc/751x532cq70/putu-ayu-jagung-manis-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga gurih. Karasteristik masakan Indonesia putu ayu jagung manis yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga dapat ditemukan dengan cara mudah. Salah satunya adalah memasak Putu Ayu Jagung Manis untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.

Assalamu&#39;alaikum Everyone🤗,Siapa nih yang suka dengan kue putu ayu,karena kali ini aku mau berbagi resep cara membuat Kue Putu Ayu,Rasanya Manis dan Gurih. Teksturnya yang lembut serta perpaduan cita rasanya yang manis, dijamin bikin. Bolu Gulung Ekonomis Isi Selai Nanas Cake Roll Cake Gulung. Kue putu ayu atau terkadang juga sering disebut sebagai kue putri ayu adalah penganan yang terbuat dari tepung yang dikukus bersama dengan kelapa parut.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang bisa anda praktekkan salah satunya putu ayu jagung manis yang merupakan resep favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep putu ayu jagung manis tanpa harus bersusah payah.
Seperti resep Putu Ayu Jagung Manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 12 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Putu Ayu Jagung Manis:

1. Dibutuhkan 1 buah jagung manis (berat sudah dipipil 120 gr), kukus 10 menit
1. Harus ada 50 ml santan instan
1. Harus ada 2 butir telur
1. Dibutuhkan 130 gr gula pasir (di resep asli 150 gr gula pasir)
1. Jangan lupa 1/2 sdt sp
1. Harap siapkan 150 gram tepung terigu protein sedang, ayak
1. Harap siapkan 1/4 sdt vanili bubuk
1. Harus ada 1/4 sdt garam
1. Tambah 4-5 tetes pewarna makanan kuning (optional)
1. Harap siapkan  Topping (aduk jadi 1 dan kukus 10 menit) :
1. Siapkan 100 gr kelapa muda parut
1. Harus ada 1/4 sdt garam


Meski begitu, rasa gurih dan manisnya selalu ditunggu pada berbagai acara. Terlebih bentuknya yang manis dan berwarna lembut membuat siapa pun tak segan memungutnya untuk dicicipi bersama teh manis di. Kue putu ayu merupakan salah satu kue tradisional yang berasal dari Indonesia, tepatnya di dareh Jawa. Kue yang satu ini memiliki bentuk yang unik dan menarik, warnanya hijau dengan lapisan kelapa di atasnya. 

<!--inarticleads2-->

##### Cara membuat  Putu Ayu Jagung Manis:

1. Blender jagung dengan santan sampai menjadi bubur jagung. Sisihkan.
1. Mixer dengan kecepatan tinggi telur, gula pasir dan sp sampai mengembang kental berjejak.
1. Masukkan tepung terigu yg sudah di ayak, garam dan vanili bubuk. Mixer asal rata dengan kecepatan rendah.
1. Masukkan bubur jagung dan pewarna makanan kuning, mixer asal rata. Ratakan adonan dengan spatula.
1. Panaskan kukusan dan lapisi tutup kukusan dengan serbet bersih. Olesi cetakan putu ayu dengan minyak lalu masukkan kelapa dan tekan-tekan agar padat lalu timpa adonan memenuhi cetakan. Kukus selama 15-20 menit hingga matang.
1. Angkat. Keluarkan dari cetakan. Siap disajikan.


Kue putu ayu merupakan salah satu kue tradisional yang berasal dari Indonesia, tepatnya di dareh Jawa. Kue yang satu ini memiliki bentuk yang unik dan menarik, warnanya hijau dengan lapisan kelapa di atasnya. Kue ini memiliki cita rasa yang begitu enak dan manis, teksturnya yang empuk sangat. Kue putu mangkok, kueh tutu, kue putu ayu, or putu piring is a round-shaped, traditional Indonesian steamed rice flour kue or sweet snack filled with palm sugar, and commonly found in Indonesia, Singapore, Malaysia, and Southern Thailand. Cara membuat kue putu ayu ini sebenarnya cukup mudah dan bahan bahan yang digunakan juga tidak aneh aneh dan sangat mudah dibeli dan harganya cukup murah, sehingga tidak ada salahnya jika bunda dan sis sekalian mencoba untuk membuatnya, lumayan untuk menambah kepiawaian bunda. 

Demikianlah cara membuat putu ayu jagung manis yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat mudah dan teruji, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
