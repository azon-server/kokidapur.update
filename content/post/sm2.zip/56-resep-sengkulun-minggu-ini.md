---
description: "Resep : Sengkulun minggu ini"
title: "Resep : Sengkulun minggu ini"
slug: 56-resep-sengkulun-minggu-ini
date: 2021-01-07T23:59:03.106Z
image: https://img-global.cpcdn.com/recipes/709ffd4e6b3b7ab0/751x532cq70/sengkulun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/709ffd4e6b3b7ab0/751x532cq70/sengkulun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/709ffd4e6b3b7ab0/751x532cq70/sengkulun-foto-resep-utama.jpg
author: Lucy Patterson
ratingvalue: 4.5
reviewcount: 11091
recipeingredient:
- " Kelapa parut 12 buah 12 tua"
- "300 gr Tepung tapioka"
- "200 gr Gula Pasir"
- "1/2 sdm Vanili"
- "1 sdt Garam"
- " Pewarna makanan saya pakai warna hijau dan merah"
recipeinstructions:
- "Campur semua bahan dan aduk-aduk sampai tercampur rata"
- "Adonan 1 saya beri warna hijau, Adonan 2 saya beri warna merah, Adonan 3 saya biarkan warna putih"
- "Bagi adonan menjadi 3"
- "Masukkan adonan ke cetakan dan kukus selama kurang lebih 45 menit"
categories:
- Recipe
tags:
- sengkulun

katakunci: sengkulun 
nutrition: 254 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT52M"
recipeyield: "1"
recipecategory: Dinner

---


![Sengkulun](https://img-global.cpcdn.com/recipes/709ffd4e6b3b7ab0/751x532cq70/sengkulun-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau empuk. Ciri makanan Nusantara sengkulun yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan keluarga dapat didapat dengan cara sederhana. Diantaranya adalah membuat makanan Sengkulun untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang bisa anda coba salah satunya sengkulun yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep sengkulun tanpa harus bersusah payah.
Seperti resep Sengkulun yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sengkulun:

1. Siapkan  Kelapa parut 1-2 buah (1/2 tua)
1. Diperlukan 300 gr Tepung tapioka
1. Harap siapkan 200 gr Gula Pasir
1. Tambah 1/2 sdm Vanili
1. Harus ada 1 sdt Garam
1. Dibutuhkan  Pewarna makanan (saya pakai warna hijau dan merah)




<!--inarticleads2-->

##### Bagaimana membuat  Sengkulun:

1. Campur semua bahan dan aduk-aduk sampai tercampur rata
1. Adonan 1 saya beri warna hijau, Adonan 2 saya beri warna merah, Adonan 3 saya biarkan warna putih
1. Bagi adonan menjadi 3
1. Masukkan adonan ke cetakan dan kukus selama kurang lebih 45 menit




Demikianlah cara membuat sengkulun yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan terbukti, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
