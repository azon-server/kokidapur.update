---
description: "Bagaimana membuat Babi Rica Terbukti"
title: "Bagaimana membuat Babi Rica Terbukti"
slug: 271-bagaimana-membuat-babi-rica-terbukti
date: 2020-12-11T03:28:20.513Z
image: https://img-global.cpcdn.com/recipes/83f0b3e736d70da5/751x532cq70/babi-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/83f0b3e736d70da5/751x532cq70/babi-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/83f0b3e736d70da5/751x532cq70/babi-rica-foto-resep-utama.jpg
author: Lucy Potter
ratingvalue: 4.2
reviewcount: 29433
recipeingredient:
- "1 kg daging babi"
- "4 btg serehgeprek"
- "1 ruas lengkuas 45cmgeprek"
- "2 lbr daun kunyit"
- "1 batang daun bawangdipotong2 2cm"
- "1 ruas jahegeprek"
- "2 lbr daun pandan"
- "7 lbr daun jeruk"
- " Air kira2 sj"
- " Bahan halus"
- "6 siung bawang putih"
- "6 siung bawang merah"
- "20 bh cabe rawitboleh tambah klo suka pedes"
- "8 btr kemiri"
- "1 sdt ketumbar"
- "1 sdt lada"
- "1 ruas kunyit"
- " Garam dan penyedap secukup nya"
recipeinstructions:
- "Ini lah bumbu2 nya.saya pake cabe keriting dan hijau ya.soalnya biar anak2 bisa makan jg."
- "Tumis bumbu halus hingga wangi dan masukan daun pandan,jahe,sereh,lengkuas,daun kunyit,dan daun jeruk.daun bawang ntar terakhir ya"
- "Masukan daging nya.dan masukan air hingga penuh.tunggu hingga daging nya lunak dan air nya kering"
- "Babi rica siap di hidangkan.sy ksh kuah biar anak2 makannya ada kuah2 dikit"
categories:
- Recipe
tags:
- babi
- rica

katakunci: babi rica 
nutrition: 136 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dessert

---


![Babi Rica](https://img-global.cpcdn.com/recipes/83f0b3e736d70da5/751x532cq70/babi-rica-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga empuk. Ciri khas makanan Nusantara babi rica yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Babi Rica untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang dapat anda buat salah satunya babi rica yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep babi rica tanpa harus bersusah payah.
Berikut ini resep Babi Rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Babi Rica:

1. Tambah 1 kg daging babi
1. Harus ada 4 btg sereh(geprek)
1. Siapkan 1 ruas lengkuas 4-5cm(geprek)
1. Siapkan 2 lbr daun kunyit
1. Diperlukan 1 batang daun bawang(dipotong2 2cm)
1. Harap siapkan 1 ruas jahe(geprek)
1. Dibutuhkan 2 lbr daun pandan
1. Diperlukan 7 lbr daun jeruk
1. Diperlukan  Air kira2 sj
1. Dibutuhkan  Bahan halus
1. Jangan lupa 6 siung bawang putih
1. Diperlukan 6 siung bawang merah
1. Dibutuhkan 20 bh cabe rawit,boleh tambah klo suka pedes
1. Harap siapkan 8 btr kemiri
1. Tambah 1 sdt ketumbar
1. Diperlukan 1 sdt lada
1. Diperlukan 1 ruas kunyit
1. Tambah  Garam dan penyedap secukup nya




<!--inarticleads2-->

##### Bagaimana membuat  Babi Rica:

1. Ini lah bumbu2 nya.saya pake cabe keriting dan hijau ya.soalnya biar anak2 bisa makan jg.
1. Tumis bumbu halus hingga wangi dan masukan daun pandan,jahe,sereh,lengkuas,daun kunyit,dan daun jeruk.daun bawang ntar terakhir ya
1. Masukan daging nya.dan masukan air hingga penuh.tunggu hingga daging nya lunak dan air nya kering
1. Babi rica siap di hidangkan.sy ksh kuah biar anak2 makannya ada kuah2 dikit




Demikianlah cara membuat babi rica yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan cepat, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
