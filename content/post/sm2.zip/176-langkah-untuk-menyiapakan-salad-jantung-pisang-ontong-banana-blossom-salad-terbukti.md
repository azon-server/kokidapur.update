---
description: "Langkah untuk menyiapakan Salad Jantung Pisang (Ontong)/ Banana Blossom Salad Terbukti"
title: "Langkah untuk menyiapakan Salad Jantung Pisang (Ontong)/ Banana Blossom Salad Terbukti"
slug: 176-langkah-untuk-menyiapakan-salad-jantung-pisang-ontong-banana-blossom-salad-terbukti
date: 2020-12-06T04:00:25.171Z
image: https://img-global.cpcdn.com/recipes/9abb18a4f3fbabec/751x532cq70/salad-jantung-pisang-ontong-banana-blossom-salad-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9abb18a4f3fbabec/751x532cq70/salad-jantung-pisang-ontong-banana-blossom-salad-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9abb18a4f3fbabec/751x532cq70/salad-jantung-pisang-ontong-banana-blossom-salad-foto-resep-utama.jpg
author: Amy Reynolds
ratingvalue: 4.7
reviewcount: 10777
recipeingredient:
- "1 buah300gr jantung pisang"
- "250 gr daging sapi iris tipis beram dgn garam dan lada hitam"
- "1/4 buah pepaya muda"
- "1 buah wortel"
- "1/2 buah bawang bombay"
- "10 lembar Vietnamese mint ato daun selasih boleh d skip"
- "500 ml air dingin dgn 1sendok air jeruk nipis"
- "1 sdm blue band"
- "3 sendok kacang goreng yg d hancurkan"
- "2 sendok bawang goreng utk taburan"
- "  Bahan Saus"
- "1 sdm air"
- "1 sdm madu"
- "1 sdm kecap asin"
- "1 sdm air jeruk nipis"
- "1/2 sdm bawang putih cincang"
- "1/2 bawang berah cincang"
- "1 biji cabe rawit iris"
recipeinstructions:
- "Buka lembaran demi lembaran ontong cuci bersih, gulung dan iris tipis. Lakukan sampai habis kemudian rendam di campuran air dingin dan air jeruk nipis, kurang lebih 25 menit kmudian tiriskan."
- "Potong pepaya, wortel dan bawang bombay spt korek api, bawang bombay nya lebih d tipisin potongnya dan boleh d kurangi klo ga suka rasa yg kuat dr bawang bombay."
- "Panaskan wajan, kasih 1 sdm blue ban, masukkan daging sapi yg telah d beram dan masak kurang lebih 3-5 menit, jgn smpai over cook, krn daging akan keras."
- "Siapkan wadah yg besar, masukkan bahan saus, aduk2 sampai rata terus tambahkan ontong, pepaya, wortel,bombay, daun selasih dan 1 sdm kacang cincang dan daging sapi (jus nya jgn d buang, campurkan), gaul rata."
- "Siapkan piring, atur Salad di piring taburi dengan sisa kacang cincang dan bawang goreng dan Salad yg gampang dan renyah ini siiiiaaapppp menjamu keluarga🤗🤗🤗"
categories:
- Recipe
tags:
- salad
- jantung
- pisang

katakunci: salad jantung pisang 
nutrition: 161 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dinner

---


![Salad Jantung Pisang (Ontong)/ Banana Blossom Salad](https://img-global.cpcdn.com/recipes/9abb18a4f3fbabec/751x532cq70/salad-jantung-pisang-ontong-banana-blossom-salad-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga enak. Karasteristik kuliner Indonesia salad jantung pisang (ontong)/ banana blossom salad yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Kami masak dan menikmati makan siang dihalaman belakang rumah. Menu kali ini ada sambal Jantung Pisang dan ikan bakar yang tradisional. Hari ini cbok berkongsi resipi yg diajar oleh arwah emak cbok. Bagi yg tidak boleh makan belacan, boleh.

Kedekatan keluarga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Salad Jantung Pisang (Ontong)/ Banana Blossom Salad untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang dapat anda coba salah satunya salad jantung pisang (ontong)/ banana blossom salad yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep salad jantung pisang (ontong)/ banana blossom salad tanpa harus bersusah payah.
Berikut ini resep Salad Jantung Pisang (Ontong)/ Banana Blossom Salad yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Salad Jantung Pisang (Ontong)/ Banana Blossom Salad:

1. Diperlukan 1 buah(300gr) jantung pisang
1. Diperlukan 250 gr daging sapi, iris tipis (beram dgn garam dan lada hitam)
1. Jangan lupa 1/4 buah pepaya muda
1. Harap siapkan 1 buah wortel
1. Tambah 1/2 buah bawang bombay
1. Harap siapkan 10 lembar Vietnamese mint ato daun selasih (boleh d skip)
1. Siapkan 500 ml air dingin dgn 1sendok air jeruk nipis
1. Siapkan 1 sdm blue band
1. Siapkan 3 sendok kacang goreng yg d hancurkan
1. Diperlukan 2 sendok bawang goreng, utk taburan
1. Harap siapkan  # Bahan Saus
1. Diperlukan 1 sdm air
1. Harus ada 1 sdm madu
1. Tambah 1 sdm kecap asin
1. Diperlukan 1 sdm air jeruk nipis
1. Siapkan 1/2 sdm bawang putih cincang
1. Dibutuhkan 1/2 bawang berah, cincang
1. Harap siapkan 1 biji cabe rawit, iris


Jantung pisang atau ontong dalam bahasa Jawa bisa diolah menjadi berbagai macam makanan. Tak cuma pepes, lodeh, dan tumis. Trova immagini stock HD a tema Jantung Pisang Called Banana Blossom Still e milioni di altre foto, illustrazioni e contenuti vettoriali stock royalty free nella vasta raccolta di Shutterstock. Jantung pisang or called as banana blossom is still fresh and hanged on the tree. 

<!--inarticleads2-->

##### Bagaimana membuat  Salad Jantung Pisang (Ontong)/ Banana Blossom Salad:

1. Buka lembaran demi lembaran ontong cuci bersih, gulung dan iris tipis. Lakukan sampai habis kemudian rendam di campuran air dingin dan air jeruk nipis, kurang lebih 25 menit kmudian tiriskan.
1. Potong pepaya, wortel dan bawang bombay spt korek api, bawang bombay nya lebih d tipisin potongnya dan boleh d kurangi klo ga suka rasa yg kuat dr bawang bombay.
1. Panaskan wajan, kasih 1 sdm blue ban, masukkan daging sapi yg telah d beram dan masak kurang lebih 3-5 menit, jgn smpai over cook, krn daging akan keras.
1. Siapkan wadah yg besar, masukkan bahan saus, aduk2 sampai rata terus tambahkan ontong, pepaya, wortel,bombay, daun selasih dan 1 sdm kacang cincang dan daging sapi (jus nya jgn d buang, campurkan), gaul rata.
1. Siapkan piring, atur Salad di piring taburi dengan sisa kacang cincang dan bawang goreng dan Salad yg gampang dan renyah ini siiiiaaapppp menjamu keluarga🤗🤗🤗


Trova immagini stock HD a tema Jantung Pisang Called Banana Blossom Still e milioni di altre foto, illustrazioni e contenuti vettoriali stock royalty free nella vasta raccolta di Shutterstock. Jantung pisang or called as banana blossom is still fresh and hanged on the tree. Chè Chuối - Banana in Coconut Milk with Tapioca Pearls Pudding. PagesOtherBrandKitchen/CookingHuongBui CookingVideosBanana blossom salad - Nộm hoa chuối. A banana blossom salad made with red cabbage, white onions and red bell peppers, topped with minced mint, Vietnamese coriander, roasted peanuts and the same generous pour of fish sauce dressing. 

Demikianlah cara membuat salad jantung pisang (ontong)/ banana blossom salad yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan teruji, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
