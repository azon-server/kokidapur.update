---
description: "Langkah menyiapakan Babi Rica rica kemangi Homemade"
title: "Langkah menyiapakan Babi Rica rica kemangi Homemade"
slug: 342-langkah-menyiapakan-babi-rica-rica-kemangi-homemade
date: 2020-11-07T16:09:47.604Z
image: https://img-global.cpcdn.com/recipes/f2a238f8994e84f2/751x532cq70/babi-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f2a238f8994e84f2/751x532cq70/babi-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f2a238f8994e84f2/751x532cq70/babi-rica-rica-kemangi-foto-resep-utama.jpg
author: Ronnie Murphy
ratingvalue: 5
reviewcount: 31557
recipeingredient:
- "2 kg daging babi bisa diganti sesuai selera"
- "3 ruas lengkuas digeprek"
- "3 btg sereh di geprek"
- " Daun jeruk sesuai selerabanyak lebih baik geprek"
- "2 buah tomat dipotong weges"
- "4 ikat Kemangi sesuai selera banyak lebih baik"
- " Bumbu halus"
- "1/4 kg cabe merah"
- "2 ons cabe rawit"
- "15 siung bawang merah"
- "8 siung bawang putih"
- "3 ruas kunyit"
- "5 ruas jahe sebagian dihaluskan dan sebagian digeprek"
- "1 sdt Lada kasar"
- "5 sdm Minyak untuk mengoreng"
- "1 bks kecil Royco sapi"
- "3 sdt garam"
- "450 ml air"
recipeinstructions:
- "Tumis dahulu daun jeruk,lengkuas,sere jangan sampai kering/gosong. Lalu masukan bumbu yg sudah dihaluskan, tumis hingga aromanya sedap"
- "Masukan daging/tulang babi, masak hingga redius.dan"
- "Masukan garam dan royco serta tambahkan air 350 ml, aduk dan tutup rapat."
- "Setelah redius, cicipi rasa *(jika kurang asin tambah garam/royco). Tambahkan air 150ml dan masukan tomat."
- "Tunggu sampai air mendidih dan sampai tomat hancur, setelah itu cicipi kembali. Jika rasa telah sesuai selera, angkat dan masukan daun kemangi yg telah dicuci bersih."
categories:
- Recipe
tags:
- babi
- rica
- rica

katakunci: babi rica rica 
nutrition: 245 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT40M"
recipeyield: "3"
recipecategory: Dinner

---


![Babi Rica rica kemangi](https://img-global.cpcdn.com/recipes/f2a238f8994e84f2/751x532cq70/babi-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti babi rica rica kemangi yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan keistimewahan yang merupakan keragaman Kita



Kehangatan rumah tangga bisa ditemukan dengan cara simple. Salah satunya adalah membuat makanan Babi Rica rica kemangi untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang dapat anda coba salah satunya babi rica rica kemangi yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep babi rica rica kemangi tanpa harus bersusah payah.
Seperti resep Babi Rica rica kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Babi Rica rica kemangi:

1. Siapkan 2 kg daging babi (bisa diganti sesuai selera)
1. Tambah 3 ruas lengkuas digeprek
1. Siapkan 3 btg sereh di geprek
1. Dibutuhkan  Daun jeruk sesuai selera#banyak lebih baik (geprek)
1. Harus ada 2 buah tomat dipotong weges
1. Siapkan 4 ikat Kemangi sesuai selera #banyak lebih baik
1. Dibutuhkan  Bumbu halus
1. Jangan lupa 1/4 kg cabe merah
1. Diperlukan 2 ons cabe rawit
1. Jangan lupa 15 siung bawang merah
1. Tambah 8 siung bawang putih
1. Siapkan 3 ruas kunyit
1. Siapkan 5 ruas jahe (sebagian dihaluskan dan sebagian digeprek)
1. Tambah 1 sdt Lada kasar
1. Harus ada 5 sdm Minyak untuk mengoreng
1. Dibutuhkan 1 bks kecil Royco sapi
1. Diperlukan 3 sdt garam
1. Diperlukan 450 ml air




<!--inarticleads2-->

##### Instruksi membuat  Babi Rica rica kemangi:

1. Tumis dahulu daun jeruk,lengkuas,sere jangan sampai kering/gosong. Lalu masukan bumbu yg sudah dihaluskan, tumis hingga aromanya sedap
1. Masukan daging/tulang babi, masak hingga redius.dan
1. Masukan garam dan royco serta tambahkan air 350 ml, aduk dan tutup rapat.
1. Setelah redius, cicipi rasa *(jika kurang asin tambah garam/royco). Tambahkan air 150ml dan masukan tomat.
1. Tunggu sampai air mendidih dan sampai tomat hancur, setelah itu cicipi kembali. Jika rasa telah sesuai selera, angkat dan masukan daun kemangi yg telah dicuci bersih.




Demikianlah cara membuat babi rica rica kemangi yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
