---
description: "Langkah menyiapakan Rainbow Cake (Steamed) minggu ini"
title: "Langkah menyiapakan Rainbow Cake (Steamed) minggu ini"
slug: 22-langkah-menyiapakan-rainbow-cake-steamed-minggu-ini
date: 2020-12-23T03:47:35.039Z
image: https://img-global.cpcdn.com/recipes/6b8ab47b7cffb8d6/751x532cq70/rainbow-cake-steamed-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6b8ab47b7cffb8d6/751x532cq70/rainbow-cake-steamed-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6b8ab47b7cffb8d6/751x532cq70/rainbow-cake-steamed-foto-resep-utama.jpg
author: Susie Cooper
ratingvalue: 4.8
reviewcount: 17580
recipeingredient:
- "4 telur"
- "175 gr gula pasir diblender"
- "1/2 sdt garam"
- "1/2 sdt baking powder"
- "150 gr tepung terigu protein sedang"
- "2 sdm susu bubuk full cream"
- "40 gr kental manis"
- "65 ml santan"
- "150 ml minyak saya Barco kelapa"
- " Pewarna makanan merah jingga kuning biru ungu"
- " Hiasan"
- " Buttercream resep terpisah"
- " Chocolate Ganache resep terpisah"
- " Choco chips warna warni"
recipeinstructions:
- "Siapkan bahan2nya terlebih dahulu."
- "Siapkan loyang &amp; baking paper seukuran bagian dalam loyang (15x15). Olesi loyang dgn margarin, alasi dgn baking paper, dan olesi lagi dgn margarin hanya di bagian dasar. Tidak perlu mengolesi bagian sisi loyang."
- "Kocok telur, gula, dan garam sampai mengembang. Masukkan baking powder. Kocok lagi sampai soft peak."
- "Masukkan terigu &amp; susu sambil diayak secara bertahap. Kocok dgn kecepatan sedang selama 5 menit."
- "Masukkan kental manis &amp; santan, kocok sebentar dgn kecepatan rendah."
- "Masukkan minyak, aduk balik dgn spatula hingga tidak ada larutan minyak tersisa."
- "Timbang adonan, lalu bagi sama rata sesuai jumlah warna yg ada."
- "Beri pewarna &amp; aduk perlahan hingga rata. Saya pake Koepoe Koepoe sebanyak 5 tetes."
- "Kukus per warna, masing2 selama 7 menit. Angkat &amp; dinginkan"
- "Oles buttercream atau whip cream di tiap lapisan. Tutupi permukaan &amp; sisi2 kue dgn buttercream. Lalu hias dgn ganache &amp; taburi choco chips."
- "Simpan di kulkas selama 1 jam sampai hiasan set."
- "Potong2 &amp; sajikan."
categories:
- Recipe
tags:
- rainbow
- cake
- steamed

katakunci: rainbow cake steamed 
nutrition: 220 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Dinner

---


![Rainbow Cake (Steamed)](https://img-global.cpcdn.com/recipes/6b8ab47b7cffb8d6/751x532cq70/rainbow-cake-steamed-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita lestarikan karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti rainbow cake (steamed) yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Kita



Kehangatan rumah tangga bisa didapat dengan cara simple. Salah satunya adalah membuat makanan Rainbow Cake (Steamed) untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang bisa anda coba salah satunya rainbow cake (steamed) yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep rainbow cake (steamed) tanpa harus bersusah payah.
Seperti resep Rainbow Cake (Steamed) yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 12 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Rainbow Cake (Steamed):

1. Harap siapkan 4 telur
1. Diperlukan 175 gr gula pasir, di-blender
1. Diperlukan 1/2 sdt garam
1. Harus ada 1/2 sdt baking powder
1. Tambah 150 gr tepung terigu protein sedang
1. Siapkan 2 sdm susu bubuk full cream
1. Harus ada 40 gr kental manis
1. Siapkan 65 ml santan
1. Diperlukan 150 ml minyak (saya: Barco, kelapa)
1. Dibutuhkan  Pewarna makanan (merah, jingga, kuning, biru, ungu)
1. Dibutuhkan  Hiasan
1. Harap siapkan  Buttercream (resep terpisah)
1. Siapkan  Chocolate Ganache (resep terpisah)
1. Harap siapkan  Choco chips warna warni




<!--inarticleads2-->

##### Instruksi membuat  Rainbow Cake (Steamed):

1. Siapkan bahan2nya terlebih dahulu.
1. Siapkan loyang &amp; baking paper seukuran bagian dalam loyang (15x15). Olesi loyang dgn margarin, alasi dgn baking paper, dan olesi lagi dgn margarin hanya di bagian dasar. Tidak perlu mengolesi bagian sisi loyang.
1. Kocok telur, gula, dan garam sampai mengembang. Masukkan baking powder. Kocok lagi sampai soft peak.
1. Masukkan terigu &amp; susu sambil diayak secara bertahap. Kocok dgn kecepatan sedang selama 5 menit.
1. Masukkan kental manis &amp; santan, kocok sebentar dgn kecepatan rendah.
1. Masukkan minyak, aduk balik dgn spatula hingga tidak ada larutan minyak tersisa.
1. Timbang adonan, lalu bagi sama rata sesuai jumlah warna yg ada.
1. Beri pewarna &amp; aduk perlahan hingga rata. Saya pake Koepoe Koepoe sebanyak 5 tetes.
1. Kukus per warna, masing2 selama 7 menit. Angkat &amp; dinginkan
1. Oles buttercream atau whip cream di tiap lapisan. Tutupi permukaan &amp; sisi2 kue dgn buttercream. Lalu hias dgn ganache &amp; taburi choco chips.
1. Simpan di kulkas selama 1 jam sampai hiasan set.
1. Potong2 &amp; sajikan.




Demikianlah cara membuat rainbow cake (steamed) yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan terbukti, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
