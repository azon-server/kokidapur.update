---
description: "Resep : Babi rica Sempurna"
title: "Resep : Babi rica Sempurna"
slug: 326-resep-babi-rica-sempurna
date: 2020-11-24T14:49:04.518Z
image: https://img-global.cpcdn.com/recipes/8a02cbaab1655a04/751x532cq70/babi-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8a02cbaab1655a04/751x532cq70/babi-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8a02cbaab1655a04/751x532cq70/babi-rica-foto-resep-utama.jpg
author: Frank Frazier
ratingvalue: 4.9
reviewcount: 42184
recipeingredient:
- "500 gr daging babi ptg dadu"
- "1/2 bh jeruk nipis1 bh jeruk limau"
- "5 lmbr daun jeruk sobek"
- "5 bh cabe kecil utuh"
- "Secukupnya air"
- "1/2 sdm kecap manis"
- "2 bh tomat ptg kasar"
- "Secukupnya garam"
- " Gula"
- " Minyak goreng"
- " Bumbu halus "
- "10 siung bw merah"
- "4 siung bw putih"
- "5 bh cabe merah besar"
- "5 bh cabe kecil"
- "5 cm kunyit"
- "5 cm jahe"
- "2 btg sereh ambil putihnya"
recipeinstructions:
- "Tumis bumbu halus, daun jeruk dan tomat hingga matang agar tdk langu"
- "Masukkan dagingnya aduk rata dan beri air untuk mematangkan. Tutup wajan sambil sesekali diaduk. Bila air hampir menyusut, masukkan cabe utuh, bubuhi gula, garam dan beri kecap manis. Aduk rata"
- "Terakhir perasi dgn jeruk nipis/jeruk limau, aduk rata dan sajikan"
categories:
- Recipe
tags:
- babi
- rica

katakunci: babi rica 
nutrition: 153 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Dinner

---


![Babi rica](https://img-global.cpcdn.com/recipes/8a02cbaab1655a04/751x532cq70/babi-rica-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau renyah. Ciri khas masakan Nusantara babi rica yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah membuat makanan Babi rica untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang bisa anda praktekkan salah satunya babi rica yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep babi rica tanpa harus bersusah payah.
Berikut ini resep Babi rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Babi rica:

1. Tambah 500 gr daging babi, ptg dadu
1. Dibutuhkan 1/2 bh jeruk nipis/1 bh jeruk limau
1. Tambah 5 lmbr daun jeruk, sobek
1. Diperlukan 5 bh cabe kecil utuh
1. Harus ada Secukupnya air
1. Diperlukan 1/2 sdm kecap manis
1. Dibutuhkan 2 bh tomat, ptg kasar
1. Jangan lupa Secukupnya garam
1. Harus ada  Gula
1. Harap siapkan  Minyak goreng
1. Harus ada  Bumbu halus :
1. Tambah 10 siung bw merah
1. Dibutuhkan 4 siung bw putih
1. Siapkan 5 bh cabe merah besar
1. Tambah 5 bh cabe kecil
1. Harap siapkan 5 cm kunyit
1. Diperlukan 5 cm jahe
1. Jangan lupa 2 btg sereh, ambil putihnya




<!--inarticleads2-->

##### Instruksi membuat  Babi rica:

1. Tumis bumbu halus, daun jeruk dan tomat hingga matang agar tdk langu
1. Masukkan dagingnya aduk rata dan beri air untuk mematangkan. Tutup wajan sambil sesekali diaduk. Bila air hampir menyusut, masukkan cabe utuh, bubuhi gula, garam dan beri kecap manis. Aduk rata
1. Terakhir perasi dgn jeruk nipis/jeruk limau, aduk rata dan sajikan




Demikianlah cara membuat babi rica yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
