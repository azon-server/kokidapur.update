---
description: "Resep : Rainbow Cake (Kukus) Favorite"
title: "Resep : Rainbow Cake (Kukus) Favorite"
slug: 25-resep-rainbow-cake-kukus-favorite
date: 2020-12-06T16:13:59.888Z
image: https://img-global.cpcdn.com/recipes/1098ca7917a754a2/751x532cq70/rainbow-cake-kukus-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1098ca7917a754a2/751x532cq70/rainbow-cake-kukus-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1098ca7917a754a2/751x532cq70/rainbow-cake-kukus-foto-resep-utama.jpg
author: Sallie Allen
ratingvalue: 4.1
reviewcount: 39305
recipeingredient:
- " Bahan A "
- "4 btr telur ayam"
- "150 gr gula pasir"
- "1 sdt TBM"
- " Bahan B "
- "150 gr tepung terigu"
- "1 sdt baking powder"
- "2 sdm susu bubuk"
- "1/2 sdt vanili bubuk"
- "Sejumput garam"
- " Bahan C "
- "1 sachet kental manis putih"
- "1 bks santan instan kara uk65ml"
- "150 ml minyak sayur"
- " Pelengkap  pewarna makanan"
- " Topping "
- " Homemade Buttercream resep ada dibawah"
- " Meisis rainbow"
recipeinstructions:
- "Siapkan loyang ukuran 18cm, olesi mentega dan alasi dgn baking paper. Sisihkan"
- "Campur semua bahan B, ayak. Sisihkan. Diwadah terpisah campur juga bahan C aduk dan sisihkan."
- "Mixer bahan A sampai mengembang dan putih pucat."
- "Campur bahan B yg sudah diayak bergantian dgn campuran bahan C. Aduk balik sampai rata"
- "Bagi adonan menjadi 6 dan berikan masing2 3 tetes pewarna makanan."
- "Tuang 1 warna ke dalam loyang dan kukus sekitar 6 menit kedalam kukusan yg sebelumnya sudah dipanaskan. Lakukan sampai masing2 warna adonan habis. Biarkan dingin"
- "Ambil 1 warna dasar (me : ungu) olesi dengan Buttercream tumpuk lagi dgn warna selanjutnya. Ulangi sampai semua rainbow cake nya habis. Lalu olesi keseluruhan permukaan kue dgn butter Cream. Ratakan. Hias sesuai selera"
categories:
- Recipe
tags:
- rainbow
- cake
- kukus

katakunci: rainbow cake kukus 
nutrition: 167 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Lunch

---


![Rainbow Cake (Kukus)](https://img-global.cpcdn.com/recipes/1098ca7917a754a2/751x532cq70/rainbow-cake-kukus-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang harus kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti rainbow cake (kukus) yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa keistimewahan yang merupakan keragaman Indonesia



Kedekatan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Rainbow Cake (Kukus) untuk keluarga. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang dapat anda coba salah satunya rainbow cake (kukus) yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep rainbow cake (kukus) tanpa harus bersusah payah.
Seperti resep Rainbow Cake (Kukus) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Rainbow Cake (Kukus):

1. Harap siapkan  Bahan A :
1. Diperlukan 4 btr telur ayam
1. Harap siapkan 150 gr gula pasir
1. Diperlukan 1 sdt TBM
1. Jangan lupa  Bahan B :
1. Siapkan 150 gr tepung terigu
1. Siapkan 1 sdt baking powder
1. Tambah 2 sdm susu bubuk
1. Siapkan 1/2 sdt vanili bubuk
1. Dibutuhkan Sejumput garam
1. Jangan lupa  Bahan C :
1. Dibutuhkan 1 sachet kental manis putih
1. Dibutuhkan 1 bks santan instan (kara uk.65ml)
1. Harus ada 150 ml minyak sayur
1. Jangan lupa  Pelengkap : pewarna makanan
1. Jangan lupa  Topping :
1. Jangan lupa  Homemade Buttercream (resep ada dibawah)
1. Siapkan  Meisis rainbow




<!--inarticleads2-->

##### Langkah membuat  Rainbow Cake (Kukus):

1. Siapkan loyang ukuran 18cm, olesi mentega dan alasi dgn baking paper. Sisihkan
1. Campur semua bahan B, ayak. Sisihkan. Diwadah terpisah campur juga bahan C aduk dan sisihkan.
1. Mixer bahan A sampai mengembang dan putih pucat.
1. Campur bahan B yg sudah diayak bergantian dgn campuran bahan C. Aduk balik sampai rata
1. Bagi adonan menjadi 6 dan berikan masing2 3 tetes pewarna makanan.
1. Tuang 1 warna ke dalam loyang dan kukus sekitar 6 menit kedalam kukusan yg sebelumnya sudah dipanaskan. Lakukan sampai masing2 warna adonan habis. Biarkan dingin
1. Ambil 1 warna dasar (me : ungu) olesi dengan Buttercream tumpuk lagi dgn warna selanjutnya. Ulangi sampai semua rainbow cake nya habis. Lalu olesi keseluruhan permukaan kue dgn butter Cream. Ratakan. Hias sesuai selera




Demikianlah cara membuat rainbow cake (kukus) yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
