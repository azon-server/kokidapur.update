---
description: "Resep : Babi Rica-Rica versi Express Favorite"
title: "Resep : Babi Rica-Rica versi Express Favorite"
slug: 325-resep-babi-rica-rica-versi-express-favorite
date: 2020-09-01T17:52:36.436Z
image: https://img-global.cpcdn.com/recipes/151dabc679189968/751x532cq70/babi-rica-rica-versi-express-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/151dabc679189968/751x532cq70/babi-rica-rica-versi-express-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/151dabc679189968/751x532cq70/babi-rica-rica-versi-express-foto-resep-utama.jpg
author: Oscar Stewart
ratingvalue: 4.9
reviewcount: 8345
recipeingredient:
- "500 gr daging babi bagian agak berlemak potong agak kecil"
- "3 sdm bumbu dasar kuning"
- "1 sdm bumbu dasar merah resep ada di postingan sebelumnya"
- "4 batang serai geprek bikin simpul"
- "4 lbr daun jeruk buang bagian batang"
- "1,5 btr tomat ukuran sedang buang biji dan iris kecil"
- " Minyak utk menumis dikit aja bumbu dasar uda ada minyaknya"
- "secukupnya Garam"
- "3/4 btr jeruk nipis ambil airnya"
- "1 sdt gula pasir"
- "1 ikat daun kemangi"
- "1 batang bawang daun iris tipis"
recipeinstructions:
- "Tumis dengan sedikit minyak hingga wangi, masukkan bumbu dasar. Campurkan potongan daging dan tambahkan daun jeruk serta potongan tomat. Beri sedikit air, ungkep hingga daging empuk dan kuah menyusut"
- "Tambahkan daun kemangi, daun bawang dan jeruk serta garam dan gula, icip. Koreksi rasa dan biarkan hingga kuah mengering, angkat. Siap dihidangkan dengan taburan bawang goreng"
- "Update: Jadi fav gembulers jadi agak sering masaknya. Pernah bikin pake jeruk nipis yang ukurannya kecil bgt jd niatnya mo pake 1 utuh, ternyata baru pake 3/4 dicobain tes rasa aseeemm. Waduh bingung deh kl terlalu asem anak-anak ga kan suka padahal tomat hanya pake 1 bh. Akhirnya gula pasir dibanyakin buat ngurangin rasa asemnya dan garam agak ditambah. Jadi untuk takaran jeruk nipisnya pake 1/2 bh dulu ya moms, tes rasa baru jadikan 3/4 bh jika masih kurang 😀"
categories:
- Recipe
tags:
- babi
- ricarica
- versi

katakunci: babi ricarica versi 
nutrition: 141 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dessert

---


![Babi Rica-Rica versi Express](https://img-global.cpcdn.com/recipes/151dabc679189968/751x532cq70/babi-rica-rica-versi-express-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga renyah. Ciri masakan Nusantara babi rica-rica versi express yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah memasak Babi Rica-Rica versi Express untuk keluarga. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang dapat anda praktekkan salah satunya babi rica-rica versi express yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep babi rica-rica versi express tanpa harus bersusah payah.
Seperti resep Babi Rica-Rica versi Express yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 12 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Babi Rica-Rica versi Express:

1. Tambah 500 gr daging babi, bagian agak berlemak, potong agak kecil
1. Harap siapkan 3 sdm bumbu dasar kuning
1. Harap siapkan 1 sdm bumbu dasar merah *resep ada di postingan sebelumnya
1. Harap siapkan 4 batang serai geprek, bikin simpul
1. Dibutuhkan 4 lbr daun jeruk, buang bagian batang
1. Diperlukan 1,5 btr tomat ukuran sedang, buang biji dan iris kecil
1. Diperlukan  Minyak utk menumis *dikit aja, bumbu dasar uda ada minyaknya
1. Diperlukan secukupnya Garam
1. Jangan lupa 3/4 btr jeruk nipis, ambil airnya
1. Harus ada 1 sdt gula pasir
1. Siapkan 1 ikat daun kemangi
1. Dibutuhkan 1 batang bawang daun iris tipis




<!--inarticleads2-->

##### Cara membuat  Babi Rica-Rica versi Express:

1. Tumis dengan sedikit minyak hingga wangi, masukkan bumbu dasar. Campurkan potongan daging dan tambahkan daun jeruk serta potongan tomat. Beri sedikit air, ungkep hingga daging empuk dan kuah menyusut
1. Tambahkan daun kemangi, daun bawang dan jeruk serta garam dan gula, icip. Koreksi rasa dan biarkan hingga kuah mengering, angkat. Siap dihidangkan dengan taburan bawang goreng
1. Update: Jadi fav gembulers jadi agak sering masaknya. Pernah bikin pake jeruk nipis yang ukurannya kecil bgt jd niatnya mo pake 1 utuh, ternyata baru pake 3/4 dicobain tes rasa aseeemm. Waduh bingung deh kl terlalu asem anak-anak ga kan suka padahal tomat hanya pake 1 bh. Akhirnya gula pasir dibanyakin buat ngurangin rasa asemnya dan garam agak ditambah. Jadi untuk takaran jeruk nipisnya pake 1/2 bh dulu ya moms, tes rasa baru jadikan 3/4 bh jika masih kurang 😀




Demikianlah cara membuat babi rica-rica versi express yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan teruji, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
