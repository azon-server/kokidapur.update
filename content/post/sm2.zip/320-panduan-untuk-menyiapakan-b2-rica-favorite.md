---
description: "Panduan untuk menyiapakan B2 rica Favorite"
title: "Panduan untuk menyiapakan B2 rica Favorite"
slug: 320-panduan-untuk-menyiapakan-b2-rica-favorite
date: 2020-11-20T20:41:49.537Z
image: https://img-global.cpcdn.com/recipes/e17548abc2670ede/751x532cq70/b2-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e17548abc2670ede/751x532cq70/b2-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e17548abc2670ede/751x532cq70/b2-rica-foto-resep-utama.jpg
author: Rachel Woods
ratingvalue: 4.5
reviewcount: 5400
recipeingredient:
- "1 kg daging b2 samcan Sy pke bag has"
- "5 btg daun bawang"
- "5 lbr daun salam"
- "15 lbr daun jeruk"
- "secukupnya garam dan vetsin"
- "secukupnya air"
- " dihaluskan"
- "20 siung bawang merah"
- "8 siung bawang putih"
- "secukupnya cabe merah"
- "1 bongkol lengkuas"
- "6-7 btg sereh"
- "2 sdm kunyit bubuk"
- "1 jari jahe"
- "30 biji Lombok padisesuai kan dgn tingkat pedas yg diinginkan"
- " saya taruh nya belakangan karena disimpankan buat anak dlu"
recipeinstructions:
- "Tumis bumbu halus,daun salam dan daun jeruk sampai kering dan harum"
- "Masukkan daging yang sudah dipotong kecil diaduk sampai darahnya tdk terlihat dan bumbu dan daging menyatu"
- "Tambahkan air masak sampai daging empuk dan air kering"
- "Kalo daging Masi keras tambahkan lagi air dan masak Lgi sampai daging empuk dan air habis"
categories:
- Recipe
tags:
- b2
- rica

katakunci: b2 rica 
nutrition: 192 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Dessert

---


![B2 rica](https://img-global.cpcdn.com/recipes/e17548abc2670ede/751x532cq70/b2-rica-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga empuk. Ciri kuliner Nusantara b2 rica yang penuh dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan B2 rica untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang bisa anda coba salah satunya b2 rica yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep b2 rica tanpa harus bersusah payah.
Seperti resep B2 rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat B2 rica:

1. Diperlukan 1 kg daging b2 samcan (Sy pke bag has)
1. Harus ada 5 btg daun bawang
1. Siapkan 5 lbr daun salam
1. Siapkan 15 lbr daun jeruk
1. Harap siapkan secukupnya garam dan vetsin
1. Siapkan secukupnya air
1. Jangan lupa  dihaluskan:
1. Tambah 20 siung bawang merah
1. Harus ada 8 siung bawang putih
1. Jangan lupa secukupnya cabe merah
1. Jangan lupa 1 bongkol lengkuas
1. Dibutuhkan 6-7 btg sereh
1. Siapkan 2 sdm kunyit bubuk
1. Jangan lupa 1 jari jahe
1. Diperlukan 30 biji Lombok padi/sesuai kan dgn tingkat pedas yg diinginkan
1. Dibutuhkan  (saya taruh nya belakangan karena disimpankan buat anak dlu)




<!--inarticleads2-->

##### Bagaimana membuat  B2 rica:

1. Tumis bumbu halus,daun salam dan daun jeruk sampai kering dan harum
1. Masukkan daging yang sudah dipotong kecil diaduk sampai darahnya tdk terlihat dan bumbu dan daging menyatu
1. Tambahkan air masak sampai daging empuk dan air kering
1. Kalo daging Masi keras tambahkan lagi air dan masak Lgi sampai daging empuk dan air habis




Demikianlah cara membuat b2 rica yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
