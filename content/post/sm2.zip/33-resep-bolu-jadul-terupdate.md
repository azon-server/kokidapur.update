---
description: "Resep : Bolu Jadul terupdate"
title: "Resep : Bolu Jadul terupdate"
slug: 33-resep-bolu-jadul-terupdate
date: 2021-02-16T10:12:58.278Z
image: https://img-global.cpcdn.com/recipes/3a9d12db0e3e37af/751x532cq70/bolu-jadul-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3a9d12db0e3e37af/751x532cq70/bolu-jadul-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3a9d12db0e3e37af/751x532cq70/bolu-jadul-foto-resep-utama.jpg
author: Dorothy Steele
ratingvalue: 4.1
reviewcount: 9784
recipeingredient:
- "4 Butir telur utuh"
- "100 gr gula pasir"
- "100 gr terigu"
- "20 gr susu bubuk"
- "1/2 Sdt vanila extract"
- "75 gr mentega cair"
- " Resep butter cream "
- "250 gr mentega putih  margarin"
- "5 sdm susu kental manis putih"
- "secukupnya Pewarna makanan"
recipeinstructions:
- "Panaskan oven 180° C"
- "Oles loyang bulat (saya pakai pengoles loyang) diameter 18 cm"
- "Kocok telur dan gula sampai putih pucat mengembang, sekitar 15 menit"
- "Masukkan sedikit2 (saya 3 kali) tepung dan susu yg sudah diayak, aduk rata tapi jangan overmix"
- "Masukkan butter leleh dan pasta vanila, aduk rata pastikan butter tidak ada yg mengendap di bawah"
- "Masukkan ke dalam loyang. Oven sekitar 35 menit (oven saya) atau tergantung oven masing2 ya"
- "Setelah matang, segera keluarkan dari loyang agar tidak menciut. Hias sesuai selera"
- "Cara membuat buttercream : Kocok mentega putih menggunakan mixer -/+ 20 menit kecepatan sedang sampai kental agak lembut"
- "Tambahkan susu kental manis. Kocok lagi hingga lembut dan mengembang"
- "Beri pewarna sesuai selera. Aduk sampai rata."
categories:
- Recipe
tags:
- bolu
- jadul

katakunci: bolu jadul 
nutrition: 213 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dinner

---


![Bolu Jadul](https://img-global.cpcdn.com/recipes/3a9d12db0e3e37af/751x532cq70/bolu-jadul-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang setidaknya kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti bolu jadul yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan ciri khas yang merupakan keragaman Nusantara

Kedekatan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak Bolu Jadul untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang dapat anda buat salah satunya bolu jadul yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep bolu jadul tanpa harus bersusah payah.
Berikut ini resep Bolu Jadul yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 10 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Bolu Jadul:

1. Diperlukan 4 Butir telur utuh
1. Tambah 100 gr gula pasir
1. Harap siapkan 100 gr terigu
1. Siapkan 20 gr susu bubuk
1. Harap siapkan 1/2 Sdt vanila extract
1. Dibutuhkan 75 gr mentega cair
1. Tambah  Resep butter cream :
1. Tambah 250 gr mentega putih / margarin
1. Jangan lupa 5 sdm susu kental manis putih
1. Dibutuhkan secukupnya Pewarna makanan




<!--inarticleads2-->

##### Cara membuat  Bolu Jadul:

1. Panaskan oven 180° C
1. Oles loyang bulat (saya pakai pengoles loyang) diameter 18 cm
1. Kocok telur dan gula sampai putih pucat mengembang, sekitar 15 menit
1. Masukkan sedikit2 (saya 3 kali) tepung dan susu yg sudah diayak, aduk rata tapi jangan overmix
1. Masukkan butter leleh dan pasta vanila, aduk rata pastikan butter tidak ada yg mengendap di bawah
1. Masukkan ke dalam loyang. Oven sekitar 35 menit (oven saya) atau tergantung oven masing2 ya
1. Setelah matang, segera keluarkan dari loyang agar tidak menciut. Hias sesuai selera
1. Cara membuat buttercream : Kocok mentega putih menggunakan mixer -/+ 20 menit kecepatan sedang sampai kental agak lembut
1. Tambahkan susu kental manis. Kocok lagi hingga lembut dan mengembang
1. Beri pewarna sesuai selera. Aduk sampai rata.




Demikianlah cara membuat bolu jadul yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
