---
description: "Resep : Steamed Rainbow Cake Homemade"
title: "Resep : Steamed Rainbow Cake Homemade"
slug: 24-resep-steamed-rainbow-cake-homemade
date: 2020-10-05T04:01:48.037Z
image: https://img-global.cpcdn.com/recipes/65f8adf02d02bcc3/751x532cq70/steamed-rainbow-cake-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/65f8adf02d02bcc3/751x532cq70/steamed-rainbow-cake-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/65f8adf02d02bcc3/751x532cq70/steamed-rainbow-cake-foto-resep-utama.jpg
author: Bryan Rice
ratingvalue: 4
reviewcount: 49111
recipeingredient:
- "4 butir telur"
- "150 g gula pasir"
- "1 sdt emulsifier aku pakai SP"
- "150 g tepung terigu aku pakai segitiga"
- "2/4 sdt vanili cream bubuk"
- "1/2 sdt baking powder double action herkules"
- "50 g fibercream resep asli pakai Dancow"
- "150 ml minyak goreng"
- "1 bks santan instan kecil"
- "50 g kental manis aku pakai Frisian flag gold"
- " pewarna makanan cap koepoe2 kuning mudahijauungu merah cabe"
recipeinstructions:
- "Siapkan bahan, panaskan kukusan,ayak bersamaan tepung terigu, fibercream, vanili cream dan baking powder,kemudian kocok telur gula dan sp sampai kaku kental berjejak"
- "Masukkan campuran tepung secara bertahap sambil mixer dengan kecepatan rendah lalu masukkan santan minyak goreng dan kental manis aduk sebentar sekali lalu matikan mixer aduk balik pakai spatula"
- "Bagi adonan menjadi beberapa bagian, tergantung jumlah warnah kemudian beri pewarna masing masing dan aduk rata,(maaf step ini lupa photo.. next ya) kukus tiap layer 5 menit tumpuk lagi warna lain sampai selesai, setelah semua warna lengkap kukus terus 10-15 menit.angkat dan dinginkan"
- "Steamed Rainbow Cake siap di hidangkan 😋😋"
categories:
- Recipe
tags:
- steamed
- rainbow
- cake

katakunci: steamed rainbow cake 
nutrition: 218 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Lunch

---


![Steamed Rainbow Cake](https://img-global.cpcdn.com/recipes/65f8adf02d02bcc3/751x532cq70/steamed-rainbow-cake-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita jaga karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti steamed rainbow cake yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa keistimewahan yang merupakan keragaman Indonesia



Kehangatan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Steamed Rainbow Cake untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang dapat anda praktekkan salah satunya steamed rainbow cake yang merupakan resep favorite yang mudah dengan kreasi sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep steamed rainbow cake tanpa harus bersusah payah.
Seperti resep Steamed Rainbow Cake yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Steamed Rainbow Cake:

1. Tambah 4 butir telur
1. Tambah 150 g gula pasir
1. Jangan lupa 1 sdt emulsifier (aku pakai SP)
1. Diperlukan 150 g tepung terigu (aku pakai segitiga)
1. Tambah 2/4 sdt vanili cream bubuk
1. Siapkan 1/2 sdt baking powder double action (herkules)
1. Tambah 50 g fibercream (resep asli pakai Dancow)
1. Dibutuhkan 150 ml minyak goreng
1. Diperlukan 1 bks santan instan kecil
1. Harap siapkan 50 g kental manis (aku pakai Frisian flag gold)
1. Harus ada  pewarna makanan (cap koepoe2 kuning muda,hijau,ungu, merah cabe




<!--inarticleads2-->

##### Instruksi membuat  Steamed Rainbow Cake:

1. Siapkan bahan, panaskan kukusan,ayak bersamaan tepung terigu, fibercream, vanili cream dan baking powder,kemudian kocok telur gula dan sp sampai kaku kental berjejak
1. Masukkan campuran tepung secara bertahap sambil mixer dengan kecepatan rendah lalu masukkan santan minyak goreng dan kental manis aduk sebentar sekali lalu matikan mixer aduk balik pakai spatula
1. Bagi adonan menjadi beberapa bagian, tergantung jumlah warnah kemudian beri pewarna masing masing dan aduk rata,(maaf step ini lupa photo.. next ya) kukus tiap layer 5 menit tumpuk lagi warna lain sampai selesai, setelah semua warna lengkap kukus terus 10-15 menit.angkat dan dinginkan
1. Steamed Rainbow Cake siap di hidangkan 😋😋




Demikianlah cara membuat steamed rainbow cake yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan teruji, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
