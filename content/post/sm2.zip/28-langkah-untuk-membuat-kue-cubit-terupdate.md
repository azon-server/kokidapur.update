---
description: "Langkah untuk membuat Kue cubit terupdate"
title: "Langkah untuk membuat Kue cubit terupdate"
slug: 28-langkah-untuk-membuat-kue-cubit-terupdate
date: 2020-10-10T05:39:06.663Z
image: https://img-global.cpcdn.com/recipes/0e6cd72df1cbe31a/751x532cq70/kue-cubit-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0e6cd72df1cbe31a/751x532cq70/kue-cubit-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0e6cd72df1cbe31a/751x532cq70/kue-cubit-foto-resep-utama.jpg
author: Douglas Chandler
ratingvalue: 4.6
reviewcount: 39335
recipeingredient:
- "3 butir telur"
- "100 g gula halus menurut saya kurang manis jd sesuai selera ya"
- "200 g tepung terigu saya pakai segitiga biru"
- "100 g margarin cair blueband"
- "100 ml susu cair saya pakai ultra milk"
- "1/2 sdt garam"
- "1 sdt baking powdr resep asli 12 baking pwdr 14sdt soda kue"
- "1/2 sdt vanili"
- " Pewarna makanan hijau"
- " Topping sesuai selera saya pakai chocochip"
recipeinstructions:
- "Siapkan wadah, kocok telur dan gula halus dengan mixer sampai mengembang dan pucat"
- "Masukan margarin cair, susu, vanila cair aduk rata saja"
- "Sebelumnya tepung terigu, garam, baking powder diayak"
- "Masukan campuran tepung terigu sedikit demi sedikit sampai tercampur rata (kalau saya aduk tidak usah pakai mixer, pakai whisk saja)"
- "Pisahkan adonan untuk diwarnai sesuai selera"
- "Masak adonan dlm wajan kue cubit (sebelumnya wajan d olesi margarin terlebih dahulu)"
- "Masak dengan api kecil dan di tutup"
- "Jika sudah mengembang dan setengah matang masukan toping sesuai selera."
- "Tutup kembali dan masak hingga matang. Setengah matang jg enak😁"
- "Angkat dan olesi sedikit margarin dan Sajikan"
categories:
- Recipe
tags:
- kue
- cubit

katakunci: kue cubit 
nutrition: 288 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Dinner

---


![Kue cubit](https://img-global.cpcdn.com/recipes/0e6cd72df1cbe31a/751x532cq70/kue-cubit-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti kue cubit yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa keistimewahan yang merupakan keragaman Kita

Kehangatan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah memasak Kue cubit untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang bisa anda contoh salah satunya kue cubit yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep kue cubit tanpa harus bersusah payah.
Seperti resep Kue cubit yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 10 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue cubit:

1. Tambah 3 butir telur
1. Harap siapkan 100 g gula halus (menurut saya kurang manis, jd sesuai selera ya)
1. Dibutuhkan 200 g tepung terigu (saya pakai segitiga biru)
1. Dibutuhkan 100 g margarin cair (blueband)
1. Diperlukan 100 ml susu cair (saya pakai ultra milk)
1. Harus ada 1/2 sdt garam
1. Diperlukan 1 sdt baking powdr (resep asli 1/2 baking pwdr, 1/4sdt soda kue)
1. Tambah 1/2 sdt vanili
1. Dibutuhkan  Pewarna makanan hijau
1. Jangan lupa  Topping sesuai selera (saya pakai chocochip)




<!--inarticleads2-->

##### Bagaimana membuat  Kue cubit:

1. Siapkan wadah, kocok telur dan gula halus dengan mixer sampai mengembang dan pucat
1. Masukan margarin cair, susu, vanila cair aduk rata saja
1. Sebelumnya tepung terigu, garam, baking powder diayak
1. Masukan campuran tepung terigu sedikit demi sedikit sampai tercampur rata (kalau saya aduk tidak usah pakai mixer, pakai whisk saja)
1. Pisahkan adonan untuk diwarnai sesuai selera
1. Masak adonan dlm wajan kue cubit (sebelumnya wajan d olesi margarin terlebih dahulu)
1. Masak dengan api kecil dan di tutup
1. Jika sudah mengembang dan setengah matang masukan toping sesuai selera.
1. Tutup kembali dan masak hingga matang. Setengah matang jg enak😁
1. Angkat dan olesi sedikit margarin dan Sajikan




Demikianlah cara membuat kue cubit yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat simple dan cepat, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
