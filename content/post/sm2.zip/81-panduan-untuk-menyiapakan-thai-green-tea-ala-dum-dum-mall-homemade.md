---
description: "Panduan untuk menyiapakan Thai Green Tea ala dum dum mall Homemade"
title: "Panduan untuk menyiapakan Thai Green Tea ala dum dum mall Homemade"
slug: 81-panduan-untuk-menyiapakan-thai-green-tea-ala-dum-dum-mall-homemade
date: 2021-01-07T17:16:00.113Z
image: https://img-global.cpcdn.com/recipes/53c1f1c6da651a92/751x532cq70/thai-green-tea-ala-dum-dum-mall-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/53c1f1c6da651a92/751x532cq70/thai-green-tea-ala-dum-dum-mall-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/53c1f1c6da651a92/751x532cq70/thai-green-tea-ala-dum-dum-mall-foto-resep-utama.jpg
author: Amanda Copeland
ratingvalue: 4
reviewcount: 1213
recipeingredient:
- "2,5 sdm bubuk green tea"
- "1 sdt gula pasir"
- " Susu Kental manis"
- "1 liter Air"
- " Evaporated milk sy skip krn gapunya"
- " Topping boba bubble"
recipeinstructions:
- "Rebus 700ml air sampai mendidih"
- "Masukkan 2sdm green tea. Bungkus greentea sy itu kena benyek boba sama si anak bayi😂"
- "Rebus kira2 3-5mnt hingga kental dan pekat"
- "Saring menggunakan saringan kain. Sisihkan"
- "Sisa teh yg masih ada di panci, rebus lagi dengan 300ml air."
- "Isi gelas dengan susu kental manis. Sy pake harvest jar. takarannya sampai di tulisan &#34;drinking jar&#34; itu. Lalu tmbhkn 1sdt gula pasir"
- "Angkat rebusan teh kedua, saring. Dan campurkan ke rebusan pertama. (Rebusan kedua ini sbnenya supaya ga mubazir aja sih sisa teh nya. Kalo mau sekali rebus 1 liter jg ga masalah)."
- "Tuangkan green tea td ke dalam gelas yg sudah diisi susu dan gula. Sisakan sisa 1/4 bagian gelas kosong."
- "Aduk rata, tambahkan es batu, dan tuang susu evaporasi (sy skip krn gpunya)."
- "Sajikan dengan Topping Boba bubble lebih nikmat😋"
categories:
- Recipe
tags:
- thai
- green
- tea

katakunci: thai green tea 
nutrition: 110 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Lunch

---


![Thai Green Tea ala dum dum mall](https://img-global.cpcdn.com/recipes/53c1f1c6da651a92/751x532cq70/thai-green-tea-ala-dum-dum-mall-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti thai green tea ala dum dum mall yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan ciri khas yang merupakan keragaman Nusantara

Kehangatan rumah tangga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Thai Green Tea ala dum dum mall untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang dapat anda contoh salah satunya thai green tea ala dum dum mall yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep thai green tea ala dum dum mall tanpa harus bersusah payah.
Seperti resep Thai Green Tea ala dum dum mall yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 10 langkah dan 6 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Thai Green Tea ala dum dum mall:

1. Harap siapkan 2,5 sdm bubuk green tea
1. Harap siapkan 1 sdt gula pasir
1. Harap siapkan  Susu Kental manis
1. Harus ada 1 liter Air
1. Diperlukan  Evaporated milk (sy skip krn gapunya)
1. Harus ada  Topping boba (bubble)




<!--inarticleads2-->

##### Cara membuat  Thai Green Tea ala dum dum mall:

1. Rebus 700ml air sampai mendidih
1. Masukkan 2sdm green tea. Bungkus greentea sy itu kena benyek boba sama si anak bayi😂
1. Rebus kira2 3-5mnt hingga kental dan pekat
1. Saring menggunakan saringan kain. Sisihkan
1. Sisa teh yg masih ada di panci, rebus lagi dengan 300ml air.
1. Isi gelas dengan susu kental manis. Sy pake harvest jar. takarannya sampai di tulisan &#34;drinking jar&#34; itu. Lalu tmbhkn 1sdt gula pasir
1. Angkat rebusan teh kedua, saring. Dan campurkan ke rebusan pertama. (Rebusan kedua ini sbnenya supaya ga mubazir aja sih sisa teh nya. Kalo mau sekali rebus 1 liter jg ga masalah).
1. Tuangkan green tea td ke dalam gelas yg sudah diisi susu dan gula. Sisakan sisa 1/4 bagian gelas kosong.
1. Aduk rata, tambahkan es batu, dan tuang susu evaporasi (sy skip krn gpunya).
1. Sajikan dengan Topping Boba bubble lebih nikmat😋




Demikianlah cara membuat thai green tea ala dum dum mall yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan terbukti, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
