---
description: "Resep : Steam Rainbow Cake 4 Telur Cepat"
title: "Resep : Steam Rainbow Cake 4 Telur Cepat"
slug: 30-resep-steam-rainbow-cake-4-telur-cepat
date: 2020-12-05T02:14:44.600Z
image: https://img-global.cpcdn.com/recipes/0f14be7711626d13/751x532cq70/steam-rainbow-cake-4-telur-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0f14be7711626d13/751x532cq70/steam-rainbow-cake-4-telur-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0f14be7711626d13/751x532cq70/steam-rainbow-cake-4-telur-foto-resep-utama.jpg
author: Lelia Luna
ratingvalue: 4.7
reviewcount: 41782
recipeingredient:
- " Bahan A "
- "4 butir telur"
- "150 gram gula pasir"
- "1 sdt sp"
- " Bahan B "
- "150 gram tepung terigu"
- "1/2 sdt baking powder"
- "1 saset susu bubuk full cream dancow"
- "1/2 sdt vanili bubuk"
- "Sejumput garam"
- " Bahan C "
- "150 ml minyak sayur"
- "6 sdm susu kental manis resep asli pake 1 saset"
- " Pewarna makanan rainbow"
- "1 bungkus kara 65 ml"
- " Hiasan "
- " Whipecreambuttercream"
recipeinstructions:
- "Siapkan loyang (saya pakai loyang bulat ukuran 18×18). Siapkan 6 lembar kertas baking buat dasar loyang. Dan siapkan juga panci kukusan dgn tutup dibungkus serbet bersih.tanpa dioles Apapun, experiment pertama saya oles butter malah hasilnya gak maksimal jadi basah2 walaupun gak bantet"
- "Ayak Bahan B bahan kering. Campur Bahan C minyak, susu kental manis dan santan, sisihkan."
- "Mixer telur, gula dan sp sampai putih mengembang pucat."
- "Masukkan ayakan bahan kering selang seling dgn campuran minyak. Aduk balik rata sampai semua bahan tercampur."
- "Panaskan panci kukusan dgn api sedang."
- "Bagi adonan jadi 6 bagian. Beri masing2 warna. Saya menambahkan warna sesat akan dikukus"
- "Tuang pada loyang, lalu kukus selama 6-7 menit. Setelah matang angkat dan dinginkan. Kukus untuk warna yg lainnya."
- "Setelah matang angkat dan dinginkan. Hias sesuai selera. Selamat mencoba."
- "Hasilnya lembut bgt...wajib coba semalaman dikulkas tetep Lembyut 😘😘"
- "Keabisan whipcream akhirnya diakali oles SKM Taburin cheese Atasnya 😉😉"
- "Sebaiknya tiap adonan ditimbang biar rata beratnya"
categories:
- Recipe
tags:
- steam
- rainbow
- cake

katakunci: steam rainbow cake 
nutrition: 148 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Lunch

---


![Steam Rainbow Cake 4 Telur](https://img-global.cpcdn.com/recipes/0f14be7711626d13/751x532cq70/steam-rainbow-cake-4-telur-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan gurih. Ciri kuliner Nusantara steam rainbow cake 4 telur yang kaya dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Steam Rainbow Cake 4 Telur untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang dapat anda praktekkan salah satunya steam rainbow cake 4 telur yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep steam rainbow cake 4 telur tanpa harus bersusah payah.
Seperti resep Steam Rainbow Cake 4 Telur yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 11 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Steam Rainbow Cake 4 Telur:

1. Tambah  Bahan A :
1. Dibutuhkan 4 butir telur
1. Harus ada 150 gram gula pasir
1. Siapkan 1 sdt sp
1. Tambah  Bahan B :
1. Siapkan 150 gram tepung terigu
1. Harus ada 1/2 sdt baking powder
1. Jangan lupa 1 saset susu bubuk full cream (dancow)
1. Tambah 1/2 sdt vanili bubuk
1. Siapkan Sejumput garam
1. Diperlukan  Bahan C :
1. Tambah 150 ml minyak sayur
1. Tambah 6 sdm susu kental manis (resep asli pake 1 saset)
1. Dibutuhkan  Pewarna makanan rainbow
1. Siapkan 1 bungkus kara (65 ml)
1. Tambah  Hiasan :
1. Harus ada  Whipecream/buttercream




<!--inarticleads2-->

##### Cara membuat  Steam Rainbow Cake 4 Telur:

1. Siapkan loyang (saya pakai loyang bulat ukuran 18×18). Siapkan 6 lembar kertas baking buat dasar loyang. Dan siapkan juga panci kukusan dgn tutup dibungkus serbet bersih.tanpa dioles Apapun, experiment pertama saya oles butter malah hasilnya gak maksimal jadi basah2 walaupun gak bantet
1. Ayak Bahan B bahan kering. Campur Bahan C minyak, susu kental manis dan santan, sisihkan.
1. Mixer telur, gula dan sp sampai putih mengembang pucat.
1. Masukkan ayakan bahan kering selang seling dgn campuran minyak. Aduk balik rata sampai semua bahan tercampur.
1. Panaskan panci kukusan dgn api sedang.
1. Bagi adonan jadi 6 bagian. Beri masing2 warna. Saya menambahkan warna sesat akan dikukus
1. Tuang pada loyang, lalu kukus selama 6-7 menit. Setelah matang angkat dan dinginkan. Kukus untuk warna yg lainnya.
1. Setelah matang angkat dan dinginkan. Hias sesuai selera. Selamat mencoba.
1. Hasilnya lembut bgt...wajib coba semalaman dikulkas tetep Lembyut 😘😘
1. Keabisan whipcream akhirnya diakali oles SKM Taburin cheese Atasnya 😉😉
1. Sebaiknya tiap adonan ditimbang biar rata beratnya




Demikianlah cara membuat steam rainbow cake 4 telur yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan cepat, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
