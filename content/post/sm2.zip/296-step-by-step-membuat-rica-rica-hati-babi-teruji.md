---
description: "Step-by-Step membuat Rica Rica Hati Babi Teruji"
title: "Step-by-Step membuat Rica Rica Hati Babi Teruji"
slug: 296-step-by-step-membuat-rica-rica-hati-babi-teruji
date: 2020-10-06T00:45:09.950Z
image: https://img-global.cpcdn.com/recipes/892c51bb6fc6b198/751x532cq70/rica-rica-hati-babi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/892c51bb6fc6b198/751x532cq70/rica-rica-hati-babi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/892c51bb6fc6b198/751x532cq70/rica-rica-hati-babi-foto-resep-utama.jpg
author: Cecelia Davidson
ratingvalue: 4.2
reviewcount: 18524
recipeingredient:
- "500 gr hati babi"
- "2 daun jeruk"
- "2 daun salam"
- "1 ruas lengkuas geprak"
- "1 btg sereh geprak"
- "Sesuai selera garam gula pasir kecap manis kaldu bubuk"
- " Bumbu halus "
- "5 bawang merah"
- "3 bawang putih"
- "2 cabe merah keriting"
- "5 cabe rawit"
- "3 butir kemiri"
- "1 ruas jahe"
- "50 gr gula merah sisir"
- "Sesuai selera merica bubuk"
recipeinstructions:
- "Didihkan air, rebus hati babi, lalu potong2 sesuai selera. Sisihkan"
- "Panaskan minyak dalam wajan, tumis bumbu halus hingga harum"
- "Masukkan daun salam, daun jeruk, lengkuas, sereh. Aduk2 sebentar. Beri air secukupnya. Aduk rata."
- "Masukkan hati babi, beri gula pasir, garam, kaldu bubuk dan kecap manis sesuai selera. Aduk rata kembali."
- "Masak hingga air menyusut dan hati empuk."
- "Tes rasa. Sajikan"
categories:
- Recipe
tags:
- rica
- rica
- hati

katakunci: rica rica hati 
nutrition: 288 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT53M"
recipeyield: "4"
recipecategory: Lunch

---


![Rica Rica Hati Babi](https://img-global.cpcdn.com/recipes/892c51bb6fc6b198/751x532cq70/rica-rica-hati-babi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan empuk. Ciri khas kuliner Indonesia rica rica hati babi yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kehangatan keluarga bisa didapat dengan cara simple. Salah satunya adalah memasak Rica Rica Hati Babi untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang bisa anda coba salah satunya rica rica hati babi yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep rica rica hati babi tanpa harus bersusah payah.
Seperti resep Rica Rica Hati Babi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 15 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Rica Rica Hati Babi:

1. Harus ada 500 gr hati babi
1. Tambah 2 daun jeruk
1. Harus ada 2 daun salam
1. Harap siapkan 1 ruas lengkuas, geprak
1. Jangan lupa 1 btg sereh, geprak
1. Tambah Sesuai selera garam, gula pasir, kecap manis, kaldu bubuk
1. Jangan lupa  Bumbu halus :
1. Harap siapkan 5 bawang merah
1. Jangan lupa 3 bawang putih
1. Siapkan 2 cabe merah keriting
1. Diperlukan 5 cabe rawit
1. Siapkan 3 butir kemiri
1. Harap siapkan 1 ruas jahe
1. Harap siapkan 50 gr gula merah, sisir
1. Diperlukan Sesuai selera merica bubuk




<!--inarticleads2-->

##### Langkah membuat  Rica Rica Hati Babi:

1. Didihkan air, rebus hati babi, lalu potong2 sesuai selera. Sisihkan
1. Panaskan minyak dalam wajan, tumis bumbu halus hingga harum
1. Masukkan daun salam, daun jeruk, lengkuas, sereh. Aduk2 sebentar. Beri air secukupnya. Aduk rata.
1. Masukkan hati babi, beri gula pasir, garam, kaldu bubuk dan kecap manis sesuai selera. Aduk rata kembali.
1. Masak hingga air menyusut dan hati empuk.
1. Tes rasa. Sajikan




Demikianlah cara membuat rica rica hati babi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan terbukti, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
