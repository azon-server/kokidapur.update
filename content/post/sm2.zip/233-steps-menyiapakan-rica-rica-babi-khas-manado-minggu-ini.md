---
description: "Steps menyiapakan Rica Rica Babi khas Manado minggu ini"
title: "Steps menyiapakan Rica Rica Babi khas Manado minggu ini"
slug: 233-steps-menyiapakan-rica-rica-babi-khas-manado-minggu-ini
date: 2020-12-18T00:54:02.671Z
image: https://img-global.cpcdn.com/recipes/830612c4089da3c4/751x532cq70/rica-rica-babi-khas-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/830612c4089da3c4/751x532cq70/rica-rica-babi-khas-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/830612c4089da3c4/751x532cq70/rica-rica-babi-khas-manado-foto-resep-utama.jpg
author: Phoebe Salazar
ratingvalue: 5
reviewcount: 46370
recipeingredient:
- "400 gr daging babi potong kecil"
- "2 lembar daun pandan"
- "2 iris lengkuas"
- "4 lembar daun jeruk purut"
- "3 batang serai bagian putih saja geprek"
- "1 sdm air jeruk nipis"
- " Minyak untuk menggoreng dan menumis"
- "Secukupnya  garam gula pasir dan kaldu bubuk"
- " Bumbu halus "
- "6 siung bawang merah"
- "4 siung bawang putih"
- "10 cabe merah keriting saya 15 campur merah dan hijau"
- "5 cabe rawit resep asli 10"
- "2 cm kunyit"
- "1 ruas jahe"
- "1 sdt merica"
recipeinstructions:
- "Goreng sebentar babi. Sisihkan."
- "Tumis bumbu yang sudah dihaluskan bersama dengan daun pandan, daun jeruk, dan serai sampai harum. Masukkan daging babi, tumis sebentar. Tambahkan sedikit air bila perlu, kemudian masukkan garam, gula pasir, dan kaldu bubuk. Ungkep sampai air menyusut dan keluar minyak."
- "Sesaat sebelum diangkat, kucuri dengan air jeruk nipis dan test rasa. Angkat dan hidangkan bersama nasi hangat 😋....tak sabar untuk segera makan."
categories:
- Recipe
tags:
- rica
- rica
- babi

katakunci: rica rica babi 
nutrition: 288 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dinner

---


![Rica Rica Babi khas Manado](https://img-global.cpcdn.com/recipes/830612c4089da3c4/751x532cq70/rica-rica-babi-khas-manado-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau enak. Ciri kuliner Nusantara rica rica babi khas manado yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Babi Rica masakan manado memang sudah terkenal apa lagi Bat Manado atau yang dikenal dengan nama Bat Paniki Manado itu rasanya nikmat dan Babi Masakan Khas Manado bisa bikin ngiler terutama Paniki Khas Manado bisa juga untuk Sarapan Pagi Babi Hutan Babi Masakan Khas. Merry Christmas! 🎅 Masak dan makannya pas Natal. Maaf non halal, daging bisa diganti daging ayam, kali ini masak masakan kesukaan suami, rica-rica, maklum suami asli orang manado, sedangkan saya asli org kalimantan, berbeda sekali selera makanannya. Resep rica rica sendiri sebenarnya tidak harus menggunakan bahan daging ayam saja.

Kedekatan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Rica Rica Babi khas Manado untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang dapat anda contoh salah satunya rica rica babi khas manado yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep rica rica babi khas manado tanpa harus bersusah payah.
Berikut ini resep Rica Rica Babi khas Manado yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Rica Rica Babi khas Manado:

1. Harus ada 400 gr daging babi, potong kecil
1. Diperlukan 2 lembar daun pandan
1. Diperlukan 2 iris lengkuas
1. Dibutuhkan 4 lembar daun jeruk purut
1. Siapkan 3 batang serai bagian putih saja, geprek
1. Jangan lupa 1 sdm air jeruk nipis
1. Harus ada  Minyak untuk menggoreng dan menumis
1. Dibutuhkan Secukupnya : garam, gula pasir dan kaldu bubuk
1. Harus ada  Bumbu halus :
1. Harus ada 6 siung bawang merah
1. Diperlukan 4 siung bawang putih
1. Dibutuhkan 10 cabe merah keriting (saya 15 campur merah dan hijau)
1. Harus ada 5 cabe rawit (resep asli 10)
1. Tambah 2 cm kunyit
1. Harap siapkan 1 ruas jahe
1. Siapkan 1 sdt merica


Apalagi ayam rica-ricanya yang cenderung Rasanya mantap, bikin sulit untuk melupakan kenikmatannya. Kalau belum berkesempatan ke Manado untuk mencicipi ayam rica-ricanya secara. Resep ayam Rica-rica merupakan salah satu resep masakan tradisional yang berasal dari Manado Sulawesi Utara. Nama Rica-rica sendiri berarti pedas Nah untuk memperkaya kamus resep ayam di resephariini.com, kali ini kami akan memberikan sebuah resep ayam rica-rica bumbu pedas khas. 

<!--inarticleads2-->

##### Bagaimana membuat  Rica Rica Babi khas Manado:

1. Goreng sebentar babi. Sisihkan.
1. Tumis bumbu yang sudah dihaluskan bersama dengan daun pandan, daun jeruk, dan serai sampai harum. Masukkan daging babi, tumis sebentar. Tambahkan sedikit air bila perlu, kemudian masukkan garam, gula pasir, dan kaldu bubuk. Ungkep sampai air menyusut dan keluar minyak.
1. Sesaat sebelum diangkat, kucuri dengan air jeruk nipis dan test rasa. Angkat dan hidangkan bersama nasi hangat 😋....tak sabar untuk segera makan.


Resep ayam Rica-rica merupakan salah satu resep masakan tradisional yang berasal dari Manado Sulawesi Utara. Nama Rica-rica sendiri berarti pedas Nah untuk memperkaya kamus resep ayam di resephariini.com, kali ini kami akan memberikan sebuah resep ayam rica-rica bumbu pedas khas. RICA RICA BABI masakkan khas Manado. Resep Babi Rica Rica Yang Enak Dan Spesial. Rica-rica ini menggunakan bumbu rempah-rempah sehingga sangat aman dan nyaman dimakan dengan menggunakan nasi yang masih hangat. 

Demikianlah cara membuat rica rica babi khas manado yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
