---
description: "Steps untuk membuat Babi Rica Favorite"
title: "Steps untuk membuat Babi Rica Favorite"
slug: 353-steps-untuk-membuat-babi-rica-favorite
date: 2021-02-16T09:13:48.864Z
image: https://img-global.cpcdn.com/recipes/f2aa91d4ec31607d/751x532cq70/babi-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f2aa91d4ec31607d/751x532cq70/babi-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f2aa91d4ec31607d/751x532cq70/babi-rica-foto-resep-utama.jpg
author: Joe Lyons
ratingvalue: 4.7
reviewcount: 41627
recipeingredient:
- "250 gr Daging babi kapsim atau has dalam"
- "6 btr bawang putih"
- "4 btr bawang merah"
- "5 bh cabe rawit merah"
- "7 bh cabe keriting"
- "2 ruas jari jahe"
- "2 ruas jari kunyit"
- "2 batang serai ambil bagian putihnya  geprek"
- "secukupnya daun bawang"
- "secukupnya daun kemangi"
- "4 lembar daun jeruk buang tulang daunnya"
- "secukupnya garam"
- " minyak untuk menumis"
recipeinstructions:
- "Daging babi potong2 sesuai selera"
- "Haluskan cabe, bawang merah, bawang putih, jahe, kunyit, garam"
- "Daun bawang iris halus, daun jeruk buang tulang daunnya, kemangi petiki"
- "Panaskan minyak.. masukkan serai yang sudah digeprek tumis sebentar.. lalu masukkan bumbu halus.. tumis sampe harum."
- "Masukkan daun jeruk dan daging babi.. aduk2 sampe matang. Tambahkan daun bawang dan kemangi. tunggu sampe daging matang dan bumbu meresap. bila perlu tambahkan air sedikit supaya tidak gosong. Cicipi.. bila rasanya sudah pas.. angkat dan sajikan. Happy Cooking...☺"
categories:
- Recipe
tags:
- babi
- rica

katakunci: babi rica 
nutrition: 257 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Lunch

---


![Babi Rica](https://img-global.cpcdn.com/recipes/f2aa91d4ec31607d/751x532cq70/babi-rica-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau renyah. Ciri makanan Indonesia babi rica yang penuh dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Babi Rica untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang dapat anda coba salah satunya babi rica yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep babi rica tanpa harus bersusah payah.
Berikut ini resep Babi Rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Babi Rica:

1. Jangan lupa 250 gr Daging babi (kapsim atau has dalam)
1. Diperlukan 6 btr bawang putih
1. Tambah 4 btr bawang merah
1. Siapkan 5 bh cabe rawit merah
1. Diperlukan 7 bh cabe keriting
1. Jangan lupa 2 ruas jari jahe
1. Diperlukan 2 ruas jari kunyit
1. Harap siapkan 2 batang serai ambil bagian putihnya - geprek
1. Diperlukan secukupnya daun bawang
1. Harap siapkan secukupnya daun kemangi
1. Harus ada 4 lembar daun jeruk buang tulang daunnya
1. Diperlukan secukupnya garam
1. Diperlukan  minyak untuk menumis




<!--inarticleads2-->

##### Bagaimana membuat  Babi Rica:

1. Daging babi potong2 sesuai selera
1. Haluskan cabe, bawang merah, bawang putih, jahe, kunyit, garam
1. Daun bawang iris halus, daun jeruk buang tulang daunnya, kemangi petiki
1. Panaskan minyak.. masukkan serai yang sudah digeprek tumis sebentar.. lalu masukkan bumbu halus.. tumis sampe harum.
1. Masukkan daun jeruk dan daging babi.. aduk2 sampe matang. Tambahkan daun bawang dan kemangi. tunggu sampe daging matang dan bumbu meresap. bila perlu tambahkan air sedikit supaya tidak gosong. Cicipi.. bila rasanya sudah pas.. angkat dan sajikan. Happy Cooking...☺




Demikianlah cara membuat babi rica yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan cepat, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
