---
description: "Steps membuat Babi Rica-rica Homemade"
title: "Steps membuat Babi Rica-rica Homemade"
slug: 302-steps-membuat-babi-rica-rica-homemade
date: 2021-02-05T05:25:57.345Z
image: https://img-global.cpcdn.com/recipes/e68472d9ef2c80fe/751x532cq70/babi-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e68472d9ef2c80fe/751x532cq70/babi-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e68472d9ef2c80fe/751x532cq70/babi-rica-rica-foto-resep-utama.jpg
author: Leila Osborne
ratingvalue: 5
reviewcount: 25962
recipeingredient:
- "1/2 kg samcan"
- "1/2 kg karbonat"
- "4 sdm angciu"
- "2 sdm air jeruk nipis"
- "1 sdm kaldu jamur"
- "1 sdm gula pasir"
- "1/2 sdm garam"
- "1 sdt lada bubuk"
- "3 ikat daun kemangi sy tdk pakai"
- " Bumbu halus"
- "5 butir kemiri"
- "25 butir bawang merah"
- "15 butir bawang putih"
- "100 gr cabe keriting"
- "250 gr cabe rawit merah"
- "1 ruas kunyit sedang"
- "1 buah jahe yg agak besar"
- "1 buah lengkuas besar"
- " Bumbu iris"
- "8 batang sereh"
- "3 buah tomat merah"
- "20 lembar daun jeruk purut"
- "5 lembar daun salam"
- "10 sdm minyak goreng"
- "250 ml air"
recipeinstructions:
- "Cuci bersih daging, lalu potong2 sesuai selera, dan ungkep dengan angciu lalu sisihkan."
- "Panaskan minyak lalu tumis bumbu halus hingga harum dan berubah warna."
- "Tiriskan daging lalu masukkan ke tumisan bumbu, tambahkan irisan sereh, daun jeruk, daun salam, aduk rata."
- "Kecilkan api dan tambahkan tomat dan irisan sereh lalu aduk rata."
- "Beri air, godok dengan api kecil, sambil sesekali diaduk. Masak hingga air menyusut. Tambahkan garam, lada, gula, kaldu jamur lalu koreksi rasa."
- "Saat air mulai menyusut dan daging mulai empuk, bisa ditambahkan air jeruk nipis dan daun kemangi, di tahap ini harus sering diaduk supaya tidak gosong. Masak hingga daging empuk lalu sajikan dengan nasi panas. Endess 👍"
categories:
- Recipe
tags:
- babi
- ricarica

katakunci: babi ricarica 
nutrition: 233 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Dessert

---


![Babi Rica-rica](https://img-global.cpcdn.com/recipes/e68472d9ef2c80fe/751x532cq70/babi-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan empuk. Ciri khas masakan Indonesia babi rica-rica yang kaya dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah memasak Babi Rica-rica untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang bisa anda praktekkan salah satunya babi rica-rica yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep babi rica-rica tanpa harus bersusah payah.
Seperti resep Babi Rica-rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 25 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Babi Rica-rica:

1. Dibutuhkan 1/2 kg samcan
1. Diperlukan 1/2 kg karbonat
1. Jangan lupa 4 sdm angciu
1. Tambah 2 sdm air jeruk nipis
1. Harus ada 1 sdm kaldu jamur
1. Siapkan 1 sdm gula pasir
1. Harap siapkan 1/2 sdm garam
1. Harus ada 1 sdt lada bubuk
1. Harap siapkan 3 ikat daun kemangi (sy tdk pakai)
1. Dibutuhkan  Bumbu halus:
1. Diperlukan 5 butir kemiri
1. Dibutuhkan 25 butir bawang merah
1. Dibutuhkan 15 butir bawang putih
1. Tambah 100 gr cabe keriting
1. Tambah 250 gr cabe rawit merah
1. Dibutuhkan 1 ruas kunyit sedang
1. Tambah 1 buah jahe yg agak besar
1. Dibutuhkan 1 buah lengkuas besar
1. Tambah  Bumbu iris:
1. Diperlukan 8 batang sereh
1. Tambah 3 buah tomat merah
1. Tambah 20 lembar daun jeruk purut
1. Dibutuhkan 5 lembar daun salam
1. Dibutuhkan 10 sdm minyak goreng
1. Tambah 250 ml air




<!--inarticleads2-->

##### Instruksi membuat  Babi Rica-rica:

1. Cuci bersih daging, lalu potong2 sesuai selera, dan ungkep dengan angciu lalu sisihkan.
1. Panaskan minyak lalu tumis bumbu halus hingga harum dan berubah warna.
1. Tiriskan daging lalu masukkan ke tumisan bumbu, tambahkan irisan sereh, daun jeruk, daun salam, aduk rata.
1. Kecilkan api dan tambahkan tomat dan irisan sereh lalu aduk rata.
1. Beri air, godok dengan api kecil, sambil sesekali diaduk. Masak hingga air menyusut. Tambahkan garam, lada, gula, kaldu jamur lalu koreksi rasa.
1. Saat air mulai menyusut dan daging mulai empuk, bisa ditambahkan air jeruk nipis dan daun kemangi, di tahap ini harus sering diaduk supaya tidak gosong. Masak hingga daging empuk lalu sajikan dengan nasi panas. Endess 👍




Demikianlah cara membuat babi rica-rica yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
