---
description: "Step-by-Step untuk membuat 130. Gudeg Jogja (pake Kacang Merah) teraktual"
title: "Step-by-Step untuk membuat 130. Gudeg Jogja (pake Kacang Merah) teraktual"
slug: 370-step-by-step-untuk-membuat-130-gudeg-jogja-pake-kacang-merah-teraktual
date: 2021-01-17T01:34:08.056Z
image: https://img-global.cpcdn.com/recipes/a9ce50a808944c31/751x532cq70/130-gudeg-jogja-pake-kacang-merah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a9ce50a808944c31/751x532cq70/130-gudeg-jogja-pake-kacang-merah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a9ce50a808944c31/751x532cq70/130-gudeg-jogja-pake-kacang-merah-foto-resep-utama.jpg
author: Jerry Alvarez
ratingvalue: 4
reviewcount: 48160
recipeingredient:
- "1/2 kg nangka kupas"
- "4 butir telur rebus"
- "Segenggam kacang merah"
- "Secukupnya air rebusan nangka dan kacang merah"
- "1 sdt baking soda dan garam"
- " Bumbu halus"
- "5 bh bamer"
- "2 bh baput"
- "3 biji kemiri"
- "1/3 sdt ketumbar bubuk"
- "1/3 sdt merica bubuk"
- "1 ruas kencur"
- "7 biji cabe merah keriting"
- " Bumbu lain"
- "2 lbr daun salam"
- "3 lbr daun jeruk"
- "1/2 tangkai serai geprek skip saya lagi gak ada stock"
- "1 ruas lengkuas geprek"
- "1 butir gula merah kecil bulat"
- "2 sdm kecap manis"
- "65 ml santan Kara"
- "Secukupnya air garam dan kaldu daging saya pakai Masako"
- " Minyak untuk numis"
recipeinstructions:
- "Didihkan air, beri garam dan baking soda. Rebus nangka dan kacang merah bersamaan. Warna merah pekat akan melekat ke nangka. Jika sudah empuk, angkat dan tiriskan. Untuk nangka, saya potong2 lagi kecil2. Karna saya beli nangka yg udah kupas di pasar."
- "Sambil potong2 nangka, didihkan air untuk rebus telur. Setelah mendidih, rebus selama 5-7menit. Angkat, dinginkan."
- "Panaskan sedikit minyak, tumis bumbu halus, beri sedikit air, aduk dan tambahkan santan juga bumbu lain. Aduk rata hingga mendidih. Lalu masukkan nangka dan kacang merah. Aduk rata, tes rasa."
- "Kupas telur rebus, masukkan ke dalam gudeg dan biarkan mendidih hingga kuah menyusut. Siap disajikan. Di jamin maknyosos.. lezatoss.."
- "Bawain temen kantor, tadi 1cup penuh, ini habis maem, dia cemil."
categories:
- Recipe
tags:
- 130
- gudeg
- jogja

katakunci: 130 gudeg jogja 
nutrition: 251 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Lunch

---


![130. Gudeg Jogja (pake Kacang Merah)](https://img-global.cpcdn.com/recipes/a9ce50a808944c31/751x532cq70/130-gudeg-jogja-pake-kacang-merah-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang setidaknya kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti 130. gudeg jogja (pake kacang merah) yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Kita

Kedekatan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak 130. Gudeg Jogja (pake Kacang Merah) untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda contoh salah satunya 130. gudeg jogja (pake kacang merah) yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep 130. gudeg jogja (pake kacang merah) tanpa harus bersusah payah.
Seperti resep 130. Gudeg Jogja (pake Kacang Merah) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 23 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat 130. Gudeg Jogja (pake Kacang Merah):

1. Jangan lupa 1/2 kg nangka kupas
1. Dibutuhkan 4 butir telur rebus
1. Harap siapkan Segenggam kacang merah
1. Diperlukan Secukupnya air rebusan nangka dan kacang merah
1. Harap siapkan 1 sdt baking soda dan garam
1. Harus ada  Bumbu halus:
1. Tambah 5 bh bamer
1. Dibutuhkan 2 bh baput
1. Tambah 3 biji kemiri
1. Jangan lupa 1/3 sdt ketumbar bubuk
1. Tambah 1/3 sdt merica bubuk
1. Dibutuhkan 1 ruas kencur
1. Diperlukan 7 biji cabe merah keriting
1. Dibutuhkan  Bumbu lain:
1. Diperlukan 2 lbr daun salam
1. Dibutuhkan 3 lbr daun jeruk
1. Dibutuhkan 1/2 tangkai serai geprek (skip, saya lagi gak ada stock)
1. Harap siapkan 1 ruas lengkuas geprek
1. Tambah 1 butir gula merah (kecil bulat)
1. Diperlukan 2 sdm kecap manis
1. Jangan lupa 65 ml santan Kara
1. Harap siapkan Secukupnya air, garam dan kaldu daging (saya pakai Masako)
1. Harus ada  Minyak untuk numis




<!--inarticleads2-->

##### Instruksi membuat  130. Gudeg Jogja (pake Kacang Merah):

1. Didihkan air, beri garam dan baking soda. Rebus nangka dan kacang merah bersamaan. Warna merah pekat akan melekat ke nangka. Jika sudah empuk, angkat dan tiriskan. Untuk nangka, saya potong2 lagi kecil2. Karna saya beli nangka yg udah kupas di pasar.
1. Sambil potong2 nangka, didihkan air untuk rebus telur. Setelah mendidih, rebus selama 5-7menit. Angkat, dinginkan.
1. Panaskan sedikit minyak, tumis bumbu halus, beri sedikit air, aduk dan tambahkan santan juga bumbu lain. Aduk rata hingga mendidih. Lalu masukkan nangka dan kacang merah. Aduk rata, tes rasa.
1. Kupas telur rebus, masukkan ke dalam gudeg dan biarkan mendidih hingga kuah menyusut. Siap disajikan. Di jamin maknyosos.. lezatoss..
1. Bawain temen kantor, tadi 1cup penuh, ini habis maem, dia cemil.




Demikianlah cara membuat 130. gudeg jogja (pake kacang merah) yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
