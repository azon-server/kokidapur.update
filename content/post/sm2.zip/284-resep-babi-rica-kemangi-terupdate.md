---
description: "Resep : Babi Rica Kemangi terupdate"
title: "Resep : Babi Rica Kemangi terupdate"
slug: 284-resep-babi-rica-kemangi-terupdate
date: 2020-09-19T08:57:30.927Z
image: https://img-global.cpcdn.com/recipes/a234b376389854b7/751x532cq70/babi-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a234b376389854b7/751x532cq70/babi-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a234b376389854b7/751x532cq70/babi-rica-kemangi-foto-resep-utama.jpg
author: Winifred Aguilar
ratingvalue: 4.4
reviewcount: 28692
recipeingredient:
- "1/2 kg daging babi bagian perut samchan  daging merahnya kalo saya campurbisa diganti dengan daging ayam"
- "2 siung bawang putih geprek utk merebus daging"
- "2 lembar daun salam utk merebus daging"
- "2 siung bawang merah iris"
- "2 siung bawang putih iris"
- "2 batang sereh ambil putihnya geprek"
- "4 lembar daun jeruk potong tulang tengahnya"
- "1 buah tomat irissesuai selera"
- "1 tangkai daun bawang iris"
- "2 ikat daun kemangisesuai selera optional"
- "1 sdm gula"
- "1 sdm garam"
- "1 sdm penyedap jamur totolebisa penyedap rasa yg lain"
- "1 sendok sayur minyak untuk menumis"
- " Bumbu Halus"
- "4 siung bawang merah"
- "2 siung bawang putih"
- "5 buah cabe merah besarcabe keriting"
- "7 buah cabe rawit merahsesuai selera"
- "2 cm jahe"
- "2 cm lengkuas"
recipeinstructions:
- "Langkah pertama cuci daging babi sampai bersih lalu beri perasan jeruk nipis biarkan kurang lebih 15 menit lalu cuci kembali. Lalu rebus dengan bawang putih geprek, daun salam &amp; sedikit garam. Masak sampai setengah matang &amp; sisihkan."
- "Tumis bawang putih &amp; bawang merah iris sampai wangi lalu masukkan bumbu halus, sereh geprek &amp; daun jeruk masak sampai matang lalu masukkan daging babi yg sudah di rebus setengah matang, aduk-aduk sampai merata lalu tuangkan air kurang lebih 500ml."
- "Masak hingga mendidih lalu koreksi rasa, beri garam, gula &amp; penyedap rasa. Masak kembali sampai air surut dan daging matang."
- "Setelah daging matang &amp; air sudah mulai surut, masukkan tomat, daun bawang &amp; daun kemangi. Aduk rata, angkat, lalu hidangkan."
categories:
- Recipe
tags:
- babi
- rica
- kemangi

katakunci: babi rica kemangi 
nutrition: 298 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Lunch

---


![Babi Rica Kemangi](https://img-global.cpcdn.com/recipes/a234b376389854b7/751x532cq70/babi-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan enak. Ciri khas masakan Indonesia babi rica kemangi yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga bisa diperoleh dengan cara sederhana. Diantaranya adalah memasak Babi Rica Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang bisa anda contoh salah satunya babi rica kemangi yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep babi rica kemangi tanpa harus bersusah payah.
Berikut ini resep Babi Rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 21 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Babi Rica Kemangi:

1. Tambah 1/2 kg daging babi bagian perut (samchan) + daging merahnya (kalo saya campur)/bisa diganti dengan daging ayam
1. Dibutuhkan 2 siung bawang putih geprek utk merebus daging
1. Harap siapkan 2 lembar daun salam utk merebus daging
1. Harap siapkan 2 siung bawang merah iris
1. Harus ada 2 siung bawang putih iris
1. Diperlukan 2 batang sereh ambil putihnya, geprek
1. Diperlukan 4 lembar daun jeruk potong tulang tengahnya
1. Siapkan 1 buah tomat iris/sesuai selera
1. Jangan lupa 1 tangkai daun bawang iris
1. Tambah 2 ikat daun kemangi/sesuai selera (optional)
1. Harap siapkan 1 sdm gula
1. Dibutuhkan 1 sdm garam
1. Siapkan 1 sdm penyedap jamur (totole)/bisa penyedap rasa yg lain
1. Harus ada 1 sendok sayur minyak untuk menumis
1. Dibutuhkan  Bumbu Halus:
1. Harus ada 4 siung bawang merah
1. Diperlukan 2 siung bawang putih
1. Dibutuhkan 5 buah cabe merah besar/cabe keriting
1. Tambah 7 buah cabe rawit merah/sesuai selera
1. Siapkan 2 cm jahe
1. Jangan lupa 2 cm lengkuas




<!--inarticleads2-->

##### Bagaimana membuat  Babi Rica Kemangi:

1. Langkah pertama cuci daging babi sampai bersih lalu beri perasan jeruk nipis biarkan kurang lebih 15 menit lalu cuci kembali. Lalu rebus dengan bawang putih geprek, daun salam &amp; sedikit garam. Masak sampai setengah matang &amp; sisihkan.
1. Tumis bawang putih &amp; bawang merah iris sampai wangi lalu masukkan bumbu halus, sereh geprek &amp; daun jeruk masak sampai matang lalu masukkan daging babi yg sudah di rebus setengah matang, aduk-aduk sampai merata lalu tuangkan air kurang lebih 500ml.
1. Masak hingga mendidih lalu koreksi rasa, beri garam, gula &amp; penyedap rasa. Masak kembali sampai air surut dan daging matang.
1. Setelah daging matang &amp; air sudah mulai surut, masukkan tomat, daun bawang &amp; daun kemangi. Aduk rata, angkat, lalu hidangkan.




Demikianlah cara membuat babi rica kemangi yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
