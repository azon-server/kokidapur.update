---
description: "Panduan untuk membuat 11. Rusuk babi masak garo rica khas Manado Teruji"
title: "Panduan untuk membuat 11. Rusuk babi masak garo rica khas Manado Teruji"
slug: 242-panduan-untuk-membuat-11-rusuk-babi-masak-garo-rica-khas-manado-teruji
date: 2020-12-22T10:01:18.390Z
image: https://img-global.cpcdn.com/recipes/72f34c60619243b0/751x532cq70/11-rusuk-babi-masak-garo-rica-khas-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/72f34c60619243b0/751x532cq70/11-rusuk-babi-masak-garo-rica-khas-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/72f34c60619243b0/751x532cq70/11-rusuk-babi-masak-garo-rica-khas-manado-foto-resep-utama.jpg
author: Owen Holloway
ratingvalue: 4.2
reviewcount: 28061
recipeingredient:
- " Bahanbahan"
- "1/2 kg rusukdaging babi bisa diganti ikan tuna dll"
- "3 sdm garam"
- "3 bh lemon"
- " Bumbubumbu dan rempah"
- "1 raup cabe rawit sesuaikan dengan selera"
- "3 bji cabe merah panjang"
- "8 siung bawang merah"
- "3 siung bawang putih"
- "1 ruas jahe"
- "3 btr biji kemiri"
- "1 btg serai"
- "150 ml minyak untuk tumis"
- "3 lbr daun jeruk"
- "1 lbr daun pandan option"
- "2 bh tomat iris"
- "1 sct kaldu bubuk saya royko"
- "1 sdt kunyit bubuk saya desaku"
recipeinstructions:
- "Siapkan bahan. Marinasi daging babi/ikan dengan garam dan lemon kira² 30 menit. Potong 2 bagian batang serai. Iris² bagian bawah dan memarkan bagian atasnya dan ikat simpul. Iris² 5 siung bawang merah."
- "Panaskan minyak dan tumis bawang merah hingga berubah warna kecoklatan, masukkan serai dan daun jeruk. Tumis hingga bawang merah berubah warna coklat tua. Haluskan cabe merah, cabe rawit, bawang merah, bawang putih, kemiri, jahe, serai."
- "Masukkan bumbu halus dan tomat iris. Masak sebentar, tambahkan kaldu bubuk dan kunyit bubuk"
- "Masukkan daging babi, tambahkan air sedikit kecilkan api, aduk² sedikit dan tutup dengan penutup panci sebentar saja."
- "Buka penutup, aduk lagi dan biarkan masak sampai air sedikit susut. Cek daging, jika daging belum empuk, tambahkan lagi air dan masak hingga daging empuk. Cek rasa. Angkat dan sajikan. Selamat mencoba😊"
categories:
- Recipe
tags:
- 11
- rusuk
- babi

katakunci: 11 rusuk babi 
nutrition: 127 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dessert

---


![11. Rusuk babi masak garo rica khas Manado](https://img-global.cpcdn.com/recipes/72f34c60619243b0/751x532cq70/11-rusuk-babi-masak-garo-rica-khas-manado-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti 11. rusuk babi masak garo rica khas manado yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan keistimewahan yang merupakan keragaman Kita



Kedekatan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah membuat makanan 11. Rusuk babi masak garo rica khas Manado untuk orang di rumah. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang dapat anda coba salah satunya 11. rusuk babi masak garo rica khas manado yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep 11. rusuk babi masak garo rica khas manado tanpa harus bersusah payah.
Berikut ini resep 11. Rusuk babi masak garo rica khas Manado yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 11. Rusuk babi masak garo rica khas Manado:

1. Jangan lupa  Bahan-bahan
1. Jangan lupa 1/2 kg rusuk/daging babi (bisa diganti ikan tuna dll)
1. Harap siapkan 3 sdm garam
1. Tambah 3 bh lemon
1. Harus ada  Bumbu-bumbu dan rempah
1. Tambah 1 raup cabe rawit (sesuaikan dengan selera)
1. Harap siapkan 3 bji cabe merah panjang
1. Tambah 8 siung bawang merah
1. Harap siapkan 3 siung bawang putih
1. Harus ada 1 ruas jahe
1. Diperlukan 3 btr biji kemiri
1. Tambah 1 btg serai
1. Jangan lupa 150 ml minyak untuk tumis
1. Tambah 3 lbr daun jeruk
1. Diperlukan 1 lbr daun pandan (option)
1. Dibutuhkan 2 bh tomat iris²
1. Harus ada 1 sct kaldu bubuk (saya royko)
1. Tambah 1 sdt kunyit bubuk (saya desaku)




<!--inarticleads2-->

##### Langkah membuat  11. Rusuk babi masak garo rica khas Manado:

1. Siapkan bahan. Marinasi daging babi/ikan dengan garam dan lemon kira² 30 menit. Potong 2 bagian batang serai. Iris² bagian bawah dan memarkan bagian atasnya dan ikat simpul. Iris² 5 siung bawang merah.
1. Panaskan minyak dan tumis bawang merah hingga berubah warna kecoklatan, masukkan serai dan daun jeruk. Tumis hingga bawang merah berubah warna coklat tua. Haluskan cabe merah, cabe rawit, bawang merah, bawang putih, kemiri, jahe, serai.
1. Masukkan bumbu halus dan tomat iris. Masak sebentar, tambahkan kaldu bubuk dan kunyit bubuk
1. Masukkan daging babi, tambahkan air sedikit kecilkan api, aduk² sedikit dan tutup dengan penutup panci sebentar saja.
1. Buka penutup, aduk lagi dan biarkan masak sampai air sedikit susut. Cek daging, jika daging belum empuk, tambahkan lagi air dan masak hingga daging empuk. Cek rasa. Angkat dan sajikan. Selamat mencoba😊




Demikianlah cara membuat 11. rusuk babi masak garo rica khas manado yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat simple dan cepat, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
