---
description: "Cara menyiapakan Babi Rica Manado Teruji"
title: "Cara menyiapakan Babi Rica Manado Teruji"
slug: 241-cara-menyiapakan-babi-rica-manado-teruji
date: 2020-10-29T19:18:59.117Z
image: https://img-global.cpcdn.com/recipes/f50dfc3503a4710c/751x532cq70/babi-rica-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f50dfc3503a4710c/751x532cq70/babi-rica-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f50dfc3503a4710c/751x532cq70/babi-rica-manado-foto-resep-utama.jpg
author: Sarah Swanson
ratingvalue: 4.6
reviewcount: 31612
recipeingredient:
- "500 gr daging babi tenderloin jika suka yang berlemak bisa di mix dengan samcan"
- "1 lbr daun pandan diikat"
- "2 siung bawang putih di geprek"
- "Secukupnya daun salam"
- "2 ikat daun kemangi"
- "5 lbr daun jeruk"
- "2 batang serai"
- "1 1/2 tsp garam"
- "2 tsp gula pasir"
- "1 tsp merica bubuk"
- "500 ml air"
- " Bumbu Halus"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "1 ruas jari kunyit"
- "2 cm lengkuas"
- "2 cm jahe"
- "15 bh cabai merah keriting"
- "15 bh cabai rawit orange"
recipeinstructions:
- "Lumuri daging babi dengan perasan jeruk nipis selama 15 menit, lalu ambil 2 siung bawang putih digeprek. Setelah 15 menit, rebus daging babi dengan 2 siung bawang putih yg sudah digeprek serta daun salam. Rebus hingga setengah matang"
- "Sambil menunggu rebusan daging, blender semua bahan bumbu halus lalu tumis hinga harum. Masukan serai, daun jeruk, daun pandan, lalu masak sebentar hingga berubah warna"
- "Masukan daging babi, lalu aduk hingga daging dibaluri bumbu secara merata, lalu tambahkan 500ml liter air, aduk lalu tutup panci, masak dengan api sedang hingga air menyusut"
- "Masukan garam, gula, merica lalu aduk-aduk kembali hingga merata, terakhir masukan daun kemangi, aduk sebentar saja, lalu matikan kompor dan sajikan"
categories:
- Recipe
tags:
- babi
- rica
- manado

katakunci: babi rica manado 
nutrition: 142 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Dinner

---


![Babi Rica Manado](https://img-global.cpcdn.com/recipes/f50dfc3503a4710c/751x532cq70/babi-rica-manado-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita lestarikan karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti babi rica manado yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan ciri khas yang merupakan keragaman Nusantara

Keharmonisan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Babi Rica Manado untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang dapat anda contoh salah satunya babi rica manado yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya saat ini kamu bisa dengan gampang menemukan resep babi rica manado tanpa harus bersusah payah.
Berikut ini resep Babi Rica Manado yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Babi Rica Manado:

1. Siapkan 500 gr daging babi tenderloin (jika suka yang berlemak bisa di mix dengan samcan)
1. Jangan lupa 1 lbr daun pandan diikat
1. Jangan lupa 2 siung bawang putih di geprek
1. Tambah Secukupnya daun salam
1. Tambah 2 ikat daun kemangi
1. Diperlukan 5 lbr daun jeruk
1. Siapkan 2 batang serai
1. Diperlukan 1 1/2 tsp garam
1. Harus ada 2 tsp gula pasir
1. Diperlukan 1 tsp merica bubuk
1. Jangan lupa 500 ml air
1. Diperlukan  Bumbu Halus
1. Tambah 10 siung bawang merah
1. Siapkan 5 siung bawang putih
1. Harus ada 1 ruas jari kunyit
1. Tambah 2 cm lengkuas
1. Harap siapkan 2 cm jahe
1. Tambah 15 bh cabai merah keriting
1. Tambah 15 bh cabai rawit orange




<!--inarticleads2-->

##### Instruksi membuat  Babi Rica Manado:

1. Lumuri daging babi dengan perasan jeruk nipis selama 15 menit, lalu ambil 2 siung bawang putih digeprek. Setelah 15 menit, rebus daging babi dengan 2 siung bawang putih yg sudah digeprek serta daun salam. Rebus hingga setengah matang
1. Sambil menunggu rebusan daging, blender semua bahan bumbu halus lalu tumis hinga harum. Masukan serai, daun jeruk, daun pandan, lalu masak sebentar hingga berubah warna
1. Masukan daging babi, lalu aduk hingga daging dibaluri bumbu secara merata, lalu tambahkan 500ml liter air, aduk lalu tutup panci, masak dengan api sedang hingga air menyusut
1. Masukan garam, gula, merica lalu aduk-aduk kembali hingga merata, terakhir masukan daun kemangi, aduk sebentar saja, lalu matikan kompor dan sajikan




Demikianlah cara membuat babi rica manado yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat gampang dan teruji, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
