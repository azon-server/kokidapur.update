---
description: "Resep : Babi Rica-Rica Kemangi (non-halal) Teruji"
title: "Resep : Babi Rica-Rica Kemangi (non-halal) Teruji"
slug: 295-resep-babi-rica-rica-kemangi-non-halal-teruji
date: 2020-11-10T03:46:23.376Z
image: https://img-global.cpcdn.com/recipes/5d77fb843781b4e7/751x532cq70/babi-rica-rica-kemangi-non-halal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5d77fb843781b4e7/751x532cq70/babi-rica-rica-kemangi-non-halal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5d77fb843781b4e7/751x532cq70/babi-rica-rica-kemangi-non-halal-foto-resep-utama.jpg
author: Marie Joseph
ratingvalue: 4.3
reviewcount: 8280
recipeingredient:
- "400 gr daging babi potong sesuai selera"
- "1 batang sereh geprek"
- "1 batang daun bawang iris halus"
- "1 lembar daun pandan ikat"
- "1 lembar daun kunyit potong 4"
- "2 lembar daun jeruk sobek"
- "1 genggam daun kemangi"
- "1/2 sdt kunyit bubuk"
- "1 sdm minyak goreng"
- "secukupnya Garam"
- "secukupnya Air"
- " Bumbu halus"
- "10 buah cabe rawit"
- "2 buah cabe keriting"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "3 butir kemiri"
- "1 cm jahe"
recipeinstructions:
- "Siapkan bahan dan bumbu"
- "Panaskan minyak dalam wajan dan tumis bumbu halus sampai wangi kemudian masukkan sereh, daun pandan, daun kunyit, daun jeruk. Tumis sampai layu."
- "Kemudian masukkan daging babinya dan masukkan kunyit bubuk. Aduk rata, diamkan sampai muncul minyak dari daging. Dan masukkan air dan tutup. Masak sampai daging lunak."
- "Masukkan daun bawang, tambahkan garam dan koreksi rasa. Didihkan selama 5 menit, lalu masukkan daun kemangi dan campur rata. Angkat dan hidangkan."
categories:
- Recipe
tags:
- babi
- ricarica
- kemangi

katakunci: babi ricarica kemangi 
nutrition: 107 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT50M"
recipeyield: "1"
recipecategory: Dessert

---


![Babi Rica-Rica Kemangi (non-halal)](https://img-global.cpcdn.com/recipes/5d77fb843781b4e7/751x532cq70/babi-rica-rica-kemangi-non-halal-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas atau renyah. Ciri makanan Nusantara babi rica-rica kemangi (non-halal) yang penuh dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Babi Rica-Rica Kemangi (non-halal) untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang dapat anda praktekkan salah satunya babi rica-rica kemangi (non-halal) yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep babi rica-rica kemangi (non-halal) tanpa harus bersusah payah.
Berikut ini resep Babi Rica-Rica Kemangi (non-halal) yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Babi Rica-Rica Kemangi (non-halal):

1. Harus ada 400 gr daging babi, potong sesuai selera
1. Diperlukan 1 batang sereh, geprek
1. Harus ada 1 batang daun bawang, iris halus
1. Harus ada 1 lembar daun pandan, ikat
1. Diperlukan 1 lembar daun kunyit, potong 4
1. Dibutuhkan 2 lembar daun jeruk, sobek
1. Jangan lupa 1 genggam daun kemangi
1. Diperlukan 1/2 sdt kunyit bubuk
1. Dibutuhkan 1 sdm minyak goreng
1. Tambah secukupnya Garam
1. Diperlukan secukupnya Air
1. Harap siapkan  Bumbu halus:
1. Tambah 10 buah cabe rawit
1. Harus ada 2 buah cabe keriting
1. Tambah 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Dibutuhkan 3 butir kemiri
1. Siapkan 1 cm jahe




<!--inarticleads2-->

##### Cara membuat  Babi Rica-Rica Kemangi (non-halal):

1. Siapkan bahan dan bumbu
1. Panaskan minyak dalam wajan dan tumis bumbu halus sampai wangi kemudian masukkan sereh, daun pandan, daun kunyit, daun jeruk. Tumis sampai layu.
1. Kemudian masukkan daging babinya dan masukkan kunyit bubuk. Aduk rata, diamkan sampai muncul minyak dari daging. Dan masukkan air dan tutup. Masak sampai daging lunak.
1. Masukkan daun bawang, tambahkan garam dan koreksi rasa. Didihkan selama 5 menit, lalu masukkan daun kemangi dan campur rata. Angkat dan hidangkan.




Demikianlah cara membuat babi rica-rica kemangi (non-halal) yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan cepat, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
