---
description: "Bagaimana membuat Babi Rica-Rica &amp;amp; Kemangi Cepat"
title: "Bagaimana membuat Babi Rica-Rica &amp;amp; Kemangi Cepat"
slug: 292-bagaimana-membuat-babi-rica-rica-and-amp-kemangi-cepat
date: 2020-11-01T00:32:16.798Z
image: https://img-global.cpcdn.com/recipes/a8448d31351bbf2e/751x532cq70/babi-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a8448d31351bbf2e/751x532cq70/babi-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a8448d31351bbf2e/751x532cq70/babi-rica-rica-kemangi-foto-resep-utama.jpg
author: Isaiah Reed
ratingvalue: 4.3
reviewcount: 33788
recipeingredient:
- "250 gr daging babi"
- "250 gr daging sancam"
- " Bumbu Halus "
- "8 siung bawang merah"
- "5 siung bawang putih"
- "10 buah cabe keriting"
- "5 buah cabe rawit"
- "2 cm jahe"
- "2 cm lengkuas"
- "1/2 sdt Kunyit bubuk"
- " Bahan Lainnya"
- "1 lembar Daun pandan ikat"
- "3 lembar daun jeruk sobek2"
- "1 ikat daun kemangi"
- "2 batang serai digeprek"
- "Secukupnya Garam Merica  sedikit gula"
recipeinstructions:
- "Potong2 daging babi dan sancam. Saya lebih suka dicampur sancam supaya hasil akhirnya agak lebih berminyak dan tidak terlalu kering."
- "Haluskan bahan-bahan yg akan dihaluskan. Lalu tumis sampai harum."
- "Masukkan bahan2 yang lain : Daun jeruk, Daun pandan &amp; Serai, Kecuali daun kemangi."
- "Setelah harumnya keluar, masukkan daging babi &amp; sancam. Masukkan air sekitar 500ml. Masak dgn api sedang sampai air menyusut. Diusahakan ditutup supaya cepat empuk. Setelah air menyusut, cek dagingnya. Sudah empuk atau belum. Kalau belum bisa ditambah air sampai daging babinya empuk."
- "Sembari menunggu dagingnya empuk, dimasukkan garam, gula &amp; merica. Masukkan daun kemangi, aduk2."
- "Setelah daging empuk, cek rasa. Angkat &amp; sajikan."
categories:
- Recipe
tags:
- babi
- ricarica
- 

katakunci: babi ricarica  
nutrition: 250 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Dessert

---


![Babi Rica-Rica &amp; Kemangi](https://img-global.cpcdn.com/recipes/a8448d31351bbf2e/751x532cq70/babi-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas dan renyah. Karasteristik makanan Nusantara babi rica-rica &amp; kemangi yang penuh dengan rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.


Keharmonisan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Babi Rica-Rica &amp; Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda coba salah satunya babi rica-rica &amp; kemangi yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep babi rica-rica &amp; kemangi tanpa harus bersusah payah.
Berikut ini resep Babi Rica-Rica &amp; Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Babi Rica-Rica &amp; Kemangi:

1. Harap siapkan 250 gr daging babi
1. Dibutuhkan 250 gr daging sancam
1. Dibutuhkan  Bumbu Halus :
1. Jangan lupa 8 siung bawang merah
1. Jangan lupa 5 siung bawang putih
1. Harap siapkan 10 buah cabe keriting
1. Dibutuhkan 5 buah cabe rawit
1. Harap siapkan 2 cm jahe
1. Harap siapkan 2 cm lengkuas
1. Diperlukan 1/2 sdt Kunyit bubuk
1. Jangan lupa  Bahan Lainnya:
1. Harap siapkan 1 lembar Daun pandan, ikat
1. Dibutuhkan 3 lembar daun jeruk, sobek2
1. Jangan lupa 1 ikat daun kemangi
1. Diperlukan 2 batang serai digeprek
1. Diperlukan Secukupnya Garam, Merica &amp; sedikit gula




<!--inarticleads2-->

##### Instruksi membuat  Babi Rica-Rica &amp; Kemangi:

1. Potong2 daging babi dan sancam. Saya lebih suka dicampur sancam supaya hasil akhirnya agak lebih berminyak dan tidak terlalu kering.
1. Haluskan bahan-bahan yg akan dihaluskan. Lalu tumis sampai harum.
1. Masukkan bahan2 yang lain : Daun jeruk, Daun pandan &amp; Serai, Kecuali daun kemangi.
1. Setelah harumnya keluar, masukkan daging babi &amp; sancam. Masukkan air sekitar 500ml. Masak dgn api sedang sampai air menyusut. Diusahakan ditutup supaya cepat empuk. Setelah air menyusut, cek dagingnya. Sudah empuk atau belum. Kalau belum bisa ditambah air sampai daging babinya empuk.
1. Sembari menunggu dagingnya empuk, dimasukkan garam, gula &amp; merica. Masukkan daun kemangi, aduk2.
1. Setelah daging empuk, cek rasa. Angkat &amp; sajikan.




Demikianlah cara membuat babi rica-rica &amp; kemangi yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
