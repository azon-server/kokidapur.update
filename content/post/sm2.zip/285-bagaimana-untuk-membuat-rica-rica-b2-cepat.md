---
description: "Bagaimana untuk membuat Rica-rica b2 Cepat"
title: "Bagaimana untuk membuat Rica-rica b2 Cepat"
slug: 285-bagaimana-untuk-membuat-rica-rica-b2-cepat
date: 2020-11-10T08:16:00.915Z
image: https://img-global.cpcdn.com/recipes/9a4dcfb74901d395/751x532cq70/rica-rica-b2-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9a4dcfb74901d395/751x532cq70/rica-rica-b2-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9a4dcfb74901d395/751x532cq70/rica-rica-b2-foto-resep-utama.jpg
author: Willie Burns
ratingvalue: 4
reviewcount: 4936
recipeingredient:
- "1 kg daging b2 diiris sesuai selera"
- " Kemangi sesuai selera kebetulan stok di kebun habis "
- " Minyak untuk menumis"
- " Bumbu halus"
- " Bumbu ungkep beli di pasar jahe kunyit duo bawang lengkuas"
- "1 batang Serai"
- "secukupnya Merica"
- " Daun Salam tidak dihaluskan"
- "secukupnya Garam"
- "1 ons Cabe rawit setan"
- "1/2 ons Cabe rawit hijau"
recipeinstructions:
- "Haluskan merica, cabe, Dan garam. Campurkan dengan bumbu ungkep halus yang sudah dibeli."
- "Panaskan minyak untuk menumis."
- "Tumis bumbu halus, campurkan dengan serai dikeprek Dan daun Salam sampai harum"
- "Masukkan daging, beri air secukupnya. Tambahkan garam dan kaldu totole secukupnya."
- "Aduk rata, tutup kuali biarkan daging empuk sekitar setengah jam sembari diaduk sesekali."
- "Koreksi rasa dan kekenyalan daging"
- "Masak hingga matang, angkat dan siap disajikan."
categories:
- Recipe
tags:
- ricarica
- b2

katakunci: ricarica b2 
nutrition: 148 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Lunch

---


![Rica-rica b2](https://img-global.cpcdn.com/recipes/9a4dcfb74901d395/751x532cq70/rica-rica-b2-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas dan renyah. Ciri makanan Nusantara rica-rica b2 yang penuh dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Rica-rica b2 untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang bisa anda buat salah satunya rica-rica b2 yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep rica-rica b2 tanpa harus bersusah payah.
Berikut ini resep Rica-rica b2 yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Rica-rica b2:

1. Diperlukan 1 kg daging b2, diiris sesuai selera
1. Siapkan  Kemangi sesuai selera (kebetulan stok di kebun habis 😭)
1. Siapkan  Minyak untuk menumis
1. Harus ada  Bumbu halus
1. Siapkan  Bumbu ungkep beli di pasar (jahe, kunyit, duo bawang, lengkuas)
1. Siapkan 1 batang Serai
1. Dibutuhkan secukupnya Merica
1. Tambah  Daun Salam (tidak dihaluskan)
1. Jangan lupa secukupnya Garam
1. Harap siapkan 1 ons Cabe rawit setan
1. Harap siapkan 1/2 ons Cabe rawit hijau




<!--inarticleads2-->

##### Cara membuat  Rica-rica b2:

1. Haluskan merica, cabe, Dan garam. Campurkan dengan bumbu ungkep halus yang sudah dibeli.
1. Panaskan minyak untuk menumis.
1. Tumis bumbu halus, campurkan dengan serai dikeprek Dan daun Salam sampai harum
1. Masukkan daging, beri air secukupnya. Tambahkan garam dan kaldu totole secukupnya.
1. Aduk rata, tutup kuali biarkan daging empuk sekitar setengah jam sembari diaduk sesekali.
1. Koreksi rasa dan kekenyalan daging
1. Masak hingga matang, angkat dan siap disajikan.




Demikianlah cara membuat rica-rica b2 yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan cepat, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
