---
description: "Cara untuk menyiapakan Babi Rica (Woku) terupdate"
title: "Cara untuk menyiapakan Babi Rica (Woku) terupdate"
slug: 356-cara-untuk-menyiapakan-babi-rica-woku-terupdate
date: 2021-01-05T04:51:53.112Z
image: https://img-global.cpcdn.com/recipes/a697f11cda31e1ea/751x532cq70/babi-rica-woku-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a697f11cda31e1ea/751x532cq70/babi-rica-woku-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a697f11cda31e1ea/751x532cq70/babi-rica-woku-foto-resep-utama.jpg
author: Shane Phillips
ratingvalue: 4.8
reviewcount: 21730
recipeingredient:
- " bahan utama "
- "1 kg Daging Babi Belly potong dadu"
- " Bahan 1 "
- "10 btg Daun Bawang slice"
- "4 btg Serai sebagian di slice dan sebagian biarkan utuh"
- "10 lbr Daun Jeruk sebagian di slice dan sebagian biarkan utuh"
- "1 lbr Daun Kunyit"
- "2 lbr Daun Pandan"
- " Bahan 2  Haluskan"
- "200 gr Cabe Rawit Merah optional"
- "100 gr Cabe Rawit Hijau"
- "6 btr Kemiri"
- "2 ruas Jahe 10cm"
- "1 ruas Kunyit"
- "2 ruas Lengkuas10cm"
- "2 sdt Lada Putih"
- " Bahan tambahan "
- "3 buah Jeruk Nipis"
- "5 tangkai Kemangi ambil daunnya"
- "5 sdm Minyak Kelapa"
- " Garam"
- " Air"
recipeinstructions:
- "(cara pertama) 1. Rendam daging Babi dengan perasan jeruk nipis dan garam ± 30 menit. 2. Tumis Bahan 1 sampai aromanya keluar. 3. Masukan Bahan 2 dan tumis sampai bumbunya setengah matang. 4. Masukan daging Babi setelah agak matang,tambahkan air,tutup dan masak sampai matang. 5. Cicipi dan tambahkan garam. 6. Masukan daun kemangi dan angkat."
- "(cara kedua) 1. Rendam daging Babi dengan perasan jeruk nipis dan garam ± 30 menit. 2. Campur daging Babi dengan Semua Bahan (bahan 1 dan 2). 3. Masukan minyak di wajan dan masak semua bahan. 4. Setelah agak mengering,tambahkan air dan tutup. Tunggu sampai matang. 5. Cicipi dan tambahkan garam. 6. Masukan daun kemangi dan angkat."
categories:
- Recipe
tags:
- babi
- rica
- woku

katakunci: babi rica woku 
nutrition: 255 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT46M"
recipeyield: "4"
recipecategory: Lunch

---


![Babi Rica (Woku)](https://img-global.cpcdn.com/recipes/a697f11cda31e1ea/751x532cq70/babi-rica-woku-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau empuk. Ciri khas masakan Nusantara babi rica (woku) yang kaya dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Babi Rica (Woku) untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang dapat anda buat salah satunya babi rica (woku) yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep babi rica (woku) tanpa harus bersusah payah.
Seperti resep Babi Rica (Woku) yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 2 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Babi Rica (Woku):

1. Harus ada  bahan utama :
1. Dibutuhkan 1 kg Daging Babi (Belly) potong dadu
1. Tambah  Bahan 1 :
1. Tambah 10 btg Daun Bawang (slice)
1. Jangan lupa 4 btg Serai (sebagian di slice dan sebagian biarkan utuh)
1. Siapkan 10 lbr Daun Jeruk (sebagian di slice dan sebagian biarkan utuh)
1. Siapkan 1 lbr Daun Kunyit
1. Harap siapkan 2 lbr Daun Pandan
1. Dibutuhkan  Bahan 2 : Haluskan
1. Harus ada 200 gr Cabe Rawit Merah (optional)
1. Tambah 100 gr Cabe Rawit Hijau
1. Jangan lupa 6 btr Kemiri
1. Harus ada 2 ruas Jahe (10cm)
1. Harus ada 1 ruas Kunyit
1. Harus ada 2 ruas Lengkuas(10cm)
1. Harus ada 2 sdt Lada Putih
1. Diperlukan  Bahan tambahan :
1. Siapkan 3 buah Jeruk Nipis
1. Siapkan 5 tangkai Kemangi (ambil daunnya)
1. Harap siapkan 5 sdm Minyak Kelapa
1. Diperlukan  Garam
1. Siapkan  Air




<!--inarticleads2-->

##### Instruksi membuat  Babi Rica (Woku):

1. (cara pertama) 1. Rendam daging Babi dengan perasan jeruk nipis dan garam ± 30 menit. 2. Tumis Bahan 1 sampai aromanya keluar. 3. Masukan Bahan 2 dan tumis sampai bumbunya setengah matang. 4. Masukan daging Babi setelah agak matang,tambahkan air,tutup dan masak sampai matang. 5. Cicipi dan tambahkan garam. 6. Masukan daun kemangi dan angkat.
1. (cara kedua) 1. Rendam daging Babi dengan perasan jeruk nipis dan garam ± 30 menit. 2. Campur daging Babi dengan Semua Bahan (bahan 1 dan 2). 3. Masukan minyak di wajan dan masak semua bahan. 4. Setelah agak mengering,tambahkan air dan tutup. Tunggu sampai matang. 5. Cicipi dan tambahkan garam. 6. Masukan daun kemangi dan angkat.




Demikianlah cara membuat babi rica (woku) yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan teruji, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
