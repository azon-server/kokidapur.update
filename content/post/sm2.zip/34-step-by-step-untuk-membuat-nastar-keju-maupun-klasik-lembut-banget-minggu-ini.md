---
description: "Step-by-Step untuk membuat Nastar keju maupun klasik lembut banget minggu ini"
title: "Step-by-Step untuk membuat Nastar keju maupun klasik lembut banget minggu ini"
slug: 34-step-by-step-untuk-membuat-nastar-keju-maupun-klasik-lembut-banget-minggu-ini
date: 2020-11-10T16:14:47.468Z
image: https://img-global.cpcdn.com/recipes/4000e75e9ce2dbe9/751x532cq70/nastar-keju-maupun-klasik-lembut-banget-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4000e75e9ce2dbe9/751x532cq70/nastar-keju-maupun-klasik-lembut-banget-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4000e75e9ce2dbe9/751x532cq70/nastar-keju-maupun-klasik-lembut-banget-foto-resep-utama.jpg
author: Callie Swanson
ratingvalue: 4.2
reviewcount: 46113
recipeingredient:
- "500 gr terigu pro rendah"
- "40 gr maizena"
- "50 gr gula halus"
- "3 sdm susu"
- "200 gr butter"
- "200 gr margarin"
- "4 kuning telur 2 mentah 2 rebus"
- "2 sdt vanila cair"
- "50 gr keju kraft parut"
- "50 gr cream cheese home made"
- " resep asli 50 gr keju edam dan 50 gr keju permesan"
- "secukupnya keju parut utk taburan nastar keju"
- " Bahanbahan untuk selai "
- "3 buah nanas parut Saya beli yg sudah di kupas"
- "50 gr gula pasir Sesuai selera ya bisa ditambahdikurangi"
- "3 buah cengkeh"
- "3 cm kayu manis"
- " Bahanbahan utk olesan "
- "2 kuning telur Resep asli menggunakan telur omega"
- "2 sdm minyak goreng"
- "2 sdt SKM"
- "2 tetes ujung tusukgigi pewarna makanan kuning tuaSesuai selera"
recipeinstructions:
- "Mixer dg kecepatan rendah butter, margarin, telur, gula halus, vanila cair. Sebentar saja kurleb 1 menit hanya agar tercampur saja"
- "Masukkan keju parut aduk sebentar dg spatula asal tercampur saja"
- "Masukkan terigu, maizena, susu bubuk aduk kembali dg spatula hingga tercampur rata semua bahan"
- "Uleni sebentar saja dg tangan lalu masukkan kulkas kurleb 2jm. Adonan memang lembek oleh sebab itu saya masukkan kulkas dulu"
- "Ambil adonan yg besarnya sesuai selera lalu isi dg selai lalu bulatkan. Kebetulan saya ngga punya timbangan digital jadi kira2 saja"
- "Olesi tipis minyak goreng pada loyang. Tata nastar pada loyang diberi jarak"
- "Panaskan oven kurleb 30 menit. Lalu masukan loyang yg sudah terisi nastar"
- "Oven kurleb 35 menit dg api kecil ke sedang. Saya pake otang jadi tiap 10 menit loyangnya dipindah posisinya agar matang merata. Jika sudah 35 menit cek nastar apakah sudah benar2 matang kemudian diamkan dlm oven hingga oven dingin/berada pada suhu ruang. Posisi api pada saat ini sudah dimatikan ya"
- "Keluarkan nastar dari oven dinginkan hingga benar-benar dingin. Saya bisa berjam-jam bahkan saya tinggalkan di oven tp ingat dg posisi api sudah dimatikan. Biasanya saya bikin sore matangnya kn malam. Baru saya keluarkan dari oven besok paginya"
- "Jika nastar sudah dingin siap untuk dioles. Oles hingga 3x. Klo saya oles yg pertama : loyang 1 lanjut loyang 2 lanjut loyang 3. Oles ke-2 kembali ke loyang 1 dst. Oles ke-3 kembali ke loyang 1 dst. Jika nastar keju setelah dioles kutel ditaburi keju parut"
- "Masukkan kembali nastar yg sudah dioles ke oven dg api kecil ke sedang panggang kurleb 5 menit. Kembali diamkan dlm oven posisi api sudah mati. Jika sudah dingin baru dikeluarkan"
- "Masukkan toples jika nastar sudah dalam keadaan benar2 dingin"
- "Tips 1 : sangrai terigu dg menambahkan daun pandan. Jika daun pandan sudah kering berarti proses sangrai telah selesai. Menurut info yg saya tau jika terigu disangrai menjadikan adonan renyah dan tahan lama sehingga kue kering bisa awet bbrp bulan. Oia, setiap saya sangrai 1kg terigu pro rendah+4 daun pandan. Jika tepung yg sudah disangrai ingin digunakan maka tunggu hingga benar2 dingin lalu diayak ya agar halus"
- "Tips 2: adonan jika dimixer terlalu lama akan bleber saat di oven nanti. Jgn menguleni terlalu lama dan kuat dg tangan krn akan membuat kue kering akan keras nantinya"
- "Tips 3 : butter dan margarin pada saat dimixer dlm keadaan dingin, baru keluar dari kulkas"
- "Tips 4 : jika sudah cape tp adonan masih sisa bisa dimasukkan kulkas. Lanjut keesokan harinya. Saya pernah diamkan di kulkas 3 hari tanpa ditutup. Adonan aman, tetap harum, tidak jamuran"
- "Kalo saya tahap paling pertama sangrai terigu lalu rebus telur. Tunggu hingga benar-benar dingin"
- "Proses pembuatannya memang lama, butuh stamina yg fit juga, butuh kesabaran tapi sepadan dg hasilnya koq"
- "Nastar keju"
- "Nastar klasik"
categories:
- Recipe
tags:
- nastar
- keju
- maupun

katakunci: nastar keju maupun 
nutrition: 204 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Lunch

---


![Nastar keju maupun klasik lembut banget](https://img-global.cpcdn.com/recipes/4000e75e9ce2dbe9/751x532cq70/nastar-keju-maupun-klasik-lembut-banget-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti nastar keju maupun klasik lembut banget yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan keistimewahan yang merupakan keragaman Indonesia



Keharmonisan rumah tangga dapat diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Nastar keju maupun klasik lembut banget untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis makanan yang bisa anda buat salah satunya nastar keju maupun klasik lembut banget yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep nastar keju maupun klasik lembut banget tanpa harus bersusah payah.
Berikut ini resep Nastar keju maupun klasik lembut banget yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nastar keju maupun klasik lembut banget:

1. Harus ada 500 gr terigu pro rendah
1. Jangan lupa 40 gr maizena
1. Jangan lupa 50 gr gula halus
1. Siapkan 3 sdm susu
1. Tambah 200 gr butter
1. Tambah 200 gr margarin
1. Harus ada 4 kuning telur (2 mentah, 2 rebus)
1. Harus ada 2 sdt vanila cair
1. Harap siapkan 50 gr keju kraft parut
1. Harap siapkan 50 gr cream cheese home made
1. Tambah  (resep asli 50 gr keju edam dan 50 gr keju permesan)
1. Diperlukan secukupnya keju parut utk taburan nastar keju
1. Jangan lupa  Bahan-bahan untuk selai :
1. Diperlukan 3 buah nanas parut. Saya beli yg sudah di kupas
1. Tambah 50 gr gula pasir. Sesuai selera ya bisa ditambah/dikurangi
1. Harus ada 3 buah cengkeh
1. Dibutuhkan 3 cm kayu manis
1. Harus ada  Bahan-bahan utk olesan :
1. Tambah 2 kuning telur. Resep asli menggunakan telur omega
1. Dibutuhkan 2 sdm minyak goreng
1. Harus ada 2 sdt SKM
1. Harus ada 2 tetes ujung tusukgigi pewarna makanan kuning tua.Sesuai selera




<!--inarticleads2-->

##### Instruksi membuat  Nastar keju maupun klasik lembut banget:

1. Mixer dg kecepatan rendah butter, margarin, telur, gula halus, vanila cair. Sebentar saja kurleb 1 menit hanya agar tercampur saja
1. Masukkan keju parut aduk sebentar dg spatula asal tercampur saja
1. Masukkan terigu, maizena, susu bubuk aduk kembali dg spatula hingga tercampur rata semua bahan
1. Uleni sebentar saja dg tangan lalu masukkan kulkas kurleb 2jm. Adonan memang lembek oleh sebab itu saya masukkan kulkas dulu
1. Ambil adonan yg besarnya sesuai selera lalu isi dg selai lalu bulatkan. Kebetulan saya ngga punya timbangan digital jadi kira2 saja
1. Olesi tipis minyak goreng pada loyang. Tata nastar pada loyang diberi jarak
1. Panaskan oven kurleb 30 menit. Lalu masukan loyang yg sudah terisi nastar
1. Oven kurleb 35 menit dg api kecil ke sedang. Saya pake otang jadi tiap 10 menit loyangnya dipindah posisinya agar matang merata. Jika sudah 35 menit cek nastar apakah sudah benar2 matang kemudian diamkan dlm oven hingga oven dingin/berada pada suhu ruang. Posisi api pada saat ini sudah dimatikan ya
1. Keluarkan nastar dari oven dinginkan hingga benar-benar dingin. Saya bisa berjam-jam bahkan saya tinggalkan di oven tp ingat dg posisi api sudah dimatikan. Biasanya saya bikin sore matangnya kn malam. Baru saya keluarkan dari oven besok paginya
1. Jika nastar sudah dingin siap untuk dioles. Oles hingga 3x. Klo saya oles yg pertama : loyang 1 lanjut loyang 2 lanjut loyang 3. Oles ke-2 kembali ke loyang 1 dst. Oles ke-3 kembali ke loyang 1 dst. Jika nastar keju setelah dioles kutel ditaburi keju parut
1. Masukkan kembali nastar yg sudah dioles ke oven dg api kecil ke sedang panggang kurleb 5 menit. Kembali diamkan dlm oven posisi api sudah mati. Jika sudah dingin baru dikeluarkan
1. Masukkan toples jika nastar sudah dalam keadaan benar2 dingin
1. Tips 1 : sangrai terigu dg menambahkan daun pandan. Jika daun pandan sudah kering berarti proses sangrai telah selesai. Menurut info yg saya tau jika terigu disangrai menjadikan adonan renyah dan tahan lama sehingga kue kering bisa awet bbrp bulan. Oia, setiap saya sangrai 1kg terigu pro rendah+4 daun pandan. Jika tepung yg sudah disangrai ingin digunakan maka tunggu hingga benar2 dingin lalu diayak ya agar halus
1. Tips 2: adonan jika dimixer terlalu lama akan bleber saat di oven nanti. Jgn menguleni terlalu lama dan kuat dg tangan krn akan membuat kue kering akan keras nantinya
1. Tips 3 : butter dan margarin pada saat dimixer dlm keadaan dingin, baru keluar dari kulkas
1. Tips 4 : jika sudah cape tp adonan masih sisa bisa dimasukkan kulkas. Lanjut keesokan harinya. Saya pernah diamkan di kulkas 3 hari tanpa ditutup. Adonan aman, tetap harum, tidak jamuran
1. Kalo saya tahap paling pertama sangrai terigu lalu rebus telur. Tunggu hingga benar-benar dingin
1. Proses pembuatannya memang lama, butuh stamina yg fit juga, butuh kesabaran tapi sepadan dg hasilnya koq
1. Nastar keju
1. Nastar klasik




Demikianlah cara membuat nastar keju maupun klasik lembut banget yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
