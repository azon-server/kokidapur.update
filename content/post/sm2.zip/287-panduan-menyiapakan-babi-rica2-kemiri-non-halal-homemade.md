---
description: "Panduan menyiapakan Babi rica2 kemiri (non halal!) Homemade"
title: "Panduan menyiapakan Babi rica2 kemiri (non halal!) Homemade"
slug: 287-panduan-menyiapakan-babi-rica2-kemiri-non-halal-homemade
date: 2020-09-28T08:58:11.292Z
image: https://img-global.cpcdn.com/recipes/05344f2126610781/751x532cq70/babi-rica2-kemiri-non-halal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/05344f2126610781/751x532cq70/babi-rica2-kemiri-non-halal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/05344f2126610781/751x532cq70/babi-rica2-kemiri-non-halal-foto-resep-utama.jpg
author: Alex Hunter
ratingvalue: 4.3
reviewcount: 18173
recipeingredient:
- " Daging babi kurang lebih ini saya setengah kilo"
- "4 buah Kentang"
- "1/2 buah Bawang bombai"
- "3 lembar Daun salam"
- "4 lembar Daun jeruk"
- "2 tangkai Sereh"
- "secukupnya Garam"
- "secukupnya Penyedap"
- " Bumbu yang dihaluskan"
- "8 siung Bawang putih"
- "6 siung Bawang merah"
- " Cabai rawit 15 biji bisa ditambahkan kalau mau lebih pedes"
- " Tomat 1 buah besar"
- "1 ruas ibu jari Jahe"
- "5 biji Kemiri"
recipeinstructions:
- "Iris-iris kentang sesuai selera, disini saya iris persegi panjang, goreng dan tiriskan"
- "Iris2 daging babi sesuai selera, disini saya seragamkan dengan bentuk irisan kentang."
- "Haluskan bumbu yang sudah disiapkan untuk dihaluskan."
- "Di papan iris, iris tipis2 bawang bombay, keprek2 sereh, dan iris tipis2 daun jeruk, sisihkan."
- "Siapkan wajan, masukkan minyak goreng secukupnya. Tumis bawang bombay sampai menguning, masukkan bumbu yang telah dihaluskan, tambahkan daun salam, keprekan sereh, dan irisan daun jeruk, tumis sampai layu dan harum."
- "Masukkan potongan daging babi, tumis sampai menyatu dengan bumbu, tambahkan air, dan tutup wajan, biarkan sampai daging lunak. Setelah agak lunak, buka tutup wajan, tambahkan garam dan penyedap sesuai selera. Tunggu sampai daging matang dan koreksi rasa."
- "Setelah daging matang dan bumbu mulai meresap, sebelum terlalu kering, tambahkan kentang yang sudah digoreng, aduk2 sampai rata dan masakan siap dihidangkan."
categories:
- Recipe
tags:
- babi
- rica2
- kemiri

katakunci: babi rica2 kemiri 
nutrition: 127 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Lunch

---


![Babi rica2 kemiri (non halal!)](https://img-global.cpcdn.com/recipes/05344f2126610781/751x532cq70/babi-rica2-kemiri-non-halal-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti babi rica2 kemiri (non halal!) yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Nusantara



Kehangatan rumah tangga dapat ditemukan dengan cara simple. Salah satunya adalah membuat makanan Babi rica2 kemiri (non halal!) untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang dapat anda coba salah satunya babi rica2 kemiri (non halal!) yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep babi rica2 kemiri (non halal!) tanpa harus bersusah payah.
Seperti resep Babi rica2 kemiri (non halal!) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Babi rica2 kemiri (non halal!):

1. Diperlukan  Daging babi (kurang lebih ini saya setengah kilo)
1. Siapkan 4 buah Kentang
1. Dibutuhkan 1/2 buah Bawang bombai
1. Harus ada 3 lembar Daun salam
1. Harus ada 4 lembar Daun jeruk
1. Dibutuhkan 2 tangkai Sereh
1. Jangan lupa secukupnya Garam
1. Harus ada secukupnya Penyedap
1. Siapkan  Bumbu yang dihaluskan:
1. Tambah 8 siung Bawang putih
1. Dibutuhkan 6 siung Bawang merah
1. Siapkan  Cabai rawit 15 biji (bisa ditambahkan kalau mau lebih pedes)
1. Siapkan  Tomat 1 buah besar
1. Harus ada 1 ruas ibu jari Jahe
1. Jangan lupa 5 biji Kemiri




<!--inarticleads2-->

##### Bagaimana membuat  Babi rica2 kemiri (non halal!):

1. Iris-iris kentang sesuai selera, disini saya iris persegi panjang, goreng dan tiriskan
1. Iris2 daging babi sesuai selera, disini saya seragamkan dengan bentuk irisan kentang.
1. Haluskan bumbu yang sudah disiapkan untuk dihaluskan.
1. Di papan iris, iris tipis2 bawang bombay, keprek2 sereh, dan iris tipis2 daun jeruk, sisihkan.
1. Siapkan wajan, masukkan minyak goreng secukupnya. Tumis bawang bombay sampai menguning, masukkan bumbu yang telah dihaluskan, tambahkan daun salam, keprekan sereh, dan irisan daun jeruk, tumis sampai layu dan harum.
1. Masukkan potongan daging babi, tumis sampai menyatu dengan bumbu, tambahkan air, dan tutup wajan, biarkan sampai daging lunak. Setelah agak lunak, buka tutup wajan, tambahkan garam dan penyedap sesuai selera. Tunggu sampai daging matang dan koreksi rasa.
1. Setelah daging matang dan bumbu mulai meresap, sebelum terlalu kering, tambahkan kentang yang sudah digoreng, aduk2 sampai rata dan masakan siap dihidangkan.




Demikianlah cara membuat babi rica2 kemiri (non halal!) yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan teruji, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
