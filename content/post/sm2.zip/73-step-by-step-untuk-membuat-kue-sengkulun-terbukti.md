---
description: "Step-by-Step untuk membuat Kue sengkulun Terbukti"
title: "Step-by-Step untuk membuat Kue sengkulun Terbukti"
slug: 73-step-by-step-untuk-membuat-kue-sengkulun-terbukti
date: 2021-01-12T02:16:40.388Z
image: https://img-global.cpcdn.com/recipes/466a9a996280e30e/751x532cq70/kue-sengkulun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/466a9a996280e30e/751x532cq70/kue-sengkulun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/466a9a996280e30e/751x532cq70/kue-sengkulun-foto-resep-utama.jpg
author: Elsie Parsons
ratingvalue: 4.4
reviewcount: 7511
recipeingredient:
- "1 butir kelapa setengah tuah"
- "200 gram tepung kanji"
- "200 gram gula putih"
- " Pewarna makanan saya ungu"
- " Minyak untuk olesan"
- "Sedikit vanili"
recipeinstructions:
- "Campurkan kelapa tepung kanji dan gula, vanili tes rasa, setelah tercampur rata bagi 2 y.. Saya putih dan ungu"
- "Panaskan dandang tutup dengan kain bersih, olesi cetakan dengan minyak tipis2 y lalu masukan adonan yg ungu langsung timpah lg dengan yang putih"
- "Kukus 20 menit, setelah matang keluarkan dari kukusan.. Hasilnya enak banget.. Cocok bwat acara di rumah.."
categories:
- Recipe
tags:
- kue
- sengkulun

katakunci: kue sengkulun 
nutrition: 169 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Dinner

---


![Kue sengkulun](https://img-global.cpcdn.com/recipes/466a9a996280e30e/751x532cq70/kue-sengkulun-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang dapat kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti kue sengkulun yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa keistimewahan yang merupakan keragaman Nusantara

Kedekatan rumah tangga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Kue sengkulun untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang dapat anda contoh salah satunya kue sengkulun yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep kue sengkulun tanpa harus bersusah payah.
Berikut ini resep Kue sengkulun yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 6 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kue sengkulun:

1. Harap siapkan 1 butir kelapa setengah tuah
1. Harus ada 200 gram tepung kanji
1. Dibutuhkan 200 gram gula putih
1. Diperlukan  Pewarna makanan (saya ungu)
1. Diperlukan  Minyak untuk olesan
1. Dibutuhkan Sedikit vanili




<!--inarticleads2-->

##### Langkah membuat  Kue sengkulun:

1. Campurkan kelapa tepung kanji dan gula, vanili tes rasa, setelah tercampur rata bagi 2 y.. Saya putih dan ungu
1. Panaskan dandang tutup dengan kain bersih, olesi cetakan dengan minyak tipis2 y lalu masukan adonan yg ungu langsung timpah lg dengan yang putih
1. Kukus 20 menit, setelah matang keluarkan dari kukusan.. Hasilnya enak banget.. Cocok bwat acara di rumah..




Demikianlah cara membuat kue sengkulun yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan teruji, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
