---
description: "Langkah untuk membuat Babi Rica khas Manado (Non-Halal) Luar biasa"
title: "Langkah untuk membuat Babi Rica khas Manado (Non-Halal) Luar biasa"
slug: 235-langkah-untuk-membuat-babi-rica-khas-manado-non-halal-luar-biasa
date: 2020-11-04T06:29:44.915Z
image: https://img-global.cpcdn.com/recipes/26fcded58c85af1d/751x532cq70/babi-rica-khas-manado-non-halal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/26fcded58c85af1d/751x532cq70/babi-rica-khas-manado-non-halal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/26fcded58c85af1d/751x532cq70/babi-rica-khas-manado-non-halal-foto-resep-utama.jpg
author: Gertrude Powers
ratingvalue: 4.7
reviewcount: 9277
recipeingredient:
- "1 kg daging babi saya suka nambah 2 potong tulang"
- "1 bh jeruk nipis"
- "4 cm jahe"
- "10 siung bawang merah"
- "30 bh cabe rawit bisa kurang bisa tambah sesuai selera"
- "10 bh cabe keriting sebagai pewarna aja biar cerah merahnya"
- "1 bh serai ambil putihnya geprek"
- "5 bh daun jeruk"
- "1 lbr daun pandan"
- "6 bh kentang potong besarbesar"
- "1 ltr air"
- "secukupnya Garam dan penyedap"
recipeinstructions:
- "Cuci bersih daging, lumuri jeruk nipis dan sedikit garam"
- "Haluskan cabe rawit, cabe keriting, jahe, dan bawang merah"
- "Panaskan minyak, masukkan serai, daun jeruk, dan daun pandan. Tumis hingga harum"
- "Masukkan bumbu halus, tumis hingga masak"
- "Masukkan daging, aduk sebentar sampai berubah warna, lalu masukkan air. Masak hingga daging empuk. Cek terus jangan sampai airnya habis."
- "Apabila daging sudah masak, masukkan kentang, garam, dan penyedap. Tambahkan sedikit air. Masak hingga kentang empuk."
- "Anglat dan sajikan."
categories:
- Recipe
tags:
- babi
- rica
- khas

katakunci: babi rica khas 
nutrition: 171 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Dinner

---


![Babi Rica khas Manado (Non-Halal)](https://img-global.cpcdn.com/recipes/26fcded58c85af1d/751x532cq70/babi-rica-khas-manado-non-halal-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas dan enak. Ciri khas makanan Indonesia babi rica khas manado (non-halal) yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kehangatan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah memasak Babi Rica khas Manado (Non-Halal) untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang bisa anda contoh salah satunya babi rica khas manado (non-halal) yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep babi rica khas manado (non-halal) tanpa harus bersusah payah.
Seperti resep Babi Rica khas Manado (Non-Halal) yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 12 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Babi Rica khas Manado (Non-Halal):

1. Dibutuhkan 1 kg daging babi (saya suka nambah 2 potong tulang)
1. Dibutuhkan 1 bh jeruk nipis
1. Dibutuhkan 4 cm jahe
1. Jangan lupa 10 siung bawang merah
1. Jangan lupa 30 bh cabe rawit (bisa kurang bisa tambah, sesuai selera)
1. Tambah 10 bh cabe keriting (sebagai pewarna aja, biar cerah merahnya)
1. Harap siapkan 1 bh serai, ambil putihnya, geprek
1. Tambah 5 bh daun jeruk
1. Tambah 1 lbr daun pandan
1. Dibutuhkan 6 bh kentang, potong besar-besar
1. Jangan lupa 1 ltr air
1. Dibutuhkan secukupnya Garam dan penyedap




<!--inarticleads2-->

##### Instruksi membuat  Babi Rica khas Manado (Non-Halal):

1. Cuci bersih daging, lumuri jeruk nipis dan sedikit garam
1. Haluskan cabe rawit, cabe keriting, jahe, dan bawang merah
1. Panaskan minyak, masukkan serai, daun jeruk, dan daun pandan. Tumis hingga harum
1. Masukkan bumbu halus, tumis hingga masak
1. Masukkan daging, aduk sebentar sampai berubah warna, lalu masukkan air. Masak hingga daging empuk. Cek terus jangan sampai airnya habis.
1. Apabila daging sudah masak, masukkan kentang, garam, dan penyedap. Tambahkan sedikit air. Masak hingga kentang empuk.
1. Anglat dan sajikan.




Demikianlah cara membuat babi rica khas manado (non-halal) yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan cepat, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
