---
description: "Cara membuat Ayam bakar Solo resep Xander&amp;#39;s Kitchen Favorite"
title: "Cara membuat Ayam bakar Solo resep Xander&amp;#39;s Kitchen Favorite"
slug: 47-cara-membuat-ayam-bakar-solo-resep-xander-and-39-s-kitchen-favorite
date: 2020-10-28T23:28:06.845Z
image: https://img-global.cpcdn.com/recipes/50b9e831215d6bd4/751x532cq70/ayam-bakar-solo-resep-xanders-kitchen-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/50b9e831215d6bd4/751x532cq70/ayam-bakar-solo-resep-xanders-kitchen-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/50b9e831215d6bd4/751x532cq70/ayam-bakar-solo-resep-xanders-kitchen-foto-resep-utama.jpg
author: Sean Silva
ratingvalue: 4.2
reviewcount: 27091
recipeingredient:
- "1 sdm gula merah sisir"
- "1 ekor ayam kampung potong sesuai selera"
- "2 sdm kecap manis"
- " Air kelapa untuk ungkep ayam saya pakai dari satu butir kelapa masih sisa"
- " Bumbu yg dihaluskan "
- "8 butir bawang merah"
- "6 siung bawang putih"
- "2 butir kemiri sangrai"
- "Seruas kunyit"
- "secukupnya Garam"
- " Pelengkap"
- " Timun"
- " Tomat"
- " Sambal terasi ABC"
recipeinstructions:
- "1. Taruh ayam di wajan lalu balurkan bumbu yg telah dihaluskan ke ayam yg telah dipotong-potong. Remas-remas sebentar. Diamkan kira-kira 20 menit."
- "Tuang air kelapa, gula merah, kecap manis dan garam. Ungkep ayam."
- "Masak sampai ayam empuk dan bumbu mengental. Jangan lupa dibalik-balik biar merata."
- "Panggang ayam menggunakan Happy Call sampai agak kering sambil diolesi sisa bumbu (ini saya skip)."
- "Siapkan pelengkap sesuai selera, misal timun dan tomat."
- "Lengkapi dengan sambal terasi ABC sebagai cocolan"
categories:
- Recipe
tags:
- ayam
- bakar
- solo

katakunci: ayam bakar solo 
nutrition: 230 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT60M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam bakar Solo resep Xander&#39;s Kitchen](https://img-global.cpcdn.com/recipes/50b9e831215d6bd4/751x532cq70/ayam-bakar-solo-resep-xanders-kitchen-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga renyah. Ciri kuliner Nusantara ayam bakar solo resep xander&#39;s kitchen yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam bakar Solo resep Xander&#39;s Kitchen untuk keluarga. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang bisa anda contoh salah satunya ayam bakar solo resep xander&#39;s kitchen yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep ayam bakar solo resep xander&#39;s kitchen tanpa harus bersusah payah.
Berikut ini resep Ayam bakar Solo resep Xander&#39;s Kitchen yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 14 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam bakar Solo resep Xander&#39;s Kitchen:

1. Siapkan 1 sdm gula merah, sisir
1. Harap siapkan 1 ekor ayam kampung, potong sesuai selera
1. Jangan lupa 2 sdm kecap manis
1. Jangan lupa  Air kelapa untuk ungkep ayam (saya pakai dari satu butir kelapa, masih sisa)
1. Harap siapkan  Bumbu yg dihaluskan :
1. Diperlukan 8 butir bawang merah
1. Tambah 6 siung bawang putih
1. Jangan lupa 2 butir kemiri, sangrai
1. Harap siapkan Seruas kunyit
1. Diperlukan secukupnya Garam
1. Jangan lupa  Pelengkap:
1. Tambah  Timun
1. Jangan lupa  Tomat
1. Harap siapkan  Sambal terasi ABC




<!--inarticleads2-->

##### Instruksi membuat  Ayam bakar Solo resep Xander&#39;s Kitchen:

1. 1. Taruh ayam di wajan lalu balurkan bumbu yg telah dihaluskan ke ayam yg telah dipotong-potong. Remas-remas sebentar. Diamkan kira-kira 20 menit.
1. Tuang air kelapa, gula merah, kecap manis dan garam. Ungkep ayam.
1. Masak sampai ayam empuk dan bumbu mengental. Jangan lupa dibalik-balik biar merata.
1. Panggang ayam menggunakan Happy Call sampai agak kering sambil diolesi sisa bumbu (ini saya skip).
1. Siapkan pelengkap sesuai selera, misal timun dan tomat.
1. Lengkapi dengan sambal terasi ABC sebagai cocolan




Demikianlah cara membuat ayam bakar solo resep xander&#39;s kitchen yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat mudah dan terbukti, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
