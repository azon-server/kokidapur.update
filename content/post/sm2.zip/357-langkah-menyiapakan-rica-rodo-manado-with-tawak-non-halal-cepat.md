---
description: "Langkah menyiapakan Rica Rodo (Manado) with Tawak (non-halal) Cepat"
title: "Langkah menyiapakan Rica Rodo (Manado) with Tawak (non-halal) Cepat"
slug: 357-langkah-menyiapakan-rica-rodo-manado-with-tawak-non-halal-cepat
date: 2020-11-04T08:28:29.463Z
image: https://img-global.cpcdn.com/recipes/9752c94eb1077b7b/751x532cq70/rica-rodo-manado-with-tawak-non-halal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9752c94eb1077b7b/751x532cq70/rica-rodo-manado-with-tawak-non-halal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9752c94eb1077b7b/751x532cq70/rica-rodo-manado-with-tawak-non-halal-foto-resep-utama.jpg
author: Teresa Kim
ratingvalue: 4.8
reviewcount: 32728
recipeingredient:
- "2 bh terong ungu uksedang belah dua iris serong tebal 5mm"
- "100 gr daging babi samcan iris tipis memanjang bole skip atau ganti ikan cakalang Suirdgg ayam ya"
- "2 genggam jagung manis pipil"
- "Secukupnya daun kemangi petik"
- "3 lonjor kacang panjang potong2"
- "1 bh bawang pre potong2"
- "1 btg serai simpul geprek"
- "2 lbr daun jeruk"
- "Secukupnya minyak utk menumis"
- "Sesuai selera garam kaldu bubuk gula pasir"
- " Bumbu halus "
- "5 butir bawang merah"
- "4 bh cabe merah"
- "Sesuai selera cabe rawit"
- "1 cm jahe"
- "1 cup air"
- "Sedikit terasi bs diganti ebi"
recipeinstructions:
- "Tumis bumbu halus bersama daun jeruk dan sereh. Aduk2 hingga layu."
- "Kmd masukkan potongan daging, aduk hingga berubah warna."
- "Stlh itu masukkan kacang panjang dan terong, aduk2 masak hingga setengah layu menyusul masukkan jagung manis. Aduk2 masak hingga semua agak layu stlh itu baru tambahkan air secukupnya."
- "Stlh mendidih, masukkan irisan bawang pre dan kemangi. Kemudian beri garam, gula pasir dan kaldu bubuk."
- "Masak hingga semua matang. Icipi rasanya. Angkat dan sajikan."
categories:
- Recipe
tags:
- rica
- rodo
- manado

katakunci: rica rodo manado 
nutrition: 187 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Dinner

---


![Rica Rodo (Manado) with Tawak (non-halal)](https://img-global.cpcdn.com/recipes/9752c94eb1077b7b/751x532cq70/rica-rodo-manado-with-tawak-non-halal-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau renyah. Ciri makanan Indonesia rica rodo (manado) with tawak (non-halal) yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah memasak Rica Rodo (Manado) with Tawak (non-halal) untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang bisa anda buat salah satunya rica rodo (manado) with tawak (non-halal) yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep rica rodo (manado) with tawak (non-halal) tanpa harus bersusah payah.
Seperti resep Rica Rodo (Manado) with Tawak (non-halal) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Rica Rodo (Manado) with Tawak (non-halal):

1. Diperlukan 2 bh terong ungu uk.sedang. belah dua, iris serong tebal +/-5mm
1. Harus ada 100 gr daging babi (samcan) iris tipis memanjang (bole skip, atau ganti ikan cakalang Suir/dgg ayam ya)
1. Tambah 2 genggam jagung manis pipil
1. Siapkan Secukupnya daun kemangi, petik
1. Jangan lupa 3 lonjor kacang panjang, potong2
1. Siapkan 1 bh bawang pre, potong2
1. Harap siapkan 1 btg serai, simpul, geprek
1. Harus ada 2 lbr daun jeruk
1. Harus ada Secukupnya minyak utk menumis
1. Dibutuhkan Sesuai selera garam, kaldu bubuk, gula pasir
1. Jangan lupa  Bumbu halus :
1. Harap siapkan 5 butir bawang merah
1. Tambah 4 bh cabe merah
1. Dibutuhkan Sesuai selera cabe rawit
1. Diperlukan 1 cm jahe
1. Dibutuhkan 1 cup air
1. Harap siapkan Sedikit terasi (bs diganti ebi)




<!--inarticleads2-->

##### Cara membuat  Rica Rodo (Manado) with Tawak (non-halal):

1. Tumis bumbu halus bersama daun jeruk dan sereh. Aduk2 hingga layu.
1. Kmd masukkan potongan daging, aduk hingga berubah warna.
1. Stlh itu masukkan kacang panjang dan terong, aduk2 masak hingga setengah layu menyusul masukkan jagung manis. Aduk2 masak hingga semua agak layu stlh itu baru tambahkan air secukupnya.
1. Stlh mendidih, masukkan irisan bawang pre dan kemangi. Kemudian beri garam, gula pasir dan kaldu bubuk.
1. Masak hingga semua matang. Icipi rasanya. Angkat dan sajikan.




Demikianlah cara membuat rica rodo (manado) with tawak (non-halal) yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan teruji, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
