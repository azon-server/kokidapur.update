---
description: "Langkah menyiapakan Roti Boy Homemade"
title: "Langkah menyiapakan Roti Boy Homemade"
slug: 279-langkah-menyiapakan-roti-boy-homemade
date: 2020-11-18T05:00:49.330Z
image: https://img-global.cpcdn.com/recipes/a69401a248f2e5b9/680x482cq70/roti-boy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a69401a248f2e5b9/680x482cq70/roti-boy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a69401a248f2e5b9/680x482cq70/roti-boy-foto-resep-utama.jpg
author: Charlotte Lawrence
ratingvalue: 4.3
reviewcount: 10474
recipeingredient:
- "250 gr tepung cakra"
- "50 gr gula pasir"
- "1 sdt ragi fermipan"
- "30 gr margarine"
- "160 ml cairan 1 kuning telursusu cair"
- "1/2 sdt garam"
- " Bahan Isian dicampur jadi satu"
- "25 gr margarine"
- "25 gr keju parut me40gr"
- "2 sdm gula halus"
- " Bahan Topping"
- "100 gr margarine"
- "70 gr gula halus"
- "1 btr putih telur uk sedang"
- "1 sachet luwak white coffee campur dgn 2 sdm air panas"
- "1/2 sdt pasta mocca"
- "100 gr tepung segitiga"
recipeinstructions:
- "Siapkan wadah. Campur tepung, gula,ragi &amp; tuang cairan, uleni setengah kalis. Tambahkan margarine &amp; garam uleni sampai kalis elastis. Bulatkan adonan,diamkan sampai mengembang 2x lipat."
- "Sambil menunggu adonan mengembang kita buat toppingnya. Mikser margarine,gula halus,luwak white coffee,pasta mocca &amp; putih telur sampai mengembang. Masukkan tepung aduk sampai tercampur rata. Masukkan kedalam piping bag simpan dlm kulkas. Keluarkan bbrapa menit sblm digunakan."
- "Kempiskan adonan. Timbang sesuai selera (me:40gr), bulatkan, isi adonan yg sdh ditimbang dgn bahan isian, bulatkan kembali. Tata diloyang, beri jarak. Diamkan selama 30 menit. Panaskan oven."
- "Setelah roti mengembang beri topping melingkar diatas roti. Panggang sampai roti matang &amp; toping kering. Sesuaikan dgn oven masing2 ya."
- "Angkat dan dinginkan. Siap disajikan 👌🥰 (maaf foto step by stepnya gak lengkap, bisa lihat langsung diresepnya Cut Aldila T.Is)😘"
categories:
- Recipe
tags:
- roti
- boy

katakunci: roti boy 
nutrition: 146 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT56M"
recipeyield: "3"
recipecategory: Lunch

---


![Roti Boy](https://img-global.cpcdn.com/recipes/a69401a248f2e5b9/680x482cq70/roti-boy-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau renyah. Ciri khas makanan Indonesia roti boy yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan rumah tangga dapat ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Roti Boy untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang dapat anda buat salah satunya roti boy yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep roti boy tanpa harus bersusah payah.
Seperti resep Roti Boy yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Boy:

1. Harus ada 250 gr tepung cakra
1. Harus ada 50 gr gula pasir
1. Diperlukan 1 sdt ragi (fermipan)
1. Dibutuhkan 30 gr margarine
1. Dibutuhkan 160 ml cairan (1 kuning telur+susu cair)
1. Jangan lupa 1/2 sdt garam
1. Siapkan  Bahan Isian (dicampur jadi satu):
1. Jangan lupa 25 gr margarine
1. Dibutuhkan 25 gr keju parut (me:40gr)
1. Harap siapkan 2 sdm gula halus
1. Dibutuhkan  Bahan Topping:
1. Tambah 100 gr margarine
1. Tambah 70 gr gula halus
1. Tambah 1 btr putih telur uk. sedang
1. Tambah 1 sachet luwak white coffee campur dgn 2 sdm air panas
1. Siapkan 1/2 sdt pasta mocca
1. Dibutuhkan 100 gr tepung segitiga




<!--inarticleads2-->

##### Langkah membuat  Roti Boy:

1. Siapkan wadah. Campur tepung, gula,ragi &amp; tuang cairan, uleni setengah kalis. Tambahkan margarine &amp; garam uleni sampai kalis elastis. Bulatkan adonan,diamkan sampai mengembang 2x lipat.
1. Sambil menunggu adonan mengembang kita buat toppingnya. Mikser margarine,gula halus,luwak white coffee,pasta mocca &amp; putih telur sampai mengembang. Masukkan tepung aduk sampai tercampur rata. Masukkan kedalam piping bag simpan dlm kulkas. Keluarkan bbrapa menit sblm digunakan.
1. Kempiskan adonan. Timbang sesuai selera (me:40gr), bulatkan, isi adonan yg sdh ditimbang dgn bahan isian, bulatkan kembali. Tata diloyang, beri jarak. Diamkan selama 30 menit. Panaskan oven.
1. Setelah roti mengembang beri topping melingkar diatas roti. Panggang sampai roti matang &amp; toping kering. Sesuaikan dgn oven masing2 ya.
1. Angkat dan dinginkan. Siap disajikan 👌🥰 (maaf foto step by stepnya gak lengkap, bisa lihat langsung diresepnya Cut Aldila T.Is)😘




Demikianlah cara membuat roti boy yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan cepat, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
