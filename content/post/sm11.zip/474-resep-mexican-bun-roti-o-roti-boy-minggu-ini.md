---
description: "Resep : Mexican Bun (Roti O / Roti Boy) minggu ini"
title: "Resep : Mexican Bun (Roti O / Roti Boy) minggu ini"
slug: 474-resep-mexican-bun-roti-o-roti-boy-minggu-ini
date: 2020-11-02T04:59:44.298Z
image: https://img-global.cpcdn.com/recipes/7f7cb8c03b6e1208/680x482cq70/mexican-bun-roti-o-roti-boy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7f7cb8c03b6e1208/680x482cq70/mexican-bun-roti-o-roti-boy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7f7cb8c03b6e1208/680x482cq70/mexican-bun-roti-o-roti-boy-foto-resep-utama.jpg
author: Martin Knight
ratingvalue: 4.6
reviewcount: 19135
recipeingredient:
- " Bahan Roti"
- "300 gr terigu cakra"
- "50 gr gula pasir"
- "1 sdt ragi"
- "1 butir kuning telur"
- "2 sdm margarine"
- "1 sdm susu bubuk"
- "100 ml air hangat"
- " Bahan Toping"
- "100 gr terigu kunci biru"
- "100 gr gula halus"
- "100 gr mentega"
- "25 gr tepung maizena"
- "1/2 sdt garam"
- "1 butir putih telur"
- "2 sachet kopi instant diseduh dengan 2 sdm air"
- " Bahan Isian"
- "secukupnya DCC"
recipeinstructions:
- "Untuk roti, campurkan semua bahan kecuali air, aduk hingga rata, kemudian tambahkan air sedikit demi sedikit aduk sampai adonan kalis."
- "Setelah kalis bulatkan adonan dan tutup dengan lap basah, diamkan 30 menit."
- "Sembari menunggu adonan mengembang, kita buat topingnya dulu, mixer telur sampai mengembang kemudian masukan mentega dan mixer kembali setelah itu masukan terigu sedikit demi sedikit sembari di mixer, masukan maizena dan gula halus, mixer kembali, dan terakhir masukan seduhan kopi, mixer kembali sampai merata."
- "Masukan toping ke dalam piping bag, sisihkan."
- "Setelah adonan mengembang, ambil adonan 50gr, bulatkan dan berikan isian (DCC)."
- "Lakukan sampai adonan habis, dan diamkan kembali selama 1 jam."
- "Setelah 1 jam, berikan toping diatasnya, dengan cara semprotkan toping dari bagian tengah ke luar seperti obat nyamuk (melingkar)."
- "Panaskan oven, panggang roti sampai toping mengeras, kurleb 30-40 menit."
- "Setelah mengeras topingnya, angkat dan sajikan."
- "Sajikan selagi hangat"
categories:
- Recipe
tags:
- mexican
- bun
- roti

katakunci: mexican bun roti 
nutrition: 292 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dinner

---


![Mexican Bun (Roti O / Roti Boy)](https://img-global.cpcdn.com/recipes/7f7cb8c03b6e1208/680x482cq70/mexican-bun-roti-o-roti-boy-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang harus kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti mexican bun (roti o / roti boy) yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan keistimewahan yang merupakan keragaman Indonesia

Kedekatan keluarga bisa didapat dengan cara simple. Salah satunya adalah memasak Mexican Bun (Roti O / Roti Boy) untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda buat salah satunya mexican bun (roti o / roti boy) yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep mexican bun (roti o / roti boy) tanpa harus bersusah payah.
Seperti resep Mexican Bun (Roti O / Roti Boy) yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Mexican Bun (Roti O / Roti Boy):

1. Tambah  Bahan Roti:
1. Jangan lupa 300 gr terigu (cakra)
1. Jangan lupa 50 gr gula pasir
1. Harus ada 1 sdt ragi
1. Diperlukan 1 butir kuning telur
1. Siapkan 2 sdm margarine
1. Siapkan 1 sdm susu bubuk
1. Harus ada 100 ml air hangat
1. Diperlukan  Bahan Toping:
1. Harus ada 100 gr terigu (kunci biru)
1. Tambah 100 gr gula halus
1. Siapkan 100 gr mentega
1. Harap siapkan 25 gr tepung maizena
1. Tambah 1/2 sdt garam
1. Diperlukan 1 butir putih telur
1. Tambah 2 sachet kopi instant (diseduh dengan 2 sdm air)
1. Siapkan  Bahan Isian:
1. Siapkan secukupnya DCC




<!--inarticleads2-->

##### Instruksi membuat  Mexican Bun (Roti O / Roti Boy):

1. Untuk roti, campurkan semua bahan kecuali air, aduk hingga rata, kemudian tambahkan air sedikit demi sedikit aduk sampai adonan kalis.
1. Setelah kalis bulatkan adonan dan tutup dengan lap basah, diamkan 30 menit.
1. Sembari menunggu adonan mengembang, kita buat topingnya dulu, mixer telur sampai mengembang kemudian masukan mentega dan mixer kembali setelah itu masukan terigu sedikit demi sedikit sembari di mixer, masukan maizena dan gula halus, mixer kembali, dan terakhir masukan seduhan kopi, mixer kembali sampai merata.
1. Masukan toping ke dalam piping bag, sisihkan.
1. Setelah adonan mengembang, ambil adonan 50gr, bulatkan dan berikan isian (DCC).
1. Lakukan sampai adonan habis, dan diamkan kembali selama 1 jam.
1. Setelah 1 jam, berikan toping diatasnya, dengan cara semprotkan toping dari bagian tengah ke luar seperti obat nyamuk (melingkar).
1. Panaskan oven, panggang roti sampai toping mengeras, kurleb 30-40 menit.
1. Setelah mengeras topingnya, angkat dan sajikan.
1. Sajikan selagi hangat




Demikianlah cara membuat mexican bun (roti o / roti boy) yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
