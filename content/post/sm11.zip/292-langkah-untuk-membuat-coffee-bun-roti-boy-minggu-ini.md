---
description: "Langkah untuk membuat Coffee Bun/Roti Boy🥯 minggu ini"
title: "Langkah untuk membuat Coffee Bun/Roti Boy🥯 minggu ini"
slug: 292-langkah-untuk-membuat-coffee-bun-roti-boy-minggu-ini
date: 2020-10-22T07:01:41.383Z
image: https://img-global.cpcdn.com/recipes/1248b4edf988f42b/680x482cq70/coffee-bunroti-boy🥯-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1248b4edf988f42b/680x482cq70/coffee-bunroti-boy🥯-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1248b4edf988f42b/680x482cq70/coffee-bunroti-boy🥯-foto-resep-utama.jpg
author: Martha Simpson
ratingvalue: 4.6
reviewcount: 7171
recipeingredient:
- " Roti"
- " Bahan A"
- "300 gr terigu pro tinggimekomachi"
- "40 gr gula pasir"
- "15 gr susu bubuk"
- "5 gr ragi instan"
- "1 btr kuning telur  susu cair dingin timbang mjd 204gr"
- " Bahan B"
- "30 gr butter"
- "3 gr garam"
- " Topping"
- "1 btr putih telur"
- "30 gr butter"
- "40 gr gula halus"
- "50 gr terigu segitiga"
- "1/4 sdt baking powder"
- "1 sdt kopi instan  1 sdm air panas utk melarutkan"
- " Fillingaduk rata semua bahan"
- "35 gr butter"
- "35 gr keju parut me cheddar soft cheese"
- "20 gr gula halus"
recipeinstructions:
- "Roti:Campur bahan A,mixer hingga kalis(aku pake breadmaker)"
- "Setelah kalis, masukkan bahan B,uleni hingga kalis elastis.Diamkan kira2 1 jam sampai mengembang"
- "Setelah itu kempeskan adonan,aku bagi jadi 12 (@ kira2 50 gr),beri filling,bulatkan,tutup dgn serbet,diamkan lagi kira2 1 jam sampai mengembang"
- "Topping:Mixer putih telur sampai kaku.Dlm wadah lain mixer butter &amp; gula sampai rata"
- "Masukkan terigu,kopi yg sdh dilarutkan &amp; putih telur kocok ke dlm adonan butter,mixer sebentar hingga rata.Masukkan dlm plastik segitiga.Siap digunakan."
- "Setelah roti mengembang,semprotkan topping melingkar rapat di atasnya,jgn terlalu sampai bawah spy rapih melelehnya sewaktu dipanggang"
- "Panggang dlm suhu 180° api atas bawah kira2 30 menit"
- "Fresh from the oven💗💗💗"
categories:
- Recipe
tags:
- coffee
- bunroti
- boy

katakunci: coffee bunroti boy 
nutrition: 255 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Lunch

---


![Coffee Bun/Roti Boy🥯](https://img-global.cpcdn.com/recipes/1248b4edf988f42b/680x482cq70/coffee-bunroti-boy🥯-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau gurih. Ciri masakan Indonesia coffee bun/roti boy🥯 yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Coffee Bun/Roti Boy🥯 untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang bisa anda coba salah satunya coffee bun/roti boy🥯 yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep coffee bun/roti boy🥯 tanpa harus bersusah payah.
Seperti resep Coffee Bun/Roti Boy🥯 yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Coffee Bun/Roti Boy🥯:

1. Harap siapkan  Roti:
1. Tambah  Bahan A:
1. Jangan lupa 300 gr terigu pro tinggi(me:komachi)
1. Harus ada 40 gr gula pasir
1. Harus ada 15 gr susu bubuk
1. Tambah 5 gr ragi instan
1. Jangan lupa 1 btr kuning telur + susu cair dingin timbang mjd 204gr
1. Harus ada  Bahan B:
1. Harus ada 30 gr butter
1. Diperlukan 3 gr garam
1. Jangan lupa  Topping:
1. Diperlukan 1 btr putih telur
1. Siapkan 30 gr butter
1. Dibutuhkan 40 gr gula halus
1. Jangan lupa 50 gr terigu segitiga
1. Siapkan 1/4 sdt baking powder
1. Siapkan 1 sdt kopi instan + 1 sdm air panas utk melarutkan
1. Tambah  Filling(aduk rata semua bahan):
1. Dibutuhkan 35 gr butter
1. Harap siapkan 35 gr keju parut (me: cheddar soft cheese)
1. Harus ada 20 gr gula halus




<!--inarticleads2-->

##### Langkah membuat  Coffee Bun/Roti Boy🥯:

1. Roti:Campur bahan A,mixer hingga kalis(aku pake breadmaker)
1. Setelah kalis, masukkan bahan B,uleni hingga kalis elastis.Diamkan kira2 1 jam sampai mengembang
1. Setelah itu kempeskan adonan,aku bagi jadi 12 (@ kira2 50 gr),beri filling,bulatkan,tutup dgn serbet,diamkan lagi kira2 1 jam sampai mengembang
1. Topping:Mixer putih telur sampai kaku.Dlm wadah lain mixer butter &amp; gula sampai rata
1. Masukkan terigu,kopi yg sdh dilarutkan &amp; putih telur kocok ke dlm adonan butter,mixer sebentar hingga rata.Masukkan dlm plastik segitiga.Siap digunakan.
1. Setelah roti mengembang,semprotkan topping melingkar rapat di atasnya,jgn terlalu sampai bawah spy rapih melelehnya sewaktu dipanggang
1. Panggang dlm suhu 180° api atas bawah kira2 30 menit
1. Fresh from the oven💗💗💗




Demikianlah cara membuat coffee bun/roti boy🥯 yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
