---
description: "Cara menyiapakan Mexican Coffee Bun aka Roti Boy terupdate"
title: "Cara menyiapakan Mexican Coffee Bun aka Roti Boy terupdate"
slug: 304-cara-menyiapakan-mexican-coffee-bun-aka-roti-boy-terupdate
date: 2020-10-13T22:20:19.030Z
image: https://img-global.cpcdn.com/recipes/af80201436d9e6ce/680x482cq70/mexican-coffee-bun-aka-roti-boy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/af80201436d9e6ce/680x482cq70/mexican-coffee-bun-aka-roti-boy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/af80201436d9e6ce/680x482cq70/mexican-coffee-bun-aka-roti-boy-foto-resep-utama.jpg
author: Warren Robertson
ratingvalue: 4.2
reviewcount: 30890
recipeingredient:
- "220 gram terigu cakra"
- "1 sdt ragi instan"
- "2 sdm gula pasir"
- "100 ml susu cair"
- "2 sdm mentega"
- " Bahan isian"
- "50 gram mentega"
- "50 gram gula halus"
- "50 gram keju parut"
- " Bahan toping"
- "50 gram mentega"
- "50 gram gula pasir"
- "1 butir putih telur"
- "100 gram terigu kunci"
- "1 saset kopi instan larutkan dengan 1 sdm air panas"
- "1/4 sdt pasta mocca"
recipeinstructions:
- "Campur terigu gula ragi lalu tuang susu cair nya uleni sampai kalis setelah kalis masukan mentega uleni lagi sampai kalis elastis, saya pake bantuan mixcer spiral setelah kalis elastis diamkan 1 jam"
- "Sambil menunggu bikin bahan isianya mixcer mentega dan gula halus sampai creamy lalu masukan keju parut mixcer lagi sampai creamy kental dan mengkilap sisihkan"
- "Lalu bikin topingnya kocok putih telur sampai kaku lalu masukan mentega gula halus lalu masukan terugu kopi instan dan pasta moca setelah rata matikan lalu masukan ke plastik segitiga"
- "Setelah adonan mengembang kempiskan adonan uleni sebentar lalu bagi adonan 1 adonan bikin 50 gram saya jadi 8 buah"
- "Lalu pipihkan adonan letekan di tangan kiri bentuk seperti cekungan lalu isi dengan isian dengan tangan kanan lalu rapatkan sambil di cubit2 lalu bulatkan bentuk agak pipih, lakukan terus sampai adonan habis yaa"
- "Diamkan kembali adonan kurang lebih 20 menitan sampai mengembang lagi, sambil menunggu mengembang panaskan oven"
- "Setelah mengembang lalu gunting kecil ujungnya plastik segitiga yg sudah berisi toping lalu semprotkan ke atas adonan bentuk melingkar swperti obat nyamuk yg rapat yaa sampai setengah bagian roti saja biar g bleber ke bawah"
- "Panggang selama 20 - 30 sampai matang tandanya topingnya akan terlihat kering lalu angkat dinginkan"
- "Taraaa ini dia jadinyaaa 😍😍😍😍"
- "Lembut toping akan terasa kres2 bila langsung d makan kalo didiamkan topingnya akan sedikit melembek jadi selera aja yaa mau dimakan langsung atau ntar2an... dua duanya rasanya tetep enak"
- "Selamat mencoba"
categories:
- Recipe
tags:
- mexican
- coffee
- bun

katakunci: mexican coffee bun 
nutrition: 129 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Dessert

---


![Mexican Coffee Bun aka Roti Boy](https://img-global.cpcdn.com/recipes/af80201436d9e6ce/680x482cq70/mexican-coffee-bun-aka-roti-boy-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan gurih. Karasteristik masakan Indonesia mexican coffee bun aka roti boy yang penuh dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Mexican Coffee Bun aka Roti Boy untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang bisa anda buat salah satunya mexican coffee bun aka roti boy yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep mexican coffee bun aka roti boy tanpa harus bersusah payah.
Berikut ini resep Mexican Coffee Bun aka Roti Boy yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 11 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican Coffee Bun aka Roti Boy:

1. Harap siapkan 220 gram terigu cakra
1. Diperlukan 1 sdt ragi instan
1. Tambah 2 sdm gula pasir
1. Harus ada 100 ml susu cair
1. Jangan lupa 2 sdm mentega
1. Diperlukan  Bahan isian
1. Jangan lupa 50 gram mentega
1. Tambah 50 gram gula halus
1. Jangan lupa 50 gram keju parut
1. Dibutuhkan  Bahan toping
1. Siapkan 50 gram mentega
1. Dibutuhkan 50 gram gula pasir
1. Tambah 1 butir putih telur
1. Tambah 100 gram terigu kunci
1. Harap siapkan 1 saset kopi instan larutkan dengan 1 sdm air panas
1. Harap siapkan 1/4 sdt pasta mocca




<!--inarticleads2-->

##### Cara membuat  Mexican Coffee Bun aka Roti Boy:

1. Campur terigu gula ragi lalu tuang susu cair nya uleni sampai kalis setelah kalis masukan mentega uleni lagi sampai kalis elastis, saya pake bantuan mixcer spiral setelah kalis elastis diamkan 1 jam
1. Sambil menunggu bikin bahan isianya mixcer mentega dan gula halus sampai creamy lalu masukan keju parut mixcer lagi sampai creamy kental dan mengkilap sisihkan
1. Lalu bikin topingnya kocok putih telur sampai kaku lalu masukan mentega gula halus lalu masukan terugu kopi instan dan pasta moca setelah rata matikan lalu masukan ke plastik segitiga
1. Setelah adonan mengembang kempiskan adonan uleni sebentar lalu bagi adonan 1 adonan bikin 50 gram saya jadi 8 buah
1. Lalu pipihkan adonan letekan di tangan kiri bentuk seperti cekungan lalu isi dengan isian dengan tangan kanan lalu rapatkan sambil di cubit2 lalu bulatkan bentuk agak pipih, lakukan terus sampai adonan habis yaa
1. Diamkan kembali adonan kurang lebih 20 menitan sampai mengembang lagi, sambil menunggu mengembang panaskan oven
1. Setelah mengembang lalu gunting kecil ujungnya plastik segitiga yg sudah berisi toping lalu semprotkan ke atas adonan bentuk melingkar swperti obat nyamuk yg rapat yaa sampai setengah bagian roti saja biar g bleber ke bawah
1. Panggang selama 20 - 30 sampai matang tandanya topingnya akan terlihat kering lalu angkat dinginkan
1. Taraaa ini dia jadinyaaa 😍😍😍😍
1. Lembut toping akan terasa kres2 bila langsung d makan kalo didiamkan topingnya akan sedikit melembek jadi selera aja yaa mau dimakan langsung atau ntar2an... dua duanya rasanya tetep enak
1. Selamat mencoba




Demikianlah cara membuat mexican coffee bun aka roti boy yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
