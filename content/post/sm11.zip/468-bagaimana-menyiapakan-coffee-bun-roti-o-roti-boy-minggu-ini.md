---
description: "Bagaimana menyiapakan Coffee Bun / Roti O / Roti Boy minggu ini"
title: "Bagaimana menyiapakan Coffee Bun / Roti O / Roti Boy minggu ini"
slug: 468-bagaimana-menyiapakan-coffee-bun-roti-o-roti-boy-minggu-ini
date: 2021-01-25T12:43:47.775Z
image: https://img-global.cpcdn.com/recipes/41e6ab4688beb6f6/680x482cq70/coffee-bun-roti-o-roti-boy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/41e6ab4688beb6f6/680x482cq70/coffee-bun-roti-o-roti-boy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/41e6ab4688beb6f6/680x482cq70/coffee-bun-roti-o-roti-boy-foto-resep-utama.jpg
author: Estelle Patterson
ratingvalue: 4.6
reviewcount: 3887
recipeingredient:
- " bahan roti "
- "450 gram terigu pro tinggi"
- "50 gram susu bubuk full cream"
- "100 gram gula halus aku ga suka terlalu manis"
- "350 ml air hangat"
- "2 butir kuning telur"
- "50 gram butter"
- "1/2 sdt garam"
- "1 sdm ragi instan"
- " bahan topping "
- "50 gram mentega"
- "50 gram gula halus"
- "1 butir putih telur"
- "2 sdm susu bubuk"
- "60 gram terigu pro rendah  kunci serbaguna jg boleh"
- "1 sdm kopi sachet aku  luwak white coffee lebih nampol"
- "1 sdm air panas untuk melarutkan kopi"
- "1 sdt pasta kopi  moka aku ga pake krn blm beli"
- " tambahan mentega  butter untuk isian"
recipeinstructions:
- "Adonan roti : air hangat dicampur 1 sdm gula + ragi dicampur, aduk rata sampai ragi larut, diamkan 7-10 menit sampai berbuih tanda raginya aktif."
- "Sementara menunggu, tepung, gula dan susu bubuk dicampur dlm satu wadah lalu aduk rata."
- "Masukkan kuning telur ke dlm air ragi yg telah aktif lalu aduk rata. Tuang semua ke dlm tepung. Aduk rata. Masukkan butter dan garam lalu uleni sampai kalis. Adonan memang akan lembek, jgn panik..uleni terus sampe ga lengket (aku olesi minyak pada tangan biar ga lengket)."
- "Bulatkan adonan, tutup dlm wadah kedap udara. Diamkan selama kurang lebih 1 jam, intinya sampe adonan mengembang 2 kali lipat."
- "Sementara menunggu, buat adonan topping : mentega dan gula dikocok sampai rata (aku pake whisk). Masukkan putih telur lalu aduk rata sampai lembut. Masukkan tepung dan susu bubuk lalu aduk rata. Masukkan cairan kopi yg sudah dilarutkan dan pasta kopi / moka lalu aduk rata. Masukkan adonan ke dlm piping bag, ikat, kemudian simpan dlm kulkas agar adonan ga terlalu leleh."
- "Setelah adonan roti mengembang, bentuk bulat dgn ukuran yg sama, beri isian mentega secukupnya, diamkan lagi sampai mengembang 2 kali lipat."
- "Beri topping kopi diatas roti. Aku kasi toppingnya kurang rapet :("
- "Panaskan oven 180 derajat sesuai oven masing-masing. Panggang selama kurang lebih 40 menit (aku : 25 menit panas bawah, 15 menit panas atas bawah, tergantung oven masing-masing)."
- "Pantau terus, jgn sampai gosong ya. Setelah matang, jgn lupa dicekrek dulu biar eksis."
- "Ini aku pernah coba bikin pake kopi hitam biasa yg ada didapur + pasta coklat, jd eksotik gini -_-"
categories:
- Recipe
tags:
- coffee
- bun
- 

katakunci: coffee bun  
nutrition: 142 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dinner

---


![Coffee Bun / Roti O / Roti Boy](https://img-global.cpcdn.com/recipes/41e6ab4688beb6f6/680x482cq70/coffee-bun-roti-o-roti-boy-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan empuk. Karasteristik makanan Nusantara coffee bun / roti o / roti boy yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak Coffee Bun / Roti O / Roti Boy untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda praktekkan salah satunya coffee bun / roti o / roti boy yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep coffee bun / roti o / roti boy tanpa harus bersusah payah.
Berikut ini resep Coffee Bun / Roti O / Roti Boy yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 10 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Coffee Bun / Roti O / Roti Boy:

1. Dibutuhkan  bahan roti :
1. Diperlukan 450 gram terigu pro tinggi
1. Diperlukan 50 gram susu bubuk full cream
1. Siapkan 100 gram gula halus (aku ga suka terlalu manis)
1. Jangan lupa 350 ml air hangat
1. Harap siapkan 2 butir kuning telur
1. Harap siapkan 50 gram butter
1. Jangan lupa 1/2 sdt garam
1. Harap siapkan 1 sdm ragi instan
1. Harus ada  bahan topping :
1. Dibutuhkan 50 gram mentega
1. Harap siapkan 50 gram gula halus
1. Harus ada 1 butir putih telur
1. Dibutuhkan 2 sdm susu bubuk
1. Tambah 60 gram terigu pro rendah / kunci (serbaguna jg boleh)
1. Harap siapkan 1 sdm kopi sachet (aku : luwak white coffee lebih nampol)
1. Siapkan 1 sdm air panas (untuk melarutkan kopi)
1. Harus ada 1 sdt pasta kopi / moka (aku ga pake krn blm beli)
1. Harap siapkan  tambahan mentega / butter untuk isian




<!--inarticleads2-->

##### Langkah membuat  Coffee Bun / Roti O / Roti Boy:

1. Adonan roti : air hangat dicampur 1 sdm gula + ragi dicampur, aduk rata sampai ragi larut, diamkan 7-10 menit sampai berbuih tanda raginya aktif.
1. Sementara menunggu, tepung, gula dan susu bubuk dicampur dlm satu wadah lalu aduk rata.
1. Masukkan kuning telur ke dlm air ragi yg telah aktif lalu aduk rata. Tuang semua ke dlm tepung. Aduk rata. Masukkan butter dan garam lalu uleni sampai kalis. Adonan memang akan lembek, jgn panik..uleni terus sampe ga lengket (aku olesi minyak pada tangan biar ga lengket).
1. Bulatkan adonan, tutup dlm wadah kedap udara. Diamkan selama kurang lebih 1 jam, intinya sampe adonan mengembang 2 kali lipat.
1. Sementara menunggu, buat adonan topping : mentega dan gula dikocok sampai rata (aku pake whisk). Masukkan putih telur lalu aduk rata sampai lembut. Masukkan tepung dan susu bubuk lalu aduk rata. Masukkan cairan kopi yg sudah dilarutkan dan pasta kopi / moka lalu aduk rata. Masukkan adonan ke dlm piping bag, ikat, kemudian simpan dlm kulkas agar adonan ga terlalu leleh.
1. Setelah adonan roti mengembang, bentuk bulat dgn ukuran yg sama, beri isian mentega secukupnya, diamkan lagi sampai mengembang 2 kali lipat.
1. Beri topping kopi diatas roti. Aku kasi toppingnya kurang rapet :(
1. Panaskan oven 180 derajat sesuai oven masing-masing. Panggang selama kurang lebih 40 menit (aku : 25 menit panas bawah, 15 menit panas atas bawah, tergantung oven masing-masing).
1. Pantau terus, jgn sampai gosong ya. Setelah matang, jgn lupa dicekrek dulu biar eksis.
1. Ini aku pernah coba bikin pake kopi hitam biasa yg ada didapur + pasta coklat, jd eksotik gini -_-




Demikianlah cara membuat coffee bun / roti o / roti boy yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan cepat, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
