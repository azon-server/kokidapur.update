---
description: "Resep : Roti Boy (Roti O) Homemade"
title: "Resep : Roti Boy (Roti O) Homemade"
slug: 415-resep-roti-boy-roti-o-homemade
date: 2020-12-03T04:55:57.727Z
image: https://img-global.cpcdn.com/recipes/4d457bb50b3e580b/680x482cq70/roti-boy-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4d457bb50b3e580b/680x482cq70/roti-boy-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4d457bb50b3e580b/680x482cq70/roti-boy-roti-o-foto-resep-utama.jpg
author: Nora Moore
ratingvalue: 4.3
reviewcount: 1917
recipeingredient:
- " Bahan Pengembang"
- "1 sdt ragi instan"
- "5 sdm susu full cream"
- "1 sdt gula pasir"
- " Bahan Roti"
- "250 gram tepung terigu protein tinggi"
- "1 butir telur"
- "2 sdm susu bubuk"
- "2 sdm margarin"
- "1/4 sdt garam"
- "1 kotak tidak semua hanya sekitar 70ml susu full cream"
- " Bahan Isian"
- "1 sachet SKM putih"
- "2 sdm margarin"
- "30 gram keju"
- " Bahan Topping"
- "1,5 sdm gula halus"
- "50 gram tepung terigu"
- "1,5 sdm margarin"
- "1 butir telur"
- "1 sachet kopi nescafe atau apapun"
- "sedikit air hangat"
recipeinstructions:
- "Pertama buat pengembang dulu. Dengan cara, memasukan semua bahan kemudian diaduk dan ditutup tunggu 10 menit."
- "Kemudian untuk bahan rotinya semuanya dimasukan, kemudian masukkan biang pengembang jangan sampe terkena garam yaaa. di uleni sampe kalisss.. ditutupin kain dan tunggu 30 menit agar mengembang."
- "Sambil menunggu mengembangnya roti, bikinlah isi roti dengan memasukan semua bahan dan kocok sampe memutih.."
- "Kemudian setelah mengembang buletin dan masukkan isian. Ohiya lebih enak isiannya kalian masukan kulkas jadi tinggal potong2 atau kalo gak diganti keju potong aja. Saya buat sebagian pake butter sebagian keju. Sama enaknya kok! Abis itu setelah sudah jadi bulet2, ditutup dulu deh tunggu 50menitan agar mengembang."
- "Sambil menunggu mengembang, membuat topping dengan cara melarutkan kopi dengan sedikit air lalu aduk. Kemudian masukkan semua bahan topping dan diaduk jadi satu dengn larutan kopi. Kemudian bentuklah topping diatas rotiii.."
- "Oven dengan 175 derajat dengn waktu 20 menit tapi dilihat dulu jika belum matang tambah 15 menit tadi saya begitu karena tergantung kompor/oven. JADI DEH!"
categories:
- Recipe
tags:
- roti
- boy
- roti

katakunci: roti boy roti 
nutrition: 125 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dinner

---


![Roti Boy (Roti O)](https://img-global.cpcdn.com/recipes/4d457bb50b3e580b/680x482cq70/roti-boy-roti-o-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau empuk. Ciri khas kuliner Nusantara roti boy (roti o) yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga bisa didapat dengan cara sederhana. Salah satunya adalah memasak Roti Boy (Roti O) untuk keluarga. kebiasaan makan bersama anak sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda contoh salah satunya roti boy (roti o) yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep roti boy (roti o) tanpa harus bersusah payah.
Berikut ini resep Roti Boy (Roti O) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 22 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Boy (Roti O):

1. Harus ada  Bahan Pengembang
1. Harus ada 1 sdt ragi instan
1. Tambah 5 sdm susu full cream
1. Tambah 1 sdt gula pasir
1. Harap siapkan  Bahan Roti
1. Dibutuhkan 250 gram tepung terigu protein tinggi
1. Harus ada 1 butir telur
1. Siapkan 2 sdm susu bubuk
1. Jangan lupa 2 sdm margarin
1. Dibutuhkan 1/4 sdt garam
1. Dibutuhkan 1 kotak (tidak semua hanya sekitar 70ml) susu full cream
1. Diperlukan  Bahan Isian
1. Tambah 1 sachet SKM putih
1. Dibutuhkan 2 sdm margarin
1. Diperlukan 30 gram keju
1. Harap siapkan  Bahan Topping
1. Diperlukan 1,5 sdm gula halus
1. Jangan lupa 50 gram tepung terigu
1. Harap siapkan 1,5 sdm margarin
1. Siapkan 1 butir telur
1. Dibutuhkan 1 sachet kopi (nescafe atau apapun)
1. Dibutuhkan sedikit air hangat




<!--inarticleads2-->

##### Instruksi membuat  Roti Boy (Roti O):

1. Pertama buat pengembang dulu. Dengan cara, memasukan semua bahan kemudian diaduk dan ditutup tunggu 10 menit.
1. Kemudian untuk bahan rotinya semuanya dimasukan, kemudian masukkan biang pengembang jangan sampe terkena garam yaaa. di uleni sampe kalisss.. ditutupin kain dan tunggu 30 menit agar mengembang.
1. Sambil menunggu mengembangnya roti, bikinlah isi roti dengan memasukan semua bahan dan kocok sampe memutih..
1. Kemudian setelah mengembang buletin dan masukkan isian. Ohiya lebih enak isiannya kalian masukan kulkas jadi tinggal potong2 atau kalo gak diganti keju potong aja. Saya buat sebagian pake butter sebagian keju. Sama enaknya kok! Abis itu setelah sudah jadi bulet2, ditutup dulu deh tunggu 50menitan agar mengembang.
1. Sambil menunggu mengembang, membuat topping dengan cara melarutkan kopi dengan sedikit air lalu aduk. Kemudian masukkan semua bahan topping dan diaduk jadi satu dengn larutan kopi. Kemudian bentuklah topping diatas rotiii..
1. Oven dengan 175 derajat dengn waktu 20 menit tapi dilihat dulu jika belum matang tambah 15 menit tadi saya begitu karena tergantung kompor/oven. JADI DEH!




Demikianlah cara membuat roti boy (roti o) yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
