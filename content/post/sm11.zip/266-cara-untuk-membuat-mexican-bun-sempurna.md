---
description: "Cara untuk membuat Mexican Bun Sempurna"
title: "Cara untuk membuat Mexican Bun Sempurna"
slug: 266-cara-untuk-membuat-mexican-bun-sempurna
date: 2021-01-31T02:06:06.943Z
image: https://img-global.cpcdn.com/recipes/a0f0635dc2392ce2/680x482cq70/mexican-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a0f0635dc2392ce2/680x482cq70/mexican-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a0f0635dc2392ce2/680x482cq70/mexican-bun-foto-resep-utama.jpg
author: Patrick Fitzgerald
ratingvalue: 4.1
reviewcount: 32948
recipeingredient:
- " Bahan A "
- "300 gram tepung protein tinggi"
- "50 gram gula pasir"
- "7 gram ragi instan"
- "100 gram susu cair"
- "100 gram whipped cream cair  susu cair"
- " Bahan B "
- "65 gram butter"
- "1/2 sdt garam"
- " Bahan Isian "
- " Butter  margarin di dinginkan lalu potong kotak"
- " Topping "
- "70 gram butter"
- "35 gram gula halus"
- "1 butir telur"
- "1 sachet kopi instan larutkan dengan 2 sdm air panas"
- "70 gram tepung terigu"
recipeinstructions:
- "Campur semua bahan A jadi satu, lalu uleni hingga 1/2 kalis."
- "Setelah adonan 1/2 kalis, masukkan butter dan garam. Uleni kembali hingga kalis."
- "Setelah adonan kalis, proofing selama 45 menit hingga mengembang dua kali lipat. Setelah adonan mengembang dua kali lipat, kempiskan. Bagi adonan masing-masing @60 gram. Bulatkan, proofing kembali selama 15 menit."
- "Sambil menunggu, siapkan bahan topping. Aduk rata dengan whisk gula halus dan margarin. Kemudian masukkan telur dan kopi. Aduk rata."
- "Terakhir masukkan tepung terigu, aduk rata. Masukkan adonan ke dalam piping bag. Sisihkan."
- "Ambil satu bulatan kemudian pipihkan. Lalu beri isian margarin beku. Bulatkan kembali, lakukan hingga adonan habis."
- "Tutup adonan dan proofing kembali hingga double size. Setelah double size, semprotkan topping 3/4 bagian saja. Panggang dengan oven 175°C kurang lebih selama 25 menit atau hingga matang."
- "Bagian dalam roti akan berongga seperti ini ketika sudah matang."
- "Sajikan."
categories:
- Recipe
tags:
- mexican
- bun

katakunci: mexican bun 
nutrition: 140 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Lunch

---


![Mexican Bun](https://img-global.cpcdn.com/recipes/a0f0635dc2392ce2/680x482cq70/mexican-bun-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau enak. Karasteristik masakan Nusantara mexican bun yang kaya dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak Mexican Bun untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi resep yang bisa anda coba salah satunya mexican bun yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep mexican bun tanpa harus bersusah payah.
Seperti resep Mexican Bun yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican Bun:

1. Harap siapkan  Bahan A :
1. Harap siapkan 300 gram tepung protein tinggi
1. Tambah 50 gram gula pasir
1. Jangan lupa 7 gram ragi instan
1. Diperlukan 100 gram susu cair
1. Diperlukan 100 gram whipped cream cair / susu cair
1. Diperlukan  Bahan B :
1. Harus ada 65 gram butter
1. Jangan lupa 1/2 sdt garam
1. Harap siapkan  Bahan Isian :
1. Harus ada  Butter / margarin di dinginkan, lalu potong kotak
1. Siapkan  Topping :
1. Tambah 70 gram butter
1. Harap siapkan 35 gram gula halus
1. Siapkan 1 butir telur
1. Jangan lupa 1 sachet kopi instan (larutkan dengan 2 sdm air panas)
1. Siapkan 70 gram tepung terigu




<!--inarticleads2-->

##### Langkah membuat  Mexican Bun:

1. Campur semua bahan A jadi satu, lalu uleni hingga 1/2 kalis.
1. Setelah adonan 1/2 kalis, masukkan butter dan garam. Uleni kembali hingga kalis.
1. Setelah adonan kalis, proofing selama 45 menit hingga mengembang dua kali lipat. Setelah adonan mengembang dua kali lipat, kempiskan. Bagi adonan masing-masing @60 gram. Bulatkan, proofing kembali selama 15 menit.
1. Sambil menunggu, siapkan bahan topping. Aduk rata dengan whisk gula halus dan margarin. Kemudian masukkan telur dan kopi. Aduk rata.
1. Terakhir masukkan tepung terigu, aduk rata. Masukkan adonan ke dalam piping bag. Sisihkan.
1. Ambil satu bulatan kemudian pipihkan. Lalu beri isian margarin beku. Bulatkan kembali, lakukan hingga adonan habis.
1. Tutup adonan dan proofing kembali hingga double size. Setelah double size, semprotkan topping 3/4 bagian saja. Panggang dengan oven 175°C kurang lebih selama 25 menit atau hingga matang.
1. Bagian dalam roti akan berongga seperti ini ketika sudah matang.
1. Sajikan.




Demikianlah cara membuat mexican bun yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
