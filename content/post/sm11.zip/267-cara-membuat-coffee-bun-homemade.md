---
description: "Cara membuat Coffee Bun Homemade"
title: "Cara membuat Coffee Bun Homemade"
slug: 267-cara-membuat-coffee-bun-homemade
date: 2021-02-05T23:47:45.925Z
image: https://img-global.cpcdn.com/recipes/8f9e9e594cb653eb/680x482cq70/coffee-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8f9e9e594cb653eb/680x482cq70/coffee-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8f9e9e594cb653eb/680x482cq70/coffee-bun-foto-resep-utama.jpg
author: Julian Mendez
ratingvalue: 4.9
reviewcount: 13917
recipeingredient:
- " Bahan Bun "
- "200 gr tepung terigu protein tinggi"
- "50 gr tepung terigu protein sedang"
- "50 gr gula pasir"
- "7 gr ragi"
- "2 butir kuning telur"
- "100 ml susu cair full cream dingin"
- "50 gr unsalted butter suhu ruang"
- " Bahan Isian "
- "sesuai selera Salted butter "
- " Bahan Topping "
- "100 gr unsalted butter"
- "70 gr gula halus"
- "1 butir telur"
- "80 gr tepung terigu protein sedang"
- "1 sachet kopi instan sy nescafe ukuran 3gr"
- "2 tetes pasta kopi sy pasta coklat"
recipeinstructions:
- "Campur semua bahan kecuali butter, uleni sampai menjadi setengah kalis. Setelah kalis tambahkan butter, uleni kembali sampai adonan menjadi kalis elastis, bulatkan adonan. Istirahatkan sampai adonan mengembang 2x lipat"
- "Setelah adonan mengembang 2x lipat, kempiskan adonan bagi menjadi beberapa bagian (sesuai selera), bulatkan adonan, istirahatkan kembali ± 10 menit"
- "Ambil 1 buah adonan, pipihkan isi dgn bahan isian, bulatkan kembali (lakukan sampai adonan habis). Istirahatkan kembali"
- "Membuat topping : ✔larutkan kopi dgn air panas sebanyak 3 sdm, sisihkan ✔siapkan wadah, masukan butter dan gula halus, aduk rata"
- "✔tambahkan 1 butir telur, aduk rata."
- "Kemudian masukan tepung terugu, tambahkan pasta kopi /coklat, aduk rata,"
- "Pindahkan ke dalam piping bag (adonan bisa di simpan di dalam kulkas terlebig dahulu)"
- "Setelah ± 30 menit, semprot bagian atas adonan dgn bahan topping sampai rata. lalu masukan ke dalam oven yg sudah dipanaskan terlebih dahulu. Panggang disuhu 200°C ± 10 s/d 13 menit sesuai suhu oven masing masing,"
- "Setelah matang angkat, tunggu hangat dan siap di santap.. Yuumyy😋"
categories:
- Recipe
tags:
- coffee
- bun

katakunci: coffee bun 
nutrition: 283 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Dinner

---


![Coffee Bun](https://img-global.cpcdn.com/recipes/8f9e9e594cb653eb/680x482cq70/coffee-bun-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga renyah. Ciri khas makanan Nusantara coffee bun yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kehangatan keluarga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Coffee Bun untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang bisa anda contoh salah satunya coffee bun yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep coffee bun tanpa harus bersusah payah.
Berikut ini resep Coffee Bun yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Coffee Bun:

1. Harus ada  Bahan Bun :
1. Diperlukan 200 gr tepung terigu protein tinggi
1. Siapkan 50 gr tepung terigu protein sedang
1. Harap siapkan 50 gr gula pasir
1. Dibutuhkan 7 gr ragi
1. Tambah 2 butir kuning telur
1. Tambah 100 ml susu cair full cream, dingin
1. Harus ada 50 gr unsalted butter, suhu ruang
1. Harus ada  Bahan Isian :
1. Jangan lupa sesuai selera Salted butter /
1. Harus ada  Bahan Topping :
1. Harus ada 100 gr unsalted butter
1. Jangan lupa 70 gr gula halus
1. Diperlukan 1 butir telur
1. Harus ada 80 gr tepung terigu protein sedang
1. Harap siapkan 1 sachet kopi instan, sy nescafe ukuran 3gr
1. Jangan lupa 2 tetes pasta kopi, sy pasta coklat




<!--inarticleads2-->

##### Instruksi membuat  Coffee Bun:

1. Campur semua bahan kecuali butter, uleni sampai menjadi setengah kalis. Setelah kalis tambahkan butter, uleni kembali sampai adonan menjadi kalis elastis, bulatkan adonan. Istirahatkan sampai adonan mengembang 2x lipat
1. Setelah adonan mengembang 2x lipat, kempiskan adonan bagi menjadi beberapa bagian (sesuai selera), bulatkan adonan, istirahatkan kembali ± 10 menit
1. Ambil 1 buah adonan, pipihkan isi dgn bahan isian, bulatkan kembali (lakukan sampai adonan habis). Istirahatkan kembali
1. Membuat topping : - ✔larutkan kopi dgn air panas sebanyak 3 sdm, sisihkan - ✔siapkan wadah, masukan butter dan gula halus, aduk rata
1. ✔tambahkan 1 butir telur, aduk rata.
1. Kemudian masukan tepung terugu, tambahkan pasta kopi /coklat, aduk rata,
1. Pindahkan ke dalam piping bag (adonan bisa di simpan di dalam kulkas terlebig dahulu)
1. Setelah ± 30 menit, semprot bagian atas adonan dgn bahan topping sampai rata. lalu masukan ke dalam oven yg sudah dipanaskan terlebih dahulu. Panggang disuhu 200°C ± 10 s/d 13 menit sesuai suhu oven masing masing,
1. Setelah matang angkat, tunggu hangat dan siap di santap.. Yuumyy😋




Demikianlah cara membuat coffee bun yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat gampang dan teruji, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
