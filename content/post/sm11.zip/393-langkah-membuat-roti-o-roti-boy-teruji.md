---
description: "Langkah membuat Roti O / roti boy Teruji"
title: "Langkah membuat Roti O / roti boy Teruji"
slug: 393-langkah-membuat-roti-o-roti-boy-teruji
date: 2020-11-11T11:27:23.332Z
image: https://img-global.cpcdn.com/recipes/41ad4bbd934b5bad/680x482cq70/roti-o-roti-boy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/41ad4bbd934b5bad/680x482cq70/roti-o-roti-boy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/41ad4bbd934b5bad/680x482cq70/roti-o-roti-boy-foto-resep-utama.jpg
author: Nettie Crawford
ratingvalue: 4.8
reviewcount: 35326
recipeingredient:
- " BAHAN ROTI"
- "500 gr tepung terigu segitiga biru"
- "100 gr gula halus"
- "2 sendok teh ragi  fernipan"
- "2 butir telur kocok lepas"
- "60 gr mentega blue band cairkan dinginkan"
- "250 ml susu cair putih UTH"
- " "
- " ISIAN "
- "200 mg mentega blueband"
- "2 sendok makan mentega wisman bisa diganti achor  butter biasa"
- "40 gr kezu mozzarella  keju melted kraft  kl ga da keju kraft cheeder jg ga papa potong kasar"
- " "
- " TOPPING ATAS ROTI "
- "1 butir putih telur"
- "150 mg mentega blueband"
- "150 gr tepung terigu"
- "35 mg tepung maizena"
- "150 gr gula halus bubuk"
- "2 sendok makan coffe bubuk nescafe tanpa gula"
- "6 sendok makan air hangat"
recipeinstructions:
- "Siap kan bahan dlu semua nya sesuai takaran"
- "Selah bahan siap, campurkan susu + ragi/ fernipan + gula aduk dan diamkan selama 5menit, kl sudah berbusa tandanya ragi nya sudah aktiv."
- "Lalu campurkan terigu + mentega cair + susu yg sudah aktiv ragi nya, aduk bs menggunakan mixer roti/ diaduk manual sampai adonan kalis / tidak lengket seperti di foto dibawah ini, tutup wadah diamkan selama 1 jam hingga adonan mengembang"
- "Setelah 1 jam adonan mengembang, kempiskan dan potong2 adonan 40gr per potong masing2"
- "Sekarang buat isian nya, campurkan mentega + butter/ wisman/ achor + keju aduk dan masukan ke dalam adonan yg sudah di timbang 40gr masing2 td. Bulatkan taru di loyang dan diamkan selama 15 menit sampai terlihat lbh mengembang"
- "Cara membuat topping atas nya, cofee+putih telur+gula+air hangat cocok lepas sampai berubah warna jd lbh muda dan halus, terigu dan maizena dimasukan pada sesi akhir, sudah halus semua, masukan adonan topping ini ke dalam plastik, ikat plastik potong ujung runcing plastik dikit aja, buat bentuk spiral diatas adonan roti yg telah di isi tadi"
- "Siap kan oven suhu 150derajat setting wktu selama 15menit, masukan roti tgg sampai terlihat coklat, buka oven tusuk roti pakai lidi / tusukan sate, kl sudah tidak lengket batang lidi nya berarti sudah matang. Angkat dan sajikan."
categories:
- Recipe
tags:
- roti
- o
- 

katakunci: roti o  
nutrition: 104 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Dessert

---


![Roti O / roti boy](https://img-global.cpcdn.com/recipes/41ad4bbd934b5bad/680x482cq70/roti-o-roti-boy-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang setidaknya kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti roti o / roti boy yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Kita

Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah membuat makanan Roti O / roti boy untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang dapat anda coba salah satunya roti o / roti boy yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep roti o / roti boy tanpa harus bersusah payah.
Berikut ini resep Roti O / roti boy yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti O / roti boy:

1. Harus ada  BAHAN ROTI:
1. Harus ada 500 gr tepung terigu segitiga biru
1. Harus ada 100 gr gula halus
1. Jangan lupa 2 sendok teh ragi / fernipan
1. Tambah 2 butir telur kocok lepas
1. Harus ada 60 gr mentega blue band (cairkan dinginkan)
1. Harap siapkan 250 ml susu cair putih UTH
1. Jangan lupa  =====================
1. Dibutuhkan  ISIAN :
1. Tambah 200 mg mentega blueband
1. Siapkan 2 sendok makan mentega wisman (bisa diganti achor / butter biasa)
1. Harap siapkan 40 gr kezu mozzarella / keju melted kraft / kl ga da keju kraft cheeder jg ga papa potong kasar
1. Diperlukan  ====================
1. Diperlukan  TOPPING ATAS ROTI :
1. Tambah 1 butir putih telur
1. Diperlukan 150 mg mentega blueband
1. Dibutuhkan 150 gr tepung terigu
1. Diperlukan 35 mg tepung maizena
1. Siapkan 150 gr gula halus bubuk
1. Harus ada 2 sendok makan coffe bubuk nescafe tanpa gula
1. Tambah 6 sendok makan air hangat




<!--inarticleads2-->

##### Cara membuat  Roti O / roti boy:

1. Siap kan bahan dlu semua nya sesuai takaran
1. Selah bahan siap, campurkan susu + ragi/ fernipan + gula aduk dan diamkan selama 5menit, kl sudah berbusa tandanya ragi nya sudah aktiv.
1. Lalu campurkan terigu + mentega cair + susu yg sudah aktiv ragi nya, aduk bs menggunakan mixer roti/ diaduk manual sampai adonan kalis / tidak lengket seperti di foto dibawah ini, tutup wadah diamkan selama 1 jam hingga adonan mengembang
1. Setelah 1 jam adonan mengembang, kempiskan dan potong2 adonan 40gr per potong masing2
1. Sekarang buat isian nya, campurkan mentega + butter/ wisman/ achor + keju aduk dan masukan ke dalam adonan yg sudah di timbang 40gr masing2 td. Bulatkan taru di loyang dan diamkan selama 15 menit sampai terlihat lbh mengembang
1. Cara membuat topping atas nya, cofee+putih telur+gula+air hangat cocok lepas sampai berubah warna jd lbh muda dan halus, terigu dan maizena dimasukan pada sesi akhir, sudah halus semua, masukan adonan topping ini ke dalam plastik, ikat plastik potong ujung runcing plastik dikit aja, buat bentuk spiral diatas adonan roti yg telah di isi tadi
1. Siap kan oven suhu 150derajat setting wktu selama 15menit, masukan roti tgg sampai terlihat coklat, buka oven tusuk roti pakai lidi / tusukan sate, kl sudah tidak lengket batang lidi nya berarti sudah matang. Angkat dan sajikan.




Demikianlah cara membuat roti o / roti boy yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
