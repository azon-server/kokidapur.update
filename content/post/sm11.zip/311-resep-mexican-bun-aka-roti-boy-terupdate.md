---
description: "Resep : Mexican Bun aka Roti Boy 🍃 terupdate"
title: "Resep : Mexican Bun aka Roti Boy 🍃 terupdate"
slug: 311-resep-mexican-bun-aka-roti-boy-terupdate
date: 2021-02-07T22:38:42.748Z
image: https://img-global.cpcdn.com/recipes/a3d043bfcd57cae4/680x482cq70/mexican-bun-aka-roti-boy-🍃-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a3d043bfcd57cae4/680x482cq70/mexican-bun-aka-roti-boy-🍃-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a3d043bfcd57cae4/680x482cq70/mexican-bun-aka-roti-boy-🍃-foto-resep-utama.jpg
author: Carl Wong
ratingvalue: 4.7
reviewcount: 16717
recipeingredient:
- "  Bahan Roti "
- "220 gr Tepung Cakra"
- "2 sdm Gula Pasir"
- "1 sdm Ragi Instan"
- "2 sdm Margarin"
- "100 ml Air Hangat"
- "1/2 sdt Garam"
- "  Bahan Filling "
- "3 sdm Selai Coklat"
- "20 ml SKM"
- "3 sdm Margarin"
- "2 sdm Gula Pasir"
- "  Bahan Topping "
- "100 gr Margarin"
- "100 gr Gula Halus"
- "100 gt Tepung Kunci"
- "1 butir Putih Telur"
- "1 scht Toracaffe  dilarutkan dgn sdikit air "
- "1/2 sdt Garam"
- "1 sdt Pasta Mocca"
recipeinstructions:
- "~ Adonan Roti :. Campur ragi dan air hangat, aduk rata.. Terigu, gula, dan garam campur jadi satu, kemudian masukkan ragi dan air uleni smpai rata lalu masukan margarin uleni lagi smpai kalis elastis, diamkan 1 jam"
- "~ Adonan Filling :. Mixer semua bahan sampai tercampur rata dan masukkan keplastik contong"
- "~ Adonan Topping :. Mixer margarin dan gula sampai rata, masukkan putih telur kocok lagi sampai ngembang.. Kemudian masukan tepung, garam, dan toracaffe sambil dikocok sampai rata lagi dan terakhir masukkan pasta mocca kocok sbntar dan masukkan keplastik contong ~"
- "Penyelesaian :. Timbang adonan masing2 50gr dan beri filling, diamkan lagi 20 menit. Lalu beri topping diatasnya dan panggang selama 30 menit disuhu 150° sesuaikan dgn oven masing2. Setelah matang angkat. Siap Dinikmatiiii 😘😘😘"
- ""
- ""
- ""
categories:
- Recipe
tags:
- mexican
- bun
- aka

katakunci: mexican bun aka 
nutrition: 140 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dessert

---


![Mexican Bun aka Roti Boy 🍃](https://img-global.cpcdn.com/recipes/a3d043bfcd57cae4/680x482cq70/mexican-bun-aka-roti-boy-🍃-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan enak. Ciri khas kuliner Nusantara mexican bun aka roti boy 🍃 yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Mexican Bun aka Roti Boy 🍃 untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang dapat anda contoh salah satunya mexican bun aka roti boy 🍃 yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep mexican bun aka roti boy 🍃 tanpa harus bersusah payah.
Berikut ini resep Mexican Bun aka Roti Boy 🍃 yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Mexican Bun aka Roti Boy 🍃:

1. Dibutuhkan  🌺 Bahan Roti :
1. Jangan lupa 220 gr Tepung Cakra
1. Diperlukan 2 sdm Gula Pasir
1. Jangan lupa 1 sdm Ragi Instan
1. Dibutuhkan 2 sdm Margarin
1. Dibutuhkan 100 ml Air Hangat
1. Dibutuhkan 1/2 sdt Garam
1. Harap siapkan  🌺 Bahan Filling :
1. Siapkan 3 sdm Selai Coklat
1. Dibutuhkan 20 ml SKM
1. Harus ada 3 sdm Margarin
1. Tambah 2 sdm Gula Pasir
1. Diperlukan  🌺 Bahan Topping :
1. Harus ada 100 gr Margarin
1. Harap siapkan 100 gr Gula Halus
1. Harus ada 100 gt Tepung Kunci
1. Tambah 1 butir Putih Telur
1. Siapkan 1 scht Toracaffe  dilarutkan dgn sdikit air 
1. Harap siapkan 1/2 sdt Garam
1. Siapkan 1 sdt Pasta Mocca




<!--inarticleads2-->

##### Instruksi membuat  Mexican Bun aka Roti Boy 🍃:

1. ~ Adonan Roti :. Campur ragi dan air hangat, aduk rata.. Terigu, gula, dan garam campur jadi satu, kemudian masukkan ragi dan air uleni smpai rata lalu masukan margarin uleni lagi smpai kalis elastis, diamkan 1 jam
1. ~ Adonan Filling :. Mixer semua bahan sampai tercampur rata dan masukkan keplastik contong
1. ~ Adonan Topping :. Mixer margarin dan gula sampai rata, masukkan putih telur kocok lagi sampai ngembang.. Kemudian masukan tepung, garam, dan toracaffe sambil dikocok sampai rata lagi dan terakhir masukkan pasta mocca kocok sbntar dan masukkan keplastik contong ~
1. Penyelesaian :. Timbang adonan masing2 50gr dan beri filling, diamkan lagi 20 menit. Lalu beri topping diatasnya dan panggang selama 30 menit disuhu 150° sesuaikan dgn oven masing2. Setelah matang angkat. Siap Dinikmatiiii 😘😘😘
1. 
1. 
1. 




Demikianlah cara membuat mexican bun aka roti boy 🍃 yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
