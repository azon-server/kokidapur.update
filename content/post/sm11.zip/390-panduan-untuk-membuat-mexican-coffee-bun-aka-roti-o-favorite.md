---
description: "Panduan untuk membuat Mexican coffee bun a.k.a Roti O Favorite"
title: "Panduan untuk membuat Mexican coffee bun a.k.a Roti O Favorite"
slug: 390-panduan-untuk-membuat-mexican-coffee-bun-aka-roti-o-favorite
date: 2020-10-16T22:30:24.042Z
image: https://img-global.cpcdn.com/recipes/a67a4d86c1eedab8/680x482cq70/mexican-coffee-bun-aka-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a67a4d86c1eedab8/680x482cq70/mexican-coffee-bun-aka-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a67a4d86c1eedab8/680x482cq70/mexican-coffee-bun-aka-roti-o-foto-resep-utama.jpg
author: Joshua McKinney
ratingvalue: 4.2
reviewcount: 49888
recipeingredient:
- " Bahan roti"
- "200 gr terigu cakra"
- "50 gr terigu segitiga"
- "50 gr gula pasir"
- "1/2 sdm ragi instan"
- "1 kuning telur"
- "1 sdm susu bubuk fullcream"
- "125 ml air"
- "50 gr margarin"
- "Sejumput garam"
- " Bahan isi"
- "25 gr keju parut"
- "25 gr margarin"
- "1 dsm gula halus"
- " Bahan atas"
- "1 sdt kopi instan saya indocafe"
- "1/4 sdt BP"
- "1 putih telur"
- "1 sdm air panas"
- "50 gr terigu"
- "50 gr gula halus"
- "50 gr margarin"
- " Pasta mocca"
recipeinstructions:
- "Campur ragi instan dengan1 sdm gula dan 125 ml air, aduk dan diamkan hingga berbusa"
- "Campur semua bahan roti kecuali margarin dan garam dalam wadah dan uleni hingga setengah kalis kemudian masukkan garam dan margarin lalu lanjutkan uleni hingga kalis. Diamkan hingga mengembang"
- "Campur bahan isi dan sisihkan"
- "Setelah adonan mengembang 2x lipat, kempiskan adonan kemudian bagi menjadi 12 bagian dan bulatkan. Diamkan 10 menit kemudian isi."
- "Sambil menunggu adonan mengembang lagi, buat bahan atas kopi. Mixer putih telur hingga mengembang kaku. Dalam wadah lain mixer terigu, margarin, kopi yang telah diseduh, gula halus, bp. Campur dengan putih telur."
- "Masukkan dalam plastik segitiga dan tuang di atas adonan dengan bentuk spiral"
- "Oven dalam suhu 180-200 derajat selama 20 menit"
- "Roti O KW siap dinikmati selagi hangat"
categories:
- Recipe
tags:
- mexican
- coffee
- bun

katakunci: mexican coffee bun 
nutrition: 207 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Dinner

---


![Mexican coffee bun a.k.a Roti O](https://img-global.cpcdn.com/recipes/a67a4d86c1eedab8/680x482cq70/mexican-coffee-bun-aka-roti-o-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau gurih. Karasteristik makanan Nusantara mexican coffee bun a.k.a roti o yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa didapat dengan cara simple. Diantaranya adalah membuat makanan Mexican coffee bun a.k.a Roti O untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang dapat anda praktekkan salah satunya mexican coffee bun a.k.a roti o yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep mexican coffee bun a.k.a roti o tanpa harus bersusah payah.
Seperti resep Mexican coffee bun a.k.a Roti O yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 23 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Mexican coffee bun a.k.a Roti O:

1. Jangan lupa  Bahan roti
1. Jangan lupa 200 gr terigu cakra
1. Harus ada 50 gr terigu segitiga
1. Siapkan 50 gr gula pasir
1. Siapkan 1/2 sdm ragi instan
1. Diperlukan 1 kuning telur
1. Harap siapkan 1 sdm susu bubuk fullcream
1. Dibutuhkan 125 ml air
1. Jangan lupa 50 gr margarin
1. Jangan lupa Sejumput garam
1. Dibutuhkan  Bahan isi
1. Siapkan 25 gr keju parut
1. Siapkan 25 gr margarin
1. Siapkan 1 dsm gula halus
1. Jangan lupa  Bahan atas
1. Dibutuhkan 1 sdt kopi instan (saya indocafe)
1. Diperlukan 1/4 sdt BP
1. Tambah 1 putih telur
1. Diperlukan 1 sdm air panas
1. Jangan lupa 50 gr terigu
1. Tambah 50 gr gula halus
1. Tambah 50 gr margarin
1. Harus ada  Pasta mocca




<!--inarticleads2-->

##### Cara membuat  Mexican coffee bun a.k.a Roti O:

1. Campur ragi instan dengan1 sdm gula dan 125 ml air, aduk dan diamkan hingga berbusa
1. Campur semua bahan roti kecuali margarin dan garam dalam wadah dan uleni hingga setengah kalis kemudian masukkan garam dan margarin lalu lanjutkan uleni hingga kalis. Diamkan hingga mengembang
1. Campur bahan isi dan sisihkan
1. Setelah adonan mengembang 2x lipat, kempiskan adonan kemudian bagi menjadi 12 bagian dan bulatkan. Diamkan 10 menit kemudian isi.
1. Sambil menunggu adonan mengembang lagi, buat bahan atas kopi. Mixer putih telur hingga mengembang kaku. Dalam wadah lain mixer terigu, margarin, kopi yang telah diseduh, gula halus, bp. Campur dengan putih telur.
1. Masukkan dalam plastik segitiga dan tuang di atas adonan dengan bentuk spiral
1. Oven dalam suhu 180-200 derajat selama 20 menit
1. Roti O KW siap dinikmati selagi hangat




Demikianlah cara membuat mexican coffee bun a.k.a roti o yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
