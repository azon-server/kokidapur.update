---
description: "Resep : Mexican Bun Teruji"
title: "Resep : Mexican Bun Teruji"
slug: 268-resep-mexican-bun-teruji
date: 2021-01-20T18:39:30.870Z
image: https://img-global.cpcdn.com/recipes/6507b3600acaf094/680x482cq70/mexican-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6507b3600acaf094/680x482cq70/mexican-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6507b3600acaf094/680x482cq70/mexican-bun-foto-resep-utama.jpg
author: Steven Ward
ratingvalue: 4.2
reviewcount: 29333
recipeingredient:
- " Dough"
- "300 gram tepung terigu protein sedang segitiga biru"
- "1 sendok teh ragi instan permifan"
- "2 sendok makan susu bubuk"
- "10 sendok makan gula halus"
- "125 ml air"
- "1 buah telur"
- "50 gram butter"
- "25 gram butter untuk isian"
- " Bahan Toping"
- "1 sendok makan kopi bubuk instan"
- "1 sendok makan air panas"
- "1/2 sendok teh baking powder"
- "50 gram terigu"
- "2 sendok makan susu bubuk"
- "1 buah putih telur"
- "50 gram butter"
recipeinstructions:
- "Campurkan semua bahan untuk Dough kecuali butter, mixer sampai tercampur semua."
- "Tambahkan 50 gram butter, mixer kembali sampai Kalis elastis."
- "Setelah kalis tutup dengan plastik wrap/kain diamkan selama 1 jam."
- "Kempeskan dough bagi menjadi 10 bagian sama banyak, isi dengan butter secukupnya. Bentuk bulatan dan susu diatas loyang, dan diberi jarak. Diamkan selama 20 menit."
- "Kocok putih telur sampai kaku."
- "Campurkan butter, gula halus, tepung dan kopi instan yang telah dilarutkan, aduk sampai tercampur semua, tambahkan putih telur kemudian aduk perlahan. Tambahkan baking powder aduk sampai tercampur merata."
- "Oleskan toping pada roti yang telah didiamkan sampai bagian atas tertutup semua. Untuk mempermudah pemberian toping bisa menggunakan piping bag."
- "Panaskan oven 180°c, masukan roti di rak atas, panggang di suhu 180°c selama 30 menit. Roti siap dinikmati."
categories:
- Recipe
tags:
- mexican
- bun

katakunci: mexican bun 
nutrition: 240 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Lunch

---


![Mexican Bun](https://img-global.cpcdn.com/recipes/6507b3600acaf094/680x482cq70/mexican-bun-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau empuk. Ciri makanan Indonesia mexican bun yang kaya dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan rumah tangga bisa didapat dengan cara simple. Salah satunya adalah membuat makanan Mexican Bun untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang dapat anda praktekkan salah satunya mexican bun yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep mexican bun tanpa harus bersusah payah.
Berikut ini resep Mexican Bun yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Mexican Bun:

1. Harus ada  Dough
1. Harap siapkan 300 gram tepung terigu protein sedang (segitiga biru)
1. Jangan lupa 1 sendok teh ragi instan permifan
1. Harap siapkan 2 sendok makan susu bubuk
1. Jangan lupa 10 sendok makan gula halus
1. Diperlukan 125 ml air
1. Jangan lupa 1 buah telur
1. Harus ada 50 gram butter
1. Jangan lupa 25 gram butter (untuk isian)
1. Siapkan  Bahan Toping
1. Jangan lupa 1 sendok makan kopi bubuk instan
1. Siapkan 1 sendok makan air panas
1. Jangan lupa 1/2 sendok teh baking powder
1. Siapkan 50 gram terigu
1. Siapkan 2 sendok makan susu bubuk
1. Harus ada 1 buah putih telur
1. Jangan lupa 50 gram butter




<!--inarticleads2-->

##### Cara membuat  Mexican Bun:

1. Campurkan semua bahan untuk Dough kecuali butter, mixer sampai tercampur semua.
1. Tambahkan 50 gram butter, mixer kembali sampai Kalis elastis.
1. Setelah kalis tutup dengan plastik wrap/kain diamkan selama 1 jam.
1. Kempeskan dough bagi menjadi 10 bagian sama banyak, isi dengan butter secukupnya. Bentuk bulatan dan susu diatas loyang, dan diberi jarak. Diamkan selama 20 menit.
1. Kocok putih telur sampai kaku.
1. Campurkan butter, gula halus, tepung dan kopi instan yang telah dilarutkan, aduk sampai tercampur semua, tambahkan putih telur kemudian aduk perlahan. Tambahkan baking powder aduk sampai tercampur merata.
1. Oleskan toping pada roti yang telah didiamkan sampai bagian atas tertutup semua. Untuk mempermudah pemberian toping bisa menggunakan piping bag.
1. Panaskan oven 180°c, masukan roti di rak atas, panggang di suhu 180°c selama 30 menit. Roti siap dinikmati.




Demikianlah cara membuat mexican bun yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan teruji, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
