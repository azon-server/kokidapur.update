---
description: "Resep : Risol mayo isi ayam dan jagung manis minggu ini"
title: "Resep : Risol mayo isi ayam dan jagung manis minggu ini"
slug: 240-resep-risol-mayo-isi-ayam-dan-jagung-manis-minggu-ini
date: 2020-10-23T07:56:48.138Z
image: https://img-global.cpcdn.com/recipes/6a0c350c858a40d6/680x482cq70/risol-mayo-isi-ayam-dan-jagung-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6a0c350c858a40d6/680x482cq70/risol-mayo-isi-ayam-dan-jagung-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6a0c350c858a40d6/680x482cq70/risol-mayo-isi-ayam-dan-jagung-manis-foto-resep-utama.jpg
author: Lottie Fletcher
ratingvalue: 4.6
reviewcount: 25128
recipeingredient:
- " Bahan kulit "
- "1 butir telur utuh"
- "1 butir kuning telurnya saja"
- "200 gr terigu"
- "1/4 sdt garam"
- "450 ml air"
- "5,5 sdm susu bubuk full cream"
- " Bahan pencelup "
- " tepung roti mama suka yang sudah dichopper"
- " Sisa putih telur  1 butir telur dikocok lepas"
- " Bahan isian "
- "500 gram ayam fillet"
- "5 siung bawang putih"
- "1 buah bawang bombay kecil"
- "2 buah jagung pipil rebus lalu saring"
- "600 ml susu cair UHT"
- "200 gr mayonais"
- "Secukupnya keju parut"
- "1/4 sdt pala bubuk"
- "5 sdm terigu"
- "4 sdm susu kental manis"
- "Secukupnya garam gula pasir kaldu bubuk lada bubuk"
recipeinstructions:
- "Haluskan ayam, bawang putih, dan bawang merah pakai food processor atau chopper"
- "Tumis bahan yg dihaluskan sampai harum dan matang. Beri lada dan pala bubuk. Masukkan terigu lalu aduk rata. Tambahkan susu cair, susu kental, mayo, garam, gula, dan kaldu bubuk. Atur selera manis."
- "Masukkan jagung dan keju. Aduk rata sampai mengental. Koreksi rasa. Dinginkan suhu ruang."
- "Langkah kulit : 1. Larutkan susu bubuk ke dalam air. Sisihkan. 2. Pada wadah, kocok (gunakan whisker) telur dan 1 butir kuning bersama garam. Masukkan terigu bertahap sambil dikocok lalu tuang susu, kocok rata. 3. Panaskan pan anti lengket *api super kecil. Buat dadar tipis sampai adonan habis. Atur besar kecilnya dgn menggoyang2 pan. Bila tidak lengket lagi atasnya, angkat dadar dengan membalik pan ke talenan, hentak sedikit agar lepas. (Gak pakai margarin untuk memudahkan terlepas biar pas dil"
- "Langkah menggoreng : 1. Masukkan isian risol ke dalam tiap kulitnya, lipat sesuai selera. 2. Masukkan ke kocokan telur dan gulingkan ke tepung roti. Ulangi sampai habis. Gunakan tangan berbeda untuk masuk ke wadah telur dan tepung. Masukkan freezer satu jam. 3. Panaskan minyak penuh dgn api sedang. Goreng risol sampai kuning keemasan."
categories:
- Recipe
tags:
- risol
- mayo
- isi

katakunci: risol mayo isi 
nutrition: 156 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT41M"
recipeyield: "2"
recipecategory: Dessert

---


![Risol mayo isi ayam dan jagung manis](https://img-global.cpcdn.com/recipes/6a0c350c858a40d6/680x482cq70/risol-mayo-isi-ayam-dan-jagung-manis-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau empuk. Karasteristik masakan Nusantara risol mayo isi ayam dan jagung manis yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah memasak Risol mayo isi ayam dan jagung manis untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang bisa anda coba salah satunya risol mayo isi ayam dan jagung manis yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep risol mayo isi ayam dan jagung manis tanpa harus bersusah payah.
Berikut ini resep Risol mayo isi ayam dan jagung manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Risol mayo isi ayam dan jagung manis:

1. Diperlukan  Bahan kulit :
1. Siapkan 1 butir telur utuh
1. Diperlukan 1 butir kuning telurnya saja
1. Diperlukan 200 gr terigu
1. Dibutuhkan 1/4 sdt garam
1. Dibutuhkan 450 ml air
1. Harap siapkan 5,5 sdm susu bubuk full cream
1. Harus ada  Bahan pencelup :
1. Harap siapkan  tepung roti mama suka yang sudah dichopper
1. Dibutuhkan  Sisa putih telur + 1 butir telur dikocok lepas
1. Siapkan  Bahan isian :
1. Diperlukan 500 gram ayam fillet
1. Harus ada 5 siung bawang putih
1. Dibutuhkan 1 buah bawang bombay kecil
1. Harap siapkan 2 buah jagung pipil (rebus lalu saring)
1. Jangan lupa 600 ml susu cair UHT
1. Siapkan 200 gr mayonais
1. Dibutuhkan Secukupnya keju parut
1. Tambah 1/4 sdt pala bubuk
1. Tambah 5 sdm terigu
1. Tambah 4 sdm susu kental manis
1. Siapkan Secukupnya garam, gula pasir, kaldu bubuk, lada bubuk




<!--inarticleads2-->

##### Bagaimana membuat  Risol mayo isi ayam dan jagung manis:

1. Haluskan ayam, bawang putih, dan bawang merah pakai food processor atau chopper
1. Tumis bahan yg dihaluskan sampai harum dan matang. Beri lada dan pala bubuk. Masukkan terigu lalu aduk rata. Tambahkan susu cair, susu kental, mayo, garam, gula, dan kaldu bubuk. Atur selera manis.
1. Masukkan jagung dan keju. Aduk rata sampai mengental. Koreksi rasa. Dinginkan suhu ruang.
1. Langkah kulit : - 1. Larutkan susu bubuk ke dalam air. Sisihkan. - 2. Pada wadah, kocok (gunakan whisker) telur dan 1 butir kuning bersama garam. Masukkan terigu bertahap sambil dikocok lalu tuang susu, kocok rata. - 3. Panaskan pan anti lengket *api super kecil. Buat dadar tipis sampai adonan habis. Atur besar kecilnya dgn menggoyang2 pan. Bila tidak lengket lagi atasnya, angkat dadar dengan membalik pan ke talenan, hentak sedikit agar lepas. (Gak pakai margarin untuk memudahkan terlepas biar pas dil
1. Langkah menggoreng : - 1. Masukkan isian risol ke dalam tiap kulitnya, lipat sesuai selera. - 2. Masukkan ke kocokan telur dan gulingkan ke tepung roti. Ulangi sampai habis. Gunakan tangan berbeda untuk masuk ke wadah telur dan tepung. Masukkan freezer satu jam. - 3. Panaskan minyak penuh dgn api sedang. Goreng risol sampai kuning keemasan.




Demikianlah cara membuat risol mayo isi ayam dan jagung manis yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
