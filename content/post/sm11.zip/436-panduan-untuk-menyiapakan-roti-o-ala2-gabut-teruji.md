---
description: "Panduan untuk menyiapakan Roti O ala2 Gabut Teruji"
title: "Panduan untuk menyiapakan Roti O ala2 Gabut Teruji"
slug: 436-panduan-untuk-menyiapakan-roti-o-ala2-gabut-teruji
date: 2021-03-06T05:34:51.098Z
image: https://img-global.cpcdn.com/recipes/03d08bf82e25f585/680x482cq70/roti-o-ala2-gabut-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/03d08bf82e25f585/680x482cq70/roti-o-ala2-gabut-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/03d08bf82e25f585/680x482cq70/roti-o-ala2-gabut-foto-resep-utama.jpg
author: George Drake
ratingvalue: 4.2
reviewcount: 7861
recipeingredient:
- " Adonan "
- "270 gr tepung terigu"
- "5 gr ragi"
- "70 Susu cair"
- "60 susu cair  air jeruk lemonnipis"
- "35 gr Gula halus"
- "40 gr Mentega"
- "3 sdt garam"
- "1 butir telur agak GD"
- " Filling "
- " Mentega gula halus keju boleh mentega saja"
- " Topping "
- "35 gr tepung terigu"
- "25 gr gula halus"
- "70 gr Mentega"
- "10 ml kopi cair"
- "1 butir telur yg agak kecil"
- "1 sdt garam"
recipeinstructions:
- "Adonan topping : mentega, gula halus dimixer, setelah tercampur masukkan telur, dan kopi cair terakhir tepung terigu"
- "Masukkan dalam papping bag dan ke dalam kulkas, keluarkan topping 30 mnt sebelum digunakan"
- "Filling : aduk rata bahan filling dan taruh di wadah plastik kotak, masukkan di freezer, setelah beli di potong2 sesuai jumlah adonan roti"
- "Adonan : campur dan ulen semua bahan selain mentega, setelah Kalis, masukkan mentega. Ulen lagi, pindahkan ke wadah yg telah dioles minyak."
- "Proofing hingga 30 menit/adonan bertambah 2x size ukuran sebelumnya"
- "Bagi adonan menjadi 10, masing-masing (60gr &amp; 6gr). Yg kecil dibagi 9 diisi filling, biarkan 10 menit"
- "Adonan kecil dibungkus adonan besar, dan proffing lg 30-40 menit."
- "Hias roti dengan topping kopi. Panggang dalam oven 180° selama 18-20 menit."
categories:
- Recipe
tags:
- roti
- o
- ala2

katakunci: roti o ala2 
nutrition: 112 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT46M"
recipeyield: "4"
recipecategory: Dessert

---


![Roti O ala2 Gabut](https://img-global.cpcdn.com/recipes/03d08bf82e25f585/680x482cq70/roti-o-ala2-gabut-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang patut kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti roti o ala2 gabut yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Indonesia



Keharmonisan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah memasak Roti O ala2 Gabut untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang dapat anda contoh salah satunya roti o ala2 gabut yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep roti o ala2 gabut tanpa harus bersusah payah.
Seperti resep Roti O ala2 Gabut yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti O ala2 Gabut:

1. Dibutuhkan  Adonan :
1. Tambah 270 gr tepung terigu
1. Diperlukan 5 gr ragi
1. Dibutuhkan 70 Susu cair
1. Dibutuhkan 60 susu cair + air jeruk lemon/nipis
1. Jangan lupa 35 gr Gula halus
1. Siapkan 40 gr Mentega
1. Jangan lupa 3 sdt garam
1. Harap siapkan 1 butir telur agak GD
1. Jangan lupa  Filling :
1. Diperlukan  Mentega, gula halus, keju (boleh mentega saja)
1. Harus ada  Topping :
1. Dibutuhkan 35 gr tepung terigu
1. Siapkan 25 gr gula halus
1. Diperlukan 70 gr Mentega
1. Dibutuhkan 10 ml kopi cair
1. Jangan lupa 1 butir telur yg agak kecil
1. Dibutuhkan 1 sdt garam




<!--inarticleads2-->

##### Instruksi membuat  Roti O ala2 Gabut:

1. Adonan topping : mentega, gula halus dimixer, setelah tercampur masukkan telur, dan kopi cair terakhir tepung terigu
1. Masukkan dalam papping bag dan ke dalam kulkas, keluarkan topping 30 mnt sebelum digunakan
1. Filling : aduk rata bahan filling dan taruh di wadah plastik kotak, masukkan di freezer, setelah beli di potong2 sesuai jumlah adonan roti
1. Adonan : campur dan ulen semua bahan selain mentega, setelah Kalis, masukkan mentega. Ulen lagi, pindahkan ke wadah yg telah dioles minyak.
1. Proofing hingga 30 menit/adonan bertambah 2x size ukuran sebelumnya
1. Bagi adonan menjadi 10, masing-masing (60gr &amp; 6gr). Yg kecil dibagi 9 diisi filling, biarkan 10 menit
1. Adonan kecil dibungkus adonan besar, dan proffing lg 30-40 menit.
1. Hias roti dengan topping kopi. Panggang dalam oven 180° selama 18-20 menit.




Demikianlah cara membuat roti o ala2 gabut yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat simple dan cepat, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
