---
description: "Cara singkat membuat Roti O Favorite"
title: "Cara singkat membuat Roti O Favorite"
slug: 425-cara-singkat-membuat-roti-o-favorite
date: 2021-03-01T03:42:44.800Z
image: https://img-global.cpcdn.com/recipes/0947ab90f9492a11/680x482cq70/roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0947ab90f9492a11/680x482cq70/roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0947ab90f9492a11/680x482cq70/roti-o-foto-resep-utama.jpg
author: Gilbert Rice
ratingvalue: 4.4
reviewcount: 4953
recipeingredient:
- " Bahan Roti"
- "200 gr tepung terigu"
- "70 gr gula pasir sesuai selera"
- "1 sdm susu bubuk"
- "7 sdm susu cair"
- "1 sdt ragi instan"
- "1 btr telur"
- "2 sdm mentega"
- " Bahan Isi"
- " Mentega"
- " Bahan Topping"
- "3 sdm mentega"
- "2 sdm gula bubuk sesuai selera"
- "1 sdt susu cair"
- "7 sdm tepung terigu"
- "1 btr telur"
- "1/2 sdt baking powder"
- "3 sdm cairan kopi"
recipeinstructions:
- "Campur &amp; aduk semua bahan roti kecuali mentega. Setelah menyatu, tambahkan mentega &amp; adon sampai kalis +- 15 menit. Setelah itu diamkan adonan sampai 1 jam."
- "Setelah 1 jam, kempeskan adonan. Bagi adonan menjadi 8 bh. Gepengkan &amp; isi mentega sesuai selera. Lalu dibulatkan. Lakukan sampai selesai. Diamkan lagi adonan sampai 1 jam."
- "Buat adonan topping. Campur mentega, gula bubuk, susu cair, lalu aduk sampai berwarna putih. Campurkan tepung terigu, telur, baking powder, dan cairan kopi. Aduk2 sampai semua menyatu. Simpan dikulkas sebentar +-5 menit."
- "Masukkan adonan topping kedalam plastik &amp; semprotkan ke roti secara melingkar perlahan2."
- "Panaskan oven dgn api kecil selama 15 menit. Lalu masukkan roti &amp; panggang sampai matang +- 50 menit."
- "Selamat mencoba :)"
categories:
- Recipe
tags:
- roti
- o

katakunci: roti o 
nutrition: 172 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT31M"
recipeyield: "1"
recipecategory: Lunch

---


![Roti O](https://img-global.cpcdn.com/recipes/0947ab90f9492a11/680x482cq70/roti-o-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti roti o yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Indonesia

Keharmonisan rumah tangga dapat diperoleh dengan cara simple. Diantaranya adalah membuat makanan Roti O untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis makanan yang dapat anda buat salah satunya roti o yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep roti o tanpa harus bersusah payah.
Seperti resep Roti O yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti O:

1. Harap siapkan  #Bahan Roti
1. Harap siapkan 200 gr tepung terigu
1. Harus ada 70 gr gula pasir (sesuai selera)
1. Harap siapkan 1 sdm susu bubuk
1. Harus ada 7 sdm susu cair
1. Siapkan 1 sdt ragi instan
1. Harap siapkan 1 btr telur
1. Dibutuhkan 2 sdm mentega
1. Harap siapkan  #Bahan Isi
1. Siapkan  Mentega
1. Siapkan  #Bahan Topping
1. Jangan lupa 3 sdm mentega
1. Siapkan 2 sdm gula bubuk (sesuai selera)
1. Diperlukan 1 sdt susu cair
1. Dibutuhkan 7 sdm tepung terigu
1. Harus ada 1 btr telur
1. Dibutuhkan 1/2 sdt baking powder
1. Tambah 3 sdm cairan kopi




<!--inarticleads2-->

##### Cara membuat  Roti O:

1. Campur &amp; aduk semua bahan roti kecuali mentega. Setelah menyatu, tambahkan mentega &amp; adon sampai kalis +- 15 menit. Setelah itu diamkan adonan sampai 1 jam.
1. Setelah 1 jam, kempeskan adonan. Bagi adonan menjadi 8 bh. Gepengkan &amp; isi mentega sesuai selera. Lalu dibulatkan. Lakukan sampai selesai. Diamkan lagi adonan sampai 1 jam.
1. Buat adonan topping. Campur mentega, gula bubuk, susu cair, lalu aduk sampai berwarna putih. Campurkan tepung terigu, telur, baking powder, dan cairan kopi. Aduk2 sampai semua menyatu. Simpan dikulkas sebentar +-5 menit.
1. Masukkan adonan topping kedalam plastik &amp; semprotkan ke roti secara melingkar perlahan2.
1. Panaskan oven dgn api kecil selama 15 menit. Lalu masukkan roti &amp; panggang sampai matang +- 50 menit.
1. Selamat mencoba :)




Demikianlah cara membuat roti o yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan teruji, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
