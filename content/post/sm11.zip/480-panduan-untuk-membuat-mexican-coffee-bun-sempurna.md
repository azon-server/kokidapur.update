---
description: "Panduan untuk membuat Mexican Coffee Bun Sempurna"
title: "Panduan untuk membuat Mexican Coffee Bun Sempurna"
slug: 480-panduan-untuk-membuat-mexican-coffee-bun-sempurna
date: 2021-02-27T19:06:16.138Z
image: https://img-global.cpcdn.com/recipes/b004bdbeade79e3f/680x482cq70/mexican-coffee-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b004bdbeade79e3f/680x482cq70/mexican-coffee-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b004bdbeade79e3f/680x482cq70/mexican-coffee-bun-foto-resep-utama.jpg
author: Travis Peterson
ratingvalue: 4.3
reviewcount: 48221
recipeingredient:
- " Bahan Roti "
- "500 gr tepung protein tinggi"
- "1 bks ragi"
- "50 gr gula pasir"
- "2 butir telur"
- "230 ml susu cair full cream tambahan dari saya"
- "75 gr butter saya palmia butter"
- "1 sdt garam halus"
- " Topping kopi "
- "75 gr butter saya palmia butter"
- "80 gr gula halus"
- "1 butir putih telur"
- "50 gr tepung terigu"
- "15 gr tepung maizena"
- "10 gr tepung beras"
- "1 sdm coklat bubuk"
- "1 bungkus kopi instant classic dilarutkan dengan 1 sdm air panas"
- "1/4 pasta mocca"
- " Bahan isi "
- "160 gr butter bagi masing  10 gr menjadi 16 bagian"
recipeinstructions:
- "Pertama siapkan bahan isi, simpan dalam freezer."
- "Tuang semua bahan roti dalam wadah, kecuali butter dan garam. Tuang susu cair sedikit demi sedikit, uleni hingga tercampur."
- "Masukkan butter dan garam. Uleni dengan mixer hingga kalis. Lalu diamkan hingga menggembang 2x lipat."
- "Sambil menunggu adonan roti mengembang, buat topping kopinya : masukkan semua bahan topping dalam wadah, mixer hingga kental mengembang. Masukkan kedalam plastik segitiga. (saya masukkan kedalam kulkas sebentar)"
- "Setelah adonan roti mengembang, kempiskan adonan, uleni dengan tangan sebentar, bagi adonan menjadi @ 60 gr."
- "Ambil satu adonan, pipihkan, kemudian isi dengan bahan isian. Bulatkan. Lakukan sampai adonan habis. Diamkan sekitar 5 menit."
- "Beri bahan topping dengan gerakan memutar mulai dari tengah seperi obat nyamuk (beri setengah bagian badan roti saja karena nanti akan turun kebawah)"
- "Oven sekitar 30 menit dengan api sedang cenderung besar (saya pakai oven tangkring). Oven hingga bahan topping kering / kenali oven masing² ya 😊"
- "Setelah matang, angkat."
- "Mexican Coffee Bun siap dihidangkan 🤗😊"
- "Enak disajikan saat masih panas, ketika sudah dingin, isiannya akan cenderung terasa asin. Tapi tetap enak kok. Selamat mencoba ya, 💕🤗"
categories:
- Recipe
tags:
- mexican
- coffee
- bun

katakunci: mexican coffee bun 
nutrition: 275 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Dessert

---


![Mexican Coffee Bun](https://img-global.cpcdn.com/recipes/b004bdbeade79e3f/680x482cq70/mexican-coffee-bun-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan renyah. Karasteristik masakan Indonesia mexican coffee bun yang penuh dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah membuat makanan Mexican Coffee Bun untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang bisa anda coba salah satunya mexican coffee bun yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep mexican coffee bun tanpa harus bersusah payah.
Seperti resep Mexican Coffee Bun yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 11 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Mexican Coffee Bun:

1. Harus ada  Bahan Roti :
1. Siapkan 500 gr tepung protein tinggi
1. Tambah 1 bks ragi
1. Jangan lupa 50 gr gula pasir
1. Diperlukan 2 butir telur
1. Jangan lupa 230 ml susu cair full cream (tambahan dari saya)
1. Jangan lupa 75 gr butter (saya palmia butter)
1. Dibutuhkan 1 sdt garam halus
1. Siapkan  Topping kopi :
1. Dibutuhkan 75 gr butter (saya palmia butter)
1. Jangan lupa 80 gr gula halus
1. Dibutuhkan 1 butir putih telur
1. Diperlukan 50 gr tepung terigu
1. Tambah 15 gr tepung maizena
1. Diperlukan 10 gr tepung beras
1. Jangan lupa 1 sdm coklat bubuk
1. Dibutuhkan 1 bungkus kopi instant classic dilarutkan dengan 1 sdm air panas
1. Jangan lupa 1/4 pasta mocca
1. Jangan lupa  Bahan isi :
1. Diperlukan 160 gr butter (bagi masing @ 10 gr menjadi 16 bagian)




<!--inarticleads2-->

##### Cara membuat  Mexican Coffee Bun:

1. Pertama siapkan bahan isi, simpan dalam freezer.
1. Tuang semua bahan roti dalam wadah, kecuali butter dan garam. Tuang susu cair sedikit demi sedikit, uleni hingga tercampur.
1. Masukkan butter dan garam. Uleni dengan mixer hingga kalis. Lalu diamkan hingga menggembang 2x lipat.
1. Sambil menunggu adonan roti mengembang, buat topping kopinya : masukkan semua bahan topping dalam wadah, mixer hingga kental mengembang. Masukkan kedalam plastik segitiga. (saya masukkan kedalam kulkas sebentar)
1. Setelah adonan roti mengembang, kempiskan adonan, uleni dengan tangan sebentar, bagi adonan menjadi @ 60 gr.
1. Ambil satu adonan, pipihkan, kemudian isi dengan bahan isian. Bulatkan. Lakukan sampai adonan habis. Diamkan sekitar 5 menit.
1. Beri bahan topping dengan gerakan memutar mulai dari tengah seperi obat nyamuk (beri setengah bagian badan roti saja karena nanti akan turun kebawah)
1. Oven sekitar 30 menit dengan api sedang cenderung besar (saya pakai oven tangkring). Oven hingga bahan topping kering / kenali oven masing² ya 😊
1. Setelah matang, angkat.
1. Mexican Coffee Bun siap dihidangkan 🤗😊
1. Enak disajikan saat masih panas, ketika sudah dingin, isiannya akan cenderung terasa asin. Tapi tetap enak kok. Selamat mencoba ya, 💕🤗




Demikianlah cara membuat mexican coffee bun yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan teruji, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
