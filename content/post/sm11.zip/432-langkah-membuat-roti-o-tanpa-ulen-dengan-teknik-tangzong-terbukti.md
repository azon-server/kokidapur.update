---
description: "Langkah membuat Roti O tanpa ulen dengan teknik Tangzong Terbukti"
title: "Langkah membuat Roti O tanpa ulen dengan teknik Tangzong Terbukti"
slug: 432-langkah-membuat-roti-o-tanpa-ulen-dengan-teknik-tangzong-terbukti
date: 2020-12-19T04:41:43.451Z
image: https://img-global.cpcdn.com/recipes/29b7cd0598c39482/680x482cq70/roti-o-tanpa-ulen-dengan-teknik-tangzong-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/29b7cd0598c39482/680x482cq70/roti-o-tanpa-ulen-dengan-teknik-tangzong-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/29b7cd0598c39482/680x482cq70/roti-o-tanpa-ulen-dengan-teknik-tangzong-foto-resep-utama.jpg
author: Bess Norton
ratingvalue: 4
reviewcount: 34927
recipeingredient:
- " Bahan dasar tangzong"
- "3 sendok makan tepung terigu"
- "1 gelas susu cair bisa dari 1 sachet SKM atau 1 sachet dancow"
- " Bahan roti"
- "500 gr tepung terigu cakra"
- "1 sachet susu bubuk full cream"
- "1 sendok makan fermipan"
- "7 sendok makan gula pasir"
- "3 sendok makan margarin dicairkan"
- "5 sendok makan makan margarin untuk isian"
- "2 butir kuning telur"
- "50 ml air"
- " Bahan toping"
- "5 sendok makan margarin"
- "5 sendok makan gula halus"
- "1 butir putih telur"
- "1 sendok makan esen moka"
- "1 sendok makan coffe capucino"
- "50 gr tepung"
recipeinstructions:
- "Membuat tangzong: masukkan tepung ke dalam susu, masak di api kecil hingga meletup dan kental"
- "Cairkan margarin: caranya letakkan mangkok steinless atau tahan panas di atas teflon yg diisi air.Didihkan airnya hingga margarin mencair"
- "Siapkan di Baskom, campurkan: tepung terigu, gula pasir, fermipan, tangzong, kuning telur, aduk-aduk"
- "Masukkan margarin cair, aduk, tuang air, aduk lagi sampai kalis"
- "Diamkan selama 3 jam, dengan tutup serbet bersih.Tiap 1 jam dibuka tutup serbet, kempiskan, lalu tutup lagi"
- "Membuat toping: mixer gula halus, margarin sampai tercampur, masukkan putih telur, mixer lagi, masukkan esen moka dan coffe dan tepung"
- "Masukkan toping dalam plastik segitiga, gunting ujungnya"
- "Bagi adonan menjadi 12 bagian.Lebarkan, isi dalamnya dengan margarin, bisa juga ditambah potongan keju kalau suka"
- "Tutup sampai rapat bagian atasnya"
- "Lingkarkan toping di atas adonan"
- "Panaskan oven 10 menit"
- "Masukkan adonan roti"
- "Panggang dengan api atas dan bawah dengan suhu 200 derajat selama 20 menit"
- "Keluarkan, dan sajikan"
categories:
- Recipe
tags:
- roti
- o
- tanpa

katakunci: roti o tanpa 
nutrition: 221 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Dinner

---


![Roti O tanpa ulen dengan teknik Tangzong](https://img-global.cpcdn.com/recipes/29b7cd0598c39482/680x482cq70/roti-o-tanpa-ulen-dengan-teknik-tangzong-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan empuk. Ciri khas masakan Indonesia roti o tanpa ulen dengan teknik tangzong yang penuh dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Resep Dasar Aneka Roti Tanpa Ulen Tanpa Mikser. Resep ROTI TANGZHONG / Water Roux - SUPER LEMBUT SUPER LEMBUT. Roti Sisir &amp; Roti Sobek Autolisis/ tanpa di ulen tetap lembut. dapur yuli. Cocok untuk pembuatan roti dan donat.

Keharmonisan keluarga bisa didapat dengan cara simple. Salah satunya adalah memasak Roti O tanpa ulen dengan teknik Tangzong untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang dapat anda coba salah satunya roti o tanpa ulen dengan teknik tangzong yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep roti o tanpa ulen dengan teknik tangzong tanpa harus bersusah payah.
Seperti resep Roti O tanpa ulen dengan teknik Tangzong yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 14 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti O tanpa ulen dengan teknik Tangzong:

1. Harus ada  Bahan dasar tangzong:
1. Dibutuhkan 3 sendok makan tepung terigu
1. Siapkan 1 gelas susu cair (bisa dari 1 sachet SKM, atau 1 sachet dancow)
1. Harap siapkan  Bahan roti:
1. Tambah 500 gr tepung terigu cakra
1. Siapkan 1 sachet susu bubuk full cream
1. Harus ada 1 sendok makan fermipan
1. Diperlukan 7 sendok makan gula pasir
1. Jangan lupa 3 sendok makan margarin dicairkan
1. Harap siapkan 5 sendok makan makan margarin untuk isian
1. Harus ada 2 butir kuning telur
1. Tambah 50 ml air
1. Harus ada  Bahan toping:
1. Dibutuhkan 5 sendok makan margarin
1. Jangan lupa 5 sendok makan gula halus
1. Harus ada 1 butir putih telur
1. Jangan lupa 1 sendok makan esen moka
1. Dibutuhkan 1 sendok makan coffe capucino
1. Harus ada 50 gr tepung


Resep Dasar Aneka Roti Tanpa Ulen Tanpa Mikser. Nah , hari ini saya bagikan lagi resep roti tawar gandum super sehat karena tanpa gula , tanpa telur dan tanpa butter. yuk dicoba. Roti nya di buat menggunakan teknik tangzhong. Tangzhong Milk Bread Recipe Resep Roti Tangzhong Tanpa Telur. 

<!--inarticleads2-->

##### Langkah membuat  Roti O tanpa ulen dengan teknik Tangzong:

1. Membuat tangzong: masukkan tepung ke dalam susu, masak di api kecil hingga meletup dan kental
1. Cairkan margarin: caranya letakkan mangkok steinless atau tahan panas di atas teflon yg diisi air.Didihkan airnya hingga margarin mencair
1. Siapkan di Baskom, campurkan: tepung terigu, gula pasir, fermipan, tangzong, kuning telur, aduk-aduk
1. Masukkan margarin cair, aduk, tuang air, aduk lagi sampai kalis
1. Diamkan selama 3 jam, dengan tutup serbet bersih.Tiap 1 jam dibuka tutup serbet, kempiskan, lalu tutup lagi
1. Membuat toping: mixer gula halus, margarin sampai tercampur, masukkan putih telur, mixer lagi, masukkan esen moka dan coffe dan tepung
1. Masukkan toping dalam plastik segitiga, gunting ujungnya
1. Bagi adonan menjadi 12 bagian.Lebarkan, isi dalamnya dengan margarin, bisa juga ditambah potongan keju kalau suka
1. Tutup sampai rapat bagian atasnya
1. Lingkarkan toping di atas adonan
1. Panaskan oven 10 menit
1. Masukkan adonan roti
1. Panggang dengan api atas dan bawah dengan suhu 200 derajat selama 20 menit
1. Keluarkan, dan sajikan


Roti nya di buat menggunakan teknik tangzhong. Tangzhong Milk Bread Recipe Resep Roti Tangzhong Tanpa Telur. Resep roti dengan teknik water roux atau tangzhong starter membuat roti empuk dan lembut. Meskipun tanpa telur, tanpa susu atau tanpa kentang, tekstur empuk donat bisa didapatkan dengan menguleni adonan hingga. Resep roti empuk dengan cara water roux/tangzhong #resepdasarroti #Carabuatrotiempuk #rotimetodewaterroux. 

Demikianlah cara membuat roti o tanpa ulen dengan teknik tangzong yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
