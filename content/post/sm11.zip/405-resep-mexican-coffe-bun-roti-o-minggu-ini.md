---
description: "Resep : Mexican coffe bun/ roti o minggu ini"
title: "Resep : Mexican coffe bun/ roti o minggu ini"
slug: 405-resep-mexican-coffe-bun-roti-o-minggu-ini
date: 2020-11-06T21:46:39.878Z
image: https://img-global.cpcdn.com/recipes/36ae80232033825a/680x482cq70/mexican-coffe-bun-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/36ae80232033825a/680x482cq70/mexican-coffe-bun-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/36ae80232033825a/680x482cq70/mexican-coffe-bun-roti-o-foto-resep-utama.jpg
author: Nannie Hernandez
ratingvalue: 4.8
reviewcount: 9272
recipeingredient:
- " Bahan A"
- "150 gr tepung protein tinggicakra"
- "150 ml air hangat"
- "1/4 sdt ragi"
- " Bahan B"
- "250 gr tepung cakra"
- "100 gr tepung segitiga"
- "8 gr ragi"
- "80 gr gula pasir"
- "1 butur telur 1 kuning telur"
- "40-60 ml susu cair"
- "80 gr butter"
- "6 gr garam"
- " Bahan topping"
- "10 gr air hangat"
- "6 gr kopi instanpasta moka sedikit"
- "60 gr butter"
- "50 gr gula"
- "50 gr telur"
- "70 gr tepung terigu"
- " Isian butter 1 sdtbekukan"
recipeinstructions:
- "Bahan A: campur air dan ragi aduk rata,masukan ke tepung aduk hingga rata diamkan 1 jam di suhu ruang dan 16 jam di kulkas memakai cling wrap"
- "Bahan B: campur semua adonan beserta bahan A kecuali butter dan garam aduk hingga setengah kalis"
- "Masukan butter dan garam aduk lagi hingga kalis"
- "Diamkan adonan selama -+1 jam,timbang adonan 60 gr dan bulatkan diamkan lagi selama 10 menit"
- "Isi adonan dengan butter yg dingin dan bulatkan lagi, diamkan hingga mengembang 2x lipat"
- "Bahan topping: aduk butter dan gula,masukan telur dan larutan kopi terakhir masukan tepung aduk rata semua"
- "Semprotkan topping melingkar di atas roti"
- "Panggang suhu 180’ selama 20 menit"
categories:
- Recipe
tags:
- mexican
- coffe
- bun

katakunci: mexican coffe bun 
nutrition: 143 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dinner

---


![Mexican coffe bun/ roti o](https://img-global.cpcdn.com/recipes/36ae80232033825a/680x482cq70/mexican-coffe-bun-roti-o-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan enak. Ciri khas kuliner Nusantara mexican coffe bun/ roti o yang penuh dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Mexican coffe bun/ roti o untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang dapat anda contoh salah satunya mexican coffe bun/ roti o yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep mexican coffe bun/ roti o tanpa harus bersusah payah.
Berikut ini resep Mexican coffe bun/ roti o yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican coffe bun/ roti o:

1. Siapkan  Bahan A:
1. Tambah 150 gr tepung protein tinggi/cakra
1. Harap siapkan 150 ml air hangat
1. Harus ada 1/4 sdt ragi
1. Dibutuhkan  Bahan B:
1. Diperlukan 250 gr tepung cakra
1. Siapkan 100 gr tepung segitiga
1. Siapkan 8 gr ragi
1. Tambah 80 gr gula pasir
1. Dibutuhkan 1 butur telur +1 kuning telur
1. Jangan lupa 40-60 ml susu cair
1. Harap siapkan 80 gr butter
1. Diperlukan 6 gr garam
1. Diperlukan  Bahan topping:
1. Tambah 10 gr air hangat
1. Dibutuhkan 6 gr kopi instan&amp;pasta moka sedikit
1. Diperlukan 60 gr butter
1. Tambah 50 gr gula
1. Tambah 50 gr telur
1. Dibutuhkan 70 gr tepung terigu
1. Diperlukan  Isian: butter 1 sdt,bekukan




<!--inarticleads2-->

##### Bagaimana membuat  Mexican coffe bun/ roti o:

1. Bahan A: campur air dan ragi aduk rata,masukan ke tepung aduk hingga rata diamkan 1 jam di suhu ruang dan 16 jam di kulkas memakai cling wrap
1. Bahan B: campur semua adonan beserta bahan A kecuali butter dan garam aduk hingga setengah kalis
1. Masukan butter dan garam aduk lagi hingga kalis
1. Diamkan adonan selama -+1 jam,timbang adonan 60 gr dan bulatkan diamkan lagi selama 10 menit
1. Isi adonan dengan butter yg dingin dan bulatkan lagi, diamkan hingga mengembang 2x lipat
1. Bahan topping: aduk butter dan gula,masukan telur dan larutan kopi terakhir masukan tepung aduk rata semua
1. Semprotkan topping melingkar di atas roti
1. Panggang suhu 180’ selama 20 menit




Demikianlah cara membuat mexican coffe bun/ roti o yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat gampang dan cepat, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
