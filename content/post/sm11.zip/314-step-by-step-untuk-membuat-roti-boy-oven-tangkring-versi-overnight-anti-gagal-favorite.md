---
description: "Step-by-Step untuk membuat Roti Boy Oven Tangkring | Versi Overnight Anti Gagal Favorite"
title: "Step-by-Step untuk membuat Roti Boy Oven Tangkring | Versi Overnight Anti Gagal Favorite"
slug: 314-step-by-step-untuk-membuat-roti-boy-oven-tangkring-versi-overnight-anti-gagal-favorite
date: 2020-11-17T06:24:55.906Z
image: https://img-global.cpcdn.com/recipes/80dbe982bf642578/680x482cq70/roti-boy-oven-tangkring-versi-overnight-anti-gagal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/80dbe982bf642578/680x482cq70/roti-boy-oven-tangkring-versi-overnight-anti-gagal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/80dbe982bf642578/680x482cq70/roti-boy-oven-tangkring-versi-overnight-anti-gagal-foto-resep-utama.jpg
author: Mattie Curry
ratingvalue: 4
reviewcount: 45212
recipeingredient:
- " Bahan A"
- "215 gr terigu protein tinggi"
- "125 ml susu cair dingin"
- "1 sdt ragi instant"
- " Bahan B"
- " Adonan Bahan A yang sudah di kulkas minimal 12 jam"
- "90 gr terigu protein tinggi"
- "30 gr telur"
- "2 sdt ragi instant"
- "1/2 sdt garam"
- "4 sdm gula pasir"
- "45 gr butter suhu ruang"
- "1 sdm susu cair dingin"
- " Topping"
- "50 gr butter"
- "2 sdm munjung gula halus"
- "50 gr terigu serbaguna"
- "1/4 sdt baking powder"
- "1 btr putih telur"
- "1 sdt kopi instant diseduh dengan 1 sdm air panas jika kurang gelap warnanya bisa ditambah lagi takaran kopinya"
- "Jika suka bisa ditambahkan pasta moka"
- " Filling"
- "25 gr butter"
- "25 gr keju parut campur rata dengan butter Bulatkan menjadi 1012 bagian Sesuai jumlah rotinya Sisihkan"
- " u isi sy biasa pake keju mozarella homemade karena lebih lumer dan gurih2 manis gitu resep sudah diposting sblmnya y"
recipeinstructions:
- "Campur semua bahan A. Aduk rata mengunakan tangan. Uleni sebentar hingga agak kalis. Adonan akan Nampak sedikit kasar tapi juga lengket."
- "Tutup wadah dengan kain atau wrap. Simpan di kulkas semalaman (min 12 jam). Saya cuma pake kresek :D"
- "Setelah 12 jam keluarkan dari kulkas lalu sobek-sobek adonan A."
- "Tambahkan adona B ke dalam adonan A kecuali butter. Uleni hingga kalis (tidak lengket)."
- "Tambahkan butternya, uleni hingga kalis elastis. Ciri-ciri adonan sudah kalis elastis yaitu ketika dilebarkan maka adonan tidak robek dan lentur."
- "Bulatkan."
- "Selanjutnya tutup dengan plastik atau kain dan diamkan hingga mengembang 2x lipat (kira-kira 1-2 jam tergantung suhu ruang."
- "Ini dia setelah mengembang."
- "Bagi adonan menjadi beberapa bagian. Jika ingin seukuran yang sama dengan roti boy maka bagi menjadi 10 bagian masing-masing kira-kira seberat 50 gram. Jika ingin lebih kecil lagi bisa dibagi menjadi 12-14 bagian, sesuai selera."
- "Pipihkan adonan lalu isi dengan isian mentega+keju. Bulatkan."
- "Diamkan selama 25 menit."
- "Sambil menunggu, kita buat toppingnya: kocok putih telur hingga kaku. Ssisihkan. Di wadah terpisah, kocok butter + gula halus hingga lembut. Lalu, campurkan tepung + baking powder, adonan putih telur tadi, dan seduhan kopi instant+pasta moka. Aduk rata."
- "Masukan ke dalam piping bag. Simpan di kulkas."
- "Setelah adonan roti tadi mengembang, semprotkan topping roti dengan gerakan melingkar seperti obat nyamuk. Usahakan rapat lingkarannya yah."
- "Tempatkan di Loyang yang dialasi kertas panggang atau diolesi margarine. Tata dengan jarak berjauhan agar tidak dempet saat matang. Panggang selama 15-20 menit dengan suhu 180 dercel. Kalau saya ini pake oven tangkring jadi gak pake suhu dikira2 aja haha.. Manggangnya sampek 45 menit lebih dengan api kecil."
- "Angkat. NOTE: ini hasil adonan yang dibagi jadi 10, masing-masing 50 gram. Sudah jauh-jauhan juga masih sedikit dempet kan ckckckck"
- "Nikmat disajikan panas-panas dengan teh hangat. NOTE: ini hasil adonan yang dibagi menjadi 12 biji. Terlihat lebih kecil."
- "NOTE TAMBAHAN: Ternyata kalau ngulenin adonannya menggunakan dough mixer, lebih maksimal lagi bund. Dus, meski dibagi jadi 13 biji rotinya masih bisa segede roti boy asli uy. Meuni lembut pisaaan tekstur rotinya, mirip banget deh sama yang asli :p Walah mantap pokoknya mah :) Dan ini sudah menggunakan oven listrik tapi justru sampai sekarang saya kalau bikin pake oven listrik belum bisa maksimal hasilnya. Hiks.. selalu kempes atasnya.. Ada yang tau kenapa???"
- "TIPS SEPUTAR ROTI BOY ANTI GAGAL: 1. Agar hasil toppingnya cantik dan rata, pastikan saat menyemprot topping, jarak lingkarannya rapat. Jika ada renggang biasanya juga saat matang, masih ada bagian yang tidak tertutup sempurna di permukaan roti."
- "2. Untuk gelap-terangnya warna topping tidak hanya bergantung pada takaran kopi tetapi juga pada jenis kopi instan yang digunakan. Jika warna kopi pekat, maka cukup 1 sdt kopi sudah menghasilkan warna yang cokelatnya sama dengan Roti Boy. Tapi jika menggunakan kopi warna moka, maka sebaiknya takaran kopi ditambah lagi."
- "3. Saat menyemprotkan Topping, jangan mentok sampai bawah ya, sisakan sedikit di bagian bawah. Sehingga hasilnya rapi dan melelehnya pas: tidak sampai blepotan ke mana-mana. Selain tampilannya jadi kurang cantik, juga susah saat diambil dari Loyang."
- "4. Saat akan dipanggang, ketika menata roti di Loyang, usahakan berjarak yang agak jauh ya, jadi tidak saling dempet saat matang. Sehingga tetap terlihat cantik saat diangkat dari Loyang."
- "5. Kita juga bisa menggantikan butter dengan penggunaan roombutter, atau juga B.O.S (Butter oil Subtitute) yang harganya jauh lebih terjangkau. Hasilnya tetap enak hanya untuk wanginya masih kalah dengan yang menggunakan butter."
- "Yang ini dibikin super petite, jadi satu resep jadi 16. Mungil banget deh, tapi isiannya berlimpah. Kemaren nyoba pake keju mozzarella homemade buat isiannya (resep keju mozza KW ada di postingan sebelumnya). Ternyata enak juga.. gurih2 manis gimana gitu...Recomended deh!"
- "Selamat mencoba :)"
categories:
- Recipe
tags:
- roti
- boy
- oven

katakunci: roti boy oven 
nutrition: 209 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Lunch

---


![Roti Boy Oven Tangkring | Versi Overnight Anti Gagal](https://img-global.cpcdn.com/recipes/80dbe982bf642578/680x482cq70/roti-boy-oven-tangkring-versi-overnight-anti-gagal-foto-resep-utama.jpg)
 versi overnight anti gagal yang penuh dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.

 Versi Overnight Anti Gagal untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang bisa anda buat salah satunya roti boy oven tangkring | versi overnight anti gagal yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep roti boy oven tangkring | versi overnight anti gagal tanpa harus bersusah payah.
Berikut ini resep Roti Boy Oven Tangkring | Versi Overnight Anti Gagal yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 25 bahan dan 25 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Boy Oven Tangkring | Versi Overnight Anti Gagal:

1. Harap siapkan  Bahan A
1. Dibutuhkan 215 gr terigu protein tinggi
1. Dibutuhkan 125 ml susu cair dingin
1. Tambah 1 sdt ragi instant
1. Siapkan  Bahan B
1. Tambah  Adonan Bahan A yang sudah di kulkas minimal 12 jam
1. Diperlukan 90 gr terigu protein tinggi
1. Harap siapkan 30 gr telur
1. Harap siapkan 2 sdt ragi instant
1. Siapkan 1/2 sdt garam
1. Diperlukan 4 sdm gula pasir
1. Jangan lupa 45 gr butter, suhu ruang
1. Harus ada 1 sdm susu cair dingin
1. Harus ada  Topping:
1. Tambah 50 gr butter
1. Tambah 2 sdm munjung gula halus
1. Siapkan 50 gr terigu serbaguna
1. Siapkan 1/4 sdt baking powder
1. Jangan lupa 1 btr putih telur
1. Dibutuhkan 1 sdt kopi instant, diseduh dengan 1 sdm air panas (jika kurang gelap warnanya bisa ditambah lagi takaran kopinya)
1. Jangan lupa Jika suka bisa ditambahkan pasta moka
1. Siapkan  Filling:
1. Diperlukan 25 gr butter
1. Siapkan 25 gr keju parut, campur rata dengan butter. Bulatkan menjadi 10-12 bagian. Sesuai jumlah rotinya. Sisihkan
1. Jangan lupa  (u/ isi sy biasa pake keju mozarella homemade, karena lebih lumer dan gurih2 manis gitu, resep sudah diposting sblmnya y)




<!--inarticleads2-->

##### Cara membuat  Roti Boy Oven Tangkring | Versi Overnight Anti Gagal:

1. Campur semua bahan A. Aduk rata mengunakan tangan. Uleni sebentar hingga agak kalis. Adonan akan Nampak sedikit kasar tapi juga lengket.
1. Tutup wadah dengan kain atau wrap. Simpan di kulkas semalaman (min 12 jam). Saya cuma pake kresek :D
1. Setelah 12 jam keluarkan dari kulkas lalu sobek-sobek adonan A.
1. Tambahkan adona B ke dalam adonan A kecuali butter. Uleni hingga kalis (tidak lengket).
1. Tambahkan butternya, uleni hingga kalis elastis. Ciri-ciri adonan sudah kalis elastis yaitu ketika dilebarkan maka adonan tidak robek dan lentur.
1. Bulatkan.
1. Selanjutnya tutup dengan plastik atau kain dan diamkan hingga mengembang 2x lipat (kira-kira 1-2 jam tergantung suhu ruang.
1. Ini dia setelah mengembang.
1. Bagi adonan menjadi beberapa bagian. Jika ingin seukuran yang sama dengan roti boy maka bagi menjadi 10 bagian masing-masing kira-kira seberat 50 gram. Jika ingin lebih kecil lagi bisa dibagi menjadi 12-14 bagian, sesuai selera.
1. Pipihkan adonan lalu isi dengan isian mentega+keju. Bulatkan.
1. Diamkan selama 25 menit.
1. Sambil menunggu, kita buat toppingnya: kocok putih telur hingga kaku. Ssisihkan. Di wadah terpisah, kocok butter + gula halus hingga lembut. Lalu, campurkan tepung + baking powder, adonan putih telur tadi, dan seduhan kopi instant+pasta moka. Aduk rata.
1. Masukan ke dalam piping bag. Simpan di kulkas.
1. Setelah adonan roti tadi mengembang, semprotkan topping roti dengan gerakan melingkar seperti obat nyamuk. Usahakan rapat lingkarannya yah.
1. Tempatkan di Loyang yang dialasi kertas panggang atau diolesi margarine. Tata dengan jarak berjauhan agar tidak dempet saat matang. Panggang selama 15-20 menit dengan suhu 180 dercel. Kalau saya ini pake oven tangkring jadi gak pake suhu dikira2 aja haha.. Manggangnya sampek 45 menit lebih dengan api kecil.
1. Angkat. NOTE: ini hasil adonan yang dibagi jadi 10, masing-masing 50 gram. Sudah jauh-jauhan juga masih sedikit dempet kan ckckckck
1. Nikmat disajikan panas-panas dengan teh hangat. NOTE: ini hasil adonan yang dibagi menjadi 12 biji. Terlihat lebih kecil.
1. NOTE TAMBAHAN: Ternyata kalau ngulenin adonannya menggunakan dough mixer, lebih maksimal lagi bund. Dus, meski dibagi jadi 13 biji rotinya masih bisa segede roti boy asli uy. Meuni lembut pisaaan tekstur rotinya, mirip banget deh sama yang asli :p Walah mantap pokoknya mah :) Dan ini sudah menggunakan oven listrik tapi justru sampai sekarang saya kalau bikin pake oven listrik belum bisa maksimal hasilnya. Hiks.. selalu kempes atasnya.. Ada yang tau kenapa???
1. TIPS SEPUTAR ROTI BOY ANTI GAGAL: 1. Agar hasil toppingnya cantik dan rata, pastikan saat menyemprot topping, jarak lingkarannya rapat. Jika ada renggang biasanya juga saat matang, masih ada bagian yang tidak tertutup sempurna di permukaan roti.
1. 2. Untuk gelap-terangnya warna topping tidak hanya bergantung pada takaran kopi tetapi juga pada jenis kopi instan yang digunakan. Jika warna kopi pekat, maka cukup 1 sdt kopi sudah menghasilkan warna yang cokelatnya sama dengan Roti Boy. Tapi jika menggunakan kopi warna moka, maka sebaiknya takaran kopi ditambah lagi.
1. 3. Saat menyemprotkan Topping, jangan mentok sampai bawah ya, sisakan sedikit di bagian bawah. Sehingga hasilnya rapi dan melelehnya pas: tidak sampai blepotan ke mana-mana. Selain tampilannya jadi kurang cantik, juga susah saat diambil dari Loyang.
1. 4. Saat akan dipanggang, ketika menata roti di Loyang, usahakan berjarak yang agak jauh ya, jadi tidak saling dempet saat matang. Sehingga tetap terlihat cantik saat diangkat dari Loyang.
1. 5. Kita juga bisa menggantikan butter dengan penggunaan roombutter, atau juga B.O.S (Butter oil Subtitute) yang harganya jauh lebih terjangkau. Hasilnya tetap enak hanya untuk wanginya masih kalah dengan yang menggunakan butter.
1. Yang ini dibikin super petite, jadi satu resep jadi 16. Mungil banget deh, tapi isiannya berlimpah. Kemaren nyoba pake keju mozzarella homemade buat isiannya (resep keju mozza KW ada di postingan sebelumnya). Ternyata enak juga.. gurih2 manis gimana gitu...Recomended deh!
1. Selamat mencoba :)




Demikianlah cara membuat roti boy oven tangkring | versi overnight anti gagal yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan teruji, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
