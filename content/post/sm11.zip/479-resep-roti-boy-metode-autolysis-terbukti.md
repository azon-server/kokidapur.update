---
description: "Resep : Roti boy metode autolysis Terbukti"
title: "Resep : Roti boy metode autolysis Terbukti"
slug: 479-resep-roti-boy-metode-autolysis-terbukti
date: 2021-02-11T14:45:44.450Z
image: https://img-global.cpcdn.com/recipes/495a5f8474a6e239/680x482cq70/roti-boy-metode-autolysis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/495a5f8474a6e239/680x482cq70/roti-boy-metode-autolysis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/495a5f8474a6e239/680x482cq70/roti-boy-metode-autolysis-foto-resep-utama.jpg
author: Nelle Wells
ratingvalue: 5
reviewcount: 24725
recipeingredient:
- "250 gr tepung segitiga biru"
- "1 kuning telur"
- "1 sdm susu bubuk"
- "40 gr gula pasir"
- "110 ml susu cair dingin"
- "1 sdt ragi"
- "Sejumput garam"
- "30 gr margarin"
- " Isian"
- " Margarin"
- " Topping"
- "1 putih telor"
- "1 bks kopi luwak"
- "50 gr tepung"
- "50 gr margarin"
- "35 gr gula"
- "2 sdm air"
recipeinstructions:
- "Campur tepung, susu bubuk, kuning telur dan gula,tuang air susu sedikit demi sedikit sambil diulen (gak perlu sampai kalis) tutup menggunakan plastik/serbet dan diamkan selama 4 jam"
- "Setelah 4 jam, campur ragi dengan 1sdm air hingga menjadi pasta dan campur kedalam adonan tadi ulen 5 menit"
- "Setelah itu Masukkan garam dan margarin, ulen lagi sampai adonan kalis, metode ini 7-10 menit ngulen sdh kalis elastis jd tangan gak terlalu capek. 😁"
- "Diamkan -+ 30 menit atau sampai memgembang 2x lipat"
- "Selagi nunggu qt buat toppingnya Campur kopi dengan 2sdm air, lalu tambahkan bahan lainnya, aduk sampai tercampur rata dan masukkan ke dalam piping bag"
- "Setelah mengembang, ulen sebentar untuk membuang angin, bagi menjadi beberapa bagian (me: 35gr)"
- "Bulatkan masing2 adonan dan tata di loyang, beri jarak 1 sama lain. Istirahatkan lg -+ 1 jam"
- "Setelah -+ 1 jam panaskan oven selama 10 menit. beri adonan dengan topping kopi dengan cara melingkar"
- "Panggang selama 25 menit sesuaikan dengan oven masing2 ya mom, kalo toppingnya ingin lebih kering bisa di panggang lebih lama."
categories:
- Recipe
tags:
- roti
- boy
- metode

katakunci: roti boy metode 
nutrition: 279 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Lunch

---


![Roti boy metode autolysis](https://img-global.cpcdn.com/recipes/495a5f8474a6e239/680x482cq70/roti-boy-metode-autolysis-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan empuk. Ciri kuliner Indonesia roti boy metode autolysis yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Roti boy metode autolysis untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang dapat anda buat salah satunya roti boy metode autolysis yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep roti boy metode autolysis tanpa harus bersusah payah.
Berikut ini resep Roti boy metode autolysis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti boy metode autolysis:

1. Tambah 250 gr tepung segitiga biru
1. Jangan lupa 1 kuning telur
1. Harap siapkan 1 sdm susu bubuk
1. Dibutuhkan 40 gr gula pasir
1. Tambah 110 ml susu cair dingin
1. Diperlukan 1 sdt ragi
1. Dibutuhkan Sejumput garam
1. Siapkan 30 gr margarin
1. Diperlukan  Isian
1. Harap siapkan  Margarin
1. Tambah  Topping
1. Harap siapkan 1 putih telor
1. Siapkan 1 bks kopi luwak
1. Tambah 50 gr tepung
1. Dibutuhkan 50 gr margarin
1. Harus ada 35 gr gula
1. Jangan lupa 2 sdm air




<!--inarticleads2-->

##### Cara membuat  Roti boy metode autolysis:

1. Campur tepung, susu bubuk, kuning telur dan gula,tuang air susu sedikit demi sedikit sambil diulen (gak perlu sampai kalis) tutup menggunakan plastik/serbet dan diamkan selama 4 jam
1. Setelah 4 jam, campur ragi dengan 1sdm air hingga menjadi pasta dan campur kedalam adonan tadi ulen 5 menit
1. Setelah itu Masukkan garam dan margarin, ulen lagi sampai adonan kalis, metode ini 7-10 menit ngulen sdh kalis elastis jd tangan gak terlalu capek. 😁
1. Diamkan -+ 30 menit atau sampai memgembang 2x lipat
1. Selagi nunggu qt buat toppingnya - Campur kopi dengan 2sdm air, lalu tambahkan bahan lainnya, aduk sampai tercampur rata dan masukkan ke dalam piping bag
1. Setelah mengembang, ulen sebentar untuk membuang angin, bagi menjadi beberapa bagian (me: 35gr)
1. Bulatkan masing2 adonan dan tata di loyang, beri jarak 1 sama lain. Istirahatkan lg -+ 1 jam
1. Setelah -+ 1 jam panaskan oven selama 10 menit. - beri adonan dengan topping kopi dengan cara melingkar
1. Panggang selama 25 menit sesuaikan dengan oven masing2 ya mom, kalo toppingnya ingin lebih kering bisa di panggang lebih lama.




Demikianlah cara membuat roti boy metode autolysis yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan cepat, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
