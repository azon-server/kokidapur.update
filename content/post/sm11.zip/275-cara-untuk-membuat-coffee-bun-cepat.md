---
description: "Cara untuk membuat Coffee Bun Cepat"
title: "Cara untuk membuat Coffee Bun Cepat"
slug: 275-cara-untuk-membuat-coffee-bun-cepat
date: 2021-01-05T10:19:10.511Z
image: https://img-global.cpcdn.com/recipes/d87bbb976e8e39f3/680x482cq70/coffee-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d87bbb976e8e39f3/680x482cq70/coffee-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d87bbb976e8e39f3/680x482cq70/coffee-bun-foto-resep-utama.jpg
author: Randall Nunez
ratingvalue: 4.6
reviewcount: 11101
recipeingredient:
- " Bahan Roti"
- "110 gr Air"
- "7 gr Ragi instant"
- "35 gr Gula pasir"
- "7 gr Garam"
- "100 gr Susu"
- "350 gr Tepung protein tinggi"
- "20 gr Butter aku pake Hollman"
- " Topping Coffee"
- "60 gr Butter"
- "60 gr Gula halus"
- "1 butir telur pisah kuning dan putihnya"
- "1 bungkus kopi goodday vanilla ini wangi bgt"
- "1/2 sdm nescafe classic"
- "70 gr Tepung protein sedang"
- " Isi roti"
- "5 sdm butter"
recipeinstructions:
- "Campur air, ragi, gula, garam, susu hingga rata, kemudian masukan tepung dan uleni hingga rata setelah itu diamkan 5 menit"
- "Ambil adonan diatas alas adonan roti kemudian uleni kembali lalu tambahakan 20 gr butter kemudian uleni sampai kalis, banting2 dan tekan sekita 5-7 menit sampai adonan benar2 mulus. Setelah itu tutup adonan dengan plastic wrap selama 1 jam. (Akan mengembang 2x lipat)"
- "Setelah 1 jam bagi adonan menjadi 10 bagian kemudian bulat2 kan diatas loyang lalu tutup dengan plastic wrap lagi 15 menit"
- "Next buat topping coffee, campurkan butter dan gula halus hingga rata, lalu masukan kuning telur aduk rata, masukan putih telur aduk rata lalu masukan kopi good day dan nescafenya kemudian aduk rata, terakhir masukan tepung terigunya, lalu aduk rata. Setelah itu masukan kedalam piping bag."
- "Balik ke adonan rotinya, setelah itu masukan isiannya dengan 1/2 sdm butter masing2 lalu bulatkan kembali yang tinggi ke atas yaa supaya bagus. Kemudian tutup dengan plastic wrap kembali diamkan selama 1 jam"
- "Terakhir tuang toping membentuk lingkaran pusat ditengah, mengelilingi permukaan atas roti hingga tertutup 3/4nya."
- "Panggang roti 180 derajat selama 15 menit(atau sesuai oven masing2)"
categories:
- Recipe
tags:
- coffee
- bun

katakunci: coffee bun 
nutrition: 163 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Lunch

---


![Coffee Bun](https://img-global.cpcdn.com/recipes/d87bbb976e8e39f3/680x482cq70/coffee-bun-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang setidaknya kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti coffee bun yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Kita



Kehangatan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Coffee Bun untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang dapat anda contoh salah satunya coffee bun yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep coffee bun tanpa harus bersusah payah.
Seperti resep Coffee Bun yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Coffee Bun:

1. Tambah  Bahan Roti
1. Siapkan 110 gr Air
1. Diperlukan 7 gr Ragi instant
1. Siapkan 35 gr Gula pasir
1. Tambah 7 gr Garam
1. Siapkan 100 gr Susu
1. Siapkan 350 gr Tepung protein tinggi
1. Jangan lupa 20 gr Butter (aku pake Hollman)
1. Dibutuhkan  Topping Coffee
1. Harap siapkan 60 gr Butter
1. Jangan lupa 60 gr Gula halus
1. Diperlukan 1 butir telur (pisah kuning dan putihnya)
1. Jangan lupa 1 bungkus kopi goodday vanilla (ini wangi bgt)
1. Jangan lupa 1/2 sdm nescafe classic
1. Siapkan 70 gr Tepung protein sedang
1. Harap siapkan  Isi roti
1. Harap siapkan 5 sdm butter




<!--inarticleads2-->

##### Instruksi membuat  Coffee Bun:

1. Campur air, ragi, gula, garam, susu hingga rata, kemudian masukan tepung dan uleni hingga rata setelah itu diamkan 5 menit
1. Ambil adonan diatas alas adonan roti kemudian uleni kembali lalu tambahakan 20 gr butter kemudian uleni sampai kalis, banting2 dan tekan sekita 5-7 menit sampai adonan benar2 mulus. Setelah itu tutup adonan dengan plastic wrap selama 1 jam. (Akan mengembang 2x lipat)
1. Setelah 1 jam bagi adonan menjadi 10 bagian kemudian bulat2 kan diatas loyang lalu tutup dengan plastic wrap lagi 15 menit
1. Next buat topping coffee, campurkan butter dan gula halus hingga rata, lalu masukan kuning telur aduk rata, masukan putih telur aduk rata lalu masukan kopi good day dan nescafenya kemudian aduk rata, terakhir masukan tepung terigunya, lalu aduk rata. Setelah itu masukan kedalam piping bag.
1. Balik ke adonan rotinya, setelah itu masukan isiannya dengan 1/2 sdm butter masing2 lalu bulatkan kembali yang tinggi ke atas yaa supaya bagus. Kemudian tutup dengan plastic wrap kembali diamkan selama 1 jam
1. Terakhir tuang toping membentuk lingkaran pusat ditengah, mengelilingi permukaan atas roti hingga tertutup 3/4nya.
1. Panggang roti 180 derajat selama 15 menit(atau sesuai oven masing2)




Demikianlah cara membuat coffee bun yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan cepat, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
