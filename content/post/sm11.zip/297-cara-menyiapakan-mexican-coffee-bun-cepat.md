---
description: "Cara menyiapakan Mexican Coffee Bun Cepat"
title: "Cara menyiapakan Mexican Coffee Bun Cepat"
slug: 297-cara-menyiapakan-mexican-coffee-bun-cepat
date: 2020-11-12T05:53:14.471Z
image: https://img-global.cpcdn.com/recipes/6069ae50e74fe21d/680x482cq70/mexican-coffee-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6069ae50e74fe21d/680x482cq70/mexican-coffee-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6069ae50e74fe21d/680x482cq70/mexican-coffee-bun-foto-resep-utama.jpg
author: Alfred Pearson
ratingvalue: 4.3
reviewcount: 14561
recipeingredient:
- " Tangzhong starter"
- "125 ml susu ultra jaya full cream"
- "25 gram terigu protein tinggi"
- " Main dough"
- "500 gram tepung terigu tinggi protein"
- "1 sdm ragi instan aku pake fermipan"
- "1 sdm susu bubuk full cream"
- "100 gram gula aku pake gula halus"
- "1/2 sdt garam"
- "1 butir telur"
- "135 ml susu ultra jaya full cream"
- "75 ml fresh cream aku pake anchor"
- "4 sdm wysman"
- " Topping"
- "100 gram wysmanblueband"
- "100 gram gula halus"
- "2 butir telur"
- "3 sdt kopi instan aku pake nescaffee classic"
- "1/2 sdt vanili"
- "1/2 sdt garam halus"
- "120 gram tepung terigu serbaguna"
recipeinstructions:
- "Thangzong Starter: Siapkan panci kecil, masukkan tepung dan susu cair ke dalam panci. Aduk menggunakan spatula hingga tepung larut dan tidak berbutir-butir. Panaskan panci di kompor dan masak menggunakan api kecil, aduk-aduk hingga menjadi adonan yang licin dan kental. Tidak sampai adonan meletup."
- "Main dough: Siapkan mangkuk besar, masukkan bahan-bahan kering: tepung terigu, ragi, garam, gula pasir halus, susu bubuk, aduk hingga benar-benar rata usahakan agar ragi tidak bertemu langsung dengan garam."
- "Siapkan mangkuk besar, masukkan bahan-bahan basah: adonan tangzhong, telur, susu cair, fresh cream, aduk menggunakan spatula hingga rata. Masukkan bahan kering aduk menggunakan jari-jari tangan. Jika telah menyatu, tambahkan butter/blueband dan uleni."
- "Siapkan meja datar, taburi tepung terigu, tuangkan adonan ke atasnya. Uleni adonan dengan menekannya menggunakan puncak telapak tangan dan mendorongnya menjauhi badan anda. Putar adonan selama menguleni sehingga semua sisi adonan terproses dengan baik. Uleni selama + 30 menit hingga menjadi adonan yang smooth dan halus. Masukkan adonan ke dalam mangkuk yang telah diolesi dengan sedikit minyak. Tutup dengan plastik dan biarkan selama 1 jam. (quick proofing)"
- "Sambil nunggu proofing kita siapkan adonan topping. Kocok gula halus dan butter/blueband sampai rata, masukkan 2 butir telur dan vanili, seduh 3 shacet nescaffee clasic dengan 1 sdm air hangat, masukkan ke dalam adonan dan kocok sebentar terakhir masukkan tepung trigu serbaguna kocok sampai homogen. Masukkan ke dalam kantong plastik."
- "Kempiskan adonan dan bagi adonan menjadi 20 bulatan dg berat yang sama. 5 bulatan dibagi menjadi 15 bagian kecil-kecil untuk membungkus butter untuk isian."
- "Setelah isian selesai ambil bagian adonan tadi untuk diisi dg bulatan kecil berisi butter/blueband. Bulatkan dan tata di loyang yg sudah dialasi kertas roti atau letakkan dlm cup kertas diamkan kurang lebih 3 jam."
- "Gunting ujung plastik yang berisi topping dan semprotkan di atas adonan yg sudah mengembang di loyang dengan gerakan menyerupai obat nyamuk."
- "Panggang selama kurang lebih 15 menit. Bila adonan sudah matang topping cookie crush akan terasa crunchy."
- ""
- "Note: Adonan utama juga bisa dilakukan dengan cara slow proofing dengan menyimpannya di dalam chiller semalam suntuk."
categories:
- Recipe
tags:
- mexican
- coffee
- bun

katakunci: mexican coffee bun 
nutrition: 154 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Lunch

---


![Mexican Coffee Bun](https://img-global.cpcdn.com/recipes/6069ae50e74fe21d/680x482cq70/mexican-coffee-bun-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan empuk. Karasteristik makanan Indonesia mexican coffee bun yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Mexican Coffee Bun untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang dapat anda buat salah satunya mexican coffee bun yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep mexican coffee bun tanpa harus bersusah payah.
Berikut ini resep Mexican Coffee Bun yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 11 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican Coffee Bun:

1. Tambah  Tangzhong starter:
1. Tambah 125 ml susu ultra jaya full cream
1. Dibutuhkan 25 gram terigu protein tinggi
1. Harap siapkan  Main dough:
1. Tambah 500 gram tepung terigu tinggi protein
1. Harap siapkan 1 sdm ragi instan (aku pake fermipan)
1. Harus ada 1 sdm susu bubuk full cream
1. Dibutuhkan 100 gram gula (aku pake gula halus)
1. Siapkan 1/2 sdt garam
1. Dibutuhkan 1 butir telur
1. Jangan lupa 135 ml susu ultra jaya full cream
1. Harap siapkan 75 ml fresh cream (aku pake anchor)
1. Dibutuhkan 4 sdm wysman
1. Harus ada  Topping
1. Tambah 100 gram wysman/blueband
1. Diperlukan 100 gram gula halus
1. Tambah 2 butir telur
1. Harap siapkan 3 sdt kopi instan (aku pake nescaffee classic)
1. Dibutuhkan 1/2 sdt vanili
1. Jangan lupa 1/2 sdt garam halus
1. Dibutuhkan 120 gram tepung terigu serbaguna




<!--inarticleads2-->

##### Cara membuat  Mexican Coffee Bun:

1. Thangzong Starter: Siapkan panci kecil, masukkan tepung dan susu cair ke dalam panci. Aduk menggunakan spatula hingga tepung larut dan tidak berbutir-butir. Panaskan panci di kompor dan masak menggunakan api kecil, aduk-aduk hingga menjadi adonan yang licin dan kental. Tidak sampai adonan meletup.
1. Main dough: Siapkan mangkuk besar, masukkan bahan-bahan kering: tepung terigu, ragi, garam, gula pasir halus, susu bubuk, aduk hingga benar-benar rata usahakan agar ragi tidak bertemu langsung dengan garam.
1. Siapkan mangkuk besar, masukkan bahan-bahan basah: adonan tangzhong, telur, susu cair, fresh cream, aduk menggunakan spatula hingga rata. Masukkan bahan kering aduk menggunakan jari-jari tangan. Jika telah menyatu, tambahkan butter/blueband dan uleni.
1. Siapkan meja datar, taburi tepung terigu, tuangkan adonan ke atasnya. Uleni adonan dengan menekannya menggunakan puncak telapak tangan dan mendorongnya menjauhi badan anda. Putar adonan selama menguleni sehingga semua sisi adonan terproses dengan baik. Uleni selama + 30 menit hingga menjadi adonan yang smooth dan halus. Masukkan adonan ke dalam mangkuk yang telah diolesi dengan sedikit minyak. Tutup dengan plastik dan biarkan selama 1 jam. (quick proofing)
1. Sambil nunggu proofing kita siapkan adonan topping. Kocok gula halus dan butter/blueband sampai rata, masukkan 2 butir telur dan vanili, seduh 3 shacet nescaffee clasic dengan 1 sdm air hangat, masukkan ke dalam adonan dan kocok sebentar terakhir masukkan tepung trigu serbaguna kocok sampai homogen. Masukkan ke dalam kantong plastik.
1. Kempiskan adonan dan bagi adonan menjadi 20 bulatan dg berat yang sama. 5 bulatan dibagi menjadi 15 bagian kecil-kecil untuk membungkus butter untuk isian.
1. Setelah isian selesai ambil bagian adonan tadi untuk diisi dg bulatan kecil berisi butter/blueband. Bulatkan dan tata di loyang yg sudah dialasi kertas roti atau letakkan dlm cup kertas diamkan kurang lebih 3 jam.
1. Gunting ujung plastik yang berisi topping dan semprotkan di atas adonan yg sudah mengembang di loyang dengan gerakan menyerupai obat nyamuk.
1. Panggang selama kurang lebih 15 menit. Bila adonan sudah matang topping cookie crush akan terasa crunchy.
1. 
1. Note: Adonan utama juga bisa dilakukan dengan cara slow proofing dengan menyimpannya di dalam chiller semalam suntuk.




Demikianlah cara membuat mexican coffee bun yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
