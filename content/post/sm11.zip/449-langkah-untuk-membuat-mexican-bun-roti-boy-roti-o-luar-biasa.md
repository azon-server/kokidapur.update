---
description: "Langkah untuk membuat Mexican Bun / Roti Boy / Roti O Luar biasa"
title: "Langkah untuk membuat Mexican Bun / Roti Boy / Roti O Luar biasa"
slug: 449-langkah-untuk-membuat-mexican-bun-roti-boy-roti-o-luar-biasa
date: 2020-12-19T03:43:07.008Z
image: https://img-global.cpcdn.com/recipes/5d1eedcd8c6c7594/680x482cq70/mexican-bun-roti-boy-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5d1eedcd8c6c7594/680x482cq70/mexican-bun-roti-boy-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5d1eedcd8c6c7594/680x482cq70/mexican-bun-roti-boy-roti-o-foto-resep-utama.jpg
author: Garrett Howell
ratingvalue: 4.4
reviewcount: 9546
recipeingredient:
- " Bahan Roti"
- "500 gr tepung terigu protein tinggi"
- "270 ml susu hangat"
- "8 sdm gula pasir"
- "1 bungkus ragi instan  11 gr ragi"
- "2 kuning telur"
- "5 sdm butter"
- "2 sdt garam"
- " Bahan Isi"
- " Keju potongpotong sesuai selera"
- " Butter yg sudah di bekukan potongpotong"
- " Kopi Mix"
- "1 bungkus kopi instan Nescafe untuk merk selera masingmasing"
- "1 sdt kopi hitam"
- "2 sdm air panas"
- " Bahan Topping"
- " Kopi mix"
- "8 sdmmunjung tepung terigu serbaguna"
- "2 sdm susu bubuk"
- "1 butir telur"
- "9 sdm butter"
- "10 sdm gula halus"
recipeinstructions:
- "Campur rata semua bahan roti, uleni hingga kalis lalu istirahatkan adonan hingga mengembang (kurleb 30 menit) ~cepat lambatnya adonan mengembang sesuai suhu ruangan masing-masing yaah~"
- "Siapkan loyang panggangan dan olesi dengan margarin. Setelah adonan mengembang, lalu kempiskan, uleni sebentar saja, bagi adonan sama rata, beri isian, bentuk bulat, letakan pada loyang panggangan, lalu istirahatkan kembali sampai mengembang (kurleb 30menit)"
- "Sambil menunggu adonan mengembang, membuat topping: pertama buat kopi mix dulu yaitu larutkan semua kopi dengan air panas"
- "Ditempat lain, campur semua bahan topping, aduk rata, masukkan plastik segitiga, lalu potong ujungnya untuk memberi topping pada roti"
- "Setelah adonan mengembang, beri topping secara memutar di atas adonan.. lakukan pada semua adonan dan langsung panggang sampai matang (pastikan panggangan sudah dipanaskan terlebih dahulu yaah)"
- "Jika sudah matang, angkat dan sajikaaan~"
categories:
- Recipe
tags:
- mexican
- bun
- 

katakunci: mexican bun  
nutrition: 213 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dessert

---


![Mexican Bun / Roti Boy / Roti O](https://img-global.cpcdn.com/recipes/5d1eedcd8c6c7594/680x482cq70/mexican-bun-roti-boy-roti-o-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga renyah. Ciri khas makanan Indonesia mexican bun / roti boy / roti o yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Mexican Bun / Roti Boy / Roti O untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang dapat anda coba salah satunya mexican bun / roti boy / roti o yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep mexican bun / roti boy / roti o tanpa harus bersusah payah.
Seperti resep Mexican Bun / Roti Boy / Roti O yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Mexican Bun / Roti Boy / Roti O:

1. Dibutuhkan  Bahan Roti:
1. Harap siapkan 500 gr tepung terigu protein tinggi
1. Siapkan 270 ml susu hangat
1. Jangan lupa 8 sdm gula pasir
1. Harap siapkan 1 bungkus ragi instan / 11 gr ragi
1. Dibutuhkan 2 kuning telur
1. Siapkan 5 sdm butter
1. Tambah 2 sdt garam
1. Siapkan  Bahan Isi:
1. Harus ada  Keju (potong-potong sesuai selera)
1. Tambah  Butter yg sudah di bekukan (potong-potong)
1. Diperlukan  Kopi Mix:
1. Siapkan 1 bungkus kopi instan Nescafe (untuk merk selera masing-masing)
1. Dibutuhkan 1 sdt kopi hitam
1. Jangan lupa 2 sdm air panas
1. Harus ada  Bahan Topping:
1. Siapkan  Kopi mix
1. Harus ada 8 sdm(munjung) tepung terigu serbaguna
1. Dibutuhkan 2 sdm susu bubuk
1. Tambah 1 butir telur
1. Diperlukan 9 sdm butter
1. Diperlukan 10 sdm gula halus




<!--inarticleads2-->

##### Bagaimana membuat  Mexican Bun / Roti Boy / Roti O:

1. Campur rata semua bahan roti, uleni hingga kalis lalu istirahatkan adonan hingga mengembang (kurleb 30 menit) ~cepat lambatnya adonan mengembang sesuai suhu ruangan masing-masing yaah~
1. Siapkan loyang panggangan dan olesi dengan margarin. Setelah adonan mengembang, lalu kempiskan, uleni sebentar saja, bagi adonan sama rata, beri isian, bentuk bulat, letakan pada loyang panggangan, lalu istirahatkan kembali sampai mengembang (kurleb 30menit)
1. Sambil menunggu adonan mengembang, membuat topping: pertama buat kopi mix dulu yaitu larutkan semua kopi dengan air panas
1. Ditempat lain, campur semua bahan topping, aduk rata, masukkan plastik segitiga, lalu potong ujungnya untuk memberi topping pada roti
1. Setelah adonan mengembang, beri topping secara memutar di atas adonan.. lakukan pada semua adonan dan langsung panggang sampai matang (pastikan panggangan sudah dipanaskan terlebih dahulu yaah)
1. Jika sudah matang, angkat dan sajikaaan~




Demikianlah cara membuat mexican bun / roti boy / roti o yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat mudah dan terbukti, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
