---
description: "Resep : Roti boy aka Roti O&amp;#39; Favorite"
title: "Resep : Roti boy aka Roti O&amp;#39; Favorite"
slug: 448-resep-roti-boy-aka-roti-o-and-39-favorite
date: 2020-10-16T14:21:59.644Z
image: https://img-global.cpcdn.com/recipes/ff4b112009f32ddb/680x482cq70/roti-boy-aka-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ff4b112009f32ddb/680x482cq70/roti-boy-aka-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ff4b112009f32ddb/680x482cq70/roti-boy-aka-roti-o-foto-resep-utama.jpg
author: Connor Wolfe
ratingvalue: 4.6
reviewcount: 7495
recipeingredient:
- " Bahan roti"
- "200 gr terigu pro sedang segitiga"
- "200 gr terigu pro tinggi cakra"
- "1/2 sdm ragi instan fermipan"
- "2 buah kuning telur"
- "1 sdm susu bubuk dancow full cream"
- "60 gr gula pasir"
- "150 ml air hangat"
- "40 gr mentega"
- "1/2 sdt garam"
- " Filling  isian roti"
- "20 gr butter"
- " Topping"
- "2 buah telur kocok"
- "100 gr gula halus"
- "100 gr butter"
- "2 sdm kopi indocafe coffe mix"
- "2 sdt air hangat"
- "100 gr tepung terigu"
- "1 sdt pasta mocca"
recipeinstructions:
- "Masukan ragi di campur 75 ml air hangat dan 1/4 sdt gula pasir dan aduk rata diamkan 15 menit, fungsi nya utk mengaktifkan ragi"
- "Campur terigu, gula, susu bubuk ke dlm wadah aduk rata masukan kuning telur, 75 ml air hangat, air ragi uleni sampai rata lalu masukan mentega dan garam uleni sampai kalis elastis"
- "Diamkan 30 mnt lalu kempeskan adonan, bagi adonan 60gr atau sesuai selera lalu bulatkan dan isi dgn bahan filling"
- "Diamkan selama 1 jam agar adonan roti mengembang"
- "Topping: kocok telur, gula haluss dan butter sampai halus lalu Campur bahan topping lainnya lalu masukan ke piping bag kemudian masukan ke dlm kulkas, keluarkan topping klo udh mau di gunakan"
- "Setelah 1 jam, semprotkan topping ke roti smpai permukaan tertutup topping, sisakan jarak 1 cm di bagian bawah roti fungsi nya agar topping tidak lengket di oven"
- "Panggang dgn suhu 200° atau sesuai oven masing masing, panggang 12 menit atau sampai topping kering"
- "Panggang roti di bagian atas ya agar roti kering"
- "Note: Setelah matang jgn langsung di ambil dr loyang biar roti tdk kempes, tunggu 10 mnt"
- "Siap disantap hangat hangat utk tmn ngeteh atau kopi"
- "Note: roti boy akan sedikit lengket topping nya klo udh 4 jam, klo mau di makan lbh dr 4 jam sebaiknya roti di hangatkan lg di oven ya moms"
categories:
- Recipe
tags:
- roti
- boy
- aka

katakunci: roti boy aka 
nutrition: 283 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Dessert

---


![Roti boy aka Roti O&#39;](https://img-global.cpcdn.com/recipes/ff4b112009f32ddb/680x482cq70/roti-boy-aka-roti-o-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang dapat kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti roti boy aka roti o&#39; yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan ciri khas yang merupakan keragaman Nusantara

Kehangatan keluarga bisa ditemukan dengan cara simple. Salah satunya adalah membuat makanan Roti boy aka Roti O&#39; untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang dapat anda contoh salah satunya roti boy aka roti o&#39; yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep roti boy aka roti o&#39; tanpa harus bersusah payah.
Berikut ini resep Roti boy aka Roti O&#39; yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 20 bahan dan 11 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti boy aka Roti O&#39;:

1. Tambah  Bahan roti
1. Jangan lupa 200 gr terigu pro sedang (segitiga)
1. Siapkan 200 gr terigu pro tinggi (cakra)
1. Dibutuhkan 1/2 sdm ragi instan (fermipan)
1. Harap siapkan 2 buah kuning telur
1. Siapkan 1 sdm susu bubuk (dancow full cream)
1. Diperlukan 60 gr gula pasir
1. Diperlukan 150 ml air hangat
1. Jangan lupa 40 gr mentega
1. Harus ada 1/2 sdt garam
1. Jangan lupa  Filling / isian roti:
1. Siapkan 20 gr butter
1. Dibutuhkan  Topping:
1. Tambah 2 buah telur kocok
1. Harus ada 100 gr gula halus
1. Tambah 100 gr butter
1. Harus ada 2 sdm kopi (indocafe coffe mix)
1. Diperlukan 2 sdt air hangat
1. Dibutuhkan 100 gr tepung terigu
1. Tambah 1 sdt pasta mocca




<!--inarticleads2-->

##### Langkah membuat  Roti boy aka Roti O&#39;:

1. Masukan ragi di campur 75 ml air hangat dan 1/4 sdt gula pasir dan aduk rata diamkan 15 menit, fungsi nya utk mengaktifkan ragi
1. Campur terigu, gula, susu bubuk ke dlm wadah aduk rata masukan kuning telur, 75 ml air hangat, air ragi uleni sampai rata lalu masukan mentega dan garam uleni sampai kalis elastis
1. Diamkan 30 mnt lalu kempeskan adonan, bagi adonan 60gr atau sesuai selera lalu bulatkan dan isi dgn bahan filling
1. Diamkan selama 1 jam agar adonan roti mengembang
1. Topping: kocok telur, gula haluss dan butter sampai halus lalu Campur bahan topping lainnya lalu masukan ke piping bag kemudian masukan ke dlm kulkas, keluarkan topping klo udh mau di gunakan
1. Setelah 1 jam, semprotkan topping ke roti smpai permukaan tertutup topping, sisakan jarak 1 cm di bagian bawah roti fungsi nya agar topping tidak lengket di oven
1. Panggang dgn suhu 200° atau sesuai oven masing masing, panggang 12 menit atau sampai topping kering
1. Panggang roti di bagian atas ya agar roti kering
1. Note: Setelah matang jgn langsung di ambil dr loyang biar roti tdk kempes, tunggu 10 mnt
1. Siap disantap hangat hangat utk tmn ngeteh atau kopi
1. Note: roti boy akan sedikit lengket topping nya klo udh 4 jam, klo mau di makan lbh dr 4 jam sebaiknya roti di hangatkan lg di oven ya moms




Demikianlah cara membuat roti boy aka roti o&#39; yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
