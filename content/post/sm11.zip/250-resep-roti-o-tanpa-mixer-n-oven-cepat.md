---
description: "Resep : Roti o tanpa mixer n oven Cepat"
title: "Resep : Roti o tanpa mixer n oven Cepat"
slug: 250-resep-roti-o-tanpa-mixer-n-oven-cepat
date: 2021-02-04T21:36:55.563Z
image: https://img-global.cpcdn.com/recipes/38fbdcb39deac47a/680x482cq70/roti-o-tanpa-mixer-n-oven-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/38fbdcb39deac47a/680x482cq70/roti-o-tanpa-mixer-n-oven-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/38fbdcb39deac47a/680x482cq70/roti-o-tanpa-mixer-n-oven-foto-resep-utama.jpg
author: Nettie Hopkins
ratingvalue: 4.8
reviewcount: 31474
recipeingredient:
- " Biang"
- "1 sdm gula"
- "1 sdt ragi"
- "1 sdm tepung terigu"
- "100 ml air hangat"
- " Roti"
- "250 gr tepung cakra"
- "1 btr kuning telur"
- "4 sdm gula pasir"
- "1 sdm susu bubuk"
- "2 sdm margarin"
- " Toping kopi"
- "50 gr terigu"
- "20 gr maizena"
- "50 gr margarin"
- "1 sachet white coffe"
- "2 sdm air hangat"
- "1 btr putih telur"
- " Isian roti"
- "30 gr margarin"
- "30 gr keju serut"
- "3 sdm gula"
recipeinstructions:
- "Campur bahan biang aduk² sampai larut. Tutup dan tunggu berbusa. Kalau tdk berbusa berarti ragi tdk aktif"
- "Dalam baskom campur bahan roti aduk sampai rata. Masukkan bahan biang. Uleni sekitar 10-15menit sampai benar² elastis agar roti lembut. Tutup dengan kain biarkan selama 1jam dan mengembang 2xlipat"
- "Sambil menunggu adonan mengembang,buat bahan isi. Campur smua bahan isian. Masukkan kulkas"
- "Untuk toping,kocok telur gula margarin dgn baloon whisk sampai creamy. Lalu masukan terigu meizena dan kopi aduk rata."
- "Setelah adonan mengembang. Ambil adonan sebesar 50gr. Bulatkan. Pipihkan. Beri isian. Lalu bulatkan lagi. Lakukan sampai habis. Tutup kembali adonan biarkan mengembang lg"
- "Setelah adonan mengembang beri toping. Caranya masukan toping dalam alat cetak roti,atau plastik segitiga, lingkarkan berbentuk seperti obat nyamuk bakar. Lakukan sampai selesai."
- "Panaskan teflon. Panggang adonan diatas sarangan jangan langsung terkena teflon karna bawahnya bisa gosong. Panggang dgn api kecil selama 30-45 menit."
categories:
- Recipe
tags:
- roti
- o
- tanpa

katakunci: roti o tanpa 
nutrition: 176 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT30M"
recipeyield: "1"
recipecategory: Dessert

---


![Roti o tanpa mixer n oven](https://img-global.cpcdn.com/recipes/38fbdcb39deac47a/680x482cq70/roti-o-tanpa-mixer-n-oven-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang harus kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti roti o tanpa mixer n oven yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa keistimewahan yang merupakan keragaman Kita

Keharmonisan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Roti o tanpa mixer n oven untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang bisa anda coba salah satunya roti o tanpa mixer n oven yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep roti o tanpa mixer n oven tanpa harus bersusah payah.
Berikut ini resep Roti o tanpa mixer n oven yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti o tanpa mixer n oven:

1. Harus ada  Biang
1. Jangan lupa 1 sdm gula
1. Harus ada 1 sdt ragi
1. Harus ada 1 sdm tepung terigu
1. Harap siapkan 100 ml air hangat
1. Diperlukan  Roti
1. Harus ada 250 gr tepung cakra
1. Dibutuhkan 1 btr kuning telur
1. Diperlukan 4 sdm gula pasir
1. Siapkan 1 sdm susu bubuk
1. Dibutuhkan 2 sdm margarin
1. Siapkan  Toping kopi
1. Jangan lupa 50 gr terigu
1. Harus ada 20 gr maizena
1. Jangan lupa 50 gr margarin
1. Tambah 1 sachet white coffe
1. Jangan lupa 2 sdm air hangat
1. Harap siapkan 1 btr putih telur
1. Harap siapkan  Isian roti
1. Tambah 30 gr margarin
1. Harap siapkan 30 gr keju serut
1. Harap siapkan 3 sdm gula




<!--inarticleads2-->

##### Bagaimana membuat  Roti o tanpa mixer n oven:

1. Campur bahan biang aduk² sampai larut. Tutup dan tunggu berbusa. Kalau tdk berbusa berarti ragi tdk aktif
1. Dalam baskom campur bahan roti aduk sampai rata. Masukkan bahan biang. Uleni sekitar 10-15menit sampai benar² elastis agar roti lembut. Tutup dengan kain biarkan selama 1jam dan mengembang 2xlipat
1. Sambil menunggu adonan mengembang,buat bahan isi. Campur smua bahan isian. Masukkan kulkas
1. Untuk toping,kocok telur gula margarin dgn baloon whisk sampai creamy. Lalu masukan terigu meizena dan kopi aduk rata.
1. Setelah adonan mengembang. Ambil adonan sebesar 50gr. Bulatkan. Pipihkan. Beri isian. Lalu bulatkan lagi. Lakukan sampai habis. Tutup kembali adonan biarkan mengembang lg
1. Setelah adonan mengembang beri toping. Caranya masukan toping dalam alat cetak roti,atau plastik segitiga, lingkarkan berbentuk seperti obat nyamuk bakar. Lakukan sampai selesai.
1. Panaskan teflon. Panggang adonan diatas sarangan jangan langsung terkena teflon karna bawahnya bisa gosong. Panggang dgn api kecil selama 30-45 menit.




Demikianlah cara membuat roti o tanpa mixer n oven yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
