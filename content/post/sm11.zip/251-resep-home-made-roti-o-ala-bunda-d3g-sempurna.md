---
description: "Resep : Home made Roti O ala Bunda D3g Sempurna"
title: "Resep : Home made Roti O ala Bunda D3g Sempurna"
slug: 251-resep-home-made-roti-o-ala-bunda-d3g-sempurna
date: 2021-01-18T19:41:10.889Z
image: https://img-global.cpcdn.com/recipes/e6c09a1a186fc48f/680x482cq70/home-made-roti-o-ala-bunda-d3g-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e6c09a1a186fc48f/680x482cq70/home-made-roti-o-ala-bunda-d3g-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e6c09a1a186fc48f/680x482cq70/home-made-roti-o-ala-bunda-d3g-foto-resep-utama.jpg
author: Steve Jimenez
ratingvalue: 4.9
reviewcount: 9428
recipeingredient:
- " Bahan Roti"
- "250 gr Terigu protein tinggi me  Cakra kembar"
- "50 gr Gula pasir"
- "1 butir telur"
- "1 sdt ragi instan fermipan"
- "1/2 sdt tbm bisa di skip"
- "100 ml air dingin"
- "1 sdm muncung mentega me  blue band cake  cookies"
- "1 sdm susu bubuk me  dancow"
- " Bahan Toping"
- "4 sdm tepung protein sedang me  segitiga biru"
- "1 putih telur"
- "25 gr mentega blue band cc"
- "4 sdm gula halus"
- "1 sachet kopi me  torabika cappucino choco granul"
recipeinstructions:
- "Timbang tepung utk roti lalu ayak."
- "Mix bahan roti kecuali mentega,mix dgn kecepatan rendah sampai tercampur lalu dgn kecepatan besar setelah itu bru masukan mentega. Mix kembali sampai tercampur dan elastis."
- "Diamkan dan tutup sampai 1 jam"
- "Hasil setelah di diamkan 1 jam tara mengembang sempurna"
- "Step selanjutnya kempeskan adonan yg sudah di diamkan biar udara dlm adonan keluar. Lalu ambil sedikit adonan roti lalu pipih pipihkan di atas wadah yg telah di beri tepung supaya tdk lengket yah moms lalu berikan mentega dan tutup kembali sampai adonan habis."
- "Letakan adonan roti ke loyang yg telah di olesi mentega dan kertas roti (baking paper) lalu tutup kembali selama 45 menit."
- "Next step sambil menunggu adonan mengembang kita bikin toping roti. Mix dahulu gula halus dan mentega setelah tercampur semua masukan tepung, putih telur, dan kopi sachet. Lalu masukan ke plastik segi tiga."
- "Setelah 45 menit tambahkan adonan roti dgn toping lalu panggang di atas api atas bawah suhu 180 derajat selama 30 menit, tpi sebelumnya oven harus panas dahulu yah."
- "Setelah matang jgn langsung di keluarkan diamkan dlm oven 30 menit agar tdk mempes"
- "Taraa selesai home made roti o nya."
- "Biar keren bikin kemasan biar kaya tukang roti profesional."
categories:
- Recipe
tags:
- home
- made
- roti

katakunci: home made roti 
nutrition: 275 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Lunch

---


![Home made Roti O ala Bunda D3g](https://img-global.cpcdn.com/recipes/e6c09a1a186fc48f/680x482cq70/home-made-roti-o-ala-bunda-d3g-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan empuk. Karasteristik masakan Indonesia home made roti o ala bunda d3g yang penuh dengan rempah memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kehangatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Home made Roti O ala Bunda D3g untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang bisa anda coba salah satunya home made roti o ala bunda d3g yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep home made roti o ala bunda d3g tanpa harus bersusah payah.
Seperti resep Home made Roti O ala Bunda D3g yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 15 bahan dan 11 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Home made Roti O ala Bunda D3g:

1. Jangan lupa  Bahan Roti
1. Dibutuhkan 250 gr Terigu protein tinggi (me : Cakra kembar)
1. Tambah 50 gr Gula pasir
1. Harus ada 1 butir telur
1. Siapkan 1 sdt ragi instan (fermipan)
1. Dibutuhkan 1/2 sdt tbm (bisa di skip)
1. Harus ada 100 ml air dingin
1. Siapkan 1 sdm muncung mentega (me : blue band cake &amp; cookies)
1. Diperlukan 1 sdm susu bubuk (me : dancow)
1. Harap siapkan  Bahan Toping
1. Dibutuhkan 4 sdm tepung protein sedang (me : segitiga biru)
1. Jangan lupa 1 putih telur
1. Siapkan 25 gr mentega (blue band c&amp;c)
1. Diperlukan 4 sdm gula halus
1. Diperlukan 1 sachet kopi (me : torabika cappucino choco granul)




<!--inarticleads2-->

##### Langkah membuat  Home made Roti O ala Bunda D3g:

1. Timbang tepung utk roti lalu ayak.
1. Mix bahan roti kecuali mentega,mix dgn kecepatan rendah sampai tercampur lalu dgn kecepatan besar setelah itu bru masukan mentega. Mix kembali sampai tercampur dan elastis.
1. Diamkan dan tutup sampai 1 jam
1. Hasil setelah di diamkan 1 jam tara mengembang sempurna
1. Step selanjutnya kempeskan adonan yg sudah di diamkan biar udara dlm adonan keluar. Lalu ambil sedikit adonan roti lalu pipih pipihkan di atas wadah yg telah di beri tepung supaya tdk lengket yah moms lalu berikan mentega dan tutup kembali sampai adonan habis.
1. Letakan adonan roti ke loyang yg telah di olesi mentega dan kertas roti (baking paper) lalu tutup kembali selama 45 menit.
1. Next step sambil menunggu adonan mengembang kita bikin toping roti. Mix dahulu gula halus dan mentega setelah tercampur semua masukan tepung, putih telur, dan kopi sachet. Lalu masukan ke plastik segi tiga.
1. Setelah 45 menit tambahkan adonan roti dgn toping lalu panggang di atas api atas bawah suhu 180 derajat selama 30 menit, tpi sebelumnya oven harus panas dahulu yah.
1. Setelah matang jgn langsung di keluarkan diamkan dlm oven 30 menit agar tdk mempes
1. Taraa selesai home made roti o nya.
1. Biar keren bikin kemasan biar kaya tukang roti profesional.




Demikianlah cara membuat home made roti o ala bunda d3g yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
