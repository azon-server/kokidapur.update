---
description: "Bagaimana menyiapakan Roti Boy / Mexican Bun / Roti &amp;#39;O Teruji"
title: "Bagaimana menyiapakan Roti Boy / Mexican Bun / Roti &amp;#39;O Teruji"
slug: 362-bagaimana-menyiapakan-roti-boy-mexican-bun-roti-and-39-o-teruji
date: 2021-02-25T02:31:42.986Z
image: https://img-global.cpcdn.com/recipes/23d340c085b87c14/680x482cq70/roti-boy-mexican-bun-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/23d340c085b87c14/680x482cq70/roti-boy-mexican-bun-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/23d340c085b87c14/680x482cq70/roti-boy-mexican-bun-roti-o-foto-resep-utama.jpg
author: Viola Summers
ratingvalue: 4.3
reviewcount: 6929
recipeingredient:
- " BAHAN DOUGHT "
- "250 gr25sdm Tepung Terigu Cakra"
- "50 gr Gula Pasir"
- "1 sdt5gr Ragi Fermipan"
- "1 sdm Susu Bubuk klo pke Susu cair gausah pke susu bubuk"
- "1 Butir Telur dipakai 1 Kuning Telur saja"
- "100 ml Air Dingin bisa diganti susu Cair Dingin"
- "25 gr Margarin forvita"
- " BAHAN TOPING "
- "55 gr Gula Halus 5 sdm"
- "50 gr Margarin"
- "60 gr6sdm Tepung Terigu pro sedang"
- "2 sdt Kopi Luwak white coffee"
- "1 Putih Telur"
- " Pasta Moka bisa skip"
- " BAHAN ISIAN  campurkan"
- "1 sdm Mentega forvita"
- " Gula Pasir secukupnya"
recipeinstructions:
- "Pisahkan Kuning Telur dengan Putih Telur."
- "Masukkan Semua Bahan Dought, kecuali Margarin."
- "MIXSER sampai setengah kalis, masukkan Mentega. MIXSER (speed tinggi) Sampai Kalis Elastis."
- "Bulatkan. Diamkan/proofing -+1Jam sampai mengembang 2x lipat."
- "Setelah 1jam kempiskan adonan. Bagi adonan jadi 12 biji (42gr). Bulatkan satu persatu."
- "Ambil bulatan pertama pipihkan, isi Margarin."
- "Cubit² Bulatan biar isinya tidak keluar. Seperti digambar !"
- "Susun keloyang (olesi margarin+tepung). Proofing/diamkan -+40 Menit."
- "BUAT TOPING : *masukkan gula halus &amp; margarin aduk rata, masukkan tepung terigu, kopi, Putih telur. Aduk Rata. Sedikit pasta moka. Aduk Rata."
- "Masukkan Ke Plastik Segitiga, lalu sisihkan dulu. (digambar Adonan yg sudah diProofing)"
- "Setelah Adonan Mengembang. Semprot dgn Toping."
- "Panaskan Oven. Panggang suhu 170°-180° selama 20 menit."
- "Setelah matang, keluarkan dari Oven. Toping akan mencair/menyebar ke Roti."
- "Pas dibelah Roti Boy nya krispy diluar, lembut didalam.😋😍"
- "SELAMAT MENCOBA :) Yuk kirim foto hasil recook mu !"
- "Foto ini ❌karena membulatkan/mencubit adonannya kurang rapat."
- "Foto✅ sebelum matang"
categories:
- Recipe
tags:
- roti
- boy
- 

katakunci: roti boy  
nutrition: 288 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Lunch

---


![Roti Boy / Mexican Bun / Roti &#39;O](https://img-global.cpcdn.com/recipes/23d340c085b87c14/680x482cq70/roti-boy-mexican-bun-roti-o-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga empuk. Karasteristik kuliner Nusantara roti boy / mexican bun / roti &#39;o yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kedekatan keluarga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Roti Boy / Mexican Bun / Roti &#39;O untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang dapat anda praktekkan salah satunya roti boy / mexican bun / roti &#39;o yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep roti boy / mexican bun / roti &#39;o tanpa harus bersusah payah.
Seperti resep Roti Boy / Mexican Bun / Roti &#39;O yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Boy / Mexican Bun / Roti &#39;O:

1. Diperlukan  BAHAN DOUGHT :
1. Diperlukan 250 gr/25sdm Tepung Terigu (Cakra)
1. Diperlukan 50 gr Gula Pasir
1. Harus ada 1 sdt/5gr Ragi (Fermipan)
1. Harus ada 1 sdm Susu Bubuk (klo pke Susu cair, gausah pke susu bubuk)
1. Tambah 1 Butir Telur (dipakai 1 Kuning Telur saja)
1. Jangan lupa 100 ml Air Dingin (bisa diganti susu Cair Dingin)
1. Tambah 25 gr Margarin (forvita)
1. Jangan lupa  BAHAN TOPING :
1. Harap siapkan 55 gr Gula Halus (5 sdm)
1. Harap siapkan 50 gr Margarin
1. Siapkan 60 gr/6sdm Tepung Terigu (pro sedang)
1. Harus ada 2 sdt Kopi (Luwak white coffee)
1. Tambah 1 Putih Telur
1. Harap siapkan  Pasta Moka (bisa skip)
1. Harus ada  BAHAN ISIAN : campurkan
1. Tambah 1 sdm Mentega (forvita)
1. Siapkan  Gula Pasir (secukupnya)




<!--inarticleads2-->

##### Langkah membuat  Roti Boy / Mexican Bun / Roti &#39;O:

1. Pisahkan Kuning Telur dengan Putih Telur.
1. Masukkan Semua Bahan Dought, kecuali Margarin.
1. MIXSER sampai setengah kalis, masukkan Mentega. MIXSER (speed tinggi) Sampai Kalis Elastis.
1. Bulatkan. Diamkan/proofing -+1Jam sampai mengembang 2x lipat.
1. Setelah 1jam kempiskan adonan. Bagi adonan jadi 12 biji (42gr). Bulatkan satu persatu.
1. Ambil bulatan pertama pipihkan, isi Margarin.
1. Cubit² Bulatan biar isinya tidak keluar. Seperti digambar !
1. Susun keloyang (olesi margarin+tepung). Proofing/diamkan -+40 Menit.
1. BUAT TOPING : *masukkan gula halus &amp; margarin aduk rata, masukkan tepung terigu, kopi, Putih telur. Aduk Rata. Sedikit pasta moka. Aduk Rata.
1. Masukkan Ke Plastik Segitiga, lalu sisihkan dulu. (digambar Adonan yg sudah diProofing)
1. Setelah Adonan Mengembang. Semprot dgn Toping.
1. Panaskan Oven. Panggang suhu 170°-180° selama 20 menit.
1. Setelah matang, keluarkan dari Oven. Toping akan mencair/menyebar ke Roti.
1. Pas dibelah Roti Boy nya krispy diluar, lembut didalam.😋😍
1. SELAMAT MENCOBA :) Yuk kirim foto hasil recook mu !
1. Foto ini ❌karena membulatkan/mencubit adonannya kurang rapat.
1. Foto✅ sebelum matang




Demikianlah cara membuat roti boy / mexican bun / roti &#39;o yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
