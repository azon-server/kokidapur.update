---
description: "Resep : Mexican Bun Luar biasa"
title: "Resep : Mexican Bun Luar biasa"
slug: 291-resep-mexican-bun-luar-biasa
date: 2020-12-03T00:32:57.027Z
image: https://img-global.cpcdn.com/recipes/5b75357092d4986a/680x482cq70/mexican-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5b75357092d4986a/680x482cq70/mexican-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5b75357092d4986a/680x482cq70/mexican-bun-foto-resep-utama.jpg
author: Randall Walton
ratingvalue: 4.3
reviewcount: 49836
recipeingredient:
- " Bahan water roux"
- "125 ml susu cair full cream"
- "20 gr terigu cakra"
- " Bahan lain"
- "125 ml susu evaporated bisa diganti susu cair full cream"
- "1 btr telur"
- "320 gr terigu cakra"
- "2 sdt ragi instant"
- "1/2 sdt garam"
- "3 sdm gula pasir"
- "55 gr butter unsaltedmentega tawar"
- " Bahan Topping"
- "100 gr butter unsaltedmentega tawar"
- "90 gr gula halus"
- "2 btr telur"
- "2 sdt kopi instan  1 sdt air hangat  1 sdt vanilla essence"
- "120 gr terigu segitiga  14 sdt garam  14 sdt baking powder"
- " Bahan Isi"
- "100 gr mentega salted dinginkan dlm kulkas potong dadu mjd 12"
- "  punyaku unsalted jd isinya aku tambah parutan keju spy asin"
recipeinstructions:
- "Water roux: campur susu cair &amp; terigu, aduk dgn whisker, panaskan di atas api yg kecil sambil terus diaduk (TDK SAMPAI MENDIDIH, cukup sampai lembut saja, creamy), angkat. Biarkan hangat."
- "Masukkan water roux ke dlm susu evaporated atau susu cair. Aduk dgn whisker, tambahkan telur, aduk2 lagi. Sisihkan."
- "Dalam sebuah waskom masukkan terigu cakra dan ragi instan, aduk2, masukkan adonan no.2 tadi ☝️(campuran water roux + susu cair + telur). Mixer speed rendah smp bahan kering dan cair tercampur rata. Tutup, diamkan 20 menit."
- "Lanjutkan proses menguleni/mixer lagi dgn speed rendah sambil ditambahkan garam &amp; gula pasir. Mixer smp rata dan smooth. Terakhir masukkan mentega, mixer smp kalis elastis. Tutup adonan dgn plastic wrap atau serbet bersih. Diamkan 1 jam atau mengembang 2x lipat."
- "Bagi2 adonan mjd 12. Masing2 diisi dgn bahan isian, bulatkan kembali. Lakukan smp semua adonan habis, tutup, dan diamkan selama 1 jam."
- "Topping: mentega kocok sebentar (+/- 1 menit), tambahkan gula halus, kocok dgn mixer speed rendah smp pucat &amp; lembut. Kemudian tambahkan telur, masukkan satu per satu sambil terus dikocok smp rata saja. Masukkan campuran kopi (kopi instan, air hangat, vanilla) dan campuran terigu, garam, baking powder. Mixer speed rendah smp tercampur rata. Masukkan piping bag/plastik segitiga."
- "Semprotkan adonan topping di atas adonan roti yg telah mengembang, secara melingkar/spiral spt obat nyamuk."
- "Oven selama 15 - 20 menit pd suhu 190 derajat celcius (sesuai oven masing2 ya...)"
categories:
- Recipe
tags:
- mexican
- bun

katakunci: mexican bun 
nutrition: 298 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Lunch

---


![Mexican Bun](https://img-global.cpcdn.com/recipes/5b75357092d4986a/680x482cq70/mexican-bun-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan gurih. Karasteristik makanan Indonesia mexican bun yang kaya dengan rempah menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.




Keharmonisan keluarga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Mexican Bun untuk keluarga. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang bisa anda contoh salah satunya mexican bun yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep mexican bun tanpa harus bersusah payah.
Seperti resep Mexican Bun yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican Bun:

1. Dibutuhkan  Bahan water roux:
1. Dibutuhkan 125 ml susu cair full cream
1. Tambah 20 gr terigu cakra
1. Diperlukan  Bahan lain:
1. Siapkan 125 ml susu evaporated (bisa diganti susu cair full cream)
1. Tambah 1 btr telur
1. Harap siapkan 320 gr terigu cakra
1. Harus ada 2 sdt ragi instant
1. Harap siapkan 1/2 sdt garam
1. Dibutuhkan 3 sdm gula pasir
1. Dibutuhkan 55 gr butter unsalted/mentega tawar
1. Dibutuhkan  Bahan Topping:
1. Harap siapkan 100 gr butter unsalted/mentega tawar
1. Harap siapkan 90 gr gula halus
1. Jangan lupa 2 btr telur
1. Tambah 2 sdt kopi instan + 1 sdt air hangat + 1 sdt vanilla essence
1. Diperlukan 120 gr terigu segitiga + 1/4 sdt garam + 1/4 sdt baking powder
1. Siapkan  Bahan Isi:
1. Dibutuhkan 100 gr mentega salted, dinginkan dlm kulkas, potong dadu mjd 12*
1. Tambah  (* punyaku unsalted, jd isinya aku tambah parutan keju spy asin




<!--inarticleads2-->

##### Cara membuat  Mexican Bun:

1. Water roux: campur susu cair &amp; terigu, aduk dgn whisker, panaskan di atas api yg kecil sambil terus diaduk (TDK SAMPAI MENDIDIH, cukup sampai lembut saja, creamy), angkat. Biarkan hangat.
1. Masukkan water roux ke dlm susu evaporated atau susu cair. Aduk dgn whisker, tambahkan telur, aduk2 lagi. Sisihkan.
1. Dalam sebuah waskom masukkan terigu cakra dan ragi instan, aduk2, masukkan adonan no.2 tadi ☝️(campuran water roux + susu cair + telur). Mixer speed rendah smp bahan kering dan cair tercampur rata. Tutup, diamkan 20 menit.
1. Lanjutkan proses menguleni/mixer lagi dgn speed rendah sambil ditambahkan garam &amp; gula pasir. Mixer smp rata dan smooth. Terakhir masukkan mentega, mixer smp kalis elastis. Tutup adonan dgn plastic wrap atau serbet bersih. Diamkan 1 jam atau mengembang 2x lipat.
1. Bagi2 adonan mjd 12. Masing2 diisi dgn bahan isian, bulatkan kembali. Lakukan smp semua adonan habis, tutup, dan diamkan selama 1 jam.
1. Topping: mentega kocok sebentar (+/- 1 menit), tambahkan gula halus, kocok dgn mixer speed rendah smp pucat &amp; lembut. Kemudian tambahkan telur, masukkan satu per satu sambil terus dikocok smp rata saja. Masukkan campuran kopi (kopi instan, air hangat, vanilla) dan campuran terigu, garam, baking powder. Mixer speed rendah smp tercampur rata. Masukkan piping bag/plastik segitiga.
1. Semprotkan adonan topping di atas adonan roti yg telah mengembang, secara melingkar/spiral spt obat nyamuk.
1. Oven selama 15 - 20 menit pd suhu 190 derajat celcius (sesuai oven masing2 ya...)




Demikianlah cara membuat mexican bun yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan teruji, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
