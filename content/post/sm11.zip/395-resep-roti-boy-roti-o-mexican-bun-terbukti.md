---
description: "Resep : Roti boy / Roti O / Mexican bun Terbukti"
title: "Resep : Roti boy / Roti O / Mexican bun Terbukti"
slug: 395-resep-roti-boy-roti-o-mexican-bun-terbukti
date: 2020-10-27T09:07:52.160Z
image: https://img-global.cpcdn.com/recipes/8f10867f002c2f69/680x482cq70/roti-boy-roti-o-mexican-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8f10867f002c2f69/680x482cq70/roti-boy-roti-o-mexican-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8f10867f002c2f69/680x482cq70/roti-boy-roti-o-mexican-bun-foto-resep-utama.jpg
author: Peter Flores
ratingvalue: 4
reviewcount: 11387
recipeingredient:
- " Adonan roti"
- "500 gr terigu"
- "1 butir kuning telur"
- "2 sdm munjung mentega"
- "1 sdm munjung butter"
- " Biang"
- "2 sdt fermipan"
- "1 sdt garam"
- "4 sdm munjung gula pasir"
- "3/4 gelas belimbing Air"
- " Isian"
- "100 gr Mentega"
- "1 sdm munjung Butter"
- "20 gr keju"
- " Topping"
- "1 butir putih telur"
- "100 gr Mentega"
- "100 gr terigu"
- "25 gr maizena"
- "100 gr gula halus"
- "1 bungkus indocafe coffee mix"
- "2 sdm air hangat"
recipeinstructions:
- "Biang : dlm gelas masukkan air, gula &amp; garam, aduk hingga larut, lalu tambahkan fermipan, aduk lg, tunggu hingga berbuih."
- "Adonan roti : masukkan terigu, kuning telur, mentega &amp; butter dlm wadah, tambahkan adonan biang, uleni hingga kalis, jika blm kalis &amp; adonan masih berat tambahkan air, hingga adonan kalis &amp; lembut. Tutup dg serbet bersih. Diamkan 30 - 45 menit."
- "Sambil menunggu adonan d proofing, aduk bahan isian lalu masukkan kulkas, sisihkan."
- "Topping : seduh kopi dg 2 sdm air hangat, aduk hingga larut, sisihkan. Mixer gula &amp; mentega hingga mengembang &amp; pucat, masukkan putih telur, mixer lg hingga mengembang, tambahkan cairan kopi, aduk lg hingga rata. Terakhir masukkan terigu &amp; maizena, aduk hingga rata."
- "Masukkan adonan topping k dlm plastik, masukkan kulkas."
- "Setelah adonan roti mengembang, kempiskan. Timbang adonan masing 30 gr, beri isian, letakkan di loyang yg sudah dioles mentega. Lakukan hingga adonan habis."
- "Diamkan lg ± 45 menit. Setelah 45 menit, panaskan oven, beri topping roti melingkar seperti obat nyamuk. Panggang ± 30 menitan angkat."
categories:
- Recipe
tags:
- roti
- boy
- 

katakunci: roti boy  
nutrition: 203 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dinner

---


![Roti boy / Roti O / Mexican bun](https://img-global.cpcdn.com/recipes/8f10867f002c2f69/680x482cq70/roti-boy-roti-o-mexican-bun-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis dan enak. Ciri khas masakan Indonesia roti boy / roti o / mexican bun yang penuh dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan keluarga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan Roti boy / Roti O / Mexican bun untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda coba salah satunya roti boy / roti o / mexican bun yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep roti boy / roti o / mexican bun tanpa harus bersusah payah.
Berikut ini resep Roti boy / Roti O / Mexican bun yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti boy / Roti O / Mexican bun:

1. Harus ada  Adonan roti
1. Siapkan 500 gr terigu
1. Harap siapkan 1 butir kuning telur
1. Siapkan 2 sdm munjung mentega
1. Siapkan 1 sdm munjung butter
1. Siapkan  Biang
1. Harap siapkan 2 sdt fermipan
1. Harus ada 1 sdt garam
1. Tambah 4 sdm munjung gula pasir
1. Harap siapkan 3/4 gelas belimbing Air
1. Diperlukan  Isian
1. Jangan lupa 100 gr Mentega
1. Harap siapkan 1 sdm munjung Butter
1. Diperlukan 20 gr keju
1. Jangan lupa  Topping
1. Diperlukan 1 butir putih telur
1. Harus ada 100 gr Mentega
1. Harus ada 100 gr terigu
1. Jangan lupa 25 gr maizena
1. Harus ada 100 gr gula halus
1. Harap siapkan 1 bungkus indocafe coffee mix
1. Diperlukan 2 sdm air hangat




<!--inarticleads2-->

##### Instruksi membuat  Roti boy / Roti O / Mexican bun:

1. Biang : dlm gelas masukkan air, gula &amp; garam, aduk hingga larut, lalu tambahkan fermipan, aduk lg, tunggu hingga berbuih.
1. Adonan roti : masukkan terigu, kuning telur, mentega &amp; butter dlm wadah, tambahkan adonan biang, uleni hingga kalis, jika blm kalis &amp; adonan masih berat tambahkan air, hingga adonan kalis &amp; lembut. Tutup dg serbet bersih. Diamkan 30 - 45 menit.
1. Sambil menunggu adonan d proofing, aduk bahan isian lalu masukkan kulkas, sisihkan.
1. Topping : seduh kopi dg 2 sdm air hangat, aduk hingga larut, sisihkan. Mixer gula &amp; mentega hingga mengembang &amp; pucat, masukkan putih telur, mixer lg hingga mengembang, tambahkan cairan kopi, aduk lg hingga rata. Terakhir masukkan terigu &amp; maizena, aduk hingga rata.
1. Masukkan adonan topping k dlm plastik, masukkan kulkas.
1. Setelah adonan roti mengembang, kempiskan. Timbang adonan masing 30 gr, beri isian, letakkan di loyang yg sudah dioles mentega. Lakukan hingga adonan habis.
1. Diamkan lg ± 45 menit. Setelah 45 menit, panaskan oven, beri topping roti melingkar seperti obat nyamuk. Panggang ± 30 menitan angkat.




Demikianlah cara membuat roti boy / roti o / mexican bun yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
