---
description: "Langkah menyiapakan Coffee Bun atau Mexican Bun atau Roti O&amp;#39; Luar biasa"
title: "Langkah menyiapakan Coffee Bun atau Mexican Bun atau Roti O&amp;#39; Luar biasa"
slug: 420-langkah-menyiapakan-coffee-bun-atau-mexican-bun-atau-roti-o-and-39-luar-biasa
date: 2020-12-09T21:08:39.213Z
image: https://img-global.cpcdn.com/recipes/9d478c4127e4760d/680x482cq70/coffee-bun-atau-mexican-bun-atau-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9d478c4127e4760d/680x482cq70/coffee-bun-atau-mexican-bun-atau-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9d478c4127e4760d/680x482cq70/coffee-bun-atau-mexican-bun-atau-roti-o-foto-resep-utama.jpg
author: Luke Howard
ratingvalue: 4.6
reviewcount: 8546
recipeingredient:
- " Bahan adonan roti"
- "200 gr tepung protein tinggi misal cakra kembar"
- "50 gr tepung protein sedang misal segitiga biru"
- "50 gr gula pasir"
- "7 gr fermipan"
- "2 kuning telur"
- "100 ml susu cair dingin"
- "50 gr unsalted butter suhu ruang"
- " Bahan isian"
- " Salted butter dingin mama Misykah pakai selai goldenfill beku"
- " Toping"
- "100 gr unsalted butter"
- "70 gr gula halus emak ditambahi gulanya biar lbh manis"
- "1 butir telur"
- "80 gr tepung protein sedangrendah"
- "1 sachet kopi diseduh dengan 50ml air hangat emak pake kapal api"
- "2 tetes pasta kopi"
recipeinstructions:
- "Campur terigu, gula pasir, dan ragi instan aduk rata. -Masukkan kuning telur dan susu cair sedikit demi sedikit sambil diuleni hingga kalis. -Tambahkan butter, uleni kembali hingga kalis elastis. Sampai adonan mulus licin, bulatkan simpan didalam wadah tutup dgn plastik wrap atau serbet lembab, diamkan sekitar 60menit atau sampai mengembang 2kali lipat (proofing 1)"
- "Kempeskan adonan, uleni lagi sbentar, lalu bagi adonan sama banyak 50gr each. Diamkan lagi 10menit. Pipihkan adonan beri isian salted butter/mentega asin, rapatkan dan bulatkan. Tata dalam loyang anti lengket/lapisi dgn kertas roti/baking paper. Diamkan 30menit untuk fermentasi ke 2 (proofing 2)."
- "Sambil menunggu proses proofing. Buat adonan topping, kocok butter dan gula halus hingga benar2 halus. Masukan telur kocok lagi, masukan terigu. Terakhir masukan cairan kopi dan pasta kopi. Masukkan kedalam kantong segitiga/ pipping bag. -Panaskan oven 200c ( oven harus sudah panas saat memasukan roti."
- "Setelah proofing 2, semprotkan melingkar topping hingga 3/4 bagian permukaan adonan. -Panggang dalam oven sampai permukaan mengering sekitar 10-12 menit. -Sajikan selagi hangat lebih nikmat"
categories:
- Recipe
tags:
- coffee
- bun
- atau

katakunci: coffee bun atau 
nutrition: 130 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Dinner

---


![Coffee Bun atau Mexican Bun atau Roti O&#39;](https://img-global.cpcdn.com/recipes/9d478c4127e4760d/680x482cq70/coffee-bun-atau-mexican-bun-atau-roti-o-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan renyah. Karasteristik kuliner Nusantara coffee bun atau mexican bun atau roti o&#39; yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga dapat diperoleh dengan cara simple. Diantaranya adalah memasak Coffee Bun atau Mexican Bun atau Roti O&#39; untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang dapat anda praktekkan salah satunya coffee bun atau mexican bun atau roti o&#39; yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep coffee bun atau mexican bun atau roti o&#39; tanpa harus bersusah payah.
Seperti resep Coffee Bun atau Mexican Bun atau Roti O&#39; yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Coffee Bun atau Mexican Bun atau Roti O&#39;:

1. Siapkan  Bahan adonan roti
1. Diperlukan 200 gr tepung protein tinggi (misal cakra kembar)
1. Harus ada 50 gr tepung protein sedang (misal segitiga biru)
1. Harus ada 50 gr gula pasir
1. Siapkan 7 gr fermipan
1. Jangan lupa 2 kuning telur
1. Diperlukan 100 ml susu cair dingin
1. Harus ada 50 gr unsalted butter suhu ruang
1. Harap siapkan  Bahan isian
1. Jangan lupa  Salted butter dingin (mama Misykah pakai selai goldenfill beku)
1. Diperlukan  Toping
1. Harap siapkan 100 gr unsalted butter
1. Harap siapkan 70 gr gula halus (emak ditambahi gulanya biar lbh manis)
1. Siapkan 1 butir telur
1. Siapkan 80 gr tepung protein sedang/rendah
1. Tambah 1 sachet kopi diseduh dengan 50ml air hangat (emak pake kapal api
1. Jangan lupa 2 tetes pasta kopi




<!--inarticleads2-->

##### Bagaimana membuat  Coffee Bun atau Mexican Bun atau Roti O&#39;:

1. Campur terigu, gula pasir, dan ragi instan aduk rata. - -Masukkan kuning telur dan susu cair sedikit demi sedikit sambil diuleni hingga kalis. - -Tambahkan butter, uleni kembali hingga kalis elastis. Sampai adonan mulus licin, bulatkan simpan didalam wadah tutup dgn plastik wrap atau serbet lembab, diamkan sekitar 60menit atau sampai mengembang 2kali lipat (proofing 1)
1. Kempeskan adonan, uleni lagi sbentar, lalu bagi adonan sama banyak 50gr each. Diamkan lagi 10menit. Pipihkan adonan beri isian salted butter/mentega asin, rapatkan dan bulatkan. Tata dalam loyang anti lengket/lapisi dgn kertas roti/baking paper. Diamkan 30menit untuk fermentasi ke 2 (proofing 2).
1. Sambil menunggu proses proofing. Buat adonan topping, kocok butter dan gula halus hingga benar2 halus. Masukan telur kocok lagi, masukan terigu. Terakhir masukan cairan kopi dan pasta kopi. Masukkan kedalam kantong segitiga/ pipping bag. -Panaskan oven 200c ( oven harus sudah panas saat memasukan roti.
1. Setelah proofing 2, semprotkan melingkar topping hingga 3/4 bagian permukaan adonan. - -Panggang dalam oven sampai permukaan mengering sekitar 10-12 menit. -Sajikan selagi hangat lebih nikmat




Demikianlah cara membuat coffee bun atau mexican bun atau roti o&#39; yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
