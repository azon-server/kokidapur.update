---
description: "Resep : Mexican buns (roti Kopi / roti O / roti boy) Teruji"
title: "Resep : Mexican buns (roti Kopi / roti O / roti boy) Teruji"
slug: 329-resep-mexican-buns-roti-kopi-roti-o-roti-boy-teruji
date: 2021-03-08T00:34:09.838Z
image: https://img-global.cpcdn.com/recipes/8ad712c98db3db17/680x482cq70/mexican-buns-roti-kopi-roti-o-roti-boy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8ad712c98db3db17/680x482cq70/mexican-buns-roti-kopi-roti-o-roti-boy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8ad712c98db3db17/680x482cq70/mexican-buns-roti-kopi-roti-o-roti-boy-foto-resep-utama.jpg
author: Susan Hicks
ratingvalue: 4.1
reviewcount: 41180
recipeingredient:
- " BAHAN ROTI "
- "500 gr total terigu cakra dan 1 sachet tropicanaslim coffeluwak white coffe"
- "280 ml susu uht dingin"
- "30 gr susu bubuk"
- "11 gr fermipan"
- "60 gr gula pasir"
- "1 butir telur 50gr"
- "85 gr butter"
- "1 sdt garam"
- " BAHAN Filling "
- "150 gr butter"
- "75 gr brown sugar"
- " BAHAN TOPPING "
- "55 gr butter"
- "60 gr gula halus"
- "60 gr terigu kunci"
- "10 ml airpanas  1 sdt nescafe classic"
- "1 butir telur 50gr"
recipeinstructions:
- "Mixer bahan roti hingga kais elastis, proofing 1 jam"
- "Membuat filling: campur semua bahan, sendok bulat bulat dan masukkan ke kulkas"
- "Membuat topping : campur semua bahan, masukkan pippingbag"
- "Setelah 1 jam, bentuk bulat kecil, isi dgn filling (usahakan menutup adonan dgn rapat agar tdk bocor saat dipanggang)  Proofing 30 menit  Beri topping melingkar rapat sebelum dipanggang"
- "Oven suhu 200 derajat api atas bawah selama 15 menit, lanjutkan 5 menit hanya dgn api bawah"
- "Sajikan dengan teh panas atau secangkir kopi"
categories:
- Recipe
tags:
- mexican
- buns
- roti

katakunci: mexican buns roti 
nutrition: 272 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Lunch

---


![Mexican buns (roti Kopi / roti O / roti boy)](https://img-global.cpcdn.com/recipes/8ad712c98db3db17/680x482cq70/mexican-buns-roti-kopi-roti-o-roti-boy-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang harus kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti mexican buns (roti kopi / roti o / roti boy) yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan keistimewahan yang merupakan keragaman Nusantara

G. these buns are SO delicious you&#39;ve got to try them! These fluffy, buttery buns are topped with a coffee scented cookie crust, and they became wildly. Mexican Coffee Bun (Rotiboy) - Sweet bun with coffee topping and butter filling. It&#39;s popular in Malaysia and Asia.

Kehangatan keluarga dapat didapat dengan cara simple. Diantaranya adalah memasak Mexican buns (roti Kopi / roti O / roti boy) untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang dapat anda coba salah satunya mexican buns (roti kopi / roti o / roti boy) yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep mexican buns (roti kopi / roti o / roti boy) tanpa harus bersusah payah.
Seperti resep Mexican buns (roti Kopi / roti O / roti boy) yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican buns (roti Kopi / roti O / roti boy):

1. Dibutuhkan  BAHAN ROTI :
1. Harus ada 500 gr (total terigu cakra dan 1 sachet tropicanaslim coffe/luwak white coffe)
1. Harus ada 280 ml susu uht dingin
1. Siapkan 30 gr susu bubuk
1. Dibutuhkan 11 gr fermipan
1. Dibutuhkan 60 gr gula pasir
1. Siapkan 1 butir telur (50gr)
1. Harap siapkan 85 gr butter
1. Diperlukan 1 sdt garam
1. Harus ada  BAHAN Filling :
1. Dibutuhkan 150 gr butter
1. Harap siapkan 75 gr brown sugar
1. Harus ada  BAHAN TOPPING :
1. Harap siapkan 55 gr butter
1. Dibutuhkan 60 gr gula halus
1. Harap siapkan 60 gr terigu kunci
1. Diperlukan 10 ml (airpanas + 1 sdt nescafe classic)
1. Jangan lupa 1 butir telur (50gr)


I used a tangzhong milk loaf for my buns. They turned out super soft, fluffy and shreddable. The topping was crisp on day one, but softened. Divna,mekana okrugla peciva,punjena kockicama putera sa prelivom od kafe. 

<!--inarticleads2-->

##### Instruksi membuat  Mexican buns (roti Kopi / roti O / roti boy):

1. Mixer bahan roti hingga kais elastis, proofing 1 jam
1. Membuat filling: campur semua bahan, sendok bulat bulat dan masukkan ke kulkas
1. Membuat topping : campur semua bahan, masukkan pippingbag
1. Setelah 1 jam, bentuk bulat kecil, isi dgn filling (usahakan menutup adonan dgn rapat agar tdk bocor saat dipanggang) -  - Proofing 30 menit -  - Beri topping melingkar rapat sebelum dipanggang
1. Oven suhu 200 derajat api atas bawah selama 15 menit, lanjutkan 5 menit hanya dgn api bawah
1. Sajikan dengan teh panas atau secangkir kopi


The topping was crisp on day one, but softened. Divna,mekana okrugla peciva,punjena kockicama putera sa prelivom od kafe. Poznata su pod nazivima Mexican buns,Pappa Roti,Roti Boy,Coffee Buns. Coffee Bun - Kopi Roti or Mexican Bun - Spoonful Passion. Pappa Roti/Mexican Buns/Roti Boy - Savory&amp;SweetFood. 

Demikianlah cara membuat mexican buns (roti kopi / roti o / roti boy) yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan cepat, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
