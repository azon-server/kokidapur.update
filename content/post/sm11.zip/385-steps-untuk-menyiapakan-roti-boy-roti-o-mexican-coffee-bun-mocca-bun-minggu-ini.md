---
description: "Steps untuk menyiapakan Roti boy/roti o/ mexican coffee bun/mocca bun minggu ini"
title: "Steps untuk menyiapakan Roti boy/roti o/ mexican coffee bun/mocca bun minggu ini"
slug: 385-steps-untuk-menyiapakan-roti-boy-roti-o-mexican-coffee-bun-mocca-bun-minggu-ini
date: 2020-12-05T11:08:23.017Z
image: https://img-global.cpcdn.com/recipes/806a34e251b16bf8/680x482cq70/roti-boyroti-o-mexican-coffee-bunmocca-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/806a34e251b16bf8/680x482cq70/roti-boyroti-o-mexican-coffee-bunmocca-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/806a34e251b16bf8/680x482cq70/roti-boyroti-o-mexican-coffee-bunmocca-bun-foto-resep-utama.jpg
author: Vernon Williams
ratingvalue: 4.9
reviewcount: 3940
recipeingredient:
- " Bahan A"
- "250 gr tepung terigu protein tinggi"
- "50 gr gula pasir"
- "27 gr susu bubuk"
- "1 sdt ragi instan"
- "1 butir telur ukuran kecil 60 gr ditimbang dengan kulit"
- "130 ml air"
- "25 gr margarine"
- " butter asin secukupnya untuk isian dalam keadaan dingin potong dadu karena saya punyanya butter yang tidak ada rasa jadi saya kasih sedikit garam"
- " Bahan B"
- "50 gr margarine"
- "55 gr gula halus"
- "60 gr tepung terigu"
- "2 sdt kopi instan luwak"
- "1 butir putih telur"
- "sedikit pasta mocca kalau ngak ada bisa diskip ganti dengan 1 sachet kopi instan tanpa ampas cuma tidak sewangi kalau pakai pasta mocca"
recipeinstructions:
- "Campur semua bahan A, kecuali margarine. mixer dengan hand mixer sampai setengah kalis, kemudian baru masukkan margarine, mixer lagi sampai adonan menjadi kalis elastis. ciri adonan roti kalis elastis: Adonan menjadi elastis seperti karet saat di tarik.  rentangkan adonan dan buat menjadi tipis. Bila adonan menjadi sedikit transparan dan tak mudah robek, maka adonan sudah dapat dikatakan kalis."
- "Olesi sedikit minyak pada bawah mangkok dan juga di atas adonan, biar nanti waktu di proffing adonannya tidak kering. Tutup adonan dengan kain/ plastik wrap, proffing sampai mengembang 2x lipat. biasanya 1-2 jam tergantung suhu ruangan. kalau suhu ruangannya panas, adonan akan cepat naik."
- "Kempeskan adonan, pindahkan ke silicon mat yang sudah ditaburi sedikit tepung terigu. Bagi adonan sesuai selera mau beratnya berapa yah moms. kalau saya bagi menjadi 8 bagian, kemudian timbang masing masing dengan berat 50 gr."
- "Setelah didapat 8 pcs adonan dengan berat masing masing 50 gram dan sisa 89 gr, adonan 89 gr saya bagi lagi menjadi 8 pcs buat membungkus butternya. Jadi saya membungkus 2x biar butternya tidak mudah pecah waktu dipanggang."
- "Bungkus butter nya dengan adonan kecil. tutup dan bulatkan."
- "Bungkus dengan adonan yang lebih besar, tutup dan bulatkan"
- "Tata diatas loyang, kasih jarak yang lumayan jauh yah. idealnya 1 loyang isi 3-4. jangan seperti saya kebanyakan isi 6. Karena pada saat di panggang roti akan mengembang menjadi besar. kalau rotinya jadi dempet, toppingnya tidak bisa turun maksimal karena terhalang roti lainnya. Proffing lagi selama 30-40 menit."
- "Sementara kita menunggu adonan di proffing lagi, kita buat toppingnya. aduk dulu margarinenya sampai agak pucat kemudian masukkan gula halusnya, aduk lagi sampai pucat. kemudian masukkan bahan B yang lainnya aduk sampai tercampur rata.  Supaya permukaannya terselimuti rata, konsistensi topping kopi harus pas, yakni agak kental dan tidak langsung meleleh jatuh ketika dilingkarkan di atas permukaan adonan.  Tuang topping kedalam plastik segitiga. Sisihkan"
- "Setelah rotinya mengembang, kita semprotkan toppingnya diatas adonan roti. Agar hasil toppingnya cantik dan rata, pastikan saat menyemprot topping, jarak lingkarannya rapat. Jika ada renggang biasanya saat matang, masih ada bagian yang tidak tertutup sempurna di permukaan roti."
- "Panggang dalam oven yang sudah dipanaskan. saya memanggang roti dengan suhu 170 °selama 17-20 mnt api bawah, dan 10 menit api atas. sesuaikan dengan suhu oven masing masin yah.  setelah 15 menit jangan lupa mengintip bawah roti, kalau sudah agak coklat, pindahkan ke api atas."
- "Jika terlihat topping sudah kecoklatan dan mengeras, keluarkan dr oven.  roti akan matang saat topping kopinya sudah meleleh, menyelimuti permukaan adonan roti, dan bertekstur rapuh-renyah. Jika terlalu lama memanggang atau terlalu tinggi suhunya, mocha bun akan cenderung kering dan filling-nya tidak akan meleleh sesuai harapan."
- "Roti boy siap disajikan. Tonton video cara membuat roti boy di youtube Smart Mama Vlog"
categories:
- Recipe
tags:
- roti
- boyroti
- o

katakunci: roti boyroti o 
nutrition: 267 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Dinner

---


![Roti boy/roti o/ mexican coffee bun/mocca bun](https://img-global.cpcdn.com/recipes/806a34e251b16bf8/680x482cq70/roti-boyroti-o-mexican-coffee-bunmocca-bun-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang setidaknya kita lestarikan karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti roti boy/roti o/ mexican coffee bun/mocca bun yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa keistimewahan yang merupakan keragaman Kita

Keharmonisan keluarga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Roti boy/roti o/ mexican coffee bun/mocca bun untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang bisa anda praktekkan salah satunya roti boy/roti o/ mexican coffee bun/mocca bun yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep roti boy/roti o/ mexican coffee bun/mocca bun tanpa harus bersusah payah.
Seperti resep Roti boy/roti o/ mexican coffee bun/mocca bun yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 12 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti boy/roti o/ mexican coffee bun/mocca bun:

1. Diperlukan  Bahan A
1. Dibutuhkan 250 gr tepung terigu protein tinggi
1. Harap siapkan 50 gr gula pasir
1. Dibutuhkan 27 gr susu bubuk
1. Jangan lupa 1 sdt ragi instan
1. Harus ada 1 butir telur ukuran kecil (60 gr ditimbang dengan kulit)
1. Harap siapkan 130 ml air
1. Dibutuhkan 25 gr margarine
1. Tambah  butter asin secukupnya untuk isian dalam keadaan dingin (potong dadu). karena saya punyanya butter yang tidak ada rasa, jadi saya kasih sedikit garam
1. Dibutuhkan  Bahan B:
1. Harap siapkan 50 gr margarine
1. Harap siapkan 55 gr gula halus
1. Siapkan 60 gr tepung terigu
1. Tambah 2 sdt kopi instan luwak
1. Tambah 1 butir putih telur
1. Harus ada sedikit pasta mocca (kalau ngak ada bisa diskip, ganti dengan 1 sachet kopi instan tanpa ampas, cuma tidak sewangi kalau pakai pasta mocca)




<!--inarticleads2-->

##### Langkah membuat  Roti boy/roti o/ mexican coffee bun/mocca bun:

1. Campur semua bahan A, kecuali margarine. mixer dengan hand mixer sampai setengah kalis, kemudian baru masukkan margarine, mixer lagi sampai adonan menjadi kalis elastis. ciri adonan roti kalis elastis: Adonan menjadi elastis seperti karet saat di tarik. -  rentangkan adonan dan buat menjadi tipis. Bila adonan menjadi sedikit transparan dan tak mudah robek, maka adonan sudah dapat dikatakan kalis.
1. Olesi sedikit minyak pada bawah mangkok dan juga di atas adonan, biar nanti waktu di proffing adonannya tidak kering. Tutup adonan dengan kain/ plastik wrap, proffing sampai mengembang 2x lipat. biasanya 1-2 jam tergantung suhu ruangan. kalau suhu ruangannya panas, adonan akan cepat naik.
1. Kempeskan adonan, pindahkan ke silicon mat yang sudah ditaburi sedikit tepung terigu. Bagi adonan sesuai selera mau beratnya berapa yah moms. kalau saya bagi menjadi 8 bagian, kemudian timbang masing masing dengan berat 50 gr.
1. Setelah didapat 8 pcs adonan dengan berat masing masing 50 gram dan sisa 89 gr, adonan 89 gr saya bagi lagi menjadi 8 pcs buat membungkus butternya. Jadi saya membungkus 2x biar butternya tidak mudah pecah waktu dipanggang.
1. Bungkus butter nya dengan adonan kecil. tutup dan bulatkan.
1. Bungkus dengan adonan yang lebih besar, tutup dan bulatkan
1. Tata diatas loyang, kasih jarak yang lumayan jauh yah. idealnya 1 loyang isi 3-4. jangan seperti saya kebanyakan isi 6. - Karena pada saat di panggang roti akan mengembang menjadi besar. kalau rotinya jadi dempet, toppingnya tidak bisa turun maksimal karena terhalang roti lainnya. Proffing lagi selama 30-40 menit.
1. Sementara kita menunggu adonan di proffing lagi, kita buat toppingnya. aduk dulu margarinenya sampai agak pucat kemudian masukkan gula halusnya, aduk lagi sampai pucat. kemudian masukkan bahan B yang lainnya aduk sampai tercampur rata. -  Supaya permukaannya terselimuti rata, konsistensi topping kopi harus pas, yakni agak kental dan tidak langsung meleleh jatuh ketika dilingkarkan di atas permukaan adonan. -  Tuang topping kedalam plastik segitiga. Sisihkan
1. Setelah rotinya mengembang, kita semprotkan toppingnya diatas adonan roti. Agar hasil toppingnya cantik dan rata, pastikan saat menyemprot topping, jarak lingkarannya rapat. Jika ada renggang biasanya saat matang, masih ada bagian yang tidak tertutup sempurna di permukaan roti.
1. Panggang dalam oven yang sudah dipanaskan. saya memanggang roti dengan suhu 170 °selama 17-20 mnt api bawah, dan 10 menit api atas. sesuaikan dengan suhu oven masing masin yah.  - setelah 15 menit jangan lupa mengintip bawah roti, kalau sudah agak coklat, pindahkan ke api atas.
1. Jika terlihat topping sudah kecoklatan dan mengeras, keluarkan dr oven.  - roti akan matang saat topping kopinya sudah meleleh, menyelimuti permukaan adonan roti, dan bertekstur rapuh-renyah. Jika terlalu lama memanggang atau terlalu tinggi suhunya, mocha bun akan cenderung kering dan filling-nya tidak akan meleleh sesuai harapan.
1. Roti boy siap disajikan. Tonton video cara membuat roti boy di youtube Smart Mama Vlog




Demikianlah cara membuat roti boy/roti o/ mexican coffee bun/mocca bun yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan teruji, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
