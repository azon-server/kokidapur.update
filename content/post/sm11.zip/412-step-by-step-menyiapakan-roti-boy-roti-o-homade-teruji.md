---
description: "Step-by-Step menyiapakan Roti Boy / Roti O Homade Teruji"
title: "Step-by-Step menyiapakan Roti Boy / Roti O Homade Teruji"
slug: 412-step-by-step-menyiapakan-roti-boy-roti-o-homade-teruji
date: 2020-10-19T09:05:44.757Z
image: https://img-global.cpcdn.com/recipes/f6d67af8d49078f2/680x482cq70/roti-boy-roti-o-homade-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f6d67af8d49078f2/680x482cq70/roti-boy-roti-o-homade-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f6d67af8d49078f2/680x482cq70/roti-boy-roti-o-homade-foto-resep-utama.jpg
author: Benjamin Roy
ratingvalue: 4.1
reviewcount: 34728
recipeingredient:
- " Bahan roti"
- "100 gr tepung protein tinggi"
- "100 gr tepung protein sedang"
- "6 gr fermipan bisa pake merk ragi instan lainnya"
- "100 ml susu cair hangat saya pake susu bubuk dicairkan"
- "2 sdm gula pasir"
- "1 sachet susu bubuk merk apa aja"
- "2 sdm margarin butter blueband cake n cookie"
- "1 butir telur ayam kocok lepas"
- "Sejumput garam"
- " Bahan toping"
- "1 sdm luwak white coffee"
- "1 sdm air hangat"
- "1 sdm margarin blueband cake and cookie"
- "1 butir telur ayam kocok lepas"
- "1 sdm gula pasir halus"
- "60 gr tepung terigu protein tinggi"
recipeinstructions:
- "Cara membuat adonan roti :"
- "Buat biang ragi lebih dulu, campur susu cair hangat, ragi,dan gula pasir, aduk, diamkan 10 menit."
- "Campur tepung, susu bubuk, telur, dan baan biang ragi, uleni."
- "Setelah adonan sedikit kalis, tambahkan margarin dan garam, uleni lagi sampai benar-benar kalis dan tidak lengket. Bentuk bulatan, diamkan selama 1 jam, biarkan mengembang dua kali lipat. Tutup dengan kain basah."
- "Setelah satu jam, tinju adonan yang sudah mengembang, timbang per 30 gr, bulatkan kecil-kecil sambil diisi parutan keju (saya nggak pake), sambil panaskan oven selama 15 menit."
- "Buat adonan toping dengan mencampur white coffee dengan air hangat. Aduk sampai tidak berbulir."
- "Campur semua bahan toping, mixer kecepatan sedang sampai semua bahan menyatu."
- "Oleskan bahan toping di atas adonan roti secara melingkar, jangan terlalu penuh agar tidak meluber ke mana-mana."
- "Taruh adonan roti boy ke dalam loyan nastar yang sudah diolesi margarin dan tepung lebih dulu."
- "Panggang selama 20 menit dalam suhu 200°, boleh lebih lama jika ingin roti sedikit garing."
- "Sajikan hangat-hangat bersama teh."
categories:
- Recipe
tags:
- roti
- boy
- 

katakunci: roti boy  
nutrition: 111 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Dessert

---


![Roti Boy / Roti O Homade](https://img-global.cpcdn.com/recipes/f6d67af8d49078f2/680x482cq70/roti-boy-roti-o-homade-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang harus kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti roti boy / roti o homade yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa keistimewahan yang merupakan keragaman Nusantara

Kedekatan keluarga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak Roti Boy / Roti O Homade untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang dapat anda praktekkan salah satunya roti boy / roti o homade yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep roti boy / roti o homade tanpa harus bersusah payah.
Seperti resep Roti Boy / Roti O Homade yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 11 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Boy / Roti O Homade:

1. Tambah  Bahan roti:
1. Jangan lupa 100 gr tepung protein tinggi
1. Diperlukan 100 gr tepung protein sedang
1. Harus ada 6 gr fermipan (bisa pake merk ragi instan lainnya)
1. Jangan lupa 100 ml susu cair hangat (saya pake susu bubuk dicairkan)
1. Dibutuhkan 2 sdm gula pasir
1. Tambah 1 sachet susu bubuk merk apa aja
1. Harus ada 2 sdm margarin butter (blueband cake n cookie)
1. Tambah 1 butir telur ayam kocok lepas
1. Dibutuhkan Sejumput garam
1. Jangan lupa  Bahan toping:
1. Tambah 1 sdm luwak white coffee
1. Diperlukan 1 sdm air hangat
1. Harus ada 1 sdm margarin blueband cake and cookie
1. Siapkan 1 butir telur ayam kocok lepas
1. Harap siapkan 1 sdm gula pasir halus
1. Harus ada 60 gr tepung terigu protein tinggi




<!--inarticleads2-->

##### Langkah membuat  Roti Boy / Roti O Homade:

1. Cara membuat adonan roti :
1. Buat biang ragi lebih dulu, campur susu cair hangat, ragi,dan gula pasir, aduk, diamkan 10 menit.
1. Campur tepung, susu bubuk, telur, dan baan biang ragi, uleni.
1. Setelah adonan sedikit kalis, tambahkan margarin dan garam, uleni lagi sampai benar-benar kalis dan tidak lengket. Bentuk bulatan, diamkan selama 1 jam, biarkan mengembang dua kali lipat. Tutup dengan kain basah.
1. Setelah satu jam, tinju adonan yang sudah mengembang, timbang per 30 gr, bulatkan kecil-kecil sambil diisi parutan keju (saya nggak pake), sambil panaskan oven selama 15 menit.
1. Buat adonan toping dengan mencampur white coffee dengan air hangat. Aduk sampai tidak berbulir.
1. Campur semua bahan toping, mixer kecepatan sedang sampai semua bahan menyatu.
1. Oleskan bahan toping di atas adonan roti secara melingkar, jangan terlalu penuh agar tidak meluber ke mana-mana.
1. Taruh adonan roti boy ke dalam loyan nastar yang sudah diolesi margarin dan tepung lebih dulu.
1. Panggang selama 20 menit dalam suhu 200°, boleh lebih lama jika ingin roti sedikit garing.
1. Sajikan hangat-hangat bersama teh.




Demikianlah cara membuat roti boy / roti o homade yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan teruji, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
