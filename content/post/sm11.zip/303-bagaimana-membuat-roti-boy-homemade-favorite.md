---
description: "Bagaimana membuat Roti Boy Homemade Favorite"
title: "Bagaimana membuat Roti Boy Homemade Favorite"
slug: 303-bagaimana-membuat-roti-boy-homemade-favorite
date: 2021-01-19T09:00:43.578Z
image: https://img-global.cpcdn.com/recipes/5d2c816bf7d9ed67/680x482cq70/roti-boy-homemade-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5d2c816bf7d9ed67/680x482cq70/roti-boy-homemade-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5d2c816bf7d9ed67/680x482cq70/roti-boy-homemade-foto-resep-utama.jpg
author: Roy Fernandez
ratingvalue: 4.6
reviewcount: 29880
recipeingredient:
- " Bahan Roti"
- "250 gr tepung cakra"
- "1 btr kuning telor"
- "1 sdt ragi instan"
- "2 sdm munjung gula pasir"
- "1 sdm munjung margarin"
- "1 sdm susu bubuk"
- "Sejumput garam"
- "125-150 ml air hangatsusu hangat"
- " Bahan Topping"
- "1 butir putih telor"
- "50 gr margarin"
- "50 gr gula pasir"
- "60 gr tepung terigu"
- "20 gr tepung maizena"
- "1 sdm pasta moka"
- "1 sdm susu bubuk"
- "1 sachet Kopi Instan White Coffee"
- "2 sdm skm putih"
- " Isian Keju"
- "50 gr margarin"
- "50 gr keju cheddar parut"
- "2 sdm gula pasir"
- "1 sdm susu bubuk"
recipeinstructions:
- "Campurkan semua bahan roti (kecuali air hangat), sambil diratakan margarin &amp; telornya. Lalu tuangkan air sedikit-sedikit sambil terus diulenin sampai kalis elastis. Bulatkan, lalu diamkan hingga mengembang 2x lipat dgn ditutup kain lembab / plastic wrap (saya -/+ 1 jam)"
- "Sambil menunggu, qta buat isiannya. Campur semua bahan isian sambil diaduk merata dgn sendok, lalu masukkan ke dlm kulkas (klo saya setelah diaduk rata, tuangkan ke wadah kecil datar lalu diratakan biar nnti bisa dipotong/dipulung agar lebih mudah dimasukkan ke dlm roti)"
- "Topping: Mixer putih telor, gula &amp; margarin sampai creamy. Lalu masukkan tepung terigu, tepung maizena, susu bubuk, Kopi Instan, pasta moka &amp; skm putih. Mixer hingga benar&#34; lembut. Masukkan ke dlm piping bag lalu gunting sedikit ujung plastiknya"
- "Setelah adonan roti mengembang, kempeskan adonan lalu bagi adonan dgn berat yg sama sesuai selera (saya 40 gr) lalu bulat&#34;kan. Kemudian pipihkan adonan roti, isi dgn isian sesuai selera. Bulatkan kembali, lalu tata di loyang yg diberi alas kertas roti &amp; dioles margarin (saya skip kertas rotinya). Diamkan hingga mengembang kembali. Jgn lupa utk menutup roti agar tdk kering"
- "Panaskan oven"
- "Setelah didiamkan sebentar, lalu beri topping diatas roti dgn menyemprotkannya secara melingkar seperti obat nyamuk."
- "Oven roti hingga matang dgn api sedang"
- "Angkat, sajikan hangat"
categories:
- Recipe
tags:
- roti
- boy
- homemade

katakunci: roti boy homemade 
nutrition: 176 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Lunch

---


![Roti Boy Homemade](https://img-global.cpcdn.com/recipes/5d2c816bf7d9ed67/680x482cq70/roti-boy-homemade-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga renyah. Karasteristik kuliner Nusantara roti boy homemade yang penuh dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.




Keharmonisan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak Roti Boy Homemade untuk keluarga. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis makanan yang bisa anda contoh salah satunya roti boy homemade yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep roti boy homemade tanpa harus bersusah payah.
Berikut ini resep Roti Boy Homemade yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 24 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Boy Homemade:

1. Siapkan  Bahan Roti:
1. Harap siapkan 250 gr tepung cakra
1. Jangan lupa 1 btr kuning telor
1. Tambah 1 sdt ragi instan
1. Tambah 2 sdm munjung gula pasir
1. Diperlukan 1 sdm munjung margarin
1. Diperlukan 1 sdm susu bubuk
1. Siapkan Sejumput garam
1. Siapkan 125-150 ml air hangat/susu hangat
1. Tambah  Bahan Topping:
1. Harap siapkan 1 butir putih telor
1. Jangan lupa 50 gr margarin
1. Dibutuhkan 50 gr gula pasir
1. Harus ada 60 gr tepung terigu
1. Harap siapkan 20 gr tepung maizena
1. Harus ada 1 sdm pasta moka
1. Jangan lupa 1 sdm susu bubuk
1. Dibutuhkan 1 sachet Kopi Instan (White Coffee)
1. Siapkan 2 sdm skm putih
1. Harap siapkan  Isian Keju:
1. Dibutuhkan 50 gr margarin
1. Diperlukan 50 gr keju cheddar parut
1. Siapkan 2 sdm gula pasir
1. Jangan lupa 1 sdm susu bubuk




<!--inarticleads2-->

##### Cara membuat  Roti Boy Homemade:

1. Campurkan semua bahan roti (kecuali air hangat), sambil diratakan margarin &amp; telornya. Lalu tuangkan air sedikit-sedikit sambil terus diulenin sampai kalis elastis. Bulatkan, lalu diamkan hingga mengembang 2x lipat dgn ditutup kain lembab / plastic wrap (saya -/+ 1 jam)
1. Sambil menunggu, qta buat isiannya. Campur semua bahan isian sambil diaduk merata dgn sendok, lalu masukkan ke dlm kulkas (klo saya setelah diaduk rata, tuangkan ke wadah kecil datar lalu diratakan biar nnti bisa dipotong/dipulung agar lebih mudah dimasukkan ke dlm roti)
1. Topping: Mixer putih telor, gula &amp; margarin sampai creamy. Lalu masukkan tepung terigu, tepung maizena, susu bubuk, Kopi Instan, pasta moka &amp; skm putih. Mixer hingga benar&#34; lembut. Masukkan ke dlm piping bag lalu gunting sedikit ujung plastiknya
1. Setelah adonan roti mengembang, kempeskan adonan lalu bagi adonan dgn berat yg sama sesuai selera (saya 40 gr) lalu bulat&#34;kan. Kemudian pipihkan adonan roti, isi dgn isian sesuai selera. Bulatkan kembali, lalu tata di loyang yg diberi alas kertas roti &amp; dioles margarin (saya skip kertas rotinya). Diamkan hingga mengembang kembali. Jgn lupa utk menutup roti agar tdk kering
1. Panaskan oven
1. Setelah didiamkan sebentar, lalu beri topping diatas roti dgn menyemprotkannya secara melingkar seperti obat nyamuk.
1. Oven roti hingga matang dgn api sedang
1. Angkat, sajikan hangat




Demikianlah cara membuat roti boy homemade yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat simple dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
