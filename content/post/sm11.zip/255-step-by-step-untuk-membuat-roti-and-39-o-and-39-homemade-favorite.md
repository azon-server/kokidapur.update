---
description: "Step-by-Step untuk membuat Roti &amp;#39;O&amp;#39; Homemade Favorite"
title: "Step-by-Step untuk membuat Roti &amp;#39;O&amp;#39; Homemade Favorite"
slug: 255-step-by-step-untuk-membuat-roti-and-39-o-and-39-homemade-favorite
date: 2020-09-28T05:03:04.237Z
image: https://img-global.cpcdn.com/recipes/e558ba1850515088/680x482cq70/roti-o-homemade-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e558ba1850515088/680x482cq70/roti-o-homemade-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e558ba1850515088/680x482cq70/roti-o-homemade-foto-resep-utama.jpg
author: Lottie Park
ratingvalue: 4.3
reviewcount: 39313
recipeingredient:
- " Bahan roti"
- "500 gr terigu tinggi protein"
- "1 sdm fermipan"
- "50 gr gula pasir"
- "2 butir telur"
- "25 gr susu bubuk"
- "1/2 sdt garam"
- "220 ml air"
- "75 gr margarin"
- " Bahan topping"
- "100 gr butter"
- "100 gr gula palem"
- "10 gr tepung custard maizena"
- "1 butir putih telur"
- "1 sdm kopi bubuk dilarutkan dalam 3 sdm air panas"
- " Bahan filling"
- "75 gr gula palem"
- "75 gr butter"
- "25 gr terigu"
recipeinstructions:
- "Roti : campur terigu, fermipan, gula pasir, telur, susu bubuk, air, garam. Uleni hingga rata dan kalis."
- "Tambahkan margarin, uleni kembali hingga elastis saya banting-banting biar rotinya lembut. Diamkan 30 menit."
- "Sementara menunggu roti fermentasi. Kita bikin topping dan filling."
- "Topping: kocok butter dan gula palem sampai lembut. Tambahkan putih telur dan kopi kocok kembali hingga rata. Masukkan adonan ke dalam plastik segitiga, sisihkan."
- "Filing : aduk bahan semua bahan filling, taruh di kulkas sebentar agar mudah dibentuk bulat2 sekitar 10 gr."
- "Balik ke adonan roti : kempiskan adonan roti. Potong dan timbang masing2 50 gr. Bulatkan lalu pipihkan. Masukkan filing lalu katupkan adonan roti dengan diplintir agar tidak bocor. Bulatkan kembali. Diamkan 45 menit."
- "Semprotkan topping di atas permukaan roti. Gak usah sampai bawah karena topping akan mleber ke bawah. Semprot memutar seperti bentuk obat nyamuk."
- "Oven 190 dercel, 15 menit hingga matang."
- "Jadi dehh"
categories:
- Recipe
tags:
- roti
- o
- homemade

katakunci: roti o homemade 
nutrition: 176 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Dinner

---


![Roti &#39;O&#39; Homemade](https://img-global.cpcdn.com/recipes/e558ba1850515088/680x482cq70/roti-o-homemade-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti roti &#39;o&#39; homemade yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa kesan tersendiri yang merupakan keragaman Kita

Kehangatan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Roti &#39;O&#39; Homemade untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang dapat anda contoh salah satunya roti &#39;o&#39; homemade yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep roti &#39;o&#39; homemade tanpa harus bersusah payah.
Berikut ini resep Roti &#39;O&#39; Homemade yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti &#39;O&#39; Homemade:

1. Siapkan  Bahan roti
1. Diperlukan 500 gr terigu tinggi protein
1. Harap siapkan 1 sdm fermipan
1. Harap siapkan 50 gr gula pasir
1. Tambah 2 butir telur
1. Tambah 25 gr susu bubuk
1. Jangan lupa 1/2 sdt garam
1. Jangan lupa 220 ml air
1. Tambah 75 gr margarin
1. Tambah  Bahan topping
1. Dibutuhkan 100 gr butter
1. Jangan lupa 100 gr gula palem
1. Diperlukan 10 gr tepung custard /maizena
1. Diperlukan 1 butir putih telur
1. Harus ada 1 sdm kopi bubuk dilarutkan dalam 3 sdm air panas
1. Dibutuhkan  Bahan filling
1. Harap siapkan 75 gr gula palem
1. Harap siapkan 75 gr butter
1. Jangan lupa 25 gr terigu




<!--inarticleads2-->

##### Langkah membuat  Roti &#39;O&#39; Homemade:

1. Roti : campur terigu, fermipan, gula pasir, telur, susu bubuk, air, garam. Uleni hingga rata dan kalis.
1. Tambahkan margarin, uleni kembali hingga elastis saya banting-banting biar rotinya lembut. Diamkan 30 menit.
1. Sementara menunggu roti fermentasi. Kita bikin topping dan filling.
1. Topping: kocok butter dan gula palem sampai lembut. Tambahkan putih telur dan kopi kocok kembali hingga rata. Masukkan adonan ke dalam plastik segitiga, sisihkan.
1. Filing : aduk bahan semua bahan filling, taruh di kulkas sebentar agar mudah dibentuk bulat2 sekitar 10 gr.
1. Balik ke adonan roti : kempiskan adonan roti. Potong dan timbang masing2 50 gr. Bulatkan lalu pipihkan. Masukkan filing lalu katupkan adonan roti dengan diplintir agar tidak bocor. Bulatkan kembali. Diamkan 45 menit.
1. Semprotkan topping di atas permukaan roti. Gak usah sampai bawah karena topping akan mleber ke bawah. Semprot memutar seperti bentuk obat nyamuk.
1. Oven 190 dercel, 15 menit hingga matang.
1. Jadi dehh




Demikianlah cara membuat roti &#39;o&#39; homemade yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan teruji, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
