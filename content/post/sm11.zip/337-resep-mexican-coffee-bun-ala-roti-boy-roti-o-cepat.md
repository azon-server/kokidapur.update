---
description: "Resep : Mexican Coffee Bun ala Roti Boy/ Roti O Cepat"
title: "Resep : Mexican Coffee Bun ala Roti Boy/ Roti O Cepat"
slug: 337-resep-mexican-coffee-bun-ala-roti-boy-roti-o-cepat
date: 2021-03-07T00:54:18.252Z
image: https://img-global.cpcdn.com/recipes/cf4eece6d1c612af/680x482cq70/mexican-coffee-bun-ala-roti-boy-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cf4eece6d1c612af/680x482cq70/mexican-coffee-bun-ala-roti-boy-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cf4eece6d1c612af/680x482cq70/mexican-coffee-bun-ala-roti-boy-roti-o-foto-resep-utama.jpg
author: Julia Chavez
ratingvalue: 5
reviewcount: 12453
recipeingredient:
- "500 gr terigu proting"
- "26 gr susu bubuk"
- "1 butir telur  1 butir kuning telur"
- "8 sdm gula pasir bs dikurangi jika krg suka manis"
- "9 gr ragi instan aktifkan terlebih dahulu dgn sdkit susu"
- "250 ml susu cair jgn tuang semua"
- "50 gr butter margarin bs di mix butter dan margarin 11"
- "1/4 sdt garam"
- " Topping"
- "100 gr butter margarin bs dmix"
- "100 gr tepung terigu pro rendah tepung kunci biru"
- "4 sdm gula halus"
- "1 sdm peres 2 sdt kopi instan seduh dengan 2 sdm air panas"
- "1/2 sdt BPBaking powder opsional"
- "1 sdt Pasta Mocca opsional"
- " Filling Butter secukupx Keju secukupx"
recipeinstructions:
- "Buat roti, masukan semua bahan kecuali butter dan garam, tuangi susu sedikit demi sedikit smpe konsistensi adonan sesuai keinginan, adonan tdk lembek jg tdk terlalu keras..uleni hingga setengah kalis br masukan garam dan butter, uleni kembali hingga kalis elastis.."
- "Bagi adonan sesuai selera, sy timbang 30 gr, isi dengan filling lalu tutup rapat dan bulatkan susun di loyang yg sdh dilapisi lapisan carlo atw butter..tutup dgn serbet atw plastik kemudian istirahaykan adonan smpe mengembang 2 kali lipat sekitar 45 smpe 1 jam tergantung suhu pd saat itu"
- "Buat topping: mixer butter dan gula halus smpe tercampur rata lalu masukan tepung, BP, putih telur, butter, pasta mocca, dn coffee yg sdh dicairkan, mixer kembali smpe semua bnr² tercampur dgn rata, masukan keplastik pipping bag"
- "Setelah roti mengembang semprotkan topping di atasx dgn cara melingkar seperti obat nyamuk"
- "Panaskan oven di suhu 170°C..kemudian panggang selama 25 smpe 30 mnt sesuaikan oven masing²..setlah matang dinginkan br dimasukan ke dlm wadah..sy buatx 2 mcm yg satux red velvet"
- "NB: menurut pengalaman sy, topping x hrs bnr² rata d&#39;mixer krn klo tdk bnr² rata akan sulit lumer saat di oven hasilx pun tdk bs menutupi permukaan roti keseluruhan, permukaan roti terlihat pecah² toppingx. Penggunaan baking powder jg bs di skip Di topping sy menggunakan nescafe classic. Jika roti dingin dn tdk crunchy bs di oven lagi y bun dgn suhu rendah aj sekitar 110°C Semoga bermanfaat y bun🥰"
categories:
- Recipe
tags:
- mexican
- coffee
- bun

katakunci: mexican coffee bun 
nutrition: 154 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT41M"
recipeyield: "2"
recipecategory: Lunch

---


![Mexican Coffee Bun ala Roti Boy/ Roti O](https://img-global.cpcdn.com/recipes/cf4eece6d1c612af/680x482cq70/mexican-coffee-bun-ala-roti-boy-roti-o-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau enak. Karasteristik makanan Nusantara mexican coffee bun ala roti boy/ roti o yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kedekatan keluarga dapat diperoleh dengan cara mudah. Diantaranya adalah memasak Mexican Coffee Bun ala Roti Boy/ Roti O untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang bisa anda contoh salah satunya mexican coffee bun ala roti boy/ roti o yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep mexican coffee bun ala roti boy/ roti o tanpa harus bersusah payah.
Berikut ini resep Mexican Coffee Bun ala Roti Boy/ Roti O yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Mexican Coffee Bun ala Roti Boy/ Roti O:

1. Dibutuhkan 500 gr terigu proting
1. Jangan lupa 26 gr susu bubuk
1. Harus ada 1 butir telur + 1 butir kuning telur
1. Harap siapkan 8 sdm gula pasir (bs dikurangi jika krg suka manis)
1. Diperlukan 9 gr ragi instan (aktifkan terlebih dahulu dgn sdkit susu)
1. Dibutuhkan 250 ml susu cair (jgn tuang semua)
1. Dibutuhkan 50 gr butter/ margarin (bs di mix butter dan margarin 1:1)
1. Diperlukan 1/4 sdt garam
1. Diperlukan  Topping:
1. Dibutuhkan 100 gr butter/ margarin (bs d&#39;mix)
1. Tambah 100 gr tepung terigu pro rendah (tepung kunci biru)
1. Siapkan 4 sdm gula halus
1. Siapkan 1 sdm peres/ 2 sdt kopi instan (seduh dengan 2 sdm air panas)
1. Siapkan 1/2 sdt BP/Baking powder (opsional)
1. Jangan lupa 1 sdt Pasta Mocca (opsional)
1. Harap siapkan  Filling: Butter secukupx Keju secukupx




<!--inarticleads2-->

##### Bagaimana membuat  Mexican Coffee Bun ala Roti Boy/ Roti O:

1. Buat roti, masukan semua bahan kecuali butter dan garam, tuangi susu sedikit demi sedikit smpe konsistensi adonan sesuai keinginan, adonan tdk lembek jg tdk terlalu keras..uleni hingga setengah kalis br masukan garam dan butter, uleni kembali hingga kalis elastis..
1. Bagi adonan sesuai selera, sy timbang 30 gr, isi dengan filling lalu tutup rapat dan bulatkan susun di loyang yg sdh dilapisi lapisan carlo atw butter..tutup dgn serbet atw plastik kemudian istirahaykan adonan smpe mengembang 2 kali lipat sekitar 45 smpe 1 jam tergantung suhu pd saat itu
1. Buat topping: mixer butter dan gula halus smpe tercampur rata lalu masukan tepung, BP, putih telur, butter, pasta mocca, dn coffee yg sdh dicairkan, mixer kembali smpe semua bnr² tercampur dgn rata, masukan keplastik pipping bag
1. Setelah roti mengembang semprotkan topping di atasx dgn cara melingkar seperti obat nyamuk
1. Panaskan oven di suhu 170°C..kemudian panggang selama 25 smpe 30 mnt sesuaikan oven masing²..setlah matang dinginkan br dimasukan ke dlm wadah..sy buatx 2 mcm yg satux red velvet
1. NB: menurut pengalaman sy, topping x hrs bnr² rata d&#39;mixer krn klo tdk bnr² rata akan sulit lumer saat di oven hasilx pun tdk bs menutupi permukaan roti keseluruhan, permukaan roti terlihat pecah² toppingx. - Penggunaan baking powder jg bs di skip - Di topping sy menggunakan nescafe classic. - Jika roti dingin dn tdk crunchy bs di oven lagi y bun dgn suhu rendah aj sekitar 110°C - Semoga bermanfaat y bun🥰
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Mexican Coffee Bun ala Roti Boy/ Roti O"><img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Mexican Coffee Bun ala Roti Boy/ Roti O">



Demikianlah cara membuat mexican coffee bun ala roti boy/ roti o yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan teruji, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
