---
description: "Step-by-Step membuat Roti sisir mentega jadul tanpa ulen Cepat"
title: "Step-by-Step membuat Roti sisir mentega jadul tanpa ulen Cepat"
slug: 491-step-by-step-membuat-roti-sisir-mentega-jadul-tanpa-ulen-cepat
date: 2020-10-31T11:32:03.022Z
image: https://img-global.cpcdn.com/recipes/92dc5e2a88186d65/680x482cq70/roti-sisir-mentega-jadul-tanpa-ulen-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/92dc5e2a88186d65/680x482cq70/roti-sisir-mentega-jadul-tanpa-ulen-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/92dc5e2a88186d65/680x482cq70/roti-sisir-mentega-jadul-tanpa-ulen-foto-resep-utama.jpg
author: Winifred Walters
ratingvalue: 4.7
reviewcount: 28700
recipeingredient:
- "150 ml air hangat"
- "30 gram gula pasir"
- "1 sdt ragi instant4 gram"
- "200 gram terigu cakra"
- "25 gram terigu segitiga"
- "25 gram susu bubuk"
- "30 gram mentega"
- "2 gram garamsejumput"
- " Bahan filing mentega "
- "2 sdm margarin"
- "1 sdm gula pasirsy 2 sdm"
- "1 sdm susu cair"
- " Bahan olesan "
- "Secukupnya susu cair untuk olesan sebelum dioven"
- "Secukupnya margarin untuk olesan setelah dioven"
recipeinstructions:
- "Aduk rata gula air dan ragi, diamkan hingga berbuih. Tambahkan kedua tepung dan susu bubuk, aduk rata, masukkan margarin dan garam, uleni hingga kalis elastis. Diamkan hingga mengembang dua kali lipat. Resep aslinya adonan tanpa ulen ya, tp sy lebih suka yg diuleni.diamkan hingga mengembang."
- "Kempeskan adonan, timbang 25 gram lalu bulatkan, gilas memanjang lalu gulung dan padatkan. Siapkan loyang, oles margarin tipis, sy pakai loyang bronis 15 x10.tata adonan roti, sy isi 7 layer roti.sy bikin 2 resep. Hasilnya pas jadi 5 loyang.diamkan lagi hingga mengembang."
- "Ini sdh mengembang, tinggal panaskan oven dulu api sedang cenderung besar,oles dulu roti dgn susu cair, oven kue hingga matang. Buat adonan filingnya, aduk rata.selesai dioven,panas panas olesi roti dgn mentega. Biarkan hangat."
- "Buka lapisan roti, lihat seratnya.... Oles dgn bahan filing, sajikan. Sumpah meski tanpa telur, rotinya empuk banget."
categories:
- Recipe
tags:
- roti
- sisir
- mentega

katakunci: roti sisir mentega 
nutrition: 213 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dessert

---


![Roti sisir mentega jadul tanpa ulen](https://img-global.cpcdn.com/recipes/92dc5e2a88186d65/680x482cq70/roti-sisir-mentega-jadul-tanpa-ulen-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau empuk. Karasteristik makanan Indonesia roti sisir mentega jadul tanpa ulen yang kaya dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Roti sisir mentega jadul tanpa ulen untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang dapat anda praktekkan salah satunya roti sisir mentega jadul tanpa ulen yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep roti sisir mentega jadul tanpa ulen tanpa harus bersusah payah.
Seperti resep Roti sisir mentega jadul tanpa ulen yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti sisir mentega jadul tanpa ulen:

1. Dibutuhkan 150 ml air hangat
1. Diperlukan 30 gram gula pasir
1. Harus ada 1 sdt ragi instant(4 gram)
1. Harus ada 200 gram terigu cakra
1. Tambah 25 gram terigu segitiga
1. Siapkan 25 gram susu bubuk
1. Tambah 30 gram mentega
1. Dibutuhkan 2 gram garam(sejumput)
1. Harus ada  Bahan filing mentega :
1. Harap siapkan 2 sdm margarin
1. Harap siapkan 1 sdm gula pasir(sy 2 sdm)
1. Harap siapkan 1 sdm susu cair
1. Tambah  Bahan olesan :
1. Harus ada Secukupnya susu cair untuk olesan sebelum dioven
1. Siapkan Secukupnya margarin untuk olesan setelah dioven




<!--inarticleads2-->

##### Instruksi membuat  Roti sisir mentega jadul tanpa ulen:

1. Aduk rata gula air dan ragi, diamkan hingga berbuih. Tambahkan kedua tepung dan susu bubuk, aduk rata, masukkan margarin dan garam, uleni hingga kalis elastis. Diamkan hingga mengembang dua kali lipat. Resep aslinya adonan tanpa ulen ya, tp sy lebih suka yg diuleni.diamkan hingga mengembang.
1. Kempeskan adonan, timbang 25 gram lalu bulatkan, gilas memanjang lalu gulung dan padatkan. Siapkan loyang, oles margarin tipis, sy pakai loyang bronis 15 x10.tata adonan roti, sy isi 7 layer roti.sy bikin 2 resep. Hasilnya pas jadi 5 loyang.diamkan lagi hingga mengembang.
1. Ini sdh mengembang, tinggal panaskan oven dulu api sedang cenderung besar,oles dulu roti dgn susu cair, oven kue hingga matang. Buat adonan filingnya, aduk rata.selesai dioven,panas panas olesi roti dgn mentega. Biarkan hangat.
1. Buka lapisan roti, lihat seratnya.... Oles dgn bahan filing, sajikan. Sumpah meski tanpa telur, rotinya empuk banget.




Demikianlah cara membuat roti sisir mentega jadul tanpa ulen yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
