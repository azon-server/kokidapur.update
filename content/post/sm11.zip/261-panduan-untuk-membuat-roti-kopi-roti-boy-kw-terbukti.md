---
description: "Panduan untuk membuat Roti Kopi / Roti Boy KW Terbukti"
title: "Panduan untuk membuat Roti Kopi / Roti Boy KW Terbukti"
slug: 261-panduan-untuk-membuat-roti-kopi-roti-boy-kw-terbukti
date: 2020-09-10T12:37:41.705Z
image: https://img-global.cpcdn.com/recipes/9102c646fcb6cf1b/680x482cq70/roti-kopi-roti-boy-kw-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9102c646fcb6cf1b/680x482cq70/roti-kopi-roti-boy-kw-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9102c646fcb6cf1b/680x482cq70/roti-kopi-roti-boy-kw-foto-resep-utama.jpg
author: Ola Hammond
ratingvalue: 4
reviewcount: 7883
recipeingredient:
- " Bahan roti"
- "200 gr tepung proting me tepung cakra"
- "60 gr tepung pro sedang me segitiga biru"
- "1 sdt ragisaf instan"
- "1 sdm susu bubuk"
- "50 gr gula pasir me gula halus"
- "1 butir kuning telur di campur susu uht 185ml"
- "30 gr margarin resep asli butter"
- " Bahan Isi"
- "30 gr margarine resep asli butter"
- "25 gr keju parut"
- "2 sdm gula halus"
- " Bahan toping kopi"
- "1 butir putih telur"
- "50 gr margarin"
- "3 sdm gula halus"
- "50 gr tepung terigu me segitiga"
- "1/4 sdt baking pawder"
- "1 bungkus kopi instan seduh dg 1 sdm air panas"
- "1/4 sdt pasta mocca optional"
recipeinstructions:
- "Campur semua bahan roti kecuali telur&amp;susu, margarine+garam. Mix hingga rata. Jika sudah rata sambil di tuangi susu yg sudah di campur telur tadi sedikit sedikit. Uleni hingga setengah kalis. Lalu masukan margarin dan garam uleni hingga kalis. (aku pakai bantuan mixer sambil di uleni pakai tangan)😄"
- "Bagi adonan menjadi bulatan kecil2. Aku pakai timbangan ku bagi 50 gr an/bulatan. Diamkan kurleb 10 menit."
- "Untuk bikin bahan isi masukan semua bahan isi aduk2 sampai rata."
- "Gilas bulatan beri isian, lalu bulatkan lagi taruh di loyan yg sudah di alasi kertas roti dan margarine. Tutup dg plastik wrap/lap bersih hingga mengembang (kurleb 30-45 menit)"
- "Untuk bahan topping. Kocok putih telur hingga kaku. Di wadah lain campur margarin dan gula mixer hingga rata. Lalu masukan tepung, BP, putih telur dan seduhan kopi. Campur dg spatula hingga rata. Lalu masukan kedalam piping bag."
- "Ulenan roti yg sudah mengembang bisa di beri topping kopi di atasnya. Bentuk seperti bentuk obat nyamuk. Lalu oven 30 menit atau hingga matang dg suhu 180°. (kenali oven masing2, karna aku oven pakai suhu segitu atasnya agak gosong..😅 jadi aku turunin panasnya kurleb 160° pakai api atas bawah)"
- "Di nikmati sama teh hangat mantep..😘👍"
categories:
- Recipe
tags:
- roti
- kopi
- 

katakunci: roti kopi  
nutrition: 154 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Dessert

---


![Roti Kopi / Roti Boy KW](https://img-global.cpcdn.com/recipes/9102c646fcb6cf1b/680x482cq70/roti-kopi-roti-boy-kw-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga empuk. Ciri makanan Nusantara roti kopi / roti boy kw yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Roti Kopi / Roti Boy KW untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang bisa anda contoh salah satunya roti kopi / roti boy kw yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep roti kopi / roti boy kw tanpa harus bersusah payah.
Berikut ini resep Roti Kopi / Roti Boy KW yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 20 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Kopi / Roti Boy KW:

1. Tambah  Bahan roti
1. Jangan lupa 200 gr tepung proting (me: tepung cakra)
1. Siapkan 60 gr tepung pro sedang (me: segitiga biru)
1. Jangan lupa 1 sdt ragi/saf instan
1. Jangan lupa 1 sdm susu bubuk
1. Jangan lupa 50 gr gula pasir (me gula halus)
1. Dibutuhkan 1 butir kuning telur di campur susu uht 185ml
1. Harus ada 30 gr margarin (resep asli butter)
1. Harus ada  Bahan Isi
1. Tambah 30 gr margarine (resep asli butter)
1. Harus ada 25 gr keju parut
1. Harus ada 2 sdm gula halus
1. Harus ada  Bahan toping kopi
1. Harus ada 1 butir putih telur
1. Jangan lupa 50 gr margarin
1. Siapkan 3 sdm gula halus
1. Tambah 50 gr tepung terigu (me: segitiga)
1. Harap siapkan 1/4 sdt baking pawder
1. Tambah 1 bungkus kopi instan (seduh dg 1 sdm air panas)
1. Dibutuhkan 1/4 sdt pasta mocca (optional)




<!--inarticleads2-->

##### Instruksi membuat  Roti Kopi / Roti Boy KW:

1. Campur semua bahan roti kecuali telur&amp;susu, margarine+garam. Mix hingga rata. Jika sudah rata sambil di tuangi susu yg sudah di campur telur tadi sedikit sedikit. Uleni hingga setengah kalis. Lalu masukan margarin dan garam uleni hingga kalis. (aku pakai bantuan mixer sambil di uleni pakai tangan)😄
1. Bagi adonan menjadi bulatan kecil2. Aku pakai timbangan ku bagi 50 gr an/bulatan. Diamkan kurleb 10 menit.
1. Untuk bikin bahan isi masukan semua bahan isi aduk2 sampai rata.
1. Gilas bulatan beri isian, lalu bulatkan lagi taruh di loyan yg sudah di alasi kertas roti dan margarine. Tutup dg plastik wrap/lap bersih hingga mengembang (kurleb 30-45 menit)
1. Untuk bahan topping. Kocok putih telur hingga kaku. Di wadah lain campur margarin dan gula mixer hingga rata. Lalu masukan tepung, BP, putih telur dan seduhan kopi. Campur dg spatula hingga rata. Lalu masukan kedalam piping bag.
1. Ulenan roti yg sudah mengembang bisa di beri topping kopi di atasnya. Bentuk seperti bentuk obat nyamuk. Lalu oven 30 menit atau hingga matang dg suhu 180°. (kenali oven masing2, karna aku oven pakai suhu segitu atasnya agak gosong..😅 jadi aku turunin panasnya kurleb 160° pakai api atas bawah)
1. Di nikmati sama teh hangat mantep..😘👍




Demikianlah cara membuat roti kopi / roti boy kw yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
