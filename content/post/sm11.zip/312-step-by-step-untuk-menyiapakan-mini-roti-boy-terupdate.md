---
description: "Step-by-Step untuk menyiapakan Mini roti boy terupdate"
title: "Step-by-Step untuk menyiapakan Mini roti boy terupdate"
slug: 312-step-by-step-untuk-menyiapakan-mini-roti-boy-terupdate
date: 2021-02-04T21:31:51.784Z
image: https://img-global.cpcdn.com/recipes/6b706d39028e1eea/680x482cq70/mini-roti-boy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6b706d39028e1eea/680x482cq70/mini-roti-boy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6b706d39028e1eea/680x482cq70/mini-roti-boy-foto-resep-utama.jpg
author: Curtis Holmes
ratingvalue: 4.5
reviewcount: 26150
recipeingredient:
- "200 gr terigu cakra"
- "170 gr terigu segitiga biru"
- "2 sdt ragi instan"
- "4 sdm gula pasir"
- "240 ml susu cair"
- "30 gr margarin"
- "1/4 sdt garam"
- " bahan isian "
- " sucukupnya keju quick melt parut"
- " topping "
- "50 gr margarin"
- "50 gr gula halus"
- "1 butir putih telur"
- "70 gr tepung segitiga biru"
- "1 sachet white coffe larutkan dengan 1 sdm air panas"
recipeinstructions:
- "Campur tepung cakra, tepung segitiga, ragi, dan gula pasir. Aduk rata. Buat lubang di tengahnya. Masukkan susu cair. Uleni hingga setengah kalis. Tambahkan margarin dan garam. Uleni lagi hingga kalis. Bentuk bulat. Taruh di wadah yg sudah di olesi minyak tipis2. Tutup dengan serbet. Diamkan hingga mengembang 2x.."
- "Buat topping : mixer margarin dan gula halus sampai lembut. Masukkan putih telur. Mixer lagi hingga lembut. Masukkan larutan kopi dan tepung sambil di ayak. Mixer asal rata. Masukkan ke plastik segitiga.."
- "Setelah adonan mengembang kempiskan. Uleni sebentar. Bagi adonan sesuai selera. Beri isian. Bulatkan lg. Tata di loyang yg telah di oles margarin. Tunggu hingga mengembang lg. Beri topping. Panggang suhu 180°c selama 30-40 menit/sesuai oven masing2.."
- "Wuih..keju nya melted..😋"
categories:
- Recipe
tags:
- mini
- roti
- boy

katakunci: mini roti boy 
nutrition: 245 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT60M"
recipeyield: "2"
recipecategory: Dinner

---


![Mini roti boy](https://img-global.cpcdn.com/recipes/6b706d39028e1eea/680x482cq70/mini-roti-boy-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga renyah. Ciri makanan Nusantara mini roti boy yang penuh dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Mini roti boy untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang bisa anda coba salah satunya mini roti boy yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep mini roti boy tanpa harus bersusah payah.
Berikut ini resep Mini roti boy yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mini roti boy:

1. Diperlukan 200 gr terigu cakra
1. Dibutuhkan 170 gr terigu segitiga biru
1. Siapkan 2 sdt ragi instan
1. Harus ada 4 sdm gula pasir
1. Harus ada 240 ml susu cair
1. Tambah 30 gr margarin
1. Siapkan 1/4 sdt garam
1. Dibutuhkan  bahan isian :
1. Harap siapkan  sucukupnya keju quick melt parut
1. Jangan lupa  topping :
1. Harap siapkan 50 gr margarin
1. Harus ada 50 gr gula halus
1. Harus ada 1 butir putih telur
1. Dibutuhkan 70 gr tepung segitiga biru
1. Dibutuhkan 1 sachet white coffe (larutkan dengan 1 sdm air panas)




<!--inarticleads2-->

##### Bagaimana membuat  Mini roti boy:

1. Campur tepung cakra, tepung segitiga, ragi, dan gula pasir. Aduk rata. Buat lubang di tengahnya. Masukkan susu cair. Uleni hingga setengah kalis. Tambahkan margarin dan garam. Uleni lagi hingga kalis. Bentuk bulat. Taruh di wadah yg sudah di olesi minyak tipis2. Tutup dengan serbet. Diamkan hingga mengembang 2x..
1. Buat topping : mixer margarin dan gula halus sampai lembut. Masukkan putih telur. Mixer lagi hingga lembut. Masukkan larutan kopi dan tepung sambil di ayak. Mixer asal rata. Masukkan ke plastik segitiga..
1. Setelah adonan mengembang kempiskan. Uleni sebentar. Bagi adonan sesuai selera. Beri isian. Bulatkan lg. Tata di loyang yg telah di oles margarin. Tunggu hingga mengembang lg. Beri topping. Panggang suhu 180°c selama 30-40 menit/sesuai oven masing2..
1. Wuih..keju nya melted..😋




Demikianlah cara membuat mini roti boy yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
