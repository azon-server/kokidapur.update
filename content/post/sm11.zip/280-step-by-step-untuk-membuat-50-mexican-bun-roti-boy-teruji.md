---
description: "Step-by-Step untuk membuat 50* Mexican Bun / Roti Boy Teruji"
title: "Step-by-Step untuk membuat 50* Mexican Bun / Roti Boy Teruji"
slug: 280-step-by-step-untuk-membuat-50-mexican-bun-roti-boy-teruji
date: 2021-01-28T18:25:20.452Z
image: https://img-global.cpcdn.com/recipes/e18c9d730c92ae6f/680x482cq70/50-mexican-bun-roti-boy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e18c9d730c92ae6f/680x482cq70/50-mexican-bun-roti-boy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e18c9d730c92ae6f/680x482cq70/50-mexican-bun-roti-boy-foto-resep-utama.jpg
author: Vernon Fleming
ratingvalue: 4.8
reviewcount: 31071
recipeingredient:
- " Dough "
- "200 gr tepung pro tinggi"
- "60 gr tepung pro sedang"
- "50 gr gula pasir"
- "30 gr butter  margarin"
- "1 sdm susu bubuk"
- "1 sdt ragi instant"
- "1 butir kuning telur  susu uht total 180 ml"
- " Filling "
- "35 gr butter  margarin"
- "35 gr keju parut"
- "2 1/2 sdm gula halus"
- " Topping "
- "50 gr butter  margarin"
- "50 gr tepung pro sedang"
- "2 sdm munjung gula halus"
- "1 butir putih telur"
- "1 sdt kopi instan seduh dgn 1 sdm air panas sy nescafe classic"
- "1/4 sdt Baking Powder"
- "Secukupnya mocca pasta"
recipeinstructions:
- "Langkah pertama Membuat Filling :  Campur semua bahan hingga rata, sisihkan"
- "Langkah kedua Membuat Topping :  Mix putih telur sampai kaku, sisihkan. Di wadah terpisah, mix butter &amp; gula halus sampai lembut, lalu tambahkan terigu + BP (sambil di ayak) + adonan putih telur + seduhan kopi instan + mocca pasta, aduk rata semuanya, lalu masukkan ke plastik segitiga. Simpan dlm lemari es"
- "Langah ketiga membuat dough :  Campur semua bahan kering menggunakan tangan, tuang cairan susu &amp; telur sedikit² (jgn di tuang habis ya momzz, lihat kondisi adonan) uleni sampai setengah kalis. Setelah setengah kalis, masukkan butter/margarin + garam, mix sampai kalis elastis dgn menggunakan hand mixer (± 15 menit)"
- "Pindahkan ke silmat, bagi beberapa bagian @35 gr, bulatkan, ambil satu adonan, gilas lalu beri bahan filling, bulatkan lagi"
- "Tata dalam loyang yang sudah di oles margarin, beri jarak antara satu dan lainnya agar gak dempet saat di oven. Tutup kain bersih, diamkan ± 45 menit atau sampai mengembang 2x lipatnya"
- "Jika sudah mengembang, beri topping secara melingkar seperti obat nyamuk. Saat memberi topping yg rapat ya momzz, usahakan jgn ada yg renggang, sebab pada saat matang nanti ada bagian yg tidak tertutup sempurna dan itu mengurangi penampilan si Boy itu sendiri 😁✌️"
- "Panggang dlm oven suhu 175°C selama 20 - 25 menit atau sesuaikan oven masing²"
- "Angkat  Biarkan dingin  Foto Part I"
- "Foto Part 2"
categories:
- Recipe
tags:
- 50
- mexican
- bun

katakunci: 50 mexican bun 
nutrition: 170 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Lunch

---


![50* Mexican Bun / Roti Boy](https://img-global.cpcdn.com/recipes/e18c9d730c92ae6f/680x482cq70/50-mexican-bun-roti-boy-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita jaga karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti 50* mexican bun / roti boy yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa ciri khas yang merupakan keragaman Indonesia

Keharmonisan keluarga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan 50* Mexican Bun / Roti Boy untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang bisa anda contoh salah satunya 50* mexican bun / roti boy yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep 50* mexican bun / roti boy tanpa harus bersusah payah.
Berikut ini resep 50* Mexican Bun / Roti Boy yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat 50* Mexican Bun / Roti Boy:

1. Siapkan  Dough :
1. Diperlukan 200 gr tepung pro tinggi
1. Dibutuhkan 60 gr tepung pro sedang
1. Tambah 50 gr gula pasir
1. Tambah 30 gr butter / margarin
1. Harus ada 1 sdm susu bubuk
1. Diperlukan 1 sdt ragi instant
1. Jangan lupa 1 butir kuning telur + susu uht total 180 ml
1. Diperlukan  Filling :
1. Harap siapkan 35 gr butter / margarin
1. Dibutuhkan 35 gr keju parut
1. Jangan lupa 2 1/2 sdm gula halus
1. Diperlukan  Topping :
1. Jangan lupa 50 gr butter / margarin
1. Harus ada 50 gr tepung pro sedang
1. Harus ada 2 sdm munjung gula halus
1. Harap siapkan 1 butir putih telur
1. Jangan lupa 1 sdt kopi instan seduh dgn 1 sdm air panas (sy nescafe classic)
1. Harap siapkan 1/4 sdt Baking Powder
1. Siapkan Secukupnya mocca pasta




<!--inarticleads2-->

##### Instruksi membuat  50* Mexican Bun / Roti Boy:

1. Langkah pertama Membuat Filling : -  - Campur semua bahan hingga rata, sisihkan
1. Langkah kedua Membuat Topping : -  - Mix putih telur sampai kaku, sisihkan. - Di wadah terpisah, mix butter &amp; gula halus sampai lembut, lalu tambahkan terigu + BP (sambil di ayak) + adonan putih telur + seduhan kopi instan + mocca pasta, aduk rata semuanya, lalu masukkan ke plastik segitiga. Simpan dlm lemari es
1. Langah ketiga membuat dough : -  - Campur semua bahan kering menggunakan tangan, tuang cairan susu &amp; telur sedikit² (jgn di tuang habis ya momzz, lihat kondisi adonan) uleni sampai setengah kalis. Setelah setengah kalis, masukkan butter/margarin + garam, mix sampai kalis elastis dgn menggunakan hand mixer (± 15 menit)
1. Pindahkan ke silmat, bagi beberapa bagian @35 gr, bulatkan, ambil satu adonan, gilas lalu beri bahan filling, bulatkan lagi
1. Tata dalam loyang yang sudah di oles margarin, beri jarak antara satu dan lainnya agar gak dempet saat di oven. Tutup kain bersih, diamkan ± 45 menit atau sampai mengembang 2x lipatnya
1. Jika sudah mengembang, beri topping secara melingkar seperti obat nyamuk. Saat memberi topping yg rapat ya momzz, usahakan jgn ada yg renggang, sebab pada saat matang nanti ada bagian yg tidak tertutup sempurna dan itu mengurangi penampilan si Boy itu sendiri 😁✌️
1. Panggang dlm oven suhu 175°C selama 20 - 25 menit atau sesuaikan oven masing²
1. Angkat -  - Biarkan dingin -  - Foto Part I
1. Foto Part 2




Demikianlah cara membuat 50* mexican bun / roti boy yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan cepat, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
