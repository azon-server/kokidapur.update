---
description: "Resep : Roti Kopi Isi Campur (Roti O kw/Mexican Bun) Teruji"
title: "Resep : Roti Kopi Isi Campur (Roti O kw/Mexican Bun) Teruji"
slug: 244-resep-roti-kopi-isi-campur-roti-o-kw-mexican-bun-teruji
date: 2021-01-28T13:28:21.506Z
image: https://img-global.cpcdn.com/recipes/c816c5ff3101fe5a/680x482cq70/roti-kopi-isi-campur-roti-o-kwmexican-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c816c5ff3101fe5a/680x482cq70/roti-kopi-isi-campur-roti-o-kwmexican-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c816c5ff3101fe5a/680x482cq70/roti-kopi-isi-campur-roti-o-kwmexican-bun-foto-resep-utama.jpg
author: Essie Beck
ratingvalue: 4.1
reviewcount: 37467
recipeingredient:
- " Bahan roti"
- "250 gr tepung terigu protein tinggi"
- "100 ml susu cair me 6sdt SKMair hangat"
- "1 sdt ragi instan"
- "40 gr Margarin"
- "50 gr Gula pasir"
- "25 gr Susu bubuk"
- "Sejumput garam"
- "1 butir telur"
- " Bahan isian"
- "50 gr Margarin"
- "25 gr Keju parut"
- "2 sdm SKM"
- " Bahan topping"
- "1 sachet kopi instan"
- "2 sdm air panas"
- "1 butir telur"
- "40 gr margarin"
- "35 gr tepung terigu protein rendah"
- "40 gr sdm Gula halus"
recipeinstructions:
- "Siapkan semua bahan roti, isian dan toping."
- "Buat biang dulu. Campurkan 30 ml susu cair, ragi dan 1 sdm gula pasir. Diamkan selama 10 menit."
- "Untuk roti. Campurkan tepung terigu, gula, telur, garam, mixer sebentar. kemudian bahan biang ke dalam adonan dan tetap mixer dengan speed 2."
- "Setelah itu masukkan sisa susu (50ml), mixer lagi. Kemudian tambahkan margarin dan mixer sampai kalis. (Masih dengan speed 2)."
- "Uleni sebentar dengan tangan, kemudian diamkan adonan selama 30 menit atau sampai mengembang.. setelah mengembang kempiskan adonan dan bagi rata. Ini aku bagi 10 masing-masing 50 gr"
- "Campurkan bahan isian. Parut keju dan campurkan dengan margarin dan SKM. Aduk rata. Kemudian isi tiap bulatan dengan 1 sdt isian."
- "Kemudian bulatkan adonan dan tata dalam loyang yang sudah diolesi Carlo/margarin diamkan sampai mengembang, sekitar 30 menit."
- "Buat toping. Larutkan kopi instan dengan air panas. Kemudian campurkan tepung terigu dan telur (kocok lepas), aduk hingga tidak bergerindil."
- "Setelah itu, masukkan margarin aduk rata. Dan tambahkan gula halus, aduk rata kembali."
- "Kemudian masukkan larutan kopi. Aduk rata hingga semua tercampur rata. Kemudian masukkan ke dalam piping bag. (Abis dicampur biasa pake sendok, aku mixer sebentar sekitar 2 menit pake speed rendah, biar semua kecampur dan ga ada yg bergerindil)"
- "Panaskan oven. Oleskan/tuang memutar toping perlahan ke adonan roti yg sudah mengembang. Setelah itu panggang dalam oven sekitar 20 menit. Tes tusuk untuk melihat kematangan roti. Setelah roti matang sisihkan agar uap panasnya hilang."
- "Bisa langsung disajikan atau disimpan dalam box container / masukkan plastik."
categories:
- Recipe
tags:
- roti
- kopi
- isi

katakunci: roti kopi isi 
nutrition: 258 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT50M"
recipeyield: "1"
recipecategory: Dessert

---


![Roti Kopi Isi Campur (Roti O kw/Mexican Bun)](https://img-global.cpcdn.com/recipes/c816c5ff3101fe5a/680x482cq70/roti-kopi-isi-campur-roti-o-kwmexican-bun-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas atau renyah. Karasteristik masakan Nusantara roti kopi isi campur (roti o kw/mexican bun) yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Roti Kopi Isi Campur (Roti O kw/Mexican Bun) untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang dapat anda coba salah satunya roti kopi isi campur (roti o kw/mexican bun) yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep roti kopi isi campur (roti o kw/mexican bun) tanpa harus bersusah payah.
Berikut ini resep Roti Kopi Isi Campur (Roti O kw/Mexican Bun) yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 20 bahan dan 12 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Kopi Isi Campur (Roti O kw/Mexican Bun):

1. Siapkan  Bahan roti
1. Harap siapkan 250 gr tepung terigu protein tinggi
1. Siapkan 100 ml susu cair (me: 6sdt SKM+air hangat)
1. Harap siapkan 1 sdt ragi instan
1. Jangan lupa 40 gr Margarin
1. Dibutuhkan 50 gr Gula pasir
1. Diperlukan 25 gr Susu bubuk
1. Dibutuhkan Sejumput garam
1. Harus ada 1 butir telur
1. Dibutuhkan  Bahan isian
1. Dibutuhkan 50 gr Margarin
1. Harap siapkan 25 gr Keju parut
1. Jangan lupa 2 sdm SKM
1. Jangan lupa  Bahan topping
1. Diperlukan 1 sachet kopi instan
1. Jangan lupa 2 sdm air panas
1. Diperlukan 1 butir telur
1. Dibutuhkan 40 gr margarin
1. Harus ada 35 gr tepung terigu protein rendah
1. Jangan lupa 40 gr sdm Gula halus




<!--inarticleads2-->

##### Langkah membuat  Roti Kopi Isi Campur (Roti O kw/Mexican Bun):

1. Siapkan semua bahan roti, isian dan toping.
1. Buat biang dulu. Campurkan 30 ml susu cair, ragi dan 1 sdm gula pasir. Diamkan selama 10 menit.
1. Untuk roti. Campurkan tepung terigu, gula, telur, garam, mixer sebentar. kemudian bahan biang ke dalam adonan dan tetap mixer dengan speed 2.
1. Setelah itu masukkan sisa susu (50ml), mixer lagi. Kemudian tambahkan margarin dan mixer sampai kalis. (Masih dengan speed 2).
1. Uleni sebentar dengan tangan, kemudian diamkan adonan selama 30 menit atau sampai mengembang.. setelah mengembang kempiskan adonan dan bagi rata. Ini aku bagi 10 masing-masing 50 gr
1. Campurkan bahan isian. Parut keju dan campurkan dengan margarin dan SKM. Aduk rata. Kemudian isi tiap bulatan dengan 1 sdt isian.
1. Kemudian bulatkan adonan dan tata dalam loyang yang sudah diolesi Carlo/margarin diamkan sampai mengembang, sekitar 30 menit.
1. Buat toping. Larutkan kopi instan dengan air panas. Kemudian campurkan tepung terigu dan telur (kocok lepas), aduk hingga tidak bergerindil.
1. Setelah itu, masukkan margarin aduk rata. Dan tambahkan gula halus, aduk rata kembali.
1. Kemudian masukkan larutan kopi. Aduk rata hingga semua tercampur rata. Kemudian masukkan ke dalam piping bag. (Abis dicampur biasa pake sendok, aku mixer sebentar sekitar 2 menit pake speed rendah, biar semua kecampur dan ga ada yg bergerindil)
1. Panaskan oven. Oleskan/tuang memutar toping perlahan ke adonan roti yg sudah mengembang. Setelah itu panggang dalam oven sekitar 20 menit. Tes tusuk untuk melihat kematangan roti. Setelah roti matang sisihkan agar uap panasnya hilang.
1. Bisa langsung disajikan atau disimpan dalam box container / masukkan plastik.




Demikianlah cara membuat roti kopi isi campur (roti o kw/mexican bun) yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan teruji, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
