---
description: "Steps membuat Mexican Coffee Bun/Roti Boy/Roti O&amp;#39; Homemade"
title: "Steps membuat Mexican Coffee Bun/Roti Boy/Roti O&amp;#39; Homemade"
slug: 377-steps-membuat-mexican-coffee-bun-roti-boy-roti-o-and-39-homemade
date: 2020-11-24T05:57:37.114Z
image: https://img-global.cpcdn.com/recipes/5d5c4f5c6e417bf0/680x482cq70/mexican-coffee-bunroti-boyroti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5d5c4f5c6e417bf0/680x482cq70/mexican-coffee-bunroti-boyroti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5d5c4f5c6e417bf0/680x482cq70/mexican-coffee-bunroti-boyroti-o-foto-resep-utama.jpg
author: Minerva Padilla
ratingvalue: 4.3
reviewcount: 49161
recipeingredient:
- " Bahan Roti"
- "200 gram tepung terigu protein tinggi"
- "60 gram tepung terigu protein sedang"
- "50 gram gula pasir"
- "2 sdt ragi instan"
- "1 sdm susu bubuk full cream"
- "1 butir kuning telursusu cair full cream totalnya 180 ml"
- "30 gram margarin"
- "Sejumput garam"
- " Bahan Isian"
- "50 gram margarin butter saya pakai blueband cake and cookies"
- "3 sdm gula halus"
- "30 gram keju cheddar parut"
- " Bahan Topping"
- "1 butir putih telur"
- "50 gram margarin"
- "50 gram tepung terigu"
- "2 sdm munjung gula halus"
- "1/4 sdt baking powder"
- "1 sdt kopi bubuk larutkan dengan 1 sdm air panas"
- "Secukupnya pasta moka"
recipeinstructions:
- "🥯 Cara membuat roti : Campurkan dalam wadah tepung terigu, gula pasir, ragi instan dan susu bubuk. Aduk rata, lalu masukkan campuran kuning telur+susu cair sedikit demi sedikit. Uleni/mixer hingga setengah kalis."
- "Masukkan margarin dan garam lalu uleni/mixer kembali hingga kalis elastis. Bulatkan adonan."
- "Bagi adonan menjadi 11 @50 gram, bulatkan lalu diamkan selama 10 menit."
- "🍯 Cara membuat isian : campurkan semua bahan menjadi satu hingga rata."
- "🥯🍯 Pipihkan adonan menggunakan rolling pin, beri isian sekitar 1 1/2 sdt. Cubit-cubit hingga rapat dan bulatkan. Letakkan adonan yang sudah diisi ini diatas loyang yang diolesi carlo terlebih dahulu. Lakukan hingga adonan habis. Tutup dengan kain bersih dan diamkan hingga mengembang 2x lipat."
- "🍫 Cara membuat topping : mixer putih telur hingga kaku lalu sisihkan. Di wadah lain, mixer margarin dan gula halus hingga lembut dan tercampur rata. Masukkan baking powder, putih telur, tepung terigu, pasta moka dan larutan kopi (jika menggunakan kopi bubuk biasa saring terlebih dahulu). Mixer hingga rata lalu masukkan dalam piping bag."
- "🥯🍯🍫 Beri toping diatas adonan roti dengan membentuk spiral melingkar. Punya saya ga rapi ya jangan ditiru hihi usahakan ga ada celah sedikitpun biar ga bolong-bolong nantinya."
- "⏳ Panaskan panggangan terlebih dahulu, saya pakai oven tangkring. Panaskan dengan api sedang cenderung besar selama 7-10 menit. Masukkan loyang di rak tengah, panggang selama 30 menit atau hingga matang sesuai oven masing-masing."
categories:
- Recipe
tags:
- mexican
- coffee
- bunroti

katakunci: mexican coffee bunroti 
nutrition: 198 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Dinner

---


![Mexican Coffee Bun/Roti Boy/Roti O&#39;](https://img-global.cpcdn.com/recipes/5d5c4f5c6e417bf0/680x482cq70/mexican-coffee-bunroti-boyroti-o-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang patut kita lestarikan karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti mexican coffee bun/roti boy/roti o&#39; yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa ciri khas yang merupakan keragaman Kita

Keharmonisan rumah tangga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Mexican Coffee Bun/Roti Boy/Roti O&#39; untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang dapat anda buat salah satunya mexican coffee bun/roti boy/roti o&#39; yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep mexican coffee bun/roti boy/roti o&#39; tanpa harus bersusah payah.
Seperti resep Mexican Coffee Bun/Roti Boy/Roti O&#39; yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Mexican Coffee Bun/Roti Boy/Roti O&#39;:

1. Jangan lupa  Bahan Roti
1. Harus ada 200 gram tepung terigu protein tinggi
1. Diperlukan 60 gram tepung terigu protein sedang
1. Siapkan 50 gram gula pasir
1. Harap siapkan 2 sdt ragi instan
1. Diperlukan 1 sdm susu bubuk full cream
1. Dibutuhkan 1 butir kuning telur+susu cair full cream totalnya 180 ml
1. Tambah 30 gram margarin
1. Jangan lupa Sejumput garam
1. Diperlukan  Bahan Isian
1. Tambah 50 gram margarin butter (saya pakai blueband cake and cookies)
1. Tambah 3 sdm gula halus
1. Dibutuhkan 30 gram keju cheddar parut
1. Tambah  Bahan Topping
1. Siapkan 1 butir putih telur
1. Diperlukan 50 gram margarin
1. Dibutuhkan 50 gram tepung terigu
1. Tambah 2 sdm munjung gula halus
1. Jangan lupa 1/4 sdt baking powder
1. Harap siapkan 1 sdt kopi bubuk larutkan dengan 1 sdm air panas
1. Harus ada Secukupnya pasta moka




<!--inarticleads2-->

##### Instruksi membuat  Mexican Coffee Bun/Roti Boy/Roti O&#39;:

1. 🥯 Cara membuat roti : Campurkan dalam wadah tepung terigu, gula pasir, ragi instan dan susu bubuk. Aduk rata, lalu masukkan campuran kuning telur+susu cair sedikit demi sedikit. Uleni/mixer hingga setengah kalis.
1. Masukkan margarin dan garam lalu uleni/mixer kembali hingga kalis elastis. Bulatkan adonan.
1. Bagi adonan menjadi 11 @50 gram, bulatkan lalu diamkan selama 10 menit.
1. 🍯 Cara membuat isian : campurkan semua bahan menjadi satu hingga rata.
1. 🥯🍯 Pipihkan adonan menggunakan rolling pin, beri isian sekitar 1 1/2 sdt. Cubit-cubit hingga rapat dan bulatkan. Letakkan adonan yang sudah diisi ini diatas loyang yang diolesi carlo terlebih dahulu. Lakukan hingga adonan habis. Tutup dengan kain bersih dan diamkan hingga mengembang 2x lipat.
1. 🍫 Cara membuat topping : mixer putih telur hingga kaku lalu sisihkan. Di wadah lain, mixer margarin dan gula halus hingga lembut dan tercampur rata. Masukkan baking powder, putih telur, tepung terigu, pasta moka dan larutan kopi (jika menggunakan kopi bubuk biasa saring terlebih dahulu). Mixer hingga rata lalu masukkan dalam piping bag.
1. 🥯🍯🍫 Beri toping diatas adonan roti dengan membentuk spiral melingkar. Punya saya ga rapi ya jangan ditiru hihi usahakan ga ada celah sedikitpun biar ga bolong-bolong nantinya.
1. ⏳ Panaskan panggangan terlebih dahulu, saya pakai oven tangkring. Panaskan dengan api sedang cenderung besar selama 7-10 menit. Masukkan loyang di rak tengah, panggang selama 30 menit atau hingga matang sesuai oven masing-masing.




Demikianlah cara membuat mexican coffee bun/roti boy/roti o&#39; yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
