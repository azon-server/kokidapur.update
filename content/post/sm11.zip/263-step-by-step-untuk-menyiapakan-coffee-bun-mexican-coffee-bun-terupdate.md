---
description: "Step-by-Step untuk menyiapakan Coffee Bun (Mexican Coffee Bun) terupdate"
title: "Step-by-Step untuk menyiapakan Coffee Bun (Mexican Coffee Bun) terupdate"
slug: 263-step-by-step-untuk-menyiapakan-coffee-bun-mexican-coffee-bun-terupdate
date: 2020-10-30T13:57:06.107Z
image: https://img-global.cpcdn.com/recipes/8221777394656c22/680x482cq70/coffee-bun-mexican-coffee-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8221777394656c22/680x482cq70/coffee-bun-mexican-coffee-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8221777394656c22/680x482cq70/coffee-bun-mexican-coffee-bun-foto-resep-utama.jpg
author: Gussie Hanson
ratingvalue: 4.6
reviewcount: 29864
recipeingredient:
- "  Dough"
- "260 gr terigu protein tinggi"
- "5 gr ragi instant"
- "1 sdt garam"
- "40 gr gula"
- "1 butir telur"
- "120 ml susu cair hangat"
- "35 gr butter"
- "  Toping"
- "1 putih telur"
- "6 gr kopi"
- "15 ml air"
- "70 gr tepung sedang"
- "70 gr margarine butter"
- "3 sdm icing sugar"
- "  isian"
- "8 sdm butter"
recipeinstructions:
- "Buat Toping. Campur semua bahan, lalu di blender supaya teraduk rata. Masukkan ke dalam piping bag n simpan dalam kulkas."
- "Campur terigu, gula, garam n ragi, aduk dengan spatula/whisk, tambahkan telur n susu, ulen sampai setengah kalis (sy ulen pakai tangan)"
- "Setelah setengah kalis, tambahkan butter, ulen sampai kalis. Saat menambahkan butter, adonan akan pecah, tapi nanti akan kembali menjadi kalis. Bentuk adonan bulat, lalu tutup pakai plastik warp, istirahatkan selama 1 jam."
- "Setelah 1 jam, kempiskan dulu adonan, timbang @ 68 gr jadi 4 (sy 1/2 resep) bulatkan."
- "Balik bulatan sehingga bagian bawah ada diatas, pipihkan dengan bagian pinggir lebih tipis dari bagian tengah, isi 1 sdm mentega/butter, tutup dan bulatkan lagi."
- "Letakkan tiap bulatan yang sudah diisi di loyang beralas baking paper, beri jarak tiap bun. diamkan 30 menit tertutup serbet bersih."
- "Panaskan oven 10 menit sebelum waktu proofing berakhir. Ambil topping, semprotkan topping melingkar seperti obat nyamuk dari bagian tengah permukaan bun, hingga 1/2 bagian."
- "Panggang di oven dengan suhu 180°C selama 20 menit, sesuai oven masing2."
- "Angkat dari oven saat sudah matang, letakkan di atas rak/kawat pendingin.Sajikan hangat."
categories:
- Recipe
tags:
- coffee
- bun
- mexican

katakunci: coffee bun mexican 
nutrition: 300 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Lunch

---


![Coffee Bun (Mexican Coffee Bun)](https://img-global.cpcdn.com/recipes/8221777394656c22/680x482cq70/coffee-bun-mexican-coffee-bun-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang patut kita jaga karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti coffee bun (mexican coffee bun) yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan keistimewahan yang merupakan keragaman Kita

Kedekatan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Coffee Bun (Mexican Coffee Bun) untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang bisa anda contoh salah satunya coffee bun (mexican coffee bun) yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep coffee bun (mexican coffee bun) tanpa harus bersusah payah.
Berikut ini resep Coffee Bun (Mexican Coffee Bun) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Coffee Bun (Mexican Coffee Bun):

1. Dibutuhkan  ☝️ Dough
1. Harap siapkan 260 gr terigu protein tinggi
1. Tambah 5 gr ragi instant
1. Siapkan 1 sdt garam
1. Jangan lupa 40 gr gula
1. Diperlukan 1 butir telur
1. Harus ada 120 ml susu cair hangat
1. Jangan lupa 35 gr butter
1. Harus ada  ✌ Toping
1. Tambah 1 putih telur
1. Diperlukan 6 gr kopi
1. Siapkan 15 ml air
1. Siapkan 70 gr tepung sedang
1. Harus ada 70 gr margarine /butter
1. Jangan lupa 3 sdm icing sugar
1. Siapkan  👌 isian
1. Jangan lupa 8 sdm butter




<!--inarticleads2-->

##### Langkah membuat  Coffee Bun (Mexican Coffee Bun):

1. Buat Toping. Campur semua bahan, lalu di blender supaya teraduk rata. Masukkan ke dalam piping bag n simpan dalam kulkas.
1. Campur terigu, gula, garam n ragi, aduk dengan spatula/whisk, tambahkan telur n susu, ulen sampai setengah kalis (sy ulen pakai tangan)
1. Setelah setengah kalis, tambahkan butter, ulen sampai kalis. Saat menambahkan butter, adonan akan pecah, tapi nanti akan kembali menjadi kalis. Bentuk adonan bulat, lalu tutup pakai plastik warp, istirahatkan selama 1 jam.
1. Setelah 1 jam, kempiskan dulu adonan, timbang @ 68 gr jadi 4 (sy 1/2 resep) bulatkan.
1. Balik bulatan sehingga bagian bawah ada diatas, pipihkan dengan bagian pinggir lebih tipis dari bagian tengah, isi 1 sdm mentega/butter, tutup dan bulatkan lagi.
1. Letakkan tiap bulatan yang sudah diisi di loyang beralas baking paper, beri jarak tiap bun. diamkan 30 menit tertutup serbet bersih.
1. Panaskan oven 10 menit sebelum waktu proofing berakhir. Ambil topping, semprotkan topping melingkar seperti obat nyamuk dari bagian tengah permukaan bun, hingga 1/2 bagian.
1. Panggang di oven dengan suhu 180°C selama 20 menit, sesuai oven masing2.
1. Angkat dari oven saat sudah matang, letakkan di atas rak/kawat pendingin.Sajikan hangat.




Demikianlah cara membuat coffee bun (mexican coffee bun) yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan terbukti, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
