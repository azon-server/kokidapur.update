---
description: "Resep : Coffee Bun Luar biasa"
title: "Resep : Coffee Bun Luar biasa"
slug: 285-resep-coffee-bun-luar-biasa
date: 2020-09-12T19:37:25.279Z
image: https://img-global.cpcdn.com/recipes/e68c695e309bb71f/680x482cq70/coffee-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e68c695e309bb71f/680x482cq70/coffee-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e68c695e309bb71f/680x482cq70/coffee-bun-foto-resep-utama.jpg
author: Julian May
ratingvalue: 4.5
reviewcount: 1054
recipeingredient:
- " BAHAN ROTI"
- "200 gr Tepung protein tinggi Cakra"
- "50 gr Tepung protein sedang Segitiga"
- "50 gr Gula Pasir"
- "7 gr Ragi Instant"
- "2 Kuning Telur"
- "80 ml Susu UHT dingin"
- "30 ml Whipped Cream Cair"
- "50 gr Unsalted Butter saya Anchor"
- "Secubit garam"
- " __"
- " BAHAN FILLING"
- "1/2 bungkus Blue band dinginkan dulu dikulkas lalu potong dadu"
- " __"
- " BAHAN TOPPING"
- "100 gr Unsalted Buter saya Anchor"
- "70 gr Gula Halus"
- "1 butir Telur"
- "80 gr Tepung Segitiga"
- "1 sachet Kopi Instant larutkan dgn 50 ml air panas syCoffemix"
- "2 tetes pasta Kopi Moka"
recipeinstructions:
- "Campur terigu, gula, ragi. Aduk rata. Masukkan kuning telur. Tuang whipped cream semua, lalu susu cair sedikit demi sedikit. Ulen hingga setengah kalis. Masukkan butter dan garam. Ulen sampai kalis, kurleb 15-20 menit. Tutup pakai plastik wrap, diamkan sekitar 45-60 menit hingga mengembang 2xlipat."
- "Larutkan kopi instant dengan air panas. Sisihkan. Biarkan hingga dingin."
- "Setelah adonan mengembang, kempeskan. Timbang @50gr. Bisa dapat 10 pcs ya. Diamkan 10 menit. Potong2 margarin blueband yang udh didinginkan, potong dadu, @10gr. Setengah bungkus itu, bisa dibagi 10 ya."
- "Ambil satu pcs roti, pipihkan. Taruh margarin potong, rapatkan dan bulat kan. Taruh di atas loyang yg sudah diberi baking paper. Lakukan hingga selesai."
- "Utk topping, mixer gula halus dan unsalted butter hingga halus. Sekitar 5 menit. Masukkan telur. Mixer lagi sekitar 7 menit. Masukkan terigu dan larutan kopi td. Terakhir masukkan pasta kopi moka. Aduk rata. Masukkan kedalam pipping bag. Gunting kecil aja diujungnya."
- "Panaskan oven suhu 200⁰C minimal 10 menit sebelum roti dipanggang."
- "Jika roti2 nya udah mengembang menul2, mulai beri topping ya. Mulai dari tengah, putar2..Lakukan sampai 3/4 bagian roti. Panggang roti kurleb 15-20 menit aja, sampai permukaan kering."
- "Aroma semerbak ala bakery pun bikin gak sabar buat nyicip. Persis seperti yang dijual, gopong juga ditengahnya. Emang enak syekalii pemirsahh. Selamat mencoba."
categories:
- Recipe
tags:
- coffee
- bun

katakunci: coffee bun 
nutrition: 247 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT58M"
recipeyield: "1"
recipecategory: Dinner

---


![Coffee Bun](https://img-global.cpcdn.com/recipes/e68c695e309bb71f/680x482cq70/coffee-bun-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga empuk. Ciri khas makanan Indonesia coffee bun yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa ditemukan dengan cara simple. Diantaranya adalah memasak Coffee Bun untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang dapat anda coba salah satunya coffee bun yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep coffee bun tanpa harus bersusah payah.
Berikut ini resep Coffee Bun yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 21 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Coffee Bun:

1. Diperlukan  BAHAN ROTI:
1. Dibutuhkan 200 gr Tepung protein tinggi (Cakra)
1. Diperlukan 50 gr Tepung protein sedang (Segitiga)
1. Harus ada 50 gr Gula Pasir
1. Harus ada 7 gr Ragi Instant
1. Diperlukan 2 Kuning Telur
1. Dibutuhkan 80 ml Susu UHT dingin
1. Tambah 30 ml Whipped Cream Cair
1. Diperlukan 50 gr Unsalted Butter (saya: Anchor)
1. Jangan lupa Secubit garam
1. Siapkan  __
1. Jangan lupa  BAHAN FILLING:
1. Diperlukan 1/2 bungkus Blue band, dinginkan dulu dikulkas, lalu potong dadu
1. Tambah  __
1. Siapkan  BAHAN TOPPING:
1. Dibutuhkan 100 gr Unsalted Buter (saya: Anchor)
1. Jangan lupa 70 gr Gula Halus
1. Harap siapkan 1 butir Telur
1. Harus ada 80 gr Tepung Segitiga
1. Siapkan 1 sachet Kopi Instant larutkan dgn 50 ml air panas (sy:Coffemix)
1. Diperlukan 2 tetes pasta Kopi Moka




<!--inarticleads2-->

##### Cara membuat  Coffee Bun:

1. Campur terigu, gula, ragi. Aduk rata. Masukkan kuning telur. Tuang whipped cream semua, lalu susu cair sedikit demi sedikit. Ulen hingga setengah kalis. Masukkan butter dan garam. Ulen sampai kalis, kurleb 15-20 menit. Tutup pakai plastik wrap, diamkan sekitar 45-60 menit hingga mengembang 2xlipat.
1. Larutkan kopi instant dengan air panas. Sisihkan. Biarkan hingga dingin.
1. Setelah adonan mengembang, kempeskan. Timbang @50gr. Bisa dapat 10 pcs ya. Diamkan 10 menit. Potong2 margarin blueband yang udh didinginkan, potong dadu, @10gr. Setengah bungkus itu, bisa dibagi 10 ya.
1. Ambil satu pcs roti, pipihkan. Taruh margarin potong, rapatkan dan bulat kan. Taruh di atas loyang yg sudah diberi baking paper. Lakukan hingga selesai.
1. Utk topping, mixer gula halus dan unsalted butter hingga halus. Sekitar 5 menit. Masukkan telur. Mixer lagi sekitar 7 menit. Masukkan terigu dan larutan kopi td. Terakhir masukkan pasta kopi moka. Aduk rata. Masukkan kedalam pipping bag. Gunting kecil aja diujungnya.
1. Panaskan oven suhu 200⁰C minimal 10 menit sebelum roti dipanggang.
1. Jika roti2 nya udah mengembang menul2, mulai beri topping ya. Mulai dari tengah, putar2..Lakukan sampai 3/4 bagian roti. Panggang roti kurleb 15-20 menit aja, sampai permukaan kering.
1. Aroma semerbak ala bakery pun bikin gak sabar buat nyicip. Persis seperti yang dijual, gopong juga ditengahnya. Emang enak syekalii pemirsahh. Selamat mencoba.




Demikianlah cara membuat coffee bun yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
