---
description: "Panduan untuk membuat Roti o Terbukti"
title: "Panduan untuk membuat Roti o Terbukti"
slug: 409-panduan-untuk-membuat-roti-o-terbukti
date: 2020-11-02T13:12:24.166Z
image: https://img-global.cpcdn.com/recipes/8166ccb9e3a34ae2/680x482cq70/roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8166ccb9e3a34ae2/680x482cq70/roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8166ccb9e3a34ae2/680x482cq70/roti-o-foto-resep-utama.jpg
author: Lena Fletcher
ratingvalue: 4.1
reviewcount: 17635
recipeingredient:
- "250 gr tepung cakra"
- "160 ml susu dingin  telur 1 butir"
- "30 gr margarin"
- "50 gr gula pasir"
- "1 sdt ragi instan"
- "Sejumput garam"
- " Untuk toping roti"
- "60 gram margarin"
- "60 gram gula pasir"
- "1 butir telur"
- "70 gram tepung terigu"
- "3 sdt kopi instan me nescafe"
- "2 sdt air panas"
- "secukupnya Untuk isian roti  butter dingin"
recipeinstructions:
- "Aduk tepung susu dingin dan telur, gula pasir, ragi instan di mixser sampai agak setenga kalis, baru masukan margarin dan garam"
- "Kalau sudah kalis diamkan adonan sampai mengembang"
- "Kalau sudah mengembang kempiskan adonan bagi adonan 50 gr sambil d bulatkan dan d isi butter dinggin me (setenga sendok teh)"
- "Istirahatkan adonan selama setenga jam atau sampai mengembang jng lupa selama d istirahatkan d tutup dgn kain yg bersih"
- "Bila sudah mengembang beri topping d atasnya dgn cara melingkar seperti bentuk obat nyamuk"
- "Bila sudah selesai oven roti hingga matang me 20 menit jangan lupa roti atau loyang d alasi dgn kertas roti"
categories:
- Recipe
tags:
- roti
- o

katakunci: roti o 
nutrition: 192 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT44M"
recipeyield: "3"
recipecategory: Dessert

---


![Roti o](https://img-global.cpcdn.com/recipes/8166ccb9e3a34ae2/680x482cq70/roti-o-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga renyah. Karasteristik kuliner Nusantara roti o yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Roti o untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang bisa anda contoh salah satunya roti o yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep roti o tanpa harus bersusah payah.
Berikut ini resep Roti o yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti o:

1. Harap siapkan 250 gr tepung cakra
1. Harap siapkan 160 ml susu dingin + telur 1 butir
1. Diperlukan 30 gr margarin
1. Diperlukan 50 gr gula pasir
1. Jangan lupa 1 sdt ragi instan
1. Tambah Sejumput garam
1. Jangan lupa  Untuk toping roti
1. Dibutuhkan 60 gram margarin
1. Harap siapkan 60 gram gula pasir
1. Siapkan 1 butir telur
1. Dibutuhkan 70 gram tepung terigu
1. Siapkan 3 sdt kopi instan (me nescafe)
1. Siapkan 2 sdt air panas
1. Harap siapkan secukupnya Untuk isian roti : butter dingin




<!--inarticleads2-->

##### Langkah membuat  Roti o:

1. Aduk tepung susu dingin dan telur, gula pasir, ragi instan di mixser sampai agak setenga kalis, baru masukan margarin dan garam
1. Kalau sudah kalis diamkan adonan sampai mengembang
1. Kalau sudah mengembang kempiskan adonan bagi adonan 50 gr sambil d bulatkan dan d isi butter dinggin me (setenga sendok teh)
1. Istirahatkan adonan selama setenga jam atau sampai mengembang jng lupa selama d istirahatkan d tutup dgn kain yg bersih
1. Bila sudah mengembang beri topping d atasnya dgn cara melingkar seperti bentuk obat nyamuk
1. Bila sudah selesai oven roti hingga matang me 20 menit jangan lupa roti atau loyang d alasi dgn kertas roti




Demikianlah cara membuat roti o yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
