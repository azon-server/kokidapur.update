---
description: "Resep : Mexican Bun a.k.a Roti Boy (Roti &amp;#34;O&amp;#34;) tanpa telur oven tangkring Homemade"
title: "Resep : Mexican Bun a.k.a Roti Boy (Roti &amp;#34;O&amp;#34;) tanpa telur oven tangkring Homemade"
slug: 346-resep-mexican-bun-aka-roti-boy-roti-and-34-o-and-34-tanpa-telur-oven-tangkring-homemade
date: 2021-03-04T06:27:43.308Z
image: https://img-global.cpcdn.com/recipes/20514a90b9ac2516/680x482cq70/mexican-bun-aka-roti-boy-roti-o-tanpa-telur-oven-tangkring-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/20514a90b9ac2516/680x482cq70/mexican-bun-aka-roti-boy-roti-o-tanpa-telur-oven-tangkring-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/20514a90b9ac2516/680x482cq70/mexican-bun-aka-roti-boy-roti-o-tanpa-telur-oven-tangkring-foto-resep-utama.jpg
author: Sophie Shaw
ratingvalue: 4.7
reviewcount: 29246
recipeingredient:
- "125 gram tepung protein tinggi saya pake cakra"
- "1/2 sdt ragi instan saya pake fermipan"
- "3 sdt gula pasir"
- "85 ml susu cair"
- "12.5 gram butter atau 1 12 sdm butter saya pake anchor"
- "1/4 sdt garam"
- " Isian  filling"
- "Secukupnya Butter margarin bekukan saya pake anchor"
- " Topping kopi "
- "3,5 sdm tepung terigu saya pake kunci biru"
- "1,5 sdm gula pasir"
- "1,5 sdm butter margarin saya pake anchor"
- "Sejumput garam"
- "1 sachet nescafe 2gram"
- "1/4 sdt vanili bubuk saya pake larome"
- "1/4 sdt Baking Powder saya pake double acting"
- "25 ml air hangat setara 25 sdm"
recipeinstructions:
- "Campurkan tepung terigu, ragi, dan gula pasir, tuangkan susu cair, lalu uleni hingga kallis"
- "Setelah kalis masukkan butter / margarin. uleni hingga kalis elastis atau sampai WP (window pane) terbentuk"
- "Bulatkan adonan. beri olesan minyak goreng agar tidak kering. lalu tutup dan diamkan kurang lebih 1 jam (hingga mengembang)"
- "Sementara menunggu proofing, kita buat topingnya ya mommies : tuangkan kewadah semua bahan toping. baru masukkan air hangat. aduk hingga rata"
- "Masukkan kedalam piping bag. masukkan kedalam kulkas. setelah roti mengembang. kempiskan dan bagi menjadi 5 bagian masing-masing @47 gram. isi dengan butter / margarin (secukupnya aja, jangan kebanyakan, ntar malah keasinan) hihihihi"
- "Lalu bulatkan dan rounding. cara seperti video ya mommies. lalu tata di loyang."
- "Lalu diamkan 20 menit. (ditutup pakai serbet) setelah 20 menit. beri toping kopi melingkar seperti bentuk obat nyamuk. jangan sampai ada yg lubang krna nanti malah hasilnya ngga bisa rata."
- "Lakukan terus ke bulatan roti yg lain. lalu panggang dengan suhu 180 derajat kurang lebih 15-20 menit. keluarkan dari oven. dan siap disajikan."
- "Berikut ini penampakannya..yukkk cuzz bikin.. ngga akan nyesel deh..😘😘"
categories:
- Recipe
tags:
- mexican
- bun
- aka

katakunci: mexican bun aka 
nutrition: 289 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dessert

---


![Mexican Bun a.k.a Roti Boy (Roti &#34;O&#34;) tanpa telur oven tangkring](https://img-global.cpcdn.com/recipes/20514a90b9ac2516/680x482cq70/mexican-bun-aka-roti-boy-roti-o-tanpa-telur-oven-tangkring-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti mexican bun a.k.a roti boy (roti &#34;o&#34;) tanpa telur oven tangkring yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan keistimewahan yang merupakan keragaman Nusantara



Kehangatan keluarga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Mexican Bun a.k.a Roti Boy (Roti &#34;O&#34;) tanpa telur oven tangkring untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang dapat anda praktekkan salah satunya mexican bun a.k.a roti boy (roti &#34;o&#34;) tanpa telur oven tangkring yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep mexican bun a.k.a roti boy (roti &#34;o&#34;) tanpa telur oven tangkring tanpa harus bersusah payah.
Berikut ini resep Mexican Bun a.k.a Roti Boy (Roti &#34;O&#34;) tanpa telur oven tangkring yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican Bun a.k.a Roti Boy (Roti &#34;O&#34;) tanpa telur oven tangkring:

1. Siapkan 125 gram tepung protein tinggi (saya pake cakra)
1. Harap siapkan 1/2 sdt ragi instan (saya pake fermipan)
1. Jangan lupa 3 sdt gula pasir
1. Dibutuhkan 85 ml susu cair
1. Tambah 12.5 gram butter atau 1 1/2 sdm butter (saya pake anchor)
1. Harap siapkan 1/4 sdt garam
1. Tambah  Isian / filling:
1. Harap siapkan Secukupnya Butter /margarin bekukan (saya pake anchor)
1. Diperlukan  Topping kopi :
1. Diperlukan 3,5 sdm tepung terigu (saya pake kunci biru)
1. Harap siapkan 1,5 sdm gula pasir
1. Harus ada 1,5 sdm butter /margarin (saya pake anchor)
1. Diperlukan Sejumput garam
1. Dibutuhkan 1 sachet nescafe (2gram)
1. Jangan lupa 1/4 sdt vanili bubuk (saya pake larome)
1. Harus ada 1/4 sdt Baking Powder (saya pake double acting)
1. Diperlukan 25 ml air hangat (setara 2.5 sdm)




<!--inarticleads2-->

##### Bagaimana membuat  Mexican Bun a.k.a Roti Boy (Roti &#34;O&#34;) tanpa telur oven tangkring:

1. Campurkan tepung terigu, ragi, dan gula pasir, tuangkan susu cair, lalu uleni hingga kallis
1. Setelah kalis masukkan butter / margarin. uleni hingga kalis elastis atau sampai WP (window pane) terbentuk
1. Bulatkan adonan. beri olesan minyak goreng agar tidak kering. lalu tutup dan diamkan kurang lebih 1 jam (hingga mengembang)
1. Sementara menunggu proofing, kita buat topingnya ya mommies : tuangkan kewadah semua bahan toping. baru masukkan air hangat. aduk hingga rata
1. Masukkan kedalam piping bag. masukkan kedalam kulkas. setelah roti mengembang. kempiskan dan bagi menjadi 5 bagian masing-masing @47 gram. isi dengan butter / margarin (secukupnya aja, jangan kebanyakan, ntar malah keasinan) hihihihi
1. Lalu bulatkan dan rounding. cara seperti video ya mommies. lalu tata di loyang.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Mexican Bun a.k.a Roti Boy (Roti &#34;O&#34;) tanpa telur oven tangkring">1. Lalu diamkan 20 menit. (ditutup pakai serbet) setelah 20 menit. beri toping kopi melingkar seperti bentuk obat nyamuk. jangan sampai ada yg lubang krna nanti malah hasilnya ngga bisa rata.
1. Lakukan terus ke bulatan roti yg lain. lalu panggang dengan suhu 180 derajat kurang lebih 15-20 menit. keluarkan dari oven. dan siap disajikan.
1. Berikut ini penampakannya..yukkk cuzz bikin.. ngga akan nyesel deh..😘😘




Demikianlah cara membuat mexican bun a.k.a roti boy (roti &#34;o&#34;) tanpa telur oven tangkring yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
