---
description: "Cara singkat untuk membuat Coffee Bun aka Mexican Bun terupdate"
title: "Cara singkat untuk membuat Coffee Bun aka Mexican Bun terupdate"
slug: 271-cara-singkat-untuk-membuat-coffee-bun-aka-mexican-bun-terupdate
date: 2020-11-12T18:27:01.057Z
image: https://img-global.cpcdn.com/recipes/517500e90ff0c881/680x482cq70/coffee-bun-aka-mexican-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/517500e90ff0c881/680x482cq70/coffee-bun-aka-mexican-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/517500e90ff0c881/680x482cq70/coffee-bun-aka-mexican-bun-foto-resep-utama.jpg
author: Claudia Higgins
ratingvalue: 4.2
reviewcount: 49333
recipeingredient:
- " Bahan A"
- "300 gr tepung terigu protein tinggi"
- "50 gr gula pasir"
- "7 gr ragi instan"
- "100 ml susu cair"
- "100 ml whipping cream cair saya ganti 100 ml susu cair"
- " Bahan B"
- "65 gr butter saya pakai margarin"
- "1/2 sdt garam"
- " Bahan Isian"
- " Butter  margarine didinginkan lalu potong kotakkotak"
- " Bahan Topping"
- "70 gr butter saya pakai margarin"
- "35 gr gula halus"
- "1 butir telur"
- "1 sachet kopi instan Nescafe larutkan dengan 2 sdm air panas"
- "70 gr terigu saya pakai protein rendah"
recipeinstructions:
- "Campur semua Bahan A, lalu ulen / mixer hingga setengah kalis."
- "Tambahkan Bahan B, ulen/mixer hingga kalis."
- "Ambil sedikit adonan dan tes window pane. Jika sudah elastis, dan transparan saat ditarik, berarti sudah siap. Bulatkan adonan, tutup, dan istirahatkan sekitar 45 menit."
- "Kempiskan adonan, bagi menjadi beberapa bagian. Masing-masing sekitar 60 gr. Tutup dengan serbet, dan diamkan selama 15 menit."
- "Sambil menunggu, kita buat topping. Dengan whisk, campur gula halus dan butter. Lalu tambahkan telur, campur. Tambahkan kopi cair, campur."
- "Tambahkan tepung, campur. Setelah adonan bagus, masukkan ke dalam pipping bag. Sisihkan."
- "Setelah 15 menit, gilas satu adonan roti. Masukkan butter dingin (saya pakai cukup 1 sdt). Bungkus/bulatkan lagi. Lakukan sampai habis. Tutup dengan serbet, dan diamkan sampai adonan mengembang 2 x lipat."
- "Beri topping, cukup 3/4 bagian atas adonan. (Saya panggang 1 loyang isi 3 adonan roti saja, biar bentuknya baik). Panaskan oven api atas bawah 175 °C (saya pakai 200°C, sesuaikan dengan oven masing-masing ya 😁). Panggang selama 25 menit."
- "Harumnya ke mana2. Bagian dalamnya seperti ini. Siap dihidangkan selagi hangat. Makin enak dengan kopi hitam panas. 😋"
categories:
- Recipe
tags:
- coffee
- bun
- aka

katakunci: coffee bun aka 
nutrition: 250 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Lunch

---


![Coffee Bun aka Mexican Bun](https://img-global.cpcdn.com/recipes/517500e90ff0c881/680x482cq70/coffee-bun-aka-mexican-bun-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan enak. Karasteristik masakan Nusantara coffee bun aka mexican bun yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Coffee Bun aka Mexican Bun untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang bisa anda coba salah satunya coffee bun aka mexican bun yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep coffee bun aka mexican bun tanpa harus bersusah payah.
Seperti resep Coffee Bun aka Mexican Bun yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 9 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Coffee Bun aka Mexican Bun:

1. Dibutuhkan  Bahan A
1. Harus ada 300 gr tepung terigu protein tinggi
1. Diperlukan 50 gr gula pasir
1. Dibutuhkan 7 gr ragi instan
1. Harus ada 100 ml susu cair
1. Diperlukan 100 ml whipping cream cair (saya ganti 100 ml susu cair)
1. Jangan lupa  Bahan B
1. Dibutuhkan 65 gr butter (saya pakai margarin)
1. Tambah 1/2 sdt garam
1. Dibutuhkan  Bahan Isian
1. Jangan lupa  Butter / margarine didinginkan, lalu potong kotak-kotak
1. Harap siapkan  Bahan Topping
1. Jangan lupa 70 gr butter (saya pakai margarin)
1. Harap siapkan 35 gr gula halus
1. Jangan lupa 1 butir telur
1. Harus ada 1 sachet kopi instan (Nescafe), larutkan dengan 2 sdm air panas
1. Harus ada 70 gr terigu (saya pakai protein rendah)




<!--inarticleads2-->

##### Cara membuat  Coffee Bun aka Mexican Bun:

1. Campur semua Bahan A, lalu ulen / mixer hingga setengah kalis.
1. Tambahkan Bahan B, ulen/mixer hingga kalis.
1. Ambil sedikit adonan dan tes window pane. Jika sudah elastis, dan transparan saat ditarik, berarti sudah siap. Bulatkan adonan, tutup, dan istirahatkan sekitar 45 menit.
1. Kempiskan adonan, bagi menjadi beberapa bagian. Masing-masing sekitar 60 gr. Tutup dengan serbet, dan diamkan selama 15 menit.
1. Sambil menunggu, kita buat topping. Dengan whisk, campur gula halus dan butter. Lalu tambahkan telur, campur. Tambahkan kopi cair, campur.
1. Tambahkan tepung, campur. Setelah adonan bagus, masukkan ke dalam pipping bag. Sisihkan.
1. Setelah 15 menit, gilas satu adonan roti. Masukkan butter dingin (saya pakai cukup 1 sdt). Bungkus/bulatkan lagi. Lakukan sampai habis. Tutup dengan serbet, dan diamkan sampai adonan mengembang 2 x lipat.
1. Beri topping, cukup 3/4 bagian atas adonan. (Saya panggang 1 loyang isi 3 adonan roti saja, biar bentuknya baik). Panaskan oven api atas bawah 175 °C (saya pakai 200°C, sesuaikan dengan oven masing-masing ya 😁). Panggang selama 25 menit.
1. Harumnya ke mana2. Bagian dalamnya seperti ini. Siap dihidangkan selagi hangat. Makin enak dengan kopi hitam panas. 😋




Demikianlah cara membuat coffee bun aka mexican bun yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan terbukti, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
