---
description: "Panduan untuk membuat Roti Boy terupdate"
title: "Panduan untuk membuat Roti Boy terupdate"
slug: 265-panduan-untuk-membuat-roti-boy-terupdate
date: 2020-10-13T09:00:19.817Z
image: https://img-global.cpcdn.com/recipes/73d5a65eb652e314/680x482cq70/roti-boy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/73d5a65eb652e314/680x482cq70/roti-boy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/73d5a65eb652e314/680x482cq70/roti-boy-foto-resep-utama.jpg
author: Don Foster
ratingvalue: 4.2
reviewcount: 44851
recipeingredient:
- "400 gr tepung terigu protein tinggi"
- "60 gr gula pasir"
- "15 gr susu bubuk"
- "7 gr ragi"
- "2 btr kuning telur"
- "150 ml airsusu cair dingin"
- "60 gr margarin"
- "1/2 sdt garam"
- " Isi "
- " Buttermargarin potong dadu bekukan"
- " Topping "
- "100 gr margarin"
- "100 gr tepung terigu protein sedang"
- "70 gr gula halus"
- "2 btr putih telur"
- "2 sachet nescafe classic larutkan dengan 2sdm air panas"
recipeinstructions:
- "Masukkan dalam wadah besar, tepung terigu protein tinggi, gula pasir, susu bubuk, ragi, kuning telur dan air/susu cair dingin. Mixer dengan speed tinggi sampai setengah kalis. Tambahkan margarin dan garam. Mixer sampai adonan kalis elastis."
- "Setelah adonan kalis, bulatkan, kemudian tutup dengan kain bersih kurleb 45menit."
- "Selagi menunggu adonan profing, kita buat topping nya."
- "Ayak tepung terigu dan gula halus. Mix margarin dan gula halus dengan speed rendah. Tambahkan putih telur, kocok rata. Kemudian masukkan kopi dan tepung terigu. Kocok sampai tercampur rata. Masukkan adonan topping ke dalam plastik segitiga dan simpan di kulkas."
- "Setelah 45 menit, adonan mengembang 2x lipat. Kempiskan adonan yang sudah mengembang. Lalu timbang adonan @50gr, bulatkan. Tutup dengan kain bersih kurleb 15 menit."
- "Setelah 15 menit, ambil satu adonan, kemudian pipihkan. Isi dengan bahan isian. Kunci adonan agar isian tidak meleleh keluar saat di panggang. Lakukan sampai semua adonan habis. Lalu istirahat kan kembali kurleb 30 menit."
- "Setelah 30 menit, adonan mengembang 2x lipat. Semprotkan topping melingkar di atas adonan roti (maapkeun bentuknya berantakan, krn sempat ada insiden plastik nya sobek 😂😂) Lalu panggang roti kurleb 25 menit dengan api sedang cenderung besar."
- "Jika topping sudah terlihat mengeras, tandanya roti sudah matang."
categories:
- Recipe
tags:
- roti
- boy

katakunci: roti boy 
nutrition: 135 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Dinner

---


![Roti Boy](https://img-global.cpcdn.com/recipes/73d5a65eb652e314/680x482cq70/roti-boy-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang harus kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti roti boy yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Kita

Keharmonisan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah memasak Roti Boy untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang bisa anda buat salah satunya roti boy yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep roti boy tanpa harus bersusah payah.
Seperti resep Roti Boy yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Boy:

1. Diperlukan 400 gr tepung terigu protein tinggi
1. Siapkan 60 gr gula pasir
1. Harus ada 15 gr susu bubuk
1. Dibutuhkan 7 gr ragi
1. Siapkan 2 btr kuning telur
1. Tambah 150 ml air/susu cair dingin
1. Harap siapkan 60 gr margarin
1. Siapkan 1/2 sdt garam
1. Diperlukan  Isi :
1. Diperlukan  Butter/margarin.. potong dadu, bekukan.
1. Jangan lupa  Topping :
1. Harap siapkan 100 gr margarin
1. Tambah 100 gr tepung terigu protein sedang
1. Jangan lupa 70 gr gula halus
1. Dibutuhkan 2 btr putih telur
1. Jangan lupa 2 sachet nescafe classic, larutkan dengan 2sdm air panas




<!--inarticleads2-->

##### Instruksi membuat  Roti Boy:

1. Masukkan dalam wadah besar, tepung terigu protein tinggi, gula pasir, susu bubuk, ragi, kuning telur dan air/susu cair dingin. Mixer dengan speed tinggi sampai setengah kalis. Tambahkan margarin dan garam. Mixer sampai adonan kalis elastis.
1. Setelah adonan kalis, bulatkan, kemudian tutup dengan kain bersih kurleb 45menit.
1. Selagi menunggu adonan profing, kita buat topping nya.
1. Ayak tepung terigu dan gula halus. Mix margarin dan gula halus dengan speed rendah. Tambahkan putih telur, kocok rata. Kemudian masukkan kopi dan tepung terigu. Kocok sampai tercampur rata. Masukkan adonan topping ke dalam plastik segitiga dan simpan di kulkas.
1. Setelah 45 menit, adonan mengembang 2x lipat. Kempiskan adonan yang sudah mengembang. Lalu timbang adonan @50gr, bulatkan. Tutup dengan kain bersih kurleb 15 menit.
1. Setelah 15 menit, ambil satu adonan, kemudian pipihkan. Isi dengan bahan isian. Kunci adonan agar isian tidak meleleh keluar saat di panggang. Lakukan sampai semua adonan habis. Lalu istirahat kan kembali kurleb 30 menit.
1. Setelah 30 menit, adonan mengembang 2x lipat. Semprotkan topping melingkar di atas adonan roti (maapkeun bentuknya berantakan, krn sempat ada insiden plastik nya sobek 😂😂) Lalu panggang roti kurleb 25 menit dengan api sedang cenderung besar.
1. Jika topping sudah terlihat mengeras, tandanya roti sudah matang.




Demikianlah cara membuat roti boy yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
