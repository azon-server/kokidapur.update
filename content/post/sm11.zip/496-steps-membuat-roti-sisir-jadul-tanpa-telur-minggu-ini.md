---
description: "Steps membuat Roti sisir jadul (tanpa telur) minggu ini"
title: "Steps membuat Roti sisir jadul (tanpa telur) minggu ini"
slug: 496-steps-membuat-roti-sisir-jadul-tanpa-telur-minggu-ini
date: 2020-12-26T18:34:29.050Z
image: https://img-global.cpcdn.com/recipes/946922c0942627d3/680x482cq70/roti-sisir-jadul-tanpa-telur-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/946922c0942627d3/680x482cq70/roti-sisir-jadul-tanpa-telur-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/946922c0942627d3/680x482cq70/roti-sisir-jadul-tanpa-telur-foto-resep-utama.jpg
author: Anne Roberson
ratingvalue: 4.9
reviewcount: 22101
recipeingredient:
- "400 gr tepung terigu Cakra"
- "2 sdt ragi instan"
- "4 sdm gula pasir"
- "220 ml air hangat"
- "40 gr mentega"
- " Bahan olesan "
- "60 gr mentega"
- "40 gr gula pasir"
- "2 sdt SKM putih"
- " Campur merata"
recipeinstructions:
- "Membuat roti : campur bahan kering, beri lubang ditengahnya, beri sedikit demi sedikit air hangat, ulen hingga setengah kalis"
- "Lalu tambahkan mentega, ulen kembali hingga kalis, diamkan hingga mengembang 2x (tutup wadahnya)"
- "Setelah mengembang, timbang adonan masing2 sekitar 45 gr, rounding (bulatkan), saya td dapat 17 bulatan, diamkan sampai mengembang"
- "Siapkan loyang (saya pakai uk 20x20) oles tipis dengan mentega"
- "Tipiskan/giling adonan td, lalu gulung, dan tekan sedikit (agak pipih), beri satu sisi nyaa bahan olesan lalu susun di loyang"
- "Olesi bagian atasnya dengan skm putih, panggang dalam oven yg sdh dipanaskan terlebih dahulu (api sedang / -/+ 160 derajat) tapi semua tergantung oven masing2 yaa"
- "Panggang hingga atasnya kecoklatan, setelah itu angkat, biarkan hangat, lalu sobek pelan2 beri bahan olesan disetiap sisinya"
- "Selamat mencoba ☺️👌"
categories:
- Recipe
tags:
- roti
- sisir
- jadul

katakunci: roti sisir jadul 
nutrition: 117 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT35M"
recipeyield: "3"
recipecategory: Dessert

---


![Roti sisir jadul (tanpa telur)](https://img-global.cpcdn.com/recipes/946922c0942627d3/680x482cq70/roti-sisir-jadul-tanpa-telur-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan enak. Ciri khas masakan Nusantara roti sisir jadul (tanpa telur) yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah memasak Roti sisir jadul (tanpa telur) untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang dapat anda buat salah satunya roti sisir jadul (tanpa telur) yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep roti sisir jadul (tanpa telur) tanpa harus bersusah payah.
Berikut ini resep Roti sisir jadul (tanpa telur) yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 10 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti sisir jadul (tanpa telur):

1. Tambah 400 gr tepung terigu Cakra
1. Harap siapkan 2 sdt ragi instan
1. Dibutuhkan 4 sdm gula pasir
1. Jangan lupa 220 ml air hangat
1. Diperlukan 40 gr mentega
1. Siapkan  Bahan olesan :
1. Jangan lupa 60 gr mentega
1. Harus ada 40 gr gula pasir
1. Tambah 2 sdt SKM putih
1. Harus ada  Campur merata




<!--inarticleads2-->

##### Bagaimana membuat  Roti sisir jadul (tanpa telur):

1. Membuat roti : campur bahan kering, beri lubang ditengahnya, beri sedikit demi sedikit air hangat, ulen hingga setengah kalis
1. Lalu tambahkan mentega, ulen kembali hingga kalis, diamkan hingga mengembang 2x (tutup wadahnya)
1. Setelah mengembang, timbang adonan masing2 sekitar 45 gr, rounding (bulatkan), saya td dapat 17 bulatan, diamkan sampai mengembang
1. Siapkan loyang (saya pakai uk 20x20) oles tipis dengan mentega
1. Tipiskan/giling adonan td, lalu gulung, dan tekan sedikit (agak pipih), beri satu sisi nyaa bahan olesan lalu susun di loyang
1. Olesi bagian atasnya dengan skm putih, panggang dalam oven yg sdh dipanaskan terlebih dahulu (api sedang / -/+ 160 derajat) tapi semua tergantung oven masing2 yaa
1. Panggang hingga atasnya kecoklatan, setelah itu angkat, biarkan hangat, lalu sobek pelan2 beri bahan olesan disetiap sisinya
1. Selamat mencoba ☺️👌




Demikianlah cara membuat roti sisir jadul (tanpa telur) yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan terbukti, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
