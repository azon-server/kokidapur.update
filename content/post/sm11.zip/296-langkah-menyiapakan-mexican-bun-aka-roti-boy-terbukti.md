---
description: "Langkah menyiapakan Mexican Bun a.k.a Roti Boy Terbukti"
title: "Langkah menyiapakan Mexican Bun a.k.a Roti Boy Terbukti"
slug: 296-langkah-menyiapakan-mexican-bun-aka-roti-boy-terbukti
date: 2020-11-07T16:12:41.223Z
image: https://img-global.cpcdn.com/recipes/2a5b539ddc41d7c7/680x482cq70/mexican-bun-aka-roti-boy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2a5b539ddc41d7c7/680x482cq70/mexican-bun-aka-roti-boy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2a5b539ddc41d7c7/680x482cq70/mexican-bun-aka-roti-boy-foto-resep-utama.jpg
author: Jack Marshall
ratingvalue: 4.5
reviewcount: 28580
recipeingredient:
- "150 gr terigu cakra"
- "150 gr terigu segitiga"
- "1 sdt ragi instan"
- "1 sdt susu bubuk full cream"
- "3 sdm gula pasir"
- "180 ml air hangat suam kuku"
- "30 gr margarin"
- " Topping "
- "1 butir putih telur"
- "50 gr margarin"
- "50 gr terigu segitiga"
- "50 gr gula halus"
- "1/4 sdt baking powder"
- "1 sdt kopi bubuk seduh dg 1 sdm air panas"
- "2 tetes pasta moka"
- " Filling"
- "25 gr margarin"
- "30 gr keju parut"
recipeinstructions:
- "Campur terigu, ragi, gula, susu bubuk. Aduk rata. Lubangi tengahnya. Tuang air hangat."
- "Uleni hingga kalis."
- "Masukkan butter &amp; garam, uleni hingga kalis elastis. Banting2 adonan supaya lbh cepat kalis. Tutup adonan dg kain bersih.Diamkan 30-40 menit (hingga mengembang 2x lipat)."
- "Adonan yg sudah mengembang (gembul banget ini 😁)"
- "Kempiskan adonan, timbang @50 gr, bulatkan (punya saya pas jd 10 pcs)"
- "Buat filling : campur rata keju parut &amp; margarin, bagi mnjd 10 bagian."
- "Setelah adonan dibulatkan, beri filling."
- "Rapikan, tata di atas loyang yg sudah diolesi margarin. Beri jarak yg agak jauh ya, supaya tdk saling nempel saat matang. Lakukan hingga habis."
- "Biarkan mengembang hingga 2x lipat."
- "Sambil menunggu mengembang, bikin topping : kocok putih telur hingga kaku, sisihkan."
- "Kocok margarin &amp; gula halus hingga lembut. Masukkan terigu, bp, kopi yg sudah diseduh. Aduk rata."
- "Masukkan putih telur. Aduk hingga rata atau aduk balik."
- "Masukkan ke dlm piping bag."
- "Gunting sdkt ujungnya. Semprotkan di atas roti dg gerakan melingkar sprt obat nyamuk. Usahakan jarak lingkarannya rapat supaya topping hasilnya rata."
- "Panaskan oven terlebih dahulu. Oven hingga matang (sy pakai otang api bawah ± 45 - 50 menit)."
- "Bila sudah matang, angkat, sajikan. Ini enak dimakan selagi hangat yaa 😍"
- "Kehabisan topping, kurang ke bawah dikit 😁"
- "Fillingnya yummy 😍😍 pake mozarella lbh mantul lg ini 😁"
categories:
- Recipe
tags:
- mexican
- bun
- aka

katakunci: mexican bun aka 
nutrition: 286 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dinner

---


![Mexican Bun a.k.a Roti Boy](https://img-global.cpcdn.com/recipes/2a5b539ddc41d7c7/680x482cq70/mexican-bun-aka-roti-boy-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang harus kita jaga karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti mexican bun a.k.a roti boy yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa ciri khas yang merupakan keragaman Indonesia



Keharmonisan keluarga dapat diperoleh dengan cara simple. Diantaranya adalah membuat makanan Mexican Bun a.k.a Roti Boy untuk keluarga. kebiasaan makan bersama anak sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang bisa anda buat salah satunya mexican bun a.k.a roti boy yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep mexican bun a.k.a roti boy tanpa harus bersusah payah.
Berikut ini resep Mexican Bun a.k.a Roti Boy yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 18 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Mexican Bun a.k.a Roti Boy:

1. Jangan lupa 150 gr terigu cakra
1. Diperlukan 150 gr terigu segitiga
1. Jangan lupa 1 sdt ragi instan
1. Siapkan 1 sdt susu bubuk full cream
1. Diperlukan 3 sdm gula pasir
1. Dibutuhkan 180 ml air hangat suam kuku
1. Diperlukan 30 gr margarin
1. Harus ada  ▪Topping :
1. Diperlukan 1 butir putih telur
1. Jangan lupa 50 gr margarin
1. Harap siapkan 50 gr terigu segitiga
1. Diperlukan 50 gr gula halus
1. Diperlukan 1/4 sdt baking powder
1. Dibutuhkan 1 sdt kopi bubuk seduh dg 1 sdm air panas
1. Jangan lupa 2 tetes pasta moka
1. Harap siapkan  ▪Filling:
1. Siapkan 25 gr margarin
1. Siapkan 30 gr keju parut




<!--inarticleads2-->

##### Langkah membuat  Mexican Bun a.k.a Roti Boy:

1. Campur terigu, ragi, gula, susu bubuk. Aduk rata. Lubangi tengahnya. Tuang air hangat.
1. Uleni hingga kalis.
1. Masukkan butter &amp; garam, uleni hingga kalis elastis. Banting2 adonan supaya lbh cepat kalis. Tutup adonan dg kain bersih.Diamkan 30-40 menit (hingga mengembang 2x lipat).
1. Adonan yg sudah mengembang (gembul banget ini 😁)
1. Kempiskan adonan, timbang @50 gr, bulatkan (punya saya pas jd 10 pcs)
1. Buat filling : campur rata keju parut &amp; margarin, bagi mnjd 10 bagian.
1. Setelah adonan dibulatkan, beri filling.
1. Rapikan, tata di atas loyang yg sudah diolesi margarin. Beri jarak yg agak jauh ya, supaya tdk saling nempel saat matang. Lakukan hingga habis.
1. Biarkan mengembang hingga 2x lipat.
1. Sambil menunggu mengembang, bikin topping : kocok putih telur hingga kaku, sisihkan.
1. Kocok margarin &amp; gula halus hingga lembut. Masukkan terigu, bp, kopi yg sudah diseduh. Aduk rata.
1. Masukkan putih telur. Aduk hingga rata atau aduk balik.
1. Masukkan ke dlm piping bag.
1. Gunting sdkt ujungnya. Semprotkan di atas roti dg gerakan melingkar sprt obat nyamuk. Usahakan jarak lingkarannya rapat supaya topping hasilnya rata.
1. Panaskan oven terlebih dahulu. Oven hingga matang (sy pakai otang api bawah ± 45 - 50 menit).
1. Bila sudah matang, angkat, sajikan. Ini enak dimakan selagi hangat yaa 😍
1. Kehabisan topping, kurang ke bawah dikit 😁
1. Fillingnya yummy 😍😍 pake mozarella lbh mantul lg ini 😁




Demikianlah cara membuat mexican bun a.k.a roti boy yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
