---
description: "Cara menyiapakan Mexican Coffee Bun / Roti Boy / Roti O Luar biasa"
title: "Cara menyiapakan Mexican Coffee Bun / Roti Boy / Roti O Luar biasa"
slug: 431-cara-menyiapakan-mexican-coffee-bun-roti-boy-roti-o-luar-biasa
date: 2021-02-03T05:06:33.570Z
image: https://img-global.cpcdn.com/recipes/9b0ab2f33972629a/680x482cq70/mexican-coffee-bun-roti-boy-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9b0ab2f33972629a/680x482cq70/mexican-coffee-bun-roti-boy-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9b0ab2f33972629a/680x482cq70/mexican-coffee-bun-roti-boy-roti-o-foto-resep-utama.jpg
author: Edwin Bailey
ratingvalue: 4.7
reviewcount: 10018
recipeingredient:
- " Bahan Topping"
- "100 gr butter"
- "70-80 gr gula halus"
- "1 butir telur ukuran sedang"
- "1 bungkus coffee mix instan larutkan dengan 12 sdm air hangat"
- "100 gr tepung terigu ayak"
- " Bahan Roti"
- "250 gr tepung protein tinggi"
- "5 gr ragi instan"
- "1 sdm susu bubuk"
- "50 gr gula pasir"
- "1 butir telur"
- "90-110 ml air dingin  susu cair sesuaikan adonan msg2"
- "25 gr mentega"
- " Bahan isian"
- "Secukupnya butter  keju  cokelat"
recipeinstructions:
- "Buat topping lebih dulu. Mixer butter dan gula sampai mengembang, lalu masukkan telur secara bertahap. Masukkan kopi, terakhir masukkan tepung. Aduk sampai benar-benar tercampur rata. Masukkan ke piping bag / plastik segitiga, simpan dalam lemari pendingin. Keluarkan 30 menit sebelum digunakan"
- "Buat adonan Roti : Campur semua bahan kering lalu masukkan telur diikuti dengan air dingin / susu cair. Uleni hingga setengah kalis. Lalu masukkan butter / mentega, uleni hingga kalis elastis"
- "Diamkan adonan hingga mengembang 2x lipat (± 30 menit). Lalu bagi adonan (saya bagi jadi 8), bulatkan. Ambil 1 bulatan lalu pipihkan adonan (hati2 jgn terlalu tipis agar tidak pecah atau luber) dan beri isian (saya hanya mentega dan spready cheese), bulatkan dan rapatkan kembali. Ulangi hingga adonan habis kemudian diamkan kembali sampai mengembang 2x lipat"
- "Panaskan oven, semprot adonan dengan topping yang sudah kita siapkan tadi. Semprot melingkar dari bagian tengah atas sampai ¾ adonan. Lakukan pada semua adonan roti. Panggang dalam oven pada suhu 180°C selama 25-30 menit (sesuaikan oven masing-masing)"
- "Setelah matang, dinginkan di colling rack agar roti tidak lembab bagian bawahnya. Siap dimakan saat hangat"
categories:
- Recipe
tags:
- mexican
- coffee
- bun

katakunci: mexican coffee bun 
nutrition: 254 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Dessert

---


![Mexican Coffee Bun / Roti Boy / Roti O](https://img-global.cpcdn.com/recipes/9b0ab2f33972629a/680x482cq70/mexican-coffee-bun-roti-boy-roti-o-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau renyah. Ciri masakan Nusantara mexican coffee bun / roti boy / roti o yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga bisa diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Mexican Coffee Bun / Roti Boy / Roti O untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang bisa anda contoh salah satunya mexican coffee bun / roti boy / roti o yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep mexican coffee bun / roti boy / roti o tanpa harus bersusah payah.
Berikut ini resep Mexican Coffee Bun / Roti Boy / Roti O yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Mexican Coffee Bun / Roti Boy / Roti O:

1. Dibutuhkan  Bahan Topping
1. Harus ada 100 gr butter
1. Harus ada 70-80 gr gula halus
1. Dibutuhkan 1 butir telur ukuran sedang
1. Harus ada 1 bungkus coffee mix instan (larutkan dengan 1-2 sdm air hangat)
1. Dibutuhkan 100 gr tepung terigu, ayak
1. Tambah  Bahan Roti
1. Dibutuhkan 250 gr tepung protein tinggi
1. Harap siapkan 5 gr ragi instan
1. Tambah 1 sdm susu bubuk
1. Diperlukan 50 gr gula pasir
1. Diperlukan 1 butir telur
1. Harap siapkan 90-110 ml air dingin / susu cair (sesuaikan adonan msg2)
1. Tambah 25 gr mentega
1. Harap siapkan  Bahan isian
1. Dibutuhkan Secukupnya butter / keju / cokelat




<!--inarticleads2-->

##### Bagaimana membuat  Mexican Coffee Bun / Roti Boy / Roti O:

1. Buat topping lebih dulu. Mixer butter dan gula sampai mengembang, lalu masukkan telur secara bertahap. Masukkan kopi, terakhir masukkan tepung. Aduk sampai benar-benar tercampur rata. Masukkan ke piping bag / plastik segitiga, simpan dalam lemari pendingin. Keluarkan 30 menit sebelum digunakan
1. Buat adonan Roti : Campur semua bahan kering lalu masukkan telur diikuti dengan air dingin / susu cair. Uleni hingga setengah kalis. Lalu masukkan butter / mentega, uleni hingga kalis elastis
1. Diamkan adonan hingga mengembang 2x lipat (± 30 menit). Lalu bagi adonan (saya bagi jadi 8), bulatkan. Ambil 1 bulatan lalu pipihkan adonan (hati2 jgn terlalu tipis agar tidak pecah atau luber) dan beri isian (saya hanya mentega dan spready cheese), bulatkan dan rapatkan kembali. Ulangi hingga adonan habis kemudian diamkan kembali sampai mengembang 2x lipat
1. Panaskan oven, semprot adonan dengan topping yang sudah kita siapkan tadi. Semprot melingkar dari bagian tengah atas sampai ¾ adonan. Lakukan pada semua adonan roti. Panggang dalam oven pada suhu 180°C selama 25-30 menit (sesuaikan oven masing-masing)
1. Setelah matang, dinginkan di colling rack agar roti tidak lembab bagian bawahnya. Siap dimakan saat hangat




Demikianlah cara membuat mexican coffee bun / roti boy / roti o yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
