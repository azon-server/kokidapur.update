---
description: "Langkah untuk menyiapakan Roti O / Roti Boy / Mexican Bun Homemade"
title: "Langkah untuk menyiapakan Roti O / Roti Boy / Mexican Bun Homemade"
slug: 408-langkah-untuk-menyiapakan-roti-o-roti-boy-mexican-bun-homemade
date: 2020-10-18T00:42:19.687Z
image: https://img-global.cpcdn.com/recipes/079e4fd18bfd4e0b/680x482cq70/roti-o-roti-boy-mexican-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/079e4fd18bfd4e0b/680x482cq70/roti-o-roti-boy-mexican-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/079e4fd18bfd4e0b/680x482cq70/roti-o-roti-boy-mexican-bun-foto-resep-utama.jpg
author: Nettie Phillips
ratingvalue: 4.1
reviewcount: 13679
recipeingredient:
- "22 sdm tepung terigu pro tinggi"
- "5 sdm Gula Pasir"
- "1 butir telur"
- "1 sdt ragi"
- "100 ml air susu cair"
- "2 sdm mentegamargarin"
- "2 sdm susu bubuk"
- " Toping "
- "7 sdm terigu"
- "3 sdm mentegamargarin"
- "2 sdm gula halus sy pake gula halus"
- "1/2 sdt baking powder"
- "1 telur"
- "5 sdm air kopi yg sdh diseduh"
- " Secukupnya pasta moka bisa skip"
- " Isian  mentega saya pke keju melt Atau suka2 ya"
recipeinstructions:
- "Campur tepung terigu, telur, gula, dan ragi. aduk rata. Masukkan air / susu cair sedikit demi sedikit sambil diulen sampai setengah kalis. Setelah setengah kalis campurkan dg garam dan margarin. Ulen lagi sampai kalis. Lalu istirahatkan adonan sampai mengembang 2x lipat. Tutup dg serbet"
- "Setelah mengembang bagi adonan @55 gram. Pipihkan dan beri isian kemudian bulat2kan lagi. lalu diamkan lagi hingga mengembang 2x lipat"
- "Buat pasta/toping. Masukkan semua bahan topping lalu aduk rata. Saya pake sendok 😆 aduk smpai semua rata dan tdk bergerindil. Masukkan ke plastik apa aja yg dimiliki 😆 klo ada plastik segitiga pakai plastik segitiga. Saya ga ada. Jd pake plastik biasa hehehe"
- "Setelah adonan slsai diistirahatkan. Beri toping seperti motif obat nyamuk diatasnya sampai 1/2 bagian lebih dikit"
- "Kemudian oven. Sy pakai suhu 180 selama 17 menit. disesuaikan dg oven msing2 ya"
- "Jadii"
- ""
categories:
- Recipe
tags:
- roti
- o
- 

katakunci: roti o  
nutrition: 114 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Dinner

---


![Roti O / Roti Boy / Mexican Bun](https://img-global.cpcdn.com/recipes/079e4fd18bfd4e0b/680x482cq70/roti-o-roti-boy-mexican-bun-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti roti o / roti boy / mexican bun yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan ciri khas yang merupakan keragaman Nusantara



Kehangatan rumah tangga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Roti O / Roti Boy / Mexican Bun untuk orang di rumah. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang dapat anda contoh salah satunya roti o / roti boy / mexican bun yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep roti o / roti boy / mexican bun tanpa harus bersusah payah.
Berikut ini resep Roti O / Roti Boy / Mexican Bun yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti O / Roti Boy / Mexican Bun:

1. Harap siapkan 22 sdm tepung terigu pro tinggi
1. Tambah 5 sdm Gula Pasir
1. Diperlukan 1 butir telur
1. Diperlukan 1 sdt ragi
1. Jangan lupa 100 ml air/ susu cair
1. Harap siapkan 2 sdm mentega/margarin
1. Harus ada 2 sdm susu bubuk
1. Jangan lupa  Toping :
1. Harus ada 7 sdm terigu
1. Harap siapkan 3 sdm mentega/margarin
1. Harap siapkan 2 sdm gula halus (sy pake gula halus)
1. Harap siapkan 1/2 sdt baking powder
1. Jangan lupa 1 telur
1. Harap siapkan 5 sdm air kopi yg sdh diseduh
1. Harus ada  Secukupnya pasta moka (bisa skip)
1. Tambah  Isian : mentega (saya pke keju melt). Atau suka2 ya




<!--inarticleads2-->

##### Cara membuat  Roti O / Roti Boy / Mexican Bun:

1. Campur tepung terigu, telur, gula, dan ragi. aduk rata. Masukkan air / susu cair sedikit demi sedikit sambil diulen sampai setengah kalis. Setelah setengah kalis campurkan dg garam dan margarin. Ulen lagi sampai kalis. Lalu istirahatkan adonan sampai mengembang 2x lipat. Tutup dg serbet
1. Setelah mengembang bagi adonan @55 gram. Pipihkan dan beri isian kemudian bulat2kan lagi. lalu diamkan lagi hingga mengembang 2x lipat
1. Buat pasta/toping. Masukkan semua bahan topping lalu aduk rata. Saya pake sendok 😆 aduk smpai semua rata dan tdk bergerindil. Masukkan ke plastik apa aja yg dimiliki 😆 klo ada plastik segitiga pakai plastik segitiga. Saya ga ada. Jd pake plastik biasa hehehe
1. Setelah adonan slsai diistirahatkan. Beri toping seperti motif obat nyamuk diatasnya sampai 1/2 bagian lebih dikit
1. Kemudian oven. Sy pakai suhu 180 selama 17 menit. disesuaikan dg oven msing2 ya
1. Jadii
1. 




Demikianlah cara membuat roti o / roti boy / mexican bun yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan teruji, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
