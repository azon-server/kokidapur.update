---
description: "Resep : Roti o Luar biasa"
title: "Resep : Roti o Luar biasa"
slug: 470-resep-roti-o-luar-biasa
date: 2020-09-25T01:11:57.116Z
image: https://img-global.cpcdn.com/recipes/59adb1cd19fe1553/680x482cq70/roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/59adb1cd19fe1553/680x482cq70/roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/59adb1cd19fe1553/680x482cq70/roti-o-foto-resep-utama.jpg
author: Myrtie Cannon
ratingvalue: 4.5
reviewcount: 42895
recipeingredient:
- "275 ml susu hangat"
- "80 gr gula pasir"
- "11 gr ragi"
- "1 kng telur"
- "1 telur utuh"
- "550 gr tepung cakra"
- "2 sdt garam"
- "50 gr butter"
- " isi parutan keju dan butter"
- " nescave mixture"
- "1 sashet nescafe"
- "1 sdt kopi pait"
- "15 ml air panas"
- " bahan kopi "
- "90 gr butter"
- "100 gr gula halus"
- " nescafe mixture"
- "1 btr telur utuh"
- "85 gram tepung terigu"
- "2 sdm susu bubuk"
recipeinstructions:
- "Buat biang: campur air hangat,ragi san gula biarkan sampai berbuih."
- "Masukkan telur aduk tamabhkan tepung ulen sampai rata... baru masukan butter dan garam ulen sampai kalis elastis"
- "Biarkan adonan sampai ngembang 2x lipat.. lalu buat nescave mixture nya...tinggal campur aduk rata sisihkan."
- "Buat bahan kopi mix butter,gula halus,nescave mixture tambah 1 telur.tepung terigu dan susu bubuk...mixer sampai tercampur rata"
- "Masukkak ke plastik segitiga"
- "Adonan yg sudh ngembang 2x lipat... saya timbang @50 gr langsung isi dengan campuran butter dan keju parut...harus benar2 di lipat dan bulatkan yg rapi supaya pas di panggang tidak bocor.proofing sekali lgi"
- "Setelah mengembang beri topping kopi yg sudh di buat tadi"
- "Siap di panggang di suhu 180°c 20 mnt"
- ""
- "Sisa adonannya aq buat roti isi suka2..."
- "Enjoy"
categories:
- Recipe
tags:
- roti
- o

katakunci: roti o 
nutrition: 208 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Lunch

---


![Roti o](https://img-global.cpcdn.com/recipes/59adb1cd19fe1553/680x482cq70/roti-o-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis dan gurih. Karasteristik masakan Indonesia roti o yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga bisa didapat dengan cara sederhana. Salah satunya adalah membuat makanan Roti o untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang dapat anda contoh salah satunya roti o yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep roti o tanpa harus bersusah payah.
Berikut ini resep Roti o yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 11 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti o:

1. Siapkan 275 ml susu hangat
1. Tambah 80 gr gula pasir
1. Diperlukan 11 gr ragi
1. Harap siapkan 1 kng telur
1. Diperlukan 1 telur utuh
1. Tambah 550 gr tepung cakra
1. Jangan lupa 2 sdt garam
1. Tambah 50 gr butter
1. Tambah  isi: parutan keju dan butter
1. Jangan lupa  nescave mixture:
1. Dibutuhkan 1 sashet nescafe
1. Dibutuhkan 1 sdt kopi pait
1. Siapkan 15 ml air panas
1. Tambah  bahan kopi :
1. Harap siapkan 90 gr butter
1. Jangan lupa 100 gr gula halus
1. Harus ada  nescafe mixture
1. Harap siapkan 1 btr telur utuh
1. Jangan lupa 85 gram tepung terigu
1. Diperlukan 2 sdm susu bubuk




<!--inarticleads2-->

##### Instruksi membuat  Roti o:

1. Buat biang: campur air hangat,ragi san gula biarkan sampai berbuih.
1. Masukkan telur aduk tamabhkan tepung ulen sampai rata... baru masukan butter dan garam ulen sampai kalis elastis
1. Biarkan adonan sampai ngembang 2x lipat.. lalu buat nescave mixture nya...tinggal campur aduk rata sisihkan.
1. Buat bahan kopi mix butter,gula halus,nescave mixture tambah 1 telur.tepung terigu dan susu bubuk...mixer sampai tercampur rata
1. Masukkak ke plastik segitiga
1. Adonan yg sudh ngembang 2x lipat... saya timbang @50 gr langsung isi dengan campuran butter dan keju parut...harus benar2 di lipat dan bulatkan yg rapi supaya pas di panggang tidak bocor.proofing sekali lgi
1. Setelah mengembang beri topping kopi yg sudh di buat tadi
1. Siap di panggang di suhu 180°c 20 mnt
1. 
1. Sisa adonannya aq buat roti isi suka2...
1. Enjoy




Demikianlah cara membuat roti o yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan teruji, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
