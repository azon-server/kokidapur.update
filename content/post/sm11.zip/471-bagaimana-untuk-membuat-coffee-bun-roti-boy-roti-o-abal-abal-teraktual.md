---
description: "Bagaimana untuk membuat Coffee bun /roti boy/roti O abal-abal teraktual"
title: "Bagaimana untuk membuat Coffee bun /roti boy/roti O abal-abal teraktual"
slug: 471-bagaimana-untuk-membuat-coffee-bun-roti-boy-roti-o-abal-abal-teraktual
date: 2020-10-16T08:38:13.359Z
image: https://img-global.cpcdn.com/recipes/fe10572bc122d370/680x482cq70/coffee-bun-roti-boyroti-o-abal-abal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fe10572bc122d370/680x482cq70/coffee-bun-roti-boyroti-o-abal-abal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fe10572bc122d370/680x482cq70/coffee-bun-roti-boyroti-o-abal-abal-foto-resep-utama.jpg
author: Ellen Nunez
ratingvalue: 4.1
reviewcount: 14326
recipeingredient:
- "250 gram tepung terigu"
- "1 sdt fermipan"
- "50 gram gula pasir"
- "20 gram susu bubuk"
- "1 butir telur"
- "secukupnya air  saya 70 ml"
- "50 gram margarine"
- " isian"
- "100 gram butter beku potong 8"
- " topping"
- "50 gram butter"
- "40 gram gula halus"
- "1 putih telur"
- "1 sachet kopi instant seduh dengan 1 sdm air panas"
- "40 gram tepung terigu protein rendah"
- "30 gram tepung beras"
- "1/2 sdt pasta moka"
recipeinstructions:
- "Campur terigu, hula, ragi, susu bubuk lalu tambahkan telur dan air secukupnya"
- "Uleni sebentar lalu tambahkan margarine"
- "Uleni sampai kalis elastis"
- "Tunggu hingga mengembang dua kali lipat"
- "Sementara menunggu proofing, buat toppingnya"
- "Kocok 50 gram butter dengan 40 gram gula halus sampai lembut"
- "Tambahkan kopi dam putih telur lalu kocok rata"
- "Tambahkan tepung terigu dan tepung beras kocok rata"
- "Tambahkan pasta moka dan kocok rata lalu masukkan topping ke piping bag"
- "Setelah adonan roti mengembang, kempiskan lalu bagi menjadi delapan bagian"
- "Isi dengan butter beku lalu bulatkan dan tata dalam loyang"
- "Lakukan proofing kedua, tunggu sampai mengembang"
- "Spuitkan adonan topping melingkar ke atas roti"
- "Panggang roti hingga matang"
- "Selamat mencoba"
categories:
- Recipe
tags:
- coffee
- bun
- roti

katakunci: coffee bun roti 
nutrition: 134 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Dessert

---


![Coffee bun /roti boy/roti O abal-abal](https://img-global.cpcdn.com/recipes/fe10572bc122d370/680x482cq70/coffee-bun-roti-boyroti-o-abal-abal-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti coffee bun /roti boy/roti o abal-abal yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa ciri khas yang merupakan keragaman Nusantara



Kehangatan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak Coffee bun /roti boy/roti O abal-abal untuk keluarga. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang dapat anda coba salah satunya coffee bun /roti boy/roti o abal-abal yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep coffee bun /roti boy/roti o abal-abal tanpa harus bersusah payah.
Berikut ini resep Coffee bun /roti boy/roti O abal-abal yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 bahan dan 15 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Coffee bun /roti boy/roti O abal-abal:

1. Siapkan 250 gram tepung terigu
1. Harap siapkan 1 sdt fermipan
1. Harap siapkan 50 gram gula pasir
1. Siapkan 20 gram susu bubuk
1. Harus ada 1 butir telur
1. Harus ada secukupnya air  (saya: 70 ml)
1. Diperlukan 50 gram margarine
1. Jangan lupa  isian:
1. Tambah 100 gram butter beku (potong 8)
1. Diperlukan  topping:
1. Diperlukan 50 gram butter
1. Jangan lupa 40 gram gula halus
1. Harap siapkan 1 putih telur
1. Jangan lupa 1 sachet kopi instant, seduh dengan 1 sdm air panas
1. Harus ada 40 gram tepung terigu protein rendah
1. Dibutuhkan 30 gram tepung beras
1. Harus ada 1/2 sdt pasta moka




<!--inarticleads2-->

##### Instruksi membuat  Coffee bun /roti boy/roti O abal-abal:

1. Campur terigu, hula, ragi, susu bubuk lalu tambahkan telur dan air secukupnya
1. Uleni sebentar lalu tambahkan margarine
1. Uleni sampai kalis elastis
1. Tunggu hingga mengembang dua kali lipat
1. Sementara menunggu proofing, buat toppingnya
1. Kocok 50 gram butter dengan 40 gram gula halus sampai lembut
1. Tambahkan kopi dam putih telur lalu kocok rata
1. Tambahkan tepung terigu dan tepung beras kocok rata
1. Tambahkan pasta moka dan kocok rata lalu masukkan topping ke piping bag
1. Setelah adonan roti mengembang, kempiskan lalu bagi menjadi delapan bagian
1. Isi dengan butter beku lalu bulatkan dan tata dalam loyang
1. Lakukan proofing kedua, tunggu sampai mengembang
1. Spuitkan adonan topping melingkar ke atas roti
1. Panggang roti hingga matang
1. Selamat mencoba




Demikianlah cara membuat coffee bun /roti boy/roti o abal-abal yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat gampang dan teruji, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
