---
description: "Resep : Coffee bun/ Roti O&amp;#39;/ Rotiboy/ Mexican bun Homemade"
title: "Resep : Coffee bun/ Roti O&amp;#39;/ Rotiboy/ Mexican bun Homemade"
slug: 345-resep-coffee-bun-roti-o-and-39-rotiboy-mexican-bun-homemade
date: 2021-01-31T06:43:41.190Z
image: https://img-global.cpcdn.com/recipes/37eb060456c5a0c2/680x482cq70/coffee-bun-roti-o-rotiboy-mexican-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/37eb060456c5a0c2/680x482cq70/coffee-bun-roti-o-rotiboy-mexican-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/37eb060456c5a0c2/680x482cq70/coffee-bun-roti-o-rotiboy-mexican-bun-foto-resep-utama.jpg
author: Eunice Pena
ratingvalue: 4.2
reviewcount: 19045
recipeingredient:
- " Bahan A"
- "300 gr tepung terigu protein tinggi"
- "50 gr gula pasir"
- "7 gr ragi instan"
- "100 gr susu cair"
- "100 gr whipping cream cair bisa diganti susu cair"
- " Bahan B"
- "65 gr butter"
- "1/2 sdt garam"
- " Bahan isian"
- "25 gr butter"
- "25 gr keju cheddar parut"
- "2 sdm gula halus"
- " Bahan topping"
- "70 gr butter"
- "35 gr gula halus"
- "1 butir telur"
- "1 bks kopi sachet larutkan dengan 2sdm air panas"
- "70 gr terigu"
recipeinstructions:
- "Campur semua bahan A jadi satu lalu uleni/mixer hingga 1/2 kalis. Tambahkan bahan B. Mixer sampai kalis elastis."
- "Setelah kalis, bulatkan dan tutup dough. Biarkan hingga mengembang 2x lipat selama -/+ 45mnt"
- "Setelah mengembang, kempiskan dough lalu bagi&#34; adonan @60gr. Bulatkan lalu tutup istirahatkan kembali selama 15menit."
- "Sambil bikian isian ya.. campurkan semua bahan isian. Aduk rata. Sisihkan."
- "Lalu kita buat toppingnya dulu. Campur butter dan gula halus aduk rata menggunakan whisk. Lalu tambahkan telur dan kopi, aduk rata kembali. Lalu tambahkan kopi yang sudah diseduh. Aduk rata. Taruh di plastik segitiga."
- "Ambil 1 bulatan dough, pipihkan dengan rolling pin. Isi dengan isian. Tutup hingga mengembang lagi, lalu beri topping dengan melingkar dan rata seperti obat nyamuk."
- "Panggang dengan suhu 200 api atas bawah selama 25menit (sesuaikan oven masing2 ya..). Oiya, jangan lupa oven harus sudah dipanaskan sebelumny +/- 15 menit."
- "Keluarkan dari oven dan sajikan. Enak pas anget2 langsung dimakan. Tapi dimakan suhu ruangan pun tetep enak kok. Karena tekstur rotinya empukk dan lembut. Semoga bermanfaat ya.."
categories:
- Recipe
tags:
- coffee
- bun
- roti

katakunci: coffee bun roti 
nutrition: 256 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT30M"
recipeyield: "3"
recipecategory: Dinner

---


![Coffee bun/ Roti O&#39;/ Rotiboy/ Mexican bun](https://img-global.cpcdn.com/recipes/37eb060456c5a0c2/680x482cq70/coffee-bun-roti-o-rotiboy-mexican-bun-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan gurih. Karasteristik kuliner Nusantara coffee bun/ roti o&#39;/ rotiboy/ mexican bun yang penuh dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah memasak Coffee bun/ Roti O&#39;/ Rotiboy/ Mexican bun untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang dapat anda contoh salah satunya coffee bun/ roti o&#39;/ rotiboy/ mexican bun yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep coffee bun/ roti o&#39;/ rotiboy/ mexican bun tanpa harus bersusah payah.
Seperti resep Coffee bun/ Roti O&#39;/ Rotiboy/ Mexican bun yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 19 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Coffee bun/ Roti O&#39;/ Rotiboy/ Mexican bun:

1. Tambah  Bahan A:
1. Harus ada 300 gr tepung terigu protein tinggi
1. Diperlukan 50 gr gula pasir
1. Dibutuhkan 7 gr ragi instan
1. Harus ada 100 gr susu cair
1. Dibutuhkan 100 gr whipping cream cair/ bisa diganti susu cair
1. Harap siapkan  Bahan B:
1. Jangan lupa 65 gr butter
1. Diperlukan 1/2 sdt garam
1. Diperlukan  Bahan isian:
1. Siapkan 25 gr butter
1. Harap siapkan 25 gr keju cheddar, parut
1. Tambah 2 sdm gula halus
1. Harap siapkan  Bahan topping:
1. Siapkan 70 gr butter
1. Siapkan 35 gr gula halus
1. Tambah 1 butir telur
1. Dibutuhkan 1 bks kopi sachet larutkan dengan 2sdm air panas
1. Harus ada 70 gr terigu




<!--inarticleads2-->

##### Cara membuat  Coffee bun/ Roti O&#39;/ Rotiboy/ Mexican bun:

1. Campur semua bahan A jadi satu lalu uleni/mixer hingga 1/2 kalis. Tambahkan bahan B. Mixer sampai kalis elastis.
1. Setelah kalis, bulatkan dan tutup dough. Biarkan hingga mengembang 2x lipat selama -/+ 45mnt
1. Setelah mengembang, kempiskan dough lalu bagi&#34; adonan @60gr. Bulatkan lalu tutup istirahatkan kembali selama 15menit.
1. Sambil bikian isian ya.. campurkan semua bahan isian. Aduk rata. Sisihkan.
1. Lalu kita buat toppingnya dulu. Campur butter dan gula halus aduk rata menggunakan whisk. Lalu tambahkan telur dan kopi, aduk rata kembali. Lalu tambahkan kopi yang sudah diseduh. Aduk rata. Taruh di plastik segitiga.
1. Ambil 1 bulatan dough, pipihkan dengan rolling pin. Isi dengan isian. Tutup hingga mengembang lagi, lalu beri topping dengan melingkar dan rata seperti obat nyamuk.
1. Panggang dengan suhu 200 api atas bawah selama 25menit (sesuaikan oven masing2 ya..). Oiya, jangan lupa oven harus sudah dipanaskan sebelumny +/- 15 menit.
1. Keluarkan dari oven dan sajikan. Enak pas anget2 langsung dimakan. Tapi dimakan suhu ruangan pun tetep enak kok. Karena tekstur rotinya empukk dan lembut. Semoga bermanfaat ya..




Demikianlah cara membuat coffee bun/ roti o&#39;/ rotiboy/ mexican bun yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan terbukti, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
