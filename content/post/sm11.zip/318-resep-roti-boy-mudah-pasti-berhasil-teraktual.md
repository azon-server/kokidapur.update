---
description: "Resep : Roti boy (mudah, pasti berhasil) teraktual"
title: "Resep : Roti boy (mudah, pasti berhasil) teraktual"
slug: 318-resep-roti-boy-mudah-pasti-berhasil-teraktual
date: 2020-12-15T03:19:25.635Z
image: https://img-global.cpcdn.com/recipes/a6fcf6b2765ba29f/680x482cq70/roti-boy-mudah-pasti-berhasil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a6fcf6b2765ba29f/680x482cq70/roti-boy-mudah-pasti-berhasil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a6fcf6b2765ba29f/680x482cq70/roti-boy-mudah-pasti-berhasil-foto-resep-utama.jpg
author: Evelyn Luna
ratingvalue: 4.6
reviewcount: 24255
recipeingredient:
- " bahan roti "
- "260 gr terigu"
- "30 gr gula pasir"
- "3 gr ragi"
- "30 gr butter"
- "180 cc 1 telur  susu full creamair"
- "2 gr garam"
- " bahan topping "
- "80 gr butter"
- "80 gr gula halus"
- "1 btr telur kecil"
- "80 gr terigu ayak"
- "16 maizena ayak"
- "2 sdm bubuk kopi larutkan dgn sedikit air"
- "1 tetes essens mocca"
- "sedikit garam"
- " bahan isi"
- "secukupnya butter"
recipeinstructions:
- "Siapkan loyang yang sudah dialasi baking paper"
- "Bahan roti : aduk rata semua bahan (kecuali ggaram &amp; butter). Tuang campuran susu &amp; telur sedikit demi sedikit, uleni adonan hingga kalis. Sesudah kalis tambah butter &amp; garam uleni lagi sampai kalis elastis."
- "Bagi adonan menjadi 8 bagian, jika ingin ukuran lebih kecil bagi menjadi 12 - 13 bagian."
- "Potong kotak2 butter"
- "Simpan butter dalam adonan, bulatkan dan cubit2 bagian bawah adonan agar butter tidak keluar setelah meleleh. Simpan diatas loyang"
- "Istirahatkan min 1 jam tutup dengan serbet, adonan akan mengembang 2x lipat"
- "Sambil menunggu adonan mengembang, kita buat toppingnya."
- "Mixer margarin &amp; gula halus hingga gula tercampur rata"
- "Masukkan putih telur &amp; garam lalu mixer kembali dengan kecepatan tinggi hingga mengembang"
- "Masukkan terigu &amp; meizena, aduk rata menggunakan spatula"
- "Beri tetesan mocca &amp; larutan kopi, aduk hingga rata"
- "Masukkan dalam pipping bag"
- "Pre heat oven 180°c"
- "Semprotkan topping diatas adonan yang sudah mengembang dgn bentuk melingkar. Beri jarak setiap adonan, jangan terlalu berdekatan, karna akan mengembang."
- "Masukkan oven 180°c selama 25-30 menit."
- "Bagian dalam roti"
categories:
- Recipe
tags:
- roti
- boy
- mudah

katakunci: roti boy mudah 
nutrition: 230 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Dessert

---


![Roti boy (mudah, pasti berhasil)](https://img-global.cpcdn.com/recipes/a6fcf6b2765ba29f/680x482cq70/roti-boy-mudah-pasti-berhasil-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan enak. Karasteristik makanan Nusantara roti boy (mudah, pasti berhasil) yang kaya dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah memasak Roti boy (mudah, pasti berhasil) untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang dapat anda buat salah satunya roti boy (mudah, pasti berhasil) yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep roti boy (mudah, pasti berhasil) tanpa harus bersusah payah.
Berikut ini resep Roti boy (mudah, pasti berhasil) yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 16 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti boy (mudah, pasti berhasil):

1. Diperlukan  bahan roti :
1. Tambah 260 gr terigu
1. Jangan lupa 30 gr gula pasir
1. Jangan lupa 3 gr ragi
1. Harus ada 30 gr butter
1. Tambah 180 cc (1 telur + susu full cream/air)
1. Siapkan 2 gr garam
1. Tambah  bahan topping :
1. Siapkan 80 gr butter
1. Dibutuhkan 80 gr gula halus
1. Tambah 1 btr telur kecil
1. Tambah 80 gr terigu (ayak)
1. Harus ada 16 maizena (ayak)
1. Tambah 2 sdm bubuk kopi (larutkan dgn sedikit air)
1. Jangan lupa 1 tetes essens mocca
1. Diperlukan sedikit garam
1. Jangan lupa  bahan isi:
1. Tambah secukupnya butter




<!--inarticleads2-->

##### Cara membuat  Roti boy (mudah, pasti berhasil):

1. Siapkan loyang yang sudah dialasi baking paper
1. Bahan roti : aduk rata semua bahan (kecuali ggaram &amp; butter). Tuang campuran susu &amp; telur sedikit demi sedikit, uleni adonan hingga kalis. Sesudah kalis tambah butter &amp; garam uleni lagi sampai kalis elastis.
1. Bagi adonan menjadi 8 bagian, jika ingin ukuran lebih kecil bagi menjadi 12 - 13 bagian.
1. Potong kotak2 butter
1. Simpan butter dalam adonan, bulatkan dan cubit2 bagian bawah adonan agar butter tidak keluar setelah meleleh. Simpan diatas loyang
1. Istirahatkan min 1 jam tutup dengan serbet, adonan akan mengembang 2x lipat
1. Sambil menunggu adonan mengembang, kita buat toppingnya.
1. Mixer margarin &amp; gula halus hingga gula tercampur rata
1. Masukkan putih telur &amp; garam lalu mixer kembali dengan kecepatan tinggi hingga mengembang
1. Masukkan terigu &amp; meizena, aduk rata menggunakan spatula
1. Beri tetesan mocca &amp; larutan kopi, aduk hingga rata
1. Masukkan dalam pipping bag
1. Pre heat oven 180°c
1. Semprotkan topping diatas adonan yang sudah mengembang dgn bentuk melingkar. Beri jarak setiap adonan, jangan terlalu berdekatan, karna akan mengembang.
1. Masukkan oven 180°c selama 25-30 menit.
1. Bagian dalam roti




Demikianlah cara membuat roti boy (mudah, pasti berhasil) yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan cepat, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
