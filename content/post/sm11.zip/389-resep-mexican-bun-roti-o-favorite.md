---
description: "Resep : Mexican Bun / Roti O Favorite"
title: "Resep : Mexican Bun / Roti O Favorite"
slug: 389-resep-mexican-bun-roti-o-favorite
date: 2020-09-15T19:31:30.750Z
image: https://img-global.cpcdn.com/recipes/0fb0e90fe994208e/680x482cq70/mexican-bun-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0fb0e90fe994208e/680x482cq70/mexican-bun-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0fb0e90fe994208e/680x482cq70/mexican-bun-roti-o-foto-resep-utama.jpg
author: Hattie Larson
ratingvalue: 4.3
reviewcount: 31841
recipeingredient:
- " Bahan Roti"
- "15 gr tepung terigu untuk pasta Tang Zhong"
- "250 gr tepung cakra"
- "50 gr gula pasir"
- "6 gr ragi"
- " Bahan Filling isian"
- "100 gr margarin"
- "70 gr gula pasir  gula halus"
- "Secukupnya keju"
- " Bahan Topping"
- "100 gr tepung terigu"
- "100 gr margarin"
- "1 sachet luwak white coffee"
- "3 sdm gula pasir  gula halus"
- "1/2 sdt garam"
- "Secukupnya vanilli"
- "Secukupnya air hangat"
recipeinstructions:
- "Buat pasta Tang Zhong sebagai bahan dasar roti dengan memanaskan 15 gr tepung terigu dan 75 ml air diatas api kecil dan diaduk hingga mengental membentuk pasta, mulai meletup dan berubah warna menjadi kelabu. Biarkan hingga dingin."
- "Campurkan bahan roti dan pasta Tang Zhong kedalam wadah dan mixer / uleni hingga kalis dan elastis. Tutup adonan dengan kain selama 45 - 60 menit hingga mengembang dua kali lipat."
- "Siapkan bahan isian dengan mencampur margarin, gula dan parutan keju secukupnya. Mixer dengan kecepatan sedang."
- "Buat topping dengan mencampurkan tepung terigu, margarin, gula, garam, vanili, luwak white coffee, tambahkan air hangat secukupnya agar adonan tidak terlalu padat. Mixer atau aduk selama beberapa menit hingga tercampur rata."
- "Kempeskan adonan, bagi adonan menjadi beberapa bagian dan isi dengan isian roti. Bulatkan adonan dan diamkan beberapa menit hingga mengembang. Siapkan plastik untuk menempatkan topping dan berukan keatas roti dengan teknik memutar."
- "Panggang dengan suhu 180 derajat celsius selama kurang lebih 15 menit hingga bagian topping matang / mengering."
categories:
- Recipe
tags:
- mexican
- bun
- 

katakunci: mexican bun  
nutrition: 173 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Lunch

---


![Mexican Bun / Roti O](https://img-global.cpcdn.com/recipes/0fb0e90fe994208e/680x482cq70/mexican-bun-roti-o-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan renyah. Ciri khas kuliner Nusantara mexican bun / roti o yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga dapat diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Mexican Bun / Roti O untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang bisa anda praktekkan salah satunya mexican bun / roti o yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep mexican bun / roti o tanpa harus bersusah payah.
Seperti resep Mexican Bun / Roti O yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Mexican Bun / Roti O:

1. Tambah  Bahan Roti
1. Siapkan 15 gr tepung terigu (untuk pasta Tang Zhong)
1. Dibutuhkan 250 gr tepung cakra
1. Dibutuhkan 50 gr gula pasir
1. Harus ada 6 gr ragi
1. Diperlukan  Bahan Filling (isian)
1. Harap siapkan 100 gr margarin
1. Siapkan 70 gr gula pasir / gula halus
1. Siapkan Secukupnya keju
1. Jangan lupa  Bahan Topping
1. Jangan lupa 100 gr tepung terigu
1. Harus ada 100 gr margarin
1. Harus ada 1 sachet luwak white coffee
1. Harap siapkan 3 sdm gula pasir / gula halus
1. Harus ada 1/2 sdt garam
1. Diperlukan Secukupnya vanilli
1. Tambah Secukupnya air hangat




<!--inarticleads2-->

##### Langkah membuat  Mexican Bun / Roti O:

1. Buat pasta Tang Zhong sebagai bahan dasar roti dengan memanaskan 15 gr tepung terigu dan 75 ml air diatas api kecil dan diaduk hingga mengental membentuk pasta, mulai meletup dan berubah warna menjadi kelabu. Biarkan hingga dingin.
1. Campurkan bahan roti dan pasta Tang Zhong kedalam wadah dan mixer / uleni hingga kalis dan elastis. Tutup adonan dengan kain selama 45 - 60 menit hingga mengembang dua kali lipat.
1. Siapkan bahan isian dengan mencampur margarin, gula dan parutan keju secukupnya. Mixer dengan kecepatan sedang.
1. Buat topping dengan mencampurkan tepung terigu, margarin, gula, garam, vanili, luwak white coffee, tambahkan air hangat secukupnya agar adonan tidak terlalu padat. Mixer atau aduk selama beberapa menit hingga tercampur rata.
1. Kempeskan adonan, bagi adonan menjadi beberapa bagian dan isi dengan isian roti. Bulatkan adonan dan diamkan beberapa menit hingga mengembang. Siapkan plastik untuk menempatkan topping dan berukan keatas roti dengan teknik memutar.
1. Panggang dengan suhu 180 derajat celsius selama kurang lebih 15 menit hingga bagian topping matang / mengering.




Demikianlah cara membuat mexican bun / roti o yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan cepat, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
