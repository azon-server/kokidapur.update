---
description: "Steps menyiapakan Roti boy teraktual"
title: "Steps menyiapakan Roti boy teraktual"
slug: 300-steps-menyiapakan-roti-boy-teraktual
date: 2021-01-21T09:41:42.502Z
image: https://img-global.cpcdn.com/recipes/5bed460f8b93992f/680x482cq70/roti-boy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5bed460f8b93992f/680x482cq70/roti-boy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5bed460f8b93992f/680x482cq70/roti-boy-foto-resep-utama.jpg
author: Mollie Nash
ratingvalue: 4.8
reviewcount: 30708
recipeingredient:
- " Bahan adonan roti"
- "200 gr tepung cakra"
- "3 sdm gula"
- "1.5 sdt permifan"
- "1 sdt garam"
- "80 ml susu cair plain saya pakai dancow di larutkan"
- "1 butir telur"
- "50 gr mentega"
- " Bahan toping"
- " Susu cair  kopi bubuk tanpa ampas dilarutkan"
- "50 gr butter"
- "4 sdm tepung"
- "3 sdm gula"
- "1 butir telor"
- " Bahan isian"
- " Butter secukupnya sesuaikan dengan adonan"
recipeinstructions:
- "Adonan roti. Lelehkan mentega lalu dinginkan. Larutkan jga ragi dalam air hangat dan tunggu sampai aktif"
- "Campur semua bahan adonan roti dan ulenin sampai kalis. Setelah kalis tutup adonan dengan kain basah dan tunggu 2 jam sampai adonan mengembang 2 kali lebih besar."
- "Menunggu adonan mengembang, buat adonan toping. Mixer semua adonan toping sampai gula larut dan halus. Lalu masukan dalam plastik segitiga dan masukan kulkas."
- "Setelah adonan mengembang, bentuk adonan bulat dan isi dengan butter yang sudah di potong2. Diamkan kembali adonan yang sudah di bentuk ditutup dengan kain basah. Diamkan sekitar 1 jam"
- "Setelah 1 jam, panaskan oven 180C. Adonan yabg sudah mengembang, kasih topping diatasnya"
- "Bakar roti dan siap di sajikan"
categories:
- Recipe
tags:
- roti
- boy

katakunci: roti boy 
nutrition: 200 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Dinner

---


![Roti boy](https://img-global.cpcdn.com/recipes/5bed460f8b93992f/680x482cq70/roti-boy-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti roti boy yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Nusantara

Kedekatan keluarga dapat ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Roti boy untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang bisa anda buat salah satunya roti boy yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep roti boy tanpa harus bersusah payah.
Seperti resep Roti boy yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti boy:

1. Siapkan  Bahan adonan roti
1. Harus ada 200 gr tepung cakra
1. Siapkan 3 sdm gula
1. Tambah 1.5 sdt permifan
1. Tambah 1 sdt garam
1. Dibutuhkan 80 ml susu cair plain (saya pakai dancow di larutkan)
1. Diperlukan 1 butir telur
1. Diperlukan 50 gr mentega
1. Dibutuhkan  Bahan toping
1. Jangan lupa  Susu cair + kopi bubuk tanpa ampas (dilarutkan)
1. Dibutuhkan 50 gr butter
1. Harus ada 4 sdm tepung
1. Harap siapkan 3 sdm gula
1. Siapkan 1 butir telor
1. Harap siapkan  Bahan isian
1. Siapkan  Butter secukupnya *sesuaikan dengan adonan




<!--inarticleads2-->

##### Langkah membuat  Roti boy:

1. Adonan roti. Lelehkan mentega lalu dinginkan. Larutkan jga ragi dalam air hangat dan tunggu sampai aktif
1. Campur semua bahan adonan roti dan ulenin sampai kalis. Setelah kalis tutup adonan dengan kain basah dan tunggu 2 jam sampai adonan mengembang 2 kali lebih besar.
1. Menunggu adonan mengembang, buat adonan toping. Mixer semua adonan toping sampai gula larut dan halus. Lalu masukan dalam plastik segitiga dan masukan kulkas.
1. Setelah adonan mengembang, bentuk adonan bulat dan isi dengan butter yang sudah di potong2. Diamkan kembali adonan yang sudah di bentuk ditutup dengan kain basah. Diamkan sekitar 1 jam
1. Setelah 1 jam, panaskan oven 180C. Adonan yabg sudah mengembang, kasih topping diatasnya
1. Bakar roti dan siap di sajikan




Demikianlah cara membuat roti boy yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan terbukti, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
