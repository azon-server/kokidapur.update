---
description: "Panduan untuk menyiapakan Mexican bun a.k.a Roti O terupdate"
title: "Panduan untuk menyiapakan Mexican bun a.k.a Roti O terupdate"
slug: 335-panduan-untuk-menyiapakan-mexican-bun-aka-roti-o-terupdate
date: 2021-01-07T07:13:21.054Z
image: https://img-global.cpcdn.com/recipes/08794a15f38da1fa/680x482cq70/mexican-bun-aka-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/08794a15f38da1fa/680x482cq70/mexican-bun-aka-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/08794a15f38da1fa/680x482cq70/mexican-bun-aka-roti-o-foto-resep-utama.jpg
author: Rebecca Bowers
ratingvalue: 4.7
reviewcount: 2651
recipeingredient:
- " Bahan dough"
- "250 gr tepung protein tinggi cakra"
- "1 butir telor ayam"
- "50 gr gula pasir me cukup 2sdm aja"
- "1 sdm susu bubuk dancow"
- "90 ml air dingin"
- "5 gr fermipan"
- "25 gr margarin me 2sdm"
- " Bahan topping"
- "55 gr gula halus me 4sdm"
- "50 gr mentega me 3sdm blueband cake n cookies"
- "60 gr tepung protein sedang me 6sdm tepung segitiga"
- "1 sdt kopi nescafe classic"
- "1 sdm air panas"
- "1 butir putih telor"
- " Pasta moka me skip"
- " Isian"
- " Keju cheddar parut"
- " Butter unsalted"
recipeinstructions:
- "Campur semua bahan dough kecuali margarin, uleni sampai setengah kalis"
- "Masukkan margarin kemudian uleni lagi sampai benar2 kalis elastis, bulatkan lalu tutup 1 jam sampai mengembang 2x lipat"
- "Setelah mengembang 2x lipat kempiskan adonan bagi adonan menjadi 10bagian (sesuai selera). Bulatkan lagi dough, diamkan lagi selama 10menit..lalu pipihkan (bagian pinggir2 saja) isi dengan keju chedar dan irisan butter, bulatkan kembali sambil dicubit2 bagian pinggir agar ketika dioven tidak bocor. Tata diatas loyang yang sudah dioles margarin dan baking paper. Posisikan cubitan ada dibawah ea. Proofing/diamkan selama 45menit/ sampai mengembang 2x lipat"
- "Sambil menunggu doughnya mengembang, kita buat toping. Ambil nescafe campur dengan air panas, aduk hingga kopi jadi pasta. Lalu diwadah lain, masukkan gula halus mentega aduk dengan whisk sampai gula tercampur rata. Masukkan putih telor kocok hingga mengembang, lalu tepung (sambil diayak)"
- "Masukkan kopi. Aduk rata"
- "Setelah adonan toping tercampur merata masukkan ke plastik segitiga. sisihkan. Jika adonan dough sudah mengembang, semprotkan bahan topping diatasnya membentuk melingkar seperti obat nyamuk bakar. Sementara Sambil panaskan oven"
- "Panggang dengan suhu 180 derajat selama 20 menit api atas bawah (me. Pake oven tangkring selama 45menit) sampai toppingnya kering siap diangkat dan sajikan selagi hangat."
categories:
- Recipe
tags:
- mexican
- bun
- aka

katakunci: mexican bun aka 
nutrition: 147 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Dinner

---


![Mexican bun a.k.a Roti O](https://img-global.cpcdn.com/recipes/08794a15f38da1fa/680x482cq70/mexican-bun-aka-roti-o-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti mexican bun a.k.a roti o yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Kita



Keharmonisan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Mexican bun a.k.a Roti O untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang bisa anda praktekkan salah satunya mexican bun a.k.a roti o yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep mexican bun a.k.a roti o tanpa harus bersusah payah.
Berikut ini resep Mexican bun a.k.a Roti O yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican bun a.k.a Roti O:

1. Tambah  Bahan dough=
1. Diperlukan 250 gr tepung protein tinggi (cakra)
1. Dibutuhkan 1 butir telor ayam
1. Harap siapkan 50 gr gula pasir (me, cukup 2sdm aja)
1. Dibutuhkan 1 sdm susu bubuk dancow
1. Harap siapkan 90 ml air dingin
1. Dibutuhkan 5 gr fermipan
1. Siapkan 25 gr margarin (me, 2sdm)
1. Tambah  Bahan topping=
1. Dibutuhkan 55 gr gula halus (me 4sdm)
1. Harap siapkan 50 gr mentega (me 3sdm blueband cake n cookies)
1. Diperlukan 60 gr tepung protein sedang (me 6sdm tepung segitiga)
1. Harap siapkan 1 sdt kopi nescafe classic
1. Diperlukan 1 sdm air panas
1. Tambah 1 butir putih telor
1. Harus ada  Pasta moka (me skip)
1. Dibutuhkan  Isian=
1. Diperlukan  Keju cheddar parut
1. Jangan lupa  Butter unsalted




<!--inarticleads2-->

##### Cara membuat  Mexican bun a.k.a Roti O:

1. Campur semua bahan dough kecuali margarin, uleni sampai setengah kalis
1. Masukkan margarin kemudian uleni lagi sampai benar2 kalis elastis, bulatkan lalu tutup 1 jam sampai mengembang 2x lipat
1. Setelah mengembang 2x lipat kempiskan adonan bagi adonan menjadi 10bagian (sesuai selera). Bulatkan lagi dough, diamkan lagi selama 10menit..lalu pipihkan (bagian pinggir2 saja) isi dengan keju chedar dan irisan butter, bulatkan kembali sambil dicubit2 bagian pinggir agar ketika dioven tidak bocor. Tata diatas loyang yang sudah dioles margarin dan baking paper. Posisikan cubitan ada dibawah ea. Proofing/diamkan selama 45menit/ sampai mengembang 2x lipat
1. Sambil menunggu doughnya mengembang, kita buat toping. Ambil nescafe campur dengan air panas, aduk hingga kopi jadi pasta. Lalu diwadah lain, masukkan gula halus mentega aduk dengan whisk sampai gula tercampur rata. Masukkan putih telor kocok hingga mengembang, lalu tepung (sambil diayak)
1. Masukkan kopi. Aduk rata
1. Setelah adonan toping tercampur merata masukkan ke plastik segitiga. sisihkan. Jika adonan dough sudah mengembang, semprotkan bahan topping diatasnya membentuk melingkar seperti obat nyamuk bakar. Sementara Sambil panaskan oven
1. Panggang dengan suhu 180 derajat selama 20 menit api atas bawah (me. Pake oven tangkring selama 45menit) sampai toppingnya kering siap diangkat dan sajikan selagi hangat.




Demikianlah cara membuat mexican bun a.k.a roti o yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan teruji, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
