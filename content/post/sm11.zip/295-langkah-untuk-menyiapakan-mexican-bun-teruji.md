---
description: "Langkah untuk menyiapakan Mexican Bun Teruji"
title: "Langkah untuk menyiapakan Mexican Bun Teruji"
slug: 295-langkah-untuk-menyiapakan-mexican-bun-teruji
date: 2021-02-09T12:28:55.026Z
image: https://img-global.cpcdn.com/recipes/78ef26abdb8c151d/680x482cq70/mexican-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/78ef26abdb8c151d/680x482cq70/mexican-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/78ef26abdb8c151d/680x482cq70/mexican-bun-foto-resep-utama.jpg
author: Glenn Jimenez
ratingvalue: 4.1
reviewcount: 46900
recipeingredient:
- " Bahan roti"
- "250 gr Tepung Terigu protein tinggisaya cakra"
- "55 gr gula pasir"
- "6 gr Fermipan"
- "125 ml susu cair"
- "35 gr Butter"
- "secukupnya garam"
- "1 Butir telur"
- " Bahan topping"
- "65 gr margarin"
- "75 gr tepung protein rendah"
- "1 sachet nescafesaya pake nescafe classic tanpa ampas"
- "60 gr Gula halus"
- "1 butir telur"
- "sedikit pasta mocca"
- " optional"
- " coklat bubuk"
- " Bahan isian"
- "100 gr butter beku"
- " kejusaya"
recipeinstructions:
- "Masukan semua bahan roti di satu wadah kecuali butter diamkan ±10 menit,kmudian uleni hinggan hampir kalis lalu masukan butter,uleni kembali hingga kalis elastis"
- "Sambil menunggu adonan mengembang siap kan topping roti"
- "Seduh kopi dengan 1sendok air panas hingga membentuk pasta"
- "Mixer gula halus dan margarin hingga creamy,lalu masukan telur,pasta mocca dan kopi yg sudah di seduh,mixer hingga merata,terakhir masukan terigu sedikit demi sedikit,dan mixer kembali hingga adonan halus merata"
- "Masukan adonan topping ke plastik segitiga lalu simpan di kulkas sambil menunggu adonan dough mengembang dan diisi"
- "Cek dough,jika sudah mengembang,kempiskan dough lalu timbang adonan 50gr"
- "Isi adonan dengan butter beku yg sdh dipotong2 kotak,saya tambahkan keju,tp original nya tanpa keju ya..."
- "Setelah diisi diamkan kembali adonan hingga mengembang"
- "Setelah mengembang semprotkan adonan toping di atas dough dengan memutar dan rapat"
- "Lalu oven dengan suhu 180°c selama ±17 menit,(sesuaikan oven masing2)"
- "Setelah matang mexican bun sukses bikin wangi kopi seluruh ruangan,dan kopi bun siap dinikmati 😍"
categories:
- Recipe
tags:
- mexican
- bun

katakunci: mexican bun 
nutrition: 217 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Dinner

---


![Mexican Bun](https://img-global.cpcdn.com/recipes/78ef26abdb8c151d/680x482cq70/mexican-bun-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga enak. Ciri khas makanan Nusantara mexican bun yang kaya dengan rempah menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kehangatan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah memasak Mexican Bun untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang bisa anda buat salah satunya mexican bun yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep mexican bun tanpa harus bersusah payah.
Seperti resep Mexican Bun yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 11 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Mexican Bun:

1. Jangan lupa  Bahan roti
1. Diperlukan 250 gr Tepung Terigu protein tinggi(saya cakra)
1. Diperlukan 55 gr gula pasir
1. Jangan lupa 6 gr Fermipan
1. Dibutuhkan 125 ml susu cair
1. Siapkan 35 gr Butter
1. Dibutuhkan secukupnya garam
1. Harap siapkan 1 Butir telur
1. Tambah  Bahan topping
1. Diperlukan 65 gr margarin
1. Harus ada 75 gr tepung protein rendah
1. Tambah 1 sachet nescafe(saya pake nescafe classic tanpa ampas)
1. Diperlukan 60 gr Gula halus
1. Siapkan 1 butir telur
1. Diperlukan sedikit pasta mocca
1. Siapkan  optional
1. Jangan lupa  (coklat bubuk)
1. Harap siapkan  Bahan isian
1. Tambah 100 gr butter beku
1. Siapkan  keju(saya)




<!--inarticleads2-->

##### Bagaimana membuat  Mexican Bun:

1. Masukan semua bahan roti di satu wadah kecuali butter diamkan ±10 menit,kmudian uleni hinggan hampir kalis lalu masukan butter,uleni kembali hingga kalis elastis
1. Sambil menunggu adonan mengembang siap kan topping roti
1. Seduh kopi dengan 1sendok air panas hingga membentuk pasta
1. Mixer gula halus dan margarin hingga creamy,lalu masukan telur,pasta mocca dan kopi yg sudah di seduh,mixer hingga merata,terakhir masukan terigu sedikit demi sedikit,dan mixer kembali hingga adonan halus merata
1. Masukan adonan topping ke plastik segitiga lalu simpan di kulkas sambil menunggu adonan dough mengembang dan diisi
1. Cek dough,jika sudah mengembang,kempiskan dough lalu timbang adonan 50gr
1. Isi adonan dengan butter beku yg sdh dipotong2 kotak,saya tambahkan keju,tp original nya tanpa keju ya...
1. Setelah diisi diamkan kembali adonan hingga mengembang
1. Setelah mengembang semprotkan adonan toping di atas dough dengan memutar dan rapat
1. Lalu oven dengan suhu 180°c selama ±17 menit,(sesuaikan oven masing2)
1. Setelah matang mexican bun sukses bikin wangi kopi seluruh ruangan,dan kopi bun siap dinikmati 😍




Demikianlah cara membuat mexican bun yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
