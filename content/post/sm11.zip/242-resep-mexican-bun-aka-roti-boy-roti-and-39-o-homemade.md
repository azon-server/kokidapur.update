---
description: "Resep : Mexican Bun a.k.a Roti Boy / Roti &amp;#39;O Homemade"
title: "Resep : Mexican Bun a.k.a Roti Boy / Roti &amp;#39;O Homemade"
slug: 242-resep-mexican-bun-aka-roti-boy-roti-and-39-o-homemade
date: 2020-12-15T06:56:46.800Z
image: https://img-global.cpcdn.com/recipes/5ef67d37d5dee05f/680x482cq70/mexican-bun-aka-roti-boy-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5ef67d37d5dee05f/680x482cq70/mexican-bun-aka-roti-boy-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5ef67d37d5dee05f/680x482cq70/mexican-bun-aka-roti-boy-roti-o-foto-resep-utama.jpg
author: Oscar Holloway
ratingvalue: 4
reviewcount: 19225
recipeingredient:
- " Bahan A"
- "300 gr tepung terigu"
- "50 gr gula pasir"
- "7 gr ragi instan"
- "200 gr susu cair asli nya mix whipping cream"
- " Bahan B"
- "65 gr margarin"
- "1/2 sdt garam"
- " Topping"
- "70 gr margarin"
- "35 gr gula halus"
- "1 sc kopi instan seduh dg 2sdm air panas saya nescafe clasic"
- "1 butir telur"
- "70 gr tepung terigu"
- " Bahan isian"
- " Mentega margarin beku"
recipeinstructions:
- "Campur bahan A sambil diuleni sampe stengah kalis lalu masukkan bahan B, uleni sampai kalis elastis"
- "Cek windowpane nya dg mengambil sedikit adonan lalu bentangkan perlahan sampai tipis, kalo adonan tdk mudah robek berarti adonan siap di diamkan. Bulatkan adonan lalu simpan di wadah kemudian tutup dg kain bersih, diamkan sampai ukuran nya mengembang menjadi 2x lipat sekitar 45 menit"
- "Sambil nunggu adonan ngembang, kita buat topping nya. Campurkan margarin dan gula halus, aduk sampai rata lalu masukkan telur dan kopi yg sudah di seduh. Aduk rata lalu masukkan terigu, aduk sampai benar2 rata, saya ratakan pakai sendok biar lebih mudah😁"
- "Masukkan ke dlm plastik segitiga, sisihkan."
- "Setelah mengembang 2x lipat, kempiskan adonan untuk mengeluarkan gas nya.. Bagi adonan jd 10 buah, sya timbang @60 gr bulatkan lalu pipihkan dan isi dg mentega beku, kemudian bulatkan lagi"
- "Tata roti di loyang yg sudah dialasi kertas roti. Diamkan dan tutup lagi selama 15 menit sampai mengembang 2x lipat lagi. Semprotkan adonan topping ke atas adonan roti dg bentuk melingkar seperti obat nyamuk, panggang sampai matang. Saya 25 menit menggunakan api sedang."
- "Enak bangettt hasilnya kriukk😍😍😍😍"
categories:
- Recipe
tags:
- mexican
- bun
- aka

katakunci: mexican bun aka 
nutrition: 282 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Dinner

---


![Mexican Bun a.k.a Roti Boy / Roti &#39;O](https://img-global.cpcdn.com/recipes/5ef67d37d5dee05f/680x482cq70/mexican-bun-aka-roti-boy-roti-o-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga gurih. Ciri khas kuliner Nusantara mexican bun a.k.a roti boy / roti &#39;o yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Mexican Bun a.k.a Roti Boy / Roti &#39;O untuk orang di rumah. Momen makan bersama orang tua sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang bisa anda buat salah satunya mexican bun a.k.a roti boy / roti &#39;o yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep mexican bun a.k.a roti boy / roti &#39;o tanpa harus bersusah payah.
Seperti resep Mexican Bun a.k.a Roti Boy / Roti &#39;O yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 16 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Mexican Bun a.k.a Roti Boy / Roti &#39;O:

1. Diperlukan  Bahan A:
1. Siapkan 300 gr tepung terigu
1. Harus ada 50 gr gula pasir
1. Harap siapkan 7 gr ragi instan
1. Dibutuhkan 200 gr susu cair (asli nya mix whipping cream)
1. Dibutuhkan  Bahan B:
1. Tambah 65 gr margarin
1. Siapkan 1/2 sdt garam
1. Jangan lupa  Topping:
1. Diperlukan 70 gr margarin
1. Siapkan 35 gr gula halus
1. Tambah 1 sc kopi instan seduh dg 2sdm air panas (saya nescafe clasic)
1. Jangan lupa 1 butir telur
1. Siapkan 70 gr tepung terigu
1. Dibutuhkan  Bahan isian:
1. Diperlukan  Mentega/ margarin beku




<!--inarticleads2-->

##### Cara membuat  Mexican Bun a.k.a Roti Boy / Roti &#39;O:

1. Campur bahan A sambil diuleni sampe stengah kalis lalu masukkan bahan B, uleni sampai kalis elastis
1. Cek windowpane nya dg mengambil sedikit adonan lalu bentangkan perlahan sampai tipis, kalo adonan tdk mudah robek berarti adonan siap di diamkan. Bulatkan adonan lalu simpan di wadah kemudian tutup dg kain bersih, diamkan sampai ukuran nya mengembang menjadi 2x lipat sekitar 45 menit
1. Sambil nunggu adonan ngembang, kita buat topping nya. Campurkan margarin dan gula halus, aduk sampai rata lalu masukkan telur dan kopi yg sudah di seduh. Aduk rata lalu masukkan terigu, aduk sampai benar2 rata, saya ratakan pakai sendok biar lebih mudah😁
1. Masukkan ke dlm plastik segitiga, sisihkan.
1. Setelah mengembang 2x lipat, kempiskan adonan untuk mengeluarkan gas nya.. Bagi adonan jd 10 buah, sya timbang @60 gr bulatkan lalu pipihkan dan isi dg mentega beku, kemudian bulatkan lagi
1. Tata roti di loyang yg sudah dialasi kertas roti. Diamkan dan tutup lagi selama 15 menit sampai mengembang 2x lipat lagi. Semprotkan adonan topping ke atas adonan roti dg bentuk melingkar seperti obat nyamuk, panggang sampai matang. Saya 25 menit menggunakan api sedang.
1. Enak bangettt hasilnya kriukk😍😍😍😍




Demikianlah cara membuat mexican bun a.k.a roti boy / roti &#39;o yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan terbukti, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
