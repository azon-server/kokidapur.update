---
description: "Resep : Coffee bun/ roti boy/ roti o terupdate"
title: "Resep : Coffee bun/ roti boy/ roti o terupdate"
slug: 407-resep-coffee-bun-roti-boy-roti-o-terupdate
date: 2021-01-13T11:23:48.452Z
image: https://img-global.cpcdn.com/recipes/712512a92f33b4a9/680x482cq70/coffee-bun-roti-boy-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/712512a92f33b4a9/680x482cq70/coffee-bun-roti-boy-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/712512a92f33b4a9/680x482cq70/coffee-bun-roti-boy-roti-o-foto-resep-utama.jpg
author: Lena Ferguson
ratingvalue: 4.6
reviewcount: 31720
recipeingredient:
- "250 gr tepung"
- "1/2 sdt garam"
- "1 sdt ragi"
- "30 gr butter"
- "1 butir telur"
- " Bun"
- " Butter cream coffee"
- "1 sdt kopi instan saya nescafe"
- "50 gr gula halus"
- "50 gr butter"
- "1 butir telur"
- "30 gr tepung"
recipeinstructions:
- "Mixer semua bahan bun kecuali butter. Mixer dengan kecepatan sedang 2-3 menit (diuleni pake tangan juga boleh) setelah itu masukan butter, mixer hingga kalis. Tutup adonan dengan kain diamkan selama 1 jam."
- "Sambil menunggu adonan. Seduh 1 sdt kopi dengan 1 sdt air panas, sisihkan. Mixer semua butter dengan gula halus hingga creamy, masukan telur, tepung dan kopi tadi. Mixer hingga rata, masukan kedalam piping bag, lalu taro di chiller."
- "Setelah 1 jam. Bagi adonan menjadi 9 bagian. Lalu yang 1 bagian, bagi menjadi 8 bagian kecil untuk taro butter yang sudah di bekukan. Isi butter kedalam adonan yg kecil lalu masukan kedalam adonan yg besar. Bulat kan kemudian tutup dengan kain tunggu hingga 30 menit"
- "Setelah 30 menit. Panaskan oven, tata roti diloyang lalu tuangkan butter cream coffee tadi diatasnya. Panggang disuhu 180 dengan api atas bawah selama 20 menit (sesuaikan oven masing2 ya)"
- "Sajikan~ selamat mencoba yaa. Walaupun bentuknya jelek tapi tetep enak kok hehe"
categories:
- Recipe
tags:
- coffee
- bun
- roti

katakunci: coffee bun roti 
nutrition: 252 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Dessert

---


![Coffee bun/ roti boy/ roti o](https://img-global.cpcdn.com/recipes/712512a92f33b4a9/680x482cq70/coffee-bun-roti-boy-roti-o-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan enak. Ciri masakan Indonesia coffee bun/ roti boy/ roti o yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kehangatan keluarga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Coffee bun/ roti boy/ roti o untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang bisa anda praktekkan salah satunya coffee bun/ roti boy/ roti o yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep coffee bun/ roti boy/ roti o tanpa harus bersusah payah.
Berikut ini resep Coffee bun/ roti boy/ roti o yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Coffee bun/ roti boy/ roti o:

1. Harus ada 250 gr tepung
1. Harus ada 1/2 sdt garam
1. Jangan lupa 1 sdt ragi
1. Dibutuhkan 30 gr butter
1. Siapkan 1 butir telur
1. Harap siapkan  Bun
1. Jangan lupa  Butter cream coffee
1. Harap siapkan 1 sdt kopi instan (saya nescafe)
1. Dibutuhkan 50 gr gula halus
1. Diperlukan 50 gr butter
1. Tambah 1 butir telur
1. Siapkan 30 gr tepung




<!--inarticleads2-->

##### Cara membuat  Coffee bun/ roti boy/ roti o:

1. Mixer semua bahan bun kecuali butter. Mixer dengan kecepatan sedang 2-3 menit (diuleni pake tangan juga boleh) setelah itu masukan butter, mixer hingga kalis. Tutup adonan dengan kain diamkan selama 1 jam.
1. Sambil menunggu adonan. Seduh 1 sdt kopi dengan 1 sdt air panas, sisihkan. Mixer semua butter dengan gula halus hingga creamy, masukan telur, tepung dan kopi tadi. Mixer hingga rata, masukan kedalam piping bag, lalu taro di chiller.
1. Setelah 1 jam. Bagi adonan menjadi 9 bagian. Lalu yang 1 bagian, bagi menjadi 8 bagian kecil untuk taro butter yang sudah di bekukan. Isi butter kedalam adonan yg kecil lalu masukan kedalam adonan yg besar. Bulat kan kemudian tutup dengan kain tunggu hingga 30 menit
1. Setelah 30 menit. Panaskan oven, tata roti diloyang lalu tuangkan butter cream coffee tadi diatasnya. Panggang disuhu 180 dengan api atas bawah selama 20 menit (sesuaikan oven masing2 ya)
1. Sajikan~ selamat mencoba yaa. Walaupun bentuknya jelek tapi tetep enak kok hehe




Demikianlah cara membuat coffee bun/ roti boy/ roti o yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
