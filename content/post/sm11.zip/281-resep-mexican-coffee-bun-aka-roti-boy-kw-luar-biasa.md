---
description: "Resep : Mexican Coffee Bun a.k.a Roti Boy KW Luar biasa"
title: "Resep : Mexican Coffee Bun a.k.a Roti Boy KW Luar biasa"
slug: 281-resep-mexican-coffee-bun-aka-roti-boy-kw-luar-biasa
date: 2020-12-18T13:30:06.860Z
image: https://img-global.cpcdn.com/recipes/c47f8b981306e3af/680x482cq70/mexican-coffee-bun-aka-roti-boy-kw-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c47f8b981306e3af/680x482cq70/mexican-coffee-bun-aka-roti-boy-kw-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c47f8b981306e3af/680x482cq70/mexican-coffee-bun-aka-roti-boy-kw-foto-resep-utama.jpg
author: Gussie Conner
ratingvalue: 4.8
reviewcount: 42957
recipeingredient:
- "220 tepung cakra"
- "2 sdm gula pasir"
- "1 sdt ragi instant"
- "130 ml air hangat"
- "1 btr kuning telur"
- "2 sdm margarinbutter"
- "Sejumput garam"
- " Isian "
- "50-70 gr margarin"
- "1-1,5 sdm gula halus"
- " Topping "
- "50 gr margarin"
- "50 gr gula halus"
- "1 btr putih telur"
- "50 gr tepung serbaguna"
- "17 gr maizena"
- "1/2 sachet Luwak Whitecoffee cairkan dgn sedikit air"
- "2 tetes pasta mocca"
recipeinstructions:
- "Campur air hangat, gula &amp; ragi instant, biarkan berbusa hingga 15 menit"
- "Masukkan tepung, kuning telur, aduk rata, masukkan larutan ragi &amp; gula, tambahkan garam, ulen hingga kalis, masukkan margarin, ulen hingga kalis elastis, lalu proofing selama 1 jam/hingga mengembang 2 x lipat"
- "Mixer bahan topping, dari margarin &amp; gula halus dimixer hingga mengembang, lalu masukkan putih telur, mixer kembali, kemudian ayak tepung serbaguna &amp; maizena diatas adonan topping, mixer kembali hingga rata, terakhir masukkan pasta kopi Luwak &amp; pasta mocca, mixer hingga rata, masukkan dlm plastik segitiga, lalu masukkan ke dlm kulkas"
- "Kempiskan adonan, lalu bagi adonan menjadi @ 50 gr/dibagi menjadi 8 bh, beri isian &amp; bulatkan, proofing kembali +/- 15 menit - 1 jam/hingga mengembang"
- "Panaskan oven, sementara menunggu oven panas, keluarkan topping dr kulkas, lalu semprotkan topping di atas roti yg sdh diproofing tadi dgn cara penyemprotannya seperti obat nyamuk (melingkar), lalu panggang selama 25 mnt dgn suhu 180 derajat celcius api atas bawah, sesuaikan dgn oven masing2 ya"
- "Setelah matang, keluarkan roti dr dlm oven lalu angin2kan, setelah dingin segera masukkan ke dlm plastik agar keempukkannya terjaga"
categories:
- Recipe
tags:
- mexican
- coffee
- bun

katakunci: mexican coffee bun 
nutrition: 105 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Lunch

---


![Mexican Coffee Bun a.k.a Roti Boy KW](https://img-global.cpcdn.com/recipes/c47f8b981306e3af/680x482cq70/mexican-coffee-bun-aka-roti-boy-kw-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang harus kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti mexican coffee bun a.k.a roti boy kw yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan ciri khas yang merupakan keragaman Indonesia

Kedekatan rumah tangga dapat diperoleh dengan cara simple. Diantaranya adalah membuat makanan Mexican Coffee Bun a.k.a Roti Boy KW untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang dapat anda contoh salah satunya mexican coffee bun a.k.a roti boy kw yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep mexican coffee bun a.k.a roti boy kw tanpa harus bersusah payah.
Seperti resep Mexican Coffee Bun a.k.a Roti Boy KW yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Mexican Coffee Bun a.k.a Roti Boy KW:

1. Diperlukan 220 tepung cakra
1. Harap siapkan 2 sdm gula pasir
1. Diperlukan 1 sdt ragi instant
1. Diperlukan 130 ml air hangat
1. Harap siapkan 1 btr kuning telur
1. Harap siapkan 2 sdm margarin/butter
1. Jangan lupa Sejumput garam
1. Siapkan  Isian :
1. Tambah 50-70 gr margarin
1. Harus ada 1-1,5 sdm gula halus
1. Jangan lupa  Topping :
1. Siapkan 50 gr margarin
1. Harus ada 50 gr gula halus
1. Dibutuhkan 1 btr putih telur
1. Harus ada 50 gr tepung serbaguna
1. Jangan lupa 17 gr maizena
1. Harus ada 1/2 sachet Luwak Whitecoffee (cairkan dgn sedikit air)
1. Dibutuhkan 2 tetes pasta mocca




<!--inarticleads2-->

##### Bagaimana membuat  Mexican Coffee Bun a.k.a Roti Boy KW:

1. Campur air hangat, gula &amp; ragi instant, biarkan berbusa hingga 15 menit
1. Masukkan tepung, kuning telur, aduk rata, masukkan larutan ragi &amp; gula, tambahkan garam, ulen hingga kalis, masukkan margarin, ulen hingga kalis elastis, lalu proofing selama 1 jam/hingga mengembang 2 x lipat
1. Mixer bahan topping, dari margarin &amp; gula halus dimixer hingga mengembang, lalu masukkan putih telur, mixer kembali, kemudian ayak tepung serbaguna &amp; maizena diatas adonan topping, mixer kembali hingga rata, terakhir masukkan pasta kopi Luwak &amp; pasta mocca, mixer hingga rata, masukkan dlm plastik segitiga, lalu masukkan ke dlm kulkas
1. Kempiskan adonan, lalu bagi adonan menjadi @ 50 gr/dibagi menjadi 8 bh, beri isian &amp; bulatkan, proofing kembali +/- 15 menit - 1 jam/hingga mengembang
1. Panaskan oven, sementara menunggu oven panas, keluarkan topping dr kulkas, lalu semprotkan topping di atas roti yg sdh diproofing tadi dgn cara penyemprotannya seperti obat nyamuk (melingkar), lalu panggang selama 25 mnt dgn suhu 180 derajat celcius api atas bawah, sesuaikan dgn oven masing2 ya
1. Setelah matang, keluarkan roti dr dlm oven lalu angin2kan, setelah dingin segera masukkan ke dlm plastik agar keempukkannya terjaga




Demikianlah cara membuat mexican coffee bun a.k.a roti boy kw yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan cepat, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
