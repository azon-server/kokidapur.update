---
description: "Langkah membuat Risol Mayo teraktual"
title: "Langkah membuat Risol Mayo teraktual"
slug: 76-langkah-membuat-risol-mayo-teraktual
date: 2020-11-22T12:57:01.625Z
image: https://img-global.cpcdn.com/recipes/418fd2fd9bc21082/680x482cq70/risol-mayo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/418fd2fd9bc21082/680x482cq70/risol-mayo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/418fd2fd9bc21082/680x482cq70/risol-mayo-foto-resep-utama.jpg
author: Herman Mullins
ratingvalue: 5
reviewcount: 9005
recipeingredient:
- " Bahan kulit"
- "150 gr tepung cakra"
- "100 gr tepung segitiga biru"
- "1/2 sdt garam"
- "2 telur"
- "3 sdm minyak goreng"
- "650 ml air"
- " Minyak untuk menggoreng"
- " Bahan filling"
- "5 lembar smoke beef iris jd 4"
- "4 telur rebus bagi jd 6"
- "3 sdm mayonise"
- "2 sdm saos tomat"
- " Bahan perekat"
- "4 sdm tepung serbaguna"
- "Sejumput garam"
- " Tepung panir dihaluskan"
- "150-200 ml air"
recipeinstructions:
- "Campur semua bahan kulit, kecuali air. Yuang air setengah dl kemudian aduk sambil tuang sisa air sedikit demi sedikit. Campur rata dan pastikan tdk ada lg yg menggerindil."
- "Saring adonan kulit, dan diamkan sekitar 15 menit."
- "Siapkan isiannya: panggang smoke beef di atas teflon sebentar.. jgn sampai terlalu kering. Rebus telur selama -+10 menit, lalu angkat dan guyur air dingin atau kalo tdk ada cukup dg air biasa saja. Campur mayonais dan saos tomat. Sisihkan."
- "Panaskan teflon dengan api sedang cenderung kecil. Pakai teflon yg bagus, tdk dipakai untuk menumis. Bentuk kulit risol diatas teflon, tunggu sampai kulit ikut bergerak jika teflon di goyang2, jd g perlu di dicek menggunakan spatula atau yg lain.. paham tak sampai sini😅🤭 pokonya gt lah😂 setelah adonan kulit habis, dinginkan kulit risol."
- "Isi kulit dg isian td, lalu lipat seeeesuka hati🤭"
- "Campur tepung, garam dan air untuk pelapis. Masukkan risol yg adh dibentuk ke dlm tepung, setelah itu lumuri dengan tepung panir. Lakukan sprti itu sampai selesai"
- "Panaskan minyak yg agak banyak dengan api sedang, goreng risol sampai coklat keemasan, tiriskan dan sajikan hangat."
categories:
- Recipe
tags:
- risol
- mayo

katakunci: risol mayo 
nutrition: 144 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Lunch

---


![Risol Mayo](https://img-global.cpcdn.com/recipes/418fd2fd9bc21082/680x482cq70/risol-mayo-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti risol mayo yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa ciri khas yang merupakan keragaman Kita

Keharmonisan keluarga dapat diperoleh dengan cara simple. Salah satunya adalah memasak Risol Mayo untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang dapat anda buat salah satunya risol mayo yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep risol mayo tanpa harus bersusah payah.
Berikut ini resep Risol Mayo yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Risol Mayo:

1. Diperlukan  Bahan kulit:
1. Diperlukan 150 gr tepung cakra
1. Harus ada 100 gr tepung segitiga biru
1. Diperlukan 1/2 sdt garam
1. Siapkan 2 telur
1. Harap siapkan 3 sdm minyak goreng
1. Harus ada 650 ml air
1. Harap siapkan  Minyak untuk menggoreng
1. Dibutuhkan  Bahan filling:
1. Tambah 5 lembar smoke beef (iris jd 4)
1. Tambah 4 telur rebus (bagi jd 6)
1. Jangan lupa 3 sdm mayonise
1. Tambah 2 sdm saos tomat
1. Harus ada  Bahan perekat:
1. Harap siapkan 4 sdm tepung serbaguna
1. Jangan lupa Sejumput garam
1. Harap siapkan  Tepung panir dihaluskan
1. Diperlukan 150-200 ml air




<!--inarticleads2-->

##### Cara membuat  Risol Mayo:

1. Campur semua bahan kulit, kecuali air. Yuang air setengah dl kemudian aduk sambil tuang sisa air sedikit demi sedikit. Campur rata dan pastikan tdk ada lg yg menggerindil.
1. Saring adonan kulit, dan diamkan sekitar 15 menit.
1. Siapkan isiannya: panggang smoke beef di atas teflon sebentar.. jgn sampai terlalu kering. Rebus telur selama -+10 menit, lalu angkat dan guyur air dingin atau kalo tdk ada cukup dg air biasa saja. Campur mayonais dan saos tomat. Sisihkan.
1. Panaskan teflon dengan api sedang cenderung kecil. Pakai teflon yg bagus, tdk dipakai untuk menumis. Bentuk kulit risol diatas teflon, tunggu sampai kulit ikut bergerak jika teflon di goyang2, jd g perlu di dicek menggunakan spatula atau yg lain.. paham tak sampai sini😅🤭 pokonya gt lah😂 setelah adonan kulit habis, dinginkan kulit risol.
1. Isi kulit dg isian td, lalu lipat seeeesuka hati🤭
1. Campur tepung, garam dan air untuk pelapis. Masukkan risol yg adh dibentuk ke dlm tepung, setelah itu lumuri dengan tepung panir. Lakukan sprti itu sampai selesai
1. Panaskan minyak yg agak banyak dengan api sedang, goreng risol sampai coklat keemasan, tiriskan dan sajikan hangat.




Demikianlah cara membuat risol mayo yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan terbukti, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
