---
description: "Step-by-Step menyiapakan Roti O Cepat"
title: "Step-by-Step menyiapakan Roti O Cepat"
slug: 421-step-by-step-menyiapakan-roti-o-cepat
date: 2020-09-21T22:39:16.945Z
image: https://img-global.cpcdn.com/recipes/39f1ebeb7aae2de4/680x482cq70/roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/39f1ebeb7aae2de4/680x482cq70/roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/39f1ebeb7aae2de4/680x482cq70/roti-o-foto-resep-utama.jpg
author: Katherine Rodgers
ratingvalue: 4.9
reviewcount: 43080
recipeingredient:
- "300 gr Tepung terigu"
- "40 gr gula halus"
- "1 sdt fermipan"
- "1 butir kuning telur"
- "3 sdm margarin"
- " Air 100_120ml"
- " Isian"
- " Coklat batangDCC"
- " Topping"
- "1 butir putih telur"
- "100 gr tepung terigu"
- "100 gr gula halus"
- " Kopi instan Nescafe"
- "100 gr Margarin"
- "2 sdt tepung maizena"
- "1/2 sdt garam halus"
recipeinstructions:
- "Siapkan wadah, masukkan tepung terigu, gula, fermipan, tbm, kuning telur, aduk sampai rata, tambahkan sedikit demi sedikit air sambil uleni sampai kalis elastis ya. Ini adonan harus benar ² Kalis ya biar rotinya lembut."
- "Setelah adonan Kalis, bulatkan adonan, lalu tutup dengan plastik warp, tunggu sampai 30 menit sampai adonan mengembang 2 kali lipat."
- "Setelah adonan mengembang, ambil bulatan kecil, tadi saya timbang sekitar 40 gr ya Bun. Pipihkan lalu berikan isian coklat atau keju juga boleh ya, sesuai selera aja. Bulatkan kembali"
- "Taruh di loyang yang sudah di olesi dengan mentega dan tepung terigu, lakukan sampai adonan habis. Tutup adonan dengan kain lembab Lalu tunggu sampai 60 menit."
- "Sambil menunggu adonan, kita siapkan bahan topping nya ya. Mixer gula halus dan margarin sampai mengembang, lalu masukkan putih telur, mixer sebentar saja, lalu tambahkan tepung terigu, tepung maizena, dan terakhir tambahkan kopi Nescafe yang sudah di larutkan dengan sedikit air hangat. Mixer sebentar saja. Lalu masukkan ke dalam plastik segitiga. Bentuk topping dengan cara melingkar seperti obat nyamuk."
- "Setelah selesai panaskan oven, kalau oven sudah panas, panggang roti O sampai matang dengan api sedang."
- "Kalau sudah matang, angkat dan sajikan. Selamat mencoba 😍rotinya bakalan crispy di luar dan lembut di dalam"
categories:
- Recipe
tags:
- roti
- o

katakunci: roti o 
nutrition: 192 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Lunch

---


![Roti O](https://img-global.cpcdn.com/recipes/39f1ebeb7aae2de4/680x482cq70/roti-o-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita lestarikan karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti roti o yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa ciri khas yang merupakan keragaman Nusantara



Keharmonisan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Roti O untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang dapat anda coba salah satunya roti o yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep roti o tanpa harus bersusah payah.
Berikut ini resep Roti O yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti O:

1. Siapkan 300 gr Tepung terigu
1. Tambah 40 gr gula halus
1. Jangan lupa 1 sdt fermipan
1. Diperlukan 1 butir kuning telur
1. Siapkan 3 sdm margarin
1. Tambah  Air 100_120ml
1. Harus ada  Isian:
1. Jangan lupa  Coklat batang(DCC)
1. Harus ada  Topping:
1. Diperlukan 1 butir putih telur
1. Diperlukan 100 gr tepung terigu
1. Tambah 100 gr gula halus
1. Diperlukan  Kopi instan (Nescafe)
1. Jangan lupa 100 gr Margarin
1. Diperlukan 2 sdt tepung maizena
1. Harap siapkan 1/2 sdt garam halus




<!--inarticleads2-->

##### Instruksi membuat  Roti O:

1. Siapkan wadah, masukkan tepung terigu, gula, fermipan, tbm, kuning telur, aduk sampai rata, tambahkan sedikit demi sedikit air sambil uleni sampai kalis elastis ya. Ini adonan harus benar ² Kalis ya biar rotinya lembut.
1. Setelah adonan Kalis, bulatkan adonan, lalu tutup dengan plastik warp, tunggu sampai 30 menit sampai adonan mengembang 2 kali lipat.
1. Setelah adonan mengembang, ambil bulatan kecil, tadi saya timbang sekitar 40 gr ya Bun. Pipihkan lalu berikan isian coklat atau keju juga boleh ya, sesuai selera aja. Bulatkan kembali
1. Taruh di loyang yang sudah di olesi dengan mentega dan tepung terigu, lakukan sampai adonan habis. Tutup adonan dengan kain lembab Lalu tunggu sampai 60 menit.
1. Sambil menunggu adonan, kita siapkan bahan topping nya ya. Mixer gula halus dan margarin sampai mengembang, lalu masukkan putih telur, mixer sebentar saja, lalu tambahkan tepung terigu, tepung maizena, dan terakhir tambahkan kopi Nescafe yang sudah di larutkan dengan sedikit air hangat. Mixer sebentar saja. Lalu masukkan ke dalam plastik segitiga. Bentuk topping dengan cara melingkar seperti obat nyamuk.
1. Setelah selesai panaskan oven, kalau oven sudah panas, panggang roti O sampai matang dengan api sedang.
1. Kalau sudah matang, angkat dan sajikan. Selamat mencoba 😍rotinya bakalan crispy di luar dan lembut di dalam




Demikianlah cara membuat roti o yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan teruji, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
