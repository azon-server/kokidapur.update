---
description: "Steps menyiapakan Roti O / Roti Meksiko Sempurna"
title: "Steps menyiapakan Roti O / Roti Meksiko Sempurna"
slug: 423-steps-menyiapakan-roti-o-roti-meksiko-sempurna
date: 2020-12-25T13:17:47.903Z
image: https://img-global.cpcdn.com/recipes/61b02002930501fa/680x482cq70/roti-o-roti-meksiko-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/61b02002930501fa/680x482cq70/roti-o-roti-meksiko-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/61b02002930501fa/680x482cq70/roti-o-roti-meksiko-foto-resep-utama.jpg
author: Emily Davidson
ratingvalue: 4.9
reviewcount: 29826
recipeingredient:
- " Bahan Roti "
- "200 g Tepung Terigu"
- "1 butir Telur"
- "1 sdt Ragi"
- "5 sdm Gula Pasir"
- "50 ml Susu Cair"
- "2 sdm Mentega"
- " Bahan Topping"
- "3 sdm Mentega"
- "2 sdm Gula Halus bisa ditambah kalau mau lebih manis"
- "1 butir Telur"
- "1 sdt Vanilli"
- "7 sdm Tepung Terigu"
- "2 sdm Larutan Kopi"
recipeinstructions:
- "Campurkan semua bahan roti kecuali mentega, aduk sampai rata (aku mengaduk pakai tangan). Bila sudah rata tambahkan mentega, aduk hingga kalis."
- "Jika sudah kalis, diamkan setengah jam sampai mengembang. Bila sudah mengembang, ambil sebagian adonan dan beri isian (aku pakai isian mentega), lalu buat bentuk bulat. Saat semua adonan sudah terbentuk, diamkan lagi 1 jam hingga mengembang."
- "Selagi menunggu, buat topping atasnya. Campurkan semua bahan topping dan mixer hingga rata (bisa menggunakan sendok biasa). Masukan adonan topping ke dalam plastik agar mudah dituangkan ke roti."
- "Bila roti sudah mengembang, tuangkan adonan topping ke atas roti, hingga setengah bagian roti."
- "Masukan roti yang sudah bertopping ke dalam oven, dan panggang dengan suhu 170° selama 20 menit (aku pakai pemanas atas dan bawah)."
- "Roti Meksiko siap dihidangkan selagi hangat ♥️."
categories:
- Recipe
tags:
- roti
- o
- 

katakunci: roti o  
nutrition: 121 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Lunch

---


![Roti O / Roti Meksiko](https://img-global.cpcdn.com/recipes/61b02002930501fa/680x482cq70/roti-o-roti-meksiko-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau enak. Ciri khas makanan Nusantara roti o / roti meksiko yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan rumah tangga dapat ditemukan dengan cara mudah. Salah satunya adalah memasak Roti O / Roti Meksiko untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang bisa anda contoh salah satunya roti o / roti meksiko yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep roti o / roti meksiko tanpa harus bersusah payah.
Berikut ini resep Roti O / Roti Meksiko yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 14 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti O / Roti Meksiko:

1. Jangan lupa  Bahan Roti :
1. Jangan lupa 200 g Tepung Terigu
1. Tambah 1 butir Telur
1. Harap siapkan 1 sdt Ragi
1. Tambah 5 sdm Gula Pasir
1. Harus ada 50 ml Susu Cair
1. Tambah 2 sdm Mentega
1. Harus ada  Bahan Topping:
1. Diperlukan 3 sdm Mentega
1. Diperlukan 2 sdm Gula Halus (bisa ditambah kalau mau lebih manis)
1. Tambah 1 butir Telur
1. Tambah 1 sdt Vanilli
1. Siapkan 7 sdm Tepung Terigu
1. Jangan lupa 2 sdm Larutan Kopi




<!--inarticleads2-->

##### Bagaimana membuat  Roti O / Roti Meksiko:

1. Campurkan semua bahan roti kecuali mentega, aduk sampai rata (aku mengaduk pakai tangan). Bila sudah rata tambahkan mentega, aduk hingga kalis.
1. Jika sudah kalis, diamkan setengah jam sampai mengembang. Bila sudah mengembang, ambil sebagian adonan dan beri isian (aku pakai isian mentega), lalu buat bentuk bulat. Saat semua adonan sudah terbentuk, diamkan lagi 1 jam hingga mengembang.
1. Selagi menunggu, buat topping atasnya. Campurkan semua bahan topping dan mixer hingga rata (bisa menggunakan sendok biasa). Masukan adonan topping ke dalam plastik agar mudah dituangkan ke roti.
1. Bila roti sudah mengembang, tuangkan adonan topping ke atas roti, hingga setengah bagian roti.
1. Masukan roti yang sudah bertopping ke dalam oven, dan panggang dengan suhu 170° selama 20 menit (aku pakai pemanas atas dan bawah).
1. Roti Meksiko siap dihidangkan selagi hangat ♥️.




Demikianlah cara membuat roti o / roti meksiko yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
