---
description: "Resep : Roti Boy/ Mexican Bun/ Roti O Cepat"
title: "Resep : Roti Boy/ Mexican Bun/ Roti O Cepat"
slug: 462-resep-roti-boy-mexican-bun-roti-o-cepat
date: 2020-11-05T23:25:05.664Z
image: https://img-global.cpcdn.com/recipes/f7280e7515617844/680x482cq70/roti-boy-mexican-bun-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f7280e7515617844/680x482cq70/roti-boy-mexican-bun-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f7280e7515617844/680x482cq70/roti-boy-mexican-bun-roti-o-foto-resep-utama.jpg
author: Bess Guerrero
ratingvalue: 4.6
reviewcount: 45601
recipeingredient:
- " roti"
- "260 gr terigu cakra"
- "3 gr ragi"
- "30 gr gula pasir"
- "160-180 gr kuning telursusu cair ditimbang ya"
- "30 gr butter"
- "2 gr garam"
- " filling"
- "50 gr buttermargarin"
- "1 sdm gula halus"
- " Topping"
- "50 gr butter"
- "40 gr gula halus"
- "38 gr telur kocok 1 butir telur kecil"
- "1 sdm kopi instan larutkan dengam 1 sdm air panas"
- "50 gr terigu"
recipeinstructions:
- "Buat adonan roti. Pakai metode Killer Soft Bread. Campur semua bahan kecuali butter dan garam. Penambahan telur dan susu pelan2 ya, sampai dirasa setengah kalis. Uleni dengan tangan saja lebih gampang."
- "Lanjut tambahkan butter dan garam. Uleni dengan mixer sampai KALIS ELASTIS. Kurleb 15 menit."
- "Setelah kalis, bagi dan timbang adonan masing2 40 gr."
- "Buat isian. Campur rata dengan sendok/spatula sampai homogen."
- "Ambil bulatan, beri isian, bulatkan rapi. Lakukan sampai adonan habis ya😊"
- "Tutup adonan selama 30 menit."
- "Buat topping. Mixer butter dan gula sampai rata. Tambahkan telur dan kopi, mixer sampai tercampur. Tambahkan terigu, mixer sampai homogen. Masukkan ke piping bag (saya pakai plastik biasa dipotong ujungnya)"
- "Panaskan oven pada suhu 170-180°C selama 10 menit."
- "Buka adonan, beri toping memutar seperti obat nyamuk bakar😁 apa ya istilah lainnya😂"
- "Panggang selama 20-30 menit, api atas bawah. Sesuaikan oven masing2 ya😊"
- "Taraa..sudah jadi."
- "Paling enak disantap pas anget."
- "Tapi kata suami paa dingin juga enak, udah layak jual kata suamikkk😆😆😆"
- "Semoga bermanfaat😊"
- "Selamat mencoba😉"
- ""
categories:
- Recipe
tags:
- roti
- boy
- mexican

katakunci: roti boy mexican 
nutrition: 124 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT30M"
recipeyield: "2"
recipecategory: Lunch

---


![Roti Boy/ Mexican Bun/ Roti O](https://img-global.cpcdn.com/recipes/f7280e7515617844/680x482cq70/roti-boy-mexican-bun-roti-o-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang patut kita jaga karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti roti boy/ mexican bun/ roti o yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa keistimewahan yang merupakan keragaman Nusantara



Keharmonisan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Roti Boy/ Mexican Bun/ Roti O untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang bisa anda contoh salah satunya roti boy/ mexican bun/ roti o yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini anda bisa dengan cepat menemukan resep roti boy/ mexican bun/ roti o tanpa harus bersusah payah.
Berikut ini resep Roti Boy/ Mexican Bun/ Roti O yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 16 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Boy/ Mexican Bun/ Roti O:

1. Tambah  roti:
1. Jangan lupa 260 gr terigu cakra
1. Harap siapkan 3 gr ragi
1. Harus ada 30 gr gula pasir
1. Dibutuhkan 160-180 gr kuning telur+susu cair (ditimbang ya)
1. Siapkan 30 gr butter
1. Siapkan 2 gr garam
1. Harus ada  filling:
1. Diperlukan 50 gr butter/margarin
1. Jangan lupa 1 sdm gula halus
1. Siapkan  Topping:
1. Dibutuhkan 50 gr butter
1. Tambah 40 gr gula halus
1. Jangan lupa 38 gr telur kocok (1 butir telur kecil)
1. Tambah 1 sdm kopi instan (larutkan dengam 1 sdm air panas)
1. Siapkan 50 gr terigu




<!--inarticleads2-->

##### Cara membuat  Roti Boy/ Mexican Bun/ Roti O:

1. Buat adonan roti. Pakai metode Killer Soft Bread. Campur semua bahan kecuali butter dan garam. Penambahan telur dan susu pelan2 ya, sampai dirasa setengah kalis. Uleni dengan tangan saja lebih gampang.
1. Lanjut tambahkan butter dan garam. Uleni dengan mixer sampai KALIS ELASTIS. Kurleb 15 menit.
1. Setelah kalis, bagi dan timbang adonan masing2 40 gr.
1. Buat isian. Campur rata dengan sendok/spatula sampai homogen.
1. Ambil bulatan, beri isian, bulatkan rapi. Lakukan sampai adonan habis ya😊
1. Tutup adonan selama 30 menit.
1. Buat topping. Mixer butter dan gula sampai rata. Tambahkan telur dan kopi, mixer sampai tercampur. Tambahkan terigu, mixer sampai homogen. Masukkan ke piping bag (saya pakai plastik biasa dipotong ujungnya)
1. Panaskan oven pada suhu 170-180°C selama 10 menit.
1. Buka adonan, beri toping memutar seperti obat nyamuk bakar😁 apa ya istilah lainnya😂
1. Panggang selama 20-30 menit, api atas bawah. Sesuaikan oven masing2 ya😊
1. Taraa..sudah jadi.
1. Paling enak disantap pas anget.
1. Tapi kata suami paa dingin juga enak, udah layak jual kata suamikkk😆😆😆
1. Semoga bermanfaat😊
1. Selamat mencoba😉
1. 




Demikianlah cara membuat roti boy/ mexican bun/ roti o yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan terbukti, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
