---
description: "Bagaimana untuk menyiapakan Roti Boy / Roti O / mexican Buns / Roti Kopi Homemade"
title: "Bagaimana untuk menyiapakan Roti Boy / Roti O / mexican Buns / Roti Kopi Homemade"
slug: 336-bagaimana-untuk-menyiapakan-roti-boy-roti-o-mexican-buns-roti-kopi-homemade
date: 2021-01-04T17:56:08.795Z
image: https://img-global.cpcdn.com/recipes/dbafed65b7a6cefa/680x482cq70/roti-boy-roti-o-mexican-buns-roti-kopi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dbafed65b7a6cefa/680x482cq70/roti-boy-roti-o-mexican-buns-roti-kopi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dbafed65b7a6cefa/680x482cq70/roti-boy-roti-o-mexican-buns-roti-kopi-foto-resep-utama.jpg
author: Beatrice Estrada
ratingvalue: 4.8
reviewcount: 10745
recipeingredient:
- " Bahan Roti "
- " Biang  tangzong"
- "25 gram tepung terigu Cakra"
- "125 ml air"
- " Bahan adonan "
- "225 gram tepung terigu Cakra  50 gram tepung terigu segitiga"
- "1 SDM susu bubuk"
- "40 gram gula pasir"
- "1 sdt ragi instan"
- "1 butir kuning telur"
- "60 ml air  susu cair"
- "40 gram margarin"
- " Bahan filling "
- "15 gram Bekukan margarin kedalam freezer Potong"
- "75 gram margarin"
- "60 gram gula halus"
- "1 Bks kopi luwak"
- "1 butir putih telur"
- "1 Bks Nescafe classic di larutkan dengan sedikit air"
- "50 gram tepung"
- "10 gram tepung beras"
- "15 gram tepung maizena"
- "1 sdt coklat bubuk"
- "1/4 sdt baking powder"
recipeinstructions:
- "Cara membuat biang / tangzong"
- "Masak tepung dengan air aduk rata hingga adonan Kalis. Angkat dan dinginkan"
- "Masukan semua bahan adonan + biang kecuali margarin aduk rata hingga 1/2 Kalis. Masukan margarin aduk rata hingga bener bener Kalis"
- "Timbang 50 gram lakukan hingga adonan habis"
- "Isi adonan dengan margarin yg sudah di bekukan bulatkan dan istirahat selama 45 menit."
- "Cara membuat bahan filling:"
- "Mixer margarin, gula dan kopi luwak hingga pucat, masukan putih telur mixer hingga tercampur rata."
- "Masukan semua sisa bahan mixer sebentar sampai Tercampur rata"
- "Masukan ke dalam papping bag, dinginkan ke dalam freezer kurleb 15 menit"
- "Ambil adonan filling dalam kulkas semprot di atas adonan roti lakukan hingga adonan habis"
- "Panaskan oven, oven adonan hingga matang kurleb 20 menit angkat dan sajikan"
- "Selamat mencoba 🤗"
categories:
- Recipe
tags:
- roti
- boy
- 

katakunci: roti boy  
nutrition: 273 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dinner

---


![Roti Boy / Roti O / mexican Buns / Roti Kopi](https://img-global.cpcdn.com/recipes/dbafed65b7a6cefa/680x482cq70/roti-boy-roti-o-mexican-buns-roti-kopi-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita lestarikan karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti roti boy / roti o / mexican buns / roti kopi yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa keistimewahan yang merupakan keragaman Nusantara



Kedekatan rumah tangga bisa didapat dengan cara simple. Diantaranya adalah membuat makanan Roti Boy / Roti O / mexican Buns / Roti Kopi untuk keluarga. kebersamaan makan bersama anak sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang dapat anda coba salah satunya roti boy / roti o / mexican buns / roti kopi yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep roti boy / roti o / mexican buns / roti kopi tanpa harus bersusah payah.
Seperti resep Roti Boy / Roti O / mexican Buns / Roti Kopi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 12 langkah dan 24 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Boy / Roti O / mexican Buns / Roti Kopi:

1. Diperlukan  Bahan Roti :
1. Jangan lupa  Biang / tangzong
1. Tambah 25 gram tepung terigu Cakra
1. Tambah 125 ml air
1. Harap siapkan  Bahan adonan :
1. Jangan lupa 225 gram tepung terigu Cakra + 50 gram tepung terigu segitiga
1. Tambah 1 SDM susu bubuk
1. Diperlukan 40 gram gula pasir
1. Dibutuhkan 1 sdt ragi instan
1. Harus ada 1 butir kuning telur
1. Diperlukan 60 ml air / susu cair
1. Harus ada 40 gram margarin
1. Tambah  Bahan filling :
1. Siapkan 15 gram Bekukan margarin kedalam freezer. Potong²
1. Dibutuhkan 75 gram margarin
1. Harap siapkan 60 gram gula halus
1. Harap siapkan 1 Bks kopi luwak
1. Dibutuhkan 1 butir putih telur
1. Dibutuhkan 1 Bks Nescafe classic di larutkan dengan sedikit air
1. Jangan lupa 50 gram tepung
1. Harus ada 10 gram tepung beras
1. Tambah 15 gram tepung maizena
1. Siapkan 1 sdt coklat bubuk
1. Harus ada 1/4 sdt baking powder




<!--inarticleads2-->

##### Instruksi membuat  Roti Boy / Roti O / mexican Buns / Roti Kopi:

1. Cara membuat biang / tangzong
1. Masak tepung dengan air aduk rata hingga adonan Kalis. Angkat dan dinginkan
1. Masukan semua bahan adonan + biang kecuali margarin aduk rata hingga 1/2 Kalis. Masukan margarin aduk rata hingga bener bener Kalis
1. Timbang 50 gram lakukan hingga adonan habis
1. Isi adonan dengan margarin yg sudah di bekukan bulatkan dan istirahat selama 45 menit.
1. Cara membuat bahan filling:
1. Mixer margarin, gula dan kopi luwak hingga pucat, masukan putih telur mixer hingga tercampur rata.
1. Masukan semua sisa bahan mixer sebentar sampai Tercampur rata
1. Masukan ke dalam papping bag, dinginkan ke dalam freezer kurleb 15 menit
1. Ambil adonan filling dalam kulkas semprot di atas adonan roti lakukan hingga adonan habis
1. Panaskan oven, oven adonan hingga matang kurleb 20 menit angkat dan sajikan
1. Selamat mencoba 🤗




Demikianlah cara membuat roti boy / roti o / mexican buns / roti kopi yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan cepat, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
