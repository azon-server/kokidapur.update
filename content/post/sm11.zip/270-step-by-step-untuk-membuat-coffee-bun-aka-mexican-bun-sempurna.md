---
description: "Step-by-Step untuk membuat Coffee Bun a.k.a. Mexican Bun Sempurna"
title: "Step-by-Step untuk membuat Coffee Bun a.k.a. Mexican Bun Sempurna"
slug: 270-step-by-step-untuk-membuat-coffee-bun-aka-mexican-bun-sempurna
date: 2020-11-18T13:32:05.318Z
image: https://img-global.cpcdn.com/recipes/a047c95e02dfc821/680x482cq70/coffee-bun-aka-mexican-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a047c95e02dfc821/680x482cq70/coffee-bun-aka-mexican-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a047c95e02dfc821/680x482cq70/coffee-bun-aka-mexican-bun-foto-resep-utama.jpg
author: Jeremy Hogan
ratingvalue: 4.9
reviewcount: 44142
recipeingredient:
- " Bahan A"
- "300 gram tepung protein tinggi"
- "50 gram gula pasir"
- "7 gram ragi instan"
- "100 gram susu cair"
- "100 gram whipping cream cairsusu cair"
- " Bahan B"
- "65 gram butter"
- "1/2 sdt garam"
- " Bahan isian"
- "secukupnya Buttermargarin"
- " Topping"
- "70 gram butter"
- "35 gram gula halus"
- "1 butir telur"
- "1 sachet kopi instan tanpa ampas seduh dgn 2 sdm air panas"
- "1/2 sdt pasta mocca optional"
- "70 gram tepung terigu"
recipeinstructions:
- "Siapkan bahan-bahan."
- "Siapkan wadah. Campurkan bahan A. Mixer hingga setengah kalis."
- "Masukkan Bahan B. Mixer sampai kalis elastis."
- "Cek adonan. Jika sudah window pane maka adonan sudah kalis elastis. Bulatkan adonan, taruh di wadah dan tutup dengan serbet. Istirahatkan selama 45 menit hingga mengembang 2x lipat."
- "Setelah mengembang 2x lipat. Kempiskan adonan untuk mengeluarkan gas di dalam adonan."
- "Bagi adonan dengan berat masing-masing 60 gram. Bulatkan dan kemudian tuangkan istirahatkan kembali selama 15 menit. Tutup dengan lap/serbet."
- "Bahan topping. Kocok butter dan gula halus dengan whisk sampai rata. Tambahkan telur, larutan kopi dan pasta mocca. Aduk rata. Tambahkan terigu."
- "Aduk rata adonan topping. Kemudian taruh di plasti segitiga. Jika dirasa adonan lumer, masukkan kulkas beberapa saat."
- "Tipiskan adonan roti dengan rolling pin. Beri isian butter/margarin kemudian bulatkan. Letakkan di loyang. Beri jarak. Pastikan tidak ada filling yang bocor."
- "Istirahatkan adonan sampai mengembang 2x lipat. Semprotkan topping dengan bentuk melingkar sampai 3/4 bulatan. Pastikan semua permukaan tertutup dengan topping."
- "Panggang dengan api sedang selama 25 menit. Saya pakai otang. Utk yang pakai otrik, oven dengan suhu 180 derajat api atas bawah. Utk yg pke otang, kenali oven masing-masing ya."
- "Siap dan sajikan hangat lebih nikmat. Fresh from the oven. Happy weekend 😍😍😍"
categories:
- Recipe
tags:
- coffee
- bun
- aka

katakunci: coffee bun aka 
nutrition: 181 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dinner

---


![Coffee Bun a.k.a. Mexican Bun](https://img-global.cpcdn.com/recipes/a047c95e02dfc821/680x482cq70/coffee-bun-aka-mexican-bun-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga gurih. Ciri khas makanan Nusantara coffee bun a.k.a. mexican bun yang kaya dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Coffee Bun a.k.a. Mexican Bun untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang dapat anda praktekkan salah satunya coffee bun a.k.a. mexican bun yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep coffee bun a.k.a. mexican bun tanpa harus bersusah payah.
Berikut ini resep Coffee Bun a.k.a. Mexican Bun yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 12 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Coffee Bun a.k.a. Mexican Bun:

1. Dibutuhkan  Bahan A:
1. Dibutuhkan 300 gram tepung protein tinggi
1. Jangan lupa 50 gram gula pasir
1. Tambah 7 gram ragi instan
1. Siapkan 100 gram susu cair
1. Siapkan 100 gram whipping cream cair/susu cair
1. Harap siapkan  Bahan B:
1. Dibutuhkan 65 gram butter
1. Dibutuhkan 1/2 sdt garam
1. Diperlukan  Bahan isian:
1. Dibutuhkan secukupnya Butter/margarin
1. Jangan lupa  Topping:
1. Dibutuhkan 70 gram butter
1. Siapkan 35 gram gula halus
1. Harap siapkan 1 butir telur
1. Dibutuhkan 1 sachet kopi instan tanpa ampas seduh dgn 2 sdm air panas
1. Dibutuhkan 1/2 sdt pasta mocca (optional)
1. Siapkan 70 gram tepung terigu




<!--inarticleads2-->

##### Langkah membuat  Coffee Bun a.k.a. Mexican Bun:

1. Siapkan bahan-bahan.
1. Siapkan wadah. Campurkan bahan A. Mixer hingga setengah kalis.
1. Masukkan Bahan B. Mixer sampai kalis elastis.
1. Cek adonan. Jika sudah window pane maka adonan sudah kalis elastis. Bulatkan adonan, taruh di wadah dan tutup dengan serbet. Istirahatkan selama 45 menit hingga mengembang 2x lipat.
1. Setelah mengembang 2x lipat. Kempiskan adonan untuk mengeluarkan gas di dalam adonan.
1. Bagi adonan dengan berat masing-masing 60 gram. Bulatkan dan kemudian tuangkan istirahatkan kembali selama 15 menit. Tutup dengan lap/serbet.
1. Bahan topping. Kocok butter dan gula halus dengan whisk sampai rata. Tambahkan telur, larutan kopi dan pasta mocca. Aduk rata. Tambahkan terigu.
1. Aduk rata adonan topping. Kemudian taruh di plasti segitiga. Jika dirasa adonan lumer, masukkan kulkas beberapa saat.
1. Tipiskan adonan roti dengan rolling pin. Beri isian butter/margarin kemudian bulatkan. Letakkan di loyang. Beri jarak. Pastikan tidak ada filling yang bocor.
1. Istirahatkan adonan sampai mengembang 2x lipat. Semprotkan topping dengan bentuk melingkar sampai 3/4 bulatan. Pastikan semua permukaan tertutup dengan topping.
1. Panggang dengan api sedang selama 25 menit. Saya pakai otang. Utk yang pakai otrik, oven dengan suhu 180 derajat api atas bawah. Utk yg pke otang, kenali oven masing-masing ya.
1. Siap dan sajikan hangat lebih nikmat. Fresh from the oven. Happy weekend 😍😍😍




Demikianlah cara membuat coffee bun a.k.a. mexican bun yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
