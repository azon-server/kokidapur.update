---
description: "Steps untuk menyiapakan Coffee Bun/Roti O teraktual"
title: "Steps untuk menyiapakan Coffee Bun/Roti O teraktual"
slug: 392-steps-untuk-menyiapakan-coffee-bun-roti-o-teraktual
date: 2021-01-13T23:21:43.815Z
image: https://img-global.cpcdn.com/recipes/8bb51f21f9796095/680x482cq70/coffee-bunroti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8bb51f21f9796095/680x482cq70/coffee-bunroti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8bb51f21f9796095/680x482cq70/coffee-bunroti-o-foto-resep-utama.jpg
author: Myrtie Stokes
ratingvalue: 5
reviewcount: 39352
recipeingredient:
- "400 gr tepung protein tinggi me  pakai cakra kembar"
- "100 gr tepung protein sedang me  pakai kunci biru"
- "100 gr gula pasir"
- "14 gr ragi instan"
- "27 gr susu bubuk me  dancow sachet"
- "200 ml air hangat"
- "3 kuning telur"
- "100 gt unsalted butter me blue band margarin"
- " Bahan Isian "
- " Salted butter me  pakai blue band margarin"
- " Bahan Topping"
- "3 putih telur"
- "120 gr gula"
- "200 gr margarin"
- "2 bks kopi instan me  good day cappucino"
- "100 ml air panas"
- "4 tetes pasta kopi"
recipeinstructions:
- "Seduh susu dengan air hangat, sesendok gula (dr takaran yg 100 gr), aduk rata. Tunggu hangat kuku, masukkan ragi, aduk, diamkan sampai berbuih"
- "Campurkan terigu + gula aduk rata. Masukkan air ragi dan susu sedikit sedikit, aduk menggunakan spatula kayu, jika sudah mulai tercampur boleh lanjut menggunakan tangan (bagi yg tdk pakai mixer roti) sampai adonan kalis"
- "Tambahkan margarin, uleni lagi sampai kalis elastis. Istirahatkan selama 60 menit atau sampai mengembang 2x lebih besar"
- "Setelah mengembang, kempiskan adonan, uleni sebentar kurleb 10 menit bagi sama banyak dgn berat masing-masing 50 gr, bulatkan, lalu pipihkan isi dengan kurleb 1/2 sdt margarin, tutup adonan, bulatkan lagi, lalu istirahatkan kembali selama 30 menit sampai mengembang lbh besar lg"
- "Sambil menunggu proofing ke 2, siapkan topping. Kocok putih telur dan gula sampai kaku. Di tempat terpisah kocok margarin sampai lembut. Masukkan terigu. Aduk rata. kopi seduh dgn 100 ml air panas, lalu masukkan ke dalam adonan, aduk rata. Campurkan adonan putih telur dan terigu, aduk rata. Masukkan ke dalam piping bag."
- "Panaskan oven dgn api sedang (harus sdh panas pada saat adonan roti dimasukkan). Saya pakai oven tangkring biasa yaa..."
- "Setelah adonan diistirahatkan, hias atasnya dgn topping dibuat melingkar spt obat nyamuk, menutupi 3/4 permukaan roti (maaaf yg ini lupa di foto krn sambil bolak balik ngurusin yg lainnya 😁😂)"
- "Masukkan roti ke dalam oven, panggang kurleb 15-20 menit atau topping kelihatan sdh kering. Angkat sajikan hangat."
categories:
- Recipe
tags:
- coffee
- bunroti
- o

katakunci: coffee bunroti o 
nutrition: 252 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Dessert

---


![Coffee Bun/Roti O](https://img-global.cpcdn.com/recipes/8bb51f21f9796095/680x482cq70/coffee-bunroti-o-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang setidaknya kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti coffee bun/roti o yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Nusantara

Kedekatan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Coffee Bun/Roti O untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang dapat anda contoh salah satunya coffee bun/roti o yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep coffee bun/roti o tanpa harus bersusah payah.
Seperti resep Coffee Bun/Roti O yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Coffee Bun/Roti O:

1. Harap siapkan 400 gr tepung protein tinggi (me : pakai cakra kembar)
1. Diperlukan 100 gr tepung protein sedang (me : pakai kunci biru)
1. Harap siapkan 100 gr gula pasir
1. Diperlukan 14 gr ragi instan
1. Diperlukan 27 gr susu bubuk (me : dancow sachet)
1. Tambah 200 ml air hangat
1. Siapkan 3 kuning telur
1. Dibutuhkan 100 gt unsalted butter (me :blue band margarin)
1. Jangan lupa  Bahan Isian :
1. Jangan lupa  Salted butter (me : pakai blue band margarin)
1. Dibutuhkan  Bahan Topping
1. Dibutuhkan 3 putih telur
1. Jangan lupa 120 gr gula
1. Harus ada 200 gr margarin
1. Harus ada 2 bks kopi instan (me : good day cappucino)
1. Harus ada 100 ml air panas
1. Tambah 4 tetes pasta kopi




<!--inarticleads2-->

##### Cara membuat  Coffee Bun/Roti O:

1. Seduh susu dengan air hangat, sesendok gula (dr takaran yg 100 gr), aduk rata. Tunggu hangat kuku, masukkan ragi, aduk, diamkan sampai berbuih
1. Campurkan terigu + gula aduk rata. Masukkan air ragi dan susu sedikit sedikit, aduk menggunakan spatula kayu, jika sudah mulai tercampur boleh lanjut menggunakan tangan (bagi yg tdk pakai mixer roti) sampai adonan kalis
1. Tambahkan margarin, uleni lagi sampai kalis elastis. Istirahatkan selama 60 menit atau sampai mengembang 2x lebih besar
1. Setelah mengembang, kempiskan adonan, uleni sebentar kurleb 10 menit bagi sama banyak dgn berat masing-masing 50 gr, bulatkan, lalu pipihkan isi dengan kurleb 1/2 sdt margarin, tutup adonan, bulatkan lagi, lalu istirahatkan kembali selama 30 menit sampai mengembang lbh besar lg
1. Sambil menunggu proofing ke 2, siapkan topping. Kocok putih telur dan gula sampai kaku. Di tempat terpisah kocok margarin sampai lembut. Masukkan terigu. Aduk rata. kopi seduh dgn 100 ml air panas, lalu masukkan ke dalam adonan, aduk rata. Campurkan adonan putih telur dan terigu, aduk rata. Masukkan ke dalam piping bag.
1. Panaskan oven dgn api sedang (harus sdh panas pada saat adonan roti dimasukkan). Saya pakai oven tangkring biasa yaa...
1. Setelah adonan diistirahatkan, hias atasnya dgn topping dibuat melingkar spt obat nyamuk, menutupi 3/4 permukaan roti (maaaf yg ini lupa di foto krn sambil bolak balik ngurusin yg lainnya 😁😂)
1. Masukkan roti ke dalam oven, panggang kurleb 15-20 menit atau topping kelihatan sdh kering. Angkat sajikan hangat.




Demikianlah cara membuat coffee bun/roti o yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan terbukti, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
