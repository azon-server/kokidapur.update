---
description: "Step-by-Step untuk menyiapakan Risol Mayo Teruji"
title: "Step-by-Step untuk menyiapakan Risol Mayo Teruji"
slug: 90-step-by-step-untuk-menyiapakan-risol-mayo-teruji
date: 2020-09-29T05:34:29.430Z
image: https://img-global.cpcdn.com/recipes/c322eb1cf5a25c28/680x482cq70/risol-mayo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c322eb1cf5a25c28/680x482cq70/risol-mayo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c322eb1cf5a25c28/680x482cq70/risol-mayo-foto-resep-utama.jpg
author: Alma Moran
ratingvalue: 4.7
reviewcount: 49982
recipeingredient:
- " Bahan Kulit"
- "250 gr tepung terigu serbaguna"
- "50 gr tepung tapioka"
- "1 btr telur ayam"
- "20 gr gula pasir"
- "25 gr margarin"
- "50 ml minyak goreng"
- " Garam"
- " Air"
- " Bahan isian"
- "3 btr telur ayam rebus"
- "300 gr mayonais"
- " Garam"
- " Oregano"
- "5 lembar daging burger bisa juga pakai daging asap"
- " Keju cheddar parut"
- " Saos tomat"
- " Bahan pencelup"
- "1 btr telur ayam kocok lepas"
- "10 sdm adonan bahan kulit"
- " Tepung panir"
- " Minyak goreng"
recipeinstructions:
- "Membuat adonan kulit risol : Campur semua bahan kulit, aduk dengan wisk hingga tercampur rata dan tidak berbutir2, saring bila perlu. Panaskan dan olesi wajan datar anti lengket (diameter 20 cm) dengan minyak/margarin. Ambil adonan kulit sebanyak 1 sendok sayur, tuang kedalam wajan. Ratakan ke seluruh permukaan wajan dan tunggu hingga matang. Tanda kulit yang sudah matang adalah pinggirannya mengelupas sendiri dari wajan. Angkat dan sisihkan."
- "Membuat isian risol : Olesi loyang anti lengket dengan minyak/margarin, kemudian panggang daging burger hingga matang tetapi jangan sampai kering. Angkat, potong2 sesuai ukuran panjang risol. Sisihkan dahulu."
- "Belah/cincang kasar telur rebus menggunakan garpu, campur dengan mayonais, taburi garam dan oregano secukupnya. Sisihkan."
- "Membungkus risol : Ambil 1 kulit risol, ambil 1 sdt penuh campuran telur rebus, taruh di tengah, diikuti dengan potongan daging burger/asap, saos tomat, dan keju parut. Tambahkan campuran telur rebus lagi bila masih kurang. Kemudian lipat bagian atas, samping, dan gulung sambil agak ditekan untuk memadatkan isian nya. Rekatkan lipatan terakhir kulit risol dengan mengoleskan sedikit bahan pencelup agar isinya tidak meluber saat digoreng."
- "Celupkan risol ke dalam bahan pencelup, kemudian gulingkan ke dalam tepung roti. Tekan-tekan sedikit agar tepung roti menempel sempurna di kulit risol."
- "Taruh risol dalam wadah plastik, dan simpan di freezer dahulu agar tepung roti tidak mudah rontok saat digoreng"
- "Menggoreng risol : gunakan api sedang, minyak harus benar-benar panas dan usahakan jumlahnya bisa menutup seluruh permukaan risol agar matangnya merata,, jangan dibolak balik untuk mengurangi kemungkinan kulit risol sobek dan isinya meluber (ambyar)"
- "Sajikan dengan saos sambal botolan atau cabe rawit hijau"
- "Panaskan pan anti lengket, olesi sedikit minyak. Tuang"
categories:
- Recipe
tags:
- risol
- mayo

katakunci: risol mayo 
nutrition: 175 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dessert

---


![Risol Mayo](https://img-global.cpcdn.com/recipes/c322eb1cf5a25c28/680x482cq70/risol-mayo-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang setidaknya kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti risol mayo yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Nusantara

Keharmonisan rumah tangga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Risol Mayo untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang bisa anda coba salah satunya risol mayo yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep risol mayo tanpa harus bersusah payah.
Seperti resep Risol Mayo yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 9 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Risol Mayo:

1. Jangan lupa  Bahan Kulit
1. Tambah 250 gr tepung terigu serbaguna
1. Diperlukan 50 gr tepung tapioka
1. Tambah 1 btr telur ayam
1. Diperlukan 20 gr gula pasir
1. Dibutuhkan 25 gr margarin
1. Diperlukan 50 ml minyak goreng
1. Siapkan  Garam
1. Siapkan  Air
1. Jangan lupa  Bahan isian
1. Harus ada 3 btr telur ayam, rebus
1. Diperlukan 300 gr mayonais
1. Harus ada  Garam
1. Jangan lupa  Oregano
1. Dibutuhkan 5 lembar daging burger (bisa juga pakai daging asap)
1. Dibutuhkan  Keju cheddar, parut
1. Tambah  Saos tomat
1. Harap siapkan  Bahan pencelup
1. Dibutuhkan 1 btr telur ayam, kocok lepas
1. Diperlukan 10 sdm adonan bahan kulit
1. Harus ada  Tepung panir
1. Harus ada  Minyak goreng




<!--inarticleads2-->

##### Bagaimana membuat  Risol Mayo:

1. Membuat adonan kulit risol : Campur semua bahan kulit, aduk dengan wisk hingga tercampur rata dan tidak berbutir2, saring bila perlu. Panaskan dan olesi wajan datar anti lengket (diameter 20 cm) dengan minyak/margarin. Ambil adonan kulit sebanyak 1 sendok sayur, tuang kedalam wajan. Ratakan ke seluruh permukaan wajan dan tunggu hingga matang. Tanda kulit yang sudah matang adalah pinggirannya mengelupas sendiri dari wajan. Angkat dan sisihkan.
1. Membuat isian risol : Olesi loyang anti lengket dengan minyak/margarin, kemudian panggang daging burger hingga matang tetapi jangan sampai kering. Angkat, potong2 sesuai ukuran panjang risol. Sisihkan dahulu.
1. Belah/cincang kasar telur rebus menggunakan garpu, campur dengan mayonais, taburi garam dan oregano secukupnya. Sisihkan.
1. Membungkus risol : Ambil 1 kulit risol, ambil 1 sdt penuh campuran telur rebus, taruh di tengah, diikuti dengan potongan daging burger/asap, saos tomat, dan keju parut. Tambahkan campuran telur rebus lagi bila masih kurang. Kemudian lipat bagian atas, samping, dan gulung sambil agak ditekan untuk memadatkan isian nya. Rekatkan lipatan terakhir kulit risol dengan mengoleskan sedikit bahan pencelup agar isinya tidak meluber saat digoreng.
1. Celupkan risol ke dalam bahan pencelup, kemudian gulingkan ke dalam tepung roti. Tekan-tekan sedikit agar tepung roti menempel sempurna di kulit risol.
1. Taruh risol dalam wadah plastik, dan simpan di freezer dahulu agar tepung roti tidak mudah rontok saat digoreng
1. Menggoreng risol : gunakan api sedang, minyak harus benar-benar panas dan usahakan jumlahnya bisa menutup seluruh permukaan risol agar matangnya merata,, jangan dibolak balik untuk mengurangi kemungkinan kulit risol sobek dan isinya meluber (ambyar)
1. Sajikan dengan saos sambal botolan atau cabe rawit hijau
1. Panaskan pan anti lengket, olesi sedikit minyak. Tuang




Demikianlah cara membuat risol mayo yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
