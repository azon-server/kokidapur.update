---
description: "Resep : Resep Roti Boy Atau Roti O Dengan Takaran Sendok Favorite"
title: "Resep : Resep Roti Boy Atau Roti O Dengan Takaran Sendok Favorite"
slug: 374-resep-resep-roti-boy-atau-roti-o-dengan-takaran-sendok-favorite
date: 2020-12-15T16:27:45.522Z
image: https://img-global.cpcdn.com/recipes/e7f314cfe28fd761/680x482cq70/resep-roti-boy-atau-roti-o-dengan-takaran-sendok-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e7f314cfe28fd761/680x482cq70/resep-roti-boy-atau-roti-o-dengan-takaran-sendok-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e7f314cfe28fd761/680x482cq70/resep-roti-boy-atau-roti-o-dengan-takaran-sendok-foto-resep-utama.jpg
author: Flora Young
ratingvalue: 4.9
reviewcount: 47143
recipeingredient:
- " Bahan adonannya "
- " Tepung cakra 250 gram 25 sendok makan"
- "1 sendok makan Ragi instan"
- " Gula pasir 100 gram 5 sendok makan"
- "1 butir Telur"
- " Mentega 24 gram 2 sendok makan"
- " Bahan toppingnya "
- " Gula halus 60 gram 5 sendok makan"
- " Mentega 48 gram 4 sendok makan"
- "1/2 sendok makan Kopi instan ABC Moca"
- " Tepung terigu protein sedang 70 gram 7 sendok makan"
- "1/2 sendok makan Pasta moca atau pasta kopi"
- " isiannya "
- " Mentega"
recipeinstructions:
- "Masukkan tepung terigu cakra kedalam wadah sebanyak 250 gram (16 ½ sdm)"
- "Masukkan ragi instan 1 sendok makan"
- "Masukkan gula pasir 100 gram (5 sdm)"
- "Masukkan air 90 ml (6 sdm)"
- "Masukkan telur 1 butir"
- "Aduk dengan mixer hingga bahan tercampur rata, gunakan kecepatan tinggi (boleh juga diuleni pakai tangan)"
- "Jika sudah tercampur rata, tambahkan mentega 24 gram (2 sdm)"
- "Lalu aduk hingga adonan tercampur rata dan khalis"
- "Kemudian diamkan selama 1 jam, jangan lupa tutup dengan kain"
- "Sambil menunggu adonanan ngembang, langsung buat topping rotinya. Pertama masukkan gula halus kedalam wadah sebanyak 60 gram (5 sendok makan)"
- "Lalu masukkan mentega sebanyak 48 gram (4 sdm)"
- "Lalu aduk hingga merata dan berwarna pucat"
- "Lalu masukkan tepung terigu protein sedang sebanyak 70 gram (7 sdm)"
- "Lalu masukkan putih telur 1 butir"
- "Masukkan kopi instan ½ sdm"
- "Masukkan pasta mocca (pasta kopi) ½ sdm"
- "Lalu aduk hingga merata ( 2 menit?"
- "Kemudian masukkan krim kedalam plastik segitiga"
- ""
- "Nah jika sudah 1 jam buka adonan, lalu timbang"
- ""
- "Dan berat adonan sekitar 42 gram jadi adonannya bagi sekitar 12 atau 13 adonan (tiap adoanan sekitar 6 gram)"
- "Kemudian bulatin adonan, lalu tipisin bagian pinggirnya bagian dalam biarkan tebal kemudian masukkan mentega secukupnya"
- "Kemudian tutup adonannya, lalu bulatin lagi"
- ""
- "Kemudian diamkan selama 10 menit"
- "Jika sudah 10 menit, langsung beri topping"
- "Kemudian panggang di oven selama 35 menit dengan suhu 180°c atau sesuaikan dengan suhu oven masing²"
- "Jika sudah 35 menit keluarkan dari oven"
- ""
- "Dan Roti Boy nya siap disajikan 😋 silahkan cek video lengkapnya di channel youtobe Fransiska Tien 🙏"
- "Ini rasanya enak banget, empuk, lembut, nggak nyesal jika nyobain deh 😋 selamat mencoba"
categories:
- Recipe
tags:
- resep
- roti
- boy

katakunci: resep roti boy 
nutrition: 136 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Lunch

---


![Resep Roti Boy Atau Roti O Dengan Takaran Sendok](https://img-global.cpcdn.com/recipes/e7f314cfe28fd761/680x482cq70/resep-roti-boy-atau-roti-o-dengan-takaran-sendok-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti resep roti boy atau roti o dengan takaran sendok yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan keistimewahan yang merupakan keragaman Kita

Keharmonisan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Resep Roti Boy Atau Roti O Dengan Takaran Sendok untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda coba salah satunya resep roti boy atau roti o dengan takaran sendok yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep resep roti boy atau roti o dengan takaran sendok tanpa harus bersusah payah.
Seperti resep Resep Roti Boy Atau Roti O Dengan Takaran Sendok yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 32 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Resep Roti Boy Atau Roti O Dengan Takaran Sendok:

1. Tambah  Bahan adonannya :
1. Harap siapkan  Tepung cakra 250 gram (25 sendok makan)
1. Jangan lupa 1 sendok makan Ragi instan
1. Tambah  Gula pasir 100 gram (5 sendok makan)
1. Harap siapkan 1 butir Telur
1. Dibutuhkan  Mentega 24 gram (2 sendok makan)
1. Harap siapkan  Bahan toppingnya :
1. Harap siapkan  Gula halus 60 gram (5 sendok makan)
1. Harus ada  Mentega 48 gram (4 sendok makan)
1. Harus ada 1/2 sendok makan Kopi instan (ABC Moca)
1. Tambah  Tepung terigu protein sedang 70 gram (7 sendok makan)
1. Tambah 1/2 sendok makan Pasta moca atau pasta kopi
1. Tambah  isiannya :
1. Jangan lupa  Mentega




<!--inarticleads2-->

##### Langkah membuat  Resep Roti Boy Atau Roti O Dengan Takaran Sendok:

1. Masukkan tepung terigu cakra kedalam wadah sebanyak 250 gram (16 ½ sdm)
1. Masukkan ragi instan 1 sendok makan
1. Masukkan gula pasir 100 gram (5 sdm)
1. Masukkan air 90 ml (6 sdm)
1. Masukkan telur 1 butir
1. Aduk dengan mixer hingga bahan tercampur rata, gunakan kecepatan tinggi (boleh juga diuleni pakai tangan)
1. Jika sudah tercampur rata, tambahkan mentega 24 gram (2 sdm)
1. Lalu aduk hingga adonan tercampur rata dan khalis
1. Kemudian diamkan selama 1 jam, jangan lupa tutup dengan kain
1. Sambil menunggu adonanan ngembang, langsung buat topping rotinya. Pertama masukkan gula halus kedalam wadah sebanyak 60 gram (5 sendok makan)
1. Lalu masukkan mentega sebanyak 48 gram (4 sdm)
1. Lalu aduk hingga merata dan berwarna pucat
1. Lalu masukkan tepung terigu protein sedang sebanyak 70 gram (7 sdm)
1. Lalu masukkan putih telur 1 butir
1. Masukkan kopi instan ½ sdm
1. Masukkan pasta mocca (pasta kopi) ½ sdm
1. Lalu aduk hingga merata ( 2 menit?
1. Kemudian masukkan krim kedalam plastik segitiga
1. 
1. Nah jika sudah 1 jam buka adonan, lalu timbang
1. 
1. Dan berat adonan sekitar 42 gram jadi adonannya bagi sekitar 12 atau 13 adonan (tiap adoanan sekitar 6 gram)
1. Kemudian bulatin adonan, lalu tipisin bagian pinggirnya bagian dalam biarkan tebal kemudian masukkan mentega secukupnya
1. Kemudian tutup adonannya, lalu bulatin lagi
1. 
1. Kemudian diamkan selama 10 menit
1. Jika sudah 10 menit, langsung beri topping
1. Kemudian panggang di oven selama 35 menit dengan suhu 180°c atau sesuaikan dengan suhu oven masing²
1. Jika sudah 35 menit keluarkan dari oven
1. 
1. Dan Roti Boy nya siap disajikan 😋 silahkan cek video lengkapnya di channel youtobe Fransiska Tien 🙏
1. Ini rasanya enak banget, empuk, lembut, nggak nyesal jika nyobain deh 😋 selamat mencoba




Demikianlah cara membuat resep roti boy atau roti o dengan takaran sendok yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan terbukti, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
