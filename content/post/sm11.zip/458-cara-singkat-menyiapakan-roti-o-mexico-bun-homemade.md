---
description: "Cara singkat menyiapakan Roti O / Mexico Bun Homemade"
title: "Cara singkat menyiapakan Roti O / Mexico Bun Homemade"
slug: 458-cara-singkat-menyiapakan-roti-o-mexico-bun-homemade
date: 2020-11-27T18:22:14.164Z
image: https://img-global.cpcdn.com/recipes/c0b718561b47f852/680x482cq70/roti-o-mexico-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c0b718561b47f852/680x482cq70/roti-o-mexico-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c0b718561b47f852/680x482cq70/roti-o-mexico-bun-foto-resep-utama.jpg
author: Delia Hansen
ratingvalue: 5
reviewcount: 22147
recipeingredient:
- " Bahan roti"
- "550 gr tepung terigu"
- "1 butir telur"
- "1 butir kuning telur"
- "11 gr ragi"
- "275 ml susu cair hangat"
- "80 gr gula pasir"
- "2 tsp garam"
- "50 gr butter aku pakai blueband"
- " Bahan topping"
- "1 pack kopi instan  1 sdt kopi pahit  15 ml air campur"
- "90 gr butter aku pakai blueband"
- "100 gr gula icing"
- "85 gr tepung terigu"
- "1 butir telur"
- "2 sdm susu bubuk"
- " Bahan filling"
- " Harusnya isi butter tapi aku cuma pakai keju cheddar"
- " Filling optional aja ya "
recipeinstructions:
- "Masukkan gula dan ragi ke dalam susu hangat, aduk rata (tunggu ± 8 menit)"
- "Kocok lepas telur dan masukan ke dalam wadah susu, aduk rata"
- "Siapkan wadah, masukan tepung terigu dan garam aduk rata"
- "Buat lubang di tengah, tuang adonan cair. aduk rata menggunakan sendok atau spatula"
- "Uleni hingga kalis / tidak lengket menggunakan tangan (yang punya mixer roti juga boleh😅)"
- "Masukan butter / margarin, uleni hingga tercampur rata"
- "Banting2 adonan sambil di uleni, sampai adonan elastis dan mulus"
- "Siapkan wadah, olesi dengan minyak. Bulatkan adonan dan Taruh adonan di wadah"
- "Tutup wadah dengan plastik dan kain. Tunggu 1 jam sampai adonan mengembang dua kali lipat"
- "Kempeskan adonan, potong adonan sesuai selera (aku 80gr / 75 gr per pcs)"
- "Bulatkan semua adonan. Beri jarak yaa dan taruh d atas lembaran plastik aja, tunggu 15 menit."
- "Adonan di pipihkan dan di isi dengan filling sesuai selera dan bulatkan kembali, Taruh di loyang yg sudah di lapisi kertas (beri jarak karna roti akan mengembang), tunggu 10 menit"
- "Sambil menunggu buat adonan toping (1. Mixer Telur, margarin, gula di aduk rata sampai halus 2. Masukan campuran kopi, aduk rata 3. Masukan tepung terigu, aduk rata)"
- "Adonan yg sudah mengembang di beri topping (buat melingkar dan rata)"
- "Oven deh sampai matang (api atas bawah)"
- "Selamat mencoba"
categories:
- Recipe
tags:
- roti
- o
- 

katakunci: roti o  
nutrition: 276 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Dessert

---


![Roti O / Mexico Bun](https://img-global.cpcdn.com/recipes/c0b718561b47f852/680x482cq70/roti-o-mexico-bun-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas hingga renyah. Karasteristik kuliner Indonesia roti o / mexico bun yang kaya dengan rempah menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kehangatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Roti O / Mexico Bun untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang dapat anda buat salah satunya roti o / mexico bun yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep roti o / mexico bun tanpa harus bersusah payah.
Berikut ini resep Roti O / Mexico Bun yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 16 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti O / Mexico Bun:

1. Diperlukan  Bahan roti
1. Jangan lupa 550 gr tepung terigu
1. Siapkan 1 butir telur
1. Harus ada 1 butir kuning telur
1. Tambah 11 gr ragi
1. Tambah 275 ml susu cair hangat
1. Siapkan 80 gr gula pasir
1. Harap siapkan 2 tsp garam
1. Harus ada 50 gr butter (aku pakai blueband)
1. Diperlukan  Bahan topping
1. Jangan lupa 1 pack kopi instan + 1 sdt kopi pahit + 15 ml air (campur)
1. Siapkan 90 gr butter (aku pakai blueband)
1. Siapkan 100 gr gula icing
1. Harap siapkan 85 gr tepung terigu
1. Siapkan 1 butir telur
1. Diperlukan 2 sdm susu bubuk
1. Tambah  Bahan filling
1. Siapkan  Harusnya isi butter tapi aku cuma pakai keju cheddar
1. Jangan lupa  Filling optional aja ya 😁




<!--inarticleads2-->

##### Instruksi membuat  Roti O / Mexico Bun:

1. Masukkan gula dan ragi ke dalam susu hangat, aduk rata (tunggu ± 8 menit)
1. Kocok lepas telur dan masukan ke dalam wadah susu, aduk rata
1. Siapkan wadah, masukan tepung terigu dan garam aduk rata
1. Buat lubang di tengah, tuang adonan cair. aduk rata menggunakan sendok atau spatula
1. Uleni hingga kalis / tidak lengket menggunakan tangan (yang punya mixer roti juga boleh😅)
1. Masukan butter / margarin, uleni hingga tercampur rata
1. Banting2 adonan sambil di uleni, sampai adonan elastis dan mulus
1. Siapkan wadah, olesi dengan minyak. Bulatkan adonan dan Taruh adonan di wadah
1. Tutup wadah dengan plastik dan kain. Tunggu 1 jam sampai adonan mengembang dua kali lipat
1. Kempeskan adonan, potong adonan sesuai selera (aku 80gr / 75 gr per pcs)
1. Bulatkan semua adonan. Beri jarak yaa dan taruh d atas lembaran plastik aja, tunggu 15 menit.
1. Adonan di pipihkan dan di isi dengan filling sesuai selera dan bulatkan kembali, Taruh di loyang yg sudah di lapisi kertas (beri jarak karna roti akan mengembang), tunggu 10 menit
1. Sambil menunggu buat adonan toping (1. Mixer Telur, margarin, gula di aduk rata sampai halus 2. Masukan campuran kopi, aduk rata 3. Masukan tepung terigu, aduk rata)
1. Adonan yg sudah mengembang di beri topping (buat melingkar dan rata)
1. Oven deh sampai matang (api atas bawah)
1. Selamat mencoba




Demikianlah cara membuat roti o / mexico bun yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
