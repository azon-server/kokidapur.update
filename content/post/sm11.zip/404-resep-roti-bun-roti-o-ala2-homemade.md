---
description: "Resep : Roti Bun/Roti O ala2 Homemade"
title: "Resep : Roti Bun/Roti O ala2 Homemade"
slug: 404-resep-roti-bun-roti-o-ala2-homemade
date: 2020-12-21T21:28:56.944Z
image: https://img-global.cpcdn.com/recipes/289a63ea28f663a2/680x482cq70/roti-bunroti-o-ala2-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/289a63ea28f663a2/680x482cq70/roti-bunroti-o-ala2-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/289a63ea28f663a2/680x482cq70/roti-bunroti-o-ala2-foto-resep-utama.jpg
author: Lily Parsons
ratingvalue: 4.3
reviewcount: 30603
recipeingredient:
- " Bahan Adonan Roti"
- "250 gr Tepung terigu protein tinggi"
- "50 gr Gula pasir"
- "1 sdt Ragi Instant"
- "150 cc Air dingin"
- "2 SDM susu bubuk"
- "1 butir Telur"
- "50 gr Margarin"
- " Bahan isi"
- "secukupnya Margarin"
- " Topping"
- "50 gr Tepung terigu protein sedang"
- "50 gr Gula pasir"
- "1 Sachet Kopi Instant"
- "50 gr Margarin"
- "1 butir Putih Telur"
recipeinstructions:
- "Campurkan semua bahan adonan roti kedalam mangkok besar, kocok menggunakan mikser dengan spiral"
- "Setelah Kalis, tutup adonan dengan plastik wrap dan diamkan selama 1 jam hingga adonan mengembang 2x lipat"
- "Setelah 1 jam, kempeskan adonan dan bagi menjadi 11 bulatan seberat kurang lebih 40 gr masing-masing"
- "Pipihkan adonan lalu isi dengan margarin secukupnya, kemudian bulatkan kembali dengan mencubit - cubit bagian pinggir hingga menutupi margarin"
- "Susun di loyang dengan beri jarak karena adonan akan kembali mengembang"
- "Lakukan hingga semua adonan terisi, diamkan kembali adonan selama 15 menit"
- "Buat topping dengan mencampurkan semua bahan sampai creami, lalu masukkan kedalam piping bag"
- "Semprotkan melingkar diatas adonan yg telah didiamkan tadi lalu panggang di oven bersuhu kurleb 150⁰ selama 40 menit."
- "Keluarkan dari oven dan siap disajikan"
categories:
- Recipe
tags:
- roti
- bunroti
- o

katakunci: roti bunroti o 
nutrition: 300 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Dinner

---


![Roti Bun/Roti O ala2](https://img-global.cpcdn.com/recipes/289a63ea28f663a2/680x482cq70/roti-bunroti-o-ala2-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang harus kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti roti bun/roti o ala2 yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa ciri khas yang merupakan keragaman Nusantara



Kedekatan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Roti Bun/Roti O ala2 untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang bisa anda coba salah satunya roti bun/roti o ala2 yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep roti bun/roti o ala2 tanpa harus bersusah payah.
Berikut ini resep Roti Bun/Roti O ala2 yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Bun/Roti O ala2:

1. Diperlukan  Bahan Adonan Roti
1. Tambah 250 gr Tepung terigu protein tinggi
1. Harus ada 50 gr Gula pasir
1. Dibutuhkan 1 sdt Ragi Instant
1. Harap siapkan 150 cc Air dingin
1. Harus ada 2 SDM susu bubuk
1. Harap siapkan 1 butir Telur
1. Tambah 50 gr Margarin
1. Harap siapkan  Bahan isi
1. Dibutuhkan secukupnya Margarin
1. Dibutuhkan  Topping
1. Tambah 50 gr Tepung terigu protein sedang
1. Diperlukan 50 gr Gula pasir
1. Siapkan 1 Sachet Kopi Instant
1. Siapkan 50 gr Margarin
1. Siapkan 1 butir Putih Telur




<!--inarticleads2-->

##### Cara membuat  Roti Bun/Roti O ala2:

1. Campurkan semua bahan adonan roti kedalam mangkok besar, kocok menggunakan mikser dengan spiral
1. Setelah Kalis, tutup adonan dengan plastik wrap dan diamkan selama 1 jam hingga adonan mengembang 2x lipat
1. Setelah 1 jam, kempeskan adonan dan bagi menjadi 11 bulatan seberat kurang lebih 40 gr masing-masing
1. Pipihkan adonan lalu isi dengan margarin secukupnya, kemudian bulatkan kembali dengan mencubit - cubit bagian pinggir hingga menutupi margarin
1. Susun di loyang dengan beri jarak karena adonan akan kembali mengembang
1. Lakukan hingga semua adonan terisi, diamkan kembali adonan selama 15 menit
1. Buat topping dengan mencampurkan semua bahan sampai creami, lalu masukkan kedalam piping bag
1. Semprotkan melingkar diatas adonan yg telah didiamkan tadi lalu panggang di oven bersuhu kurleb 150⁰ selama 40 menit.
1. Keluarkan dari oven dan siap disajikan




Demikianlah cara membuat roti bun/roti o ala2 yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
