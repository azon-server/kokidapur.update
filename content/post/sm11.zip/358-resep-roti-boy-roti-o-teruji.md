---
description: "Resep : Roti Boy/ Roti O Teruji"
title: "Resep : Roti Boy/ Roti O Teruji"
slug: 358-resep-roti-boy-roti-o-teruji
date: 2021-01-04T10:43:51.388Z
image: https://img-global.cpcdn.com/recipes/d3b431d66a0ed105/680x482cq70/roti-boy-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d3b431d66a0ed105/680x482cq70/roti-boy-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d3b431d66a0ed105/680x482cq70/roti-boy-roti-o-foto-resep-utama.jpg
author: Alexander Foster
ratingvalue: 4
reviewcount: 39419
recipeingredient:
- "1 kg Tepung Cakra"
- "100 gram gula pasir"
- "11 gram"
- "100 gram margarin"
- "1/2 sdt garam"
- "550 ml air es"
- " Toping"
- "4 gram kopi instan"
- "6 sdm air panas"
- "100 gram Tepung terigu"
- "1 butir telur"
- "80 gram Mentega"
- "60 gram gula pasir"
- " Isian Roti"
- " Mentega  gula"
recipeinstructions:
- "Campur Tepung terigu,gula,ragi,"
- "Mix dengan kecepatan sedang selama 1,kemudian tambahkan air,mix sampai setengah kali"
- "Setelah setengah kalis tambahkan margarin,garam,mix sampai kalis,kira2 10-15 menit"
- "Stelah kalis,diamkan kurang lebih 20 menit,setelah mengembang siap di timbang,40 gram tiap bulatannya.diamkan adonan lagi selama 1 jam"
- "Buat toping : campurkan semua bahan toping"
- "Jika sudah ingin di panggang,baru kita toping,"
- "Panggang dengan api 180 derajat."
- "Selamat mencoba ini resep Homemade ya sisbun 🙏"
categories:
- Recipe
tags:
- roti
- boy
- roti

katakunci: roti boy roti 
nutrition: 166 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dessert

---


![Roti Boy/ Roti O](https://img-global.cpcdn.com/recipes/d3b431d66a0ed105/680x482cq70/roti-boy-roti-o-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga enak. Karasteristik masakan Nusantara roti boy/ roti o yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kehangatan keluarga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Roti Boy/ Roti O untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang bisa anda contoh salah satunya roti boy/ roti o yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep roti boy/ roti o tanpa harus bersusah payah.
Seperti resep Roti Boy/ Roti O yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 15 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Boy/ Roti O:

1. Siapkan 1 kg Tepung Cakra
1. Harus ada 100 gram gula pasir
1. Jangan lupa 11 gram
1. Dibutuhkan 100 gram margarin
1. Tambah 1/2 sdt garam
1. Harap siapkan 550 ml air es
1. Tambah  Toping
1. Siapkan 4 gram kopi instan
1. Harus ada 6 sdm air panas
1. Dibutuhkan 100 gram Tepung terigu
1. Tambah 1 butir telur
1. Siapkan 80 gram Mentega
1. Harap siapkan 60 gram gula pasir
1. Dibutuhkan  Isian Roti
1. Harap siapkan  Mentega + gula




<!--inarticleads2-->

##### Bagaimana membuat  Roti Boy/ Roti O:

1. Campur Tepung terigu,gula,ragi,
1. Mix dengan kecepatan sedang selama 1,kemudian tambahkan air,mix sampai setengah kali
1. Setelah setengah kalis tambahkan margarin,garam,mix sampai kalis,kira2 10-15 menit
1. Stelah kalis,diamkan kurang lebih 20 menit,setelah mengembang siap di timbang,40 gram tiap bulatannya.diamkan adonan lagi selama 1 jam
1. Buat toping : campurkan semua bahan toping
1. Jika sudah ingin di panggang,baru kita toping,
1. Panggang dengan api 180 derajat.
1. Selamat mencoba ini resep Homemade ya sisbun 🙏




Demikianlah cara membuat roti boy/ roti o yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
