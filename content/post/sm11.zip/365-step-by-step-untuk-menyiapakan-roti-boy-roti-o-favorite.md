---
description: "Step-by-Step untuk menyiapakan Roti boy / Roti O Favorite"
title: "Step-by-Step untuk menyiapakan Roti boy / Roti O Favorite"
slug: 365-step-by-step-untuk-menyiapakan-roti-boy-roti-o-favorite
date: 2020-12-24T07:16:51.544Z
image: https://img-global.cpcdn.com/recipes/586dee4286243bf3/680x482cq70/roti-boy-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/586dee4286243bf3/680x482cq70/roti-boy-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/586dee4286243bf3/680x482cq70/roti-boy-roti-o-foto-resep-utama.jpg
author: Mike Lane
ratingvalue: 4.5
reviewcount: 8521
recipeingredient:
- " BAHAN ROTI "
- "250 tepung terigu protein tinggi"
- "40 gr gula"
- "5 gr ragi instant"
- "110-120 ml susu cair full cream"
- "4 kuning telur"
- "2 butir telur utuh"
- "25 gr margarin"
- "3 gr garam"
- " BAHAN TOPPING "
- "65 margarine"
- "60 gr gula halus"
- "3 butir telur"
- "60 gr tepung terigu"
- "1 sdm maizena"
- "2 sdt bubuk kopi larutkan dengan 1 sdm air panas"
- "Secukupnya pasta mocca"
- " ISIAN "
- " Coklat batang potong kotak"
- " Keju potong kotak"
- " Chocochips u taburan"
recipeinstructions:
- "Siapkan wadah masukkan 250 gr tepung terigu 40 gr gula 5 gr ragi instant aduk sebentar kemudian masukkan 2 butir telur dan 4 kuning telur aduk² tambahkan susu cair full cream uleni hingga setengah Kalis tambahkan 3 gr garam dan 25 gr margarine uleni hingga Kalis elastis"
- "Bagi adonan menjadi beberapa bagian bulat² kan adonan dan langsung diisi dengan isian sesuai selera ya bulatkan kembali dan rapatkan lakukan hingga adonan habis diamkan tutup dengan kain bersih 1± jam"
- "Sambil menunggu proffing buat topping kopi terlebih dahulu caranya : mixer margarine dan gula halus hingga tercampur rata masukkan 3 butir telur mixer kembali hingga merata masukkan kopi bubuk yang sudah di seduh dengan 1 sdm air panas tadi dan tambahkan pasta mocca secukupnya mixer sebentar masukkan tepung terigu dan tepung maizena mixer kembali hingga tercampur rata masukkan adonan topping ke dalam piping bag / plastik segitiga masukkan dulu ke dalam kulkas"
- "Panaskan oven terlebih dahulu jika adonan roti sudah mengembang 2 x lipat beri topping kopi dengan cara melingkar lakukan hingga selesai"
- "Oven hingga matang ± 20 menit sesuaikan dengan oven masing²"
- "Saya di atasnya saya kasih chochochips sama keju parut setiap per roti biar tau mana yang coklat dan mana yang keju (biar ga salah ambil gitu hehe) terserah masih"
- "Sajikan selagi hangat"
categories:
- Recipe
tags:
- roti
- boy
- 

katakunci: roti boy  
nutrition: 284 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT56M"
recipeyield: "4"
recipecategory: Lunch

---


![Roti boy / Roti O](https://img-global.cpcdn.com/recipes/586dee4286243bf3/680x482cq70/roti-boy-roti-o-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang patut kita jaga karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti roti boy / roti o yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Indonesia

Kehangatan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak Roti boy / Roti O untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang bisa anda buat salah satunya roti boy / roti o yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep roti boy / roti o tanpa harus bersusah payah.
Seperti resep Roti boy / Roti O yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti boy / Roti O:

1. Harus ada  BAHAN ROTI :
1. Tambah 250 tepung terigu protein tinggi
1. Siapkan 40 gr gula
1. Siapkan 5 gr ragi instant
1. Diperlukan 110-120 ml susu cair full cream
1. Harap siapkan 4 kuning telur
1. Tambah 2 butir telur utuh
1. Dibutuhkan 25 gr margarin
1. Tambah 3 gr garam
1. Diperlukan  BAHAN TOPPING :
1. Harus ada 65 margarine
1. Harap siapkan 60 gr gula halus
1. Dibutuhkan 3 butir telur
1. Harap siapkan 60 gr tepung terigu
1. Harap siapkan 1 sdm maizena
1. Siapkan 2 sdt bubuk kopi (larutkan dengan 1 sdm air panas)
1. Dibutuhkan Secukupnya pasta mocca
1. Siapkan  ISIAN :
1. Dibutuhkan  Coklat batang (potong kotak)
1. Dibutuhkan  Keju (potong kotak)
1. Harap siapkan  Chocochips u/ taburan




<!--inarticleads2-->

##### Instruksi membuat  Roti boy / Roti O:

1. Siapkan wadah masukkan 250 gr tepung terigu 40 gr gula 5 gr ragi instant aduk sebentar kemudian masukkan 2 butir telur dan 4 kuning telur aduk² tambahkan susu cair full cream uleni hingga setengah Kalis tambahkan 3 gr garam dan 25 gr margarine uleni hingga Kalis elastis
1. Bagi adonan menjadi beberapa bagian bulat² kan adonan dan langsung diisi dengan isian sesuai selera ya bulatkan kembali dan rapatkan lakukan hingga adonan habis diamkan tutup dengan kain bersih 1± jam
1. Sambil menunggu proffing buat topping kopi terlebih dahulu caranya : mixer margarine dan gula halus hingga tercampur rata masukkan 3 butir telur mixer kembali hingga merata masukkan kopi bubuk yang sudah di seduh dengan 1 sdm air panas tadi dan tambahkan pasta mocca secukupnya mixer sebentar masukkan tepung terigu dan tepung maizena mixer kembali hingga tercampur rata masukkan adonan topping ke dalam piping bag / plastik segitiga masukkan dulu ke dalam kulkas
1. Panaskan oven terlebih dahulu jika adonan roti sudah mengembang 2 x lipat beri topping kopi dengan cara melingkar lakukan hingga selesai
1. Oven hingga matang ± 20 menit sesuaikan dengan oven masing²
1. Saya di atasnya saya kasih chochochips sama keju parut setiap per roti biar tau mana yang coklat dan mana yang keju (biar ga salah ambil gitu hehe) terserah masih
1. Sajikan selagi hangat




Demikianlah cara membuat roti boy / roti o yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan teruji, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
