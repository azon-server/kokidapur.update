---
description: "Langkah membuat Mexican coffee bun Luar biasa"
title: "Langkah membuat Mexican coffee bun Luar biasa"
slug: 289-langkah-membuat-mexican-coffee-bun-luar-biasa
date: 2021-02-25T22:30:54.889Z
image: https://img-global.cpcdn.com/recipes/2870b3f38b28751e/680x482cq70/mexican-coffee-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2870b3f38b28751e/680x482cq70/mexican-coffee-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2870b3f38b28751e/680x482cq70/mexican-coffee-bun-foto-resep-utama.jpg
author: Amelia Robertson
ratingvalue: 4
reviewcount: 30300
recipeingredient:
- "100 gr terigu cakra"
- "80 gr terigu segitiga"
- "2 gr fermipan"
- "1 kuning telur dan susu cair sampai 120 ml"
- "2 sdm gula pasir"
- "15 gr mentega"
- " Filling"
- "25 gr mentega  25 gr gula halus"
- " Topping"
- "25 gr gula halus"
- "25 gr mentega"
- "1 putih telur"
- "50 gr terigu segitiga"
- "1 sachet Nescafe classic 1 sdm air panas"
recipeinstructions:
- "Dalam baskom, campur terigu Cakra, terigu segitiga, gula pasir dan fermipan. Pisahkan kuning telur dan putih telur. Masukan kuning telur dlm gelas ukur, tambahkan susu cair sampai 120 ml."
- "Masukan kuning telur dan susu cair ke dlm baskom. Aduk hingga cairan terserap dan terbentuk adonan."
- "Uleni ringan hingga tidak ada lagi yg menempel di dingin baskom. Masukan mentega. Uleni kembali dan bulatkan. Tutup dg plastik dan biarkan mengembang 2x lipat, sekitar 1 jam."
- "Sambil menunggu siapkan filling: campur mentega dan gula halus. Aduk rata, sisihkan."
- "Siapkan topping: mixer rata mentega dan gula halus. Tambahkan putih telur. Mixer sebentar. Tambahkan terigu sambil diayak, aduk perlahan. Tambahkan larutan Nescafe. Aduk rata, masukan ke plastik, simpan di kulkas."
- "Setelah 1 jam dan adonan mengembang 2 x lipat, tinju dan kempiskan. Bagi adonan, saya kecil kecil, jadi 7. Masing masing pipihkan dan isi dg filling kemudian bulatkan kembali. Tata di loyang. Kemudian tutup plastik lagi dan biarkan sekitar 30 menit hingga mengembang kembali. Ternyata roti saya kok ngga bulat, bahkan ada 2 yg filling bocor dan sulit dibulatkan. Jadilah saya masukan cup saja deh. Perlu latihan."
- "Setelah mengembang kembali, keluarkan topping dr kulkas. Preheat oven. Beri filling di tiap atas roti. Oven sampai matang. Saya di 170C 30 menit. Setelah matang keluarkan dr oven, nikmati selagi hangat."
categories:
- Recipe
tags:
- mexican
- coffee
- bun

katakunci: mexican coffee bun 
nutrition: 298 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Lunch

---


![Mexican coffee bun](https://img-global.cpcdn.com/recipes/2870b3f38b28751e/680x482cq70/mexican-coffee-bun-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga enak. Karasteristik makanan Nusantara mexican coffee bun yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan rumah tangga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Mexican coffee bun untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang bisa anda praktekkan salah satunya mexican coffee bun yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep mexican coffee bun tanpa harus bersusah payah.
Berikut ini resep Mexican coffee bun yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican coffee bun:

1. Jangan lupa 100 gr terigu cakra
1. Diperlukan 80 gr terigu segitiga
1. Siapkan 2 gr fermipan
1. Tambah 1 kuning telur dan susu cair, sampai 120 ml
1. Harus ada 2 sdm gula pasir
1. Diperlukan 15 gr mentega
1. Siapkan  Filling:
1. Harap siapkan 25 gr mentega + 25 gr gula halus
1. Tambah  Topping:
1. Harus ada 25 gr gula halus
1. Jangan lupa 25 gr mentega
1. Siapkan 1 putih telur
1. Dibutuhkan 50 gr terigu segitiga
1. Siapkan 1 sachet Nescafe classic +1 sdm air panas




<!--inarticleads2-->

##### Instruksi membuat  Mexican coffee bun:

1. Dalam baskom, campur terigu Cakra, terigu segitiga, gula pasir dan fermipan. Pisahkan kuning telur dan putih telur. Masukan kuning telur dlm gelas ukur, tambahkan susu cair sampai 120 ml.
1. Masukan kuning telur dan susu cair ke dlm baskom. Aduk hingga cairan terserap dan terbentuk adonan.
1. Uleni ringan hingga tidak ada lagi yg menempel di dingin baskom. Masukan mentega. Uleni kembali dan bulatkan. Tutup dg plastik dan biarkan mengembang 2x lipat, sekitar 1 jam.
1. Sambil menunggu siapkan filling: campur mentega dan gula halus. Aduk rata, sisihkan.
1. Siapkan topping: mixer rata mentega dan gula halus. Tambahkan putih telur. Mixer sebentar. Tambahkan terigu sambil diayak, aduk perlahan. Tambahkan larutan Nescafe. Aduk rata, masukan ke plastik, simpan di kulkas.
1. Setelah 1 jam dan adonan mengembang 2 x lipat, tinju dan kempiskan. Bagi adonan, saya kecil kecil, jadi 7. Masing masing pipihkan dan isi dg filling kemudian bulatkan kembali. Tata di loyang. Kemudian tutup plastik lagi dan biarkan sekitar 30 menit hingga mengembang kembali. Ternyata roti saya kok ngga bulat, bahkan ada 2 yg filling bocor dan sulit dibulatkan. Jadilah saya masukan cup saja deh. Perlu latihan.
1. Setelah mengembang kembali, keluarkan topping dr kulkas. Preheat oven. Beri filling di tiap atas roti. Oven sampai matang. Saya di 170C 30 menit. Setelah matang keluarkan dr oven, nikmati selagi hangat.




Demikianlah cara membuat mexican coffee bun yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan cepat, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
