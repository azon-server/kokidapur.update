---
description: "Bagaimana untuk menyiapakan Roti Boy a.k.a Roti O (pakai Telur) versi Oven Tangkring Favorite"
title: "Bagaimana untuk menyiapakan Roti Boy a.k.a Roti O (pakai Telur) versi Oven Tangkring Favorite"
slug: 342-bagaimana-untuk-menyiapakan-roti-boy-aka-roti-o-pakai-telur-versi-oven-tangkring-favorite
date: 2021-01-19T20:27:09.388Z
image: https://img-global.cpcdn.com/recipes/459975345de8e8e4/680x482cq70/roti-boy-aka-roti-o-pakai-telur-versi-oven-tangkring-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/459975345de8e8e4/680x482cq70/roti-boy-aka-roti-o-pakai-telur-versi-oven-tangkring-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/459975345de8e8e4/680x482cq70/roti-boy-aka-roti-o-pakai-telur-versi-oven-tangkring-foto-resep-utama.jpg
author: Harold Fields
ratingvalue: 4.1
reviewcount: 2536
recipeingredient:
- " Topping kopi "
- "1 butir putih telur"
- "2 sdm gula halus"
- "50 gram margarin me  palmia"
- "50 gram tepung kunci biru"
- "1/4 sdt Baking Powder me hercules BPDA"
- "1 sachet nescafe classic 2gram larutkan dgn 1 sdm air"
- " Bahan Roti "
- "200 gram tepung protein tinggi me  cakra"
- "60 gram tepung protein sedang me  segitiga"
- "50 gram gula pasir"
- "1 sdm susu bubuk"
- "1 sdt ragi instan me fermipan"
- "1 btr kuning telur"
- "150 ml air dingin"
- "30 gram margarinbutter saya pake anchor"
- "Sejumput garam"
- " Bahan isian "
- " Butter beku secukup nya"
- "secukupnya Keju saya pake prochiz spready"
recipeinstructions:
- "Toping kopi : siapkan putih telur. Kocok hingga soft peak (dibalik tidak jatuh) sisihkan"
- "Siapkan margarin dan gula halus. Kocok hingga lembut dan lalu masukkan tepung plus baking powder"
- "Kocok kembali hingga rata. Masukkan putih telur yg sdh kaku tadi. Mixer kembali hingga rata"
- "Setelah rata masukkan cairan kopi. Mixer kembali hingga rata. Lalu masukkan ke piping bag. Simpan di kulkas"
- "Siapkan tepung, susu bubuk, ragi instan. Masukkan kuning telur. Mixer hingga rata. Masukkan air sedikit demi sedikit"
- "Setelah setengah kalis. Masukkan mentega dan garam. Mixer kembali hingga kalis elastis"
- "Jika sdh terbentuk window pane timbang @52gram jadi 11 pcs. Diamkan 10 menit. Lalu gilas dan Isi dengan keju dan butter beku. Lalu bulatkan."
- "Tata di loyang yg sdh bersemir margarin. Proffing kurang lebih 60 menit. Ato sampai adonan mengembang 2x lipat. Lalu beri topping kopi melingkar seperti.obat nyamuk hingga lebih dari setengah roti. Pangganh dioven dengan suhu 180° C selama 25-30 menit. Sesuaikan dengan oven masing-masing. Jika toping kopi sdh mengering angkat. Dinginkan di cooling rack"
- "Nantinya toping akan cruncy.. hangat-hangat buat teman minum teh ato kopi cocok banget..yuk.ah bikin.. dapat banyak..rasa 11-12 sm yg diemol.."
categories:
- Recipe
tags:
- roti
- boy
- aka

katakunci: roti boy aka 
nutrition: 180 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Lunch

---


![Roti Boy a.k.a Roti O (pakai Telur) versi Oven Tangkring](https://img-global.cpcdn.com/recipes/459975345de8e8e4/680x482cq70/roti-boy-aka-roti-o-pakai-telur-versi-oven-tangkring-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau empuk. Ciri makanan Indonesia roti boy a.k.a roti o (pakai telur) versi oven tangkring yang penuh dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Roti Boy a.k.a Roti O (pakai Telur) versi Oven Tangkring untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang bisa anda buat salah satunya roti boy a.k.a roti o (pakai telur) versi oven tangkring yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep roti boy a.k.a roti o (pakai telur) versi oven tangkring tanpa harus bersusah payah.
Seperti resep Roti Boy a.k.a Roti O (pakai Telur) versi Oven Tangkring yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Boy a.k.a Roti O (pakai Telur) versi Oven Tangkring:

1. Jangan lupa  Topping kopi :
1. Harus ada 1 butir putih telur
1. Jangan lupa 2 sdm gula halus
1. Harus ada 50 gram margarin (me : palmia)
1. Diperlukan 50 gram tepung kunci biru
1. Harus ada 1/4 sdt Baking Powder (me: hercules BPDA)
1. Siapkan 1 sachet nescafe classic 2gram larutkan dgn 1 sdm air
1. Diperlukan  Bahan Roti :
1. Siapkan 200 gram tepung protein tinggi (me : cakra)
1. Harus ada 60 gram tepung protein sedang (me : segitiga)
1. Diperlukan 50 gram gula pasir
1. Siapkan 1 sdm susu bubuk
1. Jangan lupa 1 sdt ragi instan (me: fermipan)
1. Jangan lupa 1 btr kuning telur
1. Jangan lupa 150 ml air dingin
1. Siapkan 30 gram margarin/butter (saya pake anchor)
1. Diperlukan Sejumput garam
1. Siapkan  Bahan isian :
1. Diperlukan  Butter beku secukup nya
1. Jangan lupa secukupnya Keju (saya pake prochiz spready)




<!--inarticleads2-->

##### Bagaimana membuat  Roti Boy a.k.a Roti O (pakai Telur) versi Oven Tangkring:

1. Toping kopi : siapkan putih telur. Kocok hingga soft peak (dibalik tidak jatuh) sisihkan
1. Siapkan margarin dan gula halus. Kocok hingga lembut dan lalu masukkan tepung plus baking powder
1. Kocok kembali hingga rata. Masukkan putih telur yg sdh kaku tadi. Mixer kembali hingga rata
1. Setelah rata masukkan cairan kopi. Mixer kembali hingga rata. Lalu masukkan ke piping bag. Simpan di kulkas
1. Siapkan tepung, susu bubuk, ragi instan. Masukkan kuning telur. Mixer hingga rata. Masukkan air sedikit demi sedikit
1. Setelah setengah kalis. Masukkan mentega dan garam. Mixer kembali hingga kalis elastis
1. Jika sdh terbentuk window pane timbang @52gram jadi 11 pcs. Diamkan 10 menit. Lalu gilas dan Isi dengan keju dan butter beku. Lalu bulatkan.
1. Tata di loyang yg sdh bersemir margarin. Proffing kurang lebih 60 menit. Ato sampai adonan mengembang 2x lipat. Lalu beri topping kopi melingkar seperti.obat nyamuk hingga lebih dari setengah roti. Pangganh dioven dengan suhu 180° C selama 25-30 menit. Sesuaikan dengan oven masing-masing. Jika toping kopi sdh mengering angkat. Dinginkan di cooling rack
1. Nantinya toping akan cruncy.. hangat-hangat buat teman minum teh ato kopi cocok banget..yuk.ah bikin.. dapat banyak..rasa 11-12 sm yg diemol..




Demikianlah cara membuat roti boy a.k.a roti o (pakai telur) versi oven tangkring yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan teruji, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
