---
description: "Cara untuk membuat Roti Boy (Teflon) Cepat"
title: "Cara untuk membuat Roti Boy (Teflon) Cepat"
slug: 301-cara-untuk-membuat-roti-boy-teflon-cepat
date: 2020-12-07T03:56:47.159Z
image: https://img-global.cpcdn.com/recipes/bdbe9b0089c13d29/680x482cq70/roti-boy-teflon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bdbe9b0089c13d29/680x482cq70/roti-boy-teflon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bdbe9b0089c13d29/680x482cq70/roti-boy-teflon-foto-resep-utama.jpg
author: Russell Montgomery
ratingvalue: 4.3
reviewcount: 24159
recipeingredient:
- " Bahan roti "
- "250 gram tepung cakra"
- "1 butir kuning telur"
- "1 sdt ragi instan"
- "2 sdm munjung gula pasir"
- "1 sdm margarin"
- "1 sdm susu bubuk"
- "Sejumput garam"
- "125-150 ml air hangatsusu hangat"
- " Bahan topping "
- "1 butir putih telur"
- "50 gram gula pasir"
- "50 gram margarin"
- "60 gram tepung terigu"
- "20 gram tepung maizena"
- "1 sdm pasta moca skip"
- "1 sdm susu bubuk"
- "1 sachet kopi instan White Coffee"
- "2 sdm SKM putih"
- " Isian keju "
- "50 gram margarin"
- "50 gram keju cheddar parut"
- "2 sdm gula pasir"
- "1 sdm susu bubuk"
recipeinstructions:
- "Dalam wadah, campur semua bahan roti 👉 tepung, kuning telur, ragi, gula pasir, margarin, susu bubuk dan garam. Aduk sampai kuning telur dan margarin merata."
- "Lalu tuang air hangat sedikit demi sedikit sambil di uleni. Jangan menuang semua air hangat, sesuaikan dengan adonan saja. Uleni sampai kalis elastis. Bentuk adonan bulat dan diamkan selama kurleb sejam. Tutup adonan dengan lap basah. Biarkan sampai mengembang 2x lipat."
- "Sambil menunggu adonan mengembang. Campur semua bahan isi dengan menggunakan sendok. Kemudian masukkan dalam kulkas."
- "Untuk toppingnya, mixer/whisk putih telur, margarin dan gula pasir sampai creamy. Kemudian masukkan tepung terigu, tepung maizena, susu bubuk, kopi instan dan skm. Aduk dengan menggunakan wisk sampai lembut. Lalu masukkan dalam piping bag dan gunting sedikit ujungnya. Simpan dalam kulkas terlebih dahulu. 20-30 menit sblm di gunakan, baru keluarkan dr kulkas."
- "Setelah adonan roti mengembang, kempiskan adonan. Bagi adonan sesuai selera. Lalu bentuk adonan bulat&#34;. Pipihkan adonan roti, kemudian isi dengan bahan isian sesuai selera. Tutup kembali adonan roti. Dan bentuk bulat lagi. Tata adonan roti dalam loyang roti yang sudah dioles dengan margarin di permukaan loyangnya. Beri jarak antara adonan rotinya. Diamkan adonan sampai mengembang lagi. Tutup adonan dengan lap bersih."
- "Selagi menunggu adonan mengembang, panaskan teflon. Tutup teflon lapisi dengan lap bersih."
- "Setelah adonan mengembang, semprotkan adonan topping diatas adonan roti. Semprot melingkar seperti obat nyamuk."
- "Panggang dalam teflon dengan api kecil selama kurleb 30 menit(disesuaikan). Jika pake oven panggang selama 30 menit."
- "Angkat dan sajikan selagi hangat."
categories:
- Recipe
tags:
- roti
- boy
- teflon

katakunci: roti boy teflon 
nutrition: 227 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Lunch

---


![Roti Boy (Teflon)](https://img-global.cpcdn.com/recipes/bdbe9b0089c13d29/680x482cq70/roti-boy-teflon-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang setidaknya kita lestarikan karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti roti boy (teflon) yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Kita

Kehangatan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah membuat makanan Roti Boy (Teflon) untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang dapat anda coba salah satunya roti boy (teflon) yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep roti boy (teflon) tanpa harus bersusah payah.
Berikut ini resep Roti Boy (Teflon) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 24 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Boy (Teflon):

1. Diperlukan  Bahan roti :
1. Harus ada 250 gram tepung cakra
1. Siapkan 1 butir kuning telur
1. Harus ada 1 sdt ragi instan
1. Siapkan 2 sdm munjung gula pasir
1. Tambah 1 sdm margarin
1. Diperlukan 1 sdm susu bubuk
1. Jangan lupa Sejumput garam
1. Jangan lupa 125-150 ml air hangat/susu hangat
1. Tambah  Bahan topping :
1. Tambah 1 butir putih telur
1. Harus ada 50 gram gula pasir
1. Diperlukan 50 gram margarin
1. Tambah 60 gram tepung terigu
1. Siapkan 20 gram tepung maizena
1. Jangan lupa 1 sdm pasta moca (skip)
1. Harus ada 1 sdm susu bubuk
1. Siapkan 1 sachet kopi instan (White Coffee)
1. Dibutuhkan 2 sdm SKM putih
1. Dibutuhkan  Isian keju :
1. Tambah 50 gram margarin
1. Harap siapkan 50 gram keju cheddar parut
1. Jangan lupa 2 sdm gula pasir
1. Jangan lupa 1 sdm susu bubuk




<!--inarticleads2-->

##### Bagaimana membuat  Roti Boy (Teflon):

1. Dalam wadah, campur semua bahan roti 👉 tepung, kuning telur, ragi, gula pasir, margarin, susu bubuk dan garam. Aduk sampai kuning telur dan margarin merata.
1. Lalu tuang air hangat sedikit demi sedikit sambil di uleni. Jangan menuang semua air hangat, sesuaikan dengan adonan saja. Uleni sampai kalis elastis. Bentuk adonan bulat dan diamkan selama kurleb sejam. Tutup adonan dengan lap basah. Biarkan sampai mengembang 2x lipat.
1. Sambil menunggu adonan mengembang. Campur semua bahan isi dengan menggunakan sendok. Kemudian masukkan dalam kulkas.
1. Untuk toppingnya, mixer/whisk putih telur, margarin dan gula pasir sampai creamy. Kemudian masukkan tepung terigu, tepung maizena, susu bubuk, kopi instan dan skm. Aduk dengan menggunakan wisk sampai lembut. Lalu masukkan dalam piping bag dan gunting sedikit ujungnya. Simpan dalam kulkas terlebih dahulu. 20-30 menit sblm di gunakan, baru keluarkan dr kulkas.
1. Setelah adonan roti mengembang, kempiskan adonan. Bagi adonan sesuai selera. Lalu bentuk adonan bulat&#34;. Pipihkan adonan roti, kemudian isi dengan bahan isian sesuai selera. Tutup kembali adonan roti. Dan bentuk bulat lagi. Tata adonan roti dalam loyang roti yang sudah dioles dengan margarin di permukaan loyangnya. Beri jarak antara adonan rotinya. Diamkan adonan sampai mengembang lagi. Tutup adonan dengan lap bersih.
1. Selagi menunggu adonan mengembang, panaskan teflon. Tutup teflon lapisi dengan lap bersih.
1. Setelah adonan mengembang, semprotkan adonan topping diatas adonan roti. Semprot melingkar seperti obat nyamuk.
1. Panggang dalam teflon dengan api kecil selama kurleb 30 menit(disesuaikan). Jika pake oven panggang selama 30 menit.
1. Angkat dan sajikan selagi hangat.




Demikianlah cara membuat roti boy (teflon) yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
