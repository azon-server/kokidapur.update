---
description: "Cara menyiapakan Roti Boy/ Roti O/Mexican Bun Part 3 (Metode Autolysis) Luar biasa"
title: "Cara menyiapakan Roti Boy/ Roti O/Mexican Bun Part 3 (Metode Autolysis) Luar biasa"
slug: 352-cara-menyiapakan-roti-boy-roti-o-mexican-bun-part-3-metode-autolysis-luar-biasa
date: 2020-09-30T09:13:03.083Z
image: https://img-global.cpcdn.com/recipes/7d6162109e462101/680x482cq70/roti-boy-roti-omexican-bun-part-3-metode-autolysis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7d6162109e462101/680x482cq70/roti-boy-roti-omexican-bun-part-3-metode-autolysis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7d6162109e462101/680x482cq70/roti-boy-roti-omexican-bun-part-3-metode-autolysis-foto-resep-utama.jpg
author: Eric Page
ratingvalue: 4.4
reviewcount: 36474
recipeingredient:
- " Bahan roti"
- "200 gram tepung terigu protein tinggi"
- "50 gram tepung terigu protein rendah"
- "50 gram gula pasir"
- "1 butir telur utuh"
- "80 ml air susu cair"
- "1 sdt ragi instan"
- "60 gram margarine suhu ruang"
- "1/4 sdt garam"
- " Bahan isifiling"
- "Secukupnya margarine dingin"
- " Bahan topping"
- "60 gram margarine"
- "60 gram tepung terigu"
- "50 gram gula halus me gula pasir biasa"
- "1 butir telur"
- "1 bks kopi luwak white coffe  1 sdm air panas"
recipeinstructions:
- "Membuat roti: Dalam wadah, Campur tepung, gula, dan telur. Aduk rata. Lalu tuang air/susu cair sedikit demi sedikit hingga tercampur rata. Tutup dengan serbet. Diamkan selama 6-8 jam di suhu ruang."
- "Setelah 6-8 jam, buka serbet lalu, beri ragi. Jika ulen pake tangan sebaiknya ragi di beri sedikit air hangat agar mudah larut. Tetapi jika menggunakan mixer, ragi tidak perlu di larutkan."
- "Setelah ragi tercampur, tambahkan margarin dan garam. Ulen lagi dengan mixer hingga kalis elastis."
- "Proofing lagi selama 1 jam hingga mengembang 2 kali lipat. Lalu kempeskan. Bagi menjadi 10 bagian sama rata. Beri isian margarine."
- "Lakukan hingga semuanya habis. Tutup lagi dengan serbet selama 15-30 menit."
- "Sambil menunggu, buat topping. Mixer/ wisk semua bahan topping. Taruh di plastik segitiga. Letakkan dikulkas sebentar."
- "Semprotkan topping di atas permukaan roti melingkar seperti obat nyamuk. Panaskan oven selama 10 menit. Panggang roti selama 20-25 menit di api sedang. (sesuaikan oven masing² ya)"
- "Tadada.. Rotinya cantik, lembut dan enak pastinya.."
- "Sajikan..."
categories:
- Recipe
tags:
- roti
- boy
- roti

katakunci: roti boy roti 
nutrition: 125 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dinner

---


![Roti Boy/ Roti O/Mexican Bun Part 3 (Metode Autolysis)](https://img-global.cpcdn.com/recipes/7d6162109e462101/680x482cq70/roti-boy-roti-omexican-bun-part-3-metode-autolysis-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang harus kita lestarikan karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti roti boy/ roti o/mexican bun part 3 (metode autolysis) yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan keistimewahan yang merupakan keragaman Kita

Kehangatan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah memasak Roti Boy/ Roti O/Mexican Bun Part 3 (Metode Autolysis) untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang bisa anda contoh salah satunya roti boy/ roti o/mexican bun part 3 (metode autolysis) yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep roti boy/ roti o/mexican bun part 3 (metode autolysis) tanpa harus bersusah payah.
Berikut ini resep Roti Boy/ Roti O/Mexican Bun Part 3 (Metode Autolysis) yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Boy/ Roti O/Mexican Bun Part 3 (Metode Autolysis):

1. Tambah  Bahan roti
1. Diperlukan 200 gram tepung terigu protein tinggi
1. Harus ada 50 gram tepung terigu protein rendah
1. Harap siapkan 50 gram gula pasir
1. Siapkan 1 butir telur utuh
1. Harap siapkan 80 ml air/ susu cair
1. Harap siapkan 1 sdt ragi instan
1. Diperlukan 60 gram margarine (suhu ruang)
1. Siapkan 1/4 sdt garam
1. Tambah  Bahan isi/filing:
1. Tambah Secukupnya margarine dingin
1. Harap siapkan  Bahan topping:
1. Jangan lupa 60 gram margarine
1. Harus ada 60 gram tepung terigu
1. Diperlukan 50 gram gula halus (me: gula pasir biasa)
1. Harus ada 1 butir telur
1. Dibutuhkan 1 bks kopi luwak white coffe + 1 sdm air panas




<!--inarticleads2-->

##### Langkah membuat  Roti Boy/ Roti O/Mexican Bun Part 3 (Metode Autolysis):

1. Membuat roti: Dalam wadah, Campur tepung, gula, dan telur. Aduk rata. Lalu tuang air/susu cair sedikit demi sedikit hingga tercampur rata. Tutup dengan serbet. Diamkan selama 6-8 jam di suhu ruang.
1. Setelah 6-8 jam, buka serbet lalu, beri ragi. Jika ulen pake tangan sebaiknya ragi di beri sedikit air hangat agar mudah larut. Tetapi jika menggunakan mixer, ragi tidak perlu di larutkan.
1. Setelah ragi tercampur, tambahkan margarin dan garam. Ulen lagi dengan mixer hingga kalis elastis.
1. Proofing lagi selama 1 jam hingga mengembang 2 kali lipat. Lalu kempeskan. Bagi menjadi 10 bagian sama rata. Beri isian margarine.
1. Lakukan hingga semuanya habis. Tutup lagi dengan serbet selama 15-30 menit.
1. Sambil menunggu, buat topping. Mixer/ wisk semua bahan topping. Taruh di plastik segitiga. Letakkan dikulkas sebentar.
1. Semprotkan topping di atas permukaan roti melingkar seperti obat nyamuk. Panaskan oven selama 10 menit. Panggang roti selama 20-25 menit di api sedang. (sesuaikan oven masing² ya)
1. Tadada.. Rotinya cantik, lembut dan enak pastinya..
1. Sajikan...




Demikianlah cara membuat roti boy/ roti o/mexican bun part 3 (metode autolysis) yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan cepat, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
