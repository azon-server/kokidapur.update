---
description: "Panduan membuat Mexican Coffee Bun (Roti Kopi Mini) terupdate"
title: "Panduan membuat Mexican Coffee Bun (Roti Kopi Mini) terupdate"
slug: 273-panduan-membuat-mexican-coffee-bun-roti-kopi-mini-terupdate
date: 2020-12-02T13:13:31.275Z
image: https://img-global.cpcdn.com/recipes/5f79239f675e69b2/680x482cq70/mexican-coffee-bun-roti-kopi-mini-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5f79239f675e69b2/680x482cq70/mexican-coffee-bun-roti-kopi-mini-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5f79239f675e69b2/680x482cq70/mexican-coffee-bun-roti-kopi-mini-foto-resep-utama.jpg
author: Mollie Holloway
ratingvalue: 4.2
reviewcount: 28177
recipeingredient:
- " Bahan Adonan Roti"
- "250 gram tepung pro tinggi"
- "150 ml susu UHT"
- "1 butir telur"
- "3 sdm mentega"
- "3 sdm gula pasir"
- "1/2 sdt garam halus"
- "1 sdm ragi  50 ml air hangat  1 sdm gula"
- " Bahan Topping"
- "1 bungkus kopi instan moka  3 sdm air panas larutkan"
- "2 sdm susu bubuk"
- "3 sdm gula halus"
- "50 gram mentega butter"
- "5 sdm kurleb tepung terigu jika masih cair bs ditambahkan"
- "1 butir telur"
- " Bahan Isian"
- "1 sdt mentega butter per 1 roti"
- "potong dadu Keju quick melt"
recipeinstructions:
- "Siapkan bahan untuk membuat roti dan juga untuk membuat toppingnya"
- "Aktifkan ragi dgn 50 ml air hangat (jgn terlalu panas) + 1 sdm gula pasir, tutup biarkan hingga berbusa"
- "Campurkan tepung, telur, susu, larutan ragi, garam, gula pasir, aduk sampai setengah kalis. Lalu tambahkan mentega, uleni kembali hingga kalis"
- "Tutup dan diamkan adonan supaya mengembang 2x lipat. Bagi beberapa adonan, aku bagi adonan kecil2. Sesuai selera saja yaa"
- "Beri isian, potongan keju dan butter. Isi sesuai selera yaa, jgn lupa tutup kembali dgn rapat dan putar dibagian bawahnya supaya rata dan tdk bocor. Diamkan kembali biarkan hingga mengembang"
- "Panaskan oven, dan waktunya buat topping. Mixer butter dan gula, tambahkan larutan kopi, tepung, susu dan telur. Aduk rata *jika adonan masih seperti pd gambar 1, tambahkan tepung terigu hingga adonan berbentuk krim. pindahkan ke plastik sgitiga."
- "Tuang diatas roti berbentuk lingkaran. Panggang hingga matang, suhu menyesuaikan ya.. Aku pakai oven tangkring dgn api kecil, jd kurleb 20 menitan, bolak balik rak bawah atas. Dan siap disajikan, dalemnya melt bgt ya kejunya. Nikmati selagi hangat"
categories:
- Recipe
tags:
- mexican
- coffee
- bun

katakunci: mexican coffee bun 
nutrition: 145 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT60M"
recipeyield: "1"
recipecategory: Dessert

---


![Mexican Coffee Bun (Roti Kopi Mini)](https://img-global.cpcdn.com/recipes/5f79239f675e69b2/680x482cq70/mexican-coffee-bun-roti-kopi-mini-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau gurih. Ciri masakan Nusantara mexican coffee bun (roti kopi mini) yang kaya dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Mexican Coffee Bun (Roti Kopi Mini) untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang dapat anda contoh salah satunya mexican coffee bun (roti kopi mini) yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep mexican coffee bun (roti kopi mini) tanpa harus bersusah payah.
Seperti resep Mexican Coffee Bun (Roti Kopi Mini) yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Mexican Coffee Bun (Roti Kopi Mini):

1. Harap siapkan  Bahan Adonan Roti:
1. Siapkan 250 gram tepung pro tinggi
1. Harus ada 150 ml susu UHT
1. Siapkan 1 butir telur
1. Diperlukan 3 sdm mentega
1. Diperlukan 3 sdm gula pasir
1. Dibutuhkan 1/2 sdt garam halus
1. Tambah 1 sdm ragi + 50 ml air hangat + 1 sdm gula
1. Harap siapkan  Bahan Topping:
1. Tambah 1 bungkus kopi instan moka + 3 sdm air panas, larutkan
1. Harus ada 2 sdm susu bubuk
1. Tambah 3 sdm gula halus
1. Harus ada 50 gram mentega butter
1. Harus ada 5 sdm kurleb tepung terigu, jika masih cair bs ditambahkan
1. Harap siapkan 1 butir telur
1. Diperlukan  Bahan Isian:
1. Harus ada 1 sdt mentega butter per 1 roti
1. Harap siapkan potong dadu Keju quick melt




<!--inarticleads2-->

##### Langkah membuat  Mexican Coffee Bun (Roti Kopi Mini):

1. Siapkan bahan untuk membuat roti dan juga untuk membuat toppingnya
1. Aktifkan ragi dgn 50 ml air hangat (jgn terlalu panas) + 1 sdm gula pasir, tutup biarkan hingga berbusa
1. Campurkan tepung, telur, susu, larutan ragi, garam, gula pasir, aduk sampai setengah kalis. Lalu tambahkan mentega, uleni kembali hingga kalis
1. Tutup dan diamkan adonan supaya mengembang 2x lipat. Bagi beberapa adonan, aku bagi adonan kecil2. Sesuai selera saja yaa
1. Beri isian, potongan keju dan butter. Isi sesuai selera yaa, jgn lupa tutup kembali dgn rapat dan putar dibagian bawahnya supaya rata dan tdk bocor. Diamkan kembali biarkan hingga mengembang
1. Panaskan oven, dan waktunya buat topping. Mixer butter dan gula, tambahkan larutan kopi, tepung, susu dan telur. Aduk rata *jika adonan masih seperti pd gambar 1, tambahkan tepung terigu hingga adonan berbentuk krim. pindahkan ke plastik sgitiga.
1. Tuang diatas roti berbentuk lingkaran. Panggang hingga matang, suhu menyesuaikan ya.. Aku pakai oven tangkring dgn api kecil, jd kurleb 20 menitan, bolak balik rak bawah atas. Dan siap disajikan, dalemnya melt bgt ya kejunya. Nikmati selagi hangat




Demikianlah cara membuat mexican coffee bun (roti kopi mini) yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
