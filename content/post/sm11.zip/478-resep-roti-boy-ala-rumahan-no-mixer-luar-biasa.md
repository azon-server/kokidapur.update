---
description: "Resep : Roti Boy Ala Rumahan no mixer Luar biasa"
title: "Resep : Roti Boy Ala Rumahan no mixer Luar biasa"
slug: 478-resep-roti-boy-ala-rumahan-no-mixer-luar-biasa
date: 2021-01-02T12:33:15.678Z
image: https://img-global.cpcdn.com/recipes/d6096c4eb4034d6a/680x482cq70/roti-boy-ala-rumahan-no-mixer-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d6096c4eb4034d6a/680x482cq70/roti-boy-ala-rumahan-no-mixer-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d6096c4eb4034d6a/680x482cq70/roti-boy-ala-rumahan-no-mixer-foto-resep-utama.jpg
author: Jennie Parker
ratingvalue: 5
reviewcount: 8503
recipeingredient:
- "1 sdt gula pasir"
- "1 sdt ragi instan"
- "100 ml air hangat kalau kurang boleh ditambah 12 sdm"
- "250 gr tepung terigu protein tinggi aku pake golden eagle"
- "3 sdm 30 gr gula halus"
- "2 sdm 20 gr susu bubuk"
- "2 butir kuning telur"
- "Sejumput garam"
- "1/2 sdt emulsifier SPOvalet"
- "1 sdm 10 gr margarin"
- " Bahan Topping "
- "6 sdm 60 gr gula pasir"
- "5 sdm 50 gr margarinbutter"
- "6 sdm 60 gr tepung terigu"
- "1 butir putih telur"
- "1 sdt kopi instan luwak white coffee"
- "1 sdt pasta mocca"
- " Untuk isian "
- "secukupnya Margarin butter"
- "2 sdm gula halus"
recipeinstructions:
- "Pertama, tes dulu ke aktifan ragi nya, siapkan wadah lalu masukkan 1 sdt ragi instan, 1 sdt gula pasir dan 100 ml air putih hangat, kemudian aduk rata dan tutup wadah, tunggu hingga 3-5 menit. Apabila mengembang dan berbusa maka ragi masih aktif dan siap digunakan."
- "Setelah itu siapkan wadah ukuran sedang, lalu masukkan 250 gr tepung terigu, 30 gr gula halus, 20 gr susu bubuk, 2 butir kuning telur dan ragi yang telah dilarutkan sebelumnya. Lalu aduk adonan hingga tercampur rata menggunakan spatula atau boleh juga langsung di uleni menggunakan tangan. Jika dirasa adonan masih terlalu kering boleh di tambah 1-2 sdm air putih hangat."
- "Apabila adonan sudah mulai tercampur rata dan setengah kalis, masukkan sejumput garam, ½ sdt SP dan 1 sdm margarin, lalu uleni adonan hingga tercampur rata sampai margarin terserap keseluruh adonan. Tips agar margarin cepat menyerap ke adonan peras peras adonan seperti memeras santan kelapa sambil sesekali di uleni."
- "Setelah itu masukkan kembali adonan kedalam wadah, kemudian tutup menggunakan plastic wrap/serbet. Diamkan hingga 40-60 menit sampai adonan mengembang."
- "Sambil menunggu adonan mengembang, buat untuk topping rotinya, siapkan wadah, masukkan 60 gr gula halus, 50 gr margarin/butter, kemudian aduk hingga tercampur rata menggunakan spatula/whisk. Masukkan 60 gr tepung terigu, putih telur, 1 sdt kopi instan dan pasta mocca. Aduk hingga tercampur rata. Masukkan adonan kedalam plastik segitiga yang nanti ujungnya digunting pada saat pemberian topping."
- "Setelah 60 menit dan adonan sudah mengembang 2x lipat, buka plastic wrapnya lalu kempiskan/tinju adonan sambil di bulat bulatkan. Siapkan adonan di baking matt/talenan lalu bagi adonan menjadi beberapa bagian. Tiap tiap adonan menjadi 40gr bila ditimbang dan hasilnya ada 11 potong."
- "Kemudian bulat bulatkan adonan satu per satu, untuk adonan yang menunggu tutup dengan serbet agar tetap lembab. Setelah itu bulat bulatkan adonan secara mulus, boleh di rounding di baking matt. Adonan yang pertama dibulatkan yang diberi isian lalu teruskan sesuai urutan. Setelah diberi isian bulatkan kembali dan tutup rapat adonan agar saat di oven adonan tidak bocor."
- "Setelah itu letakkan adonan yang telah diberi isian tadi diatas loyang yang telah diberi margarin atau boleh jg diberi kertas roti diatasnya. Lanjutkan dan beri jarak antara 1 roti dan roti lainnya karena saat di oven roti akan semakin mengembang. Lalu tutup adonan dengan serbet dan diamkan kembali selama 40 menit. Setelah adonan mengembang beri topping diatasnya dengan gerakan melingkar."
- "Sebelum memanggang roti, panaskan dahulu oven di suhu 200°c selama 10 menit. Setelah panas masukkan roti dan atur suhu menjadi 180°c api atas dan bawah selama 20 menit atau sampai roti matang. Apabila ingin hasil yang krispy tambahkan 5 menit lagi waktu pemanggangan maka hasil akhirnya topping roti akan menjadi krispy tapi tetap lembut didalam. Selamat mencoba."
categories:
- Recipe
tags:
- roti
- boy
- ala

katakunci: roti boy ala 
nutrition: 293 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dinner

---


![Roti Boy Ala Rumahan no mixer](https://img-global.cpcdn.com/recipes/d6096c4eb4034d6a/680x482cq70/roti-boy-ala-rumahan-no-mixer-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan empuk. Karasteristik masakan Nusantara roti boy ala rumahan no mixer yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan rumah tangga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Roti Boy Ala Rumahan no mixer untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang dapat anda praktekkan salah satunya roti boy ala rumahan no mixer yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep roti boy ala rumahan no mixer tanpa harus bersusah payah.
Seperti resep Roti Boy Ala Rumahan no mixer yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 20 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Boy Ala Rumahan no mixer:

1. Siapkan 1 sdt gula pasir
1. Diperlukan 1 sdt ragi instan
1. Dibutuhkan 100 ml air hangat, kalau kurang boleh ditambah 1-2 sdm
1. Tambah 250 gr tepung terigu protein tinggi (aku pake golden eagle)
1. Tambah 3 sdm/ 30 gr gula halus
1. Harus ada 2 sdm/ 20 gr susu bubuk
1. Diperlukan 2 butir kuning telur
1. Diperlukan Sejumput garam
1. Diperlukan 1/2 sdt emulsifier (SP/Ovalet)
1. Jangan lupa 1 sdm/ 10 gr margarin
1. Harap siapkan  Bahan Topping :
1. Harap siapkan 6 sdm/ 60 gr gula pasir
1. Harus ada 5 sdm/ 50 gr margarin/butter
1. Harus ada 6 sdm/ 60 gr tepung terigu
1. Harap siapkan 1 butir putih telur
1. Tambah 1 sdt kopi instan (luwak white coffee)
1. Tambah 1 sdt pasta mocca
1. Harap siapkan  Untuk isian :
1. Diperlukan secukupnya Margarin/ butter
1. Harus ada 2 sdm gula halus




<!--inarticleads2-->

##### Langkah membuat  Roti Boy Ala Rumahan no mixer:

1. Pertama, tes dulu ke aktifan ragi nya, siapkan wadah lalu masukkan 1 sdt ragi instan, 1 sdt gula pasir dan 100 ml air putih hangat, kemudian aduk rata dan tutup wadah, tunggu hingga 3-5 menit. Apabila mengembang dan berbusa maka ragi masih aktif dan siap digunakan.
1. Setelah itu siapkan wadah ukuran sedang, lalu masukkan 250 gr tepung terigu, 30 gr gula halus, 20 gr susu bubuk, 2 butir kuning telur dan ragi yang telah dilarutkan sebelumnya. Lalu aduk adonan hingga tercampur rata menggunakan spatula atau boleh juga langsung di uleni menggunakan tangan. Jika dirasa adonan masih terlalu kering boleh di tambah 1-2 sdm air putih hangat.
1. Apabila adonan sudah mulai tercampur rata dan setengah kalis, masukkan sejumput garam, ½ sdt SP dan 1 sdm margarin, lalu uleni adonan hingga tercampur rata sampai margarin terserap keseluruh adonan. Tips agar margarin cepat menyerap ke adonan peras peras adonan seperti memeras santan kelapa sambil sesekali di uleni.
1. Setelah itu masukkan kembali adonan kedalam wadah, kemudian tutup menggunakan plastic wrap/serbet. Diamkan hingga 40-60 menit sampai adonan mengembang.
1. Sambil menunggu adonan mengembang, buat untuk topping rotinya, siapkan wadah, masukkan 60 gr gula halus, 50 gr margarin/butter, kemudian aduk hingga tercampur rata menggunakan spatula/whisk. Masukkan 60 gr tepung terigu, putih telur, 1 sdt kopi instan dan pasta mocca. Aduk hingga tercampur rata. Masukkan adonan kedalam plastik segitiga yang nanti ujungnya digunting pada saat pemberian topping.
1. Setelah 60 menit dan adonan sudah mengembang 2x lipat, buka plastic wrapnya lalu kempiskan/tinju adonan sambil di bulat bulatkan. Siapkan adonan di baking matt/talenan lalu bagi adonan menjadi beberapa bagian. Tiap tiap adonan menjadi 40gr bila ditimbang dan hasilnya ada 11 potong.
1. Kemudian bulat bulatkan adonan satu per satu, untuk adonan yang menunggu tutup dengan serbet agar tetap lembab. Setelah itu bulat bulatkan adonan secara mulus, boleh di rounding di baking matt. Adonan yang pertama dibulatkan yang diberi isian lalu teruskan sesuai urutan. Setelah diberi isian bulatkan kembali dan tutup rapat adonan agar saat di oven adonan tidak bocor.
1. Setelah itu letakkan adonan yang telah diberi isian tadi diatas loyang yang telah diberi margarin atau boleh jg diberi kertas roti diatasnya. Lanjutkan dan beri jarak antara 1 roti dan roti lainnya karena saat di oven roti akan semakin mengembang. Lalu tutup adonan dengan serbet dan diamkan kembali selama 40 menit. Setelah adonan mengembang beri topping diatasnya dengan gerakan melingkar.
1. Sebelum memanggang roti, panaskan dahulu oven di suhu 200°c selama 10 menit. Setelah panas masukkan roti dan atur suhu menjadi 180°c api atas dan bawah selama 20 menit atau sampai roti matang. Apabila ingin hasil yang krispy tambahkan 5 menit lagi waktu pemanggangan maka hasil akhirnya topping roti akan menjadi krispy tapi tetap lembut didalam. Selamat mencoba.




Demikianlah cara membuat roti boy ala rumahan no mixer yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
