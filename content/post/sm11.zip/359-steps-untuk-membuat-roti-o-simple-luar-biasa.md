---
description: "Steps untuk membuat Roti O simple Luar biasa"
title: "Steps untuk membuat Roti O simple Luar biasa"
slug: 359-steps-untuk-membuat-roti-o-simple-luar-biasa
date: 2021-01-07T02:54:17.795Z
image: https://img-global.cpcdn.com/recipes/cb3d693e914381d0/680x482cq70/roti-o-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cb3d693e914381d0/680x482cq70/roti-o-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cb3d693e914381d0/680x482cq70/roti-o-simple-foto-resep-utama.jpg
author: Sally Foster
ratingvalue: 4.5
reviewcount: 39505
recipeingredient:
- " Bahan Roti"
- "250 gr tepung terigu protein tinggi mecakra"
- "50 gr gula pasir"
- "30 gr mentega"
- "160 gr susu cair dingin  1 kuning telur"
- "1 sdt ragi mefermipan"
- "1/4 sdt garam"
- " Bahan Topping"
- "60 gr mentega"
- "60 gr gula halusmegula pasir di blender"
- "1 butir telur utuh"
- "70 gr terigu protein sedangmesegitiga biru"
- "3 sdt kopi instan"
- "2 sdt air panas untuk menyeduh kopi"
- " Bahan isian"
- " Buttermentega"
- " Mozarellaoptional"
recipeinstructions:
- "Campur semua bahan roti kecuali mentega, lalu mixxer/adon pake tangan sampe setengah kalis lalu terakhir masukkan mentega, adon lagi sampe kalis. Lalu diamkan adonan selama 60 menit sampai mengembang 2x lipat. Jika sudah mengembang kempiskan/buang gas pada adonan, lalu bagi adonan menjadi 10 bagian, lalu bulatkan semua adonan dan diamkan 15 menit."
- "Jika sudah 15 menit, pipihkan adonan lalu masukkan isiannya (butter/mentega/mozarella) lalu tutup kembali dengan cara dibulatkan, letakkan di atas loyang yg di lapisi kertas roti. Lalu diamkan kembali adonan selama 60 menit dan mengembang 2x lipat."
- "Mixxer mentega sampe warna agak berubah putih, lalu masukkan gula halus sambil di mixxer sampe warna putih agak pucat, lalu masukkan kuning telur terlebih dahulu dan mixxer, lalu masukkan putih telurnya di mixxer sampai pucat agak mengembang. Seduh 3 sdm kopi dengan 2 sdm air panas, aduk sampai mencair dan tidak ada ampas lalu masukkan kedalam adonan topping yg di mixxer tadi, mixxer sampai kopi merata, terakhir masukkam terigu lalu aduk menggunakan whisk/spatula sampai rata."
- "Terakhir masukkan adonan topping kedalam piping bag(plastik segitiga) simpan dalam chiller sambil menunggu roti mengembang."
- "Jika roti sudah mengembang 2 x lipat setelah didiamkan 60 menit, oleskan/semprotkan adonan topping diatas roti membentuk lingkaran seperti obat nyamuk. Jangan lupa panaskan oven 200°c selama 15 menit terlebih dahulu sebelum memanggang roti. Masukkan dan panggang roti didalam oven 180°c selama 20-25 menit."
- "Roti siap dihidangkan bersama kopi atau teh, semoga berhasil bunda-bunda semuanya❤️"
categories:
- Recipe
tags:
- roti
- o
- simple

katakunci: roti o simple 
nutrition: 290 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Dinner

---


![Roti O simple](https://img-global.cpcdn.com/recipes/cb3d693e914381d0/680x482cq70/roti-o-simple-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas atau gurih. Ciri kuliner Nusantara roti o simple yang penuh dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga dapat ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Roti O simple untuk keluarga. Momen makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang bisa anda contoh salah satunya roti o simple yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep roti o simple tanpa harus bersusah payah.
Seperti resep Roti O simple yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti O simple:

1. Siapkan  Bahan Roti:
1. Harus ada 250 gr tepung terigu protein tinggi (me:cakra)
1. Harus ada 50 gr gula pasir
1. Tambah 30 gr mentega
1. Dibutuhkan 160 gr (susu cair dingin + 1 kuning telur)
1. Dibutuhkan 1 sdt ragi (me:fermipan)
1. Siapkan 1/4 sdt garam
1. Harus ada  Bahan Topping:
1. Dibutuhkan 60 gr mentega
1. Jangan lupa 60 gr gula halus(me:gula pasir di blender)
1. Tambah 1 butir telur utuh
1. Harus ada 70 gr terigu protein sedang(me:segitiga biru)
1. Dibutuhkan 3 sdt kopi instan
1. Tambah 2 sdt air panas untuk menyeduh kopi
1. Tambah  Bahan isian:
1. Jangan lupa  Butter/mentega
1. Dibutuhkan  Mozarella(optional)




<!--inarticleads2-->

##### Langkah membuat  Roti O simple:

1. Campur semua bahan roti kecuali mentega, lalu mixxer/adon pake tangan sampe setengah kalis lalu terakhir masukkan mentega, adon lagi sampe kalis. - Lalu diamkan adonan selama 60 menit sampai mengembang 2x lipat. - Jika sudah mengembang kempiskan/buang gas pada adonan, lalu bagi adonan menjadi 10 bagian, lalu bulatkan semua adonan dan diamkan 15 menit.
1. Jika sudah 15 menit, pipihkan adonan lalu masukkan isiannya (butter/mentega/mozarella) lalu tutup kembali dengan cara dibulatkan, letakkan di atas loyang yg di lapisi kertas roti. Lalu diamkan kembali adonan selama 60 menit dan mengembang 2x lipat.
1. Mixxer mentega sampe warna agak berubah putih, lalu masukkan gula halus sambil di mixxer sampe warna putih agak pucat, lalu masukkan kuning telur terlebih dahulu dan mixxer, lalu masukkan putih telurnya di mixxer sampai pucat agak mengembang. Seduh 3 sdm kopi dengan 2 sdm air panas, aduk sampai mencair dan tidak ada ampas lalu masukkan kedalam adonan topping yg di mixxer tadi, mixxer sampai kopi merata, terakhir masukkam terigu lalu aduk menggunakan whisk/spatula sampai rata.
1. Terakhir masukkan adonan topping kedalam piping bag(plastik segitiga) simpan dalam chiller sambil menunggu roti mengembang.
1. Jika roti sudah mengembang 2 x lipat setelah didiamkan 60 menit, oleskan/semprotkan adonan topping diatas roti membentuk lingkaran seperti obat nyamuk. - Jangan lupa panaskan oven 200°c selama 15 menit terlebih dahulu sebelum memanggang roti. - Masukkan dan panggang roti didalam oven 180°c selama 20-25 menit.
1. Roti siap dihidangkan bersama kopi atau teh, semoga berhasil bunda-bunda semuanya❤️




Demikianlah cara membuat roti o simple yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
