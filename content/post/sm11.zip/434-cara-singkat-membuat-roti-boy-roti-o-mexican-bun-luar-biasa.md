---
description: "Cara singkat membuat Roti boy/roti O/Mexican bun Luar biasa"
title: "Cara singkat membuat Roti boy/roti O/Mexican bun Luar biasa"
slug: 434-cara-singkat-membuat-roti-boy-roti-o-mexican-bun-luar-biasa
date: 2020-10-16T11:13:44.050Z
image: https://img-global.cpcdn.com/recipes/adb205fdfc44018b/680x482cq70/roti-boyroti-omexican-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/adb205fdfc44018b/680x482cq70/roti-boyroti-omexican-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/adb205fdfc44018b/680x482cq70/roti-boyroti-omexican-bun-foto-resep-utama.jpg
author: Jennie Erickson
ratingvalue: 4.8
reviewcount: 10060
recipeingredient:
- " Bahan roti"
- "250 gr tepung protein tinggiCakra"
- "1 butir telur ayam"
- "25 gr mentega"
- "90 ml air"
- "5 gr ragi instran"
- "1 sdm susu bubuk"
- "50 gr gula pasir"
- " Bahan toping"
- "60 gr gula halusicing sugar"
- "60 gr mentega"
- "70 gr tepung protein sedang"
- "1 sachet kopi instan aku pake good day mocacinobs sesuai selera"
- " Pasta mokaopsional"
- "1 btr putih telur"
- " Filing"
- "sesuai selera Mentegabisa coklat dll"
recipeinstructions:
- "Masukkan semua bahan roti,kecuali mentega,mixer dengan kecepatan tinggi sampe semua tercampur rata dan kalis.kemudian masukan mentega,mixer lagi sampe kalis elastis.kemudian diamkan adonan sampe mengembang ±1 jam"
- "Setelah 1 jam dan adonan mengembang,kempeskan adonan dan bagi adonan menjadi 12pcs/ bisa tergantung mau seberapa besar ukuran roti nya.setelah itu masukkan filing mentega bentuk bulat dan tutup adonan dengan plastik wrap/lap biarkan mengembang."
- "Sambil menunggu adonan mengembang,Kemudian kita membuat toping.dalam wadah masukkan,gula halus&amp;mentega aduk sampe tercampur rata.masukkan tepung,putih telur,kopi instan,dan pasta moka.aduk2 sampe tercampur rata dan tidak ada gumpalan/adonan terasa halus."
- "Masukkan adonan toping dalam plastik segitiga.beri toping ke adonan roti secara melingkar,seperti di photo ya bund."
- "Kemudian panggang roti disuhu 180°c selama 15-20 menit.dan roti boy siap untuk disantap🤩"
categories:
- Recipe
tags:
- roti
- boyroti
- omexican

katakunci: roti boyroti omexican 
nutrition: 238 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT39M"
recipeyield: "1"
recipecategory: Dinner

---


![Roti boy/roti O/Mexican bun](https://img-global.cpcdn.com/recipes/adb205fdfc44018b/680x482cq70/roti-boyroti-omexican-bun-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita lestarikan karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti roti boy/roti o/mexican bun yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Kita

Keharmonisan keluarga bisa diperoleh dengan cara sederhana. Diantaranya adalah memasak Roti boy/roti O/Mexican bun untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda contoh salah satunya roti boy/roti o/mexican bun yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep roti boy/roti o/mexican bun tanpa harus bersusah payah.
Berikut ini resep Roti boy/roti O/Mexican bun yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti boy/roti O/Mexican bun:

1. Diperlukan  Bahan roti*
1. Harus ada 250 gr tepung protein tinggi(Cakra)
1. Jangan lupa 1 butir telur ayam
1. Siapkan 25 gr mentega
1. Siapkan 90 ml air
1. Tambah 5 gr ragi instran
1. Jangan lupa 1 sdm susu bubuk
1. Diperlukan 50 gr gula pasir
1. Harus ada  Bahan toping*
1. Harus ada 60 gr gula halus/icing sugar
1. Harus ada 60 gr mentega
1. Tambah 70 gr tepung protein sedang
1. Harus ada 1 sachet kopi instan (aku pake good day mocacino/bs sesuai selera)
1. Harap siapkan  Pasta moka(opsional)
1. Harap siapkan 1 btr putih telur
1. Jangan lupa  Filing*
1. Tambah sesuai selera Mentega/bisa coklat dll




<!--inarticleads2-->

##### Bagaimana membuat  Roti boy/roti O/Mexican bun:

1. Masukkan semua bahan roti,kecuali mentega,mixer dengan kecepatan tinggi sampe semua tercampur rata dan kalis.kemudian masukan mentega,mixer lagi sampe kalis elastis.kemudian diamkan adonan sampe mengembang ±1 jam
1. Setelah 1 jam dan adonan mengembang,kempeskan adonan dan bagi adonan menjadi 12pcs/ bisa tergantung mau seberapa besar ukuran roti nya.setelah itu masukkan filing mentega bentuk bulat dan tutup adonan dengan plastik wrap/lap biarkan mengembang.
1. Sambil menunggu adonan mengembang,Kemudian kita membuat toping.dalam wadah masukkan,gula halus&amp;mentega aduk sampe tercampur rata.masukkan tepung,putih telur,kopi instan,dan pasta moka.aduk2 sampe tercampur rata dan tidak ada gumpalan/adonan terasa halus.
1. Masukkan adonan toping dalam plastik segitiga.beri toping ke adonan roti secara melingkar,seperti di photo ya bund.
1. Kemudian panggang roti disuhu 180°c selama 15-20 menit.dan roti boy siap untuk disantap🤩




Demikianlah cara membuat roti boy/roti o/mexican bun yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
