---
description: "Langkah untuk membuat Mexican Bun/Coffe Bun (Roti Boy/Roti O&amp;#39;/Papa Buns) teraktual"
title: "Langkah untuk membuat Mexican Bun/Coffe Bun (Roti Boy/Roti O&amp;#39;/Papa Buns) teraktual"
slug: 371-langkah-untuk-membuat-mexican-bun-coffe-bun-roti-boy-roti-o-and-39-papa-buns-teraktual
date: 2020-12-01T13:53:31.123Z
image: https://img-global.cpcdn.com/recipes/f0818e91233a5977/680x482cq70/mexican-buncoffe-bun-roti-boyroti-opapa-buns-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f0818e91233a5977/680x482cq70/mexican-buncoffe-bun-roti-boyroti-opapa-buns-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f0818e91233a5977/680x482cq70/mexican-buncoffe-bun-roti-boyroti-opapa-buns-foto-resep-utama.jpg
author: Warren McBride
ratingvalue: 4.9
reviewcount: 35731
recipeingredient:
- " Bahan roti"
- "9 sdm munjung tepung pro tinggi Cakra Kembar"
- "1 sachet susu bubuk dancow"
- "2 sdm gula pasir"
- "1 sdm ragi fermipan"
- "1 butir kuning telur"
- "100 ml air bisa kurang bisa lebih ya Sesuaikan saja"
- "1 sdm mentega Blue Band"
- " Bahan Topping"
- "2 1/2 sdm gula halus boleh di tambah"
- "1 sachet Luwak White Koffie"
- "2 sdm mentega Blue Band"
- "3 sdm tepung pro sedang Segitiga biru"
- "1 butir putih telur"
- " Fillingisian"
- "Secukupnya mentegaBlue Band isian bisa bebas ya"
recipeinstructions:
- "Campur tepung pro tinggi, susu bubuk, ragi, gula, dan kuning telur dalam 1 wadah, lalu mixer spiral atau ulen tangan sembari di tuangkan air perlahan-lahan. Ulen/mixer hingga setengah kalis"
- "Saat hampir kalis, tambahkan 1 sdm mentega, ulen lagi hingga benar-benar kalis. Setelah kalis, istirahatkan adonan. Tutup dengan kain/plastic wrap selama 1 jam"
- "Selama pengistirahatan adonan mari kita buat adonan topping nya. Campurkan gula halus, kopi bubuk, dan mentega di 1 wadah. Lalu mixer dengan speed 2 hingga terlihat bercampur. Lalu tambahkan 3 sdm tepung pro sedang dan 1 butir putih telur. Mix kembali hingga menjadi krim"
- "Jika sudah masukan krim topping ke dalam pipping bag. Klo aku simpan krim nya di plastik tomat kiloan, karna gk ada pipping bag 🤭. Krim topping nya bisa di taro di kulkas dulu sampai saat ingin di pakai. Oh iya, Mentega untuk filling roti juga di sarankan simpan di freezer dulu ya, supaya gk meleleh &amp; bleber saat di masukan ke roti"
- "Setelah 1 jam, siapkan loyang, alasi loyang dengan baking paper. Setelah loyang siap, buka adonan dan kempeskan adonan roti kembali. Lalu bagi-bagi adonan sesuai selera. Kalau aku bagi jadi 7 bagian"
- "Pipihkan pinggiran adonan dan biarkan tengahnya lebih tebal (bentuknya jadi mirip kue cucur ya), lalu beri mentega pada bagian tengah adonan. Tutup rapat adonan, dan bentuk menjadi bulat. Sisihkan adonan yang sudah memiliki isi. Jika seluruh adonan telah terisi, istirahatkan kembali selama 20 menit"
- "Selama menunggu 20 menit, panaskan oven dengan api sedang-besar. Aku pakai oven tangkring, kalau pakai oven listrik sesuaikan aja ya"
- "Setelah 20 menit terlewat, beri topping pada adonan roti. Bentuk melingkar, usahakan jangan ada celah yang terlihat ya"
- "Jika sudah, panggang roti dengan api kecil selama 25 menit. Aku taro loyang persegi di stage paling bawah dan yg bulat di stage paling atas. Putar-putar loyang setiap beberapa menit sekali agar matangnya merata. Saat sudah 15 menit aku tukar posisi loyang jadi yg persegi di paling atas dan yg bulat di paling bawah"
- "Setelah lapisan atas di rasa sudah mengeras dan roti sudah kecoklatan, angkat biarkan mendingin di suhu ruang. Setelah dingin pisah-pisahkan roti"
- "Roti pun siap di hidangkan sebagai camilan, teman minum teh/kopi, atau sebagai sarapan pagi. Roti nya benar-benar empuk dan endull lho 🤤🤤. Setelah dingin langsung raib 3 roti diambil adik ku 😂"
categories:
- Recipe
tags:
- mexican
- buncoffe
- bun

katakunci: mexican buncoffe bun 
nutrition: 293 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Dinner

---


![Mexican Bun/Coffe Bun (Roti Boy/Roti O&#39;/Papa Buns)](https://img-global.cpcdn.com/recipes/f0818e91233a5977/680x482cq70/mexican-buncoffe-bun-roti-boyroti-opapa-buns-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga empuk. Ciri kuliner Nusantara mexican bun/coffe bun (roti boy/roti o&#39;/papa buns) yang kaya dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Mexican Bun/Coffe Bun (Roti Boy/Roti O&#39;/Papa Buns) untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Banyak yang sering mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang dapat anda buat salah satunya mexican bun/coffe bun (roti boy/roti o&#39;/papa buns) yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep mexican bun/coffe bun (roti boy/roti o&#39;/papa buns) tanpa harus bersusah payah.
Berikut ini resep Mexican Bun/Coffe Bun (Roti Boy/Roti O&#39;/Papa Buns) yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 11 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Mexican Bun/Coffe Bun (Roti Boy/Roti O&#39;/Papa Buns):

1. Jangan lupa  Bahan roti
1. Harap siapkan 9 sdm munjung tepung pro tinggi (Cakra Kembar)
1. Harap siapkan 1 sachet susu bubuk (dancow)
1. Harus ada 2 sdm gula pasir
1. Tambah 1 sdm ragi (fermipan)
1. Jangan lupa 1 butir kuning telur
1. Siapkan 100 ml air (bisa kurang bisa lebih ya. Sesuaikan saja)
1. Diperlukan 1 sdm mentega (Blue Band)
1. Siapkan  Bahan Topping
1. Diperlukan 2 1/2 sdm gula halus (boleh di tambah)
1. Harus ada 1 sachet Luwak White Koffie
1. Harus ada 2 sdm mentega (Blue Band)
1. Siapkan 3 sdm tepung pro sedang (Segitiga biru)
1. Diperlukan 1 butir putih telur
1. Harus ada  Filling/isian
1. Siapkan Secukupnya mentega/Blue Band (isian bisa bebas ya)




<!--inarticleads2-->

##### Instruksi membuat  Mexican Bun/Coffe Bun (Roti Boy/Roti O&#39;/Papa Buns):

1. Campur tepung pro tinggi, susu bubuk, ragi, gula, dan kuning telur dalam 1 wadah, lalu mixer spiral atau ulen tangan sembari di tuangkan air perlahan-lahan. Ulen/mixer hingga setengah kalis
1. Saat hampir kalis, tambahkan 1 sdm mentega, ulen lagi hingga benar-benar kalis. Setelah kalis, istirahatkan adonan. Tutup dengan kain/plastic wrap selama 1 jam
1. Selama pengistirahatan adonan mari kita buat adonan topping nya. Campurkan gula halus, kopi bubuk, dan mentega di 1 wadah. Lalu mixer dengan speed 2 hingga terlihat bercampur. Lalu tambahkan 3 sdm tepung pro sedang dan 1 butir putih telur. Mix kembali hingga menjadi krim
1. Jika sudah masukan krim topping ke dalam pipping bag. Klo aku simpan krim nya di plastik tomat kiloan, karna gk ada pipping bag 🤭. Krim topping nya bisa di taro di kulkas dulu sampai saat ingin di pakai. Oh iya, Mentega untuk filling roti juga di sarankan simpan di freezer dulu ya, supaya gk meleleh &amp; bleber saat di masukan ke roti
1. Setelah 1 jam, siapkan loyang, alasi loyang dengan baking paper. Setelah loyang siap, buka adonan dan kempeskan adonan roti kembali. Lalu bagi-bagi adonan sesuai selera. Kalau aku bagi jadi 7 bagian
1. Pipihkan pinggiran adonan dan biarkan tengahnya lebih tebal (bentuknya jadi mirip kue cucur ya), lalu beri mentega pada bagian tengah adonan. Tutup rapat adonan, dan bentuk menjadi bulat. Sisihkan adonan yang sudah memiliki isi. Jika seluruh adonan telah terisi, istirahatkan kembali selama 20 menit
1. Selama menunggu 20 menit, panaskan oven dengan api sedang-besar. Aku pakai oven tangkring, kalau pakai oven listrik sesuaikan aja ya
1. Setelah 20 menit terlewat, beri topping pada adonan roti. Bentuk melingkar, usahakan jangan ada celah yang terlihat ya
1. Jika sudah, panggang roti dengan api kecil selama 25 menit. Aku taro loyang persegi di stage paling bawah dan yg bulat di stage paling atas. Putar-putar loyang setiap beberapa menit sekali agar matangnya merata. Saat sudah 15 menit aku tukar posisi loyang jadi yg persegi di paling atas dan yg bulat di paling bawah
1. Setelah lapisan atas di rasa sudah mengeras dan roti sudah kecoklatan, angkat biarkan mendingin di suhu ruang. Setelah dingin pisah-pisahkan roti
1. Roti pun siap di hidangkan sebagai camilan, teman minum teh/kopi, atau sebagai sarapan pagi. Roti nya benar-benar empuk dan endull lho 🤤🤤. Setelah dingin langsung raib 3 roti diambil adik ku 😂




Demikianlah cara membuat mexican bun/coffe bun (roti boy/roti o&#39;/papa buns) yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan terbukti, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
