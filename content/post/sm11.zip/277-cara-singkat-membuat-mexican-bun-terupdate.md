---
description: "Cara singkat membuat Mexican Bun terupdate"
title: "Cara singkat membuat Mexican Bun terupdate"
slug: 277-cara-singkat-membuat-mexican-bun-terupdate
date: 2021-02-10T00:05:37.229Z
image: https://img-global.cpcdn.com/recipes/67a2737c9082820d/680x482cq70/mexican-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/67a2737c9082820d/680x482cq70/mexican-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/67a2737c9082820d/680x482cq70/mexican-bun-foto-resep-utama.jpg
author: Seth Daniel
ratingvalue: 4.1
reviewcount: 21361
recipeingredient:
- " Bahan roti "
- "200 gram tepung terigu protein tinggi"
- "60 gram tepung terigu protein sedang"
- "3 gram ragi instan"
- "50 gram gula pasir"
- "15 gram susu bubuk"
- "1 kuning telur ukuran besar  susu cair sampai 160180 ml"
- "30 gram butter"
- "3 gram garam"
- " Bahan isian "
- "25 gram butter"
- "25 gram keju cheddar parut"
- "2 sdm gula halus"
- " Bahan topping "
- "1 putih telur"
- "50 gram butter"
- "2 sdm munjung gula halus"
- "50 gram tepung terigu"
- "1/4 sdt baking powder"
- "1 sdt kopi bubuk diseduh dengan 1 sdm air panas"
- "1 sdt pasta moka"
recipeinstructions:
- "Campurkan semua bahan kecuali butter dan garam. Aduk hingga kalis. Tambahkan butter dan garam, aduk hingga kalis elastis. Bulatkan adonan. Diamkan 15 menit dalam wadah yang ditutup plastik."
- "Timbang adonan @ 50 gram. Bulatkan. Diamkan 10 menit."
- "Sambil menunggu, buat bahan isiannya. Campur semua bahan jadi satu. Aduk rata."
- "Setelah 10 menit, ambil adonan, pipihkan dan beri bahan isian. Tutup adonan dan bulatkan. Letakkan pada loyang yang telah dilapisi baking paper. Tutupi dengan plastik. Diamkan hingga mengembang 2x lipat (kurleb 1 jam)."
- "Sambil menunggu, kita buat bahan toppingnya. Kocok putih telur hingga kaku. Sisihkan."
- "Dalam wadah lain, kocok butter dan gula hingga lembut. Tambahkan terigu, baking powder, kocokan putih telur, air kopi dan pasta moka. Aduk rata."
- "Masukkan bahan topping ke dalam piping bag."
- "Setelah adonan rotinya mengembang 2x lipat, beri topping diatasnya dengan motif melingkar rapat. Lalu oven dengan suhu 170-180 dercel selama 15 menit. (Kenali oven masing2)"
- "Mexican bun siap disantap. Lebih nikmat disantap dalam kondisi hangat karena lapisan toppingnya masih kriuk."
- "Rotinya empuk banget, lihat seratnya... 😍"
categories:
- Recipe
tags:
- mexican
- bun

katakunci: mexican bun 
nutrition: 293 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT39M"
recipeyield: "1"
recipecategory: Dessert

---


![Mexican Bun](https://img-global.cpcdn.com/recipes/67a2737c9082820d/680x482cq70/mexican-bun-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga gurih. Karasteristik masakan Nusantara mexican bun yang penuh dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga dapat diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Mexican Bun untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang bisa anda praktekkan salah satunya mexican bun yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep mexican bun tanpa harus bersusah payah.
Seperti resep Mexican Bun yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 10 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican Bun:

1. Diperlukan  Bahan roti :
1. Harus ada 200 gram tepung terigu protein tinggi
1. Tambah 60 gram tepung terigu protein sedang
1. Siapkan 3 gram ragi instan
1. Harap siapkan 50 gram gula pasir
1. Harus ada 15 gram susu bubuk
1. Siapkan 1 kuning telur (ukuran besar) + susu cair sampai 160-180 ml
1. Tambah 30 gram butter
1. Harus ada 3 gram garam
1. Siapkan  Bahan isian :
1. Jangan lupa 25 gram butter
1. Jangan lupa 25 gram keju cheddar parut
1. Harap siapkan 2 sdm gula halus
1. Dibutuhkan  Bahan topping :
1. Diperlukan 1 putih telur
1. Dibutuhkan 50 gram butter
1. Dibutuhkan 2 sdm munjung gula halus
1. Dibutuhkan 50 gram tepung terigu
1. Dibutuhkan 1/4 sdt baking powder
1. Harus ada 1 sdt kopi bubuk diseduh dengan 1 sdm air panas
1. Harap siapkan 1 sdt pasta moka




<!--inarticleads2-->

##### Bagaimana membuat  Mexican Bun:

1. Campurkan semua bahan kecuali butter dan garam. Aduk hingga kalis. Tambahkan butter dan garam, aduk hingga kalis elastis. Bulatkan adonan. Diamkan 15 menit dalam wadah yang ditutup plastik.
1. Timbang adonan @ 50 gram. Bulatkan. Diamkan 10 menit.
1. Sambil menunggu, buat bahan isiannya. Campur semua bahan jadi satu. Aduk rata.
1. Setelah 10 menit, ambil adonan, pipihkan dan beri bahan isian. Tutup adonan dan bulatkan. Letakkan pada loyang yang telah dilapisi baking paper. Tutupi dengan plastik. Diamkan hingga mengembang 2x lipat (kurleb 1 jam).
1. Sambil menunggu, kita buat bahan toppingnya. Kocok putih telur hingga kaku. Sisihkan.
1. Dalam wadah lain, kocok butter dan gula hingga lembut. Tambahkan terigu, baking powder, kocokan putih telur, air kopi dan pasta moka. Aduk rata.
1. Masukkan bahan topping ke dalam piping bag.
1. Setelah adonan rotinya mengembang 2x lipat, beri topping diatasnya dengan motif melingkar rapat. Lalu oven dengan suhu 170-180 dercel selama 15 menit. (Kenali oven masing2)
1. Mexican bun siap disantap. Lebih nikmat disantap dalam kondisi hangat karena lapisan toppingnya masih kriuk.
1. Rotinya empuk banget, lihat seratnya... 😍




Demikianlah cara membuat mexican bun yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan terbukti, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
