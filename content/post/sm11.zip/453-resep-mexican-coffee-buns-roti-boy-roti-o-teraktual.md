---
description: "Resep : Mexican Coffee Buns / Roti Boy / Roti O teraktual"
title: "Resep : Mexican Coffee Buns / Roti Boy / Roti O teraktual"
slug: 453-resep-mexican-coffee-buns-roti-boy-roti-o-teraktual
date: 2020-11-30T12:32:30.571Z
image: https://img-global.cpcdn.com/recipes/732ef35335ca3af2/680x482cq70/mexican-coffee-buns-roti-boy-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/732ef35335ca3af2/680x482cq70/mexican-coffee-buns-roti-boy-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/732ef35335ca3af2/680x482cq70/mexican-coffee-buns-roti-boy-roti-o-foto-resep-utama.jpg
author: Antonio Benson
ratingvalue: 4.3
reviewcount: 13800
recipeingredient:
- " Bahan A "
- "200 gram Tepung Terigu Protein Tinggi Cakra"
- "45 gram Tepung Terigu Protein Sedang Segitiga Biru"
- "15 gram  2 sdm Susu Bubuk Dancow"
- "0,5 sdt Pasta Susu ku pake extract milk powder"
- "36 gram  25 sdm Gula Pasir"
- "6 gram  2 sdt Ragi Instan Fermipan"
- "180 ml Telor 1 btr  20 gr whip cream bubuk  susu cair UHT"
- " Bahan B "
- "30 gram  2 sdm Butter Anchor"
- "2 gram  34 sdt Garam konversi 1 sdt  3 gram"
- " Bahan C Kopi campuran toping "
- "2 sdt Nescafe"
- "2 sdt Susu Dancow"
- "15 ml Air panas"
- " Bahan D Topping "
- "90 gram Butter suhu ruang Elle  Vire"
- "100 gram Gula Halus Icing Sugar"
- "1 btr Telor"
- "85 gram Tepung Terigu Segitiga Biru"
- "2 sdm Susu Bubuk"
- " Bahan E Isian "
- " Butter potong kotak kecil"
- " Keju cheddar parut"
recipeinstructions:
- "Mixer semua bahan A sampe kalis kecuali bahan B : butter dan garam."
- "Setelah kalis masukkan bahan B : butter dan garam lanjut mixer sampai lembut kalis elastis."
- "Bagi adonan menjadi 10 bagian masing masing 50 gram."
- "Gilas adonan kemudian isi dengan butter dan keju, tutup bulatkan. Tata di atas loyang yang sudah dioles margarin. Beri jarak lebar."
- "Fermentasikan selama 40 menit sampai 2x nya."
- "Buat campuran kopi untuk topping : campur nescafe+susu+air panas aduk dinginkan."
- "Mixer butter, gula halus, campuran kopi sampai rata. Kemudian masukkan telor, terigu dan susu bubuk. Mixer sampai rata."
- "Masukkan ke dalam plastik segitiga kemudian semprot melingkar rapat di atas roti yg sudah difermentasi 40 menit tadi.Batas sampai setengah roti. Harus rapat nyemprotnya biar rata topingnya."
- "Sebelumnya panaskan oven terlebih dahulu. Kemudian oven roti dengan suhu 180 derajat selama 20 menit."
- "Selamat mencoba -Dewo&#39;s Kitchen- jgn lupa mampir ke channel youtube aku dewo saputro yaa ------&gt; https://www.youtube.com/channel/UCa5bcMN3z1uJZUH70_IT7ew"
categories:
- Recipe
tags:
- mexican
- coffee
- buns

katakunci: mexican coffee buns 
nutrition: 151 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT40M"
recipeyield: "3"
recipecategory: Dinner

---


![Mexican Coffee Buns / Roti Boy / Roti O](https://img-global.cpcdn.com/recipes/732ef35335ca3af2/680x482cq70/mexican-coffee-buns-roti-boy-roti-o-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau gurih. Ciri khas kuliner Indonesia mexican coffee buns / roti boy / roti o yang kaya dengan rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Keharmonisan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Mexican Coffee Buns / Roti Boy / Roti O untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang bisa anda praktekkan salah satunya mexican coffee buns / roti boy / roti o yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep mexican coffee buns / roti boy / roti o tanpa harus bersusah payah.
Seperti resep Mexican Coffee Buns / Roti Boy / Roti O yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 24 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican Coffee Buns / Roti Boy / Roti O:

1. Harus ada  Bahan A :
1. Siapkan 200 gram Tepung Terigu Protein Tinggi (Cakra)
1. Siapkan 45 gram Tepung Terigu Protein Sedang (Segitiga Biru)
1. Siapkan 15 gram / 2 sdm Susu Bubuk (Dancow)
1. Jangan lupa 0,5 sdt Pasta Susu (ku pake extract milk powder)
1. Tambah 36 gram / 2,5 sdm Gula Pasir
1. Siapkan 6 gram / 2 sdt Ragi Instan (Fermipan)
1. Dibutuhkan 180 ml (Telor 1 btr + 20 gr whip cream bubuk + susu cair UHT)
1. Dibutuhkan  Bahan B :
1. Harus ada 30 gram / 2 sdm Butter Anchor
1. Harus ada 2 gram / 3/4 sdt Garam (konversi 1 sdt = 3 gram)
1. Dibutuhkan  Bahan C (Kopi campuran toping) :
1. Dibutuhkan 2 sdt Nescafe
1. Tambah 2 sdt Susu Dancow
1. Dibutuhkan 15 ml Air panas
1. Harap siapkan  Bahan D (Topping) :
1. Tambah 90 gram Butter suhu ruang (Elle &amp; Vire)
1. Harap siapkan 100 gram Gula Halus (Icing Sugar)
1. Harus ada 1 btr Telor
1. Diperlukan 85 gram Tepung Terigu (Segitiga Biru)
1. Harap siapkan 2 sdm Susu Bubuk
1. Harus ada  Bahan E (Isian) :
1. Siapkan  Butter potong kotak kecil
1. Diperlukan  Keju cheddar parut




<!--inarticleads2-->

##### Cara membuat  Mexican Coffee Buns / Roti Boy / Roti O:

1. Mixer semua bahan A sampe kalis kecuali bahan B : butter dan garam.
1. Setelah kalis masukkan bahan B : butter dan garam lanjut mixer sampai lembut kalis elastis.
1. Bagi adonan menjadi 10 bagian masing masing 50 gram.
1. Gilas adonan kemudian isi dengan butter dan keju, tutup bulatkan. Tata di atas loyang yang sudah dioles margarin. Beri jarak lebar.
1. Fermentasikan selama 40 menit sampai 2x nya.
1. Buat campuran kopi untuk topping : campur nescafe+susu+air panas aduk dinginkan.
1. Mixer butter, gula halus, campuran kopi sampai rata. Kemudian masukkan telor, terigu dan susu bubuk. Mixer sampai rata.
1. Masukkan ke dalam plastik segitiga kemudian semprot melingkar rapat di atas roti yg sudah difermentasi 40 menit tadi.Batas sampai setengah roti. Harus rapat nyemprotnya biar rata topingnya.
1. Sebelumnya panaskan oven terlebih dahulu. Kemudian oven roti dengan suhu 180 derajat selama 20 menit.
1. Selamat mencoba -Dewo&#39;s Kitchen- jgn lupa mampir ke channel youtube aku dewo saputro yaa ------&gt; https://www.youtube.com/channel/UCa5bcMN3z1uJZUH70_IT7ew




Demikianlah cara membuat mexican coffee buns / roti boy / roti o yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan teruji, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
