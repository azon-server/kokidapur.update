---
description: "Langkah untuk menyiapakan Mexican Coffee Bun / Roti Boy / Roti O Homemade"
title: "Langkah untuk menyiapakan Mexican Coffee Bun / Roti Boy / Roti O Homemade"
slug: 348-langkah-untuk-menyiapakan-mexican-coffee-bun-roti-boy-roti-o-homemade
date: 2020-09-23T20:21:00.345Z
image: https://img-global.cpcdn.com/recipes/46c10cad39c0d86d/680x482cq70/mexican-coffee-bun-roti-boy-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/46c10cad39c0d86d/680x482cq70/mexican-coffee-bun-roti-boy-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/46c10cad39c0d86d/680x482cq70/mexican-coffee-bun-roti-boy-roti-o-foto-resep-utama.jpg
author: Isaiah Padilla
ratingvalue: 4
reviewcount: 18576
recipeingredient:
- " Dough"
- " Bahan A"
- "260 gr tepung terigu protein tinggi"
- "50 gr gula pasir"
- "1 sdt ragi instant"
- "1 sdm susu bubuk"
- "1 kuning telur"
- "150 gr susu cair"
- " Bahan B "
- "30 gr margarin"
- "1/2 sdt garam"
- " Bahan Isian"
- " margarine"
- " Meses"
- " Bahan Topping"
- " Bahan A "
- "1 butir putih telur"
- " Bahan B "
- "50 gr butter"
- "1 sdm gula halus"
- " Bahan C "
- "1/3 sdt baking powder"
- "1 bks kopi sachet larutkan dengan 2sdm air panas"
- "50 gr terigu"
recipeinstructions:
- "Campur semua bahan dough kering bagian A jadi satu lalu uleni/mixer hingga 1/2 kalis"
- "Setelah 1/2 kalis masukan butter dan garam, lanjut uleni/mixer hingga kalis"
- "Setelah kalis tutup dough proofing hingga double size selama -/+ 45mnt"
- "Setelah double size kempiskan dough lalu bagi&#34; adonan @35 gr bulatkan lalu tutup istirahatkan kembali selama 15menit"
- "Selagi menunggu dough mengembang. Lanjutkan proses pembuatan topping. Pertama kocok putih telur hingga kaku lalu sisihkan."
- "Larutkan kopi dengan air panas lalu tambahkan 4-5 tetes perasa mocca. Untuk mendapatkan aroma &amp; rasa kopi yg otentik, bisa menggunakan kopi hitam ya."
- "Aduk bahan topping B, campur butter dan gula halus aduk rata. Tambahkan tepung lalu tambahkan kopi yg sdh dilarutkan dgn air hangat tadi. Aduk rata."
- "Setelah rata. Saatnya pencampuran dengan putih telur. Aduk campur perlahan ya."
- "Tuang adonan topping kedalam plastik segitiga. Sisihkan"
- "Setelah semua beres saatnya kembali membuka dough yg tadi diistirahatkan. Kempeskan adonan lalu beri isian margarin ataupun selai coklat /meses hingga selesai. Tutup rapat dough agar selai maupun margarin tidak bocor di bagian bawah. Langsung tata diatas loyang. Setelah selesai, kembali istirahatkan hingga mengembang. Jangan over profing ya"
- "Tutup dan proofing hingga double size"
- "Setelah double size semprotkan topping sampai 3/4 bagian dough saja."
- "Panggang dengan suhu 175 api atas bawah selama 20 menit (sy pakai api bawah sj). Hasilnya roti terasa lembut sekali."
- "Sajikan."
categories:
- Recipe
tags:
- mexican
- coffee
- bun

katakunci: mexican coffee bun 
nutrition: 165 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Dinner

---


![Mexican Coffee Bun / Roti Boy / Roti O](https://img-global.cpcdn.com/recipes/46c10cad39c0d86d/680x482cq70/mexican-coffee-bun-roti-boy-roti-o-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang setidaknya kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti mexican coffee bun / roti boy / roti o yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Kita

Kedekatan keluarga bisa didapat dengan cara simple. Diantaranya adalah memasak Mexican Coffee Bun / Roti Boy / Roti O untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang bisa anda praktekkan salah satunya mexican coffee bun / roti boy / roti o yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep mexican coffee bun / roti boy / roti o tanpa harus bersusah payah.
Berikut ini resep Mexican Coffee Bun / Roti Boy / Roti O yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 24 bahan dan 14 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican Coffee Bun / Roti Boy / Roti O:

1. Harus ada  Dough
1. Harap siapkan  Bahan A
1. Dibutuhkan 260 gr tepung terigu protein tinggi
1. Dibutuhkan 50 gr gula pasir
1. Siapkan 1 sdt ragi instant
1. Harus ada 1 sdm susu bubuk
1. Jangan lupa 1 kuning telur
1. Jangan lupa 150 gr susu cair
1. Jangan lupa  Bahan B :
1. Harap siapkan 30 gr margarin
1. Dibutuhkan 1/2 sdt garam
1. Jangan lupa  Bahan Isian
1. Diperlukan  margarine
1. Harus ada  Meses
1. Siapkan  Bahan Topping
1. Harus ada  Bahan A :
1. Diperlukan 1 butir putih telur
1. Tambah  Bahan B :
1. Siapkan 50 gr butter
1. Siapkan 1 sdm gula halus
1. Harap siapkan  Bahan C :
1. Siapkan 1/3 sdt baking powder
1. Harus ada 1 bks kopi sachet larutkan dengan 2sdm air panas
1. Jangan lupa 50 gr terigu




<!--inarticleads2-->

##### Cara membuat  Mexican Coffee Bun / Roti Boy / Roti O:

1. Campur semua bahan dough kering bagian A jadi satu lalu uleni/mixer hingga 1/2 kalis
1. Setelah 1/2 kalis masukan butter dan garam, lanjut uleni/mixer hingga kalis
1. Setelah kalis tutup dough proofing hingga double size selama -/+ 45mnt
1. Setelah double size kempiskan dough lalu bagi&#34; adonan @35 gr bulatkan lalu tutup istirahatkan kembali selama 15menit
1. Selagi menunggu dough mengembang. Lanjutkan proses pembuatan topping. Pertama kocok putih telur hingga kaku lalu sisihkan.
1. Larutkan kopi dengan air panas lalu tambahkan 4-5 tetes perasa mocca. Untuk mendapatkan aroma &amp; rasa kopi yg otentik, bisa menggunakan kopi hitam ya.
1. Aduk bahan topping B, campur butter dan gula halus aduk rata. Tambahkan tepung lalu tambahkan kopi yg sdh dilarutkan dgn air hangat tadi. Aduk rata.
1. Setelah rata. Saatnya pencampuran dengan putih telur. Aduk campur perlahan ya.
1. Tuang adonan topping kedalam plastik segitiga. Sisihkan
1. Setelah semua beres saatnya kembali membuka dough yg tadi diistirahatkan. Kempeskan adonan lalu beri isian margarin ataupun selai coklat /meses hingga selesai. Tutup rapat dough agar selai maupun margarin tidak bocor di bagian bawah. Langsung tata diatas loyang. Setelah selesai, kembali istirahatkan hingga mengembang. Jangan over profing ya
1. Tutup dan proofing hingga double size
1. Setelah double size semprotkan topping sampai 3/4 bagian dough saja.
1. Panggang dengan suhu 175 api atas bawah selama 20 menit (sy pakai api bawah sj). Hasilnya roti terasa lembut sekali.
1. Sajikan.




Demikianlah cara membuat mexican coffee bun / roti boy / roti o yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
