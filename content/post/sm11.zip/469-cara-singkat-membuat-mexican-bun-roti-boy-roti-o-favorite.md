---
description: "Cara singkat membuat Mexican Bun (roti boy, roti o) Favorite"
title: "Cara singkat membuat Mexican Bun (roti boy, roti o) Favorite"
slug: 469-cara-singkat-membuat-mexican-bun-roti-boy-roti-o-favorite
date: 2021-03-05T17:00:06.890Z
image: https://img-global.cpcdn.com/recipes/6347f8a4087d4179/680x482cq70/mexican-bun-roti-boy-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6347f8a4087d4179/680x482cq70/mexican-bun-roti-boy-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6347f8a4087d4179/680x482cq70/mexican-bun-roti-boy-roti-o-foto-resep-utama.jpg
author: Elnora Jensen
ratingvalue: 4.8
reviewcount: 48384
recipeingredient:
- " Adonan tangzhong"
- "50 gr tepung protein tinggi me cakra"
- "250 ml air"
- " Adonan roti"
- "450 gr tepung protein tinggi"
- "100 gr tepung protein sedang"
- "100 gr gula"
- "11 gr ragi instant"
- "1 butir telur"
- "115 ml susu cair"
- "50 gr butter cair"
- " Filling"
- "20 buah salted butter beku yang dipotong kotak 15x15cm"
- " Topping kopi"
- "3 butir putih telur"
- "110 gr butter"
- "80 gr gula"
- "2 sachet kopi instant"
- "100 gr tepung protein rendah"
recipeinstructions:
- "Adonan tangzhong: campur tepung dan air, pastikan tidak ada yg bergerindil. masak di atas api kecil. aduk-aduk sampai menjadi adonan yang kental (seperti isian kue sus). dinginkan."
- "Campur tepung, gula, ragi, telur, susu aduk sampai kalis. tambahkan butter cair, aduk sampai kalis elastis."
- "Istirahatkan sampai mengembang 2 kali lipat. kempiskan."
- "Ambil adonan, sekitar 40gr, isi dengan salted butter dingin, bentuk bulatan. istirahatkan kembali 20 menitan."
- "Kocok/mixer semua bahan topping kopi, kecuali tepung. aduk sampai rata, terakhir masukan tepung. aduk, adonan topping akan sedikit kental seperti pasta gigi, kalo masih encer jangan ragu tambahkan tepung. masukan kedalam plastik segitiga."
- "Beri topping diatas adonan roti yang siap di panggang dengan bentuk melingkar seperti obat nyamuk."
- "Panggang disuhu 200 derajat celcius selama 15-20 menit. sajikan hangat."
categories:
- Recipe
tags:
- mexican
- bun
- roti

katakunci: mexican bun roti 
nutrition: 143 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Dessert

---


![Mexican Bun (roti boy, roti o)](https://img-global.cpcdn.com/recipes/6347f8a4087d4179/680x482cq70/mexican-bun-roti-boy-roti-o-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas atau enak. Karasteristik kuliner Indonesia mexican bun (roti boy, roti o) yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Mexican Bun (roti boy, roti o) untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang dapat anda coba salah satunya mexican bun (roti boy, roti o) yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep mexican bun (roti boy, roti o) tanpa harus bersusah payah.
Berikut ini resep Mexican Bun (roti boy, roti o) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican Bun (roti boy, roti o):

1. Tambah  Adonan tangzhong
1. Diperlukan 50 gr tepung protein tinggi (me: cakra)
1. Siapkan 250 ml air
1. Tambah  Adonan roti
1. Siapkan 450 gr tepung protein tinggi
1. Jangan lupa 100 gr tepung protein sedang
1. Jangan lupa 100 gr gula
1. Jangan lupa 11 gr ragi instant
1. Siapkan 1 butir telur
1. Harus ada 115 ml susu cair
1. Harap siapkan 50 gr butter cair
1. Harus ada  Filling
1. Dibutuhkan 20 buah salted butter beku yang dipotong kotak 1,5x1,5cm
1. Dibutuhkan  Topping kopi
1. Harap siapkan 3 butir putih telur
1. Tambah 110 gr butter
1. Dibutuhkan 80 gr gula
1. Tambah 2 sachet kopi instant
1. Harap siapkan 100 gr tepung protein rendah




<!--inarticleads2-->

##### Cara membuat  Mexican Bun (roti boy, roti o):

1. Adonan tangzhong: campur tepung dan air, pastikan tidak ada yg bergerindil. masak di atas api kecil. aduk-aduk sampai menjadi adonan yang kental (seperti isian kue sus). dinginkan.
1. Campur tepung, gula, ragi, telur, susu aduk sampai kalis. tambahkan butter cair, aduk sampai kalis elastis.
1. Istirahatkan sampai mengembang 2 kali lipat. kempiskan.
1. Ambil adonan, sekitar 40gr, isi dengan salted butter dingin, bentuk bulatan. istirahatkan kembali 20 menitan.
1. Kocok/mixer semua bahan topping kopi, kecuali tepung. aduk sampai rata, terakhir masukan tepung. aduk, adonan topping akan sedikit kental seperti pasta gigi, kalo masih encer jangan ragu tambahkan tepung. masukan kedalam plastik segitiga.
1. Beri topping diatas adonan roti yang siap di panggang dengan bentuk melingkar seperti obat nyamuk.
1. Panggang disuhu 200 derajat celcius selama 15-20 menit. sajikan hangat.




Demikianlah cara membuat mexican bun (roti boy, roti o) yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
