---
description: "Resep : Coffe Bun a.k.a Mexican Bun [adonan simpan lemari pendingin] Teruji"
title: "Resep : Coffe Bun a.k.a Mexican Bun [adonan simpan lemari pendingin] Teruji"
slug: 269-resep-coffe-bun-aka-mexican-bun-adonan-simpan-lemari-pendingin-teruji
date: 2020-11-24T05:37:07.042Z
image: https://img-global.cpcdn.com/recipes/26d4bacde493b7a8/680x482cq70/coffe-bun-aka-mexican-bun-adonan-simpan-lemari-pendingin-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/26d4bacde493b7a8/680x482cq70/coffe-bun-aka-mexican-bun-adonan-simpan-lemari-pendingin-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/26d4bacde493b7a8/680x482cq70/coffe-bun-aka-mexican-bun-adonan-simpan-lemari-pendingin-foto-resep-utama.jpg
author: Aaron Ryan
ratingvalue: 4.5
reviewcount: 3997
recipeingredient:
- " Bahan A "
- "300 gr tepung terigu protein tinggi"
- "50 gr gula pasir"
- "7 gr ragi instan"
- "100 gr susu cair"
- "100 gr whipping cream cairsusu cair"
- " Bahan B "
- "65 gr butter"
- "1/2 sdt garam"
- " Bahan Isian "
- "kotak Butter margarine dinginkan lalu dipotong"
- " Bahan Topping "
- "70 gr butter"
- "35 gr gula halus"
- "1 butir telur"
- "70 gr tepung terigu"
- "1 sachet kopi instan larutkan dg 2 sdm air panas"
recipeinstructions:
- "Campur semua bahan A jadi satu lalu uleni/mixer hingga 1/2 kalis (gunakan kecepatan paling rendah)."
- "Setelah 1/2 kalis masukan butter dan garam, lanjut uleni/mixer hingga kalis (gunakan kecepatan paling tinggi)."
- "Setelah kalis tutup dough proofing hingga double size selama -/+ 45mnt."
- "Setelah double size kempiskan dough lalu bagi² adonan @60gr bulatkan lalu tutup istirahatkan kembali selama 15 menit."
- "Selagi menunggu, kita buat toppingnya dulu. Campur butter dan gula halus aduk rata menggunakan whisk."
- "Lalu tambahkan telur dan kopi, aduk rata kembali."
- "Terakhir masukan tepung terigu, aduk rata. Tuang adonan topping kedalam plastik segitiga. Sisihkan. (Saya pakai plastik biasa)."
- "Ambil 1 bulatan dough, pipihkan dengan rolling pin."
- "Lalu beri isian butter/margarine beku, bulatkan kembali. Lakukan sampai semua dough habis."
- "Tata pada loyang yg sudah dioles dg margarin sebelumnya. Tutup dan proofing hingga double size."
- "Setelah double size semprotkan topping sampai 3/4 bagian dough saja. (Roti saya ada yg kehabisan topping, jd gundulan)."
- "Panaskan otang selama 20 menit dg api sedang, kemudian panggang roti selama 25-30 menit dibagian rak tengah. Jika pakai oven listrik maka panggang dengan suhu 175 api atas bawah selama 25 menit. (Nah..pada tahap mau oven ini elpiji saya habis di hampir tengah malam. Akhirnya roti pada tahap diatas saya masukkan ke lemari pendingin. Besoknya roti saya keluarkan dari lemari es sambil nunggu oven panas, baru saya oven deh)."
- "Hasilnya dalam roti akan berongga seperti ini. Tekstur rotinya lembut dan rasanya cenderung asin 😘"
- "Nikmati selagi hangat ya 😉"
categories:
- Recipe
tags:
- coffe
- bun
- aka

katakunci: coffe bun aka 
nutrition: 296 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Dinner

---


![Coffe Bun a.k.a Mexican Bun [adonan simpan lemari pendingin]](https://img-global.cpcdn.com/recipes/26d4bacde493b7a8/680x482cq70/coffe-bun-aka-mexican-bun-adonan-simpan-lemari-pendingin-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan empuk. Karasteristik makanan Indonesia coffe bun a.k.a mexican bun [adonan simpan lemari pendingin] yang kaya dengan bumbu memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kedekatan keluarga dapat ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Coffe Bun a.k.a Mexican Bun [adonan simpan lemari pendingin] untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang bisa anda praktekkan salah satunya coffe bun a.k.a mexican bun [adonan simpan lemari pendingin] yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep coffe bun a.k.a mexican bun [adonan simpan lemari pendingin] tanpa harus bersusah payah.
Berikut ini resep Coffe Bun a.k.a Mexican Bun [adonan simpan lemari pendingin] yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 14 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Coffe Bun a.k.a Mexican Bun [adonan simpan lemari pendingin]:

1. Harap siapkan  Bahan A :
1. Harap siapkan 300 gr tepung terigu protein tinggi
1. Harap siapkan 50 gr gula pasir
1. Tambah 7 gr ragi instan
1. Tambah 100 gr susu cair
1. Siapkan 100 gr whipping cream cair/susu cair
1. Harap siapkan  Bahan B :
1. Jangan lupa 65 gr butter
1. Dibutuhkan 1/2 sdt garam
1. Diperlukan  Bahan Isian :
1. Tambah kotak Butter/ margarine, dinginkan lalu dipotong²
1. Jangan lupa  Bahan Topping :
1. Tambah 70 gr butter
1. Diperlukan 35 gr gula halus
1. Siapkan 1 butir telur
1. Tambah 70 gr tepung terigu
1. Diperlukan 1 sachet kopi instan, larutkan dg 2 sdm air panas




<!--inarticleads2-->

##### Langkah membuat  Coffe Bun a.k.a Mexican Bun [adonan simpan lemari pendingin]:

1. Campur semua bahan A jadi satu lalu uleni/mixer hingga 1/2 kalis (gunakan kecepatan paling rendah).
1. Setelah 1/2 kalis masukan butter dan garam, lanjut uleni/mixer hingga kalis (gunakan kecepatan paling tinggi).
1. Setelah kalis tutup dough proofing hingga double size selama -/+ 45mnt.
1. Setelah double size kempiskan dough lalu bagi² adonan @60gr bulatkan lalu tutup istirahatkan kembali selama 15 menit.
1. Selagi menunggu, kita buat toppingnya dulu. Campur butter dan gula halus aduk rata menggunakan whisk.
1. Lalu tambahkan telur dan kopi, aduk rata kembali.
1. Terakhir masukan tepung terigu, aduk rata. Tuang adonan topping kedalam plastik segitiga. Sisihkan. (Saya pakai plastik biasa).
1. Ambil 1 bulatan dough, pipihkan dengan rolling pin.
1. Lalu beri isian butter/margarine beku, bulatkan kembali. Lakukan sampai semua dough habis.
1. Tata pada loyang yg sudah dioles dg margarin sebelumnya. Tutup dan proofing hingga double size.
1. Setelah double size semprotkan topping sampai 3/4 bagian dough saja. (Roti saya ada yg kehabisan topping, jd gundulan).
1. Panaskan otang selama 20 menit dg api sedang, kemudian panggang roti selama 25-30 menit dibagian rak tengah. Jika pakai oven listrik maka panggang dengan suhu 175 api atas bawah selama 25 menit. (Nah..pada tahap mau oven ini elpiji saya habis di hampir tengah malam. Akhirnya roti pada tahap diatas saya masukkan ke lemari pendingin. Besoknya roti saya keluarkan dari lemari es sambil nunggu oven panas, baru saya oven deh).
1. Hasilnya dalam roti akan berongga seperti ini. Tekstur rotinya lembut dan rasanya cenderung asin 😘
1. Nikmati selagi hangat ya 😉




Demikianlah cara membuat coffe bun a.k.a mexican bun [adonan simpan lemari pendingin] yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan teruji, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
