---
description: "Langkah untuk membuat Mexican Coffee Bun / Roti Boy / Roti O Terbukti"
title: "Langkah untuk membuat Mexican Coffee Bun / Roti Boy / Roti O Terbukti"
slug: 341-langkah-untuk-membuat-mexican-coffee-bun-roti-boy-roti-o-terbukti
date: 2020-12-24T16:49:49.692Z
image: https://img-global.cpcdn.com/recipes/2b6fb580f8df40af/680x482cq70/mexican-coffee-bun-roti-boy-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2b6fb580f8df40af/680x482cq70/mexican-coffee-bun-roti-boy-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2b6fb580f8df40af/680x482cq70/mexican-coffee-bun-roti-boy-roti-o-foto-resep-utama.jpg
author: Chris Lopez
ratingvalue: 4.9
reviewcount: 9907
recipeingredient:
- "  Bahan A"
- "300 gram tepung terigu pro tinggi sy Cakra"
- "50 gram gula pasir"
- "6 gram ragi instan"
- "200 gram susu cair"
- "  Bahan B"
- "65 gram butter  margarin"
- "1/2 sdt garam"
- "  Bahan Topping"
- "70 gram butter"
- "50 gram gula halus"
- "1 btr putih telur"
- "1 bngkus kopi saset nescafe larutkan dengan 2 sdm air pnas"
- "70 gram tepung terigu"
- " Pasta mocca saya skip"
- "  Bahan isi"
- " Mentega  margarin beku"
recipeinstructions:
- "Campur semua bahan A, uleni setengah kalis. Masukkan bahan B. Uleni sampai kalis"
- "Tutup adonan, tunggu sampai mengembang 2x lipat +/- 45 menit"
- "Kempiskan adonan, bagi @60gr. Bulatkan. Istirahatkan lagi 15 menit (saya langsung di isi)"
- "Ambil 1 adonan. Pipihkan, isi dengan margarin. Bulatkan kembali. Profing hingga dobel size"
- "Selagi menunggu buat toping, campur butter dan gula halus. Aduk rata dengan wisk"
- "Tambahkan putih telur dan larutan kopi. Lalu tambahkan tepung terigu. Masukkan dalam piping bag. Sisihkan"
- "Setelah dobel size. Semprotkan toping,"
- "Panggang suhu 180°, +/- 25 menit. Sesuaikan oven masing-masing. Sajikan."
categories:
- Recipe
tags:
- mexican
- coffee
- bun

katakunci: mexican coffee bun 
nutrition: 288 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Dessert

---


![Mexican Coffee Bun / Roti Boy / Roti O](https://img-global.cpcdn.com/recipes/2b6fb580f8df40af/680x482cq70/mexican-coffee-bun-roti-boy-roti-o-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang setidaknya kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti mexican coffee bun / roti boy / roti o yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Nusantara



Kedekatan rumah tangga dapat ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Mexican Coffee Bun / Roti Boy / Roti O untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang bisa anda praktekkan salah satunya mexican coffee bun / roti boy / roti o yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep mexican coffee bun / roti boy / roti o tanpa harus bersusah payah.
Berikut ini resep Mexican Coffee Bun / Roti Boy / Roti O yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican Coffee Bun / Roti Boy / Roti O:

1. Harap siapkan  📌 Bahan A
1. Harus ada 300 gram tepung terigu pro tinggi (sy Cakra)
1. Dibutuhkan 50 gram gula pasir
1. Harap siapkan 6 gram ragi instan
1. Tambah 200 gram susu cair
1. Harus ada  📌 Bahan B
1. Harap siapkan 65 gram butter / margarin
1. Dibutuhkan 1/2 sdt garam
1. Tambah  📌 Bahan Topping
1. Harap siapkan 70 gram butter
1. Siapkan 50 gram gula halus
1. Diperlukan 1 btr putih telur
1. Harus ada 1 bngkus kopi saset (nescafe) larutkan dengan 2 sdm air pnas
1. Siapkan 70 gram tepung terigu
1. Tambah  Pasta mocca, saya skip
1. Siapkan  📌 Bahan isi
1. Harap siapkan  Mentega / margarin beku




<!--inarticleads2-->

##### Langkah membuat  Mexican Coffee Bun / Roti Boy / Roti O:

1. Campur semua bahan A, uleni setengah kalis. Masukkan bahan B. Uleni sampai kalis
1. Tutup adonan, tunggu sampai mengembang 2x lipat +/- 45 menit
1. Kempiskan adonan, bagi @60gr. Bulatkan. Istirahatkan lagi 15 menit (saya langsung di isi)
1. Ambil 1 adonan. Pipihkan, isi dengan margarin. Bulatkan kembali. Profing hingga dobel size
1. Selagi menunggu buat toping, campur butter dan gula halus. Aduk rata dengan wisk
1. Tambahkan putih telur dan larutan kopi. Lalu tambahkan tepung terigu. Masukkan dalam piping bag. Sisihkan
1. Setelah dobel size. Semprotkan toping,
1. Panggang suhu 180°, +/- 25 menit. Sesuaikan oven masing-masing. Sajikan.




Demikianlah cara membuat mexican coffee bun / roti boy / roti o yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan cepat, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
