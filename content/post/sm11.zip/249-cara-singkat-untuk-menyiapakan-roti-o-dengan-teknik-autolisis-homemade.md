---
description: "Cara singkat untuk menyiapakan Roti O dengan teknik autolisis Homemade"
title: "Cara singkat untuk menyiapakan Roti O dengan teknik autolisis Homemade"
slug: 249-cara-singkat-untuk-menyiapakan-roti-o-dengan-teknik-autolisis-homemade
date: 2020-12-28T19:08:26.384Z
image: https://img-global.cpcdn.com/recipes/b745d4b4542b2883/680x482cq70/roti-o-dengan-teknik-autolisis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b745d4b4542b2883/680x482cq70/roti-o-dengan-teknik-autolisis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b745d4b4542b2883/680x482cq70/roti-o-dengan-teknik-autolisis-foto-resep-utama.jpg
author: Marian Kelley
ratingvalue: 4.2
reviewcount: 10150
recipeingredient:
- "500 gr tepung cakra"
- "4 butir telur"
- "125 gr gula pasir"
- "250 ml air"
- "2 sdt fermipan"
- "50 gr margarin"
- "1 sachet susu dancow putih"
- " toping"
- "50 gr gula halus"
- "100 gr margarin"
- "50 gr tepung terigu"
- "1 sdm coffe capucino"
- "1 sdt essen moka"
- "1 butir putih telur"
recipeinstructions:
- "Tepung terigu dicampur dg 1 sachet dancow dan 3 butir kuning telur"
- "Larutkan gula dalam air"
- "Tuang gula dalam campuran tepung, aduk-aduk dan uleni bentar sampe kalis"
- "Tutup dg serbet, diamkan 2 jam"
- "Setelah 2 jam ditengok, lalu bagian2 pinggir dibawa ke tengah.Diamkan lg 1 jam"
- "Fermipan dicampur dg air 1 sdm, dg gula 1 sdt,diamkn 5 menit"
- "Adonan dibuka, agak dilebarkan, masukkan fermipan ditengah.Lipat-lipat biar tercampur"
- "Adonan dilebarkan lagi, masukkan 50 margarin di tengah, dicampur dengan dilipat-lipat"
- "Didiamkan 1 jam"
- "Bagi-bagi adonan 50 gr dibulatkan, diisi dg margarin, bisa juga ditambah keju"
- "Buat toping:gula, margarin dikocok, campur putih telur, coffe dan moka.Campurkan tepung"
- "Masukkan toping dalam plastik segitiga, gunting ujungnya.Semprotkan toping di atas adonan melingkar"
- "Oven selama 20 menit"
- "Sajikan panas-panas"
categories:
- Recipe
tags:
- roti
- o
- dengan

katakunci: roti o dengan 
nutrition: 253 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dessert

---


![Roti O dengan teknik autolisis](https://img-global.cpcdn.com/recipes/b745d4b4542b2883/680x482cq70/roti-o-dengan-teknik-autolisis-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga empuk. Ciri khas kuliner Nusantara roti o dengan teknik autolisis yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga dapat diperoleh dengan cara simple. Diantaranya adalah membuat makanan Roti O dengan teknik autolisis untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang dapat anda contoh salah satunya roti o dengan teknik autolisis yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep roti o dengan teknik autolisis tanpa harus bersusah payah.
Seperti resep Roti O dengan teknik autolisis yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 14 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti O dengan teknik autolisis:

1. Jangan lupa 500 gr tepung cakra
1. Siapkan 4 butir telur
1. Jangan lupa 125 gr gula pasir
1. Dibutuhkan 250 ml air
1. Jangan lupa 2 sdt fermipan
1. Siapkan 50 gr margarin
1. Dibutuhkan 1 sachet susu dancow putih
1. Dibutuhkan  toping:
1. Jangan lupa 50 gr gula halus
1. Harap siapkan 100 gr margarin
1. Diperlukan 50 gr tepung terigu
1. Jangan lupa 1 sdm coffe capucino
1. Dibutuhkan 1 sdt essen moka
1. Diperlukan 1 butir putih telur




<!--inarticleads2-->

##### Instruksi membuat  Roti O dengan teknik autolisis:

1. Tepung terigu dicampur dg 1 sachet dancow dan 3 butir kuning telur
1. Larutkan gula dalam air
1. Tuang gula dalam campuran tepung, aduk-aduk dan uleni bentar sampe kalis
1. Tutup dg serbet, diamkan 2 jam
1. Setelah 2 jam ditengok, lalu bagian2 pinggir dibawa ke tengah.Diamkan lg 1 jam
1. Fermipan dicampur dg air 1 sdm, dg gula 1 sdt,diamkn 5 menit
1. Adonan dibuka, agak dilebarkan, masukkan fermipan ditengah.Lipat-lipat biar tercampur
1. Adonan dilebarkan lagi, masukkan 50 margarin di tengah, dicampur dengan dilipat-lipat
1. Didiamkan 1 jam
1. Bagi-bagi adonan 50 gr dibulatkan, diisi dg margarin, bisa juga ditambah keju
1. Buat toping:gula, margarin dikocok, campur putih telur, coffe dan moka.Campurkan tepung
1. Masukkan toping dalam plastik segitiga, gunting ujungnya.Semprotkan toping di atas adonan melingkar
1. Oven selama 20 menit
1. Sajikan panas-panas




Demikianlah cara membuat roti o dengan teknik autolisis yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan terbukti, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
