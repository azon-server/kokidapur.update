---
description: "Steps untuk menyiapakan Mexican Bun (Roti Boy) Terbukti"
title: "Steps untuk menyiapakan Mexican Bun (Roti Boy) Terbukti"
slug: 302-steps-untuk-menyiapakan-mexican-bun-roti-boy-terbukti
date: 2020-09-13T05:31:07.846Z
image: https://img-global.cpcdn.com/recipes/33f0364016f08920/680x482cq70/mexican-bun-roti-boy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/33f0364016f08920/680x482cq70/mexican-bun-roti-boy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/33f0364016f08920/680x482cq70/mexican-bun-roti-boy-foto-resep-utama.jpg
author: Alma Ramsey
ratingvalue: 4.7
reviewcount: 14689
recipeingredient:
- " Bahan Biang"
- "1 sdm ragi instan"
- "2 sdm gula pasir"
- "1 sachet susu kental manis"
- "75 ml air hangat kuku"
- " Bahan Roti"
- "250 gr terigu cakra"
- "3 sdm margarin"
- "3 sdm gula pasir"
- "1/2 sdt garam"
- "1 butir telur"
- " Bahan Isi"
- "50 gr keju cheddar parut"
- "3 sdm margarin"
- " Bahan Topping"
- "1 butir telur"
- "3 sdm gula pasir"
- "3 sdm margarin"
- "6 sdm terigu serbaguna"
- "1 sachet nescafe original"
- "1 tetes pasta rasa mocca"
recipeinstructions:
- "Siapkan semua bahan"
- "Buat biang dengan campuran susu kental manis, gula, air hangat, aduk rata, tambahkan ragi instan dan aduk, diamkan 10 menit hingga berbuih"
- "Buar roti dengan mencampurkan semua bahan sampai berbulir2 kemudian masukkan bahan biang sesikit demi sedikit, uleni hingga kalis dan diamkan selama 1 jam dengan ditutup serbet lembab"
- "Buat isian dengan mencampurkan keju parut dan margarin dalam mangkok sampai rata"
- "Buat topping, campurkan semua bahan, mixer sampai lembut masukkan dalam piping bag dan simpan dalam kulkas"
- "Kempeskan adonan, bagi menjadi 9 bagian, bentuk bulat2, istirahatkan lagi 10 menit"
- "Isi masing2 dengan isian, istirahatkan lagi 30 menit"
- "Semprotkan topping melingkar dari tengah terlebih dahulu menyerupai motif obat nyamuk bakar sampai 2/3 bagian saja karena topping nanti akan lumer sendiri ke bawah ketika di oven"
- "Oven selama 30 menit, sebelumnya pastikan oven sudah panas. Saya menggunakan oven tangkring dengan api sedang."
- "Tunggu sampai kecoklatan dan angkat."
- ""
- "Tekstur dalamnya"
categories:
- Recipe
tags:
- mexican
- bun
- roti

katakunci: mexican bun roti 
nutrition: 232 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dessert

---


![Mexican Bun (Roti Boy)](https://img-global.cpcdn.com/recipes/33f0364016f08920/680x482cq70/mexican-bun-roti-boy-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau enak. Karasteristik masakan Indonesia mexican bun (roti boy) yang penuh dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah memasak Mexican Bun (Roti Boy) untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang bisa anda coba salah satunya mexican bun (roti boy) yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep mexican bun (roti boy) tanpa harus bersusah payah.
Berikut ini resep Mexican Bun (Roti Boy) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 12 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Mexican Bun (Roti Boy):

1. Harus ada  Bahan Biang:
1. Diperlukan 1 sdm ragi instan
1. Harap siapkan 2 sdm gula pasir
1. Harap siapkan 1 sachet susu kental manis
1. Dibutuhkan 75 ml air hangat kuku
1. Harap siapkan  Bahan Roti:
1. Tambah 250 gr terigu cakra
1. Harus ada 3 sdm margarin
1. Siapkan 3 sdm gula pasir
1. Harap siapkan 1/2 sdt garam
1. Tambah 1 butir telur
1. Tambah  Bahan Isi:
1. Diperlukan 50 gr keju cheddar parut
1. Tambah 3 sdm margarin
1. Dibutuhkan  Bahan Topping:
1. Harap siapkan 1 butir telur
1. Tambah 3 sdm gula pasir
1. Diperlukan 3 sdm margarin
1. Harap siapkan 6 sdm terigu serbaguna
1. Diperlukan 1 sachet nescafe original
1. Jangan lupa 1 tetes pasta rasa mocca




<!--inarticleads2-->

##### Bagaimana membuat  Mexican Bun (Roti Boy):

1. Siapkan semua bahan
1. Buat biang dengan campuran susu kental manis, gula, air hangat, aduk rata, tambahkan ragi instan dan aduk, diamkan 10 menit hingga berbuih
1. Buar roti dengan mencampurkan semua bahan sampai berbulir2 kemudian masukkan bahan biang sesikit demi sedikit, uleni hingga kalis dan diamkan selama 1 jam dengan ditutup serbet lembab
1. Buat isian dengan mencampurkan keju parut dan margarin dalam mangkok sampai rata
1. Buat topping, campurkan semua bahan, mixer sampai lembut masukkan dalam piping bag dan simpan dalam kulkas
1. Kempeskan adonan, bagi menjadi 9 bagian, bentuk bulat2, istirahatkan lagi 10 menit
1. Isi masing2 dengan isian, istirahatkan lagi 30 menit
1. Semprotkan topping melingkar dari tengah terlebih dahulu menyerupai motif obat nyamuk bakar sampai 2/3 bagian saja karena topping nanti akan lumer sendiri ke bawah ketika di oven
1. Oven selama 30 menit, sebelumnya pastikan oven sudah panas. Saya menggunakan oven tangkring dengan api sedang.
1. Tunggu sampai kecoklatan dan angkat.
1. 
1. Tekstur dalamnya




Demikianlah cara membuat mexican bun (roti boy) yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
