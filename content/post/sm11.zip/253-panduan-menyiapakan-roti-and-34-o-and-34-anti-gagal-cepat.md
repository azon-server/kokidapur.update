---
description: "Panduan menyiapakan Roti &amp;#34;O&amp;#34; anti gagal Cepat"
title: "Panduan menyiapakan Roti &amp;#34;O&amp;#34; anti gagal Cepat"
slug: 253-panduan-menyiapakan-roti-and-34-o-and-34-anti-gagal-cepat
date: 2020-12-13T17:04:24.424Z
image: https://img-global.cpcdn.com/recipes/452d756bac92e4c7/680x482cq70/roti-o-anti-gagal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/452d756bac92e4c7/680x482cq70/roti-o-anti-gagal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/452d756bac92e4c7/680x482cq70/roti-o-anti-gagal-foto-resep-utama.jpg
author: Zachary Leonard
ratingvalue: 4.3
reviewcount: 13821
recipeingredient:
- "600 gr tepung terigu"
- "2 sdt fernifan"
- "4 sdm gula"
- "1 saset susu bubuk dancow8"
- "270 ml air es"
- "10 ml air hangat kuku"
- "60 gr butter"
- "1 Telur"
- "  isian"
- "Secukupnya mentega"
- " toping"
- "100 gr mentega"
- "100 gr tepung terigu"
- "100 gr gula"
- "1 telur"
- "1 saset white koffe"
- "1 sdt kopi"
- "15 ml air panas"
recipeinstructions:
- "Larutkan fernifan dengan air hangat kuku,(sampai mengembang) sementara menuggu mengembang campur tepung terigu, susu, gula,telur aduk rata dan tambah sedikit demi sedikit air dingin beserta fernifan aduk dengan tangan hingga kalis."
- "Diamkan adonan -+45 menit hingga mengembang 2x lipat.tutup dengan saputangan bersih"
- "Setelah mengembang kempeskan adonan dan bagi menjadi bulatan-bulata seberat 50 gr. Dan isi bulatan dengan secupnya butter. Dan diamkan selama -+45 menit diatas loyang yg sudah di olesi mentega dg di tutupi serbet bersih."
- "Sambil menunggu adonan mengembang selanjutnya membuat toping dg me mixer gula dan butter hingga warna pucat dan aduk dg spatula + telur dan seduhan white koffe dan kopi.. aduk hingga rata (tes rasa bisa di tambah kopi jika kurang)"
- "Masukkan adonan toping ke plasting segitiga atau bisa plastik biasa dg di gunting lelebihan plastik yg ada di bawah jilitan. Ikat dan buat lubang pada plasti,selanjutnya bentuk toping di atas adona berbentuk seperti obat nyamuk."
- "Panaskan ovenan dan oven -+20 menit / warna roti sudah agak menguning.."
categories:
- Recipe
tags:
- roti
- o
- anti

katakunci: roti o anti 
nutrition: 178 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Dinner

---


![Roti &#34;O&#34; anti gagal](https://img-global.cpcdn.com/recipes/452d756bac92e4c7/680x482cq70/roti-o-anti-gagal-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga gurih. Ciri khas kuliner Nusantara roti &#34;o&#34; anti gagal yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah memasak Roti &#34;O&#34; anti gagal untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang dapat anda coba salah satunya roti &#34;o&#34; anti gagal yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep roti &#34;o&#34; anti gagal tanpa harus bersusah payah.
Seperti resep Roti &#34;O&#34; anti gagal yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti &#34;O&#34; anti gagal:

1. Tambah 600 gr tepung terigu
1. Dibutuhkan 2 sdt fernifan
1. Tambah 4 sdm gula
1. Siapkan 1 saset susu bubuk dancow8
1. Siapkan 270 ml air es
1. Siapkan 10 ml air hangat kuku
1. Harap siapkan 60 gr butter
1. Harus ada 1 Telur
1. Dibutuhkan  ➡ isian
1. Tambah Secukupnya mentega
1. Jangan lupa  ➡toping
1. Diperlukan 100 gr mentega
1. Dibutuhkan 100 gr tepung terigu
1. Harus ada 100 gr gula
1. Harus ada 1 telur
1. Dibutuhkan 1 saset white koffe
1. Tambah 1 sdt kopi
1. Dibutuhkan 15 ml air panas




<!--inarticleads2-->

##### Bagaimana membuat  Roti &#34;O&#34; anti gagal:

1. Larutkan fernifan dengan air hangat kuku,(sampai mengembang) sementara menuggu mengembang campur tepung terigu, susu, gula,telur aduk rata dan tambah sedikit demi sedikit air dingin beserta fernifan aduk dengan tangan hingga kalis.
1. Diamkan adonan -+45 menit hingga mengembang 2x lipat.tutup dengan saputangan bersih
1. Setelah mengembang kempeskan adonan dan bagi menjadi bulatan-bulata seberat 50 gr. Dan isi bulatan dengan secupnya butter. Dan diamkan selama -+45 menit diatas loyang yg sudah di olesi mentega dg di tutupi serbet bersih.
1. Sambil menunggu adonan mengembang selanjutnya membuat toping dg me mixer gula dan butter hingga warna pucat dan aduk dg spatula + telur dan seduhan white koffe dan kopi.. aduk hingga rata (tes rasa bisa di tambah kopi jika kurang)
1. Masukkan adonan toping ke plasting segitiga atau bisa plastik biasa dg di gunting lelebihan plastik yg ada di bawah jilitan. Ikat dan buat lubang pada plasti,selanjutnya bentuk toping di atas adona berbentuk seperti obat nyamuk.
1. Panaskan ovenan dan oven -+20 menit / warna roti sudah agak menguning..




Demikianlah cara membuat roti &#34;o&#34; anti gagal yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan cepat, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
