---
description: "Cara singkat untuk menyiapakan Mexican Bun versi overnight anti gagal Cepat"
title: "Cara singkat untuk menyiapakan Mexican Bun versi overnight anti gagal Cepat"
slug: 307-cara-singkat-untuk-menyiapakan-mexican-bun-versi-overnight-anti-gagal-cepat
date: 2021-01-07T00:07:40.108Z
image: https://img-global.cpcdn.com/recipes/5b43fffd8b22711a/680x482cq70/mexican-bun-versi-overnight-anti-gagal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5b43fffd8b22711a/680x482cq70/mexican-bun-versi-overnight-anti-gagal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5b43fffd8b22711a/680x482cq70/mexican-bun-versi-overnight-anti-gagal-foto-resep-utama.jpg
author: Marguerite Fleming
ratingvalue: 4.3
reviewcount: 31078
recipeingredient:
- " bahan A "
- "200-215 terigu protein tinggi"
- "125 ml susu cair dingin"
- "2 sdt ragi instant me fermipan"
- " bahan B "
- " Adonan bahan A yg sudah minimal 12 jam di kulkas"
- "90 gr terigu protein tinggi"
- "1 butir telur"
- "2 sdt ragi instant"
- "1 sdt garam"
- "4 sdm gula pasir"
- "45 gr butter suhu ruang"
- "1 sdm susu cair dingin"
- " topping "
- "50 gr butter"
- "2 sdm gula halus"
- "50 gr terigu serbaguna"
- "1/4 sdt baking powder"
- "1 butir putih telur"
- "1-2 sdt kopi instant seduh dng 1 sdm air panas"
- "Secukupnya pasta moka jika suka"
- " filling campur dan aduk jadi satu "
- "75 gr butter"
- "75 gr keju parut"
recipeinstructions:
- "Campur bahan A jadi satu, uleni dengan tangan hingga setengah kalis"
- "Tutup dengan plastik, simpan didalam kulkas minimal 12 jam"
- "Setelah 12 jam, sobek2 adonan A, sisihkan, dalam 1 wadah campur seluruh bahan B kecuali butter, lalu tuang sobekan bahan A, uleni sampai tidak lengket, masukkan butter, uleni hingga kalis elastis, saya gunakan mixer, 15 menitan sudah kalis elastis"
- "Ciri2 adonan kalis elastis adalah, bila adonan dibentangkan, dia tidak akan sobek"
- "Bulatkan adonan, lalu isirahatkan kurang lebih 1-2 jam tergantung suhu ruangan, hingga mengembang 2 kali lipat, tutup dengan plastik atau serbet bersih"
- "Sementara menunggu roti di proofing, kita bikin isiannya dulu, campur seluruh bahan isian jadi satu, aduk rata, banyaknya isian suka2 yaa, kalo mau banyakan boleh ditambah, perbandingannya 1:1"
- "Setelah mix, bentuk bulatan sesuai jumlah roti, kalo mau mirip roti boy biasanya jadi 10-12 bagian, kalo mau buat 14-20 silahkan saja, masukkan filling ke dalam kulkas agar sedikit membeku, jadi mudah untuk mengisinya nanti"
- "Ini setelah mengembang, lalu bagi menjadi beberapa bagian (saya timbang @50gr, dapet 12 bagian)"
- "Pipihkan adonan, isi dengan filling, bulatkan kembali, tata diatas loyang bersemir margarin, biarkan lagi sekitar 25 menitan"
- "Sementara menunggu, kita buat toppingnya, kocok putih telur hingga kaku"
- "Sementara di wadah lain, aduk butter dan gula halus hingga menyatu, lalu tuang seduhan kopi, baking powder, pasta moka, dan putih telur tadi, aduk rata"
- "Masukkan adonan kedalam pipping bag, gunting ujungnya, semprotkan keatas adonan roti melingkar seperti obat nyamuk, ini saya lubangnya kegedean, jadi agak bleber"
- "Panggang di oven yang sudah dipanaskan sebelumnya, di suhu 180° selama kurang lebih 15-20 menitan"
- "Angkat, sajikan hangat enak banget😍"
- "Empuuuuuuk pake bingits😍"
categories:
- Recipe
tags:
- mexican
- bun
- versi

katakunci: mexican bun versi 
nutrition: 112 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Dessert

---


![Mexican Bun versi overnight anti gagal](https://img-global.cpcdn.com/recipes/5b43fffd8b22711a/680x482cq70/mexican-bun-versi-overnight-anti-gagal-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti mexican bun versi overnight anti gagal yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan ciri khas yang merupakan keragaman Kita

Kedekatan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah memasak Mexican Bun versi overnight anti gagal untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang bisa anda contoh salah satunya mexican bun versi overnight anti gagal yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep mexican bun versi overnight anti gagal tanpa harus bersusah payah.
Seperti resep Mexican Bun versi overnight anti gagal yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 24 bahan dan 15 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican Bun versi overnight anti gagal:

1. Harap siapkan  🍞bahan A :
1. Dibutuhkan 200-215 terigu protein tinggi
1. Jangan lupa 125 ml susu cair dingin
1. Diperlukan 2 sdt ragi instant (me, fermipan)
1. Tambah  🍞bahan B :
1. Dibutuhkan  Adonan bahan A yg sudah minimal 12 jam di kulkas
1. Harap siapkan 90 gr terigu protein tinggi
1. Diperlukan 1 butir telur
1. Dibutuhkan 2 sdt ragi instant
1. Harus ada 1 sdt garam
1. Jangan lupa 4 sdm gula pasir
1. Jangan lupa 45 gr butter suhu ruang
1. Jangan lupa 1 sdm susu cair dingin
1. Harap siapkan  🍞topping :
1. Harap siapkan 50 gr butter
1. Tambah 2 sdm gula halus
1. Harap siapkan 50 gr terigu serbaguna
1. Harap siapkan 1/4 sdt baking powder
1. Tambah 1 butir putih telur
1. Jangan lupa 1-2 sdt kopi instant, seduh dng 1 sdm air panas
1. Siapkan Secukupnya pasta moka (jika suka)
1. Jangan lupa  🍞filling, campur dan aduk jadi satu :
1. Harap siapkan 75 gr butter
1. Harap siapkan 75 gr keju parut




<!--inarticleads2-->

##### Cara membuat  Mexican Bun versi overnight anti gagal:

1. Campur bahan A jadi satu, uleni dengan tangan hingga setengah kalis
1. Tutup dengan plastik, simpan didalam kulkas minimal 12 jam
1. Setelah 12 jam, sobek2 adonan A, sisihkan, dalam 1 wadah campur seluruh bahan B kecuali butter, lalu tuang sobekan bahan A, uleni sampai tidak lengket, masukkan butter, uleni hingga kalis elastis, saya gunakan mixer, 15 menitan sudah kalis elastis
1. Ciri2 adonan kalis elastis adalah, bila adonan dibentangkan, dia tidak akan sobek
1. Bulatkan adonan, lalu isirahatkan kurang lebih 1-2 jam tergantung suhu ruangan, hingga mengembang 2 kali lipat, tutup dengan plastik atau serbet bersih
1. Sementara menunggu roti di proofing, kita bikin isiannya dulu, campur seluruh bahan isian jadi satu, aduk rata, banyaknya isian suka2 yaa, kalo mau banyakan boleh ditambah, perbandingannya 1:1
1. Setelah mix, bentuk bulatan sesuai jumlah roti, kalo mau mirip roti boy biasanya jadi 10-12 bagian, kalo mau buat 14-20 silahkan saja, masukkan filling ke dalam kulkas agar sedikit membeku, jadi mudah untuk mengisinya nanti
1. Ini setelah mengembang, lalu bagi menjadi beberapa bagian (saya timbang @50gr, dapet 12 bagian)
1. Pipihkan adonan, isi dengan filling, bulatkan kembali, tata diatas loyang bersemir margarin, biarkan lagi sekitar 25 menitan
1. Sementara menunggu, kita buat toppingnya, kocok putih telur hingga kaku
1. Sementara di wadah lain, aduk butter dan gula halus hingga menyatu, lalu tuang seduhan kopi, baking powder, pasta moka, dan putih telur tadi, aduk rata
1. Masukkan adonan kedalam pipping bag, gunting ujungnya, semprotkan keatas adonan roti melingkar seperti obat nyamuk, ini saya lubangnya kegedean, jadi agak bleber
1. Panggang di oven yang sudah dipanaskan sebelumnya, di suhu 180° selama kurang lebih 15-20 menitan
1. Angkat, sajikan hangat enak banget😍
1. Empuuuuuuk pake bingits😍




Demikianlah cara membuat mexican bun versi overnight anti gagal yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
