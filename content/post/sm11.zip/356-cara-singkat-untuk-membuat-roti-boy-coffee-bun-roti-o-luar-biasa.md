---
description: "Cara singkat untuk membuat Roti Boy / coffee Bun / roti O Luar biasa"
title: "Cara singkat untuk membuat Roti Boy / coffee Bun / roti O Luar biasa"
slug: 356-cara-singkat-untuk-membuat-roti-boy-coffee-bun-roti-o-luar-biasa
date: 2021-01-14T05:28:50.821Z
image: https://img-global.cpcdn.com/recipes/7a9f9a909b08d6cd/680x482cq70/roti-boy-coffee-bun-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7a9f9a909b08d6cd/680x482cq70/roti-boy-coffee-bun-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7a9f9a909b08d6cd/680x482cq70/roti-boy-coffee-bun-roti-o-foto-resep-utama.jpg
author: Wesley Barnett
ratingvalue: 4.3
reviewcount: 18796
recipeingredient:
- " Bahan Biang"
- "125 ml susu UHT dingin"
- "215 gr tepung terigu protein tinggi"
- "1 sdt ragi instan"
- " Adonan Roti"
- " Bahan biang yang sudah didiamkan 12 jam"
- "90 gr tepung terigu protein tinggi"
- "1/4 sdt bubuk vanila LArome"
- "30 gr telur  1 btr yg super mungil"
- "2 sdt ragi instan"
- "1/2 sdt garam"
- "4 sdm gulpas"
- "1 sdm UHT dingin"
- "45 gr butter"
- " Topping"
- "1 btr putih telur"
- "50 gr butter"
- "3 sdm gula halus"
- "50 gr tepung terigu protein sedang"
- "1/2 sdt baking powder"
- "1 1/2 sdt kopi instan me  INDcafe 1 sdm air panas"
- " Filingisi"
- "sesuai selera Selai coklat keju"
recipeinstructions:
- "Campur semua bahan biang. Uleni sampai tercampur rata. Tutup dgn plastik, simpan di lemari es minimal selama 12 jam"
- "Setelah 12 jam, sobek2 adonan, campur dgn bahan adonan lainnya kecuali butter. Uleni sampai tercampur rata. Tambahkan butter, uleni dgn mixer spiral hingga Kalis dan elastis. Diamkan 1-2 jam (fermentasi)."
- "Setelah fermentasi, kempiskan adonan, lalu timbang @50gr..."
- "Pipihkan adonan, beri isian, tutup kembali dan bulatkan. Tata di loyang yg sudah dioles mentega tipis-tipis. (Beri jarak agak jauh y...!!) Diamkan lagi 25-30 menit"
- "Sambil menunggu, kocok putih telur sampai kaku, sisihkan. Dgn wadah lainnya kocok butter &amp; tulis smp lembut, masukan tepung terigu &amp; BP, tambahkan putih telur tadi dan kopi yg sudah dicairkan. Masukan ke dalam piping bag."
- "Panaskan oven 180 DC. Semprotkan adonan. Topping secara melingkar seperti obat nyamuk di atas roti (usahakan rapat y) lalu panggang selama 15-20 menit"
categories:
- Recipe
tags:
- roti
- boy
- 

katakunci: roti boy  
nutrition: 132 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT30M"
recipeyield: "3"
recipecategory: Dessert

---


![Roti Boy / coffee Bun / roti O](https://img-global.cpcdn.com/recipes/7a9f9a909b08d6cd/680x482cq70/roti-boy-coffee-bun-roti-o-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas atau empuk. Ciri khas kuliner Nusantara roti boy / coffee bun / roti o yang kaya dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kehangatan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Roti Boy / coffee Bun / roti O untuk orang di rumah. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang bisa anda coba salah satunya roti boy / coffee bun / roti o yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep roti boy / coffee bun / roti o tanpa harus bersusah payah.
Berikut ini resep Roti Boy / coffee Bun / roti O yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 23 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Boy / coffee Bun / roti O:

1. Jangan lupa  Bahan Biang
1. Dibutuhkan 125 ml susu UHT dingin
1. Dibutuhkan 215 gr tepung terigu protein tinggi
1. Dibutuhkan 1 sdt ragi instan
1. Dibutuhkan  Adonan Roti
1. Jangan lupa  Bahan biang yang sudah didiamkan 12 jam
1. Jangan lupa 90 gr tepung terigu protein tinggi
1. Dibutuhkan 1/4 sdt bubuk vanila L&#39;Arome
1. Siapkan 30 gr telur / 1 btr yg super mungil
1. Siapkan 2 sdt ragi instan
1. Harus ada 1/2 sdt garam
1. Siapkan 4 sdm gulpas
1. Diperlukan 1 sdm UHT dingin
1. Tambah 45 gr butter
1. Jangan lupa  Topping
1. Siapkan 1 btr putih telur
1. Dibutuhkan 50 gr butter
1. Jangan lupa 3 sdm gula halus
1. Harap siapkan 50 gr tepung terigu protein sedang
1. Siapkan 1/2 sdt baking powder
1. Dibutuhkan 1 1/2 sdt kopi instan (me : IND*cafe)+ 1 sdm air panas
1. Jangan lupa  Filing/isi
1. Siapkan sesuai selera Selai coklat, keju,




<!--inarticleads2-->

##### Bagaimana membuat  Roti Boy / coffee Bun / roti O:

1. Campur semua bahan biang. Uleni sampai tercampur rata. Tutup dgn plastik, simpan di lemari es minimal selama 12 jam
1. Setelah 12 jam, sobek2 adonan, campur dgn bahan adonan lainnya kecuali butter. Uleni sampai tercampur rata. Tambahkan butter, uleni dgn mixer spiral hingga Kalis dan elastis. Diamkan 1-2 jam (fermentasi).
1. Setelah fermentasi, kempiskan adonan, lalu timbang @50gr...
1. Pipihkan adonan, beri isian, tutup kembali dan bulatkan. Tata di loyang yg sudah dioles mentega tipis-tipis. (Beri jarak agak jauh y...!!) Diamkan lagi 25-30 menit
1. Sambil menunggu, kocok putih telur sampai kaku, sisihkan. Dgn wadah lainnya kocok butter &amp; tulis smp lembut, masukan tepung terigu &amp; BP, tambahkan putih telur tadi dan kopi yg sudah dicairkan. Masukan ke dalam piping bag.
1. Panaskan oven 180 DC. Semprotkan adonan. Topping secara melingkar seperti obat nyamuk di atas roti (usahakan rapat y) lalu panggang selama 15-20 menit




Demikianlah cara membuat roti boy / coffee bun / roti o yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
