---
description: "Resep : Mexico bun / Roti O minggu ini"
title: "Resep : Mexico bun / Roti O minggu ini"
slug: 328-resep-mexico-bun-roti-o-minggu-ini
date: 2020-11-26T21:18:52.231Z
image: https://img-global.cpcdn.com/recipes/20f56db1cd76ec2a/680x482cq70/mexico-bun-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/20f56db1cd76ec2a/680x482cq70/mexico-bun-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/20f56db1cd76ec2a/680x482cq70/mexico-bun-roti-o-foto-resep-utama.jpg
author: Jerome Walker
ratingvalue: 4.6
reviewcount: 19749
recipeingredient:
- " Kulit"
- "300 gr tepung cakra"
- "60 gr gula pasir"
- "1/2 sachet fermipan"
- "2 kuning telur"
- "150 ml air hangat"
- "40 gr margarin"
- "1/2 sdt garam"
- "1 sachet susu dancow"
- " Isi"
- "150 gr margarin"
- "1 sdm gula halus"
- " Topping"
- "80 gr butter"
- "70 gr gula halus"
- "1 telur ukuran besar dikocok"
- "1 sdm kopi instan me luwak white coffee"
- "1 sdm air hangat"
- "70 gr terigu"
- "1 sdt pasta mocca"
recipeinstructions:
- "Buat biang dulu, ambil air dan gula dari resep kulit ambil setengah, campur dgn fermipan, aduk dan biarkan berbusa"
- "Kocok kuning telur dan sisa gula aduk sampai larut, masukkan terigu, susu bubuk dan bahan biang tadi, aduk rata"
- "Masukkan margarin, uleni sampai kalis atau adonan elastis dan tidak lengket ditangan"
- "Tutup adonan dgn plastik/kain serbet bersih selama 30 menit"
- "Setelah mengembang kempiskan, potong2 adonan/timbang 40 gr jadi 15 biji, bulat2kan, pipihkan, isi dengan isian margarin dan gula halus yg telah dicampur pakai sendok teh"
- "Tata pada loyang yg dialas kertas roti beri jarak agak lebar karena rotinya mengembang bgt. Diamkan 1 jam"
- "Sambil nunggu 1 jam, buat topping, campur semua bahan toping. Aduk rata, masukkan pada plastik segitiga/piping, sisihkan"
- "Panaskan oven. Setelah adonan mengembang semprot atasnya dgn toping dgn gerak melingkar"
- "Oven 30 menit pada sushu 200° sampai permukaan atas kering"
- "Siap disajikan"
categories:
- Recipe
tags:
- mexico
- bun
- 

katakunci: mexico bun  
nutrition: 131 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Lunch

---


![Mexico bun / Roti O](https://img-global.cpcdn.com/recipes/20f56db1cd76ec2a/680x482cq70/mexico-bun-roti-o-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan enak. Ciri makanan Indonesia mexico bun / roti o yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah memasak Mexico bun / Roti O untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

Mexican Coffee Bun (Rotiboy) - Sweet bun with coffee topping and butter filling. The word &#34;Mexican&#34; might be misleading but this bun originated from a bakery in Bukit Mertajam, Penang, and now Mexican coffee bun is famous all over Asia, with many bakeries and copycat bakeries selling this. G. these buns are SO delicious you&#39;ve got to try them! These fluffy, buttery buns are topped with a coffee scented cookie crust, and they became wildly.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda buat salah satunya mexico bun / roti o yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep mexico bun / roti o tanpa harus bersusah payah.
Berikut ini resep Mexico bun / Roti O yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 20 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexico bun / Roti O:

1. Jangan lupa  Kulit:
1. Diperlukan 300 gr tepung cakra
1. Harap siapkan 60 gr gula pasir
1. Siapkan 1/2 sachet fermipan
1. Siapkan 2 kuning telur
1. Tambah 150 ml air hangat
1. Harus ada 40 gr margarin
1. Jangan lupa 1/2 sdt garam
1. Harus ada 1 sachet susu dancow
1. Harus ada  Isi:
1. Siapkan 150 gr margarin
1. Siapkan 1 sdm gula halus
1. Diperlukan  Topping:
1. Tambah 80 gr butter
1. Siapkan 70 gr gula halus
1. Diperlukan 1 telur ukuran besar, dikocok
1. Diperlukan 1 sdm kopi instan (me: luwak white coffee)
1. Diperlukan 1 sdm air hangat
1. Siapkan 70 gr terigu
1. Siapkan 1 sdt pasta mocca


The topping was crisp on day one, but softened. Also a copycat of Pappa Roti. These are delicious and so different- Not really Mexican, they are from Malaysia. Roti Mexico (Mexican bun) atau juga dikenali sebagai roti kopi (coffee bun) merupakan sejenis roti yang mempunyai topping berperisa kopi. 

<!--inarticleads2-->

##### Cara membuat  Mexico bun / Roti O:

1. Buat biang dulu, ambil air dan gula dari resep kulit ambil setengah, campur dgn fermipan, aduk dan biarkan berbusa
1. Kocok kuning telur dan sisa gula aduk sampai larut, masukkan terigu, susu bubuk dan bahan biang tadi, aduk rata
1. Masukkan margarin, uleni sampai kalis atau adonan elastis dan tidak lengket ditangan
1. Tutup adonan dgn plastik/kain serbet bersih selama 30 menit
1. Setelah mengembang kempiskan, potong2 adonan/timbang 40 gr jadi 15 biji, bulat2kan, pipihkan, isi dengan isian margarin dan gula halus yg telah dicampur pakai sendok teh
1. Tata pada loyang yg dialas kertas roti beri jarak agak lebar karena rotinya mengembang bgt. Diamkan 1 jam
1. Sambil nunggu 1 jam, buat topping, campur semua bahan toping. Aduk rata, masukkan pada plastik segitiga/piping, sisihkan
1. Panaskan oven. Setelah adonan mengembang semprot atasnya dgn toping dgn gerak melingkar
1. Oven 30 menit pada sushu 200° sampai permukaan atas kering
1. Siap disajikan


These are delicious and so different- Not really Mexican, they are from Malaysia. Roti Mexico (Mexican bun) atau juga dikenali sebagai roti kopi (coffee bun) merupakan sejenis roti yang mempunyai topping berperisa kopi. Baunya wangi ketika dibakar dan enak dinikmati bersama kopi panas. Roti canai (pronunciation: /tʃanaɪ/), or roti chenai, also known as roti cane (/tʃane/) and roti prata, is an Indian-influenced flatbread dish found in several countries in Southeast Asia, including Brunei, Indonesia, Malaysia and Singapore. Kalau tak pernah makan roti boy ni, actually rasa roti ni seperti roti kopi dan dalamnya ada inti mentega yang masin dan sedikit manis. 

Demikianlah cara membuat mexico bun / roti o yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat mudah dan terbukti, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
