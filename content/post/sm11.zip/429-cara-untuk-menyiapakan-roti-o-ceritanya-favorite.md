---
description: "Cara untuk menyiapakan Roti O (ceritanya) Favorite"
title: "Cara untuk menyiapakan Roti O (ceritanya) Favorite"
slug: 429-cara-untuk-menyiapakan-roti-o-ceritanya-favorite
date: 2020-10-29T13:47:37.750Z
image: https://img-global.cpcdn.com/recipes/50c132ea7d841ca3/680x482cq70/roti-o-ceritanya-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/50c132ea7d841ca3/680x482cq70/roti-o-ceritanya-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/50c132ea7d841ca3/680x482cq70/roti-o-ceritanya-foto-resep-utama.jpg
author: Vera Cole
ratingvalue: 4.2
reviewcount: 17652
recipeingredient:
- " Bahan roti"
- " Bahan A"
- "300 gr terigu prot tinggi"
- "15 gr susu bubuk"
- "40 gr gula pasir"
- "1 sdt ragi"
- "204 gr 1kuning telursusu cairair dingin"
- " Bahan B"
- "50 gr margarin mix butter"
- "3 gr garam"
- " Bahan isian"
- " Butter Salted beku potong kotak"
- " Bahan Topping"
- "75 gr margarin"
- "60 gr gula halus"
- "1 sc kopi capucino"
- "1 putih telur"
- "50 gr terigu"
- "1 sdt coklat bubuk"
- "10 gr tepung beras"
- "15 gr tepung maizena"
- "1 sc nescafe clasik larutkan dgn 2sdm air panas"
recipeinstructions:
- "Untuk topping,, mixer margarin, gula, kopi capucino sampai tercampur rata (2menit) lalu masukan putih telur mixer lagi 1menit dgn sped rendah, lalu tambahkan kopi nescafe dan bahan kering mixer lagi sampai tercampur rata, masukan ke plastik segitiga, dan masukan ke kulkas (15menit aja d kulkaasnya ya supaya ga terlalu keras nanti saat d aplikasikan ke rotinya)"
- "Untuk roti.."
- "Campur bahan kering di bahan A aduk rata tambahakan susu cair langsung di mixer sampai setengah kalis, lalu masukan bahan B mixer lg sampai kalis. Setelah kalis diam kan dan tutup adonan selama 45 menit"
- "Buang gas pada adonan lalu timbang adonan sesuai selera (me, 50gr) lalu bulatkan semua dan istirahatkan lagi 10 menit."
- "Setelah itu isi dgn potongan buttet salted yg sudah d potong potong kotak dan dibekukan, lakukan sampai habis lalu istirahatkan lagi selama satu jam, sampai roti mengembang 2x lipatnya."
- "Nyalakan oven suhu 190°C api atas bawah."
- "Aplikasikan topping td ke atas roti buat melingkar seperti obatnyamuk, biarkan setengah roti tertutup dgn topping, lakukan sampai habis lalu panggang selama 15-20menit"
- "Angkat dan siap d sajikan selagi hangat.. Garing diluar lembut di dalam.. Sensasi manis d luar gurih d dlm."
- "Note; ini adonan pas banget ukurannya antara roti dan toppingnya. Penggunaan api atas pd pemanggangan ini supaya bagian topping lebih krispy.... semua topping saat sudah dingin akan lengket (sy nyoba 2resep yg berbeda tp osama saat dingin lengket toppingnnya) jika mau tetap krispy, setiap mau makan panaskan d oven sebentar, pasti krispy lagi.."
- "Selamat mencoba, berikan yg terbaik untuk keluarga tercinta.. Lelah saat memasak akan hilang saat anak anak makannya lahap.."
categories:
- Recipe
tags:
- roti
- o
- ceritanya

katakunci: roti o ceritanya 
nutrition: 191 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dessert

---


![Roti O (ceritanya)](https://img-global.cpcdn.com/recipes/50c132ea7d841ca3/680x482cq70/roti-o-ceritanya-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan gurih. Karasteristik makanan Indonesia roti o (ceritanya) yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Roti O (ceritanya) untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang dapat anda contoh salah satunya roti o (ceritanya) yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep roti o (ceritanya) tanpa harus bersusah payah.
Berikut ini resep Roti O (ceritanya) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 22 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti O (ceritanya):

1. Dibutuhkan  Bahan roti;
1. Harap siapkan  Bahan A,
1. Diperlukan 300 gr terigu prot tinggi
1. Harus ada 15 gr susu bubuk
1. Tambah 40 gr gula pasir
1. Diperlukan 1 sdt ragi
1. Diperlukan 204 gr (1kuning telur+susu cair/air dingin)
1. Siapkan  Bahan B,
1. Diperlukan 50 gr margarin mix butter
1. Tambah 3 gr garam
1. Tambah  Bahan isian;
1. Harus ada  Butter Salted beku potong kotak
1. Tambah  Bahan Topping
1. Harus ada 75 gr margarin
1. Diperlukan 60 gr gula halus
1. Tambah 1 sc kopi capucino
1. Harap siapkan 1 putih telur
1. Dibutuhkan 50 gr terigu
1. Harap siapkan 1 sdt coklat bubuk
1. Dibutuhkan 10 gr tepung beras
1. Siapkan 15 gr tepung maizena
1. Harap siapkan 1 sc nescafe clasik (larutkan dgn 2sdm air panas)




<!--inarticleads2-->

##### Instruksi membuat  Roti O (ceritanya):

1. Untuk topping,, mixer margarin, gula, kopi capucino sampai tercampur rata (2menit) lalu masukan putih telur mixer lagi 1menit dgn sped rendah, lalu tambahkan kopi nescafe dan bahan kering mixer lagi sampai tercampur rata, masukan ke plastik segitiga, dan masukan ke kulkas (15menit aja d kulkaasnya ya supaya ga terlalu keras nanti saat d aplikasikan ke rotinya)
1. Untuk roti..
1. Campur bahan kering di bahan A aduk rata tambahakan susu cair langsung di mixer sampai setengah kalis, lalu masukan bahan B mixer lg sampai kalis. Setelah kalis diam kan dan tutup adonan selama 45 menit
1. Buang gas pada adonan lalu timbang adonan sesuai selera (me, 50gr) lalu bulatkan semua dan istirahatkan lagi 10 menit.
1. Setelah itu isi dgn potongan buttet salted yg sudah d potong potong kotak dan dibekukan, lakukan sampai habis lalu istirahatkan lagi selama satu jam, sampai roti mengembang 2x lipatnya.
1. Nyalakan oven suhu 190°C api atas bawah.
1. Aplikasikan topping td ke atas roti buat melingkar seperti obatnyamuk, biarkan setengah roti tertutup dgn topping, lakukan sampai habis lalu panggang selama 15-20menit
1. Angkat dan siap d sajikan selagi hangat.. Garing diluar lembut di dalam.. Sensasi manis d luar gurih d dlm.
1. Note; ini adonan pas banget ukurannya antara roti dan toppingnya. Penggunaan api atas pd pemanggangan ini supaya bagian topping lebih krispy.... semua topping saat sudah dingin akan lengket (sy nyoba 2resep yg berbeda tp osama saat dingin lengket toppingnnya) jika mau tetap krispy, setiap mau makan panaskan d oven sebentar, pasti krispy lagi..
1. Selamat mencoba, berikan yg terbaik untuk keluarga tercinta.. Lelah saat memasak akan hilang saat anak anak makannya lahap..




Demikianlah cara membuat roti o (ceritanya) yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
