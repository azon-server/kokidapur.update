---
description: "Resep : MEXICAN BUN/ ROTI O&amp;#39; Sempurna"
title: "Resep : MEXICAN BUN/ ROTI O&amp;#39; Sempurna"
slug: 427-resep-mexican-bun-roti-o-and-39-sempurna
date: 2020-11-06T19:05:09.527Z
image: https://img-global.cpcdn.com/recipes/2470959b85d8dc75/680x482cq70/mexican-bun-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2470959b85d8dc75/680x482cq70/mexican-bun-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2470959b85d8dc75/680x482cq70/mexican-bun-roti-o-foto-resep-utama.jpg
author: Alvin Mullins
ratingvalue: 4.8
reviewcount: 35386
recipeingredient:
- " Bahan roti"
- "250 gr tepung protein tinggi"
- "40 gr mentega tawar"
- "1 sdt ragi"
- "150 ml susu cair"
- "1 sdm gula halus"
- "1 butir telur kocok"
- " Bahan topping kopi"
- "1 sdm kopi instan  harusnya pake nescafe indocafe karna kopi yg ku pake rasanya kurang nampol waktu rotinya sudah jadi"
- "1 sdm air panas"
- "1 butir telur"
- "50 gr mentega"
- "50 gr gula halus"
- " Isian roti"
- " Cokelat blok  Blueberry jam"
recipeinstructions:
- "Cara membuat roti : Tuang ragi kedalam susu cair hangat, aduk lalu diamkan 5 menit hingga berbusa (untuk mengaktifkan raginya, klo ga berbusa berarti sudah tidak aktif)"
- "Masukan tepung, 1 sdm gula, 1 telur kocok dan ragi yang tadi sudah dilarutkan kedalam wadah, aduk rata"
- "Masukan mentega lalu uleni hingga kalis (Eitss jgn lupa cuci tangan sebelum menguleni ya) Setelah adonan kalis,"
- "Tutup dengan serbet lalu proofing 1 jam/ sampai adonan mengembang 2x lipat"
- "Sambil menunggu adonan, kita buat topping kopinya"
- "Cara membuat topping kopi: - Larutkan kopi dengan air hangat - Masukan mentega, gula halus dan telur ke dalam wadah lalu mixer - Masukan larutan kopi, mixer hingfa tercampur rata - Masukan adonan topping ke dalam pippingbag"
- "SETELAH 1 JAM - Kempeskan adonan roti, bulat bulatkan adonan lalu diamkan selama 20 menit. Sambil menunggu, panaskan oven terlebih dahulu dengan suhu 180° C selama 20 menit - Isi adonan roti dengan coklat blok dan blueberry - Setelah semua di isi lalu beri roti topping"
- "Setelah semua di isi lalu beri roti topping - Panggang adonan roti dengan suhu 180° selama 20-30 menit"
categories:
- Recipe
tags:
- mexican
- bun
- roti

katakunci: mexican bun roti 
nutrition: 153 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT60M"
recipeyield: "1"
recipecategory: Lunch

---


![MEXICAN BUN/ ROTI O&#39;](https://img-global.cpcdn.com/recipes/2470959b85d8dc75/680x482cq70/mexican-bun-roti-o-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau enak. Ciri makanan Indonesia mexican bun/ roti o&#39; yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak MEXICAN BUN/ ROTI O&#39; untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang bisa anda coba salah satunya mexican bun/ roti o&#39; yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep mexican bun/ roti o&#39; tanpa harus bersusah payah.
Seperti resep MEXICAN BUN/ ROTI O&#39; yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 8 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat MEXICAN BUN/ ROTI O&#39;:

1. Harap siapkan  Bahan roti
1. Diperlukan 250 gr tepung protein tinggi
1. Harap siapkan 40 gr mentega tawar
1. Jangan lupa 1 sdt ragi
1. Diperlukan 150 ml susu cair
1. Jangan lupa 1 sdm gula halus
1. Jangan lupa 1 butir telur kocok
1. Harap siapkan  Bahan topping kopi
1. Jangan lupa 1 sdm kopi instan ( harusnya pake nescafe/ indocafe karna kopi yg ku pake rasanya kurang nampol waktu rotinya sudah jadi
1. Jangan lupa 1 sdm air panas
1. Dibutuhkan 1 butir telur
1. Jangan lupa 50 gr mentega
1. Harus ada 50 gr gula halus
1. Diperlukan  Isian roti
1. Harap siapkan  Cokelat blok • Blueberry jam




<!--inarticleads2-->

##### Langkah membuat  MEXICAN BUN/ ROTI O&#39;:

1. Cara membuat roti : - Tuang ragi kedalam susu cair hangat, aduk lalu diamkan 5 menit hingga berbusa (untuk mengaktifkan raginya, klo ga berbusa berarti sudah tidak aktif)
1. Masukan tepung, 1 sdm gula, 1 telur kocok dan ragi yang tadi sudah dilarutkan kedalam wadah, aduk rata
1. Masukan mentega lalu uleni hingga kalis (Eitss jgn lupa cuci tangan sebelum menguleni ya) - Setelah adonan kalis,
1. Tutup dengan serbet lalu proofing 1 jam/ sampai adonan mengembang 2x lipat
1. Sambil menunggu adonan, kita buat topping kopinya
1. Cara membuat topping kopi: - - Larutkan kopi dengan air hangat - - Masukan mentega, gula halus dan telur ke dalam wadah lalu mixer - - Masukan larutan kopi, mixer hingfa tercampur rata - - Masukan adonan topping ke dalam pippingbag
1. SETELAH 1 JAM - - Kempeskan adonan roti, bulat bulatkan adonan lalu diamkan selama 20 menit. Sambil menunggu, panaskan oven terlebih dahulu dengan suhu 180° C selama 20 menit - - Isi adonan roti dengan coklat blok dan blueberry - - Setelah semua di isi lalu beri roti topping
1. Setelah semua di isi lalu beri roti topping - - Panggang adonan roti dengan suhu 180° selama 20-30 menit




Demikianlah cara membuat mexican bun/ roti o&#39; yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
