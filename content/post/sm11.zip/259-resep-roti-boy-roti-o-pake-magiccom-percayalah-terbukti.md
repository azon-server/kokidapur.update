---
description: "Resep : Roti Boy/Roti O pake Magiccom (percayalah...^-^) Terbukti"
title: "Resep : Roti Boy/Roti O pake Magiccom (percayalah...^-^) Terbukti"
slug: 259-resep-roti-boy-roti-o-pake-magiccom-percayalah-terbukti
date: 2021-02-13T02:37:50.870Z
image: https://img-global.cpcdn.com/recipes/bce444cf0a1f2837/680x482cq70/roti-boyroti-o-pake-magiccom-percayalah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bce444cf0a1f2837/680x482cq70/roti-boyroti-o-pake-magiccom-percayalah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bce444cf0a1f2837/680x482cq70/roti-boyroti-o-pake-magiccom-percayalah-foto-resep-utama.jpg
author: Hilda Payne
ratingvalue: 4.7
reviewcount: 9635
recipeingredient:
- " BAHAN ISI Campur rata "
- "1 sdm gula halus sya pke 12sdm biar gak terlalu manis"
- "50 gr margarin"
- " bahan roti "
- "1 sdt ragi"
- "300 gr tepung terigu pro tinggi"
- "50 gr gula pasir butiran halus"
- "2 sdm butter bole pke margarin"
- "120-150 ml air sesuaikan saja"
- "1 butir kuning telur"
- "1 sdm susu bubuk sy pke dancow"
- " bahan topping "
- "1 butir putih telur"
- "100 gr tepung terigu pro rendah kunciayak"
- "25 gr tepung maizena ayakklo sya maizena 15grtepung tapioka 10gr hasilnya lbh renyah bagus mnurutku"
- "100 gr gula halus ayak"
- "1-2 sdm kopi hitam 1sdm  nescafe capucino 1 sdm larutkan dgn sedikit air hangat sya tmbah juga 1sdt pasta mocca"
- "100 gr margarin"
- "1-2 sdt vanila extract"
- "1/2 sdt garam halus"
recipeinstructions:
- "Buat isian : campur rata semua bahan. Kmdian simpan dikulkas agar sdkit keras.Klo mo isian asin gak usah dicampurkn gula jg gpp."
- "Kemudian buat bahan roti : campurkan semua bahan roti jadi satu lalu uleni.Sya nguleni pke mixer spiral sktar 10 menit kmdian sya lnjut uleni pke tangan sktr 5menit smpe kalis. Bentuk bulatan besar kmdian tutup dg kain. DIAMKAN adonan slma 30menit tutupi dg kain. (Klo nguleni pke tangan sktr 10-15 menit sampe kalis elastis ya moms)"
- "Setelah 30menit buat bulatan2 kecil.Sya buat sktr 12 bulatan kemudian pipihkan dan beri isian margarin yg tadi disimpan dikulkas. #abaikan bentuknya yg kacau balau hihii"
- "Diamkan 60 menit sblm diberi topping.Tutupi kmbali dg kain supaya lembut dan mngembang"
- "Buat toping : mixer mentega+gula halus smpe mngembang putih. *kmdian lnjut masukkan putih telur.Lanjut masukkan bahan lain sprti tepung+ maizena+ vanila+ garam (mixer keceotan rendah aja buat ngaduk).Matikan mixer. *masukkan seduhan kopi+pasta mocca aduk pake spatula aja"
- "Trus masukkan toping kedlam plastik piping bag. Kl sya ke plastik biasa aja trus taruh dikulkas smbil nunggu roti ngembang"
- "Sambil nunggu panaskan magiccom skali cekrek. Kemudian kluarkan wadah trus alasi wadah magiccom dgn kertas oven kmdian olesi margarin.Hati2 panass hee"
- "Setelah 60 menit,beri toping adonan dgn adonan mocca dlm piping bag. Bikin bntuk melingkar sprti obat nyamuk bakar. Note : karena ini pke magiccom yg sekali masuk roti cm bisa 2-3 adonan saja sebaiknya toping diberi sesaat sblm adonan masuk magiccom. Sya malah kasi toping semua jd pas masukin yg kedua belepotan msuk ke wadah magiccomnya."
- "Taruh 2-3 adonan roti ke magiccom kmdian tekan tombol cook. Stlh tombol naik bunyi &#34;teg&#34; bgtu tunggu bbrp saat tekan tombol cook kebawah lg. Saya tadi menekan tombol cook smpe 5x kebawah dan roti sdh matang.Kl blm matang bsa tmbah skali cook lg kebawah.Dan tadaaaaa...ini dia rotinya berhasilll.....senenggggbngetttt"
- "Untungnya sya tmbahin pasta mocca td jadi rasa toping roti bner2 terasa bnget enakkkkk...wangi mocca bngetttt.huaaaaaa..aduhhhhh.ini sy fto dlu sblm msuk perut. Anget2 enak bnget lumer....huhuhuuuu..mo nangisss"
- "Tersisa cm segini yg sdh dingin bungkus2 dlu....utk temen sarapan besok deh..."
- "NOTE : *Saya pke magiccom kecil jd cm muat 3 adonam sja. *karena adonan masuk cm sdkit jadi proses manggangnya lamaaaa deh..gpp tp happy krn brhasil heee *adonan terakhir jadi kempis saat masuk saking lamanya dia antre nunggu masuk magiccom. Tp tetep mau kembang kok :) *roti bagian bawahnya sdkit kering kyak bakpia gtu...tp gpplah...yg pnting rasanya endessss...lumer enakkkkm.... *pake magiccom bagus utk pemula sprti sya hee."
categories:
- Recipe
tags:
- roti
- boyroti
- o

katakunci: roti boyroti o 
nutrition: 206 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Dinner

---


![Roti Boy/Roti O pake Magiccom (percayalah...^-^)](https://img-global.cpcdn.com/recipes/bce444cf0a1f2837/680x482cq70/roti-boyroti-o-pake-magiccom-percayalah-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga gurih. Karasteristik kuliner Nusantara roti boy/roti o pake magiccom (percayalah...^-^) yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga bisa didapat dengan cara simple. Diantaranya adalah membuat makanan Roti Boy/Roti O pake Magiccom (percayalah...^-^) untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang dapat anda praktekkan salah satunya roti boy/roti o pake magiccom (percayalah...^-^) yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep roti boy/roti o pake magiccom (percayalah...^-^) tanpa harus bersusah payah.
Seperti resep Roti Boy/Roti O pake Magiccom (percayalah...^-^) yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 12 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Boy/Roti O pake Magiccom (percayalah...^-^):

1. Dibutuhkan  BAHAN ISI (Campur rata) :
1. Harap siapkan 1 sdm gula halus (sya pke 1/2sdm biar gak terlalu manis)
1. Harus ada 50 gr margarin
1. Siapkan  bahan roti :
1. Tambah 1 sdt ragi
1. Harap siapkan 300 gr tepung terigu pro tinggi
1. Jangan lupa 50 gr gula pasir butiran halus
1. Siapkan 2 sdm butter (bole pke margarin)
1. Harus ada 120-150 ml air (sesuaikan saja)
1. Harap siapkan 1 butir kuning telur
1. Tambah 1 sdm susu bubuk (sy pke dancow)
1. Jangan lupa  bahan topping :
1. Dibutuhkan 1 butir putih telur
1. Harap siapkan 100 gr tepung terigu pro rendah (kunci,ayak)
1. Harus ada 25 gr tepung maizena (ayak).(klo sya maizena 15gr+tepung tapioka 10gr) hasilnya lbh renyah bagus mnurutku
1. Harus ada 100 gr gula halus (ayak)
1. Diperlukan 1-2 sdm kopi hitam (1sdm + nescafe capucino 1 sdm) larutkan dgn sedikit air hangat (sya tmbah juga 1sdt pasta mocca)
1. Tambah 100 gr margarin
1. Jangan lupa 1-2 sdt vanila extract
1. Dibutuhkan 1/2 sdt garam halus




<!--inarticleads2-->

##### Bagaimana membuat  Roti Boy/Roti O pake Magiccom (percayalah...^-^):

1. Buat isian : campur rata semua bahan. Kmdian simpan dikulkas agar sdkit keras.Klo mo isian asin gak usah dicampurkn gula jg gpp.
1. Kemudian buat bahan roti : campurkan semua bahan roti jadi satu lalu uleni.Sya nguleni pke mixer spiral sktar 10 menit kmdian sya lnjut uleni pke tangan sktr 5menit smpe kalis. Bentuk bulatan besar kmdian tutup dg kain. DIAMKAN adonan slma 30menit tutupi dg kain. (Klo nguleni pke tangan sktr 10-15 menit sampe kalis elastis ya moms)
1. Setelah 30menit buat bulatan2 kecil.Sya buat sktr 12 bulatan kemudian pipihkan dan beri isian margarin yg tadi disimpan dikulkas. #abaikan bentuknya yg kacau balau hihii
1. Diamkan 60 menit sblm diberi topping.Tutupi kmbali dg kain supaya lembut dan mngembang
1. Buat toping : mixer mentega+gula halus smpe mngembang putih. *kmdian lnjut masukkan putih telur.Lanjut masukkan bahan lain sprti tepung+ maizena+ vanila+ garam (mixer keceotan rendah aja buat ngaduk).Matikan mixer. *masukkan seduhan kopi+pasta mocca aduk pake spatula aja
1. Trus masukkan toping kedlam plastik piping bag. Kl sya ke plastik biasa aja trus taruh dikulkas smbil nunggu roti ngembang
1. Sambil nunggu panaskan magiccom skali cekrek. Kemudian kluarkan wadah trus alasi wadah magiccom dgn kertas oven kmdian olesi margarin.Hati2 panass hee
1. Setelah 60 menit,beri toping adonan dgn adonan mocca dlm piping bag. Bikin bntuk melingkar sprti obat nyamuk bakar. Note : karena ini pke magiccom yg sekali masuk roti cm bisa 2-3 adonan saja sebaiknya toping diberi sesaat sblm adonan masuk magiccom. Sya malah kasi toping semua jd pas masukin yg kedua belepotan msuk ke wadah magiccomnya.
1. Taruh 2-3 adonan roti ke magiccom kmdian tekan tombol cook. Stlh tombol naik bunyi &#34;teg&#34; bgtu tunggu bbrp saat tekan tombol cook kebawah lg. Saya tadi menekan tombol cook smpe 5x kebawah dan roti sdh matang.Kl blm matang bsa tmbah skali cook lg kebawah.Dan tadaaaaa...ini dia rotinya berhasilll.....senenggggbngetttt
1. Untungnya sya tmbahin pasta mocca td jadi rasa toping roti bner2 terasa bnget enakkkkk...wangi mocca bngetttt.huaaaaaa..aduhhhhh.ini sy fto dlu sblm msuk perut. Anget2 enak bnget lumer....huhuhuuuu..mo nangisss
1. Tersisa cm segini yg sdh dingin bungkus2 dlu....utk temen sarapan besok deh...
1. NOTE : *Saya pke magiccom kecil jd cm muat 3 adonam sja. *karena adonan masuk cm sdkit jadi proses manggangnya lamaaaa deh..gpp tp happy krn brhasil heee *adonan terakhir jadi kempis saat masuk saking lamanya dia antre nunggu masuk magiccom. Tp tetep mau kembang kok :) *roti bagian bawahnya sdkit kering kyak bakpia gtu...tp gpplah...yg pnting rasanya endessss...lumer enakkkkm.... *pake magiccom bagus utk pemula sprti sya hee.




Demikianlah cara membuat roti boy/roti o pake magiccom (percayalah...^-^) yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan teruji, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
