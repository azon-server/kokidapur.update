---
description: "Cara singkat untuk membuat Risol Mayo Teruji"
title: "Cara singkat untuk membuat Risol Mayo Teruji"
slug: 50-cara-singkat-untuk-membuat-risol-mayo-teruji
date: 2021-02-13T20:53:35.733Z
image: https://img-global.cpcdn.com/recipes/911dd657d8ad339f/680x482cq70/risol-mayo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/911dd657d8ad339f/680x482cq70/risol-mayo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/911dd657d8ad339f/680x482cq70/risol-mayo-foto-resep-utama.jpg
author: Brandon Willis
ratingvalue: 4.2
reviewcount: 5748
recipeingredient:
- " Bahan Kulit"
- "150 gr terigu serbaguna"
- "350 ml air"
- "2 butir telur"
- "30 ml minyak goreng"
- "1 sdt garam"
- "1/2 sdt kaldu jamur"
- " Isian"
- "11 lembar smoked beef"
- "2 butir telur rebus bagi 1112"
- "100 gr mayones"
- " Pelapis"
- "1 putih telur"
- "Secukupnya tepung roti kalau mau lebih cantik pakai yg oren"
recipeinstructions:
- "Pertama buat kulit risolnya. Campur terigu, garam dan kaldu jamur. Tambahkan telur dan minyak goreng. Aduk dengan whisker. Masukkan air sedikit demi sedikit sambil diaduk sampai rata dan tidak bergerindil."
- "Panaskan teflon, oles dengan sedikit minyak. Tuang 1 centong adonan, dadar dengan api kecil sampai matang. Ulangi sampai adonan habis. (Saya pakai teflon yg diameter dasarnya 20cm)"
- "Panaskan smoked beef di atas teflon sampai matang. Siapkan telur rebus dan potong2."
- "Tata smoked beef, telur rebus dan mayones di atas kulit risol. Lipat seperti biasa membuat risol. Ulangi untuk seluruh kulit risol."
- "Siapkan putih telur dan tepung roti. Balur risol dalam putih telur lalu ke tepung roti. Sedikit ditekan2 supaya menempel."
- "Goreng dalam minyak yang banyak dan panas sampai risol matang atau luarnya kriuk. Jika tidak mau digoreng sekaligus, simpan sisanya dalam wadah kedap udara ke dalam freezer."
- "Setelah matang kecoklatan, tiriskan. Risol mayo siap disajikan."
categories:
- Recipe
tags:
- risol
- mayo

katakunci: risol mayo 
nutrition: 150 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT37M"
recipeyield: "4"
recipecategory: Lunch

---


![Risol Mayo](https://img-global.cpcdn.com/recipes/911dd657d8ad339f/680x482cq70/risol-mayo-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita jaga karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti risol mayo yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa keistimewahan yang merupakan keragaman Nusantara



Keharmonisan keluarga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Risol Mayo untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian masakan yang dapat anda buat salah satunya risol mayo yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep risol mayo tanpa harus bersusah payah.
Berikut ini resep Risol Mayo yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Risol Mayo:

1. Dibutuhkan  Bahan Kulit
1. Tambah 150 gr terigu serbaguna
1. Siapkan 350 ml air
1. Diperlukan 2 butir telur
1. Diperlukan 30 ml minyak goreng
1. Siapkan 1 sdt garam
1. Harap siapkan 1/2 sdt kaldu jamur
1. Jangan lupa  Isian
1. Dibutuhkan 11 lembar smoked beef
1. Siapkan 2 butir telur rebus (bagi 11/12)
1. Dibutuhkan 100 gr mayones
1. Harus ada  Pelapis
1. Harus ada 1 putih telur
1. Harap siapkan Secukupnya tepung roti (kalau mau lebih cantik, pakai yg oren)




<!--inarticleads2-->

##### Instruksi membuat  Risol Mayo:

1. Pertama buat kulit risolnya. Campur terigu, garam dan kaldu jamur. Tambahkan telur dan minyak goreng. Aduk dengan whisker. Masukkan air sedikit demi sedikit sambil diaduk sampai rata dan tidak bergerindil.
1. Panaskan teflon, oles dengan sedikit minyak. Tuang 1 centong adonan, dadar dengan api kecil sampai matang. Ulangi sampai adonan habis. (Saya pakai teflon yg diameter dasarnya 20cm)
1. Panaskan smoked beef di atas teflon sampai matang. Siapkan telur rebus dan potong2.
1. Tata smoked beef, telur rebus dan mayones di atas kulit risol. Lipat seperti biasa membuat risol. Ulangi untuk seluruh kulit risol.
1. Siapkan putih telur dan tepung roti. Balur risol dalam putih telur lalu ke tepung roti. Sedikit ditekan2 supaya menempel.
1. Goreng dalam minyak yang banyak dan panas sampai risol matang atau luarnya kriuk. Jika tidak mau digoreng sekaligus, simpan sisanya dalam wadah kedap udara ke dalam freezer.
1. Setelah matang kecoklatan, tiriskan. Risol mayo siap disajikan.




Demikianlah cara membuat risol mayo yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
