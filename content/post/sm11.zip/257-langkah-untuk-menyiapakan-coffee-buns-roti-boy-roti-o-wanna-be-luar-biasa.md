---
description: "Langkah untuk menyiapakan Coffee Buns/ Roti Boy/ Roti O wanna be Luar biasa"
title: "Langkah untuk menyiapakan Coffee Buns/ Roti Boy/ Roti O wanna be Luar biasa"
slug: 257-langkah-untuk-menyiapakan-coffee-buns-roti-boy-roti-o-wanna-be-luar-biasa
date: 2021-02-07T14:07:36.409Z
image: https://img-global.cpcdn.com/recipes/0846d1fa8cfac1bf/680x482cq70/coffee-buns-roti-boy-roti-o-wanna-be-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0846d1fa8cfac1bf/680x482cq70/coffee-buns-roti-boy-roti-o-wanna-be-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0846d1fa8cfac1bf/680x482cq70/coffee-buns-roti-boy-roti-o-wanna-be-foto-resep-utama.jpg
author: Harvey Gardner
ratingvalue: 4.3
reviewcount: 40958
recipeingredient:
- " Bahan Biang"
- "1 sdm ragi"
- "2 sdm gula pasir"
- "75 ml air hangat"
- "1 sachet susu kental manis 40gr"
- " Bahan Roti"
- "250 gr tepung terigu protein tinggi"
- "3 sdm margarine"
- "3 sdm gula pasir"
- "1/2 sdt garam"
- "1 butir telur"
- " Bahan Isian"
- "3 sdm margarin saya campur unsaltedbutter"
- "50 gr keju parut kalo pake salted butter skip keju"
- " Bahan Topping"
- "3 sdm gula pasir"
- "3 sdm margarine"
- "6 sdm terigu saran saya gunakan protein rendah"
- "1 butir telur"
- "1 sachet nescafe 2gr"
- " notes saya ganti  takaran margarine dengan butter"
recipeinstructions:
- "Aktifkan bahan biang: campurkan semua bahan, aduk rata, biarkan 10menit sampai berbusa."
- "Aduk rata bahan roti, lalu masukan bahan biang/no.1, uleni hingga kalis, lalu istirahatkan/proofing#1 selama 1 jam."
- "Selagi menunggu proofing.. Siapkan isian: campur semua bahan isian, aduk rata, bagi 9, masukan ke freezer. Siapkan topping: campur semua bahan topping, mix sampai lembut, masukan pipping bag&amp;simpan di freezer."
- "Setelah 1 jam diistirahatkan, kempiskan adonan lalu bagi menjadi 9 bagian, bulatkan setiap bagian. Istirahatkan/proofing#2 selama 10 menit."
- "Isi tiap2 bulatan dengan bahan isian, bulatkan lagi, istirahatkan/proofing#3 selama 30 menit."
- "Beri topping di tiap bulatan dengan menyemprotkan mulai dari atas lalu melingkar seperti obat nyamuk. Semprot sampai ¾bagian roti."
- "Panggang dengan suhu 180°C (oven sudah dipanaskan lebih dahulu) selama 15-20menit hingga atasnya kecoklatan &amp; kering."
- "Punya saya jaraknya terlalu dekat, jadi nempel2 semua kayak roti kasur (kalau punya loyang lebih besar, atur jarak antar roti supaya tidak saling nempel saat dipanggang)."
- "Siap disajikan.."
categories:
- Recipe
tags:
- coffee
- buns
- roti

katakunci: coffee buns roti 
nutrition: 292 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Dinner

---


![Coffee Buns/ Roti Boy/ Roti O wanna be](https://img-global.cpcdn.com/recipes/0846d1fa8cfac1bf/680x482cq70/coffee-buns-roti-boy-roti-o-wanna-be-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas hingga enak. Ciri kuliner Indonesia coffee buns/ roti boy/ roti o wanna be yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Coffee Buns/ Roti Boy/ Roti O wanna be untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang bisa anda praktekkan salah satunya coffee buns/ roti boy/ roti o wanna be yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep coffee buns/ roti boy/ roti o wanna be tanpa harus bersusah payah.
Berikut ini resep Coffee Buns/ Roti Boy/ Roti O wanna be yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Coffee Buns/ Roti Boy/ Roti O wanna be:

1. Harap siapkan  Bahan Biang:
1. Tambah 1 sdm ragi
1. Jangan lupa 2 sdm gula pasir
1. Siapkan 75 ml air hangat
1. Harap siapkan 1 sachet susu kental manis (±40gr)
1. Jangan lupa  Bahan Roti:
1. Harus ada 250 gr tepung terigu protein tinggi
1. Dibutuhkan 3 sdm margarine*
1. Diperlukan 3 sdm gula pasir
1. Dibutuhkan 1/2 sdt garam
1. Siapkan 1 butir telur
1. Harap siapkan  Bahan Isian:
1. Harap siapkan 3 sdm margarin* (saya campur unsaltedbutter)
1. Dibutuhkan 50 gr keju parut (kalo pake salted butter, skip keju)
1. Diperlukan  Bahan Topping:
1. Harap siapkan 3 sdm gula pasir
1. Dibutuhkan 3 sdm margarine*
1. Jangan lupa 6 sdm terigu (saran saya gunakan protein rendah)
1. Jangan lupa 1 butir telur
1. Tambah 1 sachet nescafe (2gr)
1. Harap siapkan  notes: saya ganti ⅓ takaran margarine dengan butter




<!--inarticleads2-->

##### Langkah membuat  Coffee Buns/ Roti Boy/ Roti O wanna be:

1. Aktifkan bahan biang: campurkan semua bahan, aduk rata, biarkan 10menit sampai berbusa.
1. Aduk rata bahan roti, lalu masukan bahan biang/no.1, uleni hingga kalis, lalu istirahatkan/proofing#1 selama 1 jam.
1. Selagi menunggu proofing.. Siapkan isian: campur semua bahan isian, aduk rata, bagi 9, masukan ke freezer. Siapkan topping: campur semua bahan topping, mix sampai lembut, masukan pipping bag&amp;simpan di freezer.
1. Setelah 1 jam diistirahatkan, kempiskan adonan lalu bagi menjadi 9 bagian, bulatkan setiap bagian. Istirahatkan/proofing#2 selama 10 menit.
1. Isi tiap2 bulatan dengan bahan isian, bulatkan lagi, istirahatkan/proofing#3 selama 30 menit.
1. Beri topping di tiap bulatan dengan menyemprotkan mulai dari atas lalu melingkar seperti obat nyamuk. Semprot sampai ¾bagian roti.
1. Panggang dengan suhu 180°C (oven sudah dipanaskan lebih dahulu) selama 15-20menit hingga atasnya kecoklatan &amp; kering.
1. Punya saya jaraknya terlalu dekat, jadi nempel2 semua kayak roti kasur (kalau punya loyang lebih besar, atur jarak antar roti supaya tidak saling nempel saat dipanggang).
1. Siap disajikan..




Demikianlah cara membuat coffee buns/ roti boy/ roti o wanna be yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
