---
description: "Steps untuk menyiapakan Roti Boy a.k.a Mexican Bun Cepat"
title: "Steps untuk menyiapakan Roti Boy a.k.a Mexican Bun Cepat"
slug: 313-steps-untuk-menyiapakan-roti-boy-aka-mexican-bun-cepat
date: 2021-02-17T23:37:05.376Z
image: https://img-global.cpcdn.com/recipes/1ff7b8c93e43645a/680x482cq70/roti-boy-aka-mexican-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1ff7b8c93e43645a/680x482cq70/roti-boy-aka-mexican-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1ff7b8c93e43645a/680x482cq70/roti-boy-aka-mexican-bun-foto-resep-utama.jpg
author: Minnie Harmon
ratingvalue: 4.6
reviewcount: 24142
recipeingredient:
- " bahan roti "
- "200 g tepung protein tinggi ak pakai tepung cakra kembar"
- "50 g tepung protein sedang ak pakai tepung segitiga biru"
- "10 g susu bubuk"
- "6 g ragi instan"
- "1/2 sdt bread improver"
- "2 btr kuning telur"
- "100 ml air"
- "50 g mentega"
- "1/4 sdt garam"
- " bahan filling "
- "50 g mentega"
- "50 g kejuparut"
- "1 sdt gula"
- " bahan topping "
- "50 g tepung"
- "50 g mentega"
- "3 sdm gula"
- "1/4 sdt baling powder"
- "1 btr putih telur"
- "1 bungkus kopi cappucinolarutkan dengan 1 sdm air panas"
recipeinstructions:
- "Untuk roti: Campur terigu, susu bubuk, vanilla susu, gula pasir, ragi instant dan bread improver. Aduk rata. Masukkan kuning telur dan air sedikit demi sedikit sambil diuleni hingga kalis. Masukkan mentega dan garam. Uleni kembali hingga kalis dan elastis. Adonan mulus, licin dan bila direnggangkan tidak mudah sobek. Bulatkan adonan. Taruh dalam wadah yg diolesi sedikit minyak. Tutup dengan kain bersih.Diamkan sekitar 45-60 menit untuk proses fermentasi."
- "Setelah roti mengembang uleni lagi sekitar 5 menit, lalu bulat kan adonan masing&#34;berat 50 g,kalau mau seukuran roti boy berat adonan masing 100 g mungkin jadi sekitar 6 biji.setelah itu susun adonan di loyang persegi panjang yg sdh di oles mentega tipis&#34;,tutup dengan kain diamkan sekitar 5 menit."
- "Sambil menunggu adonan proofing,kita buat filling : campurkan semua bahan sampai tercampur rata."
- "Lalu buat topping : kocok putih telur hingga kaku berjejak, di wadah lain, kocok mentega,tepung,gula,baking powder. campurkan ke dua adonan,lalu tambahkan pasta kopi cappucino tadi,kocok hingga rata.taruh adonan dalam plastik piping bag.sisihkan"
- "Setelah adonan roti mengembang pipihkan adonan lalu beri filling lalu rapatkan adonan bentuk menjadi bulat,harus benar&#34; rapat,supaya waktu d panggang tdk bocor,lakukan hingga adonan habis."
- "Tata kembali masing&#34;adonan roti di loyang tutup dengan kain biarkan 10 menit. lalu beri topping diatasnya,topping harus rata,supaya nnti waktu jadi ga keliatan belang.dan jangan tutup penuh adonan roti dengan topping cukup setengah dari adonan roti supaya nanti topping ga melebar kemana&#34;.lakukan berulang hingga adonan habis.oh iya,jangan tata adonan berdekatan karena bisa membuat roti tidak mengembang secara sempurna,dan membuat topping saling lengket."
- "Panggang di oven dengan suhu 200°C selama 12 menit. angkat dan sajikan selagi hangat. so yummy.. 😋"
- "Happy cooking 😊"
categories:
- Recipe
tags:
- roti
- boy
- aka

katakunci: roti boy aka 
nutrition: 255 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dinner

---


![Roti Boy a.k.a Mexican Bun](https://img-global.cpcdn.com/recipes/1ff7b8c93e43645a/680x482cq70/roti-boy-aka-mexican-bun-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita lestarikan karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti roti boy a.k.a mexican bun yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan keistimewahan yang merupakan keragaman Kita

Keharmonisan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Roti Boy a.k.a Mexican Bun untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang bisa anda praktekkan salah satunya roti boy a.k.a mexican bun yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep roti boy a.k.a mexican bun tanpa harus bersusah payah.
Seperti resep Roti Boy a.k.a Mexican Bun yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 21 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Boy a.k.a Mexican Bun:

1. Tambah  bahan roti 🍞:
1. Jangan lupa 200 g tepung protein tinggi, (ak pakai tepung cakra kembar)
1. Tambah 50 g tepung protein sedang, (ak pakai tepung segitiga biru)
1. Siapkan 10 g susu bubuk
1. Siapkan 6 g ragi instan
1. Jangan lupa 1/2 sdt bread improver
1. Tambah 2 btr kuning telur
1. Dibutuhkan 100 ml air
1. Harap siapkan 50 g mentega
1. Harus ada 1/4 sdt garam
1. Dibutuhkan  bahan filling 🍯:
1. Tambah 50 g mentega
1. Diperlukan 50 g keju,parut
1. Jangan lupa 1 sdt gula
1. Harap siapkan  bahan topping 🍪:
1. Siapkan 50 g tepung
1. Diperlukan 50 g mentega
1. Harus ada 3 sdm gula
1. Jangan lupa 1/4 sdt baling powder
1. Dibutuhkan 1 btr putih telur
1. Harap siapkan 1 bungkus kopi cappucino,larutkan dengan 1 sdm air panas




<!--inarticleads2-->

##### Bagaimana membuat  Roti Boy a.k.a Mexican Bun:

1. Untuk roti: Campur terigu, susu bubuk, vanilla susu, gula pasir, ragi instant dan bread improver. Aduk rata. Masukkan kuning telur dan air sedikit demi sedikit sambil diuleni hingga kalis. Masukkan mentega dan garam. Uleni kembali hingga kalis dan elastis. Adonan mulus, licin dan bila direnggangkan tidak mudah sobek. Bulatkan adonan. Taruh dalam wadah yg diolesi sedikit minyak. Tutup dengan kain bersih.Diamkan sekitar 45-60 menit untuk proses fermentasi.
1. Setelah roti mengembang uleni lagi sekitar 5 menit, lalu bulat kan adonan masing&#34;berat 50 g,kalau mau seukuran roti boy berat adonan masing 100 g mungkin jadi sekitar 6 biji.setelah itu susun adonan di loyang persegi panjang yg sdh di oles mentega tipis&#34;,tutup dengan kain diamkan sekitar 5 menit.
1. Sambil menunggu adonan proofing,kita buat filling : campurkan semua bahan sampai tercampur rata.
1. Lalu buat topping : kocok putih telur hingga kaku berjejak, di wadah lain, kocok mentega,tepung,gula,baking powder. campurkan ke dua adonan,lalu tambahkan pasta kopi cappucino tadi,kocok hingga rata.taruh adonan dalam plastik piping bag.sisihkan
1. Setelah adonan roti mengembang pipihkan adonan lalu beri filling lalu rapatkan adonan bentuk menjadi bulat,harus benar&#34; rapat,supaya waktu d panggang tdk bocor,lakukan hingga adonan habis.
1. Tata kembali masing&#34;adonan roti di loyang tutup dengan kain biarkan 10 menit. lalu beri topping diatasnya,topping harus rata,supaya nnti waktu jadi ga keliatan belang.dan jangan tutup penuh adonan roti dengan topping cukup setengah dari adonan roti supaya nanti topping ga melebar kemana&#34;.lakukan berulang hingga adonan habis.oh iya,jangan tata adonan berdekatan karena bisa membuat roti tidak mengembang secara sempurna,dan membuat topping saling lengket.
1. Panggang di oven dengan suhu 200°C selama 12 menit. angkat dan sajikan selagi hangat. so yummy.. 😋
1. Happy cooking 😊




Demikianlah cara membuat roti boy a.k.a mexican bun yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
