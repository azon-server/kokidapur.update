---
description: "Step-by-Step membuat Roti boy mini Luar biasa"
title: "Step-by-Step membuat Roti boy mini Luar biasa"
slug: 316-step-by-step-membuat-roti-boy-mini-luar-biasa
date: 2020-11-03T02:24:41.038Z
image: https://img-global.cpcdn.com/recipes/04847a36bf77f504/680x482cq70/roti-boy-mini-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/04847a36bf77f504/680x482cq70/roti-boy-mini-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/04847a36bf77f504/680x482cq70/roti-boy-mini-foto-resep-utama.jpg
author: Betty Maldonado
ratingvalue: 4.1
reviewcount: 11714
recipeingredient:
- " bahan roti"
- "300 gr terigu aku pake segitiga biru"
- "100 gr gula halus"
- "1 sdt ragi instan"
- "150 ml susu cair full cream"
- "2 sdm margarin"
- "1 kuning telur"
- " bahan isian"
- "65 gr mentega"
- "5 gr batter"
- "15 gr keju"
- " bahan toping"
- "100 gr gula halus"
- "100 gr margarin"
- "100 gr terigu"
- "25 gr maizena"
- "1 putih telur"
- "sedikit garam  untuk menambah rasa gurih"
- "1 sdm kopi"
- "sedikit air panas untuk melarutkan kopi"
- " nbjangan terlalu banyak airnya nanti adonan toping encer"
recipeinstructions:
- "Buat isian: campur semua bahan isian setelah campir,maskkan ke dalam flize agar beku"
- "Membuat roti: masuk kan semua bahan kecuali margarin dan telur.. di mixer/di uleni paketangan sampai kalis. Tambahkan telur dan margarin mixer/uleni sampai kalis elastis... setelah itu istirahatkan tutup rapat dengan pelastik tunggu 1 jm sampai mengembang 2x lipat"
- "Ambil bahan isian di flizer fotong&#34; sampai menjadi 22 bagian"
- "Adonan roti yg sudah di istirahatkan di kempeskan kembali dengan cara di tonjok lalu timbang kurang leboh 25 gr sampai habis"
- "Beri isian roti..bundarkan taruh di atas loyang yg sudah di lapisi kertas roti"
- "Istirahatkan kembali tutup dengan plastik tunggu kira&#34; 1jm sampai mengembang 2x lipat"
- "Membuat toping: kocok margarin dan gula sampai creami masukan telur dan garam kocok sampai mengembang, masuk kan terigu dan meizena yang sudah di ayak sampai rata.. lalu masuk kan larutan kopi aduk sampai rata....lalu masuk kan ke dalam pelastik segitiga"
- "Setelah roti sudah mengembang 2x lipat kasi toping di atas roti dengan cara memutar dari tengah sampai bagian atas tertutup rata"
- "Oven kurang lebih 30 menit dengan suhu 170° (sesuaikan dengan oven saudara)"
categories:
- Recipe
tags:
- roti
- boy
- mini

katakunci: roti boy mini 
nutrition: 131 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dinner

---


![Roti boy mini](https://img-global.cpcdn.com/recipes/04847a36bf77f504/680x482cq70/roti-boy-mini-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti roti boy mini yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Nusantara



Kedekatan rumah tangga dapat didapat dengan cara sederhana. Diantaranya adalah membuat makanan Roti boy mini untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang bisa anda contoh salah satunya roti boy mini yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep roti boy mini tanpa harus bersusah payah.
Seperti resep Roti boy mini yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 9 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti boy mini:

1. Siapkan  bahan roti:
1. Harus ada 300 gr terigu (aku pake segitiga biru)
1. Tambah 100 gr gula halus
1. Diperlukan 1 sdt ragi instan
1. Harap siapkan 150 ml susu cair full cream
1. Dibutuhkan 2 sdm margarin
1. Diperlukan 1 kuning telur
1. Jangan lupa  bahan isian:
1. Siapkan 65 gr mentega
1. Harus ada 5 gr batter
1. Siapkan 15 gr keju
1. Harus ada  bahan toping:
1. Siapkan 100 gr gula halus
1. Diperlukan 100 gr margarin
1. Siapkan 100 gr terigu
1. Harap siapkan 25 gr maizena
1. Dibutuhkan 1 putih telur
1. Tambah sedikit garam : untuk menambah rasa gurih
1. Tambah 1 sdm kopi
1. Dibutuhkan sedikit air panas (untuk melarutkan kopi)
1. Jangan lupa  nb:jangan terlalu banyak airnya nanti adonan toping encer




<!--inarticleads2-->

##### Cara membuat  Roti boy mini:

1. Buat isian: campur semua bahan isian setelah campir,maskkan ke dalam flize agar beku
1. Membuat roti: masuk kan semua bahan kecuali margarin dan telur.. di mixer/di uleni paketangan sampai kalis. Tambahkan telur dan margarin mixer/uleni sampai kalis elastis... setelah itu istirahatkan tutup rapat dengan pelastik tunggu 1 jm sampai mengembang 2x lipat
1. Ambil bahan isian di flizer fotong&#34; sampai menjadi 22 bagian
1. Adonan roti yg sudah di istirahatkan di kempeskan kembali dengan cara di tonjok lalu timbang kurang leboh 25 gr sampai habis
1. Beri isian roti..bundarkan taruh di atas loyang yg sudah di lapisi kertas roti
1. Istirahatkan kembali tutup dengan plastik tunggu kira&#34; 1jm sampai mengembang 2x lipat
1. Membuat toping: kocok margarin dan gula sampai creami masukan telur dan garam kocok sampai mengembang, masuk kan terigu dan meizena yang sudah di ayak sampai rata.. lalu masuk kan larutan kopi aduk sampai rata....lalu masuk kan ke dalam pelastik segitiga
1. Setelah roti sudah mengembang 2x lipat kasi toping di atas roti dengan cara memutar dari tengah sampai bagian atas tertutup rata
1. Oven kurang lebih 30 menit dengan suhu 170° (sesuaikan dengan oven saudara)




Demikianlah cara membuat roti boy mini yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
