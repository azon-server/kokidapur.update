---
description: "Resep : Mexican Bun a.k.a Roti Boy terupdate"
title: "Resep : Mexican Bun a.k.a Roti Boy terupdate"
slug: 294-resep-mexican-bun-aka-roti-boy-terupdate
date: 2021-02-20T18:15:14.366Z
image: https://img-global.cpcdn.com/recipes/212563a13cf4fcd6/680x482cq70/mexican-bun-aka-roti-boy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/212563a13cf4fcd6/680x482cq70/mexican-bun-aka-roti-boy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/212563a13cf4fcd6/680x482cq70/mexican-bun-aka-roti-boy-foto-resep-utama.jpg
author: Mittie Hopkins
ratingvalue: 4.8
reviewcount: 2288
recipeingredient:
- " Bahan Biang "
- "150 ml air hangat"
- "1 sdt gula pasir"
- "1 sdt ragi instan"
- " Bahan Adonan "
- "200 gr tepung terigu protein tinggi"
- "100 gr tepung terigu protein sedang"
- "60 gr gula halus"
- "2 butir kuning telur"
- "1 sdm susu bubuk"
- "40 gr margarin"
- "1/2 sdt garam"
- " Bahan Isian "
- " Meises dan Butter"
- " Topping "
- "50 gr butter"
- "40 gr gula halus"
- "38 gr telur kocok lepas"
- "50 gr tepung terigu"
- "1 sdt kopi instan"
- "1 sdm air"
- "1/2 sdt pasta moka"
recipeinstructions:
- "Buat bahan biang. Masukkan gula pasir ke dalam air hangat, aduk rata. Masukkan ragi, aduk rata, pelan aja. Diamkan hingga berbuih tanda ragi aktif."
- "Campur terigu, gula halus dan susu bubuk. Masukkan kuning telur, aduk rata. Masukkan Bahan biang sedikit demi sedikit, uleni hingga kalis. Bahan biang jangan langsung dituang semua ya, cukup sampai dirasa adonan kalis, saya cuma pake 130 ml."
- "Masukkan garam dan mentega, uleni hingga kalis elastis. Saya sambil dibanting2 tapi gak sampai elastis juga sih hehehe. Dah pegel nih tangan 😅. Hanya sampai seperti ini penampakannya 😂."
- "Tutup adonan dengan plastik wrap, diamkan selama 30 menit. Ini penampakan setelah 30 menit. Sudah mengembang hampir 2x lipat 😁."
- "Kempiskan adonan. Bagi2 sesuai selera, saya timbang 50 gr an. Isi dengan bahan isian. Lalu taruh di loyang yang telah disemir dengan mentega. Beri jarak agak jauh ya, ini saya terlalu deket 😅. Adonan nanti akan mengembang besar ketika di oven. Tutup kembali dengan plastik wrap, diamkan hingga 1 jam."
- "Sementara menunggu, buat topping. Kocok dengan mixer butter dan gula hingga creamy lalu masukkan telur kocok dan pasta moka. Mixer hingga tercampur rata. Turunkan kecepatan mixer ke rendah, masukkan terigu, kopi dan air secara bertahap ya. Mixer sampe rata. Masukkan ke pipping bag. Sisihkan."
- "Panaskan oven. Adonan yang telah mengembang, beri topping. Gunting ujung pipping bag, semprotkan secara melingkar di atas adonan seperti obat nyamuk."
- "Panggang dengan api sedang hingga matang, topping berwarna kecoklatan kurleb 40 menit. Sesuaikan suhu oven masing2 ya 😀."
- "Nikmat disantap pas anget2. Ini saya isi butter."
- "Yang ini isi coklat 😁"
- "Dan ini penampakan rotinya 😊. Lembut banget."
- "Selamat mencoba 😊."
categories:
- Recipe
tags:
- mexican
- bun
- aka

katakunci: mexican bun aka 
nutrition: 123 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Lunch

---


![Mexican Bun a.k.a Roti Boy](https://img-global.cpcdn.com/recipes/212563a13cf4fcd6/680x482cq70/mexican-bun-aka-roti-boy-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan gurih. Karasteristik makanan Nusantara mexican bun a.k.a roti boy yang kaya dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kedekatan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Mexican Bun a.k.a Roti Boy untuk keluarga. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang dapat anda buat salah satunya mexican bun a.k.a roti boy yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep mexican bun a.k.a roti boy tanpa harus bersusah payah.
Berikut ini resep Mexican Bun a.k.a Roti Boy yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 22 bahan dan 12 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican Bun a.k.a Roti Boy:

1. Siapkan  Bahan Biang :
1. Siapkan 150 ml air hangat
1. Siapkan 1 sdt gula pasir
1. Diperlukan 1 sdt ragi instan
1. Jangan lupa  Bahan Adonan :
1. Jangan lupa 200 gr tepung terigu protein tinggi
1. Tambah 100 gr tepung terigu protein sedang
1. Dibutuhkan 60 gr gula halus
1. Diperlukan 2 butir kuning telur
1. Diperlukan 1 sdm susu bubuk
1. Harus ada 40 gr margarin
1. Harus ada 1/2 sdt garam
1. Tambah  Bahan Isian :
1. Diperlukan  Meises dan Butter
1. Siapkan  Topping :
1. Harap siapkan 50 gr butter
1. Tambah 40 gr gula halus
1. Siapkan 38 gr telur kocok lepas
1. Diperlukan 50 gr tepung terigu
1. Harus ada 1 sdt kopi instan
1. Harap siapkan 1 sdm air
1. Tambah 1/2 sdt pasta moka




<!--inarticleads2-->

##### Cara membuat  Mexican Bun a.k.a Roti Boy:

1. Buat bahan biang. Masukkan gula pasir ke dalam air hangat, aduk rata. Masukkan ragi, aduk rata, pelan aja. Diamkan hingga berbuih tanda ragi aktif.
1. Campur terigu, gula halus dan susu bubuk. Masukkan kuning telur, aduk rata. Masukkan Bahan biang sedikit demi sedikit, uleni hingga kalis. Bahan biang jangan langsung dituang semua ya, cukup sampai dirasa adonan kalis, saya cuma pake 130 ml.
1. Masukkan garam dan mentega, uleni hingga kalis elastis. Saya sambil dibanting2 tapi gak sampai elastis juga sih hehehe. Dah pegel nih tangan 😅. Hanya sampai seperti ini penampakannya 😂.
1. Tutup adonan dengan plastik wrap, diamkan selama 30 menit. Ini penampakan setelah 30 menit. Sudah mengembang hampir 2x lipat 😁.
1. Kempiskan adonan. Bagi2 sesuai selera, saya timbang 50 gr an. Isi dengan bahan isian. Lalu taruh di loyang yang telah disemir dengan mentega. Beri jarak agak jauh ya, ini saya terlalu deket 😅. Adonan nanti akan mengembang besar ketika di oven. Tutup kembali dengan plastik wrap, diamkan hingga 1 jam.
1. Sementara menunggu, buat topping. Kocok dengan mixer butter dan gula hingga creamy lalu masukkan telur kocok dan pasta moka. Mixer hingga tercampur rata. Turunkan kecepatan mixer ke rendah, masukkan terigu, kopi dan air secara bertahap ya. Mixer sampe rata. Masukkan ke pipping bag. Sisihkan.
1. Panaskan oven. Adonan yang telah mengembang, beri topping. Gunting ujung pipping bag, semprotkan secara melingkar di atas adonan seperti obat nyamuk.
1. Panggang dengan api sedang hingga matang, topping berwarna kecoklatan kurleb 40 menit. Sesuaikan suhu oven masing2 ya 😀.
1. Nikmat disantap pas anget2. Ini saya isi butter.
1. Yang ini isi coklat 😁
1. Dan ini penampakan rotinya 😊. Lembut banget.
1. Selamat mencoba 😊.




Demikianlah cara membuat mexican bun a.k.a roti boy yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
