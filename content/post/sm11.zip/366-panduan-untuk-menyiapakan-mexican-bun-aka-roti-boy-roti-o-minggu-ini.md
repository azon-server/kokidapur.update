---
description: "Panduan untuk menyiapakan Mexican Bun aka Roti Boy / Roti O minggu ini"
title: "Panduan untuk menyiapakan Mexican Bun aka Roti Boy / Roti O minggu ini"
slug: 366-panduan-untuk-menyiapakan-mexican-bun-aka-roti-boy-roti-o-minggu-ini
date: 2020-12-06T01:38:36.479Z
image: https://img-global.cpcdn.com/recipes/07c75661a52c73c0/680x482cq70/mexican-bun-aka-roti-boy-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/07c75661a52c73c0/680x482cq70/mexican-bun-aka-roti-boy-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/07c75661a52c73c0/680x482cq70/mexican-bun-aka-roti-boy-roti-o-foto-resep-utama.jpg
author: Cameron Greer
ratingvalue: 4.5
reviewcount: 5546
recipeingredient:
- " Bahan A"
- "215 gram terigu protein tinggi"
- "125 mL susu cair dingin"
- "1 sdt ragi instan"
- " Bahan B"
- " Adonan bahan A yang sudah di kulkas"
- "90 gram terigu protein tinggi"
- "1 butir telur"
- "2 sdt ragi instan"
- "1/2 sdt garam"
- "1 sdt vanili essens"
- "4 sdm gula pasir"
- "45 gram butter  margarin"
- "1 sdm susu cair dingin"
- " Topping "
- "50 gram butter  margarin"
- "2 sdm munjung gula halus"
- "50 gram terigu protein sedang"
- "1/4 sdt baking powder"
- "1 butir putih telur"
- "1 sdt kopi instan diseduh dengan 1 sdm air panas"
- " Filling "
- "50 gram butter"
- "50 gram keju parut"
recipeinstructions:
- "Campur semua bahan A, ulen hingga agak kalis (ga lengket lagi). Tutup dengan plastik atau kain, masukkan ke dalam kulkas selama 12 jam. Non freezer ya"
- "Keluarkan adonan A dari kulkas jika sudah 12 jam, sobek sobek"
- "Campur bahan A dengan bahan B kecuali butter/ margarin. Ulen hingga kalis"
- "Tambah butter/margarin. Ulen hingga kalis elastis"
- "Diamkan selama 1-2 jam hingga mengembang 2 kali lipat."
- "Pisahkan adonan menjadi adonan kecil. Timbang masing2 50 gram dan bulatkan"
- "Pipihkan adonan dengan rolling pin. Isi dengan butter dan keju. Bulatkan lagi."
- "Letakkan di atas loyang yang dilapisi kertas roti / margarin. Jaga jarak agar tidak lengket antar roti. Diamkan selama 30 menit"
- "Sambilan menunggu, buat topping. Kocok/ mixer putih telur hingga kaku. Di tempat terpisah, kocok/ mixer butter dengan gula halus"
- "Pada wadah yang berisi butter dan gula halus, jika sudah teraduk rata, tambahkan kocokan putih telur, terigu, kopi yang sudah diseduh dengan air, dan baking powder. Aduk merata. Masukkan ke dalam plastik segitiga"
- "Jika roti sudah mengembang, letakkan topping secara melingkar. Jangan sampai ada space biar cantik ketika sudah matang. Jangan meletakkan topping hingga ke bawah roti krn nanti topping akan meleleh"
- "Jika pakai oven tangkring, pangang roti dengan api kecil selama 50 menit. Jika pakai oven listrik, panaskan dengan suhu 180 derajat selama 15 menit. Angkat roti dan santap selagi hangat jika sudah matang"
categories:
- Recipe
tags:
- mexican
- bun
- aka

katakunci: mexican bun aka 
nutrition: 195 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT50M"
recipeyield: "3"
recipecategory: Dessert

---


![Mexican Bun aka Roti Boy / Roti O](https://img-global.cpcdn.com/recipes/07c75661a52c73c0/680x482cq70/mexican-bun-aka-roti-boy-roti-o-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang patut kita lestarikan karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti mexican bun aka roti boy / roti o yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa keistimewahan yang merupakan keragaman Kita



Kehangatan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Mexican Bun aka Roti Boy / Roti O untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang dapat anda praktekkan salah satunya mexican bun aka roti boy / roti o yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep mexican bun aka roti boy / roti o tanpa harus bersusah payah.
Berikut ini resep Mexican Bun aka Roti Boy / Roti O yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 12 langkah dan 24 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Mexican Bun aka Roti Boy / Roti O:

1. Tambah  Bahan A:
1. Diperlukan 215 gram terigu protein tinggi
1. Harus ada 125 mL susu cair dingin
1. Harap siapkan 1 sdt ragi instan
1. Dibutuhkan  Bahan B:
1. Diperlukan  Adonan bahan A yang sudah di kulkas
1. Jangan lupa 90 gram terigu protein tinggi
1. Jangan lupa 1 butir telur
1. Jangan lupa 2 sdt ragi instan
1. Jangan lupa 1/2 sdt garam
1. Diperlukan 1 sdt vanili essens
1. Tambah 4 sdm gula pasir
1. Jangan lupa 45 gram butter / margarin
1. Harus ada 1 sdm susu cair dingin
1. Harus ada  Topping :
1. Jangan lupa 50 gram butter / margarin
1. Harap siapkan 2 sdm munjung gula halus
1. Dibutuhkan 50 gram terigu protein sedang
1. Dibutuhkan 1/4 sdt baking powder
1. Jangan lupa 1 butir putih telur
1. Tambah 1 sdt kopi instan diseduh dengan 1 sdm air panas
1. Diperlukan  Filling :
1. Jangan lupa 50 gram butter
1. Diperlukan 50 gram keju parut




<!--inarticleads2-->

##### Langkah membuat  Mexican Bun aka Roti Boy / Roti O:

1. Campur semua bahan A, ulen hingga agak kalis (ga lengket lagi). Tutup dengan plastik atau kain, masukkan ke dalam kulkas selama 12 jam. Non freezer ya
1. Keluarkan adonan A dari kulkas jika sudah 12 jam, sobek sobek
1. Campur bahan A dengan bahan B kecuali butter/ margarin. Ulen hingga kalis
1. Tambah butter/margarin. Ulen hingga kalis elastis
1. Diamkan selama 1-2 jam hingga mengembang 2 kali lipat.
1. Pisahkan adonan menjadi adonan kecil. Timbang masing2 50 gram dan bulatkan
1. Pipihkan adonan dengan rolling pin. Isi dengan butter dan keju. Bulatkan lagi.
1. Letakkan di atas loyang yang dilapisi kertas roti / margarin. Jaga jarak agar tidak lengket antar roti. Diamkan selama 30 menit
1. Sambilan menunggu, buat topping. Kocok/ mixer putih telur hingga kaku. Di tempat terpisah, kocok/ mixer butter dengan gula halus
1. Pada wadah yang berisi butter dan gula halus, jika sudah teraduk rata, tambahkan kocokan putih telur, terigu, kopi yang sudah diseduh dengan air, dan baking powder. Aduk merata. Masukkan ke dalam plastik segitiga
1. Jika roti sudah mengembang, letakkan topping secara melingkar. Jangan sampai ada space biar cantik ketika sudah matang. Jangan meletakkan topping hingga ke bawah roti krn nanti topping akan meleleh
1. Jika pakai oven tangkring, pangang roti dengan api kecil selama 50 menit. Jika pakai oven listrik, panaskan dengan suhu 180 derajat selama 15 menit. Angkat roti dan santap selagi hangat jika sudah matang




Demikianlah cara membuat mexican bun aka roti boy / roti o yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
