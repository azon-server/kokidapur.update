---
description: "Steps membuat Mexican Bun / Roti Boy / Roti O teraktual"
title: "Steps membuat Mexican Bun / Roti Boy / Roti O teraktual"
slug: 254-steps-membuat-mexican-bun-roti-boy-roti-o-teraktual
date: 2021-01-07T23:15:21.518Z
image: https://img-global.cpcdn.com/recipes/77580e9162aca1b7/680x482cq70/mexican-bun-roti-boy-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/77580e9162aca1b7/680x482cq70/mexican-bun-roti-boy-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/77580e9162aca1b7/680x482cq70/mexican-bun-roti-boy-roti-o-foto-resep-utama.jpg
author: Madge Rice
ratingvalue: 4.6
reviewcount: 5277
recipeingredient:
- " Bahan toping "
- "6 sdm tepung"
- "3 sdm gula pasir"
- "3 sdm margarin"
- "1 putih telur"
- "1 sdm maizena"
- "1 sachet kecil nescaffe classic"
- " Bahan roti "
- "250 gr tepung cakraproteintinggi"
- "25 gr susu bubuk"
- "4 sdm gula pasir"
- "25 gr margarin"
- "1/4 sdt garam"
- "1 kuning telur"
- "150 ml airsusu cair dingin"
- "1 sdt ragi instan"
- " Isian"
- "potong dadu Butter beku"
recipeinstructions:
- "Siapkan wadah tuang susu cair campurkan 2 sdm gula pasir, ragi, dan kuning telur pastikan ragi aktif karena tanpa air hangat"
- "Campur tepung terigu, Susu bubuk dan sisa gula pasir aduk rata tambahkan Susu cair yg sudah Dicampur dengan ragi dan kuning telur dengan spatula"
- "Setelah rata tambahkan margarin dan garam. Aduk dengan tangan hingga rata, hampir 1/2 kalis. Bulatkan. Tutup Dengan plastik wrap / serbet basah hingga mengembang 2x lipat."
- "Dalam wadah lain campur semua tapung, susu bubuk dan sisa gula pasir, aduk rata. Lalu tambahkan campuran susu cair, aduk rata dengan spatula."
- "Topping : sambil nunggu Mengembang. Kita buat topingnya. Dalam wadah mixer semua bahan. Setelah rata, masukkan kedalam piping bag. Simpan dalam kulkas."
- "Balik ke adonan roti : Setelah mengembang 2xlipat. Tinju adonan, uleni sebentar. Lalu bagi-bagi adonan, saya 35 gram, ditahap ini kalo adonan lengket, taburi meja kerja dan tangan kita pake tepung."
- "Beri isian butter beku, bulatkan Lalu semprotkan dengan bahan toping. Melingkar seperti obat nyamuk. Mulai dari bawah sampe ke atas."
- "Toppingnya Kebanyakan dan sukses mleber 😱😆"
- "Panggang selama 25menit, suhu 150°. Atau sesuikan dengan oven"
- "Empukkk, simpan dalam plastik jika tidak habis, ato Tupperware supaya awet empuknya"
categories:
- Recipe
tags:
- mexican
- bun
- 

katakunci: mexican bun  
nutrition: 277 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT57M"
recipeyield: "1"
recipecategory: Lunch

---


![Mexican Bun / Roti Boy / Roti O](https://img-global.cpcdn.com/recipes/77580e9162aca1b7/680x482cq70/mexican-bun-roti-boy-roti-o-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas hingga empuk. Ciri masakan Nusantara mexican bun / roti boy / roti o yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah memasak Mexican Bun / Roti Boy / Roti O untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang dapat anda praktekkan salah satunya mexican bun / roti boy / roti o yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep mexican bun / roti boy / roti o tanpa harus bersusah payah.
Berikut ini resep Mexican Bun / Roti Boy / Roti O yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 10 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican Bun / Roti Boy / Roti O:

1. Tambah  Bahan toping :
1. Harus ada 6 sdm tepung
1. Harus ada 3 sdm gula pasir
1. Siapkan 3 sdm margarin
1. Diperlukan 1 putih telur
1. Diperlukan 1 sdm maizena
1. Tambah 1 sachet kecil nescaffe classic
1. Dibutuhkan  Bahan roti :
1. Harus ada 250 gr tepung cakra/protein.tinggi
1. Jangan lupa 25 gr susu bubuk
1. Jangan lupa 4 sdm gula pasir
1. Harap siapkan 25 gr margarin
1. Dibutuhkan 1/4 sdt garam
1. Diperlukan 1 kuning telur
1. Harus ada 150 ml air/susu cair dingin
1. Diperlukan 1 sdt ragi instan
1. Jangan lupa  Isian
1. Harap siapkan potong dadu Butter beku




<!--inarticleads2-->

##### Langkah membuat  Mexican Bun / Roti Boy / Roti O:

1. Siapkan wadah tuang susu cair campurkan 2 sdm gula pasir, ragi, dan kuning telur pastikan ragi aktif karena tanpa air hangat
1. Campur tepung terigu, Susu bubuk dan sisa gula pasir aduk rata tambahkan Susu cair yg sudah Dicampur dengan ragi dan kuning telur dengan spatula
1. Setelah rata tambahkan margarin dan garam. Aduk dengan tangan hingga rata, hampir 1/2 kalis. Bulatkan. Tutup Dengan plastik wrap / serbet basah hingga mengembang 2x lipat.
1. Dalam wadah lain campur semua tapung, susu bubuk dan sisa gula pasir, aduk rata. Lalu tambahkan campuran susu cair, aduk rata dengan spatula.
1. Topping : sambil nunggu Mengembang. Kita buat topingnya. Dalam wadah mixer semua bahan. Setelah rata, masukkan kedalam piping bag. Simpan dalam kulkas.
1. Balik ke adonan roti : Setelah mengembang 2xlipat. Tinju adonan, uleni sebentar. Lalu bagi-bagi adonan, saya 35 gram, ditahap ini kalo adonan lengket, taburi meja kerja dan tangan kita pake tepung.
1. Beri isian butter beku, bulatkan Lalu semprotkan dengan bahan toping. Melingkar seperti obat nyamuk. Mulai dari bawah sampe ke atas.
1. Toppingnya Kebanyakan dan sukses mleber 😱😆
1. Panggang selama 25menit, suhu 150°. Atau sesuikan dengan oven
1. Empukkk, simpan dalam plastik jika tidak habis, ato Tupperware supaya awet empuknya




Demikianlah cara membuat mexican bun / roti boy / roti o yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
