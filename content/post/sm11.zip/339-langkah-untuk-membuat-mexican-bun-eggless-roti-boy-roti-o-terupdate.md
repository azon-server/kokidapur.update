---
description: "Langkah untuk membuat Mexican Bun Eggless / Roti Boy / Roti O terupdate"
title: "Langkah untuk membuat Mexican Bun Eggless / Roti Boy / Roti O terupdate"
slug: 339-langkah-untuk-membuat-mexican-bun-eggless-roti-boy-roti-o-terupdate
date: 2020-09-23T09:35:26.235Z
image: https://img-global.cpcdn.com/recipes/6629ce66579f897f/680x482cq70/mexican-bun-eggless-roti-boy-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6629ce66579f897f/680x482cq70/mexican-bun-eggless-roti-boy-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6629ce66579f897f/680x482cq70/mexican-bun-eggless-roti-boy-roti-o-foto-resep-utama.jpg
author: Lois Jacobs
ratingvalue: 4.9
reviewcount: 22133
recipeingredient:
- "250 gram tepung terigu protein tinggi"
- "1 sdt ragi instan"
- "6 sdt gula pasir"
- "170 ml susu cair"
- "3 sdm butter"
- "1/2 sdt garam"
- " Bahan Filling"
- "25 gram butter"
- "25 gram keju parut"
- " Bahan Topping"
- "50 gram butter"
- "2 sdm munjung gula halus"
- "50 gram tepung terigu serba guna"
- "1/4 sdt Baking Powder"
- "1 butir putih telur"
- "1 sdt kopi instan diseduh dengan 1 sdm air panas"
- "Secukupnya pasta mocca"
recipeinstructions:
- "Campur tepung terigu, ragu, gula pasir, tuang susu perlahan uleni hingga setengah Kalis kemudian tambahkan butter dan garam uleni hingga kalis elastis manual"
- "Saya lanjutkan dengan mixer spiral, uleni hingga kalis elastis, bulatkan adonan poles dengan minyak sayur agar tidak kering tutup adonan dengan plastik wrap atau serbet bersih dan diamkan hingga mengembang 2x lipat sekitar 1 jam tergantung suhu ruang masing-masing, pastikan selalu cek karena bila suhu ruang panas di menit 30 bisa sudah mengembang"
- "Topping : Sambil menunggu adonan mengembang kita buat adonan topping, kocok putih telur hingga kaku, sisihkan. Di tempat terpisah kocok butter dan gula halus hingga lembut lalu campur tepung, baking powder dan putih telur tadi dan tambahkan seduhan kopi dengan air panas dan pasta mocca aduk rata masukkan dalam piping bag simpan dikulkas           (lihat resep)"
- "Campur adonan filling, setelah adonan mengembang tinju adonan bagi adonan dengan berat 50 gram beri 1 sdm adonan filling kemudian bulatkan dan tata di loyang yang sudah di alasi baking paper beri jarak agar tidak menempel ketika di panggang, punya saya saling menempel 😆 karena biar sekalian satu loyang ngoven nya maklum oven nya kecil, diamkan adonan selama 20 menit dengan di tutup lap bersih"
- "Setelah 20 menit beri adonan topping melingkar seperti obat nyamuk, pastikan tidak ada yang bolong ketika mengaplikasikan agar bentuknya cantik, oven sebelumnya sudah di panaskan, oven dengan suhu 180°C selama 15-20 menit"
- "Setelah matang angkat dan sajikan segera, jika masih bisa di simpan di wadah kedap udara, jika ingin di hangatkan kembali bisa di masukkan ke dalam microwave"
categories:
- Recipe
tags:
- mexican
- bun
- eggless

katakunci: mexican bun eggless 
nutrition: 109 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT60M"
recipeyield: "1"
recipecategory: Dessert

---


![Mexican Bun Eggless / Roti Boy / Roti O](https://img-global.cpcdn.com/recipes/6629ce66579f897f/680x482cq70/mexican-bun-eggless-roti-boy-roti-o-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti mexican bun eggless / roti boy / roti o yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Indonesia

Keharmonisan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak Mexican Bun Eggless / Roti Boy / Roti O untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda contoh salah satunya mexican bun eggless / roti boy / roti o yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep mexican bun eggless / roti boy / roti o tanpa harus bersusah payah.
Berikut ini resep Mexican Bun Eggless / Roti Boy / Roti O yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican Bun Eggless / Roti Boy / Roti O:

1. Jangan lupa 250 gram tepung terigu protein tinggi
1. Dibutuhkan 1 sdt ragi instan
1. Dibutuhkan 6 sdt gula pasir
1. Harap siapkan 170 ml susu cair
1. Diperlukan 3 sdm butter
1. Jangan lupa 1/2 sdt garam
1. Jangan lupa  Bahan Filling
1. Tambah 25 gram butter
1. Harus ada 25 gram keju parut
1. Dibutuhkan  Bahan Topping
1. Diperlukan 50 gram butter
1. Diperlukan 2 sdm munjung gula halus
1. Harus ada 50 gram tepung terigu serba guna
1. Dibutuhkan 1/4 sdt Baking Powder
1. Tambah 1 butir putih telur
1. Dibutuhkan 1 sdt kopi instan diseduh dengan 1 sdm air panas
1. Diperlukan Secukupnya pasta mocca




<!--inarticleads2-->

##### Langkah membuat  Mexican Bun Eggless / Roti Boy / Roti O:

1. Campur tepung terigu, ragu, gula pasir, tuang susu perlahan uleni hingga setengah Kalis kemudian tambahkan butter dan garam uleni hingga kalis elastis manual
1. Saya lanjutkan dengan mixer spiral, uleni hingga kalis elastis, bulatkan adonan poles dengan minyak sayur agar tidak kering tutup adonan dengan plastik wrap atau serbet bersih dan diamkan hingga mengembang 2x lipat sekitar 1 jam tergantung suhu ruang masing-masing, pastikan selalu cek karena bila suhu ruang panas di menit 30 bisa sudah mengembang
1. Topping : Sambil menunggu adonan mengembang kita buat adonan topping, kocok putih telur hingga kaku, sisihkan. Di tempat terpisah kocok butter dan gula halus hingga lembut lalu campur tepung, baking powder dan putih telur tadi dan tambahkan seduhan kopi dengan air panas dan pasta mocca aduk rata masukkan dalam piping bag simpan dikulkas -           (lihat resep)
1. Campur adonan filling, setelah adonan mengembang tinju adonan bagi adonan dengan berat 50 gram beri 1 sdm adonan filling kemudian bulatkan dan tata di loyang yang sudah di alasi baking paper beri jarak agar tidak menempel ketika di panggang, punya saya saling menempel 😆 karena biar sekalian satu loyang ngoven nya maklum oven nya kecil, diamkan adonan selama 20 menit dengan di tutup lap bersih
1. Setelah 20 menit beri adonan topping melingkar seperti obat nyamuk, pastikan tidak ada yang bolong ketika mengaplikasikan agar bentuknya cantik, oven sebelumnya sudah di panaskan, oven dengan suhu 180°C selama 15-20 menit
1. Setelah matang angkat dan sajikan segera, jika masih bisa di simpan di wadah kedap udara, jika ingin di hangatkan kembali bisa di masukkan ke dalam microwave




Demikianlah cara membuat mexican bun eggless / roti boy / roti o yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan cepat, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
