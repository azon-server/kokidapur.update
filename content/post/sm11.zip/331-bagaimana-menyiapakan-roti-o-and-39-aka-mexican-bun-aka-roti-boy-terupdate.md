---
description: "Bagaimana menyiapakan Roti O&amp;#39; aka Mexican Bun aka Roti Boy terupdate"
title: "Bagaimana menyiapakan Roti O&amp;#39; aka Mexican Bun aka Roti Boy terupdate"
slug: 331-bagaimana-menyiapakan-roti-o-and-39-aka-mexican-bun-aka-roti-boy-terupdate
date: 2020-09-11T08:54:41.918Z
image: https://img-global.cpcdn.com/recipes/c473fce9c77921d0/680x482cq70/roti-o-aka-mexican-bun-aka-roti-boy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c473fce9c77921d0/680x482cq70/roti-o-aka-mexican-bun-aka-roti-boy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c473fce9c77921d0/680x482cq70/roti-o-aka-mexican-bun-aka-roti-boy-foto-resep-utama.jpg
author: Ricky Stokes
ratingvalue: 4.4
reviewcount: 31593
recipeingredient:
- "250 gr tepung terigu serbaguna"
- "50 gr tepung kentang"
- "50 gr gula pasir"
- "1 butir kuning telur"
- "1/2 sachet ragi instan"
- "150 ml air"
- "2 sdm margarin"
- "1/2 sdt garam"
- " Bahan Isian"
- "30 gr margarin resep asli pake butter"
- "25 gr keju parut"
- "2 sdm gula halus"
- " Campur semua bahan sisihkan"
- " Bahan Topping"
- "1 putih telur"
- "50 gr margarin resep asli pake butter"
- "50 gr tepung terigu"
- "1/4 baking powder"
- "1 sdt kopi instan seduh dengan 1 sdm air panas"
- " Pasta mocca saya ga pake"
recipeinstructions:
- "Campurkan bahan kering: tepung, gula, dan ragi. Masukkan kuning telur dan air secara bertahap.."
- "Setelah setengah Kalis, tambahkan garam dan margarin. Uleni lagi sampai Kalis."
- "Bagi adonan menjadi beberapa bulatan. Saya jadi 12 bulatan. Istirahatkan 10 menit.."
- "Pipihkan adonan, tambahkan isian, bentuk bulat lagi.. istirahatkan lagi sampai mengembang.."
- "Sambil menunggu, buat toppingnya. Kocok putih telur sampai kaku."
- "Di wadah lain aduk margarin dan gula halus sampai lembut, tambahkan terigu, BP, kocokan putih telur, dan kopi yang sudah diseduh tadi..masukkan ke paping bag.."
- "Semprotkan topping diatas roti yang sudah mengembang.. dengan motif seperti obat nyamuk."
- "Panaskan oven terlebih dahulu selama 10 menit. Panggang dengan suhu 180°c selama 25-30 menit.."
categories:
- Recipe
tags:
- roti
- o
- aka

katakunci: roti o aka 
nutrition: 145 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Dessert

---


![Roti O&#39; aka Mexican Bun aka Roti Boy](https://img-global.cpcdn.com/recipes/c473fce9c77921d0/680x482cq70/roti-o-aka-mexican-bun-aka-roti-boy-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga enak. Karasteristik kuliner Nusantara roti o&#39; aka mexican bun aka roti boy yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan keluarga bisa didapat dengan cara mudah. Diantaranya adalah memasak Roti O&#39; aka Mexican Bun aka Roti Boy untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang bisa anda contoh salah satunya roti o&#39; aka mexican bun aka roti boy yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep roti o&#39; aka mexican bun aka roti boy tanpa harus bersusah payah.
Seperti resep Roti O&#39; aka Mexican Bun aka Roti Boy yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti O&#39; aka Mexican Bun aka Roti Boy:

1. Harus ada 250 gr tepung terigu serbaguna
1. Siapkan 50 gr tepung kentang
1. Tambah 50 gr gula pasir
1. Harus ada 1 butir kuning telur
1. Harus ada 1/2 sachet ragi instan
1. Dibutuhkan 150 ml air
1. Siapkan 2 sdm margarin
1. Tambah 1/2 sdt garam
1. Dibutuhkan  Bahan Isian
1. Dibutuhkan 30 gr margarin (resep asli pake butter)
1. Tambah 25 gr keju parut
1. Diperlukan 2 sdm gula halus
1. Diperlukan  Campur semua bahan, sisihkan
1. Siapkan  Bahan Topping
1. Harap siapkan 1 putih telur
1. Dibutuhkan 50 gr margarin (resep asli pake butter)
1. Siapkan 50 gr tepung terigu
1. Harus ada 1/4 baking powder
1. Tambah 1 sdt kopi instan, seduh dengan 1 sdm air panas
1. Dibutuhkan  Pasta mocca (saya ga pake)




<!--inarticleads2-->

##### Cara membuat  Roti O&#39; aka Mexican Bun aka Roti Boy:

1. Campurkan bahan kering: tepung, gula, dan ragi. Masukkan kuning telur dan air secara bertahap..
1. Setelah setengah Kalis, tambahkan garam dan margarin. Uleni lagi sampai Kalis.
1. Bagi adonan menjadi beberapa bulatan. Saya jadi 12 bulatan. Istirahatkan 10 menit..
1. Pipihkan adonan, tambahkan isian, bentuk bulat lagi.. istirahatkan lagi sampai mengembang..
1. Sambil menunggu, buat toppingnya. Kocok putih telur sampai kaku.
1. Di wadah lain aduk margarin dan gula halus sampai lembut, tambahkan terigu, BP, kocokan putih telur, dan kopi yang sudah diseduh tadi..masukkan ke paping bag..
1. Semprotkan topping diatas roti yang sudah mengembang.. dengan motif seperti obat nyamuk.
1. Panaskan oven terlebih dahulu selama 10 menit. Panggang dengan suhu 180°c selama 25-30 menit..




Demikianlah cara membuat roti o&#39; aka mexican bun aka roti boy yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
