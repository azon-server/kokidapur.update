---
description: "Steps menyiapakan Roti O ala rumahan terupdate"
title: "Steps menyiapakan Roti O ala rumahan terupdate"
slug: 386-steps-menyiapakan-roti-o-ala-rumahan-terupdate
date: 2020-11-19T14:07:12.729Z
image: https://img-global.cpcdn.com/recipes/a653580574024f86/680x482cq70/roti-o-ala-rumahan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a653580574024f86/680x482cq70/roti-o-ala-rumahan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a653580574024f86/680x482cq70/roti-o-ala-rumahan-foto-resep-utama.jpg
author: Jackson Ingram
ratingvalue: 4.5
reviewcount: 12374
recipeingredient:
- " Adonan roti"
- "260 gr tepung terigu pro tinggi mecakra"
- "40 gr gula pasir boleh tambah jika suka manis"
- "1 butir kuning telur"
- "1 sdt ragi instan mefermipan"
- "150 ml susu UHT plain"
- "2 sdm margarin"
- "Sejumput garam"
- " Setenga gelas kecil air hangat"
- " Topping kopi"
- "2 sachet kopi instan me good day vanilla latte"
- "4 sdm tepung terigu"
- "2-3 sdm gula pasir"
- "3-4 sdm margarin"
- " Isian roti"
- "4 sdm cream cheese boleh ganti keju parut dan sesuai selera"
- "4 sdm margarin"
- "2 sdm gula pasirgula halus"
recipeinstructions:
- "Campurkan ragi instan,gula pasir,air hangat dlm gelas,aduk. Lalu tunggu kira2 3-5mnt sampai berbusa."
- "Di wadah terpisah campurkan tepung terigu,kuning telur, dan susu cair,aduk merata. Setelah tercampur rata masukkan adonan ragi yg telah berbusa tadi. Uleni sampai setengah kalis. Lalu masukkan mentega dan sejumput garam. Uleni sampai kalis. Setelah kalis sisihkan adonan dan tutup dgn kain hinggan mengembang 2x lipat kurang lebih 40-60mnt."
- "Sembari menunggu adonan mengembang,kita siapkan topping kopi. Campur semua bahan dan kocok boleh pke whisk atau mixer sampai tercampur rata. Masukkan ke plastik segitiga dan taroh d kulkas agar setting."
- "Utk isian roti campur semua bahan dan kocok hinggan tercampur sempurna. Masukkan ke kulkas sementara sampai adonan roti setting."
- "Kempiskan adonan roti yg telah mengembang. Uleni kembali dan bagi kurang lebih 40gr-60gr. Pipihkan masing2 adonan dan isi dn isian keju yg telah dibuat. Tutup kembali dan bulatkan hinggan bagian atas licin."
- "Setelah itu biarkan adonan roti yg telah diisi kurang lbh 10mnt. Setelah 10mnt,beri topping kopi yg telah dibuat dgn gerakan melingkar sesuai selera. Krna ketika di panggang akan lumer menutupi seluruh permukaan roti."
- "Panaskan oven. Panggang 15-20mnt disesuaikan dgn jenis oven masing2 ya. Sambil sesekali dilihat bagian bawah utk meminimalisir gosong."
categories:
- Recipe
tags:
- roti
- o
- ala

katakunci: roti o ala 
nutrition: 182 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT60M"
recipeyield: "1"
recipecategory: Lunch

---


![Roti O ala rumahan](https://img-global.cpcdn.com/recipes/a653580574024f86/680x482cq70/roti-o-ala-rumahan-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang harus kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti roti o ala rumahan yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa ciri khas yang merupakan keragaman Kita



Kehangatan rumah tangga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Roti O ala rumahan untuk keluarga. Momen makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang bisa anda buat salah satunya roti o ala rumahan yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep roti o ala rumahan tanpa harus bersusah payah.
Berikut ini resep Roti O ala rumahan yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti O ala rumahan:

1. Harap siapkan  Adonan roti
1. Tambah 260 gr tepung terigu pro tinggi (me:cakra)
1. Tambah 40 gr gula pasir (boleh tambah jika suka manis)
1. Siapkan 1 butir kuning telur
1. Tambah 1 sdt ragi instan (me:fermipan)
1. Diperlukan 150 ml susu UHT plain
1. Siapkan 2 sdm margarin
1. Tambah Sejumput garam
1. Diperlukan  Setenga gelas kecil air hangat
1. Harap siapkan  Topping kopi
1. Siapkan 2 sachet kopi instan (me: good day vanilla latte)
1. Siapkan 4 sdm tepung terigu
1. Dibutuhkan 2-3 sdm gula pasir
1. Tambah 3-4 sdm margarin
1. Harap siapkan  Isian roti
1. Tambah 4 sdm cream cheese (boleh ganti keju parut dan sesuai selera)
1. Harap siapkan 4 sdm margarin
1. Tambah 2 sdm gula pasir/gula halus




<!--inarticleads2-->

##### Bagaimana membuat  Roti O ala rumahan:

1. Campurkan ragi instan,gula pasir,air hangat dlm gelas,aduk. Lalu tunggu kira2 3-5mnt sampai berbusa.
1. Di wadah terpisah campurkan tepung terigu,kuning telur, dan susu cair,aduk merata. Setelah tercampur rata masukkan adonan ragi yg telah berbusa tadi. Uleni sampai setengah kalis. Lalu masukkan mentega dan sejumput garam. Uleni sampai kalis. Setelah kalis sisihkan adonan dan tutup dgn kain hinggan mengembang 2x lipat kurang lebih 40-60mnt.
1. Sembari menunggu adonan mengembang,kita siapkan topping kopi. Campur semua bahan dan kocok boleh pke whisk atau mixer sampai tercampur rata. Masukkan ke plastik segitiga dan taroh d kulkas agar setting.
1. Utk isian roti campur semua bahan dan kocok hinggan tercampur sempurna. Masukkan ke kulkas sementara sampai adonan roti setting.
1. Kempiskan adonan roti yg telah mengembang. Uleni kembali dan bagi kurang lebih 40gr-60gr. Pipihkan masing2 adonan dan isi dn isian keju yg telah dibuat. Tutup kembali dan bulatkan hinggan bagian atas licin.
1. Setelah itu biarkan adonan roti yg telah diisi kurang lbh 10mnt. Setelah 10mnt,beri topping kopi yg telah dibuat dgn gerakan melingkar sesuai selera. Krna ketika di panggang akan lumer menutupi seluruh permukaan roti.
1. Panaskan oven. Panggang 15-20mnt disesuaikan dgn jenis oven masing2 ya. Sambil sesekali dilihat bagian bawah utk meminimalisir gosong.




Demikianlah cara membuat roti o ala rumahan yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan teruji, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
