---
description: "Resep : Roti boy ala ala Terbukti"
title: "Resep : Roti boy ala ala Terbukti"
slug: 315-resep-roti-boy-ala-ala-terbukti
date: 2020-12-27T21:30:12.515Z
image: https://img-global.cpcdn.com/recipes/5c5ebc526bd51774/680x482cq70/roti-boy-ala-ala-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5c5ebc526bd51774/680x482cq70/roti-boy-ala-ala-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5c5ebc526bd51774/680x482cq70/roti-boy-ala-ala-foto-resep-utama.jpg
author: Maude Sullivan
ratingvalue: 5
reviewcount: 5121
recipeingredient:
- " Bahan roti "
- "300 gram terigumesegitiga biru"
- "1 sdt fermipan"
- "3 sdm margarin"
- "2 sdm gula pasir"
- "1 butir telur utuh"
- "200 ml susu cair"
- " Bahan topping "
- "100 gram terigu"
- "100 gram margarin"
- "100 gram gula halus"
- "2 putih telur"
- "1 sachet nescafe classicsdkt kopi hitamdiseduh dg 2 sdm air"
- " pasta mocca"
- " Bahan isi "
- "100 gram margarin"
- "50 gram keju parut"
recipeinstructions:
- "Bekukan bahan isi"
- "Hangatkan susu cair suam-suam kuku,masukkan ragi+gula pasir,aduk sampai gula larut"
- "Campur susu dan telur yang sudah dikocok,aduk rata,lalu masukkan terigu sedikit demi sedikit sambil diaduk dengan garpu sampai rata(jika adonan terlalu lembek tambahkan tepung)"
- "Taburi tangan dengan tepung lalu uleni adonan hingga kalis,selanjutnya campurkan margarin adoni lagi kurang lebih 10 menit atau hingga kalis elastis (kmrn dibantuin anak sulung yang lagi bete gagal masuk final lomba,saya suruh aja banting2 adonan sambil bilang,lomba berikutnya harus menang haha)"
- "Setelah kalis,diamkan adonan tutup dengan kain atau tutup panci sampe ngembang kurang lebih 1 jam"
- "Sambil menunggu adonan,bikin topping dulu ya.Mixer margarin dan gula halus sampai lembut,lalu masukkan putih telur mixer lagi,masukkan bahan tepung,bahan kopi dan terakhir pasta mocca.Adonan harus kental kayak pasta,klo dirasa kurang kental,tambahin terigu aja,hehe.Masukkan dalam piping bag,simpan di kulkas.Sampai bagian ini lupa foto soalnya."
- "Jika adonan sudah mengembang 2 kali lipat,kempiskan adonan,ambil sedikit adonan,pipihkan,isi potongan margarin beku,tutup cubit2 rapat supaya filler tidak meleleh keluar saat dipanggang,bulatkan, taruh diatas loyang,lakukan sampai adonan habis,lalu diamkan lagi kurang lebih 1 jam"
- "Setelah adonan mengembang kembali,beri toping atasnya dengan pola melingkar seperti obat nyamuk bakar"
- "Oven roti dengan suhu kurang lebih 180°,selama 25-30 menit"
- "Roti boy ala ala siap disantap selagi hangat.Saat udah dinginpun tetep lembut,gurih dan ngopi"
- "Lembuut syukaa semua,sampe pas tetangga lewat,cium baunya,jadi mampir nyicipin,hihi"
categories:
- Recipe
tags:
- roti
- boy
- ala

katakunci: roti boy ala 
nutrition: 205 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Dessert

---


![Roti boy ala ala](https://img-global.cpcdn.com/recipes/5c5ebc526bd51774/680x482cq70/roti-boy-ala-ala-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang harus kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti roti boy ala ala yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan keistimewahan yang merupakan keragaman Indonesia



Keharmonisan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah memasak Roti boy ala ala untuk keluarga. kebersamaan makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang bisa anda praktekkan salah satunya roti boy ala ala yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep roti boy ala ala tanpa harus bersusah payah.
Berikut ini resep Roti boy ala ala yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 11 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti boy ala ala:

1. Jangan lupa  Bahan roti :
1. Jangan lupa 300 gram terigu,me:segitiga biru
1. Siapkan 1 sdt fermipan
1. Tambah 3 sdm margarin
1. Harap siapkan 2 sdm gula pasir
1. Siapkan 1 butir telur utuh
1. Harap siapkan 200 ml susu cair
1. Harus ada  Bahan topping :
1. Jangan lupa 100 gram terigu
1. Siapkan 100 gram margarin
1. Diperlukan 100 gram gula halus
1. Jangan lupa 2 putih telur
1. Harus ada 1 sachet nescafe classic+sdkt kopi hitam,diseduh dg 2 sdm air
1. Harap siapkan  pasta mocca
1. Siapkan  Bahan isi :
1. Jangan lupa 100 gram margarin
1. Harus ada 50 gram keju parut




<!--inarticleads2-->

##### Bagaimana membuat  Roti boy ala ala:

1. Bekukan bahan isi
1. Hangatkan susu cair suam-suam kuku,masukkan ragi+gula pasir,aduk sampai gula larut
1. Campur susu dan telur yang sudah dikocok,aduk rata,lalu masukkan terigu sedikit demi sedikit sambil diaduk dengan garpu sampai rata(jika adonan terlalu lembek tambahkan tepung)
1. Taburi tangan dengan tepung lalu uleni adonan hingga kalis,selanjutnya campurkan margarin adoni lagi kurang lebih 10 menit atau hingga kalis elastis (kmrn dibantuin anak sulung yang lagi bete gagal masuk final lomba,saya suruh aja banting2 adonan sambil bilang,lomba berikutnya harus menang haha)
1. Setelah kalis,diamkan adonan tutup dengan kain atau tutup panci sampe ngembang kurang lebih 1 jam
1. Sambil menunggu adonan,bikin topping dulu ya.Mixer margarin dan gula halus sampai lembut,lalu masukkan putih telur mixer lagi,masukkan bahan tepung,bahan kopi dan terakhir pasta mocca.Adonan harus kental kayak pasta,klo dirasa kurang kental,tambahin terigu aja,hehe.Masukkan dalam piping bag,simpan di kulkas.Sampai bagian ini lupa foto soalnya.
1. Jika adonan sudah mengembang 2 kali lipat,kempiskan adonan,ambil sedikit adonan,pipihkan,isi potongan margarin beku,tutup cubit2 rapat supaya filler tidak meleleh keluar saat dipanggang,bulatkan, taruh diatas loyang,lakukan sampai adonan habis,lalu diamkan lagi kurang lebih 1 jam
1. Setelah adonan mengembang kembali,beri toping atasnya dengan pola melingkar seperti obat nyamuk bakar
1. Oven roti dengan suhu kurang lebih 180°,selama 25-30 menit
1. Roti boy ala ala siap disantap selagi hangat.Saat udah dinginpun tetep lembut,gurih dan ngopi
1. Lembuut syukaa semua,sampe pas tetangga lewat,cium baunya,jadi mampir nyicipin,hihi




Demikianlah cara membuat roti boy ala ala yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat gampang dan terbukti, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
