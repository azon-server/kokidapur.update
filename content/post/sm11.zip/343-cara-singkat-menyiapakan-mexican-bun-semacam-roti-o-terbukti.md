---
description: "Cara singkat menyiapakan Mexican Bun (semacam Roti O) Terbukti"
title: "Cara singkat menyiapakan Mexican Bun (semacam Roti O) Terbukti"
slug: 343-cara-singkat-menyiapakan-mexican-bun-semacam-roti-o-terbukti
date: 2020-09-10T10:38:14.832Z
image: https://img-global.cpcdn.com/recipes/1a1436b1ef364846/680x482cq70/mexican-bun-semacam-roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1a1436b1ef364846/680x482cq70/mexican-bun-semacam-roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1a1436b1ef364846/680x482cq70/mexican-bun-semacam-roti-o-foto-resep-utama.jpg
author: Rhoda Christensen
ratingvalue: 4.1
reviewcount: 6620
recipeingredient:
- "200 gr terigu protein tinggi cakra kembar"
- "60 gr terigu protein sedang segitiga biru"
- "40 gr gula pasir"
- "1 sdm susu bubuk full cream"
- "1 sdt ragi instant fermipan"
- "1 butir kuning telur"
- "120 ml susu cair full cream"
- "1/2 sdt garam"
- "30 gr unsalted butter"
- " Bahan isian campur rata"
- "30 gr salted butter"
- "2 sdm gula halus"
- "30 gr keju cheddar parut"
- "Optional choco chip utk isian coklat"
- " Topping"
- "1 putih telur"
- "50 gr salted butter"
- "2 sdm gula halus"
- "50 gr terigu segitiga biru"
- "1/4 sdt baking powder"
- "1 sachet (2 gr) kopi instant resep asli 12 sdt coklat bubuk"
- "1 sdm air utk menyeduh kopicoklat bubuk"
- "1/2 sdt pasta mocca"
recipeinstructions:
- "Campur semua bahan kecuali garam &amp; butter sampai setengah kalis. Nuangin susunya pelan2 aja yaa.. kalau sudah 1/2 kalis masukkan butter &amp; garam. Uleni lagi sampai kalis elastis. Tutup adonan dg plasric wrap/lap basah. Diamkan kira2 1 jam"
- "Buat isian. Campur semua bahan isian."
- "Buat topping. Mixer putih telur sampai kaku (meringue), sisihkan. Di wadah terpisah, campur butter dan gula halus sampai rata kemudian masukan tepung terigu, baking powder, campuran kopi dan peasta moka, aduk rata. Kemudian masukan adonan meringue secara bertahap aduk rata kembali. Masukkan ke plastik 1/3."
- "Adonan yg sudah mengembang, kempiskan. Bagi rata sesuaikan besarnya dg selera. Saya timbang 25 gram jadi 14 bulatan. Gilas masing2 bulatan, beri isian. Bulatkan kembali. Tata di loyang yg sdh dioles margarin. Beri jarak. Diamkan kembali 10 menit. Setelah 10 menit, semprotkan topping dg pola melingkar seperti obat nyamuk sampai nutup 2/3 bagian (Nah ini sy masih harus banyak berlatih 🤭)"
- "Panggang dalam oven 180° dg api atas bawah yg sudah dipanaskan sebelumnya. Durasi kurang lebih 20 menitan. Sesuaikan dg oven masing2 yaa. Kalau topping sudah meleleh bisa switch lgs pakai api bawah saja. Kalau sudah matang, pindahkan ke cooling rack. Hmmmm harum kopinya semerbaaak 😋. Tinggal bikin wedang kopi deh."
categories:
- Recipe
tags:
- mexican
- bun
- semacam

katakunci: mexican bun semacam 
nutrition: 200 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dessert

---


![Mexican Bun (semacam Roti O)](https://img-global.cpcdn.com/recipes/1a1436b1ef364846/680x482cq70/mexican-bun-semacam-roti-o-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan gurih. Ciri khas makanan Indonesia mexican bun (semacam roti o) yang penuh dengan rempah memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kedekatan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Mexican Bun (semacam Roti O) untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang bisa anda coba salah satunya mexican bun (semacam roti o) yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep mexican bun (semacam roti o) tanpa harus bersusah payah.
Berikut ini resep Mexican Bun (semacam Roti O) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 23 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican Bun (semacam Roti O):

1. Siapkan 200 gr terigu protein tinggi (cakra kembar)
1. Harap siapkan 60 gr terigu protein sedang (segitiga biru)
1. Harus ada 40 gr gula pasir
1. Tambah 1 sdm susu bubuk full cream
1. Siapkan 1 sdt ragi instant (fermipan)
1. Jangan lupa 1 butir kuning telur
1. Dibutuhkan 120 ml susu cair full cream
1. Diperlukan 1/2 sdt garam
1. Harus ada 30 gr unsalted butter
1. Siapkan  Bahan isian (campur rata)
1. Harus ada 30 gr salted butter
1. Harap siapkan 2 sdm gula halus
1. Harus ada 30 gr keju cheddar parut
1. Jangan lupa Optional choco chip utk isian coklat
1. Dibutuhkan  Topping
1. Harap siapkan 1 putih telur
1. Dibutuhkan 50 gr salted butter
1. Dibutuhkan 2 sdm gula halus
1. Tambah 50 gr terigu segitiga biru
1. Harus ada 1/4 sdt baking powder
1. Jangan lupa 1 sachet (2 gr) kopi instant (resep asli 1/2 sdt coklat bubuk)
1. Harap siapkan 1 sdm air utk menyeduh kopi/coklat bubuk
1. Harap siapkan 1/2 sdt pasta mocca




<!--inarticleads2-->

##### Langkah membuat  Mexican Bun (semacam Roti O):

1. Campur semua bahan kecuali garam &amp; butter sampai setengah kalis. Nuangin susunya pelan2 aja yaa.. kalau sudah 1/2 kalis masukkan butter &amp; garam. Uleni lagi sampai kalis elastis. Tutup adonan dg plasric wrap/lap basah. Diamkan kira2 1 jam
1. Buat isian. Campur semua bahan isian.
1. Buat topping. Mixer putih telur sampai kaku (meringue), sisihkan. Di wadah terpisah, campur butter dan gula halus sampai rata kemudian masukan tepung terigu, baking powder, campuran kopi dan peasta moka, aduk rata. Kemudian masukan adonan meringue secara bertahap aduk rata kembali. Masukkan ke plastik 1/3.
1. Adonan yg sudah mengembang, kempiskan. Bagi rata sesuaikan besarnya dg selera. Saya timbang 25 gram jadi 14 bulatan. Gilas masing2 bulatan, beri isian. Bulatkan kembali. Tata di loyang yg sdh dioles margarin. Beri jarak. Diamkan kembali 10 menit. Setelah 10 menit, semprotkan topping dg pola melingkar seperti obat nyamuk sampai nutup 2/3 bagian (Nah ini sy masih harus banyak berlatih 🤭)
1. Panggang dalam oven 180° dg api atas bawah yg sudah dipanaskan sebelumnya. Durasi kurang lebih 20 menitan. Sesuaikan dg oven masing2 yaa. Kalau topping sudah meleleh bisa switch lgs pakai api bawah saja. Kalau sudah matang, pindahkan ke cooling rack. Hmmmm harum kopinya semerbaaak 😋. Tinggal bikin wedang kopi deh.




Demikianlah cara membuat mexican bun (semacam roti o) yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
