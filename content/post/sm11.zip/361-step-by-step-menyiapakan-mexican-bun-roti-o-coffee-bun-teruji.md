---
description: "Step-by-Step menyiapakan Mexican Bun/Roti O/Coffee Bun Teruji"
title: "Step-by-Step menyiapakan Mexican Bun/Roti O/Coffee Bun Teruji"
slug: 361-step-by-step-menyiapakan-mexican-bun-roti-o-coffee-bun-teruji
date: 2020-12-28T07:21:23.196Z
image: https://img-global.cpcdn.com/recipes/6f2f57011ad22af8/680x482cq70/mexican-bunroti-ocoffee-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6f2f57011ad22af8/680x482cq70/mexican-bunroti-ocoffee-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6f2f57011ad22af8/680x482cq70/mexican-bunroti-ocoffee-bun-foto-resep-utama.jpg
author: Joseph Steele
ratingvalue: 4.3
reviewcount: 25872
recipeingredient:
- " Bahan A"
- "300 gr tepung terigu protein tinggi"
- "50 gr gula pasir"
- "7 gr ragi instan"
- "100 gr susu cair"
- "100 gr whipping cream cair susu cair"
- " Bahan B"
- "65 gr butter"
- "1/2 sdt garam"
- " Bahan isian"
- " Butter"
- " Bahan toping"
- "70 gr butter"
- "35 gr gula pasir"
- "1 butir telur"
- "1 bks kopi torabika sachet larutkan dengan 2 sdm air panas"
- "70 gr tepung terigu"
recipeinstructions:
- "Campur semua bahan A jadi satu lalu uleni hingga 1/2 kalis, saya ulen manual no mixer ya, kalau mau pakai mixer juga bisa malah lebih cepat"
- "Setelah 1/2 kalis masukkan butter dan garam, lanjut uleni hingga kalis"
- "Setelah kalis tutup dough proffing hingga double size -/+45 menit"
- "Setelah double size kempiskan adonan, lalu bagi&#34; adonan @60gr bulatkan lalu tutup istirahatkan kembali selama 15 menit"
- "Selagi menunggu, kita buat topingnya dulu, campur butter dan gula aduk rata menggunakan wisk, lalu tambahkan telur dan kopi aduk rata kembali, masukkan tepung terigu aduk rata lalu tuang toping pada plastik segitiga, sisihkan"
- "Ambil 1 bulatan dough, pipihkan beri isian mentega di tengahnya lalu bulatkan kembali. Lakukan sampai semua dough habis, tutup lagi hingga double size"
- "Setelah double size semprotkan toping sampai 3/4 bagian dough saja"
- "Panaskan teflon 5 - 10 menit, saya juga menggunakan panci kecil yang biasa buat merebus mie biar tidak mudah gosong ya. Pancinya di olesi margarin terlebih dahulu, jika sudah panas masukkan panci kedalam wajan teflon panggang selama -/+ 20 menit"
- "Mexican Bun/Coffe Bun siap di hidangkan, dalamnya berongga rotinya empuk mantul banget👌 cocok untuk teman ngopi/ngeteh🥰"
categories:
- Recipe
tags:
- mexican
- bunroti
- ocoffee

katakunci: mexican bunroti ocoffee 
nutrition: 171 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Lunch

---


![Mexican Bun/Roti O/Coffee Bun](https://img-global.cpcdn.com/recipes/6f2f57011ad22af8/680x482cq70/mexican-bunroti-ocoffee-bun-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau renyah. Ciri kuliner Nusantara mexican bun/roti o/coffee bun yang kaya dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan keluarga bisa didapat dengan cara simple. Diantaranya adalah memasak Mexican Bun/Roti O/Coffee Bun untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.

Super Delicious Mexican Coffee Bun (Homebake Coffee Butter Bun). 巧克力墨西哥面包 Chocolate Mexican Buns. Mexican Coffee Bun (Rotiboy) - Sweet bun with coffee topping and butter filling. It&#39;s popular in Malaysia and Asia. The aroma of this Mexican coffee bun bun is really tantalizing and makes you just want to eat it piping hot.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang bisa anda contoh salah satunya mexican bun/roti o/coffee bun yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep mexican bun/roti o/coffee bun tanpa harus bersusah payah.
Berikut ini resep Mexican Bun/Roti O/Coffee Bun yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Mexican Bun/Roti O/Coffee Bun:

1. Diperlukan  Bahan A
1. Harap siapkan 300 gr tepung terigu protein tinggi
1. Harap siapkan 50 gr gula pasir
1. Jangan lupa 7 gr ragi instan
1. Dibutuhkan 100 gr susu cair
1. Harus ada 100 gr whipping cream cair/ susu cair
1. Harus ada  Bahan B
1. Dibutuhkan 65 gr butter
1. Jangan lupa 1/2 sdt garam
1. Tambah  Bahan isian
1. Tambah  Butter
1. Tambah  Bahan toping
1. Tambah 70 gr butter
1. Dibutuhkan 35 gr gula pasir
1. Siapkan 1 butir telur
1. Harap siapkan 1 bks kopi torabika sachet larutkan dengan 2 sdm air panas
1. Harus ada 70 gr tepung terigu


I used a tangzhong milk loaf for my buns. They turned out super soft, fluffy and. Also a copycat of Pappa Roti. These are delicious and so different It is like a thin coffee butter cookie spread over the bun. 

<!--inarticleads2-->

##### Instruksi membuat  Mexican Bun/Roti O/Coffee Bun:

1. Campur semua bahan A jadi satu lalu uleni hingga 1/2 kalis, saya ulen manual no mixer ya, kalau mau pakai mixer juga bisa malah lebih cepat
1. Setelah 1/2 kalis masukkan butter dan garam, lanjut uleni hingga kalis
1. Setelah kalis tutup dough proffing hingga double size -/+45 menit
1. Setelah double size kempiskan adonan, lalu bagi&#34; adonan @60gr bulatkan lalu tutup istirahatkan kembali selama 15 menit
1. Selagi menunggu, kita buat topingnya dulu, campur butter dan gula aduk rata menggunakan wisk, lalu tambahkan telur dan kopi aduk rata kembali, masukkan tepung terigu aduk rata lalu tuang toping pada plastik segitiga, sisihkan
1. Ambil 1 bulatan dough, pipihkan beri isian mentega di tengahnya lalu bulatkan kembali. Lakukan sampai semua dough habis, tutup lagi hingga double size
1. Setelah double size semprotkan toping sampai 3/4 bagian dough saja
1. Panaskan teflon 5 - 10 menit, saya juga menggunakan panci kecil yang biasa buat merebus mie biar tidak mudah gosong ya. Pancinya di olesi margarin terlebih dahulu, jika sudah panas masukkan panci kedalam wajan teflon panggang selama -/+ 20 menit
1. Mexican Bun/Coffe Bun siap di hidangkan, dalamnya berongga rotinya empuk mantul banget👌 cocok untuk teman ngopi/ngeteh🥰


Also a copycat of Pappa Roti. These are delicious and so different It is like a thin coffee butter cookie spread over the bun. These &#34;Rotiboy&#34; Mexican coffee buns are to die for. Ultra pillowy soft coffee buns with heavenly buttery goodness. It has just the right amount of coffee to tease and wake your senses! 

Demikianlah cara membuat mexican bun/roti o/coffee bun yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan teruji, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
