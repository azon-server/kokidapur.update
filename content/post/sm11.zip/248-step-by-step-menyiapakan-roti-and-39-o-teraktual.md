---
description: "Step-by-Step menyiapakan Roti &amp;#39;O teraktual"
title: "Step-by-Step menyiapakan Roti &amp;#39;O teraktual"
slug: 248-step-by-step-menyiapakan-roti-and-39-o-teraktual
date: 2020-09-13T10:12:30.774Z
image: https://img-global.cpcdn.com/recipes/4defdafccb34fb09/680x482cq70/roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4defdafccb34fb09/680x482cq70/roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4defdafccb34fb09/680x482cq70/roti-o-foto-resep-utama.jpg
author: Sue Stewart
ratingvalue: 4.6
reviewcount: 18910
recipeingredient:
- " Bahan Adonan"
- "300 gram tepung terigu"
- "1 butir kuning telur"
- "100 ml air susu hangat"
- "1 sdm ragi instanfermipan"
- "3 sdm gula pasir boleh lebihkurang"
- "4 sdm mentega"
- " Bahan filling"
- "1 butir putih telur"
- "2 sdm gula halu"
- "4 sdm tepung terigu"
- "4 sdm mentega"
- "4 sdm kopi instan larutkan ke dalam 4 Sdm air panas"
recipeinstructions:
- "Baca Basmallah dan tersenyum :)"
- "Buat adonan: masukan tepung terigu, gula pasir, kuning telur, ragi instan dan air susu hangat. Aduk dan uleni hingga setengah kalis. Lalu masukan mentega dan uleni kembali hingga benar-benar kalis dan adonan bisa elastis tidak sobek."
- "Setelah adonan kalis, tutup rapat dan diamkan selama 20 menit hingga adonan mengembang. Setelah adonan mengembang, lalu kempeskan. Kemudian bagi adonan dan bentuk adonan menjadi bulat dan tata diatas loyang yang sudah diberi alas."
- "Sambil menunggu adonan mengembang dengan sempurna. Langkah selanjutnya yaitu membuat filling: campurkan mentega dan gula halus, lalu mixer dengan kecepatan sedang sampai rata. Lalu tambahkan tepung terigu, putih telur dan kopi aduk hingga semua tercampur rata. Lalu masukan filling ke dalam piping bag/ plastik biasa."
- "Setelah adonan mengembang sempurna, tuang filling keatas permukaan adonan roti dengan gerakan memutar. Lalu panggang dengan api sedang selama 30 menit (Oven tangkring)"
- "Alhamdulilah... roti O Siap dinikmati bersama keluarga ^^ mudah kan, selamat mencoba ♡"
categories:
- Recipe
tags:
- roti
- o

katakunci: roti o 
nutrition: 248 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Dessert

---


![Roti &#39;O](https://img-global.cpcdn.com/recipes/4defdafccb34fb09/680x482cq70/roti-o-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti roti &#39;o yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa ciri khas yang merupakan keragaman Indonesia

Keharmonisan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah memasak Roti &#39;O untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang dapat anda buat salah satunya roti &#39;o yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep roti &#39;o tanpa harus bersusah payah.
Seperti resep Roti &#39;O yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 13 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti &#39;O:

1. Jangan lupa  Bahan Adonan:
1. Harap siapkan 300 gram tepung terigu
1. Harap siapkan 1 butir kuning telur
1. Dibutuhkan 100 ml air susu hangat
1. Tambah 1 sdm ragi instan/fermipan
1. Jangan lupa 3 sdm gula pasir (boleh lebih/kurang)
1. Siapkan 4 sdm mentega
1. Jangan lupa  Bahan filling
1. Tambah 1 butir putih telur
1. Tambah 2 sdm gula halu
1. Diperlukan 4 sdm tepung terigu
1. Jangan lupa 4 sdm mentega
1. Tambah 4 sdm kopi instan larutkan ke dalam 4 Sdm air panas




<!--inarticleads2-->

##### Bagaimana membuat  Roti &#39;O:

1. Baca Basmallah dan tersenyum :)
1. Buat adonan: masukan tepung terigu, gula pasir, kuning telur, ragi instan dan air susu hangat. Aduk dan uleni hingga setengah kalis. Lalu masukan mentega dan uleni kembali hingga benar-benar kalis dan adonan bisa elastis tidak sobek.
1. Setelah adonan kalis, tutup rapat dan diamkan selama 20 menit hingga adonan mengembang. Setelah adonan mengembang, lalu kempeskan. Kemudian bagi adonan dan bentuk adonan menjadi bulat dan tata diatas loyang yang sudah diberi alas.
1. Sambil menunggu adonan mengembang dengan sempurna. Langkah selanjutnya yaitu membuat filling: campurkan mentega dan gula halus, lalu mixer dengan kecepatan sedang sampai rata. Lalu tambahkan tepung terigu, putih telur dan kopi aduk hingga semua tercampur rata. Lalu masukan filling ke dalam piping bag/ plastik biasa.
1. Setelah adonan mengembang sempurna, tuang filling keatas permukaan adonan roti dengan gerakan memutar. Lalu panggang dengan api sedang selama 30 menit (Oven tangkring)
1. Alhamdulilah... roti O Siap dinikmati bersama keluarga ^^ mudah kan, selamat mencoba ♡




Demikianlah cara membuat roti &#39;o yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
