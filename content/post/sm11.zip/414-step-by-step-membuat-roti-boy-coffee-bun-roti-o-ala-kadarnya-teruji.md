---
description: "Step-by-Step membuat Roti boy/coffee bun/ roti o ala kadarnya Teruji"
title: "Step-by-Step membuat Roti boy/coffee bun/ roti o ala kadarnya Teruji"
slug: 414-step-by-step-membuat-roti-boy-coffee-bun-roti-o-ala-kadarnya-teruji
date: 2020-11-23T23:09:58.825Z
image: https://img-global.cpcdn.com/recipes/daf0964ac0300c7e/680x482cq70/roti-boycoffee-bun-roti-o-ala-kadarnya-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/daf0964ac0300c7e/680x482cq70/roti-boycoffee-bun-roti-o-ala-kadarnya-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/daf0964ac0300c7e/680x482cq70/roti-boycoffee-bun-roti-o-ala-kadarnya-foto-resep-utama.jpg
author: Belle Moran
ratingvalue: 4.6
reviewcount: 4286
recipeingredient:
- " Adonan roti"
- "200 gr tepung terigu saya pakai tepung cakra 15 gelas belimbin"
- "2 sdm mentega saya palmia"
- "Sejumput garam"
- "2 sdm gula vanilla secukupnya"
- "1 sdm susu bubuk"
- "1/2 sdm ragi instan baiknya dibanyakin sy raginya kurang"
- "secukupnya Air hangat"
- " Isian"
- "Secukupnya butter"
- "Secukupnya keju parut"
- " Topping kopi"
- "2 sdm tepung terigu kenyataannya saya tambah terus sd 5 sdm"
- "2 sdm gula halus"
- "1 butir telur ambil putihnya"
- "1 sdm kopi instan hasil warna gelap jd bs sesuai selera"
- " Air hangat harusnya ga ushkopi lgsg masukin adonan topping aja"
recipeinstructions:
- "Campurkan satu per satu adonan roti. Kalau bisa raginya dicampur air hangat dl biar kekuatannya bekerja. Pastikan campur sampe rata."
- "Uleni adonan sampai kalis. Harus sabar dan strong"
- "Diamkan selama satu jam adonan hingga mengembang 2x. Jangan lupa tutupi serbet/ plastic wrap"
- "Setelah satu jam, bagi adonan menjadi 6 bagian sama besar."
- "Langkah 4 lgsg bs dikasi filing. Tp saya diamkan lagi karena lagi nyambi kerjaan lain. Intinya tutupin serbet."
- "Setelah langkah 5 selesai kurleb 30 menit, langsung sy kasih filling. Karena hbs itu masih harus didiemin biar ngembang lagi."
- "Pembuatan filing. Ambil adonan. Ratakan. Isi dengan butter dan keju parut."
- "Pembuatan topi. Mixer kecepatan rendah butter dan gula halus sampai ngembang. Tambahkan putih telur. Mixer lagi. Tuang coffe (klo bs ga ush dikasi air gpp). Terakhir tambahkan maizena dan terigu (sambil diayak aja biar ga grindil)."
- "Untuk topping, klo agaik cair memang harus hati2. Karena pas dioven pasti luber. Punya saya tak tambahin terigu terus, jadi ga begitu cair dan ga luber. Masukan ke plastik. Saya diemin di kulkas dlu biar agak semi madet krn takut lumer pas dioven..hehe"
- "Taruh topping di atas adonan yang sudah ditaruh di loyang. Jangan lupa olesi loyang dg mentega. Saya buat jarak rotinya jauh. Takut dempet"
- "Untuk topping semi padet (koloid), baiknya diisi smpai mnutupi roti, karena ga terlalu luber pas dioven"
- "Sajikan hangat enak. Rasanya enak walaupun tampilan masih harus diperbaiki.heh"
categories:
- Recipe
tags:
- roti
- boycoffee
- bun

katakunci: roti boycoffee bun 
nutrition: 270 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dinner

---


![Roti boy/coffee bun/ roti o ala kadarnya](https://img-global.cpcdn.com/recipes/daf0964ac0300c7e/680x482cq70/roti-boycoffee-bun-roti-o-ala-kadarnya-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau gurih. Karasteristik masakan Indonesia roti boy/coffee bun/ roti o ala kadarnya yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Mexican Coffee Bun (Rotiboy) - Sweet bun with coffee topping and butter filling. The word &#34;Mexican&#34; might be misleading but this bun originated from a bakery in Bukit Mertajam, Penang, and now Mexican coffee bun is famous all over Asia, with many bakeries and copycat bakeries selling this. How to make coffee bun/coffee bun recipe/모카번만들기/rotiboy/paparoti. Смотреть позже. Поделиться. Terima Kasih Untuk Video Kerennya Channel Youtube : Arina Ulfa Link.

Kehangatan rumah tangga bisa diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Roti boy/coffee bun/ roti o ala kadarnya untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang dapat anda contoh salah satunya roti boy/coffee bun/ roti o ala kadarnya yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep roti boy/coffee bun/ roti o ala kadarnya tanpa harus bersusah payah.
Seperti resep Roti boy/coffee bun/ roti o ala kadarnya yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 bahan dan 12 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti boy/coffee bun/ roti o ala kadarnya:

1. Harap siapkan  Adonan roti
1. Siapkan 200 gr tepung terigu (saya pakai tepung cakra 1,5 gelas belimbin
1. Tambah 2 sdm mentega (saya palmia)
1. Tambah Sejumput garam
1. Diperlukan 2 sdm gula, vanilla secukupnya
1. Siapkan 1 sdm susu bubuk
1. Harus ada 1/2 sdm ragi instan (baiknya dibanyakin, sy raginya kurang)
1. Harus ada secukupnya Air hangat
1. Siapkan  Isian
1. Siapkan Secukupnya butter
1. Jangan lupa Secukupnya keju parut
1. Tambah  Topping kopi
1. Jangan lupa 2 sdm tepung terigu (kenyataannya saya tambah terus s.d 5 sdm)
1. Siapkan 2 sdm gula halus
1. Dibutuhkan 1 butir telur (ambil putihnya)
1. Siapkan 1 sdm kopi instan (hasil warna gelap, jd bs sesuai selera)
1. Diperlukan  Air hangat (harusnya ga ush-kopi lgsg masukin adonan topping aja


I have been told you can freeze the cooked buns and heat. Lihat juga resep # Roti boy enak lainnya. The coffee bun has a fragrant coffee flavour that comes with a layer of cookie crust on the top whilst the inside is soft and fluffy. Panganan roti dengan model tempurung dan berkulit renyah dengan rasa mentega yang khas ini biasanya dinikmati sebagai menu sarapan atau camilan Nah ternyata kamu bisa bikin coffee bun ala Rotiboy sendiri lho! 

<!--inarticleads2-->

##### Bagaimana membuat  Roti boy/coffee bun/ roti o ala kadarnya:

1. Campurkan satu per satu adonan roti. Kalau bisa raginya dicampur air hangat dl biar kekuatannya bekerja. Pastikan campur sampe rata.
1. Uleni adonan sampai kalis. Harus sabar dan strong
1. Diamkan selama satu jam adonan hingga mengembang 2x. Jangan lupa tutupi serbet/ plastic wrap
1. Setelah satu jam, bagi adonan menjadi 6 bagian sama besar.
1. Langkah 4 lgsg bs dikasi filing. Tp saya diamkan lagi karena lagi nyambi kerjaan lain. Intinya tutupin serbet.
1. Setelah langkah 5 selesai kurleb 30 menit, langsung sy kasih filling. Karena hbs itu masih harus didiemin biar ngembang lagi.
1. Pembuatan filing. Ambil adonan. Ratakan. Isi dengan butter dan keju parut.
1. Pembuatan topi. Mixer kecepatan rendah butter dan gula halus sampai ngembang. Tambahkan putih telur. Mixer lagi. Tuang coffe (klo bs ga ush dikasi air gpp). Terakhir tambahkan maizena dan terigu (sambil diayak aja biar ga grindil).
1. Untuk topping, klo agaik cair memang harus hati2. Karena pas dioven pasti luber. Punya saya tak tambahin terigu terus, jadi ga begitu cair dan ga luber. Masukan ke plastik. Saya diemin di kulkas dlu biar agak semi madet krn takut lumer pas dioven..hehe
1. Taruh topping di atas adonan yang sudah ditaruh di loyang. Jangan lupa olesi loyang dg mentega. Saya buat jarak rotinya jauh. Takut dempet
1. Untuk topping semi padet (koloid), baiknya diisi smpai mnutupi roti, karena ga terlalu luber pas dioven
1. Sajikan hangat enak. Rasanya enak walaupun tampilan masih harus diperbaiki.heh


The coffee bun has a fragrant coffee flavour that comes with a layer of cookie crust on the top whilst the inside is soft and fluffy. Panganan roti dengan model tempurung dan berkulit renyah dengan rasa mentega yang khas ini biasanya dinikmati sebagai menu sarapan atau camilan Nah ternyata kamu bisa bikin coffee bun ala Rotiboy sendiri lho! Yuk intip resep dan cara membuatnya seperti dilansir brilio.net dari cookpad.com. Resep Coffee Bun Roti Boy Anti Gagal. Super Delicious Mexican Coffee Bun Homebake Coffee Butter Bun. 

Demikianlah cara membuat roti boy/coffee bun/ roti o ala kadarnya yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
