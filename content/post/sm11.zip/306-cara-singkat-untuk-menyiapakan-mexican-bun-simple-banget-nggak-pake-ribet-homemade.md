---
description: "Cara singkat untuk menyiapakan Mexican Bun Simple Banget, Nggak Pake Ribet Homemade"
title: "Cara singkat untuk menyiapakan Mexican Bun Simple Banget, Nggak Pake Ribet Homemade"
slug: 306-cara-singkat-untuk-menyiapakan-mexican-bun-simple-banget-nggak-pake-ribet-homemade
date: 2020-10-23T03:33:59.872Z
image: https://img-global.cpcdn.com/recipes/f1e7aef6d82ce4a0/680x482cq70/mexican-bun-simple-banget-nggak-pake-ribet-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f1e7aef6d82ce4a0/680x482cq70/mexican-bun-simple-banget-nggak-pake-ribet-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f1e7aef6d82ce4a0/680x482cq70/mexican-bun-simple-banget-nggak-pake-ribet-foto-resep-utama.jpg
author: Norman Stanley
ratingvalue: 4.1
reviewcount: 44787
recipeingredient:
- " Bahan roti"
- "150 ml air hangat jangan panas ya nanti raginya mati"
- "1 sdt ragi instant"
- "4 sdm gula pasir"
- "225 gram tepung terigu protein tinggi me protein sedang"
- "27 gram susu bubuk atau 1 sachet"
- "1 butir kuning telur"
- "25 gram mentega"
- "1/4 sdt garam"
- " Bahan isian"
- "50 gram mentega"
- "1 sdm gula halus boleh gula pasir"
- " Bahan topping"
- "50 gram mentega"
- "50 gr gula halus boleh gula pasir"
- "70 gram tepung terigu"
- "1-2 sachet coffeemix instan"
- "1 putih telur"
recipeinstructions:
- "Untuk topping, mixer putih telur, mentega, dan gula sampai tercampur rata. Lalu masukkan kopi dan tepung terigu sambil diayak, sisihkan"
- "Untuk isian, aduk rata mentega dan gula, sisihkan"
- "Campur rata air hangat dan 2 sdm gula pasir dalam gelas. Lalu beri ragi instant, diamkan selama 5-10 menit sampai berbuih banyak, tanda ragi aktif (kalau tidak berbuih jangan dipakai ya, nanti adonan nggak ngembang, rotinya bisa bantet)"
- "Campur rata tepung terigu, susu bubuk, sisa gula pasir, dan kuning telur. Lalu masukkan larutan ragi, aduk menggunakan sendok kayu/spatula sampai rata (Nggak usah diulen ya)"
- "Setelah itu masukkan mentega dan garam, aduk menggunakan tangan sampai semua bahan menyatu dengan baik, lalu bulatkan (adonan lengket ya, nggakpapa memang kayak gitu) tutup dengan plastic wrap/serbet lembab, diamkan selama 30-35 menit/ sampai adonan mengembang 2x (kalo saya sampai 1 jam)"
- "Setelah adonan mengembang 2x, lumuri telapak tangan dengan tepung terigu, kempiskan adonan"
- "Taburi meja kerja dengan sedikit tepung terigu, dan jangan lupa (PENTING!) selalu lumuri telapak tangan dengan tepung terigu. Ambil adonan yang tadi dikempiskan, taruh di meja kerja, ulen adonan dengan cara melipat adonan berkali-kali atau dengan cara mencubit cubit adonan agar seratnya bagus, sambil ditaburi tipis tepung terigu. Bagi adonan menjadi beberapa bulatan (saya 12 bulatan)"
- "Tata adonan yang sudah diisi dalam loyang yang sudah di semir tipis dengan mentega jika mau atau dialasi kertas roti. Lalu diamkan kembali kurang lebih 10-15 menit atau sampai adonan mengembang kembali"
- "Beri topping diatas adonan dengan cara seperti digambar (maaf kalo berantakan, kalo bisa buletannya lebih rapet ya...)"
- "Oven dengan suhu 120°C selama ±40-50 menit (sesuaikan dengan oven masing-masing ya, jangan lupa ditukar-tukar posisi. Kalo saya 20 menit diatas dan 20 menit ditengah)"
- "Mexican bun siap untuk disantap..."
- "Berantakan banget ya?"
- "Tapi rasanya nggak usah ditanya, serasa beli di toko-toko"
- "Ini isinya, berserat banget rotinya"
- "Enak dalemnya, kayak ada rasa-rasa asin mentega gitu"
- "...ماشاء الله"
- "Saya saranin pake kopi yang wanginya pekat, soalnya ini punya saya nggak ada bau kopinya sama sekali, cuman berasa kopi doang"
- "Empuk"
- "Sisain buat besok pagi sarapan aja kayaknya lebih enak"
- "Alhamdulillaah..., akhirnya bisa bikin roti boy sendiri. Nggak perlu beli mahal mahal lagi sekarang, tinggal ke dapur aja gampang"
- "Makan satu aja kayaknya nggak cukup deh"
- "Tampak atas"
- "Selamat mencoba..., ditunggu recooknya... : )"
- "Buat lagi..., versi ke-2. Rotinya rasa kopi juga. Biar makin mantap"
- "Kali ini buatnya 14 biji, biar bisa makan lebih banyak (itu yang di gambar baru ada 6 doang, 8 nya belum di oven)"
- "Dalemnya"
- "Kalo bisa kopinya pake nescafe aja ya, biar rasa dan wangi kopinya lebih kecium dan enak"
categories:
- Recipe
tags:
- mexican
- bun
- simple

katakunci: mexican bun simple 
nutrition: 158 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT37M"
recipeyield: "3"
recipecategory: Dessert

---


![Mexican Bun Simple Banget, Nggak Pake Ribet](https://img-global.cpcdn.com/recipes/f1e7aef6d82ce4a0/680x482cq70/mexican-bun-simple-banget-nggak-pake-ribet-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti mexican bun simple banget, nggak pake ribet yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan keistimewahan yang merupakan keragaman Nusantara

Kehangatan keluarga bisa didapat dengan cara simple. Diantaranya adalah memasak Mexican Bun Simple Banget, Nggak Pake Ribet untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang dapat anda buat salah satunya mexican bun simple banget, nggak pake ribet yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep mexican bun simple banget, nggak pake ribet tanpa harus bersusah payah.
Berikut ini resep Mexican Bun Simple Banget, Nggak Pake Ribet yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 27 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Mexican Bun Simple Banget, Nggak Pake Ribet:

1. Tambah  Bahan roti:
1. Harus ada 150 ml air hangat (jangan panas ya nanti raginya mati)
1. Jangan lupa 1 sdt ragi instant
1. Harus ada 4 sdm gula pasir
1. Dibutuhkan 225 gram tepung terigu protein tinggi (me: protein sedang)
1. Harap siapkan 27 gram susu bubuk (atau 1 sachet)
1. Harap siapkan 1 butir kuning telur
1. Diperlukan 25 gram mentega
1. Siapkan 1/4 sdt garam
1. Harus ada  Bahan isian:
1. Jangan lupa 50 gram mentega
1. Siapkan 1 sdm gula halus (boleh gula pasir)
1. Siapkan  Bahan topping:
1. Diperlukan 50 gram mentega
1. Harus ada 50 gr gula halus (boleh gula pasir)
1. Harap siapkan 70 gram tepung terigu
1. Harap siapkan 1-2 sachet coffeemix instan
1. Dibutuhkan 1 putih telur




<!--inarticleads2-->

##### Cara membuat  Mexican Bun Simple Banget, Nggak Pake Ribet:

1. Untuk topping, mixer putih telur, mentega, dan gula sampai tercampur rata. Lalu masukkan kopi dan tepung terigu sambil diayak, sisihkan
1. Untuk isian, aduk rata mentega dan gula, sisihkan
1. Campur rata air hangat dan 2 sdm gula pasir dalam gelas. Lalu beri ragi instant, diamkan selama 5-10 menit sampai berbuih banyak, tanda ragi aktif (kalau tidak berbuih jangan dipakai ya, nanti adonan nggak ngembang, rotinya bisa bantet)
1. Campur rata tepung terigu, susu bubuk, sisa gula pasir, dan kuning telur. Lalu masukkan larutan ragi, aduk menggunakan sendok kayu/spatula sampai rata (Nggak usah diulen ya)
1. Setelah itu masukkan mentega dan garam, aduk menggunakan tangan sampai semua bahan menyatu dengan baik, lalu bulatkan (adonan lengket ya, nggakpapa memang kayak gitu) tutup dengan plastic wrap/serbet lembab, diamkan selama 30-35 menit/ sampai adonan mengembang 2x (kalo saya sampai 1 jam)
1. Setelah adonan mengembang 2x, lumuri telapak tangan dengan tepung terigu, kempiskan adonan
1. Taburi meja kerja dengan sedikit tepung terigu, dan jangan lupa (PENTING!) selalu lumuri telapak tangan dengan tepung terigu. Ambil adonan yang tadi dikempiskan, taruh di meja kerja, ulen adonan dengan cara melipat adonan berkali-kali atau dengan cara mencubit cubit adonan agar seratnya bagus, sambil ditaburi tipis tepung terigu. Bagi adonan menjadi beberapa bulatan (saya 12 bulatan)
1. Tata adonan yang sudah diisi dalam loyang yang sudah di semir tipis dengan mentega jika mau atau dialasi kertas roti. Lalu diamkan kembali kurang lebih 10-15 menit atau sampai adonan mengembang kembali
1. Beri topping diatas adonan dengan cara seperti digambar (maaf kalo berantakan, kalo bisa buletannya lebih rapet ya...)
1. Oven dengan suhu 120°C selama ±40-50 menit (sesuaikan dengan oven masing-masing ya, jangan lupa ditukar-tukar posisi. Kalo saya 20 menit diatas dan 20 menit ditengah)
1. Mexican bun siap untuk disantap...
1. Berantakan banget ya?
1. Tapi rasanya nggak usah ditanya, serasa beli di toko-toko
1. Ini isinya, berserat banget rotinya
1. Enak dalemnya, kayak ada rasa-rasa asin mentega gitu
1. ...ماشاء الله
1. Saya saranin pake kopi yang wanginya pekat, soalnya ini punya saya nggak ada bau kopinya sama sekali, cuman berasa kopi doang
1. Empuk
1. Sisain buat besok pagi sarapan aja kayaknya lebih enak
1. Alhamdulillaah..., akhirnya bisa bikin roti boy sendiri. Nggak perlu beli mahal mahal lagi sekarang, tinggal ke dapur aja gampang
1. Makan satu aja kayaknya nggak cukup deh
1. Tampak atas
1. Selamat mencoba..., ditunggu recooknya... : )
1. Buat lagi..., versi ke-2. Rotinya rasa kopi juga. Biar makin mantap
1. Kali ini buatnya 14 biji, biar bisa makan lebih banyak (itu yang di gambar baru ada 6 doang, 8 nya belum di oven)
1. Dalemnya
1. Kalo bisa kopinya pake nescafe aja ya, biar rasa dan wangi kopinya lebih kecium dan enak




Demikianlah cara membuat mexican bun simple banget, nggak pake ribet yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat simple dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
