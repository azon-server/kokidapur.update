---
description: "Panduan untuk membuat Coffee Bun Favorite"
title: "Panduan untuk membuat Coffee Bun Favorite"
slug: 283-panduan-untuk-membuat-coffee-bun-favorite
date: 2020-10-05T12:19:30.666Z
image: https://img-global.cpcdn.com/recipes/0afeede770780486/680x482cq70/coffee-bun-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0afeede770780486/680x482cq70/coffee-bun-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0afeede770780486/680x482cq70/coffee-bun-foto-resep-utama.jpg
author: Fanny Newman
ratingvalue: 4.1
reviewcount: 17917
recipeingredient:
- " Roti"
- "250 gr tepung protein tinggicakrabread flour"
- "1 sdm susu bubuk saya skip"
- "1/4 sdt bread improver saya skip"
- "2 btr kuning telur"
- "30 gr margarineunsalted butter"
- "40 gr gula halus"
- "7 gr ragiinstant yeast saya 15 sdt"
- "130 ml airsusu putih"
- " Topping"
- "50 gr unsalted butter"
- "50 gr gula halus"
- "1 btr putih telur"
- "50 gr tepung terigu"
- "15 gr tepung maizena"
- "2 sdm kopi instan tanpa ampas seduh dengan air panas"
- " Filling"
- "secukupnya salted butter"
recipeinstructions:
- "Campur ragi dengan sedikit air hangat kuku dan sejumput gula halus (ambil dari takaran resep). Tunggu 10 menit hingga muncul banyak gelembung kecil."
- "Membuat roti: Campurkan semua bahan roti beserta ragi. Uleni hingga kalis. Tutup dengan cling wrap/kain. Diamkan adonan hingga mengembang dua kali lipat sekitar 30 menit."
- "Membuat topping: kocok putih telur hingga putih kaku lalu sisihkan. Pada wadah yang berbeda kocok butter dan gula halus hingga lembut. Matikan mixer. Kemudian masukkan putih telur yang sudah dikocok tadi beserta tepung terigu, maizena, dan kopi instan. Kocok kembali dengan kecepatan rendah sampai tercampur rata. Masukkan adonan topping ke plastik. Simpan di kulkas supaya lebih set."
- "Kempeskan adonan roti yang sudah mengembang, pastikan tidak ada gas di dalam adonan. Timbang adonan masing-masing 50 gr. Bulatkan lalu pipihkan dan beri isian salted butter sekitar 3/4 sdt salted butter. Tutup adonan lalu bulatkan. Bagian yang ditutup tadi hadap bawah. Diamkan lagi sekitar 10 menit sambil nyalakan oven 180° api atas bawah."
- "Gunting ujung plastik topping tadi. Olesi semua roti dengan cara melingkar dari atas seperti obat nyamuk hingga menutupi separuh roti saja. Segera masukkan ke dalam oven selama kurang lebih 15 menit."
- "Sisa adonan topping bisa jadi cookies kopi dengan cara dipanggang di oven kurang lebih 20 menit dengan suhu 150°."
categories:
- Recipe
tags:
- coffee
- bun

katakunci: coffee bun 
nutrition: 183 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dinner

---


![Coffee Bun](https://img-global.cpcdn.com/recipes/0afeede770780486/680x482cq70/coffee-bun-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti coffee bun yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa ciri khas yang merupakan keragaman Nusantara



Kedekatan keluarga bisa diperoleh dengan cara simple. Diantaranya adalah membuat makanan Coffee Bun untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang dapat anda coba salah satunya coffee bun yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep coffee bun tanpa harus bersusah payah.
Seperti resep Coffee Bun yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Coffee Bun:

1. Jangan lupa  Roti
1. Jangan lupa 250 gr tepung protein tinggi/cakra/bread flour
1. Harap siapkan 1 sdm susu bubuk (saya skip)
1. Harus ada 1/4 sdt bread improver (saya skip)
1. Siapkan 2 btr kuning telur
1. Tambah 30 gr margarine/unsalted butter
1. Harus ada 40 gr gula halus
1. Harus ada 7 gr ragi/instant yeast (saya 1.5 sdt)
1. Harus ada 130 ml air/susu putih
1. Siapkan  Topping
1. Dibutuhkan 50 gr unsalted butter
1. Harap siapkan 50 gr gula halus
1. Harap siapkan 1 btr putih telur
1. Harus ada 50 gr tepung terigu
1. Jangan lupa 15 gr tepung maizena
1. Tambah 2 sdm kopi instan (tanpa ampas, seduh dengan air panas)
1. Siapkan  Filling
1. Tambah secukupnya salted butter




<!--inarticleads2-->

##### Cara membuat  Coffee Bun:

1. Campur ragi dengan sedikit air hangat kuku dan sejumput gula halus (ambil dari takaran resep). Tunggu 10 menit hingga muncul banyak gelembung kecil.
1. Membuat roti: Campurkan semua bahan roti beserta ragi. Uleni hingga kalis. Tutup dengan cling wrap/kain. Diamkan adonan hingga mengembang dua kali lipat sekitar 30 menit.
1. Membuat topping: kocok putih telur hingga putih kaku lalu sisihkan. Pada wadah yang berbeda kocok butter dan gula halus hingga lembut. Matikan mixer. Kemudian masukkan putih telur yang sudah dikocok tadi beserta tepung terigu, maizena, dan kopi instan. Kocok kembali dengan kecepatan rendah sampai tercampur rata. Masukkan adonan topping ke plastik. Simpan di kulkas supaya lebih set.
1. Kempeskan adonan roti yang sudah mengembang, pastikan tidak ada gas di dalam adonan. Timbang adonan masing-masing 50 gr. Bulatkan lalu pipihkan dan beri isian salted butter sekitar 3/4 sdt salted butter. Tutup adonan lalu bulatkan. Bagian yang ditutup tadi hadap bawah. Diamkan lagi sekitar 10 menit sambil nyalakan oven 180° api atas bawah.
1. Gunting ujung plastik topping tadi. Olesi semua roti dengan cara melingkar dari atas seperti obat nyamuk hingga menutupi separuh roti saja. Segera masukkan ke dalam oven selama kurang lebih 15 menit.
1. Sisa adonan topping bisa jadi cookies kopi dengan cara dipanggang di oven kurang lebih 20 menit dengan suhu 150°.




Demikianlah cara membuat coffee bun yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
