---
description: "Step-by-Step untuk membuat Roti O teraktual"
title: "Step-by-Step untuk membuat Roti O teraktual"
slug: 378-step-by-step-untuk-membuat-roti-o-teraktual
date: 2020-09-19T03:06:52.823Z
image: https://img-global.cpcdn.com/recipes/158dc0388188e306/680x482cq70/roti-o-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/158dc0388188e306/680x482cq70/roti-o-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/158dc0388188e306/680x482cq70/roti-o-foto-resep-utama.jpg
author: Ralph Hicks
ratingvalue: 4.1
reviewcount: 46049
recipeingredient:
- " Bahan Roti "
- "250 gram tepung cakra"
- "1 butir telor"
- "4 sdm gula pasir"
- "2 sdm susu bubuk dancow"
- "1 sdm margarine"
- "1/4 sdt garam"
- "70 ml susu full cream"
- " Bahan Isian "
- "1 sachet kental manis putih"
- "30 gram keju parut"
- "50 gram margarine"
- " Topping roti "
- "40 gram gula halus"
- "40 gram margarine"
- "50 gram terigu protein sedang"
- "1 sachet kopi nescafe"
- "1/2 sdt perasa moka"
recipeinstructions:
- "Campur ragi instan, 1 sdm gula pasir dan 5 sdm susu cair lalu biarkan 10 hingga mengembang. Lalu dalam wadah campurkan terigu, gula pasir, susu, telur garam aduk rata dan tambahkan ragi instan tadi kemudian campur dan tambahkan susu lalu diaduk dn uleni hingga setengah kalis kemudian tambahkan margarine dan uleni lagi hingga kalis"
- "Kemudian diamkan adonan selama 30 menit"
- "Sambil nunggu adonan, buat isiannya: campur semua bahan isian kemudian masukan dalam plastik segitiga"
- "Kemudian lanjut buat topping rotinya: campur semua bahan topping roti kemudian masukan dalam plastik segitiga."
- "Setelah 30 menit kempiskan adonan dan isi dengan isian roti kemudian tutup rapat dan bulatkan lagi dan di diamkan kembali selama 40 menit hingga mengembang"
- "Setelah 40 menit semprotkan topping roti diatasnya, dengan cara memutar"
- "Kemudian panaskn oven terlebih dahulu dan kemudian panggang selama 25 menit pada suhu 170°c (kenali oven masing)"
- "Setelah matang biarkan dahulu didalam oven biar agak sedikit hangat lalu keluarkan dan siap sajikan. Selamat mencoba ❤"
categories:
- Recipe
tags:
- roti
- o

katakunci: roti o 
nutrition: 291 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dessert

---


![Roti O](https://img-global.cpcdn.com/recipes/158dc0388188e306/680x482cq70/roti-o-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang patut kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti roti o yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan keistimewahan yang merupakan keragaman Indonesia

Keharmonisan keluarga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Roti O untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang bisa anda contoh salah satunya roti o yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep roti o tanpa harus bersusah payah.
Berikut ini resep Roti O yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti O:

1. Diperlukan  Bahan Roti :
1. Harap siapkan 250 gram tepung cakra
1. Siapkan 1 butir telor
1. Dibutuhkan 4 sdm gula pasir
1. Diperlukan 2 sdm susu bubuk dancow
1. Harus ada 1 sdm margarine
1. Tambah 1/4 sdt garam
1. Dibutuhkan 70 ml susu full cream
1. Diperlukan  Bahan Isian :
1. Harus ada 1 sachet kental manis putih
1. Siapkan 30 gram keju parut
1. Siapkan 50 gram margarine
1. Siapkan  Topping roti :
1. Diperlukan 40 gram gula halus
1. Tambah 40 gram margarine
1. Jangan lupa 50 gram terigu protein sedang
1. Tambah 1 sachet kopi nescafe
1. Jangan lupa 1/2 sdt perasa moka




<!--inarticleads2-->

##### Instruksi membuat  Roti O:

1. Campur ragi instan, 1 sdm gula pasir dan 5 sdm susu cair lalu biarkan 10 hingga mengembang. Lalu dalam wadah campurkan terigu, gula pasir, susu, telur garam aduk rata dan tambahkan ragi instan tadi kemudian campur dan tambahkan susu lalu diaduk dn uleni hingga setengah kalis kemudian tambahkan margarine dan uleni lagi hingga kalis
1. Kemudian diamkan adonan selama 30 menit
1. Sambil nunggu adonan, buat isiannya: campur semua bahan isian kemudian masukan dalam plastik segitiga
1. Kemudian lanjut buat topping rotinya: campur semua bahan topping roti kemudian masukan dalam plastik segitiga.
1. Setelah 30 menit kempiskan adonan dan isi dengan isian roti kemudian tutup rapat dan bulatkan lagi dan di diamkan kembali selama 40 menit hingga mengembang
1. Setelah 40 menit semprotkan topping roti diatasnya, dengan cara memutar
1. Kemudian panaskn oven terlebih dahulu dan kemudian panggang selama 25 menit pada suhu 170°c (kenali oven masing)
1. Setelah matang biarkan dahulu didalam oven biar agak sedikit hangat lalu keluarkan dan siap sajikan. Selamat mencoba ❤




Demikianlah cara membuat roti o yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
