---
description: "Step-by-Step menyiapakan Bakul Pedas (Bakwan, kol dan Jengcool) Cepat"
title: "Step-by-Step menyiapakan Bakul Pedas (Bakwan, kol dan Jengcool) Cepat"
slug: 356-step-by-step-menyiapakan-bakul-pedas-bakwan-kol-dan-jengcool-cepat
date: 2020-10-30T14:40:01.155Z
image: https://img-global.cpcdn.com/recipes/6c9be1b42af83eab/680x482cq70/bakul-pedas-bakwan-kol-dan-jengcool-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6c9be1b42af83eab/680x482cq70/bakul-pedas-bakwan-kol-dan-jengcool-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6c9be1b42af83eab/680x482cq70/bakul-pedas-bakwan-kol-dan-jengcool-foto-resep-utama.jpg
author: Sylvia Townsend
ratingvalue: 4.2
reviewcount: 31040
recipeingredient:
- "250 gr tepung terigu"
- "50 gr tepung sagu"
- "250 gr kubis kol"
- "2 batang wortel"
- "5 batang daun bawang"
- "10 buah jengkol"
- "250 gr minyak goreng"
- "10 buah cabe rawit"
- "1 siung bawang putih"
- "5 butir kemiri"
- "1 bungkus masako"
- "1/2 sendok teh garam"
- "300 mil air"
recipeinstructions:
- "Cuci bersih kol dan wortel, daun bawang. Iris tipis-tipis, sisihkan. Sementara itu rebus jengkol selama 15 menit. Dinginkan. Iris tipis-tipis"
- "Tumbuk halus, cabe, bawang putih, kemiri, garam. Masukkan ke dalam wadah yang sudah berisi tepung. Beri air dan masako. Aduk rata"
- "Campur adonan tepung dengan sayuran dan jengkol"
- "Panaskan minyak goreng, dan goreng adonan tepung tipis-tipis di pinggir wajan. (Gunakan api panas biar hasilnya garing). Balik-balik biar merata kuningnya. Angkat. Tiriskan"
- "Sajikan selagi hangat bersama sambel goreng. Hmm selamat menikmati"
categories:
- Recipe
tags:
- bakul
- pedas
- bakwan

katakunci: bakul pedas bakwan 
nutrition: 185 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Lunch

---


![Bakul Pedas (Bakwan, kol dan Jengcool)](https://img-global.cpcdn.com/recipes/6c9be1b42af83eab/680x482cq70/bakul-pedas-bakwan-kol-dan-jengcool-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti bakul pedas (bakwan, kol dan jengcool) yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa keistimewahan yang merupakan keragaman Indonesia

Kehangatan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Bakul Pedas (Bakwan, kol dan Jengcool) untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang bisa anda contoh salah satunya bakul pedas (bakwan, kol dan jengcool) yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya sekarang ini anda bisa dengan cepat menemukan resep bakul pedas (bakwan, kol dan jengcool) tanpa harus bersusah payah.
Berikut ini resep Bakul Pedas (Bakwan, kol dan Jengcool) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 13 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Bakul Pedas (Bakwan, kol dan Jengcool):

1. Tambah 250 gr tepung terigu
1. Jangan lupa 50 gr tepung sagu
1. Harus ada 250 gr kubis (kol)
1. Tambah 2 batang wortel
1. Harap siapkan 5 batang daun bawang
1. Tambah 10 buah jengkol
1. Jangan lupa 250 gr minyak goreng
1. Diperlukan 10 buah cabe rawit
1. Siapkan 1 siung bawang putih
1. Harap siapkan 5 butir kemiri
1. Dibutuhkan 1 bungkus masako
1. Jangan lupa 1/2 sendok teh garam
1. Tambah 300 mil air




<!--inarticleads2-->

##### Cara membuat  Bakul Pedas (Bakwan, kol dan Jengcool):

1. Cuci bersih kol dan wortel, daun bawang. Iris tipis-tipis, sisihkan. Sementara itu rebus jengkol selama 15 menit. Dinginkan. Iris tipis-tipis
1. Tumbuk halus, cabe, bawang putih, kemiri, garam. Masukkan ke dalam wadah yang sudah berisi tepung. Beri air dan masako. Aduk rata
1. Campur adonan tepung dengan sayuran dan jengkol
1. Panaskan minyak goreng, dan goreng adonan tepung tipis-tipis di pinggir wajan. (Gunakan api panas biar hasilnya garing). Balik-balik biar merata kuningnya. Angkat. Tiriskan
1. Sajikan selagi hangat bersama sambel goreng. Hmm selamat menikmati




Demikianlah cara membuat bakul pedas (bakwan, kol dan jengcool) yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
