---
description: "Panduan untuk menyiapakan Pia Kacang Hijau (Teflon) Luar biasa"
title: "Panduan untuk menyiapakan Pia Kacang Hijau (Teflon) Luar biasa"
slug: 271-panduan-untuk-menyiapakan-pia-kacang-hijau-teflon-luar-biasa
date: 2021-03-09T01:28:49.952Z
image: https://img-global.cpcdn.com/recipes/762311ef1a5d95a5/680x482cq70/pia-kacang-hijau-teflon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/762311ef1a5d95a5/680x482cq70/pia-kacang-hijau-teflon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/762311ef1a5d95a5/680x482cq70/pia-kacang-hijau-teflon-foto-resep-utama.jpg
author: Callie Houston
ratingvalue: 4.7
reviewcount: 34641
recipeingredient:
- " Bahan isi "
- "250 gr kacang hijau kupas rendam 2 jam lalu rebus smp matang"
- "2 sct dancow bubuk"
- "10 sdm gula pasir"
- "1 sdt garam"
- "1 sdt vanili"
- " Air 90 ml"
- " Bahan kulit A "
- "300 gr tep terigu"
- "1 sdm gula pasir"
- "Secubit garam"
- "2 sdm margarin"
- "2 sdm butter"
- "2 sdm minyak goreng"
- "Secukupnya air untuk menguleni"
- " Bahan kulit B "
- "100 gr tep terigu"
- "2 sdm margarin"
- "1 sdm minyak sayur"
recipeinstructions:
- "Buat bahan isian:"
- "Kacang hijau kupas di rendam 2 jam, lalu rebus dengan air smp matang (matang ya bukan jd bubur). Kalo masih ada airnya saring. Kemudian blender kacang hijau (sy lebih suka ga terlalu halus)."
- "Dalam teflon masukan kacang hijau yg sdh di blender, air, gula, dancow, garam, vanili. Masak dengan api kecil hingga air surut gula larut, dan bisa di bentuk. Dinginkan kemudian bikin bulat&#34; kecil selera kalian. (sy jd 45 bulatan). masukan kulkas."
- "Buat kulit A, campur semua bahan kecuali air, uleni. Kemudian tambahkan air sedikit&#34;, smp adonan bisa di bentuk bulat bulat, sy jd 24 bulatan."
- "Bahan kulit B, campur semua bahan B kemudian bikin bulat kecil&#34; saja sebanyak 24 bulatan. Yg besar bahan kulit A yg kecil bahan kulit B."
- "Pipihkan bahan kulit A, kemudian diatasnya pipihkan bahan kulit B. Seperti gambar."
- "Masukan bahan isian kacang hijau. Kemudian tutup bulatkan lalu pipihkan. Seperti bentuk pia."
- "Panggang dengan teflon tutup gunakan api sangat kecil. Jika bagian bawah sudah kering lalu balik pia dan panggang lg. Siap di sajikan."
- "Hedehh brapa kali yak itu sy ngetik kata bulat, bulatan, bulatkan. Jd pusing."
- "Sisa bahan isian mau sy bikin buat onde&#34; besok. (kalo rajin)."
categories:
- Recipe
tags:
- pia
- kacang
- hijau

katakunci: pia kacang hijau 
nutrition: 248 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Lunch

---


![Pia Kacang Hijau (Teflon)](https://img-global.cpcdn.com/recipes/762311ef1a5d95a5/680x482cq70/pia-kacang-hijau-teflon-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan gurih. Ciri kuliner Nusantara pia kacang hijau (teflon) yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah memasak Pia Kacang Hijau (Teflon) untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang bisa anda coba salah satunya pia kacang hijau (teflon) yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep pia kacang hijau (teflon) tanpa harus bersusah payah.
Berikut ini resep Pia Kacang Hijau (Teflon) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 19 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Pia Kacang Hijau (Teflon):

1. Harap siapkan  Bahan isi :
1. Jangan lupa 250 gr kacang hijau kupas (rendam 2 jam, lalu rebus smp matang)
1. Siapkan 2 sct dancow bubuk
1. Dibutuhkan 10 sdm gula pasir
1. Tambah 1 sdt garam
1. Harap siapkan 1 sdt vanili
1. Harus ada  Air (90 ml)
1. Diperlukan  Bahan kulit A :
1. Siapkan 300 gr tep terigu
1. Tambah 1 sdm gula pasir
1. Jangan lupa Secubit garam
1. Tambah 2 sdm margarin
1. Dibutuhkan 2 sdm butter
1. Dibutuhkan 2 sdm minyak goreng
1. Diperlukan Secukupnya air untuk menguleni
1. Jangan lupa  Bahan kulit B :
1. Jangan lupa 100 gr tep terigu
1. Harap siapkan 2 sdm margarin
1. Tambah 1 sdm minyak sayur




<!--inarticleads2-->

##### Bagaimana membuat  Pia Kacang Hijau (Teflon):

1. Buat bahan isian:
1. Kacang hijau kupas di rendam 2 jam, lalu rebus dengan air smp matang (matang ya bukan jd bubur). Kalo masih ada airnya saring. Kemudian blender kacang hijau (sy lebih suka ga terlalu halus).
1. Dalam teflon masukan kacang hijau yg sdh di blender, air, gula, dancow, garam, vanili. Masak dengan api kecil hingga air surut gula larut, dan bisa di bentuk. Dinginkan kemudian bikin bulat&#34; kecil selera kalian. (sy jd 45 bulatan). masukan kulkas.
1. Buat kulit A, campur semua bahan kecuali air, uleni. Kemudian tambahkan air sedikit&#34;, smp adonan bisa di bentuk bulat bulat, sy jd 24 bulatan.
1. Bahan kulit B, campur semua bahan B kemudian bikin bulat kecil&#34; saja sebanyak 24 bulatan. Yg besar bahan kulit A yg kecil bahan kulit B.
1. Pipihkan bahan kulit A, kemudian diatasnya pipihkan bahan kulit B. Seperti gambar.
1. Masukan bahan isian kacang hijau. Kemudian tutup bulatkan lalu pipihkan. Seperti bentuk pia.
1. Panggang dengan teflon tutup gunakan api sangat kecil. Jika bagian bawah sudah kering lalu balik pia dan panggang lg. Siap di sajikan.
1. Hedehh brapa kali yak itu sy ngetik kata bulat, bulatan, bulatkan. Jd pusing.
1. Sisa bahan isian mau sy bikin buat onde&#34; besok. (kalo rajin).




Demikianlah cara membuat pia kacang hijau (teflon) yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan teruji, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
