---
description: "Cara membuat Baso Aci Kuah Mercon Cepat"
title: "Cara membuat Baso Aci Kuah Mercon Cepat"
slug: 304-cara-membuat-baso-aci-kuah-mercon-cepat
date: 2020-11-21T14:44:04.437Z
image: https://img-global.cpcdn.com/recipes/4da76f7236b1c8ec/680x482cq70/baso-aci-kuah-mercon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4da76f7236b1c8ec/680x482cq70/baso-aci-kuah-mercon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4da76f7236b1c8ec/680x482cq70/baso-aci-kuah-mercon-foto-resep-utama.jpg
author: Martin Jones
ratingvalue: 5
reviewcount: 48863
recipeingredient:
- "250 gram Tepung sagu"
- "250 gram Tepung Terigu"
- "1 sdt Bawang Putih goreng"
- "1/2 sdt lada bubuk"
- "secukupnya Penyedap rasa"
- " Garam secukupnya minyak goreng secukupnya air hangat secukupnya"
- " Bahan kuah mercon di haluskan"
- "10 Cabe Merah kriting"
- "10 Cabe Rawit merah"
- "2 siung bawang putih"
- "3 siung bawang merah"
- " Tambahan "
- " Bawang goreng seledri klo suka"
recipeinstructions:
- "Satukan Tepung sagu, Tepung terigu, bawang putih goreng, lada, penyedap, Dan garam, tambah air sedikit demi sedikit aduk sampai kalis.setelah kalis cetak sesuai ukuran yang di inginkan, biar rata timbang sesuai ukuran."
- "Didihkan air rebus baso aci yang Sudah di cetak bulat masukkan,klo sudah terapung angkat beri minyak sedikit biar tidak menempel."
- "Untuk kuah Tumis bumbu yang Sudah di haluskan beri penyedap, garam, gula putih secukupnya, Jangan lupa di coba rasanya. Selamat mencoba."
categories:
- Recipe
tags:
- baso
- aci
- kuah

katakunci: baso aci kuah 
nutrition: 285 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Lunch

---


![Baso Aci Kuah Mercon](https://img-global.cpcdn.com/recipes/4da76f7236b1c8ec/680x482cq70/baso-aci-kuah-mercon-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga enak. Ciri makanan Nusantara baso aci kuah mercon yang kaya dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Baso Aci Kuah Mercon untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi makanan yang dapat anda buat salah satunya baso aci kuah mercon yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep baso aci kuah mercon tanpa harus bersusah payah.
Seperti resep Baso Aci Kuah Mercon yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 13 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Baso Aci Kuah Mercon:

1. Diperlukan 250 gram Tepung sagu
1. Siapkan 250 gram Tepung Terigu
1. Harus ada 1 sdt Bawang Putih goreng
1. Siapkan 1/2 sdt lada bubuk
1. Siapkan secukupnya Penyedap rasa
1. Jangan lupa  Garam secukupnya, minyak goreng secukupnya air hangat secukupnya
1. Tambah  Bahan kuah mercon di haluskan
1. Siapkan 10 Cabe Merah kriting
1. Dibutuhkan 10 Cabe Rawit merah
1. Diperlukan 2 siung bawang putih
1. Harap siapkan 3 siung bawang merah
1. Harus ada  Tambahan :
1. Harus ada  Bawang goreng, seledri klo suka




<!--inarticleads2-->

##### Langkah membuat  Baso Aci Kuah Mercon:

1. Satukan Tepung sagu, Tepung terigu, bawang putih goreng, lada, penyedap, Dan garam, tambah air sedikit demi sedikit aduk sampai kalis.setelah kalis cetak sesuai ukuran yang di inginkan, biar rata timbang sesuai ukuran.
1. Didihkan air rebus baso aci yang Sudah di cetak bulat masukkan,klo sudah terapung angkat beri minyak sedikit biar tidak menempel.
1. Untuk kuah Tumis bumbu yang Sudah di haluskan beri penyedap, garam, gula putih secukupnya, Jangan lupa di coba rasanya. Selamat mencoba.




Demikianlah cara membuat baso aci kuah mercon yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
