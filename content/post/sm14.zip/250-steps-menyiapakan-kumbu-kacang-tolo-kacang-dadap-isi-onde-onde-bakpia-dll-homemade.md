---
description: "Steps menyiapakan Kumbu Kacang Tolo/Kacang Dadap (Isi onde-onde/ Bakpia dll) Homemade"
title: "Steps menyiapakan Kumbu Kacang Tolo/Kacang Dadap (Isi onde-onde/ Bakpia dll) Homemade"
slug: 250-steps-menyiapakan-kumbu-kacang-tolo-kacang-dadap-isi-onde-onde-bakpia-dll-homemade
date: 2020-12-22T15:04:30.452Z
image: https://img-global.cpcdn.com/recipes/c61b4ab12841ea56/680x482cq70/kumbu-kacang-tolokacang-dadap-isi-onde-onde-bakpia-dll-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c61b4ab12841ea56/680x482cq70/kumbu-kacang-tolokacang-dadap-isi-onde-onde-bakpia-dll-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c61b4ab12841ea56/680x482cq70/kumbu-kacang-tolokacang-dadap-isi-onde-onde-bakpia-dll-foto-resep-utama.jpg
author: Lillian Reese
ratingvalue: 4.9
reviewcount: 19891
recipeingredient:
- "250 g kacang tolokacang dadap"
- "1/4 buah kelapa parut"
- "250 g gula pasir"
- "1 sdt garam"
- "1 sdt vanilli bubuk"
- "1 lbr daun pandan"
recipeinstructions:
- "Suapkan bahan, cuci kacang tolo lalu rendam.minimal 2 jam lebih lama lebih baik. Rebus air 1 liter stlh mendidih masukkan kacangnya tutup rapat, rebus 5 menit dt mendidih. Matikan kompor diamkan 30 menit, nyalakan lg kompor selama 5 menit."
- "Angkat tiruskan, stlh dingin haluskan dg blender tambahkan 200ml air."
- "Nyalakan blender, jk sdh halus siapkan gula pasir"
- "Tuang kacang yg sdh diblender ke penggorengan, beri parutan kelapa, gula pasir, garam, vanilli, daun pandan. Nyakalan kompor dg api kecil sambil dibolak balik"
- "Jk sdh mulsi mengental jgn ditinggal, aduk terus sampai kalis dan dpt dibentuk. Matikan api, tunggu dingin. Bentuk bulat sesuai selera."
- "Ambil seperlunya, dan lainnya dpt disimpan dikulkas, suatu saat akan dipakai tinggal dikeluarkan dr kulkas."
categories:
- Recipe
tags:
- kumbu
- kacang
- tolokacang

katakunci: kumbu kacang tolokacang 
nutrition: 187 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Lunch

---


![Kumbu Kacang Tolo/Kacang Dadap (Isi onde-onde/ Bakpia dll)](https://img-global.cpcdn.com/recipes/c61b4ab12841ea56/680x482cq70/kumbu-kacang-tolokacang-dadap-isi-onde-onde-bakpia-dll-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang setidaknya kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti kumbu kacang tolo/kacang dadap (isi onde-onde/ bakpia dll) yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Nusantara



Keharmonisan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Kumbu Kacang Tolo/Kacang Dadap (Isi onde-onde/ Bakpia dll) untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang bisa anda contoh salah satunya kumbu kacang tolo/kacang dadap (isi onde-onde/ bakpia dll) yang merupakan resep favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep kumbu kacang tolo/kacang dadap (isi onde-onde/ bakpia dll) tanpa harus bersusah payah.
Berikut ini resep Kumbu Kacang Tolo/Kacang Dadap (Isi onde-onde/ Bakpia dll) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Kumbu Kacang Tolo/Kacang Dadap (Isi onde-onde/ Bakpia dll):

1. Diperlukan 250 g kacang tolo/kacang dadap
1. Dibutuhkan 1/4 buah kelapa parut
1. Dibutuhkan 250 g gula pasir
1. Tambah 1 sdt garam
1. Diperlukan 1 sdt vanilli bubuk
1. Jangan lupa 1 lbr daun pandan




<!--inarticleads2-->

##### Bagaimana membuat  Kumbu Kacang Tolo/Kacang Dadap (Isi onde-onde/ Bakpia dll):

1. Suapkan bahan, cuci kacang tolo lalu rendam.minimal 2 jam lebih lama lebih baik. Rebus air 1 liter stlh mendidih masukkan kacangnya tutup rapat, rebus 5 menit dt mendidih. Matikan kompor diamkan 30 menit, nyalakan lg kompor selama 5 menit.
1. Angkat tiruskan, stlh dingin haluskan dg blender tambahkan 200ml air.
1. Nyalakan blender, jk sdh halus siapkan gula pasir
1. Tuang kacang yg sdh diblender ke penggorengan, beri parutan kelapa, gula pasir, garam, vanilli, daun pandan. Nyakalan kompor dg api kecil sambil dibolak balik
1. Jk sdh mulsi mengental jgn ditinggal, aduk terus sampai kalis dan dpt dibentuk. Matikan api, tunggu dingin. Bentuk bulat sesuai selera.
1. Ambil seperlunya, dan lainnya dpt disimpan dikulkas, suatu saat akan dipakai tinggal dikeluarkan dr kulkas.




Demikianlah cara membuat kumbu kacang tolo/kacang dadap (isi onde-onde/ bakpia dll) yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat simple dan teruji, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
