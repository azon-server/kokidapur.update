---
description: "Bagaimana membuat Lao Po Pia / Wife Cake Luar biasa"
title: "Bagaimana membuat Lao Po Pia / Wife Cake Luar biasa"
slug: 279-bagaimana-membuat-lao-po-pia-wife-cake-luar-biasa
date: 2021-01-09T04:23:27.762Z
image: https://img-global.cpcdn.com/recipes/19882e0aeb2bf242/680x482cq70/lao-po-pia-wife-cake-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/19882e0aeb2bf242/680x482cq70/lao-po-pia-wife-cake-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/19882e0aeb2bf242/680x482cq70/lao-po-pia-wife-cake-foto-resep-utama.jpg
author: Nancy Bowen
ratingvalue: 4
reviewcount: 8222
recipeingredient:
- " water dough "
- "140 gr tepung kunci"
- "25 gr gula pasir halus"
- "50 gr mentega putih"
- "75 ml air suhu ruang"
- " oil dough "
- "100 gr tepung kunci"
- "50 gr mentega putih"
- " isian "
- "150 gr kundur manis  candied winter melon haluskan"
- "40 gr tepung ketan putih rosebrand"
- "25 gr wijen putih panggang 5 menit"
- "50 ml air"
- "5 ml olive oil"
recipeinstructions:
- "Buat adonan water dough:"
- "Campur tepung, mentega putih, gula dan air. Uleni sampai tercampur rata, kalis, elastis dan lembut. Tutup dengan plastik wrap. Diamkan 20 menit."
- "Buat adonan oil dough :"
- "Campurkan tepung dan mentega putih. Uleni sampai rata, lembut dan kalis. Lalu bagi menjadi 12 bagian. Lalu tutupi dengan plastik wrap. Diamkan 20 menit."
- "Bagi water dough menjadi 12 bagian. Bentuk bulat."
- "Pipihkan water dough dengan rolling pin, lalu ambil oil dough dan bungkus dengan water dough sampai tertutup rapat. Bulatkan adonan menjadi 12 bagian adonan kulit."
- "Setelah itu, pipihkan kembali adonan kulit dengan rolling pin secara vertikal, dari atas ke bawah, membentuk memanjang. Lalu gulung adonan dari atas ke bawah."
- "Setelah 12 bagian selesai digulung. Diamkan selama 15-20 menit."
- "Kemudian pipihkan lagi adonan kulit dengan rolling pin memanjang ke arah yang berlawanan dan gulung lagi dari atas ke bawah. Diamkan 15-20 menit."
- "Selama menunggu, buat adonan isian. Campurkan semua bahan menjadi satu, kecuali wijen. Ambil setengah bagian wijen dan campurkan ke adonan isian. Lalu uleni sampai bisa dibentuk. Jika masih terlalu lengket, tambahkan tepung."
- "Bagi adonan isian menjadi 12 bagian."
- "Pipihkan kembali adonan kulit, lalu masukkan isian, dan bungkus kembali membentuk bulat, dan pipihkan."
- "Oleskan dengan kuning telur. Iris bagian tengahnya sedikit. Lalu taburkan dengan biji wijen."
- "Panaskan oven disuhu 180°c. Kemudian panggang selama 20 menit sampai kecoklatan. Angkat, dan dinginkan."
- "Kulitnya renyah dan crispy. Isiannya manis dan lembut."
- ""
categories:
- Recipe
tags:
- lao
- po
- pia

katakunci: lao po pia 
nutrition: 277 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT52M"
recipeyield: "1"
recipecategory: Dinner

---


![Lao Po Pia / Wife Cake](https://img-global.cpcdn.com/recipes/19882e0aeb2bf242/680x482cq70/lao-po-pia-wife-cake-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti lao po pia / wife cake yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan ciri khas yang merupakan keragaman Kita



Kedekatan rumah tangga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak Lao Po Pia / Wife Cake untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang bisa anda coba salah satunya lao po pia / wife cake yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep lao po pia / wife cake tanpa harus bersusah payah.
Berikut ini resep Lao Po Pia / Wife Cake yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 14 bahan dan 16 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Lao Po Pia / Wife Cake:

1. Harus ada  water dough :
1. Diperlukan 140 gr tepung kunci
1. Harus ada 25 gr gula pasir halus
1. Diperlukan 50 gr mentega putih
1. Siapkan 75 ml air suhu ruang
1. Diperlukan  oil dough :
1. Harus ada 100 gr tepung kunci
1. Tambah 50 gr mentega putih
1. Tambah  isian :
1. Dibutuhkan 150 gr kundur manis / candied winter melon, haluskan
1. Siapkan 40 gr tepung ketan putih rosebrand
1. Siapkan 25 gr wijen putih, panggang 5 menit
1. Siapkan 50 ml air
1. Jangan lupa 5 ml olive oil




<!--inarticleads2-->

##### Langkah membuat  Lao Po Pia / Wife Cake:

1. Buat adonan water dough:
1. Campur tepung, mentega putih, gula dan air. Uleni sampai tercampur rata, kalis, elastis dan lembut. Tutup dengan plastik wrap. Diamkan 20 menit.
1. Buat adonan oil dough :
1. Campurkan tepung dan mentega putih. Uleni sampai rata, lembut dan kalis. Lalu bagi menjadi 12 bagian. Lalu tutupi dengan plastik wrap. Diamkan 20 menit.
1. Bagi water dough menjadi 12 bagian. Bentuk bulat.
1. Pipihkan water dough dengan rolling pin, lalu ambil oil dough dan bungkus dengan water dough sampai tertutup rapat. Bulatkan adonan menjadi 12 bagian adonan kulit.
1. Setelah itu, pipihkan kembali adonan kulit dengan rolling pin secara vertikal, dari atas ke bawah, membentuk memanjang. Lalu gulung adonan dari atas ke bawah.
1. Setelah 12 bagian selesai digulung. Diamkan selama 15-20 menit.
1. Kemudian pipihkan lagi adonan kulit dengan rolling pin memanjang ke arah yang berlawanan dan gulung lagi dari atas ke bawah. Diamkan 15-20 menit.
1. Selama menunggu, buat adonan isian. Campurkan semua bahan menjadi satu, kecuali wijen. Ambil setengah bagian wijen dan campurkan ke adonan isian. Lalu uleni sampai bisa dibentuk. Jika masih terlalu lengket, tambahkan tepung.
1. Bagi adonan isian menjadi 12 bagian.
1. Pipihkan kembali adonan kulit, lalu masukkan isian, dan bungkus kembali membentuk bulat, dan pipihkan.
1. Oleskan dengan kuning telur. Iris bagian tengahnya sedikit. Lalu taburkan dengan biji wijen.
1. Panaskan oven disuhu 180°c. Kemudian panggang selama 20 menit sampai kecoklatan. Angkat, dan dinginkan.
1. Kulitnya renyah dan crispy. Isiannya manis dan lembut.
1. 




Demikianlah cara membuat lao po pia / wife cake yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan terbukti, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
