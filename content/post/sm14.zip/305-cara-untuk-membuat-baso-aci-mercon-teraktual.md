---
description: "Cara untuk membuat Baso aci mercon teraktual"
title: "Cara untuk membuat Baso aci mercon teraktual"
slug: 305-cara-untuk-membuat-baso-aci-mercon-teraktual
date: 2020-09-17T07:01:54.520Z
image: https://img-global.cpcdn.com/recipes/25a1d1450088c812/680x482cq70/baso-aci-mercon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/25a1d1450088c812/680x482cq70/baso-aci-mercon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/25a1d1450088c812/680x482cq70/baso-aci-mercon-foto-resep-utama.jpg
author: Corey Bowman
ratingvalue: 4.4
reviewcount: 23280
recipeingredient:
- "250 gr sagu"
- "100 gr terigu"
- " Penyedap rasa"
- " Air hangat"
- " Kuah "
- "3 bawang putih"
- "1 batang daun bawang"
- " Lada bubuk"
- " Penyedap rasa"
- " Garam"
- " Isian "
- "15 biji Cabe jablay"
- "5 bawang putih"
recipeinstructions:
- "Masukan sagu dan penyedap rasa ke dalam wadah lalu siram dengan air hangat aduk hingga rata setelah itu masukan tepung terigu uleni"
- "Tumbuk cabe dan bawang putih untuk isian (untuk isian bebas ya bun, mau di tambah tetelanpun bisa)"
- "Setelah itu bulatkan adonan masukan isian lalu rebus di air dengan campuran minyak lakukan hingga adonan habis"
- "Untuk kuah tumis bawang putih hingga harum masukan ke dlm panci berisi air didihkan lalu masuka potongan daun bawang, penyedap rasa, garam, lada bubuk tes rasa hingga benar2 pas."
- "Sajikan dengan jeruk nipis agar lebih segar 😚"
- ""
categories:
- Recipe
tags:
- baso
- aci
- mercon

katakunci: baso aci mercon 
nutrition: 285 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT46M"
recipeyield: "2"
recipecategory: Dessert

---


![Baso aci mercon](https://img-global.cpcdn.com/recipes/25a1d1450088c812/680x482cq70/baso-aci-mercon-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan enak. Ciri khas makanan Indonesia baso aci mercon yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Baso aci mercon untuk keluarga. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang bisa anda coba salah satunya baso aci mercon yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep baso aci mercon tanpa harus bersusah payah.
Berikut ini resep Baso aci mercon yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 13 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Baso aci mercon:

1. Jangan lupa 250 gr sagu
1. Harus ada 100 gr terigu
1. Dibutuhkan  Penyedap rasa
1. Dibutuhkan  Air hangat
1. Diperlukan  Kuah :
1. Diperlukan 3 bawang putih
1. Tambah 1 batang daun bawang
1. Dibutuhkan  Lada bubuk
1. Harus ada  Penyedap rasa
1. Harus ada  Garam
1. Dibutuhkan  Isian :
1. Tambah 15 biji Cabe jablay
1. Tambah 5 bawang putih




<!--inarticleads2-->

##### Langkah membuat  Baso aci mercon:

1. Masukan sagu dan penyedap rasa ke dalam wadah lalu siram dengan air hangat aduk hingga rata setelah itu masukan tepung terigu uleni
1. Tumbuk cabe dan bawang putih untuk isian (untuk isian bebas ya bun, mau di tambah tetelanpun bisa)
1. Setelah itu bulatkan adonan masukan isian lalu rebus di air dengan campuran minyak lakukan hingga adonan habis
1. Untuk kuah tumis bawang putih hingga harum masukan ke dlm panci berisi air didihkan lalu masuka potongan daun bawang, penyedap rasa, garam, lada bubuk tes rasa hingga benar2 pas.
1. Sajikan dengan jeruk nipis agar lebih segar 😚
1. 




Demikianlah cara membuat baso aci mercon yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan cepat, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
