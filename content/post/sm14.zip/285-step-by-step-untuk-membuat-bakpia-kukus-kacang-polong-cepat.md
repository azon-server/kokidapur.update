---
description: "Step-by-Step untuk membuat Bakpia Kukus Kacang Polong Cepat"
title: "Step-by-Step untuk membuat Bakpia Kukus Kacang Polong Cepat"
slug: 285-step-by-step-untuk-membuat-bakpia-kukus-kacang-polong-cepat
date: 2020-11-09T02:34:16.470Z
image: https://img-global.cpcdn.com/recipes/3fc85db2fbc70aa0/680x482cq70/bakpia-kukus-kacang-polong-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3fc85db2fbc70aa0/680x482cq70/bakpia-kukus-kacang-polong-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3fc85db2fbc70aa0/680x482cq70/bakpia-kukus-kacang-polong-foto-resep-utama.jpg
author: Gordon Barnett
ratingvalue: 4.3
reviewcount: 3601
recipeingredient:
- " Bahan bakpia adonan hijau "
- "50 gr kacang polong"
- "30 ml susu cair"
- "2 butir kuning telur"
- "65 gr tepung terigu"
- " Adonan putih "
- "2 butir putih telur"
- "1/2 sdt SP"
- "75 gula pasir"
- " Bahan isian krim"
- "25 gr kacang polong"
- "60 ml susu cair"
- "50 gr coklat putih"
- "10 gr butter"
- "1/2 sdt SP"
- "1/2 sdt gula pasir optional"
- " Pewarna hijau sesuai selera"
recipeinstructions:
- "Berdoa dulu. Haluskan kacang polong dengan susu, baik untuk adonan isian dan bakpianya."
- "Buat isian. Tuang jus kacang polong dalam panci dengan api kecil sedang, masukkan butter, coklat putih dan gula. Aduk sampai coklat meleleh dan tercampur. Lanjut masukkan SP dan tepung secara bertahap (kurleb 3 kali)"
- "Beri pewarna, aduk rata hingga bentuk krim. Angkat, dinginkan. Taruh di piping bag. Sisihkan."
- "Sekarang kita buat adonan hijau bakpianya. Campur jus kacang polong, telur dan tepung kemudian aduk sampai rata. Sisihkan."
- "Setelah itu buat adonan putih. Kocok dengan kecepatan tinggi, putih telur, SP dan gua sampai pucat (soft peak aja)."
- "Sementara menyiapkan kukusan. Campur adonan hijau dan putih secara bertahap sambil aduk balik."
- "Saya pakai cetakan muffin kertas. Siapkan cetakan yang sudah dioles butter. Tuang setengah sekitar 1 sdm, kukus sekitar 2 menit, beri isian di tengah, tutup dengan adonan bakpia. Lanjut kukus sampai 10 menit. Angkat, dinginkan."
- "Enyakkk...empuk... NOTE : 1. Saat memberi olesan butter, beri yang agak banyak ya agar tidak lengket di cetakan. 2. Pemberian gula di isian ga wajib jika memang sudah manis. 3. Ingat! Kukusan wajib dalam keadaan panas agar matangnya bagus. 4. Jika dipakai Mpasi, gula dan coklat putih diganti madu ya, juga SP di skip. Selamat mencoba... 😉"
categories:
- Recipe
tags:
- bakpia
- kukus
- kacang

katakunci: bakpia kukus kacang 
nutrition: 273 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Lunch

---


![Bakpia Kukus Kacang Polong](https://img-global.cpcdn.com/recipes/3fc85db2fbc70aa0/680x482cq70/bakpia-kukus-kacang-polong-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang dapat kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti bakpia kukus kacang polong yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Indonesia

Keharmonisan rumah tangga bisa didapat dengan cara simple. Diantaranya adalah membuat makanan Bakpia Kukus Kacang Polong untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang dapat anda praktekkan salah satunya bakpia kukus kacang polong yang merupakan resep favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep bakpia kukus kacang polong tanpa harus bersusah payah.
Seperti resep Bakpia Kukus Kacang Polong yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Bakpia Kukus Kacang Polong:

1. Dibutuhkan  Bahan bakpia (adonan hijau) :
1. Harus ada 50 gr kacang polong
1. Siapkan 30 ml susu cair
1. Harus ada 2 butir kuning telur
1. Harap siapkan 65 gr tepung terigu
1. Harap siapkan  (Adonan putih) :
1. Dibutuhkan 2 butir putih telur
1. Tambah 1/2 sdt SP
1. Diperlukan 75 gula pasir
1. Diperlukan  Bahan isian (krim):
1. Siapkan 25 gr kacang polong
1. Harap siapkan 60 ml susu cair
1. Diperlukan 50 gr coklat putih
1. Harap siapkan 10 gr butter
1. Tambah 1/2 sdt SP
1. Siapkan 1/2 sdt gula pasir (optional)
1. Diperlukan  Pewarna hijau (sesuai selera)




<!--inarticleads2-->

##### Langkah membuat  Bakpia Kukus Kacang Polong:

1. Berdoa dulu. Haluskan kacang polong dengan susu, baik untuk adonan isian dan bakpianya.
1. Buat isian. Tuang jus kacang polong dalam panci dengan api kecil sedang, masukkan butter, coklat putih dan gula. Aduk sampai coklat meleleh dan tercampur. Lanjut masukkan SP dan tepung secara bertahap (kurleb 3 kali)
1. Beri pewarna, aduk rata hingga bentuk krim. Angkat, dinginkan. Taruh di piping bag. Sisihkan.
1. Sekarang kita buat adonan hijau bakpianya. Campur jus kacang polong, telur dan tepung kemudian aduk sampai rata. Sisihkan.
1. Setelah itu buat adonan putih. Kocok dengan kecepatan tinggi, putih telur, SP dan gua sampai pucat (soft peak aja).
1. Sementara menyiapkan kukusan. Campur adonan hijau dan putih secara bertahap sambil aduk balik.
1. Saya pakai cetakan muffin kertas. Siapkan cetakan yang sudah dioles butter. Tuang setengah sekitar 1 sdm, kukus sekitar 2 menit, beri isian di tengah, tutup dengan adonan bakpia. Lanjut kukus sampai 10 menit. Angkat, dinginkan.
1. Enyakkk...empuk... NOTE : 1. Saat memberi olesan butter, beri yang agak banyak ya agar tidak lengket di cetakan. 2. Pemberian gula di isian ga wajib jika memang sudah manis. 3. Ingat! Kukusan wajib dalam keadaan panas agar matangnya bagus. 4. Jika dipakai Mpasi, gula dan coklat putih diganti madu ya, juga SP di skip. Selamat mencoba... 😉




Demikianlah cara membuat bakpia kukus kacang polong yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan teruji, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
