---
description: "Panduan untuk membuat Bakpia Ubi Ungu Luar biasa"
title: "Panduan untuk membuat Bakpia Ubi Ungu Luar biasa"
slug: 245-panduan-untuk-membuat-bakpia-ubi-ungu-luar-biasa
date: 2021-01-03T22:54:03.736Z
image: https://img-global.cpcdn.com/recipes/8b703b40674a94f3/680x482cq70/bakpia-ubi-ungu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8b703b40674a94f3/680x482cq70/bakpia-ubi-ungu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8b703b40674a94f3/680x482cq70/bakpia-ubi-ungu-foto-resep-utama.jpg
author: Maggie Ferguson
ratingvalue: 4.4
reviewcount: 44311
recipeingredient:
- " Kulit luar "
- "250 gr terigu protein sedang"
- "30 gr gula halus"
- "100 ml air es"
- "90 gr margarin"
- "5 gr susu bubuk"
- "3 gr garam"
- " Kulit dalam "
- "125 gr terigu protein sedang"
- "75 gr korsvet"
- "5 gr susu bubuk"
- " Filling "
- " Pasta ubi ungu"
recipeinstructions:
- "Siapkan pasta ubi ungu, saya jadi 20 bulatan, @±11 gram           (lihat resep)"
- "Kulit luar : campur semua bahan jadi satu (untuk air tuang sedikit demi sedikit sambil diuleni) lakukan sampai kalis, lalu bagi adonan @±12 gram saya jadi 20 pas"
- "Kulit dalam : campur semua bahan jadi satu sampai berbulir, jika susah menggumpal bisa ditambah sedikit minyak goreng"
- "Ambil satu kulit luar dan pipihkan lalu beri adonan kulit dalam di atasnya, lipat amplop lakukan sampai habis"
- "Ambil satu amplop lalu pipihkan, lipat lagi memanjang Lalu digilas, lakukan sampai tiga kali berlawanan arah, kemudian gulung"
- "Rendam dengan minyak goreng ±15 menit lalu tiriskan"
- "Ambil satu adonan lalu pipihkan dan beri isian, bentuk bulat tertutup rapi, lalu panggang dengan api bawah, rak tengah (sy pakai otrik mito fantasy) suhu 180 derajat Celcius ±15 menit."
- "Keluarkan, balik semua kue dan panggang lagi ±15 menit tetap pakai api bawah, rak tengah"
- "Jika sudah matang biarkan panasnya hilang"
- "Pindahkan ke wadah untuk disajikan"
categories:
- Recipe
tags:
- bakpia
- ubi
- ungu

katakunci: bakpia ubi ungu 
nutrition: 225 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dessert

---


![Bakpia Ubi Ungu](https://img-global.cpcdn.com/recipes/8b703b40674a94f3/680x482cq70/bakpia-ubi-ungu-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang harus kita lestarikan karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti bakpia ubi ungu yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan ciri khas yang merupakan keragaman Nusantara

Keharmonisan rumah tangga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak Bakpia Ubi Ungu untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang bisa anda buat salah satunya bakpia ubi ungu yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep bakpia ubi ungu tanpa harus bersusah payah.
Berikut ini resep Bakpia Ubi Ungu yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 13 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Bakpia Ubi Ungu:

1. Tambah  Kulit luar :
1. Harap siapkan 250 gr terigu protein sedang
1. Siapkan 30 gr gula halus
1. Jangan lupa 100 ml air es
1. Siapkan 90 gr margarin
1. Harus ada 5 gr susu bubuk
1. Harap siapkan 3 gr garam
1. Dibutuhkan  Kulit dalam :
1. Diperlukan 125 gr terigu protein sedang
1. Siapkan 75 gr korsvet
1. Harap siapkan 5 gr susu bubuk
1. Dibutuhkan  Filling :
1. Siapkan  Pasta ubi ungu




<!--inarticleads2-->

##### Langkah membuat  Bakpia Ubi Ungu:

1. Siapkan pasta ubi ungu, saya jadi 20 bulatan, @±11 gram -           (lihat resep)
1. Kulit luar : campur semua bahan jadi satu (untuk air tuang sedikit demi sedikit sambil diuleni) lakukan sampai kalis, lalu bagi adonan @±12 gram saya jadi 20 pas
1. Kulit dalam : campur semua bahan jadi satu sampai berbulir, jika susah menggumpal bisa ditambah sedikit minyak goreng
1. Ambil satu kulit luar dan pipihkan lalu beri adonan kulit dalam di atasnya, lipat amplop lakukan sampai habis
1. Ambil satu amplop lalu pipihkan, lipat lagi memanjang Lalu digilas, lakukan sampai tiga kali berlawanan arah, kemudian gulung
1. Rendam dengan minyak goreng ±15 menit lalu tiriskan
1. Ambil satu adonan lalu pipihkan dan beri isian, bentuk bulat tertutup rapi, lalu panggang dengan api bawah, rak tengah (sy pakai otrik mito fantasy) suhu 180 derajat Celcius ±15 menit.
1. Keluarkan, balik semua kue dan panggang lagi ±15 menit tetap pakai api bawah, rak tengah
1. Jika sudah matang biarkan panasnya hilang
1. Pindahkan ke wadah untuk disajikan




Demikianlah cara membuat bakpia ubi ungu yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan terbukti, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
