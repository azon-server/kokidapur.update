---
description: "Resep : Bapia Ubi (teflon) Favorite"
title: "Resep : Bapia Ubi (teflon) Favorite"
slug: 243-resep-bapia-ubi-teflon-favorite
date: 2021-02-20T19:11:19.020Z
image: https://img-global.cpcdn.com/recipes/7d93f23df1b3486d/680x482cq70/bapia-ubi-teflon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7d93f23df1b3486d/680x482cq70/bapia-ubi-teflon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7d93f23df1b3486d/680x482cq70/bapia-ubi-teflon-foto-resep-utama.jpg
author: Marion Castro
ratingvalue: 5
reviewcount: 32250
recipeingredient:
- " Bahan Kulit"
- "130 gr tepung terigu protein sedang"
- "30 gr gula pasir"
- "30 gr susu bubuk"
- "1 sdt ragi instant"
- "100 ml air hangat atau tidak usah semua"
- "30 gr mentagamargarin"
- "Sejumput garam"
- " Bahan Isi"
- "250 gr ubi putih"
- "30 gr gula pasir"
- "1.5 sdm susu bubuk"
recipeinstructions:
- "Kita siapkan dulu bahan isian. Rebus ubi sampai empuk banget, kemudian hancurkan dengan garpu. Lalu masukkan gula dan susu bubuk, aduk hingga tercampur rata. Sisihkan."
- "Siapkan bahan kulit bapia."
- "Masukkan tepung dan susu dalam wadah sambil diayak. Masukkan juga gula pasir dan ragi. Aduk2 rata. Tuang air hangat sedikit demi sedikit sambil uleni adonan. Tidak usah semua air kalau dirasa sudah setengah kalis. Setelah itu masukkan mentega dan garam. Uleni kembali sampai kalis."
- "Istirahatkan adonan, tutup dengan lap bersih atau plastic wrap selama 30 menit, sampai adonan mengembang (gak sempat photo, tangan masih belepotan hehe)."
- "Setelah 30 menit, kempeskan adonan, bagi menjadi 30 bagian. Saya: jumput saja, bulatkan di atas telapak tangan, lalu pipihkan. Beri sejumput isian ubi di tengahnya, kemudian lipat kulit bapia ke tengah. Rapihkan bentuknya seperti antara bulat dan kotak. (gak sempat photo juga, soalnya lagi ribet dan belepotan :D)"
- "Panggang bapia di atas teflon dengan api kecil. Oles dengan sedikit margarin setiap kali sebelum menaruh bapia baru. Perhatikan bagian bawahnya jangan sampai gosong, balik setelah menguning. Selamat menikmati bapia lembut dan manis :)"
categories:
- Recipe
tags:
- bapia
- ubi
- teflon

katakunci: bapia ubi teflon 
nutrition: 272 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT39M"
recipeyield: "1"
recipecategory: Dinner

---


![Bapia Ubi (teflon)](https://img-global.cpcdn.com/recipes/7d93f23df1b3486d/680x482cq70/bapia-ubi-teflon-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan empuk. Karasteristik masakan Nusantara bapia ubi (teflon) yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Keharmonisan rumah tangga dapat ditemukan dengan cara mudah. Salah satunya adalah memasak Bapia Ubi (teflon) untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda coba salah satunya bapia ubi (teflon) yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep bapia ubi (teflon) tanpa harus bersusah payah.
Berikut ini resep Bapia Ubi (teflon) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 12 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Bapia Ubi (teflon):

1. Siapkan  Bahan Kulit
1. Dibutuhkan 130 gr tepung terigu protein sedang
1. Dibutuhkan 30 gr gula pasir
1. Dibutuhkan 30 gr susu bubuk
1. Diperlukan 1 sdt ragi instant
1. Harap siapkan 100 ml air hangat (atau tidak usah semua
1. Harus ada 30 gr mentaga/margarin
1. Diperlukan Sejumput garam
1. Tambah  Bahan Isi
1. Tambah 250 gr ubi putih
1. Tambah 30 gr gula pasir
1. Diperlukan 1.5 sdm susu bubuk




<!--inarticleads2-->

##### Bagaimana membuat  Bapia Ubi (teflon):

1. Kita siapkan dulu bahan isian. Rebus ubi sampai empuk banget, kemudian hancurkan dengan garpu. Lalu masukkan gula dan susu bubuk, aduk hingga tercampur rata. Sisihkan.
1. Siapkan bahan kulit bapia.
1. Masukkan tepung dan susu dalam wadah sambil diayak. Masukkan juga gula pasir dan ragi. Aduk2 rata. Tuang air hangat sedikit demi sedikit sambil uleni adonan. Tidak usah semua air kalau dirasa sudah setengah kalis. Setelah itu masukkan mentega dan garam. Uleni kembali sampai kalis.
1. Istirahatkan adonan, tutup dengan lap bersih atau plastic wrap selama 30 menit, sampai adonan mengembang (gak sempat photo, tangan masih belepotan hehe).
1. Setelah 30 menit, kempeskan adonan, bagi menjadi 30 bagian. Saya: jumput saja, bulatkan di atas telapak tangan, lalu pipihkan. Beri sejumput isian ubi di tengahnya, kemudian lipat kulit bapia ke tengah. Rapihkan bentuknya seperti antara bulat dan kotak. (gak sempat photo juga, soalnya lagi ribet dan belepotan :D)
1. Panggang bapia di atas teflon dengan api kecil. Oles dengan sedikit margarin setiap kali sebelum menaruh bapia baru. Perhatikan bagian bawahnya jangan sampai gosong, balik setelah menguning. Selamat menikmati bapia lembut dan manis :)




Demikianlah cara membuat bapia ubi (teflon) yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
