---
description: "Cara singkat untuk membuat Bakpia Ubi Ungu terupdate"
title: "Cara singkat untuk membuat Bakpia Ubi Ungu terupdate"
slug: 259-cara-singkat-untuk-membuat-bakpia-ubi-ungu-terupdate
date: 2021-02-07T02:42:24.339Z
image: https://img-global.cpcdn.com/recipes/dd942e2458fef196/680x482cq70/bakpia-ubi-ungu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dd942e2458fef196/680x482cq70/bakpia-ubi-ungu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dd942e2458fef196/680x482cq70/bakpia-ubi-ungu-foto-resep-utama.jpg
author: Mattie Luna
ratingvalue: 4.3
reviewcount: 17872
recipeingredient:
- " Bahan isi"
- "200 gr Ubi ungu kukus haluskan"
- "2 sdm SKM putih"
- "2 sdm gula halus"
- "2 sdm margarine cair"
- " Bahan A"
- "100 gr tepung protein sedang"
- "1/4 sdt garam"
- "50 ml minyak goreng"
- "50 gr margarine me palmia"
- " Bahan B"
- "150 gr tepung protein sedang"
- "50 gr margarine"
- "2 sdm gula pasir"
- "1/4 sdt garam"
- "70 ml air"
recipeinstructions:
- "Kukus Ubi Lalu masukkan semua Bahan isi. Aduk rata. (Aduk selagi Ubi panas ya. Agar teksturnya elastis dan ngga keras)"
- "Bulatkan adonan sisihkan"
- "Campur dan uleni Bahan A sampai kalis, diamkan selama 15 menit."
- "Campur dan uleni Bahan A sampai kalis, diamkan selama 15 menit."
- "Ambil semua adonan A lalu letakkan semua adonan B diatasnya. Gulung dengan rolling pan. Balik lagi sisi nya dan Gulung kembali. Lipat kedalam lalu Gulung kembali sampai menyatu. Lalu Potong2 sesuai selera."
- "Panaskan oven selama 15 menit."
- "Ambil satu potongan adonan, beri isian lalu tutup adonan dan bulatkan. Tata diatas loyang yang sudah diolesi margarine."
- "Oven selama 20 menit dengan api atas bawah. Angkat dan dinginkan..."
categories:
- Recipe
tags:
- bakpia
- ubi
- ungu

katakunci: bakpia ubi ungu 
nutrition: 176 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Dessert

---


![Bakpia Ubi Ungu](https://img-global.cpcdn.com/recipes/dd942e2458fef196/680x482cq70/bakpia-ubi-ungu-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga renyah. Ciri khas kuliner Nusantara bakpia ubi ungu yang penuh dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Bakpia Ubi Ungu untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang bisa anda buat salah satunya bakpia ubi ungu yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep bakpia ubi ungu tanpa harus bersusah payah.
Berikut ini resep Bakpia Ubi Ungu yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Bakpia Ubi Ungu:

1. Diperlukan  Bahan isi:
1. Harap siapkan 200 gr Ubi ungu, kukus haluskan
1. Jangan lupa 2 sdm SKM putih
1. Tambah 2 sdm gula halus
1. Siapkan 2 sdm margarine cair
1. Harus ada  Bahan A:
1. Tambah 100 gr tepung protein sedang
1. Harus ada 1/4 sdt garam
1. Jangan lupa 50 ml minyak goreng
1. Tambah 50 gr margarine (me palmia)
1. Harus ada  Bahan B:
1. Diperlukan 150 gr tepung protein sedang
1. Dibutuhkan 50 gr margarine
1. Harap siapkan 2 sdm gula pasir
1. Harap siapkan 1/4 sdt garam
1. Dibutuhkan 70 ml air




<!--inarticleads2-->

##### Instruksi membuat  Bakpia Ubi Ungu:

1. Kukus Ubi Lalu masukkan semua Bahan isi. Aduk rata. (Aduk selagi Ubi panas ya. Agar teksturnya elastis dan ngga keras)
1. Bulatkan adonan sisihkan
1. Campur dan uleni Bahan A sampai kalis, diamkan selama 15 menit.
1. Campur dan uleni Bahan A sampai kalis, diamkan selama 15 menit.
1. Ambil semua adonan A lalu letakkan semua adonan B diatasnya. Gulung dengan rolling pan. Balik lagi sisi nya dan Gulung kembali. Lipat kedalam lalu Gulung kembali sampai menyatu. Lalu Potong2 sesuai selera.
1. Panaskan oven selama 15 menit.
1. Ambil satu potongan adonan, beri isian lalu tutup adonan dan bulatkan. Tata diatas loyang yang sudah diolesi margarine.
1. Oven selama 20 menit dengan api atas bawah. Angkat dan dinginkan...




Demikianlah cara membuat bakpia ubi ungu yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan cepat, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
