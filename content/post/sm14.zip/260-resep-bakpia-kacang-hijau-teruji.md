---
description: "Resep : Bakpia kacang hijau Teruji"
title: "Resep : Bakpia kacang hijau Teruji"
slug: 260-resep-bakpia-kacang-hijau-teruji
date: 2020-11-20T07:34:48.119Z
image: https://img-global.cpcdn.com/recipes/d612f302d65e202f/680x482cq70/bakpia-kacang-hijau-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d612f302d65e202f/680x482cq70/bakpia-kacang-hijau-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d612f302d65e202f/680x482cq70/bakpia-kacang-hijau-foto-resep-utama.jpg
author: Celia Parks
ratingvalue: 4
reviewcount: 14161
recipeingredient:
- "125 gr tepung terigu protein sedang"
- " 1 Bahan kulit"
- "65 gr tepung terigu protein tinggi"
- "2 sdm gula pasir"
- "1/2 sdt garam"
- "100 ml air"
- "50 ml minyak goreng"
- " Bahan kulit 2"
- "65 gr tepung terigu protein sedang"
- "25 ml minyak goreng"
- "1/2 sdm margarin"
- " Bahan perendam adonan kulit"
- "150 ml minyak goreng"
- " Bahan isi"
- "125 gr kacang hijau"
- "100 gr gula pasir"
- "Sejumput garam"
- "50 ml santan kental"
recipeinstructions:
- "BAHAN ISI: tiriskan kacang hijau yang sudah direndam 1 jam lalu kukus selama 30 menit sampai matang dan empuk, haluskan. Campur dengan gula pasir, garam, santan, dan daun pandan, aduk rata. Masak sambil diaduk hingga kalis. Angkat dan dinginkan. Bulatkan lalu sisihkan"
- "KULIT 1: panaskan air, masukkan gula pasir. Aduk hingga rata dan gula larut. Dinginkan. Campur terigu dan garam. Tuangi air larutan gula lalu uleni hingga rata. Tuang minyak goreng lalu uleni hingga kalis."
- "KULIT 2: campur semua bahan, aduk rata."
- "Bagi adonan masing-masing menjadi 20 bagian. Ambil adonan kulit 1 lalu gilas. Letakkan adonan kulit 2 di atas adonan kulit 1 yang telah digilas. Ratakan."
- "Lipat seperti amplop. Lipat keempat sisinya. Lalu bulatkan"
- "Rendam dalam minyak selama 15 menit"
- "Beri isian dan tutup dengan kulit yang telah digilas. Agar tidak tebal ujung kulit saya gunting"
- "Panggang dengan suhu 170&#39; C selama 15 menit lalu balikkan bakpia dan panggang lagi sampai semua sisinya matang."
categories:
- Recipe
tags:
- bakpia
- kacang
- hijau

katakunci: bakpia kacang hijau 
nutrition: 218 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Lunch

---


![Bakpia kacang hijau](https://img-global.cpcdn.com/recipes/d612f302d65e202f/680x482cq70/bakpia-kacang-hijau-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga renyah. Ciri masakan Indonesia bakpia kacang hijau yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Bakpia kacang hijau untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.

Ini dia cemilan enak khas Yogya yang bikin kita pengen ngeganyem terus. Lihat juga resep Pia isi kacang hijau enak lainnya. Resep &#39;bakpia kacang hijau&#39; paling teruji. Produsen Bakpia Kacang Ijo Kering &#34;Bakpi Berkah&#34; Berpusat Di Sidoarjo melayani.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang dapat anda contoh salah satunya bakpia kacang hijau yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep bakpia kacang hijau tanpa harus bersusah payah.
Berikut ini resep Bakpia kacang hijau yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Bakpia kacang hijau:

1. Harus ada 125 gr tepung terigu protein sedang
1. Harap siapkan  1 Bahan kulit
1. Harus ada 65 gr tepung terigu protein tinggi
1. Harus ada 2 sdm gula pasir
1. Dibutuhkan 1/2 sdt garam
1. Siapkan 100 ml air
1. Jangan lupa 50 ml minyak goreng
1. Siapkan  Bahan kulit 2:
1. Diperlukan 65 gr tepung terigu protein sedang
1. Harus ada 25 ml minyak goreng
1. Tambah 1/2 sdm margarin
1. Siapkan  Bahan perendam adonan kulit:
1. Diperlukan 150 ml minyak goreng
1. Dibutuhkan  Bahan isi:
1. Diperlukan 125 gr kacang hijau
1. Dibutuhkan 100 gr gula pasir
1. Harap siapkan Sejumput garam
1. Harus ada 50 ml santan kental


Nah bagi kamu yang suka mengonsumsi kacang hijau namun bingung cara mengolahnya seperti apa, atau merasa bosan dengan olahan yang. Bakpia Kacang Hijau Tanpa Oven By Peggy Louisa. Resep Tao Sa Kacang Hijau Untuk Isian Kue Kue. Rebus kacang hijau sampai empuk atau lunak. 

<!--inarticleads2-->

##### Cara membuat  Bakpia kacang hijau:

1. BAHAN ISI: tiriskan kacang hijau yang sudah direndam 1 jam lalu kukus selama 30 menit sampai matang dan empuk, haluskan. Campur dengan gula pasir, garam, santan, dan daun pandan, aduk rata. Masak sambil diaduk hingga kalis. Angkat dan dinginkan. Bulatkan lalu sisihkan
1. KULIT 1: panaskan air, masukkan gula pasir. Aduk hingga rata dan gula larut. Dinginkan. Campur terigu dan garam. Tuangi air larutan gula lalu uleni hingga rata. Tuang minyak goreng lalu uleni hingga kalis.
1. KULIT 2: campur semua bahan, aduk rata.
1. Bagi adonan masing-masing menjadi 20 bagian. - Ambil adonan kulit 1 lalu gilas. - Letakkan adonan kulit 2 di atas adonan kulit 1 yang telah digilas. Ratakan.
1. Lipat seperti amplop. Lipat keempat sisinya. Lalu bulatkan
1. Rendam dalam minyak selama 15 menit
1. Beri isian dan tutup dengan kulit yang telah digilas. Agar tidak tebal ujung kulit saya gunting
1. Panggang dengan suhu 170&#39; C selama 15 menit lalu balikkan bakpia dan panggang lagi sampai semua sisinya matang.


Resep Tao Sa Kacang Hijau Untuk Isian Kue Kue. Rebus kacang hijau sampai empuk atau lunak. Jika kacang hijau sudah matang dan empuk, anda bisa langsung menyaring dan meniriskannya. Awal mulanya bakpia diperkenalkan dengan varian kacang hijau saja. Seiring berkembangnya jaman, banyak inovasi dari varian rasa Bakpia yang disuguhkan dipasaran. 

Demikianlah cara membuat bakpia kacang hijau yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan teruji, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
