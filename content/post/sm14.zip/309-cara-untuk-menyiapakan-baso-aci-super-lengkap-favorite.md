---
description: "Cara untuk menyiapakan Baso Aci (Super Lengkap) Favorite"
title: "Cara untuk menyiapakan Baso Aci (Super Lengkap) Favorite"
slug: 309-cara-untuk-menyiapakan-baso-aci-super-lengkap-favorite
date: 2021-02-04T09:10:15.930Z
image: https://img-global.cpcdn.com/recipes/b3d91c231da75825/680x482cq70/baso-aci-super-lengkap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b3d91c231da75825/680x482cq70/baso-aci-super-lengkap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b3d91c231da75825/680x482cq70/baso-aci-super-lengkap-foto-resep-utama.jpg
author: Stephen Jennings
ratingvalue: 4.6
reviewcount: 7681
recipeingredient:
- " Bahan Baso Aci"
- "250 gr Tapioka"
- "150 gr Daging ayam giling"
- "2 sdm Bawang prei yg sudah dirajang halus"
- "2 sdm Bawang putih yg sudah dihaluskan"
- "Secukupnya garam dan penyedap rasa"
- "Secukupnya air"
- " Bahan Tahu Aci Kering"
- "10 buah Tahu goreng"
- "250 gr Tapioka"
- "2 sdm Bawang prei yg sudah dirajang halus"
- "1 sdm Bawang putih yg sudah dihaluskan"
- "Secukupnya garam dan penyedap rasa"
- "Secukupnya air"
- " Bahan Cuankie Lidah"
- "250 gr Tapioka"
- "100 gr Daging ayam gilingikan giling"
- "1 sdm Bawang putih yang sudah dihalusnya"
- "Secukupnya garam dan penyedap rasa"
- "Secukupnya air"
- " Bahan Pilus Cikur"
- "250 gr Tapioka"
- "2 ruas Kencur yg sudah dihaluskan"
- "1 sdm Bawang putih yg sudah dihaluskan"
- "Secukupnya garam dan penyedap rasa"
- "Secukupnya air"
- " Bahn Bumbu Kuah Boci"
- "30 buah Cabe merah keriting"
- "15 buah Cabe setan"
- "15 siung bawang putih"
- "10 siung bawang merah"
- "2 bungkus bumbu sop butiran"
- "Secukupnya gula garam dan penyedap rasa"
recipeinstructions:
- "Cara membuat baso aci: didalam mangkuk, campur tapioka kering dengan bawang prei, aduk rata. Sisihkan"
- "Lalu, didihkan air bersama dengan 1sdm bawang putih halus, tambahkan garam dan penyedap rasa secukupnya. Setelah itu tuang air panas perlahan-lahan kedalam adonan kering tadi, aduk dengan cepat menggunakan spatula, tidak apa-apa jika masih ada bagian adonan kering yg tidak terkena air. Setelah dirasa cukup airnya, diamkan selama 15 menitan agar adonan tidak terlalu panas untuk diuleni dengan tangan."
- "Setelah agak dingin, uleni adonan dengan tangan sampai benar-benar kalis seperti playdoh. Sisihkan."
- "Tumis daging ayam giling tadi dengan sedikit minyak dan 1sdm bawang putih halus, tambahkan garam dan penyedap rasa. Tumis sampai sedikit kering. Sisihkan"
- "Bentuk bulat2 kecil adonan bakso aci tadi, lalu pipihkan terus isi dengan tumisan ayam giling secukupnya. Bulatkan lagi sampai semua permukaan tertutup. Lakukan sampai habis ya."
- "Rebus baso aci dengan air yg sudah ditambah sedikit minyak agar tidak lengket, tunggu hingga semua baso mengapung ke atas. Angkat, sisihkan."
- "Cara membuat tahu aci kering: campur tapioka dengan bawang prei, aduk rata. Sisihkan"
- "Didihkan air lalu campur dengan bawang putih halus tadi, terakhir masukan garam dan penyedap rasa sesuai selera. Tuang didihan air kedalam campuran tepung kering tadi, sampai adonanya tercampur rata dan lembut. Sisihkan."
- "Potong-potong tahu goreng silang menjadi 4 bagian, lalu tiap sisi potong lagi menjadi dua bagian."
- "Olesi permukaan tahu yang putih dengan adonan aci tadi diatasnya. Tekan-tekan agar melekat tidak mudah lepas saat digoreng nanti. Lakukan sampai habis ya."
- "Panaskan minyak goreng agak banyak dengan api sedang, setelah agak panas masukan adonan tahu tadi perlahan. Lalu kecilkan api, goreng hingga garing. Setelah kecoklatan, angkat. Sisihkan."
- "Cara membuat cuankie lidah: campur tepung kering dengan daging ayam lalu sisihkan. Didihkan air dengan bawang putih halus lalu tambahkan dengan garam dan penyedap rasa sesuai selera."
- "Tuangkan air mendidih kedalam campuran tepung dan ayam tadi, aduk cepat sampai rata."
- "Lalu panaskan minyak agak banyak dengan api sedang menuju kecil, ambil sedikit adonan lalu pulung menggunakan tangan sampai panjang lalu cetak garis memanjang menggunakan garpu seperti ini. Bentuk sampai habis ya."
- "Setelah itu goreng hingga kecoklatan. Angkat, sisihkan."
- "Cara membuat pilus cikur: didihkan air dengan kencur dan bawang putih halus, lalu tambahkan garam dan penyedap rasa."
- "Tuang perlahan air mendidih kedalam tapioka, aduk dengan cepat menggunakan spatula, tidak apa-apa jika masih ada bagian adonan kering yg tidak terkena air. Setelah dirasa cukup airnya, diamkan selama 15 menitan agar adonan tidak terlalu panas untuk diuleni dengan tangan."
- "Setelah agak dingin, uleni adonan dengan tangan sampai benar-benar kalis seperti playdoh."
- "Ambil sedikit adonan, lalu pulung memanjang diatas talenan. setelah itu potong kecil-kecil adonan dengan ujung sendok. Setelah itu, letak diatas tray yang sudah ditaburi tapioka, agar tidak saling lengket satu sama lain. Lakukan sampai habis."
- "Siapkan minyak didalam penggorengan, api kompor jangan dihidupkan dulu. Lalu masukan adonan cikur tadi kedalam minyak dingin. Baru nyalakan kompor dengan api kecil. Masak hingga semua pilus cikur mengeras dan gelembung minyak hilang kira-kira 20 menitan. Angkat, sisihkan. Setelah dingin, masukan kedalam wadah kedap udara agar tidak melempam cikurnya."
- "Cara membuat bumbu kuah boci: blender semua bumbu jadi satu, lalu tumis sampai harum dan langu sekitar 15 menit dengan api sedang menuju kecil, jangan lupa tambahkan gula, garam dan penyedap rasa. Sebaiknya penggunaaanya agak sedikit banyak, gapapa asin, kan nanti bakal dicampur air kaldu hehe. (Tips: semakin lama menumis dengan api kecil, semakin enak bumbu yg dihasilkan)"
- "Setelah bumbu ditumis, angkat. Lalu tunggu dingin. Setelah dingin, simpan dalam wadah kedap udara."
- "Cara membuat kuah kaldu : didihkan air, bawang prei halus dan tulang ayam dalam panci. Jangan lupa tambahkan 2 siung bawang putih yg sudah di geprek agar kuah kaldunya semakin harum. Oiya masukan sejumput garam. Aduk rata, tunggu hingga mendidih dan air sedikit menyusut."
- "Jika ingin menyajikan, sebaiknya ambil sedikit bumbu boci tadi, campur dengan kuah kaldu. Terus tambahin deh isian baso acinya tadi, tata dimangkuk bersamaan. Buatnya emang sedikit ribet, tapi hasilnya ga bakal ngecewain deh 😊. Selamat mencobaaaaaa❤️"
categories:
- Recipe
tags:
- baso
- aci
- super

katakunci: baso aci super 
nutrition: 141 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Dessert

---


![Baso Aci (Super Lengkap)](https://img-global.cpcdn.com/recipes/b3d91c231da75825/680x482cq70/baso-aci-super-lengkap-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti baso aci (super lengkap) yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Kita

Keharmonisan keluarga dapat diperoleh dengan cara simple. Diantaranya adalah membuat makanan Baso Aci (Super Lengkap) untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang bisa anda contoh salah satunya baso aci (super lengkap) yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep baso aci (super lengkap) tanpa harus bersusah payah.
Seperti resep Baso Aci (Super Lengkap) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 24 langkah dan 33 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Baso Aci (Super Lengkap):

1. Jangan lupa  Bahan Baso Aci
1. Jangan lupa 250 gr Tapioka
1. Diperlukan 150 gr Daging ayam giling
1. Harap siapkan 2 sdm Bawang prei yg sudah dirajang halus
1. Siapkan 2 sdm Bawang putih yg sudah dihaluskan
1. Dibutuhkan Secukupnya garam dan penyedap rasa
1. Harus ada Secukupnya air
1. Tambah  Bahan Tahu Aci Kering
1. Harus ada 10 buah Tahu goreng
1. Jangan lupa 250 gr Tapioka
1. Harus ada 2 sdm Bawang prei yg sudah dirajang halus
1. Jangan lupa 1 sdm Bawang putih yg sudah dihaluskan
1. Tambah Secukupnya garam dan penyedap rasa
1. Siapkan Secukupnya air
1. Diperlukan  Bahan Cuankie Lidah
1. Siapkan 250 gr Tapioka
1. Diperlukan 100 gr Daging ayam giling/ikan giling
1. Diperlukan 1 sdm Bawang putih yang sudah dihalusnya
1. Jangan lupa Secukupnya garam dan penyedap rasa
1. Harap siapkan Secukupnya air
1. Dibutuhkan  Bahan Pilus Cikur
1. Dibutuhkan 250 gr Tapioka
1. Harap siapkan 2 ruas Kencur yg sudah dihaluskan
1. Diperlukan 1 sdm Bawang putih yg sudah dihaluskan
1. Jangan lupa Secukupnya garam dan penyedap rasa
1. Jangan lupa Secukupnya air
1. Jangan lupa  Bahn Bumbu Kuah Boci
1. Diperlukan 30 buah Cabe merah keriting
1. Siapkan 15 buah Cabe setan
1. Siapkan 15 siung bawang putih
1. Jangan lupa 10 siung bawang merah
1. Harus ada 2 bungkus bumbu sop butiran
1. Dibutuhkan Secukupnya gula, garam dan penyedap rasa




<!--inarticleads2-->

##### Instruksi membuat  Baso Aci (Super Lengkap):

1. Cara membuat baso aci: didalam mangkuk, campur tapioka kering dengan bawang prei, aduk rata. Sisihkan
1. Lalu, didihkan air bersama dengan 1sdm bawang putih halus, tambahkan garam dan penyedap rasa secukupnya. Setelah itu tuang air panas perlahan-lahan kedalam adonan kering tadi, aduk dengan cepat menggunakan spatula, tidak apa-apa jika masih ada bagian adonan kering yg tidak terkena air. Setelah dirasa cukup airnya, diamkan selama 15 menitan agar adonan tidak terlalu panas untuk diuleni dengan tangan.
1. Setelah agak dingin, uleni adonan dengan tangan sampai benar-benar kalis seperti playdoh. Sisihkan.
1. Tumis daging ayam giling tadi dengan sedikit minyak dan 1sdm bawang putih halus, tambahkan garam dan penyedap rasa. Tumis sampai sedikit kering. Sisihkan
1. Bentuk bulat2 kecil adonan bakso aci tadi, lalu pipihkan terus isi dengan tumisan ayam giling secukupnya. Bulatkan lagi sampai semua permukaan tertutup. Lakukan sampai habis ya.
1. Rebus baso aci dengan air yg sudah ditambah sedikit minyak agar tidak lengket, tunggu hingga semua baso mengapung ke atas. Angkat, sisihkan.
1. Cara membuat tahu aci kering: campur tapioka dengan bawang prei, aduk rata. Sisihkan
1. Didihkan air lalu campur dengan bawang putih halus tadi, terakhir masukan garam dan penyedap rasa sesuai selera. Tuang didihan air kedalam campuran tepung kering tadi, sampai adonanya tercampur rata dan lembut. Sisihkan.
1. Potong-potong tahu goreng silang menjadi 4 bagian, lalu tiap sisi potong lagi menjadi dua bagian.
1. Olesi permukaan tahu yang putih dengan adonan aci tadi diatasnya. Tekan-tekan agar melekat tidak mudah lepas saat digoreng nanti. Lakukan sampai habis ya.
1. Panaskan minyak goreng agak banyak dengan api sedang, setelah agak panas masukan adonan tahu tadi perlahan. Lalu kecilkan api, goreng hingga garing. Setelah kecoklatan, angkat. Sisihkan.
1. Cara membuat cuankie lidah: campur tepung kering dengan daging ayam lalu sisihkan. Didihkan air dengan bawang putih halus lalu tambahkan dengan garam dan penyedap rasa sesuai selera.
1. Tuangkan air mendidih kedalam campuran tepung dan ayam tadi, aduk cepat sampai rata.
1. Lalu panaskan minyak agak banyak dengan api sedang menuju kecil, ambil sedikit adonan lalu pulung menggunakan tangan sampai panjang lalu cetak garis memanjang menggunakan garpu seperti ini. Bentuk sampai habis ya.
1. Setelah itu goreng hingga kecoklatan. Angkat, sisihkan.
1. Cara membuat pilus cikur: didihkan air dengan kencur dan bawang putih halus, lalu tambahkan garam dan penyedap rasa.
1. Tuang perlahan air mendidih kedalam tapioka, aduk dengan cepat menggunakan spatula, tidak apa-apa jika masih ada bagian adonan kering yg tidak terkena air. Setelah dirasa cukup airnya, diamkan selama 15 menitan agar adonan tidak terlalu panas untuk diuleni dengan tangan.
1. Setelah agak dingin, uleni adonan dengan tangan sampai benar-benar kalis seperti playdoh.
1. Ambil sedikit adonan, lalu pulung memanjang diatas talenan. setelah itu potong kecil-kecil adonan dengan ujung sendok. Setelah itu, letak diatas tray yang sudah ditaburi tapioka, agar tidak saling lengket satu sama lain. Lakukan sampai habis.
1. Siapkan minyak didalam penggorengan, api kompor jangan dihidupkan dulu. Lalu masukan adonan cikur tadi kedalam minyak dingin. Baru nyalakan kompor dengan api kecil. Masak hingga semua pilus cikur mengeras dan gelembung minyak hilang kira-kira 20 menitan. Angkat, sisihkan. Setelah dingin, masukan kedalam wadah kedap udara agar tidak melempam cikurnya.
1. Cara membuat bumbu kuah boci: blender semua bumbu jadi satu, lalu tumis sampai harum dan langu sekitar 15 menit dengan api sedang menuju kecil, jangan lupa tambahkan gula, garam dan penyedap rasa. Sebaiknya penggunaaanya agak sedikit banyak, gapapa asin, kan nanti bakal dicampur air kaldu hehe. (Tips: semakin lama menumis dengan api kecil, semakin enak bumbu yg dihasilkan)
1. Setelah bumbu ditumis, angkat. Lalu tunggu dingin. Setelah dingin, simpan dalam wadah kedap udara.
1. Cara membuat kuah kaldu : didihkan air, bawang prei halus dan tulang ayam dalam panci. Jangan lupa tambahkan 2 siung bawang putih yg sudah di geprek agar kuah kaldunya semakin harum. Oiya masukan sejumput garam. Aduk rata, tunggu hingga mendidih dan air sedikit menyusut.
1. Jika ingin menyajikan, sebaiknya ambil sedikit bumbu boci tadi, campur dengan kuah kaldu. Terus tambahin deh isian baso acinya tadi, tata dimangkuk bersamaan. Buatnya emang sedikit ribet, tapi hasilnya ga bakal ngecewain deh 😊. Selamat mencobaaaaaa❤️




Demikianlah cara membuat baso aci (super lengkap) yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan cepat, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
