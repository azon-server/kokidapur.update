---
description: "Steps menyiapakan Baso Aci Mercon Terbukti"
title: "Steps menyiapakan Baso Aci Mercon Terbukti"
slug: 300-steps-menyiapakan-baso-aci-mercon-terbukti
date: 2020-12-22T08:16:27.642Z
image: https://img-global.cpcdn.com/recipes/9140b4d562960ad3/680x482cq70/baso-aci-mercon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9140b4d562960ad3/680x482cq70/baso-aci-mercon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9140b4d562960ad3/680x482cq70/baso-aci-mercon-foto-resep-utama.jpg
author: Vincent Coleman
ratingvalue: 4.7
reviewcount: 26251
recipeingredient:
- "200 gr tepung tapioka"
- "200 gr tepung terigu"
- "6 siung bawang putih haluskan"
- "1 sachet masako sapi"
- "1 sdm garam"
- "Secukupnya lada bubuk"
- "2 batang sledri"
- "Secukupnya air panas"
- " Bahan Isian "
- "20 biji cabe rawit domba direbus"
- " Bahan kuah "
- "5 siung bawang putih"
- "3 siung bawang merah"
- "Secukupnya garam penyedap lada bubuk"
- " Toping "
- " Pilus sukro"
- " Cuanki lidah Cuanki Tahu siomay"
- " Cabe bubuk Homemade liat di resep sebelumnya"
- " Jeruk limau"
recipeinstructions:
- "Campurkan duo tepung masukan masako, garam, lada bubuk dan sledri aduk rata, didihkan air beri bawang putih. Setelah mendidih tuang sedikit&#34; ke adonan tepung sambil di uleni kalo panas bisa pake sendok ya. Uleni sampe kalis dan bisa di bentuk"
- "Ambil adonan secukupnya kemudian pipihkan Kasih isian cabe rawit domba nya lalu bulat&#34;kan, sebagian di poloskan."
- "Rebus baso aci sampe mengapung, tiriskan jangan lupa rebus nya kasih minyak ya biar gk nempel&#34;,"
- "Tumis bahan kuah sampe harum beri air secukupnya, masukan baso aci nya tunggu sampe matang -+ 3 menit"
- "Angkat dan masukan ke mangkok tata dengan toping nya biar makin cantik ya, toping sesuai selera. Mantep bener&#34; pedes yg suka pedes boleh coba deh 😁"
categories:
- Recipe
tags:
- baso
- aci
- mercon

katakunci: baso aci mercon 
nutrition: 128 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dessert

---


![Baso Aci Mercon](https://img-global.cpcdn.com/recipes/9140b4d562960ad3/680x482cq70/baso-aci-mercon-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas hingga gurih. Ciri masakan Indonesia baso aci mercon yang penuh dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Keharmonisan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Baso Aci Mercon untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang bisa anda buat salah satunya baso aci mercon yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep baso aci mercon tanpa harus bersusah payah.
Berikut ini resep Baso Aci Mercon yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Baso Aci Mercon:

1. Siapkan 200 gr tepung tapioka
1. Jangan lupa 200 gr tepung terigu
1. Jangan lupa 6 siung bawang putih, haluskan
1. Siapkan 1 sachet masako sapi
1. Harap siapkan 1 sdm garam
1. Siapkan Secukupnya lada bubuk
1. Diperlukan 2 batang sledri
1. Harap siapkan Secukupnya air panas
1. Dibutuhkan  Bahan Isian :
1. Harap siapkan 20 biji cabe rawit domba, direbus
1. Harap siapkan  Bahan kuah :
1. Tambah 5 siung bawang putih
1. Diperlukan 3 siung bawang merah
1. Jangan lupa Secukupnya garam, penyedap, lada bubuk
1. Diperlukan  Toping :
1. Siapkan  Pilus sukro
1. Dibutuhkan  Cuanki lidah, Cuanki Tahu, siomay
1. Siapkan  Cabe bubuk Homemade liat di resep sebelumnya
1. Harap siapkan  Jeruk limau




<!--inarticleads2-->

##### Cara membuat  Baso Aci Mercon:

1. Campurkan duo tepung masukan masako, garam, lada bubuk dan sledri aduk rata, didihkan air beri bawang putih. Setelah mendidih tuang sedikit&#34; ke adonan tepung sambil di uleni kalo panas bisa pake sendok ya. Uleni sampe kalis dan bisa di bentuk
1. Ambil adonan secukupnya kemudian pipihkan Kasih isian cabe rawit domba nya lalu bulat&#34;kan, sebagian di poloskan.
1. Rebus baso aci sampe mengapung, tiriskan jangan lupa rebus nya kasih minyak ya biar gk nempel&#34;,
1. Tumis bahan kuah sampe harum beri air secukupnya, masukan baso aci nya tunggu sampe matang -+ 3 menit
1. Angkat dan masukan ke mangkok tata dengan toping nya biar makin cantik ya, toping sesuai selera. Mantep bener&#34; pedes yg suka pedes boleh coba deh 😁




Demikianlah cara membuat baso aci mercon yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
