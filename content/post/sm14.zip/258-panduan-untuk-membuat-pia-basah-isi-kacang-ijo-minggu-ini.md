---
description: "Panduan untuk membuat Pia Basah isi Kacang Ijo minggu ini"
title: "Panduan untuk membuat Pia Basah isi Kacang Ijo minggu ini"
slug: 258-panduan-untuk-membuat-pia-basah-isi-kacang-ijo-minggu-ini
date: 2020-10-21T19:08:42.250Z
image: https://img-global.cpcdn.com/recipes/97c40b8b68561d0d/680x482cq70/pia-basah-isi-kacang-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/97c40b8b68561d0d/680x482cq70/pia-basah-isi-kacang-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/97c40b8b68561d0d/680x482cq70/pia-basah-isi-kacang-ijo-foto-resep-utama.jpg
author: Francis Pratt
ratingvalue: 4.9
reviewcount: 3235
recipeingredient:
- " Kulit"
- "250 terigu protein sedang sy pakai all purpose"
- "1 1/2 sdt ragi instan setengah bungkus"
- "50 g gula pasir"
- "1/2 sdt garam"
- "35 g margarin"
- "125 ml air"
- " Isian"
- "150 g kacang ijo"
- "75 g gula pasir"
- "1/4 sdt garam"
- "1 1/2 sdm minyak goreng"
- "1 lembar daun pandan"
recipeinstructions:
- "Isian : rebus kacang hijau sampai empuk, angkat dan tiriskan, kemudian haluskan. Masak bersama gula pasir (saya pakai sedikit gula merah), garam dan pandan. Aduk terus sampai kacang hijau menjadi kering dan kalis. Dinginkan. Bentuk bulat bulat."
- "Kulit : campur tepung, ragi dan gula pasir. Aduk rata."
- "Masukkan air hangat, uleni hingga rata adonannya"
- "Masukkan margarin dan garam, uleni lagi sampai kalis elastis."
- "Bulatkan adonan, tutup dengan kain lembab lalu fermentasikan 45 menit (aku 30 menit)."
- "Kempiskan adonan dan timbang masing-masing 15 gr, beri isian kacang ijo lalu tutup bentuk bulat dan pipihkan. Letakkan di loyang tanpa olesan (sy pakai kertas roti dibawahnya). Beri jarak karena roti ini akan mengembang sedikit."
- "Diamkan 15 menit. Panggang dengan oven suhu 180 C selama 10 menit."
- "Keluarkan dari oven dan balik. Masukkan ke dalam oven lagi lalu panggang selama 5 menit. Angkat. Pake teflon? Bisa juga!"
categories:
- Recipe
tags:
- pia
- basah
- isi

katakunci: pia basah isi 
nutrition: 181 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dinner

---


![Pia Basah isi Kacang Ijo](https://img-global.cpcdn.com/recipes/97c40b8b68561d0d/680x482cq70/pia-basah-isi-kacang-ijo-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti pia basah isi kacang ijo yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan ciri khas yang merupakan keragaman Indonesia



Kedekatan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Pia Basah isi Kacang Ijo untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang bisa anda contoh salah satunya pia basah isi kacang ijo yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep pia basah isi kacang ijo tanpa harus bersusah payah.
Berikut ini resep Pia Basah isi Kacang Ijo yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Pia Basah isi Kacang Ijo:

1. Harus ada  Kulit
1. Dibutuhkan 250 terigu protein sedang (sy pakai all purpose)
1. Diperlukan 1 1/2 sdt ragi instan/ setengah bungkus
1. Harus ada 50 g gula pasir
1. Siapkan 1/2 sdt garam
1. Harus ada 35 g margarin
1. Tambah 125 ml air
1. Tambah  Isian
1. Dibutuhkan 150 g kacang ijo
1. Siapkan 75 g gula pasir
1. Diperlukan 1/4 sdt garam
1. Diperlukan 1 1/2 sdm minyak goreng
1. Harap siapkan 1 lembar daun pandan




<!--inarticleads2-->

##### Bagaimana membuat  Pia Basah isi Kacang Ijo:

1. Isian : rebus kacang hijau sampai empuk, angkat dan tiriskan, kemudian haluskan. Masak bersama gula pasir (saya pakai sedikit gula merah), garam dan pandan. Aduk terus sampai kacang hijau menjadi kering dan kalis. Dinginkan. Bentuk bulat bulat.
1. Kulit : campur tepung, ragi dan gula pasir. Aduk rata.
1. Masukkan air hangat, uleni hingga rata adonannya
1. Masukkan margarin dan garam, uleni lagi sampai kalis elastis.
1. Bulatkan adonan, tutup dengan kain lembab lalu fermentasikan 45 menit (aku 30 menit).
1. Kempiskan adonan dan timbang masing-masing 15 gr, beri isian kacang ijo lalu tutup bentuk bulat dan pipihkan. Letakkan di loyang tanpa olesan (sy pakai kertas roti dibawahnya). Beri jarak karena roti ini akan mengembang sedikit.
1. Diamkan 15 menit. Panggang dengan oven suhu 180 C selama 10 menit.
1. Keluarkan dari oven dan balik. Masukkan ke dalam oven lagi lalu panggang selama 5 menit. Angkat. Pake teflon? Bisa juga!




Demikianlah cara membuat pia basah isi kacang ijo yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan terbukti, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
