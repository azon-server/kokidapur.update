---
description: "Panduan untuk membuat Bakpia Homemade"
title: "Panduan untuk membuat Bakpia Homemade"
slug: 263-panduan-untuk-membuat-bakpia-homemade
date: 2020-11-22T20:02:42.197Z
image: https://img-global.cpcdn.com/recipes/2633ac2a9c537ee8/680x482cq70/bakpia-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2633ac2a9c537ee8/680x482cq70/bakpia-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2633ac2a9c537ee8/680x482cq70/bakpia-foto-resep-utama.jpg
author: Larry Oliver
ratingvalue: 4.7
reviewcount: 5009
recipeingredient:
- " Bhn isi "
- "150 gr kcg ijo rendam 1_2jam"
- "150 ml santan kental"
- "7 sdm gula psr"
- "1/4 sdt garam"
- "1/2 sdt vanili skip"
- " Kulit bahan a"
- "250 gr terigu serba guna"
- "50 gr gula halus"
- " Garam"
- "2 sdm minyak"
- "25 gr mentega tawar suhu ruang"
- "25 gr margarin"
- "90 ml air"
- " Bahan b "
- "100 gr terigu"
- "2 sdm margarin"
- "1 sdm minyak"
recipeinstructions:
- "Rebus kcg ijo smp empuk. Ak pk 5mnt tebus, angkat. Ttp 30mnt biarkan. 7mnt godog lg. Tiriskan. Haluskan dg 50ml santan. Campur dg gula, garam,sisa santan,. Masukkan ke wajan teflon. Masak, aduk smp kalis, bs dibentuk. Ssdh adem. Pulung jd 23bh"
- "Kulit:campur terigu, gula, garam, minyak, mentega. Tuang air sedikit2 smbl diulen hingga kalis dan dpt dibentuk. Bagi jd 23"
- "Gilas, ll letakkan adonan b, gilas, masukkan isian. Bentuk bulat pipih"
- "Nah yg no 3 td, aku tambahin gilas, tumpuk, gilas, lipat, gilas, gulung. Gilas, lipat, gulung, gilas, baru isi dg kcg ijo. Klo mw cpt si emng kyk no 3"
- "Panaskan oven suhu 180 drjt. Panggang 15mnt. Balik, panggang lg 15mnt"
- "Yg pertama gede2.;mklm ga pk timbangan"
- "Yg kedua, dibikin ga gitu eksotis, enk mn ya"
- "Rasanya bakpiaku jd kres kres. Biasanya mkn bakpia, kulitnya empuk ya"
- "Total 44 bh. Jd setelah kulitnya habis, aku bikin adonan kulit."
- "Hasil gilas, gulung, lipat, dst mpe blengerr"
- ""
- ""
categories:
- Recipe
tags:
- bakpia

katakunci: bakpia 
nutrition: 126 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Lunch

---


![Bakpia](https://img-global.cpcdn.com/recipes/2633ac2a9c537ee8/680x482cq70/bakpia-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang dapat kita jaga karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti bakpia yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan keistimewahan yang merupakan keragaman Indonesia

Kehangatan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Bakpia untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang bisa anda coba salah satunya bakpia yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep bakpia tanpa harus bersusah payah.
Berikut ini resep Bakpia yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 12 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Bakpia:

1. Jangan lupa  Bhn isi :
1. Jangan lupa 150 gr kcg ijo, rendam 1_2jam
1. Harap siapkan 150 ml santan kental
1. Diperlukan 7 sdm gula psr
1. Jangan lupa 1/4 sdt garam
1. Jangan lupa 1/2 sdt vanili (skip)
1. Diperlukan  Kulit /bahan a:
1. Tambah 250 gr terigu serba guna
1. Siapkan 50 gr gula halus
1. Siapkan  Garam
1. Diperlukan 2 sdm minyak
1. Harap siapkan 25 gr mentega tawar suhu ruang
1. Harus ada 25 gr margarin
1. Jangan lupa 90 ml air
1. Siapkan  Bahan b :
1. Harus ada 100 gr terigu
1. Tambah 2 sdm margarin
1. Siapkan 1 sdm minyak




<!--inarticleads2-->

##### Langkah membuat  Bakpia:

1. Rebus kcg ijo smp empuk. Ak pk 5mnt tebus, angkat. Ttp 30mnt biarkan. 7mnt godog lg. Tiriskan. Haluskan dg 50ml santan. Campur dg gula, garam,sisa santan,. Masukkan ke wajan teflon. Masak, aduk smp kalis, bs dibentuk. Ssdh adem. Pulung jd 23bh
1. Kulit:campur terigu, gula, garam, minyak, mentega. Tuang air sedikit2 smbl diulen hingga kalis dan dpt dibentuk. Bagi jd 23
1. Gilas, ll letakkan adonan b, gilas, masukkan isian. Bentuk bulat pipih
1. Nah yg no 3 td, aku tambahin gilas, tumpuk, gilas, lipat, gilas, gulung. Gilas, lipat, gulung, gilas, baru isi dg kcg ijo. Klo mw cpt si emng kyk no 3
1. Panaskan oven suhu 180 drjt. Panggang 15mnt. Balik, panggang lg 15mnt
1. Yg pertama gede2.;mklm ga pk timbangan
1. Yg kedua, dibikin ga gitu eksotis, enk mn ya
1. Rasanya bakpiaku jd kres kres. Biasanya mkn bakpia, kulitnya empuk ya
1. Total 44 bh. Jd setelah kulitnya habis, aku bikin adonan kulit.
1. Hasil gilas, gulung, lipat, dst mpe blengerr
1. 
1. 




Demikianlah cara membuat bakpia yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat simple dan cepat, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
