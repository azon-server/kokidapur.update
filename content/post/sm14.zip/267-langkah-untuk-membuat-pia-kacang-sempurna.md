---
description: "Langkah untuk membuat Pia Kacang Sempurna"
title: "Langkah untuk membuat Pia Kacang Sempurna"
slug: 267-langkah-untuk-membuat-pia-kacang-sempurna
date: 2021-03-08T19:19:58.713Z
image: https://img-global.cpcdn.com/recipes/9cbbf2fbf8bf0bb4/680x482cq70/pia-kacang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9cbbf2fbf8bf0bb4/680x482cq70/pia-kacang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9cbbf2fbf8bf0bb4/680x482cq70/pia-kacang-foto-resep-utama.jpg
author: Garrett Lopez
ratingvalue: 4.8
reviewcount: 30319
recipeingredient:
- "250 gr margarine"
- "150 gr gula halus"
- "150 gr kacang tanah sangrai tumbuk kasar"
- "50 gr bawang merah goreh"
- "420 gr tepung terigu"
- "25 gr susu bubuk"
- "25 gr maizena"
- "1 butir telur"
recipeinstructions:
- "Kocok margarine, gula halus sampai tercampur rata. Tambahkan telur. Kocok lagi hingga lembut dan pucat. Kira kira 5 menit"
- "Masukkan kacang, bawang merah, aduk rata dgn spatula"
- "Masukkan maizena, susu bubuk, aduk rata, tambahkan tepung terigu. Campur rata, tapi jgn terlalu ditekan kuat kuat biar tidak bantat."
- "Timbang masing2 20gr. Bulatkan, tindis dgn tutup botol nya vanili hingga timbul rekahan di pinggirannya. *pica"
- "Panggang di oven kira2 30 menit, tergantung oven masing2."
- "Angkat, dinginkan, simpan du toples."
categories:
- Recipe
tags:
- pia
- kacang

katakunci: pia kacang 
nutrition: 148 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Dinner

---


![Pia Kacang](https://img-global.cpcdn.com/recipes/9cbbf2fbf8bf0bb4/680x482cq70/pia-kacang-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau empuk. Ciri khas masakan Nusantara pia kacang yang kaya dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Pia Kacang untuk keluarga. kebiasaan makan bersama anak sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang bisa anda contoh salah satunya pia kacang yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep pia kacang tanpa harus bersusah payah.
Berikut ini resep Pia Kacang yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 8 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Pia Kacang:

1. Jangan lupa 250 gr margarine
1. Harap siapkan 150 gr gula halus
1. Harap siapkan 150 gr kacang tanah, sangrai, tumbuk kasar
1. Dibutuhkan 50 gr bawang merah goreh
1. Tambah 420 gr tepung terigu
1. Diperlukan 25 gr susu bubuk
1. Tambah 25 gr maizena
1. Tambah 1 butir telur




<!--inarticleads2-->

##### Langkah membuat  Pia Kacang:

1. Kocok margarine, gula halus sampai tercampur rata. Tambahkan telur. Kocok lagi hingga lembut dan pucat. Kira kira 5 menit
1. Masukkan kacang, bawang merah, aduk rata dgn spatula
1. Masukkan maizena, susu bubuk, aduk rata, tambahkan tepung terigu. Campur rata, tapi jgn terlalu ditekan kuat kuat biar tidak bantat.
1. Timbang masing2 20gr. Bulatkan, tindis dgn tutup botol nya vanili hingga timbul rekahan di pinggirannya. *pica
1. Panggang di oven kira2 30 menit, tergantung oven masing2.
1. Angkat, dinginkan, simpan du toples.




Demikianlah cara membuat pia kacang yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan cepat, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
