---
description: "Resep : Bakpia Pathok Simple minggu ini"
title: "Resep : Bakpia Pathok Simple minggu ini"
slug: 288-resep-bakpia-pathok-simple-minggu-ini
date: 2020-10-24T01:01:08.095Z
image: https://img-global.cpcdn.com/recipes/2fb03cb7b6af4927/680x482cq70/bakpia-pathok-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2fb03cb7b6af4927/680x482cq70/bakpia-pathok-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2fb03cb7b6af4927/680x482cq70/bakpia-pathok-simple-foto-resep-utama.jpg
author: Nina Potter
ratingvalue: 4.6
reviewcount: 23833
recipeingredient:
- " Isian "
- "100 gram kacangijo kupas"
- "65 gram santan kara"
- "150 ml air"
- "60 gram gulapasir"
- " Kulit 1 "
- "50 gram "
- "35 gram margarine"
- "1/2 sdt minyak"
- " Kulit 2 "
- "100 gram cakra"
- "15 gram gula halus"
- "Sejumput garam"
- "35 gram butter palmia"
- "5 sdm air"
recipeinstructions:
- "Rendam kacangijo selama 3jam. lalu kukus sampai matang. blender kacangijo, air &amp; santan lalu masak.. Tambahkan gula pasir api kecil hingga mengental"
- "Kulit 1 : campur semua bahan dan timbang 6 gram / dibagi menjadi 15 bagian."
- "Campur bahan 2 uleni hingga kalis, bagi menjadi 15 bagian"
- "Lalu lipat perlahan adonan 1 &amp; 2 seperti mebuat kulit Bolen ya... Masukan isian dan tata diloyang."
- "Api sedang yah dioven sampai matang. dibolak balik."
- "Saya pakai oven tangkring pemirsah"
categories:
- Recipe
tags:
- bakpia
- pathok
- simple

katakunci: bakpia pathok simple 
nutrition: 269 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dinner

---


![Bakpia Pathok Simple](https://img-global.cpcdn.com/recipes/2fb03cb7b6af4927/680x482cq70/bakpia-pathok-simple-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti bakpia pathok simple yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa keistimewahan yang merupakan keragaman Nusantara



Kehangatan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Bakpia Pathok Simple untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang bisa anda coba salah satunya bakpia pathok simple yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep bakpia pathok simple tanpa harus bersusah payah.
Seperti resep Bakpia Pathok Simple yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 15 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Bakpia Pathok Simple:

1. Jangan lupa  Isian :
1. Diperlukan 100 gram kacangijo kupas
1. Tambah 65 gram santan kara
1. Tambah 150 ml air
1. Siapkan 60 gram gulapasir
1. Dibutuhkan  Kulit 1 :
1. Jangan lupa 50 gram ∆
1. Siapkan 35 gram margarine
1. Diperlukan 1/2 sdt minyak
1. Harus ada  Kulit 2 :
1. Jangan lupa 100 gram cakra
1. Diperlukan 15 gram gula halus
1. Harus ada Sejumput garam
1. Harap siapkan 35 gram butter (palmia)
1. Diperlukan 5 sdm air




<!--inarticleads2-->

##### Langkah membuat  Bakpia Pathok Simple:

1. Rendam kacangijo selama 3jam. lalu kukus sampai matang. blender kacangijo, air &amp; santan lalu masak.. Tambahkan gula pasir api kecil hingga mengental
1. Kulit 1 : campur semua bahan dan timbang 6 gram / dibagi menjadi 15 bagian.
1. Campur bahan 2 uleni hingga kalis, bagi menjadi 15 bagian
1. Lalu lipat perlahan adonan 1 &amp; 2 seperti mebuat kulit Bolen ya... Masukan isian dan tata diloyang.
1. Api sedang yah dioven sampai matang. dibolak balik.
1. Saya pakai oven tangkring pemirsah




Demikianlah cara membuat bakpia pathok simple yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
