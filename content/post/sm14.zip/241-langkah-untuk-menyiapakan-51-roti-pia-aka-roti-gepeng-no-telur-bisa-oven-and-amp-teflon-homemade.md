---
description: "Langkah untuk menyiapakan 51. Roti Pia aka Roti Gepeng No Telur (bisa Oven &amp;amp; Teflon) Homemade"
title: "Langkah untuk menyiapakan 51. Roti Pia aka Roti Gepeng No Telur (bisa Oven &amp;amp; Teflon) Homemade"
slug: 241-langkah-untuk-menyiapakan-51-roti-pia-aka-roti-gepeng-no-telur-bisa-oven-and-amp-teflon-homemade
date: 2021-02-24T22:52:08.167Z
image: https://img-global.cpcdn.com/recipes/2c5a9bbc5f8be1de/680x482cq70/51-roti-pia-aka-roti-gepeng-no-telur-bisa-oven-teflon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2c5a9bbc5f8be1de/680x482cq70/51-roti-pia-aka-roti-gepeng-no-telur-bisa-oven-teflon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2c5a9bbc5f8be1de/680x482cq70/51-roti-pia-aka-roti-gepeng-no-telur-bisa-oven-teflon-foto-resep-utama.jpg
author: Ruth Barber
ratingvalue: 4.3
reviewcount: 2095
recipeingredient:
- "250 gr terigu saya  biru"
- "50 gr gula pasir halus bisa gulanya diblender dulu"
- "1 gr bread improver saya Bakerine Plus"
- "4 gr ragi instan"
- "180 ml air kalo saya cukup suhu ruang"
- "10 gr susu bubuk tambahan saya"
- "30 gr margarin"
- "1/2 sdt garam saya 38 sdt"
- " Bahan Filling"
- " Susukeju manis           lihat resep"
- " Nougat kacang           lihat resep"
recipeinstructions:
- "Buat adonan roti seperti biasa. Pada tahap ini saya masih menggunakan tangan. Pertama, campur semua bahan di atas (kecuali margarin &amp; garam). Aduk rata. Air digunakan seperlunya saja, TIDAK HARUS habis. Lalu tambahkan margarin &amp; garam, campur hingga rata (homogen). Lalu saya gunakan mixer untuk membantu ulen hingga kalis. Cara menggunakan hand mixer bisa lihat di Channel Resep Papa Youtube. Saya juga belajar dari sini."
- "Setelah adonan kalis elastis, resting sebentar sekitar 10-20 menit. Lalu langsung dibagi 20 gr/pcs. Rounding, dan siap diberi isian."
- "Saya bikin ini 2x. Hari pertama bikin versi oven listrik, hari kedua bikin versi teflon. Untuk versi oven, setelah adonan diberi filling (isian), selanjutnya proofing di loyang yang sudah diberi olesan carlo cukup tebal (lebih tebal dari olesan biasa). Gunanya agar saat dibalik roti tidak lengket di loyang. Proofing sebentar saja, cukup sampai ukuran adonan mengembang 2x."
- "Panaskan dulu oven. Setelah itu atur suhu 220°C api bawah saja. Panggang roti pada rak terbawah hingga bagian bawah mulai kecoklatan. Kemudian segera balik adonan dan panggang sisi satunya hingga matang. Di oven saya sekitar 5-6 menit tiap sisi. Karena saya suka tampilan yang lebih coklat, kadangkala saya panggang lebih lama sedikit."
- "Hari kedua, saya bikin lagi 2x resep dan dipanggang di teflon. Cukup panaskan teflon dengan api kecil hingga siap digunakan. Teflon tidak saya beri olesan karena punya saya masih mulus, masih antilengket. Panggang tiap sisi hingga matang &amp; mudah dibalik. Jangan lupa loyang ditutup agar diperoleh suhu panas maksimal."
- "Taraaa...ini dia hasilnya. Baik versi oven maupun versi teflon, keduanya sama-sama berhasil. Bedanya, yang versi oven tingkat kematangan, warna, bisa lebih seragam daripada versi teflon. Foto 1 versi teflon. Foto 2 versi oven listrik."
categories:
- Recipe
tags:
- 51
- roti
- pia

katakunci: 51 roti pia 
nutrition: 110 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Dessert

---


![51. Roti Pia aka Roti Gepeng No Telur (bisa Oven &amp; Teflon)](https://img-global.cpcdn.com/recipes/2c5a9bbc5f8be1de/680x482cq70/51-roti-pia-aka-roti-gepeng-no-telur-bisa-oven-teflon-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti 51. roti pia aka roti gepeng no telur (bisa oven &amp; teflon) yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Kita



Kehangatan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah memasak 51. Roti Pia aka Roti Gepeng No Telur (bisa Oven &amp; Teflon) untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang bisa anda buat salah satunya 51. roti pia aka roti gepeng no telur (bisa oven &amp; teflon) yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep 51. roti pia aka roti gepeng no telur (bisa oven &amp; teflon) tanpa harus bersusah payah.
Berikut ini resep 51. Roti Pia aka Roti Gepeng No Telur (bisa Oven &amp; Teflon) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 11 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat 51. Roti Pia aka Roti Gepeng No Telur (bisa Oven &amp; Teflon):

1. Dibutuhkan 250 gr terigu (saya ∆ biru)
1. Siapkan 50 gr gula pasir halus (bisa gulanya diblender dulu)
1. Dibutuhkan 1 gr bread improver (saya Bakerine Plus)
1. Harap siapkan 4 gr ragi instan
1. Tambah 180 ml air (kalo saya cukup suhu ruang)
1. Tambah 10 gr susu bubuk (tambahan saya)
1. Siapkan 30 gr margarin
1. Jangan lupa 1/2 sdt garam (saya 3/8 sdt)
1. Harap siapkan  Bahan Filling:
1. Jangan lupa  Susu/keju manis           (lihat resep)
1. Siapkan  Nougat kacang           (lihat resep)




<!--inarticleads2-->

##### Cara membuat  51. Roti Pia aka Roti Gepeng No Telur (bisa Oven &amp; Teflon):

1. Buat adonan roti seperti biasa. Pada tahap ini saya masih menggunakan tangan. Pertama, campur semua bahan di atas (kecuali margarin &amp; garam). Aduk rata. Air digunakan seperlunya saja, TIDAK HARUS habis. Lalu tambahkan margarin &amp; garam, campur hingga rata (homogen). Lalu saya gunakan mixer untuk membantu ulen hingga kalis. Cara menggunakan hand mixer bisa lihat di Channel Resep Papa Youtube. Saya juga belajar dari sini.
1. Setelah adonan kalis elastis, resting sebentar sekitar 10-20 menit. Lalu langsung dibagi 20 gr/pcs. Rounding, dan siap diberi isian.
1. Saya bikin ini 2x. Hari pertama bikin versi oven listrik, hari kedua bikin versi teflon. Untuk versi oven, setelah adonan diberi filling (isian), selanjutnya proofing di loyang yang sudah diberi olesan carlo cukup tebal (lebih tebal dari olesan biasa). Gunanya agar saat dibalik roti tidak lengket di loyang. Proofing sebentar saja, cukup sampai ukuran adonan mengembang 2x.
1. Panaskan dulu oven. Setelah itu atur suhu 220°C api bawah saja. Panggang roti pada rak terbawah hingga bagian bawah mulai kecoklatan. Kemudian segera balik adonan dan panggang sisi satunya hingga matang. Di oven saya sekitar 5-6 menit tiap sisi. Karena saya suka tampilan yang lebih coklat, kadangkala saya panggang lebih lama sedikit.
1. Hari kedua, saya bikin lagi 2x resep dan dipanggang di teflon. Cukup panaskan teflon dengan api kecil hingga siap digunakan. Teflon tidak saya beri olesan karena punya saya masih mulus, masih antilengket. Panggang tiap sisi hingga matang &amp; mudah dibalik. Jangan lupa loyang ditutup agar diperoleh suhu panas maksimal.
1. Taraaa...ini dia hasilnya. Baik versi oven maupun versi teflon, keduanya sama-sama berhasil. Bedanya, yang versi oven tingkat kematangan, warna, bisa lebih seragam daripada versi teflon. Foto 1 versi teflon. Foto 2 versi oven listrik.




Demikianlah cara membuat 51. roti pia aka roti gepeng no telur (bisa oven &amp; teflon) yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
