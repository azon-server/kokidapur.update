---
description: "Langkah untuk membuat Kacang hijau untuk isian bakpia / onde2 Sempurna"
title: "Langkah untuk membuat Kacang hijau untuk isian bakpia / onde2 Sempurna"
slug: 291-langkah-untuk-membuat-kacang-hijau-untuk-isian-bakpia-onde2-sempurna
date: 2020-10-08T16:21:11.810Z
image: https://img-global.cpcdn.com/recipes/bb18ddd20e3b27a8/680x482cq70/kacang-hijau-untuk-isian-bakpia-onde2-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bb18ddd20e3b27a8/680x482cq70/kacang-hijau-untuk-isian-bakpia-onde2-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bb18ddd20e3b27a8/680x482cq70/kacang-hijau-untuk-isian-bakpia-onde2-foto-resep-utama.jpg
author: Lawrence Wilkerson
ratingvalue: 4.4
reviewcount: 38434
recipeingredient:
- "500 g kacang hijau"
- "300 g gula pasir"
- "1 sdt vanilla bubuk"
- "2 bungkus santan kara 65ml"
- "1 sdt garam"
- "Secukupnya air"
recipeinstructions:
- "Rebus kacang hijau hingga lunak, saya pake presto biar cepet 😁"
- "Haluskan menggunakan blender, punya saya cuma d bejek2 aja tadi pake ulekan.."
- "Masak lagi bersama gula, garam, santan dan vanilla hingga adonan mengental (air menyusut) dan adonan bisa d pulung.."
- "Biarkan dingin baru d pulung, punya saya jadi 80 bagian.. lumayan banyak yah, kalo mau buat sedikit pakai aja setengah resep 😉"
categories:
- Recipe
tags:
- kacang
- hijau
- untuk

katakunci: kacang hijau untuk 
nutrition: 141 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Lunch

---


![Kacang hijau untuk isian bakpia / onde2](https://img-global.cpcdn.com/recipes/bb18ddd20e3b27a8/680x482cq70/kacang-hijau-untuk-isian-bakpia-onde2-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita jaga karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti kacang hijau untuk isian bakpia / onde2 yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia



Keharmonisan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Kacang hijau untuk isian bakpia / onde2 untuk keluarga. kebersamaan makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang bisa anda buat salah satunya kacang hijau untuk isian bakpia / onde2 yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan cepat menemukan resep kacang hijau untuk isian bakpia / onde2 tanpa harus bersusah payah.
Seperti resep Kacang hijau untuk isian bakpia / onde2 yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 6 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kacang hijau untuk isian bakpia / onde2:

1. Jangan lupa 500 g kacang hijau
1. Siapkan 300 g gula pasir
1. Jangan lupa 1 sdt vanilla bubuk
1. Dibutuhkan 2 bungkus santan kara (65ml)
1. Diperlukan 1 sdt garam
1. Jangan lupa Secukupnya air




<!--inarticleads2-->

##### Bagaimana membuat  Kacang hijau untuk isian bakpia / onde2:

1. Rebus kacang hijau hingga lunak, saya pake presto biar cepet 😁
1. Haluskan menggunakan blender, punya saya cuma d bejek2 aja tadi pake ulekan..
1. Masak lagi bersama gula, garam, santan dan vanilla hingga adonan mengental (air menyusut) dan adonan bisa d pulung..
1. Biarkan dingin baru d pulung, punya saya jadi 80 bagian.. lumayan banyak yah, kalo mau buat sedikit pakai aja setengah resep 😉




Demikianlah cara membuat kacang hijau untuk isian bakpia / onde2 yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan cepat, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
