---
description: "Resep : Bakpia basah pandan Cepat"
title: "Resep : Bakpia basah pandan Cepat"
slug: 242-resep-bakpia-basah-pandan-cepat
date: 2021-02-16T12:28:07.947Z
image: https://img-global.cpcdn.com/recipes/bd0a8aa3fcb75c9f/680x482cq70/bakpia-basah-pandan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bd0a8aa3fcb75c9f/680x482cq70/bakpia-basah-pandan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bd0a8aa3fcb75c9f/680x482cq70/bakpia-basah-pandan-foto-resep-utama.jpg
author: Janie Osborne
ratingvalue: 4.7
reviewcount: 24560
recipeingredient:
- "  isi"
- "100 gr kacang hijau"
- "50 gr gula pasir"
- "150 ml santan kara 65ml  air"
- "1/4 sdt garam"
- "1 sachet vanili bubuk"
- " kulit A "
- "250 gr tepung trigu"
- "50 gr margarin"
- "50 gr gula pasir"
- "2 sdm minyak sayur"
- "100 ml air"
- "1/4 sdt pasta pandan"
- " kulit B "
- "100 gr tepung trigu"
- "50 gr margarin"
- "1 sdm minyak sayur"
- "2 sdm air putih matang"
- "2 tetes pasta pandan"
recipeinstructions:
- "Rebus kacang hijau sampe empuk, tapi jangan hancur, tiriskan dan dinginkan. Blender kacang hijau dengan santan, masak sampe set bersama gula, garam, dan vanili. setelah dingin bentuk bulat2."
- "Kulit A, campur air bersama pasta pandan aduk rata. Campur semua bahan kulit A lalu tuang air pandan aduk rata sampe kalis."
- "Kulit B, campur semua bahan aduk rata sampe kalis."
- "Bagi adonan A menjadi 20 pcs berat masing2 20 gr. Bagi adonan B mengikuti jumlah adonan A (nggak usah ditimbang)"
- "Pipihkan gilas adonan A dengan rolling pin lalu tumpuk atasnya adonan B gilas kembali, beri isian kacang hijau agak di pipihkan, lalu tutup rapat."
- "Panaskan teflon dengan api kecil hampir mati, bakar bakpia di teflon sampe semua sisi terlihat coklat, jangan lupa di tutup ya. (Api sesuaikan saja, karna aku pake teflon yang agak kecil dan tipis jadi api kecil banget, untuk pembakaran aku gak pake waktu, dilihat saja kl sudah terlihat coklat baru di balik)"
- ""
categories:
- Recipe
tags:
- bakpia
- basah
- pandan

katakunci: bakpia basah pandan 
nutrition: 213 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dinner

---


![Bakpia basah pandan](https://img-global.cpcdn.com/recipes/bd0a8aa3fcb75c9f/680x482cq70/bakpia-basah-pandan-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga gurih. Ciri makanan Indonesia bakpia basah pandan yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan keluarga dapat diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Bakpia basah pandan untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang dapat anda contoh salah satunya bakpia basah pandan yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep bakpia basah pandan tanpa harus bersusah payah.
Berikut ini resep Bakpia basah pandan yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Bakpia basah pandan:

1. Jangan lupa  📍 isi:
1. Diperlukan 100 gr kacang hijau
1. Harus ada 50 gr gula pasir
1. Siapkan 150 ml santan (kara 65ml + air)
1. Harus ada 1/4 sdt garam
1. Harap siapkan 1 sachet vanili bubuk
1. Harus ada  📍kulit A :
1. Siapkan 250 gr tepung trigu
1. Harap siapkan 50 gr margarin
1. Tambah 50 gr gula pasir
1. Siapkan 2 sdm minyak sayur
1. Harap siapkan 100 ml air
1. Diperlukan 1/4 sdt pasta pandan
1. Harap siapkan  📍kulit B :
1. Harus ada 100 gr tepung trigu
1. Dibutuhkan 50 gr margarin
1. Tambah 1 sdm minyak sayur
1. Harus ada 2 sdm air putih matang
1. Harus ada 2 tetes pasta pandan




<!--inarticleads2-->

##### Instruksi membuat  Bakpia basah pandan:

1. Rebus kacang hijau sampe empuk, tapi jangan hancur, tiriskan dan dinginkan. Blender kacang hijau dengan santan, masak sampe set bersama gula, garam, dan vanili. setelah dingin bentuk bulat2.
1. Kulit A, campur air bersama pasta pandan aduk rata. Campur semua bahan kulit A lalu tuang air pandan aduk rata sampe kalis.
1. Kulit B, campur semua bahan aduk rata sampe kalis.
1. Bagi adonan A menjadi 20 pcs berat masing2 20 gr. Bagi adonan B mengikuti jumlah adonan A (nggak usah ditimbang)
1. Pipihkan gilas adonan A dengan rolling pin lalu tumpuk atasnya adonan B gilas kembali, beri isian kacang hijau agak di pipihkan, lalu tutup rapat.
1. Panaskan teflon dengan api kecil hampir mati, bakar bakpia di teflon sampe semua sisi terlihat coklat, jangan lupa di tutup ya. (Api sesuaikan saja, karna aku pake teflon yang agak kecil dan tipis jadi api kecil banget, untuk pembakaran aku gak pake waktu, dilihat saja kl sudah terlihat coklat baru di balik)
1. 




Demikianlah cara membuat bakpia basah pandan yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan cepat, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
