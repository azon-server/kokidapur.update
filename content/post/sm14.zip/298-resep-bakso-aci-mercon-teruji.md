---
description: "Resep : Bakso Aci Mercon Teruji"
title: "Resep : Bakso Aci Mercon Teruji"
slug: 298-resep-bakso-aci-mercon-teruji
date: 2020-09-11T22:31:37.525Z
image: https://img-global.cpcdn.com/recipes/90905741d886c9eb/680x482cq70/bakso-aci-mercon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/90905741d886c9eb/680x482cq70/bakso-aci-mercon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/90905741d886c9eb/680x482cq70/bakso-aci-mercon-foto-resep-utama.jpg
author: Travis McGuire
ratingvalue: 5
reviewcount: 15582
recipeingredient:
- " bahan aci"
- "5 sdm sagu"
- "2-2.5 sdm terigu"
- "1 sdm fibercreme"
- " lada"
- " bawang baceman 1 sdt"
- "secukupnya air"
- "secukupnya daun bawang"
- " Bahan kuah"
- "3 bawang merah sedang uleg"
- "1 sdt baceman baput"
- "3 cabe merah rawit uleg"
- "3 rawit merah utuh"
- "2-2.5 sdm fibercreme"
- "1   34 sdt royco"
- "2 telur krn unt 2 porsi"
- "600 ml air putih"
- " lada"
- " sawi  sayuran lain"
- " cabe bubuk optional"
- " kecap asin"
- " garam"
- " pelengkap"
- " bihun n mie rebus"
- " bawang goreng"
- " jeruk limo"
recipeinstructions:
- "Campur sagu, terigu, lada, fibercreme, baceman, daun bawang, aduk dgn sendok atau garpu dl spy tepung tdk menyatu. MAsukan air secukupnya smp bs di pulung. bila kebanyakan air bs sesuaikan sagu n terigunya lagi ya. pas mskin air sdkt2 aja dl"
- "Bentuk bulat n masukan ke air mendidih. Masak smp bakso ngapung, ak masak 10- 15 menit biar acinya matang smp ke dalam."
- "Bakso aci boleh di goreng dl bila suka. lbh enak juga loh.. ak cmpr ada yg goreng n ga goreng"
- "Tumis bamer, cabe uleg, baceman smp wang n matang. Masukan air n rawit utuh."
- "Didihkan air n masukan fibercreme. bumbui royco, lada dan cabe bubuk. masukan daun sawi dan telur. Telurnya jgn di kocok, bila mau buat 1/2 matang kuningnya masak sebentar n di angkat n sisihkan dl bila sdh setengah matang. Lanjutkan memasak kuahnya. bumbui garam dan kecap asin smp mencapai asin yang diinginkan. beri daun bawang iris or seledri juga blh."
- "Finishing beri bihun n mie rebus di mangkok, beri baso aci n kuahnya, sajikan selagi panas dan beri bawang goreng n perasan limo bila suka asam."
categories:
- Recipe
tags:
- bakso
- aci
- mercon

katakunci: bakso aci mercon 
nutrition: 300 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Lunch

---


![Bakso Aci Mercon](https://img-global.cpcdn.com/recipes/90905741d886c9eb/680x482cq70/bakso-aci-mercon-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti bakso aci mercon yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa kesan tersendiri yang merupakan keragaman Nusantara



Keharmonisan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Bakso Aci Mercon untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang bisa anda buat salah satunya bakso aci mercon yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep bakso aci mercon tanpa harus bersusah payah.
Berikut ini resep Bakso Aci Mercon yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 26 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Bakso Aci Mercon:

1. Tambah  bahan aci
1. Dibutuhkan 5 sdm sagu
1. Siapkan 2-2.5 sdm terigu
1. Harap siapkan 1 sdm fibercreme
1. Diperlukan  lada
1. Harap siapkan  bawang baceman 1/² sdt
1. Siapkan secukupnya air
1. Siapkan secukupnya daun bawang
1. Harap siapkan  Bahan kuah
1. Jangan lupa 3 bawang merah sedang, uleg
1. Diperlukan 1 sdt baceman baput
1. Tambah 3 cabe merah rawit uleg
1. Jangan lupa 3 rawit merah utuh
1. Siapkan 2-2.5 sdm fibercreme
1. Dibutuhkan 1 /² - 3/4 sdt royco
1. Siapkan 2 telur (krn unt 2 porsi)
1. Tambah 600 ml air putih
1. Harap siapkan  lada
1. Harap siapkan  sawi / sayuran lain
1. Diperlukan  cabe bubuk (optional)
1. Harap siapkan  kecap asin
1. Harus ada  garam
1. Harap siapkan  pelengkap
1. Diperlukan  bihun n mie rebus
1. Tambah  bawang goreng
1. Harus ada  jeruk limo




<!--inarticleads2-->

##### Cara membuat  Bakso Aci Mercon:

1. Campur sagu, terigu, lada, fibercreme, baceman, daun bawang, aduk dgn sendok atau garpu dl spy tepung tdk menyatu. MAsukan air secukupnya smp bs di pulung. bila kebanyakan air bs sesuaikan sagu n terigunya lagi ya. pas mskin air sdkt2 aja dl
1. Bentuk bulat n masukan ke air mendidih. Masak smp bakso ngapung, ak masak 10- 15 menit biar acinya matang smp ke dalam.
1. Bakso aci boleh di goreng dl bila suka. lbh enak juga loh.. ak cmpr ada yg goreng n ga goreng
1. Tumis bamer, cabe uleg, baceman smp wang n matang. Masukan air n rawit utuh.
1. Didihkan air n masukan fibercreme. bumbui royco, lada dan cabe bubuk. masukan daun sawi dan telur. Telurnya jgn di kocok, bila mau buat 1/2 matang kuningnya masak sebentar n di angkat n sisihkan dl bila sdh setengah matang. Lanjutkan memasak kuahnya. bumbui garam dan kecap asin smp mencapai asin yang diinginkan. beri daun bawang iris or seledri juga blh.
1. Finishing beri bihun n mie rebus di mangkok, beri baso aci n kuahnya, sajikan selagi panas dan beri bawang goreng n perasan limo bila suka asam.




Demikianlah cara membuat bakso aci mercon yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat gampang dan teruji, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
