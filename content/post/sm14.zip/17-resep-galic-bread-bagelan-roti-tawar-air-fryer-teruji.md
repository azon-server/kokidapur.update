---
description: "Resep : Galic Bread (Bagelan) Roti Tawar Air Fryer Teruji"
title: "Resep : Galic Bread (Bagelan) Roti Tawar Air Fryer Teruji"
slug: 17-resep-galic-bread-bagelan-roti-tawar-air-fryer-teruji
date: 2021-03-02T19:14:49.480Z
image: https://img-global.cpcdn.com/recipes/ffc047e479fa0159/680x482cq70/galic-bread-bagelan-roti-tawar-air-fryer-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ffc047e479fa0159/680x482cq70/galic-bread-bagelan-roti-tawar-air-fryer-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ffc047e479fa0159/680x482cq70/galic-bread-bagelan-roti-tawar-air-fryer-foto-resep-utama.jpg
author: Jon Adkins
ratingvalue: 4.2
reviewcount: 22508
recipeingredient:
- "4 lembar roti tawar"
- " Bahan olesan"
- "3 sdm mentega Blue Band serbaguna"
- "2 siung bawang putih ukuran sedang"
- "1/2 sdt oregano kering"
- "1 sdt daun parsley kering"
- " Bahan cocolan aduk jadi 1"
- "1 sdm mayonaise Maestro"
- "1 sdt saos sambal Del Monte"
- "1/3 sdt daun parsley kering"
recipeinstructions:
- "Haluskan bawang putih"
- "Campurkan mentega, bawang putih halus, oregano, dan daun parsley"
- "Oleskan ke masing-masing lembaran roti tawar sesuai selera. Jika suka, bisa dioleskan di bagian atas-bawah (lebih gurih)"
- "Potong roti yang sudah diolesi menjadi 4 bagian"
- "Susun di rak air fryer dan panggang selama 8-10 menit dengan suhu 200°C dengan api atas bawah. Jika ingin agak chewy, panggang selama 6-7 menit saja"
- "Setelah matang, garlic bread siap disajikan selagi hangat dengan bahan cocolan. Angin-anginkan sebentar hingga dingin, tempatkan di toples jika ingin lebih tahan lama"
categories:
- Recipe
tags:
- galic
- bread
- bagelan

katakunci: galic bread bagelan 
nutrition: 110 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Lunch

---


![Galic Bread (Bagelan) Roti Tawar Air Fryer](https://img-global.cpcdn.com/recipes/ffc047e479fa0159/680x482cq70/galic-bread-bagelan-roti-tawar-air-fryer-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti galic bread (bagelan) roti tawar air fryer yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa kesan tersendiri yang merupakan keragaman Indonesia

Keharmonisan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah memasak Galic Bread (Bagelan) Roti Tawar Air Fryer untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang bisa anda contoh salah satunya galic bread (bagelan) roti tawar air fryer yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep galic bread (bagelan) roti tawar air fryer tanpa harus bersusah payah.
Berikut ini resep Galic Bread (Bagelan) Roti Tawar Air Fryer yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Galic Bread (Bagelan) Roti Tawar Air Fryer:

1. Harap siapkan 4 lembar roti tawar
1. Harap siapkan  Bahan olesan
1. Dibutuhkan 3 sdm mentega (Blue Band serbaguna)
1. Jangan lupa 2 siung bawang putih ukuran sedang
1. Diperlukan 1/2 sdt oregano kering
1. Dibutuhkan 1 sdt daun parsley kering
1. Harus ada  Bahan cocolan (aduk jadi 1)
1. Dibutuhkan 1 sdm mayonaise (Maestro)
1. Jangan lupa 1 sdt saos sambal (Del Monte)
1. Tambah 1/3 sdt daun parsley kering




<!--inarticleads2-->

##### Bagaimana membuat  Galic Bread (Bagelan) Roti Tawar Air Fryer:

1. Haluskan bawang putih
1. Campurkan mentega, bawang putih halus, oregano, dan daun parsley
1. Oleskan ke masing-masing lembaran roti tawar sesuai selera. Jika suka, bisa dioleskan di bagian atas-bawah (lebih gurih)
1. Potong roti yang sudah diolesi menjadi 4 bagian
1. Susun di rak air fryer dan panggang selama 8-10 menit dengan suhu 200°C dengan api atas bawah. Jika ingin agak chewy, panggang selama 6-7 menit saja
1. Setelah matang, garlic bread siap disajikan selagi hangat dengan bahan cocolan. Angin-anginkan sebentar hingga dingin, tempatkan di toples jika ingin lebih tahan lama




Demikianlah cara membuat galic bread (bagelan) roti tawar air fryer yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
