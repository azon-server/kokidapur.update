---
description: "Resep : Bakpia kacang hijau minggu ini"
title: "Resep : Bakpia kacang hijau minggu ini"
slug: 264-resep-bakpia-kacang-hijau-minggu-ini
date: 2020-11-29T02:53:35.162Z
image: https://img-global.cpcdn.com/recipes/a74b8e0b70b874b1/680x482cq70/bakpia-kacang-hijau-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a74b8e0b70b874b1/680x482cq70/bakpia-kacang-hijau-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a74b8e0b70b874b1/680x482cq70/bakpia-kacang-hijau-foto-resep-utama.jpg
author: Sophie Powers
ratingvalue: 4.1
reviewcount: 34740
recipeingredient:
- " Bahan Isian "
- " Kacang hijau 100 gramrendam 2 jam lalu rebus sampai matang"
- "secukupnya Keju parut"
- "80 gram Gula pasir"
- "1 sachet Susu skm"
- "1/2 sdt Garam"
- " Bahan A kulit"
- "150 gram Terigu"
- "25 gram Gula halus"
- "50 gram Margarin"
- "75 ml Air"
- "1/2 sdt garam"
- " Bahan B kulit"
- "100 gram Terigu"
- "55 gram Mentega"
- "10 gram Maizena"
- "2 sdm Minyak goreng"
recipeinstructions:
- "Kacang hijau yang sudah matang tiriskan.kemudian haluskan bersama gula pasir,skm dan garam."
- "Beri parutan keju secukupnya sesuai selera kemudian aduk rata."
- "Adonan isian dibentuk bulat bulat tapi sedikit di pipihkan"
- "Campur adonan A dalam satu wadah aduk rata sampai kalis.Demikian juga dengan bahan B campur dalam satu wadah aduk rata sampai kalis. Diamkan adonan 20 menit.setelah itu masing masing adonan di bagi menjadi bola bola kecil dengan jumlah yang sama.(saya pakai ukuran 1/2 sdm untuk adonan A.sedangkan adonan B ukuran 1 sdt)"
- "Ambil adonan A lalu gilas rata.lalu beri adonan B diatasnya kemudian gulung.dan gilas lagi.lalukan sampai 3 kali gulung dan gilasnya biar hasil kulitnya berlapis lapis."
- "Kemudian ambil isian lalu bulatkan terakhir pipihkan."
- "Adonan yang sudah selesai di bentuk susun di loyang yang telah dialasi baking paper.kemudian bakar.bila bagian bawah kue terlihat kekuningan kue bisa di balik lalu bakar lagi."
- "Kue pia yang sudah matang didinginkan lalu masukan toples biar awet dan tahan lama."
categories:
- Recipe
tags:
- bakpia
- kacang
- hijau

katakunci: bakpia kacang hijau 
nutrition: 144 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Lunch

---


![Bakpia kacang hijau](https://img-global.cpcdn.com/recipes/a74b8e0b70b874b1/680x482cq70/bakpia-kacang-hijau-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang setidaknya kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti bakpia kacang hijau yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan ciri khas yang merupakan keragaman Indonesia

Keharmonisan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Bakpia kacang hijau untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang dapat anda praktekkan salah satunya bakpia kacang hijau yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep bakpia kacang hijau tanpa harus bersusah payah.
Seperti resep Bakpia kacang hijau yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Bakpia kacang hijau:

1. Harus ada  Bahan Isian :
1. Tambah  Kacang hijau 100 gram(rendam 2 jam lalu rebus sampai matang)
1. Jangan lupa secukupnya Keju parut
1. Dibutuhkan 80 gram Gula pasir
1. Tambah 1 sachet Susu skm
1. Harap siapkan 1/2 sdt Garam
1. Diperlukan  Bahan A :(kulit)
1. Harap siapkan 150 gram Terigu
1. Harus ada 25 gram Gula halus
1. Dibutuhkan 50 gram Margarin
1. Harus ada 75 ml Air
1. Harap siapkan 1/2 sdt garam
1. Harus ada  Bahan B :(kulit)
1. Harus ada 100 gram Terigu
1. Tambah 55 gram Mentega
1. Jangan lupa 10 gram Maizena
1. Tambah 2 sdm Minyak goreng




<!--inarticleads2-->

##### Bagaimana membuat  Bakpia kacang hijau:

1. Kacang hijau yang sudah matang tiriskan.kemudian haluskan bersama gula pasir,skm dan garam.
1. Beri parutan keju secukupnya sesuai selera kemudian aduk rata.
1. Adonan isian dibentuk bulat bulat tapi sedikit di pipihkan
1. Campur adonan A dalam satu wadah aduk rata sampai kalis.Demikian juga dengan bahan B campur dalam satu wadah aduk rata sampai kalis. Diamkan adonan 20 menit.setelah itu masing masing adonan di bagi menjadi bola bola kecil dengan jumlah yang sama.(saya pakai ukuran 1/2 sdm untuk adonan A.sedangkan adonan B ukuran 1 sdt)
1. Ambil adonan A lalu gilas rata.lalu beri adonan B diatasnya kemudian gulung.dan gilas lagi.lalukan sampai 3 kali gulung dan gilasnya biar hasil kulitnya berlapis lapis.
1. Kemudian ambil isian lalu bulatkan terakhir pipihkan.
1. Adonan yang sudah selesai di bentuk susun di loyang yang telah dialasi baking paper.kemudian bakar.bila bagian bawah kue terlihat kekuningan kue bisa di balik lalu bakar lagi.
1. Kue pia yang sudah matang didinginkan lalu masukan toples biar awet dan tahan lama.




Demikianlah cara membuat bakpia kacang hijau yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
