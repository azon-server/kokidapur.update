---
description: "Panduan membuat Baso Aci (jajan kekinian) teraktual"
title: "Panduan membuat Baso Aci (jajan kekinian) teraktual"
slug: 323-panduan-membuat-baso-aci-jajan-kekinian-teraktual
date: 2020-12-04T21:28:52.124Z
image: https://img-global.cpcdn.com/recipes/c86988bd4be01e20/680x482cq70/baso-aci-jajan-kekinian-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c86988bd4be01e20/680x482cq70/baso-aci-jajan-kekinian-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c86988bd4be01e20/680x482cq70/baso-aci-jajan-kekinian-foto-resep-utama.jpg
author: Rena Ingram
ratingvalue: 4.6
reviewcount: 13862
recipeingredient:
- " bahan baso aci"
- "15 sdm tepung terigu"
- "8 sdm tepung sagutapioka"
- "250 ml air panas"
- "1/2 sdt bawang putih bubuk"
- "1 sdt garam"
- "1/4 sdt gula pasir tambahan dr aku"
- "1 sdt roycomasako"
- "1 helai daun bawang bagian yg hijau aja potong tipis"
- "1 sdm minyak goreng tambahan dr aku"
- "secukupnya daging cincang me kornet pronas 50 gr"
- " bahan kuah"
- "1 liter airkaldu sapi lbh enak"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "5 buah cabe merah besar"
- "3 buah cabe rawit merahsetan sesuaikan aja pedesnya"
- "2 sdt bubuk cabe"
- "1 helai daun bawang"
- "secukupnya ladagulagaram dan royco"
- " pelengkap"
- " mie basah"
- " otak2 goreng"
- " tahu kulit"
- " bawang goreng"
- "jika suka kecapsaus sambal"
recipeinstructions:
- "Siapkan semua bahan,bikin baso aci dulu. dalam wadah campur rata tepung terigu tepung aci/tapioka gula garam royco irisan daun bawang dan air panas. uleni rata kmd masukkan minyak goreng uleni lg hingga rata"
- "Bulat2 isi dg daging cincang/kornet. lakukan sampe habis"
- "Saya pake kornet pronas siap pakai"
- "Kmd panaskan air hingga mendidih lalu matikan api. masukkan baso aci. nyalakan lagi apinya rebus baso hingga matang"
- "Stlh matang tiriskan"
- "Siapkan bahan kuah. ulek halus duo bawang dan cabe. tumis hingga matang dan harum"
- "Setelah matang beri air/kaldu sedikit"
- "Dalam panci rebus kaldu hingga mendidih kmd masukkan bumbu tumisan. bumbui gula garam penyedap. cek rasa jika sdh pas masukkan irisan daun bawang. matikan api"
- "Siapkan bahan pelengkap di mangkok"
- "Siram kuah ke mangkok taburi bawang goreng. siap disajikan..tambahkan kecap dan saus sambal,, nyumm.."
- ""
categories:
- Recipe
tags:
- baso
- aci
- jajan

katakunci: baso aci jajan 
nutrition: 172 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Dessert

---


![Baso Aci (jajan kekinian)](https://img-global.cpcdn.com/recipes/c86988bd4be01e20/680x482cq70/baso-aci-jajan-kekinian-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga empuk. Ciri kuliner Indonesia baso aci (jajan kekinian) yang penuh dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Baso Aci (jajan kekinian) untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi budaya, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang bisa anda coba salah satunya baso aci (jajan kekinian) yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep baso aci (jajan kekinian) tanpa harus bersusah payah.
Berikut ini resep Baso Aci (jajan kekinian) yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 11 langkah dan 26 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Baso Aci (jajan kekinian):

1. Siapkan  bahan baso aci:
1. Dibutuhkan 15 sdm tepung terigu
1. Harus ada 8 sdm tepung sagu/tapioka
1. Harus ada 250 ml air panas
1. Harus ada 1/2 sdt bawang putih bubuk
1. Harap siapkan 1 sdt garam
1. Jangan lupa 1/4 sdt gula pasir (tambahan dr aku)
1. Jangan lupa 1 sdt royco/masako
1. Siapkan 1 helai daun bawang bagian yg hijau aja potong tipis
1. Dibutuhkan 1 sdm minyak goreng (tambahan dr aku)
1. Jangan lupa secukupnya daging cincang (me: kornet pronas 50 gr)
1. Diperlukan  bahan kuah:
1. Dibutuhkan 1 liter air(kaldu sapi lbh enak)
1. Tambah 6 siung bawang merah
1. Harus ada 4 siung bawang putih
1. Diperlukan 5 buah cabe merah besar
1. Harus ada 3 buah cabe rawit merah(setan), sesuaikan aja pedesnya
1. Tambah 2 sdt bubuk cabe
1. Diperlukan 1 helai daun bawang
1. Siapkan secukupnya lada,gula,garam dan royco
1. Siapkan  pelengkap:
1. Harus ada  mie basah
1. Diperlukan  otak2 goreng
1. Diperlukan  tahu kulit
1. Jangan lupa  bawang goreng
1. Diperlukan jika suka kecap/saus sambal




<!--inarticleads2-->

##### Bagaimana membuat  Baso Aci (jajan kekinian):

1. Siapkan semua bahan,bikin baso aci dulu. dalam wadah campur rata tepung terigu tepung aci/tapioka gula garam royco irisan daun bawang dan air panas. uleni rata kmd masukkan minyak goreng uleni lg hingga rata
1. Bulat2 isi dg daging cincang/kornet. lakukan sampe habis
1. Saya pake kornet pronas siap pakai
1. Kmd panaskan air hingga mendidih lalu matikan api. masukkan baso aci. nyalakan lagi apinya rebus baso hingga matang
1. Stlh matang tiriskan
1. Siapkan bahan kuah. ulek halus duo bawang dan cabe. tumis hingga matang dan harum
1. Setelah matang beri air/kaldu sedikit
1. Dalam panci rebus kaldu hingga mendidih kmd masukkan bumbu tumisan. bumbui gula garam penyedap. cek rasa jika sdh pas masukkan irisan daun bawang. matikan api
1. Siapkan bahan pelengkap di mangkok
1. Siram kuah ke mangkok taburi bawang goreng. siap disajikan..tambahkan kecap dan saus sambal,, nyumm..
1. 




Demikianlah cara membuat baso aci (jajan kekinian) yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
