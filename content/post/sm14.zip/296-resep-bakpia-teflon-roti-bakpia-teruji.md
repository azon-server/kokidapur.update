---
description: "Resep : Bakpia Teflon/Roti Bakpia Teruji"
title: "Resep : Bakpia Teflon/Roti Bakpia Teruji"
slug: 296-resep-bakpia-teflon-roti-bakpia-teruji
date: 2021-03-10T00:01:37.514Z
image: https://img-global.cpcdn.com/recipes/8dc16a379844a0bf/680x482cq70/bakpia-teflonroti-bakpia-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8dc16a379844a0bf/680x482cq70/bakpia-teflonroti-bakpia-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8dc16a379844a0bf/680x482cq70/bakpia-teflonroti-bakpia-foto-resep-utama.jpg
author: Kenneth Jennings
ratingvalue: 4
reviewcount: 10062
recipeingredient:
- "250 gr tepung terigu aq pke kunci biru"
- "6 gr ragi instan fermipan"
- "1 butir kuning telur"
- "100 cc air hangat"
- "3 sdm gula halus aq haluskan gulapasir takaran gula mnyesuaikan selera dan rasa isian"
- "50 gr margarin"
- "1/2 sdt garam"
- " bahan isian "
- "200 gr kacang hijau kupas aq rendam semalaman biar saat direbus cpt empuk dan ngga pke lama"
- "50 gr gula merah"
- "50 gr gulapasir"
- "400 ml santan"
- "1 sdt garam"
- "1 lembar daun pandan"
- " Rebus semua bahan sampai santan dan gula meresapaduk rata sampai benar2 setmasukan kulkas bbrpa jam agar lebih set dan mudah dibulat2kan"
recipeinstructions:
- "Dalam Wadah masukan tepung terigu,ragi instan,gulahalus dan kuning telur,aduk dan uleni sambil tuangi air hangat sdikit2 sampai stgh kalis,stop tuangi air klo adonan udah pas tercampur rata (ingat disini margarin blom masuk,jdi perkirakan takaran airnya)"
- "Campurkan Margarin dan garam uleni hingga tercampur rata,bila adonan terasa masih lembek &amp; lengket ditangan beri tepung terigu sdikit2 smpai adonan pas dan tidak lengket ditangan,uleni terus sampai permukaan adonan licin dan kalis."
- "Istirahatkan dan Bulatkan adonan,tutup dgn serbet/plastik wrap kurleb 45 mnit atau smpai mngembang 2x lipat."
- "Kempeskan Adonan,uleni sebntar saja utk mngeluarkan udara yg terkurung,bagi/timbang bulatkan adonan mnjadi bbrpa bagian (aq bagi jdi 15 buah)"
- "Isi tiap2 potongan adonan dgn bahan isian secukupnya,tutup dan bulatkan lalu pipihkan sdikit,lakukan hingga selesai,diamkan kmbli kurleb 20 menit."
- "Siapkan Teflon,panaskan dgn api sedang lalu kecilkan(aq pke api kecil sekali) susun bbrpa adonan pipihkan dan tekan2 pelan,tutup teflon,periksa dan bolak balik kedua sisinya,sampai adonan bakpia matang."
- "Sajikan hangat atau dingin sama2 enak dan Bakpia teflon ini masih empuk sampai keesokan harinya."
- "Note : Untuk Bahan Isian Sesuai selera masing2 yaa,aq pke kacang hijau kupas yg udah dibulat2kan sprti ini 😊"
categories:
- Recipe
tags:
- bakpia
- teflonroti
- bakpia

katakunci: bakpia teflonroti bakpia 
nutrition: 177 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dessert

---


![Bakpia Teflon/Roti Bakpia](https://img-global.cpcdn.com/recipes/8dc16a379844a0bf/680x482cq70/bakpia-teflonroti-bakpia-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang dapat kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti bakpia teflon/roti bakpia yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia



Kedekatan rumah tangga bisa didapat dengan cara simple. Salah satunya adalah membuat makanan Bakpia Teflon/Roti Bakpia untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang bisa anda contoh salah satunya bakpia teflon/roti bakpia yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep bakpia teflon/roti bakpia tanpa harus bersusah payah.
Seperti resep Bakpia Teflon/Roti Bakpia yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Bakpia Teflon/Roti Bakpia:

1. Harap siapkan 250 gr tepung terigu (aq pke kunci biru)
1. Tambah 6 gr ragi instan (fermipan)
1. Harap siapkan 1 butir kuning telur
1. Harap siapkan 100 cc air hangat
1. Harap siapkan 3 sdm gula halus (aq haluskan gulapasir, takaran gula mnyesuaikan selera dan rasa isian)
1. Harap siapkan 50 gr margarin
1. Jangan lupa 1/2 sdt garam
1. Dibutuhkan  bahan isian :
1. Siapkan 200 gr kacang hijau kupas (aq rendam semalaman biar saat direbus cpt empuk dan ngga pke lama)
1. Harap siapkan 50 gr gula merah
1. Harus ada 50 gr gulapasir
1. Siapkan 400 ml santan
1. Harap siapkan 1 sdt garam
1. Harap siapkan 1 lembar daun pandan
1. Diperlukan  (Rebus semua bahan sampai santan dan gula meresap,aduk rata sampai benar2 set,masukan kulkas bbrpa jam agar lebih set dan mudah dibulat2kan)




<!--inarticleads2-->

##### Instruksi membuat  Bakpia Teflon/Roti Bakpia:

1. Dalam Wadah masukan tepung terigu,ragi instan,gulahalus dan kuning telur,aduk dan uleni sambil tuangi air hangat sdikit2 sampai stgh kalis,stop tuangi air klo adonan udah pas tercampur rata (ingat disini margarin blom masuk,jdi perkirakan takaran airnya)
1. Campurkan Margarin dan garam uleni hingga tercampur rata,bila adonan terasa masih lembek &amp; lengket ditangan beri tepung terigu sdikit2 smpai adonan pas dan tidak lengket ditangan,uleni terus sampai permukaan adonan licin dan kalis.
1. Istirahatkan dan Bulatkan adonan,tutup dgn serbet/plastik wrap kurleb 45 mnit atau smpai mngembang 2x lipat.
1. Kempeskan Adonan,uleni sebntar saja utk mngeluarkan udara yg terkurung,bagi/timbang bulatkan adonan mnjadi bbrpa bagian (aq bagi jdi 15 buah)
1. Isi tiap2 potongan adonan dgn bahan isian secukupnya,tutup dan bulatkan lalu pipihkan sdikit,lakukan hingga selesai,diamkan kmbli kurleb 20 menit.
1. Siapkan Teflon,panaskan dgn api sedang lalu kecilkan(aq pke api kecil sekali) susun bbrpa adonan pipihkan dan tekan2 pelan,tutup teflon,periksa dan bolak balik kedua sisinya,sampai adonan bakpia matang.
1. Sajikan hangat atau dingin sama2 enak dan Bakpia teflon ini masih empuk sampai keesokan harinya.
1. Note : Untuk Bahan Isian Sesuai selera masing2 yaa,aq pke kacang hijau kupas yg udah dibulat2kan sprti ini 😊




Demikianlah cara membuat bakpia teflon/roti bakpia yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan cepat, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
