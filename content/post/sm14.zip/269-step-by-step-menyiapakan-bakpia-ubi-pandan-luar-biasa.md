---
description: "Step-by-Step menyiapakan Bakpia Ubi Pandan Luar biasa"
title: "Step-by-Step menyiapakan Bakpia Ubi Pandan Luar biasa"
slug: 269-step-by-step-menyiapakan-bakpia-ubi-pandan-luar-biasa
date: 2020-10-04T01:47:48.906Z
image: https://img-global.cpcdn.com/recipes/7b320eea0cf5e4d7/680x482cq70/bakpia-ubi-pandan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7b320eea0cf5e4d7/680x482cq70/bakpia-ubi-pandan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7b320eea0cf5e4d7/680x482cq70/bakpia-ubi-pandan-foto-resep-utama.jpg
author: Amanda Bailey
ratingvalue: 4
reviewcount: 31844
recipeingredient:
- " Bahan A "
- "100 gram tepung terigu segitiga biru"
- "50 gram tepung terigu cakra"
- "50 gram margarin"
- "2 sdm gula pasir"
- "1/2 sdt garam halus"
- "75 ml air"
- " Bahan B "
- "100 gram tepung terigu segitiga biru"
- "50 gram margarin"
- "1 sdm minyak sayur"
- " Bahan isian "
- "250 gram ubi jalar kukus haluskan"
- "2 sdm margarin"
- "2 sdm susu bubuk"
- "5 sdm gula halus sesuai selera"
- "1/2 sdt vanili bubuk"
- "1/2 sdt pasta pandan"
recipeinstructions:
- "Campur semua bahan isi, masak di panci anti lengket sampai tercampur rata dan kering. Angkat dan biarkan dingin. Lalu bulatkan menjadi 20 bulatan. Sisihkan."
- "Campur semua bahan A, uleni sampai merata dan lembut. Bentuk bulat dan diamkan selama 20 menit. Tutup dengan plastik. Sisihkan."
- "Campur semua bahan B, uleni sampai tercampur merata. Bulatkan dan diamkan selama 20 menit. Tutup dengan plastik. Sisihkan."
- "Setelah 20 menit, bagi adonan A dan adonan B, masing&#34;menjadi bulatan&#34; kecil 20 bagian."
- "Ambil 1 adonan A, pipihkan. Letakkan 1 adonan B di atas adonan A pipihkan. Gulung adonan memanjang. Kemudian gilas memanjang. Lalu gulung lagi. Dan gilas lagi melebar. Beri isian di tengah adonan. Tutup adonan yang rapat. Bentuk bulat. Pipihkan sedikit. Sisihkan. Lakukan sampai adonan habis. 👉Tips: jika adonan pas digilas takud bocor, sblm menggilas taburi dlu adonan dengan sedikit tepung."
- "Panaskan oven/teflon terlebih dahulu. Klo pake oven panaskan 150&#39; disesuaikan oven masing&#34;."
- "Ambil loyang dan olesi dengan sedikit margarin. Tata bakpia dalam loyang."
- "Panggang bakpia selama 20 menit dengan api kecil, lalu balik. Sampai berwarna kecoklatan. Kemudian panggang lagi selama 20 menit. Sampai permukaan kedua sisinya kecoklatan. Disesuaikan dengan oven masing&#34; yaa.."
- "Kalau aku pake teflon. Aku taruh loyang kue lagi didalam teflon. Lalu tutup teflon aku lapisi lap bersih. Aku panggang awal 25 menit dengan api kecil, lalu balik, panggang lagi selama 25 menit. Tetap disesuaikn dengan teflon masing&#34;."
- "Kalau panggang di teflon, sedikit ribet yaa.. Karna ndak bisa sekaligus manggang. Jadi 2x manggang."
- "Angkat bakpia dan sajikan dengan di temani secangkir teh hangat."
categories:
- Recipe
tags:
- bakpia
- ubi
- pandan

katakunci: bakpia ubi pandan 
nutrition: 163 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Dinner

---


![Bakpia Ubi Pandan](https://img-global.cpcdn.com/recipes/7b320eea0cf5e4d7/680x482cq70/bakpia-ubi-pandan-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang harus kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti bakpia ubi pandan yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa ciri khas yang merupakan keragaman Kita



Kehangatan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Bakpia Ubi Pandan untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang dapat anda contoh salah satunya bakpia ubi pandan yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu bisa dengan gampang menemukan resep bakpia ubi pandan tanpa harus bersusah payah.
Seperti resep Bakpia Ubi Pandan yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 11 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Bakpia Ubi Pandan:

1. Tambah  Bahan A :
1. Harus ada 100 gram tepung terigu segitiga biru
1. Jangan lupa 50 gram tepung terigu cakra
1. Jangan lupa 50 gram margarin
1. Siapkan 2 sdm gula pasir
1. Harus ada 1/2 sdt garam halus
1. Jangan lupa 75 ml air
1. Harap siapkan  Bahan B :
1. Diperlukan 100 gram tepung terigu segitiga biru
1. Tambah 50 gram margarin
1. Dibutuhkan 1 sdm minyak sayur
1. Siapkan  Bahan isian :
1. Tambah 250 gram ubi jalar kukus, haluskan
1. Siapkan 2 sdm margarin
1. Diperlukan 2 sdm susu bubuk
1. Diperlukan 5 sdm gula halus, sesuai selera
1. Dibutuhkan 1/2 sdt vanili bubuk
1. Harus ada 1/2 sdt pasta pandan




<!--inarticleads2-->

##### Cara membuat  Bakpia Ubi Pandan:

1. Campur semua bahan isi, masak di panci anti lengket sampai tercampur rata dan kering. Angkat dan biarkan dingin. Lalu bulatkan menjadi 20 bulatan. Sisihkan.
1. Campur semua bahan A, uleni sampai merata dan lembut. Bentuk bulat dan diamkan selama 20 menit. Tutup dengan plastik. Sisihkan.
1. Campur semua bahan B, uleni sampai tercampur merata. Bulatkan dan diamkan selama 20 menit. Tutup dengan plastik. Sisihkan.
1. Setelah 20 menit, bagi adonan A dan adonan B, masing&#34;menjadi bulatan&#34; kecil 20 bagian.
1. Ambil 1 adonan A, pipihkan. Letakkan 1 adonan B di atas adonan A pipihkan. Gulung adonan memanjang. Kemudian gilas memanjang. Lalu gulung lagi. Dan gilas lagi melebar. Beri isian di tengah adonan. Tutup adonan yang rapat. Bentuk bulat. Pipihkan sedikit. Sisihkan. Lakukan sampai adonan habis. 👉Tips: jika adonan pas digilas takud bocor, sblm menggilas taburi dlu adonan dengan sedikit tepung.
1. Panaskan oven/teflon terlebih dahulu. Klo pake oven panaskan 150&#39; disesuaikan oven masing&#34;.
1. Ambil loyang dan olesi dengan sedikit margarin. Tata bakpia dalam loyang.
1. Panggang bakpia selama 20 menit dengan api kecil, lalu balik. Sampai berwarna kecoklatan. Kemudian panggang lagi selama 20 menit. Sampai permukaan kedua sisinya kecoklatan. Disesuaikan dengan oven masing&#34; yaa..
1. Kalau aku pake teflon. Aku taruh loyang kue lagi didalam teflon. Lalu tutup teflon aku lapisi lap bersih. Aku panggang awal 25 menit dengan api kecil, lalu balik, panggang lagi selama 25 menit. Tetap disesuaikn dengan teflon masing&#34;.
1. Kalau panggang di teflon, sedikit ribet yaa.. Karna ndak bisa sekaligus manggang. Jadi 2x manggang.
1. Angkat bakpia dan sajikan dengan di temani secangkir teh hangat.




Demikianlah cara membuat bakpia ubi pandan yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
