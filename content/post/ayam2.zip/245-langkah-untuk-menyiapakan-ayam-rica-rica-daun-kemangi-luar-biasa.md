---
description: "Langkah untuk menyiapakan Ayam Rica-Rica daun kemangi Luar biasa"
title: "Langkah untuk menyiapakan Ayam Rica-Rica daun kemangi Luar biasa"
slug: 245-langkah-untuk-menyiapakan-ayam-rica-rica-daun-kemangi-luar-biasa
date: 2020-08-12T00:03:24.249Z
image: https://img-global.cpcdn.com/recipes/6be0541143ff04db/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6be0541143ff04db/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6be0541143ff04db/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Evelyn Waters
ratingvalue: 4.9
reviewcount: 11800
recipeingredient:
- "1/2 ekor ayam"
- "5 ikat kecil daun kemangi"
- "5 buah cabe merah"
- "4 buah cabe rawit"
- "5 siung bawang merah"
- "4 siung bawang putih"
- "2 buah kemiri"
- "2 cm lengkuas"
- "1 lembar salam"
- "3 lembar daun jeruk"
- "Secukupnya garam"
- "Secukupnya penyedap rasa"
- "Secukupnya gula merah"
- "1 batang serai"
recipeinstructions:
- "Siapkan bahan-bahan cuci bersih."
- "Haluskan bumbu kemudian tumis sampai harum, masukan daun salam, daun jeruk, lengkuas dan serai."
- "Masukan air hingga mendidih. Masukan ayam. Tambahkan garam, Gula dan penyedap rasa"
- "Masak sampai air menyusut dan ayam empuk. Koreksi rasa. Kalau sudah hampir matang masukan daun kemangi."
categories:
- Recipe
tags:
- ayam
- ricarica
- daun

katakunci: ayam ricarica daun 
nutrition: 201 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica-Rica daun kemangi](https://img-global.cpcdn.com/recipes/6be0541143ff04db/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga empuk. Ciri khas masakan Indonesia ayam rica-rica daun kemangi yang penuh dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Keharmonisan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica-Rica daun kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang bisa anda buat salah satunya ayam rica-rica daun kemangi yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica-rica daun kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica daun kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica daun kemangi:

1. Siapkan 1/2 ekor ayam
1. Jangan lupa 5 ikat kecil daun kemangi
1. Harap siapkan 5 buah cabe merah
1. Tambah 4 buah cabe rawit
1. Harap siapkan 5 siung bawang merah
1. Dibutuhkan 4 siung bawang putih
1. Harap siapkan 2 buah kemiri
1. Harap siapkan 2 cm lengkuas
1. Jangan lupa 1 lembar salam
1. Siapkan 3 lembar daun jeruk
1. Harap siapkan Secukupnya garam
1. Harap siapkan Secukupnya penyedap rasa
1. Dibutuhkan Secukupnya gula merah
1. Dibutuhkan 1 batang serai




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica daun kemangi:

1. Siapkan bahan-bahan cuci bersih.
1. Haluskan bumbu kemudian tumis sampai harum, masukan daun salam, daun jeruk, lengkuas dan serai.
1. Masukan air hingga mendidih. Masukan ayam. Tambahkan garam, Gula dan penyedap rasa
1. Masak sampai air menyusut dan ayam empuk. Koreksi rasa. Kalau sudah hampir matang masukan daun kemangi.




Demikianlah cara membuat ayam rica-rica daun kemangi yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
