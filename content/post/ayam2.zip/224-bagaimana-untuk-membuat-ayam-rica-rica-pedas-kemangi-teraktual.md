---
description: "Bagaimana untuk membuat Ayam Rica-Rica Pedas Kemangi teraktual"
title: "Bagaimana untuk membuat Ayam Rica-Rica Pedas Kemangi teraktual"
slug: 224-bagaimana-untuk-membuat-ayam-rica-rica-pedas-kemangi-teraktual
date: 2020-10-15T23:44:26.621Z
image: https://img-global.cpcdn.com/recipes/70fe4d1a847382bb/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/70fe4d1a847382bb/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/70fe4d1a847382bb/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
author: Steven Abbott
ratingvalue: 4
reviewcount: 32484
recipeingredient:
- "6 potong ayam"
- "sesuai selera Tempe dipotong kecil2"
- "2 daun jeruk"
- "1 daun salam"
- "1 ikat kemangi"
- "1 batang sereh digeprek"
- " Gula"
- " Totole kaldu jamur"
- " Bumbu halus"
- "5 bawang merah"
- "2 bawang putih"
- "1 ruas jahe"
- "1 ruas laos"
- " Kunyit secukupnya saya pake kunyit bubuk desaku"
- " Ketumbar sedikit saya pake ketumbar bubuk desaku"
- "5 cabe rawit kecil"
- "1 cabe merah besar"
- "secukupnya Garam"
recipeinstructions:
- "Rebus ayam terlebih dahulu (saya merebusnya dikasih garam sedikit)"
- "Didihkan air, rebus ayam hingga matang. Lalu tiriskan"
- "Bahan2 yang dihaluskan (bawang merah, bawang putih, jahe, laos, kunyit, ketumbar, garam). Boleh diulek boleh pake blender"
- "Panaskan wajan, beri minyak sedikit. Lalu tumis bumbu halus. Masukkan daun jeruk, daun salam, dan sereh. Tumis hingga harum."
- "Setelah harum, beri air secukupnya. Masukkan tempe yg sudah dipotong. Didihkan hingga tempe matang"
- "Lalu masukkan ayam yang sudah direbus. Beri garam, gula, totole. Koreksi rasa. Tunggu hingga bumbu meresap ke dalam ayam dan tempe. Terakhir masukkan daun kemangi. Lalu aduk hingga merata."
categories:
- Recipe
tags:
- ayam
- ricarica
- pedas

katakunci: ayam ricarica pedas 
nutrition: 161 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica-Rica Pedas Kemangi](https://img-global.cpcdn.com/recipes/70fe4d1a847382bb/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica-rica pedas kemangi yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia

Kehangatan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica-Rica Pedas Kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda buat salah satunya ayam rica-rica pedas kemangi yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep ayam rica-rica pedas kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Pedas Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica Pedas Kemangi:

1. Dibutuhkan 6 potong ayam
1. Dibutuhkan sesuai selera Tempe dipotong kecil2
1. Harus ada 2 daun jeruk
1. Harap siapkan 1 daun salam
1. Jangan lupa 1 ikat kemangi
1. Diperlukan 1 batang sereh digeprek
1. Harap siapkan  Gula
1. Diperlukan  Totole kaldu jamur
1. Diperlukan  Bumbu halus
1. Jangan lupa 5 bawang merah
1. Jangan lupa 2 bawang putih
1. Tambah 1 ruas jahe
1. Diperlukan 1 ruas laos
1. Tambah  Kunyit secukupnya (saya pake kunyit bubuk desaku)
1. Dibutuhkan  Ketumbar sedikit (saya pake ketumbar bubuk desaku)
1. Diperlukan 5 cabe rawit kecil
1. Harus ada 1 cabe merah besar
1. Diperlukan secukupnya Garam




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica Pedas Kemangi:

1. Rebus ayam terlebih dahulu (saya merebusnya dikasih garam sedikit)
1. Didihkan air, rebus ayam hingga matang. Lalu tiriskan
1. Bahan2 yang dihaluskan (bawang merah, bawang putih, jahe, laos, kunyit, ketumbar, garam). Boleh diulek boleh pake blender
1. Panaskan wajan, beri minyak sedikit. Lalu tumis bumbu halus. Masukkan daun jeruk, daun salam, dan sereh. Tumis hingga harum.
1. Setelah harum, beri air secukupnya. Masukkan tempe yg sudah dipotong. Didihkan hingga tempe matang
1. Lalu masukkan ayam yang sudah direbus. Beri garam, gula, totole. Koreksi rasa. Tunggu hingga bumbu meresap ke dalam ayam dan tempe. Terakhir masukkan daun kemangi. Lalu aduk hingga merata.




Demikianlah cara membuat ayam rica-rica pedas kemangi yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan teruji, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
