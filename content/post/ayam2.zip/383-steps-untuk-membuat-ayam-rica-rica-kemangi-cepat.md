---
description: "Steps untuk membuat Ayam Rica-rica Kemangi Cepat"
title: "Steps untuk membuat Ayam Rica-rica Kemangi Cepat"
slug: 383-steps-untuk-membuat-ayam-rica-rica-kemangi-cepat
date: 2020-10-04T06:30:01.224Z
image: https://img-global.cpcdn.com/recipes/81b9f6d22e3871d0/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/81b9f6d22e3871d0/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/81b9f6d22e3871d0/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Josie White
ratingvalue: 4.2
reviewcount: 20756
recipeingredient:
- "1/2 kg dada ayam fillet"
- " Daun kemangi"
- " Daun jeruk"
- "1 ruas Jahe"
- "1 ruas Lengkuas"
- " Tomat"
- " Bumbu Halus"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "7 pcs cabe rawit merah"
- "1 ruas kunyit"
- "2 butir kemiri"
recipeinstructions:
- "Potong dada ayam fillet sesuai selera. Sisihkan."
- "Tumis bumbu halus sampai harum. Masukkan jahe, lengkuas, daun jeruk aduk-aduk sampai harum"
- "Masukkan dada ayam yang sudah dipotong, tambahkan air sedikit. Aduk-aduk sampai tercampur rata."
- "Tambahkan gula, garam, penyedap rasa. Test rasa."
- "Terakhir masukkan daun kemangi dan tomat, aduk pelan-pelan supaya tomat tidak hancur."
- "Ayam rica-rica kemangi siap dihidangkan."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 102 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/81b9f6d22e3871d0/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita lestarikan karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan ciri khas yang merupakan keragaman Kita



Keharmonisan rumah tangga dapat didapat dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Rica-rica Kemangi untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang bisa anda buat salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 12 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Kemangi:

1. Diperlukan 1/2 kg dada ayam fillet
1. Tambah  Daun kemangi
1. Dibutuhkan  Daun jeruk
1. Harus ada 1 ruas Jahe
1. Jangan lupa 1 ruas Lengkuas
1. Harap siapkan  Tomat
1. Tambah  Bumbu Halus
1. Diperlukan 6 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Jangan lupa 7 pcs cabe rawit merah
1. Siapkan 1 ruas kunyit
1. Harap siapkan 2 butir kemiri




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-rica Kemangi:

1. Potong dada ayam fillet sesuai selera. Sisihkan.
1. Tumis bumbu halus sampai harum. Masukkan jahe, lengkuas, daun jeruk aduk-aduk sampai harum
1. Masukkan dada ayam yang sudah dipotong, tambahkan air sedikit. Aduk-aduk sampai tercampur rata.
1. Tambahkan gula, garam, penyedap rasa. Test rasa.
1. Terakhir masukkan daun kemangi dan tomat, aduk pelan-pelan supaya tomat tidak hancur.
1. Ayam rica-rica kemangi siap dihidangkan.




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
