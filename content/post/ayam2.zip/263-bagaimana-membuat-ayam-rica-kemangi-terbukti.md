---
description: "Bagaimana membuat Ayam Rica Kemangi 🍃 Terbukti"
title: "Bagaimana membuat Ayam Rica Kemangi 🍃 Terbukti"
slug: 263-bagaimana-membuat-ayam-rica-kemangi-terbukti
date: 2020-10-16T01:01:09.365Z
image: https://img-global.cpcdn.com/recipes/0a1e36b8872cf94d/751x532cq70/ayam-rica-kemangi-🍃-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0a1e36b8872cf94d/751x532cq70/ayam-rica-kemangi-🍃-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0a1e36b8872cf94d/751x532cq70/ayam-rica-kemangi-🍃-foto-resep-utama.jpg
author: Lucas Simon
ratingvalue: 4.1
reviewcount: 41150
recipeingredient:
- "1/2 kg Ayam"
- " Bumbu Halus "
- "4 siung Bawang Merah"
- "5 siung Bawang Putih"
- "10 biji Cabe Merang Keriting"
- "sesuai selera Cabe Rawit"
- "1 buah Kemiri"
- " Tambahan bumbu "
- "1 batang Serai"
- "2 lbr Daun Salam"
- "3 lbr Daun Jeruk"
- "1 ruas Lengkuas"
- "Secukupnya Daun Kemangi"
- " Garam penyedap gula"
recipeinstructions:
- "Bersihkan ayam sampai benar benar bersih. Lalu goreng hingga matang. Bisa di rebus dulu atau mau di goreng langsung juga boleh."
- "Masukan bumbu halus beserta salam, serai, lengkuas dan daun jeruk. Lalu tambahkan bumbu penyedap. Tes rasa lalu masukan ayam."
- "Setelah itu masukan air secukupnya. Tunggu bumbu hingga agak menyusut. Lalu masukan daun kemangi."
- "Setelah air menyusut, matikan kompor. Lalu sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 284 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica Kemangi 🍃](https://img-global.cpcdn.com/recipes/0a1e36b8872cf94d/751x532cq70/ayam-rica-kemangi-🍃-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang harus kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica kemangi 🍃 yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan keistimewahan yang merupakan keragaman Nusantara

Keharmonisan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam Rica Kemangi 🍃 untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang bisa anda praktekkan salah satunya ayam rica kemangi 🍃 yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica kemangi 🍃 tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi 🍃 yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi 🍃:

1. Siapkan 1/2 kg Ayam
1. Jangan lupa  Bumbu Halus :
1. Tambah 4 siung Bawang Merah
1. Siapkan 5 siung Bawang Putih
1. Siapkan 10 biji Cabe Merang Keriting
1. Dibutuhkan sesuai selera Cabe Rawit
1. Dibutuhkan 1 buah Kemiri
1. Harus ada  Tambahan bumbu :
1. Dibutuhkan 1 batang Serai
1. Diperlukan 2 lbr Daun Salam
1. Jangan lupa 3 lbr Daun Jeruk
1. Tambah 1 ruas Lengkuas
1. Siapkan Secukupnya Daun Kemangi
1. Dibutuhkan  Garam, penyedap, gula




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Kemangi 🍃:

1. Bersihkan ayam sampai benar benar bersih. Lalu goreng hingga matang. Bisa di rebus dulu atau mau di goreng langsung juga boleh.
1. Masukan bumbu halus beserta salam, serai, lengkuas dan daun jeruk. Lalu tambahkan bumbu penyedap. Tes rasa lalu masukan ayam.
1. Setelah itu masukan air secukupnya. Tunggu bumbu hingga agak menyusut. Lalu masukan daun kemangi.
1. Setelah air menyusut, matikan kompor. Lalu sajikan




Demikianlah cara membuat ayam rica kemangi 🍃 yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan terbukti, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
