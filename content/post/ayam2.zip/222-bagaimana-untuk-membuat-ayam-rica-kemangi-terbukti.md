---
description: "Bagaimana untuk membuat Ayam Rica Kemangi Terbukti"
title: "Bagaimana untuk membuat Ayam Rica Kemangi Terbukti"
slug: 222-bagaimana-untuk-membuat-ayam-rica-kemangi-terbukti
date: 2020-12-09T20:56:21.891Z
image: https://img-global.cpcdn.com/recipes/5b512e02c7c8e3b0/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5b512e02c7c8e3b0/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5b512e02c7c8e3b0/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Adelaide Edwards
ratingvalue: 4
reviewcount: 23851
recipeingredient:
- " Bahan utama"
- "10 potong ayam"
- "1 buah lemon untuk marinasi"
- "1 ikat kemangi petik daunnya"
- " Bahan yang dihaluskandirajang"
- "6 siung bawang merah"
- "1 siung bawang putih"
- "5 buah cabe merah atau tambah rawit bila suka pedas"
- "1 cm jahe"
- "3 cm kunyit"
- "1 batang sereh memarkan"
- "2 lembar daun salam"
- "3 lembar daun jeruk iris2"
recipeinstructions:
- "Bersihkan ayam. Lumuri dengan perasan jeruk nipis. Simpan di kulkas selama 15 menit. Petik daun kemangi, sisinkan."
- "Siapkan bumbu yg akan dihaluskan/diiris."
- "Haluskan bawang, kunyit, jahe, cabe, dengan ulekan atau blender. Iris daun jeruk, memarkan sereh. Sisihkan bersama daun salam."
- "Siapkan minyak panas di wajan. Tumis bumbu halus hingga harum. Kemudian masukkan daun salam, daun jeruj,.dan sereh. Lanjutkan tumis sampai harum/matang."
- "Masukkan potongan ayam, aduk2 masak hingga kira2 dagingnya sudah tidak terlihat merah atau bumbu meresap. Beri air secukupnya. Tambakan garam dan gula pasir. Test rasa. Tutup wajan dan masak sampai kuah ayam sedikit mengering/meresap dan dagingnya empuk."
- "Setelah daging empuk dan rasa sudah oke, masukkan daun kemangi, aduk2 sebentar, lalu matikan kompor."
- "Ayam Rica Kemangi siap dinikmati."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 283 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/5b512e02c7c8e3b0/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang harus kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica kemangi yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan ciri khas yang merupakan keragaman Kita

Kehangatan rumah tangga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Rica Kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang dapat anda praktekkan salah satunya ayam rica kemangi yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Jangan lupa  Bahan utama
1. Diperlukan 10 potong ayam
1. Harus ada 1 buah lemon untuk marinasi
1. Harus ada 1 ikat kemangi, petik daunnya
1. Tambah  Bahan yang dihaluskan/dirajang
1. Diperlukan 6 siung bawang merah
1. Dibutuhkan 1 siung bawang putih
1. Tambah 5 buah cabe merah, atau tambah rawit bila suka pedas
1. Tambah 1 cm jahe
1. Harus ada 3 cm kunyit
1. Diperlukan 1 batang sereh, memarkan
1. Harus ada 2 lembar daun salam
1. Diperlukan 3 lembar daun jeruk, iris2




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Kemangi:

1. Bersihkan ayam. Lumuri dengan perasan jeruk nipis. Simpan di kulkas selama 15 menit. Petik daun kemangi, sisinkan.
1. Siapkan bumbu yg akan dihaluskan/diiris.
1. Haluskan bawang, kunyit, jahe, cabe, dengan ulekan atau blender. Iris daun jeruk, memarkan sereh. Sisihkan bersama daun salam.
1. Siapkan minyak panas di wajan. Tumis bumbu halus hingga harum. Kemudian masukkan daun salam, daun jeruj,.dan sereh. Lanjutkan tumis sampai harum/matang.
1. Masukkan potongan ayam, aduk2 masak hingga kira2 dagingnya sudah tidak terlihat merah atau bumbu meresap. Beri air secukupnya. Tambakan garam dan gula pasir. Test rasa. Tutup wajan dan masak sampai kuah ayam sedikit mengering/meresap dan dagingnya empuk.
1. Setelah daging empuk dan rasa sudah oke, masukkan daun kemangi, aduk2 sebentar, lalu matikan kompor.
1. Ayam Rica Kemangi siap dinikmati.




Demikianlah cara membuat ayam rica kemangi yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
