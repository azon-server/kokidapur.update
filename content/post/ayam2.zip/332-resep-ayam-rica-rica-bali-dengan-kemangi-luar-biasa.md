---
description: "Resep : Ayam Rica Rica Bali dengan Kemangi Luar biasa"
title: "Resep : Ayam Rica Rica Bali dengan Kemangi Luar biasa"
slug: 332-resep-ayam-rica-rica-bali-dengan-kemangi-luar-biasa
date: 2021-01-02T14:47:16.826Z
image: https://img-global.cpcdn.com/recipes/dbb141b4a432bd25/751x532cq70/ayam-rica-rica-bali-dengan-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dbb141b4a432bd25/751x532cq70/ayam-rica-rica-bali-dengan-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dbb141b4a432bd25/751x532cq70/ayam-rica-rica-bali-dengan-kemangi-foto-resep-utama.jpg
author: Sam Williams
ratingvalue: 4.1
reviewcount: 38454
recipeingredient:
- "1 ekor ayam"
- "1 jeruk nipis utk merendam ayam"
- " Kemangi"
- "Secukupnya garam"
- "1 sendok teh gula pasir"
- "2 sendok makan kecap manis"
- " Kaldu bubuk"
- "2 batang serai digeprek"
- " Lengkuas digeprek"
- "4 lembar daun jeruk"
- "1 sendok teh trasi"
- "2 sendok makan minyak untuk menumis"
- " Bumbu yg dihaluskan  diblender"
- "5 Bawang merah"
- "4 Bawang putih"
- "10 Cabe merah keriting"
- "5 Cabe rawit merah sesuai selera"
- "1 ibu jari jahe"
- "1 buah tomat yg besar"
recipeinstructions:
- "Potong2 ayam cuci bersih, rendam dengan air jeruk nipis dan sedikit garam selama 10 menit. Kemudian cuci bersih. Tiriskan"
- "Tumis bumbu2 yg sudah dihaluskan, masukkan lengkuas, sere, daun jeruk, terasi, kaldu bubuk, garam dan gula secukupnya, tumis sampai wangi"
- "Kemudian masukkan ayam, sedikit kecap manis, aduk2, tutup agar merata matangnya."
- "Setelah air menyusut, masukkan daun kemangi, aduk2 sebentar, cek rasa. Jika sudah pas, rica2 ayam siap dihidangkan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 168 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT43M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica Rica Bali dengan Kemangi](https://img-global.cpcdn.com/recipes/dbb141b4a432bd25/751x532cq70/ayam-rica-rica-bali-dengan-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang patut kita jaga karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica rica bali dengan kemangi yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan keistimewahan yang merupakan keragaman Kita

Kedekatan keluarga dapat didapat dengan cara simple. Salah satunya adalah memasak Ayam Rica Rica Bali dengan Kemangi untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang dapat anda praktekkan salah satunya ayam rica rica bali dengan kemangi yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep ayam rica rica bali dengan kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Bali dengan Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Bali dengan Kemangi:

1. Diperlukan 1 ekor ayam
1. Harus ada 1 jeruk nipis utk merendam ayam
1. Dibutuhkan  Kemangi
1. Harap siapkan Secukupnya garam
1. Jangan lupa 1 sendok teh gula pasir
1. Tambah 2 sendok makan kecap manis
1. Diperlukan  Kaldu bubuk
1. Harus ada 2 batang serai digeprek
1. Harap siapkan  Lengkuas digeprek
1. Jangan lupa 4 lembar daun jeruk
1. Tambah 1 sendok teh trasi
1. Diperlukan 2 sendok makan minyak untuk menumis
1. Tambah  Bumbu yg dihaluskan / diblender:
1. Tambah 5 Bawang merah
1. Harus ada 4 Bawang putih
1. Harap siapkan 10 Cabe merah keriting
1. Jangan lupa 5 Cabe rawit merah (sesuai selera)
1. Jangan lupa 1 ibu jari jahe
1. Tambah 1 buah tomat yg besar




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Rica Bali dengan Kemangi:

1. Potong2 ayam cuci bersih, rendam dengan air jeruk nipis dan sedikit garam selama 10 menit. Kemudian cuci bersih. Tiriskan
1. Tumis bumbu2 yg sudah dihaluskan, masukkan lengkuas, sere, daun jeruk, terasi, kaldu bubuk, garam dan gula secukupnya, tumis sampai wangi
1. Kemudian masukkan ayam, sedikit kecap manis, aduk2, tutup agar merata matangnya.
1. Setelah air menyusut, masukkan daun kemangi, aduk2 sebentar, cek rasa. Jika sudah pas, rica2 ayam siap dihidangkan




Demikianlah cara membuat ayam rica rica bali dengan kemangi yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
