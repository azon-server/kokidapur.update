---
description: "Resep : Ayam Rica Kemangi minggu ini"
title: "Resep : Ayam Rica Kemangi minggu ini"
slug: 280-resep-ayam-rica-kemangi-minggu-ini
date: 2020-12-21T04:14:52.356Z
image: https://img-global.cpcdn.com/recipes/d9a820cdc98ca8db/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d9a820cdc98ca8db/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d9a820cdc98ca8db/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Stanley Williamson
ratingvalue: 4.1
reviewcount: 39470
recipeingredient:
- " Bahan"
- "250 gr ayam potong"
- " Air secukupnya utk merebus ayam"
- " Minyak goreng utk menggoreng ayam"
- " Bumbu Halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "3 biji kemiri"
- "11 biji cabe rawit"
- "4 biji cabe merah buang isinya"
- "1 ruas jahe kecil"
- "1 ruas kunyit sedang"
- "1 ruas lengkuas kecil"
- "secukupnya Garam dan Gula"
- " Bumbu Pelengkap"
- "2 lembar daun jeruk gunting tipis"
- "2 lembar daun salam"
- "1 btg sereh digeprek"
- "1/2 ikat kemangi"
recipeinstructions:
- "Rebus ayam dg garam secukupnya kurleb 10 menit utk buang lemaknya. Buang airnya, bilas lagi dg air matang. Goreng ayam hingga setengah matang."
- "Blender smua bumbu halus. Tumis bumbu halus smp harum. Tambahkan daun jeruk, daun salam, dan sereh. Test rasa. Masukkan ayam yg sudah di goreng. Tumis lg. lalu, Tambahkan 300ml air agar bumbu meresap ke dlm ayam. Tambahkan daun kemangi saat air mulai menyusut. Aduk hingga layu. Test rasa."
- "Ayam rica kemangi obat rindu makan di kantin kampus siap disantap.. sy beri telur rebus biar lebih mantab.."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 227 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/d9a820cdc98ca8db/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau renyah. Ciri kuliner Indonesia ayam rica kemangi yang kaya dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica Kemangi untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang bisa anda contoh salah satunya ayam rica kemangi yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Dibutuhkan  Bahan
1. Tambah 250 gr ayam potong
1. Dibutuhkan  Air secukupnya utk merebus ayam
1. Harus ada  Minyak goreng utk menggoreng ayam
1. Dibutuhkan  Bumbu Halus
1. Harap siapkan 5 siung bawang merah
1. Harap siapkan 3 siung bawang putih
1. Siapkan 3 biji kemiri
1. Tambah 11 biji cabe rawit
1. Dibutuhkan 4 biji cabe merah (buang isinya)
1. Siapkan 1 ruas jahe (kecil)
1. Dibutuhkan 1 ruas kunyit (sedang)
1. Jangan lupa 1 ruas lengkuas (kecil)
1. Diperlukan secukupnya Garam dan Gula
1. Tambah  Bumbu Pelengkap
1. Siapkan 2 lembar daun jeruk (gunting tipis)
1. Jangan lupa 2 lembar daun salam
1. Harus ada 1 btg sereh (digeprek)
1. Tambah 1/2 ikat kemangi




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Kemangi:

1. Rebus ayam dg garam secukupnya kurleb 10 menit utk buang lemaknya. Buang airnya, bilas lagi dg air matang. Goreng ayam hingga setengah matang.
1. Blender smua bumbu halus. Tumis bumbu halus smp harum. Tambahkan daun jeruk, daun salam, dan sereh. Test rasa. Masukkan ayam yg sudah di goreng. Tumis lg. lalu, Tambahkan 300ml air agar bumbu meresap ke dlm ayam. Tambahkan daun kemangi saat air mulai menyusut. Aduk hingga layu. Test rasa.
1. Ayam rica kemangi obat rindu makan di kantin kampus siap disantap.. sy beri telur rebus biar lebih mantab..




Demikianlah cara membuat ayam rica kemangi yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan terbukti, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
