---
description: "Bagaimana untuk membuat Ayam Rica-rica Pedas Kemangi Cepat"
title: "Bagaimana untuk membuat Ayam Rica-rica Pedas Kemangi Cepat"
slug: 227-bagaimana-untuk-membuat-ayam-rica-rica-pedas-kemangi-cepat
date: 2020-10-24T06:27:26.020Z
image: https://img-global.cpcdn.com/recipes/0fbe6bc28195c770/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0fbe6bc28195c770/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0fbe6bc28195c770/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
author: Albert Guerrero
ratingvalue: 4.8
reviewcount: 1048
recipeingredient:
- "1/2 ekor ayam yg sudah direbus dan dipotong sesuai selera tanpa direbus juga boleh"
- "3 lembar daun salam"
- "3 lembar daun jeruk purut"
- "2 batang serai geprek"
- "5 cm lengkuas geprek"
- "1 genggam daunh kemangi"
- "1 lembar daun kunyit"
- "1 batang daun bawang"
- " Bumbu halus "
- "7 siung bawang merah"
- "3 siung bawang putih"
- "6 cm kunyit"
- "6 cm jahe"
- "4 butir kemiri sangrai"
- "1 sdm ketumbar sangrai"
- " Cabe rawit secukupnya bisa banyak bila mau pedes banget"
- "2 buah tomat"
- "500 ml air masak"
- " Minyak goreng utk menumis bumbu"
- "sesuai selera Garam dan penyedap rasa ayam"
recipeinstructions:
- "Siapkan semua bumbu. Ayam saya rebus sekitaran 10 menit dan tiriskan lalu potong sesuai selera. Ketumbar dan kemiri saya sangrai dan tumbuk. Kemudian bumbu halus saya blender."
- "Tumis bumbu hingga wangi dan berubah warna, masukan ayam dan aduk sebentar. Kemudian tuang air hingga menutupi ayam dan beri garam dan penyedap rasa. Aduk hingga rata dan diamkan sekitar 5 menit. Kemudian masukan kemangi, daun kunyit, dan daun bawang. Masak hingga air menyusut."
- "Masukan tomat dan aduk sebentar dan koreksi rasa. Setelah matang dan air menyusut maka ayam rica pedas kemangi siap dihidangkan."
- "Resep ini mudah banget dicobain moms. Enak deh. Dan ayam rica-rica kemangi benar nikmat dan yummy. 🥰🥰🥰🥰"
categories:
- Recipe
tags:
- ayam
- ricarica
- pedas

katakunci: ayam ricarica pedas 
nutrition: 285 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT40M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica-rica Pedas Kemangi](https://img-global.cpcdn.com/recipes/0fbe6bc28195c770/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan enak. Ciri makanan Nusantara ayam rica-rica pedas kemangi yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan rumah tangga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam Rica-rica Pedas Kemangi untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang dapat anda praktekkan salah satunya ayam rica-rica pedas kemangi yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica-rica pedas kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Pedas Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Pedas Kemangi:

1. Dibutuhkan 1/2 ekor ayam yg sudah direbus dan dipotong sesuai selera (tanpa direbus juga boleh)
1. Harap siapkan 3 lembar daun salam
1. Harap siapkan 3 lembar daun jeruk purut
1. Diperlukan 2 batang serai geprek
1. Jangan lupa 5 cm lengkuas, geprek
1. Jangan lupa 1 genggam daunh kemangi
1. Diperlukan 1 lembar daun kunyit
1. Harap siapkan 1 batang daun bawang
1. Harus ada  Bumbu halus :
1. Harus ada 7 siung bawang merah
1. Dibutuhkan 3 siung bawang putih
1. Harap siapkan 6 cm kunyit
1. Diperlukan 6 cm jahe
1. Dibutuhkan 4 butir kemiri sangrai
1. Harus ada 1 sdm ketumbar sangrai
1. Harus ada  Cabe rawit secukupnya (bisa banyak bila mau pedes banget)
1. Harap siapkan 2 buah tomat
1. Tambah 500 ml air masak
1. Diperlukan  Minyak goreng utk menumis bumbu
1. Siapkan sesuai selera Garam dan penyedap rasa ayam




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-rica Pedas Kemangi:

1. Siapkan semua bumbu. Ayam saya rebus sekitaran 10 menit dan tiriskan lalu potong sesuai selera. Ketumbar dan kemiri saya sangrai dan tumbuk. Kemudian bumbu halus saya blender.
1. Tumis bumbu hingga wangi dan berubah warna, masukan ayam dan aduk sebentar. Kemudian tuang air hingga menutupi ayam dan beri garam dan penyedap rasa. Aduk hingga rata dan diamkan sekitar 5 menit. Kemudian masukan kemangi, daun kunyit, dan daun bawang. Masak hingga air menyusut.
1. Masukan tomat dan aduk sebentar dan koreksi rasa. Setelah matang dan air menyusut maka ayam rica pedas kemangi siap dihidangkan.
1. Resep ini mudah banget dicobain moms. Enak deh. Dan ayam rica-rica kemangi benar nikmat dan yummy. 🥰🥰🥰🥰




Demikianlah cara membuat ayam rica-rica pedas kemangi yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan terbukti, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
