---
description: "Resep : AYAM RICA-RICA KEMANGI Luar biasa"
title: "Resep : AYAM RICA-RICA KEMANGI Luar biasa"
slug: 267-resep-ayam-rica-rica-kemangi-luar-biasa
date: 2020-09-28T13:28:35.807Z
image: https://img-global.cpcdn.com/recipes/c9cd201a4274d3c7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c9cd201a4274d3c7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c9cd201a4274d3c7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Dale Butler
ratingvalue: 4.8
reviewcount: 10941
recipeingredient:
- "500 gram ayam beri perasan jeruk nipis  garam diamkan"
- "4 lbr daun jeruk"
- "1 batang serai memarkan"
- "1 jempol Lengkuas memarkan"
- " Kemangi"
- "1 sdt merica bubuk"
- "secukupnya Gula dan garam"
- "Secukupnya kaldu bubuk"
- " Bumbu halus "
- "5 siung bawang merah"
- "5 siung bawang putih"
- "2 cm jahe"
- "3 cm kunyit"
- "2 butir kemiri"
- "10 biji cabe rawit"
- "5 bh cabe merah besar"
- "1/2 sdt ketumbar"
recipeinstructions:
- "Ulek semua bumbu"
- "Beri sedikit minyak pada wajan, lalu masukkan 4 lembar daun jeruk dan serai."
- "Selanjutnya masukkan bahan yang telah diulek, tumis sampai harum dan bumbu matang. Setelah itu beri gula,garam, merica bubuk, dan penyedap rasa."
- "Masukkan ayam, aduk rata, biarkan sampai berubah warna, kemudian tambahkan air sedikit untuk meresapkannya. Tutup. Masak dengan api kecil sampai bumbu benar-benar meresap ke dalam ayamnya dan ayam matang. Terakhir masukkan kemangi, aduk sebentar. Matikan api, angkat"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 293 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Dessert

---


![AYAM RICA-RICA KEMANGI](https://img-global.cpcdn.com/recipes/c9cd201a4274d3c7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang dapat kita jaga karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica-rica kemangi yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Nusantara



Kedekatan rumah tangga dapat ditemukan dengan cara mudah. Salah satunya adalah membuat makanan AYAM RICA-RICA KEMANGI untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang bisa anda contoh salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep AYAM RICA-RICA KEMANGI yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat AYAM RICA-RICA KEMANGI:

1. Dibutuhkan 500 gram ayam, beri perasan jeruk nipis &amp; garam, diamkan
1. Harap siapkan 4 lbr daun jeruk
1. Siapkan 1 batang serai, memarkan
1. Harap siapkan 1 jempol Lengkuas, memarkan
1. Harap siapkan  Kemangi
1. Diperlukan 1 sdt merica bubuk
1. Harus ada secukupnya Gula dan garam
1. Harus ada Secukupnya kaldu bubuk
1. Jangan lupa  Bumbu halus :
1. Diperlukan 5 siung bawang merah
1. Siapkan 5 siung bawang putih
1. Diperlukan 2 cm jahe
1. Diperlukan 3 cm kunyit
1. Harap siapkan 2 butir kemiri
1. Dibutuhkan 10 biji cabe rawit
1. Diperlukan 5 bh cabe merah besar
1. Tambah 1/2 sdt ketumbar




<!--inarticleads2-->

##### Langkah membuat  AYAM RICA-RICA KEMANGI:

1. Ulek semua bumbu
1. Beri sedikit minyak pada wajan, lalu masukkan 4 lembar daun jeruk dan serai.
1. Selanjutnya masukkan bahan yang telah diulek, tumis sampai harum dan bumbu matang. Setelah itu beri gula,garam, merica bubuk, dan penyedap rasa.
1. Masukkan ayam, aduk rata, biarkan sampai berubah warna, - kemudian tambahkan air sedikit untuk meresapkannya. Tutup. Masak dengan api kecil sampai bumbu benar-benar meresap ke - dalam ayamnya dan ayam matang. Terakhir masukkan kemangi, aduk sebentar. Matikan api, angkat




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan teruji, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
