---
description: "Resep : Ayam rica kemangi (vegan) Sempurna"
title: "Resep : Ayam rica kemangi (vegan) Sempurna"
slug: 366-resep-ayam-rica-kemangi-vegan-sempurna
date: 2020-11-08T12:26:57.018Z
image: https://img-global.cpcdn.com/recipes/454f3d3d881621d2/751x532cq70/ayam-rica-kemangi-vegan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/454f3d3d881621d2/751x532cq70/ayam-rica-kemangi-vegan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/454f3d3d881621d2/751x532cq70/ayam-rica-kemangi-vegan-foto-resep-utama.jpg
author: Brian Young
ratingvalue: 4.4
reviewcount: 27483
recipeingredient:
- "10 ptg ayam crispy vegan"
- "1/2 ikat daun kemangi"
- "2 sdm minyak utk tumis"
- "secukupnya air"
- "1 sdt garam"
- "1 sdt kaldu jamur"
- " bumbu halus"
- "12 bh cabai merah keriting"
- "2 bh cabai rawit"
- "1 ruas lengkuas"
- "1 ruas jahe"
- "1 ruas kunyit"
- "3 bh kemiri"
- "1 sdt ketumbar bubuk"
- "secukupnya minyak"
- " geprek"
- "1 bh serai geprek"
- "2 bh daun salam"
- "2 bh daun jeruk"
recipeinstructions:
- "Goreng ayam krispi vegan hingga kecoklatan. sisihkan"
- "Blender semua bumbu yg dihaluskan menggunakan minyak."
- "Panaskan minyak, masukan bumbu halus dan bahan geprek aduk2 hingga mengeluarkan minyak."
- "Masukan air kira2 1 gelas. masukan garam dan kaldu jamur tunggu mendidih."
- "Setelah mendidih masukan ayam krispi aduk terus sampai air menyusut."
- "Masukan daun kemangi dan aduk2 rata sampai air menyusut dan mengeluarkan minyak. tes rasa.. jadi deeehh.. enak di makan bersama nasi hangat 😊😊"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 228 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam rica kemangi (vegan)](https://img-global.cpcdn.com/recipes/454f3d3d881621d2/751x532cq70/ayam-rica-kemangi-vegan-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis dan renyah. Ciri khas masakan Nusantara ayam rica kemangi (vegan) yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga dapat ditemukan dengan cara mudah. Salah satunya adalah memasak Ayam rica kemangi (vegan) untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang bisa anda buat salah satunya ayam rica kemangi (vegan) yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam rica kemangi (vegan) tanpa harus bersusah payah.
Seperti resep Ayam rica kemangi (vegan) yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica kemangi (vegan):

1. Harus ada 10 ptg ayam crispy vegan
1. Jangan lupa 1/2 ikat daun kemangi
1. Dibutuhkan 2 sdm minyak utk tumis
1. Diperlukan secukupnya air
1. Tambah 1 sdt garam
1. Harap siapkan 1 sdt kaldu jamur
1. Tambah  bumbu halus
1. Tambah 12 bh cabai merah keriting
1. Dibutuhkan 2 bh cabai rawit
1. Siapkan 1 ruas lengkuas
1. Harus ada 1 ruas jahe
1. Tambah 1 ruas kunyit
1. Harus ada 3 bh kemiri
1. Tambah 1 sdt ketumbar bubuk
1. Harus ada secukupnya minyak
1. Harus ada  geprek
1. Jangan lupa 1 bh serai geprek
1. Harap siapkan 2 bh daun salam
1. Tambah 2 bh daun jeruk




<!--inarticleads2-->

##### Cara membuat  Ayam rica kemangi (vegan):

1. Goreng ayam krispi vegan hingga kecoklatan. sisihkan
1. Blender semua bumbu yg dihaluskan menggunakan minyak.
1. Panaskan minyak, masukan bumbu halus dan bahan geprek aduk2 hingga mengeluarkan minyak.
1. Masukan air kira2 1 gelas. masukan garam dan kaldu jamur tunggu mendidih.
1. Setelah mendidih masukan ayam krispi aduk terus sampai air menyusut.
1. Masukan daun kemangi dan aduk2 rata sampai air menyusut dan mengeluarkan minyak. tes rasa.. jadi deeehh.. enak di makan bersama nasi hangat 😊😊




Demikianlah cara membuat ayam rica kemangi (vegan) yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan cepat, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
