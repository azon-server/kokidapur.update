---
description: "Bagaimana menyiapakan Ayam Rica Kemangi Pedas Nampol terupdate"
title: "Bagaimana menyiapakan Ayam Rica Kemangi Pedas Nampol terupdate"
slug: 170-bagaimana-menyiapakan-ayam-rica-kemangi-pedas-nampol-terupdate
date: 2021-01-02T03:39:55.967Z
image: https://img-global.cpcdn.com/recipes/570084f62e65ff09/751x532cq70/ayam-rica-kemangi-pedas-nampol-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/570084f62e65ff09/751x532cq70/ayam-rica-kemangi-pedas-nampol-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/570084f62e65ff09/751x532cq70/ayam-rica-kemangi-pedas-nampol-foto-resep-utama.jpg
author: Cynthia Dean
ratingvalue: 4.2
reviewcount: 12909
recipeingredient:
- "4 potong ayam bagian apa ja boleh lebih enak paha dan sayap"
- "1 ikat kemangi"
- " Daun bawang"
- " Bumbu Halus"
- "2 Cabai merah besar"
- "10 cabai rawit"
- "5 bawang merah"
- "3 bawang putih"
- "4 butir kemiri"
- "1 ruas kunyit"
- "1 ruas kencur"
- "1 serai"
- "2 gelas Air"
recipeinstructions:
- "Haluskan semua bumbu halus pakai cobek aja. Trus tumis ke minyak yg panas."
- "Kalau bumbunya dah matang dan mengeluarkan aroma sedap, masukin ayamnya yg telah dicuci bersih."
- "Jangan buru2 dikasih air dulu ya bund. Tunggu bagian luar ayamnya setengah matang. Tandanya daging luar dah berwarna putih. Ini supaya bumbunya meresap dan kaldu ayamnya keluar."
- "Nah kalau penampakannya dah kayak foto diatas, baru kasih air. Tunggu sampai mendidih, tambahin cabai utuh klo suka."
- "Kalau sudah mendidih dan kuahnya dah menyusut, tambahin daun bawang, garam ½ sdt, kaldu jamur 1 sdm, gula ½ sdm..Aduk2 sampai bumbu larut."
- "Koreksi rasanya, dan tambahin kemangi. Aduk2..matikan api kompor. Selesai.."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 295 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica Kemangi Pedas Nampol](https://img-global.cpcdn.com/recipes/570084f62e65ff09/751x532cq70/ayam-rica-kemangi-pedas-nampol-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan empuk. Ciri khas kuliner Indonesia ayam rica kemangi pedas nampol yang penuh dengan rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kehangatan keluarga dapat diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam Rica Kemangi Pedas Nampol untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang bisa anda praktekkan salah satunya ayam rica kemangi pedas nampol yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica kemangi pedas nampol tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi Pedas Nampol yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 13 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi Pedas Nampol:

1. Jangan lupa 4 potong ayam (bagian apa ja boleh, lebih enak paha dan sayap)
1. Harap siapkan 1 ikat kemangi
1. Jangan lupa  Daun bawang
1. Jangan lupa  Bumbu Halus
1. Siapkan 2 Cabai merah besar
1. Harap siapkan 10 cabai rawit
1. Jangan lupa 5 bawang merah
1. Tambah 3 bawang putih
1. Harus ada 4 butir kemiri
1. Dibutuhkan 1 ruas kunyit
1. Jangan lupa 1 ruas kencur
1. Dibutuhkan 1 serai
1. Tambah 2 gelas Air




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Kemangi Pedas Nampol:

1. Haluskan semua bumbu halus pakai cobek aja. Trus tumis ke minyak yg panas.
1. Kalau bumbunya dah matang dan mengeluarkan aroma sedap, masukin ayamnya yg telah dicuci bersih.
1. Jangan buru2 dikasih air dulu ya bund. Tunggu bagian luar ayamnya setengah matang. Tandanya daging luar dah berwarna putih. Ini supaya bumbunya meresap dan kaldu ayamnya keluar.
1. Nah kalau penampakannya dah kayak foto diatas, baru kasih air. Tunggu sampai mendidih, tambahin cabai utuh klo suka.
1. Kalau sudah mendidih dan kuahnya dah menyusut, tambahin daun bawang, garam ½ sdt, kaldu jamur 1 sdm, gula ½ sdm..Aduk2 sampai bumbu larut.
1. Koreksi rasanya, dan tambahin kemangi. Aduk2..matikan api kompor. Selesai..




Demikianlah cara membuat ayam rica kemangi pedas nampol yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan cepat, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
