---
description: "Resep : Ayam Rica Kemangi Teruji"
title: "Resep : Ayam Rica Kemangi Teruji"
slug: 219-resep-ayam-rica-kemangi-teruji
date: 2021-01-19T14:40:41.799Z
image: https://img-global.cpcdn.com/recipes/e1712c41e44b44ec/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e1712c41e44b44ec/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e1712c41e44b44ec/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Leah Henderson
ratingvalue: 4
reviewcount: 9738
recipeingredient:
- "1/2 ekor ayam"
- " Bumbu halus"
- "3 cabe merah besar"
- "15 cabe rawit"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "2 butir kemiri"
- "1/2 ruas jari jahe"
- "1/4 ruas jari kunyit"
- " Bumbu Pelengkap"
- "2 batang sereh memarkan"
- "1 ruas jari lengkuas memarkan"
- "1/4 keping gula merah"
- "secukupnya Garam gula pasir penyedap rasa"
- "secukupnya Air"
- "1/2 ikat kemangi"
recipeinstructions:
- "Bersihkan ayam. Sisihkan"
- "Uleg bumbu halus. Lalu tumis hingga harum. Masukkan bumbu pelengkap kecuali kemangi. Lalu masukkan ayam. Aduk aduk hingga bumbu rata. Masukkan air sedikit."
- "Tutup ayam hingga air menyusut. Test rasa. Kalo sudah pas masukkan kemangi. Aduk aduk kembali. &amp; ayam Rica kemangi siap disantap. Rasanya muantaap ciiin.. 😁😁😁"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 116 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/e1712c41e44b44ec/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang setidaknya kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica kemangi yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan ciri khas yang merupakan keragaman Kita

Keharmonisan rumah tangga dapat diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam Rica Kemangi untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang bisa anda praktekkan salah satunya ayam rica kemangi yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Harap siapkan 1/2 ekor ayam
1. Harap siapkan  Bumbu halus
1. Dibutuhkan 3 cabe merah besar
1. Tambah 15 cabe rawit
1. Jangan lupa 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Tambah 2 butir kemiri
1. Diperlukan 1/2 ruas jari jahe
1. Jangan lupa 1/4 ruas jari kunyit
1. Dibutuhkan  Bumbu Pelengkap
1. Harus ada 2 batang sereh memarkan
1. Jangan lupa 1 ruas jari lengkuas memarkan
1. Tambah 1/4 keping gula merah
1. Siapkan secukupnya Garam, gula pasir, penyedap rasa
1. Harap siapkan secukupnya Air
1. Tambah 1/2 ikat kemangi




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Kemangi:

1. Bersihkan ayam. Sisihkan
1. Uleg bumbu halus. Lalu tumis hingga harum. Masukkan bumbu pelengkap kecuali kemangi. Lalu masukkan ayam. Aduk aduk hingga bumbu rata. Masukkan air sedikit.
1. Tutup ayam hingga air menyusut. Test rasa. Kalo sudah pas masukkan kemangi. Aduk aduk kembali. &amp; ayam Rica kemangi siap disantap. Rasanya muantaap ciiin.. 😁😁😁




Demikianlah cara membuat ayam rica kemangi yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat gampang dan cepat, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
