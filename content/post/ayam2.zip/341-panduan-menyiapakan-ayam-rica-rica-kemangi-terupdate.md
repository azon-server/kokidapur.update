---
description: "Panduan menyiapakan Ayam rica-rica kemangi terupdate"
title: "Panduan menyiapakan Ayam rica-rica kemangi terupdate"
slug: 341-panduan-menyiapakan-ayam-rica-rica-kemangi-terupdate
date: 2020-09-26T23:15:35.967Z
image: https://img-global.cpcdn.com/recipes/9c260d6a5ead4eee/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9c260d6a5ead4eee/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9c260d6a5ead4eee/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Millie Carson
ratingvalue: 4.9
reviewcount: 47691
recipeingredient:
- "1 kg ayam"
- "7 siung bawang merah"
- "3 siung bawang putih"
- "10 buah cabe merah kriting"
- "3 buah cabe setan"
- "1 buah tomat"
- "3 ikat kemangi"
- " Daun salam"
- " Lengkuas"
- " Daun jeruk"
- " Sereh"
- " Kemiri"
- "Secukupnya mericagaram dan gula"
- "secukupnya Air"
- " Minyak goreng"
recipeinstructions:
- "Cuci ayam hingga bersih kemudian rebus"
- "Setelah ayam mateng goreNg sebentar jangan terlalu kering"
- "Haluskan bawang merah, bawang putih, cabe, merica, tomat dan kemiri."
- "Tumis bumbu halus tambahkan lengkuas, daun salam, daun jeruk dan sereh tumis sampe harum."
- "Masukan ayam, aduk hingga ayam tercampur dengan bumbu kemudian tambahkan air secukupnya"
- "Tambahkan gula dan garam secukupnya,. Kemudian koreksi rasa"
- "Masukan daun kemangi, masak sampe layu...setelah mateng matikan api... Ayam siap dinikmatiii"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 261 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/9c260d6a5ead4eee/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau renyah. Ciri khas kuliner Nusantara ayam rica-rica kemangi yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga bisa didapat dengan cara simple. Diantaranya adalah memasak Ayam rica-rica kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang dapat anda coba salah satunya ayam rica-rica kemangi yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica kemangi:

1. Harus ada 1 kg ayam
1. Harus ada 7 siung bawang merah
1. Harus ada 3 siung bawang putih
1. Dibutuhkan 10 buah cabe merah kriting
1. Jangan lupa 3 buah cabe setan
1. Diperlukan 1 buah tomat
1. Siapkan 3 ikat kemangi
1. Dibutuhkan  Daun salam
1. Dibutuhkan  Lengkuas
1. Tambah  Daun jeruk
1. Dibutuhkan  Sereh
1. Harap siapkan  Kemiri
1. Harap siapkan Secukupnya merica,garam dan gula
1. Jangan lupa secukupnya Air
1. Siapkan  Minyak goreng




<!--inarticleads2-->

##### Langkah membuat  Ayam rica-rica kemangi:

1. Cuci ayam hingga bersih kemudian rebus
1. Setelah ayam mateng goreNg sebentar jangan terlalu kering
1. Haluskan bawang merah, bawang putih, cabe, merica, tomat dan kemiri.
1. Tumis bumbu halus tambahkan lengkuas, daun salam, daun jeruk dan sereh tumis sampe harum.
1. Masukan ayam, aduk hingga ayam tercampur dengan bumbu kemudian tambahkan air secukupnya
1. Tambahkan gula dan garam secukupnya,. Kemudian koreksi rasa
1. Masukan daun kemangi, masak sampe layu...setelah mateng matikan api... Ayam siap dinikmatiii




Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
