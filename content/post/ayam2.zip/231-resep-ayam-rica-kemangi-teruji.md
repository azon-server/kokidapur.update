---
description: "Resep : Ayam rica kemangi Teruji"
title: "Resep : Ayam rica kemangi Teruji"
slug: 231-resep-ayam-rica-kemangi-teruji
date: 2020-10-21T04:59:18.262Z
image: https://img-global.cpcdn.com/recipes/cc6612372baee1ae/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cc6612372baee1ae/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cc6612372baee1ae/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Blanche Carlson
ratingvalue: 4.3
reviewcount: 7562
recipeingredient:
- "8 bh potongan ayam"
- "1/2 bt jeruk nipis"
- "1/2 sdt garam"
- " Bumbu uleg"
- "6 bh bawang merah"
- "3 bh bawang putih"
- "2 bh kemiri bakar sebentar"
- "5 bh cabe merah besar"
- "2 bh cabe rawit merah"
- "3 cm kunyit"
- " Bumbu tambahan"
- "2 bh daun salam"
- "2 cm jahe"
- "3 bh daun jeruk"
- "1 bh serai"
- "4 cm lengkuas"
- "1/2 sdt garam"
- "1/2 sdt merica"
- "1/2 sdt gula jawa"
- "1/4 sdt gula pasir"
- "1 bh daun bawang iris tipis"
- "1 genggam daun kemangi"
recipeinstructions:
- "Campur ayam dengan air jeruk nipis, cuci sebentar dan tiriskan. Tambahkan garam dan ratakan. Goreng setengah matang. Sisihkan."
- "Tumis bumbu uleg hingga wangi, tambahkan 1gelas air, masukkan jahe, serai, lengkuas, salam, daun jeruk, garam, merica, gula jawa, gula pasir hingga larut. Tambahkan ayam yang disisihkan. Tunggu agak mengental, koreksi rasa. Tambahkan sedikit air lagi, hingga semua bumbu meresap ke dalam ayam."
- "Masukkan daun bawang dan kemangi. Sebentar saja. Begitu layu, angkat dan siap dihidangkan."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 145 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/cc6612372baee1ae/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang dapat kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica kemangi yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa ciri khas yang merupakan keragaman Indonesia

Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap.

Kehangatan keluarga bisa didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam rica kemangi untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang dapat anda buat salah satunya ayam rica kemangi yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi:

1. Tambah 8 bh potongan ayam
1. Jangan lupa 1/2 bt jeruk nipis
1. Dibutuhkan 1/2 sdt garam
1. Harus ada  Bumbu uleg
1. Diperlukan 6 bh bawang merah
1. Harus ada 3 bh bawang putih
1. Jangan lupa 2 bh kemiri, bakar sebentar
1. Diperlukan 5 bh cabe merah besar
1. Dibutuhkan 2 bh cabe rawit merah
1. Harap siapkan 3 cm kunyit
1. Harap siapkan  Bumbu tambahan
1. Harap siapkan 2 bh daun salam
1. Dibutuhkan 2 cm jahe
1. Jangan lupa 3 bh daun jeruk
1. Harus ada 1 bh serai
1. Tambah 4 cm lengkuas
1. Tambah 1/2 sdt garam
1. Tambah 1/2 sdt merica
1. Dibutuhkan 1/2 sdt gula jawa
1. Tambah 1/4 sdt gula pasir
1. Dibutuhkan 1 bh daun bawang iris tipis
1. Siapkan 1 genggam daun kemangi


Perlu kamu ketahui bahwa di luar negeri mungkin daun basil sangat terkenal untuk campuran makanan. Akan tetapi, di Indonesia juga memiliki daun kemangi merupakan. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica kemangi:

1. Campur ayam dengan air jeruk nipis, cuci sebentar dan tiriskan. Tambahkan garam dan ratakan. Goreng setengah matang. Sisihkan.
1. Tumis bumbu uleg hingga wangi, tambahkan 1gelas air, masukkan jahe, serai, lengkuas, salam, daun jeruk, garam, merica, gula jawa, gula pasir hingga larut. Tambahkan ayam yang disisihkan. Tunggu agak mengental, koreksi rasa. Tambahkan sedikit air lagi, hingga semua bumbu meresap ke dalam ayam.
1. Masukkan daun bawang dan kemangi. Sebentar saja. Begitu layu, angkat dan siap dihidangkan.


Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. Cara Membuat Ayam Rica Rica Kemangi. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat. 

Demikianlah cara membuat ayam rica kemangi yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
