---
description: "Step-by-Step menyiapakan Ayam rica rica kemangi Homemade"
title: "Step-by-Step menyiapakan Ayam rica rica kemangi Homemade"
slug: 294-step-by-step-menyiapakan-ayam-rica-rica-kemangi-homemade
date: 2020-11-20T14:08:54.359Z
image: https://img-global.cpcdn.com/recipes/34ae7b5ad3f1f913/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/34ae7b5ad3f1f913/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/34ae7b5ad3f1f913/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Patrick Adams
ratingvalue: 5
reviewcount: 44671
recipeingredient:
- " Bahan "
- "500 gr ayam potong dan beri perasan air jeruk nipis"
- "1 ikat kemangi ambil daunnya"
- "1 buah tomat irisiris"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "2 batang serai memarkan"
- "2 cm Jahe memarkan"
- "2 ruas lengkuas memarkan"
- "2 sdm minyak goreng untuk menumis"
- "Secukupnya garam"
- "Secukupnya kaldu jamur"
- "Secukupnya air"
- " Bumbu halus "
- "6 siung bawang merah"
- "3 siung bawang putih"
- "2 cm kunyit"
- "5 buah cabai merah keriting"
- "7 buah cabai rawit merah"
- "1/2 sdt ketumbar bubuk"
- "1/2 sdt lada putih bubuk"
recipeinstructions:
- "Panaskan minyak, lalu tumis bahan-bahan bumbu halus hingga wangi. Tambahkan tomat, daun salam, daun jeruk, sereh, dan jahe. Aduk semua hingga warnanya berubah."
- "Masukkan ayam yang sudah dipotong. Aduk hingga bercampur dengan bumbu.  Tambahkan air hingga ayam terendam. Taburi garam dan gula secukupnya."
- "Masak hingga air menyusut dan daging ayam menjadi empuk. Tambahkan daun kemangi dan aduk terus hingga layu, lalu matikan api.  Sajikan selagi hangat."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 262 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/34ae7b5ad3f1f913/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau gurih. Ciri makanan Nusantara ayam rica rica kemangi yang kaya dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica rica kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang bisa anda coba salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 21 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Harus ada  Bahan :
1. Siapkan 500 gr ayam, potong dan beri perasan air jeruk nipis
1. Diperlukan 1 ikat kemangi, ambil daunnya
1. Diperlukan 1 buah tomat, iris-iris
1. Jangan lupa 2 lembar daun salam
1. Siapkan 2 lembar daun jeruk
1. Tambah 2 batang serai, memarkan
1. Harus ada 2 cm Jahe, memarkan
1. Tambah 2 ruas lengkuas, memarkan
1. Tambah 2 sdm minyak goreng untuk menumis
1. Diperlukan Secukupnya garam
1. Tambah Secukupnya kaldu jamur
1. Diperlukan Secukupnya air
1. Jangan lupa  Bumbu halus :
1. Dibutuhkan 6 siung bawang merah
1. Harap siapkan 3 siung bawang putih
1. Siapkan 2 cm kunyit
1. Dibutuhkan 5 buah cabai merah keriting
1. Siapkan 7 buah cabai rawit merah
1. Jangan lupa 1/2 sdt ketumbar bubuk
1. Tambah 1/2 sdt lada putih bubuk


Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica kemangi:

1. Panaskan minyak, lalu tumis bahan-bahan bumbu halus hingga wangi. Tambahkan tomat, daun salam, daun jeruk, sereh, dan jahe. Aduk semua hingga warnanya berubah.
1. Masukkan ayam yang sudah dipotong. Aduk hingga bercampur dengan bumbu.  - Tambahkan air hingga ayam terendam. Taburi garam dan gula secukupnya.
1. Masak hingga air menyusut dan daging ayam menjadi empuk. Tambahkan daun kemangi dan aduk terus hingga layu, lalu matikan api.  - Sajikan selagi hangat.


Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Siapa yang tidak mengenal lalapan daun kemangi di Indonesia ini. Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. 

Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
