---
description: "Bagaimana untuk menyiapakan 12.Opor ayam kentang Teruji"
title: "Bagaimana untuk menyiapakan 12.Opor ayam kentang Teruji"
slug: 473-bagaimana-untuk-menyiapakan-12opor-ayam-kentang-teruji
date: 2020-12-12T20:29:47.491Z
image: https://img-global.cpcdn.com/recipes/099fcfc4b46bf0b2/751x532cq70/12opor-ayam-kentang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/099fcfc4b46bf0b2/751x532cq70/12opor-ayam-kentang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/099fcfc4b46bf0b2/751x532cq70/12opor-ayam-kentang-foto-resep-utama.jpg
author: Isaiah Rhodes
ratingvalue: 4.5
reviewcount: 15531
recipeingredient:
- "1/2 ekor ayam potongpotong lalu cuci bersih"
- "3 buah kentang potongpotong sesuai selera"
- "500 ml air"
- "500 ml santan resep asli 1 liter santan"
- "2 lembar daun salam"
- "1 batang sereh geprek"
- "1 ruas lengkuas geprek"
- "Secukupnya garam"
- "Secukupnya kaldu bubuk"
- "Secukupnya gula pasir"
- " Bawang goreng untuk taburan"
- " Bumbu halus "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "1 ruas kunyit"
- "1 ruas jahe"
- "3 butir kemiri"
- "1/2 sdt ketumbar"
- "1/2 sdt merica"
recipeinstructions:
- "Siapkan semua bahan"
- "Haluskan bumbu halus dan tumis, masukkan daun salam,sereh dan lengkuas,masak sampai harum.masukkan ayam masak,masak ayam sampai berubah warna"
- "Tambahkan air.masak sampai mendidih,masukkan kentang, tambahkan garam, gula pasir dan kaldu bubuk.aduk rata.masak sampai ayam empuk.masukkan santan,aduk-aduk sampai mendidih dan matang."
- "Sajikan dengan taburan bawang goreng."
categories:
- Recipe
tags:
- 12opor
- ayam
- kentang

katakunci: 12opor ayam kentang 
nutrition: 185 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Dessert

---


![12.Opor ayam kentang](https://img-global.cpcdn.com/recipes/099fcfc4b46bf0b2/751x532cq70/12opor-ayam-kentang-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga renyah. Ciri khas kuliner Indonesia 12.opor ayam kentang yang kaya dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak 12.Opor ayam kentang untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang bisa anda buat salah satunya 12.opor ayam kentang yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep 12.opor ayam kentang tanpa harus bersusah payah.
Berikut ini resep 12.Opor ayam kentang yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 12.Opor ayam kentang:

1. Diperlukan 1/2 ekor ayam, potong-potong lalu cuci bersih
1. Tambah 3 buah kentang, potong-potong sesuai selera
1. Jangan lupa 500 ml air
1. Harus ada 500 ml santan (resep asli 1 liter santan)
1. Dibutuhkan 2 lembar daun salam
1. Jangan lupa 1 batang sereh, geprek
1. Diperlukan 1 ruas lengkuas, geprek
1. Diperlukan Secukupnya garam
1. Jangan lupa Secukupnya kaldu bubuk
1. Jangan lupa Secukupnya gula pasir
1. Harus ada  Bawang goreng untuk taburan
1. Jangan lupa  Bumbu halus :
1. Tambah 5 siung bawang merah
1. Jangan lupa 3 siung bawang putih
1. Tambah 1 ruas kunyit
1. Dibutuhkan 1 ruas jahe
1. Harap siapkan 3 butir kemiri
1. Jangan lupa 1/2 sdt ketumbar
1. Jangan lupa 1/2 sdt merica




<!--inarticleads2-->

##### Instruksi membuat  12.Opor ayam kentang:

1. Siapkan semua bahan
1. Haluskan bumbu halus dan tumis, masukkan daun salam,sereh dan lengkuas,masak sampai harum.masukkan ayam masak,masak ayam sampai berubah warna
1. Tambahkan air.masak sampai mendidih,masukkan kentang, tambahkan garam, gula pasir dan kaldu bubuk.aduk rata.masak sampai ayam empuk.masukkan santan,aduk-aduk sampai mendidih dan matang.
1. Sajikan dengan taburan bawang goreng.




Demikianlah cara membuat 12.opor ayam kentang yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan teruji, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
