---
description: "Resep : Ayam Geprek Ala Bensu Pedas Favorite"
title: "Resep : Ayam Geprek Ala Bensu Pedas Favorite"
slug: 74-resep-ayam-geprek-ala-bensu-pedas-favorite
date: 2020-11-25T21:20:09.031Z
image: https://img-global.cpcdn.com/recipes/1ecada4f2be159c0/751x532cq70/ayam-geprek-ala-bensu-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1ecada4f2be159c0/751x532cq70/ayam-geprek-ala-bensu-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1ecada4f2be159c0/751x532cq70/ayam-geprek-ala-bensu-pedas-foto-resep-utama.jpg
author: Rebecca Logan
ratingvalue: 4.6
reviewcount: 9787
recipeingredient:
- " Ayam bagian paha aja 4 potong bebas ya mau bagian apanya"
- " Untuk bumbu marinasi ayam"
- "3 siung bawang putih dihaluskan Sy diparut aja tadi"
- "1 sdm lada bubuk"
- "1 sdm garam"
- " Bahan Tepung"
- "5 sdm tepung terigu"
- "3 sdm meizena"
- "1 butir telur kocok"
- " Bahan Sambal"
- "3 siung bawang putih ukuran sedang"
- " Cabe jablay dan rawit ijo sesuai selera tadi saya banyak"
- " Garam"
recipeinstructions:
- "Cuci bersih ayam, tiriskan. Kemudia beri lada bubuk, garam dan bawang putih. Diaduk2 sambil agak diremas2 biar nyerep bumbunya. Diemin 2 jam. Semakin lama semakin baik ya"
- "Setelah dimarinasi, cuci bersih ayam. Tiriskan. Masukkan kocokan telur. Aduk dan remas2 pelan ayam agar seluruh bagian benar2 tercampur telur."
- "Siapkan diwadah lain untuk bahan tepung. Guling2kan ayam yg sudah dibaluri telur kedalam baham tepung hingga rata semua bagian diselimuti tepung."
- "Panaskan minyak yg banyak (deep fright biar kriuk dan matang sempurna). Masukkan ayam dan goreng hingga kuning keemasan. Angkat dan tiriskan."
- "Siapkan ulekan. Bahan sambel digoreng dulu ya hingga agak layu biar ga capek nguleknya hehehe. Setelah itu diulek deh dan ditata. Jangan lupa icip2 rasanya ya. Colek saya klo mau recook yaaa"
categories:
- Recipe
tags:
- ayam
- geprek
- ala

katakunci: ayam geprek ala 
nutrition: 103 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Geprek Ala Bensu Pedas](https://img-global.cpcdn.com/recipes/1ecada4f2be159c0/751x532cq70/ayam-geprek-ala-bensu-pedas-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam geprek ala bensu pedas yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Nusantara



Keharmonisan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Geprek Ala Bensu Pedas untuk keluarga. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang dapat anda praktekkan salah satunya ayam geprek ala bensu pedas yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep ayam geprek ala bensu pedas tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Ala Bensu Pedas yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 13 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Ala Bensu Pedas:

1. Diperlukan  Ayam bagian paha aja 4 potong (bebas ya mau bagian apanya)
1. Harus ada  Untuk bumbu marinasi ayam
1. Jangan lupa 3 siung bawang putih (dihaluskan. Sy diparut aja tadi)
1. Jangan lupa 1 sdm lada bubuk
1. Tambah 1 sdm garam
1. Jangan lupa  Bahan Tepung
1. Harus ada 5 sdm tepung terigu
1. Dibutuhkan 3 sdm meizena
1. Diperlukan 1 butir telur (kocok)
1. Harap siapkan  Bahan Sambal
1. Harap siapkan 3 siung bawang putih (ukuran sedang)
1. Siapkan  Cabe jablay dan rawit ijo (sesuai selera, tadi saya banyak)
1. Dibutuhkan  Garam




<!--inarticleads2-->

##### Cara membuat  Ayam Geprek Ala Bensu Pedas:

1. Cuci bersih ayam, tiriskan. Kemudia beri lada bubuk, garam dan bawang putih. Diaduk2 sambil agak diremas2 biar nyerep bumbunya. Diemin 2 jam. Semakin lama semakin baik ya
1. Setelah dimarinasi, cuci bersih ayam. Tiriskan. Masukkan kocokan telur. Aduk dan remas2 pelan ayam agar seluruh bagian benar2 tercampur telur.
1. Siapkan diwadah lain untuk bahan tepung. Guling2kan ayam yg sudah dibaluri telur kedalam baham tepung hingga rata semua bagian diselimuti tepung.
1. Panaskan minyak yg banyak (deep fright biar kriuk dan matang sempurna). Masukkan ayam dan goreng hingga kuning keemasan. Angkat dan tiriskan.
1. Siapkan ulekan. Bahan sambel digoreng dulu ya hingga agak layu biar ga capek nguleknya hehehe. Setelah itu diulek deh dan ditata. Jangan lupa icip2 rasanya ya. Colek saya klo mau recook yaaa




Demikianlah cara membuat ayam geprek ala bensu pedas yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan teruji, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
