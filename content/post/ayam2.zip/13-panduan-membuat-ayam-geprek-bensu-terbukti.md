---
description: "Panduan membuat Ayam Geprek Bensu Terbukti"
title: "Panduan membuat Ayam Geprek Bensu Terbukti"
slug: 13-panduan-membuat-ayam-geprek-bensu-terbukti
date: 2020-11-21T00:26:48.507Z
image: https://img-global.cpcdn.com/recipes/7a408a5900495668/751x532cq70/ayam-geprek-bensu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7a408a5900495668/751x532cq70/ayam-geprek-bensu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7a408a5900495668/751x532cq70/ayam-geprek-bensu-foto-resep-utama.jpg
author: Gertrude West
ratingvalue: 4.7
reviewcount: 46822
recipeingredient:
- "Secukupnya minyak goreng"
- "1 sdt margarin optional"
- "  Marinate Ayam "
- "1 kg ayam sy bagpaha atas"
- "1 bh jeruk nipis ukuran kecil"
- "1/2 sdt garam"
- "  Adonan Kering "
- "500 gr tepung terigu segitiga biru"
- "2 sdm maizena"
- "1 sdm tepung beras"
- "1/2 sdt baking powder"
- "1 sdt garam"
- "1 sdt kaldu bubuk"
- "1 sdt bawang putih bubuk optional"
- "  Adonan Basah "
- "1 butir putih telor kocok lepas sy 1 btr telur"
- "5 sdm tepung segitiga biru"
- "2 siung bawang putih haluskan"
- "1/2 sdt kaldu bubuk"
- "1/2 sdt meriba bubuk"
- "  Bahan Sambel "
- "100 gr cabe rawit 50 gr"
- "3 btr bawang merah iris2"
- "5 siung bawang putih geprek lalu iris2"
- "1 sdt kaldu bubuk"
- "1/2 sdt garam"
- "1 sdt gula"
- "Sedikit air"
recipeinstructions:
- "Cuci bersih ayam dan sayat bagian dagingnya lalu marinate ayam dg jeruk nipis+garam, remas2, diamkan 15 menit. Cuci bersih kembali ayam. ♦Tujuannya agar tepung dapat merata dan hasilnya akan merekah."
- "Campurkan semua adonan basah dalam wadah, lalu masukkan potongan ayam."
- "Masukkan potongan ayam yang sudah dicelupkan dalam adonan basah ke adonan kering."
- "Celupkan lagi ayam keadonan basah dan kering. ♦Lakukan 2x proses untuk hasil tepung yang sedikit tebal."
- "Hasil akhir setelah 2x proses adonan basah dan kering seperti ini."
- "Siapkan panci/wajan, panaskan minyak goreng yang banyak (sampai ayam terendam) dg api kecil, beri sedikit margarin, aduk rata. Masukkan ayam dalam suhu minyak cukup hangat. ATAU goreng dg deep fried.. ♦Goreng dg API KECIL yaa.. ♦Supaya daging ayam matang hingga kedalam dan tdk cepat gosong luarnya."
- "Balikkan ayam jk dirasa bag.bawah sdh kering/berwarna kecoklatan, goreng sisi sebaliknya hingga matang berwarna coklat keemasan, lalu besarkan api sedang sesaat mau diangkat, biarkan 1-2 menit, lalu angkat dan tiriskan."
- "Selanjutnya kita buat sambalnya. Sambil tumis bawang merah, bawang putih dengan sedikit minyak hingga layu dan harum, Uleg kasar cabe rawit."
- "Campurkan tumisan bawang tadi ke ulekan cabe, uleg ringan dan tambahkan kaldu bubuk. Lalu tumis, beri air pada sisa cabe dicobek lalu tuang ke tumisan."
- "Tumis hingga sedikit menyusut, tambahkan gula dan garam. Beri sedikit air lagi dan tumis lagi, tekstur sambel tidak kering ya.. Sedikit agak basah tapi tetap berminyak. Tumis hingga mengeluarkan minyak."
- "Geprek ayam yang sudah digoreng tadi dengan cobek dan beri sambel diatasnya..😋😋"
- "Sajikan dengan nasi hangat+lalapan+sambal 😍😛"
categories:
- Recipe
tags:
- ayam
- geprek
- bensu

katakunci: ayam geprek bensu 
nutrition: 154 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Geprek Bensu](https://img-global.cpcdn.com/recipes/7a408a5900495668/751x532cq70/ayam-geprek-bensu-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam geprek bensu yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa kesan tersendiri yang merupakan keragaman Kita

Kedekatan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam Geprek Bensu untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang bisa anda praktekkan salah satunya ayam geprek bensu yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep ayam geprek bensu tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Bensu yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 12 langkah dan 28 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Bensu:

1. Siapkan Secukupnya minyak goreng
1. Dibutuhkan 1 sdt margarin, (optional)
1. Harus ada  ♦ Marinate Ayam :
1. Jangan lupa 1 kg ayam (sy bag.paha atas)
1. Tambah 1 bh jeruk nipis ukuran kecil
1. Tambah 1/2 sdt garam
1. Diperlukan  ♦ Adonan Kering :
1. Harap siapkan 500 gr tepung terigu (segitiga biru)
1. Jangan lupa 2 sdm maizena
1. Dibutuhkan 1 sdm tepung beras
1. Harus ada 1/2 sdt baking powder
1. Jangan lupa 1 sdt garam
1. Diperlukan 1 sdt kaldu bubuk
1. Harap siapkan 1 sdt bawang putih bubuk (optional)
1. Dibutuhkan  ♦ Adonan Basah :
1. Harus ada 1 butir putih telor, kocok lepas (sy 1 btr telur)
1. Diperlukan 5 sdm tepung segitiga biru
1. Diperlukan 2 siung bawang putih, haluskan
1. Jangan lupa 1/2 sdt kaldu bubuk
1. Diperlukan 1/2 sdt meriba bubuk
1. Siapkan  ♦ Bahan Sambel :
1. Jangan lupa 100 gr cabe rawit (50 gr)
1. Dibutuhkan 3 btr bawang merah, iris2
1. Dibutuhkan 5 siung bawang putih, geprek lalu iris2
1. Harus ada 1 sdt kaldu bubuk
1. Jangan lupa 1/2 sdt garam
1. Tambah 1 sdt gula
1. Jangan lupa Sedikit air




<!--inarticleads2-->

##### Cara membuat  Ayam Geprek Bensu:

1. Cuci bersih ayam dan sayat bagian dagingnya lalu marinate ayam dg jeruk nipis+garam, remas2, diamkan 15 menit. Cuci bersih kembali ayam. ♦Tujuannya agar tepung dapat merata dan hasilnya akan merekah.
1. Campurkan semua adonan basah dalam wadah, lalu masukkan potongan ayam.
1. Masukkan potongan ayam yang sudah dicelupkan dalam adonan basah ke adonan kering.
1. Celupkan lagi ayam keadonan basah dan kering. ♦Lakukan 2x proses untuk hasil tepung yang sedikit tebal.
1. Hasil akhir setelah 2x proses adonan basah dan kering seperti ini.
1. Siapkan panci/wajan, panaskan minyak goreng yang banyak (sampai ayam terendam) dg api kecil, beri sedikit margarin, aduk rata. Masukkan ayam dalam suhu minyak cukup hangat. ATAU goreng dg deep fried.. ♦Goreng dg API KECIL yaa.. ♦Supaya daging ayam matang hingga kedalam dan tdk cepat gosong luarnya.
1. Balikkan ayam jk dirasa bag.bawah sdh kering/berwarna kecoklatan, goreng sisi sebaliknya hingga matang berwarna coklat keemasan, lalu besarkan api sedang sesaat mau diangkat, biarkan 1-2 menit, lalu angkat dan tiriskan.
1. Selanjutnya kita buat sambalnya. Sambil tumis bawang merah, bawang putih dengan sedikit minyak hingga layu dan harum, Uleg kasar cabe rawit.
1. Campurkan tumisan bawang tadi ke ulekan cabe, uleg ringan dan tambahkan kaldu bubuk. Lalu tumis, beri air pada sisa cabe dicobek lalu tuang ke tumisan.
1. Tumis hingga sedikit menyusut, tambahkan gula dan garam. Beri sedikit air lagi dan tumis lagi, tekstur sambel tidak kering ya.. Sedikit agak basah tapi tetap berminyak. Tumis hingga mengeluarkan minyak.
1. Geprek ayam yang sudah digoreng tadi dengan cobek dan beri sambel diatasnya..😋😋
1. Sajikan dengan nasi hangat+lalapan+sambal 😍😛




Demikianlah cara membuat ayam geprek bensu yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
