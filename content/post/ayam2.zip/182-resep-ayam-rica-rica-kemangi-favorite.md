---
description: "Resep : Ayam Rica-rica Kemangi Favorite"
title: "Resep : Ayam Rica-rica Kemangi Favorite"
slug: 182-resep-ayam-rica-rica-kemangi-favorite
date: 2020-08-29T16:37:52.295Z
image: https://img-global.cpcdn.com/recipes/cf4278549468cf2e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cf4278549468cf2e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cf4278549468cf2e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Katherine Nichols
ratingvalue: 4.3
reviewcount: 7089
recipeingredient:
- "500 gram Ayam"
- "2 Batang Sereh"
- " Daun Jeruk"
- " Lengkuas"
- " Kemangi"
- " Bumbu Halus"
- "5 siung Bawang Merah"
- "3 siung Bawang Putih"
- " Cabe rawit optional"
- " Cabe merah keriting optional"
- "1 ruas jahe"
recipeinstructions:
- "Rebus ayam hingga empuk. Setelah empuk angkat ayam, lalu goreng setengah matang."
- "Haluskan Bawang, cabe dan jahe. Tumis semua bumbu halus lalu masukan Sereh, lengkuas dan daun jeruk. Masak hingga wangi, setelah itu masukan air secukupnya. Setelah air sisa sedikit masukkan kemangi aduk2 sebentar dan matikan kompor."
- "Makanan siap dihilangkan :)"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 174 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/cf4278549468cf2e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan renyah. Ciri masakan Indonesia ayam rica-rica kemangi yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kehangatan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Rica-rica Kemangi untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang dapat anda contoh salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica Kemangi:

1. Harap siapkan 500 gram Ayam
1. Diperlukan 2 Batang Sereh
1. Siapkan  Daun Jeruk
1. Siapkan  Lengkuas
1. Tambah  Kemangi
1. Diperlukan  Bumbu Halus
1. Diperlukan 5 siung Bawang Merah
1. Diperlukan 3 siung Bawang Putih
1. Dibutuhkan  Cabe rawit (optional)
1. Dibutuhkan  Cabe merah keriting (optional)
1. Harus ada 1 ruas jahe




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-rica Kemangi:

1. Rebus ayam hingga empuk. Setelah empuk angkat ayam, lalu goreng setengah matang.
1. Haluskan Bawang, cabe dan jahe. Tumis semua bumbu halus lalu masukan Sereh, lengkuas dan daun jeruk. Masak hingga wangi, setelah itu masukan air secukupnya. Setelah air sisa sedikit masukkan kemangi aduk2 sebentar dan matikan kompor.
1. Makanan siap dihilangkan :)




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat gampang dan terbukti, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
