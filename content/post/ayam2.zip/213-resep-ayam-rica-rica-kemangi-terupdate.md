---
description: "Resep : Ayam rica-rica kemangi terupdate"
title: "Resep : Ayam rica-rica kemangi terupdate"
slug: 213-resep-ayam-rica-rica-kemangi-terupdate
date: 2020-11-18T12:03:24.973Z
image: https://img-global.cpcdn.com/recipes/090d3daa66c1fffc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/090d3daa66c1fffc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/090d3daa66c1fffc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Loretta Todd
ratingvalue: 4.6
reviewcount: 23290
recipeingredient:
- "1 kg ayam"
- "secukupnya Jeruk nipis"
- "3 ikat Kemangi"
- "7 lembar Daun jeruk"
- "1 batang Sereh"
- " Lengkuas 1 ruas geprek"
- "secukupnya Garam gula  penyedap"
- " Air untuk mengungkep ayam"
- " Bumbu halus "
- "3 Cabe merah besar"
- "5 Cabe keriting"
- " Cabe rawit merah 5 optional kalau suka pedas"
- "8 Bawang merah"
- "4 Bawang putih"
- "secukupnya Jahe  kunyit"
- "3 butir Kemiri"
- " Minyak goreng untuk menumis bumbu"
recipeinstructions:
- "Potong ayam sesuai selera, cuci dan bersihkan lalu lumuri dengan jeruk nipis diamkan -+ 10menit lalu bilas sampai bersih"
- "Haluskan semua bumbu lalu masukkan juga bumbu tambahan daun jeruk, sereh, lengkuas dan tumis hingga harum"
- "Setelah itu masukan ayam kedalam bumbu tumis tadi, lalu aduk2 dan beri air sampai ayam terendam, ungkep sampai matang dan tambahkan garam, gula, penyedap, tes rasa"
- "Kalau air sudah agak menyusut dan ayam sudah matang, campurkan daun kemangi lalu aduk sampai rata"
- "Ayam siap d sajikan.. Selamat mencoba 😊"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 252 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/090d3daa66c1fffc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica-rica kemangi yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa ciri khas yang merupakan keragaman Nusantara

Kehangatan keluarga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam rica-rica kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang bisa anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica kemangi:

1. Diperlukan 1 kg ayam
1. Harap siapkan secukupnya Jeruk nipis
1. Tambah 3 ikat Kemangi
1. Harus ada 7 lembar Daun jeruk
1. Dibutuhkan 1 batang Sereh
1. Harus ada  Lengkuas 1 ruas (geprek)
1. Siapkan secukupnya Garam, gula &amp; penyedap
1. Harus ada  Air untuk mengungkep ayam
1. Dibutuhkan  Bumbu halus :
1. Jangan lupa 3 Cabe merah besar
1. Diperlukan 5 Cabe keriting
1. Jangan lupa  Cabe rawit merah 5 (optional kalau suka pedas)
1. Tambah 8 Bawang merah
1. Diperlukan 4 Bawang putih
1. Diperlukan secukupnya Jahe &amp; kunyit
1. Harap siapkan 3 butir Kemiri
1. Diperlukan  Minyak goreng untuk menumis bumbu


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Instruksi membuat  Ayam rica-rica kemangi:

1. Potong ayam sesuai selera, cuci dan bersihkan lalu lumuri dengan jeruk nipis diamkan -+ 10menit lalu bilas sampai bersih
1. Haluskan semua bumbu lalu masukkan juga bumbu tambahan daun jeruk, sereh, lengkuas dan tumis hingga harum
1. Setelah itu masukan ayam kedalam bumbu tumis tadi, lalu aduk2 dan beri air sampai ayam terendam, ungkep sampai matang dan tambahkan garam, gula, penyedap, tes rasa
1. Kalau air sudah agak menyusut dan ayam sudah matang, campurkan daun kemangi lalu aduk sampai rata
1. Ayam siap d sajikan.. Selamat mencoba 😊


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
