---
description: "Cara membuat Ayam Rica-Rica Kemangi teraktual"
title: "Cara membuat Ayam Rica-Rica Kemangi teraktual"
slug: 375-cara-membuat-ayam-rica-rica-kemangi-teraktual
date: 2020-12-21T16:36:21.376Z
image: https://img-global.cpcdn.com/recipes/5f32eca6d2ce67b8/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5f32eca6d2ce67b8/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5f32eca6d2ce67b8/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Isaac Love
ratingvalue: 4.5
reviewcount: 44786
recipeingredient:
- "8 potong ayam beri perasan jeruk nipis diamkan 15 menit"
- "1 ikat kemangi"
- "5 lembar daun jeruk"
- "3 lembar daun salam"
- "1 batang serai potong 4"
- "secukupnya Gula dan garam"
- " Bumbu halus"
- "7 siung bawang merah"
- "7 siung bawang putih"
- "2 cm kunyit"
- "2 cm jahe"
- "2 kemiri"
- "12 cabai rawit merah"
- "5 cabai merah"
- "Sejumput ketumbar"
- "Sejumput lada"
recipeinstructions:
- "Blender bumbu halus.. kemudian tumis dengan 5 sdm minyak goreng.. aduk sampai wangi dan matang api kecil"
- "Masukkan serai beserta daun jeruk dan daun salam.. aduk rata lagi sampai wangi.."
- "Masukkan ayam yg sudah dilumuri jeruk tadi tambahkan juga air panas 1 gelas belimbing.. aduk beberapa kali agar semua bagian ayam matang.. api sedang sajaa"
- "Jika air sudah menyerap, dan ayam sudah matang.. masukkan daun kemangi.. aduk sampai agak layu kemudian matikan api.."
- "Ayam rica kemangi siap disantap dgn nasi hangat.. ini agak pucat karena pakainya cabai rawit karena saya suka pedas. Jika ingin lebih merah bs diganti lebih banyak cabai merah.. selamat mencobaaa"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 283 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT49M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/5f32eca6d2ce67b8/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang dapat kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Kita



Kehangatan rumah tangga bisa didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica-Rica Kemangi untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang bisa anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica Kemangi:

1. Harap siapkan 8 potong ayam beri perasan jeruk nipis, diamkan 15 menit
1. Harus ada 1 ikat kemangi
1. Siapkan 5 lembar daun jeruk
1. Tambah 3 lembar daun salam
1. Tambah 1 batang serai potong 4
1. Harap siapkan secukupnya Gula dan garam
1. Harus ada  Bumbu halus
1. Harus ada 7 siung bawang merah
1. Dibutuhkan 7 siung bawang putih
1. Siapkan 2 cm kunyit
1. Harap siapkan 2 cm jahe
1. Siapkan 2 kemiri
1. Harap siapkan 12 cabai rawit merah
1. Harus ada 5 cabai merah
1. Diperlukan Sejumput ketumbar
1. Tambah Sejumput lada




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-Rica Kemangi:

1. Blender bumbu halus.. kemudian tumis dengan 5 sdm minyak goreng.. aduk sampai wangi dan matang api kecil
1. Masukkan serai beserta daun jeruk dan daun salam.. aduk rata lagi sampai wangi..
1. Masukkan ayam yg sudah dilumuri jeruk tadi tambahkan juga air panas 1 gelas belimbing.. aduk beberapa kali agar semua bagian ayam matang.. api sedang sajaa
1. Jika air sudah menyerap, dan ayam sudah matang.. masukkan daun kemangi.. aduk sampai agak layu kemudian matikan api..
1. Ayam rica kemangi siap disantap dgn nasi hangat.. ini agak pucat karena pakainya cabai rawit karena saya suka pedas. Jika ingin lebih merah bs diganti lebih banyak cabai merah.. selamat mencobaaa




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
