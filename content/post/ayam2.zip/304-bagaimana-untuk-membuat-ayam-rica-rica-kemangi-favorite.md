---
description: "Bagaimana untuk membuat Ayam rica rica kemangi Favorite"
title: "Bagaimana untuk membuat Ayam rica rica kemangi Favorite"
slug: 304-bagaimana-untuk-membuat-ayam-rica-rica-kemangi-favorite
date: 2021-01-01T22:31:42.800Z
image: https://img-global.cpcdn.com/recipes/88a97de31403ef40/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/88a97de31403ef40/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/88a97de31403ef40/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Jean West
ratingvalue: 4.8
reviewcount: 42319
recipeingredient:
- "1/2 kg ayam potong"
- "1 ikat daun kemangi"
- "7 buah cabe keriting"
- "5 buah cabe setan"
- "3 siung bawang putih"
- "4 siung bawang merah"
- "2 batang sereh"
- "2 lembar daun salam"
- " Kemiri"
- " Bumbu penyedap saya pakai masako"
- "2 sdt gula"
- " Masing masing 1 ruas jari kunyit jahe dan lengkuas"
recipeinstructions:
- "Bersihkan ayam lalu rebus 10 menit dengan menggunakn jahe agar hilang bau amis angkat lalu tiriskan. Setelah itu goreng ayam sebentar saja jgn terlalu matang."
- "Blender bahan2 bumbu seperti cabe bawang merah bawang putih jahe lengkuas kemiri dan kunyit sampai halus. kecuali sereh dan daun salam"
- "Setelah itu tumis bumbu yg sudah di blender tadi sampai harum lalu tambahkan air sedikir dan masukan ayam yg sudah di goreng tadi aduk aduk sampai rata. Setelah itu masukan daun kemangi dan aduk sebentar lalu sajikan 😊"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 217 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/88a97de31403ef40/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga enak. Ciri makanan Indonesia ayam rica rica kemangi yang penuh dengan rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.




Keharmonisan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah memasak Ayam rica rica kemangi untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda buat salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 12 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi:

1. Harus ada 1/2 kg ayam potong
1. Harus ada 1 ikat daun kemangi
1. Tambah 7 buah cabe keriting
1. Harus ada 5 buah cabe setan
1. Tambah 3 siung bawang putih
1. Harap siapkan 4 siung bawang merah
1. Harap siapkan 2 batang sereh
1. Harap siapkan 2 lembar daun salam
1. Dibutuhkan  Kemiri
1. Harap siapkan  Bumbu penyedap (saya pakai masako)
1. Tambah 2 sdt gula
1. Siapkan  Masing masing 1 ruas jari kunyit jahe dan lengkuas




<!--inarticleads2-->

##### Cara membuat  Ayam rica rica kemangi:

1. Bersihkan ayam lalu rebus 10 menit dengan menggunakn jahe agar hilang bau amis angkat lalu tiriskan. Setelah itu goreng ayam sebentar saja jgn terlalu matang.
1. Blender bahan2 bumbu seperti cabe bawang merah bawang putih jahe lengkuas kemiri dan kunyit sampai halus. kecuali sereh dan daun salam
1. Setelah itu tumis bumbu yg sudah di blender tadi sampai harum lalu tambahkan air sedikir dan masukan ayam yg sudah di goreng tadi aduk aduk sampai rata. Setelah itu masukan daun kemangi dan aduk sebentar lalu sajikan 😊




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan terbukti, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
