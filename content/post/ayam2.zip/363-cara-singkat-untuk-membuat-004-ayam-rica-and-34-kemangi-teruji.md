---
description: "Cara singkat untuk membuat 004. AYAM RICA&amp;#34; KEMANGI Teruji"
title: "Cara singkat untuk membuat 004. AYAM RICA&amp;#34; KEMANGI Teruji"
slug: 363-cara-singkat-untuk-membuat-004-ayam-rica-and-34-kemangi-teruji
date: 2020-11-10T23:36:34.794Z
image: https://img-global.cpcdn.com/recipes/9a8ccbae8b9d3f21/751x532cq70/004-ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9a8ccbae8b9d3f21/751x532cq70/004-ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9a8ccbae8b9d3f21/751x532cq70/004-ayam-rica-kemangi-foto-resep-utama.jpg
author: Clarence Gibbs
ratingvalue: 4.5
reviewcount: 10842
recipeingredient:
- "1/2 kg ayam potong"
- "1 buab jeruk nipis"
- " Bumbu yang di halus kan"
- "1/2 ikat kemangi"
- "2 buah bawang putih"
- "3 buah bawang merah"
- "1 buah kemiri"
- "7 buah cabe merah"
- "5 buah cabe rawitselera pedas"
- "1/2 ruas kunyit"
- "1/2 ruas jahe"
- " Bumbu tambahan"
- "1/2 ruas lengkuas di geprek"
- "2 btg sereh digeprek"
- "3 lbr daun jeruk"
- " sck garam"
- " Sck lada"
- " sck gula"
- " Sck royco"
- " sck air"
recipeinstructions:
- "Cuci bersih ayam lalu lumuri dengan jeruk nipis, setelah itu rebus ayam selama 15-20 menit lqlu tiris kan"
- "Lalu goreng ayam tadi jgn terlalu kering tiriskan"
- "Tumis bumbu yang sudah di haluskan tadi bersama lengkuas,sereh,daun jeruk sampai harum dan kecoklatan"
- "Masuk kan ayam ke dalam bumbu yang suda matang aduk&#34;, lalu tambah kan sedikit air tambah garam,lada,gula dan royco aduk&#34; (koreksi rasanya) masak ayam sampai air nya sdikit meresap lalu masuk kan kemangi aduk sampai layu. Ayam rica&#34; siap di santap bund"
categories:
- Recipe
tags:
- 004
- ayam
- rica

katakunci: 004 ayam rica 
nutrition: 273 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT37M"
recipeyield: "4"
recipecategory: Dessert

---


![004. AYAM RICA&#34; KEMANGI](https://img-global.cpcdn.com/recipes/9a8ccbae8b9d3f21/751x532cq70/004-ayam-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan enak. Karasteristik makanan Indonesia 004. ayam rica&#34; kemangi yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap.

Kehangatan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah memasak 004. AYAM RICA&#34; KEMANGI untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang bisa anda contoh salah satunya 004. ayam rica&#34; kemangi yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep 004. ayam rica&#34; kemangi tanpa harus bersusah payah.
Seperti resep 004. AYAM RICA&#34; KEMANGI yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 004. AYAM RICA&#34; KEMANGI:

1. Siapkan 1/2 kg ayam potong
1. Harus ada 1 buab jeruk nipis
1. Tambah  Bumbu yang di halus kan
1. Siapkan 1/2 ikat kemangi
1. Dibutuhkan 2 buah bawang putih
1. Tambah 3 buah bawang merah
1. Jangan lupa 1 buah kemiri
1. Harus ada 7 buah cabe merah
1. Diperlukan 5 buah cabe rawit(selera pedas)
1. Siapkan 1/2 ruas kunyit
1. Harap siapkan 1/2 ruas jahe
1. Dibutuhkan  Bumbu tambahan
1. Dibutuhkan 1/2 ruas lengkuas (di geprek)
1. Harus ada 2 btg sereh (digeprek)
1. Dibutuhkan 3 lbr daun jeruk
1. Harap siapkan  sck garam
1. Siapkan  Sck lada
1. Siapkan  sck gula
1. Tambah  Sck royco
1. Tambah  sck air


Rica berarti pedas, cocok banget buat bikin selera makan. Apalagi kalau rica ayam di kasih taburan kemangi, dijamin aromanya makin sedap. Yuk, simak resep bahan membuat ayam rica kemangi di bawah ini! Resep Cara Membuat Ayam Goreng Lengkuas Yang Enak Dan Gurih. 

<!--inarticleads2-->

##### Langkah membuat  004. AYAM RICA&#34; KEMANGI:

1. Cuci bersih ayam lalu lumuri dengan jeruk nipis, setelah itu rebus ayam selama 15-20 menit lqlu tiris kan
1. Lalu goreng ayam tadi jgn terlalu kering tiriskan
1. Tumis bumbu yang sudah di haluskan tadi bersama lengkuas,sereh,daun jeruk sampai harum dan kecoklatan
1. Masuk kan ayam ke dalam bumbu yang suda matang aduk&#34;, lalu tambah kan sedikit air tambah garam,lada,gula dan royco aduk&#34; (koreksi rasanya) masak ayam sampai air nya sdikit meresap lalu masuk kan kemangi aduk sampai layu. Ayam rica&#34; siap di santap bund


Yuk, simak resep bahan membuat ayam rica kemangi di bawah ini! Resep Cara Membuat Ayam Goreng Lengkuas Yang Enak Dan Gurih. Resep Membuat Soto Babat Super Empuk Dan Lezat. Rica-rica sendiri bisa terbuat dari berbagai bahan utama, namun yang paling populer adalah ayam. Selain mudah didapat, daging ayam juga relatif lebih murah jika dibandingkan dengan bahan-bahan lain seperti daging entok dan sebagainya. 

Demikianlah cara membuat 004. ayam rica&#34; kemangi yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
