---
description: "Panduan untuk membuat 48. Ayam Rica Kemangi Kuah Kuning Terbukti"
title: "Panduan untuk membuat 48. Ayam Rica Kemangi Kuah Kuning Terbukti"
slug: 208-panduan-untuk-membuat-48-ayam-rica-kemangi-kuah-kuning-terbukti
date: 2021-01-05T03:18:18.871Z
image: https://img-global.cpcdn.com/recipes/008db8d0ec9c67e0/751x532cq70/48-ayam-rica-kemangi-kuah-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/008db8d0ec9c67e0/751x532cq70/48-ayam-rica-kemangi-kuah-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/008db8d0ec9c67e0/751x532cq70/48-ayam-rica-kemangi-kuah-kuning-foto-resep-utama.jpg
author: Devin Fletcher
ratingvalue: 4.6
reviewcount: 12862
recipeingredient:
- "1/2 kg ayam potong kecilsesuai selera"
- "1 ikat daun kemangi"
- "1 batang daun bawang iris"
- "1 buah tomat potong2"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 cm lengkuas geprek"
- "1 batang serai geprek"
- "3 sdt kaldu bubuk"
- "1 sdt garam"
- "1 sdt kecap manis"
- "1 sdt gula pasir sesuai selera"
- "300 ml air sesuai selera"
- " Bumbu halus "
- "4 siung bawang putih"
- "8 siung bawang merah"
- "3 butir kemiri"
- "1 sdt ketumbar bubuk"
- "1 cm kunyit"
- "1 cm jahe"
- "10 buah cabe rawit sesuai selera"
- "1 buah cabe keriting aslinya 6"
recipeinstructions:
- "Siapkan semua bahan, blender semua bumbu halus."
- "Tumis bumbu halus dengan sedikit minyak hingga harum, masukkan daun salam, daun jeruk dan serai. Tumis2 sebentar, masukkan daging ayam. Tumis lagi sampai agak berubah warna."
- "Tambahkan air, masak sampai daging ayam matang dan air agak menyusut. (saya suka agak berkuah jd airnya lumayan banyak). Masukkan tomat, kaldu bubuk, garam, gula pasir dan kecap. Koreksi rasa. Jika sudah pas, masukkan kemangi dan daun bawang. Aduk rata."
- "Masak sampai kemangi layu dan harum. Siap disajikan 😇"
categories:
- Recipe
tags:
- 48
- ayam
- rica

katakunci: 48 ayam rica 
nutrition: 160 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Dessert

---


![48. Ayam Rica Kemangi Kuah Kuning](https://img-global.cpcdn.com/recipes/008db8d0ec9c67e0/751x532cq70/48-ayam-rica-kemangi-kuah-kuning-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang patut kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti 48. ayam rica kemangi kuah kuning yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan keistimewahan yang merupakan keragaman Indonesia

Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Resep sayap ayam sambel pedas kemangi atau lebih di kenal dengan Ayam Rica Rica khas Manado. Mungkin tiap ornag cara memasak nya beda beda, nah Cara srik. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera.

Kehangatan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah memasak 48. Ayam Rica Kemangi Kuah Kuning untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang bisa anda praktekkan salah satunya 48. ayam rica kemangi kuah kuning yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep 48. ayam rica kemangi kuah kuning tanpa harus bersusah payah.
Seperti resep 48. Ayam Rica Kemangi Kuah Kuning yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 48. Ayam Rica Kemangi Kuah Kuning:

1. Harus ada 1/2 kg ayam, potong kecil/sesuai selera
1. Siapkan 1 ikat daun kemangi
1. Dibutuhkan 1 batang daun bawang, iris
1. Harap siapkan 1 buah tomat, potong2
1. Diperlukan 2 lembar daun salam
1. Tambah 2 lembar daun jeruk
1. Dibutuhkan 1 cm lengkuas, geprek
1. Diperlukan 1 batang serai, geprek
1. Siapkan 3 sdt kaldu bubuk
1. Diperlukan 1 sdt garam
1. Diperlukan 1 sdt kecap manis
1. Diperlukan 1 sdt gula pasir (sesuai selera)
1. Jangan lupa 300 ml air (sesuai selera)
1. Diperlukan  Bumbu halus :
1. Harap siapkan 4 siung bawang putih
1. Diperlukan 8 siung bawang merah
1. Harus ada 3 butir kemiri
1. Diperlukan 1 sdt ketumbar bubuk
1. Diperlukan 1 cm kunyit
1. Diperlukan 1 cm jahe
1. Tambah 10 buah cabe rawit (sesuai selera)
1. Jangan lupa 1 buah cabe keriting (aslinya 6)


Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal. - Masukkan cabai hijau kasar dan irisan daun bawang lalu aduk-aduk, setelah kuah rica mengental nyemek berminyak masukkan kemangi. Cara Membuat Ayam Bumbu Kuning Kemangi Berikut adalah cara memasak rica rica ayam bumbu kuning kemangi yang enak. Cara membuat masakan ayam rica rica sebenarnya hampir sama dengan resep ayam pedas lainnya, hanya takran dan bahan bumbunya saja yang sedikit berbeda. Kelezatan masakan asli manado ini cukup terkenal, sehingga kadang kala kita temukan untuk jamuan pesta pernikahan, sunatan, dan. 

<!--inarticleads2-->

##### Instruksi membuat  48. Ayam Rica Kemangi Kuah Kuning:

1. Siapkan semua bahan, blender semua bumbu halus.
1. Tumis bumbu halus dengan sedikit minyak hingga harum, masukkan daun salam, daun jeruk dan serai. Tumis2 sebentar, masukkan daging ayam. Tumis lagi sampai agak berubah warna.
1. Tambahkan air, masak sampai daging ayam matang dan air agak menyusut. (saya suka agak berkuah jd airnya lumayan banyak). Masukkan tomat, kaldu bubuk, garam, gula pasir dan kecap. Koreksi rasa. Jika sudah pas, masukkan kemangi dan daun bawang. Aduk rata.
1. Masak sampai kemangi layu dan harum. Siap disajikan 😇


Cara membuat masakan ayam rica rica sebenarnya hampir sama dengan resep ayam pedas lainnya, hanya takran dan bahan bumbunya saja yang sedikit berbeda. Kelezatan masakan asli manado ini cukup terkenal, sehingga kadang kala kita temukan untuk jamuan pesta pernikahan, sunatan, dan. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat memanjakan lidah. Cocok jika kamu ingin mencoba resep satu ini. 

Demikianlah cara membuat 48. ayam rica kemangi kuah kuning yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
