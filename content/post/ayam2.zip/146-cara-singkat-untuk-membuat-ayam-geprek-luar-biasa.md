---
description: "Cara singkat untuk membuat Ayam Geprek Luar biasa"
title: "Cara singkat untuk membuat Ayam Geprek Luar biasa"
slug: 146-cara-singkat-untuk-membuat-ayam-geprek-luar-biasa
date: 2021-01-04T06:04:34.019Z
image: https://img-global.cpcdn.com/recipes/f167a4108b531e6c/751x532cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f167a4108b531e6c/751x532cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f167a4108b531e6c/751x532cq70/ayam-geprek-foto-resep-utama.jpg
author: Ronnie Ballard
ratingvalue: 4.6
reviewcount: 11845
recipeingredient:
- "1 bh ayam goreng tepung ala KFC"
- "25 gr bawang merah"
- "25 gr cabai rawit"
- "secukupnya garam"
- " gula pasir sedikit saja bisa ga pakai kalau ga suka"
- " mentimun  kemangi"
recipeinstructions:
- "Rajang kasar bawang merah kmdn goreng dlm minyak panas bersama cabai rawit hingga ½ matang"
- "Letakkan pd cobek, beri garam &amp; sdkt gula kmdn ulek hingga halus"
- "Siapkan ayam goreng tepungnya"
- "Ambil 1 ayam goreng, letakkan diatas sambal kmdn geprek dg ulekan hingga hancur"
- "Balik dg spatula, tekan² lagi dg ulekan"
- "Siapkan lalapannya"
- "Hidangkan dg nasi putih hangat"
- "Makannya pakai tangan ya.. Selamat berbuka... Mantaaapp 👌😋"
categories:
- Recipe
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 162 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/f167a4108b531e6c/751x532cq70/ayam-geprek-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga enak. Ciri khas kuliner Nusantara ayam geprek yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam Geprek untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang dapat anda praktekkan salah satunya ayam geprek yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep ayam geprek tanpa harus bersusah payah.
Seperti resep Ayam Geprek yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 6 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek:

1. Harus ada 1 bh ayam goreng tepung (ala KFC)
1. Diperlukan 25 gr bawang merah
1. Jangan lupa 25 gr cabai rawit
1. Harus ada secukupnya garam
1. Harus ada  gula pasir sedikit saja, bisa ga pakai kalau ga suka
1. Harap siapkan  mentimun &amp; kemangi




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Geprek:

1. Rajang kasar bawang merah kmdn goreng dlm minyak panas bersama cabai rawit hingga ½ matang
1. Letakkan pd cobek, beri garam &amp; sdkt gula kmdn ulek hingga halus
1. Siapkan ayam goreng tepungnya
1. Ambil 1 ayam goreng, letakkan diatas sambal kmdn geprek dg ulekan hingga hancur
1. Balik dg spatula, tekan² lagi dg ulekan
1. Siapkan lalapannya
1. Hidangkan dg nasi putih hangat
1. Makannya pakai tangan ya.. Selamat berbuka... Mantaaapp 👌😋




Demikianlah cara membuat ayam geprek yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan cepat, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
