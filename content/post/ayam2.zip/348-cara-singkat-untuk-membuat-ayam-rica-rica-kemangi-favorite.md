---
description: "Cara singkat untuk membuat Ayam Rica Rica Kemangi Favorite"
title: "Cara singkat untuk membuat Ayam Rica Rica Kemangi Favorite"
slug: 348-cara-singkat-untuk-membuat-ayam-rica-rica-kemangi-favorite
date: 2020-10-12T14:20:53.482Z
image: https://img-global.cpcdn.com/recipes/a305d8bc4a92cace/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a305d8bc4a92cace/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a305d8bc4a92cace/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Justin Holland
ratingvalue: 4.7
reviewcount: 47941
recipeingredient:
- "1 ekor Ayam"
- "Secukupnya Daun Kemangi"
- "Secukupnya Minyak Goreng"
- "Secukupnya Air"
- " Bumbu Halus"
- "6 siung Bawang Putih"
- "8 siung Bawang Merah"
- "10 buah Cabe Rawit sesuaikan selera"
- "10 buah Cabe Merah sesuaikan selera"
- "1 ruas Jahe"
- "1 ruas Kunyit"
- "3 buah Kemiri"
- " Bumbu Tambahan"
- "1 ruas Lengkuas"
- "3 lembar Daun Jeruk"
- "2 lembar Daun Salam"
- "2 buah Serai"
- "2 sdm Gula"
- "2 sdt garam"
- "1 sdt Penyedap"
recipeinstructions:
- "Cuci bersih ayam."
- "Blender bumbu halus dengan sedikit air."
- "Tumis bumbu halus dengan minyak secukupnya hingga air menyurut. Tambahkan daun jeruk, daun salam, serai, lengkuas. Tumis hingga harum."
- "Tambahkan air dan masukan ayam. Airnya secukupnya aja sampai ayam terendam. Aduk. Tutup. Masak hingga mendidih."
- "Tambahkan gula, garam, penyedap. Aduk rata, koreksi rasa. Tambahkan bumbu yg perlu ditambahkan. Tutup lagi hingga air menyurut."
- "Jika bumbu sudah menyerap, tambahkan daun kemangi. Aduk sebentar matikan kompor. Ayam siap disajikan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 227 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/a305d8bc4a92cace/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica rica kemangi yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa keistimewahan yang merupakan keragaman Kita

Keharmonisan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica Rica Kemangi untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang dapat anda buat salah satunya ayam rica rica kemangi yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 20 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi:

1. Tambah 1 ekor Ayam
1. Dibutuhkan Secukupnya Daun Kemangi
1. Harus ada Secukupnya Minyak Goreng
1. Diperlukan Secukupnya Air
1. Jangan lupa  Bumbu Halus
1. Jangan lupa 6 siung Bawang Putih
1. Harus ada 8 siung Bawang Merah
1. Jangan lupa 10 buah Cabe Rawit (sesuaikan selera)
1. Jangan lupa 10 buah Cabe Merah (sesuaikan selera)
1. Siapkan 1 ruas Jahe
1. Siapkan 1 ruas Kunyit
1. Tambah 3 buah Kemiri
1. Harus ada  Bumbu Tambahan
1. Dibutuhkan 1 ruas Lengkuas
1. Diperlukan 3 lembar Daun Jeruk
1. Diperlukan 2 lembar Daun Salam
1. Dibutuhkan 2 buah Serai
1. Harap siapkan 2 sdm Gula
1. Dibutuhkan 2 sdt garam
1. Diperlukan 1 sdt Penyedap




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica Kemangi:

1. Cuci bersih ayam.
1. Blender bumbu halus dengan sedikit air.
1. Tumis bumbu halus dengan minyak secukupnya hingga air menyurut. Tambahkan daun jeruk, daun salam, serai, lengkuas. Tumis hingga harum.
1. Tambahkan air dan masukan ayam. Airnya secukupnya aja sampai ayam terendam. Aduk. Tutup. Masak hingga mendidih.
1. Tambahkan gula, garam, penyedap. Aduk rata, koreksi rasa. Tambahkan bumbu yg perlu ditambahkan. Tutup lagi hingga air menyurut.
1. Jika bumbu sudah menyerap, tambahkan daun kemangi. Aduk sebentar matikan kompor. Ayam siap disajikan.




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
