---
description: "Step-by-Step menyiapakan Ayam Rica Kemangi Luar biasa"
title: "Step-by-Step menyiapakan Ayam Rica Kemangi Luar biasa"
slug: 349-step-by-step-menyiapakan-ayam-rica-kemangi-luar-biasa
date: 2020-12-08T12:58:06.319Z
image: https://img-global.cpcdn.com/recipes/ef7107c21b9ca6d3/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ef7107c21b9ca6d3/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ef7107c21b9ca6d3/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Jeanette Horton
ratingvalue: 4.5
reviewcount: 5953
recipeingredient:
- "6 potong ayam"
- "1 ikat daun kemangi"
- "3 siung bawang putih"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 buah jeruk nipis"
- "1 batang serai"
- "2 ruas jahe"
- "1 ruas lengkuas"
- "1 sdt penyedap rasa"
- "Secukupnya garam"
- "Secukupnya gula"
- " Bumbu halus"
- "12 cabai merah keriting"
- "10 cabai rawit"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "2 butir kemiri"
- "1 ruas kunyit"
recipeinstructions:
- "Cuci bersih ayam. lumuri dengan jeruk nipis, tunggu beberapa saat lalu cuci ayam kembali"
- "Rebus ayam dengan 1 ruas jahe dan 3 siung bawang putih geprek"
- "Lalu goreng ayam sebentar, tidak perlu sampai kering"
- "Tumis bumbu halus sambil masukan serai, daun salam, daun jeruk, jahe dan lengkuas hingga harum"
- "Tambahkan air setengah gelas belimbing, lalu masukan penyedap rasa, garam dan gula secukupnya. Lalu koreksi rasa"
- "Masukan ayam yang sudah di goreng, aduk sebentar lalu tambahkan daun kemangi. Masak hingga air menyusut"
- "Setelah air menyusut, angkat dan sajikan🐣"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 116 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/ef7107c21b9ca6d3/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang patut kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica kemangi yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Nusantara

Keharmonisan keluarga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica Kemangi untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang dapat anda contoh salah satunya ayam rica kemangi yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 19 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Siapkan 6 potong ayam
1. Jangan lupa 1 ikat daun kemangi
1. Diperlukan 3 siung bawang putih
1. Dibutuhkan 2 lembar daun salam
1. Harus ada 3 lembar daun jeruk
1. Harap siapkan 1 buah jeruk nipis
1. Tambah 1 batang serai
1. Jangan lupa 2 ruas jahe
1. Dibutuhkan 1 ruas lengkuas
1. Tambah 1 sdt penyedap rasa
1. Dibutuhkan Secukupnya garam
1. Siapkan Secukupnya gula
1. Harus ada  Bumbu halus
1. Harap siapkan 12 cabai merah keriting
1. Siapkan 10 cabai rawit
1. Dibutuhkan 5 siung bawang merah
1. Tambah 3 siung bawang putih
1. Siapkan 2 butir kemiri
1. Harus ada 1 ruas kunyit




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Kemangi:

1. Cuci bersih ayam. lumuri dengan jeruk nipis, tunggu beberapa saat lalu cuci ayam kembali
1. Rebus ayam dengan 1 ruas jahe dan 3 siung bawang putih geprek
1. Lalu goreng ayam sebentar, tidak perlu sampai kering
1. Tumis bumbu halus sambil masukan serai, daun salam, daun jeruk, jahe dan lengkuas hingga harum
1. Tambahkan air setengah gelas belimbing, lalu masukan penyedap rasa, garam dan gula secukupnya. Lalu koreksi rasa
1. Masukan ayam yang sudah di goreng, aduk sebentar lalu tambahkan daun kemangi. Masak hingga air menyusut
1. Setelah air menyusut, angkat dan sajikan🐣




Demikianlah cara membuat ayam rica kemangi yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan teruji, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
