---
description: "Panduan menyiapakan Ayam rica - rica pedas kemangi Terbukti"
title: "Panduan menyiapakan Ayam rica - rica pedas kemangi Terbukti"
slug: 252-panduan-menyiapakan-ayam-rica-rica-pedas-kemangi-terbukti
date: 2020-09-22T16:00:20.096Z
image: https://img-global.cpcdn.com/recipes/777b13758f6f8df5/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/777b13758f6f8df5/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/777b13758f6f8df5/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
author: Barry Chambers
ratingvalue: 4.6
reviewcount: 14910
recipeingredient:
- "500 gr ayam potong beberapa bagian"
- "1 ikat kemangi"
- "2 buah cabe merah  sesuai selera"
- "20 cabe rawit  sesuai selera"
- "2 buah tomat"
- "1 ruas jari jahe"
- "2 buah serai"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "secukupnya Kaldu jamur"
- "secukupnya Garam"
- "secukupnya Gula"
- "3 sdm Minyak goreng"
- "1 gelas air"
recipeinstructions:
- "Rebus ayam terlebih dahulu (boleh juga tanpa direbus dahulu)"
- "Haluskan cabe merah, cabe rawit, tomat, bawang merah, bawang putih, dan daun jeruk 1 lembar"
- "Panaskan minyak goreng, tumis bumbu yang sudah dihaluskan sampai harum. Lalu masukkan serai geprek, jahe geprek, daun salam, dan sisa daun jeruk."
- "Aduk sampai harum, tambahkan kaldu jamur, gula, garam dan air 1 gelas. Cek rasa"
- "Masukkan ayam, Aduk hingga rata. Biarkan hingga air menyusut sedikit."
- "Tambahkan kemangi."
- "Aduk sebentar, matikan kompor dan sajikan dengan nasi hangat."
- "Selamat mencoba. ☺️☺️"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 250 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica - rica pedas kemangi](https://img-global.cpcdn.com/recipes/777b13758f6f8df5/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica - rica pedas kemangi yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Nusantara

Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica. Resep &#39;ayam rica rica&#39; paling teruji. Ayam rica rica. ayam•kemangi•Bumbu ulek•bawang putih•cabe merah besar•kemiri sangrai•Jahe•Lengkuas,sereh.

Kehangatan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Ayam rica - rica pedas kemangi untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda coba salah satunya ayam rica - rica pedas kemangi yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep ayam rica - rica pedas kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica - rica pedas kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica - rica pedas kemangi:

1. Diperlukan 500 gr ayam (potong beberapa bagian)
1. Dibutuhkan 1 ikat kemangi
1. Harap siapkan 2 buah cabe merah / sesuai selera
1. Harap siapkan 20 cabe rawit / sesuai selera
1. Diperlukan 2 buah tomat
1. Jangan lupa 1 ruas jari jahe
1. Dibutuhkan 2 buah serai
1. Diperlukan 3 lembar daun salam
1. Harap siapkan 3 lembar daun jeruk
1. Tambah 5 siung bawang merah
1. Harap siapkan 3 siung bawang putih
1. Siapkan secukupnya Kaldu jamur
1. Harap siapkan secukupnya Garam
1. Jangan lupa secukupnya Gula
1. Jangan lupa 3 sdm Minyak goreng
1. Diperlukan 1 gelas air


Rica merupakan bahasa Manado yang berarti pedas, bisa dimaknai bahwa kuliner ini merupakan ayam yang diberi bumbu pedas. Nah, untuk membuat resep Ayam Rica Kemangi khas Manado ini, tentu ada beberapa hal yang harus diperhatikan. Sebut saja rica-rica, makanan dengan cita rasa pedas ini merupakan salah satu makanan asal Manado yang sudah melegenda di Indonesia. Rica-rica sendiri bisa terbuat dari berbagai bahan utama, namun yang paling populer adalah ayam. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica - rica pedas kemangi:

1. Rebus ayam terlebih dahulu (boleh juga tanpa direbus dahulu)
1. Haluskan cabe merah, cabe rawit, tomat, bawang merah, bawang putih, dan daun jeruk 1 lembar
1. Panaskan minyak goreng, tumis bumbu yang sudah dihaluskan sampai harum. Lalu masukkan serai geprek, jahe geprek, daun salam, dan sisa daun jeruk.
1. Aduk sampai harum, tambahkan kaldu jamur, gula, garam dan air 1 gelas. Cek rasa
1. Masukkan ayam, Aduk hingga rata. Biarkan hingga air menyusut sedikit.
1. Tambahkan kemangi.
1. Aduk sebentar, matikan kompor dan sajikan dengan nasi hangat.
1. Selamat mencoba. ☺️☺️


Sebut saja rica-rica, makanan dengan cita rasa pedas ini merupakan salah satu makanan asal Manado yang sudah melegenda di Indonesia. Rica-rica sendiri bisa terbuat dari berbagai bahan utama, namun yang paling populer adalah ayam. Selain mudah didapat, daging ayam juga relatif. Bumbu rica-rica khas Manado bisa dipadukan dengan aneka bahan, seperti ayam. Coba membuat ayam panggang bumbu rica-rica berdasarkan resep ini. 

Demikianlah cara membuat ayam rica - rica pedas kemangi yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan terbukti, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
