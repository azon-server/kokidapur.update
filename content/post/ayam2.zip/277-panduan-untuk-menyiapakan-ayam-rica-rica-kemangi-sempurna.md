---
description: "Panduan untuk menyiapakan Ayam Rica-rica Kemangi Sempurna"
title: "Panduan untuk menyiapakan Ayam Rica-rica Kemangi Sempurna"
slug: 277-panduan-untuk-menyiapakan-ayam-rica-rica-kemangi-sempurna
date: 2020-11-05T02:39:58.332Z
image: https://img-global.cpcdn.com/recipes/3f57630f0ca64bc3/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3f57630f0ca64bc3/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3f57630f0ca64bc3/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Rena Knight
ratingvalue: 4.1
reviewcount: 3144
recipeingredient:
- "1/2 kg ayam"
- " Jeruk nipis"
- "2 lmbr daun salam"
- "3 lmbr daun jeruk"
- "2 batang serai"
- "Segenggam kemangi"
- " Bumbu halus"
- "7 buah cabe merah besar"
- "15 buah cabe kecil"
- "3 siung bamer"
- "2 siung baput"
- "2 buah kemiri"
- "secukupnya Garam 12 sdt lada gula penyedap 1412 sdt"
recipeinstructions:
- "Lumuri ayam dengan jeruk nipis, diamkan 5-10 menit lalu bilas sampai bersih"
- "Masukkan ayam dalam panci berisi air, cemplung 1 lmbr daun salam 1 lmbr daun jeruk dan 1 batang sereh serta garam secukupnya"
- "Didihkan lalu tunggu 3 menit, angkat ayam dan tiriskan. Tidak perlu sampai matang."
- "Tumis bumbu halus sampai matang, lalu tambahkan garam, gula, merica, penyedap."
- "Masukkan ayam yg sudah direbus, lalu tambahkan air sampai ayam hampir terendam."
- "Masak sampai air surut dan bumbu meresap. Koreksi rasa dan sajikan."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 169 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/3f57630f0ca64bc3/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita jaga karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica-rica kemangi yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Kita

Kehangatan keluarga dapat ditemukan dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica-rica Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang dapat anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 13 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Kemangi:

1. Tambah 1/2 kg ayam
1. Tambah  Jeruk nipis
1. Harap siapkan 2 lmbr daun salam
1. Dibutuhkan 3 lmbr daun jeruk
1. Tambah 2 batang serai
1. Diperlukan Segenggam kemangi
1. Dibutuhkan  Bumbu halus:
1. Tambah 7 buah cabe merah besar
1. Siapkan 15 buah cabe kecil
1. Tambah 3 siung bamer
1. Siapkan 2 siung baput
1. Diperlukan 2 buah kemiri
1. Jangan lupa secukupnya Garam (1/2 sdt), lada, gula, penyedap (1/4-1/2 sdt)




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-rica Kemangi:

1. Lumuri ayam dengan jeruk nipis, diamkan 5-10 menit lalu bilas sampai bersih
1. Masukkan ayam dalam panci berisi air, cemplung 1 lmbr daun salam 1 lmbr daun jeruk dan 1 batang sereh serta garam secukupnya
1. Didihkan lalu tunggu 3 menit, angkat ayam dan tiriskan. Tidak perlu sampai matang.
1. Tumis bumbu halus sampai matang, lalu tambahkan garam, gula, merica, penyedap.
1. Masukkan ayam yg sudah direbus, lalu tambahkan air sampai ayam hampir terendam.
1. Masak sampai air surut dan bumbu meresap. Koreksi rasa dan sajikan.




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan teruji, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
