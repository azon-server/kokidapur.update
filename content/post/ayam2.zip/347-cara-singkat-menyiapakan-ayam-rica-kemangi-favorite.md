---
description: "Cara singkat menyiapakan Ayam Rica kemangi Favorite"
title: "Cara singkat menyiapakan Ayam Rica kemangi Favorite"
slug: 347-cara-singkat-menyiapakan-ayam-rica-kemangi-favorite
date: 2021-01-21T14:16:29.134Z
image: https://img-global.cpcdn.com/recipes/6ec9b33178c9dd62/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6ec9b33178c9dd62/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6ec9b33178c9dd62/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Jeremiah Young
ratingvalue: 4.3
reviewcount: 4607
recipeingredient:
- "6 potong ayam"
- "secukupnya Kemangi"
- "1 buah jeruk"
- " Bumbu halus"
- "3 bawang putih besar"
- "6 bawang merah"
- "20 cabe setan"
- "Sedikit jahe"
- "Sejempol kunyit"
- "1 kemiri"
- " Bahan cemplung"
- "2 buah daun jeruk"
- " Lengkuas memarkan"
- "1 batang sereh memarkan"
- "Sedikit garam"
- "secukupnya Penyedap rasa"
- " Kecap manis"
recipeinstructions:
- "Marinasi ayam dengan jeruk sebentar, saya hanya 3 menit."
- "Haluskan semua bumbu halus, kemudian tumis sampai harum."
- "Masukan daun jeruk, lengkuas, sereh."
- "Masukan ayam bolak balik sampai bumbu rata di ayam, masukan garam,penyedap rasa Dan kecap, tambah air secukupnya..."
- "Terakhir tunggu sampai airnya asat Dan ayamnya masak, jangan lupa keroksi rasa..."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 212 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica kemangi](https://img-global.cpcdn.com/recipes/6ec9b33178c9dd62/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang harus kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica kemangi yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Kita

Kehangatan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Rica kemangi untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang bisa anda coba salah satunya ayam rica kemangi yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan gampang menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica kemangi:

1. Harus ada 6 potong ayam
1. Harus ada secukupnya Kemangi
1. Jangan lupa 1 buah jeruk
1. Jangan lupa  Bumbu halus
1. Dibutuhkan 3 bawang putih besar
1. Siapkan 6 bawang merah
1. Dibutuhkan 20 cabe setan
1. Siapkan Sedikit jahe
1. Tambah Sejempol kunyit
1. Dibutuhkan 1 kemiri
1. Tambah  Bahan cemplung
1. Diperlukan 2 buah daun jeruk
1. Siapkan  Lengkuas memarkan
1. Dibutuhkan 1 batang sereh memarkan
1. Harap siapkan Sedikit garam
1. Diperlukan secukupnya Penyedap rasa
1. Dibutuhkan  Kecap manis




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica kemangi:

1. Marinasi ayam dengan jeruk sebentar, saya hanya 3 menit.
1. Haluskan semua bumbu halus, kemudian tumis sampai harum.
1. Masukan daun jeruk, lengkuas, sereh.
1. Masukan ayam bolak balik sampai bumbu rata di ayam, masukan garam,penyedap rasa Dan kecap, tambah air secukupnya...
1. Terakhir tunggu sampai airnya asat Dan ayamnya masak, jangan lupa keroksi rasa...




Demikianlah cara membuat ayam rica kemangi yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan teruji, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
