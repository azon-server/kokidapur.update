---
description: "Cara menyiapakan Ayam Rica-rica Kemangi terupdate"
title: "Cara menyiapakan Ayam Rica-rica Kemangi terupdate"
slug: 284-cara-menyiapakan-ayam-rica-rica-kemangi-terupdate
date: 2020-09-24T02:57:42.314Z
image: https://img-global.cpcdn.com/recipes/feafdd200e636647/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/feafdd200e636647/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/feafdd200e636647/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Laura Norris
ratingvalue: 4.1
reviewcount: 20730
recipeingredient:
- " Bumbu A"
- "6 siung bawang merah"
- "6 siung bawang putih"
- "2 buah cabe hijau"
- "4 butir Kemiri"
- " Cabe rawit"
- " Bumbu B"
- "2 ruas jari Lengkuas geprek"
- "1 batang Serai geprek"
- " Daun jeruk potong kecil"
- " Daun salam potong kecil"
- " Kunir bubuk"
- "2 sdm gula"
- "1 sdm garam"
- "1 sdm Kaldu jamur"
- "Segenggam kemangi"
- " Bahan C"
- "500 gram Ayam"
- " Air"
recipeinstructions:
- "Rebus ayam, sampai empuk.. sisihkan kaldu rebusan ayam. Lalu potong ayam sesuai selera"
- "Goreng ayam setengah matang"
- "Buat bumbu halus. Campur semua bumbu A, bisa diuleg atau blender."
- "Siapkan minyak, lalu goreng bumbu yg sdh dihaluskan, sampai keluar aroma. Tambahkan air rebusan ayam tadi. Tunggu mendidih. Tambahkan semua bumbu B. Koreksi rasa."
- "Apabila sdh pas, masukkan ayam. Bolak balik sebentar dan tutup sampai bumbu meresap. Terakhir masukkan kemangi."
- "Ayam rica rica kemangi siap disajikan"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 144 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/feafdd200e636647/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas hingga empuk. Ciri khas makanan Nusantara ayam rica-rica kemangi yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica-rica Kemangi untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang bisa anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica Kemangi:

1. Diperlukan  Bumbu A
1. Jangan lupa 6 siung bawang merah
1. Dibutuhkan 6 siung bawang putih
1. Harus ada 2 buah cabe hijau
1. Harus ada 4 butir Kemiri
1. Harus ada  Cabe rawit
1. Harap siapkan  Bumbu B
1. Diperlukan 2 ruas jari Lengkuas (geprek)
1. Siapkan 1 batang Serai (geprek)
1. Harap siapkan  Daun jeruk (potong kecil)
1. Dibutuhkan  Daun salam (potong kecil)
1. Diperlukan  Kunir bubuk
1. Dibutuhkan 2 sdm gula
1. Siapkan 1 sdm garam
1. Dibutuhkan 1 sdm Kaldu jamur
1. Siapkan Segenggam kemangi
1. Harap siapkan  Bahan C
1. Harus ada 500 gram Ayam
1. Dibutuhkan  Air




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-rica Kemangi:

1. Rebus ayam, sampai empuk.. sisihkan kaldu rebusan ayam. Lalu potong ayam sesuai selera
1. Goreng ayam setengah matang
1. Buat bumbu halus. Campur semua bumbu A, bisa diuleg atau blender.
1. Siapkan minyak, lalu goreng bumbu yg sdh dihaluskan, sampai keluar aroma. Tambahkan air rebusan ayam tadi. Tunggu mendidih. Tambahkan semua bumbu B. Koreksi rasa.
1. Apabila sdh pas, masukkan ayam. Bolak balik sebentar dan tutup sampai bumbu meresap. Terakhir masukkan kemangi.
1. Ayam rica rica kemangi siap disajikan




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
