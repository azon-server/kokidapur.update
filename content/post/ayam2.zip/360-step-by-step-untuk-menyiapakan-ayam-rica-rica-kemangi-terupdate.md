---
description: "Step-by-Step untuk menyiapakan Ayam rica-rica kemangi terupdate"
title: "Step-by-Step untuk menyiapakan Ayam rica-rica kemangi terupdate"
slug: 360-step-by-step-untuk-menyiapakan-ayam-rica-rica-kemangi-terupdate
date: 2020-10-03T03:57:06.498Z
image: https://img-global.cpcdn.com/recipes/b87cf96fc8c1e3c6/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b87cf96fc8c1e3c6/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b87cf96fc8c1e3c6/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Terry Holmes
ratingvalue: 4.8
reviewcount: 49862
recipeingredient:
- "1/2 Ekor Ayam"
- "secukupnya Kemangi"
- " Jeruk nipislemon"
- " Bumbu yg d haluskan"
- "5 siung bawang merah"
- "2 siung bawang putih"
- "2 butir kemiri"
- "10 buah cabai merah"
- "sesuai selera Cabai rawit"
- " Kunyit secukup nya"
- "secukupnya Garam"
- "1 buah tomat"
- " Bumbu pelengkap "
- "1 ruas sereh d gprek"
- " Jahe di gprek"
- " Lengkuas secukup nya"
- " Daun salam"
- " Gula merah"
- " Kaldu bubuk"
- " Merica bubuk"
- " Minyak goreng untuk menumis bumbu"
recipeinstructions:
- "Cuci bersih ayam, potong² sesuai selera setelah itu beri perasan jeruk nipis/lemon diam kan kurang lebih 10menit."
- "Setelah 10menit cuci bersih ayam, rebus/ungkep ayam smpai stngh matang beri lada dan garam.setelah d rebus/ di ungkep ayam d goreng setengah matang tujuan nya biar ayam tdk begitu lembek/empuk."
- "Sementara menggoreng ayam, haluskan bumbu yg sudah siap di haluskan.. Selesai semua ayam d goreng,sisihkan.tumis bumbu sampai hilang bau langunya(bau bumbu mentah),tambahkan bumbu pelengkap, tumis lg smpai tercium aromanya, tambahkan air dan masukan ayam yg sudah d goreng td, tunggu sampai air susut, koreksi rasa.. Terakhir masukan daun kemanginya."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 280 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/b87cf96fc8c1e3c6/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa ciri khas yang merupakan keragaman Kita

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Kedekatan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica-rica kemangi untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang dapat anda contoh salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica kemangi:

1. Siapkan 1/2 Ekor Ayam
1. Diperlukan secukupnya Kemangi
1. Diperlukan  Jeruk nipis/lemon
1. Jangan lupa  #Bumbu yg d haluskan:
1. Harap siapkan 5 siung bawang merah
1. Harus ada 2 siung bawang putih
1. Harap siapkan 2 butir kemiri
1. Tambah 10 buah cabai merah
1. Diperlukan sesuai selera Cabai rawit
1. Diperlukan  Kunyit secukup nya
1. Siapkan secukupnya Garam
1. Siapkan 1 buah tomat
1. Jangan lupa  #Bumbu pelengkap :
1. Tambah 1 ruas sereh d gprek
1. Siapkan  Jahe di gprek
1. Diperlukan  Lengkuas secukup nya
1. Harus ada  Daun salam
1. Diperlukan  Gula merah
1. Harus ada  Kaldu bubuk
1. Harap siapkan  Merica bubuk
1. Jangan lupa  Minyak goreng untuk menumis bumbu


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Instruksi membuat  Ayam rica-rica kemangi:

1. Cuci bersih ayam, potong² sesuai selera setelah itu beri perasan jeruk nipis/lemon diam kan kurang lebih 10menit.
1. Setelah 10menit cuci bersih ayam, rebus/ungkep ayam smpai stngh matang beri lada dan garam.setelah d rebus/ di ungkep ayam d goreng setengah matang tujuan nya biar ayam tdk begitu lembek/empuk.
1. Sementara menggoreng ayam, haluskan bumbu yg sudah siap di haluskan.. Selesai semua ayam d goreng,sisihkan.tumis bumbu sampai hilang bau langunya(bau bumbu mentah),tambahkan bumbu pelengkap, tumis lg smpai tercium aromanya, tambahkan air dan masukan ayam yg sudah d goreng td, tunggu sampai air susut, koreksi rasa.. Terakhir masukan daun kemanginya.


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan teruji, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
