---
description: "Resep : Ayam Rica-Rica Kemangi terupdate"
title: "Resep : Ayam Rica-Rica Kemangi terupdate"
slug: 302-resep-ayam-rica-rica-kemangi-terupdate
date: 2020-12-10T09:44:18.968Z
image: https://img-global.cpcdn.com/recipes/fcf98377da530de9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fcf98377da530de9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fcf98377da530de9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Lewis Paul
ratingvalue: 4.6
reviewcount: 23353
recipeingredient:
- "1 ekor ayam potong jadi 12"
- "3 ikat daun kemangi"
- "3 sdm kecap manis"
- "1 sdt lada bubuk"
- "2 sdt garam"
- "2 sdt gula pasir"
- "1 sdt kaldu bubuk"
- "2 batang sereh"
- "3 lembar daun salam"
- "5 lembar daun jeruk"
- "1 ruas lengkuas"
- "1 sdm margarine"
- "300 ml air"
- " Bumbu halus"
- "8 buah cabe merah besar"
- "20 buah cabe rawit merah"
- "3 butir kemiri"
- "1 ruas kunyit"
- "1 ruas jahe"
- "6 siung bawang merah"
- "3 siung bawang putih"
recipeinstructions:
- "Rebus ayam sebentar saja untuk menghilangkan kotorannya, kurang lebih 10 menit. Setelah itu sisihkan ayam yg sudah direbus tadi."
- "Panaskan margarine, kemudian tumis bumbu halus. Tambahkan daun salam, daun jeruk, lengkuas dan sereh. Setelah harum, masukkan ayamnya. Aduk merata."
- "Tambahkan 300 ml air, kecap manis, gula, garam, lada bubuk dan kaldu bubuk. Koreksi rasa. Tunggu hingga air menyusut kemudian masukkan daun kemanginya. Aduk merata dan angkat jika sudah matang."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 283 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/fcf98377da530de9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga gurih. Karasteristik kuliner Nusantara ayam rica-rica kemangi yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Keharmonisan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica-Rica Kemangi untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda buat salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica Kemangi:

1. Tambah 1 ekor ayam (potong jadi 12)
1. Harus ada 3 ikat daun kemangi
1. Harap siapkan 3 sdm kecap manis
1. Diperlukan 1 sdt lada bubuk
1. Jangan lupa 2 sdt garam
1. Harap siapkan 2 sdt gula pasir
1. Harap siapkan 1 sdt kaldu bubuk
1. Harap siapkan 2 batang sereh
1. Siapkan 3 lembar daun salam
1. Harap siapkan 5 lembar daun jeruk
1. Siapkan 1 ruas lengkuas
1. Jangan lupa 1 sdm margarine
1. Dibutuhkan 300 ml air
1. Dibutuhkan  Bumbu halus:
1. Diperlukan 8 buah cabe merah besar
1. Harus ada 20 buah cabe rawit merah
1. Diperlukan 3 butir kemiri
1. Harus ada 1 ruas kunyit
1. Harap siapkan 1 ruas jahe
1. Tambah 6 siung bawang merah
1. Tambah 3 siung bawang putih




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-Rica Kemangi:

1. Rebus ayam sebentar saja untuk menghilangkan kotorannya, kurang lebih 10 menit. Setelah itu sisihkan ayam yg sudah direbus tadi.
1. Panaskan margarine, kemudian tumis bumbu halus. Tambahkan daun salam, daun jeruk, lengkuas dan sereh. Setelah harum, masukkan ayamnya. Aduk merata.
1. Tambahkan 300 ml air, kecap manis, gula, garam, lada bubuk dan kaldu bubuk. Koreksi rasa. Tunggu hingga air menyusut kemudian masukkan daun kemanginya. Aduk merata dan angkat jika sudah matang.




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat mudah dan cepat, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
