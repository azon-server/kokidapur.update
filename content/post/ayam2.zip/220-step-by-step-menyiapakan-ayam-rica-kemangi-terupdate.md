---
description: "Step-by-Step menyiapakan Ayam Rica Kemangi terupdate"
title: "Step-by-Step menyiapakan Ayam Rica Kemangi terupdate"
slug: 220-step-by-step-menyiapakan-ayam-rica-kemangi-terupdate
date: 2020-10-25T16:42:35.455Z
image: https://img-global.cpcdn.com/recipes/5dd8a41dd6bea65b/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5dd8a41dd6bea65b/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5dd8a41dd6bea65b/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Nathaniel Franklin
ratingvalue: 4.8
reviewcount: 13886
recipeingredient:
- "4 ekor ayam"
- "4 ikat kemangi"
- "1 ruas lengkuas geprek"
- "1 btg sereh geprek"
- "5 lmbr daun jeruk"
- "1 btg daun bawang iris"
- "Secukupnya garam kaldu jamur"
- "Secukupnya air"
- " Bumbu Halus "
- "5 siung bawang merah"
- "2 siung bawang putih"
- "6 bh cabe merah kriting"
- "15 bh cabe rawit setan optional"
- "2 btr kemiri"
- "Secukupnya jahe  kunyit"
- "Secukupnya gula merah"
recipeinstructions:
- "Siapkan wajan dan panaskan minyak"
- "Masukan bumbu halus, lengkuas, sereh, dan daun jeruk.. masak hingga harum"
- "Jika sdh harum masukan potongan ayam yg sdh di bersihkan, lalu beri air secukupnya"
- "Diamkan hingga ayam matang dan empuk, jika sdh mpuk beri garam dan kaldu jamur.."
- "Aduk&#34;hingga tercampur rata lalu cicipi, stlh rasa nya ok.. masukan kemangi dan daun bawang.. aduk&#34; lagi sebentar lalu matikan kompor.."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 267 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT31M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/5dd8a41dd6bea65b/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang harus kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica kemangi yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa kesan tersendiri yang merupakan keragaman Kita

Keharmonisan keluarga bisa didapat dengan cara mudah. Salah satunya adalah memasak Ayam Rica Kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda coba salah satunya ayam rica kemangi yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Diperlukan 4 ekor ayam
1. Diperlukan 4 ikat kemangi
1. Harap siapkan 1 ruas lengkuas (geprek)
1. Tambah 1 btg sereh (geprek)
1. Diperlukan 5 lmbr daun jeruk
1. Harap siapkan 1 btg daun bawang (iris)
1. Jangan lupa Secukupnya garam, kaldu jamur
1. Diperlukan Secukupnya air
1. Tambah  Bumbu Halus :
1. Siapkan 5 siung bawang merah
1. Dibutuhkan 2 siung bawang putih
1. Dibutuhkan 6 bh cabe merah kriting
1. Harap siapkan 15 bh cabe rawit setan (optional)
1. Harap siapkan 2 btr kemiri
1. Diperlukan Secukupnya jahe &amp; kunyit
1. Jangan lupa Secukupnya gula merah




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Kemangi:

1. Siapkan wajan dan panaskan minyak
1. Masukan bumbu halus, lengkuas, sereh, dan daun jeruk.. masak hingga harum
1. Jika sdh harum masukan potongan ayam yg sdh di bersihkan, lalu beri air secukupnya
1. Diamkan hingga ayam matang dan empuk, jika sdh mpuk beri garam dan kaldu jamur..
1. Aduk&#34;hingga tercampur rata lalu cicipi, stlh rasa nya ok.. masukan kemangi dan daun bawang.. aduk&#34; lagi sebentar lalu matikan kompor..




Demikianlah cara membuat ayam rica kemangi yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan cepat, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
