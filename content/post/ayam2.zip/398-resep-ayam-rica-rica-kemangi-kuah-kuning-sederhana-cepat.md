---
description: "Resep : Ayam rica-rica kemangi kuah kuning sederhana Cepat"
title: "Resep : Ayam rica-rica kemangi kuah kuning sederhana Cepat"
slug: 398-resep-ayam-rica-rica-kemangi-kuah-kuning-sederhana-cepat
date: 2020-11-27T06:43:03.891Z
image: https://img-global.cpcdn.com/recipes/5b1243de74b1b019/751x532cq70/ayam-rica-rica-kemangi-kuah-kuning-sederhana-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5b1243de74b1b019/751x532cq70/ayam-rica-rica-kemangi-kuah-kuning-sederhana-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5b1243de74b1b019/751x532cq70/ayam-rica-rica-kemangi-kuah-kuning-sederhana-foto-resep-utama.jpg
author: Matilda Jenkins
ratingvalue: 4.8
reviewcount: 43432
recipeingredient:
- "1/2 kg ayam atau 5 potong ayam saya pakai paha bawah"
- "1 ikat daun kemangi"
- "1 batang daun bawang"
- "1 buah tomat"
- "2 lembar daun salam"
- "1 cm lengkuas geprek"
- "1 batang serai geprek"
- "2 lembar daun jeruk buang batang"
- "3 sdt kaldu bubuk"
- "Sejumput garam sesuai selera"
- "1 sdt gula pasir"
- "1 sdt kecap manis"
- " Bumbu halus"
- "2 bawang putih"
- "3 bawang merah"
- "1 buah kemiri uk sedang"
- "1 sdt ketumbar bubuk"
- "1 cm kunyit"
- "1 cm jahe"
- "5 cabe rawit"
- "6 cabe merah keriting"
recipeinstructions:
- "Cuci bersih ayam. Siangi daun kemangi dan iris tomat serta daun bawang (maaf bahan ada yg tdk kefoto)"
- "Uleg atau blender semua bumbu halus lalu tumis bersama daun salam, daun jeruk, serai dan lengkuas. Kemudian masukkan tomat masak hingga layu dan beri secukupnya air"
- "Masukkan ayam, tunggu hingga ayam empuk/matang dan air sedikit menyusut (kurleb 20 menit)"
- "Lalu masukkan daun kemangi, masak hingga daun layu dan tercium aroma wangi"
- "Tambahkan irisan daun bawang agar masakan semakin sedap, lalu masak sebentar smbl koreksi rasa. Jika sudah enak ayam kemangi siap untuk disajikan 🙂 selamat mencoba semua."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 119 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica-rica kemangi kuah kuning sederhana](https://img-global.cpcdn.com/recipes/5b1243de74b1b019/751x532cq70/ayam-rica-rica-kemangi-kuah-kuning-sederhana-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang patut kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica-rica kemangi kuah kuning sederhana yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa ciri khas yang merupakan keragaman Nusantara

Keharmonisan rumah tangga bisa diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam rica-rica kemangi kuah kuning sederhana untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.

Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Jadi rica-rica ayam telah menjadi salah satu makanan andalan yang biasanya disajikan dalam berbagai acara.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang dapat anda contoh salah satunya ayam rica-rica kemangi kuah kuning sederhana yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep ayam rica-rica kemangi kuah kuning sederhana tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi kuah kuning sederhana yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 21 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica kemangi kuah kuning sederhana:

1. Siapkan 1/2 kg ayam atau 5 potong ayam (saya pakai paha bawah)
1. Harus ada 1 ikat daun kemangi
1. Harap siapkan 1 batang daun bawang
1. Diperlukan 1 buah tomat
1. Siapkan 2 lembar daun salam
1. Harap siapkan 1 cm lengkuas geprek
1. Tambah 1 batang serai geprek
1. Tambah 2 lembar daun jeruk (buang batang)
1. Harap siapkan 3 sdt kaldu bubuk
1. Harus ada Sejumput garam (sesuai selera)
1. Dibutuhkan 1 sdt gula pasir
1. Dibutuhkan 1 sdt kecap manis
1. Tambah  Bumbu halus:
1. Diperlukan 2 bawang putih
1. Diperlukan 3 bawang merah
1. Dibutuhkan 1 buah kemiri uk sedang
1. Diperlukan 1 sdt ketumbar bubuk
1. Dibutuhkan 1 cm kunyit
1. Harus ada 1 cm jahe
1. Dibutuhkan 5 cabe rawit
1. Harus ada 6 cabe merah keriting


Cara Membuat Ayam Bumbu Kuning Kemangi Berikut adalah cara memasak rica rica ayam bumbu kuning kemangi yang enak. Resep Masak Rica Rica Ayam Kampung Kemangi Pedas. Cara Bikin Bakmoy Ayam Kuah Resep Bakmoy Ayam Udang Gurih Lezat Khas Oriental. Resep rica rica sendiri sebenarnya tidak harus menggunakan bahan daging ayam saja. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica-rica kemangi kuah kuning sederhana:

1. Cuci bersih ayam. Siangi daun kemangi dan iris tomat serta daun bawang (maaf bahan ada yg tdk kefoto)
1. Uleg atau blender semua bumbu halus lalu tumis bersama daun salam, daun jeruk, serai dan lengkuas. Kemudian masukkan tomat masak hingga layu dan beri secukupnya air
1. Masukkan ayam, tunggu hingga ayam empuk/matang dan air sedikit menyusut (kurleb 20 menit)
1. Lalu masukkan daun kemangi, masak hingga daun layu dan tercium aroma wangi
1. Tambahkan irisan daun bawang agar masakan semakin sedap, lalu masak sebentar smbl koreksi rasa. Jika sudah enak ayam kemangi siap untuk disajikan 🙂 selamat mencoba semua.


Cara Bikin Bakmoy Ayam Kuah Resep Bakmoy Ayam Udang Gurih Lezat Khas Oriental. Resep rica rica sendiri sebenarnya tidak harus menggunakan bahan daging ayam saja. Cita rasa pedas menjadi ciri khas resep yang tergabung dalam masakan indonesia yang satu ini. Dengan demikian siapapun dapat mencoba membuat masakan rica rica ala manado ini. Ada resep masakan ayam rica-rica sederhana, resep masakan ayam rica-rica pedas manis, resep masakan ayam rica-rica kemangi, resep masakan ayam rica-rica khas Manado dan lain sebagainya. 

Demikianlah cara membuat ayam rica-rica kemangi kuah kuning sederhana yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan teruji, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
