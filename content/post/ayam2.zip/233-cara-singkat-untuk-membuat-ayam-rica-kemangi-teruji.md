---
description: "Cara singkat untuk membuat Ayam Rica Kemangi Teruji"
title: "Cara singkat untuk membuat Ayam Rica Kemangi Teruji"
slug: 233-cara-singkat-untuk-membuat-ayam-rica-kemangi-teruji
date: 2020-12-07T23:08:48.560Z
image: https://img-global.cpcdn.com/recipes/625f1026f12c3a19/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/625f1026f12c3a19/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/625f1026f12c3a19/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Leroy Pope
ratingvalue: 4.3
reviewcount: 5223
recipeingredient:
- "4 potong Ayam ukuran sedang"
- "1 ikat Daun Kemangi petiki daunnya"
- " BumbuBumbu"
- "5 siung Bawang Merah"
- "3 siung Bawang Putih"
- "10 buah Cabe Merah"
- "10 buah Cabe Rawit Merah"
- "2 lembar Daun Salam"
- "3 lembar Daun Jeruk"
- "1 batang Serai geprek"
- "2 cm Lengkuas geprek"
- "Secukupnya gula  garam"
- "250 ml air"
- " Minyak untuk menumis"
recipeinstructions:
- "Goreng ayam sampai berkulit dan agak kering, sisihkan"
- "Haluskan Duo Bawang, Cabe Merah, &amp; Cabe Rawit merah"
- "Tumis bumbu yang sudah dihaluskan, tambahkan daun salam, daun jeruk, serai, dan lengkuas. Tumis sampai harum"
- "Masukkan ayam, tumis ±3 menit.. Masukkan air, masak sampai bumbu meresap dan air menyusut."
- "Masukkan gula &amp; garam, tes rasa."
- "Masukkan Daun Kemangi, masak sampai daun layu."
- "Angkat dan sajikan."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 140 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/625f1026f12c3a19/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang dapat kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica kemangi yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara



Keharmonisan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam Rica Kemangi untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang dapat anda praktekkan salah satunya ayam rica kemangi yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 14 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Jangan lupa 4 potong Ayam ukuran sedang
1. Harus ada 1 ikat Daun Kemangi, petiki daunnya
1. Tambah  Bumbu-Bumbu
1. Tambah 5 siung Bawang Merah
1. Dibutuhkan 3 siung Bawang Putih
1. Harus ada 10 buah Cabe Merah
1. Tambah 10 buah Cabe Rawit Merah
1. Harap siapkan 2 lembar Daun Salam
1. Siapkan 3 lembar Daun Jeruk
1. Harus ada 1 batang Serai, geprek
1. Harap siapkan 2 cm Lengkuas, geprek
1. Tambah Secukupnya gula &amp; garam
1. Siapkan 250 ml air
1. Jangan lupa  Minyak untuk menumis




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Kemangi:

1. Goreng ayam sampai berkulit dan agak kering, sisihkan
1. Haluskan Duo Bawang, Cabe Merah, &amp; Cabe Rawit merah
1. Tumis bumbu yang sudah dihaluskan, tambahkan daun salam, daun jeruk, serai, dan lengkuas. Tumis sampai harum
1. Masukkan ayam, tumis ±3 menit.. Masukkan air, masak sampai bumbu meresap dan air menyusut.
1. Masukkan gula &amp; garam, tes rasa.
1. Masukkan Daun Kemangi, masak sampai daun layu.
1. Angkat dan sajikan.




Demikianlah cara membuat ayam rica kemangi yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan terbukti, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
