---
description: "Resep : Ayam Rica-Rica Pedas Kemangi Sempurna"
title: "Resep : Ayam Rica-Rica Pedas Kemangi Sempurna"
slug: 296-resep-ayam-rica-rica-pedas-kemangi-sempurna
date: 2021-01-19T09:42:46.508Z
image: https://img-global.cpcdn.com/recipes/5b45acaa7cf722fa/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5b45acaa7cf722fa/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5b45acaa7cf722fa/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
author: Gary Bell
ratingvalue: 4.8
reviewcount: 11872
recipeingredient:
- " Ayam kampung"
- "  Bumbu Halus "
- "8 siung merah"
- "3 siung bawang putih"
- "2 butir kemiri utuh"
- "21 buah cabai tambah bila suka pedas"
- "2 buah cabai merah"
- "1 ruas jari kunyit"
- "1 ruas jari jahe"
- "  Bahan Bahan lain "
- " Daun kemangi"
- "2 Daun jeruk"
- "2 Daun salam"
- "1 batang sereh"
- " Garam"
- " Gula"
- " Lada bubuk"
- " Penyedap rasa"
- " Vitsin"
- "secukupnya Air"
recipeinstructions:
- "Cuci bersih ayam, kemudian rebus ayam dengan campuran garam, ketumbar, kunyit. Setelah empuk tiriskan lalu goreng sebentar (goreng setengah matang)"
- "Blender atau uleg bumbu halus hingga halus."
- "Tumis bumbu halus dengan sedikit minyak hingga bumbu menjadi harum, setelah harum masukan sereh yang digeprek, daun jeruk, dan daun salam tumis hingga harum."
- "Tambahkan garam, gula, penyedap rasa, vitsin lalu tes rasa"
- "Masukan ayam yang digoreng setengah matang tadi ke bumbu lalu aduk hingga merata."
- "Setelah merata beri sedikit air supaya bumbu meresap ke ayam tunggu hingga mendidih"
- "Setelah mendidih masukan kemangi lalu aduk aduk sebentar hingga kemangi layu dan keluar aroma khas kemangi. Lalu matikan kompor"
- "Ayam Rica-Rica Pedas Kemangi siap dinikmati"
categories:
- Recipe
tags:
- ayam
- ricarica
- pedas

katakunci: ayam ricarica pedas 
nutrition: 155 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica-Rica Pedas Kemangi](https://img-global.cpcdn.com/recipes/5b45acaa7cf722fa/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica-rica pedas kemangi yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa ciri khas yang merupakan keragaman Kita

Kedekatan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah memasak Ayam Rica-Rica Pedas Kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi resep yang bisa anda buat salah satunya ayam rica-rica pedas kemangi yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan gampang menemukan resep ayam rica-rica pedas kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica Pedas Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica Pedas Kemangi:

1. Dibutuhkan  Ayam kampung
1. Siapkan  🌞 Bumbu Halus 🌞
1. Dibutuhkan 8 siung merah
1. Harus ada 3 siung bawang putih
1. Jangan lupa 2 butir kemiri utuh
1. Jangan lupa 21 buah cabai (tambah bila suka pedas)
1. Harap siapkan 2 buah cabai merah
1. Tambah 1 ruas jari kunyit
1. Tambah 1 ruas jari jahe
1. Diperlukan  🌞 Bahan- Bahan lain 🌞
1. Jangan lupa  Daun kemangi
1. Diperlukan 2 Daun jeruk
1. Jangan lupa 2 Daun salam
1. Dibutuhkan 1 batang sereh
1. Tambah  Garam
1. Jangan lupa  Gula
1. Jangan lupa  Lada bubuk
1. Harus ada  Penyedap rasa
1. Harus ada  Vitsin
1. Jangan lupa secukupnya Air




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica Pedas Kemangi:

1. Cuci bersih ayam, kemudian rebus ayam dengan campuran garam, ketumbar, kunyit. Setelah empuk tiriskan lalu goreng sebentar (goreng setengah matang)
1. Blender atau uleg bumbu halus hingga halus.
1. Tumis bumbu halus dengan sedikit minyak hingga bumbu menjadi harum, setelah harum masukan sereh yang digeprek, daun jeruk, dan daun salam tumis hingga harum.
1. Tambahkan garam, gula, penyedap rasa, vitsin lalu tes rasa
1. Masukan ayam yang digoreng setengah matang tadi ke bumbu lalu aduk hingga merata.
1. Setelah merata beri sedikit air supaya bumbu meresap ke ayam tunggu hingga mendidih
1. Setelah mendidih masukan kemangi lalu aduk aduk sebentar hingga kemangi layu dan keluar aroma khas kemangi. Lalu matikan kompor
1. Ayam Rica-Rica Pedas Kemangi siap dinikmati




Demikianlah cara membuat ayam rica-rica pedas kemangi yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
