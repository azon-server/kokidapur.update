---
description: "Langkah menyiapakan Ayam Rica Rica Kemangi terupdate"
title: "Langkah menyiapakan Ayam Rica Rica Kemangi terupdate"
slug: 329-langkah-menyiapakan-ayam-rica-rica-kemangi-terupdate
date: 2021-01-23T18:46:52.926Z
image: https://img-global.cpcdn.com/recipes/c872223e1e3739ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c872223e1e3739ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c872223e1e3739ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Leo Lee
ratingvalue: 4
reviewcount: 9871
recipeingredient:
- "1 kg ayam potong 10"
- "2 ikat kemangi"
- "6 buah bawang merah iris2"
- " Kunyit bubuk"
- "5 lembar daun jeruk"
- "1 lembar daun pandan"
- "2 lembar sereh geprek"
- "1 buah jeruk nipis"
- " Kaldu jamur  ayam"
- "secukupnya Garam  gula pasir"
- "secukupnya Air"
- " Minyak untuk menumis"
- " BUMBU HALUS"
- "3 buah bawang putih"
- "4 cm jahe"
- "5 buah cabe rawit merah"
- "10 buah cabe merah besar"
recipeinstructions:
- "Iris tipis bawang merah. Panaskan minyak untuk menumis. Masukan bawang merah dan sereh yg sdh digeprek. Tumis hingga harum."
- "Masukan bumbu halus. Kunyit bubuk secukupnya. Daun jeruk. Daun pandan. Tumis kembali hingga harum."
- "Masukan ayam. Aduk2 hingga merata. Masukan daun kemangi. Lalu tambahkan air, garam, gula, dan kaldu bubuk. (seperti mengungkep ayam). Tutup dengan tutupan panci."
- "Sesekali aduk masakan. Tambahkan air perasan jeruk nipis. Koreksi rasa. Cek kematangan ayam. Matikan kompor jika dirasa ayam sudah matang dan bumbu sudah enak. Selamat mencoba."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 229 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/c872223e1e3739ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita lestarikan karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica rica kemangi yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan ciri khas yang merupakan keragaman Kita



Kedekatan rumah tangga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Rica Rica Kemangi untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda buat salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Tambah 1 kg ayam potong 10
1. Siapkan 2 ikat kemangi
1. Harap siapkan 6 buah bawang merah (iris2)
1. Siapkan  Kunyit bubuk
1. Tambah 5 lembar daun jeruk
1. Harap siapkan 1 lembar daun pandan
1. Jangan lupa 2 lembar sereh (geprek)
1. Harap siapkan 1 buah jeruk nipis
1. Jangan lupa  Kaldu jamur / ayam
1. Diperlukan secukupnya Garam &amp; gula pasir
1. Harus ada secukupnya Air
1. Siapkan  Minyak untuk menumis
1. Tambah  BUMBU HALUS:
1. Dibutuhkan 3 buah bawang putih
1. Tambah 4 cm jahe
1. Harus ada 5 buah cabe rawit merah
1. Harus ada 10 buah cabe merah besar




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica Kemangi:

1. Iris tipis bawang merah. Panaskan minyak untuk menumis. Masukan bawang merah dan sereh yg sdh digeprek. Tumis hingga harum.
1. Masukan bumbu halus. Kunyit bubuk secukupnya. Daun jeruk. Daun pandan. Tumis kembali hingga harum.
1. Masukan ayam. Aduk2 hingga merata. Masukan daun kemangi. Lalu tambahkan air, garam, gula, dan kaldu bubuk. (seperti mengungkep ayam). Tutup dengan tutupan panci.
1. Sesekali aduk masakan. Tambahkan air perasan jeruk nipis. Koreksi rasa. Cek kematangan ayam. Matikan kompor jika dirasa ayam sudah matang dan bumbu sudah enak. Selamat mencoba.




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
