---
description: "Steps untuk menyiapakan Ayam rica pedas kemangi Luar biasa"
title: "Steps untuk menyiapakan Ayam rica pedas kemangi Luar biasa"
slug: 287-steps-untuk-menyiapakan-ayam-rica-pedas-kemangi-luar-biasa
date: 2020-09-11T15:16:17.343Z
image: https://img-global.cpcdn.com/recipes/55752acf7ba7c83a/751x532cq70/ayam-rica-pedas-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/55752acf7ba7c83a/751x532cq70/ayam-rica-pedas-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/55752acf7ba7c83a/751x532cq70/ayam-rica-pedas-kemangi-foto-resep-utama.jpg
author: Andre Harrington
ratingvalue: 4.8
reviewcount: 41088
recipeingredient:
- "1 kg ayam"
- "2 ikat daun kemangi"
- "1 buah jeruk nipis"
- "1 bungkus bumbu ungkep instant saya pakai bumbu racik indofood"
- "1 ruas lengkuas geprek"
- "1 batang serai geprek"
- "1 lembar daun salam"
- " Garam"
- " Gula pasir"
- " Penyedap rasa"
- " Bumbu halus "
- "7 siung bawang merah"
- "5 siung bawang putih"
- "3 buah cabe merah buang bijinya"
- "6 buah cabe rawit sesuai selera"
- "3 buah kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
recipeinstructions:
- "Cuci bersih ayam. Setelah itu lumuri dengan perasan jeruk nipis. Diamkan selama 15 menit. Kemudian cuci kembali dengan air bersih. Lumuri dengan bumbu ungkep. Ungkep ayam dengan api kecil"
- "Siapkan bumbu halus,uleg atw blender bumbu"
- "Tumis bumbu yang telah dihaluskan sampai matang kemudian masukan daun salam, serai, dan lengkuas yang sudah digeprek. Tambahkan 1 gelas air. Kemudian masukan ayamnya"
- "Aduk ayam. Tambahkan gula, garam, dan penyedap rasa. Terakhir masukan kemangi. Kemudian koreksi rasa."
- "Masak hingga air menyusut dan matang,sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- pedas

katakunci: ayam rica pedas 
nutrition: 161 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica pedas kemangi](https://img-global.cpcdn.com/recipes/55752acf7ba7c83a/751x532cq70/ayam-rica-pedas-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga gurih. Ciri kuliner Indonesia ayam rica pedas kemangi yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Ayam rica pedas kemangi untuk keluarga. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang bisa anda coba salah satunya ayam rica pedas kemangi yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica pedas kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica pedas kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica pedas kemangi:

1. Harap siapkan 1 kg ayam
1. Jangan lupa 2 ikat daun kemangi
1. Jangan lupa 1 buah jeruk nipis
1. Jangan lupa 1 bungkus bumbu ungkep instant (saya pakai bumbu racik indofood
1. Harus ada 1 ruas lengkuas geprek
1. Jangan lupa 1 batang serai geprek
1. Harus ada 1 lembar daun salam
1. Jangan lupa  Garam
1. Diperlukan  Gula pasir
1. Tambah  Penyedap rasa
1. Harap siapkan  Bumbu halus :
1. Siapkan 7 siung bawang merah
1. Dibutuhkan 5 siung bawang putih
1. Harus ada 3 buah cabe merah buang bijinya
1. Tambah 6 buah cabe rawit (sesuai selera)
1. Harus ada 3 buah kemiri
1. Harap siapkan 1 ruas jahe
1. Harap siapkan 1 ruas kunyit




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica pedas kemangi:

1. Cuci bersih ayam. Setelah itu lumuri dengan perasan jeruk nipis. Diamkan selama 15 menit. Kemudian cuci kembali dengan air bersih. - Lumuri dengan bumbu ungkep. Ungkep ayam dengan api kecil
1. Siapkan bumbu halus,uleg atw blender bumbu
1. Tumis bumbu yang telah dihaluskan sampai matang kemudian masukan daun salam, serai, dan lengkuas yang sudah digeprek. Tambahkan 1 gelas air. Kemudian masukan ayamnya
1. Aduk ayam. Tambahkan gula, garam, dan penyedap rasa. Terakhir masukan kemangi. Kemudian koreksi rasa.
1. Masak hingga air menyusut dan matang,sajikan




Demikianlah cara membuat ayam rica pedas kemangi yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
