---
description: "Resep : Ayam rica-rica daun kemangi teraktual"
title: "Resep : Ayam rica-rica daun kemangi teraktual"
slug: 173-resep-ayam-rica-rica-daun-kemangi-teraktual
date: 2020-09-08T04:34:32.992Z
image: https://img-global.cpcdn.com/recipes/8295ee86d391737a/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8295ee86d391737a/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8295ee86d391737a/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Juan Moreno
ratingvalue: 4
reviewcount: 23241
recipeingredient:
- "1/2 ekor ayam boiler"
- "1 bh jeruk nipis"
- "3 ikat kemangi"
- "1 btg serai geprek"
- "seruas lengkuas geprek"
- "7 lbr daun jeruk"
- "1 btg daun bawang"
- "Secukupnya air"
- " Garam kaldu jamur"
- "1 sdm gula merah disisir"
- " Bumbu halus "
- "6 bh bamer"
- "2 siung baput"
- "8 bh cabe merah"
- "20 bh cabe rawit selera"
- "2 btr kemiri"
- "Sejempol jahe  kunyit"
recipeinstructions:
- "Cuci bersih ayam, beri perasan jeruk nipis diamkan 1 jam -/+."
- "Goreng cabe merah, rawit, baput, bamer, hingga layu. Lalu blender halus bersama bumbu lainnya."
- "Beri minyak aga banyak, -/+ 5 sdm.. panaskan. Masukan bumbu halus. Lanjut masukan serai, lengkuas, daun jeruk. Tumis hingga wangi. Lalu masukan gula merah. Aduk hingga tercampur."
- "Beri sedikit air -/+ stengah gelas kecil. Lalu masukan garam &amp; kaldu. Cek rasa. Masukan ayam. Masak hingga matang. Balik sisi ya klo airnya g rata dgn ayamnya. Menit akhir stelah ayam sdh matang. Masukan daun bawang &amp; kemangi. Sajikan."
categories:
- Recipe
tags:
- ayam
- ricarica
- daun

katakunci: ayam ricarica daun 
nutrition: 254 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica-rica daun kemangi](https://img-global.cpcdn.com/recipes/8295ee86d391737a/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau enak. Ciri khas kuliner Nusantara ayam rica-rica daun kemangi yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga bisa didapat dengan cara simple. Salah satunya adalah memasak Ayam rica-rica daun kemangi untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.

Olahan ayam dengan santan yang banyak digemari. selamat mencoba teman- teman . Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang bisa anda coba salah satunya ayam rica-rica daun kemangi yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica-rica daun kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica daun kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica daun kemangi:

1. Tambah 1/2 ekor ayam boiler
1. Harus ada 1 bh jeruk nipis
1. Harus ada 3 ikat kemangi
1. Diperlukan 1 btg serai (geprek)
1. Diperlukan seruas lengkuas (geprek)
1. Siapkan 7 lbr daun jeruk
1. Jangan lupa 1 btg daun bawang
1. Diperlukan Secukupnya air
1. Jangan lupa  Garam, kaldu jamur
1. Diperlukan 1 sdm gula merah (disisir)
1. Harap siapkan  Bumbu halus :
1. Harap siapkan 6 bh bamer
1. Harap siapkan 2 siung baput
1. Harus ada 8 bh cabe merah
1. Dibutuhkan 20 bh cabe rawit *selera
1. Diperlukan 2 btr kemiri
1. Tambah Sejempol jahe &amp; kunyit


Tambahkan irisan daun kemangi lalu aduk sampai hingga merata dan angkat. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. Krecek Kulit Sapi Kacang Tunggak Fieldpeas Dan Peyeknya. Oseng Nanas Muda Sambel Nanas Ikan Lele. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica-rica daun kemangi:

1. Cuci bersih ayam, beri perasan jeruk nipis diamkan 1 jam -/+.
1. Goreng cabe merah, rawit, baput, bamer, hingga layu. Lalu blender halus bersama bumbu lainnya.
1. Beri minyak aga banyak, -/+ 5 sdm.. panaskan. Masukan bumbu halus. Lanjut masukan serai, lengkuas, daun jeruk. Tumis hingga wangi. Lalu masukan gula merah. Aduk hingga tercampur.
1. Beri sedikit air -/+ stengah gelas kecil. Lalu masukan garam &amp; kaldu. Cek rasa. Masukan ayam. Masak hingga matang. Balik sisi ya klo airnya g rata dgn ayamnya. Menit akhir stelah ayam sdh matang. Masukan daun bawang &amp; kemangi. Sajikan.


Krecek Kulit Sapi Kacang Tunggak Fieldpeas Dan Peyeknya. Oseng Nanas Muda Sambel Nanas Ikan Lele. Sintrong Tumis Tauco Sup Kacang Jubleg Ayam. Daun Kencur Di Oseng Di Pecel Dan Goreng Obang Abing. Acar Belimbing Wuluh Dan Ikan Nilem. 

Demikianlah cara membuat ayam rica-rica daun kemangi yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
