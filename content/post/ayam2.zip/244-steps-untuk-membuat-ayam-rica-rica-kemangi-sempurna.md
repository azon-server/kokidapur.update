---
description: "Steps untuk membuat Ayam Rica-rica Kemangi Sempurna"
title: "Steps untuk membuat Ayam Rica-rica Kemangi Sempurna"
slug: 244-steps-untuk-membuat-ayam-rica-rica-kemangi-sempurna
date: 2020-09-02T14:15:00.198Z
image: https://img-global.cpcdn.com/recipes/5959d0d19589c0a2/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5959d0d19589c0a2/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5959d0d19589c0a2/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Edith Little
ratingvalue: 4.6
reviewcount: 44828
recipeingredient:
- "1 ekor ayam potong sesuai selera"
- "1 ikat daun kemangi"
- "3 lembar daun jeruk"
- "3 lembar daun salam"
- "1 ruas jahe geprek"
- "1 ruas lengkuas geprek"
- "1 batang serai geprek"
- "secukupnya Garam merica gula dan kaldu"
- " Bumbu Halus "
- "1 ruas kunyit"
- "6 butir bawang merah"
- "3 siung bawang putih"
- "2 butir kemiri"
- "10 buah cabe rawit sesuai selera"
- " Cabe keriting sesuai selera"
recipeinstructions:
- "Cuci bersih ayam, tambahkan air perasan jeruk nipis sedikit, diamkan sktr 15 menit agar tidak bau amis. Cuci bersih lagi."
- "Rebus ayam sebentar untuk menghilangkan kotoran dan ayam cepat empuk ketika dimasak. Tiriskan."
- "Panaskan sedikit minyak, tumis bumbu halus hingga harum. Tambahkan jahe, lengkuas, serai yg sudah digeprek dan daun salam."
- "Masukkan ayam, tambahkan garam, gula, merica dan kaldu. Aduk rata. Tambahkan sedikit air. Aduk rata."
- "Jika ayam sudah empuk dan air menyusut tambahkan daun kemangi. Aduk sebentar. Sajikan."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 257 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/5959d0d19589c0a2/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang patut kita jaga karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa ciri khas yang merupakan keragaman Kita



Kehangatan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah memasak Ayam Rica-rica Kemangi untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang dapat anda coba salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya saat ini kamu bisa dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica Kemangi:

1. Jangan lupa 1 ekor ayam, potong sesuai selera
1. Harus ada 1 ikat daun kemangi
1. Jangan lupa 3 lembar daun jeruk
1. Jangan lupa 3 lembar daun salam
1. Harus ada 1 ruas jahe, geprek
1. Harap siapkan 1 ruas lengkuas, geprek
1. Tambah 1 batang serai, geprek
1. Jangan lupa secukupnya Garam, merica, gula dan kaldu
1. Harus ada  Bumbu Halus :
1. Jangan lupa 1 ruas kunyit
1. Dibutuhkan 6 butir bawang merah
1. Tambah 3 siung bawang putih
1. Dibutuhkan 2 butir kemiri
1. Diperlukan 10 buah cabe rawit (sesuai selera)
1. Siapkan  Cabe keriting (sesuai selera)




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-rica Kemangi:

1. Cuci bersih ayam, tambahkan air perasan jeruk nipis sedikit, diamkan sktr 15 menit agar tidak bau amis. Cuci bersih lagi.
1. Rebus ayam sebentar untuk menghilangkan kotoran dan ayam cepat empuk ketika dimasak. Tiriskan.
1. Panaskan sedikit minyak, tumis bumbu halus hingga harum. Tambahkan jahe, lengkuas, serai yg sudah digeprek dan daun salam.
1. Masukkan ayam, tambahkan garam, gula, merica dan kaldu. Aduk rata. Tambahkan sedikit air. Aduk rata.
1. Jika ayam sudah empuk dan air menyusut tambahkan daun kemangi. Aduk sebentar. Sajikan.




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
