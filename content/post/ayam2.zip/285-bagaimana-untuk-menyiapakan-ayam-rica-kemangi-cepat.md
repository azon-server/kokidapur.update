---
description: "Bagaimana untuk menyiapakan Ayam Rica Kemangi Cepat"
title: "Bagaimana untuk menyiapakan Ayam Rica Kemangi Cepat"
slug: 285-bagaimana-untuk-menyiapakan-ayam-rica-kemangi-cepat
date: 2020-12-28T13:44:17.942Z
image: https://img-global.cpcdn.com/recipes/83c64ef213f77272/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/83c64ef213f77272/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/83c64ef213f77272/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Ella Richardson
ratingvalue: 4.6
reviewcount: 43635
recipeingredient:
- "1 Ekor Ayam di potongpotong jadi 12"
- "1 batang serai geprek"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 ruas jahe geprek"
- "1 ruas lengkuas"
- "1 ikat daun kemangi petik daunnya saja"
- "1 bh jeruk nipis"
- "1 sdt garam"
- "1 sdm gula pasir"
- "5 sdm minyak goreng"
- "500 ml Air"
- " Bumbu Halus "
- "1 ruas kunyit"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "3 butir kemiri"
- "15 bh cabe rawit sesuaikan saja pedasnya"
- "5 bh cabe merah keriting"
recipeinstructions:
- "Cuci bersih potongan ayam, lumuri air jeruk nipis, rebus ayam sekitar 20 menit, tujuannya untuk menghilangkan kotoran yang menempel. lalu tambahkan jahe geprek, serai, daun salam dan daun jeruk, supaya menghilangkan bau pada ayam. Angkat dan tiriskan."
- "Panaskan minyak goreng, tumis bumbu halus hingga harum. Masukkan garam, gula pasir, kaldu bubuk, koreksi rasa."
- "Masukkan potongan ayamnya, aduk hingga tercampur rata dengan bumbu, diamkan hingga bumbu meresap, lalu tambahkan air, aduk lagi semua bahan"
- "Kemudian masukkan daun kemangi, aduk sebentar hingga rata, lalu sajikan."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 278 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT43M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/83c64ef213f77272/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang dapat kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica kemangi yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan ciri khas yang merupakan keragaman Kita



Kedekatan rumah tangga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica Kemangi untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang dapat anda praktekkan salah satunya ayam rica kemangi yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Diperlukan 1 Ekor Ayam (di potong-potong jadi 12)
1. Diperlukan 1 batang serai geprek
1. Dibutuhkan 2 lembar daun salam
1. Diperlukan 2 lembar daun jeruk
1. Harap siapkan 1 ruas jahe geprek
1. Harap siapkan 1 ruas lengkuas
1. Diperlukan 1 ikat daun kemangi petik daunnya saja
1. Dibutuhkan 1 bh jeruk nipis
1. Diperlukan 1 sdt garam
1. Tambah 1 sdm gula pasir
1. Harap siapkan 5 sdm minyak goreng
1. Dibutuhkan 500 ml Air
1. Tambah  Bumbu Halus :
1. Dibutuhkan 1 ruas kunyit
1. Harap siapkan 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Tambah 3 butir kemiri
1. Jangan lupa 15 bh cabe rawit (sesuaikan saja pedasnya)
1. Siapkan 5 bh cabe merah keriting




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Kemangi:

1. Cuci bersih potongan ayam, lumuri air jeruk nipis, rebus ayam sekitar 20 menit, tujuannya untuk menghilangkan kotoran yang menempel. lalu tambahkan jahe geprek, serai, daun salam dan daun jeruk, supaya menghilangkan bau pada ayam. Angkat dan tiriskan.
1. Panaskan minyak goreng, tumis bumbu halus hingga harum. Masukkan garam, gula pasir, kaldu bubuk, koreksi rasa.
1. Masukkan potongan ayamnya, aduk hingga tercampur rata dengan bumbu, diamkan hingga bumbu meresap, lalu tambahkan air, aduk lagi semua bahan
1. Kemudian masukkan daun kemangi, aduk sebentar hingga rata, lalu sajikan.




Demikianlah cara membuat ayam rica kemangi yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan terbukti, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
