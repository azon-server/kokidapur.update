---
description: "Cara singkat membuat Ketupat Sayur Betawi Komplit Favorite"
title: "Cara singkat membuat Ketupat Sayur Betawi Komplit Favorite"
slug: 477-cara-singkat-membuat-ketupat-sayur-betawi-komplit-favorite
date: 2020-09-13T09:57:34.067Z
image: https://img-global.cpcdn.com/recipes/6731270698dbbf97/751x532cq70/ketupat-sayur-betawi-komplit-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6731270698dbbf97/751x532cq70/ketupat-sayur-betawi-komplit-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6731270698dbbf97/751x532cq70/ketupat-sayur-betawi-komplit-foto-resep-utama.jpg
author: Dennis Mullins
ratingvalue: 4.6
reviewcount: 39651
recipeingredient:
- " Bahan Sayur Godog Pepaya Muda "
- "1 buah pepaya muda Serut bersihkan"
- "3 batang kacang panjang potongpotong sesuai selera"
- "1500 ml santan sedang"
- "250 ml santan kental"
- "1 batang sereh geprek"
- "2 lembar daun salam"
- "2 cm lengkuas geprek"
- "1 sdm gula merah sisir"
- "1 sdm garam"
- "1 sdm gula pasir"
- "1/2 sdm kaldu bubuk"
- "2 sdm minyak goreng"
- " Bumbu yang dihaluskan"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "5 buah cabe merah"
- "3 butir kemiri"
- "1 sdm ebi kering"
- " Bahan pelengkap "
- " Ketupat resep 231 atau mau pakai lontong Magic com resep 71"
- " Opor ayam resep 232"
- " Semur tahu dan telur resep 233"
- " Sambal goreng saya pakai sambal kuah di resep 235"
- " Bawang goreng renyah ada di daftar resep"
- " Emping melinjo gurih resep ke 236"
recipeinstructions:
- "Panaskan sedikit minyak, tumis bumbu halus beserta daun salam, sereh dan lengkuas. Masak hingga wangi."
- "Masukan pepaya muda dan kacang panjang. Tuang santan sedang. Masak hingga setengah matang."
- "Masukan santan kental, beri garam, gula pasir, kaldu bubuk dan gula merah. Masak hingga matang."
- "Siapkan wadah berisi potongan ketupat, siram sayur godog pepaya muda, tambahkan semur tahu dan telur beserta sedikit kuah. Tambahkan potongan opor ayam. Taburkan bawang goreng. Sajikan dengan sambal kuah dan emping melinjo goreng."
categories:
- Recipe
tags:
- ketupat
- sayur
- betawi

katakunci: ketupat sayur betawi 
nutrition: 109 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Dessert

---


![Ketupat Sayur Betawi Komplit](https://img-global.cpcdn.com/recipes/6731270698dbbf97/751x532cq70/ketupat-sayur-betawi-komplit-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ketupat sayur betawi komplit yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Kita



Keharmonisan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah memasak Ketupat Sayur Betawi Komplit untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang bisa anda buat salah satunya ketupat sayur betawi komplit yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep ketupat sayur betawi komplit tanpa harus bersusah payah.
Seperti resep Ketupat Sayur Betawi Komplit yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 26 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ketupat Sayur Betawi Komplit:

1. Harap siapkan  Bahan Sayur Godog (Pepaya Muda) :
1. Diperlukan 1 buah pepaya muda. Serut, bersihkan
1. Harap siapkan 3 batang kacang panjang, potong-potong sesuai selera
1. Siapkan 1500 ml santan sedang
1. Jangan lupa 250 ml santan kental
1. Siapkan 1 batang sereh, geprek
1. Harap siapkan 2 lembar daun salam
1. Siapkan 2 cm lengkuas, geprek
1. Dibutuhkan 1 sdm gula merah sisir
1. Harap siapkan 1 sdm garam
1. Siapkan 1 sdm gula pasir
1. Harus ada 1/2 sdm kaldu bubuk
1. Jangan lupa 2 sdm minyak goreng
1. Dibutuhkan  Bumbu yang dihaluskan:
1. Harap siapkan 6 siung bawang merah
1. Jangan lupa 4 siung bawang putih
1. Jangan lupa 5 buah cabe merah
1. Siapkan 3 butir kemiri
1. Tambah 1 sdm ebi kering
1. Dibutuhkan  Bahan pelengkap :
1. Diperlukan  Ketupat (resep 231) atau mau pakai lontong Magic com (resep 71)
1. Siapkan  Opor ayam (resep 232)
1. Harap siapkan  Semur tahu dan telur (resep 233)
1. Tambah  Sambal goreng (saya pakai sambal kuah di resep 235)
1. Siapkan  Bawang goreng renyah (ada di daftar resep)
1. Siapkan  Emping melinjo gurih (resep ke 236)




<!--inarticleads2-->

##### Cara membuat  Ketupat Sayur Betawi Komplit:

1. Panaskan sedikit minyak, tumis bumbu halus beserta daun salam, sereh dan lengkuas. Masak hingga wangi.
1. Masukan pepaya muda dan kacang panjang. Tuang santan sedang. Masak hingga setengah matang.
1. Masukan santan kental, beri garam, gula pasir, kaldu bubuk dan gula merah. Masak hingga matang.
1. Siapkan wadah berisi potongan ketupat, siram sayur godog pepaya muda, tambahkan semur tahu dan telur beserta sedikit kuah. Tambahkan potongan opor ayam. Taburkan bawang goreng. Sajikan dengan sambal kuah dan emping melinjo goreng.




Demikianlah cara membuat ketupat sayur betawi komplit yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
