---
description: "Resep : Ayam Rica Kemangi Cepat"
title: "Resep : Ayam Rica Kemangi Cepat"
slug: 283-resep-ayam-rica-kemangi-cepat
date: 2020-10-24T03:51:45.345Z
image: https://img-global.cpcdn.com/recipes/b71928ab1ceb509f/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b71928ab1ceb509f/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b71928ab1ceb509f/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Dale Thornton
ratingvalue: 4.1
reviewcount: 3844
recipeingredient:
- "500 gr Ayam beri perasan jeruk nipis dan garam lalu diamkan beberapa menit"
- "4 lembar daun jeruk"
- "2 lembar daun salam"
- "1 batang serai memarkan"
- "1 jempol lengkuas memarkan"
- "1/2 genggam kemangi"
- " Gula secukupnya"
- " Garam secukupnya"
- " Daun bawang saya skip"
- " Bumbu Halus"
- "5 buah bawang merah"
- "5 buah bawang putig"
- "2 cm jahe"
- "3 cm Kunyit"
- "2 butir Kemiri"
- "10 cabe rawit merah"
- "5 cabe merah besar"
- "1/2 sdt merica"
recipeinstructions:
- "Bersihkan ayam terlebih dahulu"
- "Haluskan bumbu"
- "Tumis bumbu yang sudah dihaluskan dengan sedikit minyak, masukkan daun jeruk, daun salam, serai, lengkuas."
- "Tumis hingga bumbu berubah warna, benar benar matang dan wangi"
- "Masukkan garam, gula, merica aduk sebentar"
- "Kemudian masukkan ayam aduk rata sampai berubah warna."
- "Kemudian tambahkan sedikit air untuk meresapkannya. Tutup"
- "Masak dengan api kecil sampai bumbu benar-benar meresap dan daging ayam pun empuk matang."
- "Terakhir setelah air menyusut dan bumbu sudah meresap, Masukkan daun kemangi. Aduk sebentar"
- "Matikan api, angkat dan sajikan 🥰"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 233 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/b71928ab1ceb509f/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan empuk. Ciri masakan Indonesia ayam rica kemangi yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kedekatan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam Rica Kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang dapat anda contoh salah satunya ayam rica kemangi yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Tambah 500 gr Ayam (beri perasan jeruk nipis dan garam lalu diamkan beberapa menit)
1. Tambah 4 lembar daun jeruk
1. Diperlukan 2 lembar daun salam
1. Diperlukan 1 batang serai (memarkan)
1. Dibutuhkan 1 jempol lengkuas (memarkan)
1. Tambah 1/2 genggam kemangi
1. Harap siapkan  Gula (secukupnya)
1. Jangan lupa  Garam (secukupnya)
1. Tambah  Daun bawang (saya skip)
1. Harus ada  Bumbu Halus
1. Tambah 5 buah bawang merah
1. Harus ada 5 buah bawang putig
1. Jangan lupa 2 cm jahe
1. Harus ada 3 cm Kunyit
1. Dibutuhkan 2 butir Kemiri
1. Siapkan 10 cabe rawit merah
1. Tambah 5 cabe merah besar
1. Diperlukan 1/2 sdt merica




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Kemangi:

1. Bersihkan ayam terlebih dahulu
1. Haluskan bumbu
1. Tumis bumbu yang sudah dihaluskan dengan sedikit minyak, masukkan daun jeruk, daun salam, serai, lengkuas.
1. Tumis hingga bumbu berubah warna, benar benar matang dan wangi
1. Masukkan garam, gula, merica aduk sebentar
1. Kemudian masukkan ayam aduk rata sampai berubah warna.
1. Kemudian tambahkan sedikit air untuk meresapkannya. Tutup
1. Masak dengan api kecil sampai bumbu benar-benar meresap dan daging ayam pun empuk matang.
1. Terakhir setelah air menyusut dan bumbu sudah meresap, Masukkan daun kemangi. Aduk sebentar
1. Matikan api, angkat dan sajikan 🥰




Demikianlah cara membuat ayam rica kemangi yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
