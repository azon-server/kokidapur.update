---
description: "Steps menyiapakan Ayam Rica-Rica Daun Kemangi terupdate"
title: "Steps menyiapakan Ayam Rica-Rica Daun Kemangi terupdate"
slug: 356-steps-menyiapakan-ayam-rica-rica-daun-kemangi-terupdate
date: 2021-01-25T05:53:00.659Z
image: https://img-global.cpcdn.com/recipes/84a8428c26f18d67/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/84a8428c26f18d67/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/84a8428c26f18d67/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Randy Riley
ratingvalue: 4.1
reviewcount: 42649
recipeingredient:
- "1 kg dada ayam potong sesuai selera"
- "2 lbr daun jeruk"
- "2 lbr daun salam"
- "1 batang sereh"
- "1 ruas lengkuas"
- "1 ruas jahe"
- " Daun kemangi sesuai selera"
- "secukupnya Gula dan garam"
- "1 gelas air"
- " Bahan Halus"
- "7 siung bawang merah"
- "4 siung bawang putih"
- "5 buah cabai rawit option"
- "15 buah cabai merah"
- "2 buah kemiri"
- "1 sdm ketumbar bubuk"
- "1 ruas kunyit"
recipeinstructions:
- "Haluskan bumbu halus, tumis bersama daun jeruk, daun salam, sereh, jahe, dan lengkuas"
- "Setelah bumbu harum, masukan 1 gelas air, tambahkan gula dan garam secukupnya dan aduk hingga rata"
- "Setelah bumbu merata masukan ayam yang telah di cuci bersih dan tunggu hingga setengah matang"
- "Masukan daun kemangi dan tunggu hingga air menyusut"
- "Jika bumbu mengental namun ayam dirasa belum matang tambahkan air dan masak hingga air menyusut dan bumbu mengental"
categories:
- Recipe
tags:
- ayam
- ricarica
- daun

katakunci: ayam ricarica daun 
nutrition: 205 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica-Rica Daun Kemangi](https://img-global.cpcdn.com/recipes/84a8428c26f18d67/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang dapat kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica-rica daun kemangi yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan ciri khas yang merupakan keragaman Indonesia



Kehangatan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam Rica-Rica Daun Kemangi untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang dapat anda coba salah satunya ayam rica-rica daun kemangi yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica-rica daun kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Daun Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Daun Kemangi:

1. Harus ada 1 kg dada ayam potong sesuai selera
1. Jangan lupa 2 lbr daun jeruk
1. Tambah 2 lbr daun salam
1. Jangan lupa 1 batang sereh
1. Harap siapkan 1 ruas lengkuas
1. Tambah 1 ruas jahe
1. Harus ada  Daun kemangi (sesuai selera)
1. Jangan lupa secukupnya Gula dan garam
1. Harus ada 1 gelas air
1. Siapkan  Bahan Halus
1. Diperlukan 7 siung bawang merah
1. Harap siapkan 4 siung bawang putih
1. Tambah 5 buah cabai rawit (option)
1. Jangan lupa 15 buah cabai merah
1. Diperlukan 2 buah kemiri
1. Siapkan 1 sdm ketumbar bubuk
1. Harap siapkan 1 ruas kunyit




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica Daun Kemangi:

1. Haluskan bumbu halus, tumis bersama daun jeruk, daun salam, sereh, jahe, dan lengkuas
1. Setelah bumbu harum, masukan 1 gelas air, tambahkan gula dan garam secukupnya dan aduk hingga rata
1. Setelah bumbu merata masukan ayam yang telah di cuci bersih dan tunggu hingga setengah matang
1. Masukan daun kemangi dan tunggu hingga air menyusut
1. Jika bumbu mengental namun ayam dirasa belum matang tambahkan air dan masak hingga air menyusut dan bumbu mengental




Demikianlah cara membuat ayam rica-rica daun kemangi yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
