---
description: "Resep : Ayam Rica kemangi jebret Teruji"
title: "Resep : Ayam Rica kemangi jebret Teruji"
slug: 334-resep-ayam-rica-kemangi-jebret-teruji
date: 2020-09-20T14:59:11.642Z
image: https://img-global.cpcdn.com/recipes/5fc778eb5caaebd3/751x532cq70/ayam-rica-kemangi-jebret-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5fc778eb5caaebd3/751x532cq70/ayam-rica-kemangi-jebret-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5fc778eb5caaebd3/751x532cq70/ayam-rica-kemangi-jebret-foto-resep-utama.jpg
author: Roy Copeland
ratingvalue: 4.8
reviewcount: 33569
recipeingredient:
- "1/2 kg ayam"
- "7 butir bawang merah"
- "5 butir bawang putih"
- "1/4 Cabe setan"
- "2 butir cabe merah"
- "10 butir cabe rawit"
- "3 ruas jari Kunyit"
- "2 ruas jari Jahe"
- "2 ruas jari Lengkuas"
- "1 batang sereh"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- " Daun kemangi"
recipeinstructions:
- "Rebus ayam terlebih dahulu biar empuk daging dan tulang nya"
- "Sambil menunggu ayam direbus, haluskan bawang merah, b putih, cabe, kunyit, jahe, lengkuas"
- "Tumis bumbu yg sudah dihaluskan lalu masukan daun salam, daun jeruk dan sereh yg sudah di geprek"
- "Setelah bumbu sudah harum masukan ayam yang sudah direbus tambahkan air sedikit. Beri garam, mecin atau masako dan gula pasir secukupnya."
- "Masak hingga air berkurang dan mengental..lalu masukan daun kemangi. Cek rasa lalu sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 243 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica kemangi jebret](https://img-global.cpcdn.com/recipes/5fc778eb5caaebd3/751x532cq70/ayam-rica-kemangi-jebret-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang harus kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica kemangi jebret yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Indonesia



Keharmonisan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica kemangi jebret untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis makanan yang dapat anda praktekkan salah satunya ayam rica kemangi jebret yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep ayam rica kemangi jebret tanpa harus bersusah payah.
Berikut ini resep Ayam Rica kemangi jebret yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica kemangi jebret:

1. Siapkan 1/2 kg ayam
1. Harap siapkan 7 butir bawang merah
1. Dibutuhkan 5 butir bawang putih
1. Siapkan 1/4 Cabe setan
1. Tambah 2 butir cabe merah
1. Harus ada 10 butir cabe rawit
1. Diperlukan 3 ruas jari Kunyit
1. Diperlukan 2 ruas jari Jahe
1. Tambah 2 ruas jari Lengkuas
1. Dibutuhkan 1 batang sereh
1. Harap siapkan 2 lembar daun salam
1. Tambah 2 lembar daun jeruk
1. Jangan lupa  Daun kemangi




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica kemangi jebret:

1. Rebus ayam terlebih dahulu biar empuk daging dan tulang nya
1. Sambil menunggu ayam direbus, haluskan bawang merah, b putih, cabe, kunyit, jahe, lengkuas
1. Tumis bumbu yg sudah dihaluskan lalu masukan daun salam, daun jeruk dan sereh yg sudah di geprek
1. Setelah bumbu sudah harum masukan ayam yang sudah direbus tambahkan air sedikit. Beri garam, mecin atau masako dan gula pasir secukupnya.
1. Masak hingga air berkurang dan mengental..lalu masukan daun kemangi. Cek rasa lalu sajikan




Demikianlah cara membuat ayam rica kemangi jebret yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan cepat, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
