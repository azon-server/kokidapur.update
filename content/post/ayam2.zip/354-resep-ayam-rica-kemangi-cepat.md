---
description: "Resep : Ayam Rica Kemangi Cepat"
title: "Resep : Ayam Rica Kemangi Cepat"
slug: 354-resep-ayam-rica-kemangi-cepat
date: 2021-01-07T09:20:53.409Z
image: https://img-global.cpcdn.com/recipes/dc728c9e215e75ca/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dc728c9e215e75ca/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dc728c9e215e75ca/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Jeanette Ellis
ratingvalue: 4.3
reviewcount: 25990
recipeingredient:
- "1/2 ekor ayam kampung potong kecilkecil"
- "1/2 buah jeruk nipis"
- "1 genggam kemangi"
- "2 cm lengkuas geprek"
- "2 lembar daun jeruk"
- "1 batang serai"
- "1 sdt gula merah"
- "1 sdt garam"
- "Secukupnya air asal ayam terendam"
- " Bumbu yang dihaluskan "
- "8 buah cabe merah keriting"
- "2 buah cabe rawit"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "1 buah tomat"
recipeinstructions:
- "Siapkan bahan-bahannya. Kucuri ayam dengan jeruk nipis. Diamkan sebentar lalu cuci bersih."
- "Haluskan bumbunya. Setelah itu siapkan wajan, tumis bumbu dengan sedikit minyak sampai harum. Tambahkan serai, daun jeruk, dan lengkuas."
- "Masukkan ayam, masak sampai berubah warna."
- "Tambahkan sebagian daun kemangi. Aduk sampai rata."
- "Tambahkan air, sampai ayam terendam semua dan bumbui. Masak sampai kuah menyusut."
- "Setelah menyusut tambahkan sisa daun kemangi. Aduk kembali sampai rata. Matikan api dan sajikan."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 131 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/dc728c9e215e75ca/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang patut kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica kemangi yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan ciri khas yang merupakan keragaman Nusantara

Kedekatan rumah tangga dapat ditemukan dengan cara mudah. Salah satunya adalah memasak Ayam Rica Kemangi untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang dapat anda praktekkan salah satunya ayam rica kemangi yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Harus ada 1/2 ekor ayam kampung potong kecil-kecil
1. Siapkan 1/2 buah jeruk nipis
1. Dibutuhkan 1 genggam kemangi
1. Dibutuhkan 2 cm lengkuas geprek
1. Harap siapkan 2 lembar daun jeruk
1. Dibutuhkan 1 batang serai
1. Harap siapkan 1 sdt gula merah
1. Siapkan 1 sdt garam
1. Siapkan Secukupnya air (asal ayam terendam)
1. Dibutuhkan  Bumbu yang dihaluskan :
1. Harus ada 8 buah cabe merah keriting
1. Harap siapkan 2 buah cabe rawit
1. Jangan lupa 6 siung bawang merah
1. Tambah 4 siung bawang putih
1. Tambah 1 buah tomat




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Kemangi:

1. Siapkan bahan-bahannya. Kucuri ayam dengan jeruk nipis. Diamkan sebentar lalu cuci bersih.
1. Haluskan bumbunya. Setelah itu siapkan wajan, tumis bumbu dengan sedikit minyak sampai harum. Tambahkan serai, daun jeruk, dan lengkuas.
1. Masukkan ayam, masak sampai berubah warna.
1. Tambahkan sebagian daun kemangi. Aduk sampai rata.
1. Tambahkan air, sampai ayam terendam semua dan bumbui. Masak sampai kuah menyusut.
1. Setelah menyusut tambahkan sisa daun kemangi. Aduk kembali sampai rata. Matikan api dan sajikan.




Demikianlah cara membuat ayam rica kemangi yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan teruji, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
