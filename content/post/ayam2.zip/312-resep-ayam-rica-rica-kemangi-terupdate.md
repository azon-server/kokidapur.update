---
description: "Resep : Ayam Rica Rica Kemangi terupdate"
title: "Resep : Ayam Rica Rica Kemangi terupdate"
slug: 312-resep-ayam-rica-rica-kemangi-terupdate
date: 2020-10-24T08:33:40.353Z
image: https://img-global.cpcdn.com/recipes/b1af3305b5f69fff/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b1af3305b5f69fff/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b1af3305b5f69fff/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Ernest Holland
ratingvalue: 4.4
reviewcount: 22832
recipeingredient:
- "12 potong ayam"
- "Secukupnya kunyit bubuk air jeruk nipis sedikit garam"
- " Bahan Halus"
- "3 buah cabai merah"
- "10 buah cabai rawit bisa di sesuaikan"
- "5 siung bawang merah"
- "5 siung bawang putih"
- "2 cm jahe"
- "Sedikit kunyit"
- "3 butir kemiri"
- "2 cm lengkuas"
- " Bumbu kasar"
- "1 lembar daun pandang simpul"
- "3 batang serai digeprek"
- "5 lembar daun salam"
- "5 lembar daun jeruk iris halus"
- "Secukupnya daun bawang"
- "1 genggam daun kemangi"
- "Secukupnya garam dan penyedap rasa"
recipeinstructions:
- "Baluri ayam dengan kunyit bubuk, air jeruk nipis dan sedikit garam. Lalu diamkan 10 menit kemudian goreng sampai setengah kering"
- "Tumis bumbu halus sampai wangi masukan daun jeruk, daun salam, daun pandan dan serai. Masukan ayam yg sudah di goreng stgah kering td aduk hingga rata masukan air secukupnya. masukan garam dan penyedap secukupnya."
- "Masak sampai ayam empuk. Setelah ayam empuk dan kuah mengering masukan daun kemangi dan daun bawang dan aduk hingga layu."
- "Ayam rica rica siap dihidangkan dengan nasi panas bersama lalapan.Selamat mencoba.. 😊"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 216 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/b1af3305b5f69fff/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang setidaknya kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica rica kemangi yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Nusantara

Kehangatan rumah tangga bisa diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam Rica Rica Kemangi untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang bisa anda contoh salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi:

1. Jangan lupa 12 potong ayam
1. Tambah Secukupnya kunyit bubuk, air jeruk nipis, sedikit garam
1. Diperlukan  Bahan Halus
1. Harap siapkan 3 buah cabai merah
1. Dibutuhkan 10 buah cabai rawit (bisa di sesuaikan)
1. Diperlukan 5 siung bawang merah
1. Siapkan 5 siung bawang putih
1. Jangan lupa 2 cm jahe
1. Harap siapkan Sedikit kunyit
1. Harap siapkan 3 butir kemiri
1. Jangan lupa 2 cm lengkuas
1. Tambah  Bumbu kasar
1. Jangan lupa 1 lembar daun pandang (simpul)
1. Dibutuhkan 3 batang serai (digeprek)
1. Jangan lupa 5 lembar daun salam
1. Jangan lupa 5 lembar daun jeruk (iris halus)
1. Jangan lupa Secukupnya daun bawang
1. Harap siapkan 1 genggam daun kemangi
1. Harus ada Secukupnya garam dan penyedap rasa




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica Kemangi:

1. Baluri ayam dengan kunyit bubuk, air jeruk nipis dan sedikit garam. Lalu diamkan 10 menit kemudian goreng sampai setengah kering
1. Tumis bumbu halus sampai wangi masukan daun jeruk, daun salam, daun pandan dan serai. Masukan ayam yg sudah di goreng stgah kering td aduk hingga rata masukan air secukupnya. masukan garam dan penyedap secukupnya.
1. Masak sampai ayam empuk. Setelah ayam empuk dan kuah mengering masukan daun kemangi dan daun bawang dan aduk hingga layu.
1. Ayam rica rica siap dihidangkan dengan nasi panas bersama lalapan.Selamat mencoba.. 😊




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan cepat, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
