---
description: "Resep : Ayam rica rica kemangi Favorite"
title: "Resep : Ayam rica rica kemangi Favorite"
slug: 350-resep-ayam-rica-rica-kemangi-favorite
date: 2020-08-14T11:47:21.851Z
image: https://img-global.cpcdn.com/recipes/980ee4205d842cc5/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/980ee4205d842cc5/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/980ee4205d842cc5/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Henry Graham
ratingvalue: 4.3
reviewcount: 40208
recipeingredient:
- "1 ekor ayam"
- "2 iket kemangi"
- "2 butir jeruk nipis"
- "1 buah tomat besar iris"
- " Bumbu halus "
- "1 sdt lada butir"
- "20 Cabe rawit"
- "5 cabe merah"
- "5 siung bawang merah"
- "2 siung bawang putih"
- "5 butir kemiri"
- "3 ruas kunyit"
- "1 ruas jahe geprek"
- "2 lembar daun salam"
- "2 lembar serei geprek"
- " Garam"
- " Gula"
- " Kaldu jamur"
- "2 sdm perasan jeruk nipis"
recipeinstructions:
- "Cuci bersih ayam lumuri jeruk nipis sisihkan.."
- "Siapkan wajan masukan minyak goreng secukupnya,tumis bumbu halus masukan salam serei jahe tumis hingga harum dan berminyak,"
- "Masukan ayam aduk smpai rata, tambahkan garam gula kaldu jamur dan air secukupnya masak hingga kuah menyusut masukan tomat dan yg paling akhir adalah kemangi biar kemangi tetap hijau dimasukan paling akhir ya bun sajikan🙂"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 256 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/980ee4205d842cc5/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau empuk. Ciri makanan Indonesia ayam rica rica kemangi yang kaya dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah memasak Ayam rica rica kemangi untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang bisa anda praktekkan salah satunya ayam rica rica kemangi yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Jangan lupa 1 ekor ayam
1. Diperlukan 2 iket kemangi
1. Diperlukan 2 butir jeruk nipis
1. Siapkan 1 buah tomat besar (iris)
1. Tambah  Bumbu halus :
1. Diperlukan 1 sdt lada butir
1. Dibutuhkan 20 Cabe rawit
1. Siapkan 5 cabe merah
1. Jangan lupa 5 siung bawang merah
1. Diperlukan 2 siung bawang putih
1. Diperlukan 5 butir kemiri
1. Siapkan 3 ruas kunyit
1. Diperlukan 1 ruas jahe (geprek)
1. Harus ada 2 lembar daun salam
1. Harap siapkan 2 lembar serei (geprek)
1. Tambah  Garam
1. Jangan lupa  Gula
1. Harus ada  Kaldu jamur
1. Harus ada 2 sdm perasan jeruk nipis




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica rica kemangi:

1. Cuci bersih ayam lumuri jeruk nipis sisihkan..
1. Siapkan wajan masukan minyak goreng secukupnya,tumis bumbu halus masukan salam serei jahe tumis hingga harum dan berminyak,
1. Masukan ayam aduk smpai rata, tambahkan garam gula kaldu jamur dan air secukupnya masak hingga kuah menyusut masukan tomat dan yg paling akhir adalah kemangi biar kemangi tetap hijau dimasukan paling akhir ya bun sajikan🙂




Demikianlah cara membuat ayam rica rica kemangi yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
