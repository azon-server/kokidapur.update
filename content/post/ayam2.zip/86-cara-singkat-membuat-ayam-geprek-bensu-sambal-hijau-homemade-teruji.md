---
description: "Cara singkat membuat Ayam geprek bensu sambal hijau homemade Teruji"
title: "Cara singkat membuat Ayam geprek bensu sambal hijau homemade Teruji"
slug: 86-cara-singkat-membuat-ayam-geprek-bensu-sambal-hijau-homemade-teruji
date: 2020-09-05T12:55:22.670Z
image: https://img-global.cpcdn.com/recipes/88d535983bf1a7d3/751x532cq70/ayam-geprek-bensu-sambal-hijau-homemade-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/88d535983bf1a7d3/751x532cq70/ayam-geprek-bensu-sambal-hijau-homemade-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/88d535983bf1a7d3/751x532cq70/ayam-geprek-bensu-sambal-hijau-homemade-foto-resep-utama.jpg
author: Alejandro Nguyen
ratingvalue: 4.3
reviewcount: 13920
recipeingredient:
- "4 potong ayam"
- " Tepung terigu"
- " Tepung kobe bumbu pedastepung kentucky crispy"
- " Bumbu ulek"
- "7 siung bawang putih"
- "5-7 buah cabe hijau kecil sesuai selera"
- "secukupnya Garam"
- "secukupnya minyak untuk menggoreng"
recipeinstructions:
- "Cuci bersih ayam kemudian balur dengan adonan basah (sedikit tepung terigu + tepung kobe bumbu pedas, + sedikit air), diamkankan di kulkas 10-15 menit (agar bumbu meresap)"
- "Ambil ayam dari kulkas, balurkan lagi dengan adonan basah, + tepung kobe bumbu pedas (agar crispy) kemudian goreng. *Perhatikan panas api ketika memasak ayam, saat awal memasukkan ayam pastikan minyak panas, setelah itu baru kecilkan api agar ayam matang sampai ke dalam)"
- "Sembari menggoreng ayam, masukan cabe hijau kecil dan bawang putih (kemudian angkat setelah agak layu)"
- "Ulek kasar cabe hijau kecil, bawang putih dan garam dengan cobek/ulekan, kemudian geprek ayam yg telah digoreng"
- "Ayam geprek bensu sambal hijau homeade siap disajikan"
categories:
- Recipe
tags:
- ayam
- geprek
- bensu

katakunci: ayam geprek bensu 
nutrition: 158 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam geprek bensu sambal hijau homemade](https://img-global.cpcdn.com/recipes/88d535983bf1a7d3/751x532cq70/ayam-geprek-bensu-sambal-hijau-homemade-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang harus kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam geprek bensu sambal hijau homemade yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa kesan tersendiri yang merupakan keragaman Indonesia



Kehangatan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam geprek bensu sambal hijau homemade untuk keluarga. Momen makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang dapat anda contoh salah satunya ayam geprek bensu sambal hijau homemade yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep ayam geprek bensu sambal hijau homemade tanpa harus bersusah payah.
Seperti resep Ayam geprek bensu sambal hijau homemade yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 8 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam geprek bensu sambal hijau homemade:

1. Diperlukan 4 potong ayam
1. Siapkan  Tepung terigu
1. Tambah  Tepung kobe bumbu pedas/tepung kentucky crispy
1. Dibutuhkan  Bumbu ulek:
1. Dibutuhkan 7 siung bawang putih
1. Siapkan 5-7 buah cabe hijau kecil (sesuai selera)
1. Jangan lupa secukupnya Garam
1. Harus ada secukupnya minyak untuk menggoreng




<!--inarticleads2-->

##### Bagaimana membuat  Ayam geprek bensu sambal hijau homemade:

1. Cuci bersih ayam kemudian balur dengan adonan basah (sedikit tepung terigu + tepung kobe bumbu pedas, + sedikit air), diamkankan di kulkas 10-15 menit (agar bumbu meresap)
1. Ambil ayam dari kulkas, balurkan lagi dengan adonan basah, + tepung kobe bumbu pedas (agar crispy) kemudian goreng. *Perhatikan panas api ketika memasak ayam, saat awal memasukkan ayam pastikan minyak panas, setelah itu baru kecilkan api agar ayam matang sampai ke dalam)
1. Sembari menggoreng ayam, masukan cabe hijau kecil dan bawang putih (kemudian angkat setelah agak layu)
1. Ulek kasar cabe hijau kecil, bawang putih dan garam dengan cobek/ulekan, kemudian geprek ayam yg telah digoreng
1. Ayam geprek bensu sambal hijau homeade siap disajikan




Demikianlah cara membuat ayam geprek bensu sambal hijau homemade yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan teruji, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
