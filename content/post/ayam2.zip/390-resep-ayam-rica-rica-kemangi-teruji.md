---
description: "Resep : Ayam Rica-Rica Kemangi Teruji"
title: "Resep : Ayam Rica-Rica Kemangi Teruji"
slug: 390-resep-ayam-rica-rica-kemangi-teruji
date: 2020-11-23T02:06:53.742Z
image: https://img-global.cpcdn.com/recipes/f31e03dde76ce9e0/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f31e03dde76ce9e0/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f31e03dde76ce9e0/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Dennis Black
ratingvalue: 4.1
reviewcount: 8487
recipeingredient:
- "400 gr ayam"
- "1 genggam kemangi"
- "Secukupnya minyak goreng dan air"
- " Bumbu"
- "1 batang serai geprek"
- "1 ruas lengkuas geprek"
- "1 lbr daun salam"
- "2 lbr daun jeruk"
- "Secukupnya garam gula merica ketumbar"
- " Bumbu halus"
- "4 siung bawang putih"
- "4 buah bawang merah"
- "1 buah kemiri"
- "1 ruas kunyit"
- "1 ruas jahe"
- "10 buah cabe rawit"
- "10 buah cabe merah"
recipeinstructions:
- "Panaskan secukupnya minyak, tumis serai, lengkuas, daun Salam, daun jeruk, dan bumbu halus sampai harum"
- "Masukkan ayam tambahkan air (cukup sampai ayam terendam) dan sisa bumbu lainnya aduk merata masak sampai air sisa sedikit"
- "Setelah air menyusut &amp; ayam matang tambahkan kemangi aduk rata"
- "Koreksi rasa &amp; sajikan❤️"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 229 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/f31e03dde76ce9e0/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau empuk. Ciri khas masakan Nusantara ayam rica-rica kemangi yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga bisa ditemukan dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica-Rica Kemangi untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang bisa anda buat salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica Kemangi:

1. Jangan lupa 400 gr ayam
1. Diperlukan 1 genggam kemangi
1. Harus ada Secukupnya minyak goreng dan air
1. Jangan lupa  Bumbu:
1. Jangan lupa 1 batang serai, geprek
1. Diperlukan 1 ruas lengkuas, geprek
1. Tambah 1 lbr daun salam
1. Harap siapkan 2 lbr daun jeruk
1. Jangan lupa Secukupnya garam, gula, merica, ketumbar
1. Diperlukan  Bumbu halus:
1. Jangan lupa 4 siung bawang putih
1. Dibutuhkan 4 buah bawang merah
1. Tambah 1 buah kemiri
1. Jangan lupa 1 ruas kunyit
1. Tambah 1 ruas jahe
1. Siapkan 10 buah cabe rawit
1. Harap siapkan 10 buah cabe merah




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica Kemangi:

1. Panaskan secukupnya minyak, tumis serai, lengkuas, daun Salam, daun jeruk, dan bumbu halus sampai harum
1. Masukkan ayam tambahkan air (cukup sampai ayam terendam) dan sisa bumbu lainnya aduk merata masak sampai air sisa sedikit
1. Setelah air menyusut &amp; ayam matang tambahkan kemangi aduk rata
1. Koreksi rasa &amp; sajikan❤️




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan terbukti, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
