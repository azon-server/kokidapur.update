---
description: "Step-by-Step membuat Ayam Rica-rica Kemangi Sempurna"
title: "Step-by-Step membuat Ayam Rica-rica Kemangi Sempurna"
slug: 272-step-by-step-membuat-ayam-rica-rica-kemangi-sempurna
date: 2021-01-22T15:23:20.595Z
image: https://img-global.cpcdn.com/recipes/deaf7e711a7801b0/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/deaf7e711a7801b0/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/deaf7e711a7801b0/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Bryan Walton
ratingvalue: 4
reviewcount: 25089
recipeingredient:
- " Bahan Utama"
- "1/2 kg Ayam"
- "Seikat Kemangi"
- " Bumbu Halus"
- "5 siung Bawang Merah"
- "4 siung Bawang Putih"
- "2 ruas jari Kunyit"
- "3 buah Kemiri"
- " Bumbu Geprek"
- "1 btg Sereh"
- "2 ruas jari Jahe"
- "1 ruas jari Lengkuas"
- " Bahan Tambahan"
- "3 lbr Daun Jeruk"
- "2 lbr Daur Salam"
- "3 bh Cabe Merah Keriting"
- "1 btg Daun Bawang"
- "1 sdt Garam"
- "2 sdt Gula"
- "1 bh Jeruk Nipis"
recipeinstructions:
- "Peras jeruk nipis ke ayam yang sudah dipotong-potong, diamkan 5 menit lalu cuci bersih. Rebus sebentar dengan air yang diberi 1 lembar daun salam (untuk mengangkat lemak-lemak penyebab kolesterol) 😁 Tiriskan airnya."
- "Tumis bumbu halus sampai wangi, masukkan bumbu-bumbu yang sudah digeprek, tambahkan cabe, daun salam dan daun jeruk. Setelah semakin wangi, masukkan ayam dan tambahkan air secukupnya. Jangan lupa gula garam yaa.."
- "Setelah air sudah agak berkurang, masukkan daun bawang. Aduk hingga rata. Ketika air sudah tinggal sedikit, masukkan daun kemangi. Aduk-aduk hinga kemangi layu."
- "Siap dihidangkan dengan taburan bawang goreng 😊"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 101 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/deaf7e711a7801b0/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan gurih. Karasteristik masakan Nusantara ayam rica-rica kemangi yang kaya dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan rumah tangga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica-rica Kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang dapat anda buat salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Kemangi:

1. Harus ada  Bahan Utama
1. Jangan lupa 1/2 kg Ayam
1. Tambah Seikat Kemangi
1. Harus ada  Bumbu Halus
1. Jangan lupa 5 siung Bawang Merah
1. Diperlukan 4 siung Bawang Putih
1. Jangan lupa 2 ruas jari Kunyit
1. Tambah 3 buah Kemiri
1. Siapkan  Bumbu Geprek
1. Jangan lupa 1 btg Sereh
1. Harap siapkan 2 ruas jari Jahe
1. Harus ada 1 ruas jari Lengkuas
1. Dibutuhkan  Bahan Tambahan
1. Tambah 3 lbr Daun Jeruk
1. Harap siapkan 2 lbr Daur Salam
1. Dibutuhkan 3 bh Cabe Merah Keriting
1. Diperlukan 1 btg Daun Bawang
1. Tambah 1 sdt Garam
1. Jangan lupa 2 sdt Gula
1. Siapkan 1 bh Jeruk Nipis




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-rica Kemangi:

1. Peras jeruk nipis ke ayam yang sudah dipotong-potong, diamkan 5 menit lalu cuci bersih. Rebus sebentar dengan air yang diberi 1 lembar daun salam (untuk mengangkat lemak-lemak penyebab kolesterol) 😁 Tiriskan airnya.
1. Tumis bumbu halus sampai wangi, masukkan bumbu-bumbu yang sudah digeprek, tambahkan cabe, daun salam dan daun jeruk. Setelah semakin wangi, masukkan ayam dan tambahkan air secukupnya. Jangan lupa gula garam yaa..
1. Setelah air sudah agak berkurang, masukkan daun bawang. Aduk hingga rata. Ketika air sudah tinggal sedikit, masukkan daun kemangi. Aduk-aduk hinga kemangi layu.
1. Siap dihidangkan dengan taburan bawang goreng 😊




Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
