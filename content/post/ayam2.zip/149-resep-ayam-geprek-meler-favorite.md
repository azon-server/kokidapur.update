---
description: "Resep : Ayam Geprek Meler Favorite"
title: "Resep : Ayam Geprek Meler Favorite"
slug: 149-resep-ayam-geprek-meler-favorite
date: 2021-01-21T17:40:42.555Z
image: https://img-global.cpcdn.com/recipes/3c897878ae947dcd/751x532cq70/ayam-geprek-meler-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3c897878ae947dcd/751x532cq70/ayam-geprek-meler-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3c897878ae947dcd/751x532cq70/ayam-geprek-meler-foto-resep-utama.jpg
author: Elnora Herrera
ratingvalue: 4.7
reviewcount: 13580
recipeingredient:
- "1/2 ekor ayam potong sesuai selera"
- "1 buah jeruk nipis"
- "secukupnya keju mozarella"
- "  Bahan Pencelup Marinade "
- "75 gr tepung serbaguna"
- "2 sdm tepung maizena"
- "2 siung bawang putih haluskan"
- "secukupnya kaldu bubuk"
- "secukupnya lada"
- "secukupnya air es"
- "  Bahan Kering "
- "100 gr tepung serbaguna"
- "3 sdm tepung maizena"
- "1/2 sdt baking powder"
- "secukupnya lada"
- "secukupnya kaldu bubuk"
- "  Sambal "
- "20 butir cabe rawit merah"
- "2 siung bawang putih"
- "secukupnya garam"
- "2 sdm minyak panas"
recipeinstructions:
- "Lumuri ayam dengan air jeruk nipis, diamkan 10 menit, cuci bersih, tiriskan. Aduk rata bahan pencelup, tuangi air es sedikit demi sedikit sampai jadi adonan yang kental, sisihkan."
- "Rendam daging ayam dalam adonan pencelup, diamkan 15 menit didalam kulkas."
- "Gulingkan ayam keadonan kering, cubit2 sampai rata"
- "Goreng dalam minyak panas dengan api kecil sampai matang, angkat, tiriskan."
- "Ulek bahan sambel, siram dengan minyak panas,"
- "Ambil ayam goreng lalu geprek2 diatas sambal,"
- "Taburi ayam dengan keju mozarela"
- "Panggang sebentar saja hanya untuk membuat keju lumer"
- "Sajikan"
categories:
- Recipe
tags:
- ayam
- geprek
- meler

katakunci: ayam geprek meler 
nutrition: 248 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Geprek Meler](https://img-global.cpcdn.com/recipes/3c897878ae947dcd/751x532cq70/ayam-geprek-meler-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam geprek meler yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Nusantara

Kedekatan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam Geprek Meler untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang dapat anda buat salah satunya ayam geprek meler yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep ayam geprek meler tanpa harus bersusah payah.
Seperti resep Ayam Geprek Meler yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Meler:

1. Harus ada 1/2 ekor ayam (potong sesuai selera)
1. Harap siapkan 1 buah jeruk nipis
1. Siapkan secukupnya keju mozarella
1. Siapkan  - Bahan Pencelup (Marinade) --
1. Siapkan 75 gr tepung serbaguna
1. Harap siapkan 2 sdm tepung maizena
1. Harap siapkan 2 siung bawang putih (haluskan)
1. Diperlukan secukupnya kaldu bubuk
1. Jangan lupa secukupnya lada
1. Diperlukan secukupnya air es
1. Tambah  - Bahan Kering --
1. Diperlukan 100 gr tepung serbaguna
1. Tambah 3 sdm tepung maizena
1. Jangan lupa 1/2 sdt baking powder
1. Tambah secukupnya lada
1. Jangan lupa secukupnya kaldu bubuk
1. Tambah  - Sambal --
1. Harap siapkan 20 butir cabe rawit merah
1. Dibutuhkan 2 siung bawang putih
1. Harap siapkan secukupnya garam
1. Harap siapkan 2 sdm minyak panas




<!--inarticleads2-->

##### Langkah membuat  Ayam Geprek Meler:

1. Lumuri ayam dengan air jeruk nipis, diamkan 10 menit, cuci bersih, tiriskan. Aduk rata bahan pencelup, tuangi air es sedikit demi sedikit sampai jadi adonan yang kental, sisihkan.
1. Rendam daging ayam dalam adonan pencelup, diamkan 15 menit didalam kulkas.
1. Gulingkan ayam keadonan kering, cubit2 sampai rata
1. Goreng dalam minyak panas dengan api kecil sampai matang, angkat, tiriskan.
1. Ulek bahan sambel, siram dengan minyak panas,
1. Ambil ayam goreng lalu geprek2 diatas sambal,
1. Taburi ayam dengan keju mozarela
1. Panggang sebentar saja hanya untuk membuat keju lumer
1. Sajikan




Demikianlah cara membuat ayam geprek meler yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
