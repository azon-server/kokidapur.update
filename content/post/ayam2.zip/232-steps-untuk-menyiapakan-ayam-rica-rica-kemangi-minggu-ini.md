---
description: "Steps untuk menyiapakan Ayam rica rica kemangi minggu ini"
title: "Steps untuk menyiapakan Ayam rica rica kemangi minggu ini"
slug: 232-steps-untuk-menyiapakan-ayam-rica-rica-kemangi-minggu-ini
date: 2020-11-28T00:07:50.039Z
image: https://img-global.cpcdn.com/recipes/8c99fc0d70f44364/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8c99fc0d70f44364/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8c99fc0d70f44364/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Winnie Logan
ratingvalue: 4
reviewcount: 8897
recipeingredient:
- "1 ekor ayam potong kecil"
- "6 lembar daun jeruk potong tipis2"
- "2 batang serai memarkan"
- "3 lembar daun salam"
- "2 ikat kemangi petik daunnya saja"
- "2 ruas lengkuas memarkan"
- "2 ruas jahe memarkan"
- " Garam"
- " Penyedap jamur  kaldu bubuk sesuai selera"
- "6 buah cabe rawit merah bulat boleh ditambah sesuai selera"
- " Bumbu halus"
- "20 cabe merah keriting"
- "9 cabe rawit merah"
- "8 siung bawang merah"
- "3 siung bawang putih"
- "2 ruas kunyit kupas"
recipeinstructions:
- "Cuci bersih ayam, kemudian goreng di minyak panas sampai ayam agak sedikit kecoklatan / setengah matang. Jika sudah kecoklatan, angkat dan tiriskan."
- "Tumis bumbu halus dengan api kecil hingga wangi, masukan lengkuas, jahe, daun jeruk, daun salam, dan batang serai. Tumis kembali hingga wangi."
- "Masukan ayam yang tadi sudah digoreng kedalam tumisan bumbu, masukan garam dan penyedap, aduk hingga ayam tercampur dengan bumbu cabe. Tambahkan sedikit saja air supaya lebih mudah tercampur."
- "Setelah tercampur rata, masukan cabe rawit merah bulat untuk variasi jika ingin menambah rasa pedas, tumis kembali. Setelah semua tercampur rata, masukan daun kemangi, tumis hingga agak layu. Matikan api. Rica rica siap disantap...selamat mencoba bun 🥰🥰🥰"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 115 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/8c99fc0d70f44364/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan renyah. Karasteristik makanan Nusantara ayam rica rica kemangi yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Kedekatan keluarga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica rica kemangi untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang dapat anda coba salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi:

1. Diperlukan 1 ekor ayam, potong kecil
1. Diperlukan 6 lembar daun jeruk, potong tipis2
1. Harap siapkan 2 batang serai, memarkan
1. Harus ada 3 lembar daun salam
1. Diperlukan 2 ikat kemangi, petik daunnya saja
1. Tambah 2 ruas lengkuas, memarkan
1. Diperlukan 2 ruas jahe, memarkan
1. Harus ada  Garam
1. Harus ada  Penyedap jamur / kaldu bubuk (sesuai selera)
1. Harap siapkan 6 buah cabe rawit merah bulat (boleh ditambah sesuai selera)
1. Dibutuhkan  Bumbu halus
1. Diperlukan 20 cabe merah keriting
1. Harap siapkan 9 cabe rawit merah
1. Tambah 8 siung bawang merah
1. Harap siapkan 3 siung bawang putih
1. Harap siapkan 2 ruas kunyit, kupas


Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Cara membuat  Ayam rica rica kemangi:

1. Cuci bersih ayam, kemudian goreng di minyak panas sampai ayam agak sedikit kecoklatan / setengah matang. Jika sudah kecoklatan, angkat dan tiriskan.
1. Tumis bumbu halus dengan api kecil hingga wangi, masukan lengkuas, jahe, daun jeruk, daun salam, dan batang serai. Tumis kembali hingga wangi.
1. Masukan ayam yang tadi sudah digoreng kedalam tumisan bumbu, masukan garam dan penyedap, aduk hingga ayam tercampur dengan bumbu cabe. Tambahkan sedikit saja air supaya lebih mudah tercampur.
1. Setelah tercampur rata, masukan cabe rawit merah bulat untuk variasi jika ingin menambah rasa pedas, tumis kembali. Setelah semua tercampur rata, masukan daun kemangi, tumis hingga agak layu. Matikan api. Rica rica siap disantap...selamat mencoba bun 🥰🥰🥰


Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Siapa yang tidak mengenal lalapan daun kemangi di Indonesia ini. Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. 

Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan terbukti, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
