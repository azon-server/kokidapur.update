---
description: "Resep : Ayam Geprek Bensu a la Rumahan minggu ini"
title: "Resep : Ayam Geprek Bensu a la Rumahan minggu ini"
slug: 21-resep-ayam-geprek-bensu-a-la-rumahan-minggu-ini
date: 2020-10-15T10:43:38.952Z
image: https://img-global.cpcdn.com/recipes/e2717d33d4ea49f7/751x532cq70/ayam-geprek-bensu-a-la-rumahan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e2717d33d4ea49f7/751x532cq70/ayam-geprek-bensu-a-la-rumahan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e2717d33d4ea49f7/751x532cq70/ayam-geprek-bensu-a-la-rumahan-foto-resep-utama.jpg
author: Katie Morton
ratingvalue: 4.6
reviewcount: 36410
recipeingredient:
- "8 potong dada ayam"
- "Secukupnya tepung bumbu Sajiku"
- "Secukupnya keju cheddar"
- " Bahan untuk merebus ayam"
- "1 sdm garam"
- "1 btg serai"
- "2 lbr daun salam"
- " Bahan sambal geprek"
- "1 ons cengek domba lombok cengek merah"
- "3 siung bawang merah"
- "3 siung bawang putih"
- "1 sdt garam"
- "1 sdt royco"
- "1 sdt gula pasir"
- "Secukupnya air"
recipeinstructions:
- "Rebus ayam dengan bahan2 rebusan selama ±15menit dengan api sedang"
- "Setelah ayam di rebus, dinginkan, lalu masukkan ke kulkas ±30 menit"
- "Selagi menunggu ayam dingin, buat sambal gepreknya, uleg/chopper cengek, iris bawang merah dan bawang putih"
- "Tumis bawang merah, masukkan ke ulekan cengek, setelah itu tumis bawang putih, masukkan ke ulekan cengek"
- "Ulek/ chopper cengek, tumisan bawang merah, tumisan bawang putih, garam, gula, royco"
- "Goreng bahan sambal dgn ditambahkan sedikit air hingga air menyusut, lalu sisihkan"
- "Buat adonan basah tepung Sajiku secukupnya tidak kental dan tidak encer, masukkan satu persatu potongan ayam, gulingkan hingga merata"
- "Lalu gulingkan satu persatu ayam ke tepung bumbu Sajiku sambil diremas2 merata"
- "Goreng ayam dgn minyak panas sedang hingga kuning kecoklatan. Angkat"
- "Geprek ayam dgn sambal geprek. Lalu sajikan dgn taburan keju chedar di atasnya."
categories:
- Recipe
tags:
- ayam
- geprek
- bensu

katakunci: ayam geprek bensu 
nutrition: 218 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Geprek Bensu a la Rumahan](https://img-global.cpcdn.com/recipes/e2717d33d4ea49f7/751x532cq70/ayam-geprek-bensu-a-la-rumahan-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan gurih. Ciri khas masakan Nusantara ayam geprek bensu a la rumahan yang kaya dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Ayam Geprek Bensu a la Rumahan untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda buat salah satunya ayam geprek bensu a la rumahan yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam geprek bensu a la rumahan tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Bensu a la Rumahan yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Bensu a la Rumahan:

1. Dibutuhkan 8 potong dada ayam
1. Jangan lupa Secukupnya tepung bumbu Sajiku
1. Tambah Secukupnya keju cheddar
1. Tambah  Bahan untuk merebus ayam
1. Tambah 1 sdm garam
1. Harus ada 1 btg serai
1. Dibutuhkan 2 lbr daun salam
1. Harus ada  Bahan sambal geprek
1. Siapkan 1 ons cengek domba/ lombok/ cengek merah
1. Siapkan 3 siung bawang merah
1. Jangan lupa 3 siung bawang putih
1. Jangan lupa 1 sdt garam
1. Harus ada 1 sdt royco
1. Harus ada 1 sdt gula pasir
1. Siapkan Secukupnya air




<!--inarticleads2-->

##### Instruksi membuat  Ayam Geprek Bensu a la Rumahan:

1. Rebus ayam dengan bahan2 rebusan selama ±15menit dengan api sedang
1. Setelah ayam di rebus, dinginkan, lalu masukkan ke kulkas ±30 menit
1. Selagi menunggu ayam dingin, buat sambal gepreknya, uleg/chopper cengek, iris bawang merah dan bawang putih
1. Tumis bawang merah, masukkan ke ulekan cengek, setelah itu tumis bawang putih, masukkan ke ulekan cengek
1. Ulek/ chopper cengek, tumisan bawang merah, tumisan bawang putih, garam, gula, royco
1. Goreng bahan sambal dgn ditambahkan sedikit air hingga air menyusut, lalu sisihkan
1. Buat adonan basah tepung Sajiku secukupnya tidak kental dan tidak encer, masukkan satu persatu potongan ayam, gulingkan hingga merata
1. Lalu gulingkan satu persatu ayam ke tepung bumbu Sajiku sambil diremas2 merata
1. Goreng ayam dgn minyak panas sedang hingga kuning kecoklatan. Angkat
1. Geprek ayam dgn sambal geprek. Lalu sajikan dgn taburan keju chedar di atasnya.




Demikianlah cara membuat ayam geprek bensu a la rumahan yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan cepat, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
