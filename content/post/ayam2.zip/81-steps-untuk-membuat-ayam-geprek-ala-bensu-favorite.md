---
description: "Steps untuk membuat Ayam Geprek ala Bensu Favorite"
title: "Steps untuk membuat Ayam Geprek ala Bensu Favorite"
slug: 81-steps-untuk-membuat-ayam-geprek-ala-bensu-favorite
date: 2021-01-07T00:48:48.910Z
image: https://img-global.cpcdn.com/recipes/6fb3ce44ea5dc0ac/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6fb3ce44ea5dc0ac/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6fb3ce44ea5dc0ac/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg
author: Martin Garza
ratingvalue: 5
reviewcount: 37426
recipeingredient:
- "1-2 potong ayam"
- "1-2 potong tempe"
- "1-2 potong tahu"
- "1 buah mentimunkolseladadaun kemangi"
- " Tepung serbaguna"
- " Sambal bawang atau sambal korek"
- " Jeruk nipis skip untuk yg tahan amis spt saya"
- " Garam"
- " Gula"
- " Lada bubuk"
recipeinstructions:
- "Marinasi ayam dengan perasan nipis, garam, dan lada, kalau saya pake ayam yg sudah diungkep krna selalu stok ayam siap goreng,"
- "Marinasi jg tahu dan tempe"
- "Bagi tepung mjd 2 adonan, basah dan kering"
- "Celupkan ayam k dalam tepung basah, lalu ke tepung kering, remas2 hingga tepungnya gimbal, lalu goreng dalam minyak panas hingga coklat keemasan, lakukan hal sama dengan tempe dan tahunya"
- "Angkat dan tiriskan, lalu geprek bersama sambal bawang, kalau saya dipukul2 pake anak cobek"
- "Sajikan dengan nasi hangat dan lalapan"
categories:
- Recipe
tags:
- ayam
- geprek
- ala

katakunci: ayam geprek ala 
nutrition: 275 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Geprek ala Bensu](https://img-global.cpcdn.com/recipes/6fb3ce44ea5dc0ac/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam geprek ala bensu yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan ciri khas yang merupakan keragaman Nusantara

Keharmonisan keluarga bisa didapat dengan cara sederhana. Salah satunya adalah memasak Ayam Geprek ala Bensu untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang bisa anda contoh salah satunya ayam geprek ala bensu yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep ayam geprek ala bensu tanpa harus bersusah payah.
Seperti resep Ayam Geprek ala Bensu yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek ala Bensu:

1. Harap siapkan 1-2 potong ayam
1. Harap siapkan 1-2 potong tempe
1. Dibutuhkan 1-2 potong tahu
1. Harap siapkan 1 buah mentimun/kol/selada/daun kemangi
1. Harus ada  Tepung serbaguna
1. Harus ada  Sambal bawang atau sambal korek
1. Jangan lupa  Jeruk nipis (skip untuk yg tahan amis spt saya)
1. Harus ada  Garam
1. Harus ada  Gula
1. Siapkan  Lada bubuk




<!--inarticleads2-->

##### Cara membuat  Ayam Geprek ala Bensu:

1. Marinasi ayam dengan perasan nipis, garam, dan lada, kalau saya pake ayam yg sudah diungkep krna selalu stok ayam siap goreng,
1. Marinasi jg tahu dan tempe
1. Bagi tepung mjd 2 adonan, basah dan kering
1. Celupkan ayam k dalam tepung basah, lalu ke tepung kering, remas2 hingga tepungnya gimbal, lalu goreng dalam minyak panas hingga coklat keemasan, lakukan hal sama dengan tempe dan tahunya
1. Angkat dan tiriskan, lalu geprek bersama sambal bawang, kalau saya dipukul2 pake anak cobek
1. Sajikan dengan nasi hangat dan lalapan




Demikianlah cara membuat ayam geprek ala bensu yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
