---
description: "Resep : Ayam Geprek teraktual"
title: "Resep : Ayam Geprek teraktual"
slug: 161-resep-ayam-geprek-teraktual
date: 2020-10-16T10:06:48.068Z
image: https://img-global.cpcdn.com/recipes/264b44536829cd3f/751x532cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/264b44536829cd3f/751x532cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/264b44536829cd3f/751x532cq70/ayam-geprek-foto-resep-utama.jpg
author: Zachary Walker
ratingvalue: 4.5
reviewcount: 8298
recipeingredient:
- " Bahan Ayam marinasi min 15 menit"
- "500 gr ayam fillet potong jadi 56 bagian pukul pipih"
- "Secukupnya garam kaldu bubuk lada bubuk"
- " Bahan pencelup basah"
- "3 sdm tepung terigu"
- "1 sdm tepung maizena"
- "Secukupnya air"
- "Secukupnya lada bubuk kaldu bubuk dan garam"
- " Bahan pencelup kering"
- "10 sdm tepung terigu"
- "3 sdm tepung maizena"
- " Bahan Sambal"
- "4 siung bawang putih goreng sebentar"
- "5 bh cabe merah saya hanya 4 bh"
- "10 bh cabe rawit saya hanya 5"
- "Secukupnya lada bubuk kaldu bubuk dan gula pasir"
- "3 sdm minyak goreng panasbekas goreng ayam"
recipeinstructions:
- "Gepuk ayam agak pipih agar bumbu mudah meresap dan lebih crispy lalu marinasi min 15 menit (saya 30 menit)"
- "Ayam Goreng Tepung: Siapkan bahan pencelup basah dan kering lalu ambil celupkan ayam ke bahan basah lalu balurkan ke bahan kering sambil dicubit2 lalu goreng hingga kuning keemasan, sisihkan"
- "Bahan Sambal: Ulek semua bahan sambal sampai halus, tes rasa"
- "Penyajian: Ambil sepotong ayam lalu geprek agak hancur bersamaan dgn sambal, sajikan dgn nasi hangat dan lalapan..maknyuuusss, selamat mencoba^^"
categories:
- Recipe
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 285 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/264b44536829cd3f/751x532cq70/ayam-geprek-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang setidaknya kita lestarikan karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam geprek yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa ciri khas yang merupakan keragaman Nusantara



Kehangatan keluarga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Geprek untuk keluarga. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang bisa anda buat salah satunya ayam geprek yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep ayam geprek tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek:

1. Diperlukan  #Bahan Ayam: (marinasi min 15 menit)
1. Siapkan 500 gr ayam fillet (potong jadi 5/6 bagian, pukul pipih)
1. Tambah Secukupnya garam, kaldu bubuk, lada bubuk
1. Harus ada  #Bahan pencelup (basah):
1. Dibutuhkan 3 sdm tepung terigu
1. Tambah 1 sdm tepung maizena
1. Dibutuhkan Secukupnya air
1. Dibutuhkan Secukupnya lada bubuk, kaldu bubuk dan garam
1. Jangan lupa  #Bahan pencelup (kering):
1. Diperlukan 10 sdm tepung terigu
1. Diperlukan 3 sdm tepung maizena
1. Harus ada  #Bahan Sambal:
1. Dibutuhkan 4 siung bawang putih (goreng sebentar)
1. Dibutuhkan 5 bh cabe merah (saya hanya 4 bh)
1. Harus ada 10 bh cabe rawit (saya hanya 5😅)
1. Siapkan Secukupnya lada bubuk, kaldu bubuk dan gula pasir
1. Dibutuhkan 3 sdm minyak goreng panas(bekas goreng ayam)




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Geprek:

1. Gepuk ayam agak pipih agar bumbu mudah meresap dan lebih crispy lalu marinasi min 15 menit (saya 30 menit)
1. Ayam Goreng Tepung: Siapkan bahan pencelup basah dan kering lalu ambil celupkan ayam ke bahan basah lalu balurkan ke bahan kering sambil dicubit2 lalu goreng hingga kuning keemasan, sisihkan
1. Bahan Sambal: Ulek semua bahan sambal sampai halus, tes rasa
1. Penyajian: Ambil sepotong ayam lalu geprek agak hancur bersamaan dgn sambal, sajikan dgn nasi hangat dan lalapan..maknyuuusss, selamat mencoba^^




Demikianlah cara membuat ayam geprek yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan terbukti, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
