---
description: "Cara membuat #05 Ayam Rica Kemangi teraktual"
title: "Cara membuat #05 Ayam Rica Kemangi teraktual"
slug: 292-cara-membuat-05-ayam-rica-kemangi-teraktual
date: 2020-08-11T09:40:56.947Z
image: https://img-global.cpcdn.com/recipes/be572f5c761c0499/751x532cq70/05-ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/be572f5c761c0499/751x532cq70/05-ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/be572f5c761c0499/751x532cq70/05-ayam-rica-kemangi-foto-resep-utama.jpg
author: Jean Mason
ratingvalue: 4.5
reviewcount: 22998
recipeingredient:
- "1/2 kg ayam potong kecil"
- "1 ikat kemangi"
- " Gula Pasir"
- " Garam"
- " Penyedap rasa Masako"
- " Micin Sasa"
- " Sereh geprek"
- " Daun salam"
- " Daun jeruk"
- " Bahan yang dihaluskan "
- "4 siung bawang putih"
- "8 siung bawang merah"
- "16 biji cabe rawit"
- " Lengkuas"
- " Kunyit"
- " Jahe"
- " Kemiri"
- " Merica"
- " Ketumbar"
recipeinstructions:
- "Rebus ayam hingga matang."
- "Sementara menunggu ayam, haluskan bumbu. Boleh diuleg/diblender."
- "Tumis bumbu halus."
- "Masukkan sereh geprek, daun salam dan daun jeruk."
- "Setelah bumbu matang, masukkan ayam yang telah direbus."
- "Beri 2 gelas air belimbing."
- "Tunggu 15 menit."
- "Masukkan kemangi."
- "Tambahkan gula, garam, peyedap rasa serta micin. Pastikan rasa asin cukup. Karena kalau berlebih, ketika air menyusut masakan akan jadi terlalu asin."
- "Tes rasa. Kalau sudah OK, tunggu hingga air menyusut."
- "Apabila air sudah menyusut dan habis, sajikan di piring."
- "Selamat mencoba ♥️"
categories:
- Recipe
tags:
- 05
- ayam
- rica

katakunci: 05 ayam rica 
nutrition: 172 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Lunch

---


![#05 Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/be572f5c761c0499/751x532cq70/05-ayam-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang harus kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti #05 ayam rica kemangi yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Kita

Kehangatan rumah tangga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan #05 Ayam Rica Kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda praktekkan salah satunya #05 ayam rica kemangi yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep #05 ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep #05 Ayam Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 19 bahan dan 12 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat #05 Ayam Rica Kemangi:

1. Harap siapkan 1/2 kg ayam potong kecil
1. Siapkan 1 ikat kemangi
1. Jangan lupa  Gula Pasir
1. Tambah  Garam
1. Tambah  Penyedap rasa Masako
1. Dibutuhkan  Micin Sasa
1. Siapkan  Sereh geprek
1. Harap siapkan  Daun salam
1. Tambah  Daun jeruk
1. Diperlukan  Bahan yang dihaluskan :
1. Tambah 4 siung bawang putih
1. Harus ada 8 siung bawang merah
1. Siapkan 16 biji cabe rawit
1. Harap siapkan  Lengkuas
1. Diperlukan  Kunyit
1. Diperlukan  Jahe
1. Siapkan  Kemiri
1. Dibutuhkan  Merica
1. Diperlukan  Ketumbar




<!--inarticleads2-->

##### Langkah membuat  #05 Ayam Rica Kemangi:

1. Rebus ayam hingga matang.
1. Sementara menunggu ayam, haluskan bumbu. Boleh diuleg/diblender.
1. Tumis bumbu halus.
1. Masukkan sereh geprek, daun salam dan daun jeruk.
1. Setelah bumbu matang, masukkan ayam yang telah direbus.
1. Beri 2 gelas air belimbing.
1. Tunggu 15 menit.
1. Masukkan kemangi.
1. Tambahkan gula, garam, peyedap rasa serta micin. Pastikan rasa asin cukup. Karena kalau berlebih, ketika air menyusut masakan akan jadi terlalu asin.
1. Tes rasa. Kalau sudah OK, tunggu hingga air menyusut.
1. Apabila air sudah menyusut dan habis, sajikan di piring.
1. Selamat mencoba ♥️




Demikianlah cara membuat #05 ayam rica kemangi yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
