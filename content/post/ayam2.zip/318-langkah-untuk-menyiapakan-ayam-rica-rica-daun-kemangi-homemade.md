---
description: "Langkah untuk menyiapakan Ayam rica rica daun kemangi Homemade"
title: "Langkah untuk menyiapakan Ayam rica rica daun kemangi Homemade"
slug: 318-langkah-untuk-menyiapakan-ayam-rica-rica-daun-kemangi-homemade
date: 2020-11-11T21:38:39.995Z
image: https://img-global.cpcdn.com/recipes/727a88f7e0f4f909/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/727a88f7e0f4f909/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/727a88f7e0f4f909/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Seth Gill
ratingvalue: 4.3
reviewcount: 7348
recipeingredient:
- " Bahan dasar "
- "1 ekor Ayam"
- " Bahan yg dihaluskan"
- "8 bawang merah"
- "6 bawang putih"
- "5 kemiri"
- "8 cabe keriting"
- "8 cabe rawit"
- " Lengkuas dan jahe"
- " Bahan tambahan "
- "3 daun sereh"
- "3 daun jeruk"
- "secukupnya Daun kemangi"
recipeinstructions:
- "Cuci ayam sampai bersih kemudian kita bumbuin terlebih dahulu mengunakan bawang putih, kemiri, ketumbar, kunyit, garam, lalu kita ungkep sebentar kira2 20 menit"
- "Kemudian kita blender semua bumbu yg sudah disediakan sampai halus, sambil menunggu ayam yg lg kita masak tadi"
- "Kita goreng ayam setengah matang, kemudian kita tumis terlebih dahulu bumbu yg sudah kita haluskan"
- "Kemudian kita masukkan daun sereh, daun jeruk, kecap, lada, royco, garam, gula, sasa dan daun kemangi"
- "Setelah bumbu ditumis kita masukkan ayam lalu kita tambahkan air dan tunggu sampai air nya susut"
- "Lalu kita angkat rica rica ayam tadi lalu kita siapkan kedalam wadah, setelah itu kita hidangkan ke dalam wadah"
- "Selamat menikmati 👍👍👍"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 299 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica rica daun kemangi](https://img-global.cpcdn.com/recipes/727a88f7e0f4f909/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga renyah. Ciri makanan Nusantara ayam rica rica daun kemangi yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Ayam rica rica daun kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang dapat anda buat salah satunya ayam rica rica daun kemangi yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam rica rica daun kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica rica daun kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica daun kemangi:

1. Harap siapkan  Bahan dasar :
1. Harus ada 1 ekor Ayam
1. Harus ada  Bahan yg dihaluskan:
1. Dibutuhkan 8 bawang merah
1. Jangan lupa 6 bawang putih
1. Siapkan 5 kemiri
1. Diperlukan 8 cabe keriting
1. Tambah 8 cabe rawit
1. Diperlukan  Lengkuas dan jahe
1. Siapkan  Bahan tambahan :
1. Diperlukan 3 daun sereh
1. Dibutuhkan 3 daun jeruk
1. Harap siapkan secukupnya Daun kemangi




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica rica daun kemangi:

1. Cuci ayam sampai bersih kemudian kita bumbuin terlebih dahulu mengunakan bawang putih, kemiri, ketumbar, kunyit, garam, lalu kita ungkep sebentar kira2 20 menit
1. Kemudian kita blender semua bumbu yg sudah disediakan sampai halus, sambil menunggu ayam yg lg kita masak tadi
1. Kita goreng ayam setengah matang, kemudian kita tumis terlebih dahulu bumbu yg sudah kita haluskan
1. Kemudian kita masukkan daun sereh, daun jeruk, kecap, lada, royco, garam, gula, sasa dan daun kemangi
1. Setelah bumbu ditumis kita masukkan ayam lalu kita tambahkan air dan tunggu sampai air nya susut
1. Lalu kita angkat rica rica ayam tadi lalu kita siapkan kedalam wadah, setelah itu kita hidangkan ke dalam wadah
1. Selamat menikmati 👍👍👍




Demikianlah cara membuat ayam rica rica daun kemangi yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan teruji, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
