---
description: "Bagaimana untuk menyiapakan Ayam Rica Rica Kemangi Luar biasa"
title: "Bagaimana untuk menyiapakan Ayam Rica Rica Kemangi Luar biasa"
slug: 402-bagaimana-untuk-menyiapakan-ayam-rica-rica-kemangi-luar-biasa
date: 2020-09-20T05:18:15.644Z
image: https://img-global.cpcdn.com/recipes/f67dba11b3bf4848/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f67dba11b3bf4848/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f67dba11b3bf4848/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Frederick Higgins
ratingvalue: 4
reviewcount: 39762
recipeingredient:
- "1 ekor Ayam potong 12"
- "2 sdt Garam"
- "2 sdt penyedap rasa"
- "1 sdt gula"
- " Bumbu Halus"
- "7 Bawang merah"
- "5 Bawang putih"
- "8 Cabe merah"
- "6 Cabe Rawit Setan"
- " Kunyit seruas jari"
- "3 Kemiri"
- " Jahe seruas jari"
- " Bumbu tumis"
- "3 daun salam"
- "5 daun jeruk potong kecil"
- "2 batang sereh geprek"
- "1 ruas lengkoas geprek"
- "2 batang daun bawang"
- "3 ikat daun kemangi"
recipeinstructions:
- "Cuci besih ayam. lalu lumuri dengan kunyit dan garam. Diamkan 10 menit.."
- "Goreng Ayam (jangan sampai kering) lalu tiriskan"
- "Tumis semua bumbu halus sampai wangi. Lalu Masukan daun salam, sereh, lengkoas, daun jeruk. Aduk sampai layu"
- "Masukan ayam yg sudah di goreng tadi, beri sedikit air. Beri garam, penyedap rasa dan gula. Aduk sampai air menyusut"
- "Terakhir masukan daun bawang dan kemangi.. lalu siap di nikmati dengan nasi hangat"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 229 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT53M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/f67dba11b3bf4848/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang setidaknya kita jaga karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica rica kemangi yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan keistimewahan yang merupakan keragaman Indonesia



Kedekatan keluarga bisa diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam Rica Rica Kemangi untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang dapat anda praktekkan salah satunya ayam rica rica kemangi yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi:

1. Dibutuhkan 1 ekor Ayam potong 12
1. Siapkan 2 sdt Garam
1. Tambah 2 sdt penyedap rasa
1. Tambah 1 sdt gula
1. Jangan lupa  Bumbu Halus
1. Siapkan 7 Bawang merah
1. Tambah 5 Bawang putih
1. Tambah 8 Cabe merah
1. Siapkan 6 Cabe Rawit Setan
1. Diperlukan  Kunyit seruas jari
1. Harus ada 3 Kemiri
1. Siapkan  Jahe seruas jari
1. Harus ada  Bumbu tumis
1. Tambah 3 daun salam
1. Jangan lupa 5 daun jeruk (potong kecil)
1. Tambah 2 batang sereh (geprek)
1. Harus ada 1 ruas lengkoas (geprek)
1. Tambah 2 batang daun bawang
1. Dibutuhkan 3 ikat daun kemangi




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Rica Kemangi:

1. Cuci besih ayam. lalu lumuri dengan kunyit dan garam. Diamkan 10 menit..
1. Goreng Ayam (jangan sampai kering) lalu tiriskan
1. Tumis semua bumbu halus sampai wangi. Lalu Masukan daun salam, sereh, lengkoas, daun jeruk. Aduk sampai layu
1. Masukan ayam yg sudah di goreng tadi, beri sedikit air. Beri garam, penyedap rasa dan gula. Aduk sampai air menyusut
1. Terakhir masukan daun bawang dan kemangi.. lalu siap di nikmati dengan nasi hangat




Demikianlah cara membuat ayam rica rica kemangi yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan cepat, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
