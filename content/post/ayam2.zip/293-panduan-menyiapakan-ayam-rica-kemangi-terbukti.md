---
description: "Panduan menyiapakan Ayam Rica Kemangi Terbukti"
title: "Panduan menyiapakan Ayam Rica Kemangi Terbukti"
slug: 293-panduan-menyiapakan-ayam-rica-kemangi-terbukti
date: 2020-11-19T14:05:33.657Z
image: https://img-global.cpcdn.com/recipes/5257e2b72d22a465/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5257e2b72d22a465/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5257e2b72d22a465/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Owen Bush
ratingvalue: 4.6
reviewcount: 47881
recipeingredient:
- "1/2 kg ayam"
- "1 genggam kemangi diambil daunnya saja"
- "1 buah tomat hijau potong2"
- "3 batang sereh"
- "3 biji cabe hijau potong2"
- "2 helai daun jeruk"
- " Bumbu halus"
- "20 bj cabe merah keriting"
- "5 bj cabe rawit bisa di skip"
- "10 butir bawang merah"
- "3 butir bawang putih"
- "2 butir kemiri"
- "2 cm jahe"
- "1/2 sdt terasi bakar"
- "1/2 cm kunyit"
- "1/2 sdt kaldu jamur pengganti msg"
- "secukupnya Garam gula"
recipeinstructions:
- "Tumis bumbu halus dgn sedikit minyak goreng, tambahkan sereh, daun jeruk, tomat hijau."
- "Tambahkan 500 ml air, masukkan ayam. Masak sampai air menyusut. Kira2 40 menit. Test rasa"
- "Masukkan kemangi, aduk2 sebentar. Masakan bs diangkat"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 163 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/5257e2b72d22a465/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica kemangi yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa ciri khas yang merupakan keragaman Nusantara



Keharmonisan keluarga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Ayam Rica Kemangi untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang dapat anda contoh salah satunya ayam rica kemangi yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Dibutuhkan 1/2 kg ayam
1. Siapkan 1 genggam kemangi diambil daunnya saja
1. Diperlukan 1 buah tomat hijau potong2
1. Jangan lupa 3 batang sereh
1. Jangan lupa 3 biji cabe hijau potong2
1. Tambah 2 helai daun jeruk
1. Harus ada  Bumbu halus:
1. Jangan lupa 20 bj cabe merah keriting
1. Harus ada 5 bj cabe rawit (bisa di skip)
1. Siapkan 10 butir bawang merah
1. Siapkan 3 butir bawang putih
1. Jangan lupa 2 butir kemiri
1. Jangan lupa 2 cm jahe
1. Harap siapkan 1/2 sdt terasi bakar
1. Harap siapkan 1/2 cm kunyit
1. Diperlukan 1/2 sdt kaldu jamur (pengganti msg)
1. Tambah secukupnya Garam, gula




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Kemangi:

1. Tumis bumbu halus dgn sedikit minyak goreng, tambahkan sereh, daun jeruk, tomat hijau.
1. Tambahkan 500 ml air, masukkan ayam. Masak sampai air menyusut. Kira2 40 menit. Test rasa
1. Masukkan kemangi, aduk2 sebentar. Masakan bs diangkat




Demikianlah cara membuat ayam rica kemangi yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
