---
description: "Cara singkat menyiapakan Ayam rica rica kemangi teraktual"
title: "Cara singkat menyiapakan Ayam rica rica kemangi teraktual"
slug: 401-cara-singkat-menyiapakan-ayam-rica-rica-kemangi-teraktual
date: 2021-01-18T03:15:35.109Z
image: https://img-global.cpcdn.com/recipes/e9397bb8827c3cb7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e9397bb8827c3cb7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e9397bb8827c3cb7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Chris Logan
ratingvalue: 4.6
reviewcount: 36548
recipeingredient:
- "1/2 ekor Ayam"
- "3 batang sereh geprek"
- "1 cm lengkuas geprek"
- "1 cm jahe geprek"
- "3 lembar Daun salam"
- "3 lembar daun jeruk"
- "1 butir tomat irisbisa di skip"
- "secukupnya Kaldu jamurpenyedap"
- " Bumbu halus"
- "1 cm Kunyit"
- "6 siung Bawang merah"
- "3 siung Bawang putih"
- "sesuai selera Cabai"
- "3 butir Kemiri"
- "secukupnya Ketumbar dan lada"
- "1 buah jeruk nipis"
- "secukupnya Daun kemangi"
- "secukupnya Gula pasir  garam"
recipeinstructions:
- "Cuci bersih ayam dan beri perasan jeruk nipis, setelah 10 menit cuci lgi lalu goreng setengah matang"
- "Tumis bumbu halus,hingga harum"
- "Masukan sereh,lengkuas geprek juga daun salam dan daun jeruk"
- "Masukan ayam"
- "Aduk,lalu beri air secukupnya"
- "Setelah air menyusut,dan ayam empuk masukan daun kemangi"
- "Aduk sebentar dan matikan kompor,pindahkan ayam rica-rica ke mangkuk saji"
- "Ayam rica rica siap di nikmati 😊👌"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 160 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/e9397bb8827c3cb7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga renyah. Ciri khas makanan Nusantara ayam rica rica kemangi yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Kedekatan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam rica rica kemangi untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang dapat anda coba salah satunya ayam rica rica kemangi yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya sekarang ini anda bisa dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi:

1. Siapkan 1/2 ekor Ayam
1. Harap siapkan 3 batang sereh geprek
1. Siapkan 1 cm lengkuas geprek
1. Dibutuhkan 1 cm jahe geprek
1. Siapkan 3 lembar Daun salam
1. Dibutuhkan 3 lembar daun jeruk
1. Tambah 1 butir tomat iris(bisa di skip)
1. Siapkan secukupnya Kaldu jamur/penyedap
1. Dibutuhkan  Bumbu halus
1. Tambah 1 cm Kunyit
1. Harus ada 6 siung Bawang merah
1. Dibutuhkan 3 siung Bawang putih
1. Jangan lupa sesuai selera Cabai
1. Tambah 3 butir Kemiri
1. Harus ada secukupnya Ketumbar dan lada
1. Harus ada 1 buah jeruk nipis
1. Harus ada secukupnya Daun kemangi
1. Harap siapkan secukupnya Gula pasir + garam


Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Cara membuat  Ayam rica rica kemangi:

1. Cuci bersih ayam dan beri perasan jeruk nipis, setelah 10 menit cuci lgi lalu goreng setengah matang
1. Tumis bumbu halus,hingga harum
1. Masukan sereh,lengkuas geprek juga daun salam dan daun jeruk
1. Masukan ayam
1. Aduk,lalu beri air secukupnya
1. Setelah air menyusut,dan ayam empuk masukan daun kemangi
1. Aduk sebentar dan matikan kompor,pindahkan ayam rica-rica ke mangkuk saji
1. Ayam rica rica siap di nikmati 😊👌


Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Siapa yang tidak mengenal lalapan daun kemangi di Indonesia ini. Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. 

Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
