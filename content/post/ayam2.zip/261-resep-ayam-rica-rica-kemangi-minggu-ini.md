---
description: "Resep : Ayam rica-rica kemangi minggu ini"
title: "Resep : Ayam rica-rica kemangi minggu ini"
slug: 261-resep-ayam-rica-rica-kemangi-minggu-ini
date: 2021-01-22T05:30:34.468Z
image: https://img-global.cpcdn.com/recipes/f2b2474583d54e7f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f2b2474583d54e7f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f2b2474583d54e7f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Ruth Foster
ratingvalue: 4.8
reviewcount: 27375
recipeingredient:
- "6 potong ayam paha bawah"
- "5 daun jeruk"
- "3 daun salam"
- "1 ikat kemangi ambil daun nya aja"
- "1 batang sereh"
- "secukupnya laos"
- "secukupnya minyak goreng"
- "secukupnya garampenyedap rasa gula pasir"
- " bawang putih geprek utk merebus ayam"
- " jahe geprek utk merebus ayam"
- " jeruk nipis  secukupnya garam utk merebus ayam"
- " bumbu halus "
- "6 siung bawang merah"
- "3 siung bawang putih"
- "2 cm kunyit"
- "2 cm jahe"
- "2 kemiri"
- "15 rawit setan"
- "13 cabe kriting"
recipeinstructions:
- "Cuci bersih ayam kemudian masukan ayam ke dalam panci beri air secukupnya dan perasan jeruk nipis,garam,bawang putih geprek,jahe geprek agar ayam tdk bau amis dan cpt empuk yah moms. oiya biarkan ayam d rebus sampai mendidih angkat dan tiriskan"
- "Tuang secukupnya minyak goreng dan goreng ayam hingga setengah matang lalu tiriskan"
- "Sambil menunggu ayam d goreng haluskan bawang merah,bawang putih,jahe,kunyit,rawit serta cabe keriting menggunakan cobek / d blender.. kalo saya pakai blender yah moms biar cepet heheheh"
- "Setelah itu tumis bumbu halus sampai wangi / tanak lalu masukan daun jeruk,daun salam,sereh,laos dan beri sedikit air sambil d aduk2 yah moms setelah itu masukan ayam dan aduk2 agar bumbu merata dan tambahkan garam,gula,penyedap rasa kemudian biarkan biarkan meyusut airnya/mendidih"
- "Setelah air menyusut /mendidih masukan kemangi dan aduk2 sebentar kemudian cek rasa kalo sudah pas bisa langsung disajikan yah moms 😊"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 206 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT56M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/f2b2474583d54e7f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau renyah. Karasteristik masakan Indonesia ayam rica-rica kemangi yang kaya dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Kehangatan rumah tangga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Ayam rica-rica kemangi untuk keluarga. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang bisa anda buat salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica kemangi:

1. Dibutuhkan 6 potong ayam paha bawah
1. Tambah 5 daun jeruk
1. Diperlukan 3 daun salam
1. Tambah 1 ikat kemangi (ambil daun nya aja)
1. Harap siapkan 1 batang sereh
1. Harap siapkan secukupnya laos
1. Harap siapkan secukupnya minyak goreng
1. Jangan lupa secukupnya garam,penyedap rasa&amp; gula pasir
1. Harap siapkan  bawang putih geprek (utk merebus ayam
1. Harus ada  jahe geprek (utk merebus ayam)
1. Siapkan  jeruk nipis + secukupnya garam (utk merebus ayam)
1. Jangan lupa  bumbu halus :
1. Tambah 6 siung bawang merah
1. Harus ada 3 siung bawang putih
1. Tambah 2 cm kunyit
1. Jangan lupa 2 cm jahe
1. Diperlukan 2 kemiri
1. Harus ada 15 rawit setan
1. Harus ada 13 cabe kriting


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica-rica kemangi:

1. Cuci bersih ayam kemudian masukan ayam ke dalam panci beri air secukupnya dan perasan jeruk nipis,garam,bawang putih geprek,jahe geprek agar ayam tdk bau amis dan cpt empuk yah moms. oiya biarkan ayam d rebus sampai mendidih angkat dan tiriskan
1. Tuang secukupnya minyak goreng dan goreng ayam hingga setengah matang lalu tiriskan
1. Sambil menunggu ayam d goreng haluskan bawang merah,bawang putih,jahe,kunyit,rawit serta cabe keriting menggunakan cobek / d blender.. kalo saya pakai blender yah moms biar cepet heheheh
1. Setelah itu tumis bumbu halus sampai wangi / tanak lalu masukan daun jeruk,daun salam,sereh,laos dan beri sedikit air sambil d aduk2 yah moms setelah itu masukan ayam dan aduk2 agar bumbu merata dan tambahkan garam,gula,penyedap rasa kemudian biarkan biarkan meyusut airnya/mendidih
1. Setelah air menyusut /mendidih masukan kemangi dan aduk2 sebentar kemudian cek rasa kalo sudah pas bisa langsung disajikan yah moms 😊


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat simple dan cepat, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
