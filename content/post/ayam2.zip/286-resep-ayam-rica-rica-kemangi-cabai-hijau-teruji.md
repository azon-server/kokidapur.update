---
description: "Resep : Ayam rica rica kemangi cabai hijau Teruji"
title: "Resep : Ayam rica rica kemangi cabai hijau Teruji"
slug: 286-resep-ayam-rica-rica-kemangi-cabai-hijau-teruji
date: 2021-01-21T19:12:55.312Z
image: https://img-global.cpcdn.com/recipes/565faecf3eaf8550/751x532cq70/ayam-rica-rica-kemangi-cabai-hijau-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/565faecf3eaf8550/751x532cq70/ayam-rica-rica-kemangi-cabai-hijau-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/565faecf3eaf8550/751x532cq70/ayam-rica-rica-kemangi-cabai-hijau-foto-resep-utama.jpg
author: Donald Hayes
ratingvalue: 4.9
reviewcount: 47368
recipeingredient:
- "8 potong ayam"
- "4 lbr Daun jeruk"
- "2 Sereh"
- "secukupnya Kemangi"
- " Garam"
- " Gula"
- " Kaldu jamur"
- "gelas Minyak setengh"
- "1 Yang dhaluskan"
- "10 bawang merah"
- "4 bawang putih"
- "seruas Kunyit"
- "seruas Jahe"
- " Yang di blender kasar"
- "10 Cabai keriting"
- "20 Cabai rawit hijau"
recipeinstructions:
- "Campur bahan yg dihaluskan 1 dengan ayam, sereh, daun jeruk dan tambahkan minyak setgh gelas masak dengan api sedang"
- "Setelah airnya sat dan mengeluarkan minyak ayamnya,lalu masukan cabai yg dblender kasar, beri garam gula dan kaldu jamur koreksi rasa matikan api masukan kemangi.. aduk...dan sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 234 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam rica rica kemangi cabai hijau](https://img-global.cpcdn.com/recipes/565faecf3eaf8550/751x532cq70/ayam-rica-rica-kemangi-cabai-hijau-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica rica kemangi cabai hijau yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Kita



Kehangatan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah memasak Ayam rica rica kemangi cabai hijau untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang dapat anda buat salah satunya ayam rica rica kemangi cabai hijau yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep ayam rica rica kemangi cabai hijau tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi cabai hijau yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 2 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi cabai hijau:

1. Jangan lupa 8 potong ayam
1. Tambah 4 lbr Daun jeruk
1. Harus ada 2 Sereh
1. Diperlukan secukupnya Kemangi
1. Jangan lupa  Garam
1. Siapkan  Gula
1. Harap siapkan  Kaldu jamur
1. Dibutuhkan gelas Minyak setengh
1. Tambah 1 Yang dhaluskan
1. Harus ada 10 bawang merah
1. Harap siapkan 4 bawang putih
1. Tambah seruas Kunyit
1. Siapkan seruas Jahe
1. Dibutuhkan  Yang di blender kasar
1. Harus ada 10 Cabai keriting
1. Tambah 20 Cabai rawit hijau




<!--inarticleads2-->

##### Cara membuat  Ayam rica rica kemangi cabai hijau:

1. Campur bahan yg dihaluskan 1 dengan ayam, sereh, daun jeruk dan tambahkan minyak setgh gelas masak dengan api sedang
1. Setelah airnya sat dan mengeluarkan minyak ayamnya,lalu masukan cabai yg dblender kasar, beri garam gula dan kaldu jamur koreksi rasa matikan api masukan kemangi.. aduk...dan sajikan




Demikianlah cara membuat ayam rica rica kemangi cabai hijau yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan cepat, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
