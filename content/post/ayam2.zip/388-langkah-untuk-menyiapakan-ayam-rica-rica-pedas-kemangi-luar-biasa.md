---
description: "Langkah untuk menyiapakan Ayam Rica-rica Pedas Kemangi Luar biasa"
title: "Langkah untuk menyiapakan Ayam Rica-rica Pedas Kemangi Luar biasa"
slug: 388-langkah-untuk-menyiapakan-ayam-rica-rica-pedas-kemangi-luar-biasa
date: 2021-02-03T16:09:38.075Z
image: https://img-global.cpcdn.com/recipes/98027a2d07912a0c/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/98027a2d07912a0c/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/98027a2d07912a0c/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
author: Nelle Ball
ratingvalue: 5
reviewcount: 20026
recipeingredient:
- "1 Ekor ayam segar"
- "4 Batang serai"
- "5 Lembar daun salam"
- "5 Lembar daun jeruk"
- "2 Ruas jahe"
- "1 Ikat daun kemangi"
- "2 Ruas lengkuas"
- " Bumbu Halus"
- "1/2 Ruas kunyit"
- "6 Siung bawang merah"
- "3 Siung bawang putih"
- "2 Butir kemiri"
- " Cabai rawit sesuai selera"
- " Cabang merah kritingsesuai selera"
- " Bahan Tambahan"
- "1 Buah jeruk nipis"
- "1/4 Sendok teh garam"
- "1/2 Sendok teh gula"
- "1/4 Kaldu bubuk"
- " Minyak"
- " Air"
recipeinstructions:
- "Bersihkan ayam dengan jeruk nipis sampai bersih, siapkan air untuk merebus ayam (untuk menghilangkan kotoran yang tertinggal), tambahkan jahe, bawang putih, serai, di geprek untuk menghilangkan bau amis ayam"
- "Panaskan minyak goreng, tiriskan ayam rebusan lalu goreng asal (tidak terlalu kering)"
- "Panaskan kembali minyak goreng, tumis bumbu alus tambahkan jahe, lengkuas, serai yang di geprek + daun salam, daun jeruk. Tumis sampai harum."
- "Jika sudah harum masukan garam, gula, kaldu (cek rasa) lalu masukan ayam biarkan meresap dengan bumbu tambahkan air sedikit"
- "Kalo air sudah surut dan meresap masukan kemangi. Dan siap sajikan :)"
categories:
- Recipe
tags:
- ayam
- ricarica
- pedas

katakunci: ayam ricarica pedas 
nutrition: 158 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica-rica Pedas Kemangi](https://img-global.cpcdn.com/recipes/98027a2d07912a0c/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang setidaknya kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica-rica pedas kemangi yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan ciri khas yang merupakan keragaman Kita



Kehangatan keluarga bisa ditemukan dengan cara mudah. Salah satunya adalah memasak Ayam Rica-rica Pedas Kemangi untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang bisa anda praktekkan salah satunya ayam rica-rica pedas kemangi yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica-rica pedas kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Pedas Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Pedas Kemangi:

1. Jangan lupa 1 Ekor ayam segar
1. Harap siapkan 4 Batang serai
1. Harus ada 5 Lembar daun salam
1. Siapkan 5 Lembar daun jeruk
1. Dibutuhkan 2 Ruas jahe
1. Dibutuhkan 1 Ikat daun kemangi
1. Siapkan 2 Ruas lengkuas
1. Siapkan  Bumbu Halus
1. Siapkan 1/2 Ruas kunyit
1. Siapkan 6 Siung bawang merah
1. Jangan lupa 3 Siung bawang putih
1. Tambah 2 Butir kemiri
1. Harap siapkan  Cabai rawit (sesuai selera)
1. Harap siapkan  Cabang merah kriting(sesuai selera)
1. Siapkan  Bahan Tambahan
1. Harus ada 1 Buah jeruk nipis
1. Tambah 1/4 Sendok teh garam
1. Harap siapkan 1/2 Sendok teh gula
1. Harap siapkan 1/4 Kaldu bubuk
1. Harap siapkan  Minyak
1. Jangan lupa  Air




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-rica Pedas Kemangi:

1. Bersihkan ayam dengan jeruk nipis sampai bersih, siapkan air untuk merebus ayam (untuk menghilangkan kotoran yang tertinggal), tambahkan jahe, bawang putih, serai, di geprek untuk menghilangkan bau amis ayam
1. Panaskan minyak goreng, tiriskan ayam rebusan lalu goreng asal (tidak terlalu kering)
1. Panaskan kembali minyak goreng, tumis bumbu alus tambahkan jahe, lengkuas, serai yang di geprek + daun salam, daun jeruk. Tumis sampai harum.
1. Jika sudah harum masukan garam, gula, kaldu (cek rasa) lalu masukan ayam biarkan meresap dengan bumbu tambahkan air sedikit
1. Kalo air sudah surut dan meresap masukan kemangi. Dan siap sajikan :)




Demikianlah cara membuat ayam rica-rica pedas kemangi yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan terbukti, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
