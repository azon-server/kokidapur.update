---
description: "Panduan untuk membuat Ayam Rica Rica Kemangi Favorite"
title: "Panduan untuk membuat Ayam Rica Rica Kemangi Favorite"
slug: 225-panduan-untuk-membuat-ayam-rica-rica-kemangi-favorite
date: 2020-09-19T07:05:16.198Z
image: https://img-global.cpcdn.com/recipes/1d1e8a7c5727d3a1/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1d1e8a7c5727d3a1/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1d1e8a7c5727d3a1/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Dorothy Miller
ratingvalue: 5
reviewcount: 28215
recipeingredient:
- "1 ekor ayam Potong2"
- "1 iket kemangi"
- "2 sdm perasan jeruk nipis"
- "1 buah tomat"
- " Bumbu Halus"
- "10 cabe rawit setan"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "4 buah kemiri"
- "2 ruas kunyit"
- "1 ruas jahe"
- " Bumbu Pelengkap"
- "2 lbr daun salam"
- "2 lbr sereh"
- "1 ruas lengkuas"
- "2 lbr daun jeruk"
- "1 sdm kecap"
- " Minyak utk menumis"
- "secukupnya Merica garam penyedap gula"
recipeinstructions:
- "Ayam yg tlah dipotong2 cuci bersih, lumuri perasan jeruk nipis. Sisihkan.."
- "Siapkan wajan beri minyak secukupnya, tumis bumbu halus hingga harus. Masukan salam, sereh, daun jeruk, lengkuas digeprek,"
- "Masukan ayam, tambahkan sedikit air, masukan bumbu pelengkap, merica, garam, kecap, gula, penyedap. Aduk2,, biarkan matang dan air sedikit menyusut."
- "Setelah ayam empuk, cek rasa, masukan kemangi dan tomat yg sudah diiris jd 6. aduk sebentar, angkat sajikan. Selamat mencoba.. 😊👩‍🍳👩‍🍳"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 138 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/1d1e8a7c5727d3a1/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau enak. Ciri masakan Nusantara ayam rica rica kemangi yang penuh dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga dapat diperoleh dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica Rica Kemangi untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang bisa anda contoh salah satunya ayam rica rica kemangi yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi:

1. Siapkan 1 ekor ayam. Potong2
1. Harap siapkan 1 iket kemangi
1. Siapkan 2 sdm perasan jeruk nipis
1. Harap siapkan 1 buah tomat
1. Diperlukan  Bumbu Halus
1. Harus ada 10 cabe rawit setan
1. Diperlukan 8 siung bawang merah
1. Harap siapkan 5 siung bawang putih
1. Harus ada 4 buah kemiri
1. Jangan lupa 2 ruas kunyit
1. Harap siapkan 1 ruas jahe
1. Jangan lupa  Bumbu Pelengkap
1. Diperlukan 2 lbr daun salam
1. Tambah 2 lbr sereh
1. Harap siapkan 1 ruas lengkuas
1. Dibutuhkan 2 lbr daun jeruk
1. Dibutuhkan 1 sdm kecap
1. Diperlukan  Minyak utk menumis
1. Dibutuhkan secukupnya Merica, garam, penyedap, gula




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica Kemangi:

1. Ayam yg tlah dipotong2 cuci bersih, lumuri perasan jeruk nipis. Sisihkan..
1. Siapkan wajan beri minyak secukupnya, tumis bumbu halus hingga harus. Masukan salam, sereh, daun jeruk, lengkuas digeprek,
1. Masukan ayam, tambahkan sedikit air, masukan bumbu pelengkap, merica, garam, kecap, gula, penyedap. Aduk2,, biarkan matang dan air sedikit menyusut.
1. Setelah ayam empuk, cek rasa, masukan kemangi dan tomat yg sudah diiris jd 6. aduk sebentar, angkat sajikan. Selamat mencoba.. 😊👩‍🍳👩‍🍳




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan cepat, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
