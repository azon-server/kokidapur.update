---
description: "Resep : Ayam Geprek Bensu Terbukti"
title: "Resep : Ayam Geprek Bensu Terbukti"
slug: 79-resep-ayam-geprek-bensu-terbukti
date: 2021-01-21T16:20:48.540Z
image: https://img-global.cpcdn.com/recipes/6ae4f648b30ea7f2/751x532cq70/ayam-geprek-bensu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6ae4f648b30ea7f2/751x532cq70/ayam-geprek-bensu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6ae4f648b30ea7f2/751x532cq70/ayam-geprek-bensu-foto-resep-utama.jpg
author: Kate Morales
ratingvalue: 4.3
reviewcount: 30025
recipeingredient:
- "1/4 kg Ayam Fillet bisa ayam uth potong"
- " Adonan Basah"
- "1 butir Putih Telor"
- "5 sdm tepung terigu"
- "1 butir Bawang Putih haluskan"
- "Secukupnya merica"
- "Secukupnya Garam jangan terlalu banyak"
- "Secukupnya Kaldu Bubuk"
- " Adonan Kering"
- "150 gr tepung terigu"
- "1/2 sdm Maizena"
- "1/2 sdm Tepung Beras"
- "1/4 Baking Powder"
- "Secukupnya kaldu Bubuk saya 1 sdt"
- "Secukupnya garam saya 1 sdt"
- "1 sdt Bubuk Bawang Putih boleh skip saya skip"
- " Bahan Sambal Geprek"
- "50 gr Cabe Rawit Merah"
- "3 siung Bawang Merah iris halus"
- "5 siung Bawang putih geprek"
- "1 sdt Kaldu Bubuk"
- "Secukupnya garam"
- "Secukupnya gula"
- "Sedikit air"
- " Bahan Pelengkap"
- " TahuTempe Goreng"
- " Kemangi"
- " Kol Goreng"
- " Tomat"
- " Ketimun"
- " Jeruk limo"
- " Mozzarella"
recipeinstructions:
- "Campurkan semua adonan basah di satu wadah"
- "Bersihkan ayam lalu sayat2 dan masukkan ke dalam adonan basah, diamkan sebentar hingga bumbu agak meresap. Sambil menunggu kita lanjut ke adonan kering"
- "Campur semua bahan adonan kering di wadah lain, sisihkan, sambil panaskan minyak"
- "Ayam di adonan basah cemplungkan ke adonan kering sambil cubit2 lalu masukkan lg ke adonan basah dan kembali ke adonan kering lagi cubit2 (sampai ayam habis) lalu masukkan ke minyak panas (agak banyak (ayam terendam)api kecil sedang saja ya, biar dalamnya matang lakukan sampai ayam habis, sisihkan"
- "Kita mulai di bagian sambal ya, ulek kasar cabe rawit"
- "Goreng sebentar hingga layu dan sedikit kecoklatan bawang merah dan bawang putih (saya gorengnya pisah2 ya dibuat satu satu) dengan sedikit minyak, setelah layu masukkan ke ulekan sambal tadi lalu ulek sebentar hingga rata tapi jgan terlalu halus ya uleknya"
- "Tekstur sambal sedikit berair tapi tetap berminyak ya mom"
- "Setelah semua bahan di ulek, kita tumis sebentar sambalnya td lalu beri garam, gula dan kaldu bubuk. Setelah itu beri sedikit air ya, tes rasa jika sudah pas tunggu air menyusut sedikit"
- "Selamat mencoba, bisa tambahkan keju atau perasan jeruk limo di atas sambqlnya biar makin seger pedes"
categories:
- Recipe
tags:
- ayam
- geprek
- bensu

katakunci: ayam geprek bensu 
nutrition: 124 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Geprek Bensu](https://img-global.cpcdn.com/recipes/6ae4f648b30ea7f2/751x532cq70/ayam-geprek-bensu-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang harus kita lestarikan karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam geprek bensu yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara



Keharmonisan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Geprek Bensu untuk keluarga. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang dapat anda contoh salah satunya ayam geprek bensu yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam geprek bensu tanpa harus bersusah payah.
Seperti resep Ayam Geprek Bensu yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 32 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Bensu:

1. Harap siapkan 1/4 kg Ayam Fillet (bisa ayam uth potong)
1. Diperlukan  Adonan Basah:
1. Harap siapkan 1 butir Putih Telor
1. Harus ada 5 sdm tepung terigu
1. Harap siapkan 1 butir Bawang Putih (haluskan)
1. Jangan lupa Secukupnya merica
1. Dibutuhkan Secukupnya Garam (jangan terlalu banyak)
1. Diperlukan Secukupnya Kaldu Bubuk
1. Tambah  Adonan Kering:
1. Jangan lupa 150 gr tepung terigu
1. Dibutuhkan 1/2 sdm Maizena
1. Harap siapkan 1/2 sdm Tepung Beras
1. Tambah 1/4 Baking Powder
1. Tambah Secukupnya kaldu Bubuk (saya 1 sdt)
1. Diperlukan Secukupnya garam (saya 1 sdt)
1. Dibutuhkan 1 sdt Bubuk Bawang Putih (boleh skip, saya skip)
1. Dibutuhkan  Bahan Sambal Geprek:
1. Jangan lupa 50 gr Cabe Rawit Merah
1. Tambah 3 siung Bawang Merah (iris halus)
1. Siapkan 5 siung Bawang putih (geprek)
1. Harap siapkan 1 sdt Kaldu Bubuk
1. Harap siapkan Secukupnya garam
1. Dibutuhkan Secukupnya gula
1. Jangan lupa Sedikit air
1. Harap siapkan  Bahan Pelengkap:
1. Jangan lupa  Tahu/Tempe Goreng
1. Harap siapkan  Kemangi
1. Diperlukan  Kol Goreng
1. Diperlukan  Tomat
1. Jangan lupa  Ketimun
1. Siapkan  Jeruk limo
1. Harap siapkan  Mozzarella




<!--inarticleads2-->

##### Cara membuat  Ayam Geprek Bensu:

1. Campurkan semua adonan basah di satu wadah
1. Bersihkan ayam lalu sayat2 dan masukkan ke dalam adonan basah, diamkan sebentar hingga bumbu agak meresap. Sambil menunggu kita lanjut ke adonan kering
1. Campur semua bahan adonan kering di wadah lain, sisihkan, sambil panaskan minyak
1. Ayam di adonan basah cemplungkan ke adonan kering sambil cubit2 lalu masukkan lg ke adonan basah dan kembali ke adonan kering lagi cubit2 (sampai ayam habis) lalu masukkan ke minyak panas (agak banyak (ayam terendam)api kecil sedang saja ya, biar dalamnya matang lakukan sampai ayam habis, sisihkan
1. Kita mulai di bagian sambal ya, ulek kasar cabe rawit
1. Goreng sebentar hingga layu dan sedikit kecoklatan bawang merah dan bawang putih (saya gorengnya pisah2 ya dibuat satu satu) dengan sedikit minyak, setelah layu masukkan ke ulekan sambal tadi lalu ulek sebentar hingga rata tapi jgan terlalu halus ya uleknya
1. Tekstur sambal sedikit berair tapi tetap berminyak ya mom
1. Setelah semua bahan di ulek, kita tumis sebentar sambalnya td lalu beri garam, gula dan kaldu bubuk. Setelah itu beri sedikit air ya, tes rasa jika sudah pas tunggu air menyusut sedikit
1. Selamat mencoba, bisa tambahkan keju atau perasan jeruk limo di atas sambqlnya biar makin seger pedes




Demikianlah cara membuat ayam geprek bensu yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
