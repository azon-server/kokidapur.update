---
description: "Steps membuat Ayam Rica Kemangi minggu ini"
title: "Steps membuat Ayam Rica Kemangi minggu ini"
slug: 400-steps-membuat-ayam-rica-kemangi-minggu-ini
date: 2020-09-27T06:29:31.458Z
image: https://img-global.cpcdn.com/recipes/8476f8b73fd4444d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8476f8b73fd4444d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8476f8b73fd4444d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Sylvia Lyons
ratingvalue: 5
reviewcount: 37787
recipeingredient:
- " ayam bagian dada"
- " daun kemangi"
- " bumbu halus"
- "5 bawang merah"
- "3 bawang putih"
- "1 bh kemiri"
- " kunyit"
- " jahe"
- " cabe rawitcabe merah keriting"
- " ketumbar"
- " lada bubuk"
- " lengkuassereh geprek"
- " daun salamdaun jeruk"
- " garamgula merah penyedap"
recipeinstructions:
- "Ungkep ayam dg bumbu kuning lalu goreng matang. jgn kematangan biar tdk keras"
- "Tumis semua bumbu rempah dg cukup minyak.. tumis sampai harum dan matang yaah"
- "Tmbahkan sedikit air dan bumbui sambil diicip sampai rasanya oke, baru masukan ayam"
- "Setelah dirasa bumbunya cukup meresap didlm ayam. terakhir masukan daun kemangi dan aduk sebentar saja"
- "Matikan api 🔥 dan sajikan dg nasi hangat.."
- "Selamat mencoba"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 197 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/8476f8b73fd4444d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang setidaknya kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica kemangi yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Indonesia

Kehangatan keluarga dapat didapat dengan cara simple. Diantaranya adalah memasak Ayam Rica Kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang dapat anda buat salah satunya ayam rica kemangi yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 14 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Harap siapkan  ayam bagian dada
1. Jangan lupa  daun kemangi
1. Diperlukan  bumbu halus:
1. Harap siapkan 5 bawang merah
1. Harus ada 3 bawang putih
1. Tambah 1 bh kemiri
1. Tambah  kunyit
1. Diperlukan  jahe
1. Tambah  cabe rawit+cabe merah keriting
1. Jangan lupa  ketumbar
1. Dibutuhkan  lada bubuk
1. Diperlukan  lengkuas+sereh geprek
1. Siapkan  daun salam+daun jeruk
1. Diperlukan  garam,gula merah, penyedap


Perlu kamu ketahui bahwa di luar negeri mungkin daun basil sangat terkenal untuk campuran makanan. Akan tetapi, di Indonesia juga memiliki daun kemangi merupakan. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. 

<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Kemangi:

1. Ungkep ayam dg bumbu kuning lalu goreng matang. jgn kematangan biar tdk keras
1. Tumis semua bumbu rempah dg cukup minyak.. tumis sampai harum dan matang yaah
1. Tmbahkan sedikit air dan bumbui sambil diicip sampai rasanya oke, baru masukan ayam
1. Setelah dirasa bumbunya cukup meresap didlm ayam. terakhir masukan daun kemangi dan aduk sebentar saja
1. Matikan api 🔥 dan sajikan dg nasi hangat..
1. Selamat mencoba


Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. Cara Membuat Ayam Rica Rica Kemangi. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat. 

Demikianlah cara membuat ayam rica kemangi yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan terbukti, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
