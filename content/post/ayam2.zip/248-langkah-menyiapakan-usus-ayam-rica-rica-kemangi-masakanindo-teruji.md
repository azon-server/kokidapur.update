---
description: "Langkah menyiapakan Usus Ayam Rica Rica Kemangi #masakanindo 🇮🇩 Teruji"
title: "Langkah menyiapakan Usus Ayam Rica Rica Kemangi #masakanindo 🇮🇩 Teruji"
slug: 248-langkah-menyiapakan-usus-ayam-rica-rica-kemangi-masakanindo-teruji
date: 2020-09-20T03:02:40.243Z
image: https://img-global.cpcdn.com/recipes/757da5a6b184ccab/751x532cq70/usus-ayam-rica-rica-kemangi-masakanindo-🇮🇩-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/757da5a6b184ccab/751x532cq70/usus-ayam-rica-rica-kemangi-masakanindo-🇮🇩-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/757da5a6b184ccab/751x532cq70/usus-ayam-rica-rica-kemangi-masakanindo-🇮🇩-foto-resep-utama.jpg
author: Jerry Munoz
ratingvalue: 4.4
reviewcount: 34649
recipeingredient:
- " Bahan rebus"
- "Secukupnya usus"
- "4 lembar daun salam"
- "1 ruas lengkuas"
- "1 ruas jahe"
- " Bumbu halus"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "8 buah cabe merah keriting boleh ditambah kurang"
- "6 buah cabe rawit merah boleh ditambah kurang"
- "1/2 ruas kunyit"
- "2 butir kemiri"
- " Tumisan bumbu"
- "3 lembar daun salam"
- "5 lembar daun jeruk"
- "1 ruas lengkuas geprek"
- "4 batang serai geprek"
- "1 sdt garam"
- "1 sdt gula"
- "1 sdt penyedap aku royco sapi"
- "Secukupnya daun kemangi"
- "Secukupnya air matang"
recipeinstructions:
- "Bersihkan usus sampai benar2 bersih supaya tidak bau. Lalu potong2, dan rebus dengan daun salam, lengkuas, jahe (kira2 10-15 menit). Lalu goreng sampai matang. Tiriskan."
- "Blender bumbu halus, tambahkan sedikit air supaya ga susah."
- "Tumis bumbu halus. Tambahkan serai, lengkuas, jahe, daun jeruk, daun salam, garam, gula dan bubuk penyedap + secukupnya air matang. Masak sampai harum dan matang. Test rasa. Kalo kurang, tambahkan lagi gula garamnya."
- "Masukkan usus dan daun kemangi. Aduk rata dan masak sampai matang, dan daunnya layu."
- "Jadi deh❤❤ Aku tambahin telor puyuh ya. Berhubung ada sisa dari rebusan. Hehehe"
- "Ini enak dimakan pakai jenis2 sayur santan🥰"
categories:
- Recipe
tags:
- usus
- ayam
- rica

katakunci: usus ayam rica 
nutrition: 211 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dessert

---


![Usus Ayam Rica Rica Kemangi #masakanindo 🇮🇩](https://img-global.cpcdn.com/recipes/757da5a6b184ccab/751x532cq70/usus-ayam-rica-rica-kemangi-masakanindo-🇮🇩-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang dapat kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti usus ayam rica rica kemangi #masakanindo 🇮🇩 yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Nusantara



Kedekatan rumah tangga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Usus Ayam Rica Rica Kemangi #masakanindo 🇮🇩 untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang bisa anda contoh salah satunya usus ayam rica rica kemangi #masakanindo 🇮🇩 yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep usus ayam rica rica kemangi #masakanindo 🇮🇩 tanpa harus bersusah payah.
Berikut ini resep Usus Ayam Rica Rica Kemangi #masakanindo 🇮🇩 yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Usus Ayam Rica Rica Kemangi #masakanindo 🇮🇩:

1. Dibutuhkan  Bahan rebus
1. Tambah Secukupnya usus
1. Siapkan 4 lembar daun salam
1. Siapkan 1 ruas lengkuas
1. Tambah 1 ruas jahe
1. Siapkan  Bumbu halus
1. Siapkan 6 siung bawang merah
1. Jangan lupa 3 siung bawang putih
1. Jangan lupa 8 buah cabe merah keriting (boleh ditambah kurang)
1. Harap siapkan 6 buah cabe rawit merah (boleh ditambah kurang)
1. Harap siapkan 1/2 ruas kunyit
1. Siapkan 2 butir kemiri
1. Siapkan  Tumisan bumbu
1. Jangan lupa 3 lembar daun salam
1. Harap siapkan 5 lembar daun jeruk
1. Dibutuhkan 1 ruas lengkuas (geprek)
1. Harus ada 4 batang serai (geprek)
1. Harap siapkan 1 sdt garam
1. Diperlukan 1 sdt gula
1. Siapkan 1 sdt penyedap (aku royco sapi)
1. Dibutuhkan Secukupnya daun kemangi
1. Harap siapkan Secukupnya air matang




<!--inarticleads2-->

##### Cara membuat  Usus Ayam Rica Rica Kemangi #masakanindo 🇮🇩:

1. Bersihkan usus sampai benar2 bersih supaya tidak bau. Lalu potong2, dan rebus dengan daun salam, lengkuas, jahe (kira2 10-15 menit). Lalu goreng sampai matang. Tiriskan.
1. Blender bumbu halus, tambahkan sedikit air supaya ga susah.
1. Tumis bumbu halus. Tambahkan serai, lengkuas, jahe, daun jeruk, daun salam, garam, gula dan bubuk penyedap + secukupnya air matang. Masak sampai harum dan matang. Test rasa. Kalo kurang, tambahkan lagi gula garamnya.
1. Masukkan usus dan daun kemangi. Aduk rata dan masak sampai matang, dan daunnya layu.
1. Jadi deh❤❤ Aku tambahin telor puyuh ya. Berhubung ada sisa dari rebusan. Hehehe
1. Ini enak dimakan pakai jenis2 sayur santan🥰




Demikianlah cara membuat usus ayam rica rica kemangi #masakanindo 🇮🇩 yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan teruji, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
