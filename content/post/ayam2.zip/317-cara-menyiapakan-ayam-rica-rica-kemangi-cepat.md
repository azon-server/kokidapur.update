---
description: "Cara menyiapakan Ayam rica rica kemangi Cepat"
title: "Cara menyiapakan Ayam rica rica kemangi Cepat"
slug: 317-cara-menyiapakan-ayam-rica-rica-kemangi-cepat
date: 2021-01-22T05:59:24.914Z
image: https://img-global.cpcdn.com/recipes/d0476142d25a841c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d0476142d25a841c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d0476142d25a841c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Katherine Patterson
ratingvalue: 4.9
reviewcount: 20408
recipeingredient:
- "1/2 ekor ayam potong sesuai selera"
- "1 buah jeruk nipis peraa airnya"
- "1 batang sereh digeprek"
- "3 ruas lengkuas digeprek"
- "2 ruas jahe digeprek"
- "1 lembar daun salam"
- "2 lembar daun jeruk"
- "6 buah rawit dipotong serong"
- "1 genggam kemangi"
- "250 ml air"
- "secukupnya garam"
- " minyak goreng secukupnua"
- " Bumbu halus"
- "4 buah cabe merah"
- "4 buah cabe hijau"
- "5 siung bawang putih"
- "4 butir bawang merah"
- "3 ruas kunyit"
- "2 butir kemiri"
recipeinstructions:
- "Cuci bersih ayam, kucuri dengan air jeruk nipis, diamkan selama 20menit, cuci kembali"
- "Panaskan minyak, tumis bumbu halus beserta cabe rawit, jahe, lengkuas, daun jeruk, daun salam sampai wangi, tambahkan air, garam, masak sampai mendidih"
- "Masukan ayam, aduk rata, masak sampai bumbu meresap"
- "Tambahkan kemangi, masak sampai kemangi layu"
- "Koreksi rasa, angkat, dan sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 184 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/d0476142d25a841c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica rica kemangi yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa kesan tersendiri yang merupakan keragaman Indonesia



Kedekatan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah membuat makanan Ayam rica rica kemangi untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi makanan yang bisa anda buat salah satunya ayam rica rica kemangi yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi:

1. Siapkan 1/2 ekor ayam potong sesuai selera
1. Tambah 1 buah jeruk nipis peraa airnya
1. Harus ada 1 batang sereh digeprek
1. Tambah 3 ruas lengkuas digeprek
1. Harus ada 2 ruas jahe digeprek
1. Harap siapkan 1 lembar daun salam
1. Harap siapkan 2 lembar daun jeruk
1. Dibutuhkan 6 buah rawit dipotong serong
1. Dibutuhkan 1 genggam kemangi
1. Tambah 250 ml air
1. Diperlukan secukupnya garam
1. Harap siapkan  minyak goreng secukupnua
1. Harus ada  Bumbu halus
1. Diperlukan 4 buah cabe merah
1. Tambah 4 buah cabe hijau
1. Jangan lupa 5 siung bawang putih
1. Diperlukan 4 butir bawang merah
1. Tambah 3 ruas kunyit
1. Jangan lupa 2 butir kemiri




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica rica kemangi:

1. Cuci bersih ayam, kucuri dengan air jeruk nipis, diamkan selama 20menit, cuci kembali
1. Panaskan minyak, tumis bumbu halus beserta cabe rawit, jahe, lengkuas, daun jeruk, daun salam sampai wangi, tambahkan air, garam, masak sampai mendidih
1. Masukan ayam, aduk rata, masak sampai bumbu meresap
1. Tambahkan kemangi, masak sampai kemangi layu
1. Koreksi rasa, angkat, dan sajikan




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
