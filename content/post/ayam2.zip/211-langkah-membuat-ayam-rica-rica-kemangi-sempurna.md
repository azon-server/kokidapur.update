---
description: "Langkah membuat Ayam rica-rica kemangi Sempurna"
title: "Langkah membuat Ayam rica-rica kemangi Sempurna"
slug: 211-langkah-membuat-ayam-rica-rica-kemangi-sempurna
date: 2020-09-06T23:26:43.498Z
image: https://img-global.cpcdn.com/recipes/5c2a007f00314a27/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5c2a007f00314a27/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5c2a007f00314a27/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Hannah Osborne
ratingvalue: 5
reviewcount: 47829
recipeingredient:
- "500 grm ayam"
- "900 ml santan"
- "1 ikat kemangi"
- "2 btg serai"
- "3 lmbr daun jeruk"
- "1 lmbr daun salam"
- " Minyak untuk menggoreng"
- " Bumbu halus "
- "5 butir bawang merah"
- "3 siung bawang putih"
- "3 buah cabe merah"
- "10 buah cabe rawit"
- "3 butir kemiri sangrai"
- "2 cm kunyit"
- "2 cm jahe"
- "1/2 sdt ketumbar"
recipeinstructions:
- "Cuci bersih ayam kemudian rebus hingga setengah matang angkat dan tiriskn"
- "Goreng ayam tidak sampai garing kemudian sisihkan."
- "Blender bumbu halus kemudia masak di atas wajan dan masukkan serai,daun salam,daun jeruk dan masak hingga tanak."
- "Masukkan ayam ke dalam bumbu masukkan garam,gula dan penyedap rasa dan tmbahkan santan."
- "Masak hingga kuah santan agak menyusut perbarui rasa dan masukkan kemangi yang sudah di cuci dan di siangi."
- "Aduk hingga agak layu kemanginya ayam rica siap di sajikan."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 275 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/5c2a007f00314a27/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang harus kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica-rica kemangi yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Nusantara

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Kehangatan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Ayam rica-rica kemangi untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang dapat anda buat salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica kemangi:

1. Siapkan 500 grm ayam
1. Jangan lupa 900 ml santan
1. Jangan lupa 1 ikat kemangi
1. Siapkan 2 btg serai
1. Harus ada 3 lmbr daun jeruk
1. Diperlukan 1 lmbr daun salam
1. Harus ada  Minyak untuk menggoreng
1. Siapkan  Bumbu halus :
1. Tambah 5 butir bawang merah
1. Harap siapkan 3 siung bawang putih
1. Harus ada 3 buah cabe merah
1. Jangan lupa 10 buah cabe rawit
1. Siapkan 3 butir kemiri sangrai
1. Diperlukan 2 cm kunyit
1. Harus ada 2 cm jahe
1. Dibutuhkan 1/2 sdt ketumbar


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Cara membuat  Ayam rica-rica kemangi:

1. Cuci bersih ayam kemudian rebus hingga setengah matang angkat dan tiriskn
1. Goreng ayam tidak sampai garing kemudian sisihkan.
1. Blender bumbu halus kemudia masak di atas wajan dan masukkan serai,daun salam,daun jeruk dan masak hingga tanak.
1. Masukkan ayam ke dalam bumbu masukkan garam,gula dan penyedap rasa dan tmbahkan santan.
1. Masak hingga kuah santan agak menyusut perbarui rasa dan masukkan kemangi yang sudah di cuci dan di siangi.
1. Aduk hingga agak layu kemanginya ayam rica siap di sajikan.


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan terbukti, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
