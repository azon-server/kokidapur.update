---
description: "Resep : Ayam Rica Daun Kemangi (No Oil) teraktual"
title: "Resep : Ayam Rica Daun Kemangi (No Oil) teraktual"
slug: 407-resep-ayam-rica-daun-kemangi-no-oil-teraktual
date: 2021-02-02T17:26:21.090Z
image: https://img-global.cpcdn.com/recipes/c2fa11b97355d013/751x532cq70/ayam-rica-daun-kemangi-no-oil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c2fa11b97355d013/751x532cq70/ayam-rica-daun-kemangi-no-oil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c2fa11b97355d013/751x532cq70/ayam-rica-daun-kemangi-no-oil-foto-resep-utama.jpg
author: Brandon Ramos
ratingvalue: 4.6
reviewcount: 30185
recipeingredient:
- "400 gr Dada Ayam Tanpa Tulang"
- " Bumbu Halus"
- "1 Ruas Kunyit"
- "1 Ruas Lengkuas"
- "7 Butir Bawang Merah"
- "4 Butir Bawang Putih"
- "8 Buah Cabe Merah"
- "5 Buah Cabe Rawit"
- " Bahan Lainnya"
- "1 Lembar Daun Salam"
- "2 Lembar Daun Jeruk"
- "1 Batang Sereh"
- " Gula"
- " Garam"
- " Totole Kaldu Jamur"
- " Kecap Manis"
- " Daun Kemangi"
recipeinstructions:
- "Bumbu yang sudah dihaluskan + Daun Salam,Daun Jeruk, Sereh di sangrai aja sampai wangi dan airnya surut"
- "Tambahkan Daging Ayam kemudian aduk sebentar dengan bumbu hingga tercampur, tambahkan air secukupnya, karena aku maunya agak berkuah jadi kumasukin airnya agak banyak"
- "Tambahkan Garam,Gula,Totole Kaldu Jamur dan Kecap manis sedikit sampai warnanya kecoklatan"
- "Tunggu ayam sampai matang, masukkan daun kemangi dan masak sampai daun kemangi layu"
categories:
- Recipe
tags:
- ayam
- rica
- daun

katakunci: ayam rica daun 
nutrition: 286 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica Daun Kemangi (No Oil)](https://img-global.cpcdn.com/recipes/c2fa11b97355d013/751x532cq70/ayam-rica-daun-kemangi-no-oil-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga enak. Karasteristik kuliner Nusantara ayam rica daun kemangi (no oil) yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kehangatan rumah tangga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Ayam Rica Daun Kemangi (No Oil) untuk orang di rumah. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang dapat anda praktekkan salah satunya ayam rica daun kemangi (no oil) yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep ayam rica daun kemangi (no oil) tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Daun Kemangi (No Oil) yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Daun Kemangi (No Oil):

1. Dibutuhkan 400 gr Dada Ayam Tanpa Tulang
1. Harus ada  Bumbu Halus
1. Siapkan 1 Ruas Kunyit
1. Tambah 1 Ruas Lengkuas
1. Dibutuhkan 7 Butir Bawang Merah
1. Harus ada 4 Butir Bawang Putih
1. Jangan lupa 8 Buah Cabe Merah
1. Harap siapkan 5 Buah Cabe Rawit
1. Tambah  Bahan Lainnya
1. Harap siapkan 1 Lembar Daun Salam
1. Dibutuhkan 2 Lembar Daun Jeruk
1. Harus ada 1 Batang Sereh
1. Harus ada  Gula
1. Jangan lupa  Garam
1. Dibutuhkan  Totole Kaldu Jamur
1. Diperlukan  Kecap Manis
1. Siapkan  Daun Kemangi




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Daun Kemangi (No Oil):

1. Bumbu yang sudah dihaluskan + Daun Salam,Daun Jeruk, Sereh di sangrai aja sampai wangi dan airnya surut
1. Tambahkan Daging Ayam kemudian aduk sebentar dengan bumbu hingga tercampur, tambahkan air secukupnya, karena aku maunya agak berkuah jadi kumasukin airnya agak banyak
1. Tambahkan Garam,Gula,Totole Kaldu Jamur dan Kecap manis sedikit sampai warnanya kecoklatan
1. Tunggu ayam sampai matang, masukkan daun kemangi dan masak sampai daun kemangi layu




Demikianlah cara membuat ayam rica daun kemangi (no oil) yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
