---
description: "Resep : Ayam Geprek Cepat"
title: "Resep : Ayam Geprek Cepat"
slug: 133-resep-ayam-geprek-cepat
date: 2020-11-10T20:02:35.158Z
image: https://img-global.cpcdn.com/recipes/5518d57fc51279f3/751x532cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5518d57fc51279f3/751x532cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5518d57fc51279f3/751x532cq70/ayam-geprek-foto-resep-utama.jpg
author: Stella Hammond
ratingvalue: 4.2
reviewcount: 22122
recipeingredient:
- "3 potong ayam"
- "7 buah cabai merah"
- "1 buah bawang putih"
- "15 sdm tepung terigu"
- "1 sdt backing powder"
- "15 sdm tepung bumbu"
- " Air es"
- "1 butir telur ayam"
- "1 sdm garam"
- "1 sdt gula pasir"
recipeinstructions:
- "Siapkan 3 wadah untuk adonan basah, adonan kering, dan telur"
- "Buat adonan basah yg terdiri dari tepung terigu, backing powder, dan air es"
- "Adonan kering terdiri dari tepung bumbu saja"
- "Jangan lupa kocok 1 buah telur"
- "Di sini saya tidak menjelaskan bumbu yang digunakan untuk mengungkep ayam. Jadi langsung cara membuat ayam gepreknya saja"
- "Ayam yang sudah diungkep kemudian di geprek dengan menggunakan ulekan"
- "Kemudian celupkan ayam ke telur, lalu adonan kering, adonan basah, lalu adonan kering lagi. Jangam lupa dicubit2 untuk membuat tekstur keriting"
- "Masukkan ayam ke dalam minyak yg sudah panas. Menggoreng ayam harus (deep frying) ayam harus digoreng tenggelam dalam minyak."
- "Cara membuat sambalnya ulek cabai dan bawang putih,beri garam dan gula pasir secukupnya."
- "Ayam yg sudah tiris lalu diberikan taburan sambal yg telah dibuat."
categories:
- Recipe
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 300 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT44M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/5518d57fc51279f3/751x532cq70/ayam-geprek-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang harus kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam geprek yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan ciri khas yang merupakan keragaman Nusantara

Keharmonisan rumah tangga bisa didapat dengan cara simple. Diantaranya adalah memasak Ayam Geprek untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang dapat anda praktekkan salah satunya ayam geprek yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam geprek tanpa harus bersusah payah.
Seperti resep Ayam Geprek yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 10 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek:

1. Tambah 3 potong ayam
1. Dibutuhkan 7 buah cabai merah
1. Tambah 1 buah bawang putih
1. Dibutuhkan 15 sdm tepung terigu
1. Harap siapkan 1 sdt backing powder
1. Siapkan 15 sdm tepung bumbu
1. Siapkan  Air es
1. Tambah 1 butir telur ayam
1. Tambah 1 sdm garam
1. Jangan lupa 1 sdt gula pasir




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Geprek:

1. Siapkan 3 wadah untuk adonan basah, adonan kering, dan telur
1. Buat adonan basah yg terdiri dari tepung terigu, backing powder, dan air es
1. Adonan kering terdiri dari tepung bumbu saja
1. Jangan lupa kocok 1 buah telur
1. Di sini saya tidak menjelaskan bumbu yang digunakan untuk mengungkep ayam. Jadi langsung cara membuat ayam gepreknya saja
1. Ayam yang sudah diungkep kemudian di geprek dengan menggunakan ulekan
1. Kemudian celupkan ayam ke telur, lalu adonan kering, adonan basah, lalu adonan kering lagi. Jangam lupa dicubit2 untuk membuat tekstur keriting
1. Masukkan ayam ke dalam minyak yg sudah panas. Menggoreng ayam harus (deep frying) ayam harus digoreng tenggelam dalam minyak.
1. Cara membuat sambalnya ulek cabai dan bawang putih,beri garam dan gula pasir secukupnya.
1. Ayam yg sudah tiris lalu diberikan taburan sambal yg telah dibuat.




Demikianlah cara membuat ayam geprek yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan teruji, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
