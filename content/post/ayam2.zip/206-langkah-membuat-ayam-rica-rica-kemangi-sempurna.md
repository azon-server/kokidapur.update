---
description: "Langkah membuat Ayam rica-rica kemangi Sempurna"
title: "Langkah membuat Ayam rica-rica kemangi Sempurna"
slug: 206-langkah-membuat-ayam-rica-rica-kemangi-sempurna
date: 2020-12-02T05:17:28.873Z
image: https://img-global.cpcdn.com/recipes/05d55bed5d5765ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/05d55bed5d5765ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/05d55bed5d5765ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Gary Taylor
ratingvalue: 4.3
reviewcount: 35947
recipeingredient:
- "1/2 kg ayam"
- "4 lembar daun jeruk"
- "1 batang serai"
- "1 lembar daun kunyit"
- "Secukupnya daun kemangi"
- "1 buah tomat"
- "1 ruas lengkuas geprek"
- " Bumbu"
- "8 buah cabai merah"
- "6 buah cabai rawit"
- "5 siung bawang merah"
- "2 siung bawang putih"
- "4 buah kemiri geprek"
- "1 sdt bubuk kunyit"
- "1 sdt jahe dan bawang putih yg sudah digiling"
recipeinstructions:
- "Goreng ayam hingga kecoklatan"
- "Blender bumbunya hingga halus"
- "Tumis bumbu hingga harum masukan tomat serai lengkuas daun kunyit daun jeruk"
- "Aduk semuanya hingga rata beri air secukupnya"
- "Masukan ayam lalu beri garam dan kaldu bubuk secukupnya lalu masukan daun kemangi"
- "Masak hingga bumbu meresap ke ayam dan kering"
- "Ayam rica-rica kemangi siap dinikmati🤩"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 262 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/05d55bed5d5765ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica-rica kemangi yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa kesan tersendiri yang merupakan keragaman Kita

Kehangatan rumah tangga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam rica-rica kemangi untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang bisa anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 15 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica kemangi:

1. Harap siapkan 1/2 kg ayam
1. Dibutuhkan 4 lembar daun jeruk
1. Diperlukan 1 batang serai
1. Dibutuhkan 1 lembar daun kunyit
1. Siapkan Secukupnya daun kemangi
1. Diperlukan 1 buah tomat
1. Siapkan 1 ruas lengkuas geprek
1. Siapkan  Bumbu
1. Harus ada 8 buah cabai merah
1. Diperlukan 6 buah cabai rawit
1. Dibutuhkan 5 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Siapkan 4 buah kemiri geprek
1. Jangan lupa 1 sdt bubuk kunyit
1. Diperlukan 1 sdt jahe dan bawang putih yg sudah digiling


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica-rica kemangi:

1. Goreng ayam hingga kecoklatan
1. Blender bumbunya hingga halus
1. Tumis bumbu hingga harum masukan tomat serai lengkuas daun kunyit daun jeruk
1. Aduk semuanya hingga rata beri air secukupnya
1. Masukan ayam lalu beri garam dan kaldu bubuk secukupnya lalu masukan daun kemangi
1. Masak hingga bumbu meresap ke ayam dan kering
1. Ayam rica-rica kemangi siap dinikmati🤩


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
