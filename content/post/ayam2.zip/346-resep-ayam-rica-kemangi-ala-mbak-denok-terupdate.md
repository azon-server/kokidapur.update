---
description: "Resep : Ayam rica kemangi ala mbak denok terupdate"
title: "Resep : Ayam rica kemangi ala mbak denok terupdate"
slug: 346-resep-ayam-rica-kemangi-ala-mbak-denok-terupdate
date: 2020-09-12T08:48:32.032Z
image: https://img-global.cpcdn.com/recipes/97e8a67fe9e8eae7/751x532cq70/ayam-rica-kemangi-ala-mbak-denok-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/97e8a67fe9e8eae7/751x532cq70/ayam-rica-kemangi-ala-mbak-denok-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/97e8a67fe9e8eae7/751x532cq70/ayam-rica-kemangi-ala-mbak-denok-foto-resep-utama.jpg
author: Jackson Crawford
ratingvalue: 4.8
reviewcount: 29933
recipeingredient:
- "1/2 kg daging ayam cuci bersih"
- " Bumbu halus"
- "2 cm kunyi"
- "5 buah bawang merah"
- "2 buah bawang putih"
- "10 cabe rawit"
- "10 cabe merah"
- "2 cm jahe"
- "1 buah kemiri"
- " bahan tambahan"
- "1 batang serai"
- "3 buah cabe panjang hijau"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "2 batang serai"
- "sesuai selera Daun kemangi"
- " semua bahan tambahan di iris kecuali daun kemangi yaa moms"
recipeinstructions:
- "Rebuss daging ayamm. dan goreng setengah matang"
- "Tumis bumbu halusss.. Biarkan matang lalu beri air secukupnya untuk sedikit kuah"
- "Masukkan ayam goreng... Aduk rata dan masukkan bahan tambahannya ya moms....."
- "Biarkam sampai.layu....jangan lupa garam.gula.dan penyedapnya moms 😉"
- "Aduk sesekali.... dan biarkan sampai matang... Siappp di sajikan 😉"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 103 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT49M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam rica kemangi ala mbak denok](https://img-global.cpcdn.com/recipes/97e8a67fe9e8eae7/751x532cq70/ayam-rica-kemangi-ala-mbak-denok-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga gurih. Ciri khas makanan Nusantara ayam rica kemangi ala mbak denok yang penuh dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal. Resepnya sederhana dan mudah, khas Manado asli pakai daun kemangi.

Keharmonisan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam rica kemangi ala mbak denok untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang dapat anda buat salah satunya ayam rica kemangi ala mbak denok yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica kemangi ala mbak denok tanpa harus bersusah payah.
Seperti resep Ayam rica kemangi ala mbak denok yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi ala mbak denok:

1. Diperlukan 1/2 kg daging ayam. cuci bersih
1. Tambah  #Bumbu halus
1. Dibutuhkan 2 cm kunyi
1. Harap siapkan 5 buah bawang merah
1. Diperlukan 2 buah bawang putih
1. Diperlukan 10 cabe rawit
1. Jangan lupa 10 cabe merah
1. Harap siapkan 2 cm jahe
1. Tambah 1 buah kemiri
1. Jangan lupa  #bahan tambahan
1. Dibutuhkan 1 batang serai
1. Tambah 3 buah cabe panjang hijau
1. Harap siapkan 2 lembar daun jeruk
1. Tambah 2 lembar daun salam
1. Harap siapkan 2 batang serai
1. Jangan lupa sesuai selera Daun kemangi
1. Diperlukan  (semua bahan tambahan di iris kecuali daun kemangi yaa moms)


Kalau gak suka pedas, kurangi jumlah. Resep rica rica sendiri sebenarnya tidak harus menggunakan bahan daging ayam saja. Cita rasa pedas menjadi ciri khas resep yang tergabung Dengan demikian siapapun dapat mencoba membuat masakan rica rica ala manado ini. Dan enaknya resep ayam rica rica sangat mudah anda temukan. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica kemangi ala mbak denok:

1. Rebuss daging ayamm. dan goreng setengah matang
1. Tumis bumbu halusss.. Biarkan matang lalu beri air secukupnya untuk sedikit kuah
1. Masukkan ayam goreng... Aduk rata dan masukkan bahan tambahannya ya moms.....
1. Biarkam sampai.layu....jangan lupa garam.gula.dan penyedapnya moms 😉
1. Aduk sesekali.... dan biarkan sampai matang... Siappp di sajikan 😉


Cita rasa pedas menjadi ciri khas resep yang tergabung Dengan demikian siapapun dapat mencoba membuat masakan rica rica ala manado ini. Dan enaknya resep ayam rica rica sangat mudah anda temukan. Ayam rica-rica telah menjamur hingga ke berbagai restoran dari restoran biasa hingga berbintang lima. Tidak sedikit menu ini dipesan oleh para palanggan yang rata-rata menyukai citarasa pedasnya. Ayam rica-rica memang selalu memiliki tempat tersendiri dihati masyarakat Indonesia. 

Demikianlah cara membuat ayam rica kemangi ala mbak denok yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
