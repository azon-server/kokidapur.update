---
description: "Langkah membuat 22. Ayam Rica Rica Kemangi ala Reg’s Dish 🍽 teraktual"
title: "Langkah membuat 22. Ayam Rica Rica Kemangi ala Reg’s Dish 🍽 teraktual"
slug: 340-langkah-membuat-22-ayam-rica-rica-kemangi-ala-regs-dish-teraktual
date: 2020-09-04T17:35:26.271Z
image: https://img-global.cpcdn.com/recipes/fcdc1f63d3316d26/751x532cq70/22-ayam-rica-rica-kemangi-ala-regs-dish-🍽-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fcdc1f63d3316d26/751x532cq70/22-ayam-rica-rica-kemangi-ala-regs-dish-🍽-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fcdc1f63d3316d26/751x532cq70/22-ayam-rica-rica-kemangi-ala-regs-dish-🍽-foto-resep-utama.jpg
author: Helena Knight
ratingvalue: 4.6
reviewcount: 7244
recipeingredient:
- "1/2 kg ayam kota potong kecil2"
- "2 ikat daun kemangi"
- "3 lembar kecil daun kunyit iris tipis"
- "5 lembar kecil daun jeruk purut iris tipis"
- "1 buah serai geprek"
- "1 (1/2 sdt) gula pasir"
- "Secukupnya penyedap rasa"
- "2 buah jeruk sambal"
- "2 buah asam kandis"
- " Bumbu Halus"
- "10 buah cabai rawit sesuai selera"
- "3 butir kemiri"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "1 jempol jahe"
- "1 ruas kunyit"
recipeinstructions:
- "Marinasi ayam dengan jeruk. Sisihkan."
- "Tumbuk semua bumbu halus. Geprek serai."
- "Tumis bumbu halus dan serai sampai wangi."
- "Bilas ayam yang dimarinasi. Tumis bersama bumbu halus hingga berwarna pucat."
- "Tambahkan air. Aduk sebentar. Masak hingga mendidih. Masukkan gula dan penyedap rasa. Aduk kembali."
- "Setelah kuah mulai menyusut, masukkan daun jeruk dan daun kunyit yang sudah di iris tipis2, serta 2 buah asam kandis. Aduk rata dan koreksi rasa. Jika ingin lebih berkuah, tambahkan lagi air. Masak kembali hingga mendidih dan koreksi rasa."
- "Tambahkan daun kemangi. Aduk rata. Biarkan sampai daun sedikit layu. Selamat mencoba."
- "Recook? Jangan lupa tag #regsdish terimakasih 🥰"
categories:
- Recipe
tags:
- 22
- ayam
- rica

katakunci: 22 ayam rica 
nutrition: 251 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT36M"
recipeyield: "4"
recipecategory: Dinner

---


![22. Ayam Rica Rica Kemangi
ala Reg’s Dish 🍽](https://img-global.cpcdn.com/recipes/fcdc1f63d3316d26/751x532cq70/22-ayam-rica-rica-kemangi-ala-regs-dish-🍽-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang harus kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti 22. ayam rica rica kemangi
ala reg’s dish 🍽 yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan ciri khas yang merupakan keragaman Indonesia



Kehangatan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah memasak 22. Ayam Rica Rica Kemangi
ala Reg’s Dish 🍽 untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang dapat anda contoh salah satunya 22. ayam rica rica kemangi
ala reg’s dish 🍽 yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep 22. ayam rica rica kemangi
ala reg’s dish 🍽 tanpa harus bersusah payah.
Berikut ini resep 22. Ayam Rica Rica Kemangi
ala Reg’s Dish 🍽 yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat 22. Ayam Rica Rica Kemangi
ala Reg’s Dish 🍽:

1. Siapkan 1/2 kg ayam kota potong kecil2
1. Diperlukan 2 ikat daun kemangi
1. Jangan lupa 3 lembar kecil daun kunyit (iris tipis)
1. Dibutuhkan 5 lembar kecil daun jeruk purut (iris tipis)
1. Tambah 1 buah serai (geprek)
1. Harap siapkan 1 (1/2 sdt) gula pasir
1. Harap siapkan Secukupnya penyedap rasa
1. Jangan lupa 2 buah jeruk sambal
1. Dibutuhkan 2 buah asam kandis
1. Harap siapkan  Bumbu Halus
1. Siapkan 10 buah cabai rawit (sesuai selera)
1. Diperlukan 3 butir kemiri
1. Diperlukan 6 siung bawang merah
1. Dibutuhkan 4 siung bawang putih
1. Jangan lupa 1 jempol jahe
1. Jangan lupa 1 ruas kunyit




<!--inarticleads2-->

##### Langkah membuat  22. Ayam Rica Rica Kemangi
ala Reg’s Dish 🍽:

1. Marinasi ayam dengan jeruk. Sisihkan.
1. Tumbuk semua bumbu halus. Geprek serai.
1. Tumis bumbu halus dan serai sampai wangi.
1. Bilas ayam yang dimarinasi. Tumis bersama bumbu halus hingga berwarna pucat.
1. Tambahkan air. Aduk sebentar. Masak hingga mendidih. Masukkan gula dan penyedap rasa. Aduk kembali.
1. Setelah kuah mulai menyusut, masukkan daun jeruk dan daun kunyit yang sudah di iris tipis2, serta 2 buah asam kandis. Aduk rata dan koreksi rasa. Jika ingin lebih berkuah, tambahkan lagi air. Masak kembali hingga mendidih dan koreksi rasa.
1. Tambahkan daun kemangi. Aduk rata. Biarkan sampai daun sedikit layu. Selamat mencoba.
1. Recook? Jangan lupa tag #regsdish terimakasih 🥰




Demikianlah cara membuat 22. ayam rica rica kemangi
ala reg’s dish 🍽 yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan terbukti, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
