---
description: "Panduan untuk membuat Ayam rica kemangi Luar biasa"
title: "Panduan untuk membuat Ayam rica kemangi Luar biasa"
slug: 214-panduan-untuk-membuat-ayam-rica-kemangi-luar-biasa
date: 2021-01-27T07:40:44.669Z
image: https://img-global.cpcdn.com/recipes/bbd8e729baa7e083/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bbd8e729baa7e083/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bbd8e729baa7e083/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Amy Collins
ratingvalue: 4.7
reviewcount: 27230
recipeingredient:
- "1 kg Ayam dada boneless"
- " Bumbu halus"
- "10 Cabe merah"
- "15 Cabe rawit"
- "5 Kemiri sangrai"
- "1 cm Kunyit"
- "12 Bawang merah"
- "6 Bawang putih"
- "1 buah Tomat"
- " Minyak goreng untuk tumis"
- " Bumbu pelengkap"
- "2 lbr Salam"
- "2 Serai"
- "3 Daun jeruk"
- "3 tangkai Daun bawang"
- "3 ikat Kemangi"
- " Garam"
- " Gula"
recipeinstructions:
- "Potong dadu ayam dada boneless"
- "Tumis bumbu halus dan masukkan serai daun salam serta daun jeruk, masukan garam 2sdt, 2 sdt gula tunggu bumbu wangi"
- "Masukkan potongan ayam ke bumbu tumis"
- "Masak sampai bumbu menyusut dan koreksi rasa saat sudah menyusut... menghindari rasa keasinan apabila di coba saat air masih banyak"
- "Tambahkan kemangi dan daun bawang aduk sampai layu.."
- "Siap di santap..bisa dilengkapi dengan sayuran rebus untuk menghadirkan vitamin dan serat yg lengkap tetapi tdk merubah rasa"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 278 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/bbd8e729baa7e083/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang dapat kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica kemangi yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Kita

Keharmonisan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah memasak Ayam rica kemangi untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang dapat anda buat salah satunya ayam rica kemangi yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica kemangi:

1. Diperlukan 1 kg Ayam dada boneless
1. Harus ada  Bumbu halus
1. Siapkan 10 Cabe merah
1. Tambah 15 Cabe rawit
1. Harus ada 5 Kemiri sangrai
1. Harap siapkan 1 cm Kunyit
1. Siapkan 12 Bawang merah
1. Jangan lupa 6 Bawang putih
1. Jangan lupa 1 buah Tomat
1. Harus ada  Minyak goreng untuk tumis
1. Siapkan  Bumbu pelengkap
1. Harap siapkan 2 lbr Salam
1. Dibutuhkan 2 Serai
1. Diperlukan 3 Daun jeruk
1. Jangan lupa 3 tangkai Daun bawang
1. Harus ada 3 ikat Kemangi
1. Tambah  Garam
1. Harus ada  Gula


Perlu kamu ketahui bahwa di luar negeri mungkin daun basil sangat terkenal untuk campuran makanan. Akan tetapi, di Indonesia juga memiliki daun kemangi merupakan. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica kemangi:

1. Potong dadu ayam dada boneless
1. Tumis bumbu halus dan masukkan serai daun salam serta daun jeruk, masukan garam 2sdt, 2 sdt gula tunggu bumbu wangi
1. Masukkan potongan ayam ke bumbu tumis
1. Masak sampai bumbu menyusut dan koreksi rasa saat sudah menyusut... menghindari rasa keasinan apabila di coba saat air masih banyak
1. Tambahkan kemangi dan daun bawang aduk sampai layu..
1. Siap di santap..bisa dilengkapi dengan sayuran rebus untuk menghadirkan vitamin dan serat yg lengkap tetapi tdk merubah rasa


Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. Cara Membuat Ayam Rica Rica Kemangi. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat. 

Demikianlah cara membuat ayam rica kemangi yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
