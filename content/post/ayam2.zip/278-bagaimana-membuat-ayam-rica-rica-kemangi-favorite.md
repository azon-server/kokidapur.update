---
description: "Bagaimana membuat Ayam rica-rica kemangi Favorite"
title: "Bagaimana membuat Ayam rica-rica kemangi Favorite"
slug: 278-bagaimana-membuat-ayam-rica-rica-kemangi-favorite
date: 2021-02-04T16:05:21.923Z
image: https://img-global.cpcdn.com/recipes/ae522bf6d0c8807e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ae522bf6d0c8807e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ae522bf6d0c8807e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Olivia Byrd
ratingvalue: 4.8
reviewcount: 11615
recipeingredient:
- "1/2 kg ayam"
- "3 ikat kemangi"
- "2 daun bawang"
- "  Bumbu ayam goreng"
- "2 buah jeruk nipis"
- " Bisa pakai kunyit"
- "  Bumbu halus"
- "4 bawang merah"
- "3 bawang putih"
- "3 cabai merah besar"
- "5 cabai rawit tergantung selera"
- "Secukupnya gula garam  lada"
- "2 ruas lengkuas"
- "1 ruas jahe"
- "3 daun salam"
- "2 daun jeruk"
- "1 sereh geprek"
- "Secukupnya air  250 ml"
recipeinstructions:
- "Lumuri ayam dengan perasan jeruk nipis. Diamkan 15 menit. Setelah itu goreng ayam 1/2 matang (jangan terlalu kering agar tidak keras &amp; ulet)"
- "Haluskan semua bumbu (kecuali daun salam, daun jeruk &amp; sereh). Untuk jahe &amp; lengkuas bebas, bisa ikut dihaluskan bisa juga hanya di geprek."
- "Panaskan sedikit minyak goreng. Masukkan bumbu halus, lalu tumis hingga harus."
- "Masukkan daging ayam yg sdh di goreng. Tambahkan air secukupnya. Aduk hingga merata."
- "Masak sampai air meresap. Kemudian masukkan daun kemangi &amp; irisan daun bawang. Masak sebentar saja, cukup sampai kemangi mulai layu."
- "Masakan siap disajikan. Selamat mencoba :) Jangan lupa kirim hasil re-cook nya yaa.. hehehe"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 289 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT37M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/ae522bf6d0c8807e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang harus kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia

Kehangatan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah memasak Ayam rica-rica kemangi untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda contoh salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica kemangi:

1. Dibutuhkan 1/2 kg ayam
1. Tambah 3 ikat kemangi
1. Dibutuhkan 2 daun bawang
1. Diperlukan  📌 Bumbu ayam goreng
1. Siapkan 2 buah jeruk nipis
1. Siapkan  (Bisa pakai kunyit)
1. Jangan lupa  📌 Bumbu halus
1. Harap siapkan 4 bawang merah
1. Harap siapkan 3 bawang putih
1. Harap siapkan 3 cabai merah besar
1. Harap siapkan 5 cabai rawit (tergantung selera)
1. Tambah Secukupnya gula, garam &amp; lada
1. Diperlukan 2 ruas lengkuas
1. Diperlukan 1 ruas jahe
1. Diperlukan 3 daun salam
1. Siapkan 2 daun jeruk
1. Tambah 1 sereh (geprek)
1. Dibutuhkan Secukupnya air (+/- 250 ml)


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica-rica kemangi:

1. Lumuri ayam dengan perasan jeruk nipis. Diamkan 15 menit. Setelah itu goreng ayam 1/2 matang (jangan terlalu kering agar tidak keras &amp; ulet)
1. Haluskan semua bumbu (kecuali daun salam, daun jeruk &amp; sereh). Untuk jahe &amp; lengkuas bebas, bisa ikut dihaluskan bisa juga hanya di geprek.
1. Panaskan sedikit minyak goreng. Masukkan bumbu halus, lalu tumis hingga harus.
1. Masukkan daging ayam yg sdh di goreng. Tambahkan air secukupnya. Aduk hingga merata.
1. Masak sampai air meresap. Kemudian masukkan daun kemangi &amp; irisan daun bawang. Masak sebentar saja, cukup sampai kemangi mulai layu.
1. Masakan siap disajikan. Selamat mencoba :) Jangan lupa kirim hasil re-cook nya yaa.. hehehe


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
