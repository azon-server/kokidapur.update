---
description: "Resep : Ayam Rica-Rica Kemangi Teruji"
title: "Resep : Ayam Rica-Rica Kemangi Teruji"
slug: 370-resep-ayam-rica-rica-kemangi-teruji
date: 2020-10-18T15:27:04.677Z
image: https://img-global.cpcdn.com/recipes/f57d6b7672014781/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f57d6b7672014781/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f57d6b7672014781/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Barry Hunt
ratingvalue: 4
reviewcount: 46804
recipeingredient:
- "1/2 kg Ayam"
- " Bumbu Halus"
- "10 buah Cabe Merah"
- "5 siung Bawang Merah"
- "3 siung Bawang Putih"
- "3 cm Kunyit"
- "3 cm Jahe"
- "3 butir Kemiri"
- " Penambah Aroma"
- " Daun Jeruk secukupnya saya 7 lembar"
- "segenggam Daun Kemangi"
- "1 batang Sereh"
- "3 cm Lengkuas bisa di skip tidak terlalu berpengaruh"
- "2 lembar Salam"
- " Tambahan"
- "3 sdt Garam"
- " Gula merah secukupnya bisa di skip"
- "2 sdt Penyedap"
- "300 ml Air"
- " Minyak secukupnya untuk menggoreng ayam dan menumis bumbu"
recipeinstructions:
- "Cuci bersih ayam kemudian goreng"
- "Sembari menggoreng haluskan bumbu dan siapkan bahan penambah aroma"
- "Tumis bumbu halus sampai matang lalu tambahkan daun jeruk, aduk-aduk, tambahkan air."
- "Masukan ayam, beri garam gula penyedap, koreksi rasa. Jika sudah oke tunggu sampai air menyusut"
- "Angkat dan sajikan jika air sudah menyusut seperti ini"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 151 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT35M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/f57d6b7672014781/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang dapat kita jaga karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica-rica kemangi yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Kita

Keharmonisan rumah tangga dapat diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam Rica-Rica Kemangi untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang bisa anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica Kemangi:

1. Siapkan 1/2 kg Ayam
1. Harap siapkan  Bumbu Halus
1. Diperlukan 10 buah Cabe Merah
1. Harus ada 5 siung Bawang Merah
1. Tambah 3 siung Bawang Putih
1. Dibutuhkan 3 cm Kunyit
1. Dibutuhkan 3 cm Jahe
1. Harap siapkan 3 butir Kemiri
1. Dibutuhkan  Penambah Aroma
1. Dibutuhkan  Daun Jeruk secukupnya (saya 7 lembar)
1. Dibutuhkan segenggam Daun Kemangi
1. Jangan lupa 1 batang Sereh
1. Diperlukan 3 cm Lengkuas (bisa di skip, tidak terlalu berpengaruh)
1. Tambah 2 lembar Salam
1. Harus ada  Tambahan
1. Tambah 3 sdt Garam
1. Siapkan  Gula merah secukupnya (bisa di skip)
1. Dibutuhkan 2 sdt Penyedap
1. Diperlukan 300 ml Air
1. Siapkan  Minyak secukupnya untuk menggoreng ayam dan menumis bumbu




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica Kemangi:

1. Cuci bersih ayam kemudian goreng
1. Sembari menggoreng haluskan bumbu dan siapkan bahan penambah aroma
1. Tumis bumbu halus sampai matang lalu tambahkan daun jeruk, aduk-aduk, tambahkan air.
1. Masukan ayam, beri garam gula penyedap, koreksi rasa. Jika sudah oke tunggu sampai air menyusut
1. Angkat dan sajikan jika air sudah menyusut seperti ini




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
