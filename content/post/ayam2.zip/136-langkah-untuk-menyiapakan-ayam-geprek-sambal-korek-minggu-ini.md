---
description: "Langkah untuk menyiapakan Ayam Geprek Sambal Korek minggu ini"
title: "Langkah untuk menyiapakan Ayam Geprek Sambal Korek minggu ini"
slug: 136-langkah-untuk-menyiapakan-ayam-geprek-sambal-korek-minggu-ini
date: 2020-09-22T20:37:23.444Z
image: https://img-global.cpcdn.com/recipes/9a46bc1d2306813a/751x532cq70/ayam-geprek-sambal-korek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9a46bc1d2306813a/751x532cq70/ayam-geprek-sambal-korek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9a46bc1d2306813a/751x532cq70/ayam-geprek-sambal-korek-foto-resep-utama.jpg
author: Bobby Clarke
ratingvalue: 4.9
reviewcount: 43654
recipeingredient:
- " Beberapa potong ayam"
- " Bumbu untuk ungkep ayam"
- " Tepung ayam crispy"
- "20 buah cabai rawit merah"
- "2 buah bawang putih"
- "2 lembar daun jeruk"
- "Secukupnya minyak"
- "Secukupnya garam"
recipeinstructions:
- "Ungkep ayam beserta bumbu, akan lebih nikmat jika ayam diungkep menggunakan panci presto"
- "Bumbui ayam yg telah di ungkep dengan tepung ayam crispy (siapkan 2 mangkuk tepung bumbu, yg satu dengan campuran air, mangkuk yg lain hanya tepungnya saja) ulangin proses hingga dirasa cukup"
- "Panaskan minyak pada wajan"
- "Selagi menunggu minyak panas ulek kasar cabai rawit merah beserta bawang putih"
- "Setelah minyak panas hingga mengeluarkan asap, guyur sambal yg telah di ulek sebelumnya dengan minyak panas barusan diatas cobek hingga semua sambal terkena minyak panas, jangan lupa beri secukupnya garam. Lalu sisihkan di pinggir cobek"
- "Goreng ayam yg telah di bumbui dengan sisa minyak, kecilkan api dan tunggu hingga berubah kuning keemasan lalu tiriskan"
- "Setelah minyak tiris, angkat ayam tersebut ke cobek, taruh sambal yg telah dititiskan di atas ayam dan geprek ayam beserta sambal namun jangan terlalu hancur."
- "Sobek daun jeruk dan taruh diatas ayam yg sebelumnya telah digeprek"
- "Ayam geprek sambal korek pun siap dihidangkan dengan nasi panas dan lalapan sesuai selera"
categories:
- Recipe
tags:
- ayam
- geprek
- sambal

katakunci: ayam geprek sambal 
nutrition: 125 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT43M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Geprek Sambal Korek](https://img-global.cpcdn.com/recipes/9a46bc1d2306813a/751x532cq70/ayam-geprek-sambal-korek-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau renyah. Ciri makanan Indonesia ayam geprek sambal korek yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kehangatan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah memasak Ayam Geprek Sambal Korek untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang dapat anda praktekkan salah satunya ayam geprek sambal korek yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep ayam geprek sambal korek tanpa harus bersusah payah.
Seperti resep Ayam Geprek Sambal Korek yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 9 langkah dan 8 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Sambal Korek:

1. Siapkan  Beberapa potong ayam
1. Harus ada  Bumbu untuk ungkep ayam
1. Dibutuhkan  Tepung ayam crispy
1. Diperlukan 20 buah cabai rawit merah
1. Harus ada 2 buah bawang putih
1. Jangan lupa 2 lembar daun jeruk
1. Siapkan Secukupnya minyak
1. Harus ada Secukupnya garam




<!--inarticleads2-->

##### Cara membuat  Ayam Geprek Sambal Korek:

1. Ungkep ayam beserta bumbu, akan lebih nikmat jika ayam diungkep menggunakan panci presto
1. Bumbui ayam yg telah di ungkep dengan tepung ayam crispy (siapkan 2 mangkuk tepung bumbu, yg satu dengan campuran air, mangkuk yg lain hanya tepungnya saja) ulangin proses hingga dirasa cukup
1. Panaskan minyak pada wajan
1. Selagi menunggu minyak panas ulek kasar cabai rawit merah beserta bawang putih
1. Setelah minyak panas hingga mengeluarkan asap, guyur sambal yg telah di ulek sebelumnya dengan minyak panas barusan diatas cobek hingga semua sambal terkena minyak panas, jangan lupa beri secukupnya garam. Lalu sisihkan di pinggir cobek
1. Goreng ayam yg telah di bumbui dengan sisa minyak, kecilkan api dan tunggu hingga berubah kuning keemasan lalu tiriskan
1. Setelah minyak tiris, angkat ayam tersebut ke cobek, taruh sambal yg telah dititiskan di atas ayam dan geprek ayam beserta sambal namun jangan terlalu hancur.
1. Sobek daun jeruk dan taruh diatas ayam yg sebelumnya telah digeprek
1. Ayam geprek sambal korek pun siap dihidangkan dengan nasi panas dan lalapan sesuai selera




Demikianlah cara membuat ayam geprek sambal korek yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan teruji, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
