---
description: "Panduan untuk menyiapakan 2. Ayam Rica-rica Kemangi Cepat"
title: "Panduan untuk menyiapakan 2. Ayam Rica-rica Kemangi Cepat"
slug: 268-panduan-untuk-menyiapakan-2-ayam-rica-rica-kemangi-cepat
date: 2021-01-28T19:13:26.026Z
image: https://img-global.cpcdn.com/recipes/b87a3f1111bcb347/751x532cq70/2-ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b87a3f1111bcb347/751x532cq70/2-ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b87a3f1111bcb347/751x532cq70/2-ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Rhoda Harrison
ratingvalue: 4.4
reviewcount: 3325
recipeingredient:
- "1 kg ayam"
- " Bumbu yang dihaluskan"
- "13 siung bawang merah"
- "7 siung bawang putih"
- "4 butir kemiri disangrai dulu"
- "5 buah cabai merah besar atau sesuai selera"
- "15 buah cabai kecil atau sesuai selera"
- "1/2 jari telunjuk jahe"
- "1/2 jari telunjuk kunyit"
- " Bahan untuk tumisan"
- "60 ml santan kental"
- "Secukupnya kemangi"
- "2 buah tomat"
- "1 batang daun bawang"
- "5 lembar daun jeruk yang sudah disobek"
- "5 lembar daun salam"
- "2 batang sereh yang sudah digeprek"
- "1/2 jari telunjuk laos yang sudah digeprek"
- "500 ml air"
- "Secukupnya garam gula kaldu bubuk"
- "Secukupnya minyak"
recipeinstructions:
- "Potong ayam sesuai selera dan cuci bersih."
- "Haluskan bawang merah, bawang putih, kemiri, cabai merah besar, cabai kecil, jahe dan kunyit."
- "Potong tomat dan daun bawang, lalu sisihkan."
- "Panaskan minyak lalu masukkan bumbu halus. Tumis sampai harum."
- "Setelah harum dan setengah matang, masukkan daun salam, daun jeruk, sereh dan laos. Aduk sampai rata."
- "Lalu masukkan ayam agar tercampur dengan bumbunya, tunggu beberapa saat sebelum memasukkan air. Masak hingga mendidih."
- "Campurkan santan, gula, garam dan kaldu bubuk. Jangan lupa koreksi rasa."
- "Jika sudah pas, masukkan tomat, daun bawang dan kemangi. Aduk dan makanan siap untuk disajikan. Selamat mencoba!"
categories:
- Recipe
tags:
- 2
- ayam
- ricarica

katakunci: 2 ayam ricarica 
nutrition: 226 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Dinner

---


![2. Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/b87a3f1111bcb347/751x532cq70/2-ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan gurih. Ciri khas kuliner Indonesia 2. ayam rica-rica kemangi yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga dapat diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan 2. Ayam Rica-rica Kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang dapat anda buat salah satunya 2. ayam rica-rica kemangi yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep 2. ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep 2. Ayam Rica-rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 21 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat 2. Ayam Rica-rica Kemangi:

1. Jangan lupa 1 kg ayam
1. Harus ada  Bumbu yang dihaluskan
1. Tambah 13 siung bawang merah
1. Harap siapkan 7 siung bawang putih
1. Diperlukan 4 butir kemiri (disangrai dulu)
1. Harus ada 5 buah cabai merah besar (atau sesuai selera)
1. Jangan lupa 15 buah cabai kecil (atau sesuai selera)
1. Dibutuhkan 1/2 jari telunjuk jahe
1. Harap siapkan 1/2 jari telunjuk kunyit
1. Siapkan  Bahan untuk tumisan
1. Tambah 60 ml santan kental
1. Harap siapkan Secukupnya kemangi
1. Harus ada 2 buah tomat
1. Dibutuhkan 1 batang daun bawang
1. Siapkan 5 lembar daun jeruk yang sudah disobek
1. Dibutuhkan 5 lembar daun salam
1. Siapkan 2 batang sereh yang sudah digeprek
1. Dibutuhkan 1/2 jari telunjuk laos yang sudah digeprek
1. Siapkan 500 ml air
1. Harap siapkan Secukupnya garam, gula, kaldu bubuk
1. Siapkan Secukupnya minyak




<!--inarticleads2-->

##### Langkah membuat  2. Ayam Rica-rica Kemangi:

1. Potong ayam sesuai selera dan cuci bersih.
1. Haluskan bawang merah, bawang putih, kemiri, cabai merah besar, cabai kecil, jahe dan kunyit.
1. Potong tomat dan daun bawang, lalu sisihkan.
1. Panaskan minyak lalu masukkan bumbu halus. Tumis sampai harum.
1. Setelah harum dan setengah matang, masukkan daun salam, daun jeruk, sereh dan laos. Aduk sampai rata.
1. Lalu masukkan ayam agar tercampur dengan bumbunya, tunggu beberapa saat sebelum memasukkan air. Masak hingga mendidih.
1. Campurkan santan, gula, garam dan kaldu bubuk. Jangan lupa koreksi rasa.
1. Jika sudah pas, masukkan tomat, daun bawang dan kemangi. Aduk dan makanan siap untuk disajikan. Selamat mencoba!




Demikianlah cara membuat 2. ayam rica-rica kemangi yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
