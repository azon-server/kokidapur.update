---
description: "Resep : Ayam Rica Kemangi Sempurna"
title: "Resep : Ayam Rica Kemangi Sempurna"
slug: 202-resep-ayam-rica-kemangi-sempurna
date: 2020-09-03T21:40:24.418Z
image: https://img-global.cpcdn.com/recipes/32946253ab16d3f7/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/32946253ab16d3f7/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/32946253ab16d3f7/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Tom Cummings
ratingvalue: 4.5
reviewcount: 26005
recipeingredient:
- "1 ekor ayam kampung potong 14"
- "2 buah jeruk nipis"
- " Bumbu halus"
- "12 buah cabe merah keriting"
- "4 butir kemiri"
- "10 siung bawang merah"
- "4 siung bawang putih"
- "1 ruas kunyit"
- " Bahan pelengkap"
- "800 ml air"
- "4 lembar daun jeruk iris"
- "1/2 lembar daun kunyit iris"
- "2 tangkai sereh iris"
- "2 lembar daun bawang iris"
- "1 buah tomat potong"
- "2 ruas lengkuas geprek"
- "1 ruas jahe geprek"
- "2 sdt garam"
- "6 buah cabe rawit setan"
- "4 ikat kemangi"
recipeinstructions:
- "Cuci bersih ayam lalu lumuri air perasan jeruk nipis pakai 1 buah, sisanya sisihkan dulu. Biarkan 30 menit, sambil siapkan bahan lainnya. Blender bumbu halus lalu tumis dengan sedikit minyak, masukkan daun jeruk, daun kunyit, jahe, lengkuas, sereh. Masak sampai bumbu halus berubah warna dan harum."
- "Masukkan ayam, aduk rata. Kemudian tuang air, aduk rata. Tutup wajannya dan masak sampai ayam empuk kurleb 50 menit."
- "Setelah ayam empuk, masukkan kemangi lalu aduk rata. Masukkan tomat, daun bawang, cabe rawit setan dan tambahkan garam. Koreksi rasa. Beri perasan jeruk nipis 1/2 buah atau bisa disesuaikan. Setelah rasanya pas, matikan kompor dan sajikan."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 269 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT30M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/32946253ab16d3f7/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang harus kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica kemangi yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan ciri khas yang merupakan keragaman Indonesia



Keharmonisan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica Kemangi untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang dapat anda contoh salah satunya ayam rica kemangi yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Dibutuhkan 1 ekor ayam kampung, potong 14
1. Harus ada 2 buah jeruk nipis
1. Jangan lupa  Bumbu halus:
1. Harap siapkan 12 buah cabe merah keriting
1. Siapkan 4 butir kemiri
1. Dibutuhkan 10 siung bawang merah
1. Tambah 4 siung bawang putih
1. Diperlukan 1 ruas kunyit
1. Harap siapkan  Bahan pelengkap:
1. Harap siapkan 800 ml air
1. Jangan lupa 4 lembar daun jeruk, iris
1. Harus ada 1/2 lembar daun kunyit, iris
1. Harus ada 2 tangkai sereh, iris
1. Dibutuhkan 2 lembar daun bawang, iris
1. Diperlukan 1 buah tomat, potong
1. Tambah 2 ruas lengkuas, geprek
1. Harap siapkan 1 ruas jahe, geprek
1. Tambah 2 sdt garam
1. Siapkan 6 buah cabe rawit setan
1. Dibutuhkan 4 ikat kemangi




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Kemangi:

1. Cuci bersih ayam lalu lumuri air perasan jeruk nipis pakai 1 buah, sisanya sisihkan dulu. Biarkan 30 menit, sambil siapkan bahan lainnya. Blender bumbu halus lalu tumis dengan sedikit minyak, masukkan daun jeruk, daun kunyit, jahe, lengkuas, sereh. Masak sampai bumbu halus berubah warna dan harum.
1. Masukkan ayam, aduk rata. Kemudian tuang air, aduk rata. Tutup wajannya dan masak sampai ayam empuk kurleb 50 menit.
1. Setelah ayam empuk, masukkan kemangi lalu aduk rata. Masukkan tomat, daun bawang, cabe rawit setan dan tambahkan garam. Koreksi rasa. Beri perasan jeruk nipis 1/2 buah atau bisa disesuaikan. Setelah rasanya pas, matikan kompor dan sajikan.




Demikianlah cara membuat ayam rica kemangi yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan teruji, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
