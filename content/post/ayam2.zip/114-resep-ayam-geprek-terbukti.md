---
description: "Resep : Ayam Geprek Terbukti"
title: "Resep : Ayam Geprek Terbukti"
slug: 114-resep-ayam-geprek-terbukti
date: 2020-11-04T22:09:11.534Z
image: https://img-global.cpcdn.com/recipes/e2e327bb16cb041d/751x532cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e2e327bb16cb041d/751x532cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e2e327bb16cb041d/751x532cq70/ayam-geprek-foto-resep-utama.jpg
author: Ruby Hayes
ratingvalue: 4
reviewcount: 37406
recipeingredient:
- " Ayam mentah bersihkan apabila masih ada darahnya di sini saya menggunakan ayam pejantan bagian paha"
- " Adonan kering "
- " Tepung bumbu serbaguna saya biasanya pakai sajiku spicy karena crispy hasilnya"
- " Adonan basah "
- "3 sendok tepung terigu"
- "2 sendok tepung maizena"
- "1/2 sendok teh kaldu jamur"
- " Bahan sambal geprek "
- "Sedikit garam"
- "Sedikit gula"
- "Sedikit kaldu jamur"
- "18 biji cabai rawit merah"
- "2 siung Bawang putih"
- " Minyak dipanaskan"
recipeinstructions:
- "Rebus terlebih dahulu ayam yang sudah dibersihkan setengah matang"
- "Siapkan adonan kering dan adonan basah"
- "Masukan ayam ke dalam adonan basah, lalu celup ke adonan kering. Ulangi sampai 3 kali lalu tepuk2 sebentar dan goreng ke dalam minyak panas (minyaknya agak banyak ya agar matang). Tunggu sampai kecoklatan lalu angkat"
- "Sisihkan dahulu ayam, kita membuat sambal geprek. Ambil semua cabai dan bawang putih, ulek kasar, masukan sedikit kaldu, garam dan gula. setelah halus beri dua sendok minyak panas (sisa menggoreng ayam tadi)"
- "Setelah itu tinggal kita geprek ayam beserta sambel gepreknya."
- "Saya sajikan sama indomie goreng biar kayak mie gepreknya bensu ya moms. Happy cooking☺️☺️"
categories:
- Recipe
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 256 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/e2e327bb16cb041d/751x532cq70/ayam-geprek-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga empuk. Ciri kuliner Nusantara ayam geprek yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak Ayam Geprek untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang bisa anda coba salah satunya ayam geprek yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep ayam geprek tanpa harus bersusah payah.
Seperti resep Ayam Geprek yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek:

1. Harap siapkan  Ayam mentah (bersihkan apabila masih ada darahnya, di sini saya menggunakan ayam pejantan bagian paha)
1. Siapkan  Adonan kering :
1. Jangan lupa  Tepung bumbu serbaguna (saya biasanya pakai sajiku spicy karena crispy hasilnya)
1. Jangan lupa  Adonan basah :
1. Jangan lupa 3 sendok tepung terigu
1. Diperlukan 2 sendok tepung maizena
1. Jangan lupa 1/2 sendok teh kaldu jamur
1. Jangan lupa  Bahan sambal geprek :
1. Harap siapkan Sedikit garam
1. Tambah Sedikit gula
1. Jangan lupa Sedikit kaldu jamur
1. Dibutuhkan 18 biji cabai rawit merah
1. Tambah 2 siung Bawang putih
1. Dibutuhkan  Minyak (dipanaskan)




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Geprek:

1. Rebus terlebih dahulu ayam yang sudah dibersihkan setengah matang
1. Siapkan adonan kering dan adonan basah
1. Masukan ayam ke dalam adonan basah, lalu celup ke adonan kering. Ulangi sampai 3 kali lalu tepuk2 sebentar dan goreng ke dalam minyak panas (minyaknya agak banyak ya agar matang). Tunggu sampai kecoklatan lalu angkat
1. Sisihkan dahulu ayam, kita membuat sambal geprek. Ambil semua cabai dan bawang putih, ulek kasar, masukan sedikit kaldu, garam dan gula. setelah halus beri dua sendok minyak panas (sisa menggoreng ayam tadi)
1. Setelah itu tinggal kita geprek ayam beserta sambel gepreknya.
1. Saya sajikan sama indomie goreng biar kayak mie gepreknya bensu ya moms. Happy cooking☺️☺️




Demikianlah cara membuat ayam geprek yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
