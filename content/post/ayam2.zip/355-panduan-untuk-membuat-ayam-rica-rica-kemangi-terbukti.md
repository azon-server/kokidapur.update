---
description: "Panduan untuk membuat Ayam Rica-Rica Kemangi Terbukti"
title: "Panduan untuk membuat Ayam Rica-Rica Kemangi Terbukti"
slug: 355-panduan-untuk-membuat-ayam-rica-rica-kemangi-terbukti
date: 2020-09-13T16:51:43.940Z
image: https://img-global.cpcdn.com/recipes/2fc34f12b909f01c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2fc34f12b909f01c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2fc34f12b909f01c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Floyd Evans
ratingvalue: 4.4
reviewcount: 11711
recipeingredient:
- "1/2 kg Ayam saya potong kecilkecil"
- "3 lbr daun jeruk"
- "2 lbr daun salam"
- "1 ikat daun kemangi ambil daunnya saja"
- "1 buah serai"
- " Lengkuas digeprek"
- "Secukupnya Garam"
- " Kaldu ayam bubuk"
- "Secukupnya Merica bubuk"
- "Secukupnya Ketumbar bubuk"
- "Secukupnya Gula"
- "Secukupnya air"
- "Sedikit Minyak Goreng"
- " Daun bawang iris serong bisa skip"
- " Bumbu halus "
- "3 siung Bawang Putih"
- "5 siung Bawang merah"
- "10 buah cabe merah keriting"
- "5 buah cabe rawit bisa sesuai selera"
- "2 cm Jahe"
- "1 Ruas Kunyit"
- "2 buah Kemiri"
recipeinstructions:
- "Rebus ayam dengan penyedap rasa, angkat dan tiriskan."
- "Blender bumbu halus lalu tumis dengan sedikit minyak. Masukkan daun jeruk, daun salam, lengkuas dan serai, ketumbar bubuk dan merica bubuk hingga harum."
- "Masukkan ayam lalu aduk sebentar. Tambahkan air,kaldu ayam, gula dan garam secukupnya dan tunggu hingga bumbu meresap, koreksi rasa"
- "Jika rasa sudah pas masukkan daun kemangi dan tunggu hingga air menyusut."
- "Ayam rica kemangi siap disajikan. Sajikan dengan taburan daun bawang iris diatasnya."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 283 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/2fc34f12b909f01c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang harus kita lestarikan karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica-rica kemangi yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Indonesia

Kedekatan keluarga dapat ditemukan dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica-Rica Kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang dapat anda coba salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 22 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica Kemangi:

1. Tambah 1/2 kg Ayam (saya potong kecil-kecil)
1. Tambah 3 lbr daun jeruk
1. Jangan lupa 2 lbr daun salam
1. Tambah 1 ikat daun kemangi (ambil daunnya saja)
1. Harus ada 1 buah serai
1. Siapkan  Lengkuas digeprek
1. Harus ada Secukupnya Garam
1. Dibutuhkan  Kaldu ayam bubuk
1. Diperlukan Secukupnya Merica bubuk
1. Harap siapkan Secukupnya Ketumbar bubuk
1. Tambah Secukupnya Gula
1. Harap siapkan Secukupnya air
1. Tambah Sedikit Minyak Goreng
1. Diperlukan  Daun bawang iris serong (bisa skip)
1. Jangan lupa  Bumbu halus :
1. Jangan lupa 3 siung Bawang Putih
1. Harus ada 5 siung Bawang merah
1. Diperlukan 10 buah cabe merah keriting
1. Harap siapkan 5 buah cabe rawit (bisa sesuai selera)
1. Harap siapkan 2 cm Jahe
1. Dibutuhkan 1 Ruas Kunyit
1. Jangan lupa 2 buah Kemiri




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica Kemangi:

1. Rebus ayam dengan penyedap rasa, angkat dan tiriskan.
1. Blender bumbu halus lalu tumis dengan sedikit minyak. Masukkan daun jeruk, daun salam, lengkuas dan serai, ketumbar bubuk dan merica bubuk hingga harum.
1. Masukkan ayam lalu aduk sebentar. Tambahkan air,kaldu ayam, gula dan garam secukupnya dan tunggu hingga bumbu meresap, koreksi rasa
1. Jika rasa sudah pas masukkan daun kemangi dan tunggu hingga air menyusut.
1. Ayam rica kemangi siap disajikan. Sajikan dengan taburan daun bawang iris diatasnya.




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
