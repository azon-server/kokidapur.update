---
description: "Steps untuk membuat Ayam geprek terupdate"
title: "Steps untuk membuat Ayam geprek terupdate"
slug: 115-steps-untuk-membuat-ayam-geprek-terupdate
date: 2020-10-11T18:15:40.956Z
image: https://img-global.cpcdn.com/recipes/b355c2197c89c2c1/751x532cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b355c2197c89c2c1/751x532cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b355c2197c89c2c1/751x532cq70/ayam-geprek-foto-resep-utama.jpg
author: Cora Higgins
ratingvalue: 4.9
reviewcount: 26723
recipeingredient:
- " Bahan "
- "1 ekor ayampotong 12 bagian"
- "4 siung bawang putih di haluskan"
- "1 sdt garam"
- "1/2 sdt merica bubuk"
- "500 ml minyak untuk menggoreng"
- " Bahan pencelup aduk rata "
- "500 ml air es"
- "300 9r tepung terigu"
- "25 gr tepung sagu"
- "1 sdt garam"
- "1/4 merica bubuk"
- " bahan pelapis "
- "300 gr tepung terigu"
- "50 gr maizena"
- "1/2 sdt baking powder"
- "1 sdt garam"
- "1/4 sdt merica bubuk"
- " bahan sambal"
- "10 bh cabe rawit merah"
- "2 siung bawang putih"
- "1/4 garam"
- "1/4 kaldu bubuk"
- "5 sdm minyak panas"
recipeinstructions:
- "Lumuri ayam dengan bawang putih,garam,merica bubuk,diamkan 15 menit,sisihkan."
- "Pelapis campur tepung terigu,maizena,baking powder,garam,merica bubuk,dan bawang putih bubuk,Aduk rata"
- "Celupkan ayam ke bahan pencelup,Gulingkan ke bahan pelapis,cubit2 hingga keritiing"
- "Goreng di dalam minyak yg sudah di panaskan sampai matang"
- "Sambal,haluskan cabai dan bawang putih,bumbuhi garam,merica bubuk,kaldu bubuk,ulek rata,siram dengan minyak panas.."
categories:
- Recipe
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 191 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam geprek](https://img-global.cpcdn.com/recipes/b355c2197c89c2c1/751x532cq70/ayam-geprek-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau gurih. Karasteristik masakan Indonesia ayam geprek yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.




Keharmonisan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam geprek untuk keluarga. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang bisa anda praktekkan salah satunya ayam geprek yang merupakan resep favorite yang mudah dengan kreasi sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep ayam geprek tanpa harus bersusah payah.
Seperti resep Ayam geprek yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 24 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam geprek:

1. Dibutuhkan  Bahan :
1. Diperlukan 1 ekor ayam,potong 12 bagian
1. Harap siapkan 4 siung bawang putih di haluskan
1. Siapkan 1 sdt garam
1. Dibutuhkan 1/2 sdt merica bubuk
1. Jangan lupa 500 ml minyak untuk menggoreng
1. Jangan lupa  Bahan pencelup (aduk rata) ;
1. Tambah 500 ml air es
1. Harus ada 300 9r tepung terigu
1. Dibutuhkan 25 gr tepung sagu
1. Harap siapkan 1 sdt garam
1. Harus ada 1/4 merica bubuk
1. Harap siapkan  bahan pelapis ;
1. Siapkan 300 gr tepung terigu
1. Diperlukan 50 gr maizena
1. Harap siapkan 1/2 sdt baking powder
1. Siapkan 1 sdt garam
1. Jangan lupa 1/4 sdt merica bubuk
1. Jangan lupa  bahan sambal;
1. Jangan lupa 10 bh cabe rawit merah
1. Diperlukan 2 siung bawang putih
1. Siapkan 1/4 garam
1. Tambah 1/4 kaldu bubuk
1. Dibutuhkan 5 sdm minyak panas




<!--inarticleads2-->

##### Instruksi membuat  Ayam geprek:

1. Lumuri ayam dengan bawang putih,garam,merica bubuk,diamkan 15 menit,sisihkan.
1. Pelapis campur tepung terigu,maizena,baking powder,garam,merica bubuk,dan bawang putih bubuk,Aduk rata
1. Celupkan ayam ke bahan pencelup,Gulingkan ke bahan pelapis,cubit2 hingga keritiing
1. Goreng di dalam minyak yg sudah di panaskan sampai matang
1. Sambal,haluskan cabai dan bawang putih,bumbuhi garam,merica bubuk,kaldu bubuk,ulek rata,siram dengan minyak panas..




Demikianlah cara membuat ayam geprek yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
