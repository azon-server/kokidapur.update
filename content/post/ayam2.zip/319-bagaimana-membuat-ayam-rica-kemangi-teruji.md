---
description: "Bagaimana membuat Ayam Rica Kemangi Teruji"
title: "Bagaimana membuat Ayam Rica Kemangi Teruji"
slug: 319-bagaimana-membuat-ayam-rica-kemangi-teruji
date: 2020-09-24T06:53:48.201Z
image: https://img-global.cpcdn.com/recipes/74259010268eb2ec/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/74259010268eb2ec/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/74259010268eb2ec/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Paul Simpson
ratingvalue: 4.7
reviewcount: 33525
recipeingredient:
- " Bahan utama"
- "1/2 ekor ayam potong sesuai selera"
- "2 ikat kemangi"
- " Bumbu halus"
- "10 buah cabe merah keriting"
- "5 buah cabe rawit merah"
- "5 siung bawang merah"
- "4 siung bawang putih"
- "1 buah tomat sedang"
- "4 butir kemiri"
- "1 ruas kunyit"
- "1 ruas jahe"
- " Bumbu tambahan"
- "1 ruas lengkuas gerek"
- "2 batang serai geprek"
- "2 lembar daun salam"
- "secukupnya Garam"
- "secukupnya Gula merah"
- "secukupnya Kaldu ayam"
- "secukupnya Kecap manis"
recipeinstructions:
- "Cuci bersih ayam, lalu potong sesuai selera. Setelah itu rebus ayam sebentar dengan tambahan garam, bawang putih dan jahe yang telah dihaluskan."
- "Goreng ayam setengah matang."
- "Ulek bumbu halus. Lalu tumis dengan sedikit minyak goreng. Masukkan lengkuas, daun salam, dan sereh. Tumis hingga harum."
- "Masukkan ayam yang telah digoreng lalu aduk-aduk. Setelah itu tambahkan air satu gelas."
- "Bumbui dengan garam, gula merah, kaldu ayam, dan sedikit kecap manis. Gunakan api kecil hingga air menyusut. Koreksi rasa."
- "Jika air sudah menyusut, tambahkan kemangi. Ayam rica kemangi siap dihidangkan. :)"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 258 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT53M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/74259010268eb2ec/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica kemangi yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Nusantara



Kehangatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica Kemangi untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang bisa anda contoh salah satunya ayam rica kemangi yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Diperlukan  Bahan utama
1. Tambah 1/2 ekor ayam potong sesuai selera
1. Diperlukan 2 ikat kemangi
1. Siapkan  Bumbu halus
1. Harap siapkan 10 buah cabe merah keriting
1. Diperlukan 5 buah cabe rawit merah
1. Jangan lupa 5 siung bawang merah
1. Harus ada 4 siung bawang putih
1. Harap siapkan 1 buah tomat sedang
1. Diperlukan 4 butir kemiri
1. Jangan lupa 1 ruas kunyit
1. Siapkan 1 ruas jahe
1. Harap siapkan  Bumbu tambahan
1. Harap siapkan 1 ruas lengkuas gerek
1. Harus ada 2 batang serai geprek
1. Harus ada 2 lembar daun salam
1. Siapkan secukupnya Garam
1. Diperlukan secukupnya Gula merah
1. Diperlukan secukupnya Kaldu ayam
1. Tambah secukupnya Kecap manis




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Kemangi:

1. Cuci bersih ayam, lalu potong sesuai selera. Setelah itu rebus ayam sebentar dengan tambahan garam, bawang putih dan jahe yang telah dihaluskan.
1. Goreng ayam setengah matang.
1. Ulek bumbu halus. Lalu tumis dengan sedikit minyak goreng. Masukkan lengkuas, daun salam, dan sereh. Tumis hingga harum.
1. Masukkan ayam yang telah digoreng lalu aduk-aduk. Setelah itu tambahkan air satu gelas.
1. Bumbui dengan garam, gula merah, kaldu ayam, dan sedikit kecap manis. Gunakan api kecil hingga air menyusut. Koreksi rasa.
1. Jika air sudah menyusut, tambahkan kemangi. Ayam rica kemangi siap dihidangkan. :)




Demikianlah cara membuat ayam rica kemangi yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
