---
description: "Panduan untuk membuat Ayam Rica-rica Kemangi Homemade"
title: "Panduan untuk membuat Ayam Rica-rica Kemangi Homemade"
slug: 274-panduan-untuk-membuat-ayam-rica-rica-kemangi-homemade
date: 2020-08-30T17:52:32.577Z
image: https://img-global.cpcdn.com/recipes/3a5f3a9cac617667/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3a5f3a9cac617667/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3a5f3a9cac617667/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Essie Carr
ratingvalue: 4.5
reviewcount: 10012
recipeingredient:
- "500 gram ayam"
- "1 lembar daun salam"
- "1 lembar daun jeruk"
- "1 batang serai geprek"
- "1 ikat daun kemangi"
- " Penyedap rasa"
- "secukupnya Himsalt"
- "secukupnya Minyak goreng"
- " Bumbu Halus"
- "5 siung bawang putih"
- "7 siung bawang merah"
- "5 butir cabe merah"
- "7 butir cabe rawit"
- "1 ruas kunyit bakar"
- "2 cm jahe"
- "1 sdt ketumbar bubuk"
- "3 butir kemiri"
recipeinstructions:
- "Rebus ayam 15 menit sampai berubah warna"
- "Sisihkan ayam, blender bumbu halus, dan tumis sampai harum"
- "Tambahkan serai, daun salam, daun jeruk. Beri sedikit air, lalu masukkan ayam aduk-aduk sampai bumbu meresap dan berubah warna kurleb 20 menit"
- "Masukkan himsalt dan penyedap rasa, tes rasa. Kalo sudah oke masukkan kemangi, aduk sebentar dan matikan kompor"
- "Ayam rica-rica kemangi siap disajikan"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 161 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/3a5f3a9cac617667/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga renyah. Karasteristik kuliner Nusantara ayam rica-rica kemangi yang penuh dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga dapat diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Rica-rica Kemangi untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang dapat anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Kemangi:

1. Diperlukan 500 gram ayam
1. Siapkan 1 lembar daun salam
1. Jangan lupa 1 lembar daun jeruk
1. Harus ada 1 batang serai geprek
1. Jangan lupa 1 ikat daun kemangi
1. Harus ada  Penyedap rasa
1. Harus ada secukupnya Himsalt
1. Diperlukan secukupnya Minyak goreng
1. Harus ada  Bumbu Halus
1. Harus ada 5 siung bawang putih
1. Siapkan 7 siung bawang merah
1. Dibutuhkan 5 butir cabe merah
1. Siapkan 7 butir cabe rawit
1. Diperlukan 1 ruas kunyit bakar
1. Harap siapkan 2 cm jahe
1. Siapkan 1 sdt ketumbar bubuk
1. Diperlukan 3 butir kemiri




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-rica Kemangi:

1. Rebus ayam 15 menit sampai berubah warna
1. Sisihkan ayam, blender bumbu halus, dan tumis sampai harum
1. Tambahkan serai, daun salam, daun jeruk. Beri sedikit air, lalu masukkan ayam aduk-aduk sampai bumbu meresap dan berubah warna kurleb 20 menit
1. Masukkan himsalt dan penyedap rasa, tes rasa. Kalo sudah oke masukkan kemangi, aduk sebentar dan matikan kompor
1. Ayam rica-rica kemangi siap disajikan




Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
