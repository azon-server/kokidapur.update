---
description: "Step-by-Step membuat Ayam Rica-rica Kemangi Luar biasa"
title: "Step-by-Step membuat Ayam Rica-rica Kemangi Luar biasa"
slug: 333-step-by-step-membuat-ayam-rica-rica-kemangi-luar-biasa
date: 2020-12-18T04:36:57.359Z
image: https://img-global.cpcdn.com/recipes/af5acf679de6336c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/af5acf679de6336c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/af5acf679de6336c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Ora Greer
ratingvalue: 4.7
reviewcount: 21316
recipeingredient:
- "1/2 kg ayam potong ukuran kecil"
- "1 ikat kemangi"
- "2 lembar daun jeruk potong kecilkecil"
- "2 lembar daun salam"
- "1 batang sereh memarkan"
- "1 cm lengkuas memarkan"
- "1 lembar daun pandan"
- "1 potong jeruk nipislemon"
- "secukupnya kunyit bubuk"
- "1/2 sdt garam sesuai selera"
- "1/2 sdt kaldu jamur"
- "secukupnya merica bubuk"
- "4 sdm minyak untuk menumis"
- "1/2 gelas belimbing air"
- " Bumbu halus"
- "5 buah cabe keriting merah  2 buah cabe kriting"
- "2 cm kunyit"
- "2 siung bawang putih"
- "10 buah cabe rawit  sesuai selera"
- "2 buah kemiri"
recipeinstructions:
- "Potong ayam menjadi ukuran kecil, kemudian baluri dengan 1/4 sdt garam, kunyit bubuk dan perasan jeruk nipis, biarkan sekitar 10 menit"
- "Goreng ayam sampai setengah kering, tiriskan"
- "Tumis bumbu halus, daun jeruk, daun pandan, daun salam, sereh, dan lengkuas sampai wangi"
- "Masukkan ayam yang telah digoreng, tambahkan air, garam, dan kaldu, kemudian aduk sampai rata, koreksi rasa"
- "Jika air sudah agak menyusut, masukkan daun kemangi, aduk rata, kemudian sajikan"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 288 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/af5acf679de6336c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang patut kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica-rica kemangi yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa kesan tersendiri yang merupakan keragaman Kita



Keharmonisan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah memasak Ayam Rica-rica Kemangi untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang dapat anda contoh salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Kemangi:

1. Dibutuhkan 1/2 kg ayam, potong ukuran kecil
1. Dibutuhkan 1 ikat kemangi
1. Tambah 2 lembar daun jeruk, potong kecil-kecil
1. Tambah 2 lembar daun salam
1. Siapkan 1 batang sereh, memarkan
1. Diperlukan 1 cm lengkuas, memarkan
1. Harap siapkan 1 lembar daun pandan
1. Harap siapkan 1 potong jeruk nipis/lemon
1. Harus ada secukupnya kunyit bubuk
1. Dibutuhkan 1/2 sdt garam (sesuai selera)
1. Siapkan 1/2 sdt kaldu jamur
1. Dibutuhkan secukupnya merica bubuk
1. Harap siapkan 4 sdm minyak untuk menumis
1. Jangan lupa 1/2 gelas belimbing air
1. Diperlukan  Bumbu halus
1. Diperlukan 5 buah cabe keriting merah / 2 buah cabe kriting
1. Diperlukan 2 cm kunyit
1. Diperlukan 2 siung bawang putih
1. Harus ada 10 buah cabe rawit / sesuai selera
1. Jangan lupa 2 buah kemiri




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-rica Kemangi:

1. Potong ayam menjadi ukuran kecil, kemudian baluri dengan 1/4 sdt garam, kunyit bubuk dan perasan jeruk nipis, biarkan sekitar 10 menit
1. Goreng ayam sampai setengah kering, tiriskan
1. Tumis bumbu halus, daun jeruk, daun pandan, daun salam, sereh, dan lengkuas sampai wangi
1. Masukkan ayam yang telah digoreng, tambahkan air, garam, dan kaldu, kemudian aduk sampai rata, koreksi rasa
1. Jika air sudah agak menyusut, masukkan daun kemangi, aduk rata, kemudian sajikan




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan teruji, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
