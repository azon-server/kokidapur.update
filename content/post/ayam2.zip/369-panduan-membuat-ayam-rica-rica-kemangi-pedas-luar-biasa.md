---
description: "Panduan membuat Ayam rica rica kemangi pedas Luar biasa"
title: "Panduan membuat Ayam rica rica kemangi pedas Luar biasa"
slug: 369-panduan-membuat-ayam-rica-rica-kemangi-pedas-luar-biasa
date: 2020-11-23T13:38:13.190Z
image: https://img-global.cpcdn.com/recipes/e5c02061fbe84eb4/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e5c02061fbe84eb4/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e5c02061fbe84eb4/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
author: Allie Washington
ratingvalue: 4.5
reviewcount: 38647
recipeingredient:
- "1/2 kg Ayam"
- "2 ikat kemangi"
- "1 jeruk nipis"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "1 batang serai di memarkan"
- "secukupnya Minyak goreng"
- "secukupnya Air"
- "secukupnya Garam"
- "secukupnya Gula pasir"
- "secukupnya Penyedap rasa"
- " Bumbu halus"
- "1 ons cabe setan"
- "7 bawang merah"
- "3 bawang putih"
- "2 kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
recipeinstructions:
- "Cuci bersih ayam beri perasan jeruk nipis bilas lalu ungkap ayam beri sedikit garam setelah mendidih tiriskan"
- "Panaskan minyak, goreang ayam hingga kecoklatan. Angakat tiriskan"
- "Petik kemangi lalu di cuci dan tiriskan"
- "Panaskan minyak, masukkan bumbu yang di haluskan tadi masukkan serai yg sudah si memarkan, aduk tunggu hingga wangi beri garam, gula dan penyedap rasa"
- "Masukkan kemangi tunggu hingga layu masukkan ayam dan masukkan air secukupnya tunggu mendidih dan bumbu meresap ke ayam"
- "Angkat lalu pindahkan ke dalam piring"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 232 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica rica kemangi pedas](https://img-global.cpcdn.com/recipes/e5c02061fbe84eb4/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica rica kemangi pedas yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Kita



Kedekatan keluarga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam rica rica kemangi pedas untuk keluarga. Momen makan bersama anak sudah menjadi kultur, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang bisa anda contoh salah satunya ayam rica rica kemangi pedas yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep ayam rica rica kemangi pedas tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi pedas yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi pedas:

1. Dibutuhkan 1/2 kg Ayam
1. Siapkan 2 ikat kemangi
1. Diperlukan 1 jeruk nipis
1. Siapkan 2 lembar daun jeruk
1. Siapkan 2 lembar daun salam
1. Harap siapkan 1 batang serai (di memarkan)
1. Dibutuhkan secukupnya Minyak goreng
1. Dibutuhkan secukupnya Air
1. Harus ada secukupnya Garam
1. Jangan lupa secukupnya Gula pasir
1. Dibutuhkan secukupnya Penyedap rasa
1. Diperlukan  Bumbu halus
1. Diperlukan 1 ons cabe setan
1. Dibutuhkan 7 bawang merah
1. Siapkan 3 bawang putih
1. Siapkan 2 kemiri
1. Tambah 1 ruas jahe
1. Tambah 1 ruas kunyit




<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica kemangi pedas:

1. Cuci bersih ayam beri perasan jeruk nipis bilas lalu ungkap ayam beri sedikit garam setelah mendidih tiriskan
1. Panaskan minyak, goreang ayam hingga kecoklatan. Angakat tiriskan
1. Petik kemangi lalu di cuci dan tiriskan
1. Panaskan minyak, masukkan bumbu yang di haluskan tadi masukkan serai yg sudah si memarkan, aduk tunggu hingga wangi beri garam, gula dan penyedap rasa
1. Masukkan kemangi tunggu hingga layu masukkan ayam dan masukkan air secukupnya tunggu mendidih dan bumbu meresap ke ayam
1. Angkat lalu pindahkan ke dalam piring




Demikianlah cara membuat ayam rica rica kemangi pedas yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan terbukti, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
