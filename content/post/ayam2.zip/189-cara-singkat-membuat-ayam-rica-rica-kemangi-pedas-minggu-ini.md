---
description: "Cara singkat membuat Ayam Rica Rica Kemangi Pedas minggu ini"
title: "Cara singkat membuat Ayam Rica Rica Kemangi Pedas minggu ini"
slug: 189-cara-singkat-membuat-ayam-rica-rica-kemangi-pedas-minggu-ini
date: 2021-02-02T23:35:14.866Z
image: https://img-global.cpcdn.com/recipes/f3c0b0e15b3eccba/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f3c0b0e15b3eccba/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f3c0b0e15b3eccba/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
author: Ella Spencer
ratingvalue: 4.9
reviewcount: 39527
recipeingredient:
- "6 Potong Ayam"
- "2 ikat daun kemangi"
recipeinstructions:
- "Potong Ayam menjadi 6 bagian"
- "Didihkan air Rebus ayam selama 10 menit supaya empuk dan agak lunak dan tambahkan sedikit jahe di geprek agar ayam tidak terlalu amis"
- "Bumbu Pelengkap : Daun Salam 2 lembar, Daun jeruk 2 lembar, lenkuas seruas jari di geprek, jahe seruas jari, daun sereh 2 ruas di geprek, kunyit 1 ruas jari di bakar, Bahan Bahan Dihaluskan : Cabai keriting 7 pcs cabai rawit 10 pcs bawang merah 9 siung bawang putih 3 siung kemiri 4 di sangrai ketumbar di sangrai merica bubuk masako ayam mecin garam gula"
- "Tumis bumbu yang sudah di haluskan sampai sudah tercium wangi aroma nya kemudian masukan ayam yang sudah di rebus beri sedikt air tambahkan bumbu penyedap setelah itu koreksi rasa"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 144 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica Rica Kemangi Pedas](https://img-global.cpcdn.com/recipes/f3c0b0e15b3eccba/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica rica kemangi pedas yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Indonesia

Rica-rica dalam bahasa Manado (Sulawesi Utara) berarti pedas atau cabe. dalam proses masaknya beraneka ragam. Masakan kali ini dengan menambah daun kemangi. Lihat juga resep Ayam Rica Kemangi Pedas Nampol enak lainnya. Bawang putih, cincang•cabe rawit merah (sesukanya, tergantung mau level berapa tingkat kepedasannya)•bawang bombay, cincang•ayam paha dan dada beli di Superindo (saya.

Keharmonisan keluarga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Ayam Rica Rica Kemangi Pedas untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi resep yang bisa anda buat salah satunya ayam rica rica kemangi pedas yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica rica kemangi pedas tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi Pedas yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 2 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi Pedas:

1. Harap siapkan 6 Potong Ayam
1. Jangan lupa 2 ikat daun kemangi


Resep ayam rica rica merupakan masakan selera pedas Resep rica rica sendiri sebenarnya tidak harus menggunakan bahan daging ayam saja. Cita rasa pedas menjadi ciri khas resep yang tergabung. Resep Ayam Rica - Rica Pedas Enak dan Spesial Untuk Keluarga - Asal muasal dari resep ayam rica-rica ini berasal dari daerah Manado - Sul. Rica merupakan bahasa Manado yang berarti pedas, bisa dimaknai bahwa kuliner ini merupakan ayam yang diberi bumbu pedas. 

<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica Kemangi Pedas:

1. Potong Ayam menjadi 6 bagian
1. Didihkan air Rebus ayam selama 10 menit supaya empuk dan agak lunak dan tambahkan sedikit jahe di geprek agar ayam tidak terlalu amis
1. Bumbu Pelengkap : Daun Salam 2 lembar, Daun jeruk 2 lembar, lenkuas seruas jari di geprek, jahe seruas jari, daun sereh 2 ruas di geprek, kunyit 1 ruas jari di bakar, Bahan Bahan Dihaluskan : Cabai keriting 7 pcs cabai rawit 10 pcs bawang merah 9 siung bawang putih 3 siung kemiri 4 di sangrai ketumbar di sangrai merica bubuk masako ayam mecin garam gula
1. Tumis bumbu yang sudah di haluskan sampai sudah tercium wangi aroma nya kemudian masukan ayam yang sudah di rebus beri sedikt air tambahkan bumbu penyedap setelah itu koreksi rasa


Resep Ayam Rica - Rica Pedas Enak dan Spesial Untuk Keluarga - Asal muasal dari resep ayam rica-rica ini berasal dari daerah Manado - Sul. Rica merupakan bahasa Manado yang berarti pedas, bisa dimaknai bahwa kuliner ini merupakan ayam yang diberi bumbu pedas. Nah, untuk membuat resep Ayam Rica Kemangi khas Manado ini, tentu ada beberapa hal yang harus diperhatikan. Bumbu rica-rica khas Manado bisa dipadukan dengan aneka bahan, seperti ayam. Coba membuat ayam panggang bumbu rica-rica berdasarkan resep ini. 

Demikianlah cara membuat ayam rica rica kemangi pedas yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan terbukti, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
