---
description: "Step-by-Step untuk membuat Ayam Rica-rica Kemangi minggu ini"
title: "Step-by-Step untuk membuat Ayam Rica-rica Kemangi minggu ini"
slug: 191-step-by-step-untuk-membuat-ayam-rica-rica-kemangi-minggu-ini
date: 2021-01-13T05:42:57.562Z
image: https://img-global.cpcdn.com/recipes/f0b137ae18b5a89e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f0b137ae18b5a89e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f0b137ae18b5a89e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Isabella Osborne
ratingvalue: 4.8
reviewcount: 46634
recipeingredient:
- "1/2 kg Ayam Potong"
- "1/2 potong jeruk nipis"
- " bumbu halus"
- "3 buah bawang putih"
- "5 buah bawang merah"
- "5 buah cabe merah besar"
- "10 buah cabe rawit kecil sesuai selera"
- "1/2 cm jahe"
- "Sedikit kunyit"
- "3 buah kemiri"
- " bahan tumis"
- "secukupnya Garam"
- "secukupnya Gula"
- " Penyedap rasa"
- "4 lembar daun jeruk"
- "2 buah sereh digeprek"
- "1/2 ruas lengkuas"
- "2 lembar daun salam"
- "1 ikat daun kemangi"
recipeinstructions:
- "Cuci bersih ayam, kemudian lumuri ayam dengan jeruk nipis. Diamkan selama 5-10 menit.kemudian goreng setengah matang."
- "Blender semua bumbu halus, kemudian tambahan minyak, tumis bumbu hingga wangi.masukkan bahan tumis, aduk rata hingga bumbu matang pekat."
- "Kemudian masukkan ayam potong, aduk sebentar. Tambahkan air secukupnya. Setelah itu tambahkan gula, garam dan penyedap rasa."
- "Tutup sebentar biarkan meresap. Setelah meresap koreksi rasa, matikan kompor dan masukkan daun kemangi."
- "Siap untuk dinikmati..."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 241 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/f0b137ae18b5a89e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang harus kita lestarikan karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Indonesia



Keharmonisan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah memasak Ayam Rica-rica Kemangi untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang bisa anda contoh salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica Kemangi:

1. Dibutuhkan 1/2 kg Ayam Potong
1. Siapkan 1/2 potong jeruk nipis
1. Tambah  bumbu halus
1. Dibutuhkan 3 buah bawang putih
1. Harap siapkan 5 buah bawang merah
1. Jangan lupa 5 buah cabe merah besar
1. Dibutuhkan 10 buah cabe rawit kecil (sesuai selera)
1. Jangan lupa 1/2 cm jahe
1. Siapkan Sedikit kunyit
1. Dibutuhkan 3 buah kemiri
1. Harap siapkan  bahan tumis
1. Tambah secukupnya Garam
1. Dibutuhkan secukupnya Gula
1. Harap siapkan  Penyedap rasa
1. Harus ada 4 lembar daun jeruk
1. Harus ada 2 buah sereh (digeprek)
1. Harus ada 1/2 ruas lengkuas
1. Siapkan 2 lembar daun salam
1. Tambah 1 ikat daun kemangi




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-rica Kemangi:

1. Cuci bersih ayam, kemudian lumuri ayam dengan jeruk nipis. Diamkan selama 5-10 menit.kemudian goreng setengah matang.
1. Blender semua bumbu halus, kemudian tambahan minyak, tumis bumbu hingga wangi.masukkan bahan tumis, aduk rata hingga bumbu matang pekat.
1. Kemudian masukkan ayam potong, aduk sebentar. Tambahkan air secukupnya. Setelah itu tambahkan gula, garam dan penyedap rasa.
1. Tutup sebentar biarkan meresap. Setelah meresap koreksi rasa, matikan kompor dan masukkan daun kemangi.
1. Siap untuk dinikmati...




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
