---
description: "Langkah membuat Ayam geprek sambal matah ala bensu Terbukti"
title: "Langkah membuat Ayam geprek sambal matah ala bensu Terbukti"
slug: 11-langkah-membuat-ayam-geprek-sambal-matah-ala-bensu-terbukti
date: 2020-09-25T19:57:38.052Z
image: https://img-global.cpcdn.com/recipes/7967e5ba7509d3ef/751x532cq70/ayam-geprek-sambal-matah-ala-bensu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7967e5ba7509d3ef/751x532cq70/ayam-geprek-sambal-matah-ala-bensu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7967e5ba7509d3ef/751x532cq70/ayam-geprek-sambal-matah-ala-bensu-foto-resep-utama.jpg
author: Adrian Griffith
ratingvalue: 4.6
reviewcount: 47573
recipeingredient:
- "1/2 ekor ayam"
- " Bahan tepung"
- "16 sdm tepung beras"
- "10 sdm tepung terigu"
- "1/2 sdm garam"
- "1/2 sdm kaldu jamur"
- " Minyak buat menggoreng"
- " Bahan sambal matah"
- "15 rawit jablay potong bulet"
- "3 batang sereh potong bulet"
- "10 bawang berah potong bulet"
- "3 lmbar daun jeruk iris halus"
- "1 buah jeruk limo peras"
- "1/2 tomat uk Besar potong dadu kecil"
- "secukupnya Garam kaldu gula pasir"
- "5 sdm Minyak panaskan"
recipeinstructions:
- "Cuci bersih ayam"
- "Campurkan semua bahan tepung lalu bagi 2 buat yg basah sma yg kering lalu celupkan ayam ke adonan basah lalu gulingkan ke adonan kering lakukan 2x biar krispy lalu siapkan wajan buat menggorng minyak harus bener&#34; panas goreng dngn api kecil sampai mateng angkt tata d piring"
- "Buat bahan sambel campurkan semua bahan lalu panaskan minyak smpai bener &#34; panas angkt dan siram ke bahan sambel aduk lalu tuang d atas ayam dan sajikan"
- "Selamat mencoba 😁😁"
categories:
- Recipe
tags:
- ayam
- geprek
- sambal

katakunci: ayam geprek sambal 
nutrition: 290 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT44M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam geprek sambal matah ala bensu](https://img-global.cpcdn.com/recipes/7967e5ba7509d3ef/751x532cq70/ayam-geprek-sambal-matah-ala-bensu-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau gurih. Ciri makanan Indonesia ayam geprek sambal matah ala bensu yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Keharmonisan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam geprek sambal matah ala bensu untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang dapat anda praktekkan salah satunya ayam geprek sambal matah ala bensu yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep ayam geprek sambal matah ala bensu tanpa harus bersusah payah.
Seperti resep Ayam geprek sambal matah ala bensu yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam geprek sambal matah ala bensu:

1. Harus ada 1/2 ekor ayam
1. Tambah  Bahan tepung
1. Harap siapkan 16 sdm tepung beras
1. Diperlukan 10 sdm tepung terigu
1. Tambah 1/2 sdm garam
1. Jangan lupa 1/2 sdm kaldu jamur
1. Tambah  Minyak buat menggoreng
1. Tambah  Bahan sambal matah
1. Harus ada 15 rawit jablay potong bulet
1. Dibutuhkan 3 batang sereh potong bulet
1. Siapkan 10 bawang berah potong bulet
1. Siapkan 3 lmbar daun jeruk iris halus
1. Dibutuhkan 1 buah jeruk limo peras
1. Diperlukan 1/2 tomat uk. Besar potong dadu kecil
1. Tambah secukupnya Garam, kaldu, gula pasir
1. Jangan lupa 5 sdm Minyak panaskan




<!--inarticleads2-->

##### Cara membuat  Ayam geprek sambal matah ala bensu:

1. Cuci bersih ayam
1. Campurkan semua bahan tepung lalu bagi 2 buat yg basah sma yg kering lalu celupkan ayam ke adonan basah lalu gulingkan ke adonan kering lakukan 2x biar krispy lalu siapkan wajan buat menggorng minyak harus bener&#34; panas goreng dngn api kecil sampai mateng angkt tata d piring
1. Buat bahan sambel campurkan semua bahan lalu panaskan minyak smpai bener &#34; panas angkt dan siram ke bahan sambel aduk lalu tuang d atas ayam dan sajikan
1. Selamat mencoba 😁😁




Demikianlah cara membuat ayam geprek sambal matah ala bensu yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan terbukti, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
