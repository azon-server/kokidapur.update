---
description: "Step-by-Step membuat Ayam rica kemangi lezat Luar biasa"
title: "Step-by-Step membuat Ayam rica kemangi lezat Luar biasa"
slug: 323-step-by-step-membuat-ayam-rica-kemangi-lezat-luar-biasa
date: 2020-12-31T02:47:33.793Z
image: https://img-global.cpcdn.com/recipes/2af74df84e67856f/751x532cq70/ayam-rica-kemangi-lezat-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2af74df84e67856f/751x532cq70/ayam-rica-kemangi-lezat-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2af74df84e67856f/751x532cq70/ayam-rica-kemangi-lezat-foto-resep-utama.jpg
author: Russell Bass
ratingvalue: 4.1
reviewcount: 47624
recipeingredient:
- "1 kg Ayam"
- "2 ikat Kemangi"
- " Bumbu halus"
- " Cabe rawit sesuai selera saya sih suka pedes jdi banyak bgt tuh si rawit"
- "4 biji Cabe merah"
- "1 ruas kunyit"
- "1 ruas jahe"
- "4 buah kemiri"
- "6 buah bawang merah"
- "4 buah bawang putih"
- "1 ruas laos"
- " Daun salam"
- " Sereh"
- "secukupnya Gula pasir"
- " Garam"
- " Penyedap rasa"
- " Mecin klo gak doyan skip aja"
recipeinstructions:
- "Rebus ayam sampe empuk bgt (bisa d kukus juga)"
- "Halus kan semua bumbu halus(klo bisa haluskan dlu selain cabecabean 😁) cabecabean terakhir ajaa biar endullss"
- "Tumis bumbu halus sampe harum masukan sereh dan salam"
- "Setelah harum masukan ayam yg sudah d rebus tdi sampee empuk bgt, setengah perjalanan masukan kemangi,, cicipi sesuai selera yaaaa"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 161 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica kemangi lezat](https://img-global.cpcdn.com/recipes/2af74df84e67856f/751x532cq70/ayam-rica-kemangi-lezat-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau renyah. Ciri khas kuliner Indonesia ayam rica kemangi lezat yang kaya dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Ayam rica kemangi lezat untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang bisa anda coba salah satunya ayam rica kemangi lezat yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep ayam rica kemangi lezat tanpa harus bersusah payah.
Berikut ini resep Ayam rica kemangi lezat yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica kemangi lezat:

1. Siapkan 1 kg Ayam
1. Jangan lupa 2 ikat Kemangi
1. Harus ada  Bumbu halus
1. Harap siapkan  Cabe rawit (sesuai selera saya sih suka pedes jdi banyak bgt tuh si rawit)
1. Tambah 4 biji Cabe merah
1. Dibutuhkan 1 ruas kunyit
1. Jangan lupa 1 ruas jahe
1. Jangan lupa 4 buah kemiri
1. Jangan lupa 6 buah bawang merah
1. Harap siapkan 4 buah bawang putih
1. Tambah 1 ruas laos
1. Siapkan  Daun salam
1. Harap siapkan  Sereh
1. Diperlukan secukupnya Gula pasir
1. Harap siapkan  Garam
1. Dibutuhkan  Penyedap rasa
1. Diperlukan  Mecin (klo gak doyan skip aja)




<!--inarticleads2-->

##### Cara membuat  Ayam rica kemangi lezat:

1. Rebus ayam sampe empuk bgt (bisa d kukus juga)
1. Halus kan semua bumbu halus(klo bisa haluskan dlu selain cabecabean 😁) cabecabean terakhir ajaa biar endullss
1. Tumis bumbu halus sampe harum masukan sereh dan salam
1. Setelah harum masukan ayam yg sudah d rebus tdi sampee empuk bgt, setengah perjalanan masukan kemangi,, cicipi sesuai selera yaaaa




Demikianlah cara membuat ayam rica kemangi lezat yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan terbukti, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
