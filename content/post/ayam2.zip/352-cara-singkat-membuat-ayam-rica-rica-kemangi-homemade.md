---
description: "Cara singkat membuat Ayam rica - rica kemangi Homemade"
title: "Cara singkat membuat Ayam rica - rica kemangi Homemade"
slug: 352-cara-singkat-membuat-ayam-rica-rica-kemangi-homemade
date: 2020-12-12T04:19:52.612Z
image: https://img-global.cpcdn.com/recipes/755a41e32235d00a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/755a41e32235d00a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/755a41e32235d00a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Russell Patterson
ratingvalue: 4.5
reviewcount: 18694
recipeingredient:
- " Bahan "
- "4 Paha ayam potong potong kecil"
- "1 sereh"
- "3 daun jeruk"
- "1 iris lengkuas geprek"
- "3 iris jahe geprek"
- "2 daun salam"
- "1 ikat kemangi"
- "Secukupnya kecap"
- "selera Gula pasir kalau"
- "Secukupnya air"
- "Secukupnya minyak goreng"
- " Bahan Bumbu dihaluskan"
- "3 siung bawang merah"
- "2 siung bawang putih"
- "1 bungkus lada bubuk"
- "5 cabai merah"
- "3 cabai rawit"
- "1/2 sdm garam"
recipeinstructions:
- "Haluskan Bumbu, lalu ayam paha direbus hingga matang"
- "Lalu panaskan minyak,tumis bumbu halus dimasukan sereh,daun jeruk,daun salam,lengkuas, jahe, dan lada bubuk jangan lupa diberi gula, garam sesuai selera."
- "Jika sudah beraroma lalu paha ayam dimasukkan"
- "Jangan lupa tambahkan air secukupnya"
- "Jika sudah pas rasakan ayam paha, yang sudah digoreng serta kemangi, jika sudah pas bisa langsung disajikan."
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 267 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam rica - rica kemangi](https://img-global.cpcdn.com/recipes/755a41e32235d00a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang harus kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica - rica kemangi yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan ciri khas yang merupakan keragaman Nusantara



Keharmonisan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam rica - rica kemangi untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang dapat anda buat salah satunya ayam rica - rica kemangi yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica - rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica - rica kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica - rica kemangi:

1. Siapkan  Bahan :
1. Tambah 4 Paha ayam potong (potong kecil&#34;)
1. Dibutuhkan 1 sereh
1. Harus ada 3 daun jeruk
1. Harus ada 1 iris lengkuas (geprek)
1. Diperlukan 3 iris jahe (geprek)
1. Jangan lupa 2 daun salam
1. Harus ada 1 ikat kemangi
1. Diperlukan Secukupnya kecap
1. Harap siapkan selera Gula pasir kalau
1. Dibutuhkan Secukupnya air
1. Jangan lupa Secukupnya minyak goreng
1. Harus ada  Bahan Bumbu :(dihaluskan)
1. Diperlukan 3 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Siapkan 1 bungkus lada bubuk
1. Harap siapkan 5 cabai merah
1. Harus ada 3 cabai rawit
1. Siapkan 1/2 sdm garam




<!--inarticleads2-->

##### Langkah membuat  Ayam rica - rica kemangi:

1. Haluskan Bumbu, lalu ayam paha direbus hingga matang
1. Lalu panaskan minyak,tumis bumbu halus dimasukan sereh,daun jeruk,daun salam,lengkuas, jahe, dan lada bubuk jangan lupa diberi gula, garam sesuai selera.
1. Jika sudah beraroma lalu paha ayam dimasukkan
1. Jangan lupa tambahkan air secukupnya
1. Jika sudah pas rasakan ayam paha, yang sudah digoreng serta kemangi, jika sudah pas bisa langsung disajikan.




Demikianlah cara membuat ayam rica - rica kemangi yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
