---
description: "Bagaimana untuk membuat Ayam rica rica kemangi terupdate"
title: "Bagaimana untuk membuat Ayam rica rica kemangi terupdate"
slug: 200-bagaimana-untuk-membuat-ayam-rica-rica-kemangi-terupdate
date: 2020-10-09T16:53:42.133Z
image: https://img-global.cpcdn.com/recipes/487b5054e66b7d5f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/487b5054e66b7d5f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/487b5054e66b7d5f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Calvin Griffith
ratingvalue: 4.5
reviewcount: 9142
recipeingredient:
- "5 potong ayam"
- "1 ikat kemangi"
- "4 daun jeruk"
- "1 sereh"
- "2 ruas lengkuas"
- "1 tomat"
- "1 masako"
- "1 jeruk nipis"
- " Bahan halus"
- "5 bawang merah"
- "3 bawang putih"
- "20 cabe rawit"
- "6 cabe merah"
- "2 ruas kunyit"
- "1 ruas jahe"
- "3 kemiri"
recipeinstructions:
- "5 potong ayam, dipotong jadi 3 bagian lagi, cuci bersih lalu beri perasan jeruk nipis, sisihkan"
- "Siapkan bumbu halus dan blender. Tomat di potong², kemangi ambil daunnya saja"
- "Panaskan minyak, tumis bumbu halus hingga harum, masukkan tomat, daun jeruk, sereh geprek dan lengkuas geprek, tumis sampai bumbu berwarna pekat."
- "Masukkan ayam, aduk sampai benar² rata. Tambahkan air sedikit, aduk sampai tercampur rata, tutup masakan dan diamkan sejenak sampai ayam empuk."
- "Masukkan kemangi dan masako, aduk sebentar. Masakan sudah siap dinikmati bersama nasi hangat 😉"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 125 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/487b5054e66b7d5f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica rica kemangi yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan ciri khas yang merupakan keragaman Nusantara



Kehangatan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam rica rica kemangi untuk keluarga. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang dapat anda contoh salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Harus ada 5 potong ayam
1. Diperlukan 1 ikat kemangi
1. Diperlukan 4 daun jeruk
1. Jangan lupa 1 sereh
1. Siapkan 2 ruas lengkuas
1. Jangan lupa 1 tomat
1. Siapkan 1 masako
1. Siapkan 1 jeruk nipis
1. Jangan lupa  Bahan halus
1. Harus ada 5 bawang merah
1. Siapkan 3 bawang putih
1. Harus ada 20 cabe rawit
1. Dibutuhkan 6 cabe merah
1. Siapkan 2 ruas kunyit
1. Diperlukan 1 ruas jahe
1. Jangan lupa 3 kemiri




<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica kemangi:

1. 5 potong ayam, dipotong jadi 3 bagian lagi, cuci bersih lalu beri perasan jeruk nipis, sisihkan
1. Siapkan bumbu halus dan blender. Tomat di potong², kemangi ambil daunnya saja
1. Panaskan minyak, tumis bumbu halus hingga harum, masukkan tomat, daun jeruk, sereh geprek dan lengkuas geprek, tumis sampai bumbu berwarna pekat.
1. Masukkan ayam, aduk sampai benar² rata. Tambahkan air sedikit, aduk sampai tercampur rata, tutup masakan dan diamkan sejenak sampai ayam empuk.
1. Masukkan kemangi dan masako, aduk sebentar. Masakan sudah siap dinikmati bersama nasi hangat 😉




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
