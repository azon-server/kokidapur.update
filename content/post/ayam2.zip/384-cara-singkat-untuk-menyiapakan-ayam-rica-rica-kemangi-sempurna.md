---
description: "Cara singkat untuk menyiapakan Ayam Rica-Rica Kemangi Sempurna"
title: "Cara singkat untuk menyiapakan Ayam Rica-Rica Kemangi Sempurna"
slug: 384-cara-singkat-untuk-menyiapakan-ayam-rica-rica-kemangi-sempurna
date: 2020-09-11T14:50:34.352Z
image: https://img-global.cpcdn.com/recipes/183ba02ee73557bf/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/183ba02ee73557bf/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/183ba02ee73557bf/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Justin Ortiz
ratingvalue: 4.1
reviewcount: 15988
recipeingredient:
- "2 dada ayam rebus suwir"
- "1/2 buah bawang bombay"
- "15 buah bawang merah"
- "10 buah bawang putih"
- "1 buah tomat"
- "10 cabe merah keriting"
- "1 buah kemiri"
- "1 sendok kunyit bubuk"
- "1 sendok ketumbar bubuk"
- "secukupnya Garam"
- "Secukupnya gula pasir"
- "2 lembar daun salam dan daun jeruk"
- "2 batang daun serai"
- " Kaldu ayam air rebusan ayam"
- "1 batang daun bawang"
- " Daun kemangi"
recipeinstructions:
- "Potong bawang bombay, haluskan bumbu dan tumis dengan minyak secukupnya sampai harum dan benar benar matang dan masukan daun salam, daun jeruk dan serai"
- "Setelah matang lalu masukan ayam rebus yang sudah disuir lalu masukan air kaldu masak dgn api sedang sampai meresap."
- "Setelah mau matang masuka daun kemangi dan daun bawang dan sajikan❤️"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 197 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT43M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/183ba02ee73557bf/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga renyah. Ciri khas makanan Indonesia ayam rica-rica kemangi yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan keluarga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Ayam Rica-Rica Kemangi untuk keluarga. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi resep yang bisa anda contoh salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica Kemangi:

1. Harus ada 2 dada ayam rebus (suwir)
1. Dibutuhkan 1/2 buah bawang bombay
1. Jangan lupa 15 buah bawang merah
1. Harap siapkan 10 buah bawang putih
1. Siapkan 1 buah tomat
1. Dibutuhkan 10 cabe merah keriting
1. Tambah 1 buah kemiri
1. Siapkan 1 sendok kunyit bubuk
1. Siapkan 1 sendok ketumbar bubuk
1. Diperlukan secukupnya Garam
1. Jangan lupa Secukupnya gula pasir
1. Dibutuhkan 2 lembar daun salam dan daun jeruk
1. Siapkan 2 batang daun serai
1. Diperlukan  Kaldu ayam (air rebusan ayam)
1. Dibutuhkan 1 batang daun bawang
1. Jangan lupa  Daun kemangi




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica Kemangi:

1. Potong bawang bombay, haluskan bumbu dan tumis dengan minyak secukupnya sampai harum dan benar benar matang dan masukan daun salam, daun jeruk dan serai
1. Setelah matang lalu masukan ayam rebus yang sudah disuir lalu masukan air kaldu masak dgn api sedang sampai meresap.
1. Setelah mau matang masuka daun kemangi dan daun bawang dan sajikan❤️




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan terbukti, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
