---
description: "Steps untuk menyiapakan Ayam Geprek Favorite"
title: "Steps untuk menyiapakan Ayam Geprek Favorite"
slug: 168-steps-untuk-menyiapakan-ayam-geprek-favorite
date: 2020-12-22T10:23:42.664Z
image: https://img-global.cpcdn.com/recipes/f1089db1fe2461bc/751x532cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f1089db1fe2461bc/751x532cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f1089db1fe2461bc/751x532cq70/ayam-geprek-foto-resep-utama.jpg
author: Mabel Barton
ratingvalue: 5
reviewcount: 39163
recipeingredient:
- " Bahan Ayam Crispy "
- "500 gr fillet dada ayam"
- "2 bungkus tepung bumbu sasa crispy"
- "Secukupnya garam dan lada"
- " Bahan Sambal "
- "15 buah cabai rawit merah sesuai selera"
- "7 siung bawang putih"
- "Secukupnya minyak panas"
- "Secukupnya garam dan penyedap rasa"
recipeinstructions:
- "Cuci bersih fillet ayam (klo saya di iris tipis2) lalu tusuk2 dg garpu/dipukul2 jg bisa.. Lumuri dg garam dan lada bubuk, diamkan sekitar 30 menit hingga bumbu meresap.."
- "Larutkan 1 bungkus tepung bumbu sasa dg air (untuk tepung basah) dan 1 bungkusnya lagi untuk tepung kering.."
- "Masukkan fillet ayam kedalam tepung basah, lalu masukkan ke tepung kering sambil dipijit2/dicubit2.. Agar tepungnya keriting dan crispy.."
- "Goreng ayam kedalam minyak panas hingga matang dan kecoklatan. Sisihkan.."
- "Untuk sambal : Goreng cabai rawit merah sebentar, hingga agak layu lalu angkat dan ulek agak kasar bersama bawang putih.. beri garam dan penyedap rasa lalu siram dg minyak panas.."
- "Geprek ayam di atas sambal lalu campur rata.. duuuh rasanya mantap bgt.. cabenya sesuai selera ya, klo resep sya ini pedesnya bener2 nampol, bikin dower 😂"
categories:
- Recipe
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 272 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT35M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/f1089db1fe2461bc/751x532cq70/ayam-geprek-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan gurih. Ciri masakan Indonesia ayam geprek yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ayam Geprek untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang dapat anda coba salah satunya ayam geprek yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam geprek tanpa harus bersusah payah.
Seperti resep Ayam Geprek yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 9 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek:

1. Harap siapkan  Bahan Ayam Crispy :
1. Diperlukan 500 gr fillet dada ayam
1. Siapkan 2 bungkus tepung bumbu sasa crispy
1. Tambah Secukupnya garam dan lada
1. Dibutuhkan  Bahan Sambal :
1. Harap siapkan 15 buah cabai rawit merah (sesuai selera)
1. Dibutuhkan 7 siung bawang putih
1. Harus ada Secukupnya minyak panas
1. Siapkan Secukupnya garam dan penyedap rasa




<!--inarticleads2-->

##### Cara membuat  Ayam Geprek:

1. Cuci bersih fillet ayam (klo saya di iris tipis2) lalu tusuk2 dg garpu/dipukul2 jg bisa.. Lumuri dg garam dan lada bubuk, diamkan sekitar 30 menit hingga bumbu meresap..
1. Larutkan 1 bungkus tepung bumbu sasa dg air (untuk tepung basah) dan 1 bungkusnya lagi untuk tepung kering..
1. Masukkan fillet ayam kedalam tepung basah, lalu masukkan ke tepung kering sambil dipijit2/dicubit2.. Agar tepungnya keriting dan crispy..
1. Goreng ayam kedalam minyak panas hingga matang dan kecoklatan. Sisihkan..
1. Untuk sambal : Goreng cabai rawit merah sebentar, hingga agak layu lalu angkat dan ulek agak kasar bersama bawang putih.. beri garam dan penyedap rasa lalu siram dg minyak panas..
1. Geprek ayam di atas sambal lalu campur rata.. duuuh rasanya mantap bgt.. cabenya sesuai selera ya, klo resep sya ini pedesnya bener2 nampol, bikin dower 😂




Demikianlah cara membuat ayam geprek yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
