---
description: "Steps menyiapakan 48. Ayam rica rica kemangi Teruji"
title: "Steps menyiapakan 48. Ayam rica rica kemangi Teruji"
slug: 264-steps-menyiapakan-48-ayam-rica-rica-kemangi-teruji
date: 2020-10-25T21:18:14.941Z
image: https://img-global.cpcdn.com/recipes/f181fa1d29b8a153/751x532cq70/48-ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f181fa1d29b8a153/751x532cq70/48-ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f181fa1d29b8a153/751x532cq70/48-ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Tommy Roy
ratingvalue: 4.5
reviewcount: 28386
recipeingredient:
- "1 kg ayam potong"
- "2 ikat kemangi"
- "400 ml air"
- " Bumbu halus"
- "5 siung bawang putih"
- "5 siung bawang merah"
- "1 sdm ketumbar sangrai"
- "8 biji cabe kecil"
- "6 biji cabe besar"
- "1 ruas kunyit"
- "1 ruas jahe"
- " Bumbu luar"
- " Serei"
- " Daun salam"
- " Daun jeruk"
- " Jeruk nipis"
- " Tomat"
- " Bumbu ungkep ayam"
- " Bawang merah"
- " Bawang putih"
- " Ketumbar"
- " Daun salam"
- " Jangan lupa garam gula ato penyedap rasa"
recipeinstructions:
- "Ungkep ayam terlebih dahulu, sampai empuk sisihkan"
- "Siapkan bumbu rica-rica, giling halus.dan.sebagain cabe ada yg diiris iris"
- "Tumis bumbu halus dan bumbu luar sampe harum"
- "Kemudian masukkan ayam dan tambahkan air"
- "Sudah agak meresap, masukkan tomat, perasan jeruk dan kemagi..aduk rata..cek rasa..rica rica siap dinikmati.."
categories:
- Recipe
tags:
- 48
- ayam
- rica

katakunci: 48 ayam rica 
nutrition: 133 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Dessert

---


![48. Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/f181fa1d29b8a153/751x532cq70/48-ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga empuk. Karasteristik masakan Indonesia 48. ayam rica rica kemangi yang kaya dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan 48. Ayam rica rica kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang dapat anda contoh salah satunya 48. ayam rica rica kemangi yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep 48. ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep 48. Ayam rica rica kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 23 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat 48. Ayam rica rica kemangi:

1. Siapkan 1 kg ayam potong
1. Harap siapkan 2 ikat kemangi
1. Tambah 400 ml air
1. Harus ada  Bumbu halus
1. Harus ada 5 siung bawang putih
1. Tambah 5 siung bawang merah
1. Harus ada 1 sdm ketumbar sangrai
1. Siapkan 8 biji cabe kecil
1. Tambah 6 biji cabe besar
1. Siapkan 1 ruas kunyit
1. Siapkan 1 ruas jahe
1. Harus ada  Bumbu luar
1. Harap siapkan  Serei
1. Dibutuhkan  Daun salam
1. Diperlukan  Daun jeruk
1. Tambah  Jeruk nipis
1. Dibutuhkan  Tomat
1. Harap siapkan  Bumbu ungkep ayam
1. Diperlukan  Bawang merah
1. Harus ada  Bawang putih
1. Siapkan  Ketumbar
1. Siapkan  Daun salam
1. Siapkan  Jangan lupa garam, gula ato penyedap rasa




<!--inarticleads2-->

##### Cara membuat  48. Ayam rica rica kemangi:

1. Ungkep ayam terlebih dahulu, sampai empuk sisihkan
1. Siapkan bumbu rica-rica, giling halus.dan.sebagain cabe ada yg diiris iris
1. Tumis bumbu halus dan bumbu luar sampe harum
1. Kemudian masukkan ayam dan tambahkan air
1. Sudah agak meresap, masukkan tomat, perasan jeruk dan kemagi..aduk rata..cek rasa..rica rica siap dinikmati..




Demikianlah cara membuat 48. ayam rica rica kemangi yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
