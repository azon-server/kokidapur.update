---
description: "Step-by-Step membuat Ayam geprek pedas ala bensu #week13 Cepat"
title: "Step-by-Step membuat Ayam geprek pedas ala bensu #week13 Cepat"
slug: 4-step-by-step-membuat-ayam-geprek-pedas-ala-bensu-week13-cepat
date: 2021-01-12T05:23:20.497Z
image: https://img-global.cpcdn.com/recipes/f0e7c0a5205b1bc9/751x532cq70/ayam-geprek-pedas-ala-bensu-week13-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f0e7c0a5205b1bc9/751x532cq70/ayam-geprek-pedas-ala-bensu-week13-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f0e7c0a5205b1bc9/751x532cq70/ayam-geprek-pedas-ala-bensu-week13-foto-resep-utama.jpg
author: Jose Howell
ratingvalue: 4.6
reviewcount: 16373
recipeingredient:
- "1/4 ayam me  1 paha 1 dada"
- " Bumbu marinasi"
- "3 siung bawang putih"
- "1/2 sdt merica bubuk"
- "Secukupnya garam"
- "Secukupnya penyedap rasa"
- " Pelapis"
- "1 butih telur"
- "5 sdm tepung terigubisa juga di ganti tepung bumbu"
- "3 sdm tepung maizena"
- " Bahan sambal"
- "17 buah cabe rawit"
- "3 siung bawang"
- "Sejumput garam"
- "Secukupnya kaldu bubuk bisa masako atau royco"
- "4 sdm minyak panas sisa goreng ayam"
recipeinstructions:
- "Haluskan bawang putih, campurkan dg bumbu marinasi lainnya kemudian masukkan ke dalam ayam yg telah di cuci bersih, aduk rata dan diamkan selama 2 jam agar bumbu meresap, setelah di diamkan 2 jam lalu tambahkan telur dan aduk rata"
- "Campurkan tepung terigu dan maizena, aduk rata, ambil ayam yg telah di campur dengan telur, gulingkan ke tepung sambil agak di cubit2 agar tepung kribo, celupkan lagi ke telur, kemudian gulingkan lagi ke tepung"
- "Setelah itu ayam selesai di tepungi, panaskan minyak dengan api sedang cenderung kecil, goreng hingga keemasan kemudian balik pelan2 (jangan di bolak balik agar ayam tidak berminyak stlh matang)"
- "Uleg cabe, bawang putih dan garam, kemudian tambahkan minyak panas sisa goreng ayam ke dalam sambal, geprek ayam dengan sambal dan ayam geprek siap di nikmati,, 😍😍"
- ""
categories:
- Recipe
tags:
- ayam
- geprek
- pedas

katakunci: ayam geprek pedas 
nutrition: 265 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam geprek pedas ala bensu #week13](https://img-global.cpcdn.com/recipes/f0e7c0a5205b1bc9/751x532cq70/ayam-geprek-pedas-ala-bensu-week13-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita jaga karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam geprek pedas ala bensu #week13 yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Indonesia

Kedekatan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam geprek pedas ala bensu #week13 untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi makanan yang bisa anda contoh salah satunya ayam geprek pedas ala bensu #week13 yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam geprek pedas ala bensu #week13 tanpa harus bersusah payah.
Berikut ini resep Ayam geprek pedas ala bensu #week13 yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam geprek pedas ala bensu #week13:

1. Tambah 1/4 ayam (me : 1 paha 1 dada)
1. Harap siapkan  Bumbu marinasi
1. Dibutuhkan 3 siung bawang putih
1. Tambah 1/2 sdt merica bubuk
1. Tambah Secukupnya garam
1. Siapkan Secukupnya penyedap rasa
1. Dibutuhkan  Pelapis
1. Harap siapkan 1 butih telur
1. Siapkan 5 sdm tepung terigu(bisa juga di ganti tepung bumbu)
1. Jangan lupa 3 sdm tepung maizena
1. Harap siapkan  Bahan sambal
1. Harus ada 17 buah cabe rawit
1. Diperlukan 3 siung bawang
1. Harus ada Sejumput garam
1. Dibutuhkan Secukupnya kaldu bubuk (bisa masako atau royco)
1. Tambah 4 sdm minyak panas sisa goreng ayam




<!--inarticleads2-->

##### Cara membuat  Ayam geprek pedas ala bensu #week13:

1. Haluskan bawang putih, campurkan dg bumbu marinasi lainnya kemudian masukkan ke dalam ayam yg telah di cuci bersih, aduk rata dan diamkan selama 2 jam agar bumbu meresap, setelah di diamkan 2 jam lalu tambahkan telur dan aduk rata
1. Campurkan tepung terigu dan maizena, aduk rata, ambil ayam yg telah di campur dengan telur, gulingkan ke tepung sambil agak di cubit2 agar tepung kribo, celupkan lagi ke telur, kemudian gulingkan lagi ke tepung
1. Setelah itu ayam selesai di tepungi, panaskan minyak dengan api sedang cenderung kecil, goreng hingga keemasan kemudian balik pelan2 (jangan di bolak balik agar ayam tidak berminyak stlh matang)
1. Uleg cabe, bawang putih dan garam, kemudian tambahkan minyak panas sisa goreng ayam ke dalam sambal, geprek ayam dengan sambal dan ayam geprek siap di nikmati,, 😍😍
1. 




Demikianlah cara membuat ayam geprek pedas ala bensu #week13 yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan teruji, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
