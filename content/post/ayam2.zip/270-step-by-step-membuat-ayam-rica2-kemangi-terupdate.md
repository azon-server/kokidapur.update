---
description: "Step-by-Step membuat Ayam rica2 kemangi terupdate"
title: "Step-by-Step membuat Ayam rica2 kemangi terupdate"
slug: 270-step-by-step-membuat-ayam-rica2-kemangi-terupdate
date: 2020-10-21T09:04:52.269Z
image: https://img-global.cpcdn.com/recipes/1b200a9c342befdf/751x532cq70/ayam-rica2-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1b200a9c342befdf/751x532cq70/ayam-rica2-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1b200a9c342befdf/751x532cq70/ayam-rica2-kemangi-foto-resep-utama.jpg
author: Corey Cain
ratingvalue: 4.8
reviewcount: 5902
recipeingredient:
- "6 potong ayam ungkep"
- "2 ikat kemangi"
- "2 lembar Daun salam"
- "3 lembar daun jeruk"
- "1 batang serai"
- " Garam"
- " Gula"
- " Penyedap rasa"
- "secukupnya Air"
- " Minyak untuk menumis"
- " Bumbu halus "
- "6 siung bawang merah"
- "3 siung bawang putih"
- "10 Cabe merah"
- "15 Cabe rawit merah"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 ruas lengkuas"
- "3 butir kemiri"
recipeinstructions:
- "Siangi kemangi petik daunnya dan cuci tiriskan.."
- "Goreng ayam ungkep hingga kuning keemasan.."
- "Panaskan minyak Tumis bumbu halus masukan daun jeruk sobek2 biar keluar bau harumnya.. Daun salam dan serai.. Tumis hingga harum dan masukan air.. Tambahkan garam,gula dan penyedap rasa.. Masukan ayam.. Aduk sesekali hingga bumbu meresap ke ayam.."
- "Setelah meresap masukan daun kemangi.. Aduk sebentar.. Ayam rica2 siap di santap dengan nasi hangat.."
categories:
- Recipe
tags:
- ayam
- rica2
- kemangi

katakunci: ayam rica2 kemangi 
nutrition: 300 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT30M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica2 kemangi](https://img-global.cpcdn.com/recipes/1b200a9c342befdf/751x532cq70/ayam-rica2-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica2 kemangi yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan keistimewahan yang merupakan keragaman Indonesia



Keharmonisan rumah tangga bisa diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Ayam rica2 kemangi untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, Banyak yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang dapat anda praktekkan salah satunya ayam rica2 kemangi yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam rica2 kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica2 kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica2 kemangi:

1. Diperlukan 6 potong ayam ungkep
1. Diperlukan 2 ikat kemangi
1. Harap siapkan 2 lembar Daun salam
1. Harap siapkan 3 lembar daun jeruk
1. Dibutuhkan 1 batang serai
1. Harus ada  Garam
1. Diperlukan  Gula
1. Tambah  Penyedap rasa
1. Siapkan secukupnya Air
1. Jangan lupa  Minyak untuk menumis
1. Harus ada  Bumbu halus :
1. Diperlukan 6 siung bawang merah
1. Harap siapkan 3 siung bawang putih
1. Dibutuhkan 10 Cabe merah
1. Dibutuhkan 15 Cabe rawit merah
1. Harap siapkan 1 ruas jahe
1. Harap siapkan 1 ruas kunyit
1. Jangan lupa 1 ruas lengkuas
1. Siapkan 3 butir kemiri




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica2 kemangi:

1. Siangi kemangi petik daunnya dan cuci tiriskan..
1. Goreng ayam ungkep hingga kuning keemasan..
1. Panaskan minyak Tumis bumbu halus masukan daun jeruk sobek2 biar keluar bau harumnya.. Daun salam dan serai.. Tumis hingga harum dan masukan air.. Tambahkan garam,gula dan penyedap rasa.. Masukan ayam.. Aduk sesekali hingga bumbu meresap ke ayam..
1. Setelah meresap masukan daun kemangi.. Aduk sebentar.. Ayam rica2 siap di santap dengan nasi hangat..




Demikianlah cara membuat ayam rica2 kemangi yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
