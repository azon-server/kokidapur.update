---
description: "Panduan menyiapakan Ayam Rica Kemangi minggu ini"
title: "Panduan menyiapakan Ayam Rica Kemangi minggu ini"
slug: 374-panduan-menyiapakan-ayam-rica-kemangi-minggu-ini
date: 2020-11-13T09:24:27.697Z
image: https://img-global.cpcdn.com/recipes/2af4e2ce228cf291/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2af4e2ce228cf291/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2af4e2ce228cf291/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Lee Greene
ratingvalue: 4.9
reviewcount: 4940
recipeingredient:
- "1 kg ayam"
- "1 ikat kemangi"
- "Secukupnya gula merah"
- "Secukupnya garam"
- "Secukupnya kaldu bubuk"
- "1 sdt lada bubuk"
- "2 sdm kecap manis"
- " Bumbu halus "
- "4 butir kemiri"
- "10 butir bawang merah"
- "6 siung bawang putih"
- "1 ruas kunyit"
- " Bumbu iris "
- "1 buah bawang bombai"
- "8 buah cabe rawit"
- " Rempahrempah"
- "1 jempol jahe"
- "2 potong lengkuas"
- "5 lembar daun jeruk iris halus"
- "2 batang serai ambil putihnya iris halus"
- "3 lembar daun pandan potong besar"
recipeinstructions:
- "Tumis bumbu iris sampai layu lalu masukkan bumbu halus. Tumis sampai matang"
- "Masukkan ayam aduk-aduk sampai rata. Setelah beberapa saat masukkan air tunggu mendidih baru masukkan rempah Gula Garam kaldu dan lada"
- "Tambahkan kecap manis dan masak sampai ayam matang. Koreksi rasa"
- "Sesaat sebelum diangkat masukkan kemangi dan aduk cepat"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 208 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/2af4e2ce228cf291/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang harus kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica kemangi yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan ciri khas yang merupakan keragaman Nusantara

Kedekatan keluarga dapat ditemukan dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica Kemangi untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang dapat anda buat salah satunya ayam rica kemangi yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 21 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Tambah 1 kg ayam
1. Harap siapkan 1 ikat kemangi
1. Dibutuhkan Secukupnya gula merah
1. Dibutuhkan Secukupnya garam
1. Tambah Secukupnya kaldu bubuk
1. Jangan lupa 1 sdt lada bubuk
1. Harus ada 2 sdm kecap manis
1. Harus ada  Bumbu halus :
1. Harus ada 4 butir kemiri
1. Tambah 10 butir bawang merah
1. Jangan lupa 6 siung bawang putih
1. Tambah 1 ruas kunyit
1. Diperlukan  Bumbu iris :
1. Dibutuhkan 1 buah bawang bombai
1. Siapkan 8 buah cabe rawit
1. Jangan lupa  Rempah-rempah
1. Diperlukan 1 jempol jahe
1. Tambah 2 potong lengkuas
1. Dibutuhkan 5 lembar daun jeruk iris halus
1. Dibutuhkan 2 batang serai ambil putihnya iris halus
1. Harus ada 3 lembar daun pandan potong besar


Perlu kamu ketahui bahwa di luar negeri mungkin daun basil sangat terkenal untuk campuran makanan. Akan tetapi, di Indonesia juga memiliki daun kemangi merupakan. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. 

<!--inarticleads2-->

##### Cara membuat  Ayam Rica Kemangi:

1. Tumis bumbu iris sampai layu lalu masukkan bumbu halus. Tumis sampai matang
1. Masukkan ayam aduk-aduk sampai rata. Setelah beberapa saat masukkan air tunggu mendidih baru masukkan rempah Gula Garam kaldu dan lada
1. Tambahkan kecap manis dan masak sampai ayam matang. Koreksi rasa
1. Sesaat sebelum diangkat masukkan kemangi dan aduk cepat


Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. Cara Membuat Ayam Rica Rica Kemangi. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat. 

Demikianlah cara membuat ayam rica kemangi yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan teruji, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
