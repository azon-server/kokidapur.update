---
description: "Resep : Ayam Rica  Rica Kemangi Teruji"
title: "Resep : Ayam Rica  Rica Kemangi Teruji"
slug: 217-resep-ayam-rica-rica-kemangi-teruji
date: 2020-11-18T04:00:51.912Z
image: https://img-global.cpcdn.com/recipes/58f9de339fbdc915/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/58f9de339fbdc915/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/58f9de339fbdc915/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Sean Olson
ratingvalue: 4.3
reviewcount: 2692
recipeingredient:
- "4 potong ayam ukuran besar"
- " Air perasan lemonjeruk nipis"
- "2 ikat kemangi"
- " Bumbu halus"
- "6 siung bawang merah"
- "2 siung bawang putih"
- "10 buah cabai keriting"
- "3 buah cabai rawit sesuai selera"
- "2 butir kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
- " Bumbu tambahan"
- "1 batang serai di geprek"
- "1 ruas lengkuas di geprek"
- "4 lembar daun jeruk"
- "Sedikit gula merah"
- " Garam"
- " Kaldu bubuk"
- "1 batang Daun bawang"
recipeinstructions:
- "Balurkan ayam dengan air perasan lemon/jeruk nipis"
- "Goreng bawang merah, bawang putih dan cabai hingga layu. Lalu haluskan bersama bumbu halus lainnya"
- "Tumis bumbu halus hingga wangi, tambahkan gula merah secukupnya, masukkan serai, lengkuas dan daun jeruk."
- "Masukkan ayam. Tumis hingga berubah warna"
- "Tambahkan air secukupnya. Lalu biarkan masak hingga matang"
- "Lalu masukkan kemangi dan daun bawang. Masak hingga sayuran layu"
- "Jadi deh!!!"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 110 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica  Rica Kemangi](https://img-global.cpcdn.com/recipes/58f9de339fbdc915/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang patut kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica  rica kemangi yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Kita

Kedekatan keluarga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica  Rica Kemangi untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda praktekkan salah satunya ayam rica  rica kemangi yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep ayam rica  rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica  Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica  Rica Kemangi:

1. Siapkan 4 potong ayam ukuran besar
1. Harus ada  Air perasan lemon/jeruk nipis
1. Dibutuhkan 2 ikat kemangi
1. Harap siapkan  Bumbu halus
1. Jangan lupa 6 siung bawang merah
1. Tambah 2 siung bawang putih
1. Jangan lupa 10 buah cabai keriting
1. Harus ada 3 buah cabai rawit (sesuai selera)
1. Jangan lupa 2 butir kemiri
1. Jangan lupa 1 ruas jahe
1. Harus ada 1 ruas kunyit
1. Tambah  Bumbu tambahan
1. Tambah 1 batang serai di geprek
1. Siapkan 1 ruas lengkuas di geprek
1. Diperlukan 4 lembar daun jeruk
1. Harus ada Sedikit gula merah
1. Harus ada  Garam
1. Harus ada  Kaldu bubuk
1. Dibutuhkan 1 batang Daun bawang




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica  Rica Kemangi:

1. Balurkan ayam dengan air perasan lemon/jeruk nipis
1. Goreng bawang merah, bawang putih dan cabai hingga layu. Lalu haluskan bersama bumbu halus lainnya
1. Tumis bumbu halus hingga wangi, tambahkan gula merah secukupnya, masukkan serai, lengkuas dan daun jeruk.
1. Masukkan ayam. Tumis hingga berubah warna
1. Tambahkan air secukupnya. Lalu biarkan masak hingga matang
1. Lalu masukkan kemangi dan daun bawang. Masak hingga sayuran layu
1. Jadi deh!!!




Demikianlah cara membuat ayam rica  rica kemangi yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan cepat, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
