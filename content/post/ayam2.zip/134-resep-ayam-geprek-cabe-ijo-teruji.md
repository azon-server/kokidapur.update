---
description: "Resep : Ayam geprek cabe ijo Teruji"
title: "Resep : Ayam geprek cabe ijo Teruji"
slug: 134-resep-ayam-geprek-cabe-ijo-teruji
date: 2020-09-06T05:31:09.226Z
image: https://img-global.cpcdn.com/recipes/1e6a95c235e37479/751x532cq70/ayam-geprek-cabe-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1e6a95c235e37479/751x532cq70/ayam-geprek-cabe-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1e6a95c235e37479/751x532cq70/ayam-geprek-cabe-ijo-foto-resep-utama.jpg
author: Marguerite Carpenter
ratingvalue: 4.7
reviewcount: 23354
recipeingredient:
- " ayam"
- " Tepung terigu"
- " Cabe ijo"
- " Cabe rawit"
- " Bawang putih"
- " Gula"
- " Garam"
- " merica"
recipeinstructions:
- "Cuci ayam, lalu potong2 tipis atau kecil2"
- "Baluri dangan merica dan penyedap rasa masako atau royco atau garam juga gak masalah"
- "Diamkan 10 sampai 15 menit"
- "Siapkan tepung taburi dengan merica dan garam atau penyedap rasa"
- "Gulingkan ayam ke dalam tepung lalu goreng diapi yg kecil saja, minyak harus banyak ya biar ayam tenggelam dan matang merata, goreng sampe kecoklatan lalu angkat"
- "Sambalnya, goreng cabe dan bawang lalu tumbuk dan geprek ayam yg sdh di goreng tadi lalu sajikan... pokoknya praktis banget deh, gak rempong, selamat mencoba yaaaaa.... salam, terimakasih"
categories:
- Recipe
tags:
- ayam
- geprek
- cabe

katakunci: ayam geprek cabe 
nutrition: 251 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam geprek cabe ijo](https://img-global.cpcdn.com/recipes/1e6a95c235e37479/751x532cq70/ayam-geprek-cabe-ijo-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga renyah. Karasteristik masakan Indonesia ayam geprek cabe ijo yang penuh dengan rempah-rempah memberikan kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kehangatan keluarga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Ayam geprek cabe ijo untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis makanan yang dapat anda praktekkan salah satunya ayam geprek cabe ijo yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep ayam geprek cabe ijo tanpa harus bersusah payah.
Seperti resep Ayam geprek cabe ijo yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 8 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam geprek cabe ijo:

1. Diperlukan  ayam
1. Diperlukan  Tepung terigu
1. Diperlukan  Cabe ijo
1. Dibutuhkan  Cabe rawit
1. Harus ada  Bawang putih
1. Dibutuhkan  Gula
1. Tambah  Garam
1. Harap siapkan  merica




<!--inarticleads2-->

##### Langkah membuat  Ayam geprek cabe ijo:

1. Cuci ayam, lalu potong2 tipis atau kecil2
1. Baluri dangan merica dan penyedap rasa masako atau royco atau garam juga gak masalah
1. Diamkan 10 sampai 15 menit
1. Siapkan tepung taburi dengan merica dan garam atau penyedap rasa
1. Gulingkan ayam ke dalam tepung lalu goreng diapi yg kecil saja, minyak harus banyak ya biar ayam tenggelam dan matang merata, goreng sampe kecoklatan lalu angkat
1. Sambalnya, goreng cabe dan bawang lalu tumbuk dan geprek ayam yg sdh di goreng tadi lalu sajikan... pokoknya praktis banget deh, gak rempong, selamat mencoba yaaaaa.... salam, terimakasih




Demikianlah cara membuat ayam geprek cabe ijo yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
