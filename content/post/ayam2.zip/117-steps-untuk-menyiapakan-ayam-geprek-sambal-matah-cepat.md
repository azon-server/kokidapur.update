---
description: "Steps untuk menyiapakan Ayam Geprek Sambal Matah Cepat"
title: "Steps untuk menyiapakan Ayam Geprek Sambal Matah Cepat"
slug: 117-steps-untuk-menyiapakan-ayam-geprek-sambal-matah-cepat
date: 2021-01-27T13:27:21.635Z
image: https://img-global.cpcdn.com/recipes/481f39bcd51e8d34/751x532cq70/ayam-geprek-sambal-matah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/481f39bcd51e8d34/751x532cq70/ayam-geprek-sambal-matah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/481f39bcd51e8d34/751x532cq70/ayam-geprek-sambal-matah-foto-resep-utama.jpg
author: Elijah Love
ratingvalue: 5
reviewcount: 15385
recipeingredient:
- " Bahan utama"
- "1 ekor ayam sedang"
- " Bahan pelapis"
- "400 gr Tepung Cakra protein tinggi"
- "150 gr Tepung maizena"
- "1 sendok Lada"
- "1 ruas Kunyit"
- "1 ruas Jahe"
- "5 Cabe merah"
- "1 sendok Ketumbar"
- "10 buah Bawang putih"
- "1 butir Telur"
- "1 sendok Baking soda"
- " Bahan Sambal"
- "10 butir Bawang merah"
- "5 buah Cabe merah"
- "20 buah Cabe rawit"
- " Terasi sedikit saja"
- " Gula"
- " Garam"
- " Kaldu jamur"
recipeinstructions:
- "Haluskan bawang putih, cabe merah, lada, ketumbar,kunyit, jahe. Tambahkan 1 sendok garam serta penyedap"
- "Lumurkan bumbu halus ke 1 ekor ayam. Lalu simpan di lemari es. Kurang lebih 3-5 jam agar bumbu meresap."
- "Untuk membuat pelapis tepung, tuang tepung terigu dan tepung maizena ke dalam 1 wadah. Tambahkan sedikit lada. Lalu aduk rata. Sisihkan."
- "Di wadah lainnya. Ambil air sebanyak 250 ml. Tambahkan 1 sendok baking soda. Dan 5 sendok tepung yang telah disisihkan di wadah sebelumnya. Masukkan ke dalam kulkas. Agar dingin."
- "Setelah 3 jam. Keluarkan ayam."
- "Ambil panci panaskan minyak. Minyaknya banyak ya"
- "Ambil panci panaskan minyak. Minyaknya banyak ya"
- "Langsung goreng. Agar renyah dan tidak keras."
- "Potong cabe merah, bawang merah dan cabe kecil. Dan beri sedikit terasi gula garam"
- "Siram minyak panas."
- "Ambil ulekan. Letakkan ayam yang sudah di goreng. Tambahkan sambal matah di atasnya. Lalu geprek"
- "Taraaaaaaa.... Selesai deh ❤️❤️"
categories:
- Recipe
tags:
- ayam
- geprek
- sambal

katakunci: ayam geprek sambal 
nutrition: 168 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Geprek Sambal Matah](https://img-global.cpcdn.com/recipes/481f39bcd51e8d34/751x532cq70/ayam-geprek-sambal-matah-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan renyah. Karasteristik masakan Indonesia ayam geprek sambal matah yang penuh dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah memasak Ayam Geprek Sambal Matah untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang dapat anda buat salah satunya ayam geprek sambal matah yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep ayam geprek sambal matah tanpa harus bersusah payah.
Seperti resep Ayam Geprek Sambal Matah yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 12 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Sambal Matah:

1. Jangan lupa  Bahan utama
1. Harus ada 1 ekor ayam sedang
1. Harus ada  Bahan pelapis
1. Harap siapkan 400 gr Tepung Cakra protein tinggi
1. Jangan lupa 150 gr Tepung maizena
1. Siapkan 1 sendok Lada
1. Diperlukan 1 ruas Kunyit
1. Dibutuhkan 1 ruas Jahe
1. Harus ada 5 Cabe merah
1. Harap siapkan 1 sendok Ketumbar
1. Harus ada 10 buah Bawang putih
1. Siapkan 1 butir Telur
1. Siapkan 1 sendok Baking soda
1. Dibutuhkan  Bahan Sambal
1. Jangan lupa 10 butir Bawang merah
1. Harus ada 5 buah Cabe merah
1. Dibutuhkan 20 buah Cabe rawit
1. Diperlukan  Terasi sedikit saja
1. Tambah  Gula
1. Diperlukan  Garam
1. Harus ada  Kaldu jamur




<!--inarticleads2-->

##### Langkah membuat  Ayam Geprek Sambal Matah:

1. Haluskan bawang putih, cabe merah, lada, ketumbar,kunyit, jahe. Tambahkan 1 sendok garam serta penyedap
1. Lumurkan bumbu halus ke 1 ekor ayam. Lalu simpan di lemari es. Kurang lebih 3-5 jam agar bumbu meresap.
1. Untuk membuat pelapis tepung, tuang tepung terigu dan tepung maizena ke dalam 1 wadah. Tambahkan sedikit lada. Lalu aduk rata. Sisihkan.
1. Di wadah lainnya. Ambil air sebanyak 250 ml. Tambahkan 1 sendok baking soda. Dan 5 sendok tepung yang telah disisihkan di wadah sebelumnya. Masukkan ke dalam kulkas. Agar dingin.
1. Setelah 3 jam. Keluarkan ayam.
1. Ambil panci panaskan minyak. Minyaknya banyak ya
1. Ambil panci panaskan minyak. Minyaknya banyak ya
1. Langsung goreng. Agar renyah dan tidak keras.
1. Potong cabe merah, bawang merah dan cabe kecil. Dan beri sedikit terasi gula garam
1. Siram minyak panas.
1. Ambil ulekan. Letakkan ayam yang sudah di goreng. Tambahkan sambal matah di atasnya. Lalu geprek
1. Taraaaaaaa.... Selesai deh ❤️❤️




Demikianlah cara membuat ayam geprek sambal matah yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan cepat, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
