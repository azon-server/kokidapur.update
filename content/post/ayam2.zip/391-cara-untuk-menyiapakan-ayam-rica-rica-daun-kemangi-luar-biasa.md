---
description: "Cara untuk menyiapakan Ayam rica rica daun kemangi Luar biasa"
title: "Cara untuk menyiapakan Ayam rica rica daun kemangi Luar biasa"
slug: 391-cara-untuk-menyiapakan-ayam-rica-rica-daun-kemangi-luar-biasa
date: 2020-10-26T23:44:01.811Z
image: https://img-global.cpcdn.com/recipes/c02b530624e02a77/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c02b530624e02a77/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c02b530624e02a77/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Philip Cohen
ratingvalue: 4.1
reviewcount: 7350
recipeingredient:
- "250 gr ayam dada"
- "2 ikat daun kemangi"
- "10 buah cabe merah keriting"
- "10 buah cabe rawit merah"
- "7 siung bawang merah"
- "4 siung bawang putih"
- "1 buah tomat"
- "1/2 ruas kunyit"
- "1/2 ruas jahe"
- "1 sdt ketumbar"
- "2 butir kemiri"
- "3 lembar daun jeruk"
- "1 batang sereh"
- "2 buah jeruk nipis"
- "150 ml air"
- "Secukupnya garam"
- "Secukupnya gula"
recipeinstructions:
- "Siangi bahan bahan kemudian cuci bersih"
- "Baluri ayam dada dengan perasan jeruk nipis, beri garam sedikit"
- "Goreng ayam setengah matang, angkat dan tiriskan"
- "Haluskan cabe merah keriting, bawang merah, bawang putih, cabe rawit merah (sisakan 5 buah utk irisan), tomat, kunyit, jahe, kemiri, ketumbar."
- "Panaskan minyak, tumis bahan yang sudah dihaluskan sampai harum, kemudian masukan daun jeruk dan sereh."
- "Masukan ayam yang sudah digoreng setengah matang sebelumnya. Aduk hinga bumbu meresap."
- "Masukan air kemudian masak hingga airnya surut dan bumbu lebih meresap."
- "Tambahkan secukupnya garam dan gula, koreksi rasa."
- "Terakhir masukan daun kemangi dan irisan cabe rawit merah. Angkat dan sajikan dengan nasi hangat"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 220 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica rica daun kemangi](https://img-global.cpcdn.com/recipes/c02b530624e02a77/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau enak. Ciri khas kuliner Nusantara ayam rica rica daun kemangi yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah memasak Ayam rica rica daun kemangi untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang dapat anda contoh salah satunya ayam rica rica daun kemangi yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep ayam rica rica daun kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica rica daun kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica daun kemangi:

1. Tambah 250 gr ayam dada
1. Diperlukan 2 ikat daun kemangi
1. Harus ada 10 buah cabe merah keriting
1. Siapkan 10 buah cabe rawit merah
1. Jangan lupa 7 siung bawang merah
1. Diperlukan 4 siung bawang putih
1. Diperlukan 1 buah tomat
1. Siapkan 1/2 ruas kunyit
1. Harap siapkan 1/2 ruas jahe
1. Jangan lupa 1 sdt ketumbar
1. Diperlukan 2 butir kemiri
1. Dibutuhkan 3 lembar daun jeruk
1. Diperlukan 1 batang sereh
1. Harap siapkan 2 buah jeruk nipis
1. Tambah 150 ml air
1. Harap siapkan Secukupnya garam
1. Tambah Secukupnya gula




<!--inarticleads2-->

##### Cara membuat  Ayam rica rica daun kemangi:

1. Siangi bahan bahan kemudian cuci bersih
1. Baluri ayam dada dengan perasan jeruk nipis, beri garam sedikit
1. Goreng ayam setengah matang, angkat dan tiriskan
1. Haluskan cabe merah keriting, bawang merah, bawang putih, cabe rawit merah (sisakan 5 buah utk irisan), tomat, kunyit, jahe, kemiri, ketumbar.
1. Panaskan minyak, tumis bahan yang sudah dihaluskan sampai harum, kemudian masukan daun jeruk dan sereh.
1. Masukan ayam yang sudah digoreng setengah matang sebelumnya. Aduk hinga bumbu meresap.
1. Masukan air kemudian masak hingga airnya surut dan bumbu lebih meresap.
1. Tambahkan secukupnya garam dan gula, koreksi rasa.
1. Terakhir masukan daun kemangi dan irisan cabe rawit merah. Angkat dan sajikan dengan nasi hangat




Demikianlah cara membuat ayam rica rica daun kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
