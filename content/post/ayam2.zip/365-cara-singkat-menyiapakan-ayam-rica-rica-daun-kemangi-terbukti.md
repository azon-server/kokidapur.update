---
description: "Cara singkat menyiapakan Ayam rica rica daun kemangi Terbukti"
title: "Cara singkat menyiapakan Ayam rica rica daun kemangi Terbukti"
slug: 365-cara-singkat-menyiapakan-ayam-rica-rica-daun-kemangi-terbukti
date: 2020-11-15T20:27:31.923Z
image: https://img-global.cpcdn.com/recipes/bd80c609d88aa8da/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bd80c609d88aa8da/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bd80c609d88aa8da/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Glenn Schneider
ratingvalue: 4.7
reviewcount: 43731
recipeingredient:
- "1/2 ekor ayam potong dadu"
- "Secukupnya garam dan gula"
- " Bumbu halus"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "1 buah kemiri"
- "1 ons cabe rawit"
- "1 ruas jahe"
- "1 ruas kunyit"
- " Bumbu rajang"
- "5 lembar daun jeruk iris"
- "1 batang serai iris"
- "1 ruas lengkuas muda iris"
- "1 ons daun kemangi disiang"
recipeinstructions:
- "Panaskan secukupnya minyak, tumis bumbu halus dan tambahkan serai serta lengkuas hingga harum."
- "Masukan ayam aduk2 dan tutup hingga ayam empuk, kemudian setelah ayam matang dan setelah koreksi rasa masukan daun jeruk dan daun kemangi. Aduk2 lalu matikan kompor. Siap disajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 172 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam rica rica daun kemangi](https://img-global.cpcdn.com/recipes/bd80c609d88aa8da/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang harus kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica rica daun kemangi yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan ciri khas yang merupakan keragaman Nusantara



Kedekatan keluarga dapat didapat dengan cara mudah. Salah satunya adalah memasak Ayam rica rica daun kemangi untuk keluarga. Momen makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang dapat anda buat salah satunya ayam rica rica daun kemangi yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica rica daun kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica rica daun kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 2 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica daun kemangi:

1. Harus ada 1/2 ekor ayam potong dadu
1. Harus ada Secukupnya garam dan gula
1. Jangan lupa  Bumbu halus
1. Tambah 6 siung bawang merah
1. Harap siapkan 4 siung bawang putih
1. Dibutuhkan 1 buah kemiri
1. Diperlukan 1 ons cabe rawit
1. Siapkan 1 ruas jahe
1. Harap siapkan 1 ruas kunyit
1. Jangan lupa  Bumbu rajang
1. Diperlukan 5 lembar daun jeruk iris
1. Harus ada 1 batang serai iris
1. Harap siapkan 1 ruas lengkuas muda iris
1. Jangan lupa 1 ons daun kemangi (disiang)




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica rica daun kemangi:

1. Panaskan secukupnya minyak, tumis bumbu halus dan tambahkan serai serta lengkuas hingga harum.
1. Masukan ayam aduk2 dan tutup hingga ayam empuk, kemudian setelah ayam matang dan setelah koreksi rasa masukan daun jeruk dan daun kemangi. Aduk2 lalu matikan kompor. Siap disajikan




Demikianlah cara membuat ayam rica rica daun kemangi yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
