---
description: "Panduan menyiapakan Ayam rica rica kemangi pedas Luar biasa"
title: "Panduan menyiapakan Ayam rica rica kemangi pedas Luar biasa"
slug: 380-panduan-menyiapakan-ayam-rica-rica-kemangi-pedas-luar-biasa
date: 2020-12-27T10:58:31.286Z
image: https://img-global.cpcdn.com/recipes/ee576e2cc2242a76/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ee576e2cc2242a76/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ee576e2cc2242a76/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
author: Elnora Flores
ratingvalue: 4.7
reviewcount: 12936
recipeingredient:
- "1/2 kg ayam di potong kecil Rebus sebentar lalu goreng asal"
- "1 ikat daun kemangi"
- "2 lbr daun salam"
- "2 lbr daun jeruk"
- "2 ruas lengkuas di geprek"
- "1 bh serai di geprek"
- "1 bh tomat iris tipis"
- " bumbu halus"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "2 ruas jahe"
- "2 ruas kunyit"
- "10 bh cabe merah"
- "7 bh cabe rawit"
- "2 bh kemiri uk kecil"
recipeinstructions:
- "Tumis bumbu hingga harum, lalu tambahkan serai, daun salam, daun jeruk dan lengkuas. Tambahkan air sisa rebusan ayam tadi"
- "Masukkan ayam, biarkan smpai ayam meresap dan air menyusut. Lalu masukkan tomat dan daun kemangi nya. Aduk sampai matang."
- "Siap disajikan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 271 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica rica kemangi pedas](https://img-global.cpcdn.com/recipes/ee576e2cc2242a76/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau renyah. Ciri khas makanan Nusantara ayam rica rica kemangi pedas yang penuh dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah memasak Ayam rica rica kemangi pedas untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang bisa anda contoh salah satunya ayam rica rica kemangi pedas yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep ayam rica rica kemangi pedas tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi pedas yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 15 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi pedas:

1. Diperlukan 1/2 kg ayam di potong kecil. Rebus sebentar lalu goreng asal
1. Siapkan 1 ikat daun kemangi
1. Harap siapkan 2 lbr daun salam
1. Tambah 2 lbr daun jeruk
1. Diperlukan 2 ruas lengkuas di geprek
1. Harap siapkan 1 bh serai di geprek
1. Harus ada 1 bh tomat iris tipis
1. Siapkan  bumbu halus*
1. Harus ada 6 siung bawang merah
1. Harus ada 3 siung bawang putih
1. Harus ada 2 ruas jahe
1. Harus ada 2 ruas kunyit
1. Tambah 10 bh cabe merah
1. Siapkan 7 bh cabe rawit
1. Tambah 2 bh kemiri uk kecil




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica rica kemangi pedas:

1. Tumis bumbu hingga harum, lalu tambahkan serai, daun salam, daun jeruk dan lengkuas. Tambahkan air sisa rebusan ayam tadi
1. Masukkan ayam, biarkan smpai ayam meresap dan air menyusut. Lalu masukkan tomat dan daun kemangi nya. Aduk sampai matang.
1. Siap disajikan.




Demikianlah cara membuat ayam rica rica kemangi pedas yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat gampang dan terbukti, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
