---
description: "Steps untuk menyiapakan Ayam rica rica kemangi pedas Teruji"
title: "Steps untuk menyiapakan Ayam rica rica kemangi pedas Teruji"
slug: 322-steps-untuk-menyiapakan-ayam-rica-rica-kemangi-pedas-teruji
date: 2020-12-01T00:36:14.044Z
image: https://img-global.cpcdn.com/recipes/3daf06cc31f1277d/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3daf06cc31f1277d/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3daf06cc31f1277d/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
author: Jessie Hunter
ratingvalue: 4.7
reviewcount: 33472
recipeingredient:
- "1 ekor ayam ukuran sedang"
- "250 ml air"
- "1 batang serai"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "secukupnya Garam gula dan kaldu jamur"
- "secukupnya Minyak"
- "1 ikat kemangi"
- " Bumbu halus"
- "11 siung bawang merah"
- "7 siung bawang putih"
- "6 cabe merah besar"
- "20 cabe rawit"
- "5 cm kunyit"
- "5 cm jahe"
- "5 cm lengkuas"
- "2 butir kemiri"
recipeinstructions:
- "Beraihkan ayam, lumuri dengan jeruk nipis selama 30 menit kemudian cuci bersih, potong2 sesuai selera menjadi beberapa bagian"
- "Tumis bumbu halus dengan daun salam, serai dan daun jeruk hingga harum, tambahkan air garam gula kaldujamur, aduk rata tunggu sampai mendidih"
- "Masukkan ayam dan masak dengan api kecil, biarkan meresap, aduk2 rata, setelah air menyusut masukkan kemangi sebentar, lalu matikan apinya."
- "Ayam riva rica siap disajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 271 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica rica kemangi pedas](https://img-global.cpcdn.com/recipes/3daf06cc31f1277d/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas dan gurih. Ciri khas makanan Indonesia ayam rica rica kemangi pedas yang kaya dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan rumah tangga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Ayam rica rica kemangi pedas untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda coba salah satunya ayam rica rica kemangi pedas yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep ayam rica rica kemangi pedas tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi pedas yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi pedas:

1. Dibutuhkan 1 ekor ayam ukuran sedang
1. Siapkan 250 ml air
1. Harus ada 1 batang serai
1. Diperlukan 2 lembar daun salam
1. Dibutuhkan 2 lembar daun jeruk
1. Diperlukan secukupnya Garam, gula dan kaldu jamur
1. Harus ada secukupnya Minyak
1. Diperlukan 1 ikat kemangi
1. Diperlukan  Bumbu halus:
1. Diperlukan 11 siung bawang merah
1. Harus ada 7 siung bawang putih
1. Jangan lupa 6 cabe merah besar
1. Harap siapkan 20 cabe rawit
1. Jangan lupa 5 cm kunyit
1. Diperlukan 5 cm jahe
1. Harus ada 5 cm lengkuas
1. Diperlukan 2 butir kemiri




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica rica kemangi pedas:

1. Beraihkan ayam, lumuri dengan jeruk nipis selama 30 menit kemudian cuci bersih, potong2 sesuai selera menjadi beberapa bagian
1. Tumis bumbu halus dengan daun salam, serai dan daun jeruk hingga harum, tambahkan air garam gula kaldujamur, aduk rata tunggu sampai mendidih
1. Masukkan ayam dan masak dengan api kecil, biarkan meresap, aduk2 rata, setelah air menyusut masukkan kemangi sebentar, lalu matikan apinya.
1. Ayam riva rica siap disajikan




Demikianlah cara membuat ayam rica rica kemangi pedas yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
