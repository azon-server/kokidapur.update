---
description: "Step-by-Step untuk menyiapakan Ayam rica-rica kemangi terupdate"
title: "Step-by-Step untuk menyiapakan Ayam rica-rica kemangi terupdate"
slug: 358-step-by-step-untuk-menyiapakan-ayam-rica-rica-kemangi-terupdate
date: 2020-08-24T23:19:20.598Z
image: https://img-global.cpcdn.com/recipes/fd9b1505db55ff0d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fd9b1505db55ff0d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fd9b1505db55ff0d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Duane Mason
ratingvalue: 4.6
reviewcount: 39485
recipeingredient:
- "1 kg ayam"
- "5 lembar daun jeruk"
- "2 lembar daun salam"
- "2 batang sereh di geprek"
- "1 ikat kemangi"
- "2 sdt penyedap"
- "secukupnya gula dan garam"
- "secukupnya minyak untuk menumis"
- "secukupnya air"
- " bumbu halus "
- "7 siung bawang merah"
- "8 siung bawang putih"
- "15 cabe rawit merah sesuai selera"
- "10 cabe kriting merah sesuai selera"
- "3 buah kemiri"
- "1 ruas kunyit"
- "1 ruas jahe"
- "3 cm lengkuas"
recipeinstructions:
- "Potong ayam sesuai selera, cuci bersih.kemudian rebus sebentar sekitar 15-20 menit. lalu tiriskan"
- "Siapkan wajan, panaskan minyak kemudian tumis bubu yg sudah dihaluskan tambahkan juga sereh,daun salam,daun jeruk.tumis sampai harum. lalu masukan air secukupnya"
- "Masukan ayam,tambahkan gula,garam dan penyedap. kemudian koreksi rasa, setelah sudah pas rasanya,diamkan sampai air menyusut"
- "Masukan daun kemangi, aduk rata,angkat dan sajikan ☺"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 218 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/fd9b1505db55ff0d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Nusantara



Keharmonisan rumah tangga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam rica-rica kemangi untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang dapat anda coba salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica kemangi:

1. Diperlukan 1 kg ayam
1. Tambah 5 lembar daun jeruk
1. Siapkan 2 lembar daun salam
1. Siapkan 2 batang sereh (di geprek)
1. Dibutuhkan 1 ikat kemangi
1. Harap siapkan 2 sdt penyedap
1. Harus ada secukupnya gula dan garam
1. Diperlukan secukupnya minyak untuk menumis
1. Dibutuhkan secukupnya air
1. Harap siapkan  bumbu halus :
1. Dibutuhkan 7 siung bawang merah
1. Tambah 8 siung bawang putih
1. Diperlukan 15 cabe rawit merah (sesuai selera)
1. Siapkan 10 cabe kriting merah (sesuai selera)
1. Siapkan 3 buah kemiri
1. Siapkan 1 ruas kunyit
1. Diperlukan 1 ruas jahe
1. Harus ada 3 cm lengkuas




<!--inarticleads2-->

##### Cara membuat  Ayam rica-rica kemangi:

1. Potong ayam sesuai selera, cuci bersih.kemudian rebus sebentar sekitar 15-20 menit. lalu tiriskan
1. Siapkan wajan, panaskan minyak kemudian tumis bubu yg sudah dihaluskan tambahkan juga sereh,daun salam,daun jeruk.tumis sampai harum. lalu masukan air secukupnya
1. Masukan ayam,tambahkan gula,garam dan penyedap. kemudian koreksi rasa, setelah sudah pas rasanya,diamkan sampai air menyusut
1. Masukan daun kemangi, aduk rata,angkat dan sajikan ☺




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat gampang dan terbukti, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
