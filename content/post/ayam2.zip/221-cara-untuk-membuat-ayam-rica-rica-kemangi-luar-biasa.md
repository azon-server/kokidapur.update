---
description: "Cara untuk membuat Ayam rica rica kemangi Luar biasa"
title: "Cara untuk membuat Ayam rica rica kemangi Luar biasa"
slug: 221-cara-untuk-membuat-ayam-rica-rica-kemangi-luar-biasa
date: 2020-09-21T10:25:56.799Z
image: https://img-global.cpcdn.com/recipes/c49b580a86e5e3c4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c49b580a86e5e3c4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c49b580a86e5e3c4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: William Curtis
ratingvalue: 4.2
reviewcount: 11870
recipeingredient:
- "1/2 ekor ayam boiler"
- "1 ikat kemangi"
- " Bumbu semua di ulek ya kecuali lengkuas"
- "3 siung bawang putih dan 5 siung bawang merah"
- "1/2 cm jahe"
- "1/4 kunyit"
- " Lengkuas ukuran sedanggeprek"
- "25 cabe rawitsesuai selera"
- "10 cabe merahboleh lebih"
- "2 buah Tobat boleh di skip"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
recipeinstructions:
- "Potong ayam menjadi 4 bagian"
- "Didihkan air rebus ayam hingga matang (tanpa bumbu)"
- "Goreng ayam asal (jangan sampai kuning)"
- "Tumis bumbu halus,masukkan lengkuas yg sdh di geprek,daun salam,daun jeruk"
- "Tambahkan garam,royco,dan gula(masakan sy kebanyakan pake gula karena biar rasa asin,gurih nya seimbang)"
- "Masukkan ayam,tambahkan sedikit air,"
- "Air sdh mulai mengering koreksi rasa,"
- "Terakhir masukkan kemangi,yg sdh di cuci bersih."
- "Ayam rica rica siap di sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 216 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/c49b580a86e5e3c4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau renyah. Ciri makanan Nusantara ayam rica rica kemangi yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah memasak Ayam rica rica kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang bisa anda buat salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 9 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi:

1. Harus ada 1/2 ekor ayam boiler
1. Tambah 1 ikat kemangi,
1. Diperlukan  Bumbu semua di ulek ya kecuali lengkuas
1. Siapkan 3 siung bawang putih dan 5 siung bawang merah
1. Dibutuhkan 1/2 cm jahe,
1. Jangan lupa 1/4 kunyit
1. Diperlukan  Lengkuas ukuran sedang(geprek)
1. Tambah 25 cabe rawit(sesuai selera)
1. Tambah 10 cabe merah(boleh lebih)
1. Harus ada 2 buah Tobat (boleh di skip)
1. Siapkan 3 lembar daun salam
1. Harap siapkan 3 lembar daun jeruk




<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica kemangi:

1. Potong ayam menjadi 4 bagian
1. Didihkan air rebus ayam hingga matang (tanpa bumbu)
1. Goreng ayam asal (jangan sampai kuning)
1. Tumis bumbu halus,masukkan lengkuas yg sdh di geprek,daun salam,daun jeruk
1. Tambahkan garam,royco,dan gula(masakan sy kebanyakan pake gula karena biar rasa asin,gurih nya seimbang)
1. Masukkan ayam,tambahkan sedikit air,
1. Air sdh mulai mengering koreksi rasa,
1. Terakhir masukkan kemangi,yg sdh di cuci bersih.
1. Ayam rica rica siap di sajikan




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
