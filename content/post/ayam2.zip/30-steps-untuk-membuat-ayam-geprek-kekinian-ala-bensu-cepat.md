---
description: "Steps untuk membuat Ayam Geprek Kekinian Ala Bensu Cepat"
title: "Steps untuk membuat Ayam Geprek Kekinian Ala Bensu Cepat"
slug: 30-steps-untuk-membuat-ayam-geprek-kekinian-ala-bensu-cepat
date: 2020-12-17T11:56:53.722Z
image: https://img-global.cpcdn.com/recipes/b96aa55344c0f892/751x532cq70/ayam-geprek-kekinian-ala-bensu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b96aa55344c0f892/751x532cq70/ayam-geprek-kekinian-ala-bensu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b96aa55344c0f892/751x532cq70/ayam-geprek-kekinian-ala-bensu-foto-resep-utama.jpg
author: Dean Little
ratingvalue: 4.8
reviewcount: 29596
recipeingredient:
- " Bahan Rendaman Ayam"
- "1/4 kg ayam aku pilih bagian dada ya"
- "2 siung bawang putih dihaluskan"
- "1 sdt lada bubuk"
- "secukupnya Garam"
- " Adonan Basah"
- " Air es"
- "6 sdm tepung terigu"
- "2 sdm tepung maizena"
- "1 sdm susu bubuk"
- "1 butir kuning telur"
- "1/2 sdt baking soda"
- "1/2 sdt lada bubuk"
- "secukupnya Garam"
- " Adonan Kering"
- "6 sdm tepung terigu"
- "3 sdm tepung maizena"
- "1/2 sdt baking soda"
- "1 sdt kaldu bubuk ayam"
- "1/4 sdt garam"
- " Bahan sambal bawang"
- "25 cabe rawit jablay"
- "3 siung bawang putih"
- "secukupnya Gula merah"
- "secukupnya Garam"
recipeinstructions:
- "Cuci bersih semua bahan"
- "Rendam ayam dengan bumbu rendaman di kulkas kurang lebih 15 menit"
- "Campur rata semua bahan adonan basah"
- "Campur rata semua bahan adonan kering"
- "Gulingkan ayam ke adonan kering. Lalu celupkan ke adonan basah. Setelah itu gulingkan lagi ek adonan kering"
- "Goreng ayam hingga matang dan crispy. Angkat dan sisihkan"
- "Goreng cabe dan bawang putih 1/2 matang lalu angkat. Ulek kasar dan beri tambahan gula merah dan garam"
- "Geprek ayam yang sudah digoreng tadi. Lalu beri topping sambal bawang"
- "Sajikan 💜"
categories:
- Recipe
tags:
- ayam
- geprek
- kekinian

katakunci: ayam geprek kekinian 
nutrition: 180 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT46M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Geprek Kekinian Ala Bensu](https://img-global.cpcdn.com/recipes/b96aa55344c0f892/751x532cq70/ayam-geprek-kekinian-ala-bensu-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam geprek kekinian ala bensu yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan keistimewahan yang merupakan keragaman Indonesia

Keharmonisan keluarga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam Geprek Kekinian Ala Bensu untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda contoh salah satunya ayam geprek kekinian ala bensu yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam geprek kekinian ala bensu tanpa harus bersusah payah.
Seperti resep Ayam Geprek Kekinian Ala Bensu yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 25 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Kekinian Ala Bensu:

1. Dibutuhkan  Bahan Rendaman Ayam
1. Harus ada 1/4 kg ayam (aku pilih bagian dada ya)
1. Harap siapkan 2 siung bawang putih dihaluskan
1. Harap siapkan 1 sdt lada bubuk
1. Harus ada secukupnya Garam
1. Jangan lupa  Adonan Basah
1. Tambah  Air es
1. Diperlukan 6 sdm tepung terigu
1. Siapkan 2 sdm tepung maizena
1. Diperlukan 1 sdm susu bubuk
1. Jangan lupa 1 butir kuning telur
1. Jangan lupa 1/2 sdt baking soda
1. Harus ada 1/2 sdt lada bubuk
1. Diperlukan secukupnya Garam
1. Harap siapkan  Adonan Kering
1. Siapkan 6 sdm tepung terigu
1. Tambah 3 sdm tepung maizena
1. Tambah 1/2 sdt baking soda
1. Diperlukan 1 sdt kaldu bubuk ayam
1. Dibutuhkan 1/4 sdt garam
1. Diperlukan  Bahan sambal bawang
1. Diperlukan 25 cabe rawit jablay
1. Harap siapkan 3 siung bawang putih
1. Diperlukan secukupnya Gula merah
1. Jangan lupa secukupnya Garam




<!--inarticleads2-->

##### Langkah membuat  Ayam Geprek Kekinian Ala Bensu:

1. Cuci bersih semua bahan
1. Rendam ayam dengan bumbu rendaman di kulkas kurang lebih 15 menit
1. Campur rata semua bahan adonan basah
1. Campur rata semua bahan adonan kering
1. Gulingkan ayam ke adonan kering. Lalu celupkan ke adonan basah. Setelah itu gulingkan lagi ek adonan kering
1. Goreng ayam hingga matang dan crispy. Angkat dan sisihkan
1. Goreng cabe dan bawang putih 1/2 matang lalu angkat. Ulek kasar dan beri tambahan gula merah dan garam
1. Geprek ayam yang sudah digoreng tadi. Lalu beri topping sambal bawang
1. Sajikan 💜




Demikianlah cara membuat ayam geprek kekinian ala bensu yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
