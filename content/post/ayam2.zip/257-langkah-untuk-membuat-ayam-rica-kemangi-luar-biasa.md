---
description: "Langkah untuk membuat Ayam Rica Kemangi Luar biasa"
title: "Langkah untuk membuat Ayam Rica Kemangi Luar biasa"
slug: 257-langkah-untuk-membuat-ayam-rica-kemangi-luar-biasa
date: 2021-01-11T00:05:32.664Z
image: https://img-global.cpcdn.com/recipes/a0823ea0b514ba2d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a0823ea0b514ba2d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a0823ea0b514ba2d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Zachary Lowe
ratingvalue: 4.9
reviewcount: 10277
recipeingredient:
- "14 potong ayam kampung"
- "1 buah jeruk nipis"
- "1 buah tomat merah"
- "1 batang sereh iris bagian putihnya"
- "4 lembar daun jeruk iris"
- "1/2 lembar daun kunyit iris"
- "2 batang daun bawang"
- "1 ruas jahe geprek"
- "2 ruas lengkuas geprek"
- "secukupnya Kemangi"
- " Bumbu halus"
- "5 buah cabai merah keriting"
- "2 buah cabai setan"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "4 butir kemiri"
- "Seruas kunyit"
- "700 ml air"
- "2 sdt garam"
recipeinstructions:
- "Cuci bersih ayam. Lumuri dengan air perasan jeruk nipis. Diamkan 30 menit, lalu cuci bersih lagi."
- "Blender bumbu halus dengan secukupnya minyak."
- "Tumis bumbu halus dengan minyak secukupnya. Kemudian masukkan jahe dan lengkuas. Setelah harum masukkan daun jeruk, daun kunyit dan irisan sereh. Aduk rata."
- "Masukkan ayam, tambahkan air. Pertama saya pakai 500 ml air. Setelah airnya menyusut saya tambahkan lagi 200 ml."
- "Masak sampai matang dan empuk, kurleb 1 jam. Masukkan kemangi, aduk rata biarkan agak layu. Tambahkan garam, tes rasa. Kemudian masukkan potongan tomat dan daun bawang."
- "Selesai."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 277 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/a0823ea0b514ba2d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga empuk. Ciri kuliner Nusantara ayam rica kemangi yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica Kemangi untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang dapat anda praktekkan salah satunya ayam rica kemangi yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Tambah 14 potong ayam kampung
1. Harap siapkan 1 buah jeruk nipis
1. Tambah 1 buah tomat merah
1. Tambah 1 batang sereh iris bagian putihnya
1. Diperlukan 4 lembar daun jeruk, iris
1. Jangan lupa 1/2 lembar daun kunyit, iris
1. Harap siapkan 2 batang daun bawang
1. Tambah 1 ruas jahe, geprek
1. Diperlukan 2 ruas lengkuas, geprek
1. Siapkan secukupnya Kemangi
1. Diperlukan  Bumbu halus:
1. Harap siapkan 5 buah cabai merah keriting
1. Jangan lupa 2 buah cabai setan
1. Jangan lupa 8 siung bawang merah
1. Jangan lupa 4 siung bawang putih
1. Harap siapkan 4 butir kemiri
1. Harus ada Seruas kunyit
1. Jangan lupa 700 ml air
1. Jangan lupa 2 sdt garam




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Kemangi:

1. Cuci bersih ayam. Lumuri dengan air perasan jeruk nipis. Diamkan 30 menit, lalu cuci bersih lagi.
1. Blender bumbu halus dengan secukupnya minyak.
1. Tumis bumbu halus dengan minyak secukupnya. Kemudian masukkan jahe dan lengkuas. Setelah harum masukkan daun jeruk, daun kunyit dan irisan sereh. Aduk rata.
1. Masukkan ayam, tambahkan air. Pertama saya pakai 500 ml air. Setelah airnya menyusut saya tambahkan lagi 200 ml.
1. Masak sampai matang dan empuk, kurleb 1 jam. Masukkan kemangi, aduk rata biarkan agak layu. Tambahkan garam, tes rasa. Kemudian masukkan potongan tomat dan daun bawang.
1. Selesai.




Demikianlah cara membuat ayam rica kemangi yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan cepat, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
