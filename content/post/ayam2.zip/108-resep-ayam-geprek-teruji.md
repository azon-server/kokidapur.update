---
description: "Resep : Ayam Geprek Teruji"
title: "Resep : Ayam Geprek Teruji"
slug: 108-resep-ayam-geprek-teruji
date: 2020-11-26T07:58:24.360Z
image: https://img-global.cpcdn.com/recipes/e97a3ced22470875/751x532cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e97a3ced22470875/751x532cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e97a3ced22470875/751x532cq70/ayam-geprek-foto-resep-utama.jpg
author: Eugene Harper
ratingvalue: 5
reviewcount: 9673
recipeingredient:
- " Bahan ayam "
- "250 gr fillet dada ayam iris sesuai selera"
- "1 bungkus tepung ayam krispi"
- "200 gr tepung terigu"
- "1 sdt garam"
- "Secukupnya air"
- " Bumbu marinasi ayam "
- "1/2 sdt bawang putih bubuk"
- "1/2 sdt merica bubuk"
- "1/2 sdt garam"
- "1/2 buah jeruk lemon ambil airnya"
- "Secukupnya minyak goreng"
- " Bahan sambal "
- "20 buah cabe rawit merah dan hijau"
- "4 siung bawang putih"
- "Secukupnya garam"
recipeinstructions:
- "Campurkan tepung ayam krispi, tepung terigu, garam, aduk rata."
- "Ambil 5 sdm tepung tersebut beri air secukupnya sampai kental."
- "Kucurkan air jeruk lemon ke daging ayam, bubuhi garam, bawang putih, dan merica. Diamkan 15 menit."
- "Masukan ayam ke tepung kering, gulingkan ke adonan tepung basah, masukan ke tepung kering sambil sedikit di remas dan di cubit. Goreng di minyak panas dengan api sedang sampai matang."
- "Sambal : uleg cabe rawit, bawang putih, dan garam."
- "Panaskan minyak sedikit, goreng sambal sampai matang."
- "Penyajian : ambil satu potong ayam krispi bubuhi sambal, geprek dengan ulekan."
categories:
- Recipe
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 182 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/e97a3ced22470875/751x532cq70/ayam-geprek-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam geprek yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa ciri khas yang merupakan keragaman Kita



Kedekatan rumah tangga dapat didapat dengan cara mudah. Salah satunya adalah memasak Ayam Geprek untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang dapat anda coba salah satunya ayam geprek yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam geprek tanpa harus bersusah payah.
Seperti resep Ayam Geprek yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek:

1. Harus ada  Bahan ayam :
1. Siapkan 250 gr fillet dada ayam, iris sesuai selera
1. Jangan lupa 1 bungkus tepung ayam krispi
1. Harus ada 200 gr tepung terigu
1. Jangan lupa 1 sdt garam
1. Jangan lupa Secukupnya air
1. Diperlukan  Bumbu marinasi ayam :
1. Siapkan 1/2 sdt bawang putih bubuk
1. Siapkan 1/2 sdt merica bubuk
1. Diperlukan 1/2 sdt garam
1. Tambah 1/2 buah jeruk lemon, ambil airnya
1. Dibutuhkan Secukupnya minyak goreng
1. Harus ada  Bahan sambal :
1. Dibutuhkan 20 buah cabe rawit merah dan hijau
1. Harus ada 4 siung bawang putih
1. Jangan lupa Secukupnya garam




<!--inarticleads2-->

##### Langkah membuat  Ayam Geprek:

1. Campurkan tepung ayam krispi, tepung terigu, garam, aduk rata.
1. Ambil 5 sdm tepung tersebut beri air secukupnya sampai kental.
1. Kucurkan air jeruk lemon ke daging ayam, bubuhi garam, bawang putih, dan merica. Diamkan 15 menit.
1. Masukan ayam ke tepung kering, gulingkan ke adonan tepung basah, masukan ke tepung kering sambil sedikit di remas dan di cubit. Goreng di minyak panas dengan api sedang sampai matang.
1. Sambal : uleg cabe rawit, bawang putih, dan garam.
1. Panaskan minyak sedikit, goreng sambal sampai matang.
1. Penyajian : ambil satu potong ayam krispi bubuhi sambal, geprek dengan ulekan.




Demikianlah cara membuat ayam geprek yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
