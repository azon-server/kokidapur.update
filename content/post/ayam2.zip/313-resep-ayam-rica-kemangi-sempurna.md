---
description: "Resep : Ayam Rica kemangi Sempurna"
title: "Resep : Ayam Rica kemangi Sempurna"
slug: 313-resep-ayam-rica-kemangi-sempurna
date: 2020-10-29T16:39:03.596Z
image: https://img-global.cpcdn.com/recipes/887185d3815d7dba/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/887185d3815d7dba/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/887185d3815d7dba/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Lucille Cain
ratingvalue: 4.5
reviewcount: 2626
recipeingredient:
- "1 ekor ayam Potong 16 atau 12 Buang kulitnya"
- "1 bungkus kemangi Kalo yang suka kemangi bisa dibanyakin Bisa"
- "1 buah tomat"
- "2 sendok perasan jeruk nipis"
- "1 simpul daun pandan"
- "1/2 daun kunyit muda potong tipis"
- "8 lembar daun jeruk Potong tipis"
- " Daun bawang potong tipis Secukupnya"
- "secukupnya Garam"
- "secukupnya Kaldu jamur"
- " Bumbu halus"
- "2 ruas jahe"
- "1 ruas kunyit"
- "2 kemiri"
- "Secukupnya merica"
- "2 siung bawang putih"
- "8 siung bawang merah"
- "2 biji cabe keriting"
- "5 cabe rawit Geprek kasar"
- "8 cabe rawit setan Geprek kasar"
recipeinstructions:
- "Tumis bumbu halus. Masukkan cabe rawit dan rawit setan yang digeprek kasar"
- "Masukkan daun pandan. Daun jeruk dan daun kunyit."
- "Masukkan ayam.aduk rata dengan bumbu. Sampai berubah warna.tambahkan garam, kaldu jamur."
- "Beri sedikit air. Masak sampai ayam empuk."
- "Terakhir masukkan kemangi, daun bawang dan tomat."
- "Setelah mendidih. Tes rasa. Dan bisa dihidangkan."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 169 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica kemangi](https://img-global.cpcdn.com/recipes/887185d3815d7dba/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang dapat kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica kemangi yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Nusantara



Kedekatan rumah tangga bisa didapat dengan cara sederhana. Diantaranya adalah memasak Ayam Rica kemangi untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang bisa anda praktekkan salah satunya ayam rica kemangi yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica kemangi:

1. Diperlukan 1 ekor ayam. Potong 16 atau 12. Buang kulitnya
1. Siapkan 1 bungkus kemangi. Kalo yang suka kemangi bisa dibanyakin. Bisa
1. Tambah 1 buah tomat
1. Harap siapkan 2 sendok perasan jeruk nipis
1. Harus ada 1 simpul daun pandan
1. Tambah 1/2 daun kunyit muda potong tipis
1. Jangan lupa 8 lembar daun jeruk. Potong tipis
1. Harap siapkan  Daun bawang potong tipis. Secukupnya
1. Diperlukan secukupnya Garam
1. Harap siapkan secukupnya Kaldu jamur
1. Dibutuhkan  Bumbu halus
1. Harap siapkan 2 ruas jahe
1. Harap siapkan 1 ruas kunyit
1. Jangan lupa 2 kemiri
1. Tambah Secukupnya merica
1. Tambah 2 siung bawang putih
1. Jangan lupa 8 siung bawang merah
1. Harus ada 2 biji cabe keriting
1. Dibutuhkan 5 cabe rawit. Geprek kasar
1. Diperlukan 8 cabe rawit setan. Geprek kasar




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica kemangi:

1. Tumis bumbu halus. Masukkan cabe rawit dan rawit setan yang digeprek kasar
1. Masukkan daun pandan. Daun jeruk dan daun kunyit.
1. Masukkan ayam.aduk rata dengan bumbu. Sampai berubah warna.tambahkan garam, kaldu jamur.
1. Beri sedikit air. Masak sampai ayam empuk.
1. Terakhir masukkan kemangi, daun bawang dan tomat.
1. Setelah mendidih. Tes rasa. Dan bisa dihidangkan.




Demikianlah cara membuat ayam rica kemangi yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan cepat, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
