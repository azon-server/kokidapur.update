---
description: "Panduan membuat Ayam Geprek Bensu #JumatBerkah Teruji"
title: "Panduan membuat Ayam Geprek Bensu #JumatBerkah Teruji"
slug: 33-panduan-membuat-ayam-geprek-bensu-jumatberkah-teruji
date: 2020-12-31T11:25:39.954Z
image: https://img-global.cpcdn.com/recipes/010ea2ec14dd3828/751x532cq70/ayam-geprek-bensu-jumatberkah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/010ea2ec14dd3828/751x532cq70/ayam-geprek-bensu-jumatberkah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/010ea2ec14dd3828/751x532cq70/ayam-geprek-bensu-jumatberkah-foto-resep-utama.jpg
author: Lura Obrien
ratingvalue: 4.9
reviewcount: 38345
recipeingredient:
- "1/2 kg Ayam potong"
- " Bahan Marinasi"
- "1/2 sdm garam"
- "1 sdm ketumbar bubuk"
- "1 sdm royco ayam"
- "1/2 sdm lada bubuk"
- "4 siung bawang putih halus"
- " Bahan Kulit"
- "8 sdm tepung terigu"
- "2 sdm tepung maizena"
- "1 butir telor"
- " Sambel Uleg"
- "20 cabe rawit merah"
- "2 siung bawang putih"
- "secukupnya Gula"
- "secukupnya garam"
- "secukupnya penyedap"
- " Daun kemangi"
- " Minyak goreng"
recipeinstructions:
- "Campur semua bumbu marinasi lalu balurkan pada ayam yang telah dibersihkan dan diamkan selama 6 jam di dalam kulkas"
- "Campurkan bahan kulit,lalu kocok telor"
- "Ambil potongan ayam lalu masukan ke dalam kocokan telor angkat dan masukan kedalam adonan bahan kulit,ulangi 2 kali"
- "Goreng ayam dengan api kecil agar ayam matang merata hingga warnanya coklat keemasan"
- "Sambil menunggu ayam matang, uleg cabe rawit dan tambahkan bawang putih yang sebelumnya digoreng lalu uleg kasar dan tambahkan gula, garam, penyedap secukupnya. Lalu tambahkan 1 sendok minyak panas ke dalam sambal"
- "Setelah ayam matang, geprek ayam dan taruh sambal diatasnya lalu hias dengan daun kemangi"
categories:
- Recipe
tags:
- ayam
- geprek
- bensu

katakunci: ayam geprek bensu 
nutrition: 246 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Geprek Bensu #JumatBerkah](https://img-global.cpcdn.com/recipes/010ea2ec14dd3828/751x532cq70/ayam-geprek-bensu-jumatberkah-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang dapat kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam geprek bensu #jumatberkah yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Kita

Kedekatan keluarga bisa didapat dengan cara mudah. Salah satunya adalah memasak Ayam Geprek Bensu #JumatBerkah untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang dapat anda coba salah satunya ayam geprek bensu #jumatberkah yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep ayam geprek bensu #jumatberkah tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Bensu #JumatBerkah yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Bensu #JumatBerkah:

1. Jangan lupa 1/2 kg Ayam potong
1. Jangan lupa  Bahan Marinasi
1. Diperlukan 1/2 sdm garam
1. Tambah 1 sdm ketumbar bubuk
1. Dibutuhkan 1 sdm royco ayam
1. Tambah 1/2 sdm lada bubuk
1. Diperlukan 4 siung bawang putih halus
1. Siapkan  Bahan Kulit
1. Harus ada 8 sdm tepung terigu
1. Siapkan 2 sdm tepung maizena
1. Diperlukan 1 butir telor
1. Harus ada  Sambel Uleg
1. Diperlukan 20 cabe rawit merah
1. Siapkan 2 siung bawang putih
1. Harap siapkan secukupnya Gula
1. Tambah secukupnya garam
1. Dibutuhkan secukupnya penyedap
1. Dibutuhkan  Daun kemangi
1. Harap siapkan  Minyak goreng




<!--inarticleads2-->

##### Instruksi membuat  Ayam Geprek Bensu #JumatBerkah:

1. Campur semua bumbu marinasi lalu balurkan pada ayam yang telah dibersihkan dan diamkan selama 6 jam di dalam kulkas
1. Campurkan bahan kulit,lalu kocok telor
1. Ambil potongan ayam lalu masukan ke dalam kocokan telor angkat dan masukan kedalam adonan bahan kulit,ulangi 2 kali
1. Goreng ayam dengan api kecil agar ayam matang merata hingga warnanya coklat keemasan
1. Sambil menunggu ayam matang, uleg cabe rawit dan tambahkan bawang putih yang sebelumnya digoreng lalu uleg kasar dan tambahkan gula, garam, penyedap secukupnya. Lalu tambahkan 1 sendok minyak panas ke dalam sambal
1. Setelah ayam matang, geprek ayam dan taruh sambal diatasnya lalu hias dengan daun kemangi




Demikianlah cara membuat ayam geprek bensu #jumatberkah yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan cepat, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
