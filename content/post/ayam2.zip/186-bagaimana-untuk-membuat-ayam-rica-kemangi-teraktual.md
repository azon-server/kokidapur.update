---
description: "Bagaimana untuk membuat Ayam rica kemangi teraktual"
title: "Bagaimana untuk membuat Ayam rica kemangi teraktual"
slug: 186-bagaimana-untuk-membuat-ayam-rica-kemangi-teraktual
date: 2021-02-05T18:45:08.205Z
image: https://img-global.cpcdn.com/recipes/ddb9acf88a0961fa/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ddb9acf88a0961fa/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ddb9acf88a0961fa/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Ophelia Gilbert
ratingvalue: 4.3
reviewcount: 8396
recipeingredient:
- "1/2 ekor ayam potong sesuai selera"
- "1 buah jeruk nipis"
- "1 buah tomat potongpotong"
- "Seruas jahe geprek"
- " Daun salam"
- " Daun jeruk"
- "Sebatang sereh"
- " Daun kunyit saya skip  gk ada stok"
- " Lengkuas geprek"
- "3 ikat daun kemangisaya suka banyak kemangi"
- "1 batang daun bawang"
- " Bumbu halussaya uleg sedikit kasar"
- "8 buah cabe rawit merah"
- "6 buah cabe merah"
- "6 butir bawang merah"
- "3 siung bawang putih"
- "3 butir kemiri sangrai"
- "sedikit Kunyit"
- "secukupnya Garam gula"
recipeinstructions:
- "Cuci bersih ayam dan lumuri dengan air perasan jeruk nipis dan garam, diamkan sebentar"
- "Goreng ayam setengah matang, sisihkan."
- "Tumis bumbu halus aduk masukkan daun jeruk, salam, sereh lengkuas jahe.tumis sampai harum dan matang"
- "Masukkan ayam aduk rata tambahkan sedikit air, masak dengan api kecil sampai bumbu meresap"
- "Masukkan gula garam,daun bawang, tomat,daun kemangi.aduk rata,tes rasa.angkat sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 120 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/ddb9acf88a0961fa/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau enak. Karasteristik makanan Indonesia ayam rica kemangi yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.




Keharmonisan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah memasak Ayam rica kemangi untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang bisa anda buat salah satunya ayam rica kemangi yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi:

1. Siapkan 1/2 ekor ayam potong sesuai selera
1. Diperlukan 1 buah jeruk nipis
1. Harus ada 1 buah tomat potong-potong
1. Tambah Seruas jahe geprek
1. Tambah  Daun salam
1. Harus ada  Daun jeruk
1. Harap siapkan Sebatang sereh
1. Dibutuhkan  Daun kunyit (saya skip / gk ada stok)
1. Jangan lupa  Lengkuas geprek
1. Jangan lupa 3 ikat daun kemangi(saya suka banyak kemangi)
1. Jangan lupa 1 batang daun bawang
1. Dibutuhkan  Bumbu halus(saya uleg sedikit kasar):
1. Harus ada 8 buah cabe rawit merah
1. Siapkan 6 buah cabe merah
1. Tambah 6 butir bawang merah
1. Diperlukan 3 siung bawang putih
1. Tambah 3 butir kemiri sangrai
1. Harap siapkan sedikit Kunyit
1. Diperlukan secukupnya Garam gula




<!--inarticleads2-->

##### Cara membuat  Ayam rica kemangi:

1. Cuci bersih ayam dan lumuri dengan air perasan jeruk nipis dan garam, diamkan sebentar
1. Goreng ayam setengah matang, sisihkan.
1. Tumis bumbu halus aduk masukkan daun jeruk, salam, sereh lengkuas jahe.tumis sampai harum dan matang
1. Masukkan ayam aduk rata tambahkan sedikit air, masak dengan api kecil sampai bumbu meresap
1. Masukkan gula garam,daun bawang, tomat,daun kemangi.aduk rata,tes rasa.angkat sajikan




Demikianlah cara membuat ayam rica kemangi yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan terbukti, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
