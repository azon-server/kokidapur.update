---
description: "Cara untuk menyiapakan Ayam Geprek Luar biasa"
title: "Cara untuk menyiapakan Ayam Geprek Luar biasa"
slug: 164-cara-untuk-menyiapakan-ayam-geprek-luar-biasa
date: 2021-01-03T23:53:27.108Z
image: https://img-global.cpcdn.com/recipes/88a683edc6cd4f31/751x532cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/88a683edc6cd4f31/751x532cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/88a683edc6cd4f31/751x532cq70/ayam-geprek-foto-resep-utama.jpg
author: Jeremy Rowe
ratingvalue: 4.3
reviewcount: 28737
recipeingredient:
- "4 potong ayam bagian dada"
- "3 potong tahu putih"
- "1 buah timun"
- "1 bungkus tepung sajiku ayam crispy"
- "1 butir telur ayam"
- "20 biji cabe rawit merah"
- "5 biji cabe merah keriting"
- "3 siung bawang putih"
- "4 siung bawang merah"
- "1/2 sdt garam"
- "1 sdt gula pasir"
- " minyak untuk menggoreng"
- " Nasi putih"
- " Bawang goreng"
recipeinstructions:
- "Kocok lepas telur ayam, lumuri ayam dengan tepung lalu celup ke telur dan lumuri lagi dengan tepung. Diamkan sebentar."
- "Goreng tahu, kalo saya 1 potong tahu saya bagi 2 dan sebelum menggoreng saya lumuri tepung."
- "Kupas timun dan potong sesuai selera."
- "Goreng bawang merah dan bawang putih lalu ulek dengan cabe dan beri garam dan gula, ulek kasar aja ya."
- "Goreng ayam tadi dengan api yang sedang biar bagian dalam ayam mateng dan kulitnya gag gosong."
- "Ambil minyak panas bekas gorengan ayam tadi, sirami k ulekan cabe. Aduk rata dan cek rasa. Kalo saya gag terlalu pedes."
- "Geprek ayam crispy dan susun dipiring, sajikan, siap dinikmati."
- "Jangan lupasl share recook nya ya. Ini enak ! 😘"
categories:
- Recipe
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 268 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/88a683edc6cd4f31/751x532cq70/ayam-geprek-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang harus kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam geprek yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan keistimewahan yang merupakan keragaman Indonesia



Kedekatan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah memasak Ayam Geprek untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang bisa anda contoh salah satunya ayam geprek yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep ayam geprek tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 14 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek:

1. Diperlukan 4 potong ayam bagian dada
1. Tambah 3 potong tahu putih
1. Siapkan 1 buah timun
1. Jangan lupa 1 bungkus tepung sajiku ayam crispy
1. Harus ada 1 butir telur ayam
1. Siapkan 20 biji cabe rawit merah
1. Harap siapkan 5 biji cabe merah keriting
1. Diperlukan 3 siung bawang putih
1. Dibutuhkan 4 siung bawang merah
1. Siapkan 1/2 sdt garam
1. Diperlukan 1 sdt gula pasir
1. Siapkan  minyak untuk menggoreng
1. Tambah  Nasi putih
1. Tambah  Bawang goreng




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Geprek:

1. Kocok lepas telur ayam, lumuri ayam dengan tepung lalu celup ke telur dan lumuri lagi dengan tepung. Diamkan sebentar.
1. Goreng tahu, kalo saya 1 potong tahu saya bagi 2 dan sebelum menggoreng saya lumuri tepung.
1. Kupas timun dan potong sesuai selera.
1. Goreng bawang merah dan bawang putih lalu ulek dengan cabe dan beri garam dan gula, ulek kasar aja ya.
1. Goreng ayam tadi dengan api yang sedang biar bagian dalam ayam mateng dan kulitnya gag gosong.
1. Ambil minyak panas bekas gorengan ayam tadi, sirami k ulekan cabe. Aduk rata dan cek rasa. Kalo saya gag terlalu pedes.
1. Geprek ayam crispy dan susun dipiring, sajikan, siap dinikmati.
1. Jangan lupasl share recook nya ya. Ini enak ! 😘




Demikianlah cara membuat ayam geprek yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan cepat, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
