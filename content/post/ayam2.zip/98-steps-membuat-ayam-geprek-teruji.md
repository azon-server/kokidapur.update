---
description: "Steps membuat Ayam Geprek Teruji"
title: "Steps membuat Ayam Geprek Teruji"
slug: 98-steps-membuat-ayam-geprek-teruji
date: 2021-01-24T11:55:10.232Z
image: https://img-global.cpcdn.com/recipes/0c8743308414ca00/751x532cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0c8743308414ca00/751x532cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0c8743308414ca00/751x532cq70/ayam-geprek-foto-resep-utama.jpg
author: Eugene Hudson
ratingvalue: 5
reviewcount: 14459
recipeingredient:
- "250 gr Ayam bag Dada"
- "200 gr Tepung Ayam saya pake Sajiku Golden Crispy"
- " BahanBahan "
- "7 Buah Cabe Rawit"
- "1/2 siung Bawang Putih"
- " Garam"
recipeinstructions:
- "Cuci bersih ayam, potong sesuai selera sambil beri sayatan supaya bumbu meresap ke ayam (saya jadi 4 potong Ayam) setelah itu beri perasan jeruk nipis lalu rebus sebentar"
- "Larutkan tepung Ayam tadi secukupnya untuk Ayam yg sudah di potong menjadi bbrp bagian (lebih baik menggunakan air es utk melarutkan tepungnya krna saya gak pernah buat air es jdi pake air biasa 😅) sambil di tekan2 lalu diamkan 30 menit agar meresap ya, bisa masukkan ke kulkas biar crispy gtu hehe"
- "Setelah 30 menit balurkan ayam ke sisa tepung yg kering sambil tekan2 lalu tepuk2 ayamnya agar minyaknya nanti gak terlalu kotor krna tepung"
- "Panaskan wajan dengan api kecil agar ayam tidak mudah gosong dan matang merata, setelah minyak panas masukkan ayam"
- "Sambil menunggu ayam matang, bisa haluskan bawang putih dan cabe lalu beri garam secukupnya beri sedikit minyak panas dr menggoreng ayam itu"
- "Setelah ayam matang, angkat dan tiriskan sebentar lalu geprek di atas bumbu yg sudah di haluskan, sajikan 😊"
- "Nb : untuk tepung bisa sesuai selera ya bgitu juga baputnya dan cabenya, klo mau bisa jg di tambah terasi 😁"
categories:
- Recipe
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 110 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/0c8743308414ca00/751x532cq70/ayam-geprek-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga renyah. Karasteristik makanan Indonesia ayam geprek yang kaya dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Geprek untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda buat salah satunya ayam geprek yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep ayam geprek tanpa harus bersusah payah.
Seperti resep Ayam Geprek yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 6 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek:

1. Tambah 250 gr Ayam bag. Dada
1. Siapkan 200 gr Tepung Ayam (saya pake Sajiku Golden Crispy)
1. Harap siapkan  Bahan-Bahan :
1. Siapkan 7 Buah Cabe Rawit
1. Tambah 1/2 siung Bawang Putih
1. Tambah  Garam




<!--inarticleads2-->

##### Instruksi membuat  Ayam Geprek:

1. Cuci bersih ayam, potong sesuai selera sambil beri sayatan supaya bumbu meresap ke ayam (saya jadi 4 potong Ayam) setelah itu beri perasan jeruk nipis lalu rebus sebentar
1. Larutkan tepung Ayam tadi secukupnya untuk Ayam yg sudah di potong menjadi bbrp bagian (lebih baik menggunakan air es utk melarutkan tepungnya krna saya gak pernah buat air es jdi pake air biasa 😅) sambil di tekan2 lalu diamkan 30 menit agar meresap ya, bisa masukkan ke kulkas biar crispy gtu hehe
1. Setelah 30 menit balurkan ayam ke sisa tepung yg kering sambil tekan2 lalu tepuk2 ayamnya agar minyaknya nanti gak terlalu kotor krna tepung
1. Panaskan wajan dengan api kecil agar ayam tidak mudah gosong dan matang merata, setelah minyak panas masukkan ayam
1. Sambil menunggu ayam matang, bisa haluskan bawang putih dan cabe lalu beri garam secukupnya beri sedikit minyak panas dr menggoreng ayam itu
1. Setelah ayam matang, angkat dan tiriskan sebentar lalu geprek di atas bumbu yg sudah di haluskan, sajikan 😊
1. Nb : untuk tepung bisa sesuai selera ya bgitu juga baputnya dan cabenya, klo mau bisa jg di tambah terasi 😁




Demikianlah cara membuat ayam geprek yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat simple dan teruji, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
