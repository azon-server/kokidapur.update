---
description: "Resep : Ayam Rica Kemangi Luar biasa"
title: "Resep : Ayam Rica Kemangi Luar biasa"
slug: 201-resep-ayam-rica-kemangi-luar-biasa
date: 2020-11-29T18:29:29.107Z
image: https://img-global.cpcdn.com/recipes/1c114eee7c4c45e6/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1c114eee7c4c45e6/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1c114eee7c4c45e6/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Alvin Cohen
ratingvalue: 4.2
reviewcount: 1023
recipeingredient:
- "1/2 kg ayam"
- "1 buah jeruk nipis"
- "3 daun salam"
- "3 daun jeruk"
- "1 batang serai geprek"
- "3 cm jahe geprek"
- "3 cm lengkuas geprek"
- "secukupnya Minyak"
- "secukupnya Air"
- "secukupnya Garam  gula"
- "Seikat daun kemangi"
- " Bumbu halus"
- "6 bawang merah"
- "3 bawang putih"
- "10 cabe merah"
- "3 cabe rawit"
- "2 cm kunyit"
- "3 biji kemiri"
- "1/2 sdt merica"
- "1/2 sdt ketumbar"
recipeinstructions:
- "Cuci bersih ayam lalu tambahkan perasan jeruk nipis supaya tidak amis dan diamkan sebentar"
- "Goreng ayam setengah matang lalu tiriskan"
- "Sambil menunggu ayam setengah matang, haluskan semua bumbu halus"
- "Panaskan minyak, lalu tumis bumbu halus"
- "Masukkan daun salam, daun jeruk, daun sereh, lengkuas, dan jahe lalu tumis hingga wangi"
- "Tambahkan air sesuai selera"
- "Masukkan ayam yang telah digoreng setengah matang dan aduk merata"
- "Masukkan garam &amp; gula secukupnya"
- "Ketika sudah hampir matang, masukkan seikat daun kemangi yang sudah dipetik dan dicuci bersih"
- "Tunggu sebentar hingga daun kemangi sedikit lalu, matikan api, angkat, lalu sajikan dengan nasi hangat"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 161 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/1c114eee7c4c45e6/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita jaga karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica kemangi yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa ciri khas yang merupakan keragaman Kita



Kehangatan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Rica Kemangi untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang dapat anda contoh salah satunya ayam rica kemangi yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 10 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Dibutuhkan 1/2 kg ayam
1. Diperlukan 1 buah jeruk nipis
1. Harap siapkan 3 daun salam
1. Dibutuhkan 3 daun jeruk
1. Siapkan 1 batang serai (geprek)
1. Tambah 3 cm jahe (geprek)
1. Diperlukan 3 cm lengkuas (geprek)
1. Harus ada secukupnya Minyak
1. Jangan lupa secukupnya Air
1. Dibutuhkan secukupnya Garam &amp; gula
1. Diperlukan Seikat daun kemangi
1. Jangan lupa  Bumbu halus:
1. Harus ada 6 bawang merah
1. Jangan lupa 3 bawang putih
1. Diperlukan 10 cabe merah
1. Harus ada 3 cabe rawit
1. Siapkan 2 cm kunyit
1. Harus ada 3 biji kemiri
1. Jangan lupa 1/2 sdt merica
1. Siapkan 1/2 sdt ketumbar




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Kemangi:

1. Cuci bersih ayam lalu tambahkan perasan jeruk nipis supaya tidak amis dan diamkan sebentar
1. Goreng ayam setengah matang lalu tiriskan
1. Sambil menunggu ayam setengah matang, haluskan semua bumbu halus
1. Panaskan minyak, lalu tumis bumbu halus
1. Masukkan daun salam, daun jeruk, daun sereh, lengkuas, dan jahe lalu tumis hingga wangi
1. Tambahkan air sesuai selera
1. Masukkan ayam yang telah digoreng setengah matang dan aduk merata
1. Masukkan garam &amp; gula secukupnya
1. Ketika sudah hampir matang, masukkan seikat daun kemangi yang sudah dipetik dan dicuci bersih
1. Tunggu sebentar hingga daun kemangi sedikit lalu, matikan api, angkat, lalu sajikan dengan nasi hangat




Demikianlah cara membuat ayam rica kemangi yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan teruji, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
