---
description: "Cara untuk menyiapakan Ayam Geprek Bensu KW Homemade"
title: "Cara untuk menyiapakan Ayam Geprek Bensu KW Homemade"
slug: 50-cara-untuk-menyiapakan-ayam-geprek-bensu-kw-homemade
date: 2020-12-09T12:16:31.598Z
image: https://img-global.cpcdn.com/recipes/975dd4fe91adde0c/751x532cq70/ayam-geprek-bensu-kw-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/975dd4fe91adde0c/751x532cq70/ayam-geprek-bensu-kw-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/975dd4fe91adde0c/751x532cq70/ayam-geprek-bensu-kw-foto-resep-utama.jpg
author: Scott Reese
ratingvalue: 4.7
reviewcount: 13543
recipeingredient:
- "1/2 kg ayam potong sesuai selera"
- "4 siung bawang putih"
- "1 sdt merica bubuk"
- "2 sdt kaldu bubuk"
- "1 sdt garam"
- " Bahan lainnya"
- "1 butir telur"
- "2 bks tepung serbaguna"
- " Bahan sambel"
- "20 biji cabe rawit sesuai selera"
- "3 siung bawang putih"
- "1 siung bawang merah"
- "2 sdm air perasan jeruk nipis"
- "Secukupnya garam gula pasir dan kaldu bubuk"
recipeinstructions:
- "Haluskan bawang putih kemudian campurkan dengan merica, kaldu bubuk dan garam"
- "Kemudian masukan ayam ke dalam bumbu halus tadi lalu aduk dan diremas supaya bumbu meresap diamkan min. 2 jam"
- "Setelah itu masukan telur ke dalam ayam yang sudah didiamkan dan di aduk sampai tercampur"
- "Gulingkan ayam ke dalam tepung serbaguna sampai merata dan dicubit supaya ayamnya keriting"
- "Goreng ayam dengan api kecil agar matang sampai ke dalam lalu angkat bila ayam sudah berwarna kuning keemasan"
- "Kemudian buat sambel gepreknya dengan menggoreng bawang merah dan putihnya saja lalu uleg bersama cabe rawit dan beri gula pasir, garam, kaldu bubuk dan perasan air jeruk nipis"
- "Lalu siram dengan bekas minyak menggoreng ayam lalu geprek ayamnya pada sambel atau bisa pula dipisah sambelnya agar bisa dicolek :)"
categories:
- Recipe
tags:
- ayam
- geprek
- bensu

katakunci: ayam geprek bensu 
nutrition: 204 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Geprek Bensu KW](https://img-global.cpcdn.com/recipes/975dd4fe91adde0c/751x532cq70/ayam-geprek-bensu-kw-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau renyah. Ciri khas masakan Nusantara ayam geprek bensu kw yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga bisa didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam Geprek Bensu KW untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang bisa anda contoh salah satunya ayam geprek bensu kw yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep ayam geprek bensu kw tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Bensu KW yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 14 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Bensu KW:

1. Dibutuhkan 1/2 kg ayam (potong sesuai selera
1. Diperlukan 4 siung bawang putih
1. Siapkan 1 sdt merica bubuk
1. Tambah 2 sdt kaldu bubuk
1. Diperlukan 1 sdt garam
1. Diperlukan  Bahan lainnya
1. Dibutuhkan 1 butir telur
1. Harus ada 2 bks tepung serbaguna
1. Diperlukan  Bahan sambel
1. Diperlukan 20 biji cabe rawit (sesuai selera)
1. Jangan lupa 3 siung bawang putih
1. Dibutuhkan 1 siung bawang merah
1. Diperlukan 2 sdm air perasan jeruk nipis
1. Harap siapkan Secukupnya garam, gula pasir dan kaldu bubuk




<!--inarticleads2-->

##### Instruksi membuat  Ayam Geprek Bensu KW:

1. Haluskan bawang putih kemudian campurkan dengan merica, kaldu bubuk dan garam
1. Kemudian masukan ayam ke dalam bumbu halus tadi lalu aduk dan diremas supaya bumbu meresap diamkan min. 2 jam
1. Setelah itu masukan telur ke dalam ayam yang sudah didiamkan dan di aduk sampai tercampur
1. Gulingkan ayam ke dalam tepung serbaguna sampai merata dan dicubit supaya ayamnya keriting
1. Goreng ayam dengan api kecil agar matang sampai ke dalam lalu angkat bila ayam sudah berwarna kuning keemasan
1. Kemudian buat sambel gepreknya dengan menggoreng bawang merah dan putihnya saja lalu uleg bersama cabe rawit dan beri gula pasir, garam, kaldu bubuk dan perasan air jeruk nipis
1. Lalu siram dengan bekas minyak menggoreng ayam lalu geprek ayamnya pada sambel atau bisa pula dipisah sambelnya agar bisa dicolek :)




Demikianlah cara membuat ayam geprek bensu kw yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan terbukti, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
