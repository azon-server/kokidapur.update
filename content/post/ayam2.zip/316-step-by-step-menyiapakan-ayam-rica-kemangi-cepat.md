---
description: "Step-by-Step menyiapakan Ayam Rica Kemangi Cepat"
title: "Step-by-Step menyiapakan Ayam Rica Kemangi Cepat"
slug: 316-step-by-step-menyiapakan-ayam-rica-kemangi-cepat
date: 2020-10-27T07:42:52.013Z
image: https://img-global.cpcdn.com/recipes/03acc7898c10abeb/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/03acc7898c10abeb/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/03acc7898c10abeb/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Amelia Parks
ratingvalue: 4
reviewcount: 35307
recipeingredient:
- "800 gr ayam"
- "1 buah jeruk nipis"
- " Bumbu Halus"
- "5 buah cabe merah besar"
- "7 buah cabe rawit"
- "5 siung bawang merah"
- "1 siung bawang putih"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1 ruas kunyit"
- "2 butir kemiri"
- " Bahan lain"
- " daun salam"
- " daun jeruk"
- " sereh"
- " daun bawang"
- " kemangi"
- " penyedap rasa ayam"
- " garam"
- " gula"
- " minyak goreng"
- " air"
recipeinstructions:
- "Cuci bersih ayam, lumuri dengan air jeruk nipis, cuci kembali."
- "Marinasi ayam dengan penyedap dan bubuk kunyit/kunyit yg dihaluskan. Diamkan 10 menit."
- "Goreng ayam setengah matang, tiriskan."
- "Haluskan bumbu halus, jika menggunakan blender jangan terlalu halus."
- "Panaskan minyak goreng, masukkan bumbu halus, tambahkan daun salam, daun jeruk dan sereh."
- "Setelah wangi masukkan ayam dan tambahkan air, garam, gula dan penyedap. Masak sampai air menyusut."
- "Terakhir masukkan kemangi dan daun bawang, tes rasa dan siap disajikan."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 242 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/03acc7898c10abeb/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas atau renyah. Ciri khas kuliner Nusantara ayam rica kemangi yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica Kemangi untuk keluarga. Momen makan bersama anak sudah menjadi budaya, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang bisa anda praktekkan salah satunya ayam rica kemangi yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Dibutuhkan 800 gr ayam
1. Harus ada 1 buah jeruk nipis
1. Diperlukan  Bumbu Halus
1. Jangan lupa 5 buah cabe merah besar
1. Tambah 7 buah cabe rawit
1. Siapkan 5 siung bawang merah
1. Siapkan 1 siung bawang putih
1. Harus ada 1 ruas jahe
1. Harus ada 1 ruas lengkuas
1. Jangan lupa 1 ruas kunyit
1. Tambah 2 butir kemiri
1. Tambah  Bahan lain
1. Diperlukan  daun salam
1. Harap siapkan  daun jeruk
1. Dibutuhkan  sereh
1. Tambah  daun bawang
1. Dibutuhkan  kemangi
1. Dibutuhkan  penyedap rasa ayam
1. Diperlukan  garam
1. Harap siapkan  gula
1. Harus ada  minyak goreng
1. Jangan lupa  air




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Kemangi:

1. Cuci bersih ayam, lumuri dengan air jeruk nipis, cuci kembali.
1. Marinasi ayam dengan penyedap dan bubuk kunyit/kunyit yg dihaluskan. Diamkan 10 menit.
1. Goreng ayam setengah matang, tiriskan.
1. Haluskan bumbu halus, jika menggunakan blender jangan terlalu halus.
1. Panaskan minyak goreng, masukkan bumbu halus, tambahkan daun salam, daun jeruk dan sereh.
1. Setelah wangi masukkan ayam dan tambahkan air, garam, gula dan penyedap. Masak sampai air menyusut.
1. Terakhir masukkan kemangi dan daun bawang, tes rasa dan siap disajikan.




Demikianlah cara membuat ayam rica kemangi yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan cepat, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
