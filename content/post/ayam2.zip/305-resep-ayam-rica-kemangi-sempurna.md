---
description: "Resep : Ayam rica kemangi Sempurna"
title: "Resep : Ayam rica kemangi Sempurna"
slug: 305-resep-ayam-rica-kemangi-sempurna
date: 2021-01-25T16:05:41.762Z
image: https://img-global.cpcdn.com/recipes/ada9488debf6fbcc/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ada9488debf6fbcc/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ada9488debf6fbcc/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Henry Jacobs
ratingvalue: 5
reviewcount: 19013
recipeingredient:
- " Bahan"
- "1 kg ayam"
- "5 ikat kemangi"
- " minyak goreng"
- " Garam"
- " Penyedap mecin"
- " Air"
- " Bahan halus"
- "5 buah cabe merah keriting"
- "15 buah cabe rawit merah"
- " Ketumbar"
- "4 buah bawang putih"
- "7 buah bawang merah"
- "1 buah kunyit"
- "1/2 buah jahe"
- " Bahan cemplung"
- " Lengkuas memarkan"
- "2 batang serai memarkan"
- "2 lembar daun jeruk"
- "3 lembar daun salam"
recipeinstructions:
- "Pertama cuci bersih ayam, lalu rebus dengan sedikit jahe selama 1/2 jam hingga empuk"
- "Kedua ulek/blender bahan halus, kemudian siapkan minyak panas lalu tumis bahan halus hingga wangi setelah wangi masukan serai, daun salam, daun jeruk, dan lengkuas. Kemudian masukan air setengah gayung masukan garam dan penyedap koreksi rasa setelah ok masukan ayam masak hingga airnya menyusut, kalau sudah masukan daun kemangi aduk sebentar. Ayam rica siap dihidangkan"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 145 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/ada9488debf6fbcc/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica kemangi yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan keistimewahan yang merupakan keragaman Nusantara

Kedekatan rumah tangga bisa didapat dengan cara sederhana. Salah satunya adalah memasak Ayam rica kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang bisa anda buat salah satunya ayam rica kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 2 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi:

1. Dibutuhkan  Bahan
1. Harap siapkan 1 kg ayam
1. Diperlukan 5 ikat kemangi
1. Diperlukan  minyak goreng
1. Jangan lupa  Garam
1. Siapkan  Penyedap/ mecin
1. Diperlukan  Air
1. Dibutuhkan  Bahan halus
1. Siapkan 5 buah cabe merah keriting
1. Jangan lupa 15 buah cabe rawit merah
1. Harus ada  Ketumbar
1. Jangan lupa 4 buah bawang putih
1. Diperlukan 7 buah bawang merah
1. Jangan lupa 1 buah kunyit
1. Harus ada 1/2 buah jahe
1. Tambah  Bahan cemplung
1. Diperlukan  Lengkuas memarkan
1. Diperlukan 2 batang serai memarkan
1. Harap siapkan 2 lembar daun jeruk
1. Tambah 3 lembar daun salam




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica kemangi:

1. Pertama cuci bersih ayam, lalu rebus dengan sedikit jahe selama 1/2 jam hingga empuk
1. Kedua ulek/blender bahan halus, kemudian siapkan minyak panas lalu tumis bahan halus hingga wangi setelah wangi masukan serai, daun salam, daun jeruk, dan lengkuas. Kemudian masukan air setengah gayung masukan garam dan penyedap koreksi rasa setelah ok masukan ayam masak hingga airnya menyusut, kalau sudah masukan daun kemangi aduk sebentar. Ayam rica siap dihidangkan




Demikianlah cara membuat ayam rica kemangi yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan teruji, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
