---
description: "Cara singkat menyiapakan Ayam Geprek Pedas Ala Bensu Cepat"
title: "Cara singkat menyiapakan Ayam Geprek Pedas Ala Bensu Cepat"
slug: 52-cara-singkat-menyiapakan-ayam-geprek-pedas-ala-bensu-cepat
date: 2020-09-11T17:18:05.408Z
image: https://img-global.cpcdn.com/recipes/cfe37f82ce72ec3c/751x532cq70/ayam-geprek-pedas-ala-bensu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cfe37f82ce72ec3c/751x532cq70/ayam-geprek-pedas-ala-bensu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cfe37f82ce72ec3c/751x532cq70/ayam-geprek-pedas-ala-bensu-foto-resep-utama.jpg
author: Sara Hayes
ratingvalue: 4.3
reviewcount: 5254
recipeingredient:
- "2 potong ayam bagian paha dan dada ayam"
- "1 butir telur"
- "5 sendok tepung terigu"
- "3 sendok tepung maizena"
- "3 siung bawang putih"
- "Secukupnya merica"
- "Secukupnya garam"
- "Secukupnya minyak goreng"
- "1 batang daun kemangi"
- " Sambal"
- "22 buah cabe rawit"
- "2 siung bawang putih digoreng"
- "Secukupnya garam"
recipeinstructions:
- "Masukkan ayam. Tambahkan bawang putih halus, merica, dan garam. (Bisa menambahkan bumbu penyedap jika Anda sukai) Oh iya maaf, mericanya terlihat seperti ketumbar yaa. karena stok merica bubuk habis alhasil pakai merica asli dan males diulek sampai halus 😂"
- "Remas-remas ayam, sampai bumbu tercampur rata dan teresap. Tinggalkan selama kurang lebih 2 jam (semakin lama semakin baik, agar bumbu meresap pada ayam)"
- "Setelah Anda merasa bumbu telah meresap, masukkan 1 butir telur. Kocok hingga semua permukaan ayam terlumuri telur"
- "Siapkan tepung terigu dan tepung maizena, campurkan. Lalu masukkan ayam yang telah dilumuri telur kedalam tepung. Pastikan semua permukaan ayam tertutupi tepung yaa."
- "Setelah minyak goreng panas, masukkan ayam. Goreng ayam dengan api kecil agar ayam matang sampai didalamnya. Goreng sampai berubah warna menjadi kuning keemasan lalu balik perlahan."
- "Tunggu sampai kedua sisi ayam matang dan berubah menjadi kuning keemasan. Lalu tiriskan. (Bisa juga dijadiin resep ayam krispi hihi)"
- "Sambel: masukkan bawang putih yang telah di goreng, cabe, garam. Ulek sampai halus. Tambahkan 2 sendok minyak goreng panas bekas menggoreng ayam."
- "Geprek ayam pada sambel. Berikan daun kemangi jika Anda suka. Ayam geprek pedas siap disantap!"
- "Jika ingin ikutin makanan kekinian, bisa ditambahin keju parut atau lelehan keju mozarella yaa 😊"
categories:
- Recipe
tags:
- ayam
- geprek
- pedas

katakunci: ayam geprek pedas 
nutrition: 130 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Geprek Pedas Ala Bensu](https://img-global.cpcdn.com/recipes/cfe37f82ce72ec3c/751x532cq70/ayam-geprek-pedas-ala-bensu-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan empuk. Ciri khas kuliner Indonesia ayam geprek pedas ala bensu yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan keluarga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam Geprek Pedas Ala Bensu untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang bisa anda coba salah satunya ayam geprek pedas ala bensu yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep ayam geprek pedas ala bensu tanpa harus bersusah payah.
Seperti resep Ayam Geprek Pedas Ala Bensu yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 13 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Pedas Ala Bensu:

1. Diperlukan 2 potong ayam; bagian paha dan dada ayam
1. Jangan lupa 1 butir telur
1. Tambah 5 sendok tepung terigu
1. Harap siapkan 3 sendok tepung maizena
1. Tambah 3 siung bawang putih
1. Tambah Secukupnya merica
1. Harus ada Secukupnya garam
1. Siapkan Secukupnya minyak goreng
1. Dibutuhkan 1 batang daun kemangi
1. Jangan lupa  Sambal:
1. Dibutuhkan 22 buah cabe rawit
1. Diperlukan 2 siung bawang putih, digoreng
1. Harus ada Secukupnya garam




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Geprek Pedas Ala Bensu:

1. Masukkan ayam. Tambahkan bawang putih halus, merica, dan garam. (Bisa menambahkan bumbu penyedap jika Anda sukai) Oh iya maaf, mericanya terlihat seperti ketumbar yaa. karena stok merica bubuk habis alhasil pakai merica asli dan males diulek sampai halus 😂
1. Remas-remas ayam, sampai bumbu tercampur rata dan teresap. Tinggalkan selama kurang lebih 2 jam (semakin lama semakin baik, agar bumbu meresap pada ayam)
1. Setelah Anda merasa bumbu telah meresap, masukkan 1 butir telur. Kocok hingga semua permukaan ayam terlumuri telur
1. Siapkan tepung terigu dan tepung maizena, campurkan. Lalu masukkan ayam yang telah dilumuri telur kedalam tepung. Pastikan semua permukaan ayam tertutupi tepung yaa.
1. Setelah minyak goreng panas, masukkan ayam. Goreng ayam dengan api kecil agar ayam matang sampai didalamnya. Goreng sampai berubah warna menjadi kuning keemasan lalu balik perlahan.
1. Tunggu sampai kedua sisi ayam matang dan berubah menjadi kuning keemasan. Lalu tiriskan. (Bisa juga dijadiin resep ayam krispi hihi)
1. Sambel: masukkan bawang putih yang telah di goreng, cabe, garam. Ulek sampai halus. Tambahkan 2 sendok minyak goreng panas bekas menggoreng ayam.
1. Geprek ayam pada sambel. Berikan daun kemangi jika Anda suka. Ayam geprek pedas siap disantap!
1. Jika ingin ikutin makanan kekinian, bisa ditambahin keju parut atau lelehan keju mozarella yaa 😊




Demikianlah cara membuat ayam geprek pedas ala bensu yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
