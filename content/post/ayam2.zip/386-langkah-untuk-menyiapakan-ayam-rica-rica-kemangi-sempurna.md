---
description: "Langkah untuk menyiapakan Ayam Rica-rica Kemangi Sempurna"
title: "Langkah untuk menyiapakan Ayam Rica-rica Kemangi Sempurna"
slug: 386-langkah-untuk-menyiapakan-ayam-rica-rica-kemangi-sempurna
date: 2020-11-29T07:50:10.364Z
image: https://img-global.cpcdn.com/recipes/ddb0d6fec92791db/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ddb0d6fec92791db/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ddb0d6fec92791db/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Dean Smith
ratingvalue: 4.4
reviewcount: 14657
recipeingredient:
- "500 gram ayam potong cuci bersih"
- "1/2 buah tomat iris2"
- "5 batang daun kemangi ambil daunnya"
- "Secukupnya daun bawang"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 buah serai geprek"
- "1/2 sdt garam"
- "1/2 sdt gula pasir"
- "1/2 sdt lada bubuk"
- "1/2 sdt kaldu bubuk"
- "Secukupnya air"
- "Secukupnya minyak untuk tumis"
- " Bumbu halus"
- "3 siung bawang putih"
- "6 siung bawang merah"
- "2 cm jahe"
- "3 butir kemiri"
- "1/2 sdt kunyit bubuk segar lebih baik ya"
- "5 buah cabe rawit merah"
recipeinstructions:
- "Siapkan wajan, tumis bumbu halus hingga harum"
- "Masukkan serai, daun salam, daun jeruk, lanjut tumisnya"
- "Masukkan ayam, aduk rata, oseng2 sebentar."
- "Tambahkan air, garam, gula, kaldu bubuk, lada bubuk. Masak hingga ayam matang dan bumbu meresap."
- "Tambahkan daun bawang, tomat dan daun kemangi, aduk rata. Matikan api."
- "Sajikan.."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 278 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/ddb0d6fec92791db/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga renyah. Ciri khas makanan Indonesia ayam rica-rica kemangi yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kedekatan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica-rica Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang bisa anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Kemangi:

1. Siapkan 500 gram ayam, potong cuci bersih
1. Tambah 1/2 buah tomat iris2
1. Dibutuhkan 5 batang daun kemangi, ambil daunnya
1. Dibutuhkan Secukupnya daun bawang
1. Siapkan 2 lembar daun salam
1. Siapkan 3 lembar daun jeruk
1. Jangan lupa 1 buah serai geprek
1. Dibutuhkan 1/2 sdt garam
1. Tambah 1/2 sdt gula pasir
1. Jangan lupa 1/2 sdt lada bubuk
1. Siapkan 1/2 sdt kaldu bubuk
1. Harus ada Secukupnya air
1. Dibutuhkan Secukupnya minyak untuk tumis
1. Jangan lupa  Bumbu halus
1. Harus ada 3 siung bawang putih
1. Dibutuhkan 6 siung bawang merah
1. Tambah 2 cm jahe
1. Tambah 3 butir kemiri
1. Diperlukan 1/2 sdt kunyit bubuk, segar lebih baik ya
1. Tambah 5 buah cabe rawit merah




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-rica Kemangi:

1. Siapkan wajan, tumis bumbu halus hingga harum
1. Masukkan serai, daun salam, daun jeruk, lanjut tumisnya
1. Masukkan ayam, aduk rata, oseng2 sebentar.
1. Tambahkan air, garam, gula, kaldu bubuk, lada bubuk. Masak hingga ayam matang dan bumbu meresap.
1. Tambahkan daun bawang, tomat dan daun kemangi, aduk rata. Matikan api.
1. Sajikan..




Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan cepat, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
