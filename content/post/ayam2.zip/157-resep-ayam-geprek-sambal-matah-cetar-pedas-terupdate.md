---
description: "Resep : Ayam Geprek Sambal Matah (Cetar Pedas) terupdate"
title: "Resep : Ayam Geprek Sambal Matah (Cetar Pedas) terupdate"
slug: 157-resep-ayam-geprek-sambal-matah-cetar-pedas-terupdate
date: 2020-12-13T20:13:59.662Z
image: https://img-global.cpcdn.com/recipes/933a4dffda479d6c/751x532cq70/ayam-geprek-sambal-matah-cetar-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/933a4dffda479d6c/751x532cq70/ayam-geprek-sambal-matah-cetar-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/933a4dffda479d6c/751x532cq70/ayam-geprek-sambal-matah-cetar-pedas-foto-resep-utama.jpg
author: Franklin Graham
ratingvalue: 4.6
reviewcount: 44828
recipeingredient:
- "4 potong dadapaha Ayam"
- "2 lembar daun salam dan daun jeruk"
- "1 ikat daun kemangi"
- " Bumbu Halus"
- "4 siung bawang putih"
- "5 siung bawang merah"
- "1/2 sdt kunyit bubuk"
- "1/2 sdt garam dan merica secukupnya"
- "1/2 sdt garam dan royco"
- " Adonan Crispy"
- "2 butir putih telur"
- "2 sachet tepung sajiku crispy"
- "1/2 sdt kaldu ayam bubuk Royco"
- " Bahan sambal matah"
- "5 siung bawang putih"
- "10 cabe rawit merah"
- "2 buah jeruk limo peras airnya"
- "1/2 sdt garam"
- "1/2 sdt Gula merah"
recipeinstructions:
- "Cuci bersih ayam dan bahan bumbu yg lainya. Kemudian ungkep ayam dengan bumbu yg disediakan tadi hingga meresap."
- "Ambil 3 sendok tepung campur dengan telur kocog lepas, lalu lumuri ayam dengan tepung basah. Kemudian gulingkan ayam kedalam tepung bumbu kering. Lakukan langkah tersebut dua kali."
- "Panaskan minyak lalu goreng ayam dengan api sedang hingga matang kecoklatan. Angkat dan tiriskan."
- "Buat sambal matah: goreng cabai dan bawang putih setengah matang. Kemudian uleg kasar tambahkan garam, gula dan kaldu secukupnya."
- "Kemudian geprek ayam dengan baluran sambal diatasnya. Jangan lupa tambahkan perasan jeruk lemo dan lalapan agar segar rasanya. Yummmy... Ayam geprek siap untuk disajikan."
categories:
- Recipe
tags:
- ayam
- geprek
- sambal

katakunci: ayam geprek sambal 
nutrition: 198 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Geprek Sambal Matah (Cetar Pedas)](https://img-global.cpcdn.com/recipes/933a4dffda479d6c/751x532cq70/ayam-geprek-sambal-matah-cetar-pedas-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan gurih. Karasteristik masakan Indonesia ayam geprek sambal matah (cetar pedas) yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak Ayam Geprek Sambal Matah (Cetar Pedas) untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang dapat anda contoh salah satunya ayam geprek sambal matah (cetar pedas) yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep ayam geprek sambal matah (cetar pedas) tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Sambal Matah (Cetar Pedas) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Sambal Matah (Cetar Pedas):

1. Tambah 4 potong (dada/paha Ayam)
1. Siapkan 2 lembar daun salam dan daun jeruk
1. Harap siapkan 1 ikat daun kemangi
1. Harus ada  Bumbu Halus:
1. Harap siapkan 4 siung bawang putih
1. Diperlukan 5 siung bawang merah
1. Siapkan 1/2 sdt kunyit bubuk
1. Dibutuhkan 1/2 sdt garam dan merica (secukupnya)
1. Tambah 1/2 sdt garam dan royco
1. Harus ada  Adonan Crispy:
1. Harap siapkan 2 butir putih telur
1. Dibutuhkan 2 sachet tepung (sajiku crispy)
1. Tambah 1/2 sdt kaldu ayam bubuk (Royco)
1. Siapkan  Bahan sambal matah:
1. Dibutuhkan 5 siung bawang putih
1. Diperlukan 10 cabe rawit merah
1. Jangan lupa 2 buah jeruk limo (peras airnya)
1. Siapkan 1/2 sdt garam
1. Siapkan 1/2 sdt Gula merah




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Geprek Sambal Matah (Cetar Pedas):

1. Cuci bersih ayam dan bahan bumbu yg lainya. Kemudian ungkep ayam dengan bumbu yg disediakan tadi hingga meresap.
1. Ambil 3 sendok tepung campur dengan telur kocog lepas, lalu lumuri ayam dengan tepung basah. Kemudian gulingkan ayam kedalam tepung bumbu kering. Lakukan langkah tersebut dua kali.
1. Panaskan minyak lalu goreng ayam dengan api sedang hingga matang kecoklatan. Angkat dan tiriskan.
1. Buat sambal matah: goreng cabai dan bawang putih setengah matang. Kemudian uleg kasar tambahkan garam, gula dan kaldu secukupnya.
1. Kemudian geprek ayam dengan baluran sambal diatasnya. Jangan lupa tambahkan perasan jeruk lemo dan lalapan agar segar rasanya. Yummmy... Ayam geprek siap untuk disajikan.




Demikianlah cara membuat ayam geprek sambal matah (cetar pedas) yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
