---
description: "Langkah membuat Ayam Rica Kemangi Homemade"
title: "Langkah membuat Ayam Rica Kemangi Homemade"
slug: 226-langkah-membuat-ayam-rica-kemangi-homemade
date: 2021-01-21T18:37:26.164Z
image: https://img-global.cpcdn.com/recipes/7de92ab039fcae18/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7de92ab039fcae18/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7de92ab039fcae18/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Justin Sandoval
ratingvalue: 4.3
reviewcount: 30715
recipeingredient:
- "1 ekor Ayam potong 10 bagian"
- "2 genggam Daun Kemangi"
- " Bumbu dihaluskan "
- "8 siung Bawang merah"
- "3 siung Bawang putih"
- "14 buah Cabe merah keriting"
- "3 butir Kemiri sangrai"
- " Bumbu Ungkep "
- "2 batang Sereh geprek"
- "2 ruas jari Jahe ulek kasar"
- "3 ruas jari Kunyit ulek kasar"
- "1 buah Tomat ulek kasar"
- "3 siung Bawang merah"
- "3 siung Bawang putih"
- "3 lembar Daun salam"
- "3 lembar Daun jeruk"
- "Secukupnya Gula garam lada dan penyedap rasa"
- "Segelas Air"
recipeinstructions:
- "Siapkan semua bahan beserta bumbu halus dan bumbu ungkep nya."
- "Tumis bumbu ungkep hingga harum. Masukkan ayam. Aduk hingga bumbu rata di ayamnya. Baru masukkan air. Beri gula, garam, lada dan penyedap rasa. Cicipi rasa. Masak hingga airnya surut dan bumbu meresap."
- "Tumis bumbu yang di haluskan hingga harum. Masukkan ke dalam ayam yang sudah di ungkep beserta daun kemanginya. Masak hingga semua tercampur rata dan mengental bumbunya."
- "Ketika sudah terlihat mengental semua. Matikan apinya dan sajikan hangat 😍"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 167 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/7de92ab039fcae18/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica kemangi yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan keistimewahan yang merupakan keragaman Indonesia



Keharmonisan keluarga dapat didapat dengan cara mudah. Salah satunya adalah memasak Ayam Rica Kemangi untuk keluarga. Momen makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang bisa anda contoh salah satunya ayam rica kemangi yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Dibutuhkan 1 ekor Ayam potong 10 bagian
1. Harap siapkan 2 genggam Daun Kemangi
1. Dibutuhkan  Bumbu dihaluskan :
1. Jangan lupa 8 siung Bawang merah
1. Tambah 3 siung Bawang putih
1. Siapkan 14 buah Cabe merah keriting
1. Siapkan 3 butir Kemiri, sangrai
1. Harus ada  Bumbu Ungkep :
1. Diperlukan 2 batang Sereh, geprek
1. Dibutuhkan 2 ruas jari Jahe, ulek kasar
1. Diperlukan 3 ruas jari Kunyit, ulek kasar
1. Siapkan 1 buah Tomat, ulek kasar
1. Siapkan 3 siung Bawang merah
1. Dibutuhkan 3 siung Bawang putih
1. Harus ada 3 lembar Daun salam
1. Jangan lupa 3 lembar Daun jeruk
1. Dibutuhkan Secukupnya Gula, garam, lada dan penyedap rasa
1. Tambah Segelas Air




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Kemangi:

1. Siapkan semua bahan beserta bumbu halus dan bumbu ungkep nya.
1. Tumis bumbu ungkep hingga harum. Masukkan ayam. Aduk hingga bumbu rata di ayamnya. Baru masukkan air. Beri gula, garam, lada dan penyedap rasa. Cicipi rasa. Masak hingga airnya surut dan bumbu meresap.
1. Tumis bumbu yang di haluskan hingga harum. Masukkan ke dalam ayam yang sudah di ungkep beserta daun kemanginya. Masak hingga semua tercampur rata dan mengental bumbunya.
1. Ketika sudah terlihat mengental semua. Matikan apinya dan sajikan hangat 😍




Demikianlah cara membuat ayam rica kemangi yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan teruji, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
