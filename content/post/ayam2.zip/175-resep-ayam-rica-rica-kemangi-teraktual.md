---
description: "Resep : Ayam rica-rica kemangi teraktual"
title: "Resep : Ayam rica-rica kemangi teraktual"
slug: 175-resep-ayam-rica-rica-kemangi-teraktual
date: 2020-09-07T16:51:10.390Z
image: https://img-global.cpcdn.com/recipes/236fcd038fbb6a4c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/236fcd038fbb6a4c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/236fcd038fbb6a4c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Jesus Rodgers
ratingvalue: 4.2
reviewcount: 18023
recipeingredient:
- "1/2 ekor ayam"
- "3 ikat daun kemangi"
- "2 lembar daun salam 1 lembar umenumis 1 lemar u di ungkep"
- "5 lemar daun jeruk 3 umenumis 2 u di ungkep"
- "2 batang sereh geprek 1 umenumis 1 udi ungkep"
- "1 buah kunyit"
- "1 buah jahe"
- " BUMBU HALUS "
- "20 buah cabai jablay"
- "10 siung bawang putih"
- "3 siung bawang putih"
- "3 buah kemiri"
- "Sedikit kencur"
- "1 buah tomat"
- " Penyedap rasa garam gula micin kaldu ayam"
recipeinstructions:
- "Ungkep ayam kurang lebih 20menit sampai ayam empuk"
- "Lalu goreng ayam stengah matang"
- "Tumis semua bumbu halus sampai wangi masukan daun jeruk, daun salam, sereh dan tomat tambahkan sedikit air sisa rebusan tadi"
- "Lalu masukan ayam aduk-aduk tambahkan penyedap rasa (garam, gula, micin, kaldu ayam)"
- "Masak ayam sampai air nya menyusut lalu terakhir masukan kemangi"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 182 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/236fcd038fbb6a4c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau empuk. Ciri khas makanan Indonesia ayam rica-rica kemangi yang penuh dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah memasak Ayam rica-rica kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang bisa anda contoh salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica kemangi:

1. Harus ada 1/2 ekor ayam
1. Tambah 3 ikat daun kemangi
1. Tambah 2 lembar daun salam (1 lembar u/menumis, 1 lemar u/ di ungkep
1. Siapkan 5 lemar daun jeruk (3 u/menumis, 2 u/ di ungkep)
1. Tambah 2 batang sereh geprek (1 u/menumis, 1 u/di ungkep)
1. Harap siapkan 1 buah kunyit
1. Tambah 1 buah jahe
1. Diperlukan  BUMBU HALUS :
1. Siapkan 20 buah cabai jablay
1. Tambah 10 siung bawang putih
1. Jangan lupa 3 siung bawang putih
1. Harus ada 3 buah kemiri
1. Jangan lupa Sedikit kencur
1. Diperlukan 1 buah tomat
1. Harap siapkan  Penyedap rasa (garam, gula, micin, kaldu ayam)


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica-rica kemangi:

1. Ungkep ayam kurang lebih 20menit sampai ayam empuk
1. Lalu goreng ayam stengah matang
1. Tumis semua bumbu halus sampai wangi masukan daun jeruk, daun salam, sereh dan tomat tambahkan sedikit air sisa rebusan tadi
1. Lalu masukan ayam aduk-aduk tambahkan penyedap rasa (garam, gula, micin, kaldu ayam)
1. Masak ayam sampai air nya menyusut lalu terakhir masukan kemangi


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan teruji, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
