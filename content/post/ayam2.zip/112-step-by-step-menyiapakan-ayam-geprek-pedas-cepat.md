---
description: "Step-by-Step menyiapakan Ayam Geprek Pedas Cepat"
title: "Step-by-Step menyiapakan Ayam Geprek Pedas Cepat"
slug: 112-step-by-step-menyiapakan-ayam-geprek-pedas-cepat
date: 2020-12-24T20:54:50.704Z
image: https://img-global.cpcdn.com/recipes/3a6f3b582f3a746d/751x532cq70/ayam-geprek-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3a6f3b582f3a746d/751x532cq70/ayam-geprek-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3a6f3b582f3a746d/751x532cq70/ayam-geprek-pedas-foto-resep-utama.jpg
author: Luis Copeland
ratingvalue: 4.8
reviewcount: 11215
recipeingredient:
- "1 potong ayam fillet 100  120gr an"
- " tepung bumbu jadi untuk menggoreng ayam"
- " atau campuran tepung "
- "5 Terigu  2 maizena untk 500gr ayam"
- " Bahan sambal "
- "selera Cabe rawit secukupnya tgnt"
- "2 bawang putih utuh goreng dulu aku goreng bareng pas goreng ayam"
- " garam royco  mecin"
- " minyak goreng"
recipeinstructions:
- "Buat adonan kental untuk celupan ayam dgn mencampur tepung ayam goreng dengan sedikit air. Basahi ayam dgn adonan kental, lalu lumuri kembali dengan tepung kering ayam goreng. (sorry lupa kefoto bagian ini)"
- "Goreng ayam sampai kecoklatan dan matang. sisihkan dulu.. (foto goreng ayam itu bsknya ak bkn lg ayam geprek unt ke2x nya jd ayamnya lbh bny)"
- "Ulek cabai rawit, bawang putih goreng, garam secukupnya, royco / mecin. ulek dan siram dgn 2 sdm minyak bekas goreng ayam. bila mau lbh basah sambalnya bisa di tambah minyaknya lagi. cicipi apakah sudah pas rasa asin dan gurihnya.. kalau pakai royco, kurangin garam karena royco sendiri sdh cukup asin."
- "Masukan ayam goreng tepung ke cobek dan tumbuk2 ayamnya"
- "Aduk ayam dan sambal dengan sendok sampai merata."
- "Sajikan ayam geprek dengan nasi hangat. bisa di tambahkan kemangi bila suka.. kbtlan ak punya pohonnya jd tgal petik saja."
categories:
- Recipe
tags:
- ayam
- geprek
- pedas

katakunci: ayam geprek pedas 
nutrition: 271 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Geprek Pedas](https://img-global.cpcdn.com/recipes/3a6f3b582f3a746d/751x532cq70/ayam-geprek-pedas-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga enak. Ciri khas masakan Nusantara ayam geprek pedas yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga dapat didapat dengan cara simple. Salah satunya adalah memasak Ayam Geprek Pedas untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang dapat anda buat salah satunya ayam geprek pedas yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep ayam geprek pedas tanpa harus bersusah payah.
Seperti resep Ayam Geprek Pedas yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 9 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Pedas:

1. Diperlukan 1 potong ayam fillet (100 - 120gr an)
1. Jangan lupa  tepung bumbu jadi untuk menggoreng ayam
1. Harap siapkan  atau campuran tepung :
1. Tambah 5 Terigu : 2 maizena (untk 500gr ayam)
1. Harus ada  Bahan sambal :
1. Tambah selera Cabe rawit secukupnya, tgnt
1. Harap siapkan 2 bawang putih utuh goreng dulu, (aku goreng bareng pas goreng ayam)
1. Diperlukan  garam, royco / mecin
1. Tambah  minyak goreng




<!--inarticleads2-->

##### Cara membuat  Ayam Geprek Pedas:

1. Buat adonan kental untuk celupan ayam dgn mencampur tepung ayam goreng dengan sedikit air. Basahi ayam dgn adonan kental, lalu lumuri kembali dengan tepung kering ayam goreng. (sorry lupa kefoto bagian ini)
1. Goreng ayam sampai kecoklatan dan matang. sisihkan dulu.. (foto goreng ayam itu bsknya ak bkn lg ayam geprek unt ke2x nya jd ayamnya lbh bny)
1. Ulek cabai rawit, bawang putih goreng, garam secukupnya, royco / mecin. ulek dan siram dgn 2 sdm minyak bekas goreng ayam. bila mau lbh basah sambalnya bisa di tambah minyaknya lagi. cicipi apakah sudah pas rasa asin dan gurihnya.. kalau pakai royco, kurangin garam karena royco sendiri sdh cukup asin.
1. Masukan ayam goreng tepung ke cobek dan tumbuk2 ayamnya
1. Aduk ayam dan sambal dengan sendok sampai merata.
1. Sajikan ayam geprek dengan nasi hangat. bisa di tambahkan kemangi bila suka.. kbtlan ak punya pohonnya jd tgal petik saja.




Demikianlah cara membuat ayam geprek pedas yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
