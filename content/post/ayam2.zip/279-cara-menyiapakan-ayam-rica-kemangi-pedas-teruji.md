---
description: "Cara menyiapakan Ayam Rica Kemangi Pedas Teruji"
title: "Cara menyiapakan Ayam Rica Kemangi Pedas Teruji"
slug: 279-cara-menyiapakan-ayam-rica-kemangi-pedas-teruji
date: 2020-09-19T02:45:14.864Z
image: https://img-global.cpcdn.com/recipes/a56ca852cc80f161/751x532cq70/ayam-rica-kemangi-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a56ca852cc80f161/751x532cq70/ayam-rica-kemangi-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a56ca852cc80f161/751x532cq70/ayam-rica-kemangi-pedas-foto-resep-utama.jpg
author: Marian Sandoval
ratingvalue: 4.2
reviewcount: 34766
recipeingredient:
- "1/2 kg ayam dipotong kecil kecil"
- "1 ikat kemangi"
- "1 ruas jahe digeprek"
- "3 daun salam"
- " 5 daun jeruk"
- "1 batang serai digeprek"
- "1 buah jeruk nipis"
- "2 sendok teh gula pasir"
- "secukupnya garam"
- "secukupnya kaldu rebusan ayam"
- "1 sendok makan margarin"
- "250 ml air"
- " Bumbu bumbu yang dihaluskan"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "4 butir kemiri"
- "5 cabe rawit orange"
- "10 cabe merah secukupnya"
- "2 ruas kunyit yang sudah dibakar"
- "sedikit garam"
recipeinstructions:
- "Cuci bersih ayam yg sudah dipotong kecil kecil, kemudian rendam dengan perasan jeruk nipis (20 menit) lalu rebus ayam selama 20 menit"
- "Tumis bumbu yang sudah dihaluskan dengan minyak dan mentega"
- "Masukkan serai yang sudah digeprek, daun salam, daun jeruk dan jahe kemudian tumis sampai harum"
- "Masukkan ayam dan campur dengan bumbu tumisan, lalu beri air kaldu rebusan ayam sedikit, dan beri air."
- "Kemudian setelah baunya sudah harum, masukkan kemangi yang sudah diambil daunnya saja lalu campur, koreksi rasa dengan tambahkan gula dan garam, tunggu sampai matang"
- "Setelah itu sajikan dengan nasi panas❤️"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 140 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica Kemangi Pedas](https://img-global.cpcdn.com/recipes/a56ca852cc80f161/751x532cq70/ayam-rica-kemangi-pedas-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica kemangi pedas yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa keistimewahan yang merupakan keragaman Nusantara

Kehangatan keluarga bisa didapat dengan cara simple. Diantaranya adalah memasak Ayam Rica Kemangi Pedas untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang dapat anda coba salah satunya ayam rica kemangi pedas yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep ayam rica kemangi pedas tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi Pedas yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 20 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi Pedas:

1. Diperlukan 1/2 kg ayam dipotong kecil kecil
1. Siapkan 1 ikat kemangi
1. Jangan lupa 1 ruas jahe digeprek
1. Jangan lupa 3 daun salam
1. Dibutuhkan  5 daun jeruk
1. Tambah 1 batang serai digeprek
1. Dibutuhkan 1 buah jeruk nipis
1. Siapkan 2 sendok teh gula pasir
1. Jangan lupa secukupnya garam
1. Diperlukan secukupnya kaldu rebusan ayam
1. Jangan lupa 1 sendok makan margarin
1. Dibutuhkan 250 ml air
1. Dibutuhkan  Bumbu bumbu yang dihaluskan
1. Siapkan 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Dibutuhkan 4 butir kemiri
1. Siapkan 5 cabe rawit orange
1. Dibutuhkan 10 cabe merah (secukupnya)
1. Dibutuhkan 2 ruas kunyit yang sudah dibakar
1. Siapkan sedikit garam




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Kemangi Pedas:

1. Cuci bersih ayam yg sudah dipotong kecil kecil, kemudian rendam dengan perasan jeruk nipis (20 menit) lalu rebus ayam selama 20 menit
1. Tumis bumbu yang sudah dihaluskan dengan minyak dan mentega
1. Masukkan serai yang sudah digeprek, daun salam, daun jeruk dan jahe kemudian tumis sampai harum
1. Masukkan ayam dan campur dengan bumbu tumisan, lalu beri air kaldu rebusan ayam sedikit, dan beri air.
1. Kemudian setelah baunya sudah harum, masukkan kemangi yang sudah diambil daunnya saja lalu campur, koreksi rasa dengan tambahkan gula dan garam, tunggu sampai matang
1. Setelah itu sajikan dengan nasi panas❤️




Demikianlah cara membuat ayam rica kemangi pedas yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
