---
description: "Bagaimana untuk menyiapakan Ayam Rica Rica Daun Kemangi minggu ini"
title: "Bagaimana untuk menyiapakan Ayam Rica Rica Daun Kemangi minggu ini"
slug: 393-bagaimana-untuk-menyiapakan-ayam-rica-rica-daun-kemangi-minggu-ini
date: 2020-12-23T14:14:37.768Z
image: https://img-global.cpcdn.com/recipes/a38a3dc2b3750da3/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a38a3dc2b3750da3/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a38a3dc2b3750da3/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Aaron Mullins
ratingvalue: 4.8
reviewcount: 23314
recipeingredient:
- "1 kg ayam"
- "3 Ikat kemangi"
- " Bumbu Halus"
- "4 siung bawang merah"
- "3 Siung bawang putih"
- "15 btg cabe rawit merah saya pakai cabe setan biar lebih pedas"
- "1 ruas kunyit"
- "1 ruas jahe"
- "1 Buah tomat"
- "2 Buah kemiri"
- "2 Sdt cabe merah giling"
- " Bahan Tambahan"
- "3 Batang daun bawang"
- "2 Batang sereh geprek"
- "3 Lembar daun salam"
- "Secukupnya kecap manis"
- "Secukupnya garam"
- "Secukupnya penyedap rasa"
- "Secukupnya minyak goreng untuk menumis"
recipeinstructions:
- "Cuci bersih ayam lalu rebus. Giling semua bumbu halus"
- "Tumis bumbu halus hingga harum. Lalu masukkan sereh, daun salam dan kemangi. Beri kecap manis secukupnya, garam dan penyedap rasa (jangan lupa koreksi rasa)"
- "Terakhir masukkan ayam yg telah direbus, dengan tambahkan sedikit air. Sekiranya ayam telah meresap dengan bumbu beri taburan daun bawang. Ayam rica rica daun kemangi siap dinikmati!😋"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 249 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT60M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica Rica Daun Kemangi](https://img-global.cpcdn.com/recipes/a38a3dc2b3750da3/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau gurih. Karasteristik makanan Nusantara ayam rica rica daun kemangi yang kaya dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan rumah tangga bisa didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica Rica Daun Kemangi untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang bisa anda coba salah satunya ayam rica rica daun kemangi yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica rica daun kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Daun Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Daun Kemangi:

1. Diperlukan 1 kg ayam
1. Siapkan 3 Ikat kemangi
1. Siapkan  Bumbu Halus
1. Jangan lupa 4 siung bawang merah
1. Jangan lupa 3 Siung bawang putih
1. Siapkan 15 btg cabe rawit merah (saya pakai cabe setan biar lebih pedas)
1. Dibutuhkan 1 ruas kunyit
1. Tambah 1 ruas jahe
1. Dibutuhkan 1 Buah tomat
1. Diperlukan 2 Buah kemiri
1. Harap siapkan 2 Sdt cabe merah giling
1. Harap siapkan  Bahan Tambahan
1. Harap siapkan 3 Batang daun bawang
1. Jangan lupa 2 Batang sereh (geprek)
1. Siapkan 3 Lembar daun salam
1. Dibutuhkan Secukupnya kecap manis
1. Tambah Secukupnya garam
1. Tambah Secukupnya penyedap rasa
1. Dibutuhkan Secukupnya minyak goreng untuk menumis




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica Daun Kemangi:

1. Cuci bersih ayam lalu rebus. Giling semua bumbu halus
1. Tumis bumbu halus hingga harum. Lalu masukkan sereh, daun salam dan kemangi. Beri kecap manis secukupnya, garam dan penyedap rasa (jangan lupa koreksi rasa)
1. Terakhir masukkan ayam yg telah direbus, dengan tambahkan sedikit air. Sekiranya ayam telah meresap dengan bumbu beri taburan daun bawang. Ayam rica rica daun kemangi siap dinikmati!😋




Demikianlah cara membuat ayam rica rica daun kemangi yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan terbukti, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
