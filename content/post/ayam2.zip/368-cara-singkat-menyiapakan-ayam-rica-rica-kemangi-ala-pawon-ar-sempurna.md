---
description: "Cara singkat menyiapakan Ayam Rica-Rica kemangi ala pawon AR Sempurna"
title: "Cara singkat menyiapakan Ayam Rica-Rica kemangi ala pawon AR Sempurna"
slug: 368-cara-singkat-menyiapakan-ayam-rica-rica-kemangi-ala-pawon-ar-sempurna
date: 2020-08-25T01:01:37.739Z
image: https://img-global.cpcdn.com/recipes/3d24fabead2eee16/751x532cq70/ayam-rica-rica-kemangi-ala-pawon-ar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3d24fabead2eee16/751x532cq70/ayam-rica-rica-kemangi-ala-pawon-ar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3d24fabead2eee16/751x532cq70/ayam-rica-rica-kemangi-ala-pawon-ar-foto-resep-utama.jpg
author: Vernon Poole
ratingvalue: 4.8
reviewcount: 1841
recipeingredient:
- "500 gr Daging Ayam"
- "8 siung bawang putih"
- "4 siung bawang merah"
- "3 butir kemiri"
- "8 buah cabai merah keriting sesuai selera"
- "8 buah cabai rawit sesuai selera"
- "1 ruas jahe"
- "1 ruas laos"
- "2 lembar daun jeruk sesuai selera"
- "1 batang sereh geprek"
- "3 lembar daun salam"
- " Daun kemangi secukupnya sudah di cuci bersih"
- " Garam"
- " Gula"
- " Kaldu bubukpenyedap rasa"
- " Saos tiram jika ada"
- " Minyak untuk menumis"
recipeinstructions:
- "Rebus ayam yang telah dicuci bersih dengan 1litar air/sampai ayam terendam tambahkan 1sdm garam, 2 lembar daun salam dan 2 siung bawang putih geprek dan 1 ruas jahe geprek rebus kurang lebih 20menit setelah itu tiriskan"
- "Goreng ayam kurang lebih 5 menit agar ayam tidak terlalu kering lalu sisihkan."
- "Haluskan 6 siung bawang putih, bawang merah, cabai merah, cabai rawit, dan laos."
- "Panaskan minyak dengan 4sdm minyak goreng lalu tumis bumbu halus tadi sampai harum jangan lupa tambahkan daun salam, sereh dan daun jeruk yang telah di sobek. Setelah harum tambahkan air rebusan ayam tadi (agar lebih gurih) atau bisa tambahkan air secukupnya disertai 1sdm saos tiram, 1/2 sdt garam, 1/2 sdt kaldu bubuk/penyedap rasa, dan 1sdm gula aduk dan diamkan sampai mendidih lalu test rasa."
- "Setelah itu masukkan ayam yang telah di goreng disertai daun kemangi yg telah dipetik dan dicuci bersih tadi kedalam wajan berisi bumbu aduk lalu diamkan sampai air sedikit menyusut dan meresap pada daging ayamnya."
- "Setelah air sudah menyusut dan bumbu telah meresap angkat dan sajikan. Selamat mencoba 🥰"
- "Moms juga bisa menambahkan telur puyuh atau tahu pada resep ini. Mohon maaf bila ada kekeliriuan atau kata2 yang sulit dimengerti.. happy cooking 👩‍🍳"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 213 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica-Rica kemangi ala pawon AR](https://img-global.cpcdn.com/recipes/3d24fabead2eee16/751x532cq70/ayam-rica-rica-kemangi-ala-pawon-ar-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica-rica kemangi ala pawon ar yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Nusantara



Keharmonisan keluarga dapat diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam Rica-Rica kemangi ala pawon AR untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda buat salah satunya ayam rica-rica kemangi ala pawon ar yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep ayam rica-rica kemangi ala pawon ar tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica kemangi ala pawon AR yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica kemangi ala pawon AR:

1. Dibutuhkan 500 gr Daging Ayam
1. Harus ada 8 siung bawang putih
1. Harus ada 4 siung bawang merah
1. Diperlukan 3 butir kemiri
1. Diperlukan 8 buah cabai merah keriting (sesuai selera)
1. Tambah 8 buah cabai rawit (sesuai selera)
1. Tambah 1 ruas jahe
1. Harap siapkan 1 ruas laos
1. Harap siapkan 2 lembar daun jeruk (sesuai selera)
1. Diperlukan 1 batang sereh geprek
1. Diperlukan 3 lembar daun salam
1. Harus ada  Daun kemangi secukupnya (sudah di cuci bersih)
1. Harap siapkan  Garam
1. Tambah  Gula
1. Harap siapkan  Kaldu bubuk/penyedap rasa
1. Jangan lupa  Saos tiram (jika ada)
1. Harus ada  Minyak untuk menumis




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-Rica kemangi ala pawon AR:

1. Rebus ayam yang telah dicuci bersih dengan 1litar air/sampai ayam terendam tambahkan 1sdm garam, 2 lembar daun salam dan 2 siung bawang putih geprek dan 1 ruas jahe geprek rebus kurang lebih 20menit setelah itu tiriskan
1. Goreng ayam kurang lebih 5 menit agar ayam tidak terlalu kering lalu sisihkan.
1. Haluskan 6 siung bawang putih, bawang merah, cabai merah, cabai rawit, dan laos.
1. Panaskan minyak dengan 4sdm minyak goreng lalu tumis bumbu halus tadi sampai harum jangan lupa tambahkan daun salam, sereh dan daun jeruk yang telah di sobek. Setelah harum tambahkan air rebusan ayam tadi (agar lebih gurih) atau bisa tambahkan air secukupnya disertai 1sdm saos tiram, 1/2 sdt garam, 1/2 sdt kaldu bubuk/penyedap rasa, dan 1sdm gula aduk dan diamkan sampai mendidih lalu test rasa.
1. Setelah itu masukkan ayam yang telah di goreng disertai daun kemangi yg telah dipetik dan dicuci bersih tadi kedalam wajan berisi bumbu aduk lalu diamkan sampai air sedikit menyusut dan meresap pada daging ayamnya.
1. Setelah air sudah menyusut dan bumbu telah meresap angkat dan sajikan. Selamat mencoba 🥰
1. Moms juga bisa menambahkan telur puyuh atau tahu pada resep ini. Mohon maaf bila ada kekeliriuan atau kata2 yang sulit dimengerti.. happy cooking 👩‍🍳




Demikianlah cara membuat ayam rica-rica kemangi ala pawon ar yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat simple dan teruji, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
