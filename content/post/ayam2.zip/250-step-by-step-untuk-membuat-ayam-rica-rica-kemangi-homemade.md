---
description: "Step-by-Step untuk membuat Ayam rica rica kemangi Homemade"
title: "Step-by-Step untuk membuat Ayam rica rica kemangi Homemade"
slug: 250-step-by-step-untuk-membuat-ayam-rica-rica-kemangi-homemade
date: 2020-08-27T11:02:19.854Z
image: https://img-global.cpcdn.com/recipes/4cafa99bfed78e5e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4cafa99bfed78e5e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4cafa99bfed78e5e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Antonio Ford
ratingvalue: 5
reviewcount: 13700
recipeingredient:
- "250 gram ayam"
- "3 tangkai kemangi"
- "1 btg seraimemarkan"
- "3 lbr daun jeruk"
- "1 bj cabe merahiris serong skip"
- "1 bh jeruk nipis"
- "Secukupnya garamgula pasir dan kaldu jamur"
- " Bumbu halus "
- "5 butir bawang merah"
- "4 siung bawang putih"
- "1/4 ruas kunyit tambahan ku"
- "1 ruas jari lengkuas tambahan ku"
- "2 butir kemiri tambahan ku"
- "7 bj cabe merah me 5 bj"
- "7 bj cabe rawit tambahan ku"
- "1 buah tomat"
recipeinstructions:
- "Cuci bersih ayam,lumuri jeruk diamkan 20 menit,cuci bersih lagi lalu goreng tapi jangan terlalu kering."
- "Tumis bumbu halus,daun jeruk dan serai sampai bau langu hilang dan matang,tambahkan garam,gula pasir dan kaldu jamur.Lalu masuk kan ayam,tambahkan air sedikit saja aduk merata.Biarkan sampai bumbu meresap."
- "Setelah itu masuk kan daun bawang,daun kemangi aduk sampai merata.Cek rasa,angkat dan sajikan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 300 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT30M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/4cafa99bfed78e5e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas dan empuk. Ciri khas makanan Nusantara ayam rica rica kemangi yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kedekatan rumah tangga dapat ditemukan dengan cara mudah. Salah satunya adalah memasak Ayam rica rica kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang bisa anda buat salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 16 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi:

1. Harus ada 250 gram ayam
1. Tambah 3 tangkai kemangi
1. Tambah 1 btg serai,memarkan
1. Jangan lupa 3 lbr daun jeruk
1. Diperlukan 1 bj cabe merah,iris serong (skip)
1. Dibutuhkan 1 bh jeruk nipis
1. Jangan lupa Secukupnya garam,gula pasir dan kaldu jamur
1. Tambah  Bumbu halus :
1. Siapkan 5 butir bawang merah
1. Siapkan 4 siung bawang putih
1. Tambah 1/4 ruas kunyit (tambahan ku)
1. Harap siapkan 1 ruas jari lengkuas (tambahan ku)
1. Harap siapkan 2 butir kemiri (tambahan ku)
1. Harap siapkan 7 bj cabe merah (me 5 bj)
1. Harap siapkan 7 bj cabe rawit (tambahan ku)
1. Dibutuhkan 1 buah tomat


Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica kemangi:

1. Cuci bersih ayam,lumuri jeruk diamkan 20 menit,cuci bersih lagi lalu goreng tapi jangan terlalu kering.
1. Tumis bumbu halus,daun jeruk dan serai sampai bau langu hilang dan matang,tambahkan garam,gula pasir dan kaldu jamur.Lalu masuk kan ayam,tambahkan air sedikit saja aduk merata.Biarkan sampai bumbu meresap.
1. Setelah itu masuk kan daun bawang,daun kemangi aduk sampai merata.Cek rasa,angkat dan sajikan.


Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Siapa yang tidak mengenal lalapan daun kemangi di Indonesia ini. Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. 

Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat simple dan cepat, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
