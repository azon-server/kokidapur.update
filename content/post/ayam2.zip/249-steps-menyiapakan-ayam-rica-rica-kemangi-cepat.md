---
description: "Steps menyiapakan Ayam Rica-Rica Kemangi Cepat"
title: "Steps menyiapakan Ayam Rica-Rica Kemangi Cepat"
slug: 249-steps-menyiapakan-ayam-rica-rica-kemangi-cepat
date: 2020-09-05T20:28:38.203Z
image: https://img-global.cpcdn.com/recipes/8897ce72020b441a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8897ce72020b441a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8897ce72020b441a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Bobby Taylor
ratingvalue: 5
reviewcount: 25205
recipeingredient:
- "1 ekor ayam dipotong"
- "1 ikat kemangi"
- "3 buah sereh digeprek"
- "6 lembar daun jeruk diirisiris"
- "5 lembar daun salam"
- "Secukupnya garam gula penyedap"
- "1 batang daun bawang potong potong"
- "1 lembar daun pandan simpul opsional"
- " Bumbu halus"
- "1 ons cabe merah keriting"
- "1/2 ons cabe merah rawit"
- "6 siung bawang merah"
- "5 siung bawang putih"
- "3 butir kemiri"
- "2 cm jahe"
- "2 cm lengkuas"
- "1 cm kunyit"
- " Bumbu marinasi"
- "1/2 bungkus kunyit bubuk merk desaku"
- "1 buah jeruk nipis"
- "1 sdt garam"
recipeinstructions:
- "Marinasi ayam dengan bumbu marinasi. Diamkan selama kurang lebih 15 menit."
- "Panaskan minyak lalu goreng ayam hingga sedikit kering. Ini opsional ya. Boleh langsung rebus tp kalo saya sih ga suka kalo bagian sayap agak benyek."
- "Uleg bumbu halus lalu panaskan minyak dan tumis bumbu halus hingga harum. Tambahkan daun jeruk, daun salam dan sereh. Tumis hingga harum"
- "Masukkan ayam. Aduk hingga merata lalu tambahkan air. Boleh banyak boleh dikit. Kalo saya sih 500 mL. Masukkan daun pandan. Tambahkan garam, gula dan penyedap. Aduk"
- "Masak ayam hingga empuk dan kuah sedikit menyusut. Lalu masukkan daun kemangi dan daun bawang. Masak hingga daun kemangi dan daun bawang layu."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 106 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/8897ce72020b441a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga empuk. Ciri masakan Indonesia ayam rica-rica kemangi yang penuh dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica-Rica Kemangi untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang bisa anda buat salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Kemangi:

1. Siapkan 1 ekor ayam dipotong
1. Siapkan 1 ikat kemangi
1. Diperlukan 3 buah sereh digeprek
1. Siapkan 6 lembar daun jeruk diiris-iris
1. Harus ada 5 lembar daun salam
1. Tambah Secukupnya garam, gula, penyedap
1. Jangan lupa 1 batang daun bawang potong potong
1. Tambah 1 lembar daun pandan, simpul (opsional)
1. Harap siapkan  Bumbu halus:
1. Siapkan 1 ons cabe merah keriting
1. Harap siapkan 1/2 ons cabe merah rawit
1. Jangan lupa 6 siung bawang merah
1. Tambah 5 siung bawang putih
1. Diperlukan 3 butir kemiri
1. Siapkan 2 cm jahe
1. Tambah 2 cm lengkuas
1. Tambah 1 cm kunyit
1. Dibutuhkan  Bumbu marinasi:
1. Siapkan 1/2 bungkus kunyit bubuk merk desaku
1. Siapkan 1 buah jeruk nipis
1. Diperlukan 1 sdt garam




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-Rica Kemangi:

1. Marinasi ayam dengan bumbu marinasi. Diamkan selama kurang lebih 15 menit.
1. Panaskan minyak lalu goreng ayam hingga sedikit kering. Ini opsional ya. Boleh langsung rebus tp kalo saya sih ga suka kalo bagian sayap agak benyek.
1. Uleg bumbu halus lalu panaskan minyak dan tumis bumbu halus hingga harum. Tambahkan daun jeruk, daun salam dan sereh. Tumis hingga harum
1. Masukkan ayam. Aduk hingga merata lalu tambahkan air. Boleh banyak boleh dikit. Kalo saya sih 500 mL. Masukkan daun pandan. Tambahkan garam, gula dan penyedap. Aduk
1. Masak ayam hingga empuk dan kuah sedikit menyusut. Lalu masukkan daun kemangi dan daun bawang. Masak hingga daun kemangi dan daun bawang layu.




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan cepat, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
