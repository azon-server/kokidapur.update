---
description: "Langkah untuk membuat Ayam Rica Kemangi teraktual"
title: "Langkah untuk membuat Ayam Rica Kemangi teraktual"
slug: 361-langkah-untuk-membuat-ayam-rica-kemangi-teraktual
date: 2021-01-16T08:24:34.408Z
image: https://img-global.cpcdn.com/recipes/d88aebbf03920e80/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d88aebbf03920e80/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d88aebbf03920e80/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: John Fisher
ratingvalue: 4
reviewcount: 24166
recipeingredient:
- " Ayam 1 ekor pot 12"
- "2 ikat kecil Daun kemangi"
- "1 Serai besar"
- " Lengkuas 3cm bersihkan dan memarkan"
- "6 lembar Daun jeruk"
- "3 lbr Daun salam"
- " Daun bawang iris serong optional"
- "secukupnya Kaldu jamur"
- "secukupnya Garam"
- " Minyak untuk tumis"
- " Bumbu halus"
- "5 Bawang putih"
- "8 Bawang merah"
- "15 bh Cabe merah kisaran"
- " Cabe rawit 10 bhoptional boleh banyak boleh dikit"
- "3 cm Jahe"
- "3 cm Kunyit"
- "4 bh Kemiri"
- "1/2 sdt Merica"
- "1/2 sdt Ketumbar bubuk"
recipeinstructions:
- "Cuci bersih ayam,lumuri air perasan jeruk nipis"
- "Blender bumbu halus"
- "Panaskan minyak sedikit kisaran 5 sdm di kuali lalu tumis bumbu halus,masukkan serai,daun salam,daun jeruk,lengkuas,tumis hingga harum dan matang,masukkan garam dan kaldu jamur."
- "Lalu masukkan ayam,aduk sebentar tambahkan air lalu tutup,tunggu hingga ayam matang"
- "Jika sudah keliatan matang,aduk hingga air menyusut lalu masukkan kemangi,aduk dan coba rasa jika sudah pas angkat ayam dan sajikan"
- ""
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 196 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/d88aebbf03920e80/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas dan empuk. Ciri khas makanan Indonesia ayam rica kemangi yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga dapat diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam Rica Kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang dapat anda coba salah satunya ayam rica kemangi yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Tambah  Ayam 1 ekor pot 12
1. Siapkan 2 ikat kecil Daun kemangi
1. Jangan lupa 1 Serai besar
1. Diperlukan  Lengkuas 3cm bersihkan dan memarkan
1. Jangan lupa 6 lembar Daun jeruk
1. Tambah 3 lbr Daun salam
1. Dibutuhkan  Daun bawang iris serong (optional)
1. Tambah secukupnya Kaldu jamur
1. Harap siapkan secukupnya Garam
1. Siapkan  Minyak untuk tumis
1. Harap siapkan  Bumbu halus
1. Diperlukan 5 Bawang putih
1. Tambah 8 Bawang merah
1. Diperlukan 15 bh Cabe merah kisaran
1. Diperlukan  Cabe rawit 10 bh(optional boleh banyak boleh dikit)
1. Jangan lupa 3 cm Jahe
1. Diperlukan 3 cm Kunyit
1. Diperlukan 4 bh Kemiri
1. Siapkan 1/2 sdt Merica
1. Harap siapkan 1/2 sdt Ketumbar bubuk




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Kemangi:

1. Cuci bersih ayam,lumuri air perasan jeruk nipis
1. Blender bumbu halus
1. Panaskan minyak sedikit kisaran 5 sdm di kuali lalu tumis bumbu halus,masukkan serai,daun salam,daun jeruk,lengkuas,tumis hingga harum dan matang,masukkan garam dan kaldu jamur.
1. Lalu masukkan ayam,aduk sebentar tambahkan air lalu tutup,tunggu hingga ayam matang
1. Jika sudah keliatan matang,aduk hingga air menyusut lalu masukkan kemangi,aduk dan coba rasa jika sudah pas angkat ayam dan sajikan
1. 




Demikianlah cara membuat ayam rica kemangi yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat simple dan teruji, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
