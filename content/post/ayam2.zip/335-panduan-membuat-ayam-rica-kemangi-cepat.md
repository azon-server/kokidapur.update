---
description: "Panduan membuat Ayam rica kemangi Cepat"
title: "Panduan membuat Ayam rica kemangi Cepat"
slug: 335-panduan-membuat-ayam-rica-kemangi-cepat
date: 2020-10-24T02:40:32.667Z
image: https://img-global.cpcdn.com/recipes/74c0bdb19185a857/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/74c0bdb19185a857/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/74c0bdb19185a857/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Zachary Poole
ratingvalue: 4.8
reviewcount: 31474
recipeingredient:
- "6 potong Ayam"
- " Jeruk nipis"
- "3 siung bawang putih geprek"
- "1 ruas jahe geprek"
- "1 ikat kemangi"
- "secukupnya Kunyit bubuk"
- " Garam"
- " Minyak goreng"
- " Bumbu blender tumis"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "2 buah kemiri"
- "10-12 cabe keriting"
- "9 cabe rawit"
- " Bumbu tambahan geprek"
- "3 lembar daun jeruk"
- "1 lembar daun salam"
- "1 batang sereh"
- "2 ruas jahe"
- "1 ruas lengkuas"
recipeinstructions:
- "Cuci ayam, peras jeruk nipis diamkan sesaat lalu bilas kembali. Rebus / ungkep sebentar ayam, bawang putih dan jahe. Tiriskan lalu goreng sebentar"
- "Siapkan semua bahan"
- "Ulek/blender bumbu lalu tumis ditambahkan bubuk kunyit, sereh, jahe, lengkuas, daun jeruk dan daun salam hingga harum"
- "Lalu masukkan ayam yang sudah di goreng sebentar tadi, tambahkan air dan garam, air sisa sedikit masukkan kemangi, aduk hingga tercampur rata, koreksi rasa"
- "Selesai."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 291 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/74c0bdb19185a857/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica kemangi yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Kita



Kedekatan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam rica kemangi untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang bisa anda praktekkan salah satunya ayam rica kemangi yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 20 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi:

1. Diperlukan 6 potong Ayam
1. Harus ada  Jeruk nipis
1. Dibutuhkan 3 siung bawang putih geprek
1. Jangan lupa 1 ruas jahe geprek
1. Dibutuhkan 1 ikat kemangi
1. Dibutuhkan secukupnya Kunyit bubuk
1. Dibutuhkan  Garam
1. Harap siapkan  Minyak goreng
1. Siapkan  Bumbu blender tumis
1. Siapkan 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Diperlukan 2 buah kemiri
1. Diperlukan 10-12 cabe keriting
1. Diperlukan 9 cabe rawit
1. Harap siapkan  Bumbu tambahan geprek
1. Jangan lupa 3 lembar daun jeruk
1. Dibutuhkan 1 lembar daun salam
1. Jangan lupa 1 batang sereh
1. Siapkan 2 ruas jahe
1. Siapkan 1 ruas lengkuas




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica kemangi:

1. Cuci ayam, peras jeruk nipis diamkan sesaat lalu bilas kembali. Rebus / ungkep sebentar ayam, bawang putih dan jahe. Tiriskan lalu goreng sebentar
1. Siapkan semua bahan
1. Ulek/blender bumbu lalu tumis ditambahkan bubuk kunyit, sereh, jahe, lengkuas, daun jeruk dan daun salam hingga harum
1. Lalu masukkan ayam yang sudah di goreng sebentar tadi, tambahkan air dan garam, air sisa sedikit masukkan kemangi, aduk hingga tercampur rata, koreksi rasa
1. Selesai.




Demikianlah cara membuat ayam rica kemangi yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat mudah dan cepat, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
