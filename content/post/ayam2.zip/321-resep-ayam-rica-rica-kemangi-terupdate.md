---
description: "Resep : Ayam rica-rica kemangi terupdate"
title: "Resep : Ayam rica-rica kemangi terupdate"
slug: 321-resep-ayam-rica-rica-kemangi-terupdate
date: 2020-12-23T12:00:32.592Z
image: https://img-global.cpcdn.com/recipes/d251a5dc93fd4c4b/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d251a5dc93fd4c4b/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d251a5dc93fd4c4b/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Billy Collier
ratingvalue: 4.7
reviewcount: 18030
recipeingredient:
- "4 potong ayam"
- "4 buah cabe rawit setan"
- "Secukupnya daun kemangi"
- "2 gelas air"
- " Bumbu halus "
- "3 butir bawang merah"
- "2 butir bawang putih"
- "1 butir kemiri"
- "Secukupnya lada"
- "1 ruas kunyit"
- " Garam"
recipeinstructions:
- "Tumis bumbu halus hingga harum agak banyak minyak, lalu masukan ayam aduk2"
- "Tunggu ayam hingga matang luarnya lalu masukan 2 gelas air biarkan ayam dimasak hingga matang dan air asat."
- "Setelah itu beri bumbu garam / penyedap. Aduk2 pastikan ayam matang masukan daun kemangi dan cabe rawit merah utuh."
- "Setelah matang angkat dan tiriskan!"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 220 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/d251a5dc93fd4c4b/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica-rica kemangi yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan ciri khas yang merupakan keragaman Indonesia



Kedekatan rumah tangga bisa didapat dengan cara simple. Salah satunya adalah memasak Ayam rica-rica kemangi untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang dapat anda coba salah satunya ayam rica-rica kemangi yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 11 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica kemangi:

1. Dibutuhkan 4 potong ayam
1. Siapkan 4 buah cabe rawit setan
1. Harus ada Secukupnya daun kemangi
1. Diperlukan 2 gelas air
1. Diperlukan  Bumbu halus :
1. Diperlukan 3 butir bawang merah
1. Harap siapkan 2 butir bawang putih
1. Jangan lupa 1 butir kemiri
1. Siapkan Secukupnya lada
1. Diperlukan 1 ruas kunyit
1. Siapkan  Garam




<!--inarticleads2-->

##### Langkah membuat  Ayam rica-rica kemangi:

1. Tumis bumbu halus hingga harum agak banyak minyak, lalu masukan ayam aduk2
1. Tunggu ayam hingga matang luarnya lalu masukan 2 gelas air biarkan ayam dimasak hingga matang dan air asat.
1. Setelah itu beri bumbu garam / penyedap. Aduk2 pastikan ayam matang masukan daun kemangi dan cabe rawit merah utuh.
1. Setelah matang angkat dan tiriskan!




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan terbukti, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
