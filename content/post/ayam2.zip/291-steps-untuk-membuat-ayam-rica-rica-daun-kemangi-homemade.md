---
description: "Steps untuk membuat Ayam Rica-Rica Daun Kemangi Homemade"
title: "Steps untuk membuat Ayam Rica-Rica Daun Kemangi Homemade"
slug: 291-steps-untuk-membuat-ayam-rica-rica-daun-kemangi-homemade
date: 2020-11-28T15:40:57.630Z
image: https://img-global.cpcdn.com/recipes/f6423ab5c426bd5f/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f6423ab5c426bd5f/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f6423ab5c426bd5f/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Alta Sanchez
ratingvalue: 4.9
reviewcount: 5586
recipeingredient:
- " 1 ekor ayam potong 10 baluri kunyit bubuk air jeruk nipis dan"
- " garam secukupnya diamkan 15 menit lalu goreng stgh kering"
- " Bumbu Halus "
- "1 ons cabe keriting"
- "1/2 ons cabe rawit"
- "7 siung bawang merah"
- "5 siung bawang putih"
- "2 cm jahe"
- "2 cm lengkoas"
- "Sedikit kunyit"
- "1 butir kemiri"
- " Bumbu Kasar "
- "2 btg serai geprek"
- "3 lembar daun salam"
- "2 lembar daun jeruk"
- " Daun bawang"
- "2 ikat daun kemangi"
- "secukupnya Garam dan penyedap rasa"
recipeinstructions:
- "Tumis bumbu halus (yg sdh di blender td) sampai wangi masukan daun salam, daun jeruk dan serai."
- "Masukan ayam yg sudah di goreng stgh kering tadi, aduk hingga rata."
- "Masukan air secukupnya, tambahkan garam dan penyedap rasa secukupnya."
- "Masak sampai ayam empuk krg lebih stgh jam dgn api sedang."
- "Setelah ayam empuk dan kuah agak mengering masukan daun kemangi dan daun bawang aduk hingga layu."
- "Ayam rica-rica siap dihidangkan dgm nasi hangat. 😉"
categories:
- Recipe
tags:
- ayam
- ricarica
- daun

katakunci: ayam ricarica daun 
nutrition: 121 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT54M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica-Rica Daun Kemangi](https://img-global.cpcdn.com/recipes/f6423ab5c426bd5f/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica-rica daun kemangi yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa kesan tersendiri yang merupakan keragaman Kita

Kedekatan rumah tangga bisa ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica-Rica Daun Kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang dapat anda coba salah satunya ayam rica-rica daun kemangi yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep ayam rica-rica daun kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Daun Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Daun Kemangi:

1. Harus ada  1 ekor ayam potong 10 (baluri kunyit bubuk, air jeruk nipis, dan
1. Harap siapkan  garam secukupnya) diamkan 15 menit lalu goreng stgh kering
1. Dibutuhkan  Bumbu Halus :
1. Dibutuhkan 1 ons cabe keriting
1. Jangan lupa 1/2 ons cabe rawit
1. Harap siapkan 7 siung bawang merah
1. Tambah 5 siung bawang putih
1. Dibutuhkan 2 cm jahe
1. Jangan lupa 2 cm lengkoas
1. Jangan lupa Sedikit kunyit
1. Siapkan 1 butir kemiri
1. Dibutuhkan  Bumbu Kasar :
1. Siapkan 2 btg serai geprek
1. Diperlukan 3 lembar daun salam
1. Harus ada 2 lembar daun jeruk
1. Harap siapkan  Daun bawang
1. Siapkan 2 ikat daun kemangi
1. Harus ada secukupnya Garam dan penyedap rasa




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-Rica Daun Kemangi:

1. Tumis bumbu halus (yg sdh di blender td) sampai wangi masukan daun salam, daun jeruk dan serai.
1. Masukan ayam yg sudah di goreng stgh kering tadi, aduk hingga rata.
1. Masukan air secukupnya, tambahkan garam dan penyedap rasa secukupnya.
1. Masak sampai ayam empuk krg lebih stgh jam dgn api sedang.
1. Setelah ayam empuk dan kuah agak mengering masukan daun kemangi dan daun bawang aduk hingga layu.
1. Ayam rica-rica siap dihidangkan dgm nasi hangat. 😉




Demikianlah cara membuat ayam rica-rica daun kemangi yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan teruji, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
