---
description: "Cara singkat menyiapakan Ayam Rica-rica Kemangi Luar biasa"
title: "Cara singkat menyiapakan Ayam Rica-rica Kemangi Luar biasa"
slug: 381-cara-singkat-menyiapakan-ayam-rica-rica-kemangi-luar-biasa
date: 2020-09-16T04:02:26.853Z
image: https://img-global.cpcdn.com/recipes/733f9db34e37cc11/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/733f9db34e37cc11/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/733f9db34e37cc11/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Micheal Saunders
ratingvalue: 4.6
reviewcount: 25115
recipeingredient:
- "1/2 ekor ayam"
- "sesuai selera Kemangi"
- "5 biji daun salam"
- "1 biji serai"
- "5 biji daun jeruk"
- " Bumbu halus "
- "4 siung bawang merah"
- "2 siung bawang putih"
- "7 biji cabe rawit"
- "1 ruas kunyit"
- "1 ruas jahe"
- "1 ruas laos"
- "secukupnya Lada bubuk"
- "secukupnya Ketumbar bubuk"
- "secukupnya Garam"
- "secukupnya Gula"
recipeinstructions:
- "Cuci bersih ayam nya, rebus ½mateng, direbusnya tambahkan garam secukupnya,,,setelah ayam sudah ½mateng angkat lalu tiriskan,,"
- "Haluskan bumbu dgn blender, tumis bumbu, lalu masukan salam,daun jeruk, serai, masak hingga harum dn berubah warna, masukan penyedap rasa, icip&#34; rasa lalu masukan ayam yg tadi ditiriskan"
- "Beri sedikit air kedalam masakannya, tunggu sampai bumbu meresap ke ayam nya, setelah dipirkirakan ayam matang, masukan kemangi"
- "Setelah semua selesai, hidangkan ke dalam mangkok/wadah"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 117 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/733f9db34e37cc11/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia



Keharmonisan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam Rica-rica Kemangi untuk keluarga. Momen makan bersama anak sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda coba salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Kemangi:

1. Tambah 1/2 ekor ayam
1. Harus ada sesuai selera Kemangi
1. Dibutuhkan 5 biji daun salam
1. Diperlukan 1 biji serai
1. Siapkan 5 biji daun jeruk
1. Diperlukan  Bumbu halus :
1. Jangan lupa 4 siung bawang merah
1. Jangan lupa 2 siung bawang putih
1. Harap siapkan 7 biji cabe rawit
1. Tambah 1 ruas kunyit
1. Tambah 1 ruas jahe
1. Dibutuhkan 1 ruas laos
1. Diperlukan secukupnya Lada bubuk
1. Harus ada secukupnya Ketumbar bubuk
1. Jangan lupa secukupnya Garam
1. Siapkan secukupnya Gula




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-rica Kemangi:

1. Cuci bersih ayam nya, rebus ½mateng, direbusnya tambahkan garam secukupnya,,,setelah ayam sudah ½mateng angkat lalu tiriskan,,
1. Haluskan bumbu dgn blender, tumis bumbu, lalu masukan salam,daun jeruk, serai, masak hingga harum dn berubah warna, masukan penyedap rasa, icip&#34; rasa lalu masukan ayam yg tadi ditiriskan
1. Beri sedikit air kedalam masakannya, tunggu sampai bumbu meresap ke ayam nya, setelah dipirkirakan ayam matang, masukan kemangi
1. Setelah semua selesai, hidangkan ke dalam mangkok/wadah




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat mudah dan cepat, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
