---
description: "Resep : Ayam Rica Kemangi Sempurna"
title: "Resep : Ayam Rica Kemangi Sempurna"
slug: 288-resep-ayam-rica-kemangi-sempurna
date: 2021-01-29T20:24:56.796Z
image: https://img-global.cpcdn.com/recipes/425d900059b3e9c2/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/425d900059b3e9c2/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/425d900059b3e9c2/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Edna Howard
ratingvalue: 4.6
reviewcount: 49442
recipeingredient:
- "4 paha ayam"
- "1 batang sereh"
- "4 lembar daun jeruk"
- "2 lembar daun salam"
- " Garam gula jawa gula pasir kaldu jamur"
- " Air secukupnya air putih dan air kaldu"
- " Daun kemangi"
- " Bumbu halus"
- "5 siung bawang putih"
- "7 siung bawang merah"
- "8 cabe rawit"
- "3 cabe merah keriting besar"
- "1 ruas kunyit"
- "3/4 ruas jahe"
- "2 butir kemiri"
- "1/2 tomat"
recipeinstructions:
- "Cuci bersih paha, dan rebus kurang lebih 20 menit. Air kaldunya jangan dibuang. Sementara merebus paha, haluskan bumbu halus dan geprek kasar daun salam, sereh, daun jeruk"
- "Cuci bersih kemangi. Panaskan minyak secukupnya lalu tumis bumbu hingga harum"
- "Tambahkan air kaldu ayam dan air putih secukupnya. Lalu masukkan paha ayamnya. Berikan bumbu gula jawa, gula pasir, garam, dan kaldu jamur"
- "Koreksi rasa sesuai selera. Tunggu airnya hingga agak menyusut. Ayam rica siap dihidangkan :)"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 258 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT55M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/425d900059b3e9c2/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica kemangi yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Nusantara



Kedekatan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah memasak Ayam Rica Kemangi untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang dapat anda contoh salah satunya ayam rica kemangi yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 16 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Tambah 4 paha ayam
1. Dibutuhkan 1 batang sereh
1. Dibutuhkan 4 lembar daun jeruk
1. Jangan lupa 2 lembar daun salam
1. Siapkan  Garam, gula jawa, gula pasir, kaldu jamur
1. Harap siapkan  Air secukupnya (air putih dan air kaldu)
1. Dibutuhkan  Daun kemangi
1. Diperlukan  Bumbu halus
1. Harap siapkan 5 siung bawang putih
1. Harus ada 7 siung bawang merah
1. Harap siapkan 8 cabe rawit
1. Tambah 3 cabe merah keriting besar
1. Jangan lupa 1 ruas kunyit
1. Dibutuhkan 3/4 ruas jahe
1. Siapkan 2 butir kemiri
1. Jangan lupa 1/2 tomat




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Kemangi:

1. Cuci bersih paha, dan rebus kurang lebih 20 menit. Air kaldunya jangan dibuang. Sementara merebus paha, haluskan bumbu halus dan geprek kasar daun salam, sereh, daun jeruk
1. Cuci bersih kemangi. Panaskan minyak secukupnya lalu tumis bumbu hingga harum
1. Tambahkan air kaldu ayam dan air putih secukupnya. Lalu masukkan paha ayamnya. Berikan bumbu gula jawa, gula pasir, garam, dan kaldu jamur
1. Koreksi rasa sesuai selera. Tunggu airnya hingga agak menyusut. Ayam rica siap dihidangkan :)




Demikianlah cara membuat ayam rica kemangi yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
