---
description: "Panduan menyiapakan Ayam spicy (richesee ala2) Cepat"
title: "Panduan menyiapakan Ayam spicy (richesee ala2) Cepat"
slug: 447-panduan-menyiapakan-ayam-spicy-richesee-ala2-cepat
date: 2021-01-04T12:24:54.025Z
image: https://img-global.cpcdn.com/recipes/caded039a9b329c3/751x532cq70/ayam-spicy-richesee-ala2-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/caded039a9b329c3/751x532cq70/ayam-spicy-richesee-ala2-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/caded039a9b329c3/751x532cq70/ayam-spicy-richesee-ala2-foto-resep-utama.jpg
author: Craig Greer
ratingvalue: 4.8
reviewcount: 41896
recipeingredient:
- "1/2 kg ayam"
- "1 butir telur ayam"
- "1 sdm saus tiram"
- "1/2 sdt garam"
- " 12 sdt merica bubuk"
- " Tepung bumbu "
- "5 sdm tepung terigu"
- "1 sdm maizena"
- "1/2 sdt garam"
- "1/2 sdt merica bubuk"
- " Bumbu saus "
- "1 sdm margarine"
- "1 sdm saus tiram"
- "2 sdm madu"
- "3 sdm saos tomat"
- "3 sdm saos cabe"
- "2/3 siung bawang putih"
- "6 buah cabe setan  sesuai selera"
- "30 ml air"
recipeinstructions:
- "Campurkan ayam yg sudah di potong2. Dengan telur, saus tiram, garam, merica bubuk. Diamkan minimal 1jam.."
- "Sembari menunggu siapkan bahan tumisan..campurkan madu, saus tiram, saus cabe, saus tomat, dan cabe setan yg sudah dihaluskan"
- "Setelah 1 jam ayam didiamkan. Campurkan tepung terigu, maizena, garam, merica bubuk. Aduk rata.. lalu masukan ayam ke tepung (sambil di cubit2 agar tepung tebal dan keriting setelah di goreng). Lalu goreng ayam sampai matang..."
- "Panaskan margarine, lalu tumis bawang putih yg sudah di geprek, lalu masukan air 30ml dan masukan bahan saus.. aduk rata (jgn terlalu lama agar tidak lengket) lalu masukan ayam gorengg aduk rata.. ayam pedas siap disajikan"
categories:
- Recipe
tags:
- ayam
- spicy
- richesee

katakunci: ayam spicy richesee 
nutrition: 107 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam spicy (richesee ala2)](https://img-global.cpcdn.com/recipes/caded039a9b329c3/751x532cq70/ayam-spicy-richesee-ala2-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan renyah. Ciri khas masakan Indonesia ayam spicy (richesee ala2) yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan rumah tangga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Ayam spicy (richesee ala2) untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda contoh salah satunya ayam spicy (richesee ala2) yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam spicy (richesee ala2) tanpa harus bersusah payah.
Berikut ini resep Ayam spicy (richesee ala2) yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam spicy (richesee ala2):

1. Harap siapkan 1/2 kg ayam
1. Diperlukan 1 butir telur ayam
1. Siapkan 1 sdm saus tiram
1. Harap siapkan 1/2 sdt garam
1. Jangan lupa  1/2 sdt merica bubuk
1. Jangan lupa  Tepung bumbu :
1. Dibutuhkan 5 sdm tepung terigu
1. Jangan lupa 1 sdm maizena
1. Tambah 1/2 sdt garam
1. Harap siapkan 1/2 sdt merica bubuk
1. Tambah  Bumbu saus :
1. Harap siapkan 1 sdm margarine
1. Harap siapkan 1 sdm saus tiram
1. Harus ada 2 sdm madu
1. Siapkan 3 sdm saos tomat
1. Diperlukan 3 sdm saos cabe
1. Siapkan 2/3 siung bawang putih
1. Tambah 6 buah cabe setan / sesuai selera
1. Jangan lupa 30 ml air




<!--inarticleads2-->

##### Cara membuat  Ayam spicy (richesee ala2):

1. Campurkan ayam yg sudah di potong2. Dengan telur, saus tiram, garam, merica bubuk. Diamkan minimal 1jam..
1. Sembari menunggu siapkan bahan tumisan..campurkan madu, saus tiram, saus cabe, saus tomat, dan cabe setan yg sudah dihaluskan
1. Setelah 1 jam ayam didiamkan. Campurkan tepung terigu, maizena, garam, merica bubuk. Aduk rata.. lalu masukan ayam ke tepung (sambil di cubit2 agar tepung tebal dan keriting setelah di goreng). Lalu goreng ayam sampai matang...
1. Panaskan margarine, lalu tumis bawang putih yg sudah di geprek, lalu masukan air 30ml dan masukan bahan saus.. aduk rata (jgn terlalu lama agar tidak lengket) lalu masukan ayam gorengg aduk rata.. ayam pedas siap disajikan




Demikianlah cara membuat ayam spicy (richesee ala2) yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
