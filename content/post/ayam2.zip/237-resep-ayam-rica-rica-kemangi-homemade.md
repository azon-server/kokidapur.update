---
description: "Resep : Ayam Rica Rica Kemangi Homemade"
title: "Resep : Ayam Rica Rica Kemangi Homemade"
slug: 237-resep-ayam-rica-rica-kemangi-homemade
date: 2020-10-09T09:15:49.830Z
image: https://img-global.cpcdn.com/recipes/457277078f4f31b3/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/457277078f4f31b3/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/457277078f4f31b3/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Fannie West
ratingvalue: 4.4
reviewcount: 23511
recipeingredient:
- "1 ekor Ayam kmpg utuh"
- " Bumbu Halus"
- "8 bawang merah"
- "2 bawang putih"
- "10 cabe Rawit"
- "10 Cabe Kriting"
- " Bahan Uleg"
- "2 bh kemiri yg sdh dsangrai"
- "2 ruas kunyit"
- " Bahan geprek"
- "1 ruas laos"
- "1 ruas jahe"
- "2 Bh Daun salam"
- "2 Bh Daun jeruk"
- "1 bh Daun sere"
- "4 sdm minyak goreng utk menumis"
- "1 ikat Daun kemangi"
- "1 sdt gula"
- "1 sdt gram"
- "secukupnya kaldu ayampenyedap rasa"
- "200 ml air"
recipeinstructions:
- "Potong2 ayam dan cuci bersih ayam lalu sisihkan"
- "Blender bumbu halusss diatas lalu sisihkan kemudian uleg bumbu uleg kemiri dan kunyit sisihkan"
- "Siapkan minyak tunggu hingga panas kemudian masukkan bumbu halus dan bahan uleg ke dalam minyak tumis hingga harum lalu masukkan daun salam, serai,jahe, laos kemudian ayam tumis hingga merata"
- "Kemudian tambahkan air kemudian gula, garam dan kaldu cek rasa sesuai selera tunggu hingga mendidih dn air menyusut kemudian matikan api masukkan daun kemangi.ayam rica2 sudah siap dinikmati"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 274 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT36M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/457277078f4f31b3/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang harus kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica rica kemangi yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan ciri khas yang merupakan keragaman Nusantara



Keharmonisan rumah tangga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam Rica Rica Kemangi untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang dapat anda contoh salah satunya ayam rica rica kemangi yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Harus ada 1 ekor Ayam kmpg utuh
1. Dibutuhkan  Bumbu Halus
1. Tambah 8 bawang merah
1. Tambah 2 bawang putih
1. Tambah 10 cabe Rawit
1. Harus ada 10 Cabe Kriting
1. Diperlukan  Bahan Uleg
1. Jangan lupa 2 bh kemiri yg sdh dsangrai
1. Harap siapkan 2 ruas kunyit
1. Tambah  Bahan geprek
1. Tambah 1 ruas laos
1. Tambah 1 ruas jahe
1. Harap siapkan 2 Bh Daun salam
1. Harus ada 2 Bh Daun jeruk
1. Harap siapkan 1 bh Daun sere
1. Harap siapkan 4 sdm minyak goreng utk menumis
1. Harus ada 1 ikat Daun kemangi
1. Diperlukan 1 sdt gula
1. Harus ada 1 sdt gram
1. Jangan lupa secukupnya kaldu ayam/penyedap rasa
1. Siapkan 200 ml air




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Rica Kemangi:

1. Potong2 ayam dan cuci bersih ayam lalu sisihkan
1. Blender bumbu halusss diatas lalu sisihkan kemudian uleg bumbu uleg kemiri dan kunyit sisihkan
1. Siapkan minyak tunggu hingga panas kemudian masukkan bumbu halus dan bahan uleg ke dalam minyak tumis hingga harum lalu masukkan daun salam, serai,jahe, laos kemudian ayam tumis hingga merata
1. Kemudian tambahkan air kemudian gula, garam dan kaldu cek rasa sesuai selera tunggu hingga mendidih dn air menyusut kemudian matikan api masukkan daun kemangi.ayam rica2 sudah siap dinikmati




Demikianlah cara membuat ayam rica rica kemangi yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat mudah dan cepat, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
