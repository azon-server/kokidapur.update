---
description: "Panduan membuat Ayam Geprek ala Bensu Cepat"
title: "Panduan membuat Ayam Geprek ala Bensu Cepat"
slug: 39-panduan-membuat-ayam-geprek-ala-bensu-cepat
date: 2020-11-05T05:45:29.164Z
image: https://img-global.cpcdn.com/recipes/656d3c06e0fac58f/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/656d3c06e0fac58f/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/656d3c06e0fac58f/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg
author: Ethel Fisher
ratingvalue: 4.4
reviewcount: 23745
recipeingredient:
- "250 gram ayam bagian dada"
- "1 butir telur"
- " Tepung bumbu kriukcrispy"
- " Bahan sambal korek "
- "3 siung bawang putih"
- "5 cabe rawit merah"
- "Secukupnya garam"
- " Bahan tambahan "
- " Keju parut untuk taburan"
- " Tempe goreng bumbu ungkep"
- " Ketimun"
recipeinstructions:
- "Taruh tepung dalam wadah. Sisihkan. Dalam wadah lain, kocok telur. Sisihkan."
- "Panaskan minyak dalam wajan terlebih dahulu. Minyaknya yang banyak yaa.. Biar saat digoreng, ayam kecelup semua."
- "Selagi menunggu minyak panas. Masukkan ayam ungkep ke dalam kocokan telur, bolak balik ayam. Kemudian ambil ayam dan masukkan dalam adonan tepung, bolak balik sambil ditekan dan dicubit&#34;."
- "Lalu goreng ayam sampai kuning keemasan. Sekali balik yaa.. Biar minyak tak terlalu meresap banyak di ayam. Tiriskan ayam dalam wadah yang sudah dilapisi tissue. Sisihkan."
- "Goreng bawang dan cabe sebentar. Tiriskan dan taruh di cobek. Haluskan dengan menambahkan garam. Lalu siram dengan minyak sisa menggoreng ayam td. Aduk merata."
- "Penyet ayam dalam cobek. Pindahkan ayam ke dalam piring saji. Lumuri dengan sambal koreknya, taburi dengan keju parut. Beri lalapan sesuai selera. Sajikan."
categories:
- Recipe
tags:
- ayam
- geprek
- ala

katakunci: ayam geprek ala 
nutrition: 156 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Geprek ala Bensu](https://img-global.cpcdn.com/recipes/656d3c06e0fac58f/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga renyah. Ciri masakan Nusantara ayam geprek ala bensu yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Geprek ala Bensu untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang bisa anda praktekkan salah satunya ayam geprek ala bensu yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya sekarang ini anda bisa dengan cepat menemukan resep ayam geprek ala bensu tanpa harus bersusah payah.
Seperti resep Ayam Geprek ala Bensu yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek ala Bensu:

1. Jangan lupa 250 gram ayam, bagian dada
1. Harus ada 1 butir telur
1. Harap siapkan  Tepung bumbu kriuk/crispy
1. Siapkan  Bahan sambal korek :
1. Diperlukan 3 siung bawang putih
1. Jangan lupa 5 cabe rawit merah
1. Diperlukan Secukupnya garam
1. Siapkan  Bahan tambahan :
1. Harus ada  Keju parut, untuk taburan
1. Jangan lupa  Tempe goreng, bumbu ungkep
1. Harus ada  Ketimun




<!--inarticleads2-->

##### Cara membuat  Ayam Geprek ala Bensu:

1. Taruh tepung dalam wadah. Sisihkan. Dalam wadah lain, kocok telur. Sisihkan.
1. Panaskan minyak dalam wajan terlebih dahulu. Minyaknya yang banyak yaa.. Biar saat digoreng, ayam kecelup semua.
1. Selagi menunggu minyak panas. Masukkan ayam ungkep ke dalam kocokan telur, bolak balik ayam. Kemudian ambil ayam dan masukkan dalam adonan tepung, bolak balik sambil ditekan dan dicubit&#34;.
1. Lalu goreng ayam sampai kuning keemasan. Sekali balik yaa.. Biar minyak tak terlalu meresap banyak di ayam. Tiriskan ayam dalam wadah yang sudah dilapisi tissue. Sisihkan.
1. Goreng bawang dan cabe sebentar. Tiriskan dan taruh di cobek. Haluskan dengan menambahkan garam. Lalu siram dengan minyak sisa menggoreng ayam td. Aduk merata.
1. Penyet ayam dalam cobek. Pindahkan ayam ke dalam piring saji. Lumuri dengan sambal koreknya, taburi dengan keju parut. Beri lalapan sesuai selera. Sajikan.




Demikianlah cara membuat ayam geprek ala bensu yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan terbukti, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
