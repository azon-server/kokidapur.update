---
description: "Step-by-Step membuat Ayam rica rica kemangi Luar biasa"
title: "Step-by-Step membuat Ayam rica rica kemangi Luar biasa"
slug: 353-step-by-step-membuat-ayam-rica-rica-kemangi-luar-biasa
date: 2020-12-23T21:06:11.533Z
image: https://img-global.cpcdn.com/recipes/8203fd1f3f00845c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8203fd1f3f00845c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8203fd1f3f00845c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Dominic McBride
ratingvalue: 4.2
reviewcount: 37720
recipeingredient:
- "1 ekor ayam"
- "2 lmbr daun salam"
- "2 lmbr daun jeruk"
- "1 ruas jahe  geprek"
- "1 ruas lengkuas  geprek"
- "1 batang sereh"
- "secukupnya kemangi"
- "secukupnya penyedap rasa gula garam"
- "secukupnya air"
- "1 sdt ketumbar bubuk"
- " bahan halus"
- " cabai rawit jawa selera"
- " caabai keritingselera"
- "1 ruas kunyit"
- "3 pcs bawang merah"
- "3 pcs bawang putih"
recipeinstructions:
- "Haluskan bumbu, lalu goreng ayam sampai matang"
- "Panskan minyak,lalu tumis bumbu halus masukan sereh,daun salam, daun jeruk, lengkuas,jahe dan ketumbar bubuk jangan lupa tambahkan penyedap rasa, gula, garam dan air"
- "Jika sudah pas rasa msukan ayam yang sudah di goreng serta kemangi,jika sudah pas bisa langsung di sajikan 🤗"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 156 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/8203fd1f3f00845c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita jaga karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica rica kemangi yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Nusantara

Kedekatan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah memasak Ayam rica rica kemangi untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang bisa anda praktekkan salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini anda bisa dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Siapkan 1 ekor ayam
1. Siapkan 2 lmbr daun salam
1. Jangan lupa 2 lmbr daun jeruk
1. Jangan lupa 1 ruas jahe ( geprek)
1. Diperlukan 1 ruas lengkuas ( geprek)
1. Tambah 1 batang sereh
1. Jangan lupa secukupnya kemangi
1. Harus ada secukupnya penyedap rasa, gula, garam
1. Diperlukan secukupnya air
1. Jangan lupa 1 sdt ketumbar bubuk
1. Diperlukan  bahan halus
1. Dibutuhkan  cabai rawit jawa (selera)
1. Diperlukan  caabai keriting(selera)
1. Siapkan 1 ruas kunyit
1. Tambah 3 pcs bawang merah
1. Jangan lupa 3 pcs bawang putih




<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica kemangi:

1. Haluskan bumbu, lalu goreng ayam sampai matang
1. Panskan minyak,lalu tumis bumbu halus masukan sereh,daun salam, daun jeruk, lengkuas,jahe dan ketumbar bubuk jangan lupa tambahkan penyedap rasa, gula, garam dan air
1. Jika sudah pas rasa msukan ayam yang sudah di goreng serta kemangi,jika sudah pas bisa langsung di sajikan 🤗




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan teruji, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
