---
description: "Resep : Ayam rica-rica kemangi Cepat"
title: "Resep : Ayam rica-rica kemangi Cepat"
slug: 230-resep-ayam-rica-rica-kemangi-cepat
date: 2020-10-11T07:45:54.352Z
image: https://img-global.cpcdn.com/recipes/1d4c564ddde0f1cf/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1d4c564ddde0f1cf/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1d4c564ddde0f1cf/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Bradley Scott
ratingvalue: 4.1
reviewcount: 13651
recipeingredient:
- "1/2 ekor ayam"
- "2 batang kemangi"
- "8 bawang merah"
- "4 bawang putih"
- "5 cabai keriting"
- "30 cabai rawit jablay"
- "1 buah tomat"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 batang serai"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 ruas lengkuas"
- "2 kemiri"
- "secukupnya Garam"
- "secukupnya Gula pasir"
- "secukupnya Penyedap rasa"
- "200 ml air"
recipeinstructions:
- "Cuci ayam hingga bersih lalu taburi penyedap rasa sedikit, marinasi 5 menit lalu goreng setengah matang"
- "Haluskan semua bahan, sisakan 15 cabai rawit jablay untuk taburan, geprek sereh, lengkuas"
- "Tumis bumbu halus lalu tambahkan garam, gula dan penyedap rasa"
- "Masukkan ayam aduk hingga rata, jika sudah agak menyerap masukkan kemangi dan cabai rawit, tambahkan sedikit air, biar kan hingga menyerap, koreksi rasa"
- "Ayam rica kemangi siap di hidangkan untuk lauk makan siang atau malam"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 250 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/1d4c564ddde0f1cf/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga empuk. Ciri masakan Indonesia ayam rica-rica kemangi yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga dapat didapat dengan cara mudah. Diantaranya adalah memasak Ayam rica-rica kemangi untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang dapat anda coba salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica kemangi:

1. Diperlukan 1/2 ekor ayam
1. Dibutuhkan 2 batang kemangi
1. Harap siapkan 8 bawang merah
1. Harus ada 4 bawang putih
1. Diperlukan 5 cabai keriting
1. Dibutuhkan 30 cabai rawit jablay
1. Jangan lupa 1 buah tomat
1. Diperlukan 1 ruas jahe
1. Harus ada 1 ruas kunyit
1. Siapkan 1 batang serai
1. Dibutuhkan 2 lembar daun salam
1. Jangan lupa 2 lembar daun jeruk
1. Diperlukan 1 ruas lengkuas
1. Siapkan 2 kemiri
1. Tambah secukupnya Garam
1. Diperlukan secukupnya Gula pasir
1. Diperlukan secukupnya Penyedap rasa
1. Dibutuhkan 200 ml air




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica-rica kemangi:

1. Cuci ayam hingga bersih lalu taburi penyedap rasa sedikit, marinasi 5 menit lalu goreng setengah matang
1. Haluskan semua bahan, sisakan 15 cabai rawit jablay untuk taburan, geprek sereh, lengkuas
1. Tumis bumbu halus lalu tambahkan garam, gula dan penyedap rasa
1. Masukkan ayam aduk hingga rata, jika sudah agak menyerap masukkan kemangi dan cabai rawit, tambahkan sedikit air, biar kan hingga menyerap, koreksi rasa
1. Ayam rica kemangi siap di hidangkan untuk lauk makan siang atau malam




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan cepat, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
