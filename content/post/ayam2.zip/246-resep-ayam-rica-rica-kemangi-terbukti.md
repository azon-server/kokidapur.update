---
description: "Resep : Ayam rica rica kemangi Terbukti"
title: "Resep : Ayam rica rica kemangi Terbukti"
slug: 246-resep-ayam-rica-rica-kemangi-terbukti
date: 2020-08-09T22:15:14.205Z
image: https://img-global.cpcdn.com/recipes/33014012a131bc53/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/33014012a131bc53/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/33014012a131bc53/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Clarence Carr
ratingvalue: 4.7
reviewcount: 36018
recipeingredient:
- "500 gr ayam"
- "2 ikat kemangi"
- "1 jeruk npis"
- " Bumbu halus"
- "10 siung bawang merah"
- "7 siung bawang putih"
- "15 cabe rawit"
- "5 butir kemiri sangrai"
- "1 sdt mrica"
- "1/2 sdt ketumbar"
- "10 cm kunyit"
- "10 cm jahe"
- " Bumbu cemplung"
- "2 lbr daun salam"
- " Lengkuas geprek"
- "2 batang serai geprek"
- "3 sdm kecap manis"
- "1 sdm garam"
- "1 sdm gula pasir"
- "300 ml Air"
recipeinstructions:
- "Cuci bersih ayam lumuri dgan jeruk npis diamkan 10 mnt, goreng basah sebentar"
- "Sambil nunggu ayam kita siapkan bumbu halusnya, panaskan minyak di wajan masukan bumbu halus hingga harum masukan bumbu cemplung aduk2 hingga layu lalu masukan ayam yg sdh di goreng sebentar beri air kecap gula kemangi aduk biarkan hingga air surut matikan api kompor beri garam"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 271 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT60M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/33014012a131bc53/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan renyah. Ciri khas kuliner Indonesia ayam rica rica kemangi yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam rica rica kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang dapat anda praktekkan salah satunya ayam rica rica kemangi yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 2 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Jangan lupa 500 gr ayam
1. Siapkan 2 ikat kemangi
1. Jangan lupa 1 jeruk npis
1. Harap siapkan  Bumbu halus
1. Dibutuhkan 10 siung bawang merah
1. Diperlukan 7 siung bawang putih
1. Jangan lupa 15 cabe rawit
1. Dibutuhkan 5 butir kemiri sangrai
1. Tambah 1 sdt mrica
1. Diperlukan 1/2 sdt ketumbar
1. Siapkan 10 cm kunyit
1. Tambah 10 cm jahe
1. Diperlukan  Bumbu cemplung
1. Siapkan 2 lbr daun salam
1. Dibutuhkan  Lengkuas geprek
1. Harap siapkan 2 batang serai geprek
1. Dibutuhkan 3 sdm kecap manis
1. Harap siapkan 1 sdm garam
1. Diperlukan 1 sdm gula pasir
1. Diperlukan 300 ml Air




<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica kemangi:

1. Cuci bersih ayam lumuri dgan jeruk npis diamkan 10 mnt, goreng basah sebentar
1. Sambil nunggu ayam kita siapkan bumbu halusnya, panaskan minyak di wajan masukan bumbu halus hingga harum masukan bumbu cemplung aduk2 hingga layu lalu masukan ayam yg sdh di goreng sebentar beri air kecap gula kemangi aduk biarkan hingga air surut matikan api kompor beri garam




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan terbukti, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
