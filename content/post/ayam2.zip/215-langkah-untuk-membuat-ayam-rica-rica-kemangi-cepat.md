---
description: "Langkah untuk membuat Ayam rica rica kemangi Cepat"
title: "Langkah untuk membuat Ayam rica rica kemangi Cepat"
slug: 215-langkah-untuk-membuat-ayam-rica-rica-kemangi-cepat
date: 2020-09-05T03:25:10.021Z
image: https://img-global.cpcdn.com/recipes/fb922f84ed590e1c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fb922f84ed590e1c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fb922f84ed590e1c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Douglas Blake
ratingvalue: 4.5
reviewcount: 20348
recipeingredient:
- "1 ekor ayamsaya pakai paha semua"
- "1 sdt garam"
- "1 1/2 sdm air jeruk nipis"
- " Bumbu halus"
- "10 butir bawang merah"
- "5 siung bawang putih"
- "15 cabai merah"
- "7 cabai rawit"
- "2 cm jahe"
- "1 buah tomat"
- " Bahan yang di cemplung"
- "2 batang serai ambil putihnya memarkan"
- "1 batang serai ambil putihnya iris tipis"
- "6 daun jeruk buang tulangnya robek kasar"
- "1 ikat kemangi petikin daun nya"
- "1/2 sdt garam"
- "1/2 sdt gula"
- "1/2 sdt kaldu jamur"
- "Sedikit air"
recipeinstructions:
- "Ayam, potong menjadi 10 bagian. Cuci bersih ayam. Tusuk2 ayam dengan garpu, agar bumbu lebih meresap. Lumuri dengan garam dan jeruk nipis. Diamkan selama 20 menit. Bilas. Lalu goreng ayam, sampai matang, jgn kering ya. Sisihkan"
- "Panaskan minyak, tumis bumbu halus, sampai matang dan harum.Masukkan bumbu cemplung"
- "Lalu masukkan ayam aduk rata. Tambahkan air dan gula pasir. Masak sampai semua bumbu mengental, masukkan kemangi, biarkan bumbu meresap. Matikan api"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 203 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/fb922f84ed590e1c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis atau empuk. Ciri masakan Indonesia ayam rica rica kemangi yang kaya dengan rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kehangatan keluarga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica rica kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang dapat anda coba salah satunya ayam rica rica kemangi yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 19 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Harap siapkan 1 ekor ayam*saya pakai paha semua
1. Dibutuhkan 1 sdt garam
1. Harap siapkan 1 1/2 sdm air jeruk nipis
1. Jangan lupa  Bumbu halus
1. Tambah 10 butir bawang merah
1. Tambah 5 siung bawang putih
1. Harap siapkan 15 cabai merah
1. Siapkan 7 cabai rawit
1. Jangan lupa 2 cm jahe
1. Dibutuhkan 1 buah tomat
1. Harus ada  Bahan yang di cemplung
1. Siapkan 2 batang serai ambil putihnya, memarkan
1. Dibutuhkan 1 batang serai, ambil putihnya iris tipis
1. Diperlukan 6 daun jeruk, buang tulangnya robek kasar
1. Diperlukan 1 ikat kemangi, petikin daun nya
1. Harus ada 1/2 sdt garam
1. Dibutuhkan 1/2 sdt gula
1. Harap siapkan 1/2 sdt kaldu jamur
1. Tambah Sedikit air


Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Cara membuat  Ayam rica rica kemangi:

1. Ayam, potong menjadi 10 bagian. Cuci bersih ayam. Tusuk2 ayam dengan garpu, agar bumbu lebih meresap. Lumuri dengan garam dan jeruk nipis. Diamkan selama 20 menit. Bilas. Lalu goreng ayam, sampai matang, jgn kering ya. Sisihkan
1. Panaskan minyak, tumis bumbu halus, sampai matang dan harum.Masukkan bumbu cemplung
1. Lalu masukkan ayam aduk rata. Tambahkan air dan gula pasir. Masak sampai semua bumbu mengental, masukkan kemangi, biarkan bumbu meresap. Matikan api


Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Siapa yang tidak mengenal lalapan daun kemangi di Indonesia ini. Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. 

Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
