---
description: "Langkah menyiapakan Ayam rica-rica kemangi Sempurna"
title: "Langkah menyiapakan Ayam rica-rica kemangi Sempurna"
slug: 326-langkah-menyiapakan-ayam-rica-rica-kemangi-sempurna
date: 2020-08-24T19:31:32.592Z
image: https://img-global.cpcdn.com/recipes/39c550564cc0c851/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/39c550564cc0c851/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/39c550564cc0c851/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Lillian Figueroa
ratingvalue: 4.5
reviewcount: 46759
recipeingredient:
- "1/2 ekor ayam potong kecil kecil"
- "3 buah kemiri"
- "10 cabe keriting"
- "10 cabe rawit"
- "1 ikat kemangi"
- "1/2 sdt kunyit bubuk"
- "1 ruas jahe"
- "1 batang sereh geprek aja"
- "Sejumput garam"
- "1 bungkus royco"
- "4 daun purut"
- "1 buah tomat"
- " Jeruk nipis"
- "10 siung bawang merah"
- "4 siung bawang putih"
recipeinstructions:
- "Cuci bersih ayam yg sudah dipotong,taburi sedikit garam,kunyit bubuk dan perasan air jeruk nipis,biarkan hingga meresap sekitar 15 menit. Lalu goreng ayam gula ush terllu lama cukup aga kecoklatan aja"
- "Haluskan bawang,jahe,cabe kriting &amp; rawit,tomat,dan kemiri... Sisihkan"
- "Siapkan wajan yg sdh berisi minyak goreng secukupnya untuk menumis bumbu, tumis bumbu halus beserta sereh dan daun purut sampai harum.. setelah itu masukan ayam aduk2 lg sampai rata.. dan tambahkan air segelas belimbing serta garam &amp; royco"
- "Jika air sudah mulai menyusut (hendak kering) kita tambahkan kemangi aduk rata agar tercampur.. jika kemangi sudah layu dan air sdh kering bisa langsung diangkat lalu sajikan..."
- "Aku sukanya asin ya jd aku banyak pake royconya😁😁😁"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 173 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/39c550564cc0c851/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga empuk. Karasteristik makanan Nusantara ayam rica-rica kemangi yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga bisa didapat dengan cara simple. Salah satunya adalah memasak Ayam rica-rica kemangi untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang bisa anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 15 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica kemangi:

1. Harap siapkan 1/2 ekor ayam potong kecil kecil
1. Jangan lupa 3 buah kemiri
1. Siapkan 10 cabe keriting
1. Harap siapkan 10 cabe rawit
1. Jangan lupa 1 ikat kemangi
1. Dibutuhkan 1/2 sdt kunyit bubuk
1. Siapkan 1 ruas jahe
1. Dibutuhkan 1 batang sereh geprek aja
1. Siapkan Sejumput garam
1. Jangan lupa 1 bungkus royco
1. Dibutuhkan 4 daun purut
1. Dibutuhkan 1 buah tomat
1. Jangan lupa  Jeruk nipis
1. Harus ada 10 siung bawang merah
1. Jangan lupa 4 siung bawang putih




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica-rica kemangi:

1. Cuci bersih ayam yg sudah dipotong,taburi sedikit garam,kunyit bubuk dan perasan air jeruk nipis,biarkan hingga meresap sekitar 15 menit. Lalu goreng ayam gula ush terllu lama cukup aga kecoklatan aja
1. Haluskan bawang,jahe,cabe kriting &amp; rawit,tomat,dan kemiri... Sisihkan
1. Siapkan wajan yg sdh berisi minyak goreng secukupnya untuk menumis bumbu, tumis bumbu halus beserta sereh dan daun purut sampai harum.. setelah itu masukan ayam aduk2 lg sampai rata.. dan tambahkan air segelas belimbing serta garam &amp; royco
1. Jika air sudah mulai menyusut (hendak kering) kita tambahkan kemangi aduk rata agar tercampur.. jika kemangi sudah layu dan air sdh kering bisa langsung diangkat lalu sajikan...
1. Aku sukanya asin ya jd aku banyak pake royconya😁😁😁




Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan cepat, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
