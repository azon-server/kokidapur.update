---
description: "Resep : 15. AYAM RICA DAUN KEMANGI made by @adindahwytnskitchen 🌻 Teruji"
title: "Resep : 15. AYAM RICA DAUN KEMANGI made by @adindahwytnskitchen 🌻 Teruji"
slug: 378-resep-15-ayam-rica-daun-kemangi-made-by-adindahwytnskitchen-teruji
date: 2020-08-27T23:30:50.373Z
image: https://img-global.cpcdn.com/recipes/07c5925dcd50688e/751x532cq70/15-ayam-rica-daun-kemangi-made-by-adindahwytnskitchen-🌻-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/07c5925dcd50688e/751x532cq70/15-ayam-rica-daun-kemangi-made-by-adindahwytnskitchen-🌻-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/07c5925dcd50688e/751x532cq70/15-ayam-rica-daun-kemangi-made-by-adindahwytnskitchen-🌻-foto-resep-utama.jpg
author: Eugene White
ratingvalue: 5
reviewcount: 38716
recipeingredient:
- "1 Kg ayam dadapaha"
- "5 Cabai merah besar"
- "10 cabai merah rawit"
- "5 cabai merah keriting"
- "7 siung bawang merah"
- "4 siung bawang putih"
- "2 kemiri sangrai"
- "2 cm lengkuas"
- "2 cm jahe"
- "3 daun salam"
- "3 daun jeruk"
- "1 batang sereh"
- "5 ikat daun kemangi"
- "1 sdt kaldu ayam bubuk"
- "3 sdm minyak utk menumis"
recipeinstructions:
- "Cuci ayam dan potong sesuai selera, rebus ayam dengan 1 daun salam, 1 batang sereh, 1 daun jeruk beri sedikit garam. Setelah matang, buang air rebusan (jika yg dipakai ayam negri/broiler) cuci kembali ayam lalu tiriskan."
- "Haluskan semua bumbu kecuali jahe, lengkuas, daun salam dan daun jeruk hingga matang"
- "Masukkan bumbu keprek, jahe, lengkuas, daun salam &amp; daun jeruk."
- "Masukkan ayam dlm bumbu tumisan, aduk merata dan koreksi rasa"
categories:
- Recipe
tags:
- 15
- ayam
- rica

katakunci: 15 ayam rica 
nutrition: 257 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT59M"
recipeyield: "2"
recipecategory: Dessert

---


![15. AYAM RICA DAUN KEMANGI made by @adindahwytnskitchen 🌻](https://img-global.cpcdn.com/recipes/07c5925dcd50688e/751x532cq70/15-ayam-rica-daun-kemangi-made-by-adindahwytnskitchen-🌻-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti 15. ayam rica daun kemangi made by @adindahwytnskitchen 🌻 yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Ingin merasakan ayam yg nikmat dan lezat ? Manfaat daun kemangi yang banyak orang ketahui pun sekadar penggunaannya pada aneka kuliner dan tidak membahas tentang manfaat daun Terlepas dari pembuktian secara ilmiah, kemangi secara empiris telah digunakan dalam pengobatan tradisional untuk berbagai macam penyakit, baik di. Tambahkan tomat, daun salam, daun jeruk, sereh, dan jahe; aduk-aduk sampai berubah waranya.

Kehangatan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan 15. AYAM RICA DAUN KEMANGI made by @adindahwytnskitchen 🌻 untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang bisa anda coba salah satunya 15. ayam rica daun kemangi made by @adindahwytnskitchen 🌻 yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep 15. ayam rica daun kemangi made by @adindahwytnskitchen 🌻 tanpa harus bersusah payah.
Seperti resep 15. AYAM RICA DAUN KEMANGI made by @adindahwytnskitchen 🌻 yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 15. AYAM RICA DAUN KEMANGI made by @adindahwytnskitchen 🌻:

1. Dibutuhkan 1 Kg ayam dada+paha
1. Tambah 5 Cabai merah besar
1. Tambah 10 cabai merah rawit
1. Jangan lupa 5 cabai merah keriting
1. Harus ada 7 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Siapkan 2 kemiri (sangrai)
1. Diperlukan 2 cm lengkuas
1. Harap siapkan 2 cm jahe
1. Dibutuhkan 3 daun salam
1. Harap siapkan 3 daun jeruk
1. Diperlukan 1 batang sereh
1. Harap siapkan 5 ikat daun kemangi
1. Harus ada 1 sdt kaldu ayam bubuk
1. Dibutuhkan 3 sdm minyak utk menumis


Tambahkan daun salam, daun jeruk, jahe, dan serai, aduk sampai warnanya berubah kecoklatan. Manfaat daun kemangi untuk kesehatan cukup beragam. Mulai dari mengurangi pembengkakan hingga berpotensi mencegah kanker. Selain sebagai lalapan, daun hijau berbau sedap yang biasa disebut kemangi ini ternyata juga memiliki banyak manfaat untuk kesehatan. 

<!--inarticleads2-->

##### Cara membuat  15. AYAM RICA DAUN KEMANGI made by @adindahwytnskitchen 🌻:

1. Cuci ayam dan potong sesuai selera, rebus ayam dengan 1 daun salam, 1 batang sereh, 1 daun jeruk beri sedikit garam. Setelah matang, buang air rebusan (jika yg dipakai ayam negri/broiler) cuci kembali ayam lalu tiriskan.
1. Haluskan semua bumbu kecuali jahe, lengkuas, daun salam dan daun jeruk hingga matang
1. Masukkan bumbu keprek, jahe, lengkuas, daun salam &amp; daun jeruk.
1. Masukkan ayam dlm bumbu tumisan, aduk merata dan koreksi rasa


Mulai dari mengurangi pembengkakan hingga berpotensi mencegah kanker. Selain sebagai lalapan, daun hijau berbau sedap yang biasa disebut kemangi ini ternyata juga memiliki banyak manfaat untuk kesehatan. Masak kembali hingga kuahnya menyusut, serta daging ayamnya empuk dan matang. Sebelum anda mengangkat daging ayam, tambahkan daun kemangi. Tambahan daun kemangi yang bercita rasa pedas sekaligus segar sangat pas dipadukan dengan olahan pampis ayam. 

Demikianlah cara membuat 15. ayam rica daun kemangi made by @adindahwytnskitchen 🌻 yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat mudah dan terbukti, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
