---
description: "Resep : Ayam Rica-Rica Kemangi terupdate"
title: "Resep : Ayam Rica-Rica Kemangi terupdate"
slug: 299-resep-ayam-rica-rica-kemangi-terupdate
date: 2020-08-13T07:29:11.159Z
image: https://img-global.cpcdn.com/recipes/4756c5a788075d7a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4756c5a788075d7a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4756c5a788075d7a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Alfred Morales
ratingvalue: 4.8
reviewcount: 35307
recipeingredient:
- "1 Kg Ayam"
- "2 ikat daun kemangi"
- "1 batang serai"
- "2 lembar Daun Salam"
- "2 lembar daun Jeruk"
- " Garam"
- " Gula"
- " Bumbu Halus "
- "10-15 biji Cabai Merah"
- "15 biji Cabai Rawit"
- "3 buah bamer"
- "2 siung baput"
- "1 buah tomat optional"
- "2 butir kemiri"
- "1 ruas Kunyit"
- " Jahe sedikit aja"
- "1 batang serai"
recipeinstructions:
- "Bersihkan dan potong ayam dengan ukuran kecil-kecil (sesuai selera), taburin garam, sisihkan."
- "Blend semua bumbu halus, lalu tumis dengan sedikit minyak hingga mengeluarkan aroma. (Part yang ini bener-bener menggoda, karena wangi rempah nya berasa seruangan)"
- "Masukkan Batang serai yang sudah di geprek, diikuti dengan daun salam dan daun jeruk. Tumis"
- "Lalu masukkan ayam, garam dan gula, tumis hingga matang kurleb 30 menit. Cek rasa"
- "Terakhir masukkan daun kemangi, aduk2 sebentar. Done!"
- "Tingkat Kematangan bisa di atur sesuai selera ya, jika ingin ada sedikit kuah, bisa tambahkan air. Jika ingin kering, masak sedikit lebih lama."
- "Ayam Rica-Rica Kemangi siap untuk disantap"
- "Selamat mencoba moms💙"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 199 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/4756c5a788075d7a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica-rica kemangi yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan ciri khas yang merupakan keragaman Nusantara

Keharmonisan rumah tangga dapat diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica-Rica Kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang bisa anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica Kemangi:

1. Diperlukan 1 Kg Ayam
1. Harus ada 2 ikat daun kemangi
1. Siapkan 1 batang serai
1. Harus ada 2 lembar Daun Salam
1. Tambah 2 lembar daun Jeruk
1. Jangan lupa  Garam
1. Dibutuhkan  Gula
1. Siapkan  Bumbu Halus :
1. Siapkan 10-15 biji Cabai Merah
1. Harap siapkan 15 biji Cabai Rawit
1. Tambah 3 buah bamer
1. Harap siapkan 2 siung baput
1. Harus ada 1 buah tomat (optional)
1. Siapkan 2 butir kemiri
1. Tambah 1 ruas Kunyit
1. Diperlukan  Jahe (sedikit aja)
1. Siapkan 1 batang serai




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-Rica Kemangi:

1. Bersihkan dan potong ayam dengan ukuran kecil-kecil (sesuai selera), taburin garam, sisihkan.
1. Blend semua bumbu halus, lalu tumis dengan sedikit minyak hingga mengeluarkan aroma. (Part yang ini bener-bener menggoda, karena wangi rempah nya berasa seruangan)
1. Masukkan Batang serai yang sudah di geprek, diikuti dengan daun salam dan daun jeruk. Tumis
1. Lalu masukkan ayam, garam dan gula, tumis hingga matang kurleb 30 menit. Cek rasa
1. Terakhir masukkan daun kemangi, aduk2 sebentar. Done!
1. Tingkat Kematangan bisa di atur sesuai selera ya, jika ingin ada sedikit kuah, bisa tambahkan air. Jika ingin kering, masak sedikit lebih lama.
1. Ayam Rica-Rica Kemangi siap untuk disantap
1. Selamat mencoba moms💙




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan teruji, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
