---
description: "Langkah untuk menyiapakan Ayam Rica-Rica Kemangi Terbukti"
title: "Langkah untuk menyiapakan Ayam Rica-Rica Kemangi Terbukti"
slug: 359-langkah-untuk-menyiapakan-ayam-rica-rica-kemangi-terbukti
date: 2020-12-05T02:55:34.854Z
image: https://img-global.cpcdn.com/recipes/2c6d968fa9c99095/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2c6d968fa9c99095/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2c6d968fa9c99095/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Ernest Peters
ratingvalue: 4.8
reviewcount: 14873
recipeingredient:
- " Ayam ungkep"
- "1 ekor Ayam potong 12"
- "2 sdm garam"
- "1/2 lingkaran gula merah"
- "1/2 bungkus ketumbar bubuk"
- "1/2 bungkus merica"
- " Bumbu Halus H"
- "3 ruas jahe"
- "3 ruas kunyit"
- "5 pcs bawang putih"
- "10 pcs bawang merah"
- "10 pcs cabe merah besar"
- "10 pcs cabe rawit"
- "4 pcs kemiri"
- "1/2 bungkus merica bubuk"
- "1/2 bungkus ketumbar bubuk"
- "1/2 lingkaran gula merah"
- "1 sdm kaldu jamur"
- "1/2 sdm garam"
- "5 sendok sup Air kaldu ayam pakai rebusan kepala dan ceker"
- " Bumbu Masak M"
- "12 lembar daun jeruk"
- "5 lembar daun salam"
- "2 sereh pipihkan  simpul"
- "2 ikat daun kemangi"
recipeinstructions:
- "Ayam dibersihkan lalu dibaluri bumbu ungkepan. Kukus sekitar 30 menit sampai setengah matang."
- "NOTE: air untuk mengukus diberi ceker dan kepla ayam, nantinya air ungkepan ini akan jadi air untuk bumbu halus"
- "Haluskan semua bumbu halus (H) dengan blender, agar cair, berikan air ungkepan yang sudah dimasukkan kepala dan ceker ayam"
- "Panaskan minyak/mentega, masukkan bumbu halus, tumis sebentar, lalu masukkan ayam 1/2 matang hasil ungkepan"
- "Masukkan bumbu masak (M), Aduk hingga rata dan matang"
- "Setelah matang, matikan api, dan masukkan daun kemangi, aduk lagi hingga daunnya agak layu, sajikan"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 277 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT44M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/2c6d968fa9c99095/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan empuk. Ciri khas masakan Indonesia ayam rica-rica kemangi yang penuh dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan keluarga dapat ditemukan dengan cara mudah. Salah satunya adalah memasak Ayam Rica-Rica Kemangi untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang dapat anda contoh salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 25 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Kemangi:

1. Diperlukan  Ayam, ungkep
1. Dibutuhkan 1 ekor Ayam (potong 12)
1. Harus ada 2 sdm garam
1. Siapkan 1/2 lingkaran gula merah
1. Dibutuhkan 1/2 bungkus ketumbar bubuk
1. Tambah 1/2 bungkus merica
1. Siapkan  Bumbu Halus (H)
1. Jangan lupa 3 ruas jahe
1. Dibutuhkan 3 ruas kunyit
1. Tambah 5 pcs bawang putih
1. Siapkan 10 pcs bawang merah
1. Harap siapkan 10 pcs cabe merah besar
1. Jangan lupa 10 pcs cabe rawit
1. Harap siapkan 4 pcs kemiri
1. Harus ada 1/2 bungkus merica bubuk
1. Harus ada 1/2 bungkus ketumbar bubuk
1. Jangan lupa 1/2 lingkaran gula merah
1. Harap siapkan 1 sdm kaldu jamur
1. Harus ada 1/2 sdm garam
1. Dibutuhkan 5 sendok sup Air kaldu ayam (pakai rebusan kepala dan ceker)
1. Siapkan  Bumbu Masak (M)
1. Jangan lupa 12 lembar daun jeruk
1. Harus ada 5 lembar daun salam
1. Dibutuhkan 2 sereh, pipihkan &amp; simpul
1. Tambah 2 ikat daun kemangi




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-Rica Kemangi:

1. Ayam dibersihkan lalu dibaluri bumbu ungkepan. Kukus sekitar 30 menit sampai setengah matang.
1. NOTE: air untuk mengukus diberi ceker dan kepla ayam, nantinya air ungkepan ini akan jadi air untuk bumbu halus
1. Haluskan semua bumbu halus (H) dengan blender, agar cair, berikan air ungkepan yang sudah dimasukkan kepala dan ceker ayam
1. Panaskan minyak/mentega, masukkan bumbu halus, tumis sebentar, lalu masukkan ayam 1/2 matang hasil ungkepan
1. Masukkan bumbu masak (M), Aduk hingga rata dan matang
1. Setelah matang, matikan api, dan masukkan daun kemangi, aduk lagi hingga daunnya agak layu, sajikan




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
