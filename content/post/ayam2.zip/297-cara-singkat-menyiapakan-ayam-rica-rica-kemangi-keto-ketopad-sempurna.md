---
description: "Cara singkat menyiapakan Ayam Rica-rica Kemangi Keto #ketopad Sempurna"
title: "Cara singkat menyiapakan Ayam Rica-rica Kemangi Keto #ketopad Sempurna"
slug: 297-cara-singkat-menyiapakan-ayam-rica-rica-kemangi-keto-ketopad-sempurna
date: 2020-10-21T19:06:30.035Z
image: https://img-global.cpcdn.com/recipes/b1ae364d03273006/751x532cq70/ayam-rica-rica-kemangi-keto-ketopad-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b1ae364d03273006/751x532cq70/ayam-rica-rica-kemangi-keto-ketopad-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b1ae364d03273006/751x532cq70/ayam-rica-rica-kemangi-keto-ketopad-foto-resep-utama.jpg
author: Christian Greene
ratingvalue: 4.8
reviewcount: 42751
recipeingredient:
- "potong Ayam"
- "2 sereh di geprek"
- "10 daun jeruk"
- "1 ikat daun kemangi"
- " Bumbu yang dihaluskan atau diulek"
- "8 bawang merah kecil"
- "5 bawang putih kecil"
- "8 cabe merah keriting"
- "2 cm jahe"
- "2 cm lengkuas"
- "2 cm kunyit"
- "5 kemiri"
- " garam secukup nya"
recipeinstructions:
- "Bersihkan ayam yang sudah dipotong-potong"
- "Rebus sebentar setengah matang dengan sedikit garam dan gula"
- "Angkat pisahkan"
- "Haluskan semua bumbu halus"
- "Panaskan minyak goreng, setelah agak panas masukkan bumbu halus serta sereh, daun jeruk dan daun kemangi hingga wangi"
- "Masukkan ayam yang sudah direbus setengah matang lalu aduk"
- "Aduk rata dengan api kecil sebentar lalu tutup wajan nya selama 15-20 menit"
- "Cicipi rasa apabila kurang garam dan gula kasih lalu aduk sebentar"
- "Hidangkan bersama makanan lainnya"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 262 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT41M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica-rica Kemangi Keto #ketopad](https://img-global.cpcdn.com/recipes/b1ae364d03273006/751x532cq70/ayam-rica-rica-kemangi-keto-ketopad-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan empuk. Ciri masakan Nusantara ayam rica-rica kemangi keto #ketopad yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kehangatan keluarga dapat didapat dengan cara simple. Diantaranya adalah memasak Ayam Rica-rica Kemangi Keto #ketopad untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang bisa anda contoh salah satunya ayam rica-rica kemangi keto #ketopad yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica-rica kemangi keto #ketopad tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Kemangi Keto #ketopad yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 9 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica Kemangi Keto #ketopad:

1. Diperlukan potong Ayam
1. Tambah 2 sereh di geprek
1. Tambah 10 daun jeruk
1. Tambah 1 ikat daun kemangi
1. Dibutuhkan  Bumbu yang dihaluskan atau diulek
1. Diperlukan 8 bawang merah kecil
1. Siapkan 5 bawang putih kecil
1. Dibutuhkan 8 cabe merah keriting
1. Harus ada 2 cm jahe
1. Diperlukan 2 cm lengkuas
1. Harap siapkan 2 cm kunyit
1. Harap siapkan 5 kemiri
1. Harus ada  garam secukup nya




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-rica Kemangi Keto #ketopad:

1. Bersihkan ayam yang sudah dipotong-potong
1. Rebus sebentar setengah matang dengan sedikit garam dan gula
1. Angkat pisahkan
1. Haluskan semua bumbu halus
1. Panaskan minyak goreng, setelah agak panas masukkan bumbu halus serta sereh, daun jeruk dan daun kemangi hingga wangi
1. Masukkan ayam yang sudah direbus setengah matang lalu aduk
1. Aduk rata dengan api kecil sebentar lalu tutup wajan nya selama 15-20 menit
1. Cicipi rasa apabila kurang garam dan gula kasih lalu aduk sebentar
1. Hidangkan bersama makanan lainnya




Demikianlah cara membuat ayam rica-rica kemangi keto #ketopad yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat simple dan terbukti, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
