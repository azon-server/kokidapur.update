---
description: "Cara membuat Ayam rica rica kemangi Cepat"
title: "Cara membuat Ayam rica rica kemangi Cepat"
slug: 216-cara-membuat-ayam-rica-rica-kemangi-cepat
date: 2020-11-06T09:01:07.350Z
image: https://img-global.cpcdn.com/recipes/99a36fb1d5ebc3ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/99a36fb1d5ebc3ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/99a36fb1d5ebc3ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Genevieve Mendoza
ratingvalue: 4.8
reviewcount: 19993
recipeingredient:
- "1/2 kg ayam"
- " Bumbu halus"
- "5 siung bawang putih"
- "5 siung bawang merah"
- "20 buah cabe merah keriting"
- "5-10 buah cabe rawit"
- "1 butir kemiri sangrai dulu"
- "Sedikit ketumbar"
- " Bahan cemplung "
- "1 ruas lengkuas"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "1 batang serai"
- "1 buah tomat"
- " "
- "1 ikat daun kemangi"
- "1 batang daun bawang"
- "Secukupnya garam"
- "Secukupnya gula merah"
- "Secukupnya gula putih"
- "Secukupnya lada bubuk"
- "Secukupnya penyedap rasa"
recipeinstructions:
- "Cuci bersih ayam. Kemudian goreng sebentar setengah matang dengan dilumuri bubuk bawang putih. Ketumbar. kunyit dan garam"
- "Kemudian haluskan semua bumbu halus. Kemudian tumis beserta bahan cemplung sampai harum dan matang"
- "Setelah harum dan matang tambahkan air sebanyak 1½gelas belimbing. Masukan pula ayamnya. Tambahkan juga bumbu penyedap lainnya seperti garam dll."
- "Masan hingga sampai sedikit menyusut. Lalu masukan daun bawang iris dan kemangi"
- "Masak hingga benar2 matang dan airnya menyusut"
- "Koreksi rasa dahulu.dirasa cukup. Angkat dan sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 107 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/99a36fb1d5ebc3ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga empuk. Ciri makanan Nusantara ayam rica rica kemangi yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kedekatan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Ayam rica rica kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang dapat anda buat salah satunya ayam rica rica kemangi yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi:

1. Harap siapkan 1/2 kg ayam
1. Diperlukan  Bumbu halus:
1. Harap siapkan 5 siung bawang putih
1. Dibutuhkan 5 siung bawang merah
1. Harus ada 20 buah cabe merah keriting
1. Siapkan 5-10 buah cabe rawit
1. Jangan lupa 1 butir kemiri (sangrai dulu)
1. Dibutuhkan Sedikit ketumbar
1. Siapkan  Bahan cemplung :
1. Dibutuhkan 1 ruas lengkuas
1. Harus ada 3 lembar daun salam
1. Harap siapkan 3 lembar daun jeruk
1. Harus ada 1 batang serai
1. Siapkan 1 buah tomat
1. Tambah  ~~~
1. Tambah 1 ikat daun kemangi
1. Diperlukan 1 batang daun bawang
1. Dibutuhkan Secukupnya garam
1. Tambah Secukupnya gula merah
1. Dibutuhkan Secukupnya gula putih
1. Diperlukan Secukupnya lada bubuk
1. Harap siapkan Secukupnya penyedap rasa


Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica kemangi:

1. Cuci bersih ayam. Kemudian goreng sebentar setengah matang dengan dilumuri bubuk bawang putih. Ketumbar. kunyit dan garam
1. Kemudian haluskan semua bumbu halus. Kemudian tumis beserta bahan cemplung sampai harum dan matang
1. Setelah harum dan matang tambahkan air sebanyak 1½gelas belimbing. Masukan pula ayamnya. Tambahkan juga bumbu penyedap lainnya seperti garam dll.
1. Masan hingga sampai sedikit menyusut. Lalu masukan daun bawang iris dan kemangi
1. Masak hingga benar2 matang dan airnya menyusut
1. Koreksi rasa dahulu.dirasa cukup. Angkat dan sajikan


Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Siapa yang tidak mengenal lalapan daun kemangi di Indonesia ini. Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. 

Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat gampang dan cepat, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
