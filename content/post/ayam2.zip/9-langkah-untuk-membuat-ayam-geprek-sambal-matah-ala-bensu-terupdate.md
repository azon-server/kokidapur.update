---
description: "Langkah untuk membuat Ayam Geprek Sambal Matah (Ala Bensu) terupdate"
title: "Langkah untuk membuat Ayam Geprek Sambal Matah (Ala Bensu) terupdate"
slug: 9-langkah-untuk-membuat-ayam-geprek-sambal-matah-ala-bensu-terupdate
date: 2020-09-18T03:34:50.673Z
image: https://img-global.cpcdn.com/recipes/97262496537ad729/751x532cq70/ayam-geprek-sambal-matah-ala-bensu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/97262496537ad729/751x532cq70/ayam-geprek-sambal-matah-ala-bensu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/97262496537ad729/751x532cq70/ayam-geprek-sambal-matah-ala-bensu-foto-resep-utama.jpg
author: Lulu Williamson
ratingvalue: 4.3
reviewcount: 19260
recipeingredient:
- "3 potong ayam bag dada ukuran besar"
- "1 bungkus kecil tepung bumbu serba guna pedas Me  Sajiku"
- " Sambal matah"
- "20-30 cabe setan"
- "3 siung bawang merah"
- "3 siung bawang putih"
- "1 batang sereh ambil setengah ke arah bonggolnya"
- "1 sdt air perasan jeruk nipis"
- " Tambahan"
- " Terong goreng tepung"
- " Kol goreng"
recipeinstructions:
- "Sayat 3 tiap bagian ayam, supaya matang merata dan bumbu meresap keseluruh bagian ayam. Marinasi ayam minimal 1jam dengan satu sendok tepung bumbu dan air secukupnya sampai semua bagian ayam tertutup larutan bumbunya."
- "Panaskan minyak goreng agak banyak, kira2 ayam terendam diminyak, diapi sedang saja ya. Siapkan tepung bumbu di wadah kering. Angkat ayam dari rendaman, lalu letakkan di tempat tepung kering tadi, dan balurkan seluruh bagian ayam hingga tertutup tepung seluruhnya. Lalu masukkan ke minyak yang sudah panas, apinya jangan terlalu besar, biar matang semua."
- "Iris halus semua bahan sambal matah, saya cabe rawit setannya ini di uleg kasar,tapi diiris juga gapapa kok 😁 siapkan diwadah tahan panas, lalu beri air perasan daun jeruk, sejumput garam, dan sedikit gula pasir. Kemudian siram dengan 5 sdm minyak panas, atau boleh lebih kalau dirasa kurang."
- "Ayam yang sudah matang, angkat dan tiriskan. Selagi hangat geprek ayam dengan batu ulegan. Nah di step ini sesuai selera kalian mau sampai bebeg banget apa gimana bentuk ayamnya."
- "Tata di atas piring, bersama sajian tambahan seperti terong goreng, kol goreng. Boleh juga dikasih timun, tempe, tahu, dll. Siram sambal matah tadi keatas potongan ayam."
categories:
- Recipe
tags:
- ayam
- geprek
- sambal

katakunci: ayam geprek sambal 
nutrition: 174 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Geprek Sambal Matah (Ala Bensu)](https://img-global.cpcdn.com/recipes/97262496537ad729/751x532cq70/ayam-geprek-sambal-matah-ala-bensu-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis dan renyah. Ciri khas makanan Indonesia ayam geprek sambal matah (ala bensu) yang kaya dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan keluarga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Ayam Geprek Sambal Matah (Ala Bensu) untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang bisa anda contoh salah satunya ayam geprek sambal matah (ala bensu) yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep ayam geprek sambal matah (ala bensu) tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Sambal Matah (Ala Bensu) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 11 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Sambal Matah (Ala Bensu):

1. Harus ada 3 potong ayam, bag dada ukuran besar
1. Diperlukan 1 bungkus kecil tepung bumbu serba guna pedas (Me : Sajiku)
1. Harap siapkan  Sambal matah
1. Diperlukan 20-30 cabe setan
1. Dibutuhkan 3 siung bawang merah
1. Tambah 3 siung bawang putih
1. Dibutuhkan 1 batang sereh, ambil setengah ke arah bonggolnya
1. Dibutuhkan 1 sdt air perasan jeruk nipis
1. Jangan lupa  Tambahan
1. Diperlukan  Terong goreng tepung
1. Siapkan  Kol goreng




<!--inarticleads2-->

##### Langkah membuat  Ayam Geprek Sambal Matah (Ala Bensu):

1. Sayat 3 tiap bagian ayam, supaya matang merata dan bumbu meresap keseluruh bagian ayam. Marinasi ayam minimal 1jam dengan satu sendok tepung bumbu dan air secukupnya sampai semua bagian ayam tertutup larutan bumbunya.
1. Panaskan minyak goreng agak banyak, kira2 ayam terendam diminyak, diapi sedang saja ya. Siapkan tepung bumbu di wadah kering. Angkat ayam dari rendaman, lalu letakkan di tempat tepung kering tadi, dan balurkan seluruh bagian ayam hingga tertutup tepung seluruhnya. Lalu masukkan ke minyak yang sudah panas, apinya jangan terlalu besar, biar matang semua.
1. Iris halus semua bahan sambal matah, saya cabe rawit setannya ini di uleg kasar,tapi diiris juga gapapa kok 😁 siapkan diwadah tahan panas, lalu beri air perasan daun jeruk, sejumput garam, dan sedikit gula pasir. Kemudian siram dengan 5 sdm minyak panas, atau boleh lebih kalau dirasa kurang.
1. Ayam yang sudah matang, angkat dan tiriskan. Selagi hangat geprek ayam dengan batu ulegan. Nah di step ini sesuai selera kalian mau sampai bebeg banget apa gimana bentuk ayamnya.
1. Tata di atas piring, bersama sajian tambahan seperti terong goreng, kol goreng. Boleh juga dikasih timun, tempe, tahu, dll. Siram sambal matah tadi keatas potongan ayam.




Demikianlah cara membuat ayam geprek sambal matah (ala bensu) yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
