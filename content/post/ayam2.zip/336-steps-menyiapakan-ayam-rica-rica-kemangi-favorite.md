---
description: "Steps menyiapakan Ayam Rica-rica Kemangi Favorite"
title: "Steps menyiapakan Ayam Rica-rica Kemangi Favorite"
slug: 336-steps-menyiapakan-ayam-rica-rica-kemangi-favorite
date: 2020-08-20T02:36:25.397Z
image: https://img-global.cpcdn.com/recipes/93023f691bb65a63/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/93023f691bb65a63/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/93023f691bb65a63/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Lucinda Medina
ratingvalue: 4.9
reviewcount: 36752
recipeingredient:
- "1/2 ekor Ayam"
- " Daun kemangi secukupnya"
- "secukupnya Air"
- " Bahan yg dihaluskan"
- "7 siung bawang merah"
- "4 siung bawang putih"
- "5 buah cabai merah sesuai selera"
- "4 buah cabai rawit"
- "4 butir kemiri"
- "secukupnya Ketumbar"
- "1 ruas jahe"
- "1 sdm garam"
- "1/2 sdt gula pasir"
- "1/2 sdt kaldu bubuk"
recipeinstructions:
- "Bersihkan ayam, goreng ayam setengah matang, lalu angkat"
- "Sambil menunggu ayam digoreng, kita buat bumbunya. Haluskan semua bumbu boleh diulek atau diblender"
- "Setelah ayam dan bumbu sudah siap. Siapkan wajan yg sudah diberikan minyak, masukan bumbu yg sudah dihaluskan dan tumis hingga harum dan warnanya berubah menjadi coklat"
- "Masukan ayam kedalam bumbu, aduk hingga rata. Jika sudah tercampur, masukan air kira2 setengah gelas atau secukupnya sampai ayam empuk"
- "Jika sudah empuk dan airnya menyusut, koreksi rasa yaa, jika sudah okeee tambahkan daun kemangi yg sudah dicuci bersih, aduk hingga rata."
- "Ayam siapp disajikannn, makannya pake nasi hangatttt heummmm dijamin endeusss, selamat mencoba 🤗"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 160 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/93023f691bb65a63/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica-rica kemangi yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa ciri khas yang merupakan keragaman Indonesia

Kedekatan keluarga bisa didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica-rica Kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang dapat anda contoh salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Kemangi:

1. Dibutuhkan 1/2 ekor Ayam
1. Harus ada  Daun kemangi (secukupnya)
1. Harap siapkan secukupnya Air
1. Jangan lupa  Bahan yg dihaluskan
1. Harus ada 7 siung bawang merah
1. Harap siapkan 4 siung bawang putih
1. Harap siapkan 5 buah cabai merah (sesuai selera)
1. Harap siapkan 4 buah cabai rawit
1. Diperlukan 4 butir kemiri
1. Siapkan secukupnya Ketumbar
1. Diperlukan 1 ruas jahe
1. Harap siapkan 1 sdm garam
1. Siapkan 1/2 sdt gula pasir
1. Dibutuhkan 1/2 sdt kaldu bubuk




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-rica Kemangi:

1. Bersihkan ayam, goreng ayam setengah matang, lalu angkat
1. Sambil menunggu ayam digoreng, kita buat bumbunya. Haluskan semua bumbu boleh diulek atau diblender
1. Setelah ayam dan bumbu sudah siap. Siapkan wajan yg sudah diberikan minyak, masukan bumbu yg sudah dihaluskan dan tumis hingga harum dan warnanya berubah menjadi coklat
1. Masukan ayam kedalam bumbu, aduk hingga rata. Jika sudah tercampur, masukan air kira2 setengah gelas atau secukupnya sampai ayam empuk
1. Jika sudah empuk dan airnya menyusut, koreksi rasa yaa, jika sudah okeee tambahkan daun kemangi yg sudah dicuci bersih, aduk hingga rata.
1. Ayam siapp disajikannn, makannya pake nasi hangatttt heummmm dijamin endeusss, selamat mencoba 🤗




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan teruji, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
