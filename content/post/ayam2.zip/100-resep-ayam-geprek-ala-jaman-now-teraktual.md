---
description: "Resep : Ayam geprek ala jaman now teraktual"
title: "Resep : Ayam geprek ala jaman now teraktual"
slug: 100-resep-ayam-geprek-ala-jaman-now-teraktual
date: 2020-12-13T21:42:39.959Z
image: https://img-global.cpcdn.com/recipes/af73cf4a452220c4/751x532cq70/ayam-geprek-ala-jaman-now-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/af73cf4a452220c4/751x532cq70/ayam-geprek-ala-jaman-now-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/af73cf4a452220c4/751x532cq70/ayam-geprek-ala-jaman-now-foto-resep-utama.jpg
author: Dean Ward
ratingvalue: 4.8
reviewcount: 10230
recipeingredient:
- "3 potong ayam kalo bisa dada tp aku pake apa aja sih"
- "1/2 bungkus Tepung serbaguna  sesuai keinginan untuk ketepungny"
- "secukupnya Tepung sagu"
- "1 bungkus Ladaku"
- "sesuai selera Cabai merah"
- "sesuai selera Cabai rawit merah"
- "2 siung bawang putih"
- "3 siung bawang merah"
- " Garam"
- " Minyak"
- " Jeruk nipis"
- " Gula"
recipeinstructions:
- "Cuci bersih ayam. Lalu geprek2 dengan ulekan lalu lumuri garam, ladaku, dan jeruk nipis secukupnya. Lalu diamkan sebentar."
- "Siapkan dua wadah untuk tepung kering dan tepung basah. Bagi tepung serbaguna kedlm dua wadah tsb lalu tambahkan sedikit tepung sagu. Untuk yg tepung basah gunakan air es dan aduk sampai kental."
- "Jangan lupa memberi ladaku di setiap tepung."
- "Goreng ayam seperti biasanya. Gulingkan ketepung basah lalu ketepung kering lalu di remas2. Ulangi sampai mendapatkan ketebalan yg sesuai keinginan. Lalu goreng sampai berwarna kekuningan."
- "Untuk sambalnya. Goreng semua cabai dan bawang2 an ke minyak bekas menggoreng ayam. Jgn terlalu lama, angkat dan taruh di cobek. Tambahkan sedikit minyak panas yg bekas goreng ayam, garam dan gula. Ulek dan tes rasa."
- "Letakan ayam yg sudah di goreng di piring saji. Geprek ayamnya sampai terbuka lalu lumuri dengan sambal dan di geprek lagi supaya sambalnya meresap. Dan taraaa ayam geprek jaman now siap di nikmati. Semoga suka ya."
categories:
- Recipe
tags:
- ayam
- geprek
- ala

katakunci: ayam geprek ala 
nutrition: 134 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam geprek ala jaman now](https://img-global.cpcdn.com/recipes/af73cf4a452220c4/751x532cq70/ayam-geprek-ala-jaman-now-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang patut kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam geprek ala jaman now yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan ciri khas yang merupakan keragaman Nusantara



Kehangatan keluarga bisa didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam geprek ala jaman now untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang bisa anda buat salah satunya ayam geprek ala jaman now yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam geprek ala jaman now tanpa harus bersusah payah.
Seperti resep Ayam geprek ala jaman now yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam geprek ala jaman now:

1. Siapkan 3 potong ayam, kalo bisa dada tp aku pake apa aja sih
1. Harus ada 1/2 bungkus Tepung serbaguna  sesuai keinginan untuk ketepungny
1. Jangan lupa secukupnya Tepung sagu
1. Jangan lupa 1 bungkus Ladaku
1. Diperlukan sesuai selera Cabai merah
1. Diperlukan sesuai selera Cabai rawit merah
1. Harus ada 2 siung bawang putih
1. Diperlukan 3 siung bawang merah
1. Dibutuhkan  Garam
1. Dibutuhkan  Minyak
1. Siapkan  Jeruk nipis
1. Siapkan  Gula




<!--inarticleads2-->

##### Instruksi membuat  Ayam geprek ala jaman now:

1. Cuci bersih ayam. Lalu geprek2 dengan ulekan lalu lumuri garam, ladaku, dan jeruk nipis secukupnya. Lalu diamkan sebentar.
1. Siapkan dua wadah untuk tepung kering dan tepung basah. Bagi tepung serbaguna kedlm dua wadah tsb lalu tambahkan sedikit tepung sagu. Untuk yg tepung basah gunakan air es dan aduk sampai kental.
1. Jangan lupa memberi ladaku di setiap tepung.
1. Goreng ayam seperti biasanya. Gulingkan ketepung basah lalu ketepung kering lalu di remas2. Ulangi sampai mendapatkan ketebalan yg sesuai keinginan. Lalu goreng sampai berwarna kekuningan.
1. Untuk sambalnya. Goreng semua cabai dan bawang2 an ke minyak bekas menggoreng ayam. Jgn terlalu lama, angkat dan taruh di cobek. Tambahkan sedikit minyak panas yg bekas goreng ayam, garam dan gula. Ulek dan tes rasa.
1. Letakan ayam yg sudah di goreng di piring saji. Geprek ayamnya sampai terbuka lalu lumuri dengan sambal dan di geprek lagi supaya sambalnya meresap. Dan taraaa ayam geprek jaman now siap di nikmati. Semoga suka ya.




Demikianlah cara membuat ayam geprek ala jaman now yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
