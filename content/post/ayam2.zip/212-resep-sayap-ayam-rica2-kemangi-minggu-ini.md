---
description: "Resep : Sayap ayam rica2 kemangi minggu ini"
title: "Resep : Sayap ayam rica2 kemangi minggu ini"
slug: 212-resep-sayap-ayam-rica2-kemangi-minggu-ini
date: 2020-11-08T12:17:30.071Z
image: https://img-global.cpcdn.com/recipes/76352658dda49c58/751x532cq70/sayap-ayam-rica2-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/76352658dda49c58/751x532cq70/sayap-ayam-rica2-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/76352658dda49c58/751x532cq70/sayap-ayam-rica2-kemangi-foto-resep-utama.jpg
author: Marie Daniel
ratingvalue: 4.9
reviewcount: 1072
recipeingredient:
- "10 sayap ayam"
- "1 buah jeruk nipis"
- "3 ikat daun kemangi ambil daun nya"
- "2 batang daun bawang potong2"
- "1 buah tomat potong2"
- "4 lembar daun jeruk"
- "Seruas jshe"
- "2 batang sereh potong2"
- " Garam dan gula secukup nya"
- "1 sendok saos tiram"
- " Bumbu halus"
- "7 bawang merah"
- "5 bawang putih"
- "2 cm kunyit"
- "3 buah kemiri"
- "10 cabe merah"
- "8 cabe rawit"
recipeinstructions:
- "Cuci bersih sayap ayam,beri perasan jeruk nipis, diamkan beberapa saat, lalu cuci bersih"
- "Tumis bumbu halus,daun jeruk, jahe,sereh sampe wangi beri sedikit air,masukan ayam aduk rata lalu tutup"
- "Setelah ayam mateng beri garam,gula,saos tiram,cek rasa.lalu masukan daun bawang dan tomat masak sampe mateng,terakhir masukan daun kemangi"
- "Siap di sajikan dengan nasi"
categories:
- Recipe
tags:
- sayap
- ayam
- rica2

katakunci: sayap ayam rica2 
nutrition: 109 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Lunch

---


![Sayap ayam rica2 kemangi](https://img-global.cpcdn.com/recipes/76352658dda49c58/751x532cq70/sayap-ayam-rica2-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang patut kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti sayap ayam rica2 kemangi yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa keistimewahan yang merupakan keragaman Kita

Kedekatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Sayap ayam rica2 kemangi untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini!

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang bisa anda coba salah satunya sayap ayam rica2 kemangi yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep sayap ayam rica2 kemangi tanpa harus bersusah payah.
Seperti resep Sayap ayam rica2 kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sayap ayam rica2 kemangi:

1. Harus ada 10 sayap ayam
1. Tambah 1 buah jeruk nipis
1. Diperlukan 3 ikat daun kemangi ambil daun nya
1. Dibutuhkan 2 batang daun bawang potong2
1. Harap siapkan 1 buah tomat potong2
1. Harus ada 4 lembar daun jeruk
1. Jangan lupa Seruas jshe
1. Diperlukan 2 batang sereh potong2
1. Dibutuhkan  Garam dan gula secukup nya
1. Diperlukan 1 sendok saos tiram
1. Siapkan  Bumbu halus
1. Tambah 7 bawang merah
1. Harus ada 5 bawang putih
1. Dibutuhkan 2 cm kunyit
1. Dibutuhkan 3 buah kemiri
1. Siapkan 10 cabe merah
1. Siapkan 8 cabe rawit


Sebenarnya, untuk membuat rica-rica ayam itu hampir sama dengan kita mengolah ayam pedas lainnya, mungkin saja jumlah bumbu yang digunakan lebih bervariasi seperti: cabai, kunyit, serai, bawang merah dan sebagainya. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat memanjakan lidah. Untuk anda yang bosan dengan masakan ayam yang itu-itu saja, anda bisa. 

<!--inarticleads2-->

##### Cara membuat  Sayap ayam rica2 kemangi:

1. Cuci bersih sayap ayam,beri perasan jeruk nipis, diamkan beberapa saat, lalu cuci bersih
1. Tumis bumbu halus,daun jeruk, jahe,sereh sampe wangi beri sedikit air,masukan ayam aduk rata lalu tutup
1. Setelah ayam mateng beri garam,gula,saos tiram,cek rasa.lalu masukan daun bawang dan tomat masak sampe mateng,terakhir masukan daun kemangi
1. Siap di sajikan dengan nasi


Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat memanjakan lidah. Untuk anda yang bosan dengan masakan ayam yang itu-itu saja, anda bisa. Penjelasan lengkap seputar Resep Ayam Rica Rica Sederhana, Mudah, dan Praktis. Menggunakan Bumbu Pilihan dan Resep Tradisional dari Ayam rica-rica memang selalu memiliki tempat tersendiri dihati masyarakat Indonesia. Hanya dengan satu gigitan saja akan membuat semakin ketagihan. 

Demikianlah cara membuat sayap ayam rica2 kemangi yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan cepat, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
