---
description: "Resep : Ayam rica rica kemangi pedas Favorite"
title: "Resep : Ayam rica rica kemangi pedas Favorite"
slug: 190-resep-ayam-rica-rica-kemangi-pedas-favorite
date: 2020-09-03T21:09:55.157Z
image: https://img-global.cpcdn.com/recipes/6dff6933be852f07/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6dff6933be852f07/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6dff6933be852f07/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
author: Bill Alvarez
ratingvalue: 4
reviewcount: 47039
recipeingredient:
- "1 ekor ayam potong sesuai selera"
- "2 ikat kemangi petik daunnya"
- "4 btang daun bawang"
- "5 lembar daun jeruk"
- "3 btang serai geprek"
- " Garam gula dan kaldu bubuk"
- " Bumbu halus"
- "16 bawang merah"
- "8 siung bawang putih"
- "4 biji Lombok merah"
- "4 biji cabe ijo"
- "10 biji cabe keriting"
- "15 biji cabe rawit"
- "1 jari telunjuk kunyit"
- "1 jari telunjuk jahe"
- "6 butir kemiri sangrai"
- "secukupnya Air"
recipeinstructions:
- "Cuci bersih ayam(tiriskan dan sisihkan)"
- "Tumis bumbu halus sampai harum dan matang...kemudian masukkan ayam dan tambahkan sedikit air"
- "Masukkan bumbu2 kemudian koreksi rasa dan masak ayam sampai matang dan empuk"
- "Masukkan daun bawang dan kemangi aduk rata"
- "Rica rica ayam kemangi pedas pun sudah bisa disajikan😁"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 237 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica rica kemangi pedas](https://img-global.cpcdn.com/recipes/6dff6933be852f07/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica rica kemangi pedas yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Nusantara

Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah membuat makanan Ayam rica rica kemangi pedas untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

Rica-rica dalam bahasa Manado (Sulawesi Utara) berarti pedas atau cabe. dalam proses masaknya beraneka ragam. Masakan kali ini dengan menambah daun kemangi. Lihat juga resep Ayam Rica Kemangi Pedas Nampol enak lainnya. Bawang putih, cincang•cabe rawit merah (sesukanya, tergantung mau level berapa tingkat kepedasannya)•bawang bombay, cincang•ayam paha dan dada beli di Superindo (saya.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi resep yang dapat anda buat salah satunya ayam rica rica kemangi pedas yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep ayam rica rica kemangi pedas tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi pedas yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi pedas:

1. Diperlukan 1 ekor ayam potong sesuai selera
1. Jangan lupa 2 ikat kemangi petik daunnya
1. Harus ada 4 btang daun bawang
1. Siapkan 5 lembar daun jeruk
1. Siapkan 3 btang serai geprek
1. Tambah  Garam gula dan kaldu bubuk
1. Dibutuhkan  Bumbu halus:
1. Dibutuhkan 16 bawang merah
1. Tambah 8 siung bawang putih
1. Jangan lupa 4 biji Lombok merah
1. Harap siapkan 4 biji cabe ijo
1. Jangan lupa 10 biji cabe keriting
1. Jangan lupa 15 biji cabe rawit
1. Dibutuhkan 1 jari telunjuk kunyit
1. Dibutuhkan 1 jari telunjuk jahe
1. Diperlukan 6 butir kemiri sangrai
1. Dibutuhkan secukupnya Air


Resep ayam rica rica merupakan masakan selera pedas Resep rica rica sendiri sebenarnya tidak harus menggunakan bahan daging ayam saja. Cita rasa pedas menjadi ciri khas resep yang tergabung. Resep Ayam Rica - Rica Pedas Enak dan Spesial Untuk Keluarga - Asal muasal dari resep ayam rica-rica ini berasal dari daerah Manado - Sul. Rica merupakan bahasa Manado yang berarti pedas, bisa dimaknai bahwa kuliner ini merupakan ayam yang diberi bumbu pedas. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica kemangi pedas:

1. Cuci bersih ayam(tiriskan dan sisihkan)
1. Tumis bumbu halus sampai harum dan matang...kemudian masukkan ayam dan tambahkan sedikit air
1. Masukkan bumbu2 kemudian koreksi rasa dan masak ayam sampai matang dan empuk
1. Masukkan daun bawang dan kemangi aduk rata
1. Rica rica ayam kemangi pedas pun sudah bisa disajikan😁


Resep Ayam Rica - Rica Pedas Enak dan Spesial Untuk Keluarga - Asal muasal dari resep ayam rica-rica ini berasal dari daerah Manado - Sul. Rica merupakan bahasa Manado yang berarti pedas, bisa dimaknai bahwa kuliner ini merupakan ayam yang diberi bumbu pedas. Nah, untuk membuat resep Ayam Rica Kemangi khas Manado ini, tentu ada beberapa hal yang harus diperhatikan. Bumbu rica-rica khas Manado bisa dipadukan dengan aneka bahan, seperti ayam. Coba membuat ayam panggang bumbu rica-rica berdasarkan resep ini. 

Demikianlah cara membuat ayam rica rica kemangi pedas yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan teruji, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
