---
description: "Bagaimana untuk membuat Ayam Geprek Pedas teraktual"
title: "Bagaimana untuk membuat Ayam Geprek Pedas teraktual"
slug: 96-bagaimana-untuk-membuat-ayam-geprek-pedas-teraktual
date: 2020-09-06T07:00:24.312Z
image: https://img-global.cpcdn.com/recipes/c4061653beba5a2a/751x532cq70/ayam-geprek-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c4061653beba5a2a/751x532cq70/ayam-geprek-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c4061653beba5a2a/751x532cq70/ayam-geprek-pedas-foto-resep-utama.jpg
author: Lillie Harmon
ratingvalue: 5
reviewcount: 49429
recipeingredient:
- "1 buah dada ayam potong jd 2 bagian"
- " Jeruk nipis"
- "120 gr tepung terigu"
- "40 gr tapioka"
- "3 sdm maizena"
- "1 sdt Bawang putih bubuk"
- "1/2 sdt merica bubuk"
- "1/2 sdt garam"
- "1/2 sdt kaldu bubuk"
- " Minyak goreng untuk menggoreng"
- " Bahan sambal "
- "15 cabai rawit merah"
- "6 cabai merah keriting"
- "3 siung bawang putih"
- "3 siung bawang merah"
- "secukupnya Garam gula"
- " Pelengkap  aneka lalapan"
recipeinstructions:
- "Cuci ayam kemudian lumuri dgn perasan jeruk nipis, sisihkan"
- "Campur terigu, tapioka, maizena, tambahkan bawang putih bubuk, merica bubuk, garam, kaldu bubuk"
- "Ambir kurang lebih 3 1/2 sdm beri air untuk membuat adonan basah, jgn terlalu encer"
- "Masukkan ayam ke adonan basah, kemudian gulingkan di tepung yg kering dan goreng keemasan"
- "Haluskan semua bahan sambal, jgn terlalu halus kemudian tambahkan minyak goreng panas 1 sdm"
- "Kemudian ambil ayam yg sdh digoreng lalu penyet dgn sambal"
categories:
- Recipe
tags:
- ayam
- geprek
- pedas

katakunci: ayam geprek pedas 
nutrition: 150 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Geprek Pedas](https://img-global.cpcdn.com/recipes/c4061653beba5a2a/751x532cq70/ayam-geprek-pedas-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau enak. Ciri masakan Nusantara ayam geprek pedas yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga dapat diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam Geprek Pedas untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang bisa anda praktekkan salah satunya ayam geprek pedas yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam geprek pedas tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Pedas yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Pedas:

1. Harus ada 1 buah dada ayam, potong jd 2 bagian
1. Dibutuhkan  Jeruk nipis
1. Dibutuhkan 120 gr tepung terigu
1. Jangan lupa 40 gr tapioka
1. Dibutuhkan 3 sdm maizena
1. Diperlukan 1 sdt Bawang putih bubuk
1. Siapkan 1/2 sdt merica bubuk
1. Dibutuhkan 1/2 sdt garam
1. Dibutuhkan 1/2 sdt kaldu bubuk
1. Dibutuhkan  Minyak goreng untuk menggoreng
1. Harus ada  Bahan sambal :
1. Harus ada 15 cabai rawit merah
1. Tambah 6 cabai merah keriting
1. Diperlukan 3 siung bawang putih
1. Tambah 3 siung bawang merah
1. Harus ada secukupnya Garam, gula
1. Tambah  Pelengkap : aneka lalapan




<!--inarticleads2-->

##### Langkah membuat  Ayam Geprek Pedas:

1. Cuci ayam kemudian lumuri dgn perasan jeruk nipis, sisihkan
1. Campur terigu, tapioka, maizena, tambahkan bawang putih bubuk, merica bubuk, garam, kaldu bubuk
1. Ambir kurang lebih 3 1/2 sdm beri air untuk membuat adonan basah, jgn terlalu encer
1. Masukkan ayam ke adonan basah, kemudian gulingkan di tepung yg kering dan goreng keemasan
1. Haluskan semua bahan sambal, jgn terlalu halus kemudian tambahkan minyak goreng panas 1 sdm
1. Kemudian ambil ayam yg sdh digoreng lalu penyet dgn sambal




Demikianlah cara membuat ayam geprek pedas yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
