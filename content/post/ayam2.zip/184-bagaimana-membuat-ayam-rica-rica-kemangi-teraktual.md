---
description: "Bagaimana membuat Ayam Rica Rica Kemangi teraktual"
title: "Bagaimana membuat Ayam Rica Rica Kemangi teraktual"
slug: 184-bagaimana-membuat-ayam-rica-rica-kemangi-teraktual
date: 2020-10-27T12:49:12.939Z
image: https://img-global.cpcdn.com/recipes/c964aaaf094c7173/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c964aaaf094c7173/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c964aaaf094c7173/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Mario Park
ratingvalue: 4.5
reviewcount: 31347
recipeingredient:
- "5 potong Ayam"
- "10 buah cabe merah"
- " Kemiri"
- "5 bawang merah"
- "3 bawang putih"
- "Seruas kunyit jahe lengkuas"
- " Sereh daun jeruk daun salam"
- " Kacang panjang opsional"
- " Kemangi"
- " Garam gula dan kaldu jamur"
recipeinstructions:
- "Haluskan bawang merah, bawang putih, cabe merah, kemiri dan kunyit. Tumis bumbunya lalu masukkan sereh, jahe, lengkuas, daun jeruk dan daun salam"
- "Setelah harum masukkan ayam aduk2 dan masukkan air (sesuaikan aja) tunggu mendidih masukkan garam, gula, kaldu jamur"
- "Masukkan kacang panjang, aduk2 koreksi rasa.. sekiranya sudah mau masak tambahkan kemangi aduk2 sebentar dan sajikan!"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 284 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT46M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/c964aaaf094c7173/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang patut kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica rica kemangi yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa keistimewahan yang merupakan keragaman Nusantara



Keharmonisan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica Rica Kemangi untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang dapat anda coba salah satunya ayam rica rica kemangi yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Harap siapkan 5 potong Ayam
1. Tambah 10 buah cabe merah
1. Dibutuhkan  Kemiri
1. Jangan lupa 5 bawang merah
1. Siapkan 3 bawang putih
1. Harap siapkan Seruas kunyit, jahe, lengkuas
1. Tambah  Sereh, daun jeruk, daun salam
1. Dibutuhkan  Kacang panjang (opsional)
1. Jangan lupa  Kemangi
1. Dibutuhkan  Garam, gula, dan kaldu jamur




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica Kemangi:

1. Haluskan bawang merah, bawang putih, cabe merah, kemiri dan kunyit. Tumis bumbunya lalu masukkan sereh, jahe, lengkuas, daun jeruk dan daun salam
1. Setelah harum masukkan ayam aduk2 dan masukkan air (sesuaikan aja) tunggu mendidih masukkan garam, gula, kaldu jamur
1. Masukkan kacang panjang, aduk2 koreksi rasa.. sekiranya sudah mau masak tambahkan kemangi aduk2 sebentar dan sajikan!




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan teruji, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
