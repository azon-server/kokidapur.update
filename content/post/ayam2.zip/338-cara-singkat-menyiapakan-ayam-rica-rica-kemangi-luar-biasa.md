---
description: "Cara singkat menyiapakan Ayam Rica Rica Kemangi Luar biasa"
title: "Cara singkat menyiapakan Ayam Rica Rica Kemangi Luar biasa"
slug: 338-cara-singkat-menyiapakan-ayam-rica-rica-kemangi-luar-biasa
date: 2020-09-23T04:18:28.264Z
image: https://img-global.cpcdn.com/recipes/362b2674083c9256/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/362b2674083c9256/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/362b2674083c9256/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Marion Phillips
ratingvalue: 4.9
reviewcount: 37202
recipeingredient:
- "1 ekor ayam potong kecil2 aku jadi 20bag"
- "2 bh serai geprek"
- "1 jempol lengkuas geprek"
- "4 lbr daun jeruk"
- "500 ml air"
- "1 sdt gula pasir"
- "2 sdt garam"
- "1 sdt kaldu ayam bubuk"
- "2 ikat kemangi siangi cuci bersih"
- " Bumbu halus"
- "10 siung bawang merah"
- "8 siung bawang putih"
- "1 sdt kunir bubuk atau 2 ruas jari kunir"
- "1 jempol jahe"
- " Blenderuleg kasar"
- "6 bh cabe merah buang bijinya"
- "Secukupnya cabe rawit"
recipeinstructions:
- "Tumis bumbu halus, cabe, serai, daun jeruk dan lengkuas sampe harum dan matang. Masukkan ayam, aduk2 sampe berubah warna. Tambahkan air, aduk2, masukkan gula, garam, kaldu bubuk. Masak sampe empuk. Kalo pake ayam kampung air harus ditambah bbrp kali supaya ndak kering, krn lebih masak ayam kampung butuh waktu lebih lama."
- "Kalo udah empuk, tes rasa, masukkan kemangi, aduk sebentar sampe daun layu. Angkat!"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 295 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/362b2674083c9256/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan renyah. Karasteristik kuliner Nusantara ayam rica rica kemangi yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica Rica Kemangi untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang bisa anda buat salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu bisa dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 bahan dan 2 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Siapkan 1 ekor ayam, potong kecil2 (aku jadi 20bag)
1. Harus ada 2 bh serai, geprek
1. Harus ada 1 jempol lengkuas, geprek
1. Harap siapkan 4 lbr daun jeruk
1. Siapkan 500 ml air
1. Diperlukan 1 sdt gula pasir
1. Siapkan 2 sdt garam
1. Siapkan 1 sdt kaldu ayam bubuk
1. Siapkan 2 ikat kemangi, siangi, cuci bersih
1. Jangan lupa  Bumbu halus:
1. Harap siapkan 10 siung bawang merah
1. Dibutuhkan 8 siung bawang putih
1. Harus ada 1 sdt kunir bubuk atau 2 ruas jari kunir
1. Diperlukan 1 jempol jahe
1. Harus ada  Blender/uleg kasar:
1. Dibutuhkan 6 bh cabe merah, buang bijinya
1. Siapkan Secukupnya cabe rawit




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Rica Kemangi:

1. Tumis bumbu halus, cabe, serai, daun jeruk dan lengkuas sampe harum dan matang. Masukkan ayam, aduk2 sampe berubah warna. Tambahkan air, aduk2, masukkan gula, garam, kaldu bubuk. Masak sampe empuk. Kalo pake ayam kampung air harus ditambah bbrp kali supaya ndak kering, krn lebih masak ayam kampung butuh waktu lebih lama.
1. Kalo udah empuk, tes rasa, masukkan kemangi, aduk sebentar sampe daun layu. Angkat!




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
