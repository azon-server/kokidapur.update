---
description: "Cara untuk menyiapakan Ayam Rica Kemangi Luar biasa"
title: "Cara untuk menyiapakan Ayam Rica Kemangi Luar biasa"
slug: 275-cara-untuk-menyiapakan-ayam-rica-kemangi-luar-biasa
date: 2020-08-15T21:33:53.818Z
image: https://img-global.cpcdn.com/recipes/e7295e6a910923cb/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e7295e6a910923cb/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e7295e6a910923cb/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Matthew Casey
ratingvalue: 4.7
reviewcount: 39455
recipeingredient:
- "500 gr dada ayam"
- "50 gr daun kemangi sesuai selera"
- "2 bh sereh"
- "200 gr cabai rawit"
- "1/2 sdt kemiri bubuk"
- "2 lembar daun jeruk"
- "1 ruas jahe"
- "4 siung bawang putih"
- "2 siung bawang merah"
- "500 ml air"
- "1/2 sdm garam halus"
- "1/2 sdt penyedap totole"
recipeinstructions:
- "Cuci bersih ayam, potong dadu. Sisihkan"
- "Haluskan bawang putih, bawang merah, cabai rawit. Geprek jahe dan serai. Rajang daun jeruk."
- "Panaskan minyak. Masukkan smua bumbu di langkah 2.. Masukkan garam &amp; penyedap. Tumis hingga harum"
- "Masukkan dada ayam. Didihkan 10 mnit. Masukkan daun kemangi aduk-aduk.Matikan kompor, tutup rapat wajan. Cara ini digunakan supaya daging cepat empuk. lebih efektif dan irit gas. Diamkan selama 10-15 menit (tutup tidak boleh dibuka). Setelah itu nyalakan lg hingga daging matang merata"
- "Koreksi rasa. Sajikan dengan nasi panas. Selamat mencoba 🙏☺"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 134 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT57M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/e7295e6a910923cb/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica kemangi yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa keistimewahan yang merupakan keragaman Nusantara



Keharmonisan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam Rica Kemangi untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang bisa anda contoh salah satunya ayam rica kemangi yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 12 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Siapkan 500 gr dada ayam
1. Jangan lupa 50 gr daun kemangi (sesuai selera)
1. Siapkan 2 bh sereh
1. Siapkan 200 gr cabai rawit
1. Diperlukan 1/2 sdt kemiri bubuk
1. Diperlukan 2 lembar daun jeruk
1. Jangan lupa 1 ruas jahe
1. Harap siapkan 4 siung bawang putih
1. Tambah 2 siung bawang merah
1. Jangan lupa 500 ml air
1. Harus ada 1/2 sdm garam halus
1. Jangan lupa 1/2 sdt penyedap (totole)




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Kemangi:

1. Cuci bersih ayam, potong dadu. Sisihkan
1. Haluskan bawang putih, bawang merah, cabai rawit. Geprek jahe dan serai. Rajang daun jeruk.
1. Panaskan minyak. Masukkan smua bumbu di langkah 2.. Masukkan garam &amp; penyedap. Tumis hingga harum
1. Masukkan dada ayam. Didihkan 10 mnit. Masukkan daun kemangi aduk-aduk.Matikan kompor, tutup rapat wajan. Cara ini digunakan supaya daging cepat empuk. lebih efektif dan irit gas. Diamkan selama 10-15 menit (tutup tidak boleh dibuka). Setelah itu nyalakan lg hingga daging matang merata
1. Koreksi rasa. Sajikan dengan nasi panas. Selamat mencoba 🙏☺




Demikianlah cara membuat ayam rica kemangi yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan cepat, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
