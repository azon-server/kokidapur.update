---
description: "Cara singkat membuat Ayam Geprek Bensu Kw minggu ini"
title: "Cara singkat membuat Ayam Geprek Bensu Kw minggu ini"
slug: 36-cara-singkat-membuat-ayam-geprek-bensu-kw-minggu-ini
date: 2020-09-09T13:38:39.787Z
image: https://img-global.cpcdn.com/recipes/99701943644be70c/751x532cq70/ayam-geprek-bensu-kw-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/99701943644be70c/751x532cq70/ayam-geprek-bensu-kw-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/99701943644be70c/751x532cq70/ayam-geprek-bensu-kw-foto-resep-utama.jpg
author: Warren Russell
ratingvalue: 4.4
reviewcount: 17742
recipeingredient:
- "5 potong ayam"
- "5 siung bawang putih"
- "1/2 sdt merica"
- "5 sdm tepung gandum me  segitiga biru"
- "2 sdm tepung maizena"
- "1 butir telur ayam"
- "10 bh rawit setan rawit guede warna oren klo d tempatku"
- " Secukupnya gula garam  kaldu bubuk royco"
recipeinstructions:
- "Marinasi ayam pd mlm sbelumnya klo tuk di masak besok siangnya. Ato min 2 jam sbelumnya supaya bumbunya meresap ke ayam"
- "Bumbu marinasi :"
- "2 bawang putih giling + 1/2 sdt merica + 1 sdt garam + 1/2 sdt kaldu bubuk. Remas2 ayam sampai bumbunya merata lalu masukkan ke kulkas bgian bawah aja ya bun jgn yg freezer"
- "Stlh d diamkan minimal 2 jam td kluarkan ayamnya, lalu pecahkan telur ayamnya ke marinasi ayam td remas2 lagi ayamnya lalu sisihkan"
- "Tuangkan tepung terigu &amp; maizenanya ke piring lalu aduk rata"
- "Masukkan ayam yg sdh d remas telur td ke dalam tepung sambil d cubit2 supaya pas ntar d goreng kluar kriting2 tepungnya pas sdh slesai nepungin ayamnya jgn lupa di hentak2an ayamnya ke piring spy tepungnya kokoh pd saat mau d goreng"
- "Taroh ke piring terpisah ayam yg sdh di tepungin td. Plg tidak tunggu agak 5-10 menit sblum di goreng"
- "Panaskan minyak banyak sekiranya ayam bakal tenggelam pd saat menggoreng. Klo takut hbs banyak minyak, bisa goreng menggunakan panci kecil. Karena ntar minyak hasil goreng ayamnya bakal menghitam &amp; bakal ada serbuk tepungnya d bgian bawah kuali/wajan/panci penggorengannya jgn lupa gunakan api kecil pd saat menggoreng ya bun. Supaya ayam matang merata sampai ke tulang. Goreng ayam hingga berwarna coklat keemasan. Lalu tiriskan."
- "Cara buat sambal gepreknya :"
- "Goreng 3 siung bawang putih stelah itu giling bersama rawit setannya skalian tambah garam, gula &amp; kaldu bubuknya. Trus icip ssuai slera ya.. sy gunakan awalnya 1/2 sdt gula, garam &amp; kaldu bubuknya."
- "Goreng 3 siung bawang putih stelah itu giling bersama rawit setannya skalian tambah garam, gula &amp; kaldu bubuknya. Trus icip ssuai slera ya.. sy gunakan awalnya 1/2 sdt gula, garam &amp; kaldu bubuknya."
- "Oleskan 1 sdt cabe gepreknya ke permukaan ayam goreng td lalu geprek di atas cobek/penggilingan cabe. Saya ga semua ayam lgsg di cabein &amp; di geprek ya bun. Pas gt mau makan aja baru di geprekin satu persatu. Jgn lupa lalapannya ya bun.. sy cm pke timun. Kemangi dkk lg ga nyetok 😆"
- "Selamat mencoba.. jgn lupa di recook ya.."
categories:
- Recipe
tags:
- ayam
- geprek
- bensu

katakunci: ayam geprek bensu 
nutrition: 269 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Geprek Bensu Kw](https://img-global.cpcdn.com/recipes/99701943644be70c/751x532cq70/ayam-geprek-bensu-kw-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau empuk. Ciri makanan Nusantara ayam geprek bensu kw yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.




Keharmonisan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Ayam Geprek Bensu Kw untuk keluarga. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang bisa anda contoh salah satunya ayam geprek bensu kw yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep ayam geprek bensu kw tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Bensu Kw yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 13 langkah dan 8 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Bensu Kw:

1. Tambah 5 potong ayam
1. Harus ada 5 siung bawang putih
1. Siapkan 1/2 sdt merica
1. Siapkan 5 sdm tepung gandum (me = segitiga biru)
1. Dibutuhkan 2 sdm tepung maizena
1. Harus ada 1 butir telur ayam
1. Dibutuhkan 10 bh rawit setan (rawit guede warna oren klo d tempatku)
1. Harus ada  Secukupnya gula, garam &amp; kaldu bubuk (royco)




<!--inarticleads2-->

##### Langkah membuat  Ayam Geprek Bensu Kw:

1. Marinasi ayam pd mlm sbelumnya klo tuk di masak besok siangnya. Ato min 2 jam sbelumnya supaya bumbunya meresap ke ayam
1. Bumbu marinasi :
1. 2 bawang putih giling + 1/2 sdt merica + 1 sdt garam + 1/2 sdt kaldu bubuk. Remas2 ayam sampai bumbunya merata lalu masukkan ke kulkas bgian bawah aja ya bun jgn yg freezer
1. Stlh d diamkan minimal 2 jam td kluarkan ayamnya, lalu pecahkan telur ayamnya ke marinasi ayam td remas2 lagi ayamnya lalu sisihkan
1. Tuangkan tepung terigu &amp; maizenanya ke piring lalu aduk rata
1. Masukkan ayam yg sdh d remas telur td ke dalam tepung sambil d cubit2 supaya pas ntar d goreng kluar kriting2 tepungnya pas sdh slesai nepungin ayamnya jgn lupa di hentak2an ayamnya ke piring spy tepungnya kokoh pd saat mau d goreng
1. Taroh ke piring terpisah ayam yg sdh di tepungin td. Plg tidak tunggu agak 5-10 menit sblum di goreng
1. Panaskan minyak banyak sekiranya ayam bakal tenggelam pd saat menggoreng. Klo takut hbs banyak minyak, bisa goreng menggunakan panci kecil. Karena ntar minyak hasil goreng ayamnya bakal menghitam &amp; bakal ada serbuk tepungnya d bgian bawah kuali/wajan/panci penggorengannya jgn lupa gunakan api kecil pd saat menggoreng ya bun. Supaya ayam matang merata sampai ke tulang. Goreng ayam hingga berwarna coklat keemasan. Lalu tiriskan.
1. Cara buat sambal gepreknya :
1. Goreng 3 siung bawang putih stelah itu giling bersama rawit setannya skalian tambah garam, gula &amp; kaldu bubuknya. Trus icip ssuai slera ya.. sy gunakan awalnya 1/2 sdt gula, garam &amp; kaldu bubuknya.
1. Goreng 3 siung bawang putih stelah itu giling bersama rawit setannya skalian tambah garam, gula &amp; kaldu bubuknya. Trus icip ssuai slera ya.. sy gunakan awalnya 1/2 sdt gula, garam &amp; kaldu bubuknya.
1. Oleskan 1 sdt cabe gepreknya ke permukaan ayam goreng td lalu geprek di atas cobek/penggilingan cabe. Saya ga semua ayam lgsg di cabein &amp; di geprek ya bun. Pas gt mau makan aja baru di geprekin satu persatu. Jgn lupa lalapannya ya bun.. sy cm pke timun. Kemangi dkk lg ga nyetok 😆
1. Selamat mencoba.. jgn lupa di recook ya..




Demikianlah cara membuat ayam geprek bensu kw yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
