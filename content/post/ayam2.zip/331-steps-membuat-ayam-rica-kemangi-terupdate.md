---
description: "Steps membuat Ayam Rica Kemangi terupdate"
title: "Steps membuat Ayam Rica Kemangi terupdate"
slug: 331-steps-membuat-ayam-rica-kemangi-terupdate
date: 2020-12-15T20:13:58.937Z
image: https://img-global.cpcdn.com/recipes/eb48c57271360aaa/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/eb48c57271360aaa/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/eb48c57271360aaa/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Christian Wells
ratingvalue: 4.4
reviewcount: 44418
recipeingredient:
- "1/2 kg ayam"
- "1 ikat kemangi"
- "3 lembar daun jeruk"
- "1 btg sereh"
- "1 jempol lengkuas geprek"
- "300 ml air matang"
- " Gula"
- " Garam"
- " Royco ayam"
- " Bumbu halus"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "1 ruas jari kunyit kunyit bubuk"
- " Uleg kasar"
- "3 biji cabai merah besar"
- "8 biji cabai rawit"
recipeinstructions:
- "Tumis bumbu halus, cabe, daun jeruk, sereh, dan lengkuas hingga harum. Masukan ayam, aduk rata hingga berubah warna"
- "Tambahkan air (jika pake ayam kampung perlu air lebih banyak) masak sampai ayam empuk dan menyusut"
- "Bumbui gula, garam, dan royco ayam lalu test rasa"
- "Terakhir masukan daun kemangi, aduk rata hingga kemangi layu dan harum. Matikan api, SAJIKAN DENGAN NASI HANGAT 😍"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 261 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/eb48c57271360aaa/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan empuk. Ciri masakan Indonesia ayam rica kemangi yang penuh dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan rumah tangga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Ayam Rica Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang bisa anda contoh salah satunya ayam rica kemangi yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Dibutuhkan 1/2 kg ayam
1. Harap siapkan 1 ikat kemangi
1. Harap siapkan 3 lembar daun jeruk
1. Jangan lupa 1 btg sereh
1. Harus ada 1 jempol lengkuas (geprek)
1. Tambah 300 ml air matang
1. Diperlukan  Gula
1. Jangan lupa  Garam
1. Tambah  Royco ayam
1. Tambah  Bumbu halus
1. Harap siapkan 6 siung bawang merah
1. Tambah 4 siung bawang putih
1. Dibutuhkan 1 ruas jari kunyit (kunyit bubuk)
1. Siapkan  Uleg kasar
1. Harap siapkan 3 biji cabai merah besar
1. Siapkan 8 biji cabai rawit




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Kemangi:

1. Tumis bumbu halus, cabe, daun jeruk, sereh, dan lengkuas hingga harum. Masukan ayam, aduk rata hingga berubah warna
1. Tambahkan air (jika pake ayam kampung perlu air lebih banyak) masak sampai ayam empuk dan menyusut
1. Bumbui gula, garam, dan royco ayam lalu test rasa
1. Terakhir masukan daun kemangi, aduk rata hingga kemangi layu dan harum. Matikan api, SAJIKAN DENGAN NASI HANGAT 😍




Demikianlah cara membuat ayam rica kemangi yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
