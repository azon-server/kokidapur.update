---
description: "Resep : Ayam Rica Rica Kemangi Sempurna"
title: "Resep : Ayam Rica Rica Kemangi Sempurna"
slug: 282-resep-ayam-rica-rica-kemangi-sempurna
date: 2020-11-15T13:37:44.975Z
image: https://img-global.cpcdn.com/recipes/ba5ecac138f732ae/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ba5ecac138f732ae/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ba5ecac138f732ae/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Eliza Cobb
ratingvalue: 4.3
reviewcount: 36787
recipeingredient:
- "650 gr ayam"
- " Bahan A"
- "1/2 buah jeruk nipis"
- "1/2 sdt garam"
- "1/4 sdt merica"
- " Bahan B"
- "4 butir kemiri"
- "1 ruas lengkuas"
- "1 ruas sedikit aja kunyit"
- "1 ruas jahe"
- "4 butir bawang merah besar"
- "4 butir bawang putih"
- "4 buah cabe besar4 buah cabe keriting"
- " Bumbu bahan C"
- "1/2 sdt garam"
- "1/4 sdt merica"
- "1 sdt gula"
- "1/2 sdt kaldu bubuk"
- " daun jeruk daun salam"
- "2 batang serai"
- " cabe rawit"
- "150 ml air"
- "2 ikat daun kemangi"
recipeinstructions:
- "Lumuri ayam dengan bahan A, kemudian diamkan selama 15 menit."
- "Haluskan bahan B"
- "Goreng ayam sampai setengah matang, ayam jadi lebih wangi dan lebih gurih."
- "Tumis bagan B. Masukkan daun salam, daun jeruk, serai, bumbu (bahan C). Tunggu bumbu nya matang dan wangi, masukkan ayamnya. Aduk terus, sampai bumbu mengeluarkan minyak dan menyerap ke daging ayam. Kemudian baru masukkan airnya."
- "Masak sampai air menyusut dan ayam matang merata. Kemudian masukkan cabe rawit."
- "Masukkan daun kemangi, masak sebentar saja setelah kemangi masuk."
- "Ayam rica rica siap disajikan bersama sepiring nasi hangat.endeuusss... Tonton video cara buat ayam rica rica Manado yuks. Kunjungi Youtube @Smart Mama Vlog"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 142 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/ba5ecac138f732ae/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang dapat kita jaga karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica rica kemangi yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Nusantara

Kehangatan rumah tangga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Rica Rica Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang bisa anda buat salah satunya ayam rica rica kemangi yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 23 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Harap siapkan 650 gr ayam
1. Harus ada  Bahan A:
1. Tambah 1/2 buah jeruk nipis
1. Harus ada 1/2 sdt garam
1. Harus ada 1/4 sdt merica
1. Dibutuhkan  Bahan B:
1. Diperlukan 4 butir kemiri
1. Jangan lupa 1 ruas lengkuas
1. Dibutuhkan 1 ruas (sedikit aja) kunyit
1. Tambah 1 ruas jahe
1. Tambah 4 butir bawang merah (besar)
1. Harus ada 4 butir bawang putih
1. Dibutuhkan 4 buah cabe besar+4 buah cabe keriting
1. Harus ada  Bumbu (bahan C)
1. Jangan lupa 1/2 sdt garam
1. Harus ada 1/4 sdt merica
1. Diperlukan 1 sdt gula
1. Harap siapkan 1/2 sdt kaldu bubuk
1. Harus ada  daun jeruk, daun salam
1. Tambah 2 batang serai
1. Tambah  cabe rawit
1. Siapkan 150 ml air
1. Tambah 2 ikat daun kemangi




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Rica Kemangi:

1. Lumuri ayam dengan bahan A, kemudian diamkan selama 15 menit.
1. Haluskan bahan B
1. Goreng ayam sampai setengah matang, ayam jadi lebih wangi dan lebih gurih.
1. Tumis bagan B. Masukkan daun salam, daun jeruk, serai, bumbu (bahan C). Tunggu bumbu nya matang dan wangi, masukkan ayamnya. Aduk terus, sampai bumbu mengeluarkan minyak dan menyerap ke daging ayam. Kemudian baru masukkan airnya.
1. Masak sampai air menyusut dan ayam matang merata. Kemudian masukkan cabe rawit.
1. Masukkan daun kemangi, masak sebentar saja setelah kemangi masuk.
1. Ayam rica rica siap disajikan bersama sepiring nasi hangat.endeuusss... - Tonton video cara buat ayam rica rica Manado yuks. Kunjungi Youtube @Smart Mama Vlog




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan terbukti, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
