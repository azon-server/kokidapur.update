---
description: "Step-by-Step membuat 32. Ayam rica-rica kemangi minggu ini"
title: "Step-by-Step membuat 32. Ayam rica-rica kemangi minggu ini"
slug: 281-step-by-step-membuat-32-ayam-rica-rica-kemangi-minggu-ini
date: 2020-08-29T09:17:28.123Z
image: https://img-global.cpcdn.com/recipes/9e833deb57413a0f/751x532cq70/32-ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9e833deb57413a0f/751x532cq70/32-ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9e833deb57413a0f/751x532cq70/32-ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Christopher Griffith
ratingvalue: 4.9
reviewcount: 4911
recipeingredient:
- "1/2 kg ayam jadikan 4 optional"
- "1 genggam kemangi petik2 daunnya"
- "1 buah jeruk nipis"
- "300 ml air"
- " Bumbu"
- "2 genggam cabe rawit"
- "4 biji cabe merah keriting"
- "3 siung bawang putih"
- "5 siung bawang merah"
- "2 butir kemiri"
- "1 sdt merica"
- "1 ruas jari kunyit"
- "1 ruas jari jahe geprek"
- "2 lembar daun jeruk"
- "1 lembar daun salam"
- "1 batang sereh geprek"
- "secukupnya Garam gula totole"
- " Minyak goreng"
recipeinstructions:
- "Siapkan semua bahan...cuci bersih ayam, lumuri dengan perasan jeruk nipis remas2 dan diamkan sebentar kurleb 10 menit, lalu cuci kembali hingga bersih"
- "Siapkan bumbu, cuci bersih lalu goreng cabe, bawang merah, bawang putih, kunyit dan kemiri...kemudian haluskan lalu tuang dalam wajan"
- "Masukkan merica bubuk, jahe, sereh, daun salam, daun jeruk, garam, gula dan totole....aduk hingga tercampur semua dan daun layu"
- "Kemudian masukkan air dan ayam....aduk sebentar dan tutup wajan kurleb 5 menit....aduk2 kembali biarkan sampai ayam matang dan air menyusut, koreksi rasa..... dan terakhir masukkan kemangi lalu aduk sebentar.....matikan api, setelah agak dingin siap dimasukkan dalam cup ukuran 750ml dan cusss diantar ke pelanggan 💕💕"
categories:
- Recipe
tags:
- 32
- ayam
- ricarica

katakunci: 32 ayam ricarica 
nutrition: 247 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dessert

---


![32. Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/9e833deb57413a0f/751x532cq70/32-ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti 32. ayam rica-rica kemangi yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan ciri khas yang merupakan keragaman Nusantara

Kedekatan keluarga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan 32. Ayam rica-rica kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.

Ayam rica-rica Kemangi memang enak banget buat di cobain. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian masakan yang dapat anda praktekkan salah satunya 32. ayam rica-rica kemangi yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep 32. ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep 32. Ayam rica-rica kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 32. Ayam rica-rica kemangi:

1. Jangan lupa 1/2 kg ayam jadikan 4 (optional)
1. Siapkan 1 genggam kemangi (petik2 daunnya)
1. Siapkan 1 buah jeruk nipis
1. Tambah 300 ml air
1. Dibutuhkan  Bumbu
1. Harap siapkan 2 genggam cabe rawit
1. Diperlukan 4 biji cabe merah keriting
1. Dibutuhkan 3 siung bawang putih
1. Harap siapkan 5 siung bawang merah
1. Siapkan 2 butir kemiri
1. Diperlukan 1 sdt merica
1. Harap siapkan 1 ruas jari kunyit
1. Diperlukan 1 ruas jari jahe geprek
1. Jangan lupa 2 lembar daun jeruk
1. Harap siapkan 1 lembar daun salam
1. Diperlukan 1 batang sereh geprek
1. Tambah secukupnya Garam, gula, totole
1. Siapkan  Minyak goreng


Wajib coba bagi pecinta makanan pedas. Resep cara membuat ayam rica rica, jika ditambah daun kemangi pasti lebih enak. Ini merupakan resep makanan pedas asli khas Manado yang populer. Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. 

<!--inarticleads2-->

##### Cara membuat  32. Ayam rica-rica kemangi:

1. Siapkan semua bahan...cuci bersih ayam, lumuri dengan perasan jeruk nipis remas2 dan diamkan sebentar kurleb 10 menit, lalu cuci kembali hingga bersih
1. Siapkan bumbu, cuci bersih lalu goreng cabe, bawang merah, bawang putih, kunyit dan kemiri...kemudian haluskan lalu tuang dalam wajan
1. Masukkan merica bubuk, jahe, sereh, daun salam, daun jeruk, garam, gula dan totole....aduk hingga tercampur semua dan daun layu
1. Kemudian masukkan air dan ayam....aduk sebentar dan tutup wajan kurleb 5 menit....aduk2 kembali biarkan sampai ayam matang dan air menyusut, koreksi rasa..... dan terakhir masukkan kemangi lalu aduk sebentar.....matikan api, setelah agak dingin siap dimasukkan dalam cup ukuran 750ml dan cusss diantar ke pelanggan 💕💕


Ini merupakan resep makanan pedas asli khas Manado yang populer. Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! 

Demikianlah cara membuat 32. ayam rica-rica kemangi yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
