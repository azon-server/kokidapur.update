---
description: "Bagaimana untuk membuat Ayam rica kemangi teraktual"
title: "Bagaimana untuk membuat Ayam rica kemangi teraktual"
slug: 269-bagaimana-untuk-membuat-ayam-rica-kemangi-teraktual
date: 2020-08-30T03:07:06.349Z
image: https://img-global.cpcdn.com/recipes/53d2f70255cbb72e/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/53d2f70255cbb72e/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/53d2f70255cbb72e/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Cecilia Dennis
ratingvalue: 4.7
reviewcount: 18398
recipeingredient:
- "Potongan ayam"
- " Bbrp daun kemangi yg ud bersih"
- " Santan kara sckupnya"
- " Bumbu halus"
- "3 butir kemangi"
- "5 siung bawang putih"
- "5 siung bawang merah"
- "Sd teh ketumbar"
- "3 bh cabe rawit"
- "secukupnya Kunyit bubuk"
- "secukupnya Garam"
- " Penyedap dikit aja"
- "2 cm Jahe"
- " Tambahan"
- "2 btg sereh"
- "2 lmbr daun salam"
recipeinstructions:
- "Potong ayam bbrp bgian"
- "Blender bumbu halus, panaskan wajan dan masukkan bumbu halus, tambahkan sdikit santan kara dan air 2 gelas kalo ud harum masukkan sereh yg ud d geprek dan daun salam"
- "Masukkan potongan ayam ke dlm wajan, cicipi sdikit klo ada kurang bs d tambah jgn lupa tambahkan kemangi"
- "Klo ud matang dan air nya sdikit, angkat dr wajan. Sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 217 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/53d2f70255cbb72e/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga renyah. Karasteristik kuliner Indonesia ayam rica kemangi yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah memasak Ayam rica kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang dapat anda contoh salah satunya ayam rica kemangi yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi:

1. Dibutuhkan Potongan ayam
1. Tambah  Bbrp daun kemangi yg ud bersih
1. Dibutuhkan  Santan kara sckupnya
1. Tambah  Bumbu halus
1. Harus ada 3 butir kemangi
1. Siapkan 5 siung bawang putih
1. Harap siapkan 5 siung bawang merah
1. Siapkan Sd teh ketumbar
1. Harap siapkan 3 bh cabe rawit
1. Dibutuhkan secukupnya Kunyit bubuk
1. Siapkan secukupnya Garam
1. Jangan lupa  Penyedap dikit aja
1. Siapkan 2 cm Jahe
1. Jangan lupa  Tambahan
1. Harus ada 2 btg sereh
1. Siapkan 2 lmbr daun salam




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica kemangi:

1. Potong ayam bbrp bgian
1. Blender bumbu halus, panaskan wajan dan masukkan bumbu halus, tambahkan sdikit santan kara dan air 2 gelas kalo ud harum masukkan sereh yg ud d geprek dan daun salam
1. Masukkan potongan ayam ke dlm wajan, cicipi sdikit klo ada kurang bs d tambah jgn lupa tambahkan kemangi
1. Klo ud matang dan air nya sdikit, angkat dr wajan. Sajikan




Demikianlah cara membuat ayam rica kemangi yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan cepat, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
