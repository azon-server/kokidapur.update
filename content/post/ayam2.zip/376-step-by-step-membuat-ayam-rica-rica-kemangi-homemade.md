---
description: "Step-by-Step membuat Ayam rica-rica kemangi Homemade"
title: "Step-by-Step membuat Ayam rica-rica kemangi Homemade"
slug: 376-step-by-step-membuat-ayam-rica-rica-kemangi-homemade
date: 2020-08-18T09:15:30.134Z
image: https://img-global.cpcdn.com/recipes/427a36e287b44ca8/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/427a36e287b44ca8/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/427a36e287b44ca8/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Adeline Harrington
ratingvalue: 4.9
reviewcount: 33116
recipeingredient:
- "1 kg ayam"
- "2 iket daun kemangi"
- "5 siung Bawang putih"
- "6 siung Bawang merah"
- "500 gr Cabai merah"
- " Cabai rawit merah 200gr option"
- "1 batang Sereh"
- "2 lembar Daun salam"
- " Daun jeruk 2 lembarbuang batang nya"
- "1 ruas Lengkuas"
- "1 ruas Jahe"
- "1 ruas Kunyit"
- "2 buah Kemiri"
- "1/2 sdt Ketumbar"
- "secukupnya Garam"
- " Penyedap option"
- "secukupnya Gula"
- "250 ml Air"
recipeinstructions:
- "Goreng ayam setengah matang"
- "Blender semua bumbu, kecuali sereh, daun salam dan daun jeruk"
- "Panaskan minyak, tumis bumbu masukan sereh salam dan daun jeruk. Masak hingga baunya harum,"
- "Setelah itu beri air sekitar 250ml, garam dan gula."
- "Aduk hingga rata dan masukan ayam nya."
- "Masak hingga air sedikit mengering, lalu masukan daun kemangi hingga layu, Tunggu 5 menit.lalu sajikan 😊"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 192 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/427a36e287b44ca8/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau gurih. Ciri kuliner Indonesia ayam rica-rica kemangi yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica-rica kemangi untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang bisa anda buat salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica kemangi:

1. Tambah 1 kg ayam
1. Siapkan 2 iket daun kemangi
1. Jangan lupa 5 siung Bawang putih
1. Diperlukan 6 siung Bawang merah
1. Jangan lupa 500 gr Cabai merah
1. Harap siapkan  Cabai rawit merah 200gr (option)
1. Tambah 1 batang Sereh
1. Dibutuhkan 2 lembar Daun salam
1. Harap siapkan  Daun jeruk 2 lembar(buang batang nya)
1. Jangan lupa 1 ruas Lengkuas
1. Tambah 1 ruas Jahe
1. Harap siapkan 1 ruas Kunyit
1. Siapkan 2 buah Kemiri
1. Tambah 1/2 sdt Ketumbar
1. Tambah secukupnya Garam
1. Dibutuhkan  Penyedap (option)
1. Siapkan secukupnya Gula
1. Harap siapkan 250 ml Air


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Cara membuat  Ayam rica-rica kemangi:

1. Goreng ayam setengah matang
1. Blender semua bumbu, kecuali sereh, daun salam dan daun jeruk
1. Panaskan minyak, tumis bumbu masukan sereh salam dan daun jeruk. Masak hingga baunya harum,
1. Setelah itu beri air sekitar 250ml, garam dan gula.
1. Aduk hingga rata dan masukan ayam nya.
1. Masak hingga air sedikit mengering, lalu masukan daun kemangi hingga layu, Tunggu 5 menit.lalu sajikan 😊


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan teruji, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
