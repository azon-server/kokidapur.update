---
description: "Resep : Ayam Geprek Crispy Daun Jeruk minggu ini"
title: "Resep : Ayam Geprek Crispy Daun Jeruk minggu ini"
slug: 137-resep-ayam-geprek-crispy-daun-jeruk-minggu-ini
date: 2021-01-27T00:17:46.113Z
image: https://img-global.cpcdn.com/recipes/bbd82c57e7b94247/751x532cq70/ayam-geprek-crispy-daun-jeruk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bbd82c57e7b94247/751x532cq70/ayam-geprek-crispy-daun-jeruk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bbd82c57e7b94247/751x532cq70/ayam-geprek-crispy-daun-jeruk-foto-resep-utama.jpg
author: Duane McKenzie
ratingvalue: 4
reviewcount: 5737
recipeingredient:
- "1/4 daging ayam"
- "1 bungkus tepung serbaguna sajiku"
- "Secukupnya air es"
- " Minyak untuk menggoreng"
- " Bumbu Sambal Geprek"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "10 biji cabe rawitsesuai selera"
- "3 lembar daun jeruk"
- "3 sdm minyak goreng panas"
- " Gula"
- " Garam"
- " Penyedap rasa"
recipeinstructions:
- "Potong ayam menjadi beberapa potong, cuci bersih kemudian sisihkan"
- "Siapkan 2 mangkok untuk tepung bumbu serbaguna sajiku kemudian bagi tepung menjadi 2 bagian masukan masing masing kedalam wadah (yang satu untuk adonan basah, dan yg satu lagi untuk adonan kering)"
- "Wadah pertama campurkan tepung bumbu serbaguna sajiku dengan air es secukupnya (jangan terlalu encer) kemudian masukan ayam aduk hingga rata tunggu kurang lebih 10 menit supaya bumbu meresap"
- "Setelah 10 menit masukan ayam kedalam mangkok tepung serbaguna sajiku adonan kering dan remas remas hingga 10x supaya ayam tercampur rata dengan tepung"
- "Panaskan minyak dengan api yg kecil supaya ayam matang luar dalam"
- "Goreng hingga warna coklat keemasan..angkat dan tiriskan"
- "Siapkan cobek kemudian tumbuk bumbu sambel geprek jangan terlalu halus atau sesuai selera, koreksi rasa setelah dirasa pas kemudian siram sambal geprek dengan 3 sdm minyak panas bisa kurang atau lebih sesuai selera"
- "Masukan ayam dan geprek jangan terlalu halus/sesuai selera"
- "Dan jadilaah ayam geprek daun jeruk sajikan dengan nasi pulen panas hemm yumiiii"
categories:
- Recipe
tags:
- ayam
- geprek
- crispy

katakunci: ayam geprek crispy 
nutrition: 137 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT58M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Geprek Crispy Daun Jeruk](https://img-global.cpcdn.com/recipes/bbd82c57e7b94247/751x532cq70/ayam-geprek-crispy-daun-jeruk-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam geprek crispy daun jeruk yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa keistimewahan yang merupakan keragaman Kita

Kehangatan keluarga dapat didapat dengan cara simple. Diantaranya adalah membuat makanan Ayam Geprek Crispy Daun Jeruk untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang dapat anda coba salah satunya ayam geprek crispy daun jeruk yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep ayam geprek crispy daun jeruk tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Crispy Daun Jeruk yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 13 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Crispy Daun Jeruk:

1. Harus ada 1/4 daging ayam
1. Siapkan 1 bungkus tepung serbaguna (sajiku)
1. Jangan lupa Secukupnya air es
1. Jangan lupa  Minyak untuk menggoreng
1. Jangan lupa  Bumbu Sambal Geprek
1. Siapkan 5 siung bawang merah
1. Tambah 3 siung bawang putih
1. Tambah 10 biji cabe rawit/sesuai selera
1. Harus ada 3 lembar daun jeruk
1. Dibutuhkan 3 sdm minyak goreng panas
1. Diperlukan  Gula
1. Harus ada  Garam
1. Dibutuhkan  Penyedap rasa




<!--inarticleads2-->

##### Cara membuat  Ayam Geprek Crispy Daun Jeruk:

1. Potong ayam menjadi beberapa potong, cuci bersih kemudian sisihkan
1. Siapkan 2 mangkok untuk tepung bumbu serbaguna sajiku kemudian bagi tepung menjadi 2 bagian masukan masing masing kedalam wadah (yang satu untuk adonan basah, dan yg satu lagi untuk adonan kering)
1. Wadah pertama campurkan tepung bumbu serbaguna sajiku dengan air es secukupnya (jangan terlalu encer) kemudian masukan ayam aduk hingga rata tunggu kurang lebih 10 menit supaya bumbu meresap
1. Setelah 10 menit masukan ayam kedalam mangkok tepung serbaguna sajiku adonan kering dan remas remas hingga 10x supaya ayam tercampur rata dengan tepung
1. Panaskan minyak dengan api yg kecil supaya ayam matang luar dalam
1. Goreng hingga warna coklat keemasan..angkat dan tiriskan
1. Siapkan cobek kemudian tumbuk bumbu sambel geprek jangan terlalu halus atau sesuai selera, koreksi rasa setelah dirasa pas kemudian siram sambal geprek dengan 3 sdm minyak panas bisa kurang atau lebih sesuai selera
1. Masukan ayam dan geprek jangan terlalu halus/sesuai selera
1. Dan jadilaah ayam geprek daun jeruk sajikan dengan nasi pulen panas hemm yumiiii




Demikianlah cara membuat ayam geprek crispy daun jeruk yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
