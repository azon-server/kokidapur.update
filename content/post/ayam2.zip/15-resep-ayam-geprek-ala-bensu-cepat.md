---
description: "Resep : Ayam geprek ala bensu Cepat"
title: "Resep : Ayam geprek ala bensu Cepat"
slug: 15-resep-ayam-geprek-ala-bensu-cepat
date: 2020-11-20T21:36:46.165Z
image: https://img-global.cpcdn.com/recipes/c274da299e4e5121/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c274da299e4e5121/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c274da299e4e5121/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg
author: Lucinda Farmer
ratingvalue: 4.8
reviewcount: 48534
recipeingredient:
- " Bahan Rendaman Ayam "
- "1/4 kg ayam"
- "2 siung bawang putih"
- "1 sdt lada bubuk"
- "Secukupnya garam"
- " Adonan Basah "
- "Secukupnya air es"
- "6 sdm tepung terigu"
- "2 sdm tepung maizena"
- "1 sdm susu bubuk"
- "1 butir kuning telur"
- "1/2 sdt baking soda"
- "1/2 sdt lada bubuk"
- " Swcukupnha garam"
- " Adonan kering "
- "6 sdm tepung terigu"
- "3 sdm tepung maizena"
- "1/2 sdt baking soda"
- "1 sdt kaldu bubuk ayam"
- "1/4 sdt garam"
- " Bahan Sambal Bawang "
- "25 buah cabe rawit jablay"
- "3 siung bawang putih"
- "Secukupnya gula merah"
- "Secukupnya garam"
recipeinstructions:
- "Cuci bersih semua bahan, rendam ayam dengan bumbu rendaman ayam di kulkas kurang lebih selama 15 menit."
- "Campur rata semua adonan basah dan di wadah lain campur juga semua adonan kering."
- "Gulingkan ayam ke adonan kering, lalu celupkan ke adonan basah setekah itu gukingkan lagi ke adonan kering"
- "Goreng ayam hingga matang dan crispy dengan api kecil, angkat dan sisihkan."
- "Goreng cabe dan bawang putih setengah matang lalu angkat, ulek kasar dan beri tambahan gula merah dan garam."
- "Geprek ayam yang sudah digoreng tadi, lalu beri toping sambal bawang, sajikan selagi hangat. Selamat mencoba."
categories:
- Recipe
tags:
- ayam
- geprek
- ala

katakunci: ayam geprek ala 
nutrition: 155 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam geprek ala bensu](https://img-global.cpcdn.com/recipes/c274da299e4e5121/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang dapat kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam geprek ala bensu yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara



Kedekatan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Ayam geprek ala bensu untuk orang di rumah. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang bisa anda praktekkan salah satunya ayam geprek ala bensu yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep ayam geprek ala bensu tanpa harus bersusah payah.
Seperti resep Ayam geprek ala bensu yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 25 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam geprek ala bensu:

1. Dibutuhkan  Bahan Rendaman Ayam :
1. Tambah 1/4 kg ayam
1. Siapkan 2 siung bawang putih
1. Harus ada 1 sdt lada bubuk
1. Diperlukan Secukupnya garam
1. Diperlukan  Adonan Basah :
1. Harus ada Secukupnya air es
1. Tambah 6 sdm tepung terigu
1. Diperlukan 2 sdm tepung maizena
1. Harap siapkan 1 sdm susu bubuk
1. Dibutuhkan 1 butir kuning telur
1. Dibutuhkan 1/2 sdt baking soda
1. Harus ada 1/2 sdt lada bubuk
1. Jangan lupa  Swcukupnha garam
1. Siapkan  Adonan kering :
1. Siapkan 6 sdm tepung terigu
1. Siapkan 3 sdm tepung maizena
1. Diperlukan 1/2 sdt baking soda
1. Jangan lupa 1 sdt kaldu bubuk ayam
1. Dibutuhkan 1/4 sdt garam
1. Harus ada  Bahan Sambal Bawang :
1. Diperlukan 25 buah cabe rawit jablay
1. Harap siapkan 3 siung bawang putih
1. Jangan lupa Secukupnya gula merah
1. Jangan lupa Secukupnya garam




<!--inarticleads2-->

##### Bagaimana membuat  Ayam geprek ala bensu:

1. Cuci bersih semua bahan, rendam ayam dengan bumbu rendaman ayam di kulkas kurang lebih selama 15 menit.
1. Campur rata semua adonan basah dan di wadah lain campur juga semua adonan kering.
1. Gulingkan ayam ke adonan kering, lalu celupkan ke adonan basah setekah itu gukingkan lagi ke adonan kering
1. Goreng ayam hingga matang dan crispy dengan api kecil, angkat dan sisihkan.
1. Goreng cabe dan bawang putih setengah matang lalu angkat, ulek kasar dan beri tambahan gula merah dan garam.
1. Geprek ayam yang sudah digoreng tadi, lalu beri toping sambal bawang, sajikan selagi hangat. Selamat mencoba.




Demikianlah cara membuat ayam geprek ala bensu yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan terbukti, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
