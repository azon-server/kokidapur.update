---
description: "Steps untuk menyiapakan Ayam Rica Kemangi minggu ini"
title: "Steps untuk menyiapakan Ayam Rica Kemangi minggu ini"
slug: 397-steps-untuk-menyiapakan-ayam-rica-kemangi-minggu-ini
date: 2020-10-30T21:55:21.199Z
image: https://img-global.cpcdn.com/recipes/8929143d443a64f5/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8929143d443a64f5/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8929143d443a64f5/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Jerome Moss
ratingvalue: 4.3
reviewcount: 2143
recipeingredient:
- "1/2 kg ayam"
- "1 ikat daun kemangi"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "Secukupnya air kaldu rebusan ayam"
- " Bumbu Halus"
- "3 siung bawang putih"
- "5 siung bawang merah"
- "25 cabai rawit"
- "7 cabai merah keriting"
- "2 buah kemiri"
- "1 ruas jari jahe"
- " Bumbu Geprek"
- "1 ruas jari lengkuas"
- "1 batang serai"
- " Bumbu Pelengkap"
- "1 sdt gula pasir"
- "1 sdt garam halus"
- "1/2 sdt ketumbar"
- "1/2 sdt merica"
recipeinstructions:
- "Siapkan bahan."
- "Haluskan bawang merah, bawang putih, cabai rawit, dan cabai keriting. Saya pakai chopper/pencacah."
- "Haluskan/uleg kemiri dan jahe."
- "Panaskan minyak dalam wajan. Lalu tumis bumbu halus ampai harum."
- "Masukkan bumbu geprek (lengkuas, serai) dan daun salam serta daun jeruk. Aduk2 sampai harum."
- "Tuangkan air kaldu rebusan ayam. Tunggu sampai mendidih."
- "Masukkan ayam yg telah direbus."
- "Tambahkan bumbu pelengkap. Aduk2. Cek rasa."
- "Masukkan irisan tomat."
- "Masukkan daun kemangi."
- "Masukkan irisan daun bawang. Aduk2 sampai tercampur rata. Ayam rica kemangi siap disajikan."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 235 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/8929143d443a64f5/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis atau renyah. Karasteristik kuliner Indonesia ayam rica kemangi yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan keluarga dapat didapat dengan cara simple. Salah satunya adalah memasak Ayam Rica Kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.

Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang dapat anda praktekkan salah satunya ayam rica kemangi yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 11 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Tambah 1/2 kg ayam
1. Diperlukan 1 ikat daun kemangi
1. Harap siapkan 2 lembar daun salam
1. Dibutuhkan 3 lembar daun jeruk
1. Siapkan Secukupnya air kaldu rebusan ayam
1. Dibutuhkan  Bumbu Halus
1. Diperlukan 3 siung bawang putih
1. Siapkan 5 siung bawang merah
1. Tambah 25 cabai rawit
1. Dibutuhkan 7 cabai merah keriting
1. Siapkan 2 buah kemiri
1. Tambah 1 ruas jari jahe
1. Jangan lupa  Bumbu Geprek
1. Diperlukan 1 ruas jari lengkuas
1. Diperlukan 1 batang serai
1. Jangan lupa  Bumbu Pelengkap
1. Harus ada 1 sdt gula pasir
1. Diperlukan 1 sdt garam halus
1. Diperlukan 1/2 sdt ketumbar
1. Jangan lupa 1/2 sdt merica


Perlu kamu ketahui bahwa di luar negeri mungkin daun basil sangat terkenal untuk campuran makanan. Akan tetapi, di Indonesia juga memiliki daun kemangi merupakan. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. 

<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Kemangi:

1. Siapkan bahan.
1. Haluskan bawang merah, bawang putih, cabai rawit, dan cabai keriting. Saya pakai chopper/pencacah.
1. Haluskan/uleg kemiri dan jahe.
1. Panaskan minyak dalam wajan. Lalu tumis bumbu halus ampai harum.
1. Masukkan bumbu geprek (lengkuas, serai) dan daun salam serta daun jeruk. Aduk2 sampai harum.
1. Tuangkan air kaldu rebusan ayam. Tunggu sampai mendidih.
1. Masukkan ayam yg telah direbus.
1. Tambahkan bumbu pelengkap. Aduk2. Cek rasa.
1. Masukkan irisan tomat.
1. Masukkan daun kemangi.
1. Masukkan irisan daun bawang. Aduk2 sampai tercampur rata. Ayam rica kemangi siap disajikan.


Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. Cara Membuat Ayam Rica Rica Kemangi. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat. 

Demikianlah cara membuat ayam rica kemangi yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan terbukti, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
