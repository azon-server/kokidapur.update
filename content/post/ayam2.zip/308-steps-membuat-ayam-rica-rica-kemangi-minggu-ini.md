---
description: "Steps membuat Ayam Rica Rica Kemangi minggu ini"
title: "Steps membuat Ayam Rica Rica Kemangi minggu ini"
slug: 308-steps-membuat-ayam-rica-rica-kemangi-minggu-ini
date: 2020-10-16T15:46:10.077Z
image: https://img-global.cpcdn.com/recipes/6f32d5113db052c8/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6f32d5113db052c8/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6f32d5113db052c8/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Jessie Manning
ratingvalue: 4.6
reviewcount: 7665
recipeingredient:
- "1  ekor Ayam"
- " Lombok sesuai selera saya pakai 40 buah"
- "5 Bawang merah"
- "3 Bawang putih"
- " Kunyit"
- "1 ruas Jahe"
- "1 ruas Lengkuas"
- "3 lembar Daun Jeruk"
- "1 batang Serai"
- "2 lembar Daun Salam"
- " Merica jika dirasa kurang pedes"
- " Kemangi"
- " Air"
- "secukupnya Gula Merah"
- "secukupnya Gula Pasir"
- "secukupnya Garam"
- " Penyedap rasa saya pakai royko rasa ayam"
- "Sedikit kecap"
- " Minyak goreng"
recipeinstructions:
- "Cuci bersih ayam, lalu potong kecil2 (sesuai selera)"
- "Haluskan bumbu halus seperti Lombok, bamer, Baput, kunyit, jahe, gulmer, lalu geprek lengkuas dan serai"
- "Panaskan minyak goreng, tumis bumbu halus beserta lengkuas dan serai geprek. Tambahkan daun jeruk dan daun salam. Tumis hingga harum"
- "Setelah harum masukan ayam dan tambahkan sedikit air. Tutup dan tunggu hingga bumbu meresap"
- "Tambahkan garam,. Gula, penyedap rasa dan kecap. Cek rasa, lalu masukkan kemangi. Diamkan sejenak lalu matikan kompor"
- "Ayam rica rica siap dihidangkan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 103 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/6f32d5113db052c8/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan enak. Karasteristik kuliner Nusantara ayam rica rica kemangi yang penuh dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica Rica Kemangi untuk keluarga. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang dapat anda coba salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Siapkan 1 /² ekor Ayam
1. Harus ada  Lombok sesuai selera (saya pakai 40 buah)
1. Diperlukan 5 Bawang merah
1. Siapkan 3 Bawang putih
1. Harus ada  Kunyit
1. Harap siapkan 1 ruas Jahe
1. Tambah 1 ruas Lengkuas
1. Harus ada 3 lembar Daun Jeruk
1. Harus ada 1 batang Serai
1. Jangan lupa 2 lembar Daun Salam
1. Dibutuhkan  Merica (jika dirasa kurang pedes)
1. Jangan lupa  Kemangi
1. Diperlukan  Air
1. Tambah secukupnya Gula Merah
1. Dibutuhkan secukupnya Gula Pasir
1. Dibutuhkan secukupnya Garam
1. Diperlukan  Penyedap rasa (saya pakai royko rasa ayam)
1. Siapkan Sedikit kecap
1. Siapkan  Minyak goreng




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Rica Kemangi:

1. Cuci bersih ayam, lalu potong kecil2 (sesuai selera)
1. Haluskan bumbu halus seperti Lombok, bamer, Baput, kunyit, jahe, gulmer, lalu geprek lengkuas dan serai
1. Panaskan minyak goreng, tumis bumbu halus beserta lengkuas dan serai geprek. Tambahkan daun jeruk dan daun salam. Tumis hingga harum
1. Setelah harum masukan ayam dan tambahkan sedikit air. Tutup dan tunggu hingga bumbu meresap
1. Tambahkan garam,. Gula, penyedap rasa dan kecap. Cek rasa, lalu masukkan kemangi. Diamkan sejenak lalu matikan kompor
1. Ayam rica rica siap dihidangkan.




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan terbukti, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
