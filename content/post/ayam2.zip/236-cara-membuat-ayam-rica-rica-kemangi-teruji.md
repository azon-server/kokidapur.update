---
description: "Cara membuat Ayam Rica Rica Kemangi Teruji"
title: "Cara membuat Ayam Rica Rica Kemangi Teruji"
slug: 236-cara-membuat-ayam-rica-rica-kemangi-teruji
date: 2020-08-29T10:53:24.114Z
image: https://img-global.cpcdn.com/recipes/9d4f02d8c5a58c15/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9d4f02d8c5a58c15/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9d4f02d8c5a58c15/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Eunice Erickson
ratingvalue: 4.1
reviewcount: 12966
recipeingredient:
- "1/2 Kg Ayam"
- "1 Batang Serai"
- "4 Lembar daun Jeruk"
- "2 Buah Tomat potongpotong"
- "15 Buah Cabai Rawit Merah"
- "1 Mangkok Kemangi"
- "1 Sdm Gula Merah"
- "1/2 Sdm Garam"
- "1 Sdt Kaldu Ayam Bubuk Royco"
- "300 Ml Air"
- " Bumbu yang dihaluskan"
- "6 Buah Cabai Merah Keriting"
- "7 Siung Bawang Merah"
- "4 Siung Bawang Putih"
- "1 Sdt Ketumbar Halus"
- "1 Ruas Kunyit"
- "1 Ruas Jahe"
- " Minyak untuk menumis"
recipeinstructions:
- "Goreng ayam hingga kecoklatan lalu angkat dan tiriskan."
- "Tumis bumbu yang dihaluskan lalu masukkan daun jeruk dan serai. Masak sampai harum lalu masukkan tomat dan gula merah. Aduk sampai rata lalu masukkan ayam, air, garam dan kaldu bubuk (Bisa ditambah gula pasir jika suka)."
- "Setelah air agak menyusut masukkan cabai rawit dan daun kemangi aduk sampai rata, cek juga rasanya."
- "Sajikan Ayam Rica Rica Kemangi selagi hangat. Selamat mencoba."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 221 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/9d4f02d8c5a58c15/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica rica kemangi yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Indonesia



Kehangatan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah memasak Ayam Rica Rica Kemangi untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang dapat anda coba salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Harap siapkan 1/2 Kg Ayam
1. Harap siapkan 1 Batang Serai
1. Harus ada 4 Lembar daun Jeruk
1. Siapkan 2 Buah Tomat, potong-potong
1. Harus ada 15 Buah Cabai Rawit Merah
1. Jangan lupa 1 Mangkok Kemangi
1. Jangan lupa 1 Sdm Gula Merah
1. Harus ada 1/2 Sdm Garam
1. Dibutuhkan 1 Sdt Kaldu Ayam Bubuk (Royco)
1. Siapkan 300 Ml Air
1. Harus ada  Bumbu yang dihaluskan*
1. Dibutuhkan 6 Buah Cabai Merah Keriting
1. Jangan lupa 7 Siung Bawang Merah
1. Harus ada 4 Siung Bawang Putih
1. Harap siapkan 1 Sdt Ketumbar Halus
1. Jangan lupa 1 Ruas Kunyit
1. Harus ada 1 Ruas Jahe
1. Harap siapkan  Minyak untuk menumis




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Rica Kemangi:

1. Goreng ayam hingga kecoklatan lalu angkat dan tiriskan.
1. Tumis bumbu yang dihaluskan lalu masukkan daun jeruk dan serai. Masak sampai harum lalu masukkan tomat dan gula merah. Aduk sampai rata lalu masukkan ayam, air, garam dan kaldu bubuk (Bisa ditambah gula pasir jika suka).
1. Setelah air agak menyusut masukkan cabai rawit dan daun kemangi aduk sampai rata, cek juga rasanya.
1. Sajikan Ayam Rica Rica Kemangi selagi hangat. Selamat mencoba.




Demikianlah cara membuat ayam rica rica kemangi yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
