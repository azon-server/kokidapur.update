---
description: "Step-by-Step menyiapakan Ayam geprek bensu ala ala mama fathan Teruji"
title: "Step-by-Step menyiapakan Ayam geprek bensu ala ala mama fathan Teruji"
slug: 14-step-by-step-menyiapakan-ayam-geprek-bensu-ala-ala-mama-fathan-teruji
date: 2020-11-08T17:50:19.831Z
image: https://img-global.cpcdn.com/recipes/b59cb54807f21b04/751x532cq70/ayam-geprek-bensu-ala-ala-mama-fathan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b59cb54807f21b04/751x532cq70/ayam-geprek-bensu-ala-ala-mama-fathan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b59cb54807f21b04/751x532cq70/ayam-geprek-bensu-ala-ala-mama-fathan-foto-resep-utama.jpg
author: Rosa Hudson
ratingvalue: 4.9
reviewcount: 30572
recipeingredient:
- "1 buah dada ayam potong 4 bagian"
- "4 siung bawang putih"
- "1/2 sdt lada bubuk"
- "1 bks masako ayam"
- "20 ml air"
- "1 butir telur ayam"
- "1 bks tepung bumbu serbaguna"
- " Minyak untuk menggoreng"
- " Sambal geprek "
- "30 buah cabai rawit merah"
- "3 siung bawang putih"
- "Secukupnya garam dan penyedap"
recipeinstructions:
- "Haluskan bawang putih, lada bubuk dan masako ayam, kasih air lalu aduk rata. Cuci bersih ayam lalu lumuri ayam dengan bumbu, diamkan selama 3 jam agar bumbu meresap."
- "Tambahkan telur lalu aduk rata."
- "Siapkan tepung bumbu serbaguna di wadah besar dan masukkan ayam 1 per satu sambil diremas remas hingga ayam terbalut tepung."
- "Panaskan minyak. Goreng ayam dengan api sedang sambil dibolak balik hingga garing dan matang."
- "Panaskan sedikit minyak lalu goreng cabai rawit merah dan bawang putih hingga setengah matang. Lalu ulek kasar kasih garam dan penyedap, aduk rata."
- "Geprek ayam crispy taruh dalam piring lalu lumuri dengan sambalnya. Sajikan dengan lalapan dan nasi hangat."
categories:
- Recipe
tags:
- ayam
- geprek
- bensu

katakunci: ayam geprek bensu 
nutrition: 117 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT46M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam geprek bensu ala ala mama fathan](https://img-global.cpcdn.com/recipes/b59cb54807f21b04/751x532cq70/ayam-geprek-bensu-ala-ala-mama-fathan-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam geprek bensu ala ala mama fathan yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan ciri khas yang merupakan keragaman Indonesia



Kedekatan rumah tangga bisa didapat dengan cara simple. Salah satunya adalah memasak Ayam geprek bensu ala ala mama fathan untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang dapat anda coba salah satunya ayam geprek bensu ala ala mama fathan yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep ayam geprek bensu ala ala mama fathan tanpa harus bersusah payah.
Seperti resep Ayam geprek bensu ala ala mama fathan yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 12 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam geprek bensu ala ala mama fathan:

1. Diperlukan 1 buah dada ayam potong 4 bagian
1. Diperlukan 4 siung bawang putih
1. Siapkan 1/2 sdt lada bubuk
1. Siapkan 1 bks masako ayam
1. Harap siapkan 20 ml air
1. Dibutuhkan 1 butir telur ayam
1. Diperlukan 1 bks tepung bumbu serbaguna
1. Harus ada  Minyak untuk menggoreng
1. Harus ada  Sambal geprek :
1. Diperlukan 30 buah cabai rawit merah
1. Harap siapkan 3 siung bawang putih
1. Harus ada Secukupnya garam dan penyedap




<!--inarticleads2-->

##### Bagaimana membuat  Ayam geprek bensu ala ala mama fathan:

1. Haluskan bawang putih, lada bubuk dan masako ayam, kasih air lalu aduk rata. Cuci bersih ayam lalu lumuri ayam dengan bumbu, diamkan selama 3 jam agar bumbu meresap.
1. Tambahkan telur lalu aduk rata.
1. Siapkan tepung bumbu serbaguna di wadah besar dan masukkan ayam 1 per satu sambil diremas remas hingga ayam terbalut tepung.
1. Panaskan minyak. Goreng ayam dengan api sedang sambil dibolak balik hingga garing dan matang.
1. Panaskan sedikit minyak lalu goreng cabai rawit merah dan bawang putih hingga setengah matang. Lalu ulek kasar kasih garam dan penyedap, aduk rata.
1. Geprek ayam crispy taruh dalam piring lalu lumuri dengan sambalnya. Sajikan dengan lalapan dan nasi hangat.




Demikianlah cara membuat ayam geprek bensu ala ala mama fathan yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan teruji, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
