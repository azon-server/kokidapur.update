---
description: "Resep : Ayam Rica-Rica Kemangi Terbukti"
title: "Resep : Ayam Rica-Rica Kemangi Terbukti"
slug: 385-resep-ayam-rica-rica-kemangi-terbukti
date: 2021-01-19T14:03:15.811Z
image: https://img-global.cpcdn.com/recipes/c8b49b03adaa0679/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c8b49b03adaa0679/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c8b49b03adaa0679/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Susie Carr
ratingvalue: 4.8
reviewcount: 44874
recipeingredient:
- "1,3 kg ayam potong kecil"
- "3 lbr daun salam"
- "2 btg serai geprek"
- "3 lbr daun jeruk"
- "1 sdm garam"
- "1 sdt gula pasir"
- "1/2 sdt lada bubuk"
- "50 gr daun kemangi"
- "300 ml air"
- " Bumbu halus"
- "3 buah bawang merah"
- "3 siung bawang putih"
- "75 gr cabai merah keriting"
- "2 ruas jari jahe"
recipeinstructions:
- "Siapkan bahan-bahannya."
- "Tumis bumbu halus hingga harum tambahkan serai, daun salam dan daun jeruk. Masukkan ayam aduk rata tambahkan air biarkan setengah empuk."
- "Tambahkan garam, gula pasir dan lada bubuk. Biarkan empuk dan air mulai surut masukkan daun kemangi koreksi rasa angkat. Sajikan."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 184 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT55M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/c8b49b03adaa0679/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang dapat kita lestarikan karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Kita

Kehangatan keluarga bisa didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica-Rica Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang bisa anda coba salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Kemangi:

1. Jangan lupa 1,3 kg ayam (potong kecil)
1. Tambah 3 lbr daun salam
1. Harap siapkan 2 btg serai (geprek)
1. Harap siapkan 3 lbr daun jeruk
1. Siapkan 1 sdm garam
1. Siapkan 1 sdt gula pasir
1. Siapkan 1/2 sdt lada bubuk
1. Jangan lupa 50 gr daun kemangi
1. Diperlukan 300 ml air
1. Siapkan  Bumbu halus:
1. Jangan lupa 3 buah bawang merah
1. Harus ada 3 siung bawang putih
1. Dibutuhkan 75 gr cabai merah keriting
1. Tambah 2 ruas jari jahe




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica Kemangi:

1. Siapkan bahan-bahannya.
1. Tumis bumbu halus hingga harum tambahkan serai, daun salam dan daun jeruk. Masukkan ayam aduk rata tambahkan air biarkan setengah empuk.
1. Tambahkan garam, gula pasir dan lada bubuk. Biarkan empuk dan air mulai surut masukkan daun kemangi koreksi rasa angkat. Sajikan.




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan terbukti, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
