---
description: "Cara untuk membuat 66. Ayam Rica - Rica Kemangi minggu ini"
title: "Cara untuk membuat 66. Ayam Rica - Rica Kemangi minggu ini"
slug: 382-cara-untuk-membuat-66-ayam-rica-rica-kemangi-minggu-ini
date: 2021-01-15T07:00:49.388Z
image: https://img-global.cpcdn.com/recipes/7c412925f48e5ba8/751x532cq70/66-ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7c412925f48e5ba8/751x532cq70/66-ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7c412925f48e5ba8/751x532cq70/66-ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Tillie Briggs
ratingvalue: 4.7
reviewcount: 11485
recipeingredient:
- "1/2 kg ayam saya potong 4 saja"
- "1 ikat kemangi petik daunnya"
- "1 batang serei geprek"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "2 lembar daun pandan potongpotong"
- "secukupnya kaldu ayam"
- "1/2 sdt merica bubuk"
- "sedikit air"
- "secukupnya minyak untuk menumis"
- " BUMBU HALUS"
- "30 bh rawit merah boleh dikurangi"
- "15 bh cabe merah keriting"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "1 ruas jari jahe"
- "2 ruas jari lengkoas"
- "1 ruas jari kunyit"
- "2 butir kemiri"
recipeinstructions:
- "Tumis bumbu halus sampai wangi, lalu tambahkan serei, daun salam dan daun jeruk. masak sebentar. lalu tambahkan daun pandan."
- "Masukkan ayam, masak sampai ayam berubah warna. lalu tambahkan air sedikit.."
- "Tambahkan merica dan kaldu bubuk, koreksi rasa. masak sampai air agak menyusut. lalu tambahkan kemangi."
- "Masak terus hingga air asat dan ayam empuk. Angkat, sajikan dengan nasi hangat.."
- "SELESAI... 😁"
categories:
- Recipe
tags:
- 66
- ayam
- rica

katakunci: 66 ayam rica 
nutrition: 190 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT44M"
recipeyield: "3"
recipecategory: Dessert

---


![66. Ayam Rica - Rica Kemangi](https://img-global.cpcdn.com/recipes/7c412925f48e5ba8/751x532cq70/66-ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang patut kita jaga karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti 66. ayam rica - rica kemangi yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Nusantara



Keharmonisan rumah tangga bisa didapat dengan cara sederhana. Salah satunya adalah memasak 66. Ayam Rica - Rica Kemangi untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang dapat anda praktekkan salah satunya 66. ayam rica - rica kemangi yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep 66. ayam rica - rica kemangi tanpa harus bersusah payah.
Berikut ini resep 66. Ayam Rica - Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 66. Ayam Rica - Rica Kemangi:

1. Harus ada 1/2 kg ayam (saya potong 4 saja)
1. Jangan lupa 1 ikat kemangi, petik daunnya
1. Dibutuhkan 1 batang serei, geprek
1. Harus ada 2 lembar daun salam
1. Diperlukan 3 lembar daun jeruk
1. Dibutuhkan 2 lembar daun pandan, potong-potong
1. Jangan lupa secukupnya kaldu ayam
1. Tambah 1/2 sdt merica bubuk
1. Jangan lupa sedikit air
1. Harus ada secukupnya minyak untuk menumis
1. Diperlukan  BUMBU HALUS:
1. Jangan lupa 30 bh rawit merah (boleh dikurangi)
1. Harus ada 15 bh cabe merah keriting
1. Siapkan 5 siung bawang merah
1. Harus ada 3 siung bawang putih
1. Diperlukan 1 ruas jari jahe
1. Tambah 2 ruas jari lengkoas
1. Tambah 1 ruas jari kunyit
1. Jangan lupa 2 butir kemiri




<!--inarticleads2-->

##### Cara membuat  66. Ayam Rica - Rica Kemangi:

1. Tumis bumbu halus sampai wangi, lalu tambahkan serei, daun salam dan daun jeruk. masak sebentar. lalu tambahkan daun pandan.
1. Masukkan ayam, masak sampai ayam berubah warna. lalu tambahkan air sedikit..
1. Tambahkan merica dan kaldu bubuk, koreksi rasa. masak sampai air agak menyusut. lalu tambahkan kemangi.
1. Masak terus hingga air asat dan ayam empuk. Angkat, sajikan dengan nasi hangat..
1. SELESAI... 😁




Demikianlah cara membuat 66. ayam rica - rica kemangi yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan cepat, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
