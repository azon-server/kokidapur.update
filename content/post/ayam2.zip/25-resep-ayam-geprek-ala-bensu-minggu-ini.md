---
description: "Resep : Ayam geprek ala bensu minggu ini"
title: "Resep : Ayam geprek ala bensu minggu ini"
slug: 25-resep-ayam-geprek-ala-bensu-minggu-ini
date: 2020-11-12T06:02:26.900Z
image: https://img-global.cpcdn.com/recipes/3583e14d0857f7d3/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3583e14d0857f7d3/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3583e14d0857f7d3/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg
author: Gertrude King
ratingvalue: 4.8
reviewcount: 40552
recipeingredient:
- "1/4 kg ayam"
- "1 butir telur"
- " Tepung bumbu sajiku"
- " Bumbu marinasi ayam"
- "1 sdt Garam"
- "1 sdt Ketumbar"
- "3 siung Bawang merah"
- "2 siung Bawang putih"
- " Sambal"
- "Segenggam Cengek setan"
- "3 siung Bawang putih"
- " Garam"
- " Gula"
- " Penyedap rasa"
- " Minyak goreng"
recipeinstructions:
- "Bersihkan ayam, lumuri dengan bumbu marinasi yg sudah dihaluskan. Diamkan selama 30menit."
- "Buat tepung bumbu basah:Ambil 3 sendok tepung bumbu campur dengan telur."
- "Gulingkan ayam ke dalam tepung bumbu kering, kemudian ke dalam tepung bumbu basah, lalu ke dalam tepung bumbu kering. Lalu goreng dg api kecil hingga kecoklatan."
- "Goreng cengek setan dan bawang putih stengah matang. Uleg kasar, tambahkan garam gula,penyedap rasa. Cek rasa"
- "Geprek ayam yg sudah digoreng, Lumuri dg sambal. Siap dihidangkan"
categories:
- Recipe
tags:
- ayam
- geprek
- ala

katakunci: ayam geprek ala 
nutrition: 225 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam geprek ala bensu](https://img-global.cpcdn.com/recipes/3583e14d0857f7d3/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas atau gurih. Karasteristik masakan Indonesia ayam geprek ala bensu yang kaya dengan bumbu memberikan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kehangatan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam geprek ala bensu untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang dapat anda praktekkan salah satunya ayam geprek ala bensu yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep ayam geprek ala bensu tanpa harus bersusah payah.
Seperti resep Ayam geprek ala bensu yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam geprek ala bensu:

1. Dibutuhkan 1/4 kg ayam
1. Harap siapkan 1 butir telur
1. Harus ada  Tepung bumbu sajiku
1. Diperlukan  Bumbu marinasi ayam
1. Jangan lupa 1 sdt Garam
1. Jangan lupa 1 sdt Ketumbar
1. Tambah 3 siung Bawang merah
1. Harus ada 2 siung Bawang putih
1. Diperlukan  Sambal
1. Diperlukan Segenggam Cengek setan
1. Siapkan 3 siung Bawang putih
1. Dibutuhkan  Garam
1. Diperlukan  Gula
1. Diperlukan  Penyedap rasa
1. Dibutuhkan  Minyak goreng




<!--inarticleads2-->

##### Cara membuat  Ayam geprek ala bensu:

1. Bersihkan ayam, lumuri dengan bumbu marinasi yg sudah dihaluskan. Diamkan selama 30menit.
1. Buat tepung bumbu basah:Ambil 3 sendok tepung bumbu campur dengan telur.
1. Gulingkan ayam ke dalam tepung bumbu kering, kemudian ke dalam tepung bumbu basah, lalu ke dalam tepung bumbu kering. Lalu goreng dg api kecil hingga kecoklatan.
1. Goreng cengek setan dan bawang putih stengah matang. Uleg kasar, tambahkan garam gula,penyedap rasa. Cek rasa
1. Geprek ayam yg sudah digoreng, Lumuri dg sambal. Siap dihidangkan




Demikianlah cara membuat ayam geprek ala bensu yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
