---
description: "Bagaimana untuk membuat Ayam Rica Rica Kemangi Homemade"
title: "Bagaimana untuk membuat Ayam Rica Rica Kemangi Homemade"
slug: 403-bagaimana-untuk-membuat-ayam-rica-rica-kemangi-homemade
date: 2020-11-13T02:46:29.289Z
image: https://img-global.cpcdn.com/recipes/fa0639ed26ffe719/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fa0639ed26ffe719/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fa0639ed26ffe719/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Della Reese
ratingvalue: 4.3
reviewcount: 6953
recipeingredient:
- "1 kg ayam"
- "8 lembar daun jeruk"
- "2 lembar daun salam"
- "2 batang serai ambil putihnya geprek"
- "1 ikat daun kemangi"
- "sesuai selera Gula"
- "sesuai selera Garam"
- "sesuai selera Penyedap rasa"
- " Bumbu Halus "
- "10 butir Bawang merah"
- "8 siung Bawang putih"
- "12 buah Cabe Merah Besar"
- "5 buah Cabe Rawit"
- "1 ruas Jari Laos"
- "2 ruas Jari Kunyit"
- "1 ruas Jari Jahe"
- "1 sdm Ketumbar"
- "1/2 sdm merica butir"
- "4 butir kemiri"
recipeinstructions:
- "Tumis bumbu halus beserta daun jeruk, daun salam &amp; serai"
- "Setelah bumbu matang masukkan ayam tumis sebentar sampai ayam berubah warna,setelah itu masukkan air secukupnya sampai ayam terendam."
- "Setelah mendidih masukkan garam, gula, penyedap rasa &amp; daun kemangi."
- "Koreksi rasa &amp; sajikan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 277 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/fa0639ed26ffe719/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis atau renyah. Ciri masakan Indonesia ayam rica rica kemangi yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kehangatan keluarga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Ayam Rica Rica Kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang dapat anda coba salah satunya ayam rica rica kemangi yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Dibutuhkan 1 kg ayam
1. Diperlukan 8 lembar daun jeruk
1. Harus ada 2 lembar daun salam
1. Jangan lupa 2 batang serai ambil putihnya geprek
1. Dibutuhkan 1 ikat daun kemangi
1. Harus ada sesuai selera Gula
1. Jangan lupa sesuai selera Garam
1. Dibutuhkan sesuai selera Penyedap rasa
1. Tambah  Bumbu Halus :
1. Tambah 10 butir Bawang merah
1. Siapkan 8 siung Bawang putih
1. Siapkan 12 buah Cabe Merah Besar
1. Harap siapkan 5 buah Cabe Rawit
1. Diperlukan 1 ruas Jari Laos
1. Jangan lupa 2 ruas Jari Kunyit
1. Siapkan 1 ruas Jari Jahe
1. Harap siapkan 1 sdm Ketumbar
1. Harus ada 1/2 sdm merica butir
1. Jangan lupa 4 butir kemiri




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Rica Kemangi:

1. Tumis bumbu halus beserta daun jeruk, daun salam &amp; serai
1. Setelah bumbu matang masukkan ayam tumis sebentar sampai ayam berubah warna,setelah itu masukkan air secukupnya sampai ayam terendam.
1. Setelah mendidih masukkan garam, gula, penyedap rasa &amp; daun kemangi.
1. Koreksi rasa &amp; sajikan.




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
