---
description: "Resep : Ayam rica² daun kemangi Homemade"
title: "Resep : Ayam rica² daun kemangi Homemade"
slug: 242-resep-ayam-rica-daun-kemangi-homemade
date: 2021-01-31T06:20:06.159Z
image: https://img-global.cpcdn.com/recipes/80ce77a882171fd3/751x532cq70/ayam-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/80ce77a882171fd3/751x532cq70/ayam-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/80ce77a882171fd3/751x532cq70/ayam-rica-daun-kemangi-foto-resep-utama.jpg
author: Shane Alexander
ratingvalue: 5
reviewcount: 4485
recipeingredient:
- "1 ekor ayam potong 10"
- " Bumbu ungkep "
- "1 ruas jari kunyit"
- "1 ruas jari jahe"
- "3 buat kemiri"
- "3 buah bawang merah"
- "3 buah bawang putih"
- "2 lbr sereh geprek"
- "1 buah lengkuas geprek"
- "3 buah daun salam"
- "2 buah daun jeruk sobek"
- " Bumbu halus "
- "10 buah cabe merah keriting"
- "2 buah cabe merah besar"
- "5 buah cabe rawit merah"
- "1 buah tomat"
- "3 buah bawang merah"
- "3 buah bawang putih"
- "secukupnya Garam"
- "secukupnya Gula putih"
- "3 ikat daun kemangi lebih banyak lebih nikmat"
recipeinstructions:
- "Cuci ayam hingga bersih, rebus ayam dgn bumbu ungkep. Matikan api jika sudah empuk dan air tiris."
- "Panaskan minyak goreng, tumis bumbu yang sudah dihaluskan hingga harum, tambahkan gula putih dan air sedikit lalu masukkan ayam yang sudah diungkep tadi, aduk² supaya bumbu meresap dan merata."
- "Jika air sudah tiris, tambahkan daun kemangi sambil diaduk hingga merata."
- "Koreksi rasa, matikan api. Angkat dan sajikan👌"
categories:
- Recipe
tags:
- ayam
- rica
- daun

katakunci: ayam rica daun 
nutrition: 273 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT37M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam rica² daun kemangi](https://img-global.cpcdn.com/recipes/80ce77a882171fd3/751x532cq70/ayam-rica-daun-kemangi-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang patut kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica² daun kemangi yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan keistimewahan yang merupakan keragaman Nusantara



Kehangatan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam rica² daun kemangi untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang dapat anda contoh salah satunya ayam rica² daun kemangi yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep ayam rica² daun kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica² daun kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica² daun kemangi:

1. Tambah 1 ekor ayam (potong 10)
1. Harus ada  Bumbu ungkep :
1. Dibutuhkan 1 ruas jari kunyit
1. Harus ada 1 ruas jari jahe
1. Harap siapkan 3 buat kemiri
1. Tambah 3 buah bawang merah
1. Harap siapkan 3 buah bawang putih
1. Tambah 2 lbr sereh (geprek)
1. Diperlukan 1 buah lengkuas (geprek)
1. Harap siapkan 3 buah daun salam
1. Siapkan 2 buah daun jeruk (sobek²)
1. Dibutuhkan  Bumbu halus :
1. Jangan lupa 10 buah cabe merah keriting
1. Diperlukan 2 buah cabe merah besar
1. Harap siapkan 5 buah cabe rawit merah
1. Harap siapkan 1 buah tomat
1. Harap siapkan 3 buah bawang merah
1. Jangan lupa 3 buah bawang putih
1. Siapkan secukupnya Garam
1. Diperlukan secukupnya Gula putih
1. Harus ada 3 ikat daun kemangi (lebih banyak lebih nikmat)




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica² daun kemangi:

1. Cuci ayam hingga bersih, rebus ayam dgn bumbu ungkep. Matikan api jika sudah empuk dan air tiris.
1. Panaskan minyak goreng, tumis bumbu yang sudah dihaluskan hingga harum, tambahkan gula putih dan air sedikit lalu masukkan ayam yang sudah diungkep tadi, aduk² supaya bumbu meresap dan merata.
1. Jika air sudah tiris, tambahkan daun kemangi sambil diaduk hingga merata.
1. Koreksi rasa, matikan api. Angkat dan sajikan👌




Demikianlah cara membuat ayam rica² daun kemangi yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat gampang dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
