---
description: "Bagaimana menyiapakan Ayam Rica Kemangi (resep mertua ❤) Teruji"
title: "Bagaimana menyiapakan Ayam Rica Kemangi (resep mertua ❤) Teruji"
slug: 180-bagaimana-menyiapakan-ayam-rica-kemangi-resep-mertua-teruji
date: 2020-12-27T22:53:14.178Z
image: https://img-global.cpcdn.com/recipes/8bf3c17925fe646d/751x532cq70/ayam-rica-kemangi-resep-mertua-❤-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8bf3c17925fe646d/751x532cq70/ayam-rica-kemangi-resep-mertua-❤-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8bf3c17925fe646d/751x532cq70/ayam-rica-kemangi-resep-mertua-❤-foto-resep-utama.jpg
author: Katie Ramsey
ratingvalue: 4.3
reviewcount: 11656
recipeingredient:
- "300 gr ayam"
- " Daun kemangi"
- " Daun jeruk"
- " Bumbu Blender"
- "4 bawang merah"
- "6 bawang putih"
- "3 cabe rawit merah"
- "4 cabe keriting merah"
- "1 butir kemiri"
- "jempol Jahe sekuku"
- "jempol Kunyit sekuku"
- "1/2 batang serai"
recipeinstructions:
- "Goreng ayam sebentar (kata mertua ku, kalo ayam kampung enaknya ga ush goreng dulu, tapi kalo ayam biasa enaknya digoreng dulu sebentar) setelah digoreng tiriskan."
- "Cincang daun jeruk lalu sisihkan"
- "Blender semua bumbu. Lalu tumis sebentar bumbunya dan beri air. Masukan garam gula merica dan totole. Koreksi rasa. Setelah rasa pas, masukan ayamnya lalu masak sampai air berkurang. Lalu masukan daun kemangi. Dan taburkan daun jeruk cincang diatasnya aduk2 sebentar di atas api. Dan ayam rica-rica siap disajikan 😊"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 115 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica Kemangi (resep mertua ❤)](https://img-global.cpcdn.com/recipes/8bf3c17925fe646d/751x532cq70/ayam-rica-kemangi-resep-mertua-❤-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica kemangi (resep mertua ❤) yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia

Kehangatan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah memasak Ayam Rica Kemangi (resep mertua ❤) untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang bisa anda praktekkan salah satunya ayam rica kemangi (resep mertua ❤) yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep ayam rica kemangi (resep mertua ❤) tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi (resep mertua ❤) yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 12 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi (resep mertua ❤):

1. Diperlukan 300 gr ayam
1. Tambah  Daun kemangi
1. Tambah  Daun jeruk
1. Tambah  Bumbu Blender
1. Harap siapkan 4 bawang merah
1. Dibutuhkan 6 bawang putih
1. Tambah 3 cabe rawit merah
1. Jangan lupa 4 cabe keriting merah
1. Jangan lupa 1 butir kemiri
1. Jangan lupa jempol Jahe sekuku
1. Jangan lupa jempol Kunyit sekuku
1. Dibutuhkan 1/2 batang serai




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Kemangi (resep mertua ❤):

1. Goreng ayam sebentar (kata mertua ku, kalo ayam kampung enaknya ga ush goreng dulu, tapi kalo ayam biasa enaknya digoreng dulu sebentar) setelah digoreng tiriskan.
1. Cincang daun jeruk lalu sisihkan
1. Blender semua bumbu. Lalu tumis sebentar bumbunya dan beri air. Masukan garam gula merica dan totole. Koreksi rasa. Setelah rasa pas, masukan ayamnya lalu masak sampai air berkurang. Lalu masukan daun kemangi. Dan taburkan daun jeruk cincang diatasnya aduk2 sebentar di atas api. Dan ayam rica-rica siap disajikan 😊




Demikianlah cara membuat ayam rica kemangi (resep mertua ❤) yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
