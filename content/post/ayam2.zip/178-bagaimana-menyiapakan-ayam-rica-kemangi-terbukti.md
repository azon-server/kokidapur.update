---
description: "Bagaimana menyiapakan Ayam rica kemangi Terbukti"
title: "Bagaimana menyiapakan Ayam rica kemangi Terbukti"
slug: 178-bagaimana-menyiapakan-ayam-rica-kemangi-terbukti
date: 2021-01-08T12:13:17.522Z
image: https://img-global.cpcdn.com/recipes/ff594703b5ac9a60/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ff594703b5ac9a60/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ff594703b5ac9a60/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Alexander Tate
ratingvalue: 4.9
reviewcount: 49288
recipeingredient:
- "1/2 kg ayam potongan paha"
- " Bumbu halus"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "10 buah cabai rawit"
- "1 buah cabai merah besar"
- "2 butir kemiri"
- "1 cm kunyit"
- " Bumbu cemplung"
- "1/2 ikat kemangi"
- "2 batang sereh"
- "3 lbr daun salam"
- "5 lbr daun jeruk"
- "2 cm lengkuas dikeprak"
- "2 cm jahe dikeprak"
- " Gula"
- " Garam"
- " Penyedap"
recipeinstructions:
- "Siapkan ayam yang sudah dipotong beberapa bagian. Cuci dan marinasi dengan jeruk nipis, sisihkan"
- "Siapkan bumbu halus dan bumbu cemplung"
- "Tumis bumbu halus beserta daun jeruk, sereh, salam, lengkuas dan jahe. Tumis hingga harum dan matang sempurna (biasanya minyak sudah terpisah dari bumbu)."
- "Tambahkan air secukupnya dan masukkan ayam yang telah di marinasi. Tunggu hingga mendidih dan bumbu surut kurang lebih 20 menit dengan api kecil."
- "Koreksi rasa, jika sudah pas masukkan kemangi. Bolak balik sebentar hingga kemangi layu, angkat dan siap disajikan."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 206 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/ff594703b5ac9a60/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga renyah. Ciri kuliner Nusantara ayam rica kemangi yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga bisa ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Ayam rica kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang bisa anda buat salah satunya ayam rica kemangi yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica kemangi:

1. Siapkan 1/2 kg ayam potongan paha
1. Harus ada  Bumbu halus
1. Siapkan 6 siung bawang merah
1. Harap siapkan 3 siung bawang putih
1. Siapkan 10 buah cabai rawit
1. Harus ada 1 buah cabai merah besar
1. Tambah 2 butir kemiri
1. Diperlukan 1 cm kunyit
1. Harap siapkan  Bumbu cemplung
1. Harus ada 1/2 ikat kemangi
1. Harap siapkan 2 batang sereh
1. Diperlukan 3 lbr daun salam
1. Dibutuhkan 5 lbr daun jeruk
1. Jangan lupa 2 cm lengkuas dikeprak
1. Tambah 2 cm jahe dikeprak
1. Harap siapkan  Gula
1. Dibutuhkan  Garam
1. Tambah  Penyedap




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica kemangi:

1. Siapkan ayam yang sudah dipotong beberapa bagian. Cuci dan marinasi dengan jeruk nipis, sisihkan
1. Siapkan bumbu halus dan bumbu cemplung
1. Tumis bumbu halus beserta daun jeruk, sereh, salam, lengkuas dan jahe. Tumis hingga harum dan matang sempurna (biasanya minyak sudah terpisah dari bumbu).
1. Tambahkan air secukupnya dan masukkan ayam yang telah di marinasi. Tunggu hingga mendidih dan bumbu surut kurang lebih 20 menit dengan api kecil.
1. Koreksi rasa, jika sudah pas masukkan kemangi. Bolak balik sebentar hingga kemangi layu, angkat dan siap disajikan.




Demikianlah cara membuat ayam rica kemangi yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat gampang dan teruji, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
