---
description: "Cara singkat menyiapakan Ayam Geprek Homemade ala Bensu terupdate"
title: "Cara singkat menyiapakan Ayam Geprek Homemade ala Bensu terupdate"
slug: 60-cara-singkat-menyiapakan-ayam-geprek-homemade-ala-bensu-terupdate
date: 2020-12-11T11:03:41.241Z
image: https://img-global.cpcdn.com/recipes/3312dcde3847c875/751x532cq70/ayam-geprek-homemade-ala-bensu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3312dcde3847c875/751x532cq70/ayam-geprek-homemade-ala-bensu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3312dcde3847c875/751x532cq70/ayam-geprek-homemade-ala-bensu-foto-resep-utama.jpg
author: Lillian Nelson
ratingvalue: 4
reviewcount: 46967
recipeingredient:
- "1/2 kg Fillet dada ayam dipotong sesuai selera"
- "2 bks Tepung bumbu segala merk saya pakai sasa ayam crispy"
- "secukupnya Lada bubuk"
- "secukupnya Garam"
- " Air"
- " Minyak goreng"
- "  Sambal "
- "1 siung bawang putih utk masing potongan ayam"
- " Cabe rawit sesuai selera"
- "secukupnya Gula"
recipeinstructions:
- "Cuci fillet dada ayam yg telah dipotong. Kemudian lumuri dengan lada dan garam secukupnya, remas&#34; sebentar, lalu masukkan ke dalam lemari es selama kurang lebih 15 menit."
- "Buat adonan tepung basah agak kental (tepung bumbu sasa dicampur air) dan tepung kering ke dlm wadah yg berbeda."
- "Keluarkan ayam yg telah dilumuri dengan lada dan garam dari lemari es. Kemudian celupkan satu persatu potongan ayam ke dalam tepung basah lalu tepung kering secara bergantian."
- "Panaskan minyak diatas kompor dgn api sedang."
- "Kemudian goreng ayam hingga kuning keemasan."
- "Sambil menunggu ayam matang, ulek cabe rawit (sesuai selera) dengan 1 siung bawang putih, beri sedikit garam dan gula."
- "Setelah ayam matang angkat (tanpa ditiriskan) langsung geprek dengan sambal yg sudah diulek hingga benar&#34; tercampur rata."
- "Ayam geprek homemade siap disantap bersama nasi putih hangat."
categories:
- Recipe
tags:
- ayam
- geprek
- homemade

katakunci: ayam geprek homemade 
nutrition: 142 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Geprek Homemade ala Bensu](https://img-global.cpcdn.com/recipes/3312dcde3847c875/751x532cq70/ayam-geprek-homemade-ala-bensu-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga gurih. Ciri khas masakan Indonesia ayam geprek homemade ala bensu yang kaya dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga bisa didapat dengan cara simple. Salah satunya adalah memasak Ayam Geprek Homemade ala Bensu untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang dapat anda contoh salah satunya ayam geprek homemade ala bensu yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam geprek homemade ala bensu tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Homemade ala Bensu yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 10 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Homemade ala Bensu:

1. Siapkan 1/2 kg Fillet dada ayam dipotong sesuai selera
1. Dibutuhkan 2 bks Tepung bumbu segala merk (saya pakai sasa ayam crispy)
1. Jangan lupa secukupnya Lada bubuk
1. Siapkan secukupnya Garam
1. Siapkan  Air
1. Harus ada  Minyak goreng
1. Jangan lupa  # Sambal #
1. Jangan lupa 1 siung bawang putih utk masing&#34; potongan ayam
1. Tambah  Cabe rawit (sesuai selera)
1. Jangan lupa secukupnya Gula




<!--inarticleads2-->

##### Langkah membuat  Ayam Geprek Homemade ala Bensu:

1. Cuci fillet dada ayam yg telah dipotong. Kemudian lumuri dengan lada dan garam secukupnya, remas&#34; sebentar, lalu masukkan ke dalam lemari es selama kurang lebih 15 menit.
1. Buat adonan tepung basah agak kental (tepung bumbu sasa dicampur air) dan tepung kering ke dlm wadah yg berbeda.
1. Keluarkan ayam yg telah dilumuri dengan lada dan garam dari lemari es. Kemudian celupkan satu persatu potongan ayam ke dalam tepung basah lalu tepung kering secara bergantian.
1. Panaskan minyak diatas kompor dgn api sedang.
1. Kemudian goreng ayam hingga kuning keemasan.
1. Sambil menunggu ayam matang, ulek cabe rawit (sesuai selera) dengan 1 siung bawang putih, beri sedikit garam dan gula.
1. Setelah ayam matang angkat (tanpa ditiriskan) langsung geprek dengan sambal yg sudah diulek hingga benar&#34; tercampur rata.
1. Ayam geprek homemade siap disantap bersama nasi putih hangat.




Demikianlah cara membuat ayam geprek homemade ala bensu yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
