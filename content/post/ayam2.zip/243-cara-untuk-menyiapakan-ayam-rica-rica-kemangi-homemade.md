---
description: "Cara untuk menyiapakan Ayam Rica Rica Kemangi Homemade"
title: "Cara untuk menyiapakan Ayam Rica Rica Kemangi Homemade"
slug: 243-cara-untuk-menyiapakan-ayam-rica-rica-kemangi-homemade
date: 2021-01-30T22:02:29.591Z
image: https://img-global.cpcdn.com/recipes/8b111a508e776f2c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8b111a508e776f2c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8b111a508e776f2c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Gilbert Cain
ratingvalue: 4.6
reviewcount: 23017
recipeingredient:
- "1 ekor ayam potong 8"
- " Bumbu halus "
- "5 siung bawang merah ukuran besar"
- "3 siung bawang putih ukuran besar"
- "10 buah cabe rawit merah ukuran besar bisa ganti cabe merah"
- "Sejempol kunyit"
- "Seruas jahe"
- " Ketumbar 1sd saya pakai yang bubuk"
- " Bahan pelengkap"
- "1 buah tomat potong kecil kecil"
- "2 lbr daun jeruk"
- "1 btg sere saya potong 2 kemudian di geprek"
- "Sejempol lengkuas di geprek"
- "1 genggam kemangi"
recipeinstructions:
- "Blender halus bumbu di atas lalu tumis bersama bahan pelengkap hingga harum dan menyatu"
- "Masukkan ayam lalu aduk aduk sampai bumbu Merata"
- "Tambahkan air sampai ayam tenggelam lalu masukkan tomat"
- "Masak hingga ayam empuk dan tomat hancur lalu tambahkan kemangi (saya pakai kemangi serbuk, akan lebih bagus kalau pakai kemangi utuh),garam,gula,kaldu jamur. Tunggu hingga layu dan air menyusut.."
- "Buang sereh dan lengkuas, masakan siap untuk disajikan.. 💕"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 261 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/8b111a508e776f2c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan enak. Ciri masakan Indonesia ayam rica rica kemangi yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica Rica Kemangi untuk orang di rumah. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang dapat anda praktekkan salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi:

1. Harap siapkan 1 ekor ayam potong 8
1. Dibutuhkan  Bumbu halus :
1. Dibutuhkan 5 siung bawang merah ukuran besar
1. Siapkan 3 siung bawang putih ukuran besar
1. Diperlukan 10 buah cabe rawit merah ukuran besar (bisa ganti cabe merah)
1. Harus ada Sejempol kunyit
1. Harap siapkan Seruas jahe
1. Jangan lupa  Ketumbar 1sd (saya pakai yang bubuk)
1. Harus ada  Bahan pelengkap
1. Tambah 1 buah tomat potong kecil kecil
1. Diperlukan 2 lbr daun jeruk
1. Tambah 1 btg sere (saya potong 2 kemudian di geprek)
1. Harus ada Sejempol lengkuas di geprek
1. Siapkan 1 genggam kemangi




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Rica Kemangi:

1. Blender halus bumbu di atas lalu tumis bersama bahan pelengkap hingga harum dan menyatu
1. Masukkan ayam lalu aduk aduk sampai bumbu Merata
1. Tambahkan air sampai ayam tenggelam lalu masukkan tomat
1. Masak hingga ayam empuk dan tomat hancur lalu tambahkan kemangi (saya pakai kemangi serbuk, akan lebih bagus kalau pakai kemangi utuh),garam,gula,kaldu jamur. Tunggu hingga layu dan air menyusut..
1. Buang sereh dan lengkuas, masakan siap untuk disajikan.. 💕




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan cepat, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
