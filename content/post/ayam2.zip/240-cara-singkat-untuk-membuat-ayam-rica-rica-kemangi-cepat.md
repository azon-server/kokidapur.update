---
description: "Cara singkat untuk membuat Ayam Rica-rica Kemangi Cepat"
title: "Cara singkat untuk membuat Ayam Rica-rica Kemangi Cepat"
slug: 240-cara-singkat-untuk-membuat-ayam-rica-rica-kemangi-cepat
date: 2020-09-22T04:14:50.439Z
image: https://img-global.cpcdn.com/recipes/92c2b61eb5624e99/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/92c2b61eb5624e99/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/92c2b61eb5624e99/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Johnny Daniels
ratingvalue: 4.1
reviewcount: 21948
recipeingredient:
- "1 ekor ayam potong sedang"
- "1 buah jeruk nipis"
- "1 ikat kemangi"
- "1 buah tomat"
- "2 batang sereh"
- "1 ruas lengkuas"
- "1 ruas jahe"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "100 ml air matang"
- " Bumbu halus"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "1 ruas kunyit"
- "3 butir kemiri"
- "6 buah cabe merah keriting"
- "1/2 sdt ketumbar"
- "1/2 sdt lada bubuk"
- "1 sdt kaldu bubuk"
- "Secukupnya garam  gula"
recipeinstructions:
- "Cuci bersih ayam, beri perasan jeruk nipis, kemudian diamkan selama 10 menit, lalu cuci bersih kembali. Goreng ayam setengah matang."
- "Blender bumbu halus, kemudian tumis sampai harum. Masukan daun salam, daun jeruk, lengkuas, jahe &amp; sereh yg Sdh di geprek. Tunggu sampai bumbu sedikit mengental. Masukan ayam, tambahkan sedikit air, garam, gula &amp; kaldu ayam bubuk aduk rata,."
- "Masukan tomat &amp; kemangi, aduk rata kembali sebentar saja lalu koreksi rasa. Setelah pas matikan api &amp; Siap disajikan."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 169 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/92c2b61eb5624e99/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang harus kita lestarikan karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica-rica kemangi yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa keistimewahan yang merupakan keragaman Nusantara

Kedekatan keluarga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica-rica Kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang dapat anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica Kemangi:

1. Siapkan 1 ekor ayam potong sedang
1. Siapkan 1 buah jeruk nipis
1. Dibutuhkan 1 ikat kemangi
1. Diperlukan 1 buah tomat
1. Dibutuhkan 2 batang sereh
1. Jangan lupa 1 ruas lengkuas
1. Harus ada 1 ruas jahe
1. Jangan lupa 2 lembar daun salam
1. Harap siapkan 3 lembar daun jeruk
1. Diperlukan 100 ml air matang
1. Tambah  Bumbu halus:
1. Jangan lupa 6 siung bawang merah
1. Dibutuhkan 3 siung bawang putih
1. Siapkan 1 ruas kunyit
1. Harap siapkan 3 butir kemiri
1. Tambah 6 buah cabe merah keriting
1. Diperlukan 1/2 sdt ketumbar
1. Tambah 1/2 sdt lada bubuk
1. Siapkan 1 sdt kaldu bubuk
1. Harus ada Secukupnya garam &amp; gula




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-rica Kemangi:

1. Cuci bersih ayam, beri perasan jeruk nipis, kemudian diamkan selama 10 menit, lalu cuci bersih kembali. Goreng ayam setengah matang.
1. Blender bumbu halus, kemudian tumis sampai harum. Masukan daun salam, daun jeruk, lengkuas, jahe &amp; sereh yg Sdh di geprek. Tunggu sampai bumbu sedikit mengental. Masukan ayam, tambahkan sedikit air, garam, gula &amp; kaldu ayam bubuk aduk rata,.
1. Masukan tomat &amp; kemangi, aduk rata kembali sebentar saja lalu koreksi rasa. Setelah pas matikan api &amp; Siap disajikan.




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
