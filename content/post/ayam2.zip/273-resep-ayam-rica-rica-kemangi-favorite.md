---
description: "Resep : Ayam Rica-Rica Kemangi Favorite"
title: "Resep : Ayam Rica-Rica Kemangi Favorite"
slug: 273-resep-ayam-rica-rica-kemangi-favorite
date: 2020-09-29T06:47:11.994Z
image: https://img-global.cpcdn.com/recipes/314507767aae494e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/314507767aae494e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/314507767aae494e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Sophia Jackson
ratingvalue: 4.5
reviewcount: 25628
recipeingredient:
- "900 gr ayam negripotong"
- "1 sdt bubuk kunyitkunyit di haluskan"
- "1 sdt garam"
- " Bumbu halus "
- "10 siung bwang merah"
- "4 siung bawang putih"
- "5 buah cabai merah"
- "1 ruas jari jahe"
- "1 ruas jari kunyit"
- " Bumbu Cemplung "
- "2 batang serai"
- "1 ruas lengkuas"
- "4 lembar daun salam"
- "3 lembar daun jeruk"
- " Bumbu tambahan"
- "sesuai selera Cabai rawit"
- "1 buah tomat potong wegdes"
- "secukupnya Daun kemangi"
- "secukupnya Garam gula merica"
recipeinstructions:
- "Cuci bersih ayam, marinasi dengan kunyit dan garam selama 10-20 menit. Kemudian goreng sebentar saja, asal matang"
- "Haluskan bumbu, kemudian tumis sambil masukkan serai, lengkuas dan daun2an"
- "Masak sampai harum dan bumbu sudah mengeluarkan minyak, masukkan ayam, beri air sedikit biarkan sebentar sambil masukkan garam,gula, dan merica secukupnya. Kemudian masukkan kemangi, tomat, dan cabai rawit aduk rata. Cek rasa. Matikan api"
- "Hidangkan dengan nasi panasss hmmm nikmat lah pokoknya"
- "Selamat menikmati. Makan dengan cabai rawit nya, puueedeesss"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 265 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/314507767aae494e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita jaga karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan keistimewahan yang merupakan keragaman Indonesia

Kedekatan rumah tangga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica-Rica Kemangi untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang bisa anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica Kemangi:

1. Jangan lupa 900 gr ayam negri/potong
1. Dibutuhkan 1 sdt bubuk kunyit/kunyit di haluskan
1. Jangan lupa 1 sdt garam
1. Siapkan  Bumbu halus :
1. Dibutuhkan 10 siung bwang merah
1. Dibutuhkan 4 siung bawang putih
1. Siapkan 5 buah cabai merah
1. Siapkan 1 ruas jari jahe
1. Dibutuhkan 1 ruas jari kunyit
1. Jangan lupa  Bumbu Cemplung :
1. Harus ada 2 batang serai
1. Harap siapkan 1 ruas lengkuas
1. Dibutuhkan 4 lembar daun salam
1. Dibutuhkan 3 lembar daun jeruk
1. Dibutuhkan  Bumbu tambahan
1. Tambah sesuai selera Cabai rawit
1. Harap siapkan 1 buah tomat potong wegdes
1. Dibutuhkan secukupnya Daun kemangi
1. Diperlukan secukupnya Garam, gula, merica




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica Kemangi:

1. Cuci bersih ayam, marinasi dengan kunyit dan garam selama 10-20 menit. Kemudian goreng sebentar saja, asal matang
1. Haluskan bumbu, kemudian tumis sambil masukkan serai, lengkuas dan daun2an
1. Masak sampai harum dan bumbu sudah mengeluarkan minyak, masukkan ayam, beri air sedikit biarkan sebentar sambil masukkan garam,gula, dan merica secukupnya. Kemudian masukkan kemangi, tomat, dan cabai rawit aduk rata. Cek rasa. Matikan api
1. Hidangkan dengan nasi panasss hmmm nikmat lah pokoknya
1. Selamat menikmati. Makan dengan cabai rawit nya, puueedeesss




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
