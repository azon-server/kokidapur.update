---
description: "Cara singkat menyiapakan Ayam Rica-rica Kemangi Teruji"
title: "Cara singkat menyiapakan Ayam Rica-rica Kemangi Teruji"
slug: 239-cara-singkat-menyiapakan-ayam-rica-rica-kemangi-teruji
date: 2020-11-03T21:44:19.591Z
image: https://img-global.cpcdn.com/recipes/a7810060acd15532/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a7810060acd15532/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a7810060acd15532/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Noah Banks
ratingvalue: 4.2
reviewcount: 9542
recipeingredient:
- "1/4 Daging ayam"
- " Daun Kemangi"
- "2 siung bawang merah"
- "2 siung bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "4 buah Kemiri"
- "5 buah cabe merah keriting"
- "3 buah cabe rawit merah"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 batang sereh digeprek"
- "1 buah jeruk nipis"
- "1 sdt garam"
- "2 sdt kaldu bubuk"
- "1/4 Bks lada bubuk"
- "4 sdm minyak goreng"
- "secukupnya Air"
recipeinstructions:
- "Potong ayam menjaji 4 bagian"
- "Marinasi ayam menggunakan jeruk nipis dan sedikit garam, diamkan selama 10 menit."
- "Tambahkan air, dan ungkep ayam sebentar. Jika sudah terlihat matang sisihkan (air kaldunya simpan)"
- "Haluskan bawang merah, bawang putih, kemiri, kunyit, jahe, cabe merah dan cabe rawit."
- "Panaskan wajan, dan tumis bumbu beserta sereh, daun salam dan daun jeruk sampe harum."
- "Masukan air kaldu yang tadi di simpan, setelah mendidih masukan ayam. Masukan juga bumbu penyedap seperti, garam, kaldu bubuk dan merica."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 148 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/a7810060acd15532/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga empuk. Karasteristik masakan Nusantara ayam rica-rica kemangi yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga bisa didapat dengan cara simple. Salah satunya adalah memasak Ayam Rica-rica Kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang bisa anda contoh salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Kemangi:

1. Dibutuhkan 1/4 Daging ayam
1. Harus ada  Daun Kemangi
1. Harus ada 2 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Siapkan 1 ruas jahe
1. Harap siapkan 1 ruas kunyit
1. Jangan lupa 4 buah Kemiri
1. Harap siapkan 5 buah cabe merah keriting
1. Jangan lupa 3 buah cabe rawit merah
1. Siapkan 2 lembar daun salam
1. Tambah 2 lembar daun jeruk
1. Siapkan 1 batang sereh (digeprek)
1. Siapkan 1 buah jeruk nipis
1. Tambah 1 sdt garam
1. Dibutuhkan 2 sdt kaldu bubuk
1. Dibutuhkan 1/4 Bks lada bubuk
1. Harap siapkan 4 sdm minyak goreng
1. Diperlukan secukupnya Air




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-rica Kemangi:

1. Potong ayam menjaji 4 bagian
1. Marinasi ayam menggunakan jeruk nipis dan sedikit garam, diamkan selama 10 menit.
1. Tambahkan air, dan ungkep ayam sebentar. Jika sudah terlihat matang sisihkan (air kaldunya simpan)
1. Haluskan bawang merah, bawang putih, kemiri, kunyit, jahe, cabe merah dan cabe rawit.
1. Panaskan wajan, dan tumis bumbu beserta sereh, daun salam dan daun jeruk sampe harum.
1. Masukan air kaldu yang tadi di simpan, setelah mendidih masukan ayam. Masukan juga bumbu penyedap seperti, garam, kaldu bubuk dan merica.




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan cepat, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
