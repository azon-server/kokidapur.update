---
description: "Cara singkat untuk membuat Ayam rica rica kemangi Sempurna"
title: "Cara singkat untuk membuat Ayam rica rica kemangi Sempurna"
slug: 327-cara-singkat-untuk-membuat-ayam-rica-rica-kemangi-sempurna
date: 2020-10-09T08:56:02.607Z
image: https://img-global.cpcdn.com/recipes/295edca202eb0c43/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/295edca202eb0c43/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/295edca202eb0c43/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Mamie Harmon
ratingvalue: 4.9
reviewcount: 23530
recipeingredient:
- " Ayam yg sudah diungkep"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "15 biji rawit merah"
- "3 biji cabe merah keriting"
- "4 butir kemiri"
- " Lengkuas"
- " Kunyit"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "1 batang sereh geprek"
- " Kemangi"
- "1 sdt gula"
- "Sejumput garam"
recipeinstructions:
- "Haluskan semua bumbu lalu tumis sampai matang lalu masukkan ayam yg sudah diungkep dan aduk rata. Masak dengan api kecil"
- "Lalu tambahkan air sedikit/ air sisa ungkepan ayam. Tunggu sampai matang lalu cek rasa jika sudah oke masukkan kemangi dan matikan kompornya."
- "Ayam rica rica kemangi siap untuk disajikan dengan nasi hangat"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 272 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT44M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/295edca202eb0c43/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau enak. Karasteristik masakan Nusantara ayam rica rica kemangi yang kaya dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam rica rica kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang dapat anda buat salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi:

1. Harus ada  Ayam yg sudah diungkep
1. Diperlukan 5 siung bawang merah
1. Diperlukan 3 siung bawang putih
1. Siapkan 15 biji rawit merah
1. Harus ada 3 biji cabe merah keriting
1. Tambah 4 butir kemiri
1. Harus ada  Lengkuas
1. Diperlukan  Kunyit
1. Harap siapkan 2 lembar daun jeruk
1. Dibutuhkan 2 lembar daun salam
1. Tambah 1 batang sereh geprek
1. Diperlukan  Kemangi
1. Tambah 1 sdt gula
1. Jangan lupa Sejumput garam


Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Cara membuat  Ayam rica rica kemangi:

1. Haluskan semua bumbu lalu tumis sampai matang lalu masukkan ayam yg sudah diungkep dan aduk rata. Masak dengan api kecil
1. Lalu tambahkan air sedikit/ air sisa ungkepan ayam. Tunggu sampai matang lalu cek rasa jika sudah oke masukkan kemangi dan matikan kompornya.
1. Ayam rica rica kemangi siap untuk disajikan dengan nasi hangat


Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Siapa yang tidak mengenal lalapan daun kemangi di Indonesia ini. Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. 

Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan terbukti, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
