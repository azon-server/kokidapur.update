---
description: "Panduan membuat Ayam Geprek Kekinian ala Bensu terupdate"
title: "Panduan membuat Ayam Geprek Kekinian ala Bensu terupdate"
slug: 5-panduan-membuat-ayam-geprek-kekinian-ala-bensu-terupdate
date: 2020-11-23T01:12:11.295Z
image: https://img-global.cpcdn.com/recipes/177657fa44684622/751x532cq70/ayam-geprek-kekinian-ala-bensu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/177657fa44684622/751x532cq70/ayam-geprek-kekinian-ala-bensu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/177657fa44684622/751x532cq70/ayam-geprek-kekinian-ala-bensu-foto-resep-utama.jpg
author: Vernon Henderson
ratingvalue: 4.8
reviewcount: 25318
recipeingredient:
- " Bahan Rendaman Ayam"
- "1/4 kg ayam"
- "2 siung bawang putih haluskan"
- "1 sdt lada bubuk"
- "Secukupnya garam"
- " Adonan basah"
- " Air es"
- "6 sdm tepung terigu"
- "2 sdm tepung maizena"
- "1 sdm susu bubuk"
- "1 butir kuning telur"
- "1/2 sdt soda kue"
- "1/2 sdt lada bubuk"
- "Secukupnya garam"
- " Adonan kering"
- "6 sdm tepung terigu"
- "2 sdm tepung maizena"
- "1/2 sdt soda kue"
- "1 sdt kaldu bubuk ayam"
- "1/4 sdt garam"
- " Bahan sambal bawang"
- "25 cabe rawit jablay aku 15 cabe rawit jablay4 cabe keriting"
- "3 siung bawang putih"
- "Secukupnya gula merah"
- "Secukupnya garam"
recipeinstructions:
- "Cuci bersih semua bahan. Siapkan rendaman ayam. Rendam ayam dengan bumbu rendaman di kulkas sekitar 15 menit."
- "Campur rata semua adonan basah."
- "Campur rata semua adonan kering."
- "Gulingkan ayam ke adonan kering. Lalu celupkan ke adonan basah. Setelah itu gulingkan lagi ke adonan kering, sambil dicubit-cubit agar lapisan luar kriwil crispy."
- "Goreng ayam hingga matang dan crispy (api jangan terlalu besar, supaya ayam matang merata). Angkat, sisihkan."
- "Siapkan bahan sambal. Goreng cabe dan bawang 1/2 matang lalu angkat. Ulek kasar dan beri tambahan gula merah dan garam."
- "Geprek ayam yang sudah digoreng tadi, lalu beri topping sambal bawang. Sajikan! 😊🔥🔥"
categories:
- Recipe
tags:
- ayam
- geprek
- kekinian

katakunci: ayam geprek kekinian 
nutrition: 167 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Geprek Kekinian ala Bensu](https://img-global.cpcdn.com/recipes/177657fa44684622/751x532cq70/ayam-geprek-kekinian-ala-bensu-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga empuk. Ciri makanan Indonesia ayam geprek kekinian ala bensu yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.




Keharmonisan rumah tangga dapat diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam Geprek Kekinian ala Bensu untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang bisa anda contoh salah satunya ayam geprek kekinian ala bensu yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam geprek kekinian ala bensu tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Kekinian ala Bensu yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 25 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Kekinian ala Bensu:

1. Siapkan  Bahan Rendaman Ayam:
1. Harap siapkan 1/4 kg ayam
1. Tambah 2 siung bawang putih, haluskan
1. Harap siapkan 1 sdt lada bubuk
1. Harus ada Secukupnya garam
1. Tambah  Adonan basah:
1. Diperlukan  Air es
1. Harap siapkan 6 sdm tepung terigu
1. Siapkan 2 sdm tepung maizena
1. Harap siapkan 1 sdm susu bubuk
1. Harap siapkan 1 butir kuning telur
1. Jangan lupa 1/2 sdt soda kue
1. Tambah 1/2 sdt lada bubuk
1. Dibutuhkan Secukupnya garam
1. Tambah  Adonan kering:
1. Jangan lupa 6 sdm tepung terigu
1. Diperlukan 2 sdm tepung maizena
1. Harus ada 1/2 sdt soda kue
1. Harus ada 1 sdt kaldu bubuk ayam
1. Harap siapkan 1/4 sdt garam
1. Siapkan  Bahan sambal bawang:
1. Tambah 25 cabe rawit jablay (aku 15 cabe rawit jablay+4 cabe keriting)
1. Tambah 3 siung bawang putih
1. Siapkan Secukupnya gula merah
1. Tambah Secukupnya garam




<!--inarticleads2-->

##### Cara membuat  Ayam Geprek Kekinian ala Bensu:

1. Cuci bersih semua bahan. Siapkan rendaman ayam. Rendam ayam dengan bumbu rendaman di kulkas sekitar 15 menit.
1. Campur rata semua adonan basah.
1. Campur rata semua adonan kering.
1. Gulingkan ayam ke adonan kering. Lalu celupkan ke adonan basah. Setelah itu gulingkan lagi ke adonan kering, sambil dicubit-cubit agar lapisan luar kriwil crispy.
1. Goreng ayam hingga matang dan crispy (api jangan terlalu besar, supaya ayam matang merata). Angkat, sisihkan.
1. Siapkan bahan sambal. Goreng cabe dan bawang 1/2 matang lalu angkat. Ulek kasar dan beri tambahan gula merah dan garam.
1. Geprek ayam yang sudah digoreng tadi, lalu beri topping sambal bawang. Sajikan! 😊🔥🔥




Demikianlah cara membuat ayam geprek kekinian ala bensu yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
