---
description: "Step-by-Step membuat Ayam Rica Rica Kemangi Homemade"
title: "Step-by-Step membuat Ayam Rica Rica Kemangi Homemade"
slug: 238-step-by-step-membuat-ayam-rica-rica-kemangi-homemade
date: 2020-11-14T14:07:56.325Z
image: https://img-global.cpcdn.com/recipes/155e0f30aaaca26f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/155e0f30aaaca26f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/155e0f30aaaca26f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Travis Wilkins
ratingvalue: 4
reviewcount: 34524
recipeingredient:
- "1 ekor ayam potong sesuai selera"
- "1 ikat daun kemangi"
- "3 lembar daun jeruk"
- "3 lembar daun salam"
- "1 batang serai geprek"
- "10 buah cabe rawit sy pakai utuhaslinya halus"
- "secukupnya Garam merica gula dan kaldu"
- " Bumbu Halus "
- "1 ruas lengkuas"
- "1 ruas jahe"
- "1 ruas kunyit"
- "6 butir bawang merah"
- "3 siung bawang putih"
- "2 butir kemiri"
- "10 buah cabe merah sesuai selera"
recipeinstructions:
- "Cuci bersih ayam, tambahkan air perasan jeruk nipis sedikit, diamkan sktr 15 menit agar tidak bau amis. Cuci bersih lagi. Rebus ayam sebentar untuk menghilangkan kotoran dan ayam cepat empuk. Tiriskan."
- "Panaskan sedikit minyak, tumis daun jeruk,daun salam dan serai hingga harum. Tambahkan bumbu halus, tumis hingga wangi."
- "Masukkan ayam, tambahkan garam, gula, merica dan kaldu. Aduk rata. Tambahkan sedikit air. Aduk rata."
- "Jika ayam sudah empuk dan air menyusut tambahkan daun kemangi. Aduk sebentar. Koreksi rasa. Sajikan."
- "Hmm enaaak sekali 💖💖."
- "Note : disini saya pakai daging ayam bagian dada dan beberapa ceker ayam. Tapi untuk satu ayam utuh juga bisa atau disesuaikan dgn selera masing2."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 260 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/155e0f30aaaca26f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis atau gurih. Ciri kuliner Indonesia ayam rica rica kemangi yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica Rica Kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang dapat anda praktekkan salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Diperlukan 1 ekor ayam, potong sesuai selera
1. Dibutuhkan 1 ikat daun kemangi
1. Harus ada 3 lembar daun jeruk
1. Harap siapkan 3 lembar daun salam
1. Dibutuhkan 1 batang serai, geprek
1. Harus ada 10 buah cabe rawit (sy pakai utuh)aslinya halus
1. Tambah secukupnya Garam, merica, gula dan kaldu
1. Jangan lupa  Bumbu Halus :
1. Siapkan 1 ruas lengkuas
1. Harus ada 1 ruas jahe
1. Harus ada 1 ruas kunyit
1. Diperlukan 6 butir bawang merah
1. Harap siapkan 3 siung bawang putih
1. Harus ada 2 butir kemiri
1. Dibutuhkan 10 buah cabe merah (sesuai selera)




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica Kemangi:

1. Cuci bersih ayam, tambahkan air perasan jeruk nipis sedikit, diamkan sktr 15 menit agar tidak bau amis. Cuci bersih lagi. Rebus ayam sebentar untuk menghilangkan kotoran dan ayam cepat empuk. Tiriskan.
1. Panaskan sedikit minyak, tumis daun jeruk,daun salam dan serai hingga harum. Tambahkan bumbu halus, tumis hingga wangi.
1. Masukkan ayam, tambahkan garam, gula, merica dan kaldu. Aduk rata. Tambahkan sedikit air. Aduk rata.
1. Jika ayam sudah empuk dan air menyusut tambahkan daun kemangi. Aduk sebentar. Koreksi rasa. Sajikan.
1. Hmm enaaak sekali 💖💖.
1. Note : disini saya pakai daging ayam bagian dada dan beberapa ceker ayam. Tapi untuk satu ayam utuh juga bisa atau disesuaikan dgn selera masing2.




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan teruji, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
