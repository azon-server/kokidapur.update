---
description: "Langkah membuat Ayam Rica Rica Kemangi Terbukti"
title: "Langkah membuat Ayam Rica Rica Kemangi Terbukti"
slug: 408-langkah-membuat-ayam-rica-rica-kemangi-terbukti
date: 2020-09-28T17:24:48.671Z
image: https://img-global.cpcdn.com/recipes/599f019f6e0d27b0/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/599f019f6e0d27b0/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/599f019f6e0d27b0/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Rose Harvey
ratingvalue: 4.9
reviewcount: 37881
recipeingredient:
- "1 kg ayam bagian paha"
- "4 ikat kemangi"
- "2 tangkai sereh"
- "2 lembar daun salam"
- "6 lembar daun jeruk"
- "1 buah lemon"
- " Bumbu ulek"
- "3 siung bawang merah"
- "6 siung bawang putih"
- "15 buah cabe merah keriting"
- "5 buah cabe rawit merah"
- "2 sendok garam"
- "1 sendok gula"
- "1 sendok teh royco ayam"
- "1/2 sendok merica"
- "1/4 ruas kecil jahe"
- "1 buah tomat ukuran sedang"
recipeinstructions:
- "Lumuri ayam dengan lemon, cuci lalu goreng ayam hingga kering, tiriskan."
- "Panaskan minyak, masukan bumbu halus, tumis hingga harum dan agak mengering. Masukan daun salam dan sereh."
- "Masukan ayam yg sudah digoreng, aduk dengan bumbu halus. Ketika sudah merata, tambar 1/2 gelas air lalu tutup hingga bumbu meresap."
- "Sebelum diangkat masukan daun kemangi dan aduk sebentar, lalu angkat dan sajikan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 119 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT49M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/599f019f6e0d27b0/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica rica kemangi yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan keistimewahan yang merupakan keragaman Kita



Kedekatan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam Rica Rica Kemangi untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang bisa anda contoh salah satunya ayam rica rica kemangi yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi:

1. Jangan lupa 1 kg ayam bagian paha
1. Siapkan 4 ikat kemangi
1. Diperlukan 2 tangkai sereh
1. Dibutuhkan 2 lembar daun salam
1. Harus ada 6 lembar daun jeruk
1. Tambah 1 buah lemon
1. Diperlukan  Bumbu ulek
1. Harap siapkan 3 siung bawang merah
1. Diperlukan 6 siung bawang putih
1. Harus ada 15 buah cabe merah keriting
1. Diperlukan 5 buah cabe rawit merah
1. Siapkan 2 sendok garam
1. Diperlukan 1 sendok gula
1. Jangan lupa 1 sendok teh royco ayam
1. Dibutuhkan 1/2 sendok merica
1. Siapkan 1/4 ruas kecil jahe
1. Siapkan 1 buah tomat ukuran sedang




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica Kemangi:

1. Lumuri ayam dengan lemon, cuci lalu goreng ayam hingga kering, tiriskan.
1. Panaskan minyak, masukan bumbu halus, tumis hingga harum dan agak mengering. Masukan daun salam dan sereh.
1. Masukan ayam yg sudah digoreng, aduk dengan bumbu halus. Ketika sudah merata, tambar 1/2 gelas air lalu tutup hingga bumbu meresap.
1. Sebelum diangkat masukan daun kemangi dan aduk sebentar, lalu angkat dan sajikan.




Demikianlah cara membuat ayam rica rica kemangi yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan cepat, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
