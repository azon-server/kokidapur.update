---
description: "Panduan untuk menyiapakan Ayam Rica Rica Kemangi Homemade"
title: "Panduan untuk menyiapakan Ayam Rica Rica Kemangi Homemade"
slug: 406-panduan-untuk-menyiapakan-ayam-rica-rica-kemangi-homemade
date: 2020-10-08T21:51:36.716Z
image: https://img-global.cpcdn.com/recipes/aef6361fa39d7119/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/aef6361fa39d7119/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/aef6361fa39d7119/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Norman Gomez
ratingvalue: 4
reviewcount: 43374
recipeingredient:
- "1 kg Ayam dipotong kecil kecil"
- "1 ikat Daun kemangi"
- "1 ruas Lengkuas Geprek"
- "2 tangkai Serai Geprek"
- "2 lembar Daun Salam"
- "3 lembar Daun Jeruk"
- "200 ml air putih"
- " Minyak secukupnya untuk menggoreng dan menumis"
- " Bumbu Halus"
- "11 buah Cabe Merah besar sesuai selera kepedasan"
- "9 siung Bawang Merah"
- "5 siung Bawang Putih"
- "1 ruas Kunyit"
- "1 ruas Jahe"
- "secukupnya Garam"
- "2 sdm Gula Pasir"
- "1 sdm Gula Merah iris"
recipeinstructions:
- "Cuci bersih ayam yg sudah dipotong kecil kecil, dan lumuri dengan lemon / jeruk nipis, lalu goreng sebentar sampai ayam berubah warna"
- "Haluskan bumbu bumbu, lalu tumis dengan sedikit minyak sampai harum"
- "Masukan juga bumbu tumis lainnya, aduk sampai harum."
- "Masukkan ayam yang sudah digoreng, aduk aduk sampai merata."
- "Masukan air, bumbui dengan garam, gula pasir dan gula merah sesuai selera. Biarkan sampai air meresap dan menyusut"
- "Terakhir masukan daun kemangi, aduk sebentar sampai daun layu, lalu angkat"
- "Siap disajikan dengan nasi panas.."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 231 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/aef6361fa39d7119/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan enak. Ciri khas masakan Indonesia ayam rica rica kemangi yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan rumah tangga dapat diperoleh dengan cara simple. Diantaranya adalah memasak Ayam Rica Rica Kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang bisa anda buat salah satunya ayam rica rica kemangi yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi:

1. Harus ada 1 kg Ayam, dipotong kecil kecil
1. Diperlukan 1 ikat Daun kemangi
1. Harus ada 1 ruas Lengkuas, Geprek
1. Tambah 2 tangkai Serai, Geprek
1. Dibutuhkan 2 lembar Daun Salam
1. Siapkan 3 lembar Daun Jeruk
1. Siapkan 200 ml air putih
1. Tambah  Minyak secukupnya untuk menggoreng dan menumis
1. Harap siapkan  Bumbu Halus
1. Dibutuhkan 11 buah Cabe Merah besar (sesuai selera kepedasan)
1. Diperlukan 9 siung Bawang Merah
1. Harap siapkan 5 siung Bawang Putih
1. Tambah 1 ruas Kunyit
1. Dibutuhkan 1 ruas Jahe
1. Harap siapkan secukupnya Garam
1. Harap siapkan 2 sdm Gula Pasir
1. Harap siapkan 1 sdm Gula Merah iris




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica Kemangi:

1. Cuci bersih ayam yg sudah dipotong kecil kecil, dan lumuri dengan lemon / jeruk nipis, lalu goreng sebentar sampai ayam berubah warna
1. Haluskan bumbu bumbu, lalu tumis dengan sedikit minyak sampai harum
1. Masukan juga bumbu tumis lainnya, aduk sampai harum.
1. Masukkan ayam yang sudah digoreng, aduk aduk sampai merata.
1. Masukan air, bumbui dengan garam, gula pasir dan gula merah sesuai selera. Biarkan sampai air meresap dan menyusut
1. Terakhir masukan daun kemangi, aduk sebentar sampai daun layu, lalu angkat
1. Siap disajikan dengan nasi panas..




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat simple dan terbukti, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
