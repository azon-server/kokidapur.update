---
description: "Resep : Ayam rica rica kemangi Homemade"
title: "Resep : Ayam rica rica kemangi Homemade"
slug: 229-resep-ayam-rica-rica-kemangi-homemade
date: 2021-01-17T15:23:42.976Z
image: https://img-global.cpcdn.com/recipes/c98f7dfccaab4e1a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c98f7dfccaab4e1a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c98f7dfccaab4e1a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Gerald Page
ratingvalue: 4.8
reviewcount: 9048
recipeingredient:
- "250 gr Ayam potong jadi 4 bagiangoreng sebentar"
- "2 cm lengkuasgeprek"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 batang serai geprek"
- "segenggam daun kemangi"
- "2 sdt gula pasir"
- "1 sdt garam"
- "1/2 sdt Kaldu jamur"
- " Bumbu halus"
- "2 siung bawang putih"
- "5 siung bawang merah"
- "5 buah cabai rawit"
- "2 buah cabai besar"
- "2 cm kunyit"
- "1 cm jahe"
- "2 butir kemiri"
- "1/2 sdt merica bubuk"
- "1/2 sdt ketumbar bubuk"
recipeinstructions:
- "Tumis bumbu halus,masukkan daun jeruk,daun salam,lengkuas dan serai tumis sampai harum."
- "Masukkan ayam yang sudah digoreng tambahkan sedikit air aduk2."
- "Tambahkan garam,gula dan kaldu jamur aduk rata."
- "Masukkan daun kemangi masak sampai bumbu meresap.Angkat sajikan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 255 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/c98f7dfccaab4e1a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis dan enak. Ciri khas masakan Indonesia ayam rica rica kemangi yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam rica rica kemangi untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang bisa anda praktekkan salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Harap siapkan 250 gr Ayam, potong jadi 4 bagian,goreng sebentar
1. Diperlukan 2 cm lengkuas,geprek
1. Dibutuhkan 2 lembar daun salam
1. Siapkan 3 lembar daun jeruk
1. Dibutuhkan 1 batang serai, geprek
1. Dibutuhkan segenggam daun kemangi
1. Harap siapkan 2 sdt gula pasir
1. Harus ada 1 sdt garam
1. Tambah 1/2 sdt Kaldu jamur
1. Jangan lupa  Bumbu halus
1. Harus ada 2 siung bawang putih
1. Dibutuhkan 5 siung bawang merah
1. Harap siapkan 5 buah cabai rawit
1. Harus ada 2 buah cabai besar
1. Harus ada 2 cm kunyit
1. Harus ada 1 cm jahe
1. Siapkan 2 butir kemiri
1. Harap siapkan 1/2 sdt merica bubuk
1. Harus ada 1/2 sdt ketumbar bubuk




<!--inarticleads2-->

##### Cara membuat  Ayam rica rica kemangi:

1. Tumis bumbu halus,masukkan daun jeruk,daun salam,lengkuas dan serai tumis sampai harum.
1. Masukkan ayam yang sudah digoreng tambahkan sedikit air aduk2.
1. Tambahkan garam,gula dan kaldu jamur aduk rata.
1. Masukkan daun kemangi masak sampai bumbu meresap.Angkat sajikan.




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan cepat, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
