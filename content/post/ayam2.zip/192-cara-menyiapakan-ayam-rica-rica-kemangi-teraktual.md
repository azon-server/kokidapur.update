---
description: "Cara menyiapakan Ayam Rica Rica Kemangi teraktual"
title: "Cara menyiapakan Ayam Rica Rica Kemangi teraktual"
slug: 192-cara-menyiapakan-ayam-rica-rica-kemangi-teraktual
date: 2021-01-10T17:13:22.748Z
image: https://img-global.cpcdn.com/recipes/e5ec23a440247769/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e5ec23a440247769/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e5ec23a440247769/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Elnora Allison
ratingvalue: 4
reviewcount: 22954
recipeingredient:
- "1/2 ekor ayam kampung"
- "Segenggam daun kemangi"
- " Minyak untuk menumis"
- "secukupnya Air"
- " Bumbu Non Halus"
- "1 batang sereh geprek"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- " Bumbu Halus"
- "17 buah cabe rawit pedas sesuai selera"
- "5 buah cabe merah keriting"
- "4 siung bawang putih"
- "7 siung bawang merah"
- "2 buah kemiri"
- "1 ruas jahe"
- "2 ruas lengkuas"
- "1 sdm bubuk kunyit kurang lebih segitu"
- "1 sdt bubuk ketumbar opsional"
- "1 sdt lada bubuk opsional"
- " Bumbu Tambahan"
- "Secukupnya Garam"
- "secukupnya Gula"
- "secukupnya Kaldu ayam  me masako ayam seujung sendok teh"
- "2 sdm Kecap manis kurang lebih  opsional"
recipeinstructions:
- "Bersihkan ayam lalu potong2 sesuai selera kemudian rebus dulu sekitar +- 1 jam lalu tiriskan, tujuannya supaya ayam gak alot karena tekstur ayam kampung beda sama ayam negri, kalo pake ayam negri langkah ini bisa kalian skip"
- "Haluskan bumbu halus kemudian tumis dengan minyak panas lalu masukkan sereh, daun salam dan daun jeruk. Tumis hingga wangi."
- "Tambahkan air secukupnya ke bumbu yg sedang ditumis (bisa pake air rebusan ayam sebelumnya/air biasa) tunggu hingga mendidih kemudian masukkan ayamnya."
- "Masukkan garam, gula, kaldu ayam, dan kecap, masak hingga ayam empuk"
- "Setelah itu cek rasa, jika dirasa sudah pas semua matikan api dan masukkan daun kemangi yang sudah dicuci bersih kemudian diaduk dan siap disajikan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 229 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT49M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/e5ec23a440247769/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita jaga karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica rica kemangi yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Nusantara

Keharmonisan keluarga bisa didapat dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica Rica Kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang dapat anda praktekkan salah satunya ayam rica rica kemangi yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 24 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Harus ada 1/2 ekor ayam kampung
1. Harap siapkan Segenggam daun kemangi
1. Siapkan  Minyak untuk menumis
1. Harus ada secukupnya Air
1. Diperlukan  Bumbu Non Halus
1. Tambah 1 batang sereh geprek
1. Harus ada 2 lembar daun salam
1. Siapkan 3 lembar daun jeruk
1. Tambah  Bumbu Halus
1. Jangan lupa 17 buah cabe rawit (pedas sesuai selera)
1. Jangan lupa 5 buah cabe merah keriting
1. Siapkan 4 siung bawang putih
1. Jangan lupa 7 siung bawang merah
1. Dibutuhkan 2 buah kemiri
1. Harus ada 1 ruas jahe
1. Siapkan 2 ruas lengkuas
1. Siapkan 1 sdm bubuk kunyit (kurang lebih segitu)
1. Harus ada 1 sdt bubuk ketumbar (opsional)
1. Jangan lupa 1 sdt lada bubuk (opsional)
1. Jangan lupa  Bumbu Tambahan
1. Harus ada Secukupnya Garam
1. Harap siapkan secukupnya Gula
1. Tambah secukupnya Kaldu ayam  (me: masako ayam seujung sendok teh)
1. Tambah 2 sdm Kecap manis kurang lebih  (opsional)




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica Kemangi:

1. Bersihkan ayam lalu potong2 sesuai selera kemudian rebus dulu sekitar +- 1 jam lalu tiriskan, tujuannya supaya ayam gak alot karena tekstur ayam kampung beda sama ayam negri, kalo pake ayam negri langkah ini bisa kalian skip
1. Haluskan bumbu halus kemudian tumis dengan minyak panas lalu masukkan sereh, daun salam dan daun jeruk. Tumis hingga wangi.
1. Tambahkan air secukupnya ke bumbu yg sedang ditumis (bisa pake air rebusan ayam sebelumnya/air biasa) tunggu hingga mendidih kemudian masukkan ayamnya.
1. Masukkan garam, gula, kaldu ayam, dan kecap, masak hingga ayam empuk
1. Setelah itu cek rasa, jika dirasa sudah pas semua matikan api dan masukkan daun kemangi yang sudah dicuci bersih kemudian diaduk dan siap disajikan.




Demikianlah cara membuat ayam rica rica kemangi yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan cepat, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
