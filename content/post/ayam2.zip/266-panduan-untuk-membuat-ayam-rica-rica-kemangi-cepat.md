---
description: "Panduan untuk membuat Ayam Rica Rica kemangi Cepat"
title: "Panduan untuk membuat Ayam Rica Rica kemangi Cepat"
slug: 266-panduan-untuk-membuat-ayam-rica-rica-kemangi-cepat
date: 2020-11-23T16:44:36.816Z
image: https://img-global.cpcdn.com/recipes/3750fb02635d9ebb/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3750fb02635d9ebb/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3750fb02635d9ebb/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Andrew Ramos
ratingvalue: 4.8
reviewcount: 19149
recipeingredient:
- "500 g ayam di cuci bersih dan dipotong"
- "2 lembar daun jeruk"
- "2 ikat kemangi"
- "1 btng serai di memarkan"
- "1 sdt garam"
- "1 sdt penyedap rasa"
- " Bumbu Halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "5 cabai keriting"
- "10 cabai rawit"
- "1 sdt lada"
- "2 ruas jahe"
- "2 gls air"
recipeinstructions:
- "Tumis bumbu halus,daun jeruk, serai hingga wangi dan matang"
- "Masukkan ayam, garam, dan penyedap rasa, masak sampai ayam berubah warna, di aduk² rata."
- "Kemudian tambahkan air, masak dgn api kecil sampai bumbu meresap dan matang. Setelah air menyusut, Masukkan daun kemangi aduk rata, lalu Matikan api. Siap"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 124 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica Rica kemangi](https://img-global.cpcdn.com/recipes/3750fb02635d9ebb/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga enak. Ciri khas kuliner Nusantara ayam rica rica kemangi yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica Rica kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang dapat anda contoh salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica kemangi:

1. Harap siapkan 500 g ayam di cuci bersih dan dipotong
1. Siapkan 2 lembar daun jeruk
1. Diperlukan 2 ikat kemangi
1. Jangan lupa 1 btng serai di memarkan
1. Harap siapkan 1 sdt garam
1. Harus ada 1 sdt penyedap rasa
1. Tambah  Bumbu Halus
1. Harus ada 5 siung bawang merah
1. Dibutuhkan 3 siung bawang putih
1. Harus ada 5 cabai keriting
1. Diperlukan 10 cabai rawit
1. Siapkan 1 sdt lada
1. Siapkan 2 ruas jahe
1. Dibutuhkan 2 gls air




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica kemangi:

1. Tumis bumbu halus,daun jeruk, serai hingga wangi dan matang
1. Masukkan ayam, garam, dan penyedap rasa, masak sampai ayam berubah warna, di aduk² rata.
1. Kemudian tambahkan air, masak dgn api kecil sampai bumbu meresap dan matang. Setelah air menyusut, Masukkan daun kemangi aduk rata, lalu Matikan api. Siap




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan teruji, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
