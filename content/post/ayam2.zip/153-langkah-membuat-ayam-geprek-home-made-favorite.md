---
description: "Langkah membuat Ayam geprek home made Favorite"
title: "Langkah membuat Ayam geprek home made Favorite"
slug: 153-langkah-membuat-ayam-geprek-home-made-favorite
date: 2020-11-01T14:41:09.262Z
image: https://img-global.cpcdn.com/recipes/4cfe78891134249e/751x532cq70/ayam-geprek-home-made-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4cfe78891134249e/751x532cq70/ayam-geprek-home-made-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4cfe78891134249e/751x532cq70/ayam-geprek-home-made-foto-resep-utama.jpg
author: Jonathan Burns
ratingvalue: 4.2
reviewcount: 25323
recipeingredient:
- "5 potong ayam geprek Bensu mentah"
- "1 bungkus Lada bubuk"
- "5 siung bawang putih"
- "1 bungkus tepung sasa ukuran 80 gr"
- "80 gr Tepung terigu"
- "2 Cabe kriting besar"
- "10 buah cabe setan"
- " Garam"
- " Gula"
- "1 butir telur"
recipeinstructions:
- "Buka kemasan ayam geprek Bensu mentah, saya ambil 4 potong saja"
- "Masukan 5 potong ayam tadi ke dalam wadah (saya pakai baskom kecil)"
- "Masukan lada bubuk, telur dan bawang putih yg sudah di haluskan cukup pakai ulekan saja"
- "Aduk aduk hingga tercampur rata"
- "Siapkan nampan, masukan tepung terigu dan tepung bumbu sasa, campurkan"
- "Panaskan minyak, letakan satu satu ayam tadi atas nampan yg sudah di isi dengan tepung lalu guling guling"
- "Setelah minyak panas bisa langsung celupkan ayam yang sudah di lumuri tepung, masak hingga matang"
- "Sambil menunggu ayam matang, saya membuat sambal gepreknya."
- "Masukan semua cabai dan sisa bawang putih tadi ke dalam ulekan lalu haluskan, tambahkan garam dan gula secukupnya lalu masukan sedikit minyak panas, koreksi rasa"
- "Jika ayam sudah matang, tiriskan dan geprek langsung dalam ulekan lalu sajikan. Selesai. Selamat mencoba."
categories:
- Recipe
tags:
- ayam
- geprek
- home

katakunci: ayam geprek home 
nutrition: 101 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam geprek home made](https://img-global.cpcdn.com/recipes/4cfe78891134249e/751x532cq70/ayam-geprek-home-made-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan empuk. Karasteristik kuliner Indonesia ayam geprek home made yang penuh dengan rempah-rempah memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kedekatan rumah tangga bisa didapat dengan cara simple. Diantaranya adalah memasak Ayam geprek home made untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang bisa anda buat salah satunya ayam geprek home made yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep ayam geprek home made tanpa harus bersusah payah.
Seperti resep Ayam geprek home made yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 10 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam geprek home made:

1. Harus ada 5 potong ayam geprek Bensu mentah
1. Harap siapkan 1 bungkus Lada bubuk
1. Tambah 5 siung bawang putih
1. Diperlukan 1 bungkus tepung sasa ukuran 80 gr
1. Diperlukan 80 gr Tepung terigu
1. Tambah 2 Cabe kriting besar
1. Diperlukan 10 buah cabe setan
1. Harus ada  Garam
1. Dibutuhkan  Gula
1. Diperlukan 1 butir telur




<!--inarticleads2-->

##### Bagaimana membuat  Ayam geprek home made:

1. Buka kemasan ayam geprek Bensu mentah, saya ambil 4 potong saja
1. Masukan 5 potong ayam tadi ke dalam wadah (saya pakai baskom kecil)
1. Masukan lada bubuk, telur dan bawang putih yg sudah di haluskan cukup pakai ulekan saja
1. Aduk aduk hingga tercampur rata
1. Siapkan nampan, masukan tepung terigu dan tepung bumbu sasa, campurkan
1. Panaskan minyak, letakan satu satu ayam tadi atas nampan yg sudah di isi dengan tepung lalu guling guling
1. Setelah minyak panas bisa langsung celupkan ayam yang sudah di lumuri tepung, masak hingga matang
1. Sambil menunggu ayam matang, saya membuat sambal gepreknya.
1. Masukan semua cabai dan sisa bawang putih tadi ke dalam ulekan lalu haluskan, tambahkan garam dan gula secukupnya lalu masukan sedikit minyak panas, koreksi rasa
1. Jika ayam sudah matang, tiriskan dan geprek langsung dalam ulekan lalu sajikan. Selesai. Selamat mencoba.




Demikianlah cara membuat ayam geprek home made yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan cepat, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
