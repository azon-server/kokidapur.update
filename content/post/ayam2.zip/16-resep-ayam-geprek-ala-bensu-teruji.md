---
description: "Resep : Ayam geprek ala bensu Teruji"
title: "Resep : Ayam geprek ala bensu Teruji"
slug: 16-resep-ayam-geprek-ala-bensu-teruji
date: 2020-10-12T13:51:03.152Z
image: https://img-global.cpcdn.com/recipes/d5ae61f69a5cb3de/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d5ae61f69a5cb3de/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d5ae61f69a5cb3de/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg
author: Callie Hammond
ratingvalue: 4.8
reviewcount: 37897
recipeingredient:
- "1 buah jeruk nipis"
- " Tepung bumbu sasa pedas"
- "secukupnya Minyak goreng"
- " Bumbu rendaman"
- "2 siung bawang putih"
- "1/2 sdt lada bubuk"
- "Sedikit ketumbar bubuk optional"
- "Sedikit kunyit bubuk optional"
- "1/4 sdt garam"
- "1/2 sdt kadu bubuk ayam"
- "1 sdt tepung terigu"
- " Pencelup Ayam"
- "3 sdm tepung bumbu"
- "6 sdm air es"
- " Sambel geprek"
- "25 buah cabe rawit merah atau sesuai selera"
- "3 siung bawang putih"
- "secukupnya Garam"
- " Msg secukupnya optional"
- " Minyak panas bekas goreng ayam"
recipeinstructions:
- "Siapkan bahan,cuci ayam lumuri jeruk nipis lalu cuci lagi sampe bersih*lalu campur ayam dengan bumbu rendaman kemudian remas2 bejek2 biar meresap,simpan di kulkas lebih lama lebih baik*gulingkan ke,tepung bumbu sisihkan"
- "Setelah itu,celupkan ayam kedalam bahan pencelup,kemudian gulingkan lagi ketepung bumbu lalu goreng dalam minyak panas api sedang sampai warna kuning keemasan angkat"
- "Sambel:Uleg cabe rawit beserta bawang putih,tambahkan garam dan msg,siram dengan minyak panas,aduk ratakan dengan ulegan biar rata,setelah sambal udah siap rasa dh pas masukan ayam lalu tekan supaya sambel dan ayam menyatu"
- "Ayam siap di sajikan bersama sambel bawang,gk pake sambel juga boleh cukup dengan saos,sesuai selera ajah"
categories:
- Recipe
tags:
- ayam
- geprek
- ala

katakunci: ayam geprek ala 
nutrition: 269 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam geprek ala bensu](https://img-global.cpcdn.com/recipes/d5ae61f69a5cb3de/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang setidaknya kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam geprek ala bensu yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan keistimewahan yang merupakan keragaman Nusantara

Kedekatan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam geprek ala bensu untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang dapat anda coba salah satunya ayam geprek ala bensu yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep ayam geprek ala bensu tanpa harus bersusah payah.
Seperti resep Ayam geprek ala bensu yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam geprek ala bensu:

1. Diperlukan 1 buah jeruk nipis
1. Jangan lupa  Tepung bumbu sasa pedas
1. Dibutuhkan secukupnya Minyak goreng
1. Jangan lupa  Bumbu rendaman:
1. Dibutuhkan 2 siung bawang putih
1. Harus ada 1/2 sdt lada bubuk
1. Diperlukan Sedikit ketumbar bubuk optional
1. Dibutuhkan Sedikit kunyit bubuk optional
1. Jangan lupa 1/4 sdt garam
1. Harap siapkan 1/2 sdt kadu bubuk ayam
1. Siapkan 1 sdt tepung terigu
1. Diperlukan  Pencelup Ayam:
1. Harus ada 3 sdm tepung bumbu
1. Jangan lupa 6 sdm air es
1. Siapkan  Sambel geprek:
1. Diperlukan 25 buah cabe rawit merah atau sesuai selera
1. Diperlukan 3 siung bawang putih
1. Jangan lupa secukupnya Garam
1. Dibutuhkan  Msg secukupnya optional
1. Harus ada  Minyak panas bekas goreng ayam




<!--inarticleads2-->

##### Instruksi membuat  Ayam geprek ala bensu:

1. Siapkan bahan,cuci ayam lumuri jeruk nipis lalu cuci lagi sampe bersih*lalu campur ayam dengan bumbu rendaman kemudian remas2 bejek2 biar meresap,simpan di kulkas lebih lama lebih baik*gulingkan ke,tepung bumbu sisihkan
1. Setelah itu,celupkan ayam kedalam bahan pencelup,kemudian gulingkan lagi ketepung bumbu lalu goreng dalam minyak panas api sedang sampai warna kuning keemasan angkat
1. Sambel:Uleg cabe rawit beserta bawang putih,tambahkan garam dan msg,siram dengan minyak panas,aduk ratakan dengan ulegan biar rata,setelah sambal udah siap rasa dh pas masukan ayam lalu tekan supaya sambel dan ayam menyatu
1. Ayam siap di sajikan bersama sambel bawang,gk pake sambel juga boleh cukup dengan saos,sesuai selera ajah




Demikianlah cara membuat ayam geprek ala bensu yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
