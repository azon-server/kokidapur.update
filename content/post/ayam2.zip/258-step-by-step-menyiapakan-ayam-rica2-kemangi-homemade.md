---
description: "Step-by-Step menyiapakan Ayam rica2 kemangi Homemade"
title: "Step-by-Step menyiapakan Ayam rica2 kemangi Homemade"
slug: 258-step-by-step-menyiapakan-ayam-rica2-kemangi-homemade
date: 2020-10-05T15:26:51.279Z
image: https://img-global.cpcdn.com/recipes/efb094f94398fb5a/751x532cq70/ayam-rica2-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/efb094f94398fb5a/751x532cq70/ayam-rica2-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/efb094f94398fb5a/751x532cq70/ayam-rica2-kemangi-foto-resep-utama.jpg
author: Dale Murray
ratingvalue: 4.4
reviewcount: 28363
recipeingredient:
- "250 daging ayam"
- "Secukupnya kemangi"
- "1 buah tomat potong2"
- "1/2 buah jeruk nipis untuk menghilangkan amis pada ayam"
- " Bumbu halus"
- "4 siung bawang merah"
- "3 siung bawang putih"
- "1 cabe merah besar"
- "5 cabe rawit"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 butir kemiri"
- " bumbu tambahan"
- "1 sdt garam"
- "2 sdt gula"
- "1 lembar daun salam"
- "1/2 batang serai"
- " air secukup nya"
recipeinstructions:
- "Lumuri ayam dengan jeruk nipis,diamkan 10 menit,cuci lagi sampai bersih.Blender atau ulek bumbu halus."
- "Panaskan wajan,masukkan bumbu blender tambahkan air,masukkan juga ayam,serai dan daun salam,masak sebentar sampai mendidih.tambahkan garam &amp; gula dan potongan tomat,tes rasa.tutup wajan &amp; masak terus sampai ayam empuk."
- "Setelah ayam empuk dan kuah menyusut masukkan kemangi.aduk2 sebentar,matikan api.selesai."
categories:
- Recipe
tags:
- ayam
- rica2
- kemangi

katakunci: ayam rica2 kemangi 
nutrition: 104 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT54M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica2 kemangi](https://img-global.cpcdn.com/recipes/efb094f94398fb5a/751x532cq70/ayam-rica2-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan empuk. Karasteristik makanan Indonesia ayam rica2 kemangi yang penuh dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal. Resepnya sederhana dan mudah, khas Manado asli pakai daun kemangi. Wajib coba bagi pecinta makanan pedas.

Kedekatan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam rica2 kemangi untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang bisa anda praktekkan salah satunya ayam rica2 kemangi yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica2 kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica2 kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica2 kemangi:

1. Diperlukan 250 daging ayam
1. Tambah Secukupnya kemangi
1. Diperlukan 1 buah tomat (potong2)
1. Diperlukan 1/2 buah jeruk nipis (untuk menghilangkan amis pada ayam)
1. Jangan lupa  Bumbu halus:
1. Harap siapkan 4 siung bawang merah
1. Tambah 3 siung bawang putih
1. Dibutuhkan 1 cabe merah besar
1. Siapkan 5 cabe rawit
1. Dibutuhkan 1 ruas jahe
1. Jangan lupa 1 ruas kunyit
1. Tambah 1 butir kemiri
1. Diperlukan  bumbu tambahan:
1. Diperlukan 1 sdt garam
1. Jangan lupa 2 sdt gula
1. Diperlukan 1 lembar daun salam
1. Jangan lupa 1/2 batang serai
1. Diperlukan  air secukup nya


Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. Siapa yang tidak mengenal lalapan daun kemangi di Indonesia ini. Hampir semua masakan tradisional menyediakan lalapan daun kemangi sebagai pencuci mulut. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica2 kemangi:

1. Lumuri ayam dengan jeruk nipis,diamkan 10 menit,cuci lagi sampai bersih.Blender atau ulek bumbu halus.
1. Panaskan wajan,masukkan bumbu blender tambahkan air,masukkan juga ayam,serai dan daun salam,masak sebentar sampai mendidih.tambahkan garam &amp; gula dan potongan tomat,tes rasa.tutup wajan &amp; masak terus sampai ayam empuk.
1. Setelah ayam empuk dan kuah menyusut masukkan kemangi.aduk2 sebentar,matikan api.selesai.


Hampir semua masakan tradisional menyediakan lalapan daun kemangi sebagai pencuci mulut. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. Rica-rica sendiri bisa terbuat dari berbagai bahan utama, namun yang paling populer adalah ayam. Selain mudah didapat, daging ayam juga relatif lebih murah jika dibandingkan dengan bahan-bahan lain seperti daging entok dan sebagainya. Ada resep masakan ayam rica-rica sederhana, resep masakan ayam rica-rica pedas manis, resep masakan ayam rica-rica kemangi, resep masakan ayam rica-rica khas Manado dan lain sebagainya. 

Demikianlah cara membuat ayam rica2 kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan teruji, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
