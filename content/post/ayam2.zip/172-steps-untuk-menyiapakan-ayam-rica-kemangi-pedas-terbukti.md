---
description: "Steps untuk menyiapakan Ayam Rica Kemangi Pedas Terbukti"
title: "Steps untuk menyiapakan Ayam Rica Kemangi Pedas Terbukti"
slug: 172-steps-untuk-menyiapakan-ayam-rica-kemangi-pedas-terbukti
date: 2020-08-09T16:51:17.242Z
image: https://img-global.cpcdn.com/recipes/c800002b655ead49/751x532cq70/ayam-rica-kemangi-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c800002b655ead49/751x532cq70/ayam-rica-kemangi-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c800002b655ead49/751x532cq70/ayam-rica-kemangi-pedas-foto-resep-utama.jpg
author: Kevin Silva
ratingvalue: 4
reviewcount: 46057
recipeingredient:
- "1 ekor ayam 8 potong"
- " Bumbu Halus"
- "15 Bawang Merah"
- "8 Bawang Putih"
- "1 Kelingking Kunyit"
- "2 Jempol Jahe"
- "1 Jempol Lengkuas"
- "2 Kemiri sudah disangrai"
- " Bahan cabe"
- "8 Cabe Gendut karena kebetulan ga ada cabe keriting"
- "18 Cabe Rawit Domba sesuai selera"
- " Bahan Lainnya"
- "5 Sereh digeprek"
- "15 Lembar Daun Jeruk"
- "3 Ikat daun kemangi"
- " Garam kaldu ayam gula merica sesuai selera"
- " Jeruk lemon"
recipeinstructions:
- "Cuci bersih ayam, balurkan perasan jeruk lemon dan diamkan beberapa saat."
- "Didihkan air, rebus ayam (saya 30 menit). Siapkan bahan halus, cuci bersih kemudian blender seluruh bahan halus."
- "Angkat ayam yg sudah direbus kemudian pindahkan ke wajan dan marinasi menggunakan bumbu halus (15 menit). Nyalakan kompor, tambahkan air, minyak, sereh, daun jeruk, garam, kaldu ayam, dan merica. Tunggu sampai airnya sat."
- "Masukan bahan cabe yang telah diblender, garam, gula, kaldu ayam, dan merica. Setelah semuanya merata masukkan daun kemangi dan masak sebentar. Selesai.... aromanya wangi banget🔥🔥"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 149 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica Kemangi Pedas](https://img-global.cpcdn.com/recipes/c800002b655ead49/751x532cq70/ayam-rica-kemangi-pedas-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang harus kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica kemangi pedas yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan keistimewahan yang merupakan keragaman Nusantara



Keharmonisan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica Kemangi Pedas untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang dapat anda contoh salah satunya ayam rica kemangi pedas yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep ayam rica kemangi pedas tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi Pedas yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi Pedas:

1. Tambah 1 ekor ayam (8 potong)
1. Harap siapkan  Bumbu Halus
1. Jangan lupa 15 Bawang Merah
1. Jangan lupa 8 Bawang Putih
1. Siapkan 1 Kelingking Kunyit
1. Tambah 2 Jempol Jahe
1. Tambah 1 Jempol Lengkuas
1. Harus ada 2 Kemiri (sudah disangrai)
1. Dibutuhkan  Bahan cabe
1. Harap siapkan 8 Cabe Gendut (karena kebetulan ga ada cabe keriting)
1. Jangan lupa 18 Cabe Rawit Domba (sesuai selera)
1. Dibutuhkan  Bahan Lainnya
1. Diperlukan 5 Sereh (digeprek)
1. Harus ada 15 Lembar Daun Jeruk
1. Harap siapkan 3 Ikat daun kemangi
1. Dibutuhkan  Garam, kaldu ayam, gula, merica (sesuai selera)
1. Harap siapkan  Jeruk lemon




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Kemangi Pedas:

1. Cuci bersih ayam, balurkan perasan jeruk lemon dan diamkan beberapa saat.
1. Didihkan air, rebus ayam (saya 30 menit). Siapkan bahan halus, cuci bersih kemudian blender seluruh bahan halus.
1. Angkat ayam yg sudah direbus kemudian pindahkan ke wajan dan marinasi menggunakan bumbu halus (15 menit). Nyalakan kompor, tambahkan air, minyak, sereh, daun jeruk, garam, kaldu ayam, dan merica. Tunggu sampai airnya sat.
1. Masukan bahan cabe yang telah diblender, garam, gula, kaldu ayam, dan merica. Setelah semuanya merata masukkan daun kemangi dan masak sebentar. Selesai.... aromanya wangi banget🔥🔥




Demikianlah cara membuat ayam rica kemangi pedas yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
