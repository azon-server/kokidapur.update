---
description: "Cara membuat Ayam rica kemangi bumbu olahan Sempurna"
title: "Cara membuat Ayam rica kemangi bumbu olahan Sempurna"
slug: 196-cara-membuat-ayam-rica-kemangi-bumbu-olahan-sempurna
date: 2020-10-19T14:07:19.205Z
image: https://img-global.cpcdn.com/recipes/bf42d31bf3f95597/751x532cq70/ayam-rica-kemangi-bumbu-olahan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bf42d31bf3f95597/751x532cq70/ayam-rica-kemangi-bumbu-olahan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bf42d31bf3f95597/751x532cq70/ayam-rica-kemangi-bumbu-olahan-foto-resep-utama.jpg
author: Nora Walton
ratingvalue: 4.8
reviewcount: 40526
recipeingredient:
- "1/2 ekor ayam sudah digoreng setengah masak"
- "3 batang kemangi"
- "1 gelas duralex air biasa"
- "7 sdm minyak goreng"
- " Bahan Halus"
- "5 siung bawang merah"
- "2 siung bawang putih hrusnya 3 Tp khabisan bawang putih"
- "2 biji kemiri"
- "1 ruas kunyit"
- "1 ruas jahe"
- "3 biji cabe kriting"
- "13 biji cabe rawit"
- "1 buah tomat ukuran sedang"
- "1/2 sdt lada bubuk"
- " Bahan cemplung"
- "1 batang serai"
- "2 helai daun salam"
- " Bumbu Rasa"
- "2 sdt garam tidak penuh"
- "2 sdt royco ayam"
- "1 sdm gula pasir tidak penuh"
recipeinstructions:
- "Panaskan minyak dgn api sedang. Kemudian tumis bahan halus bersamaan daun salam dan serai hingga keluar aroma wangi bumbunya"
- "Masukkan ayam, bumbu rasa dan air, aduk sebentar sekiranya semua ayam terendam merata. Tunggu skitar 3 menit, kemudian aduk lagi. Ulangi mengaduk setelah 3 menit hingga air mulai menyusut"
- "Jika sdh menyusut, cek rasa. Jika sudah pas, masukkan daun kemangi yg sudah dibersihkan. Aduk lagi hingga daun kemanginya layu."
- "Jika sudah layu, matikan kompor. Dan ayam rica kemangi bumbu olahan siap disajikan😁"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 249 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT37M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica kemangi bumbu olahan](https://img-global.cpcdn.com/recipes/bf42d31bf3f95597/751x532cq70/ayam-rica-kemangi-bumbu-olahan-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan renyah. Ciri khas kuliner Indonesia ayam rica kemangi bumbu olahan yang penuh dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kedekatan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam rica kemangi bumbu olahan untuk keluarga. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang bisa anda buat salah satunya ayam rica kemangi bumbu olahan yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep ayam rica kemangi bumbu olahan tanpa harus bersusah payah.
Seperti resep Ayam rica kemangi bumbu olahan yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica kemangi bumbu olahan:

1. Tambah 1/2 ekor ayam (sudah digoreng setengah masak)
1. Dibutuhkan 3 batang kemangi
1. Diperlukan 1 gelas duralex air biasa
1. Siapkan 7 sdm minyak goreng
1. Diperlukan  Bahan Halus
1. Tambah 5 siung bawang merah
1. Tambah 2 siung bawang putih (hrusnya 3. Tp khabisan bawang putih😅)
1. Dibutuhkan 2 biji kemiri
1. Harus ada 1 ruas kunyit
1. Diperlukan 1 ruas jahe
1. Siapkan 3 biji cabe kriting
1. Jangan lupa 13 biji cabe rawit
1. Dibutuhkan 1 buah tomat ukuran sedang
1. Jangan lupa 1/2 sdt lada bubuk
1. Siapkan  Bahan cemplung
1. Dibutuhkan 1 batang serai
1. Harap siapkan 2 helai daun salam
1. Harap siapkan  Bumbu Rasa
1. Harap siapkan 2 sdt garam (tidak penuh)
1. Dibutuhkan 2 sdt royco ayam
1. Diperlukan 1 sdm gula pasir (tidak penuh)




<!--inarticleads2-->

##### Cara membuat  Ayam rica kemangi bumbu olahan:

1. Panaskan minyak dgn api sedang. Kemudian tumis bahan halus bersamaan daun salam dan serai hingga keluar aroma wangi bumbunya
1. Masukkan ayam, bumbu rasa dan air, aduk sebentar sekiranya semua ayam terendam merata. Tunggu skitar 3 menit, kemudian aduk lagi. Ulangi mengaduk setelah 3 menit hingga air mulai menyusut
1. Jika sdh menyusut, cek rasa. Jika sudah pas, masukkan daun kemangi yg sudah dibersihkan. Aduk lagi hingga daun kemanginya layu.
1. Jika sudah layu, matikan kompor. Dan ayam rica kemangi bumbu olahan siap disajikan😁




Demikianlah cara membuat ayam rica kemangi bumbu olahan yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
