---
description: "Panduan membuat Ayam rica kemangi terupdate"
title: "Panduan membuat Ayam rica kemangi terupdate"
slug: 372-panduan-membuat-ayam-rica-kemangi-terupdate
date: 2020-11-11T12:52:14.703Z
image: https://img-global.cpcdn.com/recipes/31256e8d8836e4a7/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/31256e8d8836e4a7/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/31256e8d8836e4a7/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Rosa Rice
ratingvalue: 4.3
reviewcount: 12481
recipeingredient:
- "1  ekor ayam potong2"
- "1 ikat kemangi"
- "2 buah serai geprek"
- "2 lembar daun jeruk"
- "2 lembar daun Salam"
- "1 sdt garam"
- "1/2 sdt gula"
- "1 sdm minyak goreng"
- "secukupnya Air"
- " Bumbu halus"
- "4 siung bawang merah"
- "5 siung bawang putih"
- "3 buah kemiri"
- "1 ruas kunyit"
- "1 ruas jahe"
- "3 buah cabe keriting"
- "5 buah cabe rawit optional"
- "1/2 sdt ketumbar"
recipeinstructions:
- "Blender bumbu halus, tumis dengan minyak Goreng, aduk aduk...Masukkan daun Salam, daun jeruk serai tinggu hingga harum."
- "Masukkan ayam lalu beri air sedikit sedikit, beri garam, gula, diamkan hingga menyusut. Cek rasa"
- "Masukkan kemangi Lalu aduk kembali hingga rata. Sajikan...hmmm pedes2 maknyusss"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 135 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/31256e8d8836e4a7/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang harus kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica kemangi yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Indonesia

Kedekatan keluarga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam rica kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang dapat anda praktekkan salah satunya ayam rica kemangi yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica kemangi:

1. Harus ada 1 / ekor ayam, potong2
1. Harap siapkan 1 ikat kemangi
1. Diperlukan 2 buah serai geprek
1. Dibutuhkan 2 lembar daun jeruk
1. Dibutuhkan 2 lembar daun Salam
1. Jangan lupa 1 sdt garam
1. Tambah 1/2 sdt gula
1. Harap siapkan 1 sdm minyak goreng
1. Diperlukan secukupnya Air
1. Dibutuhkan  Bumbu halus
1. Jangan lupa 4 siung bawang merah
1. Jangan lupa 5 siung bawang putih
1. Siapkan 3 buah kemiri
1. Jangan lupa 1 ruas kunyit
1. Diperlukan 1 ruas jahe
1. Diperlukan 3 buah cabe keriting
1. Harus ada 5 buah cabe rawit (optional)
1. Harus ada 1/2 sdt ketumbar




<!--inarticleads2-->

##### Cara membuat  Ayam rica kemangi:

1. Blender bumbu halus, tumis dengan minyak Goreng, aduk aduk...Masukkan daun Salam, daun jeruk serai tinggu hingga harum.
1. Masukkan ayam lalu beri air sedikit sedikit, beri garam, gula, diamkan hingga menyusut. Cek rasa
1. Masukkan kemangi Lalu aduk kembali hingga rata. Sajikan...hmmm pedes2 maknyusss




Demikianlah cara membuat ayam rica kemangi yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
