---
description: "Resep : Ayam Geprek Keju Leleh Sambel Mercon Homemade"
title: "Resep : Ayam Geprek Keju Leleh Sambel Mercon Homemade"
slug: 109-resep-ayam-geprek-keju-leleh-sambel-mercon-homemade
date: 2020-11-21T12:06:08.231Z
image: https://img-global.cpcdn.com/recipes/dcb259acb0dd99ba/751x532cq70/ayam-geprek-keju-leleh-sambel-mercon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dcb259acb0dd99ba/751x532cq70/ayam-geprek-keju-leleh-sambel-mercon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dcb259acb0dd99ba/751x532cq70/ayam-geprek-keju-leleh-sambel-mercon-foto-resep-utama.jpg
author: Loretta Washington
ratingvalue: 4.3
reviewcount: 14861
recipeingredient:
- "1/2 kg Ayam aku pake 1 potong bagian dadasisanya buat stok"
- "1 Jeruk Limau"
- " Tepung Sasa yang Ayam Kentucky"
- "11 Cabe Orens"
- "3 Cabe Merah Kriting"
- "2-3 Siung Bawang Putih"
- "Secukupnya Garam"
- "Secukupnya Minyak Goreng"
- " Parutan Keju Kraft Quick Melt"
- "1 Butir Telur Ayam"
- " Margarin khusus untuk Orek Telurnya"
recipeinstructions:
- "Bersihkan ayam lalu beri perasan 1 buah Jeruk Limau dan lumuri dengan garam. Setelah itu diamkan selama 30 menit di kulkas. Kemudian siapkan loyang untuk tepung adonan basah menggunakan air es takaran 4 sendok makan dan 2 sendok makan tepungnya.Dan siapkan loyang lagi untuk tepung keringnya.Celupkan ayam terlebih dahulu menggunakan adonan basah lalu ke adonan kering (lakukan sebanyak 2x pada adonan basah dan yg kering ya), setelah itu goreng menggunakan banyak minyak agar ayamnya crispy"
- "Siapkan cobek untuk mengulek 11 cabe orens + 3 cabe merah kriting + 2 bawang putih + garam secukupnya. Ulek sampai halus, lalu beri 2 sendok makan minyak bekas menggoreng ayam tadi ke cobeknya. Setelah itu ambil ayam crispynya lalu geprek di atas sambel cobek."
- "Buat telur ayam orek menggunakan margarin blue band. Setelah matang, taro diatas susunan ayam geprek dan sambelnya ya. Setelah itu beri parutan keju quick meltnya.."
- "NB : klo mau lelehin keju meltnya tanpa alat bakaran, bisa menggunakan cara manual.. Siapin loyang stainless untuk menaruh ayam geprek nya + parutan keju. Lalu siapkan juga panci tanpa di isi air, masukkan loyang stainlessnya dan tutup menggunakan penutup panci. Pada saat proses meltnya, gunakan api kecil dan sesekali lihat kejunya sudah meleleh atau belum.. Klo sudah melt, lgsg matikan kompornya dan ready to eat."
- "Dijamin endeus Moms. Selamat mencoba"
categories:
- Recipe
tags:
- ayam
- geprek
- keju

katakunci: ayam geprek keju 
nutrition: 282 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Geprek Keju Leleh Sambel Mercon](https://img-global.cpcdn.com/recipes/dcb259acb0dd99ba/751x532cq70/ayam-geprek-keju-leleh-sambel-mercon-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam geprek keju leleh sambel mercon yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Nusantara

Keharmonisan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah memasak Ayam Geprek Keju Leleh Sambel Mercon untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang dapat anda buat salah satunya ayam geprek keju leleh sambel mercon yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep ayam geprek keju leleh sambel mercon tanpa harus bersusah payah.
Seperti resep Ayam Geprek Keju Leleh Sambel Mercon yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Keju Leleh Sambel Mercon:

1. Dibutuhkan 1/2 kg Ayam (aku pake 1 potong bagian dada,sisanya buat stok)
1. Harus ada 1 Jeruk Limau
1. Dibutuhkan  Tepung Sasa yang Ayam Kentucky
1. Siapkan 11 Cabe Orens
1. Harap siapkan 3 Cabe Merah Kriting
1. Diperlukan 2-3 Siung Bawang Putih
1. Tambah Secukupnya Garam
1. Jangan lupa Secukupnya Minyak Goreng
1. Diperlukan  Parutan Keju Kraft Quick Melt
1. Dibutuhkan 1 Butir Telur Ayam
1. Dibutuhkan  Margarin khusus untuk Orek Telurnya




<!--inarticleads2-->

##### Cara membuat  Ayam Geprek Keju Leleh Sambel Mercon:

1. Bersihkan ayam lalu beri perasan 1 buah Jeruk Limau dan lumuri dengan garam. Setelah itu diamkan selama 30 menit di kulkas. Kemudian siapkan loyang untuk tepung adonan basah menggunakan air es takaran 4 sendok makan dan 2 sendok makan tepungnya.Dan siapkan loyang lagi untuk tepung keringnya.Celupkan ayam terlebih dahulu menggunakan adonan basah lalu ke adonan kering (lakukan sebanyak 2x pada adonan basah dan yg kering ya), setelah itu goreng menggunakan banyak minyak agar ayamnya crispy
1. Siapkan cobek untuk mengulek 11 cabe orens + 3 cabe merah kriting + 2 bawang putih + garam secukupnya. Ulek sampai halus, lalu beri 2 sendok makan minyak bekas menggoreng ayam tadi ke cobeknya. Setelah itu ambil ayam crispynya lalu geprek di atas sambel cobek.
1. Buat telur ayam orek menggunakan margarin blue band. Setelah matang, taro diatas susunan ayam geprek dan sambelnya ya. Setelah itu beri parutan keju quick meltnya..
1. NB : klo mau lelehin keju meltnya tanpa alat bakaran, bisa menggunakan cara manual.. Siapin loyang stainless untuk menaruh ayam geprek nya + parutan keju. Lalu siapkan juga panci tanpa di isi air, masukkan loyang stainlessnya dan tutup menggunakan penutup panci. Pada saat proses meltnya, gunakan api kecil dan sesekali lihat kejunya sudah meleleh atau belum.. Klo sudah melt, lgsg matikan kompornya dan ready to eat.
1. Dijamin endeus Moms. Selamat mencoba




Demikianlah cara membuat ayam geprek keju leleh sambel mercon yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
