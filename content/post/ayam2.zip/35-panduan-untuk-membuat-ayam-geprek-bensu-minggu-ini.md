---
description: "Panduan untuk membuat Ayam Geprek Bensu minggu ini"
title: "Panduan untuk membuat Ayam Geprek Bensu minggu ini"
slug: 35-panduan-untuk-membuat-ayam-geprek-bensu-minggu-ini
date: 2020-10-29T16:15:48.255Z
image: https://img-global.cpcdn.com/recipes/d0e391c3f2cd234e/751x532cq70/ayam-geprek-bensu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d0e391c3f2cd234e/751x532cq70/ayam-geprek-bensu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d0e391c3f2cd234e/751x532cq70/ayam-geprek-bensu-foto-resep-utama.jpg
author: Arthur Adams
ratingvalue: 4.4
reviewcount: 37883
recipeingredient:
- "1/2 kg ayam"
- " Adonan kering "
- "1/2 kg tepung segitiga biru"
- "2 sdm maizena"
- "1 sdm tepung beras"
- "1/2 sdt baking powder"
- "1 sdt garam"
- "1 sdt kaldu bubuk"
- "1 sdt bawang putih bubuk optional"
- " Adonan basah "
- "1 butir putih telor"
- "5 sdm tepung segitiga biru"
- "1 bawang putih halus"
- "1/2 sdt kaldu bubuk"
- "1/2 sdt merica bubuk"
- " Bahan sambel "
- "1 ons cabe rawit"
- "3 bawang merah"
- "5 bawang putih"
- "1 sdt kaldu bubuk"
- "1/2 sdt garam"
- "1 sdt gula"
- "Sedikit air"
recipeinstructions:
- "Cuci bersih ayam dan sayat bagian daging. Tujuannya agar tepung dap!t merata dan hasilnya akan merekah."
- "Campurkan semua adonan basah dalam wadah, lalu masukkan potongan ayam."
- "Campurkan adonan kering dalam wadah terpisah."
- "Masukkan potongan ayam yang sudah dicelupkan dalam adonan basah ke adonan kering."
- "Lakukan 2x proses untuk hasil tepung yang sedikit tebal. Celupkan lagi keadonan basah dan kering."
- "Hasil akhir setelah 2x proses adonan basah dan kering seperti ini."
- "Kemudian panaskan minyak yang cukup sampai ayam terendam, masukkan ayam dalam suhu minyak masih hangat. Agar daging ayam matang hingga kedalam."
- "Saya menggunakan fillet ayam, ibu ibu bisa juga menggunakan ayam bertulang."
- "Selanjutnya kita buat sambalnya, iris bawang merah dan geprek bawang putih. Cuci bersih cabe rawit, kemudian uleg kasar. Sambil tumis bawang merah dengan sedikit minyak hingga layu dan harum."
- "Campurkan, tumisan bawang merah ke uleg an cabe, uleg ringan dan tambahkan kaldu bubuk. Kemudian goreng bawang putih geprek hingga layu dan harum. Jangan terlalu kering ya."
- "Masukkan bawang putih yang sudah digoreng ke uleg an cabe, uleg ringan lagi lalu tumis. Beri air pada sisa uleg an cabe dicobek lalu tuang ke tumisan. Tumis hingga sedikit menyusut, tambahkan gula dan garam. Beri sedikit air lagi dan tumis lagi, tekstur sambel tidak kering ya. Sedikit agak basah tapi tetap berminyak."
- "Siapkan cobek kering, geprek ayam yang sudah digoreng tadi dan beri sambel diatasnya."
categories:
- Recipe
tags:
- ayam
- geprek
- bensu

katakunci: ayam geprek bensu 
nutrition: 171 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Geprek Bensu](https://img-global.cpcdn.com/recipes/d0e391c3f2cd234e/751x532cq70/ayam-geprek-bensu-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan gurih. Ciri makanan Indonesia ayam geprek bensu yang kaya dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan rumah tangga bisa didapat dengan cara sederhana. Salah satunya adalah memasak Ayam Geprek Bensu untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang dapat anda coba salah satunya ayam geprek bensu yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep ayam geprek bensu tanpa harus bersusah payah.
Seperti resep Ayam Geprek Bensu yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 23 bahan dan 12 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Bensu:

1. Siapkan 1/2 kg ayam
1. Tambah  Adonan kering :
1. Harus ada 1/2 kg tepung segitiga biru
1. Harus ada 2 sdm maizena
1. Siapkan 1 sdm tepung beras
1. Siapkan 1/2 sdt baking powder
1. Jangan lupa 1 sdt garam
1. Siapkan 1 sdt kaldu bubuk
1. Diperlukan 1 sdt bawang putih bubuk (optional)
1. Dibutuhkan  Adonan basah :
1. Jangan lupa 1 butir putih telor
1. Diperlukan 5 sdm tepung segitiga biru
1. Jangan lupa 1 bawang putih halus
1. Jangan lupa 1/2 sdt kaldu bubuk
1. Diperlukan 1/2 sdt merica bubuk
1. Harap siapkan  Bahan sambel :
1. Tambah 1 ons cabe rawit
1. Siapkan 3 bawang merah
1. Tambah 5 bawang putih
1. Tambah 1 sdt kaldu bubuk
1. Jangan lupa 1/2 sdt garam
1. Tambah 1 sdt gula
1. Diperlukan Sedikit air




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Geprek Bensu:

1. Cuci bersih ayam dan sayat bagian daging. Tujuannya agar tepung dap!t merata dan hasilnya akan merekah.
1. Campurkan semua adonan basah dalam wadah, lalu masukkan potongan ayam.
1. Campurkan adonan kering dalam wadah terpisah.
1. Masukkan potongan ayam yang sudah dicelupkan dalam adonan basah ke adonan kering.
1. Lakukan 2x proses untuk hasil tepung yang sedikit tebal. Celupkan lagi keadonan basah dan kering.
1. Hasil akhir setelah 2x proses adonan basah dan kering seperti ini.
1. Kemudian panaskan minyak yang cukup sampai ayam terendam, masukkan ayam dalam suhu minyak masih hangat. Agar daging ayam matang hingga kedalam.
1. Saya menggunakan fillet ayam, ibu ibu bisa juga menggunakan ayam bertulang.
1. Selanjutnya kita buat sambalnya, iris bawang merah dan geprek bawang putih. Cuci bersih cabe rawit, kemudian uleg kasar. Sambil tumis bawang merah dengan sedikit minyak hingga layu dan harum.
1. Campurkan, tumisan bawang merah ke uleg an cabe, uleg ringan dan tambahkan kaldu bubuk. Kemudian goreng bawang putih geprek hingga layu dan harum. Jangan terlalu kering ya.
1. Masukkan bawang putih yang sudah digoreng ke uleg an cabe, uleg ringan lagi lalu tumis. Beri air pada sisa uleg an cabe dicobek lalu tuang ke tumisan. Tumis hingga sedikit menyusut, tambahkan gula dan garam. Beri sedikit air lagi dan tumis lagi, tekstur sambel tidak kering ya. Sedikit agak basah tapi tetap berminyak.
1. Siapkan cobek kering, geprek ayam yang sudah digoreng tadi dan beri sambel diatasnya.




Demikianlah cara membuat ayam geprek bensu yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan teruji, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
