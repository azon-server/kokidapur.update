---
description: "Bagaimana menyiapakan Ayam rica-rica kemangi minggu ini"
title: "Bagaimana menyiapakan Ayam rica-rica kemangi minggu ini"
slug: 367-bagaimana-menyiapakan-ayam-rica-rica-kemangi-minggu-ini
date: 2020-12-06T06:51:06.471Z
image: https://img-global.cpcdn.com/recipes/303e876554cba3a1/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/303e876554cba3a1/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/303e876554cba3a1/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Manuel Watts
ratingvalue: 4.1
reviewcount: 32563
recipeingredient:
- "1/2 ekor ayam"
- "1 buah jeruk nipis"
- "1 batang serai"
- "3 lembar daun salam"
- "Secukupnya daun kemangi"
- "1/2 sdt garam"
- "Secukupnya merica gula kaldu bubuk"
- " Minyak goreng"
- " Bumbu Halus "
- "7 butir bawang merah"
- "4 siung bawang putih"
- "2 ruas kunyit"
- "1 ruas jahe"
- "3 butir kemiri"
- "1 buah tomat"
- "5 buah cabe merah"
- "10 buah cabe rawit"
recipeinstructions:
- "Cuci bersih ayam, balur dengan perasan jeruk nipis. Diamkan 10 menit, bilas."
- "Goreng ayam setengah matang. Angkat dan sisihkan"
- "Tumis bumbu halus, masukkan daun salam, serai, tumis sampai harum."
- "Masukkan ayam, tambahkan air, garam, merica, gula, kaldu bubuk. Masak hingga matang. Koreksi rasa."
- "Sesaat sebelum diangkat, beri kemangi secukupnya, aduk. Angkat dan sajikan."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 249 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/303e876554cba3a1/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Kita

Keharmonisan keluarga bisa didapat dengan cara mudah. Diantaranya adalah memasak Ayam rica-rica kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang dapat anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica kemangi:

1. Diperlukan 1/2 ekor ayam
1. Diperlukan 1 buah jeruk nipis
1. Siapkan 1 batang serai
1. Harap siapkan 3 lembar daun salam
1. Dibutuhkan Secukupnya daun kemangi
1. Siapkan 1/2 sdt garam
1. Jangan lupa Secukupnya merica, gula, kaldu bubuk
1. Siapkan  Minyak goreng
1. Jangan lupa  Bumbu Halus ::
1. Harus ada 7 butir bawang merah
1. Siapkan 4 siung bawang putih
1. Siapkan 2 ruas kunyit
1. Tambah 1 ruas jahe
1. Diperlukan 3 butir kemiri
1. Harus ada 1 buah tomat
1. Tambah 5 buah cabe merah
1. Dibutuhkan 10 buah cabe rawit




<!--inarticleads2-->

##### Langkah membuat  Ayam rica-rica kemangi:

1. Cuci bersih ayam, balur dengan perasan jeruk nipis. Diamkan 10 menit, bilas.
1. Goreng ayam setengah matang. Angkat dan sisihkan
1. Tumis bumbu halus, masukkan daun salam, serai, tumis sampai harum.
1. Masukkan ayam, tambahkan air, garam, merica, gula, kaldu bubuk. Masak hingga matang. Koreksi rasa.
1. Sesaat sebelum diangkat, beri kemangi secukupnya, aduk. Angkat dan sajikan.




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan terbukti, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
