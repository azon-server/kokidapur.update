---
description: "Resep : Ayam Rica Kemangi terupdate"
title: "Resep : Ayam Rica Kemangi terupdate"
slug: 204-resep-ayam-rica-kemangi-terupdate
date: 2020-09-15T14:48:41.827Z
image: https://img-global.cpcdn.com/recipes/ad37edc013c5307d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ad37edc013c5307d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ad37edc013c5307d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Lucile Hardy
ratingvalue: 4.3
reviewcount: 28494
recipeingredient:
- "1/2 ekor ayam potong kecil kecil atau sesuai selera"
- " Bumbu halus "
- "4 siung bawang merah"
- "2 siung bawang putih sy pakai baceman bawang"
- " Sekitar 2 cm kunyit"
- " Sekitar 2 cm jahe"
- "2 buah kemiri"
- "5 Cabe kriting 2 cabe rawit"
- "Sejumput ketumbar"
- "1 sdt garam gula pasir penyedap dan lada bubuk"
- " Bahan pelengkap  lengkuas dan sereh geprekdaun salam kemangi"
- "1 gelas air matang"
recipeinstructions:
- "Cuci bersih ayam dan potong2 sesuai selera"
- "Tumis bumbu yang dihaluskan sampai wangi. Masukkan sereh, lengkuas, dan daun salam"
- "Masukkan ayam aduk2 rata sampai ayam berubah warna, tambahkan air 1 gelas belimbing boleh lebih, masak sampai air menyusut tambahkan daun kemangi, tes rasa."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 249 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/ad37edc013c5307d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau gurih. Karasteristik kuliner Nusantara ayam rica kemangi yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica Kemangi untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang dapat anda contoh salah satunya ayam rica kemangi yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Harap siapkan 1/2 ekor ayam, potong kecil kecil atau sesuai selera
1. Dibutuhkan  Bumbu halus :
1. Jangan lupa 4 siung bawang merah
1. Tambah 2 siung bawang putih (sy pakai baceman bawang)
1. Jangan lupa  Sekitar 2 cm kunyit
1. Dibutuhkan  Sekitar 2 cm jahe
1. Tambah 2 buah kemiri
1. Jangan lupa 5 Cabe kriting, 2 cabe rawit
1. Harus ada Sejumput ketumbar
1. Dibutuhkan 1 sdt garam, gula pasir, penyedap dan lada bubuk
1. Harus ada  Bahan pelengkap : lengkuas dan sereh geprek,daun salam, kemangi
1. Diperlukan 1 gelas air matang




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Kemangi:

1. Cuci bersih ayam dan potong2 sesuai selera
1. Tumis bumbu yang dihaluskan sampai wangi. Masukkan sereh, lengkuas, dan daun salam
1. Masukkan ayam aduk2 rata sampai ayam berubah warna, tambahkan air 1 gelas belimbing boleh lebih, masak sampai air menyusut tambahkan daun kemangi, tes rasa.




Demikianlah cara membuat ayam rica kemangi yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan terbukti, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
