---
description: "Step-by-Step untuk menyiapakan Ayam Rica-Rica Daun Kemangi Favorite"
title: "Step-by-Step untuk menyiapakan Ayam Rica-Rica Daun Kemangi Favorite"
slug: 295-step-by-step-untuk-menyiapakan-ayam-rica-rica-daun-kemangi-favorite
date: 2020-08-28T10:17:55.009Z
image: https://img-global.cpcdn.com/recipes/3c0aaf7772069f0f/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3c0aaf7772069f0f/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3c0aaf7772069f0f/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Bernard Walker
ratingvalue: 4.6
reviewcount: 17309
recipeingredient:
- "1 ekor ayam"
- "1 ikat daun kemangi"
- "2 lembar daun salam"
- "1 tangkai serai geprek"
- " Bumbu Halus"
- "8 siung bawang merah"
- "6 siung bawang putih"
- "12 buah cabe merah sesuai selera"
- "8 buah cabe rawit sesuai selera"
- "2 buah tomat kalo tomatnya besar 1 aja tidak apaapa"
- "2 buah kemiri"
- "2 ruas kunyit"
- "2 ruas jahe"
- "1/2 sdt garam"
- "1 1/2 sdt gula pasir"
- "1/2 sdt penyedap rasa"
- "1/2 sdt lada"
recipeinstructions:
- "Ulek/blender bumbu halus (bawang merah, bawang putih, tomat, cabe merah, cabe rawit, jahe, kunyit, kemiri) beri lada."
- "Goreng ayam yg sudah dipotong kecil-kecil (btw waktu saya beli ayam yg jual nawarin potong rica-rica/goreng), goreng setengah matang."
- "Tumis bumbu halus tadi dengan api kecil, masukkan daun salam, serai, garam, gula, &amp; penyedap rasa."
- "Setelah wangi, masukkan ayam yg sudah digoreng setengah matang aduk sebentar lalu tuangkan air sedikit demi sedikit. Patokan saya sampai ayamnya sudah agak tenggelam."
- "Tunggu sampai airnya menyusut dan mengental. Disini api boleh dibesarkan supaya cepat menyusut airnya."
- "Jika sudah menyusut kecilkan api kembali kemudian taburkan daun kemangi, aduk sebentar sampai daun agak layu. Kemudian sajikan!"
categories:
- Recipe
tags:
- ayam
- ricarica
- daun

katakunci: ayam ricarica daun 
nutrition: 258 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Rica-Rica Daun Kemangi](https://img-global.cpcdn.com/recipes/3c0aaf7772069f0f/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita jaga karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica-rica daun kemangi yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan ciri khas yang merupakan keragaman Kita

Keharmonisan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica-Rica Daun Kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang dapat anda coba salah satunya ayam rica-rica daun kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica-rica daun kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Daun Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Daun Kemangi:

1. Harus ada 1 ekor ayam
1. Siapkan 1 ikat daun kemangi
1. Harus ada 2 lembar daun salam
1. Harap siapkan 1 tangkai serai (geprek)
1. Harus ada  Bumbu Halus
1. Dibutuhkan 8 siung bawang merah
1. Jangan lupa 6 siung bawang putih
1. Siapkan 12 buah cabe merah (sesuai selera)
1. Jangan lupa 8 buah cabe rawit (sesuai selera)
1. Siapkan 2 buah tomat (kalo tomatnya besar 1 aja tidak apa-apa)
1. Jangan lupa 2 buah kemiri
1. Harap siapkan 2 ruas kunyit
1. Tambah 2 ruas jahe
1. Diperlukan 1/2 sdt garam
1. Harus ada 1 1/2 sdt gula pasir
1. Dibutuhkan 1/2 sdt penyedap rasa
1. Diperlukan 1/2 sdt lada




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica Daun Kemangi:

1. Ulek/blender bumbu halus (bawang merah, bawang putih, tomat, cabe merah, cabe rawit, jahe, kunyit, kemiri) beri lada.
1. Goreng ayam yg sudah dipotong kecil-kecil (btw waktu saya beli ayam yg jual nawarin potong rica-rica/goreng), goreng setengah matang.
1. Tumis bumbu halus tadi dengan api kecil, masukkan daun salam, serai, garam, gula, &amp; penyedap rasa.
1. Setelah wangi, masukkan ayam yg sudah digoreng setengah matang aduk sebentar lalu tuangkan air sedikit demi sedikit. Patokan saya sampai ayamnya sudah agak tenggelam.
1. Tunggu sampai airnya menyusut dan mengental. Disini api boleh dibesarkan supaya cepat menyusut airnya.
1. Jika sudah menyusut kecilkan api kembali kemudian taburkan daun kemangi, aduk sebentar sampai daun agak layu. Kemudian sajikan!




Demikianlah cara membuat ayam rica-rica daun kemangi yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
