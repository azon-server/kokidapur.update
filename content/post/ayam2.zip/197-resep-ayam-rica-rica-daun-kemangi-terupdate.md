---
description: "Resep : Ayam rica-rica daun kemangi terupdate"
title: "Resep : Ayam rica-rica daun kemangi terupdate"
slug: 197-resep-ayam-rica-rica-daun-kemangi-terupdate
date: 2020-12-31T15:22:47.261Z
image: https://img-global.cpcdn.com/recipes/6f0f4c938cbed18e/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6f0f4c938cbed18e/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6f0f4c938cbed18e/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Effie Luna
ratingvalue: 4.4
reviewcount: 37708
recipeingredient:
- "1/2 kg ayam"
- "1 ikat daun kemangi petik sesuai selera"
- "2 daun salam"
- "1 ruas lengkuas yg digeprek"
- "2 lembar daun jeruk"
- "1 sereh yg digeprek"
- "1 sdm gula jawa"
- "secukupnya Garam dan kaldu ayam"
- " Air kaldu ayam"
- "1 gelas kecil Air"
- " Bumbu halus"
- "6 bawang merah"
- "4 bawang putih"
- "1 kemiri"
- "1 cm jahe"
- "1 cm kunyit"
- "Sdt keyumbar"
recipeinstructions:
- "Haluskan bumbu halus dengan minyak"
- "Tumis bumbu halus dan tambahkan daun salam, lengkuas, daun jeruk, sereh..tumis hingga tanak"
- "Masukan ayam dan aduk2 hingga ayam berubah menjadi putih"
- "Tambahkan 250ml air / sesuai selera, kemudian tunggu hingga mendidih"
- "Masukan gula jawa, garam dan kaldu ayam sesuai selera"
- "Aduk² dan tunggu hingga air agak menyusut"
- "Tambahkan daun kemangi, aduk2 sebentar dan matikan api"
- "Tambahkan bawang merah goreng dan siap disajikan"
categories:
- Recipe
tags:
- ayam
- ricarica
- daun

katakunci: ayam ricarica daun 
nutrition: 148 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT31M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam rica-rica daun kemangi](https://img-global.cpcdn.com/recipes/6f0f4c938cbed18e/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica-rica daun kemangi yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Kita

Keharmonisan keluarga dapat didapat dengan cara mudah. Salah satunya adalah memasak Ayam rica-rica daun kemangi untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang dapat anda buat salah satunya ayam rica-rica daun kemangi yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica-rica daun kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica daun kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica daun kemangi:

1. Siapkan 1/2 kg ayam
1. Jangan lupa 1 ikat daun kemangi, petik sesuai selera
1. Dibutuhkan 2 daun salam
1. Dibutuhkan 1 ruas lengkuas yg digeprek
1. Tambah 2 lembar daun jeruk
1. Harap siapkan 1 sereh yg digeprek
1. Jangan lupa 1 sdm gula jawa
1. Harus ada secukupnya Garam dan kaldu ayam
1. Jangan lupa  Air kaldu ayam
1. Diperlukan 1 gelas kecil Air
1. Jangan lupa  Bumbu halus
1. Diperlukan 6 bawang merah
1. Tambah 4 bawang putih
1. Diperlukan 1 kemiri
1. Diperlukan 1 cm jahe
1. Siapkan 1 cm kunyit
1. Tambah Sdt keyumbar




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica-rica daun kemangi:

1. Haluskan bumbu halus dengan minyak
1. Tumis bumbu halus dan tambahkan daun salam, lengkuas, daun jeruk, sereh..tumis hingga tanak
1. Masukan ayam dan aduk2 hingga ayam berubah menjadi putih
1. Tambahkan 250ml air / sesuai selera, kemudian tunggu hingga mendidih
1. Masukan gula jawa, garam dan kaldu ayam sesuai selera
1. Aduk² dan tunggu hingga air agak menyusut
1. Tambahkan daun kemangi, aduk2 sebentar dan matikan api
1. Tambahkan bawang merah goreng dan siap disajikan




Demikianlah cara membuat ayam rica-rica daun kemangi yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan teruji, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
