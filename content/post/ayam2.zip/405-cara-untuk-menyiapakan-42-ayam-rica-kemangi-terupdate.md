---
description: "Cara untuk menyiapakan 42 - Ayam Rica Kemangi terupdate"
title: "Cara untuk menyiapakan 42 - Ayam Rica Kemangi terupdate"
slug: 405-cara-untuk-menyiapakan-42-ayam-rica-kemangi-terupdate
date: 2020-12-01T21:59:49.377Z
image: https://img-global.cpcdn.com/recipes/e3e90be60e448996/751x532cq70/42-ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e3e90be60e448996/751x532cq70/42-ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e3e90be60e448996/751x532cq70/42-ayam-rica-kemangi-foto-resep-utama.jpg
author: Eva Fisher
ratingvalue: 4.3
reviewcount: 14826
recipeingredient:
- " Bahan Utama"
- "1/2 ekor ayam potong sesuai selera"
- "1/2 buah jeruk nipis utk melumuri ayam sy skip"
- "1 ikat daun kemangi tambahan sy"
- "Secukupnya garam dan gula"
- " Bumbu Halus"
- "15 batang cabe merah keriting atau sesuai selera"
- "10 batang cabe rawit merah sy skip"
- "1 ruas jari kunyit sy 12 sdt kunyit bubuk"
- "1 ruas jari jahe"
- "1 buah tomat uk sedang"
- "4 butir bawang merah"
- "3 siung bawang putih"
- " Bahan Tambahan"
- "3 lembar daun jeruk"
- "1 batang sereh ambil bagian putihnya saja memarkan"
recipeinstructions:
- "Cuci bersih ayam dan daun kemangi, sisihkan. Blender bumbu halus, sisihkan dulu."
- "Goreng ayam jangan terlalu kering, sisihkan. Tumis bumbu bersama dg daun jeruk dan sereh hingga harum dan setengah matang. Tambahkan garam dan gula, aduk rata."
- "Masukkan ayam yg sudah digoreng, aduk rata. Masak hingga bumbu meresap. Tambahkan kemangi, aduk rata. Matikan kompor."
- "Ayam rica kemangi siap disantap. Sedia nasi putih banyakan dibanding biasa ya moms.... hehe"
categories:
- Recipe
tags:
- 42
- 
- ayam

katakunci: 42  ayam 
nutrition: 105 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT31M"
recipeyield: "1"
recipecategory: Dinner

---


![42 - Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/e3e90be60e448996/751x532cq70/42-ayam-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti 42 - ayam rica kemangi yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa ciri khas yang merupakan keragaman Indonesia

Keharmonisan rumah tangga dapat diperoleh dengan cara mudah. Salah satunya adalah memasak 42 - Ayam Rica Kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang bisa anda buat salah satunya 42 - ayam rica kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep 42 - ayam rica kemangi tanpa harus bersusah payah.
Seperti resep 42 - Ayam Rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 42 - Ayam Rica Kemangi:

1. Siapkan  Bahan Utama:
1. Dibutuhkan 1/2 ekor ayam, potong sesuai selera
1. Tambah 1/2 buah jeruk nipis, utk melumuri ayam (sy skip)
1. Dibutuhkan 1 ikat daun kemangi (tambahan sy)
1. Jangan lupa Secukupnya garam dan gula
1. Tambah  Bumbu Halus:
1. Jangan lupa 15 batang cabe merah keriting (atau sesuai selera)
1. Diperlukan 10 batang cabe rawit merah (sy skip)
1. Harus ada 1 ruas jari kunyit (sy 1/2 sdt kunyit bubuk)
1. Jangan lupa 1 ruas jari jahe
1. Diperlukan 1 buah tomat uk sedang
1. Tambah 4 butir bawang merah
1. Diperlukan 3 siung bawang putih
1. Jangan lupa  Bahan Tambahan:
1. Dibutuhkan 3 lembar daun jeruk
1. Harap siapkan 1 batang sereh, ambil bagian putihnya saja, memarkan




<!--inarticleads2-->

##### Instruksi membuat  42 - Ayam Rica Kemangi:

1. Cuci bersih ayam dan daun kemangi, sisihkan. Blender bumbu halus, sisihkan dulu.
1. Goreng ayam jangan terlalu kering, sisihkan. Tumis bumbu bersama dg daun jeruk dan sereh hingga harum dan setengah matang. Tambahkan garam dan gula, aduk rata.
1. Masukkan ayam yg sudah digoreng, aduk rata. Masak hingga bumbu meresap. Tambahkan kemangi, aduk rata. Matikan kompor.
1. Ayam rica kemangi siap disantap. Sedia nasi putih banyakan dibanding biasa ya moms.... hehe




Demikianlah cara membuat 42 - ayam rica kemangi yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan teruji, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
