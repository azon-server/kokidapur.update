---
description: "Resep : Ayam Rica Rica Kemangi Sempurna"
title: "Resep : Ayam Rica Rica Kemangi Sempurna"
slug: 315-resep-ayam-rica-rica-kemangi-sempurna
date: 2020-11-29T10:23:16.519Z
image: https://img-global.cpcdn.com/recipes/e8334cf7a8dc52fb/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e8334cf7a8dc52fb/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e8334cf7a8dc52fb/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Dominic Hammond
ratingvalue: 4.3
reviewcount: 10293
recipeingredient:
- "1 kg ayam potong"
- "2 ruas jahe"
- "1 ruas lengkuas"
- "2 batang sereh"
- "2 lembar daun jeruk"
- "1 lembar daun salam"
- "1 jeruk nipis aku skip"
- "5 buah cabai rawit iris serong"
- "300 ml air"
- "Segenggam kemangi"
- "Secukupnya gula garam dan penyedap"
- "Secukupnya minyak utk menumis"
- " Bumbu Halus"
- "6 buah cabai merah besar"
- "4 buah cabai hijau aku skip"
- "2 buah kemiri"
- "3 ruas kunyit"
- "4 siung bawang merah"
- "5 siung bawang putih"
recipeinstructions:
- "Potong ayam ukuran sedang. Kalau gak mau dipotong, juga gapapa. Optional. Cuci bersih. Sisihkan."
- "Tumis bumbu halus. Tambahkan daun salam, daun jeruk, sereh, jahe, laos. Tumis sampai harum."
- "Tambahkan air, garam, gula, penyedap. Masukan ayam. Masak hingga air menyusut. Masukkan kemangi."
- "Koreksi rasa. Sajikaaan!"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 234 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/e8334cf7a8dc52fb/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau empuk. Ciri makanan Nusantara ayam rica rica kemangi yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kedekatan rumah tangga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Rica Rica Kemangi untuk orang di rumah. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis makanan yang dapat anda coba salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Dibutuhkan 1 kg ayam potong
1. Jangan lupa 2 ruas jahe
1. Jangan lupa 1 ruas lengkuas
1. Diperlukan 2 batang sereh
1. Harus ada 2 lembar daun jeruk
1. Harus ada 1 lembar daun salam
1. Diperlukan 1 jeruk nipis (aku skip)
1. Harus ada 5 buah cabai rawit iris serong
1. Diperlukan 300 ml air
1. Jangan lupa Segenggam kemangi
1. Jangan lupa Secukupnya gula, garam dan penyedap
1. Harap siapkan Secukupnya minyak utk menumis
1. Diperlukan  Bumbu Halus
1. Siapkan 6 buah cabai merah besar
1. Dibutuhkan 4 buah cabai hijau (aku skip)
1. Jangan lupa 2 buah kemiri
1. Harus ada 3 ruas kunyit
1. Harus ada 4 siung bawang merah
1. Diperlukan 5 siung bawang putih




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica Kemangi:

1. Potong ayam ukuran sedang. Kalau gak mau dipotong, juga gapapa. Optional. Cuci bersih. Sisihkan.
1. Tumis bumbu halus. Tambahkan daun salam, daun jeruk, sereh, jahe, laos. Tumis sampai harum.
1. Tambahkan air, garam, gula, penyedap. Masukan ayam. Masak hingga air menyusut. Masukkan kemangi.
1. Koreksi rasa. Sajikaaan!




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan teruji, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
