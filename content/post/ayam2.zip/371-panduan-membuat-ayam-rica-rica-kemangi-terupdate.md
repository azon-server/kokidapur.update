---
description: "Panduan membuat Ayam Rica-rica Kemangi 🌶 terupdate"
title: "Panduan membuat Ayam Rica-rica Kemangi 🌶 terupdate"
slug: 371-panduan-membuat-ayam-rica-rica-kemangi-terupdate
date: 2020-08-09T07:52:33.272Z
image: https://img-global.cpcdn.com/recipes/e132c612b9dc9bab/751x532cq70/ayam-rica-rica-kemangi-🌶-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e132c612b9dc9bab/751x532cq70/ayam-rica-rica-kemangi-🌶-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e132c612b9dc9bab/751x532cq70/ayam-rica-rica-kemangi-🌶-foto-resep-utama.jpg
author: Ida Robbins
ratingvalue: 4.2
reviewcount: 17460
recipeingredient:
- "1/2 ekor ayam"
- "1/2 buah jeruk nipis"
- "1 ikat daun kemangi"
- "1/2 sdt gula pasir"
- "1/2 sdt garam"
- "1/2 sdt kaldu bubuk"
- "250 ml air"
- "5 sdm minyak untuk menumis"
- " Bumbu halus"
- "5 siung bawang merah"
- "4 siung bawang putih"
- "5 buah cabe merah"
- "10 buah cabe rawit hijau"
- "5 buah cabe rawit merah"
- "2 butir kemiri"
- "1 ruas kunyit"
- "1 ruas jahe"
- " Bumbu utuh"
- "1 batang sereh geprek"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "1 ruas lengkuas geprek"
recipeinstructions:
- "Cuci ayam hingga bersih, tiriskan dan beri air perasan jeruk nipis agar tidak amis. Selanjutnya cuci daun kemangi, tiriskan."
- "Tumis bumbu halus dan bumbu utuh, tambahkan gula, garam dan kaldu bubuk, koreksi rasa, kemudian tambahkan air."
- "Setelah mendidih, masukkan ayam, masak dengan api kecil sambil sesekali diaduk sampai air menyusut dan bumbu meresap ke dalam ayam."
- "Setelah matang lalu masukkan daun kemangi, aduk sebentar hingga merata kemudian matikan api."
- "Angkat dan siap disajikan."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 252 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica-rica Kemangi 🌶](https://img-global.cpcdn.com/recipes/e132c612b9dc9bab/751x532cq70/ayam-rica-rica-kemangi-🌶-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan gurih. Ciri masakan Indonesia ayam rica-rica kemangi 🌶 yang kaya dengan bumbu memberikan kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kedekatan rumah tangga bisa ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica-rica Kemangi 🌶 untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda buat salah satunya ayam rica-rica kemangi 🌶 yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica-rica kemangi 🌶 tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica Kemangi 🌶 yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 22 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica Kemangi 🌶:

1. Diperlukan 1/2 ekor ayam
1. Diperlukan 1/2 buah jeruk nipis
1. Tambah 1 ikat daun kemangi
1. Diperlukan 1/2 sdt gula pasir
1. Harap siapkan 1/2 sdt garam
1. Jangan lupa 1/2 sdt kaldu bubuk
1. Harap siapkan 250 ml air
1. Tambah 5 sdm minyak untuk menumis
1. Harap siapkan  Bumbu halus
1. Diperlukan 5 siung bawang merah
1. Harus ada 4 siung bawang putih
1. Harap siapkan 5 buah cabe merah
1. Diperlukan 10 buah cabe rawit hijau
1. Harap siapkan 5 buah cabe rawit merah
1. Harus ada 2 butir kemiri
1. Dibutuhkan 1 ruas kunyit
1. Tambah 1 ruas jahe
1. Diperlukan  Bumbu utuh
1. Jangan lupa 1 batang sereh, geprek
1. Jangan lupa 2 lembar daun jeruk
1. Dibutuhkan 2 lembar daun salam
1. Harus ada 1 ruas lengkuas, geprek




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-rica Kemangi 🌶:

1. Cuci ayam hingga bersih, tiriskan dan beri air perasan jeruk nipis agar tidak amis. Selanjutnya cuci daun kemangi, tiriskan.
1. Tumis bumbu halus dan bumbu utuh, tambahkan gula, garam dan kaldu bubuk, koreksi rasa, kemudian tambahkan air.
1. Setelah mendidih, masukkan ayam, masak dengan api kecil sambil sesekali diaduk sampai air menyusut dan bumbu meresap ke dalam ayam.
1. Setelah matang lalu masukkan daun kemangi, aduk sebentar hingga merata kemudian matikan api.
1. Angkat dan siap disajikan.




Demikianlah cara membuat ayam rica-rica kemangi 🌶 yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan teruji, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
