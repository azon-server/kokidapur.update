---
description: "Panduan untuk membuat Opor ayam lontong Favorite"
title: "Panduan untuk membuat Opor ayam lontong Favorite"
slug: 495-panduan-untuk-membuat-opor-ayam-lontong-favorite
date: 2021-01-07T01:38:23.874Z
image: https://img-global.cpcdn.com/recipes/24a808476a2c63e3/751x532cq70/opor-ayam-lontong-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/24a808476a2c63e3/751x532cq70/opor-ayam-lontong-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/24a808476a2c63e3/751x532cq70/opor-ayam-lontong-foto-resep-utama.jpg
author: Lura Powell
ratingvalue: 4.1
reviewcount: 6549
recipeingredient:
- "1 ekor Dada ayam dari  potong jadi 6"
- "1/2 buah jeruk nipis"
- "500 ml santan"
- " Bumbu halus "
- "8 siung bawang merah"
- "4 siung bawang putih"
- "2 ruas kunyit"
- "1 ruas jahe"
- "1 buah kemiri"
- "1/2 sdt biji ketumbar"
- "Secukupnya garamkaldu bubuk dan gula pasir"
- "1 "
- " Bumbu pelengkap "
- "2 batang serai geprek"
- "3 lembar daun salam"
- "4 lembar daun jeruk"
- "2 ruas lengkuas geprek"
- " Minyak untuk menumis"
- " Bahan pelengkap "
- " Lontong ada di resep sebelumnya"
- " Sambal merah"
- " Bawang goreng untuk taburan"
recipeinstructions:
- "Cuci bersih ayam beri perasan jeruk nipis biarkan 10 menit lalu bilas kembali"
- "Tumis bumbu halus sampai wangi lalu masukkan bumbu pelengkap sambil di aduk&#34;,,,kemudian masukkan ayam dan beri sedikit air masak sampai air menyusut atau sampai ayam empuk lalu matikan api"
- "Masukkan santan ke dalam panci lalu masak sampai mendidih sambil sesekali diaduk&#34; agar santan tidak pecah,,,setelah mendidih masukkan ayam yg tadi telah dimasak dengan bumbu beri garam,,kaldu bubuk dan gula pasir lalu masak sampai mendidih kembali kemudian tes rasa bila sudah ok matikan api"
- "Siapkan lontong dalam mangkok lalu siram dengan opor ayam yg baru matang beri sambal dan taburang bawang goreng,,,sajikan selagi hangat"
- "Selamat mencoba semoga bermanfaat..."
categories:
- Recipe
tags:
- opor
- ayam
- lontong

katakunci: opor ayam lontong 
nutrition: 269 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dessert

---


![Opor ayam lontong](https://img-global.cpcdn.com/recipes/24a808476a2c63e3/751x532cq70/opor-ayam-lontong-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga enak. Ciri khas makanan Indonesia opor ayam lontong yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan keluarga bisa didapat dengan cara simple. Salah satunya adalah memasak Opor ayam lontong untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi makanan yang dapat anda coba salah satunya opor ayam lontong yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep opor ayam lontong tanpa harus bersusah payah.
Berikut ini resep Opor ayam lontong yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Opor ayam lontong:

1. Harus ada 1 ekor Dada ayam dari  (potong jadi 6)
1. Dibutuhkan 1/2 buah jeruk nipis
1. Dibutuhkan 500 ml santan
1. Harus ada  Bumbu halus :
1. Jangan lupa 8 siung bawang merah
1. Dibutuhkan 4 siung bawang putih
1. Dibutuhkan 2 ruas kunyit
1. Harap siapkan 1 ruas jahe
1. Tambah 1 buah kemiri
1. Dibutuhkan 1/2 sdt biji ketumbar
1. Tambah Secukupnya garam,,kaldu bubuk dan gula pasir
1. Siapkan 1 
1. Jangan lupa  Bumbu pelengkap :
1. Siapkan 2 batang serai geprek
1. Diperlukan 3 lembar daun salam
1. Harap siapkan 4 lembar daun jeruk
1. Siapkan 2 ruas lengkuas geprek
1. Tambah  Minyak untuk menumis
1. Diperlukan  Bahan pelengkap :
1. Dibutuhkan  Lontong (ada di resep sebelumnya)
1. Tambah  Sambal merah
1. Jangan lupa  Bawang goreng untuk taburan




<!--inarticleads2-->

##### Cara membuat  Opor ayam lontong:

1. Cuci bersih ayam beri perasan jeruk nipis biarkan 10 menit lalu bilas kembali
1. Tumis bumbu halus sampai wangi lalu masukkan bumbu pelengkap sambil di aduk&#34;,,,kemudian masukkan ayam dan beri sedikit air masak sampai air menyusut atau sampai ayam empuk lalu matikan api
1. Masukkan santan ke dalam panci lalu masak sampai mendidih sambil sesekali diaduk&#34; agar santan tidak pecah,,,setelah mendidih masukkan ayam yg tadi telah dimasak dengan bumbu beri garam,,kaldu bubuk dan gula pasir lalu masak sampai mendidih kembali kemudian tes rasa bila sudah ok matikan api
1. Siapkan lontong dalam mangkok lalu siram dengan opor ayam yg baru matang beri sambal dan taburang bawang goreng,,,sajikan selagi hangat
1. Selamat mencoba semoga bermanfaat...




Demikianlah cara membuat opor ayam lontong yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
