---
description: "Cara singkat menyiapakan Ayam Rica-Rica Kemangi Homemade"
title: "Cara singkat menyiapakan Ayam Rica-Rica Kemangi Homemade"
slug: 218-cara-singkat-menyiapakan-ayam-rica-rica-kemangi-homemade
date: 2020-10-16T20:16:35.024Z
image: https://img-global.cpcdn.com/recipes/11e4867b3d2ff2a5/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/11e4867b3d2ff2a5/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/11e4867b3d2ff2a5/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Owen Price
ratingvalue: 4.2
reviewcount: 25116
recipeingredient:
- "1 Ekor Ayam Anggaran 700800gr"
- "7 Cabe Rawit Utuh Untuk Dimasak Utuh2x Sama Ayamnya Nanti"
- "1 Batang Sereh"
- "2 Lembar Daun Salam"
- "3 Lembar Daun Jeruk"
- "1 Buah Jeruk Nipis"
- "Sesuai Selera Daun Kemangi"
- " Bumbu Halus"
- "10 Cabe Merah Keriting"
- "10 Cabe Rawit"
- "10 Bawang Merah"
- "5 Bawang Putih"
- "3 Kemiri"
- "2 Ruas Jari Kunyit"
- "1 Ruas Jari Jahe"
- "Secukupnya Air"
- " Seasoning"
- " Kaldu Ayam Bubuk Garam Gula Lada Sesuai Selera"
recipeinstructions:
- "Potong2x ayam sesuai selera, kalau aku ayamnya dipotong 10..."
- "Haluskan semua bahan bumbu halus, kemudian tumis sampai tanak dan bau langunya hilang. Jangan lupa masukan Sereh, Salam dan Daun Jeruknya..."
- "Setelah bumbu matang, masukan 300ml air, didihkan, kemudian masukan ayamnya..."
- "Tambahkan seasoning seperti Kaldu ayam bubuk, Garam, Lada, Gula sesuai selera, koreksi rasanya kemudian aduk rata..."
- "Masak sampai ayamnya matang dan airnya menyusut, kemudian masukan Kemanginya, aduk sebentar aja kemudian matikan apinya..."
- "Terakhir peras Air Jeruk Nipis dan aduk rata lagi, lalu Ayam Rica-ricanya siap untuk disajikan...."
- "Semoga Suka Sama Resepnya ya... Untuk Yang Recook di Instagram Jgn Lupa Hashtag #ResepDariWonderland atau Langsung aja Tag ke @dapurdiwonderland"
- "Makasih... Selamat Mencoba... 😁😁"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 208 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT54M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/11e4867b3d2ff2a5/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga gurih. Ciri khas kuliner Nusantara ayam rica-rica kemangi yang kaya dengan rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.




Keharmonisan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah memasak Ayam Rica-Rica Kemangi untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang dapat anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Kemangi:

1. Harap siapkan 1 Ekor Ayam Anggaran 700-800gr
1. Diperlukan 7 Cabe Rawit Utuh (Untuk Dimasak Utuh2x Sama Ayamnya Nanti)
1. Tambah 1 Batang Sereh
1. Harap siapkan 2 Lembar Daun Salam
1. Siapkan 3 Lembar Daun Jeruk
1. Jangan lupa 1 Buah Jeruk Nipis
1. Siapkan Sesuai Selera Daun Kemangi
1. Siapkan  Bumbu Halus
1. Harap siapkan 10 Cabe Merah Keriting
1. Jangan lupa 10 Cabe Rawit
1. Harap siapkan 10 Bawang Merah
1. Siapkan 5 Bawang Putih
1. Jangan lupa 3 Kemiri
1. Harus ada 2 Ruas Jari Kunyit
1. Jangan lupa 1 Ruas Jari Jahe
1. Tambah Secukupnya Air
1. Harap siapkan  Seasoning
1. Jangan lupa  Kaldu Ayam Bubuk, Garam, Gula, Lada (Sesuai Selera)




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica Kemangi:

1. Potong2x ayam sesuai selera, kalau aku ayamnya dipotong 10...
1. Haluskan semua bahan bumbu halus, kemudian tumis sampai tanak dan bau langunya hilang. Jangan lupa masukan Sereh, Salam dan Daun Jeruknya...
1. Setelah bumbu matang, masukan 300ml air, didihkan, kemudian masukan ayamnya...
1. Tambahkan seasoning seperti Kaldu ayam bubuk, Garam, Lada, Gula sesuai selera, koreksi rasanya kemudian aduk rata...
1. Masak sampai ayamnya matang dan airnya menyusut, kemudian masukan Kemanginya, aduk sebentar aja kemudian matikan apinya...
1. Terakhir peras Air Jeruk Nipis dan aduk rata lagi, lalu Ayam Rica-ricanya siap untuk disajikan....
1. Semoga Suka Sama Resepnya ya... Untuk Yang Recook di Instagram Jgn Lupa Hashtag #ResepDariWonderland atau Langsung aja Tag ke @dapurdiwonderland
1. Makasih... Selamat Mencoba... 😁😁




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
