---
description: "Resep : Ayam Rica Pedas Kemangi 🍗 🌶🌶 Cepat"
title: "Resep : Ayam Rica Pedas Kemangi 🍗 🌶🌶 Cepat"
slug: 320-resep-ayam-rica-pedas-kemangi-cepat
date: 2021-01-19T15:53:01.495Z
image: https://img-global.cpcdn.com/recipes/8285d19f11bdaacf/751x532cq70/ayam-rica-pedas-kemangi-🍗-🌶🌶-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8285d19f11bdaacf/751x532cq70/ayam-rica-pedas-kemangi-🍗-🌶🌶-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8285d19f11bdaacf/751x532cq70/ayam-rica-pedas-kemangi-🍗-🌶🌶-foto-resep-utama.jpg
author: Rachel Norton
ratingvalue: 4.3
reviewcount: 12955
recipeingredient:
- " Bumbu Halus"
- "4 bh bawang merah"
- "2 bh bawang putih"
- "2 bh kemiri"
- "1 ruas lengkuas"
- "10 cabe merah"
- "5 cabe keriting"
- " Bahan"
- "2 ptg ayam kecil"
- "1 lmbr daun jeruk"
- " Daun kemangi secukupnya"
- "1 ruas sereh"
- "1 sdm kecap"
- "1 sdt lada"
- " Garam"
- " Gula"
- " Royco ayam secukupnya"
recipeinstructions:
- "Cuci bersih potongan ayam yang sudah disiapkan. Keringkan, lalu beri taburan garam secukupnya."
- "Haluskan bumbu halus yang telah disiapkan (bawang merah, bawang putih, kemiri, lengkuas &amp; cabe). Tambahkan royco secukupnya pada bumbu halus."
- "Goreng setengah matang ayam yang sudah diberi garam (kurang lebih 2 menit). Kemudian tiriskan."
- "Siapkan minyak secukupnya, masukkan bumbu halus, kemudian daun jeruk, sereh dan daun kemangi. Tunggu sampai bumbu harum."
- "Setelah bumbu harum, masukkan ayam dan goreng sebentar. Tambahkan air secukupnya, lalu tunggu hingga air sedikit menyusut."
- "Setelah itu tambahkan 1 sdm kecap manis, lada, garam, gula &amp; royco. Tes rasa, jika sudah sesuai, tunggu hingga air mulai asat."
- "Ayam rica pedas kemangi siap untuk disantap !"
categories:
- Recipe
tags:
- ayam
- rica
- pedas

katakunci: ayam rica pedas 
nutrition: 187 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Pedas Kemangi 🍗 🌶🌶](https://img-global.cpcdn.com/recipes/8285d19f11bdaacf/751x532cq70/ayam-rica-pedas-kemangi-🍗-🌶🌶-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga empuk. Ciri kuliner Nusantara ayam rica pedas kemangi 🍗 🌶🌶 yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Keharmonisan keluarga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Ayam Rica Pedas Kemangi 🍗 🌶🌶 untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang bisa anda praktekkan salah satunya ayam rica pedas kemangi 🍗 🌶🌶 yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep ayam rica pedas kemangi 🍗 🌶🌶 tanpa harus bersusah payah.
Seperti resep Ayam Rica Pedas Kemangi 🍗 🌶🌶 yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Pedas Kemangi 🍗 🌶🌶:

1. Diperlukan  Bumbu Halus
1. Tambah 4 bh bawang merah
1. Diperlukan 2 bh bawang putih
1. Tambah 2 bh kemiri
1. Diperlukan 1 ruas lengkuas
1. Diperlukan 10 cabe merah
1. Harus ada 5 cabe keriting
1. Dibutuhkan  Bahan
1. Dibutuhkan 2 ptg ayam kecil
1. Dibutuhkan 1 lmbr daun jeruk
1. Dibutuhkan  Daun kemangi (secukupnya)
1. Harus ada 1 ruas sereh
1. Harus ada 1 sdm kecap
1. Siapkan 1 sdt lada
1. Harus ada  Garam
1. Tambah  Gula
1. Jangan lupa  Royco ayam (secukupnya)




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Pedas Kemangi 🍗 🌶🌶:

1. Cuci bersih potongan ayam yang sudah disiapkan. Keringkan, lalu beri taburan garam secukupnya.
1. Haluskan bumbu halus yang telah disiapkan (bawang merah, bawang putih, kemiri, lengkuas &amp; cabe). Tambahkan royco secukupnya pada bumbu halus.
1. Goreng setengah matang ayam yang sudah diberi garam (kurang lebih 2 menit). Kemudian tiriskan.
1. Siapkan minyak secukupnya, masukkan bumbu halus, kemudian daun jeruk, sereh dan daun kemangi. Tunggu sampai bumbu harum.
1. Setelah bumbu harum, masukkan ayam dan goreng sebentar. Tambahkan air secukupnya, lalu tunggu hingga air sedikit menyusut.
1. Setelah itu tambahkan 1 sdm kecap manis, lada, garam, gula &amp; royco. Tes rasa, jika sudah sesuai, tunggu hingga air mulai asat.
1. Ayam rica pedas kemangi siap untuk disantap !




Demikianlah cara membuat ayam rica pedas kemangi 🍗 🌶🌶 yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
