---
description: "Langkah untuk menyiapakan Lontong sayur teraktual"
title: "Langkah untuk menyiapakan Lontong sayur teraktual"
slug: 487-langkah-untuk-menyiapakan-lontong-sayur-teraktual
date: 2020-08-11T03:53:11.947Z
image: https://img-global.cpcdn.com/recipes/2ff65c149aa37fec/751x532cq70/lontong-sayur-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2ff65c149aa37fec/751x532cq70/lontong-sayur-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2ff65c149aa37fec/751x532cq70/lontong-sayur-foto-resep-utama.jpg
author: Charlotte Haynes
ratingvalue: 4.4
reviewcount: 20892
recipeingredient:
- "Secukupnya Lontong"
- "4 buah manisa"
- "1 bks udang kupas kulit nya"
- "2 buah wortel"
- " opor ayam resep bisa cek di menu sebelumnya"
- "1 lt santan 1 kelapa parut peras dengan air"
- "2 cm lengkuas memarkan"
- "5 lembar daun salam"
- "1 batang serai memarkan"
- "1 sdt lada putih merica"
- " Bawang pre"
- "Secukupnya Gula"
- "Secukupnya Garam"
- "1 sdm kaldu ayam bubuk"
- "Secukupnya Bawang goreng"
- "Secukupnya minyak"
- "Secukupnya air"
- " Bumbu halus"
- "1 buah tomat"
- "4 buah cabe merah buang biji dan rebus dahulu"
- "1 cm kunyit"
- "3 butir kemiri"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "Secukupnya air"
recipeinstructions:
- "Kupas dan iris tipis tipis buah manisa dan campur dengan garam untuk mengurangi getah dan agar irisan manisa menjadi lentur tidak mudah patah."
- "Tumis bumbu halus dan tambahkan lengkuas, daun salam, serai aduk sampai harum baunya dan bumbu matang."
- "Rebus terlebih dahulu wortel yang telah di iris iris setengah matang."
- "Masukkan buah manisa, udang, wortel kemudian aduk merata dengan bumbu nya dan tambahkan santan."
- "Tambahkan gula, merica aduk hingga air menyusut kemudian tambahkan garam dan kaldu ayam. Aduk dan cek rasa."
- "Tambahkan irisan bawang prei aduk sampai merata."
- "Penyajian :Potong lontong sesuai selera kemudian tambahkan sayur manisa dan taburi bawang goreng diatasnya, tambah 1 potong opor ayam beri krupuk dan lontong sayur siap disajikan."
categories:
- Recipe
tags:
- lontong
- sayur

katakunci: lontong sayur 
nutrition: 107 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Lunch

---


![Lontong sayur](https://img-global.cpcdn.com/recipes/2ff65c149aa37fec/751x532cq70/lontong-sayur-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan empuk. Karasteristik kuliner Indonesia lontong sayur yang penuh dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Lontong sayur untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang dapat anda coba salah satunya lontong sayur yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep lontong sayur tanpa harus bersusah payah.
Berikut ini resep Lontong sayur yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 25 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Lontong sayur:

1. Tambah Secukupnya Lontong
1. Jangan lupa 4 buah manisa
1. Harap siapkan 1 bks udang (kupas kulit nya)
1. Diperlukan 2 buah wortel
1. Harap siapkan  opor ayam (resep bisa cek di menu sebelumnya
1. Harap siapkan 1 lt santan (1 kelapa parut peras dengan air)
1. Jangan lupa 2 cm lengkuas (memarkan)
1. Diperlukan 5 lembar daun salam
1. Dibutuhkan 1 batang serai (memarkan)
1. Jangan lupa 1 sdt lada putih (merica)
1. Tambah  Bawang pre
1. Harus ada Secukupnya Gula
1. Dibutuhkan Secukupnya Garam
1. Tambah 1 sdm kaldu ayam bubuk
1. Harap siapkan Secukupnya Bawang goreng
1. Diperlukan Secukupnya minyak
1. Harap siapkan Secukupnya air
1. Siapkan  Bumbu halus
1. Harap siapkan 1 buah tomat
1. Harap siapkan 4 buah cabe merah (buang biji dan rebus dahulu)
1. Tambah 1 cm kunyit
1. Jangan lupa 3 butir kemiri
1. Siapkan 5 siung bawang merah
1. Diperlukan 3 siung bawang putih
1. Dibutuhkan Secukupnya air




<!--inarticleads2-->

##### Instruksi membuat  Lontong sayur:

1. Kupas dan iris tipis tipis buah manisa dan campur dengan garam untuk mengurangi getah dan agar irisan manisa menjadi lentur tidak mudah patah.
1. Tumis bumbu halus dan tambahkan lengkuas, daun salam, serai aduk sampai harum baunya dan bumbu matang.
1. Rebus terlebih dahulu wortel yang telah di iris iris setengah matang.
1. Masukkan buah manisa, udang, wortel kemudian aduk merata dengan bumbu nya dan tambahkan santan.
1. Tambahkan gula, merica aduk hingga air menyusut kemudian tambahkan garam dan kaldu ayam. Aduk dan cek rasa.
1. Tambahkan irisan bawang prei aduk sampai merata.
1. Penyajian :Potong lontong sesuai selera kemudian tambahkan sayur manisa dan taburi bawang goreng diatasnya, tambah 1 potong opor ayam beri krupuk dan lontong sayur siap disajikan.




Demikianlah cara membuat lontong sayur yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
