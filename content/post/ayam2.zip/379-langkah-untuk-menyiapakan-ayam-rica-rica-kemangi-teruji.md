---
description: "Langkah untuk menyiapakan Ayam rica-rica kemangi Teruji"
title: "Langkah untuk menyiapakan Ayam rica-rica kemangi Teruji"
slug: 379-langkah-untuk-menyiapakan-ayam-rica-rica-kemangi-teruji
date: 2020-10-19T16:52:01.381Z
image: https://img-global.cpcdn.com/recipes/a3d9011077bdc376/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a3d9011077bdc376/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a3d9011077bdc376/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Sue Briggs
ratingvalue: 4.1
reviewcount: 45623
recipeingredient:
- "1/2 ekor ayam"
- " Bumbu halus"
- "1/2 ruas kunyit"
- "1 ruas jahe"
- "1 butir kemiri"
- "5 butir bawang merah"
- "4 butir bawang putih"
- "4 buah cabai rawit"
- "4 buah cabe merah keriting"
- " Bahan pelengkap"
- "1/2 ruas lengkuas geprek"
- "secukupnya Gula aren dan garam"
- "1 buah sereh geprek"
- "1 lembar daun salam"
- "2 butir jeruk limau bisa diganti daun jeruk"
- "secukupnya Kemangi daunnya saja"
recipeinstructions:
- "Bersihkan semua bahan, kemudian rebus ayam sebentar dan blender bumbu halus"
- "Panaskan minyak pada wajan, masukan bumbu halus, lengkuas,sereh, dan daun salam kemudian tunggu sampai harum."
- "Selanjutnya masukan ayam dan tambahkan kaldunya"
- "Kemudian tambahkan gula aren dan garam, serta jeruk limau"
- "Jika air sudah menyusut tambahkan daun kemangi"
- "Koreksi rasaa, jika sudah passs masakan siap dihidangkan"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 212 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/a3d9011077bdc376/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Kita

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Kehangatan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah memasak Ayam rica-rica kemangi untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang bisa anda coba salah satunya ayam rica-rica kemangi yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica kemangi:

1. Siapkan 1/2 ekor ayam
1. Tambah  Bumbu halus
1. Jangan lupa 1/2 ruas kunyit
1. Jangan lupa 1 ruas jahe
1. Jangan lupa 1 butir kemiri
1. Dibutuhkan 5 butir bawang merah
1. Siapkan 4 butir bawang putih
1. Harap siapkan 4 buah cabai rawit
1. Harus ada 4 buah cabe merah keriting
1. Harap siapkan  Bahan pelengkap
1. Tambah 1/2 ruas lengkuas (geprek)
1. Harap siapkan secukupnya Gula aren dan garam
1. Harus ada 1 buah sereh (geprek)
1. Diperlukan 1 lembar daun salam
1. Dibutuhkan 2 butir jeruk limau (bisa diganti daun jeruk)
1. Siapkan secukupnya Kemangi daunnya saja


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica-rica kemangi:

1. Bersihkan semua bahan, kemudian rebus ayam sebentar dan blender bumbu halus
1. Panaskan minyak pada wajan, masukan bumbu halus, lengkuas,sereh, dan daun salam kemudian tunggu sampai harum.
1. Selanjutnya masukan ayam dan tambahkan kaldunya
1. Kemudian tambahkan gula aren dan garam, serta jeruk limau
1. Jika air sudah menyusut tambahkan daun kemangi
1. Koreksi rasaa, jika sudah passs masakan siap dihidangkan


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan cepat, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
