---
description: "Resep : Ayam Rica-rica Kemangi Teruji"
title: "Resep : Ayam Rica-rica Kemangi Teruji"
slug: 253-resep-ayam-rica-rica-kemangi-teruji
date: 2020-11-02T12:36:52.728Z
image: https://img-global.cpcdn.com/recipes/e2b437161a4775ba/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e2b437161a4775ba/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e2b437161a4775ba/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Roxie Rowe
ratingvalue: 4.2
reviewcount: 17060
recipeingredient:
- "1 ekor ayam"
- "2 ikat kemangi"
- " Sereh geprek"
- " Lengkuas geprek"
- "secukupnya Ketumbar"
- "secukupnya Gula dan garam"
- "secukupnya Penyedap"
- "2 lembar daun salam"
- "1 bks bumbu ungkep me racik ikan goreng"
- " Bumbu halus"
- "sesuai selera Cabe merah keriting"
- "sesuai selera Cabe rawit setan"
- "1 ruas kunyit"
- "1/2 ruas jahe"
- "3 butir kemiri"
recipeinstructions:
- "Ungkep ayam dengan bumbu ungkep. Lalu goreng sebentar saja sampai kekuningan sedikit. Sisihkan."
- "Tumis bumbu halus, daun salam, sereh dan lengkuas sampai harum. Lalu masukkan ayam, aduk merata."
- "Tambahkan air secukupnya saja sampai ayam terendam. Tambahkan ketumbar bubuk, gula, garam dan penyedap. Koreksi rasa."
- "Masak hingga air menyusut dan mengental, terakhir masukkan kemangi. Angkat dan sajikan."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 128 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/e2b437161a4775ba/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita jaga karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa keistimewahan yang merupakan keragaman Indonesia

Keharmonisan rumah tangga dapat diperoleh dengan cara simple. Diantaranya adalah memasak Ayam Rica-rica Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang bisa anda buat salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 15 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Kemangi:

1. Harap siapkan 1 ekor ayam
1. Tambah 2 ikat kemangi
1. Harus ada  Sereh geprek
1. Diperlukan  Lengkuas geprek
1. Siapkan secukupnya Ketumbar
1. Harap siapkan secukupnya Gula dan garam
1. Dibutuhkan secukupnya Penyedap
1. Tambah 2 lembar daun salam
1. Jangan lupa 1 bks bumbu ungkep (me: racik ikan goreng)
1. Tambah  Bumbu halus:
1. Jangan lupa sesuai selera Cabe merah keriting
1. Tambah sesuai selera Cabe rawit setan
1. Dibutuhkan 1 ruas kunyit
1. Siapkan 1/2 ruas jahe
1. Jangan lupa 3 butir kemiri




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-rica Kemangi:

1. Ungkep ayam dengan bumbu ungkep. Lalu goreng sebentar saja sampai kekuningan sedikit. Sisihkan.
1. Tumis bumbu halus, daun salam, sereh dan lengkuas sampai harum. Lalu masukkan ayam, aduk merata.
1. Tambahkan air secukupnya saja sampai ayam terendam. Tambahkan ketumbar bubuk, gula, garam dan penyedap. Koreksi rasa.
1. Masak hingga air menyusut dan mengental, terakhir masukkan kemangi. Angkat dan sajikan.




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan cepat, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
