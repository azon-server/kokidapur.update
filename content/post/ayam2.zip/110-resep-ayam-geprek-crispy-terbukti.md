---
description: "Resep : Ayam geprek crispy Terbukti"
title: "Resep : Ayam geprek crispy Terbukti"
slug: 110-resep-ayam-geprek-crispy-terbukti
date: 2020-10-20T00:09:29.271Z
image: https://img-global.cpcdn.com/recipes/3a5a9174d5451260/751x532cq70/ayam-geprek-crispy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3a5a9174d5451260/751x532cq70/ayam-geprek-crispy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3a5a9174d5451260/751x532cq70/ayam-geprek-crispy-foto-resep-utama.jpg
author: Olivia Bowen
ratingvalue: 4.7
reviewcount: 34895
recipeingredient:
- " Bahan Utama"
- "1 potong ayam saya pakai dada ayam fillet"
- "1/2 potong jeruk nipis  lemon"
- " Minyak untuk menggoreng"
- " Bahan Marinasi"
- "1 siung bawang putih sedang yang dihaluskan"
- "1/2 sdt saus tiram"
- "Sejumput garam dan lada hitam bubuk"
- " Bahan Tepung"
- "4 sdm Tepung serbaguna"
- "1 sdm Tepung kobe super crispy"
- "1/2 sdt lada hitam bubuk"
- "1/2 sdt paprika bubuk"
- "1/2 sdt bawang putih bubuk"
- "1/4 sdt garam"
- " Bahan Rendaman"
- "1 sdt susu bubuk putih boleh pakai 3 sdm susu putih cair"
- "1/2 gelas air matang kira2 sampai ayam bisa terendam saja"
- " Siapkan Saringan untuk menyaring ayam yang telah direndam"
- " Sambal Geprek"
- "3 siung rawit atau sesuai selera"
- "1 siung bawang putih sedang"
- "2 sdt minyak panas"
- "Secukupnya gula garam penyedap"
recipeinstructions:
- "Cuci bersih ayam... lalu beri perasan Jeruk nipis... diamkan 10 menit (untuk menghilangkan bau amis ayam)"
- "Setelah 10 menit... cuci bersih kembali ayam.... masukan semua bumbu Marinasi... (campurkan bumbu hingga meresap ke dalam daging ayam nya)"
- "Diamkan ayam yang telah di marinasi selama 15 menit"
- "Sambil menunggu Marinasi nya... siapkan bahan tepung nya.. campur semua dan aduk rata"
- "Di wadah lain, campurkan Bahan rendaman nya (jangan lupa siapkan saringan nya juga ya)"
- "Setelah ayam termarinasi rata... siapkan penggorengan (saya pakai panci 😅 biar gag habisin banyak minyak) hehe"
- "Masukan minyak ke dalam penggorengan (kira2 banyaknya sampai bisa merendam ayam) agar matang nya merata"
- "Nyalakan api kecil saja (agar luar nya tidak gosong duluan)"
- "Setelah itu masukan ayam marinasi ke dalam bumbu Tepung tadi... lalu masukan ke dalam rendaman... angkat dengan saringan sampai airnya turun... masukan kembali ke dalam Tepung... lalu rendam lagi (lakukan seperti itu sampai 3x ya)"
- "Setelah yang ke 3 kali nya... campur aduk kembali ayam ke dalam tepung (jangan di tekan ataupun di pencet2) disini kunci nya agar kulit ayam menjadi kriting dan crispy /// aduk2 terus sampai tepung jadi keriting"
- "Cek minyak // kalau sudah panas... masukan pelan2 ayam... goreng sampai matang (jangan bolak balik ayam biarkan matang sebelah dulu.. baru balik ke bagian lain nya)"
- "Kalau sudah matang... angkat dah tiriskan"
- "Siapkan bahan sambal nya... ulek semua bahan,, tes rasa dulu ya... lalu tambahkan minyak panas nya kedalam sambal,,,, setelah itu baru campurkan ayam ke dalam sambal sambil di geprek"
- "Sajikan dengan nasi dan lalapan deh 😋"
- "Selamat Mencoba ya 😉"
categories:
- Recipe
tags:
- ayam
- geprek
- crispy

katakunci: ayam geprek crispy 
nutrition: 130 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam geprek crispy](https://img-global.cpcdn.com/recipes/3a5a9174d5451260/751x532cq70/ayam-geprek-crispy-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan gurih. Karasteristik masakan Indonesia ayam geprek crispy yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan keluarga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Ayam geprek crispy untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang bisa anda praktekkan salah satunya ayam geprek crispy yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam geprek crispy tanpa harus bersusah payah.
Berikut ini resep Ayam geprek crispy yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 24 bahan dan 15 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam geprek crispy:

1. Diperlukan  Bahan Utama
1. Jangan lupa 1 potong ayam (saya pakai dada ayam fillet)
1. Siapkan 1/2 potong jeruk nipis / lemon
1. Diperlukan  Minyak untuk menggoreng
1. Jangan lupa  Bahan Marinasi
1. Jangan lupa 1 siung bawang putih sedang yang dihaluskan
1. Tambah 1/2 sdt saus tiram
1. Harap siapkan Sejumput garam dan lada hitam bubuk
1. Harus ada  Bahan Tepung
1. Dibutuhkan 4 sdm Tepung serbaguna
1. Tambah 1 sdm Tepung kobe super crispy
1. Siapkan 1/2 sdt lada hitam bubuk
1. Harap siapkan 1/2 sdt paprika bubuk
1. Harap siapkan 1/2 sdt bawang putih bubuk
1. Jangan lupa 1/4 sdt garam
1. Dibutuhkan  Bahan Rendaman
1. Jangan lupa 1 sdt susu bubuk putih (boleh pakai 3 sdm susu putih cair)
1. Diperlukan 1/2 gelas air matang (kira2 sampai ayam bisa terendam saja)
1. Diperlukan  Siapkan Saringan untuk menyaring ayam yang telah direndam
1. Dibutuhkan  Sambal Geprek
1. Harus ada 3 siung rawit (atau sesuai selera)
1. Tambah 1 siung bawang putih sedang
1. Harap siapkan 2 sdt minyak panas
1. Harap siapkan Secukupnya gula, garam, penyedap




<!--inarticleads2-->

##### Bagaimana membuat  Ayam geprek crispy:

1. Cuci bersih ayam... lalu beri perasan Jeruk nipis... diamkan 10 menit (untuk menghilangkan bau amis ayam)
1. Setelah 10 menit... cuci bersih kembali ayam.... masukan semua bumbu Marinasi... (campurkan bumbu hingga meresap ke dalam daging ayam nya)
1. Diamkan ayam yang telah di marinasi selama 15 menit
1. Sambil menunggu Marinasi nya... siapkan bahan tepung nya.. campur semua dan aduk rata
1. Di wadah lain, campurkan Bahan rendaman nya (jangan lupa siapkan saringan nya juga ya)
1. Setelah ayam termarinasi rata... siapkan penggorengan (saya pakai panci 😅 biar gag habisin banyak minyak) hehe
1. Masukan minyak ke dalam penggorengan (kira2 banyaknya sampai bisa merendam ayam) agar matang nya merata
1. Nyalakan api kecil saja (agar luar nya tidak gosong duluan)
1. Setelah itu masukan ayam marinasi ke dalam bumbu Tepung tadi... lalu masukan ke dalam rendaman... angkat dengan saringan sampai airnya turun... masukan kembali ke dalam Tepung... lalu rendam lagi (lakukan seperti itu sampai 3x ya)
1. Setelah yang ke 3 kali nya... campur aduk kembali ayam ke dalam tepung (jangan di tekan ataupun di pencet2) disini kunci nya agar kulit ayam menjadi kriting dan crispy /// aduk2 terus sampai tepung jadi keriting
1. Cek minyak // kalau sudah panas... masukan pelan2 ayam... goreng sampai matang (jangan bolak balik ayam biarkan matang sebelah dulu.. baru balik ke bagian lain nya)
1. Kalau sudah matang... angkat dah tiriskan
1. Siapkan bahan sambal nya... ulek semua bahan,, tes rasa dulu ya... lalu tambahkan minyak panas nya kedalam sambal,,,, setelah itu baru campurkan ayam ke dalam sambal sambil di geprek
1. Sajikan dengan nasi dan lalapan deh 😋
1. Selamat Mencoba ya 😉




Demikianlah cara membuat ayam geprek crispy yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan teruji, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
