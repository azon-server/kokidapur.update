---
description: "Resep : Ayam geprek cabe ijo Favorite"
title: "Resep : Ayam geprek cabe ijo Favorite"
slug: 116-resep-ayam-geprek-cabe-ijo-favorite
date: 2021-02-05T04:27:29.420Z
image: https://img-global.cpcdn.com/recipes/1ca48da4761fa8fb/751x532cq70/ayam-geprek-cabe-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1ca48da4761fa8fb/751x532cq70/ayam-geprek-cabe-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1ca48da4761fa8fb/751x532cq70/ayam-geprek-cabe-ijo-foto-resep-utama.jpg
author: Sophia Burke
ratingvalue: 4.5
reviewcount: 43150
recipeingredient:
- "4-5 potong ayam"
- " Bahan rendaman "
- "2 butir bawang putih haluskan saya diparut"
- "1 sdt garam"
- "1/2 sdt lada bubuk"
- "1/2 sdt kaldu bubuk"
- " Bahan pelapis "
- "1 butir telur"
- "5 sdm tepung terigu"
- "1/2 sdt kaldu bubuktambahan dr saya"
- "2 sdm tepung maizena"
- " Bahan sambel "
- "1 gengam cabe rawit ijo"
- "3 buah bawang putih"
- "1/2 sdt gula"
- "1/2 sdt garam"
- "sedikit kaldu bubuk"
recipeinstructions:
- "Cuci bersih ayam, kerat&#34; supaya bumbu meresap kemudian beri bawang putih, garam, lada bubuk &amp; kaldu bubuk. Remas sampai bumbu meresap dan biarkan selama 1-2 jam (masukan kulkas)"
- "Siapkan tepung terigu dan tepung maizena aduk rata (saya tambahkan 1/2sdt kaldu bubuk)"
- "Keluarkan ayam dr kulkas tambahkan telur aduk sampai rata dengan ayam."
- "Celup dan gulingkan ayam dalam tepung sambil dicubit&#34; supaya ayam keriting saat digoreng."
- "Goreng ayam dengan api kecil cenderung sedang supaya bagian dalam ayam matang. Angkat dan tiriskan"
- "Goreng sebentar cabe dan bawang putih lalu uleg kasar dengan cobek tambahkan gula, garam dan kaldu bubuk. Tes rasa."
- "Letakan ayam dalam cobek dan geprek dengan ulekan agar bumbu sambal meresap. Sajikan"
- "Tambahkan parutan keju jadi ayam geprek Bensu loh.. sesuai selera aja ya mau dikasih keju atau tidak😘"
categories:
- Recipe
tags:
- ayam
- geprek
- cabe

katakunci: ayam geprek cabe 
nutrition: 134 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam geprek cabe ijo](https://img-global.cpcdn.com/recipes/1ca48da4761fa8fb/751x532cq70/ayam-geprek-cabe-ijo-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam geprek cabe ijo yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara

Keharmonisan keluarga bisa ditemukan dengan cara simple. Salah satunya adalah membuat makanan Ayam geprek cabe ijo untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang dapat anda praktekkan salah satunya ayam geprek cabe ijo yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep ayam geprek cabe ijo tanpa harus bersusah payah.
Berikut ini resep Ayam geprek cabe ijo yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam geprek cabe ijo:

1. Harus ada 4-5 potong ayam
1. Harus ada  Bahan rendaman :
1. Tambah 2 butir bawang putih haluskan (saya diparut)
1. Diperlukan 1 sdt garam
1. Siapkan 1/2 sdt lada bubuk
1. Harus ada 1/2 sdt kaldu bubuk
1. Diperlukan  Bahan pelapis :
1. Diperlukan 1 butir telur
1. Diperlukan 5 sdm tepung terigu
1. Diperlukan 1/2 sdt kaldu bubuk(tambahan dr saya)
1. Diperlukan 2 sdm tepung maizena
1. Diperlukan  Bahan sambel :
1. Siapkan 1 gengam cabe rawit ijo
1. Dibutuhkan 3 buah bawang putih
1. Dibutuhkan 1/2 sdt gula
1. Harap siapkan 1/2 sdt garam
1. Siapkan sedikit kaldu bubuk




<!--inarticleads2-->

##### Cara membuat  Ayam geprek cabe ijo:

1. Cuci bersih ayam, kerat&#34; supaya bumbu meresap kemudian beri bawang putih, garam, lada bubuk &amp; kaldu bubuk. Remas sampai bumbu meresap dan biarkan selama 1-2 jam (masukan kulkas)
1. Siapkan tepung terigu dan tepung maizena aduk rata (saya tambahkan 1/2sdt kaldu bubuk)
1. Keluarkan ayam dr kulkas tambahkan telur aduk sampai rata dengan ayam.
1. Celup dan gulingkan ayam dalam tepung sambil dicubit&#34; supaya ayam keriting saat digoreng.
1. Goreng ayam dengan api kecil cenderung sedang supaya bagian dalam ayam matang. Angkat dan tiriskan
1. Goreng sebentar cabe dan bawang putih lalu uleg kasar dengan cobek tambahkan gula, garam dan kaldu bubuk. Tes rasa.
1. Letakan ayam dalam cobek dan geprek dengan ulekan agar bumbu sambal meresap. Sajikan
1. Tambahkan parutan keju jadi ayam geprek Bensu loh.. sesuai selera aja ya mau dikasih keju atau tidak😘




Demikianlah cara membuat ayam geprek cabe ijo yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
