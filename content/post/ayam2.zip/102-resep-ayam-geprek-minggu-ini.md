---
description: "Resep : Ayam Geprek minggu ini"
title: "Resep : Ayam Geprek minggu ini"
slug: 102-resep-ayam-geprek-minggu-ini
date: 2021-01-18T13:20:18.951Z
image: https://img-global.cpcdn.com/recipes/0c0300e6edf0aed6/751x532cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0c0300e6edf0aed6/751x532cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0c0300e6edf0aed6/751x532cq70/ayam-geprek-foto-resep-utama.jpg
author: Eleanor Nash
ratingvalue: 4
reviewcount: 2587
recipeingredient:
- "5 potong ayam saya pakai bagian sayap"
- "1 butir telur"
- "  Bumbu Marinasi dihaluskan "
- "3 siung bawang putih atau 1 sdt bawang putih bubuk"
- "1 sdt merica butiran 1 sdt merica bubuk"
- "1 sdm kaldu bubuk"
- "  Bahan tepung  pelapis "
- "8 sdm munjung tepung terigu bebas apa saja"
- "4 sdm munjung tepung maizena"
- "1 1/2 sdt kaldu bubuk"
- "1 sdt garam sesukupnya"
- "1 sdt merica bubuk"
- "  Secukupnya minyak untuk menggoreng ayam"
- "  Bahan Sambal Geprek ulek kasar "
- "20 buah rawit merah besar saya cuma ada 5 buahselera aja"
- "5 cabe merah keriting saya pakai 10 buah"
- "4 siung bawang putih goreng"
- "1 1/2 sdt garam secukupnya"
- "1/2 sdt gula pasir secukupnya"
- "Secukupnya minyak panas untuk menyiram sambal"
recipeinstructions:
- "Cuci bersih ayam, lumuri dg air jeruk nipis, diamkan 10 mnt. Cuci lagi sampai bersih. Kemudian lumuri ayam dengan bumbu marinasi. Tusuk² ayam dengan garpu agar bumbu meresap. Aduk rata dengan bumbu sampai ayam terlumuri. Diamkan di kulkas minimal 2 jam. Setelah 2 jam keluarkan ayam, masukkan telur, aduk rata sampai ayam terlumuri telur. Sisihkan."
- "Siapkan bumbu tepung / pelapis. Campurkan tepung terigu, maizena dan bumbu² nya. Aduk rata. Cicipi dan koreksi rasa. Kalau dirasa garam nya kurang bisa ditambahkan. Gulingkan ayam ke dalam tepung. Tekan² sambil dicubit² agar tepung tebal. Lakukan sampai selesai."
- "Saya 2x pelapisan. Karena bahan basah/telur msh ada, jd setelah di gulingkan ke tepung, saya masukan lagi ke dalam telur, lalu gulingkan lagi ke tepung."
- "Siapkan wajan untuk menggoreng. Panaskan minyak. Pastikan ayam nanti tertutup minyak saat digoreng, agar matang merata. Masukkan ayam ke dalam minyak yang sudah panas. Goreng dengan api kecil saja yaa, agar matang merata sampai ke bagian dalam daging. Karena ini tidak diungkeb dulu. Jadi harus betul² matang saat digoreng. Balik ayam setelah satu sisi kering dengan warna kecoklatan. Goreng sampai ayam kering dan matang sempurna. Angkat dan tiriskan."
- "Siapkan bahan sambal. Goreng bawang putih. Ulek semua bahan (saya uleknya agak kasar saja), setelah itu siram dengan 3 sdm/secukupnya minyak panas bekas menggoreng ayam. Lalu geprek ayam bersama dengan sambalnya."
- "Ayam Geprek siap dihidangkan 🤩. Sajikan dengan nasi panas....yummi 🤤. Matang sampai daging paling dalam 😍."
- "Selamat mencobaa 🤗🥰"
categories:
- Recipe
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 224 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/0c0300e6edf0aed6/751x532cq70/ayam-geprek-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan renyah. Ciri makanan Nusantara ayam geprek yang penuh dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga dapat didapat dengan cara simple. Salah satunya adalah memasak Ayam Geprek untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang bisa anda buat salah satunya ayam geprek yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam geprek tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 20 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek:

1. Harus ada 5 potong ayam (saya pakai bagian sayap)
1. Diperlukan 1 butir telur
1. Diperlukan  ✓ Bumbu Marinasi (dihaluskan) :
1. Siapkan 3 siung bawang putih (atau 1 sdt bawang putih bubuk)
1. Harap siapkan 1 sdt merica butiran (1 sdt merica bubuk)
1. Dibutuhkan 1 sdm kaldu bubuk
1. Jangan lupa  ✓ Bahan tepung / pelapis :
1. Harus ada 8 sdm munjung tepung terigu (bebas apa saja)
1. Jangan lupa 4 sdm munjung tepung maizena
1. Siapkan 1 1/2 sdt kaldu bubuk
1. Harus ada 1 sdt garam (sesukupnya)
1. Tambah 1 sdt merica bubuk
1. Jangan lupa  ✓ Secukupnya minyak untuk menggoreng ayam
1. Tambah  ✓ Bahan Sambal Geprek (ulek kasar) :
1. Harap siapkan 20 buah rawit merah besar (saya cuma ada 5 buah)/selera aja
1. Tambah 5 cabe merah keriting (saya pakai 10 buah)
1. Siapkan 4 siung bawang putih, goreng
1. Diperlukan 1 1/2 sdt garam (secukupnya)
1. Tambah 1/2 sdt gula pasir (secukupnya)
1. Harus ada Secukupnya minyak panas untuk menyiram sambal




<!--inarticleads2-->

##### Instruksi membuat  Ayam Geprek:

1. Cuci bersih ayam, lumuri dg air jeruk nipis, diamkan 10 mnt. Cuci lagi sampai bersih. Kemudian lumuri ayam dengan bumbu marinasi. Tusuk² ayam dengan garpu agar bumbu meresap. Aduk rata dengan bumbu sampai ayam terlumuri. Diamkan di kulkas minimal 2 jam. Setelah 2 jam keluarkan ayam, masukkan telur, aduk rata sampai ayam terlumuri telur. Sisihkan.
1. Siapkan bumbu tepung / pelapis. Campurkan tepung terigu, maizena dan bumbu² nya. Aduk rata. Cicipi dan koreksi rasa. Kalau dirasa garam nya kurang bisa ditambahkan. Gulingkan ayam ke dalam tepung. Tekan² sambil dicubit² agar tepung tebal. Lakukan sampai selesai.
1. Saya 2x pelapisan. Karena bahan basah/telur msh ada, jd setelah di gulingkan ke tepung, saya masukan lagi ke dalam telur, lalu gulingkan lagi ke tepung.
1. Siapkan wajan untuk menggoreng. Panaskan minyak. Pastikan ayam nanti tertutup minyak saat digoreng, agar matang merata. Masukkan ayam ke dalam minyak yang sudah panas. Goreng dengan api kecil saja yaa, agar matang merata sampai ke bagian dalam daging. Karena ini tidak diungkeb dulu. Jadi harus betul² matang saat digoreng. Balik ayam setelah satu sisi kering dengan warna kecoklatan. Goreng sampai ayam kering dan matang sempurna. Angkat dan tiriskan.
1. Siapkan bahan sambal. Goreng bawang putih. Ulek semua bahan (saya uleknya agak kasar saja), setelah itu siram dengan 3 sdm/secukupnya minyak panas bekas menggoreng ayam. Lalu geprek ayam bersama dengan sambalnya.
1. Ayam Geprek siap dihidangkan 🤩. Sajikan dengan nasi panas....yummi 🤤. Matang sampai daging paling dalam 😍.
1. Selamat mencobaa 🤗🥰




Demikianlah cara membuat ayam geprek yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
