---
description: "Cara untuk menyiapakan Ayam geprek mercon Teruji"
title: "Cara untuk menyiapakan Ayam geprek mercon Teruji"
slug: 104-cara-untuk-menyiapakan-ayam-geprek-mercon-teruji
date: 2020-11-30T18:54:43.138Z
image: https://img-global.cpcdn.com/recipes/cb4c7f960063c9bb/751x532cq70/ayam-geprek-mercon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cb4c7f960063c9bb/751x532cq70/ayam-geprek-mercon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cb4c7f960063c9bb/751x532cq70/ayam-geprek-mercon-foto-resep-utama.jpg
author: Eula Lee
ratingvalue: 4.2
reviewcount: 6053
recipeingredient:
- "1/2 ekor ayampotong 6"
- "1/2 kg terigu"
- "1 SDM sagu"
- "1/2 sdt lada bubuk"
- "1/4 sdt ketumbar bubuk"
- "2 bungkus Masako ayam"
- "secukupnya Garam"
- "1/2 mangkuk Air"
- "3 siung bawang putih"
- "1 lt Minyak goreng"
- " Sambel bawang cabe rawit merah 11buah2 siung bawang putihgaramsasa"
recipeinstructions:
- "Potong ayam jadi 6 bagian lalu taburi bawang putih yg sdh dihaluskan dan garam,diamkan selama 30 menit"
- "Setelah siapkan terigu dalam wadah beri taburan Masako,lada bubuk dan ketumbar bubuk,klo dirasa krg gurih bisa ditambahkan garam lg,aduk rata"
- "Siapkan mangkuk beri air setengah lalu beri sagu larutkan,Kemudian panaskan minyak setelah itu gulingkan ayam yg sdh dibumbui ke dalam terigu, angkat kemudian celupkan ke air sagu lalu gulingkan sambil di aduk2,ulangi sampai 3x agar keriting lalu goreng hingga kuning kecoklatan"
- "Siapkan sambel bawang lalu beri sedikit minyak bekas goreng lalu geprek dan siap disajikan,,,slamat mencoba"
categories:
- Recipe
tags:
- ayam
- geprek
- mercon

katakunci: ayam geprek mercon 
nutrition: 239 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam geprek mercon](https://img-global.cpcdn.com/recipes/cb4c7f960063c9bb/751x532cq70/ayam-geprek-mercon-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau gurih. Ciri khas makanan Nusantara ayam geprek mercon yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Ayam geprek is an Indonesian crispy battered fried chicken crushed and mixed with hot and spicy sambal. Currently ayam geprek is commonly found in Indonesia and neighbouring countries, however its origin was from Yogyakarta in Java. Awalnya pengen bikin ayam goreng, berhubung banyak yang reques masakan ayam geprek akhirnya saya nyoba bi. Sebut saja misalnya ayam geprek, iga penyet, mie setan dan bakso mercon.

Keharmonisan rumah tangga bisa didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam geprek mercon untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang bisa anda buat salah satunya ayam geprek mercon yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam geprek mercon tanpa harus bersusah payah.
Seperti resep Ayam geprek mercon yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam geprek mercon:

1. Harus ada 1/2 ekor ayam(potong 6)
1. Harus ada 1/2 kg terigu
1. Harus ada 1 SDM sagu
1. Diperlukan 1/2 sdt lada bubuk
1. Harap siapkan 1/4 sdt ketumbar bubuk
1. Dibutuhkan 2 bungkus Masako ayam
1. Harap siapkan secukupnya Garam
1. Siapkan 1/2 mangkuk Air
1. Tambah 3 siung bawang putih
1. Harus ada 1 lt Minyak goreng
1. Dibutuhkan  Sambel bawang: cabe rawit merah 11buah,2 siung bawang putih,garam&amp;sasa


Ayam geprek (Hanacaraka:ꦄꦪꦩ꧀ ꦒꦼꦥꦽꦏ꧀) adalah makanan ayam goreng tepung khas Indonesia yang diulek atau dilumatkan bersama sambal bajak. Kini ayam geprek telah menjadi hidangan populer yang dapat ditemukan di hampir semua kota besar di Indonesia. Satu tampilan Ayam Geprek Keprabon yang telah diolah. Ayam Keprabon saat ini menggelar kompetisi geprek keprabon dengan hadiah emas batangan dan hadiah menarik lainnya. 

<!--inarticleads2-->

##### Instruksi membuat  Ayam geprek mercon:

1. Potong ayam jadi 6 bagian lalu taburi bawang putih yg sdh dihaluskan dan garam,diamkan selama 30 menit
1. Setelah siapkan terigu dalam wadah beri taburan Masako,lada bubuk dan ketumbar bubuk,klo dirasa krg gurih bisa ditambahkan garam lg,aduk rata
1. Siapkan mangkuk beri air setengah lalu beri sagu larutkan,Kemudian panaskan minyak setelah itu gulingkan ayam yg sdh dibumbui ke dalam terigu, angkat kemudian celupkan ke air sagu lalu gulingkan sambil di aduk2,ulangi sampai 3x agar keriting lalu goreng hingga kuning kecoklatan
1. Siapkan sambel bawang lalu beri sedikit minyak bekas goreng lalu geprek dan siap disajikan,,,slamat mencoba


Satu tampilan Ayam Geprek Keprabon yang telah diolah. Ayam Keprabon saat ini menggelar kompetisi geprek keprabon dengan hadiah emas batangan dan hadiah menarik lainnya. Ayam Geprek Istimewa menyadari, kelezatan, kesegaran dan kualitas menu yang disajikan adalah Kabar gembira nih buat para penggemar sambal kemasan. Dapur Ayam Geprek Istimewa baru saja. Get quick answers from Rumah Makan Betawi (Ayam Mercon) staff and past visitors. 

Demikianlah cara membuat ayam geprek mercon yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
