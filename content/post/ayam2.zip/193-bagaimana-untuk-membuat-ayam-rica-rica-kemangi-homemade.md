---
description: "Bagaimana untuk membuat Ayam rica rica kemangi Homemade"
title: "Bagaimana untuk membuat Ayam rica rica kemangi Homemade"
slug: 193-bagaimana-untuk-membuat-ayam-rica-rica-kemangi-homemade
date: 2020-11-09T00:14:54.409Z
image: https://img-global.cpcdn.com/recipes/31b25ff97e88ea6d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/31b25ff97e88ea6d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/31b25ff97e88ea6d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Caleb McCormick
ratingvalue: 4.1
reviewcount: 37110
recipeingredient:
- "1 ekor ayam"
- " Bumbu halus"
- "15 cabai rawit merah"
- "10 cabai merah keriting"
- "10 siung bawang merah"
- "6 siung bawang putih"
- "4 butir kemiri"
- "2 cm jahe"
- "2 cm kunyit"
- "5 lembar daun jeruk"
- "4 lembar daun salam"
- "3 ikat kemangi"
- "2 serai memarkan"
recipeinstructions:
- "Potong daging ayam sesuai selera beri garam dan perasan jeruk nipis lalu cuci bersih"
- "Goreng ayam sampai berwarna kecokelatan 1/2 matang jangan sampai kering"
- "Tumis bumbu halus masukkan serai, daun jeruk,dan daun salam aduk2 sampai tercium harum lalu masukkan ayam aduk rata beri garam, gula dan penyedap dan beri air secukupnya"
- ""
- "Tunggu sampai mendidih dengan api sedang masak sampai ayam empuk, koreksi rasa Lalu masukkn daun kemangi"
- "Ayam rica rica kemangi siap dihidangkan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 275 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT58M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/31b25ff97e88ea6d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica rica kemangi yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa ciri khas yang merupakan keragaman Kita

Keharmonisan keluarga dapat didapat dengan cara simple. Diantaranya adalah memasak Ayam rica rica kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda buat salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Harap siapkan 1 ekor ayam
1. Jangan lupa  Bumbu halus
1. Harus ada 15 cabai rawit merah
1. Jangan lupa 10 cabai merah keriting
1. Tambah 10 siung bawang merah
1. Dibutuhkan 6 siung bawang putih
1. Dibutuhkan 4 butir kemiri
1. Harap siapkan 2 cm jahe
1. Jangan lupa 2 cm kunyit
1. Jangan lupa 5 lembar daun jeruk
1. Harap siapkan 4 lembar daun salam
1. Jangan lupa 3 ikat kemangi
1. Tambah 2 serai memarkan




<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica kemangi:

1. Potong daging ayam sesuai selera beri garam dan perasan jeruk nipis lalu cuci bersih
1. Goreng ayam sampai berwarna kecokelatan - 1/2 matang jangan sampai kering
1. Tumis bumbu halus masukkan serai, daun jeruk,dan daun salam aduk2 sampai tercium harum lalu masukkan ayam aduk rata beri garam, gula dan penyedap dan beri air secukupnya
1. 
1. Tunggu sampai mendidih dengan api sedang masak sampai ayam empuk, koreksi rasa - Lalu masukkn daun kemangi
1. Ayam rica rica kemangi siap dihidangkan




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat simple dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
