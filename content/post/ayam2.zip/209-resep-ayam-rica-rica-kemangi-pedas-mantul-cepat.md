---
description: "Resep : Ayam Rica - Rica Kemangi Pedas Mantul Cepat"
title: "Resep : Ayam Rica - Rica Kemangi Pedas Mantul Cepat"
slug: 209-resep-ayam-rica-rica-kemangi-pedas-mantul-cepat
date: 2021-02-05T03:32:46.288Z
image: https://img-global.cpcdn.com/recipes/d15711c86b6dfa3f/751x532cq70/ayam-rica-rica-kemangi-pedas-mantul-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d15711c86b6dfa3f/751x532cq70/ayam-rica-rica-kemangi-pedas-mantul-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d15711c86b6dfa3f/751x532cq70/ayam-rica-rica-kemangi-pedas-mantul-foto-resep-utama.jpg
author: Leon Richards
ratingvalue: 4.6
reviewcount: 13721
recipeingredient:
- "1/2 kg Ayam potong dada dan sayap sesuai selera"
- "1/2 potong jeruk limau"
- " Bumbu Halus"
- "3 buah bawang putih"
- "4 buah bawang merah"
- "5 buah cabe merah besar"
- "10 cabe rawit sesuai selera"
- "1/2 cm Jahe"
- "Sedikit kunyit"
- "3 buah kemiri"
- " Bahan cemplung"
- "secukupnya Garam"
- "secukupnya Gula"
- " Merica secukupny"
- " penyedap rasa"
- "4 lembar daun jeruk"
- "2 daun sereh geprek"
- "1/2 ruas lengkuas"
- "2 lembar daun salam"
- "4 buah cabe hijau boleh skip"
- "1 ikat daun kemangi"
- "1 buah daun bawang"
- " Air matang"
recipeinstructions:
- "Cuci bersih ayam, kemudian lumuri ayam dgn jeruk limau, beri penyedap rasa, garam, ketumbar (bubuk) dan merica (bubuk) untuk marinasi yang simpel. Diamkan dikulkas 5-10 menit. Kemudian goreng setengah matang."
- "Potong- potong bumbu halus untuk di blender/diulek sesuai selera. Kemudian tambahkan minyak, tumis bumbu hingga wangi, masukkan bumbu cemplung tadi aduk rata."
- "Kemudian masukkan ayam potong, aduk sebentar, tambahkan air secukupnya. Setelah itu tambahkan garam, gula, penyedap rasa, dan merica."
- "Tutup sebentar biarkan meresap. Masukkan daun bawang, cabe hijau, cabe rawit utuh dan kemangi aduk rata, kemudian biarkan hingga meresap dan matang."
- "Koreksi rasa, siapkan mangkok ukuran sedang kemudian sajikan 😍. siap untuk dinikmati"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 109 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica - Rica Kemangi Pedas Mantul](https://img-global.cpcdn.com/recipes/d15711c86b6dfa3f/751x532cq70/ayam-rica-rica-kemangi-pedas-mantul-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica - rica kemangi pedas mantul yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan ciri khas yang merupakan keragaman Indonesia



Kehangatan keluarga dapat didapat dengan cara simple. Diantaranya adalah memasak Ayam Rica - Rica Kemangi Pedas Mantul untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang bisa anda coba salah satunya ayam rica - rica kemangi pedas mantul yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica - rica kemangi pedas mantul tanpa harus bersusah payah.
Berikut ini resep Ayam Rica - Rica Kemangi Pedas Mantul yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 23 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica - Rica Kemangi Pedas Mantul:

1. Siapkan 1/2 kg Ayam potong (dada dan sayap) sesuai selera
1. Harap siapkan 1/2 potong jeruk limau
1. Harap siapkan  Bumbu Halus
1. Diperlukan 3 buah bawang putih
1. Tambah 4 buah bawang merah
1. Jangan lupa 5 buah cabe merah besar
1. Jangan lupa 10 cabe rawit (sesuai selera)
1. Harus ada 1/2 cm Jahe
1. Harus ada Sedikit kunyit
1. Diperlukan 3 buah kemiri
1. Jangan lupa  Bahan cemplung
1. Diperlukan secukupnya Garam
1. Harus ada secukupnya Gula
1. Jangan lupa  Merica secukupny
1. Harus ada  penyedap rasa
1. Harap siapkan 4 lembar daun jeruk
1. Tambah 2 daun sereh geprek
1. Siapkan 1/2 ruas lengkuas
1. Harus ada 2 lembar daun salam
1. Tambah 4 buah cabe hijau (boleh skip)
1. Harus ada 1 ikat daun kemangi
1. Harus ada 1 buah daun bawang
1. Dibutuhkan  Air matang




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica - Rica Kemangi Pedas Mantul:

1. Cuci bersih ayam, kemudian lumuri ayam dgn jeruk limau, beri penyedap rasa, garam, ketumbar (bubuk) dan merica (bubuk) untuk marinasi yang simpel. Diamkan dikulkas 5-10 menit. Kemudian goreng setengah matang.
1. Potong- potong bumbu halus untuk di blender/diulek sesuai selera. Kemudian tambahkan minyak, tumis bumbu hingga wangi, masukkan bumbu cemplung tadi aduk rata.
1. Kemudian masukkan ayam potong, aduk sebentar, tambahkan air secukupnya. Setelah itu tambahkan garam, gula, penyedap rasa, dan merica.
1. Tutup sebentar biarkan meresap. Masukkan daun bawang, cabe hijau, cabe rawit utuh dan kemangi aduk rata, kemudian biarkan hingga meresap dan matang.
1. Koreksi rasa, siapkan mangkok ukuran sedang kemudian sajikan 😍. siap untuk dinikmati




Demikianlah cara membuat ayam rica - rica kemangi pedas mantul yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan teruji, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
