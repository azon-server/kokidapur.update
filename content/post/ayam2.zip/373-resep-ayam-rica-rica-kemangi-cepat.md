---
description: "Resep : Ayam Rica Rica Kemangi Cepat"
title: "Resep : Ayam Rica Rica Kemangi Cepat"
slug: 373-resep-ayam-rica-rica-kemangi-cepat
date: 2020-10-15T08:20:59.798Z
image: https://img-global.cpcdn.com/recipes/98d25ba9aace2263/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/98d25ba9aace2263/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/98d25ba9aace2263/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Tony Carter
ratingvalue: 4.4
reviewcount: 2970
recipeingredient:
- "1/2 Ekor Ayam"
- " Kemangi"
- "1 ruas Lengkuas di geprek"
- "1 batang Sereh di geprek"
- "2 lembar Daun salam"
- "4 lembar Daun Jeruk"
- "6 buah Cengkeh"
- "2 ruas Kayu Manis"
- "3 gelas Air"
- " Bumbu halus"
- "7 siung Bawang Merah"
- "4 siung Bawang Putih"
- "2 butir Kemiri"
- "1 ruas Jahe"
- "1 ruas Kunyit"
- "sesuai selera Lada"
- "sesuai selera Cabai rawit"
- " bahan tambahan"
- " Gula putih"
- " Garam"
- " Penyedap rasa"
recipeinstructions:
- "Bersih kan ayam"
- "Panaskan Minyak Tumis bumbu yg di haluskan, masukan Lengkuas, Salam, Sereh, Daun jeruk"
- "Jika sudah harum tambahkan air, Masukan Ayam, Cengkeh, Kayu Manis"
- "Masukan Garam, Gula, Peyedap rasa, cek rasa"
- "Tunggu sampai air kalis agar kuah agak mengental, cek rasa kembali"
- "Jika sudah agak mengental matikan Api, siap untuk disajikan dan di nikmati"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 124 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/98d25ba9aace2263/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga renyah. Ciri masakan Nusantara ayam rica rica kemangi yang kaya dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah memasak Ayam Rica Rica Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis makanan yang dapat anda contoh salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Dibutuhkan 1/2 Ekor Ayam
1. Harap siapkan  Kemangi
1. Jangan lupa 1 ruas Lengkuas di geprek
1. Dibutuhkan 1 batang Sereh di geprek
1. Jangan lupa 2 lembar Daun salam
1. Jangan lupa 4 lembar Daun Jeruk
1. Diperlukan 6 buah Cengkeh
1. Siapkan 2 ruas Kayu Manis
1. Tambah 3 gelas Air
1. Harap siapkan  Bumbu halus
1. Diperlukan 7 siung Bawang Merah
1. Tambah 4 siung Bawang Putih
1. Jangan lupa 2 butir Kemiri
1. Diperlukan 1 ruas Jahe
1. Tambah 1 ruas Kunyit
1. Harus ada sesuai selera Lada
1. Harap siapkan sesuai selera Cabai rawit
1. Siapkan  bahan tambahan
1. Harus ada  Gula putih
1. Dibutuhkan  Garam
1. Jangan lupa  Penyedap rasa




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica Kemangi:

1. Bersih kan ayam
1. Panaskan Minyak Tumis bumbu yg di haluskan, masukan Lengkuas, Salam, Sereh, Daun jeruk
1. Jika sudah harum tambahkan air, Masukan Ayam, Cengkeh, Kayu Manis
1. Masukan Garam, Gula, Peyedap rasa, cek rasa
1. Tunggu sampai air kalis agar kuah agak mengental, cek rasa kembali
1. Jika sudah agak mengental matikan Api, siap untuk disajikan dan di nikmati




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan terbukti, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
