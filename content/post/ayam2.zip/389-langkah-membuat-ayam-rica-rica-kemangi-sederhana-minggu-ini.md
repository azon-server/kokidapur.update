---
description: "Langkah membuat Ayam Rica-Rica Kemangi Sederhana minggu ini"
title: "Langkah membuat Ayam Rica-Rica Kemangi Sederhana minggu ini"
slug: 389-langkah-membuat-ayam-rica-rica-kemangi-sederhana-minggu-ini
date: 2021-01-01T03:51:35.891Z
image: https://img-global.cpcdn.com/recipes/c98f6f4d2de3d55d/751x532cq70/ayam-rica-rica-kemangi-sederhana-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c98f6f4d2de3d55d/751x532cq70/ayam-rica-rica-kemangi-sederhana-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c98f6f4d2de3d55d/751x532cq70/ayam-rica-rica-kemangi-sederhana-foto-resep-utama.jpg
author: Marvin Richards
ratingvalue: 4.3
reviewcount: 22656
recipeingredient:
- "1/2 kg sayap ayam potong2"
- "1/4 siung bawamg bombay"
- "1 batang sereh"
- "1 lembar daun jeruk"
- "1 lembar daun salam"
- "1 ruas lengkuas geprek"
- "1 ikat daun kemangi ambil daunnya saja"
- "Secukupnya garam dan merica"
- "1 sdt gula merah"
- " Bumbu Halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "5 buah cabe merah keriting"
- "3 buah rawit gendut atau sesuai selera jika ingin lebih pedas"
- "2 butir kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
- "Secukupnya garam"
recipeinstructions:
- "Rebus ayam sampai setengah matang. Tambahkn sedikit garam dan merica. Angkat sisihkan."
- "Tumis bawang bombay. Masukkan bumbu halus. Aduk. Masukkan daun salam, daun jeruk, sereh dan lengkuas, masak sampai harum. Tambahkan sedikit air."
- "Masukkan ayam. Aduk sampai ayam terlumuri bumbu. Tambahkn secukupnya air, sampai menggenangi ayam. Masukkan garam merica dan gula merah. Aduk. Koreksi rasa. Msak sampai air sedikit menyusut"
- "Angkat, sajikan dengan nasi hangat."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 245 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica-Rica Kemangi Sederhana](https://img-global.cpcdn.com/recipes/c98f6f4d2de3d55d/751x532cq70/ayam-rica-rica-kemangi-sederhana-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica-rica kemangi sederhana yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa keistimewahan yang merupakan keragaman Nusantara

Kedekatan keluarga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica-Rica Kemangi Sederhana untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang dapat anda buat salah satunya ayam rica-rica kemangi sederhana yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep ayam rica-rica kemangi sederhana tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Kemangi Sederhana yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Kemangi Sederhana:

1. Dibutuhkan 1/2 kg sayap ayam, potong2
1. Tambah 1/4 siung bawamg bombay
1. Dibutuhkan 1 batang sereh
1. Harus ada 1 lembar daun jeruk
1. Siapkan 1 lembar daun salam
1. Siapkan 1 ruas lengkuas geprek
1. Harus ada 1 ikat daun kemangi, ambil daunnya saja
1. Harus ada Secukupnya garam dan merica
1. Harus ada 1 sdt gula merah
1. Diperlukan  Bumbu Halus
1. Diperlukan 5 siung bawang merah
1. Tambah 3 siung bawang putih
1. Siapkan 5 buah cabe merah keriting
1. Dibutuhkan 3 buah rawit gendut, atau sesuai selera jika ingin lebih pedas
1. Jangan lupa 2 butir kemiri
1. Jangan lupa 1 ruas jahe
1. Tambah 1 ruas kunyit
1. Jangan lupa Secukupnya garam




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-Rica Kemangi Sederhana:

1. Rebus ayam sampai setengah matang. Tambahkn sedikit garam dan merica. Angkat sisihkan.
1. Tumis bawang bombay. Masukkan bumbu halus. Aduk. Masukkan daun salam, daun jeruk, sereh dan lengkuas, masak sampai harum. Tambahkan sedikit air.
1. Masukkan ayam. Aduk sampai ayam terlumuri bumbu. Tambahkn secukupnya air, sampai menggenangi ayam. Masukkan garam merica dan gula merah. Aduk. Koreksi rasa. Msak sampai air sedikit menyusut
1. Angkat, sajikan dengan nasi hangat.




Demikianlah cara membuat ayam rica-rica kemangi sederhana yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
