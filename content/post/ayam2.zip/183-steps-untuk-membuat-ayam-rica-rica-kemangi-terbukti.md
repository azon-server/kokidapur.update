---
description: "Steps untuk membuat Ayam rica-rica kemangi Terbukti"
title: "Steps untuk membuat Ayam rica-rica kemangi Terbukti"
slug: 183-steps-untuk-membuat-ayam-rica-rica-kemangi-terbukti
date: 2020-10-25T15:56:19.152Z
image: https://img-global.cpcdn.com/recipes/d522c05c2df88ae9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d522c05c2df88ae9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d522c05c2df88ae9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Phoebe Harvey
ratingvalue: 4.9
reviewcount: 9271
recipeingredient:
- "1,5 kg ayam potong"
- "1 buah tomat"
- " Bumbu halus "
- "4 buah Bawang putih"
- "6 buah Bawang merah"
- "1 buah Kemiri"
- "secukupnya Gula Jawa"
- "secukupnya Ketumbar"
- "secukupnya Cabe merah"
- "secukupnya Cabe rawit"
- " Garam"
- " Merica bubuk"
- " Laos"
- " Daun salam"
- " Serai"
- " Kecap manis"
- " Daun kemangi"
recipeinstructions:
- "Cuci bersih ayam &amp; rebus dalam air mendidih"
- "Uleg bumbu halus kecuali Laos, serai, daun salam"
- "Panaskan sedikit minyak, kemudian tumis bumbu halus hingga berbau harum"
- "Setelah berbau harum tambahkan sedikit air agar bumbu tdk gosong, sambil cek rasa. Masukkan Laos, daun salam dan serai."
- "Setelah itu, masukkan ayam yg sudah direbus tadi ke dalam tumisan bumbu"
- "Tambahkan sedikit kecap manis sambil cek rasa kembali"
- "Setelah rasa pas, masukkan daun kemangi"
- "Setelah daun kemangi masuk, lgsg matikan api kompor agar kemangi tdk terlalu matang"
- "Rica ayam kemangi sudah siap dihidangkan"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 270 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/d522c05c2df88ae9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas dan gurih. Karasteristik kuliner Nusantara ayam rica-rica kemangi yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga bisa ditemukan dengan cara simple. Salah satunya adalah membuat makanan Ayam rica-rica kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang dapat anda buat salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica kemangi:

1. Dibutuhkan 1,5 kg ayam potong
1. Jangan lupa 1 buah tomat
1. Siapkan  Bumbu halus :
1. Dibutuhkan 4 buah Bawang putih
1. Harus ada 6 buah Bawang merah
1. Harap siapkan 1 buah Kemiri
1. Siapkan secukupnya Gula Jawa
1. Harap siapkan secukupnya Ketumbar
1. Jangan lupa secukupnya Cabe merah
1. Dibutuhkan secukupnya Cabe rawit
1. Harus ada  Garam
1. Dibutuhkan  Merica bubuk
1. Jangan lupa  Laos
1. Harap siapkan  Daun salam
1. Diperlukan  Serai
1. Siapkan  Kecap manis
1. Dibutuhkan  Daun kemangi




<!--inarticleads2-->

##### Langkah membuat  Ayam rica-rica kemangi:

1. Cuci bersih ayam &amp; rebus dalam air mendidih
1. Uleg bumbu halus kecuali Laos, serai, daun salam
1. Panaskan sedikit minyak, kemudian tumis bumbu halus hingga berbau harum
1. Setelah berbau harum tambahkan sedikit air agar bumbu tdk gosong, sambil cek rasa. Masukkan Laos, daun salam dan serai.
1. Setelah itu, masukkan ayam yg sudah direbus tadi ke dalam tumisan bumbu
1. Tambahkan sedikit kecap manis sambil cek rasa kembali
1. Setelah rasa pas, masukkan daun kemangi
1. Setelah daun kemangi masuk, lgsg matikan api kompor agar kemangi tdk terlalu matang
1. Rica ayam kemangi sudah siap dihidangkan




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat gampang dan cepat, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
