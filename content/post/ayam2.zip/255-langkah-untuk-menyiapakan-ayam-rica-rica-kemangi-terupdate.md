---
description: "Langkah untuk menyiapakan Ayam Rica-Rica Kemangi terupdate"
title: "Langkah untuk menyiapakan Ayam Rica-Rica Kemangi terupdate"
slug: 255-langkah-untuk-menyiapakan-ayam-rica-rica-kemangi-terupdate
date: 2020-11-28T12:17:37.792Z
image: https://img-global.cpcdn.com/recipes/a1324209851ef185/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a1324209851ef185/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a1324209851ef185/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Andre Zimmerman
ratingvalue: 4.4
reviewcount: 21092
recipeingredient:
- "500 gr sayap ayam"
- "500 ml air"
- " Bumbu Marinasi"
- "1 sdt garamhimsalt"
- "1 sdt bawang putih bubuk"
- "1 sdt ketumbar bubuk"
- "1 sdt lada bubuk"
- "1 sdt kunyit bubuk"
- " Bumbu Halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "1,5 butir kemiri disangrai dulu"
- "1 ruas jahe"
- "5 buah cabe merah sesuai selera"
- "5 buah cabe rawit sesuai selera"
- " Bahan Tumis"
- "2 lembar daun salam"
- "3 lembar daun jeruk 2 diiris tipis 1 disobek"
- "1 batang serai potong lalu geprek"
- "1 ruas lengkuas iris atau geprek"
- " Bahan Pelengkap"
- "2 ikat daun kemangi"
- "1 batang daun bawang iris serong"
- "Secukupnya garam gula dan penyedap rasa optional"
recipeinstructions:
- "Awali dengan membaca &#34;Bismillahirrahmannirrahiim&#34; terlebih dahulu. 😊"
- "Cuci bersih ayam, lumuri dengan bumbu marinasi kemudian diamkan di kulkas selama ± 30 menit. Setelah itu goreng setengah matang dan sisihkan."
- "Blender bumbu halus kemudian tumis dengan sedikit minyak. Tambahkan bahan tumis: serai, lengkuas, daun salam, daun jeruk. Tumis sampai matang dan minyak menyusut."
- "Tambahkan air, garam, gula, penyedap rasa. Aduk rata dan koreksi rasa."
- "Masukkan ayam yang sudah digoreng, masak hingga air menyusut dan bumbu meresap ke dalam ayam. Proses ini membutuhkan waktu yg agak lama. Bisa disambi nyuci peralatan masak yang kotor ya buibu hehe."
- "Terakhir, masukkan daun bawang dan daun kemangi. Aduk hingga tercampur rata. Jangan terlalu lama dimasak lalu matikan api."
- "Siap disajikan. 😊"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 258 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/a1324209851ef185/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang harus kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa kesan tersendiri yang merupakan keragaman Kita

Kedekatan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah memasak Ayam Rica-Rica Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang bisa anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 24 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica Kemangi:

1. Jangan lupa 500 gr sayap ayam
1. Diperlukan 500 ml air
1. Harap siapkan  Bumbu Marinasi
1. Harus ada 1 sdt garam/himsalt
1. Diperlukan 1 sdt bawang putih bubuk
1. Harus ada 1 sdt ketumbar bubuk
1. Diperlukan 1 sdt lada bubuk
1. Dibutuhkan 1 sdt kunyit bubuk
1. Harap siapkan  Bumbu Halus
1. Diperlukan 5 siung bawang merah
1. Jangan lupa 3 siung bawang putih
1. Harap siapkan 1,5 butir kemiri (disangrai dulu)
1. Diperlukan 1 ruas jahe
1. Siapkan 5 buah cabe merah (sesuai selera)
1. Siapkan 5 buah cabe rawit (sesuai selera)
1. Siapkan  Bahan Tumis
1. Harus ada 2 lembar daun salam
1. Harap siapkan 3 lembar daun jeruk (2 diiris tipis, 1 disobek)
1. Harap siapkan 1 batang serai, potong lalu geprek
1. Harap siapkan 1 ruas lengkuas, iris atau geprek
1. Harus ada  Bahan Pelengkap
1. Tambah 2 ikat daun kemangi
1. Harap siapkan 1 batang daun bawang, iris serong
1. Harap siapkan Secukupnya garam, gula, dan penyedap rasa (optional)




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica Kemangi:

1. Awali dengan membaca &#34;Bismillahirrahmannirrahiim&#34; terlebih dahulu. 😊
1. Cuci bersih ayam, lumuri dengan bumbu marinasi kemudian diamkan di kulkas selama ± 30 menit. Setelah itu goreng setengah matang dan sisihkan.
1. Blender bumbu halus kemudian tumis dengan sedikit minyak. Tambahkan bahan tumis: serai, lengkuas, daun salam, daun jeruk. Tumis sampai matang dan minyak menyusut.
1. Tambahkan air, garam, gula, penyedap rasa. Aduk rata dan koreksi rasa.
1. Masukkan ayam yang sudah digoreng, masak hingga air menyusut dan bumbu meresap ke dalam ayam. Proses ini membutuhkan waktu yg agak lama. Bisa disambi nyuci peralatan masak yang kotor ya buibu hehe.
1. Terakhir, masukkan daun bawang dan daun kemangi. Aduk hingga tercampur rata. Jangan terlalu lama dimasak lalu matikan api.
1. Siap disajikan. 😊




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan cepat, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
