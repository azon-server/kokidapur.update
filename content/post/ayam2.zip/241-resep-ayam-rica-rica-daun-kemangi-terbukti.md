---
description: "Resep : Ayam rica rica daun kemangi Terbukti"
title: "Resep : Ayam rica rica daun kemangi Terbukti"
slug: 241-resep-ayam-rica-rica-daun-kemangi-terbukti
date: 2020-12-23T14:12:47.229Z
image: https://img-global.cpcdn.com/recipes/e3e34915e9f22d00/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e3e34915e9f22d00/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e3e34915e9f22d00/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Mabel Greene
ratingvalue: 4.6
reviewcount: 29663
recipeingredient:
- "500 gr ayam bagian dadatulangkulit"
- " bawang merah"
- " bawang putih"
- "3 buah cabe merah"
- "sesuai selera cabe rawit"
- "3 ruas jahe ukuran kecil"
- "1 ruas lengkuas ukuran sedang"
- "3 ruas kunyit ukuran kecil"
- "1 batang daun sereh"
- "3 lembar daun jeruk"
- "1 lembar daun salam"
- "2 ikat daun kemangi"
- " gula"
- " garam"
- " air"
recipeinstructions:
- "Cuci bersih ayam yang sudah di potong menjadi kecil, kemudian rebus dengan panci tertutup supaya cepat empuk (rebus kurang lebih sekitar 20-30 menit) angkat lalu tiriskan"
- "Haluskan semua bahan, kecuali jahe, lengkuas, daun sereh di geprek"
- "Panaskan minyak sedikit, kemudian masukkan semua bumbu yang sudah dihaluskan, tumis sampai wangi lalu masukkan jahe, lengkuas, daun salam, dan daun sereh, tumis kembali sampai semua bumbu tercampur"
- "Tambahkan air secukupnya, kemudian masukkan ayam yang sudah di rebus tadi, beri garam dan gula, aduk rata tunggu sampai mendidih"
- "Masukkan daun kemangi, aduk merata sampai semua bumbu meresap ke ayam, tunggu air sampai agak menyusut sedikit, koreksi rasa lalu siap disajikan 😁"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 170 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT37M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam rica rica daun kemangi](https://img-global.cpcdn.com/recipes/e3e34915e9f22d00/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau gurih. Ciri khas masakan Indonesia ayam rica rica daun kemangi yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kedekatan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam rica rica daun kemangi untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang bisa anda coba salah satunya ayam rica rica daun kemangi yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica rica daun kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica daun kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica daun kemangi:

1. Diperlukan 500 gr ayam, bagian dada/tulang/kulit
1. Jangan lupa  bawang merah
1. Jangan lupa  bawang putih
1. Tambah 3 buah cabe merah
1. Siapkan sesuai selera cabe rawit
1. Jangan lupa 3 ruas jahe ukuran kecil
1. Harap siapkan 1 ruas lengkuas ukuran sedang
1. Tambah 3 ruas kunyit ukuran kecil
1. Diperlukan 1 batang daun sereh
1. Siapkan 3 lembar daun jeruk
1. Tambah 1 lembar daun salam
1. Diperlukan 2 ikat daun kemangi
1. Dibutuhkan  gula
1. Tambah  garam
1. Harus ada  air




<!--inarticleads2-->

##### Cara membuat  Ayam rica rica daun kemangi:

1. Cuci bersih ayam yang sudah di potong menjadi kecil, kemudian rebus dengan panci tertutup supaya cepat empuk (rebus kurang lebih sekitar 20-30 menit) angkat lalu tiriskan
1. Haluskan semua bahan, kecuali jahe, lengkuas, daun sereh di geprek
1. Panaskan minyak sedikit, kemudian masukkan semua bumbu yang sudah dihaluskan, tumis sampai wangi lalu masukkan jahe, lengkuas, daun salam, dan daun sereh, tumis kembali sampai semua bumbu tercampur
1. Tambahkan air secukupnya, kemudian masukkan ayam yang sudah di rebus tadi, beri garam dan gula, aduk rata tunggu sampai mendidih
1. Masukkan daun kemangi, aduk merata sampai semua bumbu meresap ke ayam, tunggu air sampai agak menyusut sedikit, koreksi rasa lalu siap disajikan 😁




Demikianlah cara membuat ayam rica rica daun kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
