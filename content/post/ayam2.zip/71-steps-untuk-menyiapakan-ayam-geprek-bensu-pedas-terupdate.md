---
description: "Steps untuk menyiapakan Ayam Geprek BENSU Pedas terupdate"
title: "Steps untuk menyiapakan Ayam Geprek BENSU Pedas terupdate"
slug: 71-steps-untuk-menyiapakan-ayam-geprek-bensu-pedas-terupdate
date: 2020-10-21T08:05:54.429Z
image: https://img-global.cpcdn.com/recipes/965e5f1d16a6ff84/751x532cq70/ayam-geprek-bensu-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/965e5f1d16a6ff84/751x532cq70/ayam-geprek-bensu-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/965e5f1d16a6ff84/751x532cq70/ayam-geprek-bensu-pedas-foto-resep-utama.jpg
author: Mario McGee
ratingvalue: 4.2
reviewcount: 26640
recipeingredient:
- "1 ekor Beberapa potong ayam sesuai keinginan"
- "1 bungkus Tepung sasa serbaguna bisa original atau khusus fried chicken"
- " Air dingin"
- " Minyak untuk menggoreng"
- " Bahan Sambel"
- "sesuai selera cabai rawit "
- "2 atau 3 siung bawang putih tergantung banyaknya cabai"
- "secukupnya garam"
- "2 atau 3 sdm minyak panas"
recipeinstructions:
- "Ayam 1 ekor dipotong menjadi beberapa potong, kemudian rebus (saat udh agak empuk, angkat). Sebenernya bisa tanpa direbus, cuma saya lebih suka direbus biar mateng nya enak."
- "Siapkan tepung sasa serbaguna, utk adonan basah: perbandingannya 3 sdm tepung, air dingin 7 sdm (untuk porsi 4 potong ayam) sisanya dijadikan untuk adonan kering."
- "Masukkan ayam ke adonan basah, tunggu beberapa menit, bolak balik ayam sampai bumbu rata. Setelah itu masukkan (satu satu aja) ayam yg sudah diadonan basah ke adonan kering, remek-remek sampai ayam ketutup tepung"
- "Goreng ayam dengan minyak secukupnya, api kecil supaya matengnya merata"
- "Sambil menunggu ayam matang, siapkan untuk sambal, masukkan cabai bawang putih dan garam, ulek, setelah itu tambah minyak panas 2sdm"
- "Ayam matang, angkat dan tiriskan minyak. Taruh ayam di cobek, geprek pake ulekan cobek menyatu dengan sambal, lalu siapkan nasi hangat. udah jadi deh!😃"
categories:
- Recipe
tags:
- ayam
- geprek
- bensu

katakunci: ayam geprek bensu 
nutrition: 276 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT46M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Geprek BENSU Pedas](https://img-global.cpcdn.com/recipes/965e5f1d16a6ff84/751x532cq70/ayam-geprek-bensu-pedas-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang harus kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam geprek bensu pedas yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan keistimewahan yang merupakan keragaman Indonesia



Kedekatan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam Geprek BENSU Pedas untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda buat salah satunya ayam geprek bensu pedas yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep ayam geprek bensu pedas tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek BENSU Pedas yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek BENSU Pedas:

1. Jangan lupa 1 ekor Beberapa potong ayam (sesuai keinginan)
1. Harap siapkan 1 bungkus Tepung sasa serbaguna (bisa original atau khusus fried chicken)
1. Jangan lupa  Air dingin
1. Tambah  Minyak untuk menggoreng
1. Harus ada  Bahan Sambel:
1. Diperlukan sesuai selera cabai rawit ()
1. Harap siapkan 2 atau 3 siung bawang putih (tergantung banyaknya cabai)
1. Dibutuhkan secukupnya garam
1. Harus ada 2 atau 3 sdm minyak panas




<!--inarticleads2-->

##### Cara membuat  Ayam Geprek BENSU Pedas:

1. Ayam 1 ekor dipotong menjadi beberapa potong, kemudian rebus (saat udh agak empuk, angkat). Sebenernya bisa tanpa direbus, cuma saya lebih suka direbus biar mateng nya enak.
1. Siapkan tepung sasa serbaguna, utk adonan basah: perbandingannya 3 sdm tepung, air dingin 7 sdm (untuk porsi 4 potong ayam) sisanya dijadikan untuk adonan kering.
1. Masukkan ayam ke adonan basah, tunggu beberapa menit, bolak balik ayam sampai bumbu rata. Setelah itu masukkan (satu satu aja) ayam yg sudah diadonan basah ke adonan kering, remek-remek sampai ayam ketutup tepung
1. Goreng ayam dengan minyak secukupnya, api kecil supaya matengnya merata
1. Sambil menunggu ayam matang, siapkan untuk sambal, masukkan cabai bawang putih dan garam, ulek, setelah itu tambah minyak panas 2sdm
1. Ayam matang, angkat dan tiriskan minyak. Taruh ayam di cobek, geprek pake ulekan cobek menyatu dengan sambal, lalu siapkan nasi hangat. udah jadi deh!😃




Demikianlah cara membuat ayam geprek bensu pedas yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan terbukti, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
