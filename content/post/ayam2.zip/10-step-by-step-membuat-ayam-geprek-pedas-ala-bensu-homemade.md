---
description: "Step-by-Step membuat Ayam Geprek Pedas ala Bensu Homemade"
title: "Step-by-Step membuat Ayam Geprek Pedas ala Bensu Homemade"
slug: 10-step-by-step-membuat-ayam-geprek-pedas-ala-bensu-homemade
date: 2020-12-14T06:33:00.629Z
image: https://img-global.cpcdn.com/recipes/48b1942cc4185c30/751x532cq70/ayam-geprek-pedas-ala-bensu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/48b1942cc4185c30/751x532cq70/ayam-geprek-pedas-ala-bensu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/48b1942cc4185c30/751x532cq70/ayam-geprek-pedas-ala-bensu-foto-resep-utama.jpg
author: Dora Buchanan
ratingvalue: 4.9
reviewcount: 44826
recipeingredient:
- "2 potong ayam"
- "1 butir telur"
- "3 siung bawang putih"
- " Merica saya pakai bubuk"
- " Ketumbar saya pakai bubuk"
- "5 sdm tepung terigu"
- "3 sdm tepung maizena"
- " Garam"
- " Gula"
- " Cabe rawit 25 buah sesuai selera tingkat kepedasan masing2"
- "2 siung bawang putih"
- " Penyedap rasa"
recipeinstructions:
- "Cuci bersih ayam. Kemudian marinasi dengan merica bubuk. Ketumbar bubuk. 3 siung bawang putih yang sudah dihaluskan. Dan garam secukupnya. remas ayam pastikan terbalur semua bumbu. Biarkan selama kurang lebih 2 jam ya mom. Agar bumbu meresap ke ayam."
- "Setelah dirasa bumbu teresap masukkan telur.kocok hingga semua bagian ayam terbalur telur. Aduk hingga rata."
- "Campurkan 5 sdm tepung terigu. 3 sdm maizena. Beri sedikit garam dan penyedap rasa. Aduk hingga tercampur rata."
- "Masukkan ayam yang sudah terbalur telur ke dalam campuran tepung. Aduk dan pastikan semua bagian ayam terlapisi tepung. Kemudian panaskan minyak. Goreng ayam dengan api kecil. Goreng hingga matang"
- "Selanjutnya mari buat sambal bawangnya ya mom.panaskan wajan beri sedikit minyak. Goreng 25 cabe rawit dan 2 siung bawang putih. Setelah itu uleg dengan garam gula dan tuang minyak panas."
- "Geprek ayam campurkan dengan sambal bawang. Sajikan dengan nasi panas dijamin nagih. Selamat mencoba :)"
categories:
- Recipe
tags:
- ayam
- geprek
- pedas

katakunci: ayam geprek pedas 
nutrition: 241 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Geprek Pedas ala Bensu](https://img-global.cpcdn.com/recipes/48b1942cc4185c30/751x532cq70/ayam-geprek-pedas-ala-bensu-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga empuk. Ciri khas masakan Indonesia ayam geprek pedas ala bensu yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah memasak Ayam Geprek Pedas ala Bensu untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang dapat anda buat salah satunya ayam geprek pedas ala bensu yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep ayam geprek pedas ala bensu tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Pedas ala Bensu yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Pedas ala Bensu:

1. Dibutuhkan 2 potong ayam
1. Diperlukan 1 butir telur
1. Siapkan 3 siung bawang putih
1. Diperlukan  Merica (saya pakai bubuk)
1. Tambah  Ketumbar (saya pakai bubuk)
1. Dibutuhkan 5 sdm tepung terigu
1. Diperlukan 3 sdm tepung maizena
1. Siapkan  Garam
1. Harap siapkan  Gula
1. Jangan lupa  Cabe rawit 25 buah (sesuai selera tingkat kepedasan masing2)
1. Diperlukan 2 siung bawang putih
1. Siapkan  Penyedap rasa




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Geprek Pedas ala Bensu:

1. Cuci bersih ayam. Kemudian marinasi dengan merica bubuk. Ketumbar bubuk. 3 siung bawang putih yang sudah dihaluskan. Dan garam secukupnya. remas ayam pastikan terbalur semua bumbu. Biarkan selama kurang lebih 2 jam ya mom. Agar bumbu meresap ke ayam.
1. Setelah dirasa bumbu teresap masukkan telur.kocok hingga semua bagian ayam terbalur telur. Aduk hingga rata.
1. Campurkan 5 sdm tepung terigu. 3 sdm maizena. Beri sedikit garam dan penyedap rasa. Aduk hingga tercampur rata.
1. Masukkan ayam yang sudah terbalur telur ke dalam campuran tepung. Aduk dan pastikan semua bagian ayam terlapisi tepung. Kemudian panaskan minyak. Goreng ayam dengan api kecil. Goreng hingga matang
1. Selanjutnya mari buat sambal bawangnya ya mom.panaskan wajan beri sedikit minyak. Goreng 25 cabe rawit dan 2 siung bawang putih. Setelah itu uleg dengan garam gula dan tuang minyak panas.
1. Geprek ayam campurkan dengan sambal bawang. Sajikan dengan nasi panas dijamin nagih. Selamat mencoba :)




Demikianlah cara membuat ayam geprek pedas ala bensu yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan cepat, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
