---
description: "Steps menyiapakan Ayam Rica-Rica Daun Kemangi Teruji"
title: "Steps menyiapakan Ayam Rica-Rica Daun Kemangi Teruji"
slug: 387-steps-menyiapakan-ayam-rica-rica-daun-kemangi-teruji
date: 2021-02-03T11:32:41.180Z
image: https://img-global.cpcdn.com/recipes/c855ea095c7585db/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c855ea095c7585db/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c855ea095c7585db/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Lucile Berry
ratingvalue: 4.7
reviewcount: 11236
recipeingredient:
- "2 paha ayam potong kecil"
- "2 ikat kemangi petik daunnya"
- "1 batang serai memarkan"
- "1 ruas lengkuas memarkan"
- "4 lembar daun jeruk sobek sobek"
- "2 lembar daun salam"
- "1 buah jeruk nipis"
- "Secukupnya gula garam dan penyedap rasa"
- "4 sdm minyak goreng"
- "Sedikit air"
- " Bumbu halus"
- "4 siung bawang putih"
- "5 siung bawang merah"
- "12 buah cabai rawit merah"
- "9 buah cabai merah keriting"
- "2 ruas kunyit"
- "1 ruas jahe"
- "3 butir kemiri"
recipeinstructions:
- "Cuci bersih ayam beri perasan jeruk nipis dan rebus dengan sedikit air. Selesai merebus sisihkan kaldunya."
- "Tumis bumbu halus beserta daun salam, daun jeruk, serai, dan lengkuas hingga harum."
- "Masukan ayam yang sudah direbus aduk-aduk lalu tambahkan kaldunya. Masak hingga ayam empuk dan kaldu menyusut."
- "Beri garam, gula, dan penyedap rasa. Tes rasa kemudian masukan daun kemangi aduk hingga tercampur rata."
- "Segera matikan kompor jangan biarkan kemangi terlalu layu. Angkat dan sajikan😘"
categories:
- Recipe
tags:
- ayam
- ricarica
- daun

katakunci: ayam ricarica daun 
nutrition: 149 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica-Rica Daun Kemangi](https://img-global.cpcdn.com/recipes/c855ea095c7585db/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita jaga karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica-rica daun kemangi yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Nusantara



Kedekatan keluarga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Ayam Rica-Rica Daun Kemangi untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang dapat anda praktekkan salah satunya ayam rica-rica daun kemangi yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica-rica daun kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica Daun Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Daun Kemangi:

1. Diperlukan 2 paha ayam potong kecil
1. Harap siapkan 2 ikat kemangi petik daunnya
1. Diperlukan 1 batang serai memarkan
1. Siapkan 1 ruas lengkuas memarkan
1. Harap siapkan 4 lembar daun jeruk sobek sobek
1. Harus ada 2 lembar daun salam
1. Siapkan 1 buah jeruk nipis
1. Diperlukan Secukupnya gula, garam, dan penyedap rasa
1. Diperlukan 4 sdm minyak goreng
1. Harus ada Sedikit air
1. Tambah  Bumbu halus
1. Jangan lupa 4 siung bawang putih
1. Siapkan 5 siung bawang merah
1. Harus ada 12 buah cabai rawit merah
1. Siapkan 9 buah cabai merah keriting
1. Harus ada 2 ruas kunyit
1. Jangan lupa 1 ruas jahe
1. Jangan lupa 3 butir kemiri




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica Daun Kemangi:

1. Cuci bersih ayam beri perasan jeruk nipis dan rebus dengan sedikit air. Selesai merebus sisihkan kaldunya.
1. Tumis bumbu halus beserta daun salam, daun jeruk, serai, dan lengkuas hingga harum.
1. Masukan ayam yang sudah direbus aduk-aduk lalu tambahkan kaldunya. Masak hingga ayam empuk dan kaldu menyusut.
1. Beri garam, gula, dan penyedap rasa. Tes rasa kemudian masukan daun kemangi aduk hingga tercampur rata.
1. Segera matikan kompor jangan biarkan kemangi terlalu layu. Angkat dan sajikan😘




Demikianlah cara membuat ayam rica-rica daun kemangi yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
