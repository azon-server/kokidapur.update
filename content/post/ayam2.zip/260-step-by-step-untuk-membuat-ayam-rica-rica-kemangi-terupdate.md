---
description: "Step-by-Step untuk membuat Ayam rica-rica kemangi terupdate"
title: "Step-by-Step untuk membuat Ayam rica-rica kemangi terupdate"
slug: 260-step-by-step-untuk-membuat-ayam-rica-rica-kemangi-terupdate
date: 2020-09-29T18:33:03.108Z
image: https://img-global.cpcdn.com/recipes/99f754a72ccbe332/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/99f754a72ccbe332/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/99f754a72ccbe332/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Hunter Roberts
ratingvalue: 5
reviewcount: 27282
recipeingredient:
- "1/2 ekor ayam potong kecil"
- "500 ml air untuk merebus"
- "1 jeruk nipis"
- " Minyak untuk menggoreng"
- " Bumbu geprek "
- "1 cm jahe"
- "1 siung bawang putih"
- " Bumbu halus"
- "15 cabai merah"
- "5 siung bawang putih"
- "5 siung bawang merah"
- "secukupnya Garam"
- "secukupnya Kaldu jamur"
- "secukupnya Gula pasir"
- " Pelengkap"
- "2 ikat daun kemangi"
- "1/2 bombay iris"
- "1 btg sereh"
- "2 lbr daun jeruk"
recipeinstructions:
- "Cuci bersih ayam, lumuri dgn jeruk nipis. Diamkan 10 menit. Bilas"
- "Rebus ayam 5 menit dlm air mendidih. Buang air rebusan. Tiriskan"
- "Bumbui ayam dgn bumbu geprek, ditambah sedikit garam. Diamkan 10 mnt supaya bumbu meresap"
- "Goreng ayam setengah matang. Tisriskan"
- "Tumis bawang bombay sampai layu, masukkan sereh, daun jeruk, bumbu halus. Tambahkan garam, kaldu jamur, gula pasir, beri sedikit air matang"
- "Masukkan ayam, koreksi rasa. masak sampai bumbu meresap. Terakhir masukkan daun kemangi. Matikan api. Selesai"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 298 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/99f754a72ccbe332/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang harus kita jaga karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan keistimewahan yang merupakan keragaman Nusantara

Kehangatan keluarga bisa ditemukan dengan cara mudah. Salah satunya adalah memasak Ayam rica-rica kemangi untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang bisa anda coba salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica kemangi:

1. Tambah 1/2 ekor ayam potong kecil
1. Dibutuhkan 500 ml air untuk merebus
1. Harus ada 1 jeruk nipis
1. Dibutuhkan  Minyak untuk menggoreng
1. Harap siapkan  Bumbu geprek :
1. Siapkan 1 cm jahe
1. Harap siapkan 1 siung bawang putih
1. Tambah  Bumbu halus
1. Diperlukan 15 cabai merah
1. Dibutuhkan 5 siung bawang putih
1. Harus ada 5 siung bawang merah
1. Diperlukan secukupnya Garam
1. Harus ada secukupnya Kaldu jamur
1. Harus ada secukupnya Gula pasir
1. Jangan lupa  Pelengkap
1. Dibutuhkan 2 ikat daun kemangi
1. Jangan lupa 1/2 bombay, iris²
1. Harap siapkan 1 btg sereh
1. Tambah 2 lbr daun jeruk


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Instruksi membuat  Ayam rica-rica kemangi:

1. Cuci bersih ayam, lumuri dgn jeruk nipis. Diamkan 10 menit. Bilas
1. Rebus ayam 5 menit dlm air mendidih. Buang air rebusan. Tiriskan
1. Bumbui ayam dgn bumbu geprek, ditambah sedikit garam. Diamkan 10 mnt supaya bumbu meresap
1. Goreng ayam setengah matang. Tisriskan
1. Tumis bawang bombay sampai layu, masukkan sereh, daun jeruk, bumbu halus. Tambahkan garam, kaldu jamur, gula pasir, beri sedikit air matang
1. Masukkan ayam, koreksi rasa. masak sampai bumbu meresap. Terakhir masukkan daun kemangi. Matikan api. Selesai


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
