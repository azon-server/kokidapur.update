---
description: "Resep : Ayam rica rica kemangi Terbukti"
title: "Resep : Ayam rica rica kemangi Terbukti"
slug: 289-resep-ayam-rica-rica-kemangi-terbukti
date: 2020-08-06T21:19:13.945Z
image: https://img-global.cpcdn.com/recipes/cbc89984e9701d63/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cbc89984e9701d63/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cbc89984e9701d63/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Hunter Nguyen
ratingvalue: 4.7
reviewcount: 16434
recipeingredient:
- "1 ekor ayam potong"
- "3 ikat kemangi sesuai selera"
- "2 ruas lengkuas"
- "2 ruas jahe"
- "5 buah serai"
- "5 lembar daun jeruk"
- "5 lembar daun salam"
- " Bumbu Halus"
- "10 butir cabe merah keriting"
- "10 butir cabe rawit merah"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "3 butir kemiri"
- "1 sdm ketumbar"
- "1 ruas kunyit"
- "secukupnya garam dan gula"
- " Bahan Tambahan"
- "1 buah jeruk nipis"
recipeinstructions:
- "Bersihkan ayam dgn jeruk nipis sampai bersih. Siapkan air utk merebus ayam. Tambahkan jahe, serai dan bawang putih (utk menghilangkan bau amis ayam)"
- "Panaskan minyak goreng. Lalu goreng ayam yg telah direbus sebentar saja (jangan kering)"
- "Panaskan kembali wajan dgn sedikit minyak, lalu masukkan bumbu halus, tumis dan masukkan jahe, lengkuas, daun jeruk dan daun salam serta serai yg telah di geprek. Tambahkan garam dan gula sesuai selera dan cek rasa."
- "Masukkan kembali ayam yg telah di goreng. Tambahkan air dan biarkan meresap sampai bumbu agak kering."
- "Terakhir, masukkan kemangi dan siap disajikan.."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 240 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/cbc89984e9701d63/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang setidaknya kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica rica kemangi yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Nusantara

Kehangatan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam rica rica kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang dapat anda buat salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi:

1. Siapkan 1 ekor ayam potong
1. Siapkan 3 ikat kemangi (sesuai selera)
1. Dibutuhkan 2 ruas lengkuas
1. Siapkan 2 ruas jahe
1. Harap siapkan 5 buah serai
1. Siapkan 5 lembar daun jeruk
1. Diperlukan 5 lembar daun salam
1. Jangan lupa  Bumbu Halus
1. Diperlukan 10 butir cabe merah keriting
1. Harap siapkan 10 butir cabe rawit merah
1. Harus ada 6 siung bawang merah
1. Diperlukan 3 siung bawang putih
1. Jangan lupa 3 butir kemiri
1. Siapkan 1 sdm ketumbar
1. Tambah 1 ruas kunyit
1. Tambah secukupnya garam dan gula
1. Diperlukan  Bahan Tambahan
1. Diperlukan 1 buah jeruk nipis




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica rica kemangi:

1. Bersihkan ayam dgn jeruk nipis sampai bersih. Siapkan air utk merebus ayam. Tambahkan jahe, serai dan bawang putih (utk menghilangkan bau amis ayam)
1. Panaskan minyak goreng. Lalu goreng ayam yg telah direbus sebentar saja (jangan kering)
1. Panaskan kembali wajan dgn sedikit minyak, lalu masukkan bumbu halus, tumis dan masukkan jahe, lengkuas, daun jeruk dan daun salam serta serai yg telah di geprek. Tambahkan garam dan gula sesuai selera dan cek rasa.
1. Masukkan kembali ayam yg telah di goreng. Tambahkan air dan biarkan meresap sampai bumbu agak kering.
1. Terakhir, masukkan kemangi dan siap disajikan..




Demikianlah cara membuat ayam rica rica kemangi yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan cepat, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
