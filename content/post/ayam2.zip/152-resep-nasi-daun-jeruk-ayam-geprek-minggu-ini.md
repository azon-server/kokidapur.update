---
description: "Resep : Nasi Daun Jeruk Ayam Geprek minggu ini"
title: "Resep : Nasi Daun Jeruk Ayam Geprek minggu ini"
slug: 152-resep-nasi-daun-jeruk-ayam-geprek-minggu-ini
date: 2020-10-08T04:14:18.256Z
image: https://img-global.cpcdn.com/recipes/cda32dc38c79102d/751x532cq70/nasi-daun-jeruk-ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cda32dc38c79102d/751x532cq70/nasi-daun-jeruk-ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cda32dc38c79102d/751x532cq70/nasi-daun-jeruk-ayam-geprek-foto-resep-utama.jpg
author: Frederick Gray
ratingvalue: 5
reviewcount: 7599
recipeingredient:
- " Bahan Nasi Daun jeruk"
- "1 mangkok kecil Nasi putih"
- "1 siung Bawang putih"
- "3 biji Cabe rawit merah"
- "5 lembar Daun jeruk"
- "secukupnya Garam"
- "secukupnya Lada"
- "secukupnya Kaldu bubuk"
- " Bahan Ayam Geprek"
- "1 potong dada Ayam"
- "secukupnya Bawang putih halus"
- "secukupnya Jahe"
- "secukupnya Garam gula pasirketumbar lada"
- "secukupnya Daun salam dan daun jeruk"
- " Air secukupnya sampe ayam tenggelam"
- " Tepung terigu"
- " Tepung sasa hot spicy"
- " Minyak goreng"
- " Bahan cabe"
- "10 biji cabe rawit merah sesuai selera ya pedesnya"
- "1 siung Bawang putih"
- "secukupnya Garam gula pasir kaldu bubuk"
- "3 sdm Minyak panas"
recipeinstructions:
- "Siapkan air untuk mengungkap ayam kalau saya pake presto jadinya bener2 empuk dan kalau sudah mateng bunyi prestonya 😂. Lalu masukkan ayam, bawang putih, ketumbar, lada, gula pasir, daun salam, daun jeruk. Tunggu hingga mendidih dan dirasa cukup empuk kalau diungkap"
- "Setelah ayam mateng. Siapkan minyak panas sampe ayamnya terendam pas digoreng. Selagi menunggu minyak panas. Siapkan tepung terigu kemudian kasih air secukupnya jangan terlalu kental dan jangan terlalu encer. Dan tepung kering sasa hot spicy. Lalu tiriskan ayam yg sudah diungkep celupkan ketepung saya tepuk tepuk agar tepung menempel lalu angkat dan celupkan di tepung basah terigu tadi, angkat dan celupkan lg ketepung kering sasa tapuk tepuk agar tepuk menempel dan tidak terlalu tebal."
- "Goreng ayam hingga warna kecoklatkan dengan api sedang. Selagi menunggu ayam mateng. Mariii masak nasii daun jeruknya.."
- "Siapkan 1 mangkok nasi putih. Iris serong cabe rawit merah, cincang bawang putih dan iris tipis daun jeruk (buang batang ditengaj daunnya ya). Siapkan minyak sedikit buat numis bawang putih hingga harum lalu masukkan irisan cabe dan daun jeruk. Oseng2 sebentar lalu masukkan nasi, garam, lada, kaldu bubuk dan tes rasa. Sama seperti kita buat nasi goreng. Lalu sajikan dipiring."
- "Untuk cabe bawangnya. Siapkan bahan buat cabe lalu giling atau tumbuk kasar. Kemudian masukkan garam, gula, dan kaldu bubuk lalu siram dengan minyak panas. Dan siap disajikan diatas ayam. Ayamnya digeprek dulu ya."
- "Bisa berikan taburan bawang goreng."
- "Selamat mencoba 👌😍🤗"
categories:
- Recipe
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 204 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Lunch

---


![Nasi Daun Jeruk Ayam Geprek](https://img-global.cpcdn.com/recipes/cda32dc38c79102d/751x532cq70/nasi-daun-jeruk-ayam-geprek-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau empuk. Karasteristik masakan Nusantara nasi daun jeruk ayam geprek yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan keluarga dapat diperoleh dengan cara simple. Diantaranya adalah membuat makanan Nasi Daun Jeruk Ayam Geprek untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang bisa anda buat salah satunya nasi daun jeruk ayam geprek yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep nasi daun jeruk ayam geprek tanpa harus bersusah payah.
Berikut ini resep Nasi Daun Jeruk Ayam Geprek yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 23 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nasi Daun Jeruk Ayam Geprek:

1. Diperlukan  Bahan Nasi Daun jeruk
1. Jangan lupa 1 mangkok kecil Nasi putih
1. Siapkan 1 siung Bawang putih
1. Siapkan 3 biji Cabe rawit merah
1. Diperlukan 5 lembar Daun jeruk
1. Tambah secukupnya Garam
1. Jangan lupa secukupnya Lada
1. Jangan lupa secukupnya Kaldu bubuk
1. Dibutuhkan  Bahan Ayam Geprek
1. Tambah 1 potong dada Ayam
1. Dibutuhkan secukupnya Bawang putih halus
1. Tambah secukupnya Jahe
1. Siapkan secukupnya Garam, gula pasir,ketumbar, lada
1. Siapkan secukupnya Daun salam dan daun jeruk
1. Siapkan  Air secukupnya sampe ayam tenggelam
1. Diperlukan  Tepung terigu
1. Tambah  Tepung sasa hot spicy
1. Tambah  Minyak goreng
1. Tambah  Bahan cabe
1. Diperlukan 10 biji cabe rawit merah (sesuai selera ya pedesnya)
1. Harus ada 1 siung Bawang putih
1. Siapkan secukupnya Garam, gula pasir, kaldu bubuk
1. Siapkan 3 sdm Minyak panas




<!--inarticleads2-->

##### Langkah membuat  Nasi Daun Jeruk Ayam Geprek:

1. Siapkan air untuk mengungkap ayam kalau saya pake presto jadinya bener2 empuk dan kalau sudah mateng bunyi prestonya 😂. Lalu masukkan ayam, bawang putih, ketumbar, lada, gula pasir, daun salam, daun jeruk. Tunggu hingga mendidih dan dirasa cukup empuk kalau diungkap
1. Setelah ayam mateng. Siapkan minyak panas sampe ayamnya terendam pas digoreng. Selagi menunggu minyak panas. Siapkan tepung terigu kemudian kasih air secukupnya jangan terlalu kental dan jangan terlalu encer. Dan tepung kering sasa hot spicy. Lalu tiriskan ayam yg sudah diungkep celupkan ketepung saya tepuk tepuk agar tepung menempel lalu angkat dan celupkan di tepung basah terigu tadi, angkat dan celupkan lg ketepung kering sasa tapuk tepuk agar tepuk menempel dan tidak terlalu tebal.
1. Goreng ayam hingga warna kecoklatkan dengan api sedang. Selagi menunggu ayam mateng. Mariii masak nasii daun jeruknya..
1. Siapkan 1 mangkok nasi putih. Iris serong cabe rawit merah, cincang bawang putih dan iris tipis daun jeruk (buang batang ditengaj daunnya ya). Siapkan minyak sedikit buat numis bawang putih hingga harum lalu masukkan irisan cabe dan daun jeruk. Oseng2 sebentar lalu masukkan nasi, garam, lada, kaldu bubuk dan tes rasa. Sama seperti kita buat nasi goreng. Lalu sajikan dipiring.
1. Untuk cabe bawangnya. Siapkan bahan buat cabe lalu giling atau tumbuk kasar. Kemudian masukkan garam, gula, dan kaldu bubuk lalu siram dengan minyak panas. Dan siap disajikan diatas ayam. Ayamnya digeprek dulu ya.
1. Bisa berikan taburan bawang goreng.
1. Selamat mencoba 👌😍🤗




Demikianlah cara membuat nasi daun jeruk ayam geprek yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan teruji, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
