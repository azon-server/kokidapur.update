---
description: "Cara singkat untuk menyiapakan Ayam Geprek Bensu Homemade Sempurna"
title: "Cara singkat untuk menyiapakan Ayam Geprek Bensu Homemade Sempurna"
slug: 34-cara-singkat-untuk-menyiapakan-ayam-geprek-bensu-homemade-sempurna
date: 2020-11-03T00:26:31.479Z
image: https://img-global.cpcdn.com/recipes/ae68c0e97e38c4cf/751x532cq70/ayam-geprek-bensu-homemade-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ae68c0e97e38c4cf/751x532cq70/ayam-geprek-bensu-homemade-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ae68c0e97e38c4cf/751x532cq70/ayam-geprek-bensu-homemade-foto-resep-utama.jpg
author: Clarence Benson
ratingvalue: 4.8
reviewcount: 17319
recipeingredient:
- "1/2 kg ayam potong"
- " Adonan kering "
- "1/2 kg tepung segitiga biru"
- "2 sdm tepung maizena"
- "1 sdm tepung beras"
- "1/2 sdt baking powder"
- "1 sdt garam"
- "1 sdt kaldu bubuk"
- " Adonan basah "
- "1 butir putih telur"
- "5 sdm tepung segitiga biru"
- "1 bawang putih haluskan"
- "1/2 sdt lada putih bubuk"
- "1/2 sdt kaldu bubuk"
- " Bahan Sambal Geprek "
- "1 ons cabe rawit"
- "3 bawang merah"
- "5 bawang putih"
- "1 sdt kaldu bubuk"
- "1 sdt gula"
- "1/2 sdt garam"
- "sedikit air"
recipeinstructions:
- "Cara buat Ayam Krispi #step 1 :  Cuci ayam. Sayat sayat daging ayam agar tepung merata dan merekah"
- "Cara buat Ayam Krispi #step 2 :  Siapkan dua wadah.  Campur ratakan bahan adonan kering di dalam wadah 1.  Di wadah 2, campurkan bahan adonan basah, aduk rata hingga agak kental."
- "Cara buat Ayam Krispi #step 3:  Celupkan potongan ayam ke dalam adonan basah, lalu lumuri dengan adonan kering sambil dicubit cubit. Lakukan proses celupkan-lumuri tersebut dua kali untuk mendapatkan lapisan krispi lebih tebal"
- "Cara buat Ayam Krispi #step 4:  Goreng ayam ke dalam minyak (minyak harus menutupi seluruh bagian ayam). Goreng hingga matang. Angkat"
- "Cara buat sambal geprek #step 1:  Iris iris tipis bawang merah, dan geprek bawang putih. Tumis bawang merah dan bawang putih sampai layu dan harum. Angkat tiriskan."
- "Cara buat sambal geprek #step 2:  Uleg kasar cabe rawit. Tambahkan bawang merah+putih. Uleg ringan."
- "Cara buat sambal geprek #step 3:  Tumis sambal. Beri sedikit air, gula, garam dan lada. Tumis hingga air agak menyusut. Beri sedikit air. Tumis lagi.Usahakan dapat tekstur sambal yang sedikit agak basah dan berminyak. Angkat."
- "Penyelesaian :  Siapkan cobek. Beri ayam, dan sambal secukupnya di atas nya. Lalu geprek geprek. Sajikan bersama nasi hangat. Nyam nyam 🍚🍗"
categories:
- Recipe
tags:
- ayam
- geprek
- bensu

katakunci: ayam geprek bensu 
nutrition: 248 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Geprek Bensu Homemade](https://img-global.cpcdn.com/recipes/ae68c0e97e38c4cf/751x532cq70/ayam-geprek-bensu-homemade-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang harus kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam geprek bensu homemade yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa ciri khas yang merupakan keragaman Indonesia

Kedekatan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ayam Geprek Bensu Homemade untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

Ayam Geprek yg enak ini sekarang dapat di order melalui Aplikasi Homemade Indonesia. download aplikasinya sekarang juga melalui Appstore atau Playstore dari. Geprek Bensu bisa disebut sebagai perintis bisnis waralaba ayam geprek pertama di Indonesia. Awalnya ayam geprek hanya dikenal di kawasan Yogyakarta. Baca juga: Ayam Geprek, Ayam Penyet, dan Ayam Gepuk, Apa Bedanya?

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang bisa anda praktekkan salah satunya ayam geprek bensu homemade yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam geprek bensu homemade tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Bensu Homemade yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Bensu Homemade:

1. Diperlukan 1/2 kg ayam (potong&#34;)
1. Tambah  Adonan kering :
1. Harap siapkan 1/2 kg tepung segitiga biru
1. Harus ada 2 sdm tepung maizena
1. Siapkan 1 sdm tepung beras
1. Harap siapkan 1/2 sdt baking powder
1. Jangan lupa 1 sdt garam
1. Harap siapkan 1 sdt kaldu bubuk
1. Dibutuhkan  Adonan basah :
1. Jangan lupa 1 butir putih telur
1. Diperlukan 5 sdm tepung segitiga biru
1. Harus ada 1 bawang putih (haluskan)
1. Dibutuhkan 1/2 sdt lada putih bubuk
1. Siapkan 1/2 sdt kaldu bubuk
1. Harus ada  Bahan Sambal Geprek :
1. Dibutuhkan 1 ons cabe rawit
1. Tambah 3 bawang merah
1. Diperlukan 5 bawang putih
1. Siapkan 1 sdt kaldu bubuk
1. Harap siapkan 1 sdt gula
1. Harap siapkan 1/2 sdt garam
1. Tambah sedikit air


Seperti pada ayam geprek pada umumnya, Ayam Geprek Bensu terdiri dari ayam goreng tepung yang digeprek dengan sambal bawangnya. Banyak orang yang pesimis dengan sambal bawang karena rasanya bisa langu dan merusak kenikmatan ayam gepreknya. Ayam geprek Mozarella ala Geprek Bensu. Geprek Bensu dikenal murah harganya dan enak rasanya, benarkah seperti itu? 

<!--inarticleads2-->

##### Instruksi membuat  Ayam Geprek Bensu Homemade:

1. Cara buat Ayam Krispi #step 1 : -  - Cuci ayam. Sayat sayat daging ayam agar tepung merata dan merekah
1. Cara buat Ayam Krispi #step 2 : -  - Siapkan dua wadah. -  - Campur ratakan bahan adonan kering di dalam wadah 1. -  - Di wadah 2, campurkan bahan adonan basah, aduk rata hingga agak kental.
1. Cara buat Ayam Krispi #step 3: -  - Celupkan potongan ayam ke dalam adonan basah, lalu lumuri dengan adonan kering sambil dicubit cubit. Lakukan proses celupkan-lumuri tersebut dua kali untuk mendapatkan lapisan krispi lebih tebal
1. Cara buat Ayam Krispi #step 4: -  - Goreng ayam ke dalam minyak (minyak harus menutupi seluruh bagian ayam). Goreng hingga matang. Angkat
1. Cara buat sambal geprek #step 1: -  - Iris iris tipis bawang merah, dan geprek bawang putih. Tumis bawang merah dan bawang putih sampai layu dan harum. Angkat tiriskan.
1. Cara buat sambal geprek #step 2: -  - Uleg kasar cabe rawit. Tambahkan bawang merah+putih. Uleg ringan.
1. Cara buat sambal geprek #step 3: -  - Tumis sambal. Beri sedikit air, gula, garam dan lada. Tumis hingga air agak menyusut. Beri sedikit air. Tumis lagi.Usahakan dapat tekstur sambal yang sedikit agak basah dan berminyak. Angkat.
1. Penyelesaian : -  - Siapkan cobek. Beri ayam, dan sambal secukupnya di atas nya. Lalu geprek geprek. Sajikan bersama nasi hangat. Nyam nyam 🍚🍗


Ayam geprek Mozarella ala Geprek Bensu. Geprek Bensu dikenal murah harganya dan enak rasanya, benarkah seperti itu? Simak ulasan harga ayam Geprek Bensu terlengkap berikut ini. Kemudian dibuatnya lagi Geprek Bensu, nah bagaimana awal mulanya? Dan berapa harga menu di Geprek Bensu? 

Demikianlah cara membuat ayam geprek bensu homemade yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan teruji, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
