---
description: "Bagaimana untuk menyiapakan Ayam rica rica kemangi minggu ini"
title: "Bagaimana untuk menyiapakan Ayam rica rica kemangi minggu ini"
slug: 392-bagaimana-untuk-menyiapakan-ayam-rica-rica-kemangi-minggu-ini
date: 2020-11-03T08:59:30.039Z
image: https://img-global.cpcdn.com/recipes/c659e755ae8eabc9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c659e755ae8eabc9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c659e755ae8eabc9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Stella Wagner
ratingvalue: 4.4
reviewcount: 46381
recipeingredient:
- "1 kg ayam"
- "Secukupnya daun kemangi"
- "15 buah cabe rawit hijaurawit merahsy campur"
- " Bumbu halus "
- "7 buah bawang merah"
- "5 buah bawang putih"
- "5 buah cabe merah"
- "1 sdm ketumbar sangrai"
- "1/2 sdm lada"
- "7 butir kemiri sangrai"
- "1 ruas kunyit"
- "1 ruas lengkuas geprek"
- "1 batang seraigeprek"
- "1 buah tomat iris belah 4"
- "2 lembar daun jeruk"
- "Sedikit asam jawa"
- "Secukupnya gargul kaldu bubuk"
recipeinstructions:
- "Tumis bumbu halus sampai harum. Masukan bumbu lain nya seperti lengkuas,serai,daun jeruk, asam jawa."
- "Lalu masukan ayam yg sudah di potong&#34;&amp;cuci bersih sebelumnya. Aduk rata."
- "Kemudian tambahkan 350 ml air. Masukan cabai rawit merah&amp;rawit hijau. Aduk rata. Diamkan smpai air agak mnyusut.tambahkan gargul, kaldu bubuk tes rasa.masukan kemangi&amp;tomat.jika matang, angkat, sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 281 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/c659e755ae8eabc9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga renyah. Ciri makanan Indonesia ayam rica rica kemangi yang penuh dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Keharmonisan keluarga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica rica kemangi untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang dapat anda buat salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi:

1. Diperlukan 1 kg ayam
1. Siapkan Secukupnya daun kemangi
1. Tambah 15 buah cabe rawit hijau/rawit merah(sy campur)
1. Jangan lupa  Bumbu halus :
1. Dibutuhkan 7 buah bawang merah
1. Diperlukan 5 buah bawang putih
1. Siapkan 5 buah cabe merah
1. Siapkan 1 sdm ketumbar sangrai
1. Harus ada 1/2 sdm lada
1. Diperlukan 7 butir kemiri sangrai
1. Harus ada 1 ruas kunyit
1. Jangan lupa 1 ruas lengkuas (geprek)
1. Tambah 1 batang serai(geprek)
1. Tambah 1 buah tomat iris belah 4
1. Diperlukan 2 lembar daun jeruk
1. Jangan lupa Sedikit asam jawa
1. Tambah Secukupnya gargul, kaldu bubuk


Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica rica kemangi:

1. Tumis bumbu halus sampai harum. Masukan bumbu lain nya seperti lengkuas,serai,daun jeruk, asam jawa.
1. Lalu masukan ayam yg sudah di potong&#34;&amp;cuci bersih sebelumnya. Aduk rata.
1. Kemudian tambahkan 350 ml air. Masukan cabai rawit merah&amp;rawit hijau. Aduk rata. Diamkan smpai air agak mnyusut.tambahkan gargul, kaldu bubuk tes rasa.masukan kemangi&amp;tomat.jika matang, angkat, sajikan


Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Siapa yang tidak mengenal lalapan daun kemangi di Indonesia ini. Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. 

Demikianlah cara membuat ayam rica rica kemangi yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan cepat, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
