---
description: "Step-by-Step membuat Ayam Rica Rica Kemangi Cepat"
title: "Step-by-Step membuat Ayam Rica Rica Kemangi Cepat"
slug: 234-step-by-step-membuat-ayam-rica-rica-kemangi-cepat
date: 2020-10-21T16:54:41.590Z
image: https://img-global.cpcdn.com/recipes/b45ed06922704b0a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b45ed06922704b0a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b45ed06922704b0a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Ethel Chambers
ratingvalue: 4.8
reviewcount: 48525
recipeingredient:
- " Ayam Tepung"
- "6 sdm Tepung Maizena"
- "3 sdm Tepung Beras"
- "500 gram Ayam saya pakai ayam dada dipotong kecil"
- " Bumbu Ulek Kasar"
- "10 buah Cabai Merah Keriting"
- "5 buah Cabai Rawit"
- "6 siung Bawang Merah"
- "3 siung Bawang Putih"
- " Bumbu Kasar"
- "4 lembar Daun Jeruk dibuang tulangnya iris tipis"
- "3 lembar Daun Salam"
- "1 batang Sereh digeprek"
- " Bumbu Pelengkap"
- " Garam"
- " Gula Merah"
- " Penyedap rasa"
- "10 ml Air"
- "1 ikat Daun Kemangi"
recipeinstructions:
- "Tambahkan garam pada ayam, lalu diamkan selama 15 menit."
- "Campurkan Tepung Maizena dan Tepung Beras, ditambah dengan garam dan penyedap secukupnya."
- "Lumuri ayam dengan campuran tepung maizena, lalu goreng hingga matang."
- "Ulek bumbu halus kasar, lalu tumis menggunakan api sedang."
- "Tambahkan 10 ml air"
- "Tambahkan garam, gula merah dan penyedap rasa sesuai selera."
- "Masukkan bumbu kasar, hingga air surut."
- "Masukkan ayam ke dalam bumbu, aduk hingga rata."
- "Tambahkan daun kemangi, aduk rata. Diamkan hingga bumbu meresap kurang lebih 3 menit."
- "Ayam siap disajikaaan 🎉"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 175 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/b45ed06922704b0a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang dapat kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica rica kemangi yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara



Kedekatan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah memasak Ayam Rica Rica Kemangi untuk keluarga. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda coba salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 19 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi:

1. Siapkan  Ayam Tepung
1. Jangan lupa 6 sdm Tepung Maizena
1. Jangan lupa 3 sdm Tepung Beras
1. Harus ada 500 gram Ayam (saya pakai ayam dada, dipotong kecil)
1. Siapkan  Bumbu Ulek Kasar
1. Tambah 10 buah Cabai Merah Keriting
1. Harap siapkan 5 buah Cabai Rawit
1. Tambah 6 siung Bawang Merah
1. Tambah 3 siung Bawang Putih
1. Harap siapkan  Bumbu Kasar
1. Tambah 4 lembar Daun Jeruk dibuang tulangnya, iris tipis
1. Dibutuhkan 3 lembar Daun Salam
1. Harap siapkan 1 batang Sereh digeprek
1. Diperlukan  Bumbu Pelengkap
1. Harus ada  Garam
1. Harap siapkan  Gula Merah
1. Harus ada  Penyedap rasa
1. Diperlukan 10 ml Air
1. Harus ada 1 ikat Daun Kemangi




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica Kemangi:

1. Tambahkan garam pada ayam, lalu diamkan selama 15 menit.
1. Campurkan Tepung Maizena dan Tepung Beras, ditambah dengan garam dan penyedap secukupnya.
1. Lumuri ayam dengan campuran tepung maizena, lalu goreng hingga matang.
1. Ulek bumbu halus kasar, lalu tumis menggunakan api sedang.
1. Tambahkan 10 ml air
1. Tambahkan garam, gula merah dan penyedap rasa sesuai selera.
1. Masukkan bumbu kasar, hingga air surut.
1. Masukkan ayam ke dalam bumbu, aduk hingga rata.
1. Tambahkan daun kemangi, aduk rata. Diamkan hingga bumbu meresap kurang lebih 3 menit.
1. Ayam siap disajikaaan 🎉




Demikianlah cara membuat ayam rica rica kemangi yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
