---
description: "Cara menyiapakan Ayam Rica Rica Kemangi Favorite"
title: "Cara menyiapakan Ayam Rica Rica Kemangi Favorite"
slug: 325-cara-menyiapakan-ayam-rica-rica-kemangi-favorite
date: 2020-11-04T22:53:14.195Z
image: https://img-global.cpcdn.com/recipes/a86eddde338b08df/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a86eddde338b08df/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a86eddde338b08df/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Curtis Davidson
ratingvalue: 4.6
reviewcount: 42278
recipeingredient:
- "5 potong ayam"
- "3 kentang"
- " Kemangi"
- " Daun bawang"
- "Sedikit santan"
- " Bumbu"
- "5 bawang merah"
- "3 bawang putih"
- "10 cabe merah besar"
- "5 cabe rawit"
- "1 kunyit"
- " Daun salam"
- " Sereh"
- "1 lengkuas"
- "1 kemiri"
- " Garam dan gula"
recipeinstructions:
- "Cuci bersih semua bahan."
- "Rebus ayam hingga matang."
- "Haluskan bawang merah, bawang putih, kemiri, kunyit, cabe merah besar dan cabe rawit. Geprek lengkuas dan sereh."
- "Panaskan minyak, masukkan bumbu halus, lengkuas, sereh, daun salam, gula,dan garam. Tumis hingga harum. Tambahkan air, aduk hingga rata."
- "Masukkan ayam dan daun bawang yg sudah direbus. Aduk hingga rata"
- "Saat bumbu sudah meresap tuangkan sedikit santan dan daun kemangi. Aduk hingga rata jangan lupa dibolak balik. Masak hingga semuanya matang."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 194 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/a86eddde338b08df/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang setidaknya kita jaga karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica rica kemangi yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa keistimewahan yang merupakan keragaman Nusantara



Keharmonisan rumah tangga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Ayam Rica Rica Kemangi untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang dapat anda contoh salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 16 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Siapkan 5 potong ayam
1. Jangan lupa 3 kentang
1. Dibutuhkan  Kemangi
1. Diperlukan  Daun bawang
1. Jangan lupa Sedikit santan
1. Diperlukan  Bumbu
1. Harap siapkan 5 bawang merah
1. Harus ada 3 bawang putih
1. Siapkan 10 cabe merah besar
1. Harus ada 5 cabe rawit
1. Jangan lupa 1 kunyit
1. Jangan lupa  Daun salam
1. Jangan lupa  Sereh
1. Siapkan 1 lengkuas
1. Siapkan 1 kemiri
1. Dibutuhkan  Garam dan gula




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica Kemangi:

1. Cuci bersih semua bahan.
1. Rebus ayam hingga matang.
1. Haluskan bawang merah, bawang putih, kemiri, kunyit, cabe merah besar dan cabe rawit. Geprek lengkuas dan sereh.
1. Panaskan minyak, masukkan bumbu halus, lengkuas, sereh, daun salam, gula,dan garam. Tumis hingga harum. Tambahkan air, aduk hingga rata.
1. Masukkan ayam dan daun bawang yg sudah direbus. Aduk hingga rata
1. Saat bumbu sudah meresap tuangkan sedikit santan dan daun kemangi. Aduk hingga rata jangan lupa dibolak balik. Masak hingga semuanya matang.




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
