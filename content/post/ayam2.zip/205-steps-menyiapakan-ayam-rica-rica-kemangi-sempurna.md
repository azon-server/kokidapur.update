---
description: "Steps menyiapakan Ayam Rica Rica Kemangi Sempurna"
title: "Steps menyiapakan Ayam Rica Rica Kemangi Sempurna"
slug: 205-steps-menyiapakan-ayam-rica-rica-kemangi-sempurna
date: 2020-09-08T01:41:37.688Z
image: https://img-global.cpcdn.com/recipes/5709beb1e5fe12a9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5709beb1e5fe12a9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5709beb1e5fe12a9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Nicholas Lloyd
ratingvalue: 4.9
reviewcount: 29377
recipeingredient:
- "8 potong ayam"
- " Jeruk nipis"
- " Garam"
- " Gula"
- " Lada"
- " Kaldu jamur non msg"
- "2 Sereh geprek"
- "2 cm Laos geprek"
- "2 ikat Kemangi petiki"
- "4 bh Daun jeruk sobek"
- "2 lbr Daun salam"
- " Minyak goreng"
- " Air"
- " Bumbu halus "
- "5 siung Bawang merah"
- "3 siung bawang putih"
- "2 cm Kunyit"
- "2 cm jahe"
- "2 butir kemiri"
- "8 bh cabe merah keriting"
- "5 bh rawit merah"
recipeinstructions:
- "Cuci bersih ayam, marinasi dg air jeruk nipis. Bilas. Pisahkan."
- "Tumis bumbu halus dg minyak goreng bersama sereh, laos, daun jeruk, daun salam hingga wangi"
- "Setelah wangi, masukkan ayam. Aduk rata bolak balik. Biarkan meresap. Lalu tambahkan air secukupnya. Sy kira2 2 gelas air."
- "Tambahkan garam, gula, lada, kaldu jamur. Aduk rata. Biarkan kuah menyusut dan mengental. Pastikan ayam matang."
- "Sesaat sblm diangkat masukkan kemangi. Lalu matikan api. Siap dihidangkan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 295 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT59M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/5709beb1e5fe12a9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang dapat kita jaga karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica rica kemangi yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa ciri khas yang merupakan keragaman Kita

Kehangatan keluarga bisa ditemukan dengan cara mudah. Salah satunya adalah memasak Ayam Rica Rica Kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang bisa anda coba salah satunya ayam rica rica kemangi yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi:

1. Harus ada 8 potong ayam
1. Harap siapkan  Jeruk nipis
1. Harus ada  Garam
1. Siapkan  Gula
1. Harap siapkan  Lada
1. Siapkan  Kaldu jamur non msg
1. Jangan lupa 2 Sereh, geprek
1. Jangan lupa 2 cm Laos, geprek
1. Harus ada 2 ikat Kemangi, petiki
1. Harus ada 4 bh Daun jeruk, sobek
1. Diperlukan 2 lbr Daun salam
1. Harus ada  Minyak goreng
1. Harus ada  Air
1. Harus ada  Bumbu halus :
1. Diperlukan 5 siung Bawang merah
1. Dibutuhkan 3 siung bawang putih
1. Tambah 2 cm Kunyit
1. Diperlukan 2 cm jahe
1. Diperlukan 2 butir kemiri
1. Siapkan 8 bh cabe merah keriting
1. Diperlukan 5 bh rawit merah




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica Kemangi:

1. Cuci bersih ayam, marinasi dg air jeruk nipis. Bilas. Pisahkan.
1. Tumis bumbu halus dg minyak goreng bersama sereh, laos, daun jeruk, daun salam hingga wangi
1. Setelah wangi, masukkan ayam. Aduk rata bolak balik. Biarkan meresap. Lalu tambahkan air secukupnya. Sy kira2 2 gelas air.
1. Tambahkan garam, gula, lada, kaldu jamur. Aduk rata. Biarkan kuah menyusut dan mengental. Pastikan ayam matang.
1. Sesaat sblm diangkat masukkan kemangi. Lalu matikan api. Siap dihidangkan




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan cepat, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
