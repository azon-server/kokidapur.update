---
description: "Resep : 95. Ayam Rica-Rica Kemangi Sempurna"
title: "Resep : 95. Ayam Rica-Rica Kemangi Sempurna"
slug: 194-resep-95-ayam-rica-rica-kemangi-sempurna
date: 2021-01-06T11:38:03.605Z
image: https://img-global.cpcdn.com/recipes/d701e73905430287/751x532cq70/95-ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d701e73905430287/751x532cq70/95-ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d701e73905430287/751x532cq70/95-ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Cory Daniels
ratingvalue: 4.9
reviewcount: 17941
recipeingredient:
- " Ayam potong baluri kunyit bubuk air jeruk nispis  garam"
- " Bumbu Halus"
- "1 ons cabe kriting"
- "1/2 ons cabe rawit me 7 biji aja gk berani mkn pedas "
- "5 siung bawang merah"
- "5 siung bawang putih"
- "2 cm jahe"
- "Sedikit kunyit"
- "3 butir kemiri"
- "2 cm lengkuas"
- " Bahan Kasar"
- "3 batang serai geprak"
- "1 lembar daun pandan simpul"
- "5 lembar daun salam"
- "5 lembar daun jeruk iris halus"
- "2 ikat kemangi petiki"
- "Secukupnya garam dan penyedap rasa"
- "secukupnya Air matang"
recipeinstructions:
- "Rebus ayam untuk membuang amis. Kemudian marinasi. Lalu goreng ayam setengah matang."
- "Blender semua bahan bumbu halus lalu tmis bumbu halus sampai wangi masukan daun jeruk, daun salam, daun pandan dan serai."
- "Kemudiam masukan ayam yg sudah digoreng setengah matang tadi. Aduk2 sampai bumbu tercampur rata. Tambahkan air secukupnya"
- "Masukan garam dan penyedap secukupnya. Masak sampai ayam empuk kurang lebih stgah jam."
- "Setelah ayam empuk dan kuah mengering masukan daun kemangi dan daun bawang, aduk hingga layu. Ayam rica rica siap dihidangkan dengan nasi panas bersama lalapan."
categories:
- Recipe
tags:
- 95
- ayam
- ricarica

katakunci: 95 ayam ricarica 
nutrition: 121 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT37M"
recipeyield: "4"
recipecategory: Lunch

---


![95. Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/d701e73905430287/751x532cq70/95-ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti 95. ayam rica-rica kemangi yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Nusantara



Kehangatan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan 95. Ayam Rica-Rica Kemangi untuk keluarga. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang bisa anda buat salah satunya 95. ayam rica-rica kemangi yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep 95. ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep 95. Ayam Rica-Rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 95. Ayam Rica-Rica Kemangi:

1. Siapkan  Ayam potong (baluri kunyit bubuk, air jeruk nispis &amp; garam)
1. Harap siapkan  Bumbu Halus
1. Diperlukan 1 ons cabe kriting
1. Jangan lupa 1/2 ons cabe rawit (me: 7 biji aja.. gk berani mkn pedas 🤭)
1. Harap siapkan 5 siung bawang merah
1. Tambah 5 siung bawang putih
1. Diperlukan 2 cm jahe
1. Dibutuhkan Sedikit kunyit
1. Jangan lupa 3 butir kemiri
1. Tambah 2 cm lengkuas
1. Jangan lupa  Bahan Kasar
1. Jangan lupa 3 batang serai geprak
1. Diperlukan 1 lembar daun pandan simpul
1. Jangan lupa 5 lembar daun salam
1. Jangan lupa 5 lembar daun jeruk iris halus
1. Dibutuhkan 2 ikat kemangi, petiki
1. Diperlukan Secukupnya garam dan penyedap rasa
1. Diperlukan secukupnya Air matang




<!--inarticleads2-->

##### Cara membuat  95. Ayam Rica-Rica Kemangi:

1. Rebus ayam untuk membuang amis. Kemudian marinasi. Lalu goreng ayam setengah matang.
1. Blender semua bahan bumbu halus lalu tmis bumbu halus sampai wangi masukan daun jeruk, daun salam, daun pandan dan serai.
1. Kemudiam masukan ayam yg sudah digoreng setengah matang tadi. Aduk2 sampai bumbu tercampur rata. Tambahkan air secukupnya
1. Masukan garam dan penyedap secukupnya. Masak sampai ayam empuk kurang lebih stgah jam.
1. Setelah ayam empuk dan kuah mengering masukan daun kemangi dan daun bawang, aduk hingga layu. Ayam rica rica siap dihidangkan dengan nasi panas bersama lalapan.




Demikianlah cara membuat 95. ayam rica-rica kemangi yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
