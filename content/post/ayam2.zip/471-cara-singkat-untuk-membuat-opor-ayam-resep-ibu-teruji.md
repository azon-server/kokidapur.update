---
description: "Cara singkat untuk membuat Opor Ayam resep Ibu Teruji"
title: "Cara singkat untuk membuat Opor Ayam resep Ibu Teruji"
slug: 471-cara-singkat-untuk-membuat-opor-ayam-resep-ibu-teruji
date: 2020-09-08T02:39:22.035Z
image: https://img-global.cpcdn.com/recipes/881e45927470c08a/751x532cq70/opor-ayam-resep-ibu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/881e45927470c08a/751x532cq70/opor-ayam-resep-ibu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/881e45927470c08a/751x532cq70/opor-ayam-resep-ibu-foto-resep-utama.jpg
author: Eva Hall
ratingvalue: 4.5
reviewcount: 8502
recipeingredient:
- "1 ekor ayam kampung potong sesuai selera"
- "100 ml santan instant sy kara"
- "500 ml air"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "4 butir kemiri"
- "1 sdt merica bubuk"
- "1 jari kunyit"
- "3 lbr daun salam"
- "3 lbr daun jeruk purut"
- "3 batang serai geprek"
- "2 jari jahe geprek"
- " Lengkuas"
- " Gula merah 50 gr"
- "2 sdm gula pasir"
- "1/2 sdm garam"
- "1 sdt kaldu jamur"
- " Bawang goreng"
- " Minyak untuk menumis"
recipeinstructions:
- "Rebus ayam dengan 500 ml air sampai empuk"
- "Haluskan bumbu, bawang merah, bawang putih, kemiri, kunyit"
- "Tumis bumbu hingga harum dengan sedikit minyak, masukkan merica bubuk. daun salam, daun jeruk, jahe, serai, lengkuas"
- "Tuang tumisan bumbu kedalam rebusan ayam, masukkan santan, gula merah, gula pasir, kaldu jamur, garam, koreksi rasa (saya suka manis).Masak dengan api kecil sampai ayam empuk (jgn sampai hancur ya) dan bumbu meresap"
- "Hidangkan dengan taburan bawang goreng"
categories:
- Recipe
tags:
- opor
- ayam
- resep

katakunci: opor ayam resep 
nutrition: 134 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Lunch

---


![Opor Ayam resep Ibu](https://img-global.cpcdn.com/recipes/881e45927470c08a/751x532cq70/opor-ayam-resep-ibu-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti opor ayam resep ibu yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa ciri khas yang merupakan keragaman Indonesia



Kehangatan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah memasak Opor Ayam resep Ibu untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang dapat anda contoh salah satunya opor ayam resep ibu yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep opor ayam resep ibu tanpa harus bersusah payah.
Berikut ini resep Opor Ayam resep Ibu yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 19 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Opor Ayam resep Ibu:

1. Diperlukan 1 ekor ayam kampung, potong sesuai selera
1. Siapkan 100 ml santan instant (sy kara)
1. Harus ada 500 ml air
1. Harap siapkan 8 siung bawang merah
1. Harus ada 5 siung bawang putih
1. Tambah 4 butir kemiri
1. Dibutuhkan 1 sdt merica bubuk
1. Dibutuhkan 1 jari kunyit
1. Dibutuhkan 3 lbr daun salam
1. Dibutuhkan 3 lbr daun jeruk purut
1. Tambah 3 batang serai, geprek
1. Harus ada 2 jari jahe, geprek
1. Harap siapkan  Lengkuas
1. Tambah  Gula merah (50 gr)
1. Harus ada 2 sdm gula pasir
1. Harus ada 1/2 sdm garam
1. Tambah 1 sdt kaldu jamur
1. Jangan lupa  Bawang goreng
1. Harus ada  Minyak untuk menumis




<!--inarticleads2-->

##### Instruksi membuat  Opor Ayam resep Ibu:

1. Rebus ayam dengan 500 ml air sampai empuk
1. Haluskan bumbu, bawang merah, bawang putih, kemiri, kunyit
1. Tumis bumbu hingga harum dengan sedikit minyak, masukkan merica bubuk. daun salam, daun jeruk, jahe, serai, lengkuas
1. Tuang tumisan bumbu kedalam rebusan ayam, masukkan santan, gula merah, gula pasir, kaldu jamur, garam, koreksi rasa (saya suka manis).Masak dengan api kecil sampai ayam empuk (jgn sampai hancur ya) dan bumbu meresap
1. Hidangkan dengan taburan bawang goreng




Demikianlah cara membuat opor ayam resep ibu yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan terbukti, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
