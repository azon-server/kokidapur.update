---
description: "Resep : Ayam rica kemangi Homemade"
title: "Resep : Ayam rica kemangi Homemade"
slug: 174-resep-ayam-rica-kemangi-homemade
date: 2020-08-10T01:44:34.432Z
image: https://img-global.cpcdn.com/recipes/23de41188d65059d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/23de41188d65059d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/23de41188d65059d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Katharine Carlson
ratingvalue: 4.8
reviewcount: 37237
recipeingredient:
- "5 potong ayam"
- "1 bh jeruk nipis"
- "1 bh tomat potong kecil"
- "1 ruas jahe digeprek"
- "1 ruas lengkuas digeprek"
- "1 bh sereh digeprek"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "3 ikat daun kemangi"
- "1 batang daun bawang"
- " Bumbu halus"
- "20 bh cabe merah keriting"
- "15 bh cabe rawit merah"
- "10 bh bawang merah"
- "5 bh bawang putih"
- "3 bh kemiri"
- "Sedikit kunyit"
- "Secukupnya garam gula"
recipeinstructions:
- "Cuci bersih ayam, lalu lumuri dengan perasan air jeruk nipis, diamkan sebentar.."
- "Goreng ayam setengah matang, sisihkan.."
- "Tumis bumbu halus hingga harum, lalu masukan daun salam, daun jeruk, jahe, lengkuas, sereh.. tumis lagi hingga matang.."
- "Tambahkan ayam dan sedikit air, aduk rata dengan api kecil hingga bumbu meresap"
- "Masukan gula, garam, daun kemangi, tomat, aduk rata.."
- "Cek rasa.. dan siap disajikan ☺️"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 224 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/23de41188d65059d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica kemangi yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa kesan tersendiri yang merupakan keragaman Nusantara

Kedekatan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah membuat makanan Ayam rica kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang dapat anda coba salah satunya ayam rica kemangi yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica kemangi:

1. Dibutuhkan 5 potong ayam
1. Diperlukan 1 bh jeruk nipis
1. Jangan lupa 1 bh tomat potong kecil
1. Harap siapkan 1 ruas jahe digeprek
1. Harap siapkan 1 ruas lengkuas digeprek
1. Jangan lupa 1 bh sereh digeprek
1. Tambah 3 lembar daun salam
1. Harus ada 3 lembar daun jeruk
1. Harus ada 3 ikat daun kemangi
1. Dibutuhkan 1 batang daun bawang
1. Harap siapkan  Bumbu halus::
1. Diperlukan 20 bh cabe merah keriting
1. Dibutuhkan 15 bh cabe rawit merah
1. Harus ada 10 bh bawang merah
1. Jangan lupa 5 bh bawang putih
1. Siapkan 3 bh kemiri
1. Jangan lupa Sedikit kunyit
1. Jangan lupa Secukupnya garam gula


Perlu kamu ketahui bahwa di luar negeri mungkin daun basil sangat terkenal untuk campuran makanan. Akan tetapi, di Indonesia juga memiliki daun kemangi merupakan. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica kemangi:

1. Cuci bersih ayam, lalu lumuri dengan perasan air jeruk nipis, diamkan sebentar..
1. Goreng ayam setengah matang, sisihkan..
1. Tumis bumbu halus hingga harum, lalu masukan daun salam, daun jeruk, jahe, lengkuas, sereh.. tumis lagi hingga matang..
1. Tambahkan ayam dan sedikit air, aduk rata dengan api kecil hingga bumbu meresap
1. Masukan gula, garam, daun kemangi, tomat, aduk rata..
1. Cek rasa.. dan siap disajikan ☺️


Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. Cara Membuat Ayam Rica Rica Kemangi. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat. 

Demikianlah cara membuat ayam rica kemangi yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
