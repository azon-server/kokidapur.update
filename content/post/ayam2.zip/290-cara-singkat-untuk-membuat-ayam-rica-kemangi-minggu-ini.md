---
description: "Cara singkat untuk membuat Ayam Rica Kemangi 🐔 minggu ini"
title: "Cara singkat untuk membuat Ayam Rica Kemangi 🐔 minggu ini"
slug: 290-cara-singkat-untuk-membuat-ayam-rica-kemangi-minggu-ini
date: 2020-08-09T16:12:05.480Z
image: https://img-global.cpcdn.com/recipes/92d5f9fb80090310/751x532cq70/ayam-rica-kemangi-🐔-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/92d5f9fb80090310/751x532cq70/ayam-rica-kemangi-🐔-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/92d5f9fb80090310/751x532cq70/ayam-rica-kemangi-🐔-foto-resep-utama.jpg
author: Danny Palmer
ratingvalue: 5
reviewcount: 12518
recipeingredient:
- "6 Potong Ayam"
- " Bumbu "
- " Cabe rawit sesuai selera"
- "10 buah Cabe Keriting"
- "3 Siung bawah putih"
- "2 Siung bawang merah"
- "2 buah daun bawang"
- "3 lembar daun salam"
- "1 buah sereh"
- " Daun Kemangi secukupnya"
- " Penyedap garamgula"
recipeinstructions:
- "Rebus ayam dan bumbui dengan garam."
- "Selagi menunggu ayam direbus, haluskan cabe rawit, cabe keriting, bawang putih, bawang merah."
- "Goreng ayam yang telah direbus tadi. Sampai berwarna kuning kecoklatan."
- "Siapkan wajan untuk mulai memasak. Tuangkan minyak secukupnya. Tunggu sampai panas."
- "Masukkan bumbu halus yang tadi. Dengan tambahkan potongan daun bawang, daun salam, dan sereh yang sudah di geprek. Tumis hingga wangi."
- "Setelah bumbu terasa matang, masukkan potongan ayam yang telah di goreng tadi dan tambahkan air agar bumbu meresap."
- "Bumbui dengan garam dan gula, dan tunggu hingga meresap."
- "Setelah dibumbui, terakhir masukkan daun kemangi. Aduk hingga merata."
- "Jika bumbu dirasa cukup, matikan kompor dan Ayam rica kemangi siap dihidangkan."
- "Selamat mencoba :)"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 273 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT41M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica Kemangi 🐔](https://img-global.cpcdn.com/recipes/92d5f9fb80090310/751x532cq70/ayam-rica-kemangi-🐔-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau empuk. Ciri masakan Nusantara ayam rica kemangi 🐔 yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Ayam Rica Kemangi 🐔 untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis makanan yang bisa anda contoh salah satunya ayam rica kemangi 🐔 yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep ayam rica kemangi 🐔 tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi 🐔 yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 10 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi 🐔:

1. Harus ada 6 Potong Ayam
1. Harus ada  Bumbu :
1. Harus ada  Cabe rawit (sesuai selera)
1. Siapkan 10 buah Cabe Keriting
1. Siapkan 3 Siung bawah putih
1. Diperlukan 2 Siung bawang merah
1. Diperlukan 2 buah daun bawang
1. Tambah 3 lembar daun salam
1. Tambah 1 buah sereh
1. Harap siapkan  Daun Kemangi (secukupnya)
1. Harus ada  Penyedap (garam+gula)




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Kemangi 🐔:

1. Rebus ayam dan bumbui dengan garam.
1. Selagi menunggu ayam direbus, haluskan cabe rawit, cabe keriting, bawang putih, bawang merah.
1. Goreng ayam yang telah direbus tadi. Sampai berwarna kuning kecoklatan.
1. Siapkan wajan untuk mulai memasak. Tuangkan minyak secukupnya. Tunggu sampai panas.
1. Masukkan bumbu halus yang tadi. Dengan tambahkan potongan daun bawang, daun salam, dan sereh yang sudah di geprek. Tumis hingga wangi.
1. Setelah bumbu terasa matang, masukkan potongan ayam yang telah di goreng tadi dan tambahkan air agar bumbu meresap.
1. Bumbui dengan garam dan gula, dan tunggu hingga meresap.
1. Setelah dibumbui, terakhir masukkan daun kemangi. Aduk hingga merata.
1. Jika bumbu dirasa cukup, matikan kompor dan Ayam rica kemangi siap dihidangkan.
1. Selamat mencoba :)




Demikianlah cara membuat ayam rica kemangi 🐔 yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan cepat, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
