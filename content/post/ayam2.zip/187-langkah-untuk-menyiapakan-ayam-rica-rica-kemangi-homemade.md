---
description: "Langkah untuk menyiapakan Ayam rica rica kemangi Homemade"
title: "Langkah untuk menyiapakan Ayam rica rica kemangi Homemade"
slug: 187-langkah-untuk-menyiapakan-ayam-rica-rica-kemangi-homemade
date: 2020-10-04T21:20:27.414Z
image: https://img-global.cpcdn.com/recipes/e9e4e53b8aff3da7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e9e4e53b8aff3da7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e9e4e53b8aff3da7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Justin Quinn
ratingvalue: 4.9
reviewcount: 1155
recipeingredient:
- "500 gr daging ayam marinasi dengan 1 ruas kunyit  12 sdt garam  3siung bawang putih uleg halus diamkan 15 menit"
- "1 ikat daun kemangi"
- "3 btg daun bawang diiris"
- "250 ml air"
- " Bumbu halus"
- "7 siung bawang putih"
- "8 siung bawang merah"
- "1 ruas jahe"
- "4 cabe rawit"
- "2 btr kemiri100 gr cabe merah besar"
- " Bumbu cemplung"
- "2 btg serai digeprek"
- "1 ruas lengkuas digeprek"
- "7 lmbr daun jeruk purut"
- "3 lembar daun salam"
- "1 sdt garam"
- "1 sdt kaldu bubuk"
- "2 sdt gula pasir"
recipeinstructions:
- "Haluskan bumbu saya pakai cooper bisa juga diuleg"
- "Goreng ayam yg sudah dimarinasi 1/2 matang saja angkat tiriskan"
- "Panaskan minyak masukkan bumbu halus, bumbu cemplung, tumis hingga bumbu tanak"
- "Masukkan ayam goreng aduk rata"
- "Masukkan air aduk rata lalu tutup masak dengan api kecil hingga kuah agak menyusut"
- "Masukkan garam, kaldu bubuk, gula pasir aduk rata"
- "Masukkan daun bawang aduk rata"
- "Masukkan daun kemangi aduk sebentar lalu matikan kompor"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 115 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT40M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/e9e4e53b8aff3da7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga empuk. Ciri khas masakan Nusantara ayam rica rica kemangi yang penuh dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga dapat diperoleh dengan cara simple. Diantaranya adalah memasak Ayam rica rica kemangi untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang bisa anda contoh salah satunya ayam rica rica kemangi yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Jangan lupa 500 gr daging ayam marinasi dengan (1 ruas kunyit + 1/2 sdt garam + 3siung bawang putih uleg halus) diamkan 15 menit
1. Siapkan 1 ikat daun kemangi
1. Tambah 3 btg daun bawang diiris
1. Diperlukan 250 ml air
1. Harap siapkan  Bumbu halus
1. Jangan lupa 7 siung bawang putih
1. Jangan lupa 8 siung bawang merah
1. Jangan lupa 1 ruas jahe
1. Harap siapkan 4 cabe rawit
1. Jangan lupa 2 btr kemiri100 gr cabe merah besar
1. Diperlukan  Bumbu cemplung
1. Tambah 2 btg serai digeprek
1. Harap siapkan 1 ruas lengkuas digeprek
1. Siapkan 7 lmbr daun jeruk purut
1. Harap siapkan 3 lembar daun salam
1. Tambah 1 sdt garam
1. Jangan lupa 1 sdt kaldu bubuk
1. Siapkan 2 sdt gula pasir




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica rica kemangi:

1. Haluskan bumbu saya pakai cooper bisa juga diuleg
1. Goreng ayam yg sudah dimarinasi 1/2 matang saja angkat tiriskan
1. Panaskan minyak masukkan bumbu halus, bumbu cemplung, tumis hingga bumbu tanak
1. Masukkan ayam goreng aduk rata
1. Masukkan air aduk rata lalu tutup masak dengan api kecil hingga kuah agak menyusut
1. Masukkan garam, kaldu bubuk, gula pasir aduk rata
1. Masukkan daun bawang aduk rata
1. Masukkan daun kemangi aduk sebentar lalu matikan kompor




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan cepat, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
