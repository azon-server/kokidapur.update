---
description: "Cara untuk membuat 6. AYAM RICA-RICA DAUN KEMANGI Cepat"
title: "Cara untuk membuat 6. AYAM RICA-RICA DAUN KEMANGI Cepat"
slug: 364-cara-untuk-membuat-6-ayam-rica-rica-daun-kemangi-cepat
date: 2020-08-15T14:22:03.481Z
image: https://img-global.cpcdn.com/recipes/653e17a05e7f2b2f/751x532cq70/6-ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/653e17a05e7f2b2f/751x532cq70/6-ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/653e17a05e7f2b2f/751x532cq70/6-ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: James Terry
ratingvalue: 4.4
reviewcount: 35596
recipeingredient:
- "1 kg Ayam"
- "1 bh Jeruk nipis"
- " Kemangi"
- " Garam"
- " Gula"
- "1 bh Sereh"
- "3 lbr Daun salam"
- " Air"
- " Minyak goreng"
- " Bumbu halus"
- "7 bh Cabe merah"
- "10 bh Cabe rawit optional"
- "5 btr Bawang merah"
- "3 btr Bawang putih"
- "4 bh Kemiri"
- "1 bh Kunyit"
recipeinstructions:
- "Cuci bersih ayam dan beri perasan jeruk nipis."
- "Haluskan semua bumbu halus. Lalu tumis dengan menggunakan sedikit minyak."
- "Setelah bumbu harum masukan daun salam dan sereh yang telah digeprek."
- "Masukan potongan ayam kedalam bumbu halus dan beri air untuk merebus daging ayam agar matang."
- "Setelah air agak menyusut, masukan garam dan gula. Aduk hingga merata dan koreksi rasa."
- "Tambahkan kemangi dan tunggu hingga kemangi layu."
- "Ayam rica-rica kemangi siap disantap selagi hangat bersama nasi. Silahkan mencoba."
categories:
- Recipe
tags:
- 6
- ayam
- ricarica

katakunci: 6 ayam ricarica 
nutrition: 235 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Dinner

---


![6. AYAM RICA-RICA DAUN KEMANGI](https://img-global.cpcdn.com/recipes/653e17a05e7f2b2f/751x532cq70/6-ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan gurih. Ciri kuliner Nusantara 6. ayam rica-rica daun kemangi yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan keluarga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan 6. AYAM RICA-RICA DAUN KEMANGI untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang bisa anda coba salah satunya 6. ayam rica-rica daun kemangi yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep 6. ayam rica-rica daun kemangi tanpa harus bersusah payah.
Berikut ini resep 6. AYAM RICA-RICA DAUN KEMANGI yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 16 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 6. AYAM RICA-RICA DAUN KEMANGI:

1. Harap siapkan 1 kg Ayam
1. Siapkan 1 bh Jeruk nipis
1. Dibutuhkan  Kemangi
1. Harap siapkan  Garam
1. Siapkan  Gula
1. Harus ada 1 bh Sereh
1. Jangan lupa 3 lbr Daun salam
1. Harap siapkan  Air
1. Harus ada  Minyak goreng
1. Diperlukan  Bumbu halus
1. Harap siapkan 7 bh Cabe merah
1. Jangan lupa 10 bh Cabe rawit (optional)
1. Jangan lupa 5 btr Bawang merah
1. Harus ada 3 btr Bawang putih
1. Tambah 4 bh Kemiri
1. Jangan lupa 1 bh Kunyit




<!--inarticleads2-->

##### Cara membuat  6. AYAM RICA-RICA DAUN KEMANGI:

1. Cuci bersih ayam dan beri perasan jeruk nipis.
1. Haluskan semua bumbu halus. Lalu tumis dengan menggunakan sedikit minyak.
1. Setelah bumbu harum masukan daun salam dan sereh yang telah digeprek.
1. Masukan potongan ayam kedalam bumbu halus dan beri air untuk merebus daging ayam agar matang.
1. Setelah air agak menyusut, masukan garam dan gula. Aduk hingga merata dan koreksi rasa.
1. Tambahkan kemangi dan tunggu hingga kemangi layu.
1. Ayam rica-rica kemangi siap disantap selagi hangat bersama nasi. Silahkan mencoba.




Demikianlah cara membuat 6. ayam rica-rica daun kemangi yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
