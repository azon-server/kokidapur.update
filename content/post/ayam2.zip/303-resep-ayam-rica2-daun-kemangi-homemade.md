---
description: "Resep : Ayam rica2 daun kemangi Homemade"
title: "Resep : Ayam rica2 daun kemangi Homemade"
slug: 303-resep-ayam-rica2-daun-kemangi-homemade
date: 2020-10-23T02:26:22.378Z
image: https://img-global.cpcdn.com/recipes/1be1740ebe40d232/751x532cq70/ayam-rica2-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1be1740ebe40d232/751x532cq70/ayam-rica2-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1be1740ebe40d232/751x532cq70/ayam-rica2-daun-kemangi-foto-resep-utama.jpg
author: George Manning
ratingvalue: 4.4
reviewcount: 20878
recipeingredient:
- "1 ekor ayam potong2"
- "1 sdm garam"
- "1 buah jeruk nipis"
- " Minyak untuk menggoreng"
- "1 ikat daun kemangi"
- "1 ruas lengkuas geprek"
- "1 batang serai geprek"
- "4 lembar daun salam"
- "4 bawang merah iris"
- "200 ml air"
- " Bumbu halus"
- "8 bawang merah"
- "3 bawang putih"
- "8 cabai rawit merah"
- "6 cabai merah"
- "3 kemiri"
- "1 ruas jahe"
- "2 ruas kunyit"
- "1 ruas lengkuas"
- "1 sdm ketumbar"
- " Minyak untuk menumis"
- " Garam sckp nya"
- "secukupnya Penyedap"
recipeinstructions:
- "Masukkan ayam ke dalam wadah. Taburi garam dan perasan jeruk nipis. Aduk rata, diamkan ±15 menit."
- "Panaskan minya untuk menggoreng, lalu goreng ayam hingga ½ matang, sisihkan."
- "Panaskan minyak untuk menumis. Stelah panas masukkan bawang iris."
- "Setelah harum masukkan bumbu halus, daun salam, lengkuas dan serai."
- "Setelah bumbu harum, masukkan ayam, lalu aduk rata sebentar."
- "Lalu tuangkan 200ml air. Masukkan garam dan penyedap."
- "Masak hingga kuah mengental dan bumbu meresap, lalu masukkan daun kemangi."
- "Koreksi rasa, angkat lalu sajikan."
categories:
- Recipe
tags:
- ayam
- rica2
- daun

katakunci: ayam rica2 daun 
nutrition: 275 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT31M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam rica2 daun kemangi](https://img-global.cpcdn.com/recipes/1be1740ebe40d232/751x532cq70/ayam-rica2-daun-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica2 daun kemangi yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Kita

Kedekatan keluarga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam rica2 daun kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang dapat anda buat salah satunya ayam rica2 daun kemangi yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica2 daun kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica2 daun kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 23 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica2 daun kemangi:

1. Diperlukan 1 ekor ayam potong2
1. Diperlukan 1 sdm garam
1. Siapkan 1 buah jeruk nipis
1. Tambah  Minyak untuk menggoreng
1. Diperlukan 1 ikat daun kemangi
1. Tambah 1 ruas lengkuas, geprek
1. Harus ada 1 batang serai, geprek
1. Dibutuhkan 4 lembar daun salam
1. Tambah 4 bawang merah, iris
1. Siapkan 200 ml air
1. Siapkan  Bumbu halus
1. Siapkan 8 bawang merah
1. Harus ada 3 bawang putih
1. Dibutuhkan 8 cabai rawit merah
1. Harap siapkan 6 cabai merah
1. Tambah 3 kemiri
1. Harus ada 1 ruas jahe
1. Diperlukan 2 ruas kunyit
1. Tambah 1 ruas lengkuas
1. Tambah 1 sdm ketumbar
1. Jangan lupa  Minyak untuk menumis
1. Jangan lupa  Garam sckp nya
1. Diperlukan secukupnya Penyedap




<!--inarticleads2-->

##### Cara membuat  Ayam rica2 daun kemangi:

1. Masukkan ayam ke dalam wadah. Taburi garam dan perasan jeruk nipis. Aduk rata, diamkan ±15 menit.
1. Panaskan minya untuk menggoreng, lalu goreng ayam hingga ½ matang, sisihkan.
1. Panaskan minyak untuk menumis. Stelah panas masukkan bawang iris.
1. Setelah harum masukkan bumbu halus, daun salam, lengkuas dan serai.
1. Setelah bumbu harum, masukkan ayam, lalu aduk rata sebentar.
1. Lalu tuangkan 200ml air. Masukkan garam dan penyedap.
1. Masak hingga kuah mengental dan bumbu meresap, lalu masukkan daun kemangi.
1. Koreksi rasa, angkat lalu sajikan.




Demikianlah cara membuat ayam rica2 daun kemangi yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan cepat, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
