---
description: "Langkah menyiapakan Ayam Rica Kemangi Sempurna"
title: "Langkah menyiapakan Ayam Rica Kemangi Sempurna"
slug: 396-langkah-menyiapakan-ayam-rica-kemangi-sempurna
date: 2020-10-29T05:08:21.667Z
image: https://img-global.cpcdn.com/recipes/f476cf441142b8a9/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f476cf441142b8a9/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f476cf441142b8a9/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Harold Rowe
ratingvalue: 4.2
reviewcount: 30056
recipeingredient:
- " Ayam"
- "5 siung bawang putih"
- "5 siung bawang merah"
- " Ketumbar"
- " Lada bubuk"
- " Kunyit bubuk"
- "30 buah cabai setan"
- "1 ikat daun kemangi"
- "2 buah tomat"
- " Garam penyedap"
- " Minyak untuk menumis"
recipeinstructions:
- "Rebus ayam yg sudah di bersihkan. Haluskan cabai, haluskan juga bawang merah, bawang putih dan ketumbar."
- "Tumis bumbu yg di haluskan, masukan lada dan kunyit bubuk secukupnya. Lalu masukan ayam yg sudah di rebus dan tambahkan air rebusan ayam."
- "Setelah kuahnya agak mengental masukan daun kemangi dan tomat yang sudah dipotong. Masak lagi sebentar dengan api kecil"
- "Setelah daun kemangi dan tomat agak layu matikan apinya. Ayam rica kemangi siap disajikan"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 137 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/f476cf441142b8a9/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga empuk. Karasteristik masakan Indonesia ayam rica kemangi yang penuh dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.

Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang bisa anda praktekkan salah satunya ayam rica kemangi yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 11 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Harus ada  Ayam
1. Siapkan 5 siung bawang putih
1. Jangan lupa 5 siung bawang merah
1. Jangan lupa  Ketumbar
1. Tambah  Lada bubuk
1. Dibutuhkan  Kunyit bubuk
1. Tambah 30 buah cabai setan
1. Jangan lupa 1 ikat daun kemangi
1. Tambah 2 buah tomat
1. Dibutuhkan  Garam, penyedap
1. Tambah  Minyak untuk menumis


Perlu kamu ketahui bahwa di luar negeri mungkin daun basil sangat terkenal untuk campuran makanan. Akan tetapi, di Indonesia juga memiliki daun kemangi merupakan. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Kemangi:

1. Rebus ayam yg sudah di bersihkan. Haluskan cabai, haluskan juga bawang merah, bawang putih dan ketumbar.
1. Tumis bumbu yg di haluskan, masukan lada dan kunyit bubuk secukupnya. Lalu masukan ayam yg sudah di rebus dan tambahkan air rebusan ayam.
1. Setelah kuahnya agak mengental masukan daun kemangi dan tomat yang sudah dipotong. Masak lagi sebentar dengan api kecil
1. Setelah daun kemangi dan tomat agak layu matikan apinya. Ayam rica kemangi siap disajikan


Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. Cara Membuat Ayam Rica Rica Kemangi. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat. 

Demikianlah cara membuat ayam rica kemangi yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan terbukti, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
