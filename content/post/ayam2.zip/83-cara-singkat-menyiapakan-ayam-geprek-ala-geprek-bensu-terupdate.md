---
description: "Cara singkat menyiapakan AYAM GEPREK ala geprek bensu terupdate"
title: "Cara singkat menyiapakan AYAM GEPREK ala geprek bensu terupdate"
slug: 83-cara-singkat-menyiapakan-ayam-geprek-ala-geprek-bensu-terupdate
date: 2021-01-21T23:09:09.334Z
image: https://img-global.cpcdn.com/recipes/5e198be04285a23b/751x532cq70/ayam-geprek-ala-geprek-bensu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5e198be04285a23b/751x532cq70/ayam-geprek-ala-geprek-bensu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5e198be04285a23b/751x532cq70/ayam-geprek-ala-geprek-bensu-foto-resep-utama.jpg
author: Sue Washington
ratingvalue: 4.8
reviewcount: 30641
recipeingredient:
- "1 ayam ukuran besar potong 8"
- "35 buah cabe rawit merah"
- "3 siung bawang putih"
- "1 sdt garam"
- "1 sdt penyedap rasa sasa"
- "3 bks kobe tepung krispy"
- "1 buah jeruk nipis"
- "25 gram keju parut sesuai selera"
recipeinstructions:
- "Cuci bersih ayam dengan air mengalir lalu garis&#34;in ayam dengan pisau di tiap sisi supaya bumbu menyerap"
- "Baluri ayam dengan perasan jeruk nipis, aduk hingga merata dan diamkan selama ±5 menit"
- "Cuci bersih cabe dan bawang lalu ulek kasar dan beri garam dan penyedap rasa secukupnya dan ulek kembali, setelah selesai pindahkan ke piring"
- "Siapkan bahan celupannya.. Ambil 4 sdm tepung bumbu kobe lalu beri air secukupnya, jangan terlalu cair dan jangan terlalu kental, lalu baluri ayam dengan merata sampai ke garis&#34; pisau tadi lalu masukan ke tepung bumbu yg kering. Baluri hingga merata"
- "Goreng dengan minyak yg banyak dan api kecil, agar matang merata"
- "Goreng hingga tepung berubah warna kecoklat emasan, angkat lalu tiriskan.."
- "Geprek ayam dengan ulekan hingga hancur (sesuai selera) beri sambal secukupnya di atasnya lalu geprek lagi, begitu seterusnya hingga ayam dan sambal habis"
- "Hidangkan di piring dan taburi dengan keju parut sesuai selera"
- "Di makan saat hangat dengan nasi dan lalapan emang paling enak.. 😍😍"
- "Selamat mencoba bunda... 😊😘"
categories:
- Recipe
tags:
- ayam
- geprek
- ala

katakunci: ayam geprek ala 
nutrition: 272 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Dinner

---


![AYAM GEPREK ala geprek bensu](https://img-global.cpcdn.com/recipes/5e198be04285a23b/751x532cq70/ayam-geprek-ala-geprek-bensu-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam geprek ala geprek bensu yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan kesan tersendiri yang merupakan keragaman Kita

Kehangatan rumah tangga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan AYAM GEPREK ala geprek bensu untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda coba salah satunya ayam geprek ala geprek bensu yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep ayam geprek ala geprek bensu tanpa harus bersusah payah.
Berikut ini resep AYAM GEPREK ala geprek bensu yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 10 langkah dan 8 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat AYAM GEPREK ala geprek bensu:

1. Jangan lupa 1 ayam ukuran besar (potong 8)
1. Diperlukan 35 buah cabe rawit merah
1. Siapkan 3 siung bawang putih
1. Diperlukan 1 sdt garam
1. Tambah 1 sdt penyedap rasa (sasa)
1. Jangan lupa 3 bks kobe tepung krispy
1. Tambah 1 buah jeruk nipis
1. Harus ada 25 gram keju parut (sesuai selera)




<!--inarticleads2-->

##### Cara membuat  AYAM GEPREK ala geprek bensu:

1. Cuci bersih ayam dengan air mengalir lalu garis&#34;in ayam dengan pisau di tiap sisi supaya bumbu menyerap
1. Baluri ayam dengan perasan jeruk nipis, aduk hingga merata dan diamkan selama ±5 menit
1. Cuci bersih cabe dan bawang lalu ulek kasar dan beri garam dan penyedap rasa secukupnya dan ulek kembali, setelah selesai pindahkan ke piring
1. Siapkan bahan celupannya.. Ambil 4 sdm tepung bumbu kobe lalu beri air secukupnya, jangan terlalu cair dan jangan terlalu kental, lalu baluri ayam dengan merata sampai ke garis&#34; pisau tadi lalu masukan ke tepung bumbu yg kering. Baluri hingga merata
1. Goreng dengan minyak yg banyak dan api kecil, agar matang merata
1. Goreng hingga tepung berubah warna kecoklat emasan, angkat lalu tiriskan..
1. Geprek ayam dengan ulekan hingga hancur (sesuai selera) beri sambal secukupnya di atasnya lalu geprek lagi, begitu seterusnya hingga ayam dan sambal habis
1. Hidangkan di piring dan taburi dengan keju parut sesuai selera
1. Di makan saat hangat dengan nasi dan lalapan emang paling enak.. 😍😍
1. Selamat mencoba bunda... 😊😘




Demikianlah cara membuat ayam geprek ala geprek bensu yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
