---
description: "Bagaimana untuk membuat Ayam Rica-Rica Kemangi terupdate"
title: "Bagaimana untuk membuat Ayam Rica-Rica Kemangi terupdate"
slug: 185-bagaimana-untuk-membuat-ayam-rica-rica-kemangi-terupdate
date: 2020-11-17T10:43:56.140Z
image: https://img-global.cpcdn.com/recipes/d289ac8f7d557a20/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d289ac8f7d557a20/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d289ac8f7d557a20/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Ricardo Watts
ratingvalue: 4.3
reviewcount: 15897
recipeingredient:
- "1 ekor ayam kampung"
- "2 buah jeruk nipis"
- " Bahan Bumbu"
- "6 siung bawang putih"
- "10 biji bawang merah"
- "10-15 cabe rawit selera"
- "1 ruas jahe"
- "1 ruas kunyit"
- " Lengkuas sedikit saja"
- "2 batang sereh"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- " Bahan Pelengkap"
- "3 pohon kemangi ambil daunnya saja"
- "2 batang daun bawang"
- "3 sdm minyak goreng"
- "1 sdm garam"
- "1 sdt gula"
- "1 sdm kaldu bubuk"
- "1 sdt merica"
recipeinstructions:
- "Potong ayam sesuai selera (saya potong kecil² supaya bumbu cepat meresap) lalu lumuri dgn jeruk nipis dan garam. Diamkan selama kurang lebih 15 menit."
- "Setelah ayam dicuci bersih, goreng ayam sebentar diatas teflon. Ini selera ya, tdk digoreng jg gapapa. Setelah digoreng, lalu tiriskan."
- "Blender semua bahan bumbu, kecuali sereh, daun salam, daun jeruk dan lengkuas."
- "Setelah bumbu halus, panaskan minyak goreng, masukkan bumbu halus beserta lengkuas dan batang sereh yg sudah di geprek, daun salam dan daun jeruk. Aduk sebentar sampai wangi. Lalu tambahkan sedikit air."
- "Setelah itu, masukkan ayam. Aduk sampai bumbu tercampur rata. Diamkan sebentar supaya bumbu meresap dan air mulai menyusut."
- "Setelah air menyusut dan ayam empuk, masukkan kemangi dan daun bawang. Aduk sebentar lalu matikan api."
- "Ayam rica-rica siap dihidangkan bersama nasi hangat dan lalapan mentimun/selada."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 216 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/d289ac8f7d557a20/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Kita



Keharmonisan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah memasak Ayam Rica-Rica Kemangi untuk keluarga. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang bisa anda buat salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Kemangi:

1. Harus ada 1 ekor ayam kampung
1. Harus ada 2 buah jeruk nipis
1. Tambah  Bahan Bumbu
1. Dibutuhkan 6 siung bawang putih
1. Harus ada 10 biji bawang merah
1. Tambah 10-15 cabe rawit (selera)
1. Jangan lupa 1 ruas jahe
1. Harap siapkan 1 ruas kunyit
1. Diperlukan  Lengkuas sedikit saja
1. Tambah 2 batang sereh
1. Tambah 2 lembar daun salam
1. Jangan lupa 2 lembar daun jeruk
1. Diperlukan  Bahan Pelengkap
1. Harap siapkan 3 pohon kemangi, ambil daunnya saja
1. Harus ada 2 batang daun bawang
1. Diperlukan 3 sdm minyak goreng
1. Dibutuhkan 1 sdm garam
1. Jangan lupa 1 sdt gula
1. Diperlukan 1 sdm kaldu bubuk
1. Harap siapkan 1 sdt merica




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica Kemangi:

1. Potong ayam sesuai selera (saya potong kecil² supaya bumbu cepat meresap) lalu lumuri dgn jeruk nipis dan garam. Diamkan selama kurang lebih 15 menit.
1. Setelah ayam dicuci bersih, goreng ayam sebentar diatas teflon. Ini selera ya, tdk digoreng jg gapapa. Setelah digoreng, lalu tiriskan.
1. Blender semua bahan bumbu, kecuali sereh, daun salam, daun jeruk dan lengkuas.
1. Setelah bumbu halus, panaskan minyak goreng, masukkan bumbu halus beserta lengkuas dan batang sereh yg sudah di geprek, daun salam dan daun jeruk. Aduk sebentar sampai wangi. Lalu tambahkan sedikit air.
1. Setelah itu, masukkan ayam. Aduk sampai bumbu tercampur rata. Diamkan sebentar supaya bumbu meresap dan air mulai menyusut.
1. Setelah air menyusut dan ayam empuk, masukkan kemangi dan daun bawang. Aduk sebentar lalu matikan api.
1. Ayam rica-rica siap dihidangkan bersama nasi hangat dan lalapan mentimun/selada.




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan cepat, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
