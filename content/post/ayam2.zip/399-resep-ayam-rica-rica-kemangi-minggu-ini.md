---
description: "Resep : Ayam Rica-rica Kemangi minggu ini"
title: "Resep : Ayam Rica-rica Kemangi minggu ini"
slug: 399-resep-ayam-rica-rica-kemangi-minggu-ini
date: 2020-08-09T15:58:52.690Z
image: https://img-global.cpcdn.com/recipes/d21f02606926b80b/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d21f02606926b80b/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d21f02606926b80b/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Timothy Reyes
ratingvalue: 4.2
reviewcount: 4808
recipeingredient:
- "250 gr ayam potong kecilkecil"
- "1 ikat kemangi"
- "1 batang serai"
- "1 lembar daun pandan"
- "1 lembar daun salam"
- "2 lembar daun jeruk iris tipis"
- "Secukupnya gula garam"
- " Bumbu Halus"
- "6 buah cabe rawit"
- "2 buah cabe keriting"
- "1 buah cabe merah besar"
- "3 buah bawang merah ukbesar"
- "2 buah bawang putih"
- "Seruas kunyit"
- "Seruas jahe"
- "Seruas lengkuas"
- "2 butir kemiri"
recipeinstructions:
- "Potong2 ayam kemudian goreng setengah kering."
- "Tumis bumbu halus hingga harum dan matang. Kemudian masukkan daun pandan, daun salam, serai, dan daun jeruk."
- "Masukkan ayam, tambahkan air dan bumbui dengan gula garam secukupnya. Tutup wajan dan masak hingga air menyusut dan bumbu meresap. Terakhir masukkan daun kemangi dan aduk2 hingga layu."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 249 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/d21f02606926b80b/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas dan enak. Ciri makanan Indonesia ayam rica-rica kemangi yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kehangatan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam Rica-rica Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang dapat anda contoh salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica Kemangi:

1. Harap siapkan 250 gr ayam, potong kecil-kecil
1. Jangan lupa 1 ikat kemangi
1. Dibutuhkan 1 batang serai
1. Harap siapkan 1 lembar daun pandan
1. Tambah 1 lembar daun salam
1. Diperlukan 2 lembar daun jeruk, iris tipis
1. Harap siapkan Secukupnya gula, garam
1. Tambah  Bumbu Halus:
1. Tambah 6 buah cabe rawit
1. Harus ada 2 buah cabe keriting
1. Dibutuhkan 1 buah cabe merah besar
1. Dibutuhkan 3 buah bawang merah uk.besar
1. Siapkan 2 buah bawang putih
1. Tambah Seruas kunyit
1. Harus ada Seruas jahe
1. Siapkan Seruas lengkuas
1. Harap siapkan 2 butir kemiri




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-rica Kemangi:

1. Potong2 ayam kemudian goreng setengah kering.
1. Tumis bumbu halus hingga harum dan matang. Kemudian masukkan daun pandan, daun salam, serai, dan daun jeruk.
1. Masukkan ayam, tambahkan air dan bumbui dengan gula garam secukupnya. Tutup wajan dan masak hingga air menyusut dan bumbu meresap. Terakhir masukkan daun kemangi dan aduk2 hingga layu.




Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan terbukti, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
