---
description: "Resep : Ayam rica kemangi Terbukti"
title: "Resep : Ayam rica kemangi Terbukti"
slug: 210-resep-ayam-rica-kemangi-terbukti
date: 2020-10-04T22:44:17.310Z
image: https://img-global.cpcdn.com/recipes/72224a535d4e7bf4/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/72224a535d4e7bf4/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/72224a535d4e7bf4/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Clifford Miles
ratingvalue: 4
reviewcount: 35312
recipeingredient:
- "1/2 ekor ayam"
- "2 iket kemangi"
- "7 siung bawang merah"
- "3 siung bawang putih"
- "2 buah cabai merah"
- "11 buah cabai rawit  sesuai selera"
- "2 keping kemiri"
- "1/2 ruas kunyit"
- "1/2 ruas jahe"
- "1 ruas lengkuas geprek"
- "2 batang serai geprek"
- "4 lembar daun jeruk buang batang"
- "secukupnya Gula garam  penyedap rasa"
- "secukupnya Air sisa rebusan ayam  air masak ya"
recipeinstructions:
- "Potong ayam jadi beberapa bagian (sesuai selera ya ukurannya) lalu rebus sampai empuk, sisa air rebusan jgn dibuang ya buat kaldu"
- "Setelah empuk tiriskan ayam lalu goreng setengah matang ya..."
- "Ulek / blender semua bumbu kecuali lengkuas, serai dan daun jeruk yah"
- "Panaskan minyak lalu tumis bumbu yang sudah di haluskan,masukkan serai,lengkuas dan daun jeruk (robek dlu yah biar lbh wangi) aduk sampai tanak"
- "Setelah harum, masukkan air rebusan ayam secukupnya, tunggu mendidih"
- "Masukkan ayam yang sudah di goreng setengah matang tadi, beri gula,garam dan penyedap rasa secukupnya (test rasa)"
- "Ungkep sebentar smpai bumbu menyusut lalu masukkan kemangi.. Aduk sebentar lalu angkat.."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 233 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/72224a535d4e7bf4/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita lestarikan karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica kemangi yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan keistimewahan yang merupakan keragaman Indonesia

Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap.

Kehangatan keluarga bisa didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam rica kemangi untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang bisa anda contoh salah satunya ayam rica kemangi yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 14 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi:

1. Diperlukan 1/2 ekor ayam
1. Diperlukan 2 iket kemangi
1. Dibutuhkan 7 siung bawang merah
1. Tambah 3 siung bawang putih
1. Siapkan 2 buah cabai merah
1. Harap siapkan 11 buah cabai rawit / sesuai selera
1. Tambah 2 keping kemiri
1. Jangan lupa 1/2 ruas kunyit
1. Jangan lupa 1/2 ruas jahe
1. Tambah 1 ruas lengkuas geprek
1. Dibutuhkan 2 batang serai geprek
1. Harus ada 4 lembar daun jeruk buang batang
1. Harus ada secukupnya Gula, garam &amp; penyedap rasa
1. Siapkan secukupnya Air sisa rebusan ayam / air masak ya


Perlu kamu ketahui bahwa di luar negeri mungkin daun basil sangat terkenal untuk campuran makanan. Akan tetapi, di Indonesia juga memiliki daun kemangi merupakan. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica kemangi:

1. Potong ayam jadi beberapa bagian (sesuai selera ya ukurannya) lalu rebus sampai empuk, sisa air rebusan jgn dibuang ya buat kaldu
1. Setelah empuk tiriskan ayam lalu goreng setengah matang ya...
1. Ulek / blender semua bumbu kecuali lengkuas, serai dan daun jeruk yah
1. Panaskan minyak lalu tumis bumbu yang sudah di haluskan,masukkan serai,lengkuas dan daun jeruk (robek dlu yah biar lbh wangi) aduk sampai tanak
1. Setelah harum, masukkan air rebusan ayam secukupnya, tunggu mendidih
1. Masukkan ayam yang sudah di goreng setengah matang tadi, beri gula,garam dan penyedap rasa secukupnya (test rasa)
1. Ungkep sebentar smpai bumbu menyusut lalu masukkan kemangi.. Aduk sebentar lalu angkat..


Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. Cara Membuat Ayam Rica Rica Kemangi. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat. 

Demikianlah cara membuat ayam rica kemangi yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
