---
description: "Bagaimana untuk membuat Ayam rica-rica kemangi Homemade"
title: "Bagaimana untuk membuat Ayam rica-rica kemangi Homemade"
slug: 310-bagaimana-untuk-membuat-ayam-rica-rica-kemangi-homemade
date: 2021-01-05T20:38:50.106Z
image: https://img-global.cpcdn.com/recipes/4ed8d3644b6c080b/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4ed8d3644b6c080b/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4ed8d3644b6c080b/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Vernon Castillo
ratingvalue: 4.4
reviewcount: 27481
recipeingredient:
- "500 gr ayam"
- " Kemangi"
- " Jeruk nipis"
- " Garam"
- " Gula"
- " Penyedap rasa"
- "2 lembar daun salam"
- "1 lembar daun pandan"
- "1 batang serai geprek"
- "2 lembar daun jeruk buang tulangnya laru iris2"
- " Minyak goreng"
- "secukupnya Air"
- " Bumbu halus "
- "10 buah cabe merah"
- "5 buah cabe rawit merah"
- "5 buah bawang merah"
- "3 buah bawang putih"
- "2 buah kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 ruas lengkuas"
recipeinstructions:
- "Cuci bersih ayam lalu lumuri dgn perasan jeruk nipis, diamkan 15 menit"
- "Goreng ayam setengah matang"
- "Blender semua bumbu halus lalu panaskan minyak"
- "Tumis bumbu yg sudah diblender, masukkan irisan daun jeruk, daun pandan, daun salam, dan serai. Tambahkan garam, gula dan penyedap rasa"
- "Aduk hingga wangi setelah itu masukkan ayam dan beri sedikit air"
- "Aduk2 lagi sampai air susut kemudian masukkan kemangi, tes rasa dan ayam rica2 siap disajikan. Selamat makan 🤤"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 169 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/4ed8d3644b6c080b/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga empuk. Karasteristik masakan Indonesia ayam rica-rica kemangi yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Ayam rica-rica kemangi untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang bisa anda contoh salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica kemangi:

1. Siapkan 500 gr ayam
1. Dibutuhkan  Kemangi
1. Siapkan  Jeruk nipis
1. Dibutuhkan  Garam
1. Jangan lupa  Gula
1. Dibutuhkan  Penyedap rasa
1. Diperlukan 2 lembar daun salam
1. Diperlukan 1 lembar daun pandan
1. Dibutuhkan 1 batang serai (geprek)
1. Diperlukan 2 lembar daun jeruk (buang tulangnya laru iris2)
1. Siapkan  Minyak goreng
1. Dibutuhkan secukupnya Air
1. Harap siapkan  Bumbu halus :
1. Jangan lupa 10 buah cabe merah
1. Tambah 5 buah cabe rawit merah
1. Jangan lupa 5 buah bawang merah
1. Harus ada 3 buah bawang putih
1. Dibutuhkan 2 buah kemiri
1. Harap siapkan 1 ruas jahe
1. Jangan lupa 1 ruas kunyit
1. Siapkan 1 ruas lengkuas


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica-rica kemangi:

1. Cuci bersih ayam lalu lumuri dgn perasan jeruk nipis, diamkan 15 menit
1. Goreng ayam setengah matang
1. Blender semua bumbu halus lalu panaskan minyak
1. Tumis bumbu yg sudah diblender, masukkan irisan daun jeruk, daun pandan, daun salam, dan serai. Tambahkan garam, gula dan penyedap rasa
1. Aduk hingga wangi setelah itu masukkan ayam dan beri sedikit air
1. Aduk2 lagi sampai air susut kemudian masukkan kemangi, tes rasa dan ayam rica2 siap disajikan. Selamat makan 🤤


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan cepat, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
