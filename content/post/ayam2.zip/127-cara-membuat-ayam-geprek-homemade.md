---
description: "Cara membuat Ayam Geprek Homemade"
title: "Cara membuat Ayam Geprek Homemade"
slug: 127-cara-membuat-ayam-geprek-homemade
date: 2020-10-18T08:16:57.248Z
image: https://img-global.cpcdn.com/recipes/7210a21a5fc85217/751x532cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7210a21a5fc85217/751x532cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7210a21a5fc85217/751x532cq70/ayam-geprek-foto-resep-utama.jpg
author: Ann Malone
ratingvalue: 4.4
reviewcount: 8566
recipeingredient:
- "1/2 kg ayam bagian dada"
- "25 biji rawit merah"
- "5 biji cabe merah"
- "4 siung bawang putih"
- "1 sdt garam"
- "1 sdt gula"
- "1 bungkus tepung mamasuka"
- "3 jeruk nipis"
recipeinstructions:
- "Lumurii ayam dengan jeruk nipis dan diamkan selama 5-10 menit"
- "Cuci bersih cabe, bawang putih dan rawit lalu giling dan tambahkan garam untuk menggiling"
- "Setelah halus beri gula, dan diamkan sembari memasak ayam."
- "Buat tepung bumbu menjadi dua bagian, cair dan tepung lalu celupkan ayam ke bagian cair tepung dan diguling2 kembali ke tepung baru digoreng."
- "Setelah matang tiriskan, tambahkan minyak panas ke ulekan cabe sebanyak 2 sdm. Lalu geprek ayam diatas ulekan. Selamat mencobaaaa. Dijamin ketagihan karna pedasnya enaakkk :)"
categories:
- Recipe
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 173 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/7210a21a5fc85217/751x532cq70/ayam-geprek-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang harus kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam geprek yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Kita



Kedekatan rumah tangga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Geprek untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang dapat anda praktekkan salah satunya ayam geprek yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam geprek tanpa harus bersusah payah.
Seperti resep Ayam Geprek yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek:

1. Harus ada 1/2 kg ayam (bagian dada)
1. Harap siapkan 25 biji rawit merah
1. Harap siapkan 5 biji cabe merah
1. Jangan lupa 4 siung bawang putih
1. Jangan lupa 1 sdt garam
1. Jangan lupa 1 sdt gula
1. Dibutuhkan 1 bungkus tepung mamasuka
1. Diperlukan 3 jeruk nipis




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Geprek:

1. Lumurii ayam dengan jeruk nipis dan diamkan selama 5-10 menit
1. Cuci bersih cabe, bawang putih dan rawit lalu giling dan tambahkan garam untuk menggiling
1. Setelah halus beri gula, dan diamkan sembari memasak ayam.
1. Buat tepung bumbu menjadi dua bagian, cair dan tepung lalu celupkan ayam ke bagian cair tepung dan diguling2 kembali ke tepung baru digoreng.
1. Setelah matang tiriskan, tambahkan minyak panas ke ulekan cabe sebanyak 2 sdm. Lalu geprek ayam diatas ulekan. Selamat mencobaaaa. Dijamin ketagihan karna pedasnya enaakkk :)




Demikianlah cara membuat ayam geprek yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat simple dan terbukti, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
