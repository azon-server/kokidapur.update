---
description: "Cara singkat untuk membuat Ayam Rica Kemangi Cepat"
title: "Cara singkat untuk membuat Ayam Rica Kemangi Cepat"
slug: 177-cara-singkat-untuk-membuat-ayam-rica-kemangi-cepat
date: 2020-11-24T01:45:31.413Z
image: https://img-global.cpcdn.com/recipes/917ddee9ca5aeb2f/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/917ddee9ca5aeb2f/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/917ddee9ca5aeb2f/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Clyde Collier
ratingvalue: 4.9
reviewcount: 18210
recipeingredient:
- "2 potong ayam bagian dada saja"
- "Secukupnya daun kemangi"
- " Cabe rawit 5 buah potongpotong jadi 2 bagian saja"
- "3 cm jahe geprek"
- "3 cm lengkuas geprek"
- "1 gelas air matang"
- "Secukupnya merica bubuk gula pasir garam sesuai selera"
- " Bumbu halus uleg"
- "3 buah cabe keriting merah uleg kasar"
- "1 buah cabe merah besar uleg kasar"
- "5 siung bawang merah"
- "4 siung bawang putih"
recipeinstructions:
- "Potong ayam agak kecil kecil lalu rebus dg 1 bawang putih geprek dan 1/2 sdt garam, rebus sebentar lalu sisihkan"
- "Tumis bumbu halus dan cabe rawit sampai harum, tambah 1 gelas air matang, aduk rata"
- "Masukkan ayam yg sudah direbus tadi, aduk hingga tercampur bumbu, tambahkan merica, gula dan garam secukupnya (sesuai selera)"
- "Cek rasa apakah sudah pas atau belum, kalau belum bs tambah lagi gula/garam, jika sudah pas masukkan kemangi"
- "Tunggu hingga kemangi layu dan kuah menyusut, jika sudah matikan api lalu sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 279 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT31M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/917ddee9ca5aeb2f/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang patut kita jaga karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica kemangi yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa ciri khas yang merupakan keragaman Nusantara



Kedekatan keluarga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Ayam Rica Kemangi untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang dapat anda contoh salah satunya ayam rica kemangi yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya sekarang ini anda bisa dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Diperlukan 2 potong ayam bagian dada saja
1. Tambah Secukupnya daun kemangi
1. Harus ada  Cabe rawit 5 buah potong-potong jadi 2 bagian saja
1. Siapkan 3 cm jahe geprek
1. Dibutuhkan 3 cm lengkuas geprek
1. Diperlukan 1 gelas air matang
1. Harus ada Secukupnya merica bubuk, gula pasir, garam (sesuai selera)
1. Siapkan  Bumbu halus uleg
1. Harap siapkan 3 buah cabe keriting merah uleg kasar
1. Harus ada 1 buah cabe merah besar uleg kasar
1. Jangan lupa 5 siung bawang merah
1. Tambah 4 siung bawang putih




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Kemangi:

1. Potong ayam agak kecil kecil lalu rebus dg 1 bawang putih geprek dan 1/2 sdt garam, rebus sebentar lalu sisihkan
1. Tumis bumbu halus dan cabe rawit sampai harum, tambah 1 gelas air matang, aduk rata
1. Masukkan ayam yg sudah direbus tadi, aduk hingga tercampur bumbu, tambahkan merica, gula dan garam secukupnya (sesuai selera)
1. Cek rasa apakah sudah pas atau belum, kalau belum bs tambah lagi gula/garam, jika sudah pas masukkan kemangi
1. Tunggu hingga kemangi layu dan kuah menyusut, jika sudah matikan api lalu sajikan




Demikianlah cara membuat ayam rica kemangi yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
