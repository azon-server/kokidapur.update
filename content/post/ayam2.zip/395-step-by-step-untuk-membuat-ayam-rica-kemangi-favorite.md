---
description: "Step-by-Step untuk membuat Ayam rica kemangi Favorite"
title: "Step-by-Step untuk membuat Ayam rica kemangi Favorite"
slug: 395-step-by-step-untuk-membuat-ayam-rica-kemangi-favorite
date: 2020-12-25T17:13:57.348Z
image: https://img-global.cpcdn.com/recipes/dee54c1872f736c5/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dee54c1872f736c5/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dee54c1872f736c5/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Tony Mason
ratingvalue: 4.2
reviewcount: 47936
recipeingredient:
- " Ayam"
- "5 bawang merah iris"
- " Daun jeruk"
- " Kemangi"
- " Serai ambil bagputihnya iris kecil2"
- " Garamgulapenyedap"
- " Bumbu halus "
- "10 bawang merah"
- "6 bawang putih"
- " Jahe"
- " Kunyit"
- " Merica"
- "20 cabe rawit"
- "2 cabe keriting"
recipeinstructions:
- "Potong ayam kecil2 lalu rebus sebentar"
- "Oseng bawang merah (iris) dan serai (iris) setelah wangi masukan bumbu halus dan daun jeruk"
- "Lalu masukan ayam,garam,gula dan penyedap.tambahkan air segelas.(tes rasa)"
- "Masukan kemangi,lalu matikan kompor.lalu aduk (agar tidak terlalu layu)...selesai,terima kasih"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 236 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/dee54c1872f736c5/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan empuk. Ciri masakan Indonesia ayam rica kemangi yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan rumah tangga bisa didapat dengan cara simple. Salah satunya adalah membuat makanan Ayam rica kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.

Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang bisa anda praktekkan salah satunya ayam rica kemangi yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 14 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi:

1. Harap siapkan  Ayam
1. Harus ada 5 bawang merah (iris)
1. Jangan lupa  Daun jeruk
1. Harap siapkan  Kemangi
1. Dibutuhkan  Serai (ambil bag.putihnya iris kecil2)
1. Tambah  Garam,gula,penyedap
1. Harus ada  Bumbu halus :
1. Tambah 10 bawang merah
1. Siapkan 6 bawang putih
1. Tambah  Jahe
1. Diperlukan  Kunyit
1. Harap siapkan  Merica
1. Diperlukan 20 cabe rawit
1. Siapkan 2 cabe keriting


Perlu kamu ketahui bahwa di luar negeri mungkin daun basil sangat terkenal untuk campuran makanan. Akan tetapi, di Indonesia juga memiliki daun kemangi merupakan. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica kemangi:

1. Potong ayam kecil2 lalu rebus sebentar
1. Oseng bawang merah (iris) dan serai (iris) setelah wangi masukan bumbu halus dan daun jeruk
1. Lalu masukan ayam,garam,gula dan penyedap.tambahkan air segelas.(tes rasa)
1. Masukan kemangi,lalu matikan kompor.lalu aduk (agar tidak terlalu layu)...selesai,terima kasih


Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. Cara Membuat Ayam Rica Rica Kemangi. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat. 

Demikianlah cara membuat ayam rica kemangi yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
