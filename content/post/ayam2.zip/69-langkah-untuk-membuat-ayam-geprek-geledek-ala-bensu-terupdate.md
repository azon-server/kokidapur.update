---
description: "Langkah untuk membuat Ayam Geprek Geledek ala Bensu terupdate"
title: "Langkah untuk membuat Ayam Geprek Geledek ala Bensu terupdate"
slug: 69-langkah-untuk-membuat-ayam-geprek-geledek-ala-bensu-terupdate
date: 2021-02-02T09:01:14.503Z
image: https://img-global.cpcdn.com/recipes/7f6eb7200ccef6a1/751x532cq70/ayam-geprek-geledek-ala-bensu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7f6eb7200ccef6a1/751x532cq70/ayam-geprek-geledek-ala-bensu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7f6eb7200ccef6a1/751x532cq70/ayam-geprek-geledek-ala-bensu-foto-resep-utama.jpg
author: Adelaide Garrett
ratingvalue: 4.9
reviewcount: 2044
recipeingredient:
- "500 gr Dada ayam fillet jadinya 5  6 bagianpukul pipihkan"
- "Secukupnya garam kaldu bubukbubuk bawang putihlada"
- " Bahan pencelupaduk agak kental"
- "5 sdm terigu"
- "1 sdm Maizena"
- "Secukupnya garam kaldu bubuk bubuk bawang putihlada"
- "Secukupnya air"
- " Bahan Pelapis kering aduk rata"
- "10 sdm terigu"
- "3 sdm maizena"
- " Bahan Sambal"
- "20 bh rawit merah"
- "5 bh cabe merah keriting"
- "4 bh bawang putih tumis bentar"
- "secukupnya garam kaldu bubukgula pasir"
- "4 sdm minyak panasbekas goreng ayam"
recipeinstructions:
- "Gepuk ayam pipihkan spy hasilnya lbh crispy lalu marinasi minimal 15 menit.. Makin lama makin enak.(meresap bumbunya.)"
- "Celup ke bahan pencelup lalu masukkan ke bahan pelapis (kering).tepuk2 lalu goreng sampai kuning keemasan/crispy.. Sisihkan.."
- "SAMBAL GELEDEK: Ulek agak halus bawang putih dan semua cabe..lalu siram dgn minyak panas..tambahkan secukupnya garam,gula, kaldu bubuk aduk rata."
- "PENYAJIAN: Ambil sepotong, geprek bareng sambal sampai daging agak hancur..kasih lalapan..peteee...pake nasi angett... Wihhh... Sedaaaaaaaapppppp pemirsahhh....ngga sadar nambah nasi terus..😄😄😄"
- "Tips :Boleh kasih topping keju Cheddar parut/Mozarela.. (Utk mozarela, panggang di oven 170°C api atas sekitar 5-10 menit/sampai kejunya meleleh... Mantapppff ini enak bangetttt..😍😍😍👍"
categories:
- Recipe
tags:
- ayam
- geprek
- geledek

katakunci: ayam geprek geledek 
nutrition: 171 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Geprek Geledek ala Bensu](https://img-global.cpcdn.com/recipes/7f6eb7200ccef6a1/751x532cq70/ayam-geprek-geledek-ala-bensu-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau enak. Karasteristik kuliner Nusantara ayam geprek geledek ala bensu yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga dapat ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam Geprek Geledek ala Bensu untuk keluarga. kebiasaan makan bersama anak sudah menjadi budaya, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang dapat anda contoh salah satunya ayam geprek geledek ala bensu yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep ayam geprek geledek ala bensu tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Geledek ala Bensu yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Geledek ala Bensu:

1. Dibutuhkan 500 gr Dada ayam fillet jadinya 5 - 6 bagian,pukul pipihkan)
1. Dibutuhkan Secukupnya garam +kaldu bubuk+bubuk bawang putih+lada
1. Siapkan  Bahan pencelup:👉(aduk agak kental)
1. Dibutuhkan 5 sdm terigu
1. Tambah 1 sdm Maizena
1. Harap siapkan Secukupnya garam, kaldu bubuk, bubuk bawang putih,lada
1. Diperlukan Secukupnya air
1. Jangan lupa  Bahan Pelapis (kering) 👉aduk rata
1. Siapkan 10 sdm terigu
1. Dibutuhkan 3 sdm maizena
1. Harap siapkan  Bahan Sambal:
1. Siapkan 20 bh rawit merah
1. Jangan lupa 5 bh cabe merah keriting
1. Tambah 4 bh bawang putih (tumis bentar)
1. Siapkan secukupnya garam, kaldu bubuk,gula pasir
1. Jangan lupa 4 sdm minyak panas(bekas goreng ayam)




<!--inarticleads2-->

##### Cara membuat  Ayam Geprek Geledek ala Bensu:

1. Gepuk ayam pipihkan spy hasilnya lbh crispy lalu marinasi minimal 15 menit.. Makin lama makin enak.(meresap bumbunya.)
1. Celup ke bahan pencelup lalu masukkan ke bahan pelapis (kering).tepuk2 lalu goreng sampai kuning keemasan/crispy.. Sisihkan..
1. SAMBAL GELEDEK: Ulek agak halus bawang putih dan semua cabe..lalu siram dgn minyak panas..tambahkan secukupnya garam,gula, kaldu bubuk aduk rata.
1. PENYAJIAN: Ambil sepotong, geprek bareng sambal sampai daging agak hancur..kasih lalapan..peteee...pake nasi angett... Wihhh... Sedaaaaaaaapppppp pemirsahhh....ngga sadar nambah nasi terus..😄😄😄
1. Tips :Boleh kasih topping keju Cheddar parut/Mozarela.. (Utk mozarela, panggang di oven 170°C api atas sekitar 5-10 menit/sampai kejunya meleleh... Mantapppff ini enak bangetttt..😍😍😍👍




Demikianlah cara membuat ayam geprek geledek ala bensu yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat simple dan teruji, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
