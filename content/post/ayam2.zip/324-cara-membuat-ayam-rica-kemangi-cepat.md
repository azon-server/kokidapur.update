---
description: "Cara membuat Ayam Rica Kemangi Cepat"
title: "Cara membuat Ayam Rica Kemangi Cepat"
slug: 324-cara-membuat-ayam-rica-kemangi-cepat
date: 2020-09-26T16:27:06.503Z
image: https://img-global.cpcdn.com/recipes/51db8fa37c4383c5/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/51db8fa37c4383c5/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/51db8fa37c4383c5/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Leonard Obrien
ratingvalue: 4.9
reviewcount: 19769
recipeingredient:
- "7 potong ayam cuci bersihtiriskan"
- "2 batang serai dipotong tipis tipis"
- "1/2 tomat"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1/2 batang daun bawang iris serong"
- "segenggam daun kemangi"
- " Bumbu Halus"
- "5 butir bawang merah"
- "5 butir bawang putih"
- "2 butir kemiri"
- "9 cabai keriting merah uleg kasar"
- "11 cabai rawit merah uleg kasar"
- "1 ruas kunyit"
- "1 ruas jahe"
- "secukupnya air"
- "secukupnya gula"
- "secukupnya garam"
recipeinstructions:
- "Haluskan bumbu, kemudian tumis hingga harum. masukkan daun jeruk, daun salam, dan serai. aduk rata."
- "Tuang ayam ke bumbu tersebut dan aduk rata. tambahkan air sambil di aduk agar bumbu merata."
- "Bumbui dengan garam-gula-sedikit royco dan aduk rata. diamkan sampai ayam matang bumbu meresap dan air agak menyusut."
- "Jika sudah agak menyusut, masukan irisan tomat, daun bawang dan daun kemangi. aduk rata kemudian tunggu beberapa saat sampai daun kemangi layu."
- "Voilaaaa.... ayam pedas kemangi siap disantap dengan nasi hangat. selamat menambah porsi nasiii!! 😂"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 297 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/51db8fa37c4383c5/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis dan empuk. Ciri khas makanan Indonesia ayam rica kemangi yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan keluarga dapat didapat dengan cara simple. Diantaranya adalah memasak Ayam Rica Kemangi untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang bisa anda praktekkan salah satunya ayam rica kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Tambah 7 potong ayam, cuci bersih-tiriskan
1. Tambah 2 batang serai, dipotong tipis tipis
1. Harus ada 1/2 tomat
1. Diperlukan 2 lembar daun salam
1. Dibutuhkan 3 lembar daun jeruk
1. Tambah 1/2 batang daun bawang, iris serong
1. Tambah segenggam daun kemangi
1. Dibutuhkan  Bumbu Halus-
1. Harap siapkan 5 butir bawang merah
1. Diperlukan 5 butir bawang putih
1. Harap siapkan 2 butir kemiri
1. Siapkan 9 cabai keriting merah, uleg kasar
1. Siapkan 11 cabai rawit merah, uleg kasar
1. Dibutuhkan 1 ruas kunyit
1. Jangan lupa 1 ruas jahe
1. Tambah secukupnya air
1. Diperlukan secukupnya gula
1. Dibutuhkan secukupnya garam




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Kemangi:

1. Haluskan bumbu, kemudian tumis hingga harum. masukkan daun jeruk, daun salam, dan serai. aduk rata.
1. Tuang ayam ke bumbu tersebut dan aduk rata. tambahkan air sambil di aduk agar bumbu merata.
1. Bumbui dengan garam-gula-sedikit royco dan aduk rata. diamkan sampai ayam matang bumbu meresap dan air agak menyusut.
1. Jika sudah agak menyusut, masukan irisan tomat, daun bawang dan daun kemangi. aduk rata kemudian tunggu beberapa saat sampai daun kemangi layu.
1. Voilaaaa.... ayam pedas kemangi siap disantap dengan nasi hangat. selamat menambah porsi nasiii!! 😂




Demikianlah cara membuat ayam rica kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
