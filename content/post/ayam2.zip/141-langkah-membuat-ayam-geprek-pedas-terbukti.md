---
description: "Langkah membuat Ayam Geprek Pedas Terbukti"
title: "Langkah membuat Ayam Geprek Pedas Terbukti"
slug: 141-langkah-membuat-ayam-geprek-pedas-terbukti
date: 2021-01-20T00:40:36.245Z
image: https://img-global.cpcdn.com/recipes/4e9d5f876f15cddc/751x532cq70/ayam-geprek-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4e9d5f876f15cddc/751x532cq70/ayam-geprek-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4e9d5f876f15cddc/751x532cq70/ayam-geprek-pedas-foto-resep-utama.jpg
author: Helen Castro
ratingvalue: 4.8
reviewcount: 4850
recipeingredient:
- "500 gr dada ayam"
- "5 sdm penuh tepung crispy"
- "1 sdm penuh maizena "
- "3 bawang putih"
- "1 sdt ketumbar bubuk"
- "1 sdt bubuk cabe"
- "1 sdt baking powder"
- "1 sdt merica bubuk"
- "1 telur"
- " garam"
- " air dingin"
- " bahan sambal "
- "10 cabe rawit"
- "1 bawang putih"
- " garam"
- " gula"
recipeinstructions:
- "Cuci bersih dan potong dada ayam sesuai selera. Lembutkan bawang putih + ketumbar bubuk + garam + bubuk cabe. Lumuri ayam hingga meresap (15 menit)"
- "Bahan 1 : tepung crispy + maizena + garam + bubuk cabe + merica bubuk + baking powder aduk hingga rata"
- "Bahan 2 (celupan) : ambil 3sdm dari bahan 1 + kocok dgn telur beri air dingin. Campur hingga rata"
- "Siapkan wajan dgn api kecil selagi menunggu minyak panas. Ambil ayam yg sudah diberi bumbu masukan ke bahan 1 cubit-cubit. Celupkan ke bahan 2 cubit-cubit masukan ke bahan 1, cubit-cubit dan goreng (lakukan berkali kali hingga selesai)"
- "Sabar klo menggoreng karena api kecil bisa mematangkan sampai kedalam. Selagi menunggu buat sambalnya."
- "Ulek kasar cabe + garam + gula + bawang putih dan siram dgn minyak panas dari ayam crispy. Tes rasa."
- "Tiriskan ayam crispy dan masukan ke cobek sambal dan geprek hingga penyet."
- "Taraaaaaa ayam geprek siap dimakan dgn nasi hangaaat."
categories:
- Recipe
tags:
- ayam
- geprek
- pedas

katakunci: ayam geprek pedas 
nutrition: 260 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Geprek Pedas](https://img-global.cpcdn.com/recipes/4e9d5f876f15cddc/751x532cq70/ayam-geprek-pedas-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan enak. Karasteristik kuliner Indonesia ayam geprek pedas yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah memasak Ayam Geprek Pedas untuk keluarga. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda praktekkan salah satunya ayam geprek pedas yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam geprek pedas tanpa harus bersusah payah.
Seperti resep Ayam Geprek Pedas yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Pedas:

1. Dibutuhkan 500 gr dada ayam
1. Diperlukan 5 sdm (penuh) tepung crispy
1. Dibutuhkan 1 sdm (penuh) maizena 🌽
1. Jangan lupa 3 bawang putih
1. Siapkan 1 sdt ketumbar bubuk
1. Tambah 1 sdt bubuk cabe
1. Jangan lupa 1 sdt baking powder
1. Harus ada 1 sdt merica bubuk
1. Diperlukan 1 telur
1. Harus ada  garam
1. Jangan lupa  air dingin
1. Harus ada  bahan sambal :
1. Dibutuhkan 10 cabe rawit
1. Harus ada 1 bawang putih
1. Diperlukan  garam
1. Tambah  gula




<!--inarticleads2-->

##### Cara membuat  Ayam Geprek Pedas:

1. Cuci bersih dan potong dada ayam sesuai selera. Lembutkan bawang putih + ketumbar bubuk + garam + bubuk cabe. Lumuri ayam hingga meresap (15 menit)
1. Bahan 1 : tepung crispy + maizena + garam + bubuk cabe + merica bubuk + baking powder aduk hingga rata
1. Bahan 2 (celupan) : ambil 3sdm dari bahan 1 + kocok dgn telur beri air dingin. Campur hingga rata
1. Siapkan wajan dgn api kecil selagi menunggu minyak panas. Ambil ayam yg sudah diberi bumbu masukan ke bahan 1 cubit-cubit. Celupkan ke bahan 2 cubit-cubit masukan ke bahan 1, cubit-cubit dan goreng (lakukan berkali kali hingga selesai)
1. Sabar klo menggoreng karena api kecil bisa mematangkan sampai kedalam. Selagi menunggu buat sambalnya.
1. Ulek kasar cabe + garam + gula + bawang putih dan siram dgn minyak panas dari ayam crispy. Tes rasa.
1. Tiriskan ayam crispy dan masukan ke cobek sambal dan geprek hingga penyet.
1. Taraaaaaa ayam geprek siap dimakan dgn nasi hangaaat.




Demikianlah cara membuat ayam geprek pedas yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan teruji, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
