---
description: "Resep : Ayam Rica-Rica Daun Kemangi minggu ini"
title: "Resep : Ayam Rica-Rica Daun Kemangi minggu ini"
slug: 351-resep-ayam-rica-rica-daun-kemangi-minggu-ini
date: 2020-11-03T09:22:47.335Z
image: https://img-global.cpcdn.com/recipes/52158dd8748f7690/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/52158dd8748f7690/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/52158dd8748f7690/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Sophia Fuller
ratingvalue: 4.1
reviewcount: 1052
recipeingredient:
- "1/2 kg ayam"
- " Bumbu halus"
- "2 butir kemiri"
- "7 butir bawang merah"
- "5 butir bawang putih"
- "4 buah cabai merah keriting"
- "25 buah cabai rawit merah"
- "1 ruas kunyit"
- "1 ruas jahe"
- "secukupnya Lada bubuk"
- " Pelengkap"
- "2-3 lembar Daun salam  remasremas"
- "5 lembar Dau jeruk remasremas"
- "2 buah Sereh geprek"
- "1 ruas lengkuas"
- "Seikat daun kemangi"
recipeinstructions:
- "Cuci bersih ayam dan rendam dengan perasan jeruk nipis sebentar (kurang lebih 5menit), setelah itu cuci kembali"
- "Rebus ayam dengan taburi garam secukupnya untuk memberi rasa pada ayam sedikit sampai mendidih, tiriskan, air rebusan nya jangan dibuang, bisa untuk tambahan ketika menumis bumbu halusnya"
- "Sambil menunggu ayam mendidih, ulek bumbu halusnya yah"
- "Setelah ayam ditiriskan, goreng ayam sebentar, tiriskan"
- "Tumis bumbu halus beserta pelengkapnya sampai harum dan bau langu bumbu meredup, lalu berikan air rebusan ayam sedikit-sedikit, berikan gula garam, aduk-aduk sampai menggolak, lalu masukan ayam, biarkan sampai meresap dan test rasa"
- "Setelah air menyusut, berikan daun kemangi, aduk-aduk kembali sampai aroma kemangi nya tercium, lalu matikan dan sajikan"
categories:
- Recipe
tags:
- ayam
- ricarica
- daun

katakunci: ayam ricarica daun 
nutrition: 121 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica-Rica Daun Kemangi](https://img-global.cpcdn.com/recipes/52158dd8748f7690/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau gurih. Ciri kuliner Indonesia ayam rica-rica daun kemangi yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga dapat diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam Rica-Rica Daun Kemangi untuk orang di rumah. Momen makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang dapat anda contoh salah satunya ayam rica-rica daun kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica-rica daun kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica Daun Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 16 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Daun Kemangi:

1. Harus ada 1/2 kg ayam
1. Dibutuhkan  Bumbu halus:
1. Dibutuhkan 2 butir kemiri
1. Siapkan 7 butir bawang merah
1. Harap siapkan 5 butir bawang putih
1. Dibutuhkan 4 buah cabai merah keriting
1. Harap siapkan 25 buah cabai rawit merah
1. Diperlukan 1 ruas kunyit
1. Harus ada 1 ruas jahe
1. Diperlukan secukupnya Lada bubuk
1. Tambah  Pelengkap
1. Diperlukan 2-3 lembar Daun salam  (remas-remas)
1. Dibutuhkan 5 lembar Dau jeruk (remas-remas)
1. Dibutuhkan 2 buah Sereh (geprek)
1. Jangan lupa 1 ruas lengkuas
1. Diperlukan Seikat daun kemangi




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-Rica Daun Kemangi:

1. Cuci bersih ayam dan rendam dengan perasan jeruk nipis sebentar (kurang lebih 5menit), setelah itu cuci kembali
1. Rebus ayam dengan taburi garam secukupnya untuk memberi rasa pada ayam sedikit sampai mendidih, tiriskan, air rebusan nya jangan dibuang, bisa untuk tambahan ketika menumis bumbu halusnya
1. Sambil menunggu ayam mendidih, ulek bumbu halusnya yah
1. Setelah ayam ditiriskan, goreng ayam sebentar, tiriskan
1. Tumis bumbu halus beserta pelengkapnya sampai harum dan bau langu bumbu meredup, lalu berikan air rebusan ayam sedikit-sedikit, berikan gula garam, aduk-aduk sampai menggolak, lalu masukan ayam, biarkan sampai meresap dan test rasa
1. Setelah air menyusut, berikan daun kemangi, aduk-aduk kembali sampai aroma kemangi nya tercium, lalu matikan dan sajikan




Demikianlah cara membuat ayam rica-rica daun kemangi yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
