---
description: "Langkah untuk membuat Ayam Rica Kemangi, khas Manado Homemade"
title: "Langkah untuk membuat Ayam Rica Kemangi, khas Manado Homemade"
slug: 343-langkah-untuk-membuat-ayam-rica-kemangi-khas-manado-homemade
date: 2021-01-22T19:59:08.177Z
image: https://img-global.cpcdn.com/recipes/4078caf4f3f89c84/751x532cq70/ayam-rica-kemangi-khas-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4078caf4f3f89c84/751x532cq70/ayam-rica-kemangi-khas-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4078caf4f3f89c84/751x532cq70/ayam-rica-kemangi-khas-manado-foto-resep-utama.jpg
author: Jack Terry
ratingvalue: 4.3
reviewcount: 23795
recipeingredient:
- "1 kg Ayam"
- "1 ikat daun kemangi"
- " Bumbu yang dihaluskan "
- "3 siung bawang putih"
- "5 bawang merah"
- " Cabai rawit sesuai selera"
- "secukupnya Garam"
- "2 butir kemiri"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1 ruas kunyit"
- " Bumbu kasar "
- "4 lembar daun jeruk"
- "2 batang sereh"
- "3 lembar daun salam"
- "1 butir Gula merah"
- "1 Jeruk nipis"
- " Penyedap rasa"
- " Minyak goreng"
recipeinstructions:
- "Potong ayam, cuci hingga bersih lalu lumuri dengan garam dan perasan jeruk nipis. Diamkan sembari menyiapkan bumbu"
- "Siapkan bumbu halus, geprek sereh, dan potong kecil-kecil daun jeruk"
- "Setelah bumbu siap, goreng ayam. Setengah matang saja ya bun.. jangan lupa siapkan juga daun kemangi, cuci bersih buang gagang yg keras."
- "Sekarang saatnya menyiapkan wajan dan minyak goreng untuk mulai memasak."
- "Tumis bumbu halus dengan api sedang. Aduk-aduk, setelah sedikit beraroma, masukan irisan daun jeruk, sereh dan juga daun salam. Setelah aromanya menyebarr 😍 dan menggoda.. masukan ayam yang sudah digoreng setengah matang tadi.. aduk hingga rata. Kemudian masukan air hingga semua ayam tenggelam"
- "Tunggu hingga mendidih, masukan gula merah, dan penyedap rasa."
- "Biarkan hingga kuah menyusut. Pastikan ayam benar-benar empuk. Kemudian masukan daun kemangi. Dan masukan juga perasan jeruk nipis cukup 1/2 saja."
- "Test rasa. Kalau sudah mantap. Siap untuk dihidangkan. Slamat mencoba bundaa.. 🤗"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 151 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica Kemangi, khas Manado](https://img-global.cpcdn.com/recipes/4078caf4f3f89c84/751x532cq70/ayam-rica-kemangi-khas-manado-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita jaga karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica kemangi, khas manado yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Kita



Kehangatan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Rica Kemangi, khas Manado untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang bisa anda contoh salah satunya ayam rica kemangi, khas manado yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica kemangi, khas manado tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi, khas Manado yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi, khas Manado:

1. Diperlukan 1 kg Ayam
1. Tambah 1 ikat daun kemangi
1. Siapkan  Bumbu yang dihaluskan :
1. Harus ada 3 siung bawang putih
1. Tambah 5 bawang merah
1. Jangan lupa  Cabai rawit (sesuai selera)
1. Jangan lupa secukupnya Garam
1. Dibutuhkan 2 butir kemiri
1. Siapkan 1 ruas jahe
1. Harap siapkan 1 ruas lengkuas
1. Tambah 1 ruas kunyit
1. Harap siapkan  Bumbu kasar :
1. Jangan lupa 4 lembar daun jeruk
1. Harus ada 2 batang sereh
1. Harus ada 3 lembar daun salam
1. Dibutuhkan 1 butir Gula merah
1. Jangan lupa 1 Jeruk nipis
1. Harus ada  Penyedap rasa
1. Harap siapkan  Minyak goreng




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Kemangi, khas Manado:

1. Potong ayam, cuci hingga bersih lalu lumuri dengan garam dan perasan jeruk nipis. Diamkan sembari menyiapkan bumbu
1. Siapkan bumbu halus, geprek sereh, dan potong kecil-kecil daun jeruk
1. Setelah bumbu siap, goreng ayam. Setengah matang saja ya bun.. jangan lupa siapkan juga daun kemangi, cuci bersih buang gagang yg keras.
1. Sekarang saatnya menyiapkan wajan dan minyak goreng untuk mulai memasak.
1. Tumis bumbu halus dengan api sedang. Aduk-aduk, setelah sedikit beraroma, masukan irisan daun jeruk, sereh dan juga daun salam. Setelah aromanya menyebarr 😍 dan menggoda.. masukan ayam yang sudah digoreng setengah matang tadi.. aduk hingga rata. Kemudian masukan air hingga semua ayam tenggelam
1. Tunggu hingga mendidih, masukan gula merah, dan penyedap rasa.
1. Biarkan hingga kuah menyusut. Pastikan ayam benar-benar empuk. Kemudian masukan daun kemangi. Dan masukan juga perasan jeruk nipis cukup 1/2 saja.
1. Test rasa. Kalau sudah mantap. Siap untuk dihidangkan. Slamat mencoba bundaa.. 🤗




Demikianlah cara membuat ayam rica kemangi, khas manado yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
