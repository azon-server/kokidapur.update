---
description: "Langkah menyiapakan 12.Opor ayam kentang Sempurna"
title: "Langkah menyiapakan 12.Opor ayam kentang Sempurna"
slug: 474-langkah-menyiapakan-12opor-ayam-kentang-sempurna
date: 2020-12-03T13:27:52.084Z
image: https://img-global.cpcdn.com/recipes/099fcfc4b46bf0b2/751x532cq70/12opor-ayam-kentang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/099fcfc4b46bf0b2/751x532cq70/12opor-ayam-kentang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/099fcfc4b46bf0b2/751x532cq70/12opor-ayam-kentang-foto-resep-utama.jpg
author: Bobby Davis
ratingvalue: 4.2
reviewcount: 42789
recipeingredient:
- " ayam potongpotong lalu cuci bersih"
- " kentang potongpotong sesuai selera"
- " air"
- " santan resep asli 1 liter santan"
- " daun salam"
- " sereh geprek"
- " lengkuas geprek"
- " garam"
- " kaldu bubuk"
- " gula pasir"
- " Bawang goreng untuk taburan"
- " Bumbu halus "
- " bawang merah"
- " bawang putih"
- " kunyit"
- " jahe"
- " kemiri"
- " ketumbar"
- " merica"
recipeinstructions:
- "Siapkan semua bahan"
- "Haluskan bumbu halus dan tumis, masukkan daun salam,sereh dan lengkuas,masak sampai harum.masukkan ayam masak,masak ayam sampai berubah warna"
- "Tambahkan air.masak sampai mendidih,masukkan kentang, tambahkan garam, gula pasir dan kaldu bubuk.aduk rata.masak sampai ayam empuk.masukkan santan,aduk-aduk sampai mendidih dan matang."
- "Sajikan dengan taburan bawang goreng."
categories:
- Recipe
tags:
- 12opor
- ayam
- kentang

katakunci: 12opor ayam kentang 
nutrition: 158 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT50M"
recipeyield: "3"
recipecategory: Lunch

---


![12.Opor ayam kentang](https://img-global.cpcdn.com/recipes/099fcfc4b46bf0b2/751x532cq70/12opor-ayam-kentang-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas hingga empuk. Ciri khas kuliner Indonesia 12.opor ayam kentang yang penuh dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan 12.Opor ayam kentang untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang bisa anda contoh salah satunya 12.opor ayam kentang yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep 12.opor ayam kentang tanpa harus bersusah payah.
Seperti resep 12.Opor ayam kentang yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat 12.Opor ayam kentang:

1. Harus ada  ayam, potong-potong lalu cuci bersih
1. Dibutuhkan  kentang, potong-potong sesuai selera
1. Diperlukan  air
1. Dibutuhkan  santan (resep asli 1 liter santan)
1. Harus ada  daun salam
1. Harap siapkan  sereh, geprek
1. Siapkan  lengkuas, geprek
1. Tambah  garam
1. Jangan lupa  kaldu bubuk
1. Jangan lupa  gula pasir
1. Harus ada  Bawang goreng untuk taburan
1. Siapkan  Bumbu halus :
1. Dibutuhkan  bawang merah
1. Harus ada  bawang putih
1. Jangan lupa  kunyit
1. Jangan lupa  jahe
1. Dibutuhkan  kemiri
1. Jangan lupa  ketumbar
1. Siapkan  merica




<!--inarticleads2-->

##### Instruksi membuat  12.Opor ayam kentang:

1. Siapkan semua bahan
1. Haluskan bumbu halus dan tumis, masukkan daun salam,sereh dan lengkuas,masak sampai harum.masukkan ayam masak,masak ayam sampai berubah warna
1. Tambahkan air.masak sampai mendidih,masukkan kentang, tambahkan garam, gula pasir dan kaldu bubuk.aduk rata.masak sampai ayam empuk.masukkan santan,aduk-aduk sampai mendidih dan matang.
1. Sajikan dengan taburan bawang goreng.




Demikianlah cara membuat 12.opor ayam kentang yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan teruji, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
