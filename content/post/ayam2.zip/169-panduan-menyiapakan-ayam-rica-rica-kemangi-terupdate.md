---
description: "Panduan menyiapakan Ayam rica-rica kemangi terupdate"
title: "Panduan menyiapakan Ayam rica-rica kemangi terupdate"
slug: 169-panduan-menyiapakan-ayam-rica-rica-kemangi-terupdate
date: 2020-09-28T08:05:24.045Z
image: https://img-global.cpcdn.com/recipes/e5869bac0baffab4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e5869bac0baffab4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e5869bac0baffab4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Bobby Conner
ratingvalue: 4.6
reviewcount: 30587
recipeingredient:
- "1/2 kg ayam bag dada balungan lebih mantapp"
- "secukupnya Daun kemangi"
- " Bumbu halus"
- "4 siung bawang putih"
- "6 siung bawang merah"
- "4 buah kemiri"
- "25 buah cabe merah besar"
- "15 cabe rawit ijo"
- "secukupnya Jahe"
- "2 buah tomat ukuran kecil"
- " Bumbu tambahan"
- " Bawang bombai secukupnya iris"
- " Lengkuas secukupnya geprek"
- " Sereh secukupnya geprek"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "5 sdm kecap manis"
- "secukupnya Garam micin gula jawa"
recipeinstructions:
- "Rebus ayam yg uda dipotong² dan tiriskan"
- "Tumis bumbu yg sudah dihaluskan, tambahkan bawang bombai, daun salam, daun jeruk, sereh dan lengkuas"
- "Masukkan ayam kedalam bumbu, beri kecap, garam, micin, gula jawa... dan masukkan daun kemangi....tes rasa...."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 234 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/e5869bac0baffab4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang setidaknya kita lestarikan karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica-rica kemangi yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa ciri khas yang merupakan keragaman Nusantara

Keharmonisan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak Ayam rica-rica kemangi untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang dapat anda contoh salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica kemangi:

1. Tambah 1/2 kg ayam bag. dada (balungan lebih mantapp)
1. Diperlukan secukupnya Daun kemangi
1. Siapkan  Bumbu halus
1. Diperlukan 4 siung bawang putih
1. Harus ada 6 siung bawang merah
1. Tambah 4 buah kemiri
1. Dibutuhkan 25 buah cabe merah besar
1. Tambah 15 cabe rawit ijo
1. Harus ada secukupnya Jahe
1. Harap siapkan 2 buah tomat ukuran kecil
1. Jangan lupa  Bumbu tambahan
1. Tambah  Bawang bombai secukupnya (iris²)
1. Dibutuhkan  Lengkuas secukupnya (geprek)
1. Harap siapkan  Sereh secukupnya (geprek)
1. Siapkan 2 lembar daun salam
1. Diperlukan 2 lembar daun jeruk
1. Siapkan 5 sdm kecap manis
1. Diperlukan secukupnya Garam, micin, gula jawa




<!--inarticleads2-->

##### Cara membuat  Ayam rica-rica kemangi:

1. Rebus ayam yg uda dipotong² dan tiriskan
1. Tumis bumbu yg sudah dihaluskan, tambahkan bawang bombai, daun salam, daun jeruk, sereh dan lengkuas
1. Masukkan ayam kedalam bumbu, beri kecap, garam, micin, gula jawa... dan masukkan daun kemangi....tes rasa....




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
