---
description: "Step-by-Step untuk membuat Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo terupdate"
title: "Step-by-Step untuk membuat Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo terupdate"
slug: 181-step-by-step-untuk-membuat-ayam-rica-rica-daun-kemangi-masakanindo-terupdate
date: 2020-09-18T05:32:49.825Z
image: https://img-global.cpcdn.com/recipes/55574b38704c0a24/751x532cq70/ayam-rica-rica-daun-kemangi-🇮🇩-masakanindo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/55574b38704c0a24/751x532cq70/ayam-rica-rica-daun-kemangi-🇮🇩-masakanindo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/55574b38704c0a24/751x532cq70/ayam-rica-rica-daun-kemangi-🇮🇩-masakanindo-foto-resep-utama.jpg
author: Myra Bowers
ratingvalue: 5
reviewcount: 12302
recipeingredient:
- "300 gr dada ayam dapat 5 potong"
- " Bumbu halus"
- "6 siung bawang merah"
- "2 siung bawang putih"
- "10 buah cabe merah keriting"
- "5 buah cabe rawit merah"
- "2 butir kemiri"
- "1 ruas kunyit"
- "1 ruas jahe aku skip"
- " Bahan tumis"
- "1 batang serai geprek"
- "5 lembar daun jeruk"
- "1 ruas lengkuas"
- "Secukupnya air matang"
- "1 ikat kemangi boleh lebih"
- "1 lembar daun bawang iris"
- "1 sdm gula merah"
- "1 sdt kaldu jamur"
- "1 sdt gula garam sesuaikan ya"
recipeinstructions:
- "Rebus ayam / goreng. Kalau mau mentahan, direbus bersamaan dengan bumbu tumis juga bisa. Kalo aku direbus dulu😉"
- "Blender bahan Bumbu Halus"
- "Panaskan minyak. Tumis Bahan tumis. Lalu tuang Bumbu halus. Masak bersamaan hingga harum, tambahkan sedikit air, gula merah, garam dan penyedap."
- "Masukkan ayam dan daun kemangi. Aduk2 hingga tercampur semua. Tambahkan daun bawang iris. Aduk rata, masak hingga air surut."
- "Test rasa. Kalau kurang, tambah gula garam ya."
- "Siap dihidangkan🥰 medok banget warnanya btw. Tapi pedesnya gak seberapa. Karena aku banyakin cabe keriting, bukan rawitnya."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 127 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo](https://img-global.cpcdn.com/recipes/55574b38704c0a24/751x532cq70/ayam-rica-rica-daun-kemangi-🇮🇩-masakanindo-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita jaga karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica rica daun kemangi 🇮🇩 #masakanindo yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa keistimewahan yang merupakan keragaman Nusantara



Keharmonisan rumah tangga bisa didapat dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang dapat anda praktekkan salah satunya ayam rica rica daun kemangi 🇮🇩 #masakanindo yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica rica daun kemangi 🇮🇩 #masakanindo tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo:

1. Harus ada 300 gr dada ayam (dapat 5 potong)
1. Dibutuhkan  Bumbu halus
1. Jangan lupa 6 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Harap siapkan 10 buah cabe merah keriting
1. Jangan lupa 5 buah cabe rawit merah
1. Dibutuhkan 2 butir kemiri
1. Siapkan 1 ruas kunyit
1. Dibutuhkan 1 ruas jahe (aku skip)
1. Harap siapkan  Bahan tumis
1. Harus ada 1 batang serai (geprek)
1. Jangan lupa 5 lembar daun jeruk
1. Harus ada 1 ruas lengkuas
1. Tambah Secukupnya air matang
1. Jangan lupa 1 ikat kemangi (boleh lebih)
1. Jangan lupa 1 lembar daun bawang iris
1. Harus ada 1 sdm gula merah
1. Jangan lupa 1 sdt kaldu jamur
1. Jangan lupa 1 sdt gula garam (sesuaikan ya)




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo:

1. Rebus ayam / goreng. Kalau mau mentahan, direbus bersamaan dengan bumbu tumis juga bisa. Kalo aku direbus dulu😉
1. Blender bahan Bumbu Halus
1. Panaskan minyak. Tumis Bahan tumis. Lalu tuang Bumbu halus. Masak bersamaan hingga harum, tambahkan sedikit air, gula merah, garam dan penyedap.
1. Masukkan ayam dan daun kemangi. Aduk2 hingga tercampur semua. Tambahkan daun bawang iris. Aduk rata, masak hingga air surut.
1. Test rasa. Kalau kurang, tambah gula garam ya.
1. Siap dihidangkan🥰 medok banget warnanya btw. Tapi pedesnya gak seberapa. Karena aku banyakin cabe keriting, bukan rawitnya.




Demikianlah cara membuat ayam rica rica daun kemangi 🇮🇩 #masakanindo yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan terbukti, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
