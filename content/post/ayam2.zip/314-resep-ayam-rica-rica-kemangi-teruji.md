---
description: "Resep : Ayam rica-rica kemangi Teruji"
title: "Resep : Ayam rica-rica kemangi Teruji"
slug: 314-resep-ayam-rica-rica-kemangi-teruji
date: 2021-01-16T21:09:58.396Z
image: https://img-global.cpcdn.com/recipes/6198f1b2c7695ee1/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6198f1b2c7695ee1/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6198f1b2c7695ee1/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Jesse Norton
ratingvalue: 4.2
reviewcount: 40253
recipeingredient:
- "500 gr ayam Beri perasan jeruk nipis dan garam Diamkan"
- "4 lembar daun jeruk"
- "2 lembar daun salam"
- "1 batang serai Memarkan"
- "1 jempol lengkuas Memarkan"
- "Segenggam kemangi"
- "secukupnya Gula garam kaldu jamur"
- "secukupnya Daun bawang"
- " Bumbu halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "2 cm jahe"
- "3 cm kunyit"
- "2 butir kemiri"
- "15 cabe rawit"
- "3 cabe merah besar"
- "1/2 sdt merica"
- "1/2 ketumbar"
recipeinstructions:
- "Tumis bumbu halus dengan sedikit minyak, masukan daun jeruk, serai, lengkuas dan daun salam. Tumis sampe wangi dan bumbu matang"
- "Masukan garam, gula, kaldu jamur. Aduk rata"
- "Masukan ayam. Aduk rata. Biarkan ayam sampe berubah warna kemudian tambahkan sedikit air untuk meresapkan bumbu. Tutup wajan"
- "Masak dengan api kecil sampe bumbu bener2 meresap ke dalam ayam dan ayam matang"
- "Terakhir masukan kemangi, aduk sebentar. Matikan api. Angkat dan sajikan"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 233 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/6198f1b2c7695ee1/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Indonesia

Kehangatan rumah tangga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Ayam rica-rica kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang bisa anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica kemangi:

1. Diperlukan 500 gr ayam. Beri perasan jeruk nipis dan garam. Diamkan
1. Jangan lupa 4 lembar daun jeruk
1. Diperlukan 2 lembar daun salam
1. Siapkan 1 batang serai. Memarkan
1. Harap siapkan 1 jempol lengkuas. Memarkan
1. Jangan lupa Segenggam kemangi
1. Harus ada secukupnya Gula, garam, kaldu jamur
1. Harap siapkan secukupnya Daun bawang
1. Tambah  Bumbu halus:
1. Tambah 5 siung bawang merah
1. Tambah 3 siung bawang putih
1. Harus ada 2 cm jahe
1. Diperlukan 3 cm kunyit
1. Tambah 2 butir kemiri
1. Jangan lupa 15 cabe rawit
1. Siapkan 3 cabe merah besar
1. Diperlukan 1/2 sdt merica
1. Jangan lupa 1/2 ketumbar




<!--inarticleads2-->

##### Langkah membuat  Ayam rica-rica kemangi:

1. Tumis bumbu halus dengan sedikit minyak, masukan daun jeruk, serai, lengkuas dan daun salam. Tumis sampe wangi dan bumbu matang
1. Masukan garam, gula, kaldu jamur. Aduk rata
1. Masukan ayam. Aduk rata. Biarkan ayam sampe berubah warna kemudian tambahkan sedikit air untuk meresapkan bumbu. Tutup wajan
1. Masak dengan api kecil sampe bumbu bener2 meresap ke dalam ayam dan ayam matang
1. Terakhir masukan kemangi, aduk sebentar. Matikan api. Angkat dan sajikan




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan teruji, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
