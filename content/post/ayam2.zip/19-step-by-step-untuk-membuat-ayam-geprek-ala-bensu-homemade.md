---
description: "Step-by-Step untuk membuat Ayam Geprek Ala bensu Homemade"
title: "Step-by-Step untuk membuat Ayam Geprek Ala bensu Homemade"
slug: 19-step-by-step-untuk-membuat-ayam-geprek-ala-bensu-homemade
date: 2020-10-23T07:33:05.380Z
image: https://img-global.cpcdn.com/recipes/759cade28b84ba48/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/759cade28b84ba48/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/759cade28b84ba48/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg
author: Mathilda Zimmerman
ratingvalue: 4.2
reviewcount: 26661
recipeingredient:
- "1/2 kg dada ayam fillet"
- " Adonan basah "
- "1 butir telur"
- "5 sdm tepung terigu"
- "1 siung bawang putih yang sudah dihaluskan"
- "Secukupnya merica"
- "Secukupnya kaldu bubuk"
- " Adonan kering"
- "500 gram tepung terigu aku pake segitiga biru"
- "2 Sdm tepung Maizena"
- "1 Sdm Tepung beras"
- "1/2 sdt baking powder"
- "Secukupnya kaldu bubuk dan garam"
- " Bahan sambel "
- "1 ons cabe rawit orange"
- "5 siung bawang putih"
- "3 siung bawang merah"
- "Secukupnya kaldu bubuk gula dan air"
recipeinstructions:
- "Potong-potong dada ayam menjadi beberapa potong, rendam dalam adonan basah kurang lebih 10 menit"
- "Kemudian masukan ayam dalam adonan kering, celupkan lagi dalam adonan basah dan kembali gulingkan ayam dalam adonan kering (tujuannya agar tepung menempel sempurna pada ayam)."
- "Goreng ayam pada minyak yang sudah panas hingga matang, angkat dan sisihkan."
- "Selanjutnya kita akan membuat sambalnya uleg kasar cabe rawit sisihkan dahulu"
- "Goreng bawang merah dan bawang putih yang sudah diiris lalu tambahkan pada ulegan cabe rawit tadi kemudian uleg kembali. (catatan : menggoreng bawangnya cukup sebentar saja)"
- "Tumis sambal menggunakan minyak sisa menggoreng bawang, berikan air secukupnya kemudian masukan gula pasir dan kaldu bubuk koreksi rasa, setelah air menyusut angkat sambal (tekstur sambal tidak kering masih sedikit basah)"
- "Ambil cobek bersih kemudian geprek ayam dan berikan sambal diatasnya beserta dengan lalapan."
categories:
- Recipe
tags:
- ayam
- geprek
- ala

katakunci: ayam geprek ala 
nutrition: 188 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Geprek Ala bensu](https://img-global.cpcdn.com/recipes/759cade28b84ba48/751x532cq70/ayam-geprek-ala-bensu-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam geprek ala bensu yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan ciri khas yang merupakan keragaman Kita

Kedekatan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam Geprek Ala bensu untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang bisa anda praktekkan salah satunya ayam geprek ala bensu yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep ayam geprek ala bensu tanpa harus bersusah payah.
Seperti resep Ayam Geprek Ala bensu yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Ala bensu:

1. Harap siapkan 1/2 kg dada ayam fillet
1. Dibutuhkan  Adonan basah :
1. Harus ada 1 butir telur
1. Diperlukan 5 sdm tepung terigu
1. Harap siapkan 1 siung bawang putih yang sudah dihaluskan
1. Diperlukan Secukupnya merica
1. Harap siapkan Secukupnya kaldu bubuk
1. Siapkan  Adonan kering
1. Harus ada 500 gram tepung terigu (aku pake segitiga biru)
1. Diperlukan 2 Sdm tepung Maizena
1. Jangan lupa 1 Sdm Tepung beras
1. Siapkan 1/2 sdt baking powder
1. Tambah Secukupnya kaldu bubuk dan garam
1. Jangan lupa  Bahan sambel :
1. Harap siapkan 1 ons cabe rawit orange
1. Siapkan 5 siung bawang putih
1. Tambah 3 siung bawang merah
1. Siapkan Secukupnya kaldu bubuk, gula dan air




<!--inarticleads2-->

##### Langkah membuat  Ayam Geprek Ala bensu:

1. Potong-potong dada ayam menjadi beberapa potong, rendam dalam adonan basah kurang lebih 10 menit
1. Kemudian masukan ayam dalam adonan kering, celupkan lagi dalam adonan basah dan kembali gulingkan ayam dalam adonan kering (tujuannya agar tepung menempel sempurna pada ayam).
1. Goreng ayam pada minyak yang sudah panas hingga matang, angkat dan sisihkan.
1. Selanjutnya kita akan membuat sambalnya uleg kasar cabe rawit sisihkan dahulu
1. Goreng bawang merah dan bawang putih yang sudah diiris lalu tambahkan pada ulegan cabe rawit tadi kemudian uleg kembali. (catatan : menggoreng bawangnya cukup sebentar saja)
1. Tumis sambal menggunakan minyak sisa menggoreng bawang, berikan air secukupnya kemudian masukan gula pasir dan kaldu bubuk koreksi rasa, setelah air menyusut angkat sambal (tekstur sambal tidak kering masih sedikit basah)
1. Ambil cobek bersih kemudian geprek ayam dan berikan sambal diatasnya beserta dengan lalapan.




Demikianlah cara membuat ayam geprek ala bensu yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
