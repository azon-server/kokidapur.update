---
description: "Resep : Ayam Rica-rica Kemangi Teruji"
title: "Resep : Ayam Rica-rica Kemangi Teruji"
slug: 198-resep-ayam-rica-rica-kemangi-teruji
date: 2020-08-25T06:28:48.875Z
image: https://img-global.cpcdn.com/recipes/00bd827261d1c0d9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/00bd827261d1c0d9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/00bd827261d1c0d9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Gussie Snyder
ratingvalue: 4.4
reviewcount: 36532
recipeingredient:
- "1/2 kg Daging ayam paha atas"
- "1 ikat Kemangi siangi  cuci"
- "1 buah Jeruk nipis"
- "2 batang Serai geprek"
- "2 lembar Daun salam tambahan sy"
- "5 lembar Daun jeruk"
- "1 ruas Lengkuas geprek"
- "1 batang Daun bawang iris"
- "1 sdm Gula merah"
- "Secukupnya Garam  Kaldu ayam bubuk"
- "Secukupnya Air"
- "Secukupnya Minyak goreng utk menumis"
- " Bumbu halus "
- "6 buah Bawang merah"
- "2 siung Bawang putih"
- "6 buah Cabe merah keriting"
- "10 buah Cabe rawit domba"
- "2 buah Kemiri"
- "1 ruas Jahe"
- "1 ruas Kunyit"
recipeinstructions:
- "Beri perasan jeruk nipis pada daging ayam. Diamkan selama 30 menit. Cuci bersih dan potong2 sesuai selera."
- "Panaskan minyak goreng, tumis bumbu halus, serai, daun salam, daun jeruk, dan lengkuas hingga harum. Masukkan daging ayam, masak hingga berubah warna kemudian tambah air hingga menutupi daging ayam."
- "Masukkan garam, kaldu ayam bubuk, dan gula merah. Aduk rata. Masak hingga air mengental dan daging empuk. Koreksi rasa."
- "Terakhir masukkan kemangi dan daun bawang. Matikan api kompor. Ayam rica-rica kemangi siap disajikan 🥰🥰"
- "Makan sama nasi panas aja udh nikmaaat bangeettt 😋😋"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 203 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT58M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/00bd827261d1c0d9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica-rica kemangi yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa kesan tersendiri yang merupakan keragaman Kita



Kedekatan keluarga bisa diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam Rica-rica Kemangi untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang dapat anda coba salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 20 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica Kemangi:

1. Diperlukan 1/2 kg Daging ayam (paha atas)
1. Jangan lupa 1 ikat Kemangi, siangi &amp; cuci
1. Siapkan 1 buah Jeruk nipis
1. Jangan lupa 2 batang Serai, geprek
1. Dibutuhkan 2 lembar Daun salam (tambahan sy)
1. Siapkan 5 lembar Daun jeruk
1. Dibutuhkan 1 ruas Lengkuas, geprek
1. Tambah 1 batang Daun bawang, iris
1. Jangan lupa 1 sdm Gula merah
1. Siapkan Secukupnya Garam &amp; Kaldu ayam bubuk
1. Jangan lupa Secukupnya Air
1. Dibutuhkan Secukupnya Minyak goreng (utk menumis)
1. Harap siapkan  Bumbu halus :
1. Siapkan 6 buah Bawang merah
1. Diperlukan 2 siung Bawang putih
1. Jangan lupa 6 buah Cabe merah keriting
1. Diperlukan 10 buah Cabe rawit domba
1. Harus ada 2 buah Kemiri
1. Diperlukan 1 ruas Jahe
1. Dibutuhkan 1 ruas Kunyit




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-rica Kemangi:

1. Beri perasan jeruk nipis pada daging ayam. Diamkan selama 30 menit. Cuci bersih dan potong2 sesuai selera.
1. Panaskan minyak goreng, tumis bumbu halus, serai, daun salam, daun jeruk, dan lengkuas hingga harum. Masukkan daging ayam, masak hingga berubah warna kemudian tambah air hingga menutupi daging ayam.
1. Masukkan garam, kaldu ayam bubuk, dan gula merah. Aduk rata. Masak hingga air mengental dan daging empuk. Koreksi rasa.
1. Terakhir masukkan kemangi dan daun bawang. Matikan api kompor. Ayam rica-rica kemangi siap disajikan 🥰🥰
1. Makan sama nasi panas aja udh nikmaaat bangeettt 😋😋




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan cepat, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
