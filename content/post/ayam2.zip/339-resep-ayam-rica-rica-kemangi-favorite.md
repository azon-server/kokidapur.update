---
description: "Resep : Ayam rica rica kemangi Favorite"
title: "Resep : Ayam rica rica kemangi Favorite"
slug: 339-resep-ayam-rica-rica-kemangi-favorite
date: 2020-11-23T21:54:25.439Z
image: https://img-global.cpcdn.com/recipes/a6da5e21bb1f2bf4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a6da5e21bb1f2bf4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a6da5e21bb1f2bf4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Rosa Griffin
ratingvalue: 4.2
reviewcount: 27637
recipeingredient:
- "1/2 kg ayam"
- "3 cabe rawit"
- "3 cabe besar"
- "4 daun salam"
- "4 daun jeruk"
- "2 batang sereh"
- "2 ruas jari jahe"
- "3 batang daun bawang"
- "4 tangkai daun kemangi"
- "2 sachet kecap bango"
- "1/2 buah gula jawa ukuran kecil"
- " Bumbu halus"
- "4 siung bawang putih"
- "5 siung bawang merah"
- "1 sdm ketumbar"
- "1/2 sdm merica"
- "5 buah kemiri"
recipeinstructions:
- "Haluskan bumbu halus. Kemudian geprek sereh dan jahe. Tumis bumbu halus kemudian masukkan sereh, jahe, daun salam dan daun jeruk."
- "Setelah tercium harum aromanya masukkan ayam yang sudah dibersihkan. Kemudian tambahkan kecap bango, gula jawa serta air. Setelah air menyurut tambahkan air untuk kedua kalinya. Agar bumbu meresap."
- "Setelah bumbu mengental tambahkan daun kemangi serta daun bawang. Masak sebentar kemudian hidangkan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 259 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/a6da5e21bb1f2bf4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan renyah. Ciri makanan Indonesia ayam rica rica kemangi yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam rica rica kemangi untuk keluarga. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang bisa anda buat salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Harus ada 1/2 kg ayam
1. Siapkan 3 cabe rawit
1. Siapkan 3 cabe besar
1. Harus ada 4 daun salam
1. Jangan lupa 4 daun jeruk
1. Jangan lupa 2 batang sereh
1. Jangan lupa 2 ruas jari jahe
1. Tambah 3 batang daun bawang
1. Jangan lupa 4 tangkai daun kemangi
1. Diperlukan 2 sachet kecap bango
1. Tambah 1/2 buah gula jawa ukuran kecil
1. Harap siapkan  Bumbu halus
1. Harap siapkan 4 siung bawang putih
1. Jangan lupa 5 siung bawang merah
1. Harus ada 1 sdm ketumbar
1. Harap siapkan 1/2 sdm merica
1. Tambah 5 buah kemiri




<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica kemangi:

1. Haluskan bumbu halus. Kemudian geprek sereh dan jahe. Tumis bumbu halus kemudian masukkan sereh, jahe, daun salam dan daun jeruk.
1. Setelah tercium harum aromanya masukkan ayam yang sudah dibersihkan. Kemudian tambahkan kecap bango, gula jawa serta air. Setelah air menyurut tambahkan air untuk kedua kalinya. Agar bumbu meresap.
1. Setelah bumbu mengental tambahkan daun kemangi serta daun bawang. Masak sebentar kemudian hidangkan.




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat gampang dan cepat, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
