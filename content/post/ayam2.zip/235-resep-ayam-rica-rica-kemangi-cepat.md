---
description: "Resep : Ayam Rica-Rica Kemangi Cepat"
title: "Resep : Ayam Rica-Rica Kemangi Cepat"
slug: 235-resep-ayam-rica-rica-kemangi-cepat
date: 2020-11-04T08:03:37.250Z
image: https://img-global.cpcdn.com/recipes/5826f8570558c09a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5826f8570558c09a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5826f8570558c09a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Eunice Kelley
ratingvalue: 4.6
reviewcount: 16724
recipeingredient:
- "7 potong ayam beri perasan jeruk nipis  garam diamkan 10 menit"
- "4 lembar daun jeruk"
- "2 lbr daun salam"
- "1 batang serai memarkan"
- "3 cm lengkuas memarkan"
- "1 ikat kecil kemangi"
- "8 gr kaldu jamur"
- "2 sdm kecap manis"
- "Secukupnya gula dan garam"
- "400 ml air"
- " Bumbu Halus"
- "5 bawang merah"
- "5 bawang putih"
- "2 kemiri"
- "10 cabe rawit"
- "5 cabe merah"
- "1/2 sdt merica"
- "3 cm kunyit"
- "2 cm jahe"
recipeinstructions:
- "Tumis bumbu halus dg sedikit minyak, masukkan daun jeruk, daun salam, serai dan lengkuas. Tumis sampai harum kemudian masukkan garam, gula dan kaldu jamur aduk sampai rata."
- "Masukkan ayam sampai ayam terlumuri rata dg bumbu, tambahkan air dan kecap aduk lagi kemudian tutup. Masak dg api kecil tunggu sampai bumbu meresap dan ayam matang."
- "Terakhir masukkan kemangi, aduk sebentar. Matikan api, angkat dan sajikan."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 212 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT30M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/5826f8570558c09a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang harus kita lestarikan karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan ciri khas yang merupakan keragaman Nusantara

Keharmonisan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica-Rica Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis makanan yang bisa anda contoh salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica Kemangi:

1. Siapkan 7 potong ayam, beri perasan jeruk nipis &amp; garam diamkan 10 menit
1. Dibutuhkan 4 lembar daun jeruk
1. Siapkan 2 lbr daun salam
1. Dibutuhkan 1 batang serai memarkan
1. Dibutuhkan 3 cm lengkuas memarkan
1. Harap siapkan 1 ikat kecil kemangi
1. Siapkan 8 gr kaldu jamur
1. Harus ada 2 sdm kecap manis
1. Dibutuhkan Secukupnya gula dan garam
1. Tambah 400 ml air
1. Jangan lupa  Bumbu Halus
1. Harus ada 5 bawang merah
1. Harus ada 5 bawang putih
1. Harus ada 2 kemiri
1. Tambah 10 cabe rawit
1. Diperlukan 5 cabe merah
1. Diperlukan 1/2 sdt merica
1. Jangan lupa 3 cm kunyit
1. Dibutuhkan 2 cm jahe




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica Kemangi:

1. Tumis bumbu halus dg sedikit minyak, masukkan daun jeruk, daun salam, serai dan lengkuas. Tumis sampai harum kemudian masukkan garam, gula dan kaldu jamur aduk sampai rata.
1. Masukkan ayam sampai ayam terlumuri rata dg bumbu, tambahkan air dan kecap aduk lagi kemudian tutup. Masak dg api kecil tunggu sampai bumbu meresap dan ayam matang.
1. Terakhir masukkan kemangi, aduk sebentar. Matikan api, angkat dan sajikan.




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan terbukti, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
