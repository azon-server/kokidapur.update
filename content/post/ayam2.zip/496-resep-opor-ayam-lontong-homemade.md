---
description: "Resep : Opor ayam lontong Homemade"
title: "Resep : Opor ayam lontong Homemade"
slug: 496-resep-opor-ayam-lontong-homemade
date: 2020-11-22T23:22:42.754Z
image: https://img-global.cpcdn.com/recipes/24a808476a2c63e3/751x532cq70/opor-ayam-lontong-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/24a808476a2c63e3/751x532cq70/opor-ayam-lontong-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/24a808476a2c63e3/751x532cq70/opor-ayam-lontong-foto-resep-utama.jpg
author: Lydia Leonard
ratingvalue: 4.9
reviewcount: 37142
recipeingredient:
- " Dada ayam dari  potong jadi 6"
- " jeruk nipis"
- " santan"
- " Bumbu halus "
- " bawang merah"
- " bawang putih"
- " kunyit"
- " jahe"
- " kemiri"
- " biji ketumbar"
- " garamkaldu bubuk dan gula pasir"
- " "
- " Bumbu pelengkap "
- " serai geprek"
- " daun salam"
- " daun jeruk"
- " lengkuas geprek"
- " Minyak untuk menumis"
- " Bahan pelengkap "
- " Lontong ada di resep sebelumnya"
- " Sambal merah"
- " Bawang goreng untuk taburan"
recipeinstructions:
- "Cuci bersih ayam beri perasan jeruk nipis biarkan 10 menit lalu bilas kembali"
- "Tumis bumbu halus sampai wangi lalu masukkan bumbu pelengkap sambil di aduk&#34;,,,kemudian masukkan ayam dan beri sedikit air masak sampai air menyusut atau sampai ayam empuk lalu matikan api"
- "Masukkan santan ke dalam panci lalu masak sampai mendidih sambil sesekali diaduk&#34; agar santan tidak pecah,,,setelah mendidih masukkan ayam yg tadi telah dimasak dengan bumbu beri garam,,kaldu bubuk dan gula pasir lalu masak sampai mendidih kembali kemudian tes rasa bila sudah ok matikan api"
- "Siapkan lontong dalam mangkok lalu siram dengan opor ayam yg baru matang beri sambal dan taburang bawang goreng,,,sajikan selagi hangat"
- "Selamat mencoba semoga bermanfaat..."
categories:
- Recipe
tags:
- opor
- ayam
- lontong

katakunci: opor ayam lontong 
nutrition: 282 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT55M"
recipeyield: "2"
recipecategory: Lunch

---


![Opor ayam lontong](https://img-global.cpcdn.com/recipes/24a808476a2c63e3/751x532cq70/opor-ayam-lontong-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang dapat kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti opor ayam lontong yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Nusantara

Keharmonisan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Opor ayam lontong untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang bisa anda coba salah satunya opor ayam lontong yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep opor ayam lontong tanpa harus bersusah payah.
Berikut ini resep Opor ayam lontong yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Opor ayam lontong:

1. Dibutuhkan  Dada ayam dari  (potong jadi 6)
1. Harap siapkan  jeruk nipis
1. Tambah  santan
1. Siapkan  Bumbu halus :
1. Harus ada  bawang merah
1. Harap siapkan  bawang putih
1. Harus ada  kunyit
1. Tambah  jahe
1. Diperlukan  kemiri
1. Tambah  biji ketumbar
1. Siapkan  garam,,kaldu bubuk dan gula pasir
1. Tambah  
1. Jangan lupa  Bumbu pelengkap :
1. Tambah  serai geprek
1. Dibutuhkan  daun salam
1. Tambah  daun jeruk
1. Tambah  lengkuas geprek
1. Diperlukan  Minyak untuk menumis
1. Harus ada  Bahan pelengkap :
1. Harus ada  Lontong (ada di resep sebelumnya)
1. Diperlukan  Sambal merah
1. Harap siapkan  Bawang goreng untuk taburan




<!--inarticleads2-->

##### Bagaimana membuat  Opor ayam lontong:

1. Cuci bersih ayam beri perasan jeruk nipis biarkan 10 menit lalu bilas kembali
1. Tumis bumbu halus sampai wangi lalu masukkan bumbu pelengkap sambil di aduk&#34;,,,kemudian masukkan ayam dan beri sedikit air masak sampai air menyusut atau sampai ayam empuk lalu matikan api
1. Masukkan santan ke dalam panci lalu masak sampai mendidih sambil sesekali diaduk&#34; agar santan tidak pecah,,,setelah mendidih masukkan ayam yg tadi telah dimasak dengan bumbu beri garam,,kaldu bubuk dan gula pasir lalu masak sampai mendidih kembali kemudian tes rasa bila sudah ok matikan api
1. Siapkan lontong dalam mangkok lalu siram dengan opor ayam yg baru matang beri sambal dan taburang bawang goreng,,,sajikan selagi hangat
1. Selamat mencoba semoga bermanfaat...




Demikianlah cara membuat opor ayam lontong yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan cepat, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
