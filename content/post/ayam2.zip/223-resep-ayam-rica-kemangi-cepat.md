---
description: "Resep : Ayam rica kemangi Cepat"
title: "Resep : Ayam rica kemangi Cepat"
slug: 223-resep-ayam-rica-kemangi-cepat
date: 2020-10-27T18:25:05.377Z
image: https://img-global.cpcdn.com/recipes/1a6b69d71b2dd347/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1a6b69d71b2dd347/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1a6b69d71b2dd347/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Matthew Gibbs
ratingvalue: 4.1
reviewcount: 18320
recipeingredient:
- "5 potong ayam paha atas"
- "3 ikat kemangi"
- "1 btg sereh geprek"
- "1 ruas jari lengkuas geprek"
- "7 lbr daun jeruk"
- "1 btg daun bawang iris"
- "Secukupnya air"
- "Secukupnya garam  kaldu jamur"
- " Bumbu halus "
- "6 siung bamer"
- "2 siung baput"
- "6 buah cabe merah kriting"
- "13 buah cabe rawit merah optional"
- "2 btr kemiri"
- "Secukupnya jahe  kunyit"
- "1 sdm gula merah"
recipeinstructions:
- "Cuci bersih ayam beri perasan jeruk nipis diamkan sesaat"
- "Goreng baput bamer cabe jahe hingga layu lalu blender bumbu halus. Tumis bumbu halus hingga harum masukan sereh, lengkuas &amp; d.jeruk"
- "Masukan ayam sampai berubah warna tuang air secukupnya masak sampai mendidih kuahnya tes rasa beri garam &amp; kaldu jamur. Masak sampai kuah mengental juga empuk ayamnya matang"
- "Setelah ayam matang matikan api kompor masukan daun bawang juga kemangi"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 277 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT46M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/1a6b69d71b2dd347/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang patut kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica kemangi yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan keistimewahan yang merupakan keragaman Indonesia

Kehangatan rumah tangga dapat ditemukan dengan cara mudah. Salah satunya adalah memasak Ayam rica kemangi untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang bisa anda buat salah satunya ayam rica kemangi yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi:

1. Siapkan 5 potong ayam (paha atas)
1. Harap siapkan 3 ikat kemangi
1. Diperlukan 1 btg sereh (geprek)
1. Tambah 1 ruas jari lengkuas (geprek)
1. Diperlukan 7 lbr daun jeruk
1. Siapkan 1 btg daun bawang (iris)
1. Diperlukan Secukupnya air
1. Harus ada Secukupnya garam &amp; kaldu jamur
1. Harus ada  Bumbu halus :
1. Jangan lupa 6 siung bamer
1. Diperlukan 2 siung baput
1. Diperlukan 6 buah cabe merah kriting
1. Diperlukan 13 buah cabe rawit merah (optional)
1. Jangan lupa 2 btr kemiri
1. Diperlukan Secukupnya jahe &amp; kunyit
1. Tambah 1 sdm gula merah




<!--inarticleads2-->

##### Cara membuat  Ayam rica kemangi:

1. Cuci bersih ayam beri perasan jeruk nipis diamkan sesaat
1. Goreng baput bamer cabe jahe hingga layu lalu blender bumbu halus. Tumis bumbu halus hingga harum masukan sereh, lengkuas &amp; d.jeruk
1. Masukan ayam sampai berubah warna tuang air secukupnya masak sampai mendidih kuahnya tes rasa beri garam &amp; kaldu jamur. Masak sampai kuah mengental juga empuk ayamnya matang
1. Setelah ayam matang matikan api kompor masukan daun bawang juga kemangi




Demikianlah cara membuat ayam rica kemangi yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat simple dan cepat, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
