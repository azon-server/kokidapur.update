---
description: "Cara untuk membuat Ayam rica-rica kemangi teraktual"
title: "Cara untuk membuat Ayam rica-rica kemangi teraktual"
slug: 271-cara-untuk-membuat-ayam-rica-rica-kemangi-teraktual
date: 2020-08-07T02:56:04.135Z
image: https://img-global.cpcdn.com/recipes/029afd3d1c76f932/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/029afd3d1c76f932/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/029afd3d1c76f932/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Vincent Terry
ratingvalue: 4.8
reviewcount: 37254
recipeingredient:
- "1/2 ekor ayam mau ayam kampungbiasa"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit boleh kuyit bubuk 1 sdt"
- "2 ruas laos"
- "1/2 sdt ketumbar"
- "1 sdm merica butir boleh pakai yg bubuk 1 sdt"
- "7 lembar daun jeruk"
- "2 lembar daun salam"
- "8 batang serai"
- "20 biji cabe rawit boleh ditambah kalau mau pedas lagi"
- "5 biji cabe keriting"
- "2 biji cabe merah yang besar"
- "1 biji jeruk nipis"
- "1 1/5 sdt garam"
- "1 sdm gula"
- "1 bungkus kaldu bubuk ayamboleh pakai kaldu jamur"
- "1 ikat kemangi segar"
- "4 sdm Minyak goreng untuk menumis dan 1 gelas air"
recipeinstructions:
- "Bersihkan ayam lalu potong-potong dan beri perasan jeruk nipis agar hilang baunya kemudian cuci lagi."
- "Kupas dan bersihkan bawang-bawangan, jahe,kunyit,laos dan serai"
- "Haluskan bawang-bawangan,jahe,kuyit,laos,ketumbar,merica,semua cabe dan 3 lembar daun jeruk. Kalau sudah halus betul baru tambahkan serai yang sudah dipotong-potong dulu lalu ulek/blender kasar saja."
- "Setelah bumbunya halus lalu tumis sampai wangi jangan lupa tambahkan daun salam setelah itu masukkan potongan ayam dan tambahkan segelas air."
- "Masak sampai meletup-letup atau bumbunya sudah meresap keayam tambahkan garam,gula dan penyedap rasanya."
- "Hiris korek api sisa daun jeruknya lalu tambahkan ke masakan dan koreksi rasanya lagi (tambahkan gula/penyadap rasanya bila kurang)."
- "Siap untuk dihidangkan dan jangan lupa tambahkan kemanginya. Selesai selamat mencoba..."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 286 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/029afd3d1c76f932/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang patut kita jaga karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica-rica kemangi yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan keistimewahan yang merupakan keragaman Indonesia

Keharmonisan rumah tangga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Ayam rica-rica kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang bisa anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica kemangi:

1. Siapkan 1/2 ekor ayam (mau ayam kampung/biasa)
1. Siapkan 8 siung bawang merah
1. Diperlukan 5 siung bawang putih
1. Harap siapkan 1 ruas jahe
1. Tambah 1 ruas kunyit (boleh kuyit bubuk 1 sdt)
1. Siapkan 2 ruas laos
1. Tambah 1/2 sdt ketumbar
1. Tambah 1 sdm merica butir (boleh pakai yg bubuk 1 sdt)
1. Harap siapkan 7 lembar daun jeruk
1. Diperlukan 2 lembar daun salam
1. Tambah 8 batang serai
1. Siapkan 20 biji cabe rawit (boleh ditambah kalau mau pedas lagi)
1. Dibutuhkan 5 biji cabe keriting
1. Jangan lupa 2 biji cabe merah yang besar
1. Siapkan 1 biji jeruk nipis
1. Harap siapkan 1 1/5 sdt garam
1. Tambah 1 sdm gula
1. Siapkan 1 bungkus kaldu bubuk ayam/boleh pakai kaldu jamur
1. Tambah 1 ikat kemangi segar
1. Jangan lupa 4 sdm Minyak goreng untuk menumis dan 1 gelas air




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica-rica kemangi:

1. Bersihkan ayam lalu potong-potong dan beri perasan jeruk nipis agar hilang baunya kemudian cuci lagi.
1. Kupas dan bersihkan bawang-bawangan, jahe,kunyit,laos dan serai
1. Haluskan bawang-bawangan,jahe,kuyit,laos,ketumbar,merica,semua cabe dan 3 lembar daun jeruk. Kalau sudah halus betul baru tambahkan serai yang sudah dipotong-potong dulu lalu ulek/blender kasar saja.
1. Setelah bumbunya halus lalu tumis sampai wangi jangan lupa tambahkan daun salam setelah itu masukkan potongan ayam dan tambahkan segelas air.
1. Masak sampai meletup-letup atau bumbunya sudah meresap keayam tambahkan garam,gula dan penyedap rasanya.
1. Hiris korek api sisa daun jeruknya lalu tambahkan ke masakan dan koreksi rasanya lagi (tambahkan gula/penyadap rasanya bila kurang).
1. Siap untuk dihidangkan dan jangan lupa tambahkan kemanginya. Selesai selamat mencoba...




Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
