---
description: "Resep : Ayam rica kemangi (diet) minggu ini"
title: "Resep : Ayam rica kemangi (diet) minggu ini"
slug: 203-resep-ayam-rica-kemangi-diet-minggu-ini
date: 2020-08-10T01:15:01.118Z
image: https://img-global.cpcdn.com/recipes/59e83bd16ba6f69d/751x532cq70/ayam-rica-kemangi-diet-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/59e83bd16ba6f69d/751x532cq70/ayam-rica-kemangi-diet-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/59e83bd16ba6f69d/751x532cq70/ayam-rica-kemangi-diet-foto-resep-utama.jpg
author: Rena Graves
ratingvalue: 4.7
reviewcount: 38754
recipeingredient:
- "120 gr Dada ayam tanpa kulit"
- "1 daun jeruk"
- "1 daun salam"
- "1 cm jahe"
- "1 cm lengkuas"
- "1/2 batang sereh"
- " garam  kaldu jamur"
- " gula diabetamil"
- "secukupnya kemangi"
- "1/4 buah tomat"
- " bumbu halus "
- "2 bawang merah"
- "1 bawang putih"
- "1/2 butir kemiri"
- "4 cabe merah keriting"
- "5 cabe rawit"
- "2 cm kunyit"
recipeinstructions:
- "Potong ayam sesuai selera prefer kecil&#34; biar cepet mateng"
- "Blender atau ulek bumbu halus kemudian tumis dengan air kurang lebih 100 -150 ml"
- "Kemudian masukkan sereh, daun salam, jahe, daun jeruk, dan lengkuas"
- "Tunggu hingga menyusut sedikit airnya dan masukkan ayam yg sudah di potong&#34;"
- "Setelah ayam sudah mulai putih / pucat tambahkan garam, gula diet dan totole aduk hingga matang"
- "Kemudian tambahkan tomat dan daun kemangi"
- "Ayam siap dihidangkan"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 190 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica kemangi (diet)](https://img-global.cpcdn.com/recipes/59e83bd16ba6f69d/751x532cq70/ayam-rica-kemangi-diet-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis dan gurih. Ciri khas masakan Nusantara ayam rica kemangi (diet) yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kehangatan rumah tangga bisa didapat dengan cara simple. Diantaranya adalah membuat makanan Ayam rica kemangi (diet) untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang dapat anda praktekkan salah satunya ayam rica kemangi (diet) yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica kemangi (diet) tanpa harus bersusah payah.
Seperti resep Ayam rica kemangi (diet) yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi (diet):

1. Harus ada 120 gr Dada ayam tanpa kulit
1. Harus ada 1 daun jeruk
1. Dibutuhkan 1 daun salam
1. Dibutuhkan 1 cm jahe
1. Harus ada 1 cm lengkuas
1. Harap siapkan 1/2 batang sereh
1. Diperlukan  garam / kaldu jamur
1. Tambah  gula diabetamil
1. Diperlukan secukupnya kemangi
1. Tambah 1/4 buah tomat
1. Jangan lupa  bumbu halus :
1. Tambah 2 bawang merah
1. Harus ada 1 bawang putih
1. Tambah 1/2 butir kemiri
1. Diperlukan 4 cabe merah keriting
1. Tambah 5 cabe rawit
1. Diperlukan 2 cm kunyit




<!--inarticleads2-->

##### Langkah membuat  Ayam rica kemangi (diet):

1. Potong ayam sesuai selera prefer kecil&#34; biar cepet mateng
1. Blender atau ulek bumbu halus kemudian tumis dengan air kurang lebih 100 -150 ml
1. Kemudian masukkan sereh, daun salam, jahe, daun jeruk, dan lengkuas
1. Tunggu hingga menyusut sedikit airnya dan masukkan ayam yg sudah di potong&#34;
1. Setelah ayam sudah mulai putih / pucat tambahkan garam, gula diet dan totole aduk hingga matang
1. Kemudian tambahkan tomat dan daun kemangi
1. Ayam siap dihidangkan
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam rica kemangi (diet)">



Demikianlah cara membuat ayam rica kemangi (diet) yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
