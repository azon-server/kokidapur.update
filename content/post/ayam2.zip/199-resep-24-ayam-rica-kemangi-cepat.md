---
description: "Resep : 24. Ayam Rica Kemangi Cepat"
title: "Resep : 24. Ayam Rica Kemangi Cepat"
slug: 199-resep-24-ayam-rica-kemangi-cepat
date: 2020-12-31T22:09:30.243Z
image: https://img-global.cpcdn.com/recipes/92f6fd87936a00a9/751x532cq70/24-ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/92f6fd87936a00a9/751x532cq70/24-ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/92f6fd87936a00a9/751x532cq70/24-ayam-rica-kemangi-foto-resep-utama.jpg
author: Josie Harper
ratingvalue: 5
reviewcount: 5464
recipeingredient:
- "1/2 kg ayam kampung muda"
- "1 papan kecil tempe"
- "Segenggam kemangi"
- " Kecap"
- " Garam"
- " Gula Kaldu jamur"
- " Air"
- " Bumbu halus "
- "3 siung bawang putih"
- "5 siung bawang merah"
- "8 buah cabe merah kriting"
- "5 buah cabe setan"
- "1 ruas jahe"
- "3 buah kemiri"
- "1 sdt ketumbar"
- "1/2 sdt merica"
- " Bumbu cemplung "
- "1 batang serai geprek"
- "1 helai daun jeruk wangi"
recipeinstructions:
- "Cuci bersih ayam lalu rebus sebentar. Setelah matang tiriskan."
- "Potong tempe sesuai selera."
- "Rebus juga bawang merah, bawang putih &amp; cabe. Setalah itu tiriskan."
- "Ulek bumbu yg direbus tadi. Tambahkan jahe, kemiri, ketumbar, &amp; merica. Ulek hingga halus."
- "Panaskan minyak, goreng tempe &amp; ayam hingga terlihat layu saja, jadi jangan lama². Tiriskan."
- "Siapkan wajan beri sedikit minyak. Tumis bumbu ulek, tambahkan juga daun jeruk &amp; serai. Tumis hingga harum. Tambahkan ir, didihkan."
- "Masukkan ayam &amp; tempe. Beri garam, gula &amp; kaldu jamur."
- "Setelah air menyusut masukkan potongan tomat, kemangi &amp; beri sedikit kecap. Koreksi rasa."
- "Biarkan sebentar, lalu mati kompor. Ayam rica kemangi siap disajikan."
categories:
- Recipe
tags:
- 24
- ayam
- rica

katakunci: 24 ayam rica 
nutrition: 285 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT50M"
recipeyield: "3"
recipecategory: Dessert

---


![24. Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/92f6fd87936a00a9/751x532cq70/24-ayam-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang harus kita jaga karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti 24. ayam rica kemangi yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan ciri khas yang merupakan keragaman Indonesia



Kehangatan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah memasak 24. Ayam Rica Kemangi untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang dapat anda contoh salah satunya 24. ayam rica kemangi yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep 24. ayam rica kemangi tanpa harus bersusah payah.
Seperti resep 24. Ayam Rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 9 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat 24. Ayam Rica Kemangi:

1. Harus ada 1/2 kg ayam kampung muda
1. Dibutuhkan 1 papan kecil tempe
1. Tambah Segenggam kemangi
1. Harus ada  Kecap
1. Tambah  Garam
1. Siapkan  Gula Kaldu jamur
1. Dibutuhkan  Air
1. Harap siapkan  Bumbu halus :
1. Siapkan 3 siung bawang putih
1. Harus ada 5 siung bawang merah
1. Harap siapkan 8 buah cabe merah kriting
1. Tambah 5 buah cabe setan
1. Jangan lupa 1 ruas jahe
1. Jangan lupa 3 buah kemiri
1. Tambah 1 sdt ketumbar
1. Tambah 1/2 sdt merica
1. Dibutuhkan  Bumbu cemplung :
1. Tambah 1 batang serai (geprek)
1. Diperlukan 1 helai daun jeruk wangi




<!--inarticleads2-->

##### Cara membuat  24. Ayam Rica Kemangi:

1. Cuci bersih ayam lalu rebus sebentar. Setelah matang tiriskan.
1. Potong tempe sesuai selera.
1. Rebus juga bawang merah, bawang putih &amp; cabe. Setalah itu tiriskan.
1. Ulek bumbu yg direbus tadi. Tambahkan jahe, kemiri, ketumbar, &amp; merica. Ulek hingga halus.
1. Panaskan minyak, goreng tempe &amp; ayam hingga terlihat layu saja, jadi jangan lama². Tiriskan.
1. Siapkan wajan beri sedikit minyak. Tumis bumbu ulek, tambahkan juga daun jeruk &amp; serai. Tumis hingga harum. Tambahkan ir, didihkan.
1. Masukkan ayam &amp; tempe. Beri garam, gula &amp; kaldu jamur.
1. Setelah air menyusut masukkan potongan tomat, kemangi &amp; beri sedikit kecap. Koreksi rasa.
1. Biarkan sebentar, lalu mati kompor. Ayam rica kemangi siap disajikan.




Demikianlah cara membuat 24. ayam rica kemangi yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
