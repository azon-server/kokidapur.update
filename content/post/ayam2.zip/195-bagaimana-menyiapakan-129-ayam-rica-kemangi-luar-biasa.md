---
description: "Bagaimana menyiapakan (1.29) Ayam Rica Kemangi Luar biasa"
title: "Bagaimana menyiapakan (1.29) Ayam Rica Kemangi Luar biasa"
slug: 195-bagaimana-menyiapakan-129-ayam-rica-kemangi-luar-biasa
date: 2020-10-17T10:54:18.482Z
image: https://img-global.cpcdn.com/recipes/55e72c9d8e7acfb6/751x532cq70/129-ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/55e72c9d8e7acfb6/751x532cq70/129-ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/55e72c9d8e7acfb6/751x532cq70/129-ayam-rica-kemangi-foto-resep-utama.jpg
author: Nicholas Barton
ratingvalue: 4
reviewcount: 43550
recipeingredient:
- "500 gr daging ayam fillet me SoesariRokerij potong dadu"
- "2 ikat kemangi petiki daunnya"
- "50 gr gula meraharen"
- "1 sdt garam sesuaikan selera"
- " Bumbu Cemplung"
- "1 batang sereh bag putih geprek"
- "5 lembar daun jeruk buang tulang daun"
- "10 buah cabe rawit"
- " Bumbu Halus"
- "8 buah cabe merah keriting"
- "2 buah cabe merah besar"
- "5 buah cabe rawit"
- "10 siung bawang merah"
- "4 buah bawang putih"
- "2 buah tomat"
- "2 sdt ketumbar sangrai"
- "2 sdm minyak"
recipeinstructions:
- "Tumis bumbu halus hingga harum"
- "Masukkan bumbu cemplung, masak hingga bumbu matang (berwarna lebih gelap dan harum)"
- "Masukkan ayam fillet + gula + garam, aduk rata, tes rasa, masak hingga bumbu meresap"
- "Matikan api, masukkan daun kemangi, aduk rata"
- "Sajikan"
- "Gula Aren yg digunakan"
categories:
- Recipe
tags:
- 129
- ayam
- rica

katakunci: 129 ayam rica 
nutrition: 108 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Dinner

---


![(1.29) Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/55e72c9d8e7acfb6/751x532cq70/129-ayam-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti (1.29) ayam rica kemangi yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan ciri khas yang merupakan keragaman Nusantara



Kedekatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak (1.29) Ayam Rica Kemangi untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang bisa anda contoh salah satunya (1.29) ayam rica kemangi yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep (1.29) ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep (1.29) Ayam Rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat (1.29) Ayam Rica Kemangi:

1. Dibutuhkan 500 gr daging ayam fillet (me: @SoesariRokerij), potong dadu
1. Harap siapkan 2 ikat kemangi, petiki daunnya
1. Jangan lupa 50 gr gula merah/aren
1. Dibutuhkan 1 sdt garam (sesuaikan selera)
1. Dibutuhkan  Bumbu Cemplung:
1. Harap siapkan 1 batang sereh bag. putih, geprek
1. Dibutuhkan 5 lembar daun jeruk, buang tulang daun
1. Tambah 10 buah cabe rawit
1. Tambah  Bumbu Halus:
1. Harus ada 8 buah cabe merah keriting
1. Jangan lupa 2 buah cabe merah besar
1. Diperlukan 5 buah cabe rawit
1. Tambah 10 siung bawang merah
1. Siapkan 4 buah bawang putih
1. Siapkan 2 buah tomat
1. Diperlukan 2 sdt ketumbar, sangrai
1. Tambah 2 sdm minyak




<!--inarticleads2-->

##### Bagaimana membuat  (1.29) Ayam Rica Kemangi:

1. Tumis bumbu halus hingga harum
1. Masukkan bumbu cemplung, masak hingga bumbu matang (berwarna lebih gelap dan harum)
1. Masukkan ayam fillet + gula + garam, aduk rata, tes rasa, masak hingga bumbu meresap
1. Matikan api, masukkan daun kemangi, aduk rata
1. Sajikan
1. Gula Aren yg digunakan




Demikianlah cara membuat (1.29) ayam rica kemangi yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
