---
description: "Bagaimana membuat Ayam geprek sambal korek Favorite"
title: "Bagaimana membuat Ayam geprek sambal korek Favorite"
slug: 111-bagaimana-membuat-ayam-geprek-sambal-korek-favorite
date: 2020-10-04T07:26:00.824Z
image: https://img-global.cpcdn.com/recipes/639d2dcf80947952/751x532cq70/ayam-geprek-sambal-korek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/639d2dcf80947952/751x532cq70/ayam-geprek-sambal-korek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/639d2dcf80947952/751x532cq70/ayam-geprek-sambal-korek-foto-resep-utama.jpg
author: Steve Sutton
ratingvalue: 4
reviewcount: 14707
recipeingredient:
- "1/2 kg dada atau paha ayam"
- "1 buah jeruk nipis atau lemon"
- " Bahan pencelup "
- "75 gr tepung terigu 7 sdm"
- "2 sdm Tepung maizena"
- "3 siung bawang putih parut"
- "1 sdt lada bubuk"
- "1 sdt garam"
- "1/2 sdt kaldu ayam"
- "1 sdt cabe bubuk  sesuai selera"
- "secukupnya Air dingin"
- " Bahan kering "
- "100 gr tepung terigu"
- "3 sdm tepung maizena"
- "1 sdt lada bubuk"
- "1 sdt garam"
- "1 sdt kaldu ayam"
- " Bahan sambal "
- "5 buah Cabe merah"
- "5 buah cabe rawit  sesuai selera"
- "3 siung bawang merah"
- "2 siung bawang putih"
- "Sejumput garam"
- "Sejumput gula"
- " Minyak panas"
recipeinstructions:
- "Cuci bersih ayam yang sudah dipotong, kucuri air jeruk nipis/ lemon. Diamkan kira-kira 10 menit, lalu bilas lagi hingga bersih."
- "Buat bahan pencelup : Campur semua bahan pencelup kecuali air, aduk rata. Tambahkan air sedikit-sedikit sampai tekstur kental."
- "Masukkan ayam yang sudah di cuci bersih kedalam bahan pencelup, masukkan kedalam kulkas minimal 30 menit agar bumbu meresap."
- "Buat bahan kering : Campur semua bahan, Aduk hingga rata."
- "Setelah 30 menit, gulingkan ayam ke bahan kering, sambil diremas-diremas,dicubit-cubit agar hasilnya keriting seperti ayam kfc."
- "Setelah itu panaskan minyak, Setelah minyak sudah panas masukkan ayam, goreng dgn api paling kecil agar matang sempurna. Angkat dan tiriskan."
- "Lalu buat sambal korek nya : ulek semua bahan sambal lalu siram dgn minyak panas yang digunakan untuk goreng ayam, aduk rata."
- "Geprek ayam menggunakan ulekan, lalu siram ayam dgn sambal korek 😀😀."
categories:
- Recipe
tags:
- ayam
- geprek
- sambal

katakunci: ayam geprek sambal 
nutrition: 293 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT60M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam geprek sambal korek](https://img-global.cpcdn.com/recipes/639d2dcf80947952/751x532cq70/ayam-geprek-sambal-korek-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam geprek sambal korek yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa keistimewahan yang merupakan keragaman Indonesia



Kedekatan keluarga bisa didapat dengan cara mudah. Diantaranya adalah memasak Ayam geprek sambal korek untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang bisa anda praktekkan salah satunya ayam geprek sambal korek yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep ayam geprek sambal korek tanpa harus bersusah payah.
Seperti resep Ayam geprek sambal korek yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 25 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam geprek sambal korek:

1. Tambah 1/2 kg dada atau paha ayam
1. Dibutuhkan 1 buah jeruk nipis atau lemon
1. Dibutuhkan  Bahan pencelup :
1. Harus ada 75 gr tepung terigu (7 sdm)
1. Harap siapkan 2 sdm Tepung maizena
1. Dibutuhkan 3 siung bawang putih parut
1. Siapkan 1 sdt lada bubuk
1. Jangan lupa 1 sdt garam
1. Dibutuhkan 1/2 sdt kaldu ayam
1. Tambah 1 sdt cabe bubuk / sesuai selera
1. Tambah secukupnya Air dingin
1. Harus ada  Bahan kering :
1. Harap siapkan 100 gr tepung terigu
1. Dibutuhkan 3 sdm tepung maizena
1. Tambah 1 sdt lada bubuk
1. Harap siapkan 1 sdt garam
1. Harap siapkan 1 sdt kaldu ayam
1. Siapkan  Bahan sambal :
1. Tambah 5 buah Cabe merah
1. Jangan lupa 5 buah cabe rawit / sesuai selera
1. Dibutuhkan 3 siung bawang merah
1. Harus ada 2 siung bawang putih
1. Tambah Sejumput garam
1. Tambah Sejumput gula
1. Harap siapkan  Minyak panas




<!--inarticleads2-->

##### Bagaimana membuat  Ayam geprek sambal korek:

1. Cuci bersih ayam yang sudah dipotong, kucuri air jeruk nipis/ lemon. Diamkan kira-kira 10 menit, lalu bilas lagi hingga bersih.
1. Buat bahan pencelup : Campur semua bahan pencelup kecuali air, aduk rata. Tambahkan air sedikit-sedikit sampai tekstur kental.
1. Masukkan ayam yang sudah di cuci bersih kedalam bahan pencelup, masukkan kedalam kulkas minimal 30 menit agar bumbu meresap.
1. Buat bahan kering : Campur semua bahan, Aduk hingga rata.
1. Setelah 30 menit, gulingkan ayam ke bahan kering, sambil diremas-diremas,dicubit-cubit agar hasilnya keriting seperti ayam kfc.
1. Setelah itu panaskan minyak, Setelah minyak sudah panas masukkan ayam, goreng dgn api paling kecil agar matang sempurna. Angkat dan tiriskan.
1. Lalu buat sambal korek nya : ulek semua bahan sambal lalu siram dgn minyak panas yang digunakan untuk goreng ayam, aduk rata.
1. Geprek ayam menggunakan ulekan, lalu siram ayam dgn sambal korek 😀😀.




Demikianlah cara membuat ayam geprek sambal korek yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan terbukti, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
