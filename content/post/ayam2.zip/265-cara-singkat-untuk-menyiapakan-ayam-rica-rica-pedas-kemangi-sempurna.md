---
description: "Cara singkat untuk menyiapakan Ayam rica rica pedas kemangi Sempurna"
title: "Cara singkat untuk menyiapakan Ayam rica rica pedas kemangi Sempurna"
slug: 265-cara-singkat-untuk-menyiapakan-ayam-rica-rica-pedas-kemangi-sempurna
date: 2020-09-29T12:00:45.035Z
image: https://img-global.cpcdn.com/recipes/1fee1fdf6e8059f8/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1fee1fdf6e8059f8/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1fee1fdf6e8059f8/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
author: Antonio Atkins
ratingvalue: 4.6
reviewcount: 21474
recipeingredient:
- "1/2 ekor ayam"
- "5 ikat kemangi"
- "3 helai daun salam"
- "3 helai daun jeruk"
- "2 batang serai"
- " Garam"
- " Kaldu jamur"
- "1 sdt Lada bubuk"
- "1 buah jeruk nipis"
- " Bumbu yang dihaluskan"
- "12 buah cabai rawit setan"
- "6 buah cabai merah"
- "4 buah bawang putih"
- "6 buah bawang merah"
- "1 ruas jahe"
- "1/2 ruas kunyit"
- "3 butir kemiri"
recipeinstructions:
- "5 potong ayam dicuci bersih, dikasih perasan jeruk nipis sedikit garam dan lada bubuk.. diamkan beberapa menit lalu goreng jangan terlalu lama.."
- "Haluskan cabe, bawang putih, bawang merah, jahe, kunyit dan kemiri.."
- "Panaskan minyak, masukkan bumbu yang dihaluskan tadi beserta daun salam, daun jeruk dan batang sereh yang telah digeprek."
- "Tumis hingga matang dan wangi, masukkan ayam yang telah digoreng setengah matang beri air secukup ny, beri Garam, kaldu jamur, dan gula secukup ny (sambil koreksi rasa)"
- "Cuci kemangi yang sudah dipetik daunnya.. Setelah kering air ayam ny aduk terus sampe keluar minyak dan bener bener tidak ada air ny lagi, masukkan kemangi aduk rata lalu matikan api.. sajikan dan santap.. selamat mencoba😁"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 162 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam rica rica pedas kemangi](https://img-global.cpcdn.com/recipes/1fee1fdf6e8059f8/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga empuk. Ciri khas makanan Indonesia ayam rica rica pedas kemangi yang penuh dengan rempah-rempah memberikan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kehangatan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam rica rica pedas kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang dapat anda praktekkan salah satunya ayam rica rica pedas kemangi yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep ayam rica rica pedas kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica rica pedas kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica pedas kemangi:

1. Diperlukan 1/2 ekor ayam
1. Tambah 5 ikat kemangi
1. Diperlukan 3 helai daun salam
1. Dibutuhkan 3 helai daun jeruk
1. Harap siapkan 2 batang serai
1. Harus ada  Garam
1. Harus ada  Kaldu jamur
1. Harus ada 1 sdt Lada bubuk
1. Diperlukan 1 buah jeruk nipis
1. Harap siapkan  Bumbu yang dihaluskan
1. Harap siapkan 12 buah cabai rawit setan
1. Diperlukan 6 buah cabai merah
1. Diperlukan 4 buah bawang putih
1. Siapkan 6 buah bawang merah
1. Tambah 1 ruas jahe
1. Jangan lupa 1/2 ruas kunyit
1. Diperlukan 3 butir kemiri




<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica pedas kemangi:

1. 5 potong ayam dicuci bersih, dikasih perasan jeruk nipis sedikit garam dan lada bubuk.. diamkan beberapa menit lalu goreng jangan terlalu lama..
1. Haluskan cabe, bawang putih, bawang merah, jahe, kunyit dan kemiri..
1. Panaskan minyak, masukkan bumbu yang dihaluskan tadi beserta daun salam, daun jeruk dan batang sereh yang telah digeprek.
1. Tumis hingga matang dan wangi, masukkan ayam yang telah digoreng setengah matang beri air secukup ny, beri Garam, kaldu jamur, dan gula secukup ny (sambil koreksi rasa)
1. Cuci kemangi yang sudah dipetik daunnya.. Setelah kering air ayam ny aduk terus sampe keluar minyak dan bener bener tidak ada air ny lagi, masukkan kemangi aduk rata lalu matikan api.. sajikan dan santap.. selamat mencoba😁




Demikianlah cara membuat ayam rica rica pedas kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
