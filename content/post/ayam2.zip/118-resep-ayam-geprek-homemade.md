---
description: "Resep : Ayam geprek Homemade"
title: "Resep : Ayam geprek Homemade"
slug: 118-resep-ayam-geprek-homemade
date: 2020-10-27T23:59:09.648Z
image: https://img-global.cpcdn.com/recipes/39cb46ea10ee9d9c/751x532cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/39cb46ea10ee9d9c/751x532cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/39cb46ea10ee9d9c/751x532cq70/ayam-geprek-foto-resep-utama.jpg
author: Sylvia James
ratingvalue: 4
reviewcount: 29241
recipeingredient:
- "5 potong ayam aku bagi 2"
- "1 buah Jeruk nipis"
- " Bahan kering"
- "15 sdm terigu segitiga"
- "2 sdm meizena"
- "1 sdm tepung beras"
- "1/2 sdt baking powder"
- "1/2 Bks kaldu"
- " Bahan basah"
- "8 sdm terigu"
- "1 putih telur"
- "1/2 sdt Garam"
- "1/2 sdt lada bubuk"
- "1 siung bawang putih giling"
- "Secukupnya air adonan kental"
- " Sambal cabe"
- "8-10 cabe merah"
- "6 cabe rawit"
- "3 siung bawang merah"
- "2 siung bawang putih"
- "1 buah tomat"
- "1 sdm gula merah halus"
- "1 terasi abc"
- "1/2 sdt garam"
- "secukupnya Garam"
recipeinstructions:
- "Bersihkan ayam, lalu beri perasan jeruk nipis dan garam. Diamkan di freezer 30 menit"
- "Sambil nunggu buat sambal dlu, goreng bahan sambal cabe kecuali gula dan garam. Lalu giling halus bersama garam dan gula. Panaskan minyak masukkan sambal cabe dan beri 1/8 perasan jeruk nipis."
- "Campurkan adonan basah dan juga adonan kering ditempat terpisah"
- "Celupkan ayam ke adonan basah lalu kering, ke adonan basah lalu kering lagi sambil dipijat ayamnya. Lalu siap di goreng diminyak panas"
- "Goreng hingga kuning kecoklatan dgn api kecil saja."
- "Sajikan bersama sambel tadi lalu geprek deh tambah nanas biar seger😋😋"
categories:
- Recipe
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 100 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam geprek](https://img-global.cpcdn.com/recipes/39cb46ea10ee9d9c/751x532cq70/ayam-geprek-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam geprek yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Indonesia



Keharmonisan keluarga bisa didapat dengan cara simple. Salah satunya adalah memasak Ayam geprek untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang dapat anda contoh salah satunya ayam geprek yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam geprek tanpa harus bersusah payah.
Berikut ini resep Ayam geprek yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 25 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam geprek:

1. Harus ada 5 potong ayam (aku bagi 2)
1. Siapkan 1 buah Jeruk nipis
1. Harus ada  Bahan kering
1. Tambah 15 sdm terigu segitiga
1. Harus ada 2 sdm meizena
1. Diperlukan 1 sdm tepung beras
1. Dibutuhkan 1/2 sdt baking powder
1. Dibutuhkan 1/2 Bks kaldu
1. Tambah  Bahan basah
1. Jangan lupa 8 sdm terigu
1. Harap siapkan 1 putih telur
1. Tambah 1/2 sdt Garam
1. Siapkan 1/2 sdt lada bubuk
1. Diperlukan 1 siung bawang putih (giling)
1. Tambah Secukupnya air (adonan kental)
1. Harap siapkan  Sambal cabe
1. Siapkan 8-10 cabe merah
1. Jangan lupa 6 cabe rawit
1. Diperlukan 3 siung bawang merah
1. Dibutuhkan 2 siung bawang putih
1. Jangan lupa 1 buah tomat
1. Jangan lupa 1 sdm gula merah halus
1. Harap siapkan 1 terasi abc
1. Harap siapkan 1/2 sdt garam
1. Tambah secukupnya Garam




<!--inarticleads2-->

##### Langkah membuat  Ayam geprek:

1. Bersihkan ayam, lalu beri perasan jeruk nipis dan garam. Diamkan di freezer 30 menit
1. Sambil nunggu buat sambal dlu, goreng bahan sambal cabe kecuali gula dan garam. Lalu giling halus bersama garam dan gula. Panaskan minyak masukkan sambal cabe dan beri 1/8 perasan jeruk nipis.
1. Campurkan adonan basah dan juga adonan kering ditempat terpisah
1. Celupkan ayam ke adonan basah lalu kering, ke adonan basah lalu kering lagi sambil dipijat ayamnya. Lalu siap di goreng diminyak panas
1. Goreng hingga kuning kecoklatan dgn api kecil saja.
1. Sajikan bersama sambel tadi lalu geprek deh tambah nanas biar seger😋😋




Demikianlah cara membuat ayam geprek yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
