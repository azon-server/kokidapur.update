---
description: "Steps menyiapakan Ayam rica rica Kemangi terupdate"
title: "Steps menyiapakan Ayam rica rica Kemangi terupdate"
slug: 259-steps-menyiapakan-ayam-rica-rica-kemangi-terupdate
date: 2020-12-19T02:57:01.652Z
image: https://img-global.cpcdn.com/recipes/8cc16fe364cb3ca4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8cc16fe364cb3ca4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8cc16fe364cb3ca4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Lura Greene
ratingvalue: 4.8
reviewcount: 4926
recipeingredient:
- "1/2 ekor ayam"
- "1 buah jeruk nipis"
- "1 liter air untuk merebus"
- " Bumbu halus "
- "4 butir bawang merah"
- "3 butir bawang putih"
- "1 ruas jahe kunyit Lengkuas"
- "5 cabai keriting"
- "3 cabai rawit merah"
- "2 butir kemiri"
- " Bumbu tambahan "
- "300 ml air"
- "2 lembar daun salam"
- "2 lembar serai"
- "2 sdm kecap"
- "1 sdt garam"
- "1/2 sdt gula pasir"
- "secukupnya Penyedap rasa"
- "1 sdt lada"
- " Kemangi"
recipeinstructions:
- "Cuci bersih ayam yg telah dipotong-potong. Kucuri dgn perasan jeruk nipis dan sdikit garam selama setengah jam. Lalu cuci kembali dan kemudian rebus"
- "Stelah ayam empuk sisihkan. Lalu goreng setengah matang."
- "Lalu haluskan bumbu halus. Bisa jg diblender."
- "Tumis bumbu halus, beserta sereh dan salam. Hingga harum dan berubah warna, masukan air. Kemudian kecap, gula, garam, lada dan penyedap rasa. Aduk2."
- "Setelah bumbu meresap masukan kemangi masak sebentar dan angkat."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 283 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica rica Kemangi](https://img-global.cpcdn.com/recipes/8cc16fe364cb3ca4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga empuk. Karasteristik makanan Indonesia ayam rica rica kemangi yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam rica rica Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang bisa anda coba salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica Kemangi:

1. Tambah 1/2 ekor ayam
1. Harus ada 1 buah jeruk nipis
1. Dibutuhkan 1 liter air (untuk merebus)
1. Harus ada  Bumbu halus :
1. Siapkan 4 butir bawang merah
1. Dibutuhkan 3 butir bawang putih
1. Diperlukan 1 ruas jahe, kunyit, Lengkuas
1. Harap siapkan 5 cabai keriting
1. Harus ada 3 cabai rawit merah
1. Siapkan 2 butir kemiri
1. Dibutuhkan  Bumbu tambahan :
1. Harus ada 300 ml air
1. Harus ada 2 lembar daun salam
1. Siapkan 2 lembar serai
1. Jangan lupa 2 sdm kecap
1. Tambah 1 sdt garam
1. Diperlukan 1/2 sdt gula pasir
1. Harus ada secukupnya Penyedap rasa
1. Harus ada 1 sdt lada
1. Diperlukan  Kemangi


Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica rica Kemangi:

1. Cuci bersih ayam yg telah dipotong-potong. Kucuri dgn perasan jeruk nipis dan sdikit garam selama setengah jam. Lalu cuci kembali dan kemudian rebus
1. Stelah ayam empuk sisihkan. Lalu goreng setengah matang.
1. Lalu haluskan bumbu halus. Bisa jg diblender.
1. Tumis bumbu halus, beserta sereh dan salam. Hingga harum dan berubah warna, masukan air. Kemudian kecap, gula, garam, lada dan penyedap rasa. Aduk2.
1. Setelah bumbu meresap masukan kemangi masak sebentar dan angkat.


Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Siapa yang tidak mengenal lalapan daun kemangi di Indonesia ini. Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. 

Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan teruji, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
