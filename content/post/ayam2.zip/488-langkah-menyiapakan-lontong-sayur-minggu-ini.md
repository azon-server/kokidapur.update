---
description: "Langkah menyiapakan Lontong sayur minggu ini"
title: "Langkah menyiapakan Lontong sayur minggu ini"
slug: 488-langkah-menyiapakan-lontong-sayur-minggu-ini
date: 2020-09-02T08:30:01.192Z
image: https://img-global.cpcdn.com/recipes/2ff65c149aa37fec/751x532cq70/lontong-sayur-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2ff65c149aa37fec/751x532cq70/lontong-sayur-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2ff65c149aa37fec/751x532cq70/lontong-sayur-foto-resep-utama.jpg
author: Ian McCormick
ratingvalue: 4.2
reviewcount: 48305
recipeingredient:
- " Lontong"
- " manisa"
- " udang kupas kulit nya"
- " wortel"
- " opor ayam resep bisa cek di menu sebelumnya"
- " santan 1 kelapa parut peras dengan air"
- " lengkuas memarkan"
- " daun salam"
- " serai memarkan"
- " lada putih merica"
- " Bawang pre"
- " Gula"
- " Garam"
- " kaldu ayam bubuk"
- " Bawang goreng"
- " minyak"
- " air"
- " Bumbu halus"
- " tomat"
- " cabe merah buang biji dan rebus dahulu"
- " kunyit"
- " kemiri"
- " bawang merah"
- " bawang putih"
- " air"
recipeinstructions:
- "Kupas dan iris tipis tipis buah manisa dan campur dengan garam untuk mengurangi getah dan agar irisan manisa menjadi lentur tidak mudah patah."
- "Tumis bumbu halus dan tambahkan lengkuas, daun salam, serai aduk sampai harum baunya dan bumbu matang."
- "Rebus terlebih dahulu wortel yang telah di iris iris setengah matang."
- "Masukkan buah manisa, udang, wortel kemudian aduk merata dengan bumbu nya dan tambahkan santan."
- "Tambahkan gula, merica aduk hingga air menyusut kemudian tambahkan garam dan kaldu ayam. Aduk dan cek rasa."
- "Tambahkan irisan bawang prei aduk sampai merata."
- "Penyajian :Potong lontong sesuai selera kemudian tambahkan sayur manisa dan taburi bawang goreng diatasnya, tambah 1 potong opor ayam beri krupuk dan lontong sayur siap disajikan."
categories:
- Recipe
tags:
- lontong
- sayur

katakunci: lontong sayur 
nutrition: 249 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Lunch

---


![Lontong sayur](https://img-global.cpcdn.com/recipes/2ff65c149aa37fec/751x532cq70/lontong-sayur-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau empuk. Karasteristik makanan Nusantara lontong sayur yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah memasak Lontong sayur untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang bisa anda coba salah satunya lontong sayur yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep lontong sayur tanpa harus bersusah payah.
Berikut ini resep Lontong sayur yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 25 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Lontong sayur:

1. Harus ada  Lontong
1. Diperlukan  manisa
1. Dibutuhkan  udang (kupas kulit nya)
1. Dibutuhkan  wortel
1. Harap siapkan  opor ayam (resep bisa cek di menu sebelumnya
1. Harus ada  santan (1 kelapa parut peras dengan air)
1. Harap siapkan  lengkuas (memarkan)
1. Harus ada  daun salam
1. Tambah  serai (memarkan)
1. Siapkan  lada putih (merica)
1. Diperlukan  Bawang pre
1. Harap siapkan  Gula
1. Harus ada  Garam
1. Siapkan  kaldu ayam bubuk
1. Dibutuhkan  Bawang goreng
1. Dibutuhkan  minyak
1. Diperlukan  air
1. Dibutuhkan  Bumbu halus
1. Harap siapkan  tomat
1. Dibutuhkan  cabe merah (buang biji dan rebus dahulu)
1. Jangan lupa  kunyit
1. Tambah  kemiri
1. Jangan lupa  bawang merah
1. Dibutuhkan  bawang putih
1. Jangan lupa  air




<!--inarticleads2-->

##### Instruksi membuat  Lontong sayur:

1. Kupas dan iris tipis tipis buah manisa dan campur dengan garam untuk mengurangi getah dan agar irisan manisa menjadi lentur tidak mudah patah.
1. Tumis bumbu halus dan tambahkan lengkuas, daun salam, serai aduk sampai harum baunya dan bumbu matang.
1. Rebus terlebih dahulu wortel yang telah di iris iris setengah matang.
1. Masukkan buah manisa, udang, wortel kemudian aduk merata dengan bumbu nya dan tambahkan santan.
1. Tambahkan gula, merica aduk hingga air menyusut kemudian tambahkan garam dan kaldu ayam. Aduk dan cek rasa.
1. Tambahkan irisan bawang prei aduk sampai merata.
1. Penyajian :Potong lontong sesuai selera kemudian tambahkan sayur manisa dan taburi bawang goreng diatasnya, tambah 1 potong opor ayam beri krupuk dan lontong sayur siap disajikan.




Demikianlah cara membuat lontong sayur yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
