---
description: "Panduan menyiapakan Ayam Rica Kemangi ala Nona Angela Terbukti"
title: "Panduan menyiapakan Ayam Rica Kemangi ala Nona Angela Terbukti"
slug: 306-panduan-menyiapakan-ayam-rica-kemangi-ala-nona-angela-terbukti
date: 2021-02-03T11:07:00.730Z
image: https://img-global.cpcdn.com/recipes/4fa8d727cf475f67/751x532cq70/ayam-rica-kemangi-ala-nona-angela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4fa8d727cf475f67/751x532cq70/ayam-rica-kemangi-ala-nona-angela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4fa8d727cf475f67/751x532cq70/ayam-rica-kemangi-ala-nona-angela-foto-resep-utama.jpg
author: Celia Harper
ratingvalue: 4.3
reviewcount: 39688
recipeingredient:
- "1/2 kg ayam tanpa tulang bagian paha"
- "4 lembar daun jeruk buang batangnya"
- "1 ikat kemangi"
- "1 batang sereh iris tipis"
- "2 lembar daun salam"
- " Dihaluskan agak kasar"
- "4 cabe rawit"
- "10 cabe keriting"
- "5 buah bawang merah"
- "2 siung bawang putih"
- "1 butir kemiri"
- "3 cm jahe"
- "3 cm kunyit"
- "1 buat tomat"
- " Garam"
- " Lada putih"
- " Gula"
recipeinstructions:
- "Tumis bumbu yg sudah dihaluskan (diuleknya agak kasar ya)dengan sedikit minyak panas hingga harum, setelah itu masukkan daun salam dan daun jeruk dan serai."
- "Setelah itu masukkan daging ayam yg telah dipotong dadu,tambahkan garam, lada putih dan gula secukupnya."
- "Setelah ayam terlihat matang masukkan daun kemangi, aduk hingga menyatu. Setelah daun terlihat layu masakan siap disajikan. Selamat mencoba rasa sudah pasti enak dan mantap 👍🏻"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 236 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica Kemangi ala Nona Angela](https://img-global.cpcdn.com/recipes/4fa8d727cf475f67/751x532cq70/ayam-rica-kemangi-ala-nona-angela-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica kemangi ala nona angela yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Nusantara



Kedekatan keluarga bisa ditemukan dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica Kemangi ala Nona Angela untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis makanan yang bisa anda praktekkan salah satunya ayam rica kemangi ala nona angela yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep ayam rica kemangi ala nona angela tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi ala Nona Angela yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi ala Nona Angela:

1. Jangan lupa 1/2 kg ayam tanpa tulang bagian paha
1. Tambah 4 lembar daun jeruk (buang batangnya)
1. Harus ada 1 ikat kemangi
1. Tambah 1 batang sereh (iris tipis)
1. Dibutuhkan 2 lembar daun salam
1. Dibutuhkan  Dihaluskan (agak kasar)
1. Tambah 4 cabe rawit
1. Tambah 10 cabe keriting
1. Diperlukan 5 buah bawang merah
1. Siapkan 2 siung bawang putih
1. Diperlukan 1 butir kemiri
1. Tambah 3 cm jahe
1. Diperlukan 3 cm kunyit
1. Siapkan 1 buat tomat
1. Jangan lupa  Garam
1. Jangan lupa  Lada putih
1. Tambah  Gula




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Kemangi ala Nona Angela:

1. Tumis bumbu yg sudah dihaluskan (diuleknya agak kasar ya)dengan sedikit minyak panas hingga harum, setelah itu masukkan daun salam dan daun jeruk dan serai.
1. Setelah itu masukkan daging ayam yg telah dipotong dadu,tambahkan garam, lada putih dan gula secukupnya.
1. Setelah ayam terlihat matang masukkan daun kemangi, aduk hingga menyatu. Setelah daun terlihat layu masakan siap disajikan. Selamat mencoba rasa sudah pasti enak dan mantap 👍🏻




Demikianlah cara membuat ayam rica kemangi ala nona angela yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
