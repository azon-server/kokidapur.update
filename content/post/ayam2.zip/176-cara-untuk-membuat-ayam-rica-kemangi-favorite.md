---
description: "Cara untuk membuat Ayam rica kemangi Favorite"
title: "Cara untuk membuat Ayam rica kemangi Favorite"
slug: 176-cara-untuk-membuat-ayam-rica-kemangi-favorite
date: 2020-08-14T13:10:21.372Z
image: https://img-global.cpcdn.com/recipes/7969cf0328000380/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7969cf0328000380/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7969cf0328000380/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Miguel Gonzales
ratingvalue: 4.5
reviewcount: 23244
recipeingredient:
- "1 ekor ayam"
- " Jeruk nipis"
- "secukupnya Kemangi"
- "8 cabai merah keriting"
- "5 cabai rawit merah opsional kalau mau ekstra pedas"
- "8 bawang merah"
- "5 bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "4 kemiri"
- "1 lb daun jeruk"
- "1 lb daun salam"
- "2 batang serai"
- " Garam"
- "1 Bks Royco"
recipeinstructions:
- "Cuci bersih ayam Baluri ayam dengan jeruk nipis, diamkan selama 10 menit lalu cuci bersih kembali"
- "Blender halus, kemiri, cabai, duo bawang, jahe dan kunyit lalu tumis dengan minyak panas hingga harum"
- "Iris tipis daun jeruk dan sereh, masukkan ke dalam tumisan bumbu halus tambahkan daun salam, Royco dan garam lalu koreksi rasa"
- "Jika bumbu sudah matang masukan ayam aduk hingga seluruh ayam terkena bumbu lalu beri air hingga ayam terendam"
- "Diamkan hingga air menyusut, sesekali aduk ayam agar matang merata"
- "Setelah hampir matang masukan kemangi dan tunggu hingga layu, selesai"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 115 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/7969cf0328000380/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang patut kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica kemangi yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa keistimewahan yang merupakan keragaman Indonesia



Keharmonisan rumah tangga dapat diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Ayam rica kemangi untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang bisa anda praktekkan salah satunya ayam rica kemangi yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi:

1. Dibutuhkan 1 ekor ayam
1. Harap siapkan  Jeruk nipis
1. Diperlukan secukupnya Kemangi
1. Dibutuhkan 8 cabai merah keriting
1. Siapkan 5 cabai rawit merah (opsional kalau mau ekstra pedas)
1. Harus ada 8 bawang merah
1. Jangan lupa 5 bawang putih
1. Siapkan 1 ruas jahe
1. Siapkan 1 ruas kunyit
1. Harap siapkan 4 kemiri
1. Jangan lupa 1 lb daun jeruk
1. Harus ada 1 lb daun salam
1. Tambah 2 batang serai
1. Diperlukan  Garam
1. Harus ada 1 Bks Royco




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica kemangi:

1. Cuci bersih ayam Baluri ayam dengan jeruk nipis, diamkan selama 10 menit lalu cuci bersih kembali
1. Blender halus, kemiri, cabai, duo bawang, jahe dan kunyit lalu tumis dengan minyak panas hingga harum
1. Iris tipis daun jeruk dan sereh, masukkan ke dalam tumisan bumbu halus tambahkan daun salam, Royco dan garam lalu koreksi rasa
1. Jika bumbu sudah matang masukan ayam aduk hingga seluruh ayam terkena bumbu lalu beri air hingga ayam terendam
1. Diamkan hingga air menyusut, sesekali aduk ayam agar matang merata
1. Setelah hampir matang masukan kemangi dan tunggu hingga layu, selesai




Demikianlah cara membuat ayam rica kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan terbukti, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
