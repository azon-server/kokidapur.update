---
description: "Langkah untuk menyiapakan Ayam rica-rica kemangi Teruji"
title: "Langkah untuk menyiapakan Ayam rica-rica kemangi Teruji"
slug: 188-langkah-untuk-menyiapakan-ayam-rica-rica-kemangi-teruji
date: 2020-08-20T16:48:37.191Z
image: https://img-global.cpcdn.com/recipes/350af9a22f60ab8d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/350af9a22f60ab8d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/350af9a22f60ab8d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Beulah Yates
ratingvalue: 5
reviewcount: 7900
recipeingredient:
- "500 gr daging ayam"
- "1 ikat kemangi petik daun nya"
- "1 batang daun bawang potong2 me skip"
- "3 lembar daun bawang"
- "1 batang sere geprek"
- "1 ruas lengkuas geprek"
- "secukupnya Garam gula pasir penyedap"
- "500 ml air  selera saja"
- " Bumbu halus"
- "10 cabe merah keriting"
- "10 cabe rawit merah"
- "5 siung bawang merah"
- "3 Siung bawang putih"
- "3 butir kemiri sangrai"
- "1 ruas kunyit"
- "1 ruas jahe"
recipeinstructions:
- "Potong-potong daging ayam sesuai selera,cuci bersih,beri perasan jeruk nipis diamkan sebentar lalu cuci bersih"
- "Tumis bumbu halus, daun jeruk,sere dan lengkuas hingga harum,lalu masukan ayam nya,aduk hingga ayam berubah warna"
- "Lalu masukan air,aduk rata hingga airnya macak²,masukan gula pasir,garam, penyadap secukupnya tes rasa"
- "Setelah airnya menyusut,dan lima menit sebelum d angkat,masukan potongan daun bawang dan kemangi,aduk sebentar saja lalu angkat dan siap d sajikan"
- "Selamat mencoba"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 141 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/350af9a22f60ab8d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga enak. Ciri makanan Indonesia ayam rica-rica kemangi yang penuh dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ayam rica-rica kemangi untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang dapat anda coba salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica kemangi:

1. Siapkan 500 gr daging ayam
1. Diperlukan 1 ikat kemangi petik daun nya
1. Tambah 1 batang daun bawang potong2 (me skip?
1. Harus ada 3 lembar daun bawang
1. Tambah 1 batang sere geprek
1. Tambah 1 ruas lengkuas geprek
1. Jangan lupa secukupnya Garam, gula pasir, penyedap
1. Harap siapkan 500 ml air / selera saja
1. Tambah  Bumbu halus
1. Tambah 10 cabe merah keriting
1. Harus ada 10 cabe rawit merah
1. Diperlukan 5 siung bawang merah
1. Diperlukan 3 Siung bawang putih
1. Siapkan 3 butir kemiri sangrai
1. Harus ada 1 ruas kunyit
1. Harus ada 1 ruas jahe




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica-rica kemangi:

1. Potong-potong daging ayam sesuai selera,cuci bersih,beri perasan jeruk nipis diamkan sebentar lalu cuci bersih
1. Tumis bumbu halus, daun jeruk,sere dan lengkuas hingga harum,lalu masukan ayam nya,aduk hingga ayam berubah warna
1. Lalu masukan air,aduk rata hingga airnya macak²,masukan gula pasir,garam, penyadap secukupnya tes rasa
1. Setelah airnya menyusut,dan lima menit sebelum d angkat,masukan potongan daun bawang dan kemangi,aduk sebentar saja lalu angkat dan siap d sajikan
1. Selamat mencoba




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat gampang dan cepat, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
