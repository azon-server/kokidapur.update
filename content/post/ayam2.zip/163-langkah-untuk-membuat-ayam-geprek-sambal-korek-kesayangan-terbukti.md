---
description: "Langkah untuk membuat Ayam geprek sambal korek kesayangan😍 Terbukti"
title: "Langkah untuk membuat Ayam geprek sambal korek kesayangan😍 Terbukti"
slug: 163-langkah-untuk-membuat-ayam-geprek-sambal-korek-kesayangan-terbukti
date: 2021-01-15T21:59:26.374Z
image: https://img-global.cpcdn.com/recipes/3ba5e77a249dc4a5/751x532cq70/ayam-geprek-sambal-korek-kesayangan😍-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3ba5e77a249dc4a5/751x532cq70/ayam-geprek-sambal-korek-kesayangan😍-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3ba5e77a249dc4a5/751x532cq70/ayam-geprek-sambal-korek-kesayangan😍-foto-resep-utama.jpg
author: Luella Bradley
ratingvalue: 4.5
reviewcount: 14755
recipeingredient:
- "1 ekor ayam potong2 saya potong agak kecil"
- "2 buah jeruk nipisuntuk kucuran ayam"
- " bumbu perendam "
- "2 sdt garam"
- "1 sdt merica bubuk"
- "2 sdt cabe bubuk"
- "4 siung bawang putih parut"
- " bahan pencelup "
- "200 gram terigu"
- "4 sdm maizena"
- "1 sdt baking powder"
- "4 siung bawang putih parut"
- "2 sdt garam"
- "1 sdt merica bubuk"
- "Secukupnya air es"
- " bahan pelapis "
- "200 gram terigu"
- "6 sdm maizena"
- "1 sdt baking powder"
- "1 sdt garam"
- "1 sdt kaldu bubuk"
- " sambal korek "
- "24 buah cabe rawit merahrendam air panas sebentar"
- "4 siung bawang putih goreng sebentar"
- "Secukupnya garam kaldu bubuk"
- "4 sdm minyak panas bekas menggoreng ayam"
recipeinstructions:
- "Kucuri ayam dengan jeruk nipis diamkan 10 menit. Lalu cuci bersih."
- "Campurkan ayam dengan bumbu perendam, simpan di kulkas minimal 1 jam(saya semalaman)"
- "Masukkan ayam ke bahan pencelup, diamkan beberapa saat."
- "Balur dengan bahan pelapis sambil di cubit cubit tepungnya ke ayam. Goreng sampai matang(pakai api kecil)"
- "Untuk sambal korek, ulek jadi satu semua bahan sambal kecuali minyak goreng. Setelah halus siram dengan minyak panas. Lalu geprek ayam yang sudah matang di atas sambal."
- "Sajikan dengan lalapan sesuai selera😋😋"
categories:
- Recipe
tags:
- ayam
- geprek
- sambal

katakunci: ayam geprek sambal 
nutrition: 193 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT31M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam geprek sambal korek kesayangan😍](https://img-global.cpcdn.com/recipes/3ba5e77a249dc4a5/751x532cq70/ayam-geprek-sambal-korek-kesayangan😍-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis atau renyah. Ciri khas masakan Indonesia ayam geprek sambal korek kesayangan😍 yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga bisa ditemukan dengan cara simple. Salah satunya adalah membuat makanan Ayam geprek sambal korek kesayangan😍 untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang dapat anda buat salah satunya ayam geprek sambal korek kesayangan😍 yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam geprek sambal korek kesayangan😍 tanpa harus bersusah payah.
Berikut ini resep Ayam geprek sambal korek kesayangan😍 yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 26 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam geprek sambal korek kesayangan😍:

1. Jangan lupa 1 ekor ayam, potong2 (saya potong agak kecil)
1. Harus ada 2 buah jeruk nipis(untuk kucuran ayam)
1. Siapkan  bumbu perendam :
1. Diperlukan 2 sdt garam
1. Harap siapkan 1 sdt merica bubuk
1. Dibutuhkan 2 sdt cabe bubuk
1. Harus ada 4 siung bawang putih (parut)
1. Tambah  bahan pencelup :
1. Dibutuhkan 200 gram terigu
1. Dibutuhkan 4 sdm maizena
1. Tambah 1 sdt baking powder
1. Diperlukan 4 siung bawang putih (parut)
1. Siapkan 2 sdt garam
1. Tambah 1 sdt merica bubuk
1. Harus ada Secukupnya air es
1. Siapkan  bahan pelapis :
1. Jangan lupa 200 gram terigu
1. Harap siapkan 6 sdm maizena
1. Siapkan 1 sdt baking powder
1. Diperlukan 1 sdt garam
1. Harap siapkan 1 sdt kaldu bubuk
1. Siapkan  sambal korek :
1. Diperlukan 24 buah cabe rawit merah(rendam air panas sebentar)
1. Harus ada 4 siung bawang putih (goreng sebentar)
1. Harap siapkan Secukupnya garam /kaldu bubuk
1. Dibutuhkan 4 sdm minyak panas bekas menggoreng ayam




<!--inarticleads2-->

##### Instruksi membuat  Ayam geprek sambal korek kesayangan😍:

1. Kucuri ayam dengan jeruk nipis diamkan 10 menit. Lalu cuci bersih.
1. Campurkan ayam dengan bumbu perendam, simpan di kulkas minimal 1 jam(saya semalaman)
1. Masukkan ayam ke bahan pencelup, diamkan beberapa saat.
1. Balur dengan bahan pelapis sambil di cubit cubit tepungnya ke ayam. Goreng sampai matang(pakai api kecil)
1. Untuk sambal korek, ulek jadi satu semua bahan sambal kecuali minyak goreng. Setelah halus siram dengan minyak panas. Lalu geprek ayam yang sudah matang di atas sambal.
1. Sajikan dengan lalapan sesuai selera😋😋




Demikianlah cara membuat ayam geprek sambal korek kesayangan😍 yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan terbukti, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
