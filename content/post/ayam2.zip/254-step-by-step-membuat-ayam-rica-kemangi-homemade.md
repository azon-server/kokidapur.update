---
description: "Step-by-Step membuat Ayam Rica Kemangi Homemade"
title: "Step-by-Step membuat Ayam Rica Kemangi Homemade"
slug: 254-step-by-step-membuat-ayam-rica-kemangi-homemade
date: 2020-12-27T17:32:05.200Z
image: https://img-global.cpcdn.com/recipes/446b52f7ed2f2372/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/446b52f7ed2f2372/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/446b52f7ed2f2372/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Sarah Carpenter
ratingvalue: 4.7
reviewcount: 32559
recipeingredient:
- "1/2 ekor ayam kampung"
- "200 gr ayam fillet pot Dadu"
- "1 buah tomat pot6"
- "1 batang serai pot Serong"
- "1 batang daun bawang pot Serong"
- "2 Ruas jahe iris korek API"
- "2 Ruas lengkuas pot Korek API"
- "2 sdt garam"
- "1 sdt kaldu jamur"
- "1 sdt gula"
- "5 cabai rawit merah"
- "5 daun jeruk iris"
- "5 ikat daun kemangi"
- "1200 ltr air"
- "4 sdm minyak goreng"
- " Bumbu halus"
- "10 siung bawang merah"
- "6 siung bawang putih"
- "8 cabai merah keriting"
- "8 cabai rawit merah"
- "4 buah kemiri"
- "1 sdt bubuk kunyit"
recipeinstructions:
- "Tumis bumbu halus hingga harum, masukan daun jeruk, lengkuas, jahe, serai hingga harum"
- "Tambahkan air, garam, kaldu jamur, gula Dan cabai rawit. Aduk hingga rata"
- "Masukan ayam kampung terlebih dahulu sampai air mendidih. Kecilkan api"
- "Jika ayam kampung sudah setengah matang, masukan ayam fillet yg sudah di potong. Aduk rata lalu koreksi rasa"
- "Jika ayam sudah matang, masukan tomat Dan daun bawang. Aduk hingga tomat agak layu."
- "Masukan daun kemangi lalu aduk hingga daun kemangi layu. Angkat Dan sajikan."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 263 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/446b52f7ed2f2372/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau gurih. Ciri khas masakan Indonesia ayam rica kemangi yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica Kemangi untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang dapat anda contoh salah satunya ayam rica kemangi yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Tambah 1/2 ekor ayam kampung
1. Siapkan 200 gr ayam fillet (pot. Dadu)
1. Jangan lupa 1 buah tomat (pot.6)
1. Harap siapkan 1 batang serai (pot. Serong)
1. Dibutuhkan 1 batang daun bawang (pot. Serong)
1. Siapkan 2 Ruas jahe (iris korek API)
1. Tambah 2 Ruas lengkuas (pot. Korek API)
1. Dibutuhkan 2 sdt garam
1. Diperlukan 1 sdt kaldu jamur
1. Siapkan 1 sdt gula
1. Diperlukan 5 cabai rawit merah
1. Dibutuhkan 5 daun jeruk (iris)
1. Harus ada 5 ikat daun kemangi
1. Siapkan 1200 ltr air
1. Harus ada 4 sdm minyak goreng
1. Diperlukan  Bumbu halus
1. Dibutuhkan 10 siung bawang merah
1. Harus ada 6 siung bawang putih
1. Harap siapkan 8 cabai merah keriting
1. Harap siapkan 8 cabai rawit merah
1. Harus ada 4 buah kemiri
1. Harap siapkan 1 sdt bubuk kunyit




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Kemangi:

1. Tumis bumbu halus hingga harum, masukan daun jeruk, lengkuas, jahe, serai hingga harum
1. Tambahkan air, garam, kaldu jamur, gula Dan cabai rawit. Aduk hingga rata
1. Masukan ayam kampung terlebih dahulu sampai air mendidih. Kecilkan api
1. Jika ayam kampung sudah setengah matang, masukan ayam fillet yg sudah di potong. Aduk rata lalu koreksi rasa
1. Jika ayam sudah matang, masukan tomat Dan daun bawang. Aduk hingga tomat agak layu.
1. Masukan daun kemangi lalu aduk hingga daun kemangi layu. Angkat Dan sajikan.




Demikianlah cara membuat ayam rica kemangi yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan teruji, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
