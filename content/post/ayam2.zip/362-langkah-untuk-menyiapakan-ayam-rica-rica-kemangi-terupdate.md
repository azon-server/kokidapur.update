---
description: "Langkah untuk menyiapakan Ayam Rica Rica Kemangi 🤤 terupdate"
title: "Langkah untuk menyiapakan Ayam Rica Rica Kemangi 🤤 terupdate"
slug: 362-langkah-untuk-menyiapakan-ayam-rica-rica-kemangi-terupdate
date: 2020-09-30T03:28:26.875Z
image: https://img-global.cpcdn.com/recipes/6a0f0a49e4a935d2/751x532cq70/ayam-rica-rica-kemangi-🤤-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6a0f0a49e4a935d2/751x532cq70/ayam-rica-rica-kemangi-🤤-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6a0f0a49e4a935d2/751x532cq70/ayam-rica-rica-kemangi-🤤-foto-resep-utama.jpg
author: Marcus Harvey
ratingvalue: 4.9
reviewcount: 7754
recipeingredient:
- "1/2 Kg Daging Ayam"
- "2 ikat Daun kemangi"
- "1 1/2 Jeruk Nipis"
- "3 lembar Daun Jeruk"
- "2 ruas Lengkuas geprek"
- "1 batang Sereh geprek"
- "300 ml Air"
- " BahanBahan yg di haluskan "
- "6 biji Bawang merah"
- "4 Biji bawang putih"
- "10 buah Cabai Merah Keriting selera"
- "12 cabai rawit selera"
- "2 ruas Jahe"
- "1 ruas kunyit"
- "1 sendok makan ketumbargiling sampai halus"
- "1/2 SM Merica bisa pakai bubuk"
- "1 buah tomat"
- " Bahan Penyedap "
- " Garam secukupnya"
- " Gula sedikit saja"
- " Bubuk Jamur bisa pakai royco rasa ayam"
recipeinstructions:
- "Cuci bersih ayam, Lumuri dengan air dari 1 jeruk nipis (diamkan 10-15 menit). Lalu panaskan minyak goreng ayam hingga matang dan Tiriskan."
- "Giling semua Bahan yg dihaluskan."
- "Tumis bumbu halus masukan air 300ml, masukan batang sereh, daun jeruk, lengkuas. Kasih garam,kaldu jamur,gula secukupnya"
- "Koreksi Rasa (ingat ya mums airnya akan menyusut jd jgn terlalu asin saat berkuah)"
- "Masukan ayam yg sudah di goreng tunggu hingga air menyusut lalu masukan daun kemangi dan koreksi rasa lagi.... Tambahkan air 1/2 jeruk nipis biar seger lalu Sajikaann 😊"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 175 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica Rica Kemangi 🤤](https://img-global.cpcdn.com/recipes/6a0f0a49e4a935d2/751x532cq70/ayam-rica-rica-kemangi-🤤-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang setidaknya kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica rica kemangi 🤤 yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Indonesia



Keharmonisan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica Rica Kemangi 🤤 untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang dapat anda buat salah satunya ayam rica rica kemangi 🤤 yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica rica kemangi 🤤 tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi 🤤 yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 21 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi 🤤:

1. Harap siapkan 1/2 Kg Daging Ayam
1. Harus ada 2 ikat Daun kemangi
1. Tambah 1 1/2 Jeruk Nipis
1. Siapkan 3 lembar Daun Jeruk
1. Tambah 2 ruas Lengkuas (geprek)
1. Dibutuhkan 1 batang Sereh (geprek)
1. Dibutuhkan 300 ml Air
1. Harap siapkan  Bahan-Bahan yg di haluskan :
1. Jangan lupa 6 biji Bawang merah
1. Siapkan 4 Biji bawang putih
1. Diperlukan 10 buah Cabai Merah Keriting (selera)
1. Jangan lupa 12 cabai rawit (selera)
1. Dibutuhkan 2 ruas Jahe
1. Jangan lupa 1 ruas kunyit
1. Dibutuhkan 1 sendok makan ketumbar(giling sampai halus)
1. Diperlukan 1/2 SM Merica (bisa pakai bubuk)
1. Siapkan 1 buah tomat
1. Diperlukan  Bahan Penyedap :
1. Diperlukan  Garam (secukupnya)
1. Tambah  Gula (sedikit saja)
1. Harus ada  Bubuk Jamur (bisa pakai royco rasa ayam)




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Rica Kemangi 🤤:

1. Cuci bersih ayam, Lumuri dengan air dari 1 jeruk nipis (diamkan 10-15 menit). Lalu panaskan minyak goreng ayam hingga matang dan Tiriskan.
1. Giling semua Bahan yg dihaluskan.
1. Tumis bumbu halus masukan air 300ml, masukan batang sereh, daun jeruk, lengkuas. Kasih garam,kaldu jamur,gula secukupnya
1. Koreksi Rasa (ingat ya mums airnya akan menyusut jd jgn terlalu asin saat berkuah)
1. Masukan ayam yg sudah di goreng tunggu hingga air menyusut lalu masukan daun kemangi dan koreksi rasa lagi.... Tambahkan air 1/2 jeruk nipis biar seger lalu Sajikaann 😊




Demikianlah cara membuat ayam rica rica kemangi 🤤 yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
