---
description: "Resep : Sambal Tumpang Khas Kediri Favorite"
title: "Resep : Sambal Tumpang Khas Kediri Favorite"
slug: 343-resep-sambal-tumpang-khas-kediri-favorite
date: 2020-09-20T02:57:29.399Z
image: https://img-global.cpcdn.com/recipes/b219740961716d09/680x482cq70/sambal-tumpang-khas-kediri-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b219740961716d09/680x482cq70/sambal-tumpang-khas-kediri-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b219740961716d09/680x482cq70/sambal-tumpang-khas-kediri-foto-resep-utama.jpg
author: Mathilda Casey
ratingvalue: 4.7
reviewcount: 27862
recipeingredient:
- "1 papan tempe semangit 80 gr"
- "50 ml santan instan Kara 34 pak segitiga"
- "1 daun salam remas"
- "1 daun jeruk remas"
- "1 iris lengkuas"
- "150 ml air"
- " Penyedap saya skip"
- " Bumbu Halus"
- "5 siung bawang putih"
- "1 ruas kencur"
- " Cabe merah cabe rawit sesuaikan selera pedas"
- " Tambahan"
- " Kemangi segar"
recipeinstructions:
- "Ciri khas sambal Tumpang adalah tempenya yang sudah semangit/berbau agak tajam (Tapi tidak busuk). Kadang disebut juga tempe kemarin. (Di suhu ruang--tergantung panas--bisa jadi butuh waktu dua hari untuk tempe menjadi semangit. Di dalam kulkas, bisa jadi di hari ke 4-5)."
- "Haluskan bumbu. Panaskan sedikit minyak, kemudian tumis bumbu halus hingga harum. Haluskan tempe."
- "Tambahkan santan, air, daun salam, lengkuas ke bumbu. Biarkan mendidih. Masukkan tempe. Biarkan mendidih beberapa saat sambil sesekali diaduk."
- "Tambahkan gula, garam. Koreksi rasa. Siap disajikan. Bisa ditambahkan kemangi saat disajikan agar rasa dan aroma lebih segar."
categories:
- Recipe
tags:
- sambal
- tumpang
- khas

katakunci: sambal tumpang khas 
nutrition: 267 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Dinner

---


![Sambal Tumpang Khas Kediri](https://img-global.cpcdn.com/recipes/b219740961716d09/680x482cq70/sambal-tumpang-khas-kediri-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis dan gurih. Ciri khas makanan Indonesia sambal tumpang khas kediri yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Sambal Tumpang Khas Kediri untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda contoh salah satunya sambal tumpang khas kediri yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep sambal tumpang khas kediri tanpa harus bersusah payah.
Berikut ini resep Sambal Tumpang Khas Kediri yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 13 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambal Tumpang Khas Kediri:

1. Siapkan 1 papan tempe semangit (80 gr)
1. Dibutuhkan 50 ml santan instan Kara (3/4 pak segitiga)
1. Harus ada 1 daun salam, remas
1. Harap siapkan 1 daun jeruk, remas
1. Jangan lupa 1 iris lengkuas
1. Harus ada 150 ml air
1. Harus ada  Penyedap (saya skip)
1. Siapkan  Bumbu Halus
1. Siapkan 5 siung bawang putih
1. Harus ada 1 ruas kencur
1. Jangan lupa  Cabe merah, cabe rawit (sesuaikan selera pedas)
1. Jangan lupa  Tambahan
1. Jangan lupa  Kemangi segar




<!--inarticleads2-->

##### Bagaimana membuat  Sambal Tumpang Khas Kediri:

1. Ciri khas sambal Tumpang adalah tempenya yang sudah semangit/berbau agak tajam (Tapi tidak busuk). Kadang disebut juga tempe kemarin. (Di suhu ruang--tergantung panas--bisa jadi butuh waktu dua hari untuk tempe menjadi semangit. Di dalam kulkas, bisa jadi di hari ke 4-5).
1. Haluskan bumbu. Panaskan sedikit minyak, kemudian tumis bumbu halus hingga harum. Haluskan tempe.
1. Tambahkan santan, air, daun salam, lengkuas ke bumbu. Biarkan mendidih. Masukkan tempe. Biarkan mendidih beberapa saat sambil sesekali diaduk.
1. Tambahkan gula, garam. Koreksi rasa. Siap disajikan. Bisa ditambahkan kemangi saat disajikan agar rasa dan aroma lebih segar.




Demikianlah cara membuat sambal tumpang khas kediri yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan cepat, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
