---
description: "Resep : Roti unyil terupdate"
title: "Resep : Roti unyil terupdate"
slug: 12-resep-roti-unyil-terupdate
date: 2020-09-26T14:19:41.698Z
image: https://img-global.cpcdn.com/recipes/73fb113fb410fddc/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/73fb113fb410fddc/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/73fb113fb410fddc/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Julia Cross
ratingvalue: 4.8
reviewcount: 24921
recipeingredient:
- "200 gram tepung cakra"
- "45 gram tepung segitiga"
- "15 gram susu bubuk"
- "36 gram gula pasir"
- "6 gram ragi instan"
- "180 ml 1 telur utuh 20 gram whip cream bubuk susu cair"
- "30 gram butter sy pake margarin royal palmia"
- "2 gram garam"
- "1/2 sdt pasta susu sy skip"
- " Isian toping keju meseschoco chip wijen dll"
recipeinstructions:
- "Uleni/ mixer semua bahan kecuali butter/margarin dan garam sampai kalis(sy hanya punya hand mixer jadinya sy kadang mix sebntr matiin sy lanjut ulen pake tangan)"
- "Setelah kalis masukan garam dan butter lalu uleni sampai kalis elastis"
- "Timbang masing masing adonan 15 gram."
- "Isi dan bentuk sesuai selera, saya isi pake meses, keju, choco chips,dan tanpa isi krn sy mau oles buttercream dan ditaburi meses."
- "Diamkan minimal sejam sampai mengembang lalu oles dengan campuran kuning telur dan susu cair, taburi dengan toping keju, meses,wijen dll"
- "Oven dengam suhu 180 derajat selama 25 menit atau sesuai oven masing masing. Sampai kecoklatan dan matang."
- "Setelah matang keluarkan dr oven dan lngsung oles dengan butter/ margarin siap disajikan."
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 245 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Dessert

---


![Roti unyil](https://img-global.cpcdn.com/recipes/73fb113fb410fddc/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau renyah. Karasteristik masakan Indonesia roti unyil yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Roti unyil untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang dapat anda contoh salah satunya roti unyil yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep roti unyil tanpa harus bersusah payah.
Berikut ini resep Roti unyil yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 10 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti unyil:

1. Siapkan 200 gram tepung cakra
1. Harap siapkan 45 gram tepung segitiga
1. Harus ada 15 gram susu bubuk
1. Jangan lupa 36 gram gula pasir
1. Jangan lupa 6 gram ragi instan
1. Harus ada 180 ml (1 telur utuh+ 20 gram whip cream bubuk+ susu cair)
1. Tambah 30 gram butter (sy pake margarin royal palmia)
1. Harap siapkan 2 gram garam
1. Jangan lupa 1/2 sdt pasta susu (sy skip)
1. Harap siapkan  Isian+ toping: keju, meses,choco chip, wijen dll




<!--inarticleads2-->

##### Instruksi membuat  Roti unyil:

1. Uleni/ mixer semua bahan kecuali butter/margarin dan garam sampai kalis(sy hanya punya hand mixer jadinya sy kadang mix sebntr matiin sy lanjut ulen pake tangan)
1. Setelah kalis masukan garam dan butter lalu uleni sampai kalis elastis
1. Timbang masing masing adonan 15 gram.
1. Isi dan bentuk sesuai selera, saya isi pake meses, keju, choco chips,dan tanpa isi krn sy mau oles buttercream dan ditaburi meses.
1. Diamkan minimal sejam sampai mengembang lalu oles dengan campuran kuning telur dan susu cair, taburi dengan toping keju, meses,wijen dll
1. Oven dengam suhu 180 derajat selama 25 menit atau sesuai oven masing masing. Sampai kecoklatan dan matang.
1. Setelah matang keluarkan dr oven dan lngsung oles dengan butter/ margarin siap disajikan.




Demikianlah cara membuat roti unyil yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan teruji, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
