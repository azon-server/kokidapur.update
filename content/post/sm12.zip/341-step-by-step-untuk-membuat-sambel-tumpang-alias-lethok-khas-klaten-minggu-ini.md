---
description: "Step-by-Step untuk membuat Sambel tumpang alias lethok khas Klaten minggu ini"
title: "Step-by-Step untuk membuat Sambel tumpang alias lethok khas Klaten minggu ini"
slug: 341-step-by-step-untuk-membuat-sambel-tumpang-alias-lethok-khas-klaten-minggu-ini
date: 2021-01-30T04:48:25.690Z
image: https://img-global.cpcdn.com/recipes/abbd32f36bdd6978/680x482cq70/sambel-tumpang-alias-lethok-khas-klaten-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/abbd32f36bdd6978/680x482cq70/sambel-tumpang-alias-lethok-khas-klaten-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/abbd32f36bdd6978/680x482cq70/sambel-tumpang-alias-lethok-khas-klaten-foto-resep-utama.jpg
author: Adam Chavez
ratingvalue: 4
reviewcount: 38260
recipeingredient:
- "1 papan tempe lawas udh 45 hari"
- "1 bungkus santan kara 65ml"
- "2 siung bawang putih"
- "4 siung bawang merah"
- "3 buah cabe rawit"
- "5 buah cabe merah kriting"
- "1 cm kencur"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1/2 sdt Garam 3sdm gula pasir secuil gula jawa"
- "2 buah Kemiri"
- "1 bungkus kaldu bubuk"
- "400-500 ml Air"
- "1 ruas Lengkuas geprek"
- " Bakso ayam biasanya pake tahu ya bun seadanya dikulkas aja"
- "1 lonjor pete"
recipeinstructions:
- "Potong tempe lalu rebus sebentar, setelah direbus lalu diulek ya bun.."
- "Haluskan bawang merah, bawang putih, cabe, kencur, kemiri"
- "Tumis bumbu halus beserta daun jeruk, salam, lengkuas sampai harum"
- "Masukkan tempe yg sudah diulek td lalu tmbahkan air.. aduk2.."
- "Tambahkan garam, gula.. kalo diklaten khas nya gurih agak manis.. yg kurang suka manis boleh dikurangi gula nya ya.. oiya bakso ayam nya jangan lupa cemplungin 😄"
- "Lalu tambahkan santan instan.. aduk sampai mendidih.. tambahkan kaldu bubuk.. lalu aduk lagi biar santan ga pecah.. tes rasa"
- "Masukkan Pete biar tambah sedeepp.. tunggu sampai pete matang.."
- "Sambel tumpang siap dihidangkan.. disiram di atas bubur juga enakk lho bun.. tp mimin blm sempet mo praktek bikin bubur nya.. si bayik lagi rewel soalnya.."
- "Selamat mencoba 😊"
categories:
- Recipe
tags:
- sambel
- tumpang
- alias

katakunci: sambel tumpang alias 
nutrition: 258 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Lunch

---


![Sambel tumpang alias lethok khas Klaten](https://img-global.cpcdn.com/recipes/abbd32f36bdd6978/680x482cq70/sambel-tumpang-alias-lethok-khas-klaten-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau enak. Ciri kuliner Indonesia sambel tumpang alias lethok khas klaten yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Keharmonisan rumah tangga bisa ditemukan dengan cara sederhana. Diantaranya adalah memasak Sambel tumpang alias lethok khas Klaten untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang bisa anda buat salah satunya sambel tumpang alias lethok khas klaten yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep sambel tumpang alias lethok khas klaten tanpa harus bersusah payah.
Berikut ini resep Sambel tumpang alias lethok khas Klaten yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 9 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambel tumpang alias lethok khas Klaten:

1. Dibutuhkan 1 papan tempe lawas (udh 4-5 hari)
1. Diperlukan 1 bungkus santan kara 65ml
1. Diperlukan 2 siung bawang putih
1. Jangan lupa 4 siung bawang merah
1. Jangan lupa 3 buah cabe rawit
1. Jangan lupa 5 buah cabe merah kriting
1. Jangan lupa 1 cm kencur
1. Siapkan 2 lembar daun salam
1. Harap siapkan 2 lembar daun jeruk
1. Diperlukan 1/2 sdt Garam, 3sdm gula pasir, secuil gula jawa
1. Harap siapkan 2 buah Kemiri
1. Siapkan 1 bungkus kaldu bubuk
1. Siapkan 400-500 ml Air
1. Harus ada 1 ruas Lengkuas geprek
1. Tambah  Bakso ayam (biasanya pake tahu ya bun) seadanya dikulkas aja
1. Dibutuhkan 1 lonjor pete




<!--inarticleads2-->

##### Bagaimana membuat  Sambel tumpang alias lethok khas Klaten:

1. Potong tempe lalu rebus sebentar, setelah direbus lalu diulek ya bun..
1. Haluskan bawang merah, bawang putih, cabe, kencur, kemiri
1. Tumis bumbu halus beserta daun jeruk, salam, lengkuas sampai harum
1. Masukkan tempe yg sudah diulek td lalu tmbahkan air.. aduk2..
1. Tambahkan garam, gula.. kalo diklaten khas nya gurih agak manis.. yg kurang suka manis boleh dikurangi gula nya ya.. oiya bakso ayam nya jangan lupa cemplungin 😄
1. Lalu tambahkan santan instan.. aduk sampai mendidih.. tambahkan kaldu bubuk.. lalu aduk lagi biar santan ga pecah.. tes rasa
1. Masukkan Pete biar tambah sedeepp.. tunggu sampai pete matang..
1. Sambel tumpang siap dihidangkan.. disiram di atas bubur juga enakk lho bun.. tp mimin blm sempet mo praktek bikin bubur nya.. si bayik lagi rewel soalnya..
1. Selamat mencoba 😊




Demikianlah cara membuat sambel tumpang alias lethok khas klaten yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan cepat, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
