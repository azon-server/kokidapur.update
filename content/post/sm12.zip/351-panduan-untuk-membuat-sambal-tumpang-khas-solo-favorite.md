---
description: "Panduan untuk membuat Sambal Tumpang Khas Solo Favorite"
title: "Panduan untuk membuat Sambal Tumpang Khas Solo Favorite"
slug: 351-panduan-untuk-membuat-sambal-tumpang-khas-solo-favorite
date: 2020-11-11T09:01:52.508Z
image: https://img-global.cpcdn.com/recipes/e392833ea69c0874/680x482cq70/sambal-tumpang-khas-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e392833ea69c0874/680x482cq70/sambal-tumpang-khas-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e392833ea69c0874/680x482cq70/sambal-tumpang-khas-solo-foto-resep-utama.jpg
author: Maude Gilbert
ratingvalue: 4.1
reviewcount: 12638
recipeingredient:
- " Bahan A "
- "1 papan sedang tempe semangit potong 8"
- "6 butir bawang merah"
- "4 siung bawang putih"
- "1 buah cabe merah besar"
- "Sejempol kencur"
- "1 liter air untuk merebus"
- " Bahan B "
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "2 ruas jari lengkuas geprek"
- "5 buahsecukupnya cabe rawit utuh"
- "1 buah tomat potongpotong"
- "1 sdt garam"
- "2 sdt gula pasir"
- "65 ml1 bungkus santan instant Sun Kara"
- "3 sdm minyak goreng"
recipeinstructions:
- "Rebus semua bahan A hingga matang lalu tiriskan (air rebusannya sisihkan dulu). Ulek cabe, bawang merah putih dan kencur. Tempenya dipenyet aja"
- "Tumis bumbu ulek, daun salam, daun jeruk, lengkuas dan cabe utuh hingga harum. Tambahkan tempe penyet dan tomat. Tumis lagi sebentar"
- "Tuang air rebusan dan santan. Beri garam dan gula pasir. Masak hingga airnya meyusut (sesuaikan selera mau kuahnya banyak atau sedikit). Koreksi rasa"
- "Angkat dan sajikan"
categories:
- Recipe
tags:
- sambal
- tumpang
- khas

katakunci: sambal tumpang khas 
nutrition: 234 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dessert

---


![Sambal Tumpang Khas Solo](https://img-global.cpcdn.com/recipes/e392833ea69c0874/680x482cq70/sambal-tumpang-khas-solo-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti sambal tumpang khas solo yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan ciri khas yang merupakan keragaman Indonesia



Kedekatan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Sambal Tumpang Khas Solo untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang bisa anda buat salah satunya sambal tumpang khas solo yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep sambal tumpang khas solo tanpa harus bersusah payah.
Berikut ini resep Sambal Tumpang Khas Solo yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambal Tumpang Khas Solo:

1. Siapkan  Bahan A :
1. Harap siapkan 1 papan sedang tempe semangit, potong 8
1. Dibutuhkan 6 butir bawang merah
1. Harus ada 4 siung bawang putih
1. Diperlukan 1 buah cabe merah besar
1. Harus ada Sejempol kencur
1. Jangan lupa 1 liter air untuk merebus
1. Harus ada  Bahan B :
1. Dibutuhkan 2 lembar daun salam
1. Tambah 2 lembar daun jeruk
1. Siapkan 2 ruas jari lengkuas, geprek
1. Tambah 5 buah/secukupnya cabe rawit utuh
1. Siapkan 1 buah tomat, potong-potong
1. Tambah 1 sdt garam
1. Harus ada 2 sdt gula pasir
1. Tambah 65 ml/1 bungkus santan instant (Sun Kara)
1. Jangan lupa 3 sdm minyak goreng




<!--inarticleads2-->

##### Langkah membuat  Sambal Tumpang Khas Solo:

1. Rebus semua bahan A hingga matang lalu tiriskan (air rebusannya sisihkan dulu). Ulek cabe, bawang merah putih dan kencur. Tempenya dipenyet aja
1. Tumis bumbu ulek, daun salam, daun jeruk, lengkuas dan cabe utuh hingga harum. Tambahkan tempe penyet dan tomat. Tumis lagi sebentar
1. Tuang air rebusan dan santan. Beri garam dan gula pasir. Masak hingga airnya meyusut (sesuaikan selera mau kuahnya banyak atau sedikit). Koreksi rasa
1. Angkat dan sajikan




Demikianlah cara membuat sambal tumpang khas solo yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan terbukti, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
