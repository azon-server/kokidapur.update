---
description: "Langkah untuk membuat Sambal Tumpang Solo ala Ibu Mertua minggu ini"
title: "Langkah untuk membuat Sambal Tumpang Solo ala Ibu Mertua minggu ini"
slug: 497-langkah-untuk-membuat-sambal-tumpang-solo-ala-ibu-mertua-minggu-ini
date: 2020-11-10T17:19:53.654Z
image: https://img-global.cpcdn.com/recipes/bd4748c712ad001b/680x482cq70/sambal-tumpang-solo-ala-ibu-mertua-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bd4748c712ad001b/680x482cq70/sambal-tumpang-solo-ala-ibu-mertua-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bd4748c712ad001b/680x482cq70/sambal-tumpang-solo-ala-ibu-mertua-foto-resep-utama.jpg
author: Hallie Coleman
ratingvalue: 4
reviewcount: 44335
recipeingredient:
- "1 papan tempe semangit belum busuk"
- "1 papan tahu besar"
- "3 siung bawang putih"
- "15 buah cabai rawit"
- "3 lembar daun jeruk"
- "2 lembar daun salam"
- "2 sdt garam"
- "2 sdt gula"
- "secukupnya penyedap rasa"
- "1 sachet santan cair"
recipeinstructions:
- "Rebus tempe, bawang merah, bawang putih, cabai, daun jeruk, dan daun salam dalam 2 gelas air. Tunggu sampai tempe menjadi empuk. Angkat dan haluskan. Air rebusan jangan dibuang."
- "Di wajan lain, goreng tahu yang sudah dipotong-potong sampai 3/4 matang. Angkat dan tiriskan."
- "Tumis bahan bahan yang sudah dihaluskan tadi (nomor 1)kira kira 3-4 menit. Kemudian masukkan air sisa rebusan dan tambahkan air baru sebanyak 2 gelas atau sesuai selera. Kalau saya suka yang kuahnya agak pekat."
- "Setelah mendidih, tambahkan santan, garam, gula, penyedap rasa, dan tahu yang sudah digoreng. Aduk rata dan koreksi rasa."
- "Sambal tumpang siap dinikmati, bisa dimakan dengan nasi atau bubur. Dua duanya sungguh nikmat. Dan kalau dihangatkan lagi, sambal ini semakin hari jadi semakin enak 😂."
categories:
- Recipe
tags:
- sambal
- tumpang
- solo

katakunci: sambal tumpang solo 
nutrition: 188 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Dinner

---


![Sambal Tumpang Solo ala Ibu Mertua](https://img-global.cpcdn.com/recipes/bd4748c712ad001b/680x482cq70/sambal-tumpang-solo-ala-ibu-mertua-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau empuk. Karasteristik kuliner Nusantara sambal tumpang solo ala ibu mertua yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Sambal Tumpang Solo ala Ibu Mertua untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang dapat anda buat salah satunya sambal tumpang solo ala ibu mertua yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep sambal tumpang solo ala ibu mertua tanpa harus bersusah payah.
Berikut ini resep Sambal Tumpang Solo ala Ibu Mertua yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 10 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambal Tumpang Solo ala Ibu Mertua:

1. Tambah 1 papan tempe semangit (belum busuk)
1. Harap siapkan 1 papan tahu besar
1. Harus ada 3 siung bawang putih
1. Harap siapkan 15 buah cabai rawit
1. Diperlukan 3 lembar daun jeruk
1. Siapkan 2 lembar daun salam
1. Tambah 2 sdt garam
1. Tambah 2 sdt gula
1. Harus ada secukupnya penyedap rasa
1. Tambah 1 sachet santan cair




<!--inarticleads2-->

##### Bagaimana membuat  Sambal Tumpang Solo ala Ibu Mertua:

1. Rebus tempe, bawang merah, bawang putih, cabai, daun jeruk, dan daun salam dalam 2 gelas air. Tunggu sampai tempe menjadi empuk. Angkat dan haluskan. Air rebusan jangan dibuang.
1. Di wajan lain, goreng tahu yang sudah dipotong-potong sampai 3/4 matang. Angkat dan tiriskan.
1. Tumis bahan bahan yang sudah dihaluskan tadi (nomor 1)kira kira 3-4 menit. Kemudian masukkan air sisa rebusan dan tambahkan air baru sebanyak 2 gelas atau sesuai selera. Kalau saya suka yang kuahnya agak pekat.
1. Setelah mendidih, tambahkan santan, garam, gula, penyedap rasa, dan tahu yang sudah digoreng. Aduk rata dan koreksi rasa.
1. Sambal tumpang siap dinikmati, bisa dimakan dengan nasi atau bubur. Dua duanya sungguh nikmat. Dan kalau dihangatkan lagi, sambal ini semakin hari jadi semakin enak 😂.




Demikianlah cara membuat sambal tumpang solo ala ibu mertua yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
