---
description: "Resep : Sambel Tumpang Khas Kediri Terbukti"
title: "Resep : Sambel Tumpang Khas Kediri Terbukti"
slug: 407-resep-sambel-tumpang-khas-kediri-terbukti
date: 2020-12-14T21:05:27.951Z
image: https://img-global.cpcdn.com/recipes/ba3dfd8d4189db4d/680x482cq70/sambel-tumpang-khas-kediri-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ba3dfd8d4189db4d/680x482cq70/sambel-tumpang-khas-kediri-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ba3dfd8d4189db4d/680x482cq70/sambel-tumpang-khas-kediri-foto-resep-utama.jpg
author: Kenneth Willis
ratingvalue: 4.1
reviewcount: 45494
recipeingredient:
- " Bahan sambal tumpang"
- "150 gr tempe bosok busuk"
- "150 gr Tempe semangit setengah busuk"
- "4 ptg tahu belah2 tipis goreng stengah matang optional"
- "2 gelas santan cair"
- "1 gelas santan kental"
- " lebih baik santan diperas dr kelapa segar"
- " Bumbu halus sambal tumpang"
- "4 siung bawang putih"
- "8 butir bawang merah"
- "1 ruas kencur"
- "4 buah cabe merah besar"
- "8 buah cabe rawit merah boleh ditambah"
- "4 btr kemiri"
- " Minyak untuk menumis"
- " Bumbu cemplung sambal tumpang"
- "1 jempol lengkuas"
- "2 lbr daun salam"
- "4 lbr daun jeruk"
- " Penyedap"
- "1 sdt garam"
- "1/2 sdt gula"
- "1/2 sdt kaldu jamur"
- " Pelengkap"
- " Nasi"
- " Sayuran rebus daun singkongbayampepaya mudatoge"
- " Rempeyek"
recipeinstructions:
- "Rebus tempe &amp; cabe merah hingga cabe matang. Angkat &amp; tiriskan. Lalu haluskan tempe."
- "Haluskan bumbu2 halus. Tumis bumbu halus &amp; bumbu cemplung hingga harum &amp; tanak."
- "Masukkan santan cair. Biarkan mendidih."
- "Masukkan tempe. Tambah bumbu penyedap. Masak hingga keluar minyak dr kuah sambal yg dimasak."
- "Tambahkan santan kental, masak lagi hingga kuah mengental &amp; berminyak. Koreksi rasa, angkat. (Tingkat kekentalan disesuaikan dg selera)"
- "Penyajian: Ambil nasi di piring, beri sayuran diatasnya, siram dg sambal tumpang. Sajikan dg rempeyek."
categories:
- Recipe
tags:
- sambel
- tumpang
- khas

katakunci: sambel tumpang khas 
nutrition: 104 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Dinner

---


![Sambel Tumpang Khas Kediri](https://img-global.cpcdn.com/recipes/ba3dfd8d4189db4d/680x482cq70/sambel-tumpang-khas-kediri-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang patut kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti sambel tumpang khas kediri yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Indonesia

Kedekatan rumah tangga bisa didapat dengan cara mudah. Diantaranya adalah membuat makanan Sambel Tumpang Khas Kediri untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang dapat anda buat salah satunya sambel tumpang khas kediri yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep sambel tumpang khas kediri tanpa harus bersusah payah.
Seperti resep Sambel Tumpang Khas Kediri yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 27 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambel Tumpang Khas Kediri:

1. Harap siapkan  Bahan sambal tumpang
1. Jangan lupa 150 gr tempe bosok (busuk)
1. Diperlukan 150 gr Tempe semangit (setengah busuk)
1. Siapkan 4 ptg tahu, belah2 tipis, goreng stengah matang (optional)
1. Harus ada 2 gelas santan cair
1. Harus ada 1 gelas santan kental
1. Harus ada  (lebih baik santan diperas dr kelapa segar)
1. Jangan lupa  Bumbu halus sambal tumpang
1. Diperlukan 4 siung bawang putih
1. Tambah 8 butir bawang merah
1. Diperlukan 1 ruas kencur
1. Jangan lupa 4 buah cabe merah besar
1. Harus ada 8 buah cabe rawit merah (boleh ditambah)
1. Harus ada 4 btr kemiri
1. Dibutuhkan  Minyak untuk menumis
1. Jangan lupa  Bumbu cemplung sambal tumpang
1. Jangan lupa 1 jempol lengkuas
1. Harap siapkan 2 lbr daun salam
1. Tambah 4 lbr daun jeruk
1. Jangan lupa  Penyedap
1. Harap siapkan 1 sdt garam
1. Dibutuhkan 1/2 sdt gula
1. Siapkan 1/2 sdt kaldu jamur
1. Dibutuhkan  Pelengkap:
1. Siapkan  Nasi
1. Jangan lupa  Sayuran rebus (daun singkong/bayam/pepaya muda/toge)
1. Harap siapkan  Rempeyek




<!--inarticleads2-->

##### Bagaimana membuat  Sambel Tumpang Khas Kediri:

1. Rebus tempe &amp; cabe merah hingga cabe matang. Angkat &amp; tiriskan. Lalu haluskan tempe.
1. Haluskan bumbu2 halus. Tumis bumbu halus &amp; bumbu cemplung hingga harum &amp; tanak.
1. Masukkan santan cair. Biarkan mendidih.
1. Masukkan tempe. Tambah bumbu penyedap. Masak hingga keluar minyak dr kuah sambal yg dimasak.
1. Tambahkan santan kental, masak lagi hingga kuah mengental &amp; berminyak. Koreksi rasa, angkat. (Tingkat kekentalan disesuaikan dg selera)
1. Penyajian: Ambil nasi di piring, beri sayuran diatasnya, siram dg sambal tumpang. Sajikan dg rempeyek.




Demikianlah cara membuat sambel tumpang khas kediri yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan terbukti, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
