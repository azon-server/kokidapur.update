---
description: "Resep : Sambal Tumpang Kertosono minggu ini"
title: "Resep : Sambal Tumpang Kertosono minggu ini"
slug: 446-resep-sambal-tumpang-kertosono-minggu-ini
date: 2020-10-09T20:44:16.719Z
image: https://img-global.cpcdn.com/recipes/47a6be965d837614/680x482cq70/sambal-tumpang-kertosono-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/47a6be965d837614/680x482cq70/sambal-tumpang-kertosono-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/47a6be965d837614/680x482cq70/sambal-tumpang-kertosono-foto-resep-utama.jpg
author: Winifred Knight
ratingvalue: 4.8
reviewcount: 22327
recipeingredient:
- "2 buah tempe ukuran sedang sudah didiamkan 23 hari"
- "200 ml santan"
- "3 siung bawang putih"
- "5 siung bawang merah"
- "1/2 jari kencur"
- "1 lembar daun salam"
- "1 lembar daun jeruk sobek sedikit"
- "1 sdt garam sesuai selera"
- "Sejumput gula"
- "5 buah cabai sesuai selera"
- "Sedikit air"
recipeinstructions:
- "Potong-potong tempe."
- "Rebus tempe, cabai, bawang merah, bawang putih, dan kencur sampai empuk."
- "Uleg halus cabai, bawang merah, bawang putih, dan kencur. Lalu tambahkan tempe dan uleg kasar."
- "Rebus lagi ulegan tempe dan bumbu, bersama daun salam dan daun jeruk. Rebus dengan sedikit air hingga mendidih."
- "Tambahkan santan, garam, dan gula. Aduk dan tunggu hingga mendidih."
- "Cek rasa. Jika sudah cocok di lidah, bisa segera diangkat."
- "Sajikan bersama nasi hangat, sayur, tahu goreng, dan rempeyek. Cara bikin rempeyek ada di resep sebelumnya ya           (lihat resep)"
categories:
- Recipe
tags:
- sambal
- tumpang
- kertosono

katakunci: sambal tumpang kertosono 
nutrition: 231 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Lunch

---


![Sambal Tumpang Kertosono](https://img-global.cpcdn.com/recipes/47a6be965d837614/680x482cq70/sambal-tumpang-kertosono-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang harus kita jaga karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti sambal tumpang kertosono yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan ciri khas yang merupakan keragaman Indonesia



Kedekatan keluarga bisa didapat dengan cara mudah. Diantaranya adalah memasak Sambal Tumpang Kertosono untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang dapat anda contoh salah satunya sambal tumpang kertosono yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep sambal tumpang kertosono tanpa harus bersusah payah.
Berikut ini resep Sambal Tumpang Kertosono yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 11 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambal Tumpang Kertosono:

1. Tambah 2 buah tempe ukuran sedang (sudah didiamkan 2-3 hari)
1. Tambah 200 ml santan
1. Jangan lupa 3 siung bawang putih
1. Harus ada 5 siung bawang merah
1. Harus ada 1/2 jari kencur
1. Diperlukan 1 lembar daun salam
1. Siapkan 1 lembar daun jeruk, sobek sedikit
1. Siapkan 1 sdt garam (sesuai selera)
1. Harap siapkan Sejumput gula
1. Dibutuhkan 5 buah cabai (sesuai selera)
1. Jangan lupa Sedikit air




<!--inarticleads2-->

##### Langkah membuat  Sambal Tumpang Kertosono:

1. Potong-potong tempe.
1. Rebus tempe, cabai, bawang merah, bawang putih, dan kencur sampai empuk.
1. Uleg halus cabai, bawang merah, bawang putih, dan kencur. Lalu tambahkan tempe dan uleg kasar.
1. Rebus lagi ulegan tempe dan bumbu, bersama daun salam dan daun jeruk. Rebus dengan sedikit air hingga mendidih.
1. Tambahkan santan, garam, dan gula. Aduk dan tunggu hingga mendidih.
1. Cek rasa. Jika sudah cocok di lidah, bisa segera diangkat.
1. Sajikan bersama nasi hangat, sayur, tahu goreng, dan rempeyek. Cara bikin rempeyek ada di resep sebelumnya ya -           (lihat resep)




Demikianlah cara membuat sambal tumpang kertosono yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
