---
description: "Bagaimana untuk menyiapakan Sambal tumpang asli solo Homemade"
title: "Bagaimana untuk menyiapakan Sambal tumpang asli solo Homemade"
slug: 336-bagaimana-untuk-menyiapakan-sambal-tumpang-asli-solo-homemade
date: 2021-02-04T23:39:39.278Z
image: https://img-global.cpcdn.com/recipes/5c81caf93cbaf1fc/680x482cq70/sambal-tumpang-asli-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5c81caf93cbaf1fc/680x482cq70/sambal-tumpang-asli-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5c81caf93cbaf1fc/680x482cq70/sambal-tumpang-asli-solo-foto-resep-utama.jpg
author: Tony Cannon
ratingvalue: 4.9
reviewcount: 8340
recipeingredient:
- "1 papan tempe ukuran sedang yg didiemin sampai busuk biasa nyebut na tempe bosok udah asem jg gpp tambah sedep tp cuci dulu y"
- "1 gayung santan dr 12 butir kelapa pake kara jg bs"
- "5 butir telur rebus"
- "1 papan pete"
- "1 bungkus tahu goreng"
- "sesuai selera cabe merah keriting dan rawit"
- "4 buah bawang merah"
- "2 siung bawang putih"
- "5 lembar daun jeruk"
- "3 lembar daun salam"
- " lengkuas geprek"
- "secukupnya garam"
- " gula sedikit aja sy pake gula merah"
- "secukupnya kaldu bubuk ayam"
- " minyak utk menumis"
- " air utk merebus"
- "secukupnya Bawang goreng"
recipeinstructions:
- "Cabe, bawang merah, bawang putih ditumis dgn sedikit minyak.. tuang air kurleb 3 gelas tambah tempe belah 4.. tambah daun jeruk 2, daun salam,dan lengkuas.. rebus ditutup sampai tiris.."
- "Cabe dan bawang2 diulek.. tempe jg diulek tp kasar bgt aja.. taruh di wajan lg.. tambah pete, telur rebus, tahu goreng belah 2, daun jeruk 3, santan.. kalo ada krecek atau kerupuk rambak jg enak dimasukin jg.. sayang na aq lg g ada.."
- "Dimasak aduk2 sampai mendidih biar santan g pecah.. tambah garam, gula dan kaldu bubuk secukupnya.. masak sampai matang dan agak menyusut air na.. Tes rasa Matikan kompor.. Taburi bawang goreng"
- "Enak makan pake nasi trus disiram k sayuran rebus.. Misal na toge, bayam, kacang panjang atau apa aja.. G pake sayuran jg gpp.. Makan pake nasi dan kerupuk jg enak.."
categories:
- Recipe
tags:
- sambal
- tumpang
- asli

katakunci: sambal tumpang asli 
nutrition: 244 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT30M"
recipeyield: "2"
recipecategory: Dinner

---


![Sambal tumpang asli solo](https://img-global.cpcdn.com/recipes/5c81caf93cbaf1fc/680x482cq70/sambal-tumpang-asli-solo-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang setidaknya kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti sambal tumpang asli solo yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa ciri khas yang merupakan keragaman Nusantara



Kehangatan rumah tangga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Sambal tumpang asli solo untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang bisa anda praktekkan salah satunya sambal tumpang asli solo yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep sambal tumpang asli solo tanpa harus bersusah payah.
Berikut ini resep Sambal tumpang asli solo yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambal tumpang asli solo:

1. Dibutuhkan 1 papan tempe ukuran sedang yg didiemin sampai busuk.. biasa nyebut na tempe bosok.. udah asem jg gpp.. tambah sedep.. tp cuci dulu y
1. Tambah 1 gayung santan dr 1/2 butir kelapa pake kara jg bs
1. Tambah 5 butir telur rebus
1. Siapkan 1 papan pete
1. Tambah 1 bungkus tahu goreng
1. Harus ada sesuai selera cabe merah keriting dan rawit
1. Jangan lupa 4 buah bawang merah
1. Harap siapkan 2 siung bawang putih
1. Harus ada 5 lembar daun jeruk
1. Harus ada 3 lembar daun salam
1. Diperlukan  lengkuas geprek
1. Jangan lupa secukupnya garam
1. Siapkan  gula sedikit aja.. sy pake gula merah
1. Tambah secukupnya kaldu bubuk ayam
1. Harus ada  minyak utk menumis
1. Tambah  air utk merebus
1. Siapkan secukupnya Bawang goreng




<!--inarticleads2-->

##### Langkah membuat  Sambal tumpang asli solo:

1. Cabe, bawang merah, bawang putih ditumis dgn sedikit minyak.. tuang air kurleb 3 gelas tambah tempe belah 4.. tambah daun jeruk 2, daun salam,dan lengkuas.. rebus ditutup sampai tiris..
1. Cabe dan bawang2 diulek.. tempe jg diulek tp kasar bgt aja.. taruh di wajan lg.. tambah pete, telur rebus, tahu goreng belah 2, daun jeruk 3, santan.. kalo ada krecek atau kerupuk rambak jg enak dimasukin jg.. sayang na aq lg g ada..
1. Dimasak aduk2 sampai mendidih biar santan g pecah.. tambah garam, gula dan kaldu bubuk secukupnya.. masak sampai matang dan agak menyusut air na.. Tes rasa Matikan kompor.. Taburi bawang goreng
1. Enak makan pake nasi trus disiram k sayuran rebus.. Misal na toge, bayam, kacang panjang atau apa aja.. G pake sayuran jg gpp.. Makan pake nasi dan kerupuk jg enak..




Demikianlah cara membuat sambal tumpang asli solo yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan terbukti, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
