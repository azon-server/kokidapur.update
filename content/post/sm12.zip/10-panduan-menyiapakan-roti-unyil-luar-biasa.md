---
description: "Panduan menyiapakan Roti Unyil Luar biasa"
title: "Panduan menyiapakan Roti Unyil Luar biasa"
slug: 10-panduan-menyiapakan-roti-unyil-luar-biasa
date: 2020-10-21T16:29:20.720Z
image: https://img-global.cpcdn.com/recipes/7ad4926dc85d574a/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7ad4926dc85d574a/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7ad4926dc85d574a/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Patrick Norris
ratingvalue: 5
reviewcount: 37578
recipeingredient:
- " 1 Bahan"
- "350 gr tepung cakra"
- "150 gr tepung segitiga"
- "125 gr gula pasir"
- "3 btr kuning telur"
- "1 btr putih telur"
- "75 cc susu cair dingin"
- "150 cc air es"
- "10 gr ragi fermipan"
- "16 gr susu bubuk"
- " 2 Bahan"
- "100 gr butter aku margarin"
- "2 gr garam halus"
- " Isian bebas"
- "batang Keju sosis coklat"
- " Topping bebas"
- " Wijen parsley meises"
- " Bahan olesan"
- "2 kuning telur"
- "2 sdt susu cair"
recipeinstructions:
- "Campur semua bahan 1 kecuali bahan 2 diulen setengah kalis. Lalu tambah bahan 2 uleni hingga kalis elastis."
- "Diamkan sampai mengembang 2x lipat, aku kira2 1,5 jam."
- "Bagi adonan dgn berat 15-20gr. Aku 20 gr dapat 50 buah roti."
- "Bentuk adonan dan tata di loyang. Aku dempet2 soale ovennya gak muat. Diamkan 1 jam sampai mengembang."
- "Setelah mengembang oles adonan dan taburi toppping. Wijen isian keju, meises isian coklat batang dan parsley isian sosis keju."
- "Panggang sampai matang suhu 190 derajat selama 10 menitan atau sampai matang ya."
- "Setelah matang disobek2 jadi roti unyil tinggal happp. Empukk rotinya, serat cakep, gemes unyu2. 😍"
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 134 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT56M"
recipeyield: "3"
recipecategory: Dinner

---


![Roti Unyil](https://img-global.cpcdn.com/recipes/7ad4926dc85d574a/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan gurih. Ciri khas masakan Nusantara roti unyil yang penuh dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Roti Unyil untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang bisa anda praktekkan salah satunya roti unyil yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep roti unyil tanpa harus bersusah payah.
Seperti resep Roti Unyil yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Unyil:

1. Tambah  1 Bahan
1. Harap siapkan 350 gr tepung cakra
1. Harap siapkan 150 gr tepung segitiga
1. Harap siapkan 125 gr gula pasir
1. Harus ada 3 btr kuning telur
1. Harap siapkan 1 btr putih telur
1. Diperlukan 75 cc susu cair dingin
1. Siapkan 150 cc air es
1. Siapkan 10 gr ragi fermipan
1. Harap siapkan 16 gr susu bubuk
1. Harus ada  2 Bahan
1. Tambah 100 gr butter (aku margarin)
1. Harus ada 2 gr garam halus
1. Harus ada  Isian: bebas
1. Dibutuhkan batang Keju, sosis, coklat
1. Harap siapkan  Topping bebas
1. Diperlukan  Wijen, parsley, meises
1. Diperlukan  Bahan olesan:
1. Siapkan 2 kuning telur
1. Dibutuhkan 2 sdt susu cair




<!--inarticleads2-->

##### Cara membuat  Roti Unyil:

1. Campur semua bahan 1 kecuali bahan 2 diulen setengah kalis. Lalu tambah bahan 2 uleni hingga kalis elastis.
1. Diamkan sampai mengembang 2x lipat, aku kira2 1,5 jam.
1. Bagi adonan dgn berat 15-20gr. Aku 20 gr dapat 50 buah roti.
1. Bentuk adonan dan tata di loyang. Aku dempet2 soale ovennya gak muat. Diamkan 1 jam sampai mengembang.
1. Setelah mengembang oles adonan dan taburi toppping. Wijen isian keju, meises isian coklat batang dan parsley isian sosis keju.
1. Panggang sampai matang suhu 190 derajat selama 10 menitan atau sampai matang ya.
1. Setelah matang disobek2 jadi roti unyil tinggal happp. Empukk rotinya, serat cakep, gemes unyu2. 😍




Demikianlah cara membuat roti unyil yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
