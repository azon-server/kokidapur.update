---
description: "Bagaimana untuk menyiapakan Sambel tumpang khas salatiga Cepat"
title: "Bagaimana untuk menyiapakan Sambel tumpang khas salatiga Cepat"
slug: 402-bagaimana-untuk-menyiapakan-sambel-tumpang-khas-salatiga-cepat
date: 2021-01-01T11:24:07.097Z
image: https://img-global.cpcdn.com/recipes/78a4faeee0e8117a/680x482cq70/sambel-tumpang-khas-salatiga-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/78a4faeee0e8117a/680x482cq70/sambel-tumpang-khas-salatiga-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/78a4faeee0e8117a/680x482cq70/sambel-tumpang-khas-salatiga-foto-resep-utama.jpg
author: Susan Jordan
ratingvalue: 4.3
reviewcount: 31597
recipeingredient:
- "1/2 kg koyor sapi kikil  krecek dipotongpotong agak kecil"
- "3 bh tahu kulit potong sesuai selera"
- " tempe optional"
- "1 papan petai"
- " telor rebus optional telor bebek lebih nikmat"
- " santan dari 12 butir kelapa"
- " bumbu"
- "3 cabe rawit merah saya tidak suka pedas"
- "8 cabe keriting merah biar kuahnya tampak merah"
- "3 siung bawang merah"
- "3 siung bawang putih"
- "5 butir kemiri"
- "1 ruas kencur"
- "sedikit gula merah"
- " daun jerukkulit jeruk purut sedikit saja"
- " daun salam"
- " sereh"
- " lengkuas"
- " garam"
- " penyedap"
- " tempe busuk agak dibanyakin biar lebih nikmat"
recipeinstructions:
- "Rebus koyor atau kikil sampai empuk. Kalau pakai krecek tidak direbus tapi direndam ait dingin, baru dipotong"
- "Rebus bumbu: cabe rawit, cabe keriting, bawang merah, bawang putih, kemiri, kencur, daun jeruk/kulit jeruk purut, tempe busuk"
- "Haluskan bumbu yang sudah direbus.tambahkan garam"
- "Tumis bumbu yang sudah dihaluskan, ditambah daun salam, sereh, lengkuas, petai"
- "Masukkan koyor/kikil/krecek, dikongsreng sampai bercampur semua"
- "Masukkan tahu yang sudah dipotong-potong, tambahkan gula merah.kongsreng lagi sampai tahu setengah hancur"
- "Tambahkan air sedikit, masukkan telor rebus yang sudah dikupas"
- "Tunggu sampai mendidih, masukkan santan dan penyedap."
- "Setelah mendidih dan rasa sudah pas, angkat, sajikan."
- "Lebih nikmat jika dimakan keesokan harinya sehingga bumbu sudah bemar2 meresap."
- "Busa dimakan pakai nasi atau bubur."
- "Pelengkap: sayur tumpang bisa ditemani urap, pecel, oseng pare, atau oseng buncis.hmmm....nikmat..."
categories:
- Recipe
tags:
- sambel
- tumpang
- khas

katakunci: sambel tumpang khas 
nutrition: 299 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT46M"
recipeyield: "4"
recipecategory: Lunch

---


![Sambel tumpang khas salatiga](https://img-global.cpcdn.com/recipes/78a4faeee0e8117a/680x482cq70/sambel-tumpang-khas-salatiga-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang patut kita jaga karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti sambel tumpang khas salatiga yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan ciri khas yang merupakan keragaman Kita



Kehangatan keluarga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Sambel tumpang khas salatiga untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda praktekkan salah satunya sambel tumpang khas salatiga yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep sambel tumpang khas salatiga tanpa harus bersusah payah.
Seperti resep Sambel tumpang khas salatiga yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 12 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambel tumpang khas salatiga:

1. Harap siapkan 1/2 kg koyor sapi/ kikil / krecek dipotong-potong agak kecil
1. Jangan lupa 3 bh tahu kulit, potong sesuai selera
1. Jangan lupa  tempe (optional)
1. Diperlukan 1 papan petai
1. Harap siapkan  telor rebus (optional, telor bebek lebih nikmat)
1. Tambah  santan dari 1/2 butir kelapa
1. Harus ada  bumbu:
1. Harus ada 3 cabe rawit merah (saya tidak suka pedas)
1. Tambah 8 cabe keriting merah, biar kuahnya tampak merah
1. Siapkan 3 siung bawang merah
1. Harus ada 3 siung bawang putih
1. Siapkan 5 butir kemiri
1. Jangan lupa 1 ruas kencur
1. Tambah sedikit gula merah
1. Harus ada  daun jeruk/kulit jeruk purut sedikit saja
1. Siapkan  daun salam
1. Diperlukan  sereh
1. Tambah  lengkuas
1. Harap siapkan  garam
1. Siapkan  penyedap
1. Tambah  tempe busuk (agak dibanyakin biar lebih nikmat)




<!--inarticleads2-->

##### Langkah membuat  Sambel tumpang khas salatiga:

1. Rebus koyor atau kikil sampai empuk. Kalau pakai krecek tidak direbus tapi direndam ait dingin, baru dipotong
1. Rebus bumbu: cabe rawit, cabe keriting, bawang merah, bawang putih, kemiri, kencur, daun jeruk/kulit jeruk purut, tempe busuk
1. Haluskan bumbu yang sudah direbus.tambahkan garam
1. Tumis bumbu yang sudah dihaluskan, ditambah daun salam, sereh, lengkuas, petai
1. Masukkan koyor/kikil/krecek, dikongsreng sampai bercampur semua
1. Masukkan tahu yang sudah dipotong-potong, tambahkan gula merah.kongsreng lagi sampai tahu setengah hancur
1. Tambahkan air sedikit, masukkan telor rebus yang sudah dikupas
1. Tunggu sampai mendidih, masukkan santan dan penyedap.
1. Setelah mendidih dan rasa sudah pas, angkat, sajikan.
1. Lebih nikmat jika dimakan keesokan harinya sehingga bumbu sudah bemar2 meresap.
1. Busa dimakan pakai nasi atau bubur.
1. Pelengkap: sayur tumpang bisa ditemani urap, pecel, oseng pare, atau oseng buncis.hmmm....nikmat...




Demikianlah cara membuat sambel tumpang khas salatiga yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan teruji, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
