---
description: "Cara singkat untuk menyiapakan Sambel Tumpang Salatiga Terbukti"
title: "Cara singkat untuk menyiapakan Sambel Tumpang Salatiga Terbukti"
slug: 455-cara-singkat-untuk-menyiapakan-sambel-tumpang-salatiga-terbukti
date: 2021-01-17T22:23:06.874Z
image: https://img-global.cpcdn.com/recipes/457e5a2d9bfa322f/680x482cq70/sambel-tumpang-salatiga-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/457e5a2d9bfa322f/680x482cq70/sambel-tumpang-salatiga-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/457e5a2d9bfa322f/680x482cq70/sambel-tumpang-salatiga-foto-resep-utama.jpg
author: Francisco Lynch
ratingvalue: 4.9
reviewcount: 2876
recipeingredient:
- " Tempe bosok kurleb tempe papan 5cm x 10cm"
- "10-15 buah Tahu kulit uk kecil"
- "1/4 kg Tetelan sapi"
- "3 buah cabe merah keriting"
- "5 buah cabe rawit merah"
- "7 butir bawang"
- "5 butir bawang putih"
- "1 ruas jari kencur"
- "2 lbr daun salam"
- " Lengkuas"
- "2 batang serai"
- "5-6 lbr daun jeruk"
- "secukupnya Garam dan gula jawa"
- " Santan kara sachet 65ml"
- " Boleh pake penyedap kalo suka"
recipeinstructions:
- "Rebus tempe bosok, tetelan dan tahu, daun salam, daun jeruk, serai dan lengkuas. Krg lebih 20-30 menit, smp tetelan empuk"
- "Masukkan cabe, bawang merah, bawang putih dan kencur ke dalam rebusan sktr 5 menit, lalu angkat. Spy mudah, sy masukkan ke plastik tahan panas, jd ga ngambilin satu-satu dr panci."
- "Ulek bawang merah, bawang putih, cabe dan kencur yg sudah direbus smp halus. Tumis smp wangi di tungku kompor yg satunya, setelah itu tuang ke panci yg isinya rebusan tahu dll."
- "Bumbui dgn garam, gula, dan penyedap (royco/totole) bila suka. Cek rasa."
- "Masukkan santan kara. Aduk. Cek rasa lagi. Setelah mantap dan kuah mendidih, matikan api. Sambel tumpang sudah matang...."
- "Bila suka, bisa ditambah pete dan krecek di langkah pertama."
- "Merasa tertantang makan olahan tempe bosok? Selamat mencoba....♥️😊"
categories:
- Recipe
tags:
- sambel
- tumpang
- salatiga

katakunci: sambel tumpang salatiga 
nutrition: 152 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Lunch

---


![Sambel Tumpang Salatiga](https://img-global.cpcdn.com/recipes/457e5a2d9bfa322f/680x482cq70/sambel-tumpang-salatiga-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang harus kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti sambel tumpang salatiga yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Kita



Kedekatan keluarga dapat diperoleh dengan cara mudah. Diantaranya adalah memasak Sambel Tumpang Salatiga untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang bisa anda praktekkan salah satunya sambel tumpang salatiga yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep sambel tumpang salatiga tanpa harus bersusah payah.
Berikut ini resep Sambel Tumpang Salatiga yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambel Tumpang Salatiga:

1. Dibutuhkan  Tempe bosok (kurleb tempe papan 5cm x 10cm)
1. Tambah 10-15 buah Tahu kulit uk kecil
1. Harap siapkan 1/4 kg Tetelan sapi
1. Harap siapkan 3 buah cabe merah keriting
1. Diperlukan 5 buah cabe rawit merah
1. Harus ada 7 butir bawang
1. Jangan lupa 5 butir bawang putih
1. Harus ada 1 ruas jari kencur
1. Dibutuhkan 2 lbr daun salam
1. Siapkan  Lengkuas
1. Jangan lupa 2 batang serai
1. Jangan lupa 5-6 lbr daun jeruk
1. Diperlukan secukupnya Garam dan gula jawa
1. Tambah  Santan kara sachet 65ml
1. Jangan lupa  Boleh pake penyedap kalo suka




<!--inarticleads2-->

##### Instruksi membuat  Sambel Tumpang Salatiga:

1. Rebus tempe bosok, tetelan dan tahu, daun salam, daun jeruk, serai dan lengkuas. Krg lebih 20-30 menit, smp tetelan empuk
1. Masukkan cabe, bawang merah, bawang putih dan kencur ke dalam rebusan sktr 5 menit, lalu angkat. Spy mudah, sy masukkan ke plastik tahan panas, jd ga ngambilin satu-satu dr panci.
1. Ulek bawang merah, bawang putih, cabe dan kencur yg sudah direbus smp halus. Tumis smp wangi di tungku kompor yg satunya, setelah itu tuang ke panci yg isinya rebusan tahu dll.
1. Bumbui dgn garam, gula, dan penyedap (royco/totole) bila suka. Cek rasa.
1. Masukkan santan kara. Aduk. Cek rasa lagi. Setelah mantap dan kuah mendidih, matikan api. Sambel tumpang sudah matang....
1. Bila suka, bisa ditambah pete dan krecek di langkah pertama.
1. Merasa tertantang makan olahan tempe bosok? Selamat mencoba....♥️😊




Demikianlah cara membuat sambel tumpang salatiga yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan cepat, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
