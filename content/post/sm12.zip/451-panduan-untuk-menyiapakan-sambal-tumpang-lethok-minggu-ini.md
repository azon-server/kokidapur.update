---
description: "Panduan untuk menyiapakan Sambal Tumpang (Lethok) minggu ini"
title: "Panduan untuk menyiapakan Sambal Tumpang (Lethok) minggu ini"
slug: 451-panduan-untuk-menyiapakan-sambal-tumpang-lethok-minggu-ini
date: 2021-02-23T11:24:00.319Z
image: https://img-global.cpcdn.com/recipes/58df004b8fcf20fc/680x482cq70/sambal-tumpang-lethok-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/58df004b8fcf20fc/680x482cq70/sambal-tumpang-lethok-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/58df004b8fcf20fc/680x482cq70/sambal-tumpang-lethok-foto-resep-utama.jpg
author: Betty Jordan
ratingvalue: 4.5
reviewcount: 26537
recipeingredient:
- "1/4 kg babat bisa untuk 1 atau 2 kali pakai"
- " Air untuk merebus"
- "1 batang Sereh"
- "2 cm Jahe"
- "1 papan Tempe yang sudah didiamkan 23 hari di suhu ruang"
- "4 siung Bawang Merah"
- "2 siung Bawang Putih"
- "2 biji Kemiri"
- "1 cm Kencur"
- "Secukupnya Cabe RawitKriting"
- "Secukupnya Garam"
- "Secukupnya Gula Merah"
- "Secukupnya Penyedap optional"
- "3 lembar Daun Jeruk"
- "2 lembar Daun Salam"
recipeinstructions:
- "Rebus/presto babat, masukkan sereh dan jahe geprek serta sedikit garam. Setelah empuk, matikan api. Buang air rebusan, iris kecil babat."
- "Potong kecil tempe agar mudah saat diulek. Didihkan air,masukkan tempe, bawang putih dan bawang merah, cabe rawit/kriting, kencur serta kemiri. Rebus sampai matang/mulai empuk."
- "Angkat tempe dan revusan lainnya, air rebusan akan digu akan kembali. Ulek tempe sampai halus, ulek bawang, kencur, cabe, dan kemiri sampai halus."
- "Didihkan kembali air rebusan tempe, masukkan irisan babat, ulekan tempe dan bumbu."
- "Masukkan lengkuas geprek, daun jeruk, dan daun salam, garam, dan gula merah. Koreksi rasa, jika sudah pas biarkan 5-10 menit sampai meresap. Sambal Tumpang alias Lethok siap disajikan 😘"
categories:
- Recipe
tags:
- sambal
- tumpang
- lethok

katakunci: sambal tumpang lethok 
nutrition: 165 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Dessert

---


![Sambal Tumpang (Lethok)](https://img-global.cpcdn.com/recipes/58df004b8fcf20fc/680x482cq70/sambal-tumpang-lethok-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau renyah. Ciri makanan Indonesia sambal tumpang (lethok) yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Sambal Tumpang (Lethok) untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis makanan yang bisa anda praktekkan salah satunya sambal tumpang (lethok) yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep sambal tumpang (lethok) tanpa harus bersusah payah.
Berikut ini resep Sambal Tumpang (Lethok) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 15 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambal Tumpang (Lethok):

1. Tambah 1/4 kg babat (bisa untuk 1 atau 2 kali pakai)
1. Harus ada  Air untuk merebus
1. Jangan lupa 1 batang Sereh
1. Siapkan 2 cm Jahe
1. Jangan lupa 1 papan Tempe yang sudah didiamkan 2-3 hari di suhu ruang
1. Tambah 4 siung Bawang Merah
1. Dibutuhkan 2 siung Bawang Putih
1. Harus ada 2 biji Kemiri
1. Harap siapkan 1 cm Kencur
1. Harap siapkan Secukupnya Cabe Rawit/Kriting
1. Siapkan Secukupnya Garam
1. Siapkan Secukupnya Gula Merah
1. Dibutuhkan Secukupnya Penyedap (optional)
1. Diperlukan 3 lembar Daun Jeruk
1. Tambah 2 lembar Daun Salam




<!--inarticleads2-->

##### Langkah membuat  Sambal Tumpang (Lethok):

1. Rebus/presto babat, masukkan sereh dan jahe geprek serta sedikit garam. Setelah empuk, matikan api. Buang air rebusan, iris kecil babat.
1. Potong kecil tempe agar mudah saat diulek. Didihkan air,masukkan tempe, bawang putih dan bawang merah, cabe rawit/kriting, kencur serta kemiri. Rebus sampai matang/mulai empuk.
1. Angkat tempe dan revusan lainnya, air rebusan akan digu akan kembali. Ulek tempe sampai halus, ulek bawang, kencur, cabe, dan kemiri sampai halus.
1. Didihkan kembali air rebusan tempe, masukkan irisan babat, ulekan tempe dan bumbu.
1. Masukkan lengkuas geprek, daun jeruk, dan daun salam, garam, dan gula merah. Koreksi rasa, jika sudah pas biarkan 5-10 menit sampai meresap. Sambal Tumpang alias Lethok siap disajikan 😘




Demikianlah cara membuat sambal tumpang (lethok) yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan teruji, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
