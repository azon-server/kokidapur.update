---
description: "Resep : Sambal Tumpang khas Boyolali teraktual"
title: "Resep : Sambal Tumpang khas Boyolali teraktual"
slug: 419-resep-sambal-tumpang-khas-boyolali-teraktual
date: 2020-11-03T04:41:25.287Z
image: https://img-global.cpcdn.com/recipes/1e4ec5f433ae71eb/680x482cq70/sambal-tumpang-khas-boyolali-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1e4ec5f433ae71eb/680x482cq70/sambal-tumpang-khas-boyolali-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1e4ec5f433ae71eb/680x482cq70/sambal-tumpang-khas-boyolali-foto-resep-utama.jpg
author: Emma Little
ratingvalue: 4.1
reviewcount: 26283
recipeingredient:
- "1 bungkus tahu asin kulitnya cokelat isinya 8 buah"
- "4 buah tempe semangittempe busuk"
- "2 siung bawang putih"
- "4 buah bawang merah"
- "2 ruas kencur"
- "9 buah cabai rawit"
- "2 buah santan kara"
- "3 lbr daun salam"
- "1 ruas laos 3cm"
- "secukupnya garam"
- "2 sdm gula pasir"
recipeinstructions:
- "Masak tahu sambil rebus/masukkan cabai, bawang putih, bawang merah, dan kencur sampai airnya mendidih."
- "Pisahkan atau keluarkan bumbu2 yang sudah direbus, untuk ditumbuk. Masak kembali/rebus tahu tadi, ditambah 4 tempe busuk."
- "Tunggu beberapa saat sampai mendidih. Sambil menunggu, tumbuk semua bumbu hingga halus. Apabila sudah mendidih, keluar kan semua tempe, lalu tumbuk bersama bumbu halus tadi. Kalau sudah, kembalikan kedalam panci, aduk-aduk."
- "Masukkan daun salam dan laos yang sudah digeprek. Tunggu sebentar, lalu masukkan santan."
- "Tambahkan garam dan gula, aduk-aduk."
- "Koreksi rasa, kata nenek aslinya sambal tumpang ini rasanya agak manis jadi bisa disesuaikan sesuai dengan selera masing-masing ya :)"
- "Kalau sudah, angkat.. dan sajikan selagi panas."
categories:
- Recipe
tags:
- sambal
- tumpang
- khas

katakunci: sambal tumpang khas 
nutrition: 102 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Dinner

---


![Sambal Tumpang khas Boyolali](https://img-global.cpcdn.com/recipes/1e4ec5f433ae71eb/680x482cq70/sambal-tumpang-khas-boyolali-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang patut kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti sambal tumpang khas boyolali yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan keistimewahan yang merupakan keragaman Indonesia

Kehangatan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Sambal Tumpang khas Boyolali untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang dapat anda coba salah satunya sambal tumpang khas boyolali yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep sambal tumpang khas boyolali tanpa harus bersusah payah.
Berikut ini resep Sambal Tumpang khas Boyolali yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambal Tumpang khas Boyolali:

1. Dibutuhkan 1 bungkus tahu asin (kulitnya cokelat) isinya 8 buah
1. Jangan lupa 4 buah tempe semangit/tempe busuk
1. Tambah 2 siung bawang putih
1. Siapkan 4 buah bawang merah
1. Tambah 2 ruas kencur
1. Diperlukan 9 buah cabai rawit
1. Siapkan 2 buah santan kara
1. Diperlukan 3 lbr daun salam
1. Dibutuhkan 1 ruas laos (3cm)
1. Diperlukan secukupnya garam
1. Tambah 2 sdm gula pasir




<!--inarticleads2-->

##### Cara membuat  Sambal Tumpang khas Boyolali:

1. Masak tahu sambil rebus/masukkan cabai, bawang putih, bawang merah, dan kencur sampai airnya mendidih.
1. Pisahkan atau keluarkan bumbu2 yang sudah direbus, untuk ditumbuk. Masak kembali/rebus tahu tadi, ditambah 4 tempe busuk.
1. Tunggu beberapa saat sampai mendidih. Sambil menunggu, tumbuk semua bumbu hingga halus. Apabila sudah mendidih, keluar kan semua tempe, lalu tumbuk bersama bumbu halus tadi. Kalau sudah, kembalikan kedalam panci, aduk-aduk.
1. Masukkan daun salam dan laos yang sudah digeprek. Tunggu sebentar, lalu masukkan santan.
1. Tambahkan garam dan gula, aduk-aduk.
1. Koreksi rasa, kata nenek aslinya sambal tumpang ini rasanya agak manis jadi bisa disesuaikan sesuai dengan selera masing-masing ya :)
1. Kalau sudah, angkat.. dan sajikan selagi panas.




Demikianlah cara membuat sambal tumpang khas boyolali yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
