---
description: "Resep : Sambel Tumpang khas Solo Luar biasa"
title: "Resep : Sambel Tumpang khas Solo Luar biasa"
slug: 368-resep-sambel-tumpang-khas-solo-luar-biasa
date: 2020-12-07T11:42:07.200Z
image: https://img-global.cpcdn.com/recipes/e6d79bb313c14372/680x482cq70/sambel-tumpang-khas-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e6d79bb313c14372/680x482cq70/sambel-tumpang-khas-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e6d79bb313c14372/680x482cq70/sambel-tumpang-khas-solo-foto-resep-utama.jpg
author: Fannie Watkins
ratingvalue: 4.5
reviewcount: 18685
recipeingredient:
- "1 tempe semangit sy simpen dikulkas 2 minggu haluskan"
- "1 tempe fresh haluskan"
- " Tahu putih potong kecil2"
- "1 sct santan kara"
- "1 batang sereh"
- "4 ruas lengkuas"
- "4 lembar daun salam"
- "5 lembar daun jeruk"
- " Bumbu halus"
- "4 siung bawang merah"
- "4 siung bawang putih"
- "1 sdt ebi"
- "4 butir kemiri"
- "5 buah cabe sy ga pke"
- "Secukupnya minyak utk menumis"
- "Secukupnya garam gula pasir gula merah dan kaldu jamur"
- " Sayuran rebus"
- " Bayam"
- " Kacang panjang dan taoge sy ga pke"
- " Lauk tambahan"
recipeinstructions:
- "Siapkan air dlm panci, rebus. Masukkan gula merah, sereh, daun salam, daun jeruk dan lengkuas. Tambahkan tempe semangit dan tempe fresh yg sudah dihaluskan. Kecilkan api biar ga meluap airnya klo mendidih."
- "Tumis bumbu halus lalu masukkan ke dlm panci."
- "Klo sudah mendidih, masukkan tahu putih. tunggu sktr 10 menit, lalu tambahkan santan kara, garam, gula pasir dan kaldu jamur. Aduk rata, koreksi rasa."
- "Penyajiannya, tata sayuran diatas piring lalu siram dgn kuah tumpang, sajikan dgn telur rebus."
categories:
- Recipe
tags:
- sambel
- tumpang
- khas

katakunci: sambel tumpang khas 
nutrition: 144 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Dinner

---


![Sambel Tumpang khas Solo](https://img-global.cpcdn.com/recipes/e6d79bb313c14372/680x482cq70/sambel-tumpang-khas-solo-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti sambel tumpang khas solo yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan ciri khas yang merupakan keragaman Indonesia



Kedekatan rumah tangga dapat diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Sambel Tumpang khas Solo untuk orang di rumah. Momen makan bersama orang tua sudah menjadi budaya, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang dapat anda praktekkan salah satunya sambel tumpang khas solo yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep sambel tumpang khas solo tanpa harus bersusah payah.
Berikut ini resep Sambel Tumpang khas Solo yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 20 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambel Tumpang khas Solo:

1. Diperlukan 1 tempe semangit (sy simpen dikulkas 2 minggu), haluskan
1. Diperlukan 1 tempe fresh, haluskan
1. Siapkan  Tahu putih, potong kecil2
1. Diperlukan 1 sct santan kara
1. Tambah 1 batang sereh
1. Siapkan 4 ruas lengkuas
1. Harap siapkan 4 lembar daun salam
1. Harap siapkan 5 lembar daun jeruk
1. Jangan lupa  Bumbu halus:
1. Harus ada 4 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Tambah 1 sdt ebi
1. Harap siapkan 4 butir kemiri
1. Diperlukan 5 buah cabe (sy ga pke)
1. Harus ada Secukupnya minyak utk menumis
1. Tambah Secukupnya garam, gula pasir, gula merah dan kaldu jamur
1. Dibutuhkan  Sayuran rebus:
1. Siapkan  Bayam
1. Jangan lupa  Kacang panjang dan taoge (sy ga pke)
1. Dibutuhkan  Lauk tambahan:




<!--inarticleads2-->

##### Instruksi membuat  Sambel Tumpang khas Solo:

1. Siapkan air dlm panci, rebus. Masukkan gula merah, sereh, daun salam, daun jeruk dan lengkuas. Tambahkan tempe semangit dan tempe fresh yg sudah dihaluskan. Kecilkan api biar ga meluap airnya klo mendidih.
1. Tumis bumbu halus lalu masukkan ke dlm panci.
1. Klo sudah mendidih, masukkan tahu putih. tunggu sktr 10 menit, lalu tambahkan santan kara, garam, gula pasir dan kaldu jamur. Aduk rata, koreksi rasa.
1. Penyajiannya, tata sayuran diatas piring lalu siram dgn kuah tumpang, sajikan dgn telur rebus.




Demikianlah cara membuat sambel tumpang khas solo yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan terbukti, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
