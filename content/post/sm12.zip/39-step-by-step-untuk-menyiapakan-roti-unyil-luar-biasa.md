---
description: "Step-by-Step untuk menyiapakan Roti Unyil Luar biasa"
title: "Step-by-Step untuk menyiapakan Roti Unyil Luar biasa"
slug: 39-step-by-step-untuk-menyiapakan-roti-unyil-luar-biasa
date: 2021-03-04T00:00:00.248Z
image: https://img-global.cpcdn.com/recipes/fabc71a5673964fd/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fabc71a5673964fd/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fabc71a5673964fd/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Helen French
ratingvalue: 4.2
reviewcount: 2395
recipeingredient:
- " Bahan A "
- "200 gr Tepung Terigu protein tinggi"
- "60 gr tepung terigu protein rendah"
- "10 gr susu bubuk"
- "3 gr ragi instan"
- "55 gr gula castor"
- " Bahan B "
- "170 gr cairan 1 butir telur  susu cair  170gr"
- " Bahan C "
- "30 gr Butter"
- "1/4 sdt garam"
- " Bahan olesan "
- "1 butir telur kocok lepas"
- " Isian "
- " Keju"
- " Sosis Ayam"
- " Pisang"
- " Selai coklat"
- " Selai strawberry"
- " Selai blueberry"
recipeinstructions:
- "Campur semua bahan A, aduk rata."
- "Siapkan bahan B, aduk rata. Masukkan Bahan B ke bahan A sambil di uleni hingga 1/2 kalis."
- "Lalu masukkan bahan C, uleni hingga kalis elastis dan bila ditest adonannya tidak mudah sobek dan terlihat windowpane. Bulatkan adonan, dan masukkan kedalam bowl dan tutup atasnya dengan plastik wrap."
- "Istirahatkan kurleb 30-45 menit hingga mengembang 2x lipat. Setelah mengembang, kempiskan adonan, lalu timbang 11-15 gr peradonan."
- "Bentuk dan Isi sesuai selera, lalu letakkan diatas loyang yang sudah dialasi kertas roti. Panaskan oven, setelah panas lalu oles roti dengan telur lalu oven roti 15-20 menit dengan suhu 180°C (sesuaikan oven masing-masing)"
- "Sudah matang dan siap dihidangkan."
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 300 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dinner

---


![Roti Unyil](https://img-global.cpcdn.com/recipes/fabc71a5673964fd/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti roti unyil yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Indonesia

Kedekatan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah memasak Roti Unyil untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang bisa anda coba salah satunya roti unyil yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep roti unyil tanpa harus bersusah payah.
Seperti resep Roti Unyil yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Unyil:

1. Siapkan  Bahan A :
1. Harap siapkan 200 gr Tepung Terigu protein tinggi
1. Dibutuhkan 60 gr tepung terigu protein rendah
1. Tambah 10 gr susu bubuk
1. Dibutuhkan 3 gr ragi instan
1. Diperlukan 55 gr gula castor
1. Dibutuhkan  Bahan B :
1. Harap siapkan 170 gr cairan (1 butir telur + susu cair = 170gr)
1. Diperlukan  Bahan C :
1. Diperlukan 30 gr Butter
1. Dibutuhkan 1/4 sdt garam
1. Diperlukan  Bahan olesan :
1. Harap siapkan 1 butir telur, kocok lepas
1. Diperlukan  Isian :
1. Tambah  Keju
1. Harap siapkan  Sosis Ayam
1. Harap siapkan  Pisang
1. Jangan lupa  Selai coklat
1. Harap siapkan  Selai strawberry
1. Tambah  Selai blueberry




<!--inarticleads2-->

##### Bagaimana membuat  Roti Unyil:

1. Campur semua bahan A, aduk rata.
1. Siapkan bahan B, aduk rata. Masukkan Bahan B ke bahan A sambil di uleni hingga 1/2 kalis.
1. Lalu masukkan bahan C, uleni hingga kalis elastis dan bila ditest adonannya tidak mudah sobek dan terlihat windowpane. Bulatkan adonan, dan masukkan kedalam bowl dan tutup atasnya dengan plastik wrap.
1. Istirahatkan kurleb 30-45 menit hingga mengembang 2x lipat. Setelah mengembang, kempiskan adonan, lalu timbang 11-15 gr peradonan.
1. Bentuk dan Isi sesuai selera, lalu letakkan diatas loyang yang sudah dialasi kertas roti. Panaskan oven, setelah panas lalu oles roti dengan telur lalu oven roti 15-20 menit dengan suhu 180°C (sesuaikan oven masing-masing)
1. Sudah matang dan siap dihidangkan.




Demikianlah cara membuat roti unyil yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan terbukti, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
