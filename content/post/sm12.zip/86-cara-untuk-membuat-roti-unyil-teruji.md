---
description: "Cara untuk membuat Roti unyil Teruji"
title: "Cara untuk membuat Roti unyil Teruji"
slug: 86-cara-untuk-membuat-roti-unyil-teruji
date: 2020-11-07T10:11:32.206Z
image: https://img-global.cpcdn.com/recipes/ad86c5538d0aec2f/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ad86c5538d0aec2f/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ad86c5538d0aec2f/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Troy Watson
ratingvalue: 4.8
reviewcount: 48221
recipeingredient:
- " Bahan A"
- "300 gr tepung pro tinggi"
- "75 gr tepung protein sedang"
- "60 gr gula butiran halus saya blender"
- "23 gr susu bubuk fullcream"
- "7 gr ragi instan"
- " Bahan B"
- "230-235 gr cairan 1 kuning telur1 telur utuhsusu cair dingin"
- " Bahan C"
- "45 gr mentega"
- "5 gr garam dapur halus"
- " Bahan olesan"
- "1 sendok makan Kuning telur  susu cair"
recipeinstructions:
- "Campur semua bahan A aduk rata, tambahkan bahan B di mix dengan kec sedang sampai kalis. Tambahkan bahan C, mix dengan kecepatan lebih tinggi hingga kalis elastis saya kurang lebih 20-25 menit."
- "Bulatkan adonan hingga permukaan mulus, masukan ke dalam wadah tutup dengan cling wrap. Tunggu adonan hingga 2x lipat. Kurang lebih 45-60 menit"
- "Kempiskan adonan,saya bagi masing masing 20 gr, kalo seperti roti2 unyil bogor biasanya beratnya hanya 10-12 gr. Lagi males bikin yg imut2 jadi di gedein sedikit. Lalu isi dengan isian sesuai selera..diamkan kembali hingga mengembang... 30-45 menit."
- "15 menit sebelum adonan mengembang nyalahkan oven 190 derajat.(sesuaikan dengan oven masing2)"
- "Jika sudah mengembang olesi dengan bahan olesan. panggang selama 10 menit..."
- "Roti siap di hap, hap, hap.... 😂"
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 175 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT49M"
recipeyield: "1"
recipecategory: Dinner

---


![Roti unyil](https://img-global.cpcdn.com/recipes/ad86c5538d0aec2f/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas atau enak. Ciri khas kuliner Indonesia roti unyil yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kehangatan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Roti unyil untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.

Lihat juga resep Roti Unyil empuk lembut enak versi Killer Soft Bread❤️ enak lainnya. Harga Roti Unyil - Roti Unyil merupakan jenis kue yang sedang booming di pasaran. Banyak orang yang berlomba-lomba untuk membeli dan menikmati rasanya. Roti unyil nyaéta roti anu mibanda ukuran leuwih leutik tibatan roti séjén anu ilahar.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang dapat anda contoh salah satunya roti unyil yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep roti unyil tanpa harus bersusah payah.
Seperti resep Roti unyil yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 13 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti unyil:

1. Tambah  Bahan A
1. Siapkan 300 gr tepung pro tinggi
1. Harus ada 75 gr tepung protein sedang
1. Tambah 60 gr gula butiran halus (saya blender)
1. Harap siapkan 23 gr susu bubuk fullcream
1. Tambah 7 gr ragi instan
1. Dibutuhkan  Bahan B
1. Dibutuhkan 230-235 gr cairan (1 kuning telur+1 telur utuh+susu cair dingin)
1. Jangan lupa  Bahan C
1. Harap siapkan 45 gr mentega
1. Tambah 5 gr garam dapur halus
1. Harus ada  Bahan olesan
1. Harus ada 1 sendok makan Kuning telur + susu cair


Masukkan wortel, makaroni, kacang polong, dan semua bumbu yang sudah dipersiapkan. Aroma roti yang khas memang sangat mengundang selera, apalagi aroma roti yang baru dikeluarkan dari oven, nyumm! Makanan yang berbahan dasar tepung dan ragi ini sudah dikenal sejak tahun. Roti Unyil adalah roti mini atau ukuran kecil dengan aneka rasa dan aneka isi serta teksturnya empuk banget. 

<!--inarticleads2-->

##### Bagaimana membuat  Roti unyil:

1. Campur semua bahan A aduk rata, tambahkan bahan B di mix dengan kec sedang sampai kalis. Tambahkan bahan C, mix dengan kecepatan lebih tinggi hingga kalis elastis saya kurang lebih 20-25 menit.
1. Bulatkan adonan hingga permukaan mulus, masukan ke dalam wadah tutup dengan cling wrap. Tunggu adonan hingga 2x lipat. Kurang lebih 45-60 menit
1. Kempiskan adonan,saya bagi masing masing 20 gr, kalo seperti roti2 unyil bogor biasanya beratnya hanya 10-12 gr. Lagi males bikin yg imut2 jadi di gedein sedikit. Lalu isi dengan isian sesuai selera..diamkan kembali hingga mengembang... 30-45 menit.
1. 15 menit sebelum adonan mengembang nyalahkan oven 190 derajat.(sesuaikan dengan oven masing2)
1. Jika sudah mengembang olesi dengan bahan olesan. panggang selama 10 menit...
1. Roti siap di hap, hap, hap.... 😂


Makanan yang berbahan dasar tepung dan ragi ini sudah dikenal sejak tahun. Roti Unyil adalah roti mini atau ukuran kecil dengan aneka rasa dan aneka isi serta teksturnya empuk banget. Roti unyil sebenarnya sama dengan jenis resep roti manis lainnya, yang membedakan. Faila, Depok Jawab: Faila, roti unyil sebenarnya adalah adonan roti biasa yang dibentuk kecil. Roti mini atau yang lebih kita kenal dengan roti unyil cukup banyak digemari orang ini, kali ini Chef martino mangajak anda untuk membuat sendiri roti unyil di rumah. 

Demikianlah cara membuat roti unyil yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
