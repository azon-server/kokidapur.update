---
description: "Steps untuk menyiapakan Sambel Godog/Sambel Tumpang Sempurna"
title: "Steps untuk menyiapakan Sambel Godog/Sambel Tumpang Sempurna"
slug: 461-steps-untuk-menyiapakan-sambel-godog-sambel-tumpang-sempurna
date: 2020-09-17T12:55:18.136Z
image: https://img-global.cpcdn.com/recipes/630ec9a50c7b9349/680x482cq70/sambel-godogsambel-tumpang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/630ec9a50c7b9349/680x482cq70/sambel-godogsambel-tumpang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/630ec9a50c7b9349/680x482cq70/sambel-godogsambel-tumpang-foto-resep-utama.jpg
author: Craig Conner
ratingvalue: 4.7
reviewcount: 47117
recipeingredient:
- "1 kotak sedang tempe semangitbusuk di tempat saya yg 5 ribu dpt 3 kotak tempe"
- "1/2 butir kelapa besar ambil santan cair dan santal kental nya"
- "4 kotak sedang tahu putih asal goreng saja tdk usah kering2"
- "2 terong potong2 sedang"
- "1 cabe rawit buang isinyasesuai selera cabe apa aja"
- "4 Bawang merah besarsesuai selera"
- "2 Bawang putih besarsesuai selera"
- "2 cm kencursesuai selera"
- "2 batang seraisesuai selera"
- "3 lembar daun salamsesuai selera"
- "5 cm lengkuassesuai selera"
- "4 lembar daun jeruksesuai selera"
- "Secukupnya Gula merahsaya tdk pake"
- "Secukupnya Gula pasir"
- "Secukupnya garam"
- " Penyedap klo sukaklo tdk suka bisa d ganti kaldu bubuk alami"
- " Daun singkong rebus untuk pelengkapsesuai selera aja"
recipeinstructions:
- "Rebus bawang merah, bawang putih, kencur, cabe, tempe busuk, daun salam, serai, daun jeruk, lengkuas di wajan agk besar, air ny kira2 saja,, sampe bau harum, dn air d sisain 1 mangkok kecil lah kira2, jgn d habisin air rebusan nya yah,, itu yg bkin enk.. Klo pndpt kami.. #senyum"
- "Serai, lengkuas, daun salam, daun jeruk yg d rebus tdi jgn d buang yah,, msih d masak lgi.. Hee"
- "Ulek bawang putih, bawang merah, kencur, cabe, smpe halus, kemudian ulek kasar tempe ny..trus masukkn ke dalam wajan ny yg tdi yg buat rebus bumbu ny.. Masukkan tahu, santan cair, ksih gula merah, gula pasir, garam"
- "Tutup wajan, tunggu smpe mendidih dan baunya sdh harum, tes rasa,, masukkan terong dan santan kental, aduk2,, jgn smpe pecah santan ny.. Tunggu 15 mnit/smpe terong matang.. Matikan kompor,, Siap di hidangkan dengan kulupan daun singkong..."
categories:
- Recipe
tags:
- sambel
- godogsambel
- tumpang

katakunci: sambel godogsambel tumpang 
nutrition: 106 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT39M"
recipeyield: "1"
recipecategory: Dessert

---


![Sambel Godog/Sambel Tumpang](https://img-global.cpcdn.com/recipes/630ec9a50c7b9349/680x482cq70/sambel-godogsambel-tumpang-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang setidaknya kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti sambel godog/sambel tumpang yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan ciri khas yang merupakan keragaman Indonesia

Keharmonisan keluarga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Sambel Godog/Sambel Tumpang untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang bisa anda praktekkan salah satunya sambel godog/sambel tumpang yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep sambel godog/sambel tumpang tanpa harus bersusah payah.
Berikut ini resep Sambel Godog/Sambel Tumpang yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambel Godog/Sambel Tumpang:

1. Siapkan 1 kotak sedang tempe semangit/busuk, di tempat saya yg 5 ribu dpt 3 kotak tempe
1. Siapkan 1/2 butir kelapa besar ambil santan cair dan santal kental nya
1. Harap siapkan 4 kotak sedang tahu putih, asal goreng saja, tdk usah kering2
1. Siapkan 2 terong potong2 sedang
1. Harap siapkan 1 cabe rawit buang isinya/sesuai selera cabe apa aja
1. Harus ada 4 Bawang merah besar/sesuai selera
1. Tambah 2 Bawang putih besar/sesuai selera
1. Tambah 2 cm kencur/sesuai selera
1. Tambah 2 batang serai/sesuai selera
1. Harus ada 3 lembar daun salam/sesuai selera
1. Jangan lupa 5 cm lengkuas/sesuai selera
1. Diperlukan 4 lembar daun jeruk/sesuai selera
1. Tambah Secukupnya Gula merah/saya tdk pake
1. Siapkan Secukupnya Gula pasir
1. Diperlukan Secukupnya garam
1. Dibutuhkan  Penyedap klo suka/klo tdk suka bisa d ganti kaldu bubuk alami
1. Jangan lupa  Daun singkong rebus untuk pelengkap/sesuai selera aja.




<!--inarticleads2-->

##### Instruksi membuat  Sambel Godog/Sambel Tumpang:

1. Rebus bawang merah, bawang putih, kencur, cabe, tempe busuk, daun salam, serai, daun jeruk, lengkuas di wajan agk besar, air ny kira2 saja,, sampe bau harum, dn air d sisain 1 mangkok kecil lah kira2, jgn d habisin air rebusan nya yah,, itu yg bkin enk.. Klo pndpt kami.. #senyum
1. Serai, lengkuas, daun salam, daun jeruk yg d rebus tdi jgn d buang yah,, msih d masak lgi.. Hee
1. Ulek bawang putih, bawang merah, kencur, cabe, smpe halus, kemudian ulek kasar tempe ny..trus masukkn ke dalam wajan ny yg tdi yg buat rebus bumbu ny.. Masukkan tahu, santan cair, ksih gula merah, gula pasir, garam
1. Tutup wajan, tunggu smpe mendidih dan baunya sdh harum, tes rasa,, masukkan terong dan santan kental, aduk2,, jgn smpe pecah santan ny.. Tunggu 15 mnit/smpe terong matang.. Matikan kompor,, Siap di hidangkan dengan kulupan daun singkong...




Demikianlah cara membuat sambel godog/sambel tumpang yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
