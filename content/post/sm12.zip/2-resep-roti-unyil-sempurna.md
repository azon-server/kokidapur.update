---
description: "Resep : Roti Unyil Sempurna"
title: "Resep : Roti Unyil Sempurna"
slug: 2-resep-roti-unyil-sempurna
date: 2020-11-26T06:11:43.730Z
image: https://img-global.cpcdn.com/recipes/179010ba9884dc48/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/179010ba9884dc48/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/179010ba9884dc48/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Bobby Beck
ratingvalue: 5
reviewcount: 48527
recipeingredient:
- "150 gr terigu"
- "1/2 bungkus fermipan 5gr"
- "50 gr gula halus"
- "1 butir telur"
- "50 ml susu cair"
- "30 gr margarin"
- " Isian  pisangselai coklatsesuai selera"
- " Olesan "
- " Susu cair"
- " Margarin"
recipeinstructions:
- "Siapkan wadah/baskom.Campur terigu+fermipan+gula halus+telur,lalu tuang susu cair aduk rata.Tambahkan margarin dan uleni hingga kalis."
- "Diamkan adonan selama 1 jam.Tutup wadah dg menggunakan serbet.Setelah adonan mengembang,bentuk menjadi bulatan2 kecil (me:@20gr) lalu gilas,beri isian dan tutup kembali atau bentuk sesuai selera."
- "Taruh bulatan diatas loyang yg sudah dioles margarin,diamkan lg selama 30 menit.Lalu oles atasnya dg susu cair.Panaskan oven dg suhu 180°C selama kurleb 5 menit.Lalu oven roti selama 20 menit(gunakan panas atas bawah). Setelah matang,segera keluarkan dari oven dan langsung oles dg margarin supaya terlihat glowing😍"
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 198 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Dinner

---


![Roti Unyil](https://img-global.cpcdn.com/recipes/179010ba9884dc48/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti roti unyil yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan ciri khas yang merupakan keragaman Nusantara

Kehangatan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah memasak Roti Unyil untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang dapat anda contoh salah satunya roti unyil yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep roti unyil tanpa harus bersusah payah.
Berikut ini resep Roti Unyil yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 10 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Unyil:

1. Siapkan 150 gr terigu
1. Dibutuhkan 1/2 bungkus fermipan (5gr)
1. Tambah 50 gr gula halus
1. Harap siapkan 1 butir telur
1. Diperlukan 50 ml susu cair
1. Jangan lupa 30 gr margarin
1. Tambah  Isian : pisang,selai coklat/sesuai selera
1. Harus ada  Olesan :
1. Siapkan  Susu cair
1. Harap siapkan  Margarin




<!--inarticleads2-->

##### Instruksi membuat  Roti Unyil:

1. Siapkan wadah/baskom.Campur terigu+fermipan+gula halus+telur,lalu tuang susu cair aduk rata.Tambahkan margarin dan uleni hingga kalis.
1. Diamkan adonan selama 1 jam.Tutup wadah dg menggunakan serbet.Setelah adonan mengembang,bentuk menjadi bulatan2 kecil (me:@20gr) lalu gilas,beri isian dan tutup kembali atau bentuk sesuai selera.
1. Taruh bulatan diatas loyang yg sudah dioles margarin,diamkan lg selama 30 menit.Lalu oles atasnya dg susu cair.Panaskan oven dg suhu 180°C selama kurleb 5 menit.Lalu oven roti selama 20 menit(gunakan panas atas bawah). Setelah matang,segera keluarkan dari oven dan langsung oles dg margarin supaya terlihat glowing😍




Demikianlah cara membuat roti unyil yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan teruji, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
