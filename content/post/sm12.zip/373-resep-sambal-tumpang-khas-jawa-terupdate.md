---
description: "Resep : Sambal Tumpang Khas Jawa terupdate"
title: "Resep : Sambal Tumpang Khas Jawa terupdate"
slug: 373-resep-sambal-tumpang-khas-jawa-terupdate
date: 2021-02-20T08:36:39.050Z
image: https://img-global.cpcdn.com/recipes/ee638f30f94b953d/680x482cq70/sambal-tumpang-khas-jawa-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ee638f30f94b953d/680x482cq70/sambal-tumpang-khas-jawa-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ee638f30f94b953d/680x482cq70/sambal-tumpang-khas-jawa-foto-resep-utama.jpg
author: Susan Houston
ratingvalue: 4.3
reviewcount: 33730
recipeingredient:
- "200 gr tempe kukus"
- "4 ptg tahu"
- "300 ml santan"
- "7 bh cabe merah keriting rebus dahulu"
- "10 bh cabe rawit rebus dahulu"
- "5 bh bawang merah"
- "3 bh bawang putih"
- "2 cm kencur"
- "1 ruas laos geprek"
- "3 lbr daun salam"
- "3 lbr daun jeruk"
- "1 sdm gula merah"
- "1 sdt garam"
recipeinstructions:
- "Hancurkan tempe kukus dengan garpu tidak usah sampai halus."
- "Uleg kasar cabe merah, cabe rawit, bawang merah, bawang putih, kencur."
- "Panaskan wajan dengan sedikit minyak, tumis bumbu uleg bersama laos, daun salam, daun jeruk hingga harum. Tambahkan santan. Biarkan hingga mendidih"
- "Tambahkan tempe dan tahu kedalam kuah. Tambahkan garam dan gula merah. Biarkan mendidih kembali dan bumbu meresap."
categories:
- Recipe
tags:
- sambal
- tumpang
- khas

katakunci: sambal tumpang khas 
nutrition: 249 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dessert

---


![Sambal Tumpang Khas Jawa](https://img-global.cpcdn.com/recipes/ee638f30f94b953d/680x482cq70/sambal-tumpang-khas-jawa-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau renyah. Ciri kuliner Nusantara sambal tumpang khas jawa yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan rumah tangga bisa didapat dengan cara sederhana. Diantaranya adalah memasak Sambal Tumpang Khas Jawa untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang bisa anda contoh salah satunya sambal tumpang khas jawa yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep sambal tumpang khas jawa tanpa harus bersusah payah.
Berikut ini resep Sambal Tumpang Khas Jawa yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambal Tumpang Khas Jawa:

1. Jangan lupa 200 gr tempe kukus
1. Harus ada 4 ptg tahu
1. Jangan lupa 300 ml santan
1. Siapkan 7 bh cabe merah keriting, rebus dahulu
1. Dibutuhkan 10 bh cabe rawit, rebus dahulu
1. Siapkan 5 bh bawang merah
1. Jangan lupa 3 bh bawang putih
1. Harus ada 2 cm kencur
1. Jangan lupa 1 ruas laos, geprek
1. Diperlukan 3 lbr daun salam
1. Harus ada 3 lbr daun jeruk
1. Harus ada 1 sdm gula merah
1. Siapkan 1 sdt garam




<!--inarticleads2-->

##### Langkah membuat  Sambal Tumpang Khas Jawa:

1. Hancurkan tempe kukus dengan garpu tidak usah sampai halus.
1. Uleg kasar cabe merah, cabe rawit, bawang merah, bawang putih, kencur.
1. Panaskan wajan dengan sedikit minyak, tumis bumbu uleg bersama laos, daun salam, daun jeruk hingga harum. Tambahkan santan. Biarkan hingga mendidih
1. Tambahkan tempe dan tahu kedalam kuah. Tambahkan garam dan gula merah. Biarkan mendidih kembali dan bumbu meresap.




Demikianlah cara membuat sambal tumpang khas jawa yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan teruji, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
