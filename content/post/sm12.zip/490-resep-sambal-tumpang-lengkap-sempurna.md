---
description: "Resep : Sambal Tumpang Lengkap Sempurna"
title: "Resep : Sambal Tumpang Lengkap Sempurna"
slug: 490-resep-sambal-tumpang-lengkap-sempurna
date: 2021-01-20T15:56:49.610Z
image: https://img-global.cpcdn.com/recipes/b542d6adcb7aaa49/680x482cq70/sambal-tumpang-lengkap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b542d6adcb7aaa49/680x482cq70/sambal-tumpang-lengkap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b542d6adcb7aaa49/680x482cq70/sambal-tumpang-lengkap-foto-resep-utama.jpg
author: Cole Sutton
ratingvalue: 4
reviewcount: 45743
recipeingredient:
- "10 gram1 kemasan kecil tempe busuk"
- "400 gram tempe segar"
- "350 ml air kaldu"
- "1 bungkus santan kara"
- "3 cm lengkuas geprek"
- "3 lembar daun salam"
- "3 daun jeruk"
- "1 papan petai jangan di skip ya"
- "1 sdm gula nira sisir"
- "secukupnya garam"
- "secukupnya air untuk merebus"
- " bumbu halus"
- "7 siung bawang merah"
- "5 siung bawang putih"
- "8 cabe merah keriting"
- "3 cabe rawit merah"
- "1 butir kemiri"
- "1 cm kencur"
- " pelengkap"
- "10 buah tahu pong tahu goreng tanpa isi"
- "segenggam krecek"
- "secukupnya bawang goreng"
recipeinstructions:
- "Potong-potong tempe segar. rebus tempe segar sampai empuk. setelah empuk, tiriskan kemudian uleg tempe segar bersama tempe busuk. jangan terlalu halus ya numbuknya biar teksturnya ga kayak bubur. sisihkan"
- "Uleg bawang merah, bawang putih, kemiri, kencur, cabe rawit dan cabe merah. geprek lengkuas. sisihkan"
- "Panaskan air kaldu [saya biasanya membuat kaldu dengan daging ayam, tapi pada umumnya orang2 sini membuat kaldu dengan tetelan]. masukkan ulegan tempe dan bumbu halus. tambahkan santan kara, daun salam, daun jeruk, tahu, dan krecek."
- "Setelah santan matang dan kreceknya lunak, tambahkan garam dan gula. cek rasa. kalau sudah pas, baru tambahkan petai. masak sebentar. matikan. taburi bawang goreng. [petai dimasukkan terakhir agar teksturnya masih kriyuk tapi tetap dapat memberikan aroma yang khas untuk sambal tumpang]."
- "Sajikan bersama rebusan sayur bayam, taoge, dan kacang panjang. kucuri sambal pecel, trus dimakannya pakai karak. mak nyus!"
categories:
- Recipe
tags:
- sambal
- tumpang
- lengkap

katakunci: sambal tumpang lengkap 
nutrition: 166 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Lunch

---


![Sambal Tumpang Lengkap](https://img-global.cpcdn.com/recipes/b542d6adcb7aaa49/680x482cq70/sambal-tumpang-lengkap-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti sambal tumpang lengkap yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Kita



Kehangatan keluarga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Sambal Tumpang Lengkap untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang dapat anda praktekkan salah satunya sambal tumpang lengkap yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep sambal tumpang lengkap tanpa harus bersusah payah.
Berikut ini resep Sambal Tumpang Lengkap yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 22 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambal Tumpang Lengkap:

1. Jangan lupa 10 gram/1 kemasan kecil tempe busuk
1. Siapkan 400 gram tempe segar
1. Siapkan 350 ml air kaldu
1. Harus ada 1 bungkus santan kara
1. Dibutuhkan 3 cm lengkuas geprek
1. Harap siapkan 3 lembar daun salam
1. Jangan lupa 3 daun jeruk
1. Dibutuhkan 1 papan petai (jangan di skip ya)
1. Tambah 1 sdm gula nira sisir
1. Siapkan secukupnya garam
1. Siapkan secukupnya air untuk merebus
1. Harus ada  bumbu halus:
1. Dibutuhkan 7 siung bawang merah
1. Jangan lupa 5 siung bawang putih
1. Harus ada 8 cabe merah keriting
1. Harap siapkan 3 cabe rawit merah
1. Harap siapkan 1 butir kemiri
1. Jangan lupa 1 cm kencur
1. Tambah  pelengkap:
1. Harus ada 10 buah tahu pong (tahu goreng tanpa isi)
1. Jangan lupa segenggam krecek
1. Siapkan secukupnya bawang goreng




<!--inarticleads2-->

##### Langkah membuat  Sambal Tumpang Lengkap:

1. Potong-potong tempe segar. rebus tempe segar sampai empuk. setelah empuk, tiriskan kemudian uleg tempe segar bersama tempe busuk. jangan terlalu halus ya numbuknya biar teksturnya ga kayak bubur. sisihkan
1. Uleg bawang merah, bawang putih, kemiri, kencur, cabe rawit dan cabe merah. geprek lengkuas. sisihkan
1. Panaskan air kaldu [saya biasanya membuat kaldu dengan daging ayam, tapi pada umumnya orang2 sini membuat kaldu dengan tetelan]. masukkan ulegan tempe dan bumbu halus. tambahkan santan kara, daun salam, daun jeruk, tahu, dan krecek.
1. Setelah santan matang dan kreceknya lunak, tambahkan garam dan gula. cek rasa. kalau sudah pas, baru tambahkan petai. masak sebentar. matikan. taburi bawang goreng. [petai dimasukkan terakhir agar teksturnya masih kriyuk tapi tetap dapat memberikan aroma yang khas untuk sambal tumpang].
1. Sajikan bersama rebusan sayur bayam, taoge, dan kacang panjang. kucuri sambal pecel, trus dimakannya pakai karak. mak nyus!




Demikianlah cara membuat sambal tumpang lengkap yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan cepat, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
