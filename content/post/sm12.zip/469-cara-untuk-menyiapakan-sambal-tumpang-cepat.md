---
description: "Cara untuk menyiapakan Sambal Tumpang Cepat"
title: "Cara untuk menyiapakan Sambal Tumpang Cepat"
slug: 469-cara-untuk-menyiapakan-sambal-tumpang-cepat
date: 2021-01-22T20:05:40.154Z
image: https://img-global.cpcdn.com/recipes/3b76a23980db0a1c/680x482cq70/sambal-tumpang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3b76a23980db0a1c/680x482cq70/sambal-tumpang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3b76a23980db0a1c/680x482cq70/sambal-tumpang-foto-resep-utama.jpg
author: Matthew Barber
ratingvalue: 4.7
reviewcount: 7336
recipeingredient:
- "200 gr tempe semangit"
- "10 buah tahu kulit potong 2 bagian optional"
- "100 ml santan instan"
- "2 lembar daun salam"
- "4 lembar daun jeruk"
- "1 ruas lengkuas geprek"
- "Secukupnya air untuk merebus bahan"
- " Bumbu halus "
- "3 buah cabe merah besar"
- "10 buah cabe rawit merah"
- "3 siung bawang putih"
- "8 butir bawang merah"
- "1 ruas kencur"
recipeinstructions:
- "Siapkan bahan dan bumbu. Rebus tempe semangit sebentar, setelahnya tiriskan. Buang air rebusannya."
- "Didihkan lagi air sebanyak 400 ml, rebus bahan/bumbu yang akan dihaluskan. Masukkan juga tempe semangitnya. Rebus sampai bumbu layu. Ambil bumbu &amp; tempe, sisihkan air rebusannya."
- "Tiriskan bumbu dan tempe semangit. Haluskan lebih dahulu bumbu kecuali lengkuas, daun salam dan daun jeruk. Lanjut haluskan tempe secukupnya."
- "Tumis bumbu halus dengan sedikit minyak sampai harum dan matang."
- "Masukkan bumbu halus ke dalam sisa air rebusan. Masak kembali sampai mendidih kemudian tambahkan bumbu lain dan tempe yang sudah dihaluskan. Masukkan juga tahu kulit dan santan. Kecilkan api."
- "Bumbui dengan gula merah, garam dan kaldu bubuk. Didihkan sekali lagi dan sambal tumpang siap disajikan bersama rebusan aneka sayur..😍"
categories:
- Recipe
tags:
- sambal
- tumpang

katakunci: sambal tumpang 
nutrition: 276 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT41M"
recipeyield: "2"
recipecategory: Dinner

---


![Sambal Tumpang](https://img-global.cpcdn.com/recipes/3b76a23980db0a1c/680x482cq70/sambal-tumpang-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga gurih. Ciri khas masakan Indonesia sambal tumpang yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah memasak Sambal Tumpang untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang bisa anda coba salah satunya sambal tumpang yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep sambal tumpang tanpa harus bersusah payah.
Berikut ini resep Sambal Tumpang yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 13 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambal Tumpang:

1. Tambah 200 gr tempe semangit
1. Tambah 10 buah tahu kulit, potong 2 bagian (optional)
1. Harap siapkan 100 ml santan instan
1. Harus ada 2 lembar daun salam
1. Harap siapkan 4 lembar daun jeruk
1. Harap siapkan 1 ruas lengkuas, geprek
1. Harap siapkan Secukupnya air untuk merebus bahan
1. Harap siapkan  Bumbu halus :
1. Harap siapkan 3 buah cabe merah besar
1. Jangan lupa 10 buah cabe rawit merah
1. Dibutuhkan 3 siung bawang putih
1. Harus ada 8 butir bawang merah
1. Harap siapkan 1 ruas kencur




<!--inarticleads2-->

##### Instruksi membuat  Sambal Tumpang:

1. Siapkan bahan dan bumbu. Rebus tempe semangit sebentar, setelahnya tiriskan. Buang air rebusannya.
1. Didihkan lagi air sebanyak 400 ml, rebus bahan/bumbu yang akan dihaluskan. Masukkan juga tempe semangitnya. Rebus sampai bumbu layu. Ambil bumbu &amp; tempe, sisihkan air rebusannya.
1. Tiriskan bumbu dan tempe semangit. Haluskan lebih dahulu bumbu kecuali lengkuas, daun salam dan daun jeruk. Lanjut haluskan tempe secukupnya.
1. Tumis bumbu halus dengan sedikit minyak sampai harum dan matang.
1. Masukkan bumbu halus ke dalam sisa air rebusan. Masak kembali sampai mendidih kemudian tambahkan bumbu lain dan tempe yang sudah dihaluskan. Masukkan juga tahu kulit dan santan. Kecilkan api.
1. Bumbui dengan gula merah, garam dan kaldu bubuk. Didihkan sekali lagi dan sambal tumpang siap disajikan bersama rebusan aneka sayur..😍




Demikianlah cara membuat sambal tumpang yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan teruji, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
