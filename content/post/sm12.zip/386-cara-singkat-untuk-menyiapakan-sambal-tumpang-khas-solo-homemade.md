---
description: "Cara singkat untuk menyiapakan Sambal Tumpang Khas Solo Homemade"
title: "Cara singkat untuk menyiapakan Sambal Tumpang Khas Solo Homemade"
slug: 386-cara-singkat-untuk-menyiapakan-sambal-tumpang-khas-solo-homemade
date: 2020-12-15T19:28:10.606Z
image: https://img-global.cpcdn.com/recipes/dd31889b592f38aa/680x482cq70/sambal-tumpang-khas-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dd31889b592f38aa/680x482cq70/sambal-tumpang-khas-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dd31889b592f38aa/680x482cq70/sambal-tumpang-khas-solo-foto-resep-utama.jpg
author: Vera Chavez
ratingvalue: 4
reviewcount: 6912
recipeingredient:
- "1 papan tempe waras"
- "4 bungkus tempe bosok"
- "1 lonjor pete potongpotong"
- "2 buah tahu potong dadu goreng"
- "500 ml santan encer"
- "750 ml air"
- "10 butir telur puyuh"
- " Bumbu"
- "7 siung bawang merah"
- "5 siung bawang putih"
- "12 buah cabe merah"
- "1 ruas kencur"
- "1 ruas lengkuas"
- "1 batang serai"
- "3 lembar daun salam"
- "7 lembar daun jeruk"
- " Bumbu Lain"
- "Secukupnya garam"
- "Secukupnya gula pasir"
- "Secukupnya penyedap rasa"
- " Sayuran"
- "Secukupnya tauge"
- "Secukupnya kacang panjang"
- "Secukupnya bayam"
recipeinstructions:
- "Siapkan semua bahan"
- "Rebus dalam panci: 750 ml air, tempe waras, tempe bosok, dan &#39;bumbu&#39; hingga tempe lembek/hancur, matikan api."
- "Ambil cabe merah, bawang merah, bawang merah, bawang putih, dan kencur, lalu uleg hingga lembut. Masukkan kembali ke dalam panci"
- "Ambil tempe waras dan tempe bosok, uleg, lalu masukkan kembali ke dalam panci"
- "Panaskan panci kembali, masukkan tahu, pete, telur puyuh rambak krecek"
- "Masukkan santan sambil terus diaduk, tambahkan bumbu lain, cicipi dan koreksi rasa. Didihkan."
- "Dalam wadah berbeda, siram atau rendam sebentar sayuran yang sudah disiapkan dengan air panas hingga agak layu"
- "Sajikan sambal tumpang beserta dengan sayurannya. Enak dimakan sama karak nasi."
categories:
- Recipe
tags:
- sambal
- tumpang
- khas

katakunci: sambal tumpang khas 
nutrition: 214 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT50M"
recipeyield: "1"
recipecategory: Lunch

---


![Sambal Tumpang Khas Solo](https://img-global.cpcdn.com/recipes/dd31889b592f38aa/680x482cq70/sambal-tumpang-khas-solo-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau gurih. Ciri khas kuliner Indonesia sambal tumpang khas solo yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Sambal Tumpang Khas Solo untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi resep yang bisa anda praktekkan salah satunya sambal tumpang khas solo yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep sambal tumpang khas solo tanpa harus bersusah payah.
Seperti resep Sambal Tumpang Khas Solo yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 24 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambal Tumpang Khas Solo:

1. Harap siapkan 1 papan tempe waras
1. Dibutuhkan 4 bungkus tempe bosok
1. Harap siapkan 1 lonjor pete, potong-potong
1. Siapkan 2 buah tahu, potong dadu, goreng
1. Harap siapkan 500 ml santan encer
1. Diperlukan 750 ml air
1. Harap siapkan 10 butir telur puyuh
1. Harap siapkan  Bumbu
1. Tambah 7 siung bawang merah
1. Dibutuhkan 5 siung bawang putih
1. Diperlukan 12 buah cabe merah
1. Diperlukan 1 ruas kencur
1. Tambah 1 ruas lengkuas
1. Jangan lupa 1 batang serai
1. Tambah 3 lembar daun salam
1. Siapkan 7 lembar daun jeruk
1. Jangan lupa  Bumbu Lain
1. Jangan lupa Secukupnya garam
1. Jangan lupa Secukupnya gula pasir
1. Tambah Secukupnya penyedap rasa
1. Dibutuhkan  Sayuran
1. Dibutuhkan Secukupnya tauge
1. Dibutuhkan Secukupnya kacang panjang
1. Dibutuhkan Secukupnya bayam




<!--inarticleads2-->

##### Cara membuat  Sambal Tumpang Khas Solo:

1. Siapkan semua bahan
1. Rebus dalam panci: 750 ml air, tempe waras, tempe bosok, dan &#39;bumbu&#39; hingga tempe lembek/hancur, matikan api.
1. Ambil cabe merah, bawang merah, bawang merah, bawang putih, dan kencur, lalu uleg hingga lembut. Masukkan kembali ke dalam panci
1. Ambil tempe waras dan tempe bosok, uleg, lalu masukkan kembali ke dalam panci
1. Panaskan panci kembali, masukkan tahu, pete, telur puyuh rambak krecek
1. Masukkan santan sambil terus diaduk, tambahkan bumbu lain, cicipi dan koreksi rasa. Didihkan.
1. Dalam wadah berbeda, siram atau rendam sebentar sayuran yang sudah disiapkan dengan air panas hingga agak layu
1. Sajikan sambal tumpang beserta dengan sayurannya. Enak dimakan sama karak nasi.




Demikianlah cara membuat sambal tumpang khas solo yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
