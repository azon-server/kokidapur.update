---
description: "Langkah menyiapakan Roti Unyil Kolache Luar biasa"
title: "Langkah menyiapakan Roti Unyil Kolache Luar biasa"
slug: 97-langkah-menyiapakan-roti-unyil-kolache-luar-biasa
date: 2020-09-22T23:32:29.312Z
image: https://img-global.cpcdn.com/recipes/2ad8df4fa30f70f4/680x482cq70/roti-unyil-kolache-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2ad8df4fa30f70f4/680x482cq70/roti-unyil-kolache-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2ad8df4fa30f70f4/680x482cq70/roti-unyil-kolache-foto-resep-utama.jpg
author: Lucile Tran
ratingvalue: 4.3
reviewcount: 43350
recipeingredient:
- "350-400 gr terigu protein tinggi"
- "200 ml susu cair"
- "70 gr gula pasir"
- "50 gram mentega"
- "2 butir merah telur"
- "1 sdt ragi instant"
- "1/2 sdt garam halus"
- " Isian "
- "Secukupnya Vla u Pie"
- "Secukupnya mayonaise"
- " Topping bisa diganti bahan lain"
- "Secukupnya Jagung rebus"
- "Secukupnya Irisan Sosis"
- "Secukupnya Manisan ceri"
- "Secukupnya buah Berry"
- "Secukupnya Brokoli rebus"
- "Secukupnya Meses"
- " Olesan"
- "1 kuning telurresep asli mengoles dengan putih telur"
recipeinstructions:
- "Campur rata terigu, gula dan garam."
- "Masukkan dalam gelas: 1 sdm gula ambil dari total gula, ragi instant dan 75 ml susu hangat kuku yg diambil dr total keperluan susu. Aduk rata dan diamkan 10 menit atau sampai berbuih."
- "Campur dan aduk rata, campuran tepung terigu, larutan ragi, sisa susu, merah telur dan mentega. Hasil adonan adalah lengket. Bersihkan tangan, lalu bedaki dengan tepung terigu. Uleni dan banting-banting adonan sampai kalis elastis sambil tetap membedaki tangan."
- "Istirahatkan adonan sampai mengembang 2x lipat. Kempiskan dan ulen lagi adonan sebentar"
- "Potong-potong adonan masing-masing 10-15 gram. Lalu bentuk bulat-bulat. (Untuk menghindari over proofing, sy menggunakan sebagian adonan roti dulu, sebagian lagi sy bungkus dalam plastik dan disimpan di dalam kulkas. Dikeluarkan saat adonan yang pertama sudah habis)"
- "Gepengkan adonan membentuk lingkaran, lalu letakkan diatas loyang yang dialaai kertas baking dan margarin. Biarkan adoan sampai mengembang 2x lipat."
- "Setelah adonan mengembang 2x lipat, tekan-tekan bagian tengan adonan dengan jari atau alat yg sesuai sampai berbentuk mangkuk."
- "Beri isian vla dan tambahkan topingnya."
- "Oven dengan api sedang selama 20 menit. Lalu keluarkan dan oles permukaan rotinya dengan kuning/putih telur. Oven lagi selama 5 menit sampai permukaan roti keemasan. Keluarkan dari oven."
categories:
- Recipe
tags:
- roti
- unyil
- kolache

katakunci: roti unyil kolache 
nutrition: 141 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT58M"
recipeyield: "1"
recipecategory: Dessert

---


![Roti Unyil Kolache](https://img-global.cpcdn.com/recipes/2ad8df4fa30f70f4/680x482cq70/roti-unyil-kolache-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang harus kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti roti unyil kolache yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Kita



Kehangatan rumah tangga bisa didapat dengan cara sederhana. Diantaranya adalah memasak Roti Unyil Kolache untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang dapat anda coba salah satunya roti unyil kolache yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep roti unyil kolache tanpa harus bersusah payah.
Seperti resep Roti Unyil Kolache yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Unyil Kolache:

1. Harus ada 350-400 gr terigu protein tinggi
1. Diperlukan 200 ml susu cair
1. Jangan lupa 70 gr gula pasir
1. Tambah 50 gram mentega
1. Siapkan 2 butir merah telur
1. Tambah 1 sdt ragi instant
1. Harus ada 1/2 sdt garam halus
1. Siapkan  Isian :
1. Harus ada Secukupnya Vla u/ Pie
1. Harus ada Secukupnya mayonaise
1. Harap siapkan  Topping (bisa diganti bahan lain)
1. Diperlukan Secukupnya Jagung rebus
1. Diperlukan Secukupnya Irisan Sosis
1. Harus ada Secukupnya Manisan ceri
1. Harap siapkan Secukupnya buah Berry
1. Siapkan Secukupnya Brokoli rebus
1. Harap siapkan Secukupnya Meses
1. Harap siapkan  Olesan:
1. Jangan lupa 1 kuning telur/resep asli mengoles dengan putih telur




<!--inarticleads2-->

##### Cara membuat  Roti Unyil Kolache:

1. Campur rata terigu, gula dan garam.
1. Masukkan dalam gelas: 1 sdm gula ambil dari total gula, ragi instant dan 75 ml susu hangat kuku yg diambil dr total keperluan susu. Aduk rata dan diamkan 10 menit atau sampai berbuih.
1. Campur dan aduk rata, campuran tepung terigu, larutan ragi, sisa susu, merah telur dan mentega. Hasil adonan adalah lengket. Bersihkan tangan, lalu bedaki dengan tepung terigu. Uleni dan banting-banting adonan sampai kalis elastis sambil tetap membedaki tangan.
1. Istirahatkan adonan sampai mengembang 2x lipat. Kempiskan dan ulen lagi adonan sebentar
1. Potong-potong adonan masing-masing 10-15 gram. Lalu bentuk bulat-bulat. (Untuk menghindari over proofing, sy menggunakan sebagian adonan roti dulu, sebagian lagi sy bungkus dalam plastik dan disimpan di dalam kulkas. Dikeluarkan saat adonan yang pertama sudah habis)
1. Gepengkan adonan membentuk lingkaran, lalu letakkan diatas loyang yang dialaai kertas baking dan margarin. Biarkan adoan sampai mengembang 2x lipat.
1. Setelah adonan mengembang 2x lipat, tekan-tekan bagian tengan adonan dengan jari atau alat yg sesuai sampai berbentuk mangkuk.
1. Beri isian vla dan tambahkan topingnya.
1. Oven dengan api sedang selama 20 menit. Lalu keluarkan dan oles permukaan rotinya dengan kuning/putih telur. Oven lagi selama 5 menit sampai permukaan roti keemasan. Keluarkan dari oven.




Demikianlah cara membuat roti unyil kolache yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan teruji, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
