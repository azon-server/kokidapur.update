---
description: "Langkah untuk menyiapakan Sambel Tumpang khas kota Salatiga Homemade"
title: "Langkah untuk menyiapakan Sambel Tumpang khas kota Salatiga Homemade"
slug: 379-langkah-untuk-menyiapakan-sambel-tumpang-khas-kota-salatiga-homemade
date: 2021-01-31T05:23:22.948Z
image: https://img-global.cpcdn.com/recipes/6a60604553c68a39/680x482cq70/sambel-tumpang-khas-kota-salatiga-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6a60604553c68a39/680x482cq70/sambel-tumpang-khas-kota-salatiga-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6a60604553c68a39/680x482cq70/sambel-tumpang-khas-kota-salatiga-foto-resep-utama.jpg
author: Nell Gill
ratingvalue: 5
reviewcount: 49413
recipeingredient:
- "1 kg tetelan tumpangan"
- "10 buah tahu kulit"
- " Bumbu rebus lalu uleg halus "
- "15 butir bawang merah"
- "8 butir bawang putih"
- "10 buah cabe keriting"
- "6 buah cabe rawit merah"
- "2 butir besar kencur"
- "1/2 buah kecil jeruk purut ambil kulitnya sj"
- "1 bngks besar tempe bosok aku pake yg masih semangit"
- " Bumbu dapur "
- "7 lmbr daun salam"
- "7 lmbr daun jeruk"
- "3 batang sereh"
- "2 potong besar lengkuas"
- "500 cc santan kental sedang"
- "1.500 cc air untuk merebus"
- "Secukupnya garam gula merah dan minyak untuk menumis"
recipeinstructions:
- "Bersihkan tetelan (untuk masakan ini biasanya pake bag. congor/bibir dan gurung/tenggorokan sapi). Potong2 dan rebus kurleb 20 mnt lalu buang air rebusannya"
- "Didihkan air, rebus kembali tetelan smp empuk. Masukkan tahu dan bumbu dapur"
- "Tumis bumbu halus dan tempe rebus yg sdh diuleg jg...masukkan dlm panci tadi. Tambahkan garam dan gula merah...aduk2, tutup panci dan masak dgn api sedang biarkan agak lama (proses memasak cukup lama agar bumbu meresap sempurna)"
- "Bila tetelan sdh empuk koreksi rasa dulu lalu tuangkan santan (krn pas belanja tukang parut kelapanya blm buka makanya aku pake santan instan 2 bngks sg3 itu 😁) aduk dan tunggu smp ndak berbau santan"
- "Angkat dan siap disantap dgn nasi hangat. Biasanya dilengkapi rebusan pepaya serut. Selamat mencoba 😊"
categories:
- Recipe
tags:
- sambel
- tumpang
- khas

katakunci: sambel tumpang khas 
nutrition: 136 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Dessert

---


![Sambel Tumpang khas kota Salatiga](https://img-global.cpcdn.com/recipes/6a60604553c68a39/680x482cq70/sambel-tumpang-khas-kota-salatiga-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang setidaknya kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti sambel tumpang khas kota salatiga yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Kita



Keharmonisan rumah tangga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Sambel Tumpang khas kota Salatiga untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang bisa anda praktekkan salah satunya sambel tumpang khas kota salatiga yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep sambel tumpang khas kota salatiga tanpa harus bersusah payah.
Seperti resep Sambel Tumpang khas kota Salatiga yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambel Tumpang khas kota Salatiga:

1. Harus ada 1 kg tetelan tumpangan
1. Diperlukan 10 buah tahu kulit
1. Dibutuhkan  Bumbu, rebus lalu uleg halus :
1. Siapkan 15 butir bawang merah
1. Tambah 8 butir bawang putih
1. Jangan lupa 10 buah cabe keriting
1. Jangan lupa 6 buah cabe rawit merah
1. Diperlukan 2 butir besar kencur
1. Harap siapkan 1/2 buah (kecil) jeruk purut, ambil kulitnya sj
1. Harus ada 1 bngks besar tempe bosok (aku pake yg masih semangit)
1. Siapkan  Bumbu dapur :
1. Jangan lupa 7 lmbr daun salam
1. Dibutuhkan 7 lmbr daun jeruk
1. Tambah 3 batang sereh
1. Dibutuhkan 2 potong besar lengkuas
1. Dibutuhkan 500 cc santan, kental sedang
1. Harus ada 1.500 cc air untuk merebus
1. Jangan lupa Secukupnya garam, gula merah dan minyak untuk menumis




<!--inarticleads2-->

##### Instruksi membuat  Sambel Tumpang khas kota Salatiga:

1. Bersihkan tetelan (untuk masakan ini biasanya pake bag. congor/bibir dan gurung/tenggorokan sapi). Potong2 dan rebus kurleb 20 mnt lalu buang air rebusannya
1. Didihkan air, rebus kembali tetelan smp empuk. Masukkan tahu dan bumbu dapur
1. Tumis bumbu halus dan tempe rebus yg sdh diuleg jg...masukkan dlm panci tadi. Tambahkan garam dan gula merah...aduk2, tutup panci dan masak dgn api sedang biarkan agak lama (proses memasak cukup lama agar bumbu meresap sempurna)
1. Bila tetelan sdh empuk koreksi rasa dulu lalu tuangkan santan (krn pas belanja tukang parut kelapanya blm buka makanya aku pake santan instan 2 bngks sg3 itu 😁) aduk dan tunggu smp ndak berbau santan
1. Angkat dan siap disantap dgn nasi hangat. Biasanya dilengkapi rebusan pepaya serut. Selamat mencoba 😊




Demikianlah cara membuat sambel tumpang khas kota salatiga yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan cepat, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
