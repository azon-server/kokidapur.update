---
description: "Resep : Sambel Pecel Lele ala Megie minggu ini"
title: "Resep : Sambel Pecel Lele ala Megie minggu ini"
slug: 260-resep-sambel-pecel-lele-ala-megie-minggu-ini
date: 2020-10-03T07:28:20.041Z
image: https://img-global.cpcdn.com/recipes/3428057b4df64f71/680x482cq70/sambel-pecel-lele-ala-megie-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3428057b4df64f71/680x482cq70/sambel-pecel-lele-ala-megie-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3428057b4df64f71/680x482cq70/sambel-pecel-lele-ala-megie-foto-resep-utama.jpg
author: Lottie Baldwin
ratingvalue: 4.7
reviewcount: 20691
recipeingredient:
- "20 buah cabai rawit setan ukuran besar tusuktusuk"
- "10 siung bawang merah kupas belah 2"
- "2-3 buah tomat potongpotong"
- "1/4 keping terasi bulat Ju Ek atau 12 keping terasi ABC bakar"
- "8-10 sdm minyak goreng"
- "secukupnya gula merah"
- "secukupnya garam dan penyedap"
- "80-100 ml air panas  mendidih"
recipeinstructions:
- "Panaskan minyak. Goreng cabai rawit setan dan bawang merah hingga matang (jangan sampai kering ya...), angkat, kemudian ulek hingga tingkat kehalusan yang diinginkan."
- "Sementara mengulek cabai, goreng tomat dan terasi bakar hingga tomat lunak. (Gunakan minyak bekas menggoreng cabai ya, supaya rasanya semakin sedap 😁)"
- "Masukkan tumisan tomat dan terasi (beserta minyaknya juga) pada ulekan cabai, tambahkan gula merah, garam dan penyedap. Ulek kembali. Tambahkan air panas. Aduk rata, kemudian koreksi rasa. Sambel siap disajikan."
categories:
- Recipe
tags:
- sambel
- pecel
- lele

katakunci: sambel pecel lele 
nutrition: 157 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Dinner

---


![Sambel Pecel Lele ala Megie](https://img-global.cpcdn.com/recipes/3428057b4df64f71/680x482cq70/sambel-pecel-lele-ala-megie-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau enak. Ciri khas kuliner Nusantara sambel pecel lele ala megie yang kaya dengan rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.




Keharmonisan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Sambel Pecel Lele ala Megie untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang dapat anda praktekkan salah satunya sambel pecel lele ala megie yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep sambel pecel lele ala megie tanpa harus bersusah payah.
Berikut ini resep Sambel Pecel Lele ala Megie yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambel Pecel Lele ala Megie:

1. Tambah 20 buah cabai rawit setan ukuran besar, tusuk-tusuk
1. Harus ada 10 siung bawang merah, kupas, belah 2
1. Tambah 2-3 buah tomat, potong-potong
1. Dibutuhkan 1/4 keping terasi bulat (Ju Ek) atau 1/2 keping terasi ABC, bakar
1. Tambah 8-10 sdm minyak goreng
1. Dibutuhkan secukupnya gula merah
1. Diperlukan secukupnya garam dan penyedap
1. Dibutuhkan 80-100 ml air panas / mendidih




<!--inarticleads2-->

##### Bagaimana membuat  Sambel Pecel Lele ala Megie:

1. Panaskan minyak. Goreng cabai rawit setan dan bawang merah hingga matang (jangan sampai kering ya...), angkat, kemudian ulek hingga tingkat kehalusan yang diinginkan.
1. Sementara mengulek cabai, goreng tomat dan terasi bakar hingga tomat lunak. (Gunakan minyak bekas menggoreng cabai ya, supaya rasanya semakin sedap 😁)
1. Masukkan tumisan tomat dan terasi (beserta minyaknya juga) pada ulekan cabai, tambahkan gula merah, garam dan penyedap. Ulek kembali. Tambahkan air panas. Aduk rata, kemudian koreksi rasa. Sambel siap disajikan.




Demikianlah cara membuat sambel pecel lele ala megie yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
