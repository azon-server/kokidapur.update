---
description: "Cara singkat untuk menyiapakan Sambel pecel lele khas medan Luar biasa"
title: "Cara singkat untuk menyiapakan Sambel pecel lele khas medan Luar biasa"
slug: 271-cara-singkat-untuk-menyiapakan-sambel-pecel-lele-khas-medan-luar-biasa
date: 2020-12-26T22:38:15.537Z
image: https://img-global.cpcdn.com/recipes/7047ccf8b3f5e655/680x482cq70/sambel-pecel-lele-khas-medan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7047ccf8b3f5e655/680x482cq70/sambel-pecel-lele-khas-medan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7047ccf8b3f5e655/680x482cq70/sambel-pecel-lele-khas-medan-foto-resep-utama.jpg
author: Lester Hall
ratingvalue: 4.3
reviewcount: 38338
recipeingredient:
- "100 gr cabe rawit"
- "10 buah cabe merah sy tdak pakai karna lupa beli hihi"
- "5 buah tomatbelah2 jadi empat"
- "25 buah bwang merah"
- "4 siung bwang putih"
- "3 butir kemiri"
- "secukupnya Terasi"
- "secukupnya Gula merah"
- "secukupnya Penyedap"
- " Garam bila perlu"
recipeinstructions:
- "Pertama2 goreng terasi secukupx,sisihkan"
- "Goreng kemiri,sisihkan"
- "Goreng bwang merah dan bwang putih,sisihkan"
- "Goreng cabe merah dan cabe rawit,sisihkan"
- "Terakhir goreng tomat dan beri setengah gelas air,,lalu tutup tomat agar cpet matang dan layu...buka tutupx dan aduk2 merata dan biarkan hnga airx surut(sat) angkat dan sisihkan"
- "Ulek jadi satu cabe rawit goreng,cabe merah goreng,bawang merah goreng, bwng putih goreng,kemiri goreng dan trasi goreng"
- "Karna cobek sy kecil, jd sy ngulekx di dalam mangkok kaca yg besar dan ulekanx pk gelas...yuk mulai ngulekx bun"
- "Jika sdah setengah kasar masukan tomat gorengx.. Ulek trus"
- "Ulek hnga halus seperti ini (tingkat kehalusanx tergantung selera ya bun, mau kasar atw halus gk pa pa yg penting rasax"
- "Beri gula merah dan penyedap, ulek2 manja hnga merata (tes rasa) jika kurang garam bru tmbhkn dikit,(hati2 memakai garam ya bun karna trasi sdah asin jd pakai garamx secukupx sj.. Ulek2 pelan.. Jika rasa sdah pas.. Siap di santap dgan nasi uduk,ikan lele goreng dan pelengkap lainx"
- "Eit exis lg buat poto sampul resepx hehe,biar nampak syantik..."
categories:
- Recipe
tags:
- sambel
- pecel
- lele

katakunci: sambel pecel lele 
nutrition: 171 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Lunch

---


![Sambel pecel lele khas medan](https://img-global.cpcdn.com/recipes/7047ccf8b3f5e655/680x482cq70/sambel-pecel-lele-khas-medan-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan enak. Ciri khas makanan Indonesia sambel pecel lele khas medan yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga bisa diperoleh dengan cara mudah. Diantaranya adalah memasak Sambel pecel lele khas medan untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda buat salah satunya sambel pecel lele khas medan yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep sambel pecel lele khas medan tanpa harus bersusah payah.
Berikut ini resep Sambel pecel lele khas medan yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 11 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambel pecel lele khas medan:

1. Harus ada 100 gr cabe rawit
1. Diperlukan 10 buah cabe merah (sy tdak pakai karna lupa beli hihi)
1. Diperlukan 5 buah tomat,belah2 jadi empat
1. Jangan lupa 25 buah bwang merah
1. Dibutuhkan 4 siung bwang putih
1. Jangan lupa 3 butir kemiri
1. Dibutuhkan secukupnya Terasi
1. Dibutuhkan secukupnya Gula merah
1. Dibutuhkan secukupnya Penyedap
1. Tambah  Garam bila perlu




<!--inarticleads2-->

##### Cara membuat  Sambel pecel lele khas medan:

1. Pertama2 goreng terasi secukupx,sisihkan
1. Goreng kemiri,sisihkan
1. Goreng bwang merah dan bwang putih,sisihkan
1. Goreng cabe merah dan cabe rawit,sisihkan
1. Terakhir goreng tomat dan beri setengah gelas air,,lalu tutup tomat agar cpet matang dan layu...buka tutupx dan aduk2 merata dan biarkan hnga airx surut(sat) angkat dan sisihkan
1. Ulek jadi satu cabe rawit goreng,cabe merah goreng,bawang merah goreng, bwng putih goreng,kemiri goreng dan trasi goreng
1. Karna cobek sy kecil, jd sy ngulekx di dalam mangkok kaca yg besar dan ulekanx pk gelas...yuk mulai ngulekx bun
1. Jika sdah setengah kasar masukan tomat gorengx.. Ulek trus
1. Ulek hnga halus seperti ini (tingkat kehalusanx tergantung selera ya bun, mau kasar atw halus gk pa pa yg penting rasax
1. Beri gula merah dan penyedap, ulek2 manja hnga merata (tes rasa) jika kurang garam bru tmbhkn dikit,(hati2 memakai garam ya bun karna trasi sdah asin jd pakai garamx secukupx sj.. Ulek2 pelan.. Jika rasa sdah pas.. Siap di santap dgan nasi uduk,ikan lele goreng dan pelengkap lainx
1. Eit exis lg buat poto sampul resepx hehe,biar nampak syantik...




Demikianlah cara membuat sambel pecel lele khas medan yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
