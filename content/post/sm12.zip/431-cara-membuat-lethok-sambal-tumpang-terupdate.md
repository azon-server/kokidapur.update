---
description: "Cara membuat Lethok (Sambal Tumpang) terupdate"
title: "Cara membuat Lethok (Sambal Tumpang) terupdate"
slug: 431-cara-membuat-lethok-sambal-tumpang-terupdate
date: 2020-10-01T13:01:43.550Z
image: https://img-global.cpcdn.com/recipes/343995aaceaa5de1/680x482cq70/lethok-sambal-tumpang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/343995aaceaa5de1/680x482cq70/lethok-sambal-tumpang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/343995aaceaa5de1/680x482cq70/lethok-sambal-tumpang-foto-resep-utama.jpg
author: Maurice Jensen
ratingvalue: 4.8
reviewcount: 45386
recipeingredient:
- "1 papan tempe potongpotong"
- "1/2 papan tempe semangit nyaris busuk"
- "300 ml santan"
- "3 buah tahu potong 2 goreng"
- "1 plastik krecek rendam air"
- " Bumbu halus"
- "6 butir bawang merah"
- "3 siung bawang putih"
- "1/2 cm kencur"
- "5 buah cabai merah keriting"
- "10 buah cabai rawit merah"
- " Bumbu lain"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 ruas lengkuas memarkan"
- "1 sdt garam"
- "1 sdt gula pasir"
recipeinstructions:
- "Potong-potong tempe biasa dan tempe semangit"
- "Rebus bumbu yang akan dihaluskan, tempe semangit, dan tempe biasa. Angkat, tumbuk/ulek kasar (air rebusan jangan dibuang)"
- "Masukkan lagi bahan yang sudah diulek ke dalam air rebusan, tambahkan daun jeruk, daun salam, dan lengkuas"
- "Tuang santan, aduk-aduk. Bubuhkan garam dan gula pasir. Didihkan. Masukkan krecek dan tahu. Masak sebentar. Koreksi rasa, angkat, sajikan           (lihat resep)"
categories:
- Recipe
tags:
- lethok
- sambal
- tumpang

katakunci: lethok sambal tumpang 
nutrition: 267 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Lunch

---


![Lethok (Sambal Tumpang)](https://img-global.cpcdn.com/recipes/343995aaceaa5de1/680x482cq70/lethok-sambal-tumpang-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau enak. Karasteristik masakan Indonesia lethok (sambal tumpang) yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Lethok (Sambal Tumpang) untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang bisa anda coba salah satunya lethok (sambal tumpang) yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep lethok (sambal tumpang) tanpa harus bersusah payah.
Seperti resep Lethok (Sambal Tumpang) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Lethok (Sambal Tumpang):

1. Harap siapkan 1 papan tempe, potong-potong
1. Jangan lupa 1/2 papan tempe semangit (nyaris busuk)
1. Harap siapkan 300 ml santan
1. Siapkan 3 buah tahu, potong 2, goreng
1. Harus ada 1 plastik krecek, rendam air
1. Tambah  Bumbu halus
1. Siapkan 6 butir bawang merah
1. Siapkan 3 siung bawang putih
1. Diperlukan 1/2 cm kencur
1. Harap siapkan 5 buah cabai merah keriting
1. Harap siapkan 10 buah cabai rawit merah
1. Siapkan  Bumbu lain
1. Tambah 2 lembar daun salam
1. Tambah 2 lembar daun jeruk
1. Diperlukan 1 ruas lengkuas, memarkan
1. Diperlukan 1 sdt garam
1. Harus ada 1 sdt gula pasir




<!--inarticleads2-->

##### Bagaimana membuat  Lethok (Sambal Tumpang):

1. Potong-potong tempe biasa dan tempe semangit
1. Rebus bumbu yang akan dihaluskan, tempe semangit, dan tempe biasa. Angkat, tumbuk/ulek kasar (air rebusan jangan dibuang)
1. Masukkan lagi bahan yang sudah diulek ke dalam air rebusan, tambahkan daun jeruk, daun salam, dan lengkuas
1. Tuang santan, aduk-aduk. Bubuhkan garam dan gula pasir. Didihkan. Masukkan krecek dan tahu. Masak sebentar. Koreksi rasa, angkat, sajikan -           (lihat resep)




Demikianlah cara membuat lethok (sambal tumpang) yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
