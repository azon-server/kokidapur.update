---
description: "Steps menyiapakan Sambel Tumpang Solo Teruji"
title: "Steps menyiapakan Sambel Tumpang Solo Teruji"
slug: 479-steps-menyiapakan-sambel-tumpang-solo-teruji
date: 2021-03-01T17:06:52.549Z
image: https://img-global.cpcdn.com/recipes/be7e6a95697986d0/680x482cq70/sambel-tumpang-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/be7e6a95697986d0/680x482cq70/sambel-tumpang-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/be7e6a95697986d0/680x482cq70/sambel-tumpang-solo-foto-resep-utama.jpg
author: Lina Howard
ratingvalue: 4
reviewcount: 19902
recipeingredient:
- " Bahan "
- "1 papan tempe saya bukan tempe semangit"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "2 kemiri sangrai"
- "1 ruas kencur"
- "1 cabe besar"
- "10 cabe rawit cemplungan saja"
- "5 telor rebus"
- "10 tahu goreng saya  tahu bakso"
- "1200 ml air"
- "1 santan instan saya  sasa"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 ruas lengkuas geprek"
- "Secukupnya gula merah"
- "Secukupnya garam"
- " Kaldu bubuk saya  tidak"
- "Secukupnya minyak untuk menumis"
recipeinstructions:
- "Siapkan semua bahan. Rebus semua bahan (kecuali santan instan, telor dan tahu) sampai empuk. Sisain tempe rebus kembali."
- "Angkat semua bahan kecuali daun salam, lengkuas dan tempe. Ulek kasar atau halus bawang merah,bawang putih,kemiri,kencur,cabe besar, setelah agak halus ulek kembali daun jeruk (yang sudah dibuang tulangnya). Sisihkan."
- "Angkat tempe kemudian Haluskan (saya : ulek kasar) sisihkan."
- "Tumis bumbu halus yang sudah diulek dengan sedikit minyak sampai wangi dan sedikit kering. Beri secukupnya air bekas rebusan tempe (saya : 3 sendok entong sayur) beri tempe yang sudah dihaluskan aduk kembali sampai mendidih dan meresap."
- "Tuang tumisan tempe yang sudah dibumbui tadi kedalam rebusan yang berisi daun salam dan lengkuas. Masukkan telor dan tahu. Tunggu sampai air menyusut. Kemudian masukkan santan instan. Aduk aduk."
- "Beri gula merah, garam dan kaldu bubuk jika suka (saya : tidak). Aduk aduk kembali sampai mendidih. Koreksi rasa. Tunggu sampai bumbu meresap ya mom. Matikan kompor."
- "Sajikan (saya dengan sayur pecel mom dan peyek kacang). Endolitaaaa serasa pulang kampung ke solo tempat mertua 😍😍😍"
categories:
- Recipe
tags:
- sambel
- tumpang
- solo

katakunci: sambel tumpang solo 
nutrition: 277 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Lunch

---


![Sambel Tumpang Solo](https://img-global.cpcdn.com/recipes/be7e6a95697986d0/680x482cq70/sambel-tumpang-solo-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang harus kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti sambel tumpang solo yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa ciri khas yang merupakan keragaman Kita

Kehangatan rumah tangga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Sambel Tumpang Solo untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang bisa anda coba salah satunya sambel tumpang solo yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep sambel tumpang solo tanpa harus bersusah payah.
Seperti resep Sambel Tumpang Solo yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambel Tumpang Solo:

1. Tambah  Bahan :
1. Jangan lupa 1 papan tempe (saya bukan tempe semangit)
1. Harap siapkan 6 siung bawang merah
1. Harap siapkan 3 siung bawang putih
1. Siapkan 2 kemiri sangrai
1. Siapkan 1 ruas kencur
1. Jangan lupa 1 cabe besar
1. Harap siapkan 10 cabe rawit (cemplungan saja)
1. Siapkan 5 telor rebus
1. Jangan lupa 10 tahu goreng (saya : tahu bakso)
1. Siapkan 1200 ml air
1. Harus ada 1 santan instan (saya : sasa)
1. Tambah 2 lembar daun salam
1. Harap siapkan 2 lembar daun jeruk
1. Tambah 1 ruas lengkuas (geprek)
1. Harus ada Secukupnya gula merah
1. Dibutuhkan Secukupnya garam
1. Tambah  Kaldu bubuk (saya : tidak)
1. Tambah Secukupnya minyak untuk menumis




<!--inarticleads2-->

##### Bagaimana membuat  Sambel Tumpang Solo:

1. Siapkan semua bahan. Rebus semua bahan (kecuali santan instan, telor dan tahu) sampai empuk. Sisain tempe rebus kembali.
1. Angkat semua bahan kecuali daun salam, lengkuas dan tempe. Ulek kasar atau halus bawang merah,bawang putih,kemiri,kencur,cabe besar, setelah agak halus ulek kembali daun jeruk (yang sudah dibuang tulangnya). Sisihkan.
1. Angkat tempe kemudian Haluskan (saya : ulek kasar) sisihkan.
1. Tumis bumbu halus yang sudah diulek dengan sedikit minyak sampai wangi dan sedikit kering. Beri secukupnya air bekas rebusan tempe (saya : 3 sendok entong sayur) beri tempe yang sudah dihaluskan aduk kembali sampai mendidih dan meresap.
1. Tuang tumisan tempe yang sudah dibumbui tadi kedalam rebusan yang berisi daun salam dan lengkuas. Masukkan telor dan tahu. Tunggu sampai air menyusut. Kemudian masukkan santan instan. Aduk aduk.
1. Beri gula merah, garam dan kaldu bubuk jika suka (saya : tidak). Aduk aduk kembali sampai mendidih. Koreksi rasa. Tunggu sampai bumbu meresap ya mom. Matikan kompor.
1. Sajikan (saya dengan sayur pecel mom dan peyek kacang). Endolitaaaa serasa pulang kampung ke solo tempat mertua 😍😍😍




Demikianlah cara membuat sambel tumpang solo yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan cepat, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
