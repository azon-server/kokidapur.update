---
description: "Resep : Ayam Kentucky Sambel Pecel Lele Cepat"
title: "Resep : Ayam Kentucky Sambel Pecel Lele Cepat"
slug: 182-resep-ayam-kentucky-sambel-pecel-lele-cepat
date: 2020-12-20T07:47:35.842Z
image: https://img-global.cpcdn.com/recipes/818e47cce4a22d01/680x482cq70/ayam-kentucky-sambel-pecel-lele-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/818e47cce4a22d01/680x482cq70/ayam-kentucky-sambel-pecel-lele-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/818e47cce4a22d01/680x482cq70/ayam-kentucky-sambel-pecel-lele-foto-resep-utama.jpg
author: Lenora Kim
ratingvalue: 4.4
reviewcount: 8552
recipeingredient:
- " Bahan utama "
- "1/2 kg ayam potong"
- "1 liter minyak goreng"
- " Bahan pelapis "
- "250 gram tepung terigu"
- "5 sdm maizena"
- "1 bungkus royco ayam"
- "1 butir telur ayam"
- "1 liter air putih"
- " Bumbu halus "
- "4 siung bawang putih"
- "1 sdt royco ayam"
- "1 sdt garam"
- "1 sdt merica bubuk"
recipeinstructions:
- "Cuci bersih ayam yang sudah di potong kemudian lumuri dengan bumbu yang sudah di haluskan hingga merata kemudian ungkep sebentar di wajan. Setelah di ungkep angkat lalu tiriskan."
- "Kemudian siapkan bahan pelapis, tuangkan telur yang sudah di kocok tuangkan ke ayam aduk rata sedikit di pijat, bisa juga diganti dengan susu cair."
- "Masukan ayam ke adonan bahan tepung pelapis lalu celupkan ke dalam air 1 liter tadi selama 3 detik, segera masukan lagi kedalam tepung pelapis, pijat-pijat pelan sampai keriting."
- "Lalu masukan ayam yang sudah keriting ke dalam minyak goreng yang sudah dipanaskan, goreng dengan api kecil hingga bewarna kuning kecoklatan segera angkat dan tiriskan."
- "Lakukan sampai ayam habis, jika sudah siap disajikan menggunakan sambal pecel lele yang sudah di sediakan."
categories:
- Recipe
tags:
- ayam
- kentucky
- sambel

katakunci: ayam kentucky sambel 
nutrition: 247 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT50M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Kentucky Sambel Pecel Lele](https://img-global.cpcdn.com/recipes/818e47cce4a22d01/680x482cq70/ayam-kentucky-sambel-pecel-lele-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis dan renyah. Ciri masakan Indonesia ayam kentucky sambel pecel lele yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan keluarga bisa diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam Kentucky Sambel Pecel Lele untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang bisa anda praktekkan salah satunya ayam kentucky sambel pecel lele yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep ayam kentucky sambel pecel lele tanpa harus bersusah payah.
Berikut ini resep Ayam Kentucky Sambel Pecel Lele yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 14 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Kentucky Sambel Pecel Lele:

1. Dibutuhkan  Bahan utama :
1. Tambah 1/2 kg ayam potong
1. Siapkan 1 liter minyak goreng
1. Siapkan  Bahan pelapis :
1. Tambah 250 gram tepung terigu
1. Harus ada 5 sdm maizena
1. Jangan lupa 1 bungkus royco ayam
1. Jangan lupa 1 butir telur ayam
1. Diperlukan 1 liter air putih
1. Harap siapkan  Bumbu halus :
1. Jangan lupa 4 siung bawang putih
1. Tambah 1 sdt royco ayam
1. Harus ada 1 sdt garam
1. Jangan lupa 1 sdt merica bubuk




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Kentucky Sambel Pecel Lele:

1. Cuci bersih ayam yang sudah di potong kemudian lumuri dengan bumbu yang sudah di haluskan hingga merata kemudian ungkep sebentar di wajan. Setelah di ungkep angkat lalu tiriskan.
1. Kemudian siapkan bahan pelapis, tuangkan telur yang sudah di kocok tuangkan ke ayam aduk rata sedikit di pijat, bisa juga diganti dengan susu cair.
1. Masukan ayam ke adonan bahan tepung pelapis lalu celupkan ke dalam air 1 liter tadi selama 3 detik, segera masukan lagi kedalam tepung pelapis, pijat-pijat pelan sampai keriting.
1. Lalu masukan ayam yang sudah keriting ke dalam minyak goreng yang sudah dipanaskan, goreng dengan api kecil hingga bewarna kuning kecoklatan segera angkat dan tiriskan.
1. Lakukan sampai ayam habis, jika sudah siap disajikan menggunakan sambal pecel lele yang sudah di sediakan.




Demikianlah cara membuat ayam kentucky sambel pecel lele yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan terbukti, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
