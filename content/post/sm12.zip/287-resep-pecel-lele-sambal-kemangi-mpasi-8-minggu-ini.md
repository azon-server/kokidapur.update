---
description: "Resep : Pecel Lele Sambal Kemangi (MPASI 8+) minggu ini"
title: "Resep : Pecel Lele Sambal Kemangi (MPASI 8+) minggu ini"
slug: 287-resep-pecel-lele-sambal-kemangi-mpasi-8-minggu-ini
date: 2021-02-03T21:21:52.237Z
image: https://img-global.cpcdn.com/recipes/94b3452e2c5aacf3/680x482cq70/pecel-lele-sambal-kemangi-mpasi-8-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/94b3452e2c5aacf3/680x482cq70/pecel-lele-sambal-kemangi-mpasi-8-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/94b3452e2c5aacf3/680x482cq70/pecel-lele-sambal-kemangi-mpasi-8-foto-resep-utama.jpg
author: Stanley Murray
ratingvalue: 4.9
reviewcount: 1449
recipeingredient:
- " Bubur"
- "3 sdm nasi putih"
- "500 ml air"
- "3 sdt santan bubuk20ml santan instan"
- "1 sereh"
- "1 daun salam"
- "secukupnya Kaldu ayam"
- " Pecel Lele"
- "1 ekor lele"
- "1 bawang putih parut"
- "Sejumput ketumbar bubuk"
- " Sambal Kemangi"
- "1/2 buah tomat merah"
- "1 bawang merah"
- "1 bawang putih"
- "1 kemiri"
- "5 lembar kemangi cincang"
- "1 gr garam"
- "1 gr gula"
recipeinstructions:
- "Bubur: didihkan air, masukkan nasi, santan, sereh, daun salam, kaldu ayam. Aduk sesekali agar tidak gosong. Masak sampai kekentalan yg diinginkan."
- "Pecel lele: kukus/rebus ikan lele hingga matang. Angkat. Pisahkan daging dgn durinya. Sambil dibejek agar lembut (sesuaikan tekstur). Marinasi dgn bawang putih dan ketumbar. Panaskan margarin, goreng marinasi lele hingga matang (jika dirasa terlalu kering, tambahkan air rebusan lele sedikit)"
- "Sambal Kemangi: ulek/blender halus bamer, baput, kemiri, tomat. Panaskan minyak, tumis sambal yg telah halus td hingga harum. Tambahkan air rebusan lele secukupnya. Masukkan kemangi yg telah dicincang dan bumbu2. Aduk2 hingga matang, tes rasa. Angkat."
categories:
- Recipe
tags:
- pecel
- lele
- sambal

katakunci: pecel lele sambal 
nutrition: 222 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT30M"
recipeyield: "1"
recipecategory: Dessert

---


![Pecel Lele Sambal Kemangi (MPASI 8+)](https://img-global.cpcdn.com/recipes/94b3452e2c5aacf3/680x482cq70/pecel-lele-sambal-kemangi-mpasi-8-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti pecel lele sambal kemangi (mpasi 8+) yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa keistimewahan yang merupakan keragaman Indonesia



Kedekatan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Pecel Lele Sambal Kemangi (MPASI 8+) untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang bisa anda buat salah satunya pecel lele sambal kemangi (mpasi 8+) yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep pecel lele sambal kemangi (mpasi 8+) tanpa harus bersusah payah.
Seperti resep Pecel Lele Sambal Kemangi (MPASI 8+) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Pecel Lele Sambal Kemangi (MPASI 8+):

1. Harap siapkan  Bubur:
1. Diperlukan 3 sdm nasi putih
1. Siapkan 500 ml air
1. Harap siapkan 3 sdt santan bubuk/20ml santan instan
1. Tambah 1 sereh
1. Diperlukan 1 daun salam
1. Dibutuhkan secukupnya Kaldu ayam
1. Siapkan  Pecel Lele:
1. Diperlukan 1 ekor lele
1. Harap siapkan 1 bawang putih, parut
1. Siapkan Sejumput ketumbar bubuk
1. Siapkan  Sambal Kemangi:
1. Siapkan 1/2 buah tomat merah
1. Dibutuhkan 1 bawang merah
1. Harap siapkan 1 bawang putih
1. Jangan lupa 1 kemiri
1. Jangan lupa 5 lembar kemangi, cincang
1. Dibutuhkan 1 gr garam
1. Diperlukan 1 gr gula




<!--inarticleads2-->

##### Instruksi membuat  Pecel Lele Sambal Kemangi (MPASI 8+):

1. Bubur: didihkan air, masukkan nasi, santan, sereh, daun salam, kaldu ayam. Aduk sesekali agar tidak gosong. Masak sampai kekentalan yg diinginkan.
1. Pecel lele: kukus/rebus ikan lele hingga matang. Angkat. Pisahkan daging dgn durinya. Sambil dibejek agar lembut (sesuaikan tekstur). Marinasi dgn bawang putih dan ketumbar. Panaskan margarin, goreng marinasi lele hingga matang (jika dirasa terlalu kering, tambahkan air rebusan lele sedikit)
1. Sambal Kemangi: ulek/blender halus bamer, baput, kemiri, tomat. Panaskan minyak, tumis sambal yg telah halus td hingga harum. Tambahkan air rebusan lele secukupnya. Masukkan kemangi yg telah dicincang dan bumbu2. Aduk2 hingga matang, tes rasa. Angkat.




Demikianlah cara membuat pecel lele sambal kemangi (mpasi 8+) yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
