---
description: "Langkah untuk membuat Roti UnyiL Metode Autolis Teruji"
title: "Langkah untuk membuat Roti UnyiL Metode Autolis Teruji"
slug: 55-langkah-untuk-membuat-roti-unyil-metode-autolis-teruji
date: 2020-12-16T15:22:40.227Z
image: https://img-global.cpcdn.com/recipes/8ac060033f713a32/680x482cq70/roti-unyil-metode-autolis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8ac060033f713a32/680x482cq70/roti-unyil-metode-autolis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8ac060033f713a32/680x482cq70/roti-unyil-metode-autolis-foto-resep-utama.jpg
author: Lola Sandoval
ratingvalue: 4.4
reviewcount: 49422
recipeingredient:
- " Bahan A "
- " tepung terigu protein tinggi"
- " kuning telur"
- " susu bubuk"
- " gula pasir"
- " susu uht saya susu Dancowair"
- " Bahan B "
- " ragi instan"
- " margarin"
- " gram"
- " Bahan Olesan "
- " susu cair"
- " margarin"
- " Bahan isian dan Toping "
- " Selai cokelat"
- " Gula pasir"
- " Selai strawberry"
- " Daging kebab"
- " Saos"
- " Mayonaise"
recipeinstructions:
- "Campur semua bahan A (Autolisis) dalam satu wadah.. uleni dengan tangan sebentar, hingga tercampur rata saja, diamkan selama 2 jam untuk proses Autolisis.."
- "Setelah 2 jam adonan akan terlihat lebih elastis, Masukan ragi margarin dan garam.."
- "Diamkan atau profing adonan hingga mengembang 2 kali lipat, jangan lupa bungkus plastik wrap atau serbet lembab.."
- "Setelah mengembang 2 kali lipat, kempiskan adonan, lalu uleni sebentar, untuk mengeluarkan udara yang terperangkap di dalam adonan dan bagi dengan sama rata, 25 gr.."
- "Ambil satu adonan lalu gilas bentuk sesuai kreatif masing-masing, beri isian dan tata di loyang, diamkan lagi sekitar 20-30 menitan, beri olesan susu cair.. dan taburi dengan toping.."
- "Panggang roti sesuai kan dengan suhu oven masing-masing.. saya pakai otang, sekitar 25 menitan.."
- "Setelah berwarna kecoklatan beri olesan margarin untuk mempercantik tampilan, agar terlihat mengkilap.."
categories:
- Recipe
tags:
- roti
- unyil
- metode

katakunci: roti unyil metode 
nutrition: 275 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT49M"
recipeyield: "4"
recipecategory: Dessert

---


![Roti UnyiL Metode Autolis](https://img-global.cpcdn.com/recipes/8ac060033f713a32/680x482cq70/roti-unyil-metode-autolis-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga gurih. Ciri khas masakan Indonesia roti unyil metode autolis yang kaya dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Roti UnyiL Metode Autolis untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang bisa anda coba salah satunya roti unyil metode autolis yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep roti unyil metode autolis tanpa harus bersusah payah.
Seperti resep Roti UnyiL Metode Autolis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti UnyiL Metode Autolis:

1. Harus ada  Bahan A :
1. Jangan lupa  tepung terigu protein tinggi
1. Dibutuhkan  kuning telur
1. Jangan lupa  susu bubuk
1. Siapkan  gula pasir
1. Dibutuhkan  susu uht (saya susu Dancow+air)
1. Harus ada  Bahan B :
1. Harap siapkan  ragi instan
1. Diperlukan  margarin
1. Harus ada  gram
1. Jangan lupa  Bahan Olesan :
1. Siapkan  susu cair
1. Jangan lupa  margarin
1. Harap siapkan  Bahan isian dan Toping :
1. Jangan lupa  Selai cokelat
1. Diperlukan  Gula pasir
1. Siapkan  Selai strawberry
1. Tambah  Daging kebab
1. Tambah  Saos
1. Dibutuhkan  Mayonaise




<!--inarticleads2-->

##### Cara membuat  Roti UnyiL Metode Autolis:

1. Campur semua bahan A (Autolisis) dalam satu wadah.. uleni dengan tangan sebentar, hingga tercampur rata saja, diamkan selama 2 jam untuk proses Autolisis..
1. Setelah 2 jam adonan akan terlihat lebih elastis, Masukan ragi margarin dan garam..
1. Diamkan atau profing adonan hingga mengembang 2 kali lipat, jangan lupa bungkus plastik wrap atau serbet lembab..
1. Setelah mengembang 2 kali lipat, kempiskan adonan, lalu uleni sebentar, untuk mengeluarkan udara yang terperangkap di dalam adonan dan bagi dengan sama rata, 25 gr..
1. Ambil satu adonan lalu gilas bentuk sesuai kreatif masing-masing, beri isian dan tata di loyang, diamkan lagi sekitar 20-30 menitan, beri olesan susu cair.. dan taburi dengan toping..
1. Panggang roti sesuai kan dengan suhu oven masing-masing.. saya pakai otang, sekitar 25 menitan..
1. Setelah berwarna kecoklatan beri olesan margarin untuk mempercantik tampilan, agar terlihat mengkilap..




Demikianlah cara membuat roti unyil metode autolis yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan teruji, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
