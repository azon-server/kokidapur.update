---
description: "Step-by-Step membuat Sambal Tumpang solo terupdate"
title: "Step-by-Step membuat Sambal Tumpang solo terupdate"
slug: 493-step-by-step-membuat-sambal-tumpang-solo-terupdate
date: 2020-10-16T08:02:33.276Z
image: https://img-global.cpcdn.com/recipes/cd03f438bd201e72/680x482cq70/sambal-tumpang-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cd03f438bd201e72/680x482cq70/sambal-tumpang-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cd03f438bd201e72/680x482cq70/sambal-tumpang-solo-foto-resep-utama.jpg
author: Beulah Allison
ratingvalue: 4.4
reviewcount: 42356
recipeingredient:
- "3 papan tempe basi"
- "1 papan tempe bagus"
- "1/2 butir kelapa untuk santan"
- "2 sdt ebi"
- "2 sdt teri"
- "2 ruas lengkuas geprek"
- "5 lembar daun jeruk"
- "3 lembar daun salam"
- "1 sdm gula jawa"
- "Secukupnya garam"
- "Secukupnya kaldu bubuk"
- " Bumbu halus"
- "25 butir cabe rawit"
- "5 buah cabe merah"
- "1 sdt ketumbar"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "4 buah kemiri"
- "2 ruas kencur"
- " Pelengkap "
- "2 buah telur dadar kering"
- "Secukupnya rempeyek kacang"
- "Secukupnya kacang panjang rebus"
- "Secukupnya daun ubi rebus"
- "Secukupnya kangkung rebus"
- "Secukupnya toge rebus"
recipeinstructions:
- "Rebus tempe basi maupun tempe bagusnya hingga lunak, angkat tempenya, jangan buang airnya"
- "Tumis bumbu halus, daun salam, daun jeruk, gula jawa dan lengkuas hingga harum, masukkan bumbu halus ke dalam rebusan air, aduk merata"
- "Ulek tempe hingga mendidih, masukkan santan, aduk hingga mendidih dan air menyusut tambahkan garam, kaldu bubuk, tes rasa, kekentalan kuah sesuai selera ya.."
- "Tambahkan lauk pauk, siap disajikan 😍😍"
categories:
- Recipe
tags:
- sambal
- tumpang
- solo

katakunci: sambal tumpang solo 
nutrition: 206 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dinner

---


![Sambal Tumpang solo](https://img-global.cpcdn.com/recipes/cd03f438bd201e72/680x482cq70/sambal-tumpang-solo-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti sambal tumpang solo yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Nusantara



Kehangatan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Sambal Tumpang solo untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang dapat anda contoh salah satunya sambal tumpang solo yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep sambal tumpang solo tanpa harus bersusah payah.
Berikut ini resep Sambal Tumpang solo yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 26 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambal Tumpang solo:

1. Siapkan 3 papan tempe basi
1. Harap siapkan 1 papan tempe bagus
1. Harus ada 1/2 butir kelapa untuk santan
1. Dibutuhkan 2 sdt ebi
1. Harus ada 2 sdt teri
1. Harap siapkan 2 ruas lengkuas, geprek
1. Jangan lupa 5 lembar daun jeruk
1. Harap siapkan 3 lembar daun salam
1. Tambah 1 sdm gula jawa
1. Siapkan Secukupnya garam
1. Dibutuhkan Secukupnya kaldu bubuk
1. Siapkan  Bumbu halus:
1. Dibutuhkan 25 butir cabe rawit
1. Tambah 5 buah cabe merah
1. Diperlukan 1 sdt ketumbar
1. Diperlukan 8 siung bawang merah
1. Tambah 4 siung bawang putih
1. Dibutuhkan 4 buah kemiri
1. Jangan lupa 2 ruas kencur
1. Siapkan  Pelengkap :
1. Tambah 2 buah telur, dadar kering
1. Diperlukan Secukupnya rempeyek kacang
1. Diperlukan Secukupnya kacang panjang, rebus
1. Diperlukan Secukupnya daun ubi, rebus
1. Dibutuhkan Secukupnya kangkung, rebus
1. Tambah Secukupnya toge, rebus




<!--inarticleads2-->

##### Bagaimana membuat  Sambal Tumpang solo:

1. Rebus tempe basi maupun tempe bagusnya hingga lunak, angkat tempenya, jangan buang airnya
1. Tumis bumbu halus, daun salam, daun jeruk, gula jawa dan lengkuas hingga harum, masukkan bumbu halus ke dalam rebusan air, aduk merata
1. Ulek tempe hingga mendidih, masukkan santan, aduk hingga mendidih dan air menyusut tambahkan garam, kaldu bubuk, tes rasa, kekentalan kuah sesuai selera ya..
1. Tambahkan lauk pauk, siap disajikan 😍😍




Demikianlah cara membuat sambal tumpang solo yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan cepat, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
