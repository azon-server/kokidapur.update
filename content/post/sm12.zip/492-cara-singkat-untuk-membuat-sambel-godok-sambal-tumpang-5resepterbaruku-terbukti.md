---
description: "Cara singkat untuk membuat Sambel godok (Sambal tumpang) #5resepterbaruku# Terbukti"
title: "Cara singkat untuk membuat Sambel godok (Sambal tumpang) #5resepterbaruku# Terbukti"
slug: 492-cara-singkat-untuk-membuat-sambel-godok-sambal-tumpang-5resepterbaruku-terbukti
date: 2020-11-06T08:30:17.529Z
image: https://img-global.cpcdn.com/recipes/07e5e7df7e698dd5/680x482cq70/sambel-godok-sambal-tumpang-5resepterbaruku-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/07e5e7df7e698dd5/680x482cq70/sambel-godok-sambal-tumpang-5resepterbaruku-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/07e5e7df7e698dd5/680x482cq70/sambel-godok-sambal-tumpang-5resepterbaruku-foto-resep-utama.jpg
author: Isaac Griffin
ratingvalue: 4.3
reviewcount: 7740
recipeingredient:
- "10 buah tahu padat warna kecoklatan"
- "2 buah kentang"
- " Tempe busuk jgn terlalu busuk"
- "3 bungkus santan kara"
- "3 siung bawang merah"
- "4 siung bawang putih"
- "1 ruas Kencur"
- "15 buah cabe rawit hijau"
- "7 buah cabe merah kriting"
- " Daun salam"
- " Garam dan penyedap secukupny"
- "secukupnya Gula merah"
- "3 lembar daun jeruk"
recipeinstructions:
- "Cucu bersih tahu lalu potong serong jadi 2,kentang yg sudah dibersihkan jg dipotong2 jgn terlalu kecil. Sisihkan."
- "Rebus tempe busuk bersama semua bumbu kecuali kencur sampe cabenya matang biar mudah diulek."
- "Ulek kencur tersendiri."
- "Angkat bumbu yg sudah dierbus tadi lalu ulek bersama kencur yg sudah halus tadi hingha tercampur semua."
- "Tambahkan sedikit air kedalm panci sisa air rebusan tadi tunggu sampe mendidih."
- "Setelah air mendidih masukan semua bahan beserta semua bumbu yang sudah dihaluskan tadi,madukan jg dsun salam daun jeruk, gula merah tunggu sampe tahu dan kentangny empuk."
- "Terakhir masukan santan dan tambahkan penyedap sesuai selera. Setelah mendidih angkat lalu hidangkan."
categories:
- Recipe
tags:
- sambel
- godok
- sambal

katakunci: sambel godok sambal 
nutrition: 270 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT60M"
recipeyield: "1"
recipecategory: Dinner

---


![Sambel godok (Sambal tumpang) #5resepterbaruku#](https://img-global.cpcdn.com/recipes/07e5e7df7e698dd5/680x482cq70/sambel-godok-sambal-tumpang-5resepterbaruku-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga enak. Karasteristik masakan Indonesia sambel godok (sambal tumpang) #5resepterbaruku# yang penuh dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan keluarga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Sambel godok (Sambal tumpang) #5resepterbaruku# untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang bisa anda praktekkan salah satunya sambel godok (sambal tumpang) #5resepterbaruku# yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep sambel godok (sambal tumpang) #5resepterbaruku# tanpa harus bersusah payah.
Berikut ini resep Sambel godok (Sambal tumpang) #5resepterbaruku# yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambel godok (Sambal tumpang) #5resepterbaruku#:

1. Dibutuhkan 10 buah tahu padat (warna kecoklatan)
1. Jangan lupa 2 buah kentang
1. Harap siapkan  Tempe busuk (jgn terlalu busuk)
1. Harap siapkan 3 bungkus santan kara
1. Dibutuhkan 3 siung bawang merah
1. Jangan lupa 4 siung bawang putih
1. Harus ada 1 ruas Kencur
1. Siapkan 15 buah cabe rawit hijau
1. Tambah 7 buah cabe merah kriting
1. Jangan lupa  Daun salam
1. Harap siapkan  Garam dan penyedap secukupny
1. Siapkan secukupnya Gula merah
1. Harus ada 3 lembar daun jeruk




<!--inarticleads2-->

##### Instruksi membuat  Sambel godok (Sambal tumpang) #5resepterbaruku#:

1. Cucu bersih tahu lalu potong serong jadi 2,kentang yg sudah dibersihkan jg dipotong2 jgn terlalu kecil. Sisihkan.
1. Rebus tempe busuk bersama semua bumbu kecuali kencur sampe cabenya matang biar mudah diulek.
1. Ulek kencur tersendiri.
1. Angkat bumbu yg sudah dierbus tadi lalu ulek bersama kencur yg sudah halus tadi hingha tercampur semua.
1. Tambahkan sedikit air kedalm panci sisa air rebusan tadi tunggu sampe mendidih.
1. Setelah air mendidih masukan semua bahan beserta semua bumbu yang sudah dihaluskan tadi,madukan jg dsun salam daun jeruk, gula merah tunggu sampe tahu dan kentangny empuk.
1. Terakhir masukan santan dan tambahkan penyedap sesuai selera. Setelah mendidih angkat lalu hidangkan.




Demikianlah cara membuat sambel godok (sambal tumpang) #5resepterbaruku# yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
