---
description: "Resep : Sambel Tumpang Khas Kediri Terbukti"
title: "Resep : Sambel Tumpang Khas Kediri Terbukti"
slug: 416-resep-sambel-tumpang-khas-kediri-terbukti
date: 2021-02-25T20:51:45.492Z
image: https://img-global.cpcdn.com/recipes/613da6abd89c2bc2/680x482cq70/sambel-tumpang-khas-kediri-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/613da6abd89c2bc2/680x482cq70/sambel-tumpang-khas-kediri-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/613da6abd89c2bc2/680x482cq70/sambel-tumpang-khas-kediri-foto-resep-utama.jpg
author: Janie Walters
ratingvalue: 4.2
reviewcount: 44412
recipeingredient:
- "2 balok sedang tempe over fermented tempe busuk "
- "3 lembar daun jeruk"
- "4 lembar daun salam"
- "4 cm lengkuas"
- "1/2 cm kencur"
- "300-400 ml santan"
- "secukupnya Air"
- "secukupnya Gula"
- "secukupnya Garam"
- " Bumbu Halus"
- "3 siung bawang putih"
- "6 siung bawang merah"
- "7 buah cabe rawit sesuai selera"
- "2 buah cabe besar"
recipeinstructions:
- "Cuci bersih bumbu bumbu"
- "Potong kasar bumbu halus kemudian masukkan kedalam plastik, lalu rebus bersama dengan tempe busuk, daun jeruk, daun salam, dan lengkuas hingga matang. (hal ini bertujuan utk mematangkan bumbu supaya cabe dan bawang tidak terlalu menyengat)"
- "Setelah mendidih dan matang, tiriskan bumbu halus, tambahkan kencur. Kemudian haluskan dengan blender atau diulek seperti biasa buibuu"
- "Tiriskan tempe busuk, kemudian haluskan dengan cara diulek, boleh sampai lembuuut, atau diulek kasar sesuai selera andaa (ups! jangan buang air rebusan tempe ya buibu, ini yg bikin sedep hehehe)"
- "Setelah tempe halus, masukkan kembali ke air rebusan tempe, tambahkan dengan bumbu yg telah dihaluskan"
- "Tuangkan 300-400 ml santan, aduk rata tunggu hingga mendidih."
- "Tambahkan gula dan garam secukupnya, koreksi rasa"
- "Sajikan !"
categories:
- Recipe
tags:
- sambel
- tumpang
- khas

katakunci: sambel tumpang khas 
nutrition: 233 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Lunch

---


![Sambel Tumpang Khas Kediri](https://img-global.cpcdn.com/recipes/613da6abd89c2bc2/680x482cq70/sambel-tumpang-khas-kediri-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga enak. Ciri khas makanan Nusantara sambel tumpang khas kediri yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga bisa didapat dengan cara sederhana. Salah satunya adalah membuat makanan Sambel Tumpang Khas Kediri untuk keluarga. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang dapat anda coba salah satunya sambel tumpang khas kediri yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep sambel tumpang khas kediri tanpa harus bersusah payah.
Berikut ini resep Sambel Tumpang Khas Kediri yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 14 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambel Tumpang Khas Kediri:

1. Harus ada 2 balok sedang tempe over fermented (tempe busuk) 😅
1. Harus ada 3 lembar daun jeruk
1. Jangan lupa 4 lembar daun salam
1. Siapkan 4 cm lengkuas
1. Tambah 1/2 cm kencur
1. Tambah 300-400 ml santan
1. Tambah secukupnya Air
1. Dibutuhkan secukupnya Gula
1. Jangan lupa secukupnya Garam
1. Jangan lupa  Bumbu Halus:
1. Dibutuhkan 3 siung bawang putih
1. Siapkan 6 siung bawang merah
1. Harap siapkan 7 buah cabe rawit (sesuai selera)
1. Harap siapkan 2 buah cabe besar




<!--inarticleads2-->

##### Bagaimana membuat  Sambel Tumpang Khas Kediri:

1. Cuci bersih bumbu bumbu
1. Potong kasar bumbu halus kemudian masukkan kedalam plastik, lalu rebus bersama dengan tempe busuk, daun jeruk, daun salam, dan lengkuas hingga matang. (hal ini bertujuan utk mematangkan bumbu supaya cabe dan bawang tidak terlalu menyengat)
1. Setelah mendidih dan matang, tiriskan bumbu halus, tambahkan kencur. Kemudian haluskan dengan blender atau diulek seperti biasa buibuu
1. Tiriskan tempe busuk, kemudian haluskan dengan cara diulek, boleh sampai lembuuut, atau diulek kasar sesuai selera andaa (ups! jangan buang air rebusan tempe ya buibu, ini yg bikin sedep hehehe)
1. Setelah tempe halus, masukkan kembali ke air rebusan tempe, tambahkan dengan bumbu yg telah dihaluskan
1. Tuangkan 300-400 ml santan, aduk rata tunggu hingga mendidih.
1. Tambahkan gula dan garam secukupnya, koreksi rasa
1. Sajikan !




Demikianlah cara membuat sambel tumpang khas kediri yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
