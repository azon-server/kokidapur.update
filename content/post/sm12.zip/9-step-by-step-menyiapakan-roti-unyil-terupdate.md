---
description: "Step-by-Step menyiapakan RoTi Unyil terupdate"
title: "Step-by-Step menyiapakan RoTi Unyil terupdate"
slug: 9-step-by-step-menyiapakan-roti-unyil-terupdate
date: 2021-03-07T11:31:00.407Z
image: https://img-global.cpcdn.com/recipes/d59e6442d6e5390c/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d59e6442d6e5390c/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d59e6442d6e5390c/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Lucinda Massey
ratingvalue: 4.7
reviewcount: 49039
recipeingredient:
- " terigu protein tinggi"
- " terigu protein sedang"
- " susu bubuk"
- " gula pasir butiran halus"
- " ragi instan"
- " di dapat dari susu cair  1 kuning telur  2 telur utuh"
- " garam"
- " butter"
- " BAHAN OLESAN 1"
- " telur utuh  12 sdt air"
- " BAHAN OLESAN 2 "
- " nya butter lelehkan"
- " ISIAN DAN TOPPING "
- " nya keju meses sosis biji wijen oregano kering"
recipeinstructions:
- "Campur semua bahan kering (tepung, gula, ragi, susu bubuk) kecuali garam dan butter aduk rata sisihkan. Kocok lepas 360 ml campuran susu dan telur"
- "Masukan campuran susu dan telur ke bahan kering sedikit demi sedikit sambil di ulen stop sekira nya sudah di dapat adonan lembek atau cukup air hasil adonan lengket. Lalu masukan butter dan garam ulenin hingga setengah kalis"
- "Mikser adonan sekitar 10 menit kalo mikser sudah panas stop lanjut ngulen pake tangan sekitar 5-10 menit atau sampe mikser adem lanjut lagi mikser sekitar 5-10 menit hingga di dapat adonan kalis tanda nya adonan bila di tarik tidak mudah robek #kunci roti empuk adonan kalis elastis. Lama mikser tergantung mikser masing2 yah, kalo aq ngeri mikser jebol kalo terlalu lama 😁"
- "Diamkan adonan hingga 2x lipat karena cuaca panas ga sampe 10 menit udh ngembang lalu tinju untuk mengeluarkan udara di adonan"
- "Bagi2 adonan sekitar 25gr kalo aq tapi biasa nya klo roti unyil itu 10gr segini aja aq mah ga sabar 🤭"
- "Lalu bentuk adonan sesuai selera. Ini masih ga jelas bentuk nya 🤭 untuk lebih jelas bisa liat di channel youtube nya bu fatmah bahlawan di situ jelas semua 😂. Istirahat kan roti sekitar 20 menit lalu oles menggunakan bahan olesan 1 langsung panggang sekitar 15 menit suhu 160 dc tergantung oven masing2 yah atau hingga kecoklatan. Aq pake otang menggunakan api sedang cenderung kecil"
- "Setelah matang keluarkan dari oven lalu langsung di oles menggunakan bahan olesan 2 diam kan hingga dingin"
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 163 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Dessert

---


![RoTi Unyil](https://img-global.cpcdn.com/recipes/d59e6442d6e5390c/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti roti unyil yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan keistimewahan yang merupakan keragaman Indonesia

Kehangatan rumah tangga bisa didapat dengan cara sederhana. Salah satunya adalah memasak RoTi Unyil untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang bisa anda praktekkan salah satunya roti unyil yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep roti unyil tanpa harus bersusah payah.
Seperti resep RoTi Unyil yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 14 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat RoTi Unyil:

1. Siapkan  terigu protein tinggi
1. Dibutuhkan  terigu protein sedang
1. Siapkan  susu bubuk
1. Harus ada  gula pasir butiran halus
1. Harap siapkan  ragi instan
1. Tambah  di dapat dari (susu cair + 1 kuning telur + 2 telur utuh)
1. Siapkan  garam
1. Diperlukan  butter
1. Harus ada  BAHAN OLESAN 1:
1. Diperlukan  telur utuh + 1/2 sdt air
1. Tambah  BAHAN OLESAN 2 :
1. Tambah  nya butter lelehkan
1. Diperlukan  ISIAN DAN TOPPING :
1. Harap siapkan  nya keju, meses, sosis, biji wijen, oregano kering




<!--inarticleads2-->

##### Cara membuat  RoTi Unyil:

1. Campur semua bahan kering (tepung, gula, ragi, susu bubuk) kecuali garam dan butter aduk rata sisihkan. Kocok lepas 360 ml campuran susu dan telur
1. Masukan campuran susu dan telur ke bahan kering sedikit demi sedikit sambil di ulen stop sekira nya sudah di dapat adonan lembek atau cukup air hasil adonan lengket. Lalu masukan butter dan garam ulenin hingga setengah kalis
1. Mikser adonan sekitar 10 menit kalo mikser sudah panas stop lanjut ngulen pake tangan sekitar 5-10 menit atau sampe mikser adem lanjut lagi mikser sekitar 5-10 menit hingga di dapat adonan kalis tanda nya adonan bila di tarik tidak mudah robek #kunci roti empuk adonan kalis elastis. Lama mikser tergantung mikser masing2 yah, kalo aq ngeri mikser jebol kalo terlalu lama 😁
1. Diamkan adonan hingga 2x lipat karena cuaca panas ga sampe 10 menit udh ngembang lalu tinju untuk mengeluarkan udara di adonan
1. Bagi2 adonan sekitar 25gr kalo aq tapi biasa nya klo roti unyil itu 10gr segini aja aq mah ga sabar 🤭
1. Lalu bentuk adonan sesuai selera. Ini masih ga jelas bentuk nya 🤭 untuk lebih jelas bisa liat di channel youtube nya bu fatmah bahlawan di situ jelas semua 😂. Istirahat kan roti sekitar 20 menit lalu oles menggunakan bahan olesan 1 langsung panggang sekitar 15 menit suhu 160 dc tergantung oven masing2 yah atau hingga kecoklatan. Aq pake otang menggunakan api sedang cenderung kecil
1. Setelah matang keluarkan dari oven lalu langsung di oles menggunakan bahan olesan 2 diam kan hingga dingin




Demikianlah cara membuat roti unyil yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
