---
description: "Resep : Roti Unyil (Ulen Manual) Sempurna"
title: "Resep : Roti Unyil (Ulen Manual) Sempurna"
slug: 85-resep-roti-unyil-ulen-manual-sempurna
date: 2020-11-11T09:47:09.350Z
image: https://img-global.cpcdn.com/recipes/37a6a560cdc9b755/680x482cq70/roti-unyil-ulen-manual-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/37a6a560cdc9b755/680x482cq70/roti-unyil-ulen-manual-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/37a6a560cdc9b755/680x482cq70/roti-unyil-ulen-manual-foto-resep-utama.jpg
author: Trevor Fletcher
ratingvalue: 4.6
reviewcount: 3363
recipeingredient:
- " tepung terigu protein tinggi"
- " susu bubuk"
- " kentang berat setelah dikukushaluskan"
- " telur"
- " gula pasir"
- " garam"
- " butter"
- " susu cair"
- " ragi instant"
recipeinstructions:
- "Dalam wadah masukkan terigu,susu bubuk,kentang,ragi dan telur,tuangi susu cair sedikit demi sedikit sampai konsistensi yg diinginkan (stop jk sdh pas) uleni sampai setenhah kalis,masukkan butter dan garam."
- "Uleni sampai kalis elastis. Bulatkan adonan taruh di wadah lalu tutup dgn plastik wrap atau kain bersih lembab."
- "Diamkan sampai mengembang 2X lipat selama 40 menit. Lalu kempeskan uleni sebentar. Bagi adonan menjadi 20 buah @25 gr (sy nggak ditimbang adonannya 🙊)"
- "Bentuk sesuai selera beri topping suka2, Kemudian ada kismis, jdnya di jadikan topping 😊😊 tutup dgn plastik wrap,biarkan kurleb 15 - 20 menit sampai mengembang lagi, lalu oles dgn susu cair (pisa jg pakai kuning telur dan susu cair)."
- "Panaskan oven 170 decel (sesuai oven msg2) selama 20 - 25 menit (sy pakai api bawah 15 menit dan api atas 5 menit atau utk memberi efek kining pd roti). Keluarkan dr oven, oles dgn butter. Sajikan."
categories:
- Recipe
tags:
- roti
- unyil
- ulen

katakunci: roti unyil ulen 
nutrition: 111 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Dessert

---


![Roti Unyil (Ulen Manual)](https://img-global.cpcdn.com/recipes/37a6a560cdc9b755/680x482cq70/roti-unyil-ulen-manual-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan enak. Ciri kuliner Nusantara roti unyil (ulen manual) yang penuh dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah memasak Roti Unyil (Ulen Manual) untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang dapat anda contoh salah satunya roti unyil (ulen manual) yang merupakan resep favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan cepat menemukan resep roti unyil (ulen manual) tanpa harus bersusah payah.
Berikut ini resep Roti Unyil (Ulen Manual) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 9 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Unyil (Ulen Manual):

1. Diperlukan  tepung terigu protein tinggi
1. Diperlukan  susu bubuk
1. Tambah  kentang berat setelah dikukus,haluskan
1. Harus ada  telur
1. Harus ada  gula pasir
1. Tambah  garam
1. Diperlukan  butter
1. Dibutuhkan  susu cair
1. Tambah  ragi instant




<!--inarticleads2-->

##### Cara membuat  Roti Unyil (Ulen Manual):

1. Dalam wadah masukkan terigu,susu bubuk,kentang,ragi dan telur,tuangi susu cair sedikit demi sedikit sampai konsistensi yg diinginkan (stop jk sdh pas) uleni sampai setenhah kalis,masukkan butter dan garam.
1. Uleni sampai kalis elastis. Bulatkan adonan taruh di wadah lalu tutup dgn plastik wrap atau kain bersih lembab.
1. Diamkan sampai mengembang 2X lipat selama 40 menit. Lalu kempeskan uleni sebentar. Bagi adonan menjadi 20 buah @25 gr (sy nggak ditimbang adonannya 🙊)
1. Bentuk sesuai selera beri topping suka2, Kemudian ada kismis, jdnya di jadikan topping 😊😊 tutup dgn plastik wrap,biarkan kurleb 15 - 20 menit sampai mengembang lagi, lalu oles dgn susu cair (pisa jg pakai kuning telur dan susu cair).
1. Panaskan oven 170 decel (sesuai oven msg2) selama 20 - 25 menit (sy pakai api bawah 15 menit dan api atas 5 menit atau utk memberi efek kining pd roti). Keluarkan dr oven, oles dgn butter. Sajikan.




Demikianlah cara membuat roti unyil (ulen manual) yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan teruji, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
