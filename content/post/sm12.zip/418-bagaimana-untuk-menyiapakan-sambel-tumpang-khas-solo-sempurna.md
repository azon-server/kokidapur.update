---
description: "Bagaimana untuk menyiapakan Sambel Tumpang Khas Solo Sempurna"
title: "Bagaimana untuk menyiapakan Sambel Tumpang Khas Solo Sempurna"
slug: 418-bagaimana-untuk-menyiapakan-sambel-tumpang-khas-solo-sempurna
date: 2020-12-22T05:58:10.363Z
image: https://img-global.cpcdn.com/recipes/3b1cc9b0fc2e1e4c/680x482cq70/sambel-tumpang-khas-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3b1cc9b0fc2e1e4c/680x482cq70/sambel-tumpang-khas-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3b1cc9b0fc2e1e4c/680x482cq70/sambel-tumpang-khas-solo-foto-resep-utama.jpg
author: Loretta Greene
ratingvalue: 4.7
reviewcount: 7394
recipeingredient:
- "1/2 papan tempe semangit tempe umur 3 hari"
- "1/2 papan tempe baru"
- "3 siung bawang putih"
- "3 butir bawang merah"
- "10 buah cabe rawit merah dan hijau"
- "2 butir kemiri"
- "2 cm kencur"
- "2 cm lengkuas geprek"
- "1/2 batang serai geprek"
- "2 lembar daun salam"
- "1 lembar daun jeruk"
- "500 ml air"
- "150 ml santan kental"
- "4 buah tahu putih potong kotak2 goreng"
- "secukupnya garam gula pasir merica bubuk kaldu bubuk"
recipeinstructions:
- "Rebus 500 ml air + tempe + bawang merah + bawang putih + cabe + kemiri + kencur sampai empuk, angkat..tiriskan.. air sisa merebus jangan dibuang"
- "Haluskan terlebih dahulu cabe + duo bawang + kemiri + kencur.. disusul dg tempe.. aQ dihaluskan kasar ajj.. biar berasa tekstur tempe&#39;nya"
- "Masukkan tempe yg dihaluskan ke air rebusan tadi.. tambahkan bahan geprek + santan + bumbu2 lainnya"
- "Nyalakan kembali api kompor.. masak sampai santan mendidih.. masukkan tahu goreng.. masak sampai air agak menyusut.."
- "Sajikan dg nasi hangatt :) bisa disiramkan disayur rebus.. atau kacangpanjang rebuss.. kalau suamiQ suka bangett dimamam sama ikan asin.. humm..yammihh bangett^^"
categories:
- Recipe
tags:
- sambel
- tumpang
- khas

katakunci: sambel tumpang khas 
nutrition: 141 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT41M"
recipeyield: "2"
recipecategory: Lunch

---


![Sambel Tumpang Khas Solo](https://img-global.cpcdn.com/recipes/3b1cc9b0fc2e1e4c/680x482cq70/sambel-tumpang-khas-solo-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau empuk. Ciri khas kuliner Indonesia sambel tumpang khas solo yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Sambel Tumpang Khas Solo untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang bisa anda buat salah satunya sambel tumpang khas solo yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep sambel tumpang khas solo tanpa harus bersusah payah.
Seperti resep Sambel Tumpang Khas Solo yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambel Tumpang Khas Solo:

1. Dibutuhkan 1/2 papan tempe semangit (tempe umur 3 hari)
1. Dibutuhkan 1/2 papan tempe baru
1. Diperlukan 3 siung bawang putih
1. Harap siapkan 3 butir bawang merah
1. Harus ada 10 buah cabe rawit (merah dan hijau)
1. Harus ada 2 butir kemiri
1. Siapkan 2 cm kencur
1. Tambah 2 cm lengkuas, geprek
1. Siapkan 1/2 batang serai, geprek
1. Siapkan 2 lembar daun salam
1. Harap siapkan 1 lembar daun jeruk
1. Jangan lupa 500 ml air
1. Diperlukan 150 ml santan kental
1. Dibutuhkan 4 buah tahu putih, potong kotak2, goreng
1. Jangan lupa secukupnya garam, gula pasir, merica bubuk, kaldu bubuk




<!--inarticleads2-->

##### Langkah membuat  Sambel Tumpang Khas Solo:

1. Rebus 500 ml air + tempe + bawang merah + bawang putih + cabe + kemiri + kencur sampai empuk, angkat..tiriskan.. air sisa merebus jangan dibuang
1. Haluskan terlebih dahulu cabe + duo bawang + kemiri + kencur.. disusul dg tempe.. aQ dihaluskan kasar ajj.. biar berasa tekstur tempe&#39;nya
1. Masukkan tempe yg dihaluskan ke air rebusan tadi.. tambahkan bahan geprek + santan + bumbu2 lainnya
1. Nyalakan kembali api kompor.. masak sampai santan mendidih.. masukkan tahu goreng.. masak sampai air agak menyusut..
1. Sajikan dg nasi hangatt :) bisa disiramkan disayur rebus.. atau kacangpanjang rebuss.. kalau suamiQ suka bangett dimamam sama ikan asin.. humm..yammihh bangett^^




Demikianlah cara membuat sambel tumpang khas solo yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan cepat, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
