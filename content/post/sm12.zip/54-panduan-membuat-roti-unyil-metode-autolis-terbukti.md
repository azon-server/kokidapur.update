---
description: "Panduan membuat Roti UnyiL Metode Autolis Terbukti"
title: "Panduan membuat Roti UnyiL Metode Autolis Terbukti"
slug: 54-panduan-membuat-roti-unyil-metode-autolis-terbukti
date: 2020-10-18T14:50:16.471Z
image: https://img-global.cpcdn.com/recipes/8ac060033f713a32/680x482cq70/roti-unyil-metode-autolis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8ac060033f713a32/680x482cq70/roti-unyil-metode-autolis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8ac060033f713a32/680x482cq70/roti-unyil-metode-autolis-foto-resep-utama.jpg
author: Terry Tyler
ratingvalue: 4.7
reviewcount: 22570
recipeingredient:
- " Bahan A "
- "250 gram tepung terigu protein tinggi"
- "1 butir kuning telur"
- "1 SDM susu bubuk"
- "40 gr gula pasir"
- "140 ml susu uht saya susu Dancowair"
- " Bahan B "
- "1 sdt ragi instan"
- "30 gr margarin"
- "1/2 sdt gram"
- " Bahan Olesan "
- "2 SDM susu cair"
- "2 SDM margarin"
- " Bahan isian dan Toping "
- " Selai cokelat"
- " Gula pasir"
- " Selai strawberry"
- " Daging kebab"
- " Saos"
- " Mayonaise"
recipeinstructions:
- "Campur semua bahan A (Autolisis) dalam satu wadah.. uleni dengan tangan sebentar, hingga tercampur rata saja, diamkan selama 2 jam untuk proses Autolisis.."
- "Setelah 2 jam adonan akan terlihat lebih elastis, Masukan ragi margarin dan garam.."
- "Diamkan atau profing adonan hingga mengembang 2 kali lipat, jangan lupa bungkus plastik wrap atau serbet lembab.."
- "Setelah mengembang 2 kali lipat, kempiskan adonan, lalu uleni sebentar, untuk mengeluarkan udara yang terperangkap di dalam adonan dan bagi dengan sama rata, 25 gr.."
- "Ambil satu adonan lalu gilas bentuk sesuai kreatif masing-masing, beri isian dan tata di loyang, diamkan lagi sekitar 20-30 menitan, beri olesan susu cair.. dan taburi dengan toping.."
- "Panggang roti sesuai kan dengan suhu oven masing-masing.. saya pakai otang, sekitar 25 menitan.."
- "Setelah berwarna kecoklatan beri olesan margarin untuk mempercantik tampilan, agar terlihat mengkilap.."
categories:
- Recipe
tags:
- roti
- unyil
- metode

katakunci: roti unyil metode 
nutrition: 191 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Lunch

---


![Roti UnyiL Metode Autolis](https://img-global.cpcdn.com/recipes/8ac060033f713a32/680x482cq70/roti-unyil-metode-autolis-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti roti unyil metode autolis yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa ciri khas yang merupakan keragaman Kita

Kehangatan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Roti UnyiL Metode Autolis untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang bisa anda praktekkan salah satunya roti unyil metode autolis yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep roti unyil metode autolis tanpa harus bersusah payah.
Berikut ini resep Roti UnyiL Metode Autolis yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti UnyiL Metode Autolis:

1. Jangan lupa  Bahan A :
1. Diperlukan 250 gram tepung terigu protein tinggi
1. Harus ada 1 butir kuning telur
1. Diperlukan 1 SDM susu bubuk
1. Harap siapkan 40 gr gula pasir
1. Harap siapkan 140 ml susu uht (saya susu Dancow+air)
1. Diperlukan  Bahan B :
1. Siapkan 1 sdt ragi instan
1. Jangan lupa 30 gr margarin
1. Harap siapkan 1/2 sdt gram
1. Tambah  Bahan Olesan :
1. Dibutuhkan 2 SDM susu cair
1. Dibutuhkan 2 SDM margarin
1. Dibutuhkan  Bahan isian dan Toping :
1. Jangan lupa  Selai cokelat
1. Harap siapkan  Gula pasir
1. Jangan lupa  Selai strawberry
1. Jangan lupa  Daging kebab
1. Siapkan  Saos
1. Harap siapkan  Mayonaise




<!--inarticleads2-->

##### Instruksi membuat  Roti UnyiL Metode Autolis:

1. Campur semua bahan A (Autolisis) dalam satu wadah.. uleni dengan tangan sebentar, hingga tercampur rata saja, diamkan selama 2 jam untuk proses Autolisis..
1. Setelah 2 jam adonan akan terlihat lebih elastis, Masukan ragi margarin dan garam..
1. Diamkan atau profing adonan hingga mengembang 2 kali lipat, jangan lupa bungkus plastik wrap atau serbet lembab..
1. Setelah mengembang 2 kali lipat, kempiskan adonan, lalu uleni sebentar, untuk mengeluarkan udara yang terperangkap di dalam adonan dan bagi dengan sama rata, 25 gr..
1. Ambil satu adonan lalu gilas bentuk sesuai kreatif masing-masing, beri isian dan tata di loyang, diamkan lagi sekitar 20-30 menitan, beri olesan susu cair.. dan taburi dengan toping..
1. Panggang roti sesuai kan dengan suhu oven masing-masing.. saya pakai otang, sekitar 25 menitan..
1. Setelah berwarna kecoklatan beri olesan margarin untuk mempercantik tampilan, agar terlihat mengkilap..




Demikianlah cara membuat roti unyil metode autolis yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan terbukti, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
