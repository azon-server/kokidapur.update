---
description: "Langkah menyiapakan Roti Unyil terupdate"
title: "Langkah menyiapakan Roti Unyil terupdate"
slug: 111-langkah-menyiapakan-roti-unyil-terupdate
date: 2021-03-01T03:50:24.218Z
image: https://img-global.cpcdn.com/recipes/3a788b30313be67b/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3a788b30313be67b/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3a788b30313be67b/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Myra Vargas
ratingvalue: 4.8
reviewcount: 38312
recipeingredient:
- " tepung cakra kembar"
- " telur ayam suhu ruang"
- " susu cair dingin"
- " ragi"
- " gula pasir"
- " susu bubuk saya pakai Dancow"
- " margarin"
- " garam"
- " Toppingisian"
- " Keju"
- " Sosis"
- " Ceres"
- " Olesan"
- " margarin dioles setelah keluar dr oven"
- " susu cair dioles sebelum masuk oven"
recipeinstructions:
- "Campur tepung, ragi, susu bubuk, gula pasir dan telur. Untuk susu tuang perlahan sambil diuleni/mixer, jika dirasa sudah cukup lembek, distop saja. Karena bergantung pada ukuran telur juga. Uleni semua hingga setengah kalis. Lalu tambahkan garam dan mentega, lanjut uleni hingga kalis elastis, saat ditarik tipis adonan tidak sobek. Bulatkan adonan taruh dimangkuk dan tutup dengan lap basah atau plastik wrap. Diamkan selama 15 menit."
- "Adonan saya timbang setelah mengembang sekitar 550 gram. Bagi adonan kecil-kecil sesuai selera (saya 12 gram dan ada 1 roti ukuran besar sisanya) setelah ditimbang, bulatkan adonan kecil dan baru bisa dibentuk sesuai selera."
- "Setelah selesai dibentuk dan diberi isian sesuai selera, olesi dengan susu cair kemudian panggang dalam oven dengan suhu 180° sekitar 12 menit. Langsung olesi dengan mentega ketika baru keluar dari oven."
- "Tips: ketika akan membagi menjadi adonan kecil, lebih baik lakukan sebagian dulu, sebagian lagi tetap dibungkus plastik wrap. Agar adonan tidak kering dan tetap lembap."
- "Untuk isian roti yg saya buat saya memotong 1 sosis menjadi 8 buah untuk isian sosis keju. Memotong 1 sosis menjadi 4 buah untuk isian sosis saja. Memotong keju panjang seukuran sosis, dan sebagian saya parut untuk isian keju juga isian keju coklat."
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 131 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Dinner

---


![Roti Unyil](https://img-global.cpcdn.com/recipes/3a788b30313be67b/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas hingga empuk. Ciri khas makanan Indonesia roti unyil yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga dapat didapat dengan cara mudah. Salah satunya adalah memasak Roti Unyil untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang dapat anda coba salah satunya roti unyil yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep roti unyil tanpa harus bersusah payah.
Seperti resep Roti Unyil yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Unyil:

1. Harap siapkan  tepung cakra kembar
1. Siapkan  telur ayam suhu ruang
1. Harus ada  susu cair dingin
1. Jangan lupa  ragi
1. Jangan lupa  gula pasir
1. Jangan lupa  susu bubuk (saya pakai Dancow)
1. Siapkan  margarin
1. Dibutuhkan  garam
1. Diperlukan  Topping/isian
1. Diperlukan  Keju
1. Harap siapkan  Sosis
1. Diperlukan  Ceres
1. Jangan lupa  Olesan
1. Harus ada  margarin, dioles setelah keluar dr oven
1. Harap siapkan  susu cair, dioles sebelum masuk oven




<!--inarticleads2-->

##### Langkah membuat  Roti Unyil:

1. Campur tepung, ragi, susu bubuk, gula pasir dan telur. Untuk susu tuang perlahan sambil diuleni/mixer, jika dirasa sudah cukup lembek, distop saja. Karena bergantung pada ukuran telur juga. Uleni semua hingga setengah kalis. Lalu tambahkan garam dan mentega, lanjut uleni hingga kalis elastis, saat ditarik tipis adonan tidak sobek. Bulatkan adonan taruh dimangkuk dan tutup dengan lap basah atau plastik wrap. Diamkan selama 15 menit.
1. Adonan saya timbang setelah mengembang sekitar 550 gram. Bagi adonan kecil-kecil sesuai selera (saya 12 gram dan ada 1 roti ukuran besar sisanya) setelah ditimbang, bulatkan adonan kecil dan baru bisa dibentuk sesuai selera.
1. Setelah selesai dibentuk dan diberi isian sesuai selera, olesi dengan susu cair kemudian panggang dalam oven dengan suhu 180° sekitar 12 menit. Langsung olesi dengan mentega ketika baru keluar dari oven.
1. Tips: ketika akan membagi menjadi adonan kecil, lebih baik lakukan sebagian dulu, sebagian lagi tetap dibungkus plastik wrap. Agar adonan tidak kering dan tetap lembap.
1. Untuk isian roti yg saya buat saya memotong 1 sosis menjadi 8 buah untuk isian sosis keju. Memotong 1 sosis menjadi 4 buah untuk isian sosis saja. Memotong keju panjang seukuran sosis, dan sebagian saya parut untuk isian keju juga isian keju coklat.




Demikianlah cara membuat roti unyil yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan teruji, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
