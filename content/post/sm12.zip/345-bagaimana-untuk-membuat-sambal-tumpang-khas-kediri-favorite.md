---
description: "Bagaimana untuk membuat Sambal Tumpang Khas Kediri Favorite"
title: "Bagaimana untuk membuat Sambal Tumpang Khas Kediri Favorite"
slug: 345-bagaimana-untuk-membuat-sambal-tumpang-khas-kediri-favorite
date: 2021-02-08T08:00:53.589Z
image: https://img-global.cpcdn.com/recipes/4a1f9bd5a2dc0ae0/680x482cq70/sambal-tumpang-khas-kediri-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4a1f9bd5a2dc0ae0/680x482cq70/sambal-tumpang-khas-kediri-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4a1f9bd5a2dc0ae0/680x482cq70/sambal-tumpang-khas-kediri-foto-resep-utama.jpg
author: Ann Clayton
ratingvalue: 4.5
reviewcount: 45631
recipeingredient:
- "100 gr tempe semangitbosok"
- "4 lembar daun jeruk"
- "2 lembar daun salam"
- "3 cm lengkuas geprek"
- "65 ml santan instan"
- "1 sdm tepung beras"
- "750 ml air"
- "Secukupnya tulang ayam"
- " Bumbu Halus"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "4 butir kemiri sangrai"
- "2 buah cabe keriting"
- "10 buah atau sesuai selera cabe rawit"
- "1 sdt ketumbar"
- "1 sdm ebiudang papay kering"
- "1/2 sdt garam"
- "Secukupnya gula pasir"
- "Secukupnya kaldu ayam bubuk non MSG"
recipeinstructions:
- "Haluskan semua bumbu."
- "Rebus tempe semangit yang sudah dipotong-potong. Setelah beberapa menit, angkat dan sisihkan."
- "Rebus air dengan tulang ayam hingga mendidih dan keluar kaldunya."
- "Tumbuk kasar atau penyet tempe yang telah direbus bersama bumbu halus."
- "Masukkan tempe yang telah dipenyetin, bumbu halus, daun salam, daun jeruk, dan lengkuas ke dalam air kaldu. Masak hingga mendidih dan mengeluarkan aroma bumbu."
- "Masukkan santan dan terus diaduk rata agar santan tidak pecah."
- "Masukkan garam, kaldu bubuk dan gula. Tes rasa."
- "Masukkan larutan tepung beras (1 sdm tepung beras larutkan dengan sedikit air) sambil terus diaduk hingga mendidih dan mencapai kekentalan yang diinginkan."
- "Angkat dan sajikan. Siap dihidangkan bersama sayur rebus dan rempeyek. Selamat mencoba 🌺"
categories:
- Recipe
tags:
- sambal
- tumpang
- khas

katakunci: sambal tumpang khas 
nutrition: 167 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT60M"
recipeyield: "1"
recipecategory: Dinner

---


![Sambal Tumpang Khas Kediri](https://img-global.cpcdn.com/recipes/4a1f9bd5a2dc0ae0/680x482cq70/sambal-tumpang-khas-kediri-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan enak. Ciri masakan Nusantara sambal tumpang khas kediri yang penuh dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Sambal Tumpang Khas Kediri untuk keluarga. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang bisa anda coba salah satunya sambal tumpang khas kediri yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep sambal tumpang khas kediri tanpa harus bersusah payah.
Berikut ini resep Sambal Tumpang Khas Kediri yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 19 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambal Tumpang Khas Kediri:

1. Jangan lupa 100 gr tempe semangit/bosok
1. Tambah 4 lembar daun jeruk
1. Diperlukan 2 lembar daun salam
1. Diperlukan 3 cm lengkuas, geprek
1. Harus ada 65 ml santan instan
1. Harap siapkan 1 sdm tepung beras
1. Dibutuhkan 750 ml air
1. Harap siapkan Secukupnya tulang ayam
1. Diperlukan  Bumbu Halus:
1. Tambah 10 siung bawang merah
1. Jangan lupa 5 siung bawang putih
1. Diperlukan 4 butir kemiri, sangrai
1. Tambah 2 buah cabe keriting
1. Tambah 10 buah atau sesuai selera cabe rawit
1. Dibutuhkan 1 sdt ketumbar
1. Harap siapkan 1 sdm ebi/udang papay kering
1. Siapkan 1/2 sdt garam
1. Siapkan Secukupnya gula pasir
1. Diperlukan Secukupnya kaldu ayam bubuk non MSG




<!--inarticleads2-->

##### Langkah membuat  Sambal Tumpang Khas Kediri:

1. Haluskan semua bumbu.
1. Rebus tempe semangit yang sudah dipotong-potong. Setelah beberapa menit, angkat dan sisihkan.
1. Rebus air dengan tulang ayam hingga mendidih dan keluar kaldunya.
1. Tumbuk kasar atau penyet tempe yang telah direbus bersama bumbu halus.
1. Masukkan tempe yang telah dipenyetin, bumbu halus, daun salam, daun jeruk, dan lengkuas ke dalam air kaldu. Masak hingga mendidih dan mengeluarkan aroma bumbu.
1. Masukkan santan dan terus diaduk rata agar santan tidak pecah.
1. Masukkan garam, kaldu bubuk dan gula. Tes rasa.
1. Masukkan larutan tepung beras (1 sdm tepung beras larutkan dengan sedikit air) sambil terus diaduk hingga mendidih dan mencapai kekentalan yang diinginkan.
1. Angkat dan sajikan. Siap dihidangkan bersama sayur rebus dan rempeyek. Selamat mencoba 🌺




Demikianlah cara membuat sambal tumpang khas kediri yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan terbukti, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
