---
description: "Resep : Roti Unyil teraktual"
title: "Resep : Roti Unyil teraktual"
slug: 78-resep-roti-unyil-teraktual
date: 2020-10-21T11:36:59.941Z
image: https://img-global.cpcdn.com/recipes/531c254db5705735/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/531c254db5705735/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/531c254db5705735/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Nancy Duncan
ratingvalue: 4
reviewcount: 21089
recipeingredient:
- "500 gr tepung terigu"
- "2 butir kuning telur"
- "250 ml susu cair"
- "2 sdt ragi instan"
- "2 sdm butter"
- "100 gr gula pasir"
- "sejumput garam"
- "sesuai selera Siapkan jg bahan isian"
recipeinstructions:
- "Masukkan semua bahan kecuali susu cair dan butter. Aduk sebentar menggunakan spatula."
- "Lanjutkan menggunakan mixer (20 menit) lalu tambahkan sedikit demi sedikit susu cair hingga setengah kalis lalu tambahkan juga butter yang sudah disiapkan dan uleni hingga adonan kalis atau bisa dilanjutkan dengan mengulen menggunakan tangan (20 menit)"
- "Bulatkan adonan hingga mulus lalu lakukan proofing pertama tutup dengan kain atau plasticwrap selama 60 menit."
- "Bagi adonan menjadi beberapa bagian (saya 30 gr) lalu bulatkan kembali dan proofing lg selama 15 menit."
- "Setelah itu gilaskan adonan menggunakan rollingpin/botol kaca yang sudah dicuci bersih dan ditaburi tepung terigu. Lalu bentuk dan beri isian sesuai selera."
- "Panaskan oven selama 10menit dan panggang dengan api atas bawah selama 20 menit-an."
- "Selamat menikmati."
- "NB : (Jika menggunakan otang harus dibalik ya agar tidak gosong sebagian). Selamat Mencoba, Semoga bisa menambah referensi untuk kreatifitas didapur selama masa pandemi ini 🤗🤗🤗 Stay healthy and stayathome."
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 276 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dessert

---


![Roti Unyil](https://img-global.cpcdn.com/recipes/531c254db5705735/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan enak. Karasteristik kuliner Indonesia roti unyil yang penuh dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga bisa didapat dengan cara simple. Salah satunya adalah membuat makanan Roti Unyil untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda coba salah satunya roti unyil yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep roti unyil tanpa harus bersusah payah.
Berikut ini resep Roti Unyil yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Unyil:

1. Siapkan 500 gr tepung terigu
1. Harus ada 2 butir kuning telur
1. Jangan lupa 250 ml susu cair
1. Tambah 2 sdt ragi instan
1. Tambah 2 sdm butter
1. Harus ada 100 gr gula pasir
1. Jangan lupa sejumput garam
1. Siapkan sesuai selera Siapkan jg bahan isian




<!--inarticleads2-->

##### Langkah membuat  Roti Unyil:

1. Masukkan semua bahan kecuali susu cair dan butter. Aduk sebentar menggunakan spatula.
1. Lanjutkan menggunakan mixer (20 menit) lalu tambahkan sedikit demi sedikit susu cair hingga setengah kalis lalu tambahkan juga butter yang sudah disiapkan dan uleni hingga adonan kalis atau bisa dilanjutkan dengan mengulen menggunakan tangan (20 menit)
1. Bulatkan adonan hingga mulus lalu lakukan proofing pertama tutup dengan kain atau plasticwrap selama 60 menit.
1. Bagi adonan menjadi beberapa bagian (saya 30 gr) lalu bulatkan kembali dan proofing lg selama 15 menit.
1. Setelah itu gilaskan adonan menggunakan rollingpin/botol kaca yang sudah dicuci bersih dan ditaburi tepung terigu. Lalu bentuk dan beri isian sesuai selera.
1. Panaskan oven selama 10menit dan panggang dengan api atas bawah selama 20 menit-an.
1. Selamat menikmati.
1. NB : (Jika menggunakan otang harus dibalik ya agar tidak gosong sebagian). Selamat Mencoba, Semoga bisa menambah referensi untuk kreatifitas didapur selama masa pandemi ini 🤗🤗🤗 Stay healthy and stayathome.




Demikianlah cara membuat roti unyil yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
