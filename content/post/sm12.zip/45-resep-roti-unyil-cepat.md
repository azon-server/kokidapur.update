---
description: "Resep : Roti unyil Cepat"
title: "Resep : Roti unyil Cepat"
slug: 45-resep-roti-unyil-cepat
date: 2020-11-05T02:31:56.166Z
image: https://img-global.cpcdn.com/recipes/13d82156959131c2/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/13d82156959131c2/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/13d82156959131c2/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Philip Lawrence
ratingvalue: 4.5
reviewcount: 43481
recipeingredient:
- " tepung pro tinggi"
- " susu bubukoptionaltadi ga pake"
- " ragi instan"
- " telurkocok lepasbagi 2utk adonan  egg wash"
- " gula pasir"
- " susu cair dingin"
- " margarin"
- " garam"
- " Isian"
- " meses coklat"
- " sosis"
- " kejukental manis"
recipeinstructions:
- "Campur tepung,ragi,gula dan telur kocok,masukkan sedikit demi sedikit susu cair,sambil di mixer dengan kecepatan rendah.Hentikan penambahan susu,jika adonan sudah setengah kalis."
- "Tambahkan separuh margarin dan garam,mixer dengan kecepatan tinggi selama +-5 menit.tambahkan lagi sisa margarin,mixer lagi dengan kecepatan tinggi selama +-10 menit hingga kalis elastis(saya 20 menit mixer).Bulatkan adonan,tutup lap kering,diamkan 1 jam hingga mengembang 2x lipat."
- "Setelah 1 jam,kempiskan adonan.Bagi2 adonan sesuai selera,saya bagi jadi 20 buah,ukuran mini2 😁"
- "Ambil satu adonan,pipihkan.Isi dengan bahan isi.Bentuk sesuai selera.Susun di loyang yang sudah diolesi margarin dan dialasi kertas roti."
- "Lakukan sampai adonan habis,lalu diamkan 20 menit tanpa ditutup.Panaskan oven,sambil menunggu roti mengembang."
- "Setelah 20 menit,olesi roti dengan egg wash,untuk yang rasa sosis,saya tambahkan mayonais,keju parut dan parsley."
- "Panggang selama -+20 menit,sesuaikan dengan oven masing2.Panas2 olesi dengan margarin."
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 225 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Lunch

---


![Roti unyil](https://img-global.cpcdn.com/recipes/13d82156959131c2/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga gurih. Karasteristik kuliner Indonesia roti unyil yang kaya dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak Roti unyil untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang bisa anda contoh salah satunya roti unyil yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep roti unyil tanpa harus bersusah payah.
Seperti resep Roti unyil yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 12 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti unyil:

1. Diperlukan  tepung pro tinggi
1. Dibutuhkan  susu bubuk(optional,tadi ga pake)
1. Jangan lupa  ragi instan
1. Harap siapkan  telur,kocok lepas,bagi 2(utk adonan &amp; egg wash)
1. Siapkan  gula pasir
1. Siapkan  susu cair dingin
1. Harap siapkan  margarin
1. Tambah  garam
1. Dibutuhkan  Isian:
1. Siapkan  meses coklat
1. Jangan lupa  sosis
1. Harap siapkan  keju+kental manis




<!--inarticleads2-->

##### Instruksi membuat  Roti unyil:

1. Campur tepung,ragi,gula dan telur kocok,masukkan sedikit demi sedikit susu cair,sambil di mixer dengan kecepatan rendah.Hentikan penambahan susu,jika adonan sudah setengah kalis.
1. Tambahkan separuh margarin dan garam,mixer dengan kecepatan tinggi selama +-5 menit.tambahkan lagi sisa margarin,mixer lagi dengan kecepatan tinggi selama +-10 menit hingga kalis elastis(saya 20 menit mixer).Bulatkan adonan,tutup lap kering,diamkan 1 jam hingga mengembang 2x lipat.
1. Setelah 1 jam,kempiskan adonan.Bagi2 adonan sesuai selera,saya bagi jadi 20 buah,ukuran mini2 😁
1. Ambil satu adonan,pipihkan.Isi dengan bahan isi.Bentuk sesuai selera.Susun di loyang yang sudah diolesi margarin dan dialasi kertas roti.
1. Lakukan sampai adonan habis,lalu diamkan 20 menit tanpa ditutup.Panaskan oven,sambil menunggu roti mengembang.
1. Setelah 20 menit,olesi roti dengan egg wash,untuk yang rasa sosis,saya tambahkan mayonais,keju parut dan parsley.
1. Panggang selama -+20 menit,sesuaikan dengan oven masing2.Panas2 olesi dengan margarin.




Demikianlah cara membuat roti unyil yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan cepat, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
