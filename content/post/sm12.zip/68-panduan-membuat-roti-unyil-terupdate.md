---
description: "Panduan membuat Roti unyil terupdate"
title: "Panduan membuat Roti unyil terupdate"
slug: 68-panduan-membuat-roti-unyil-terupdate
date: 2020-12-13T18:59:08.347Z
image: https://img-global.cpcdn.com/recipes/188241841ebc62a2/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/188241841ebc62a2/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/188241841ebc62a2/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: George Welch
ratingvalue: 4.8
reviewcount: 30170
recipeingredient:
- "250 gr terigu protein tinggi"
- "100 gr kentang kukus lumatkan berat setelah dikukus"
- "1 sdt ragi instan"
- "1 butir telur"
- "45 gr gula pasir"
- "1 sdm susu bubuk"
- "50 ml susu cair sy ultra plain"
- "40 gr mentega boleh ganti margarin"
- "1/4 sdt garam"
- " Olesan"
- "1 butir kuning telur"
- "2 sdm susu cair"
- " Mentega margarin"
recipeinstructions:
- "Campurkan tepung terigu, ragi instan, susu bubuk, gula pasir, telur dan kentang. Aduk rata."
- "Masukkan susu cair sedikit demi sedikit. Uleni hingga setengah kalis."
- "Masukkan mentega dan garam. Uleni sampai kalis elastis. Sy pake handmixer, kurang lebih 15 menit."
- "Bulatkan adonan. Simpan di baskom. Tutup dengan plastik atau lap bersih. Tunggu hingga memgembang 2x lipat."
- "Timbang adonan @10 gram."
- "Bentuk adonan roti dengan isian sesuai selera."
- "Oles dengan kuning telur &amp; susu cair. Panggang di oven 170⁰c selama 20-25 menit. (oven sebelumnya sudah dipanaskan selama 10-15 menit). Sy 20 menit api bawah, 5 menit api atas."
- "Setelah matang, langsung oles pake mentega/ margarin."
- "Roti unyil siap disantap. Hmmm wangi dan lembut teksturnya.."
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 172 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dinner

---


![Roti unyil](https://img-global.cpcdn.com/recipes/188241841ebc62a2/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang harus kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti roti unyil yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia

Keharmonisan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Roti unyil untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang bisa anda buat salah satunya roti unyil yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep roti unyil tanpa harus bersusah payah.
Berikut ini resep Roti unyil yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 13 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti unyil:

1. Harus ada 250 gr terigu protein tinggi
1. Harus ada 100 gr kentang kukus, lumatkan (berat setelah dikukus)
1. Siapkan 1 sdt ragi instan
1. Jangan lupa 1 butir telur
1. Tambah 45 gr gula pasir
1. Jangan lupa 1 sdm susu bubuk
1. Jangan lupa 50 ml susu cair (sy ultra plain)
1. Harap siapkan 40 gr mentega (boleh ganti margarin)
1. Jangan lupa 1/4 sdt garam
1. Diperlukan  Olesan
1. Diperlukan 1 butir kuning telur
1. Tambah 2 sdm susu cair
1. Siapkan  Mentega/ margarin




<!--inarticleads2-->

##### Langkah membuat  Roti unyil:

1. Campurkan tepung terigu, ragi instan, susu bubuk, gula pasir, telur dan kentang. Aduk rata.
1. Masukkan susu cair sedikit demi sedikit. Uleni hingga setengah kalis.
1. Masukkan mentega dan garam. Uleni sampai kalis elastis. Sy pake handmixer, kurang lebih 15 menit.
1. Bulatkan adonan. Simpan di baskom. Tutup dengan plastik atau lap bersih. Tunggu hingga memgembang 2x lipat.
1. Timbang adonan @10 gram.
1. Bentuk adonan roti dengan isian sesuai selera.
1. Oles dengan kuning telur &amp; susu cair. Panggang di oven 170⁰c selama 20-25 menit. (oven sebelumnya sudah dipanaskan selama 10-15 menit). Sy 20 menit api bawah, 5 menit api atas.
1. Setelah matang, langsung oles pake mentega/ margarin.
1. Roti unyil siap disantap. Hmmm wangi dan lembut teksturnya..




Demikianlah cara membuat roti unyil yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan terbukti, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
