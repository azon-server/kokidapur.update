---
description: "Langkah menyiapakan Sambal Tumpang terupdate"
title: "Langkah menyiapakan Sambal Tumpang terupdate"
slug: 494-langkah-menyiapakan-sambal-tumpang-terupdate
date: 2020-10-21T06:27:03.734Z
image: https://img-global.cpcdn.com/recipes/2136470fba7c4d8d/680x482cq70/sambal-tumpang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2136470fba7c4d8d/680x482cq70/sambal-tumpang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2136470fba7c4d8d/680x482cq70/sambal-tumpang-foto-resep-utama.jpg
author: Jorge Walters
ratingvalue: 5
reviewcount: 25329
recipeingredient:
- "1 papan tempe semangit simpan di suhu ruang selama 45 hari"
- "1000 ml santan kental"
- " Bumbu halus "
- "6 bawang putih"
- "10 bawang merah"
- "4 butir kemiri"
- "8 cabe merah kriting"
- "1 ons cabe rawit"
- "2 ruas kencur"
- "1 sdm ketumbar bubuk"
- "1 sdm udang rebon"
- "1 ruas besar lengkuas geprek"
- "4 lembar daun salam"
- "2 lembar daun jeruk purut"
- " Garam"
- " Gula pasir"
- " Kaldu bubuk jamur"
recipeinstructions:
- "Cuci bersih tempe. Rebus tempe hingga lunak. Angkat. Ulek tempe hingga agak hancur, cukup ditekan-tekan. Masukan kembali ke dalam rebusan air."
- "Ditempat terpisah, rebus bawang putih, bawang merah, cabe, kemiri dan kencur hingga lunak. Angkat, kemudian haluskan dan masukkan ke dalam rebusan tempe."
- "Masukkan ketumbar bubuk, rebon, lengkuas, daun jeruk dan daun salam. Beri gula, garam dan kaldu bubuk. Aduk rata."
- "Masukkan santan, aduk2 hingga mendidih, koreksi rasa"
- "Sajikan bersama pecel sayuran atau lauk pauk lainnya."
categories:
- Recipe
tags:
- sambal
- tumpang

katakunci: sambal tumpang 
nutrition: 203 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Dinner

---


![Sambal Tumpang](https://img-global.cpcdn.com/recipes/2136470fba7c4d8d/680x482cq70/sambal-tumpang-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau empuk. Ciri khas kuliner Nusantara sambal tumpang yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan rumah tangga dapat diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Sambal Tumpang untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang bisa anda contoh salah satunya sambal tumpang yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep sambal tumpang tanpa harus bersusah payah.
Seperti resep Sambal Tumpang yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambal Tumpang:

1. Harus ada 1 papan tempe semangit (simpan di suhu ruang selama 4-5 hari)
1. Tambah 1000 ml santan kental
1. Diperlukan  Bumbu halus :
1. Siapkan 6 bawang putih
1. Harus ada 10 bawang merah
1. Jangan lupa 4 butir kemiri
1. Tambah 8 cabe merah kriting
1. Tambah 1 ons cabe rawit
1. Harap siapkan 2 ruas kencur
1. Diperlukan 1 sdm ketumbar bubuk
1. Siapkan 1 sdm udang rebon
1. Jangan lupa 1 ruas besar lengkuas, geprek
1. Harus ada 4 lembar daun salam
1. Jangan lupa 2 lembar daun jeruk purut
1. Jangan lupa  Garam
1. Harus ada  Gula pasir
1. Jangan lupa  Kaldu bubuk jamur




<!--inarticleads2-->

##### Instruksi membuat  Sambal Tumpang:

1. Cuci bersih tempe. Rebus tempe hingga lunak. Angkat. Ulek tempe hingga agak hancur, cukup ditekan-tekan. Masukan kembali ke dalam rebusan air.
1. Ditempat terpisah, rebus bawang putih, bawang merah, cabe, kemiri dan kencur hingga lunak. Angkat, kemudian haluskan dan masukkan ke dalam rebusan tempe.
1. Masukkan ketumbar bubuk, rebon, lengkuas, daun jeruk dan daun salam. Beri gula, garam dan kaldu bubuk. Aduk rata.
1. Masukkan santan, aduk2 hingga mendidih, koreksi rasa
1. Sajikan bersama pecel sayuran atau lauk pauk lainnya.




Demikianlah cara membuat sambal tumpang yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan terbukti, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
