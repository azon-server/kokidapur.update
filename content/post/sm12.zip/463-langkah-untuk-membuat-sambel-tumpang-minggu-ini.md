---
description: "Langkah untuk membuat Sambel Tumpang minggu ini"
title: "Langkah untuk membuat Sambel Tumpang minggu ini"
slug: 463-langkah-untuk-membuat-sambel-tumpang-minggu-ini
date: 2021-02-17T15:56:31.839Z
image: https://img-global.cpcdn.com/recipes/ae39c94c99cf01ac/680x482cq70/sambel-tumpang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ae39c94c99cf01ac/680x482cq70/sambel-tumpang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ae39c94c99cf01ac/680x482cq70/sambel-tumpang-foto-resep-utama.jpg
author: Abbie Wallace
ratingvalue: 4.9
reviewcount: 49334
recipeingredient:
- "1/2 potong tempe semangit 125 gr"
- "1/2 potong tempe baru 125 gr"
- "6 buah cabe rawit utuh"
- "2 helai daun salam"
- "2 helai daun jeruk purut"
- "3 cm lengkuas geprek"
- "1 potong serai geprek"
- "3 butir telur rebus optional bisa diganti tahu krecek"
- "500 ml air"
- " Bumbu Halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "3 buah cabe merah besar"
- "6 buah cabe rawit merah"
- "2 butir kemiri"
- "1 ruas kencur"
- "1/2 potong gula merah ukuran kecil"
- "secukupnya garam"
recipeinstructions:
- "Didihkan air, rebus tempe bersama bahan bumbu kecuali garam &amp; gula merah. Setelah air menyusut, matikan kompor, angkat pisahkan bahan bumbu &amp; tempe."
- "Sisihkan 6 bh cabe rawit biarkan utuh, daun salam, daun jeruk &amp; lengkuas. Sisa bumbu yg lain dihaluskan. Utk tempe boleh diulek kasar atau sampai halus, sesuai selera saja."
- "Resep asli bumbu tidak ditumis, saya tumis dulu bumbu sampai wangi sedap, lalu masukkan tempe, daun salam, daun jeruk, lengkuas, serai, garam &amp; gula merah. Tambahkan air sisa rebusan, aduk rata."
- "Tambahkan santan, aduk2 sampai mendidih tp jangan sampai pecah. Sambal tumpang ini bisa polosan atau dikombinasi dg isian telur rebus, tahu, ataupun krecek. Tanpa santan pun enak."
categories:
- Recipe
tags:
- sambel
- tumpang

katakunci: sambel tumpang 
nutrition: 117 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT56M"
recipeyield: "4"
recipecategory: Dinner

---


![Sambel Tumpang](https://img-global.cpcdn.com/recipes/ae39c94c99cf01ac/680x482cq70/sambel-tumpang-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti sambel tumpang yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa kesan tersendiri yang merupakan keragaman Kita

Kehangatan keluarga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Sambel Tumpang untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi makanan yang bisa anda praktekkan salah satunya sambel tumpang yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep sambel tumpang tanpa harus bersusah payah.
Seperti resep Sambel Tumpang yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambel Tumpang:

1. Siapkan 1/2 potong tempe semangit (125 gr)
1. Siapkan 1/2 potong tempe baru (125 gr)
1. Siapkan 6 buah cabe rawit utuh
1. Tambah 2 helai daun salam
1. Harus ada 2 helai daun jeruk purut
1. Jangan lupa 3 cm lengkuas, geprek
1. Tambah 1 potong serai geprek
1. Harus ada 3 butir telur rebus (optional, bisa diganti tahu, krecek)
1. Siapkan 500 ml air
1. Tambah  🌾Bumbu Halus:
1. Tambah 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Tambah 3 buah cabe merah besar
1. Jangan lupa 6 buah cabe rawit merah
1. Dibutuhkan 2 butir kemiri
1. Dibutuhkan 1 ruas kencur
1. Harus ada 1/2 potong gula merah ukuran kecil
1. Dibutuhkan secukupnya garam




<!--inarticleads2-->

##### Cara membuat  Sambel Tumpang:

1. Didihkan air, rebus tempe bersama bahan bumbu kecuali garam &amp; gula merah. Setelah air menyusut, matikan kompor, angkat pisahkan bahan bumbu &amp; tempe.
1. Sisihkan 6 bh cabe rawit biarkan utuh, daun salam, daun jeruk &amp; lengkuas. Sisa bumbu yg lain dihaluskan. Utk tempe boleh diulek kasar atau sampai halus, sesuai selera saja.
1. Resep asli bumbu tidak ditumis, saya tumis dulu bumbu sampai wangi sedap, lalu masukkan tempe, daun salam, daun jeruk, lengkuas, serai, garam &amp; gula merah. Tambahkan air sisa rebusan, aduk rata.
1. Tambahkan santan, aduk2 sampai mendidih tp jangan sampai pecah. Sambal tumpang ini bisa polosan atau dikombinasi dg isian telur rebus, tahu, ataupun krecek. Tanpa santan pun enak.




Demikianlah cara membuat sambel tumpang yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
