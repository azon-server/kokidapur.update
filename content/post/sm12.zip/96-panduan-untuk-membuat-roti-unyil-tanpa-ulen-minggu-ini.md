---
description: "Panduan untuk membuat Roti Unyil (tanpa ulen) minggu ini"
title: "Panduan untuk membuat Roti Unyil (tanpa ulen) minggu ini"
slug: 96-panduan-untuk-membuat-roti-unyil-tanpa-ulen-minggu-ini
date: 2021-02-12T05:13:29.015Z
image: https://img-global.cpcdn.com/recipes/c72da0c8337ff22c/680x482cq70/roti-unyil-tanpa-ulen-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c72da0c8337ff22c/680x482cq70/roti-unyil-tanpa-ulen-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c72da0c8337ff22c/680x482cq70/roti-unyil-tanpa-ulen-foto-resep-utama.jpg
author: Verna Sharp
ratingvalue: 4.5
reviewcount: 43088
recipeingredient:
- " terigu protein tinggi"
- " gula pasir"
- " susu bubuk"
- " ragi instant1 sdt"
- " telur sisakan sedikit untuk polesan"
- " air"
- " butter"
- " garam halus"
- " Bahan tangzhong"
- " peres terigu"
- " air"
- " Bahan isian sesuai selera"
- " Selai coklat"
- " sosis"
- " keju soft"
recipeinstructions:
- "Adonan biang tangzhong dibuat terlebih dahulu. Campur bahan tangzhong dalam panci kecil. Panaskan diatas kompor, api kecil saja, sembari diaduk hingga tampak menggumpal. Matikan api. Biarkan hangat"
- "Campur semua bahan roti (kecuali butter dan garam) dan adonan tangzhong dalam wadah. Aduk rata dengan tangan."
- "Tambahkan butter dan garam. Aduk rata kembali dengan tangan hinggal kalis, tidak lengket ditangan"
- "Tutup dengan plastik wrap, simpan ditempat hangat hingga mengembang 2x lipat. Karena cuaca mendung, adonan saya perlu 3 jam untuk mengembang"
- "Setelah mengembang, ambil adonan, pindahkan ke alas datar, uleni sebentar. Kemudian bagi menjadi beberapa bagian kecil. Diamkan 15 menit sebelum diisi."
- "Ambil 1 buah adonan, bentuk sesuai selera dan isi sesuai keinginan. Lakukan hingga semua adonan habis dibentuk"
- "Ini salah satu cara membentuk roti unyil isian keju"
- "Tata roti unyil pada loyang yang sudah dialasi kertas roti. Diamkan 30 menit, kemudian poles dengan dengan kocokkan telur. Beri topping. Panggang dengan api sedang (175⁰C)10 menit kemudian turunkan suhu oven, panggang lagi 5 menit"
- "Beri polesan butter saat roti unyil keluar dari oven supaya tampak berkilat dan lembab."
categories:
- Recipe
tags:
- roti
- unyil
- tanpa

katakunci: roti unyil tanpa 
nutrition: 209 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Lunch

---


![Roti Unyil (tanpa ulen)](https://img-global.cpcdn.com/recipes/c72da0c8337ff22c/680x482cq70/roti-unyil-tanpa-ulen-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan empuk. Ciri masakan Nusantara roti unyil (tanpa ulen) yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Roti Unyil (tanpa ulen) untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang bisa anda praktekkan salah satunya roti unyil (tanpa ulen) yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep roti unyil (tanpa ulen) tanpa harus bersusah payah.
Berikut ini resep Roti Unyil (tanpa ulen) yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 9 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Unyil (tanpa ulen):

1. Tambah  terigu protein tinggi
1. Siapkan  gula pasir
1. Diperlukan  susu bubuk
1. Harap siapkan  ragi instant/1 sdt
1. Jangan lupa  telur (sisakan sedikit untuk polesan)
1. Diperlukan  air
1. Jangan lupa  butter
1. Harap siapkan  garam halus
1. Jangan lupa  Bahan tangzhong:
1. Harus ada  peres terigu
1. Dibutuhkan  air
1. Harus ada  Bahan isian (sesuai selera)
1. Harap siapkan  Selai coklat
1. Siapkan  sosis
1. Siapkan  keju soft




<!--inarticleads2-->

##### Instruksi membuat  Roti Unyil (tanpa ulen):

1. Adonan biang tangzhong dibuat terlebih dahulu. Campur bahan tangzhong dalam panci kecil. Panaskan diatas kompor, api kecil saja, sembari diaduk hingga tampak menggumpal. Matikan api. Biarkan hangat
1. Campur semua bahan roti (kecuali butter dan garam) dan adonan tangzhong dalam wadah. Aduk rata dengan tangan.
1. Tambahkan butter dan garam. Aduk rata kembali dengan tangan hinggal kalis, tidak lengket ditangan
1. Tutup dengan plastik wrap, simpan ditempat hangat hingga mengembang 2x lipat. Karena cuaca mendung, adonan saya perlu 3 jam untuk mengembang
1. Setelah mengembang, ambil adonan, pindahkan ke alas datar, uleni sebentar. Kemudian bagi menjadi beberapa bagian kecil. Diamkan 15 menit sebelum diisi.
1. Ambil 1 buah adonan, bentuk sesuai selera dan isi sesuai keinginan. Lakukan hingga semua adonan habis dibentuk
1. Ini salah satu cara membentuk roti unyil isian keju
1. Tata roti unyil pada loyang yang sudah dialasi kertas roti. Diamkan 30 menit, kemudian poles dengan dengan kocokkan telur. Beri topping. Panggang dengan api sedang (175⁰C)10 menit kemudian turunkan suhu oven, panggang lagi 5 menit
1. Beri polesan butter saat roti unyil keluar dari oven supaya tampak berkilat dan lembab.




Demikianlah cara membuat roti unyil (tanpa ulen) yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan cepat, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
