---
description: "Langkah untuk membuat Roti Unyil (Tanpa Ulen) Terbukti"
title: "Langkah untuk membuat Roti Unyil (Tanpa Ulen) Terbukti"
slug: 18-langkah-untuk-membuat-roti-unyil-tanpa-ulen-terbukti
date: 2020-12-26T18:11:15.415Z
image: https://img-global.cpcdn.com/recipes/1f9b5c2618f99fa0/680x482cq70/roti-unyil-tanpa-ulen-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1f9b5c2618f99fa0/680x482cq70/roti-unyil-tanpa-ulen-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1f9b5c2618f99fa0/680x482cq70/roti-unyil-tanpa-ulen-foto-resep-utama.jpg
author: Ronnie Jennings
ratingvalue: 5
reviewcount: 8531
recipeingredient:
- "450 gram terigu cakra"
- "1 butir telur kocok lepas"
- "300 ml susu cair full cream hangat"
- "50 gram gula pasir"
- "1 sdt garam"
- "2 sdt ragi instan"
- "60 gram butter saya Anchor"
- " untuk olesan sblm oven kuning telurputih telursusu cair"
- " untuk isi meisis keju sosis nutella dll"
- " untuk olesan setelah keluar oven butter"
recipeinstructions:
- "Aktifkan ragi. Campur 50ml susu hangat dengan ragi, aduk rata. Tambahkan 1sdm gula pasir. Diamkan 5-8 menit hingga berbuih. Tanda ragi aktif."
- "Siapkan wadah, campir terigu yg sudah di ayak, garam dan gula pasir. Aduk rata."
- "Masukan butter, remas2 dgn tangan hingga adonan scrumble."
- "Masukan kocokan telur, cairan ragi, dan sisa susu cair yg 250ml. Aduk rata dgn tangan."
- "Bersihkan tangan dengan spatula. Bentuk bulat adonan. Tutup plastik wrap, dan kain kering. Diamkan 1 jam hingga mengembang."
- "Setelah mengembang, aduk2 dgn spatula hingga adonan kempis lagi. Diamkan 20 menit."
- "Lalukan proses ini 2-3x. Saya 3x@20 menit."
- "Keluarkan adonan dr wadah, alasi terigu. Tepuk2 adonan dengan terigu agar tidak lengket."
- "Timbang @25 gram, bentuk dan isi sesuai selera. Diamkan lagi 15 menit, biarkan mengembang."
- "Olesi dgn bahan oles. Loyang olesi dgn margarin/alasi baking sheet."
- "Panggang 180&#39;C 15 menit, atau sesuaikan kondisi oven masing2. Jangan over bake ya nanti rotinya keras."
- "Tips: Adonan ini lengket karena tidak di uleni. Untuk bentuk roti unyil sebaiknya yg simpel saja, tangan jg harus di lumuri terigu. Tapi jgn terlalu banyak terigu, roti bs jadi keras. Tipis2 saja."
- "Memanggang roti bagusnya mmg api atas dan bawah. Kalau bawah saja, kdg bawah roti sudah coklat tp atasnya msh pucat. Olesan kuning telur bs membantu membuat warna roti lebih kuning."
categories:
- Recipe
tags:
- roti
- unyil
- tanpa

katakunci: roti unyil tanpa 
nutrition: 203 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Lunch

---


![Roti Unyil (Tanpa Ulen)](https://img-global.cpcdn.com/recipes/1f9b5c2618f99fa0/680x482cq70/roti-unyil-tanpa-ulen-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga renyah. Ciri kuliner Indonesia roti unyil (tanpa ulen) yang kaya dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah memasak Roti Unyil (Tanpa Ulen) untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang dapat anda buat salah satunya roti unyil (tanpa ulen) yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep roti unyil (tanpa ulen) tanpa harus bersusah payah.
Seperti resep Roti Unyil (Tanpa Ulen) yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 13 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Unyil (Tanpa Ulen):

1. Diperlukan 450 gram terigu cakra
1. Jangan lupa 1 butir telur, kocok lepas
1. Tambah 300 ml susu cair full cream hangat
1. Diperlukan 50 gram gula pasir
1. Harap siapkan 1 sdt garam
1. Jangan lupa 2 sdt ragi instan
1. Dibutuhkan 60 gram butter, saya Anchor
1. Siapkan  untuk olesan sblm oven: kuning telur/putih telur/susu cair
1. Jangan lupa  untuk isi: meisis, keju, sosis, nutella dll
1. Harus ada  untuk olesan setelah keluar oven: butter




<!--inarticleads2-->

##### Cara membuat  Roti Unyil (Tanpa Ulen):

1. Aktifkan ragi. Campur 50ml susu hangat dengan ragi, aduk rata. Tambahkan 1sdm gula pasir. Diamkan 5-8 menit hingga berbuih. Tanda ragi aktif.
1. Siapkan wadah, campir terigu yg sudah di ayak, garam dan gula pasir. Aduk rata.
1. Masukan butter, remas2 dgn tangan hingga adonan scrumble.
1. Masukan kocokan telur, cairan ragi, dan sisa susu cair yg 250ml. Aduk rata dgn tangan.
1. Bersihkan tangan dengan spatula. Bentuk bulat adonan. Tutup plastik wrap, dan kain kering. Diamkan 1 jam hingga mengembang.
1. Setelah mengembang, aduk2 dgn spatula hingga adonan kempis lagi. Diamkan 20 menit.
1. Lalukan proses ini 2-3x. Saya 3x@20 menit.
1. Keluarkan adonan dr wadah, alasi terigu. Tepuk2 adonan dengan terigu agar tidak lengket.
1. Timbang @25 gram, bentuk dan isi sesuai selera. Diamkan lagi 15 menit, biarkan mengembang.
1. Olesi dgn bahan oles. Loyang olesi dgn margarin/alasi baking sheet.
1. Panggang 180&#39;C 15 menit, atau sesuaikan kondisi oven masing2. Jangan over bake ya nanti rotinya keras.
1. Tips: Adonan ini lengket karena tidak di uleni. Untuk bentuk roti unyil sebaiknya yg simpel saja, tangan jg harus di lumuri terigu. Tapi jgn terlalu banyak terigu, roti bs jadi keras. Tipis2 saja.
1. Memanggang roti bagusnya mmg api atas dan bawah. Kalau bawah saja, kdg bawah roti sudah coklat tp atasnya msh pucat. Olesan kuning telur bs membantu membuat warna roti lebih kuning.




Demikianlah cara membuat roti unyil (tanpa ulen) yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan cepat, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
