---
description: "Cara untuk membuat Ayam Kentucky Sambel Pecel Lele minggu ini"
title: "Cara untuk membuat Ayam Kentucky Sambel Pecel Lele minggu ini"
slug: 183-cara-untuk-membuat-ayam-kentucky-sambel-pecel-lele-minggu-ini
date: 2021-01-27T16:58:56.854Z
image: https://img-global.cpcdn.com/recipes/818e47cce4a22d01/680x482cq70/ayam-kentucky-sambel-pecel-lele-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/818e47cce4a22d01/680x482cq70/ayam-kentucky-sambel-pecel-lele-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/818e47cce4a22d01/680x482cq70/ayam-kentucky-sambel-pecel-lele-foto-resep-utama.jpg
author: Alma Neal
ratingvalue: 4.7
reviewcount: 45641
recipeingredient:
- " Bahan utama "
- " ayam potong"
- " minyak goreng"
- " Bahan pelapis "
- " tepung terigu"
- " maizena"
- " royco ayam"
- " telur ayam"
- " air putih"
- " Bumbu halus "
- " bawang putih"
- " royco ayam"
- " garam"
- " merica bubuk"
recipeinstructions:
- "Cuci bersih ayam yang sudah di potong kemudian lumuri dengan bumbu yang sudah di haluskan hingga merata kemudian ungkep sebentar di wajan. Setelah di ungkep angkat lalu tiriskan."
- "Kemudian siapkan bahan pelapis, tuangkan telur yang sudah di kocok tuangkan ke ayam aduk rata sedikit di pijat, bisa juga diganti dengan susu cair."
- "Masukan ayam ke adonan bahan tepung pelapis lalu celupkan ke dalam air 1 liter tadi selama 3 detik, segera masukan lagi kedalam tepung pelapis, pijat-pijat pelan sampai keriting."
- "Lalu masukan ayam yang sudah keriting ke dalam minyak goreng yang sudah dipanaskan, goreng dengan api kecil hingga bewarna kuning kecoklatan segera angkat dan tiriskan."
- "Lakukan sampai ayam habis, jika sudah siap disajikan menggunakan sambal pecel lele yang sudah di sediakan."
categories:
- Recipe
tags:
- ayam
- kentucky
- sambel

katakunci: ayam kentucky sambel 
nutrition: 283 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Kentucky Sambel Pecel Lele](https://img-global.cpcdn.com/recipes/818e47cce4a22d01/680x482cq70/ayam-kentucky-sambel-pecel-lele-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas dan gurih. Ciri kuliner Nusantara ayam kentucky sambel pecel lele yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan keluarga bisa ditemukan dengan cara simple. Diantaranya adalah memasak Ayam Kentucky Sambel Pecel Lele untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang bisa anda praktekkan salah satunya ayam kentucky sambel pecel lele yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep ayam kentucky sambel pecel lele tanpa harus bersusah payah.
Seperti resep Ayam Kentucky Sambel Pecel Lele yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 14 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Kentucky Sambel Pecel Lele:

1. Siapkan  Bahan utama :
1. Harus ada  ayam potong
1. Harap siapkan  minyak goreng
1. Tambah  Bahan pelapis :
1. Harap siapkan  tepung terigu
1. Tambah  maizena
1. Siapkan  royco ayam
1. Harap siapkan  telur ayam
1. Tambah  air putih
1. Harus ada  Bumbu halus :
1. Tambah  bawang putih
1. Diperlukan  royco ayam
1. Diperlukan  garam
1. Diperlukan  merica bubuk




<!--inarticleads2-->

##### Langkah membuat  Ayam Kentucky Sambel Pecel Lele:

1. Cuci bersih ayam yang sudah di potong kemudian lumuri dengan bumbu yang sudah di haluskan hingga merata kemudian ungkep sebentar di wajan. Setelah di ungkep angkat lalu tiriskan.
1. Kemudian siapkan bahan pelapis, tuangkan telur yang sudah di kocok tuangkan ke ayam aduk rata sedikit di pijat, bisa juga diganti dengan susu cair.
1. Masukan ayam ke adonan bahan tepung pelapis lalu celupkan ke dalam air 1 liter tadi selama 3 detik, segera masukan lagi kedalam tepung pelapis, pijat-pijat pelan sampai keriting.
1. Lalu masukan ayam yang sudah keriting ke dalam minyak goreng yang sudah dipanaskan, goreng dengan api kecil hingga bewarna kuning kecoklatan segera angkat dan tiriskan.
1. Lakukan sampai ayam habis, jika sudah siap disajikan menggunakan sambal pecel lele yang sudah di sediakan.




Demikianlah cara membuat ayam kentucky sambel pecel lele yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat gampang dan terbukti, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
