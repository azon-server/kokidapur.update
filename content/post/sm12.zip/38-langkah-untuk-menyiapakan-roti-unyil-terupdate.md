---
description: "Langkah untuk menyiapakan Roti Unyil terupdate"
title: "Langkah untuk menyiapakan Roti Unyil terupdate"
slug: 38-langkah-untuk-menyiapakan-roti-unyil-terupdate
date: 2020-12-02T04:58:32.211Z
image: https://img-global.cpcdn.com/recipes/517fc1be7ea42832/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/517fc1be7ea42832/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/517fc1be7ea42832/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Lula Nichols
ratingvalue: 4.1
reviewcount: 38065
recipeingredient:
- " Bahan A"
- " tepung terigu protein tinggi"
- " ragi instan"
- " gula pasir"
- " susu bubuk"
- " Bahan B "
- " telur 25gr untuk adonan dan sisanya untuk egg wash"
- " air"
- " susu"
- " Bahan C "
- " margarine"
- " garam"
recipeinstructions:
- "Campur bahan A tambahkan bahan B, aduk dengan mixer slow speed sampai semua bahan kering tercampur"
- "Ketika semua bahan kering tidak ada lagi yang menempel di mangkok ubah menjadi fast speed sampai setengah kalis. Kalau adonan mulai halus, stop mixer sebentar dan tambahkan bahan C (mentega harus sudah lembut tapi tidak cair)"
- "Aduk kembali sampai mentega tercampur rata dan adonan menjadi mengkilap. Untuk tahu kalau adonan sudah ready boleh di test dengan window pane (ambil sedikit adonan, bulatkan, lalu tarik tarik dengan jari sampai bisa stretch tanpa merobek adonan). Tutup mangkok dan simpan di tempat lembab dan hangat kira-kira 1 jam sampai ukuran mengembang 2x lipat."
- "Setelah mengembang 2xnya kempeskan adonan dan bagi menjadi beberapa bagian adonan sama besar @20gr. Bentuk sesuai keinginan."
- "Bisa diisi coklat dan keju gulung dan gunting bagian atasnya tp jgn sampe putus"
- "Beri isian meses lalu bentuk bulat dan taburin dengan meses di atasnya"
- "Gilas adonan dan beri isian meses lalu gilas lagi dan potong setengah bagian dan gulung dan bentuk menjadi lingkaran"
- "Bagi adonan menjadi 3 bagian dan kepang adonan"
- "Beri isian sosis dan gulung dan potong bagian atasnya jangan sampe putus"
- "Ambil setengah bagian sosis dan taruh di atas adonan lalu gulung kemudian potong-potong jangan sampe putus dan tarik sejajar tiap potongan membentuk seperti papan bermata sosis"
- "Ambil adonan isi dengan meses lalu tutup kembali sampe rapat kemudian potong menjadi 4 bagian dan potong lagi 4 bagian sehingga menyerupai bunga"
- "Setelah semua adonan terbentuk letakkan di loyang. Beri jarak. Simpan kembali di tempat hangat dan lembab (tidak usah ditutup) kira-kira 20 menit."
- "Panaskan oven 175⁰C. Kalau adonan mulai terlihat agak transparant. Oleskan egg wash dan bakar 15 menit. Putar bila warna tidak merata. Setelah matang angkat dan siap di nikmatin. Selamat mencoba"
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 208 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Dessert

---


![Roti Unyil](https://img-global.cpcdn.com/recipes/517fc1be7ea42832/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti roti unyil yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa kesan tersendiri yang merupakan keragaman Kita

Kedekatan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah memasak Roti Unyil untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang bisa anda buat salah satunya roti unyil yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep roti unyil tanpa harus bersusah payah.
Seperti resep Roti Unyil yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 13 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Unyil:

1. Jangan lupa  Bahan A:
1. Jangan lupa  tepung terigu protein tinggi
1. Harus ada  ragi instan
1. Jangan lupa  gula pasir
1. Diperlukan  susu bubuk
1. Tambah  Bahan B :
1. Diperlukan  telur (25gr untuk adonan dan sisanya untuk egg wash)
1. Jangan lupa  air
1. Jangan lupa  susu
1. Harus ada  Bahan C :
1. Jangan lupa  margarine
1. Jangan lupa  garam




<!--inarticleads2-->

##### Cara membuat  Roti Unyil:

1. Campur bahan A tambahkan bahan B, aduk dengan mixer slow speed sampai semua bahan kering tercampur
1. Ketika semua bahan kering tidak ada lagi yang menempel di mangkok ubah menjadi fast speed sampai setengah kalis. Kalau adonan mulai halus, stop mixer sebentar dan tambahkan bahan C (mentega harus sudah lembut tapi tidak cair)
1. Aduk kembali sampai mentega tercampur rata dan adonan menjadi mengkilap. Untuk tahu kalau adonan sudah ready boleh di test dengan window pane (ambil sedikit adonan, bulatkan, lalu tarik tarik dengan jari sampai bisa stretch tanpa merobek adonan). Tutup mangkok dan simpan di tempat lembab dan hangat kira-kira 1 jam sampai ukuran mengembang 2x lipat.
1. Setelah mengembang 2xnya kempeskan adonan dan bagi menjadi beberapa bagian adonan sama besar @20gr. Bentuk sesuai keinginan.
1. Bisa diisi coklat dan keju gulung dan gunting bagian atasnya tp jgn sampe putus
1. Beri isian meses lalu bentuk bulat dan taburin dengan meses di atasnya
1. Gilas adonan dan beri isian meses lalu gilas lagi dan potong setengah bagian dan gulung dan bentuk menjadi lingkaran
1. Bagi adonan menjadi 3 bagian dan kepang adonan
1. Beri isian sosis dan gulung dan potong bagian atasnya jangan sampe putus
1. Ambil setengah bagian sosis dan taruh di atas adonan lalu gulung kemudian potong-potong jangan sampe putus dan tarik sejajar tiap potongan membentuk seperti papan bermata sosis
1. Ambil adonan isi dengan meses lalu tutup kembali sampe rapat kemudian potong menjadi 4 bagian dan potong lagi 4 bagian sehingga menyerupai bunga
1. Setelah semua adonan terbentuk letakkan di loyang. Beri jarak. Simpan kembali di tempat hangat dan lembab (tidak usah ditutup) kira-kira 20 menit.
1. Panaskan oven 175⁰C. Kalau adonan mulai terlihat agak transparant. Oleskan egg wash dan bakar 15 menit. Putar bila warna tidak merata. Setelah matang angkat dan siap di nikmatin. Selamat mencoba




Demikianlah cara membuat roti unyil yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan cepat, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
