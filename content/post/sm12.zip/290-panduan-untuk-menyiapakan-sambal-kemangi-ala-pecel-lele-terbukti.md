---
description: "Panduan untuk menyiapakan Sambal Kemangi ala Pecel Lele Terbukti"
title: "Panduan untuk menyiapakan Sambal Kemangi ala Pecel Lele Terbukti"
slug: 290-panduan-untuk-menyiapakan-sambal-kemangi-ala-pecel-lele-terbukti
date: 2020-12-23T00:13:08.597Z
image: https://img-global.cpcdn.com/recipes/ba3b7cb42bc8e30a/680x482cq70/sambal-kemangi-ala-pecel-lele-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ba3b7cb42bc8e30a/680x482cq70/sambal-kemangi-ala-pecel-lele-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ba3b7cb42bc8e30a/680x482cq70/sambal-kemangi-ala-pecel-lele-foto-resep-utama.jpg
author: Gordon Manning
ratingvalue: 4
reviewcount: 19300
recipeingredient:
- "20 buah cabe rawit merah diirisiris"
- "1 sdt terasi bakar me  skip"
- "3 siung bawang putih irisiris"
- "5 tangkai kemangi petik daunnya saja"
- "1 1/2 tomat merah"
- " Garam"
- " Gula skip"
- "5 sdm minyak"
recipeinstructions:
- "Siapkan cabe saya pakai cabe keriting 10 buah. Cabe rawit merah 5 buah dan cabe rawit hijau 5 buah."
- "Goreng bawang putih yang sudah diiris-iris menggunakan minyak. Sampai harum dan kekuningan. Angkat dan sisihkan."
- "Goreng cabe merah yang sudah diiris-iris dengan minyak ketika harum masukkan tomat. Masak sebentar sampai tomat layu kemudian masukkan daun kemangi. Masak sampai kemangi layu. Matikan ati."
- "Campur tumisan cabe, tomat, kemangi dan bawang putih, ulek sampai tingkat kehalusan yang diinginkan atau blender sebentar sampai cabe terlihat hancur. Beri garam dan tes rasa. Sajikan"
categories:
- Recipe
tags:
- sambal
- kemangi
- ala

katakunci: sambal kemangi ala 
nutrition: 186 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Lunch

---


![Sambal Kemangi ala Pecel Lele](https://img-global.cpcdn.com/recipes/ba3b7cb42bc8e30a/680x482cq70/sambal-kemangi-ala-pecel-lele-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis dan empuk. Ciri khas kuliner Indonesia sambal kemangi ala pecel lele yang kaya dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga bisa didapat dengan cara mudah. Diantaranya adalah membuat makanan Sambal Kemangi ala Pecel Lele untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis makanan yang bisa anda coba salah satunya sambal kemangi ala pecel lele yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep sambal kemangi ala pecel lele tanpa harus bersusah payah.
Seperti resep Sambal Kemangi ala Pecel Lele yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 8 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambal Kemangi ala Pecel Lele:

1. Jangan lupa 20 buah cabe rawit merah, diiris-iris
1. Diperlukan 1 sdt terasi bakar (me : skip)
1. Dibutuhkan 3 siung bawang putih, iris-iris
1. Jangan lupa 5 tangkai kemangi petik daunnya saja
1. Tambah 1 1/2 tomat merah
1. Jangan lupa  Garam
1. Dibutuhkan  Gula (skip)
1. Tambah 5 sdm minyak




<!--inarticleads2-->

##### Cara membuat  Sambal Kemangi ala Pecel Lele:

1. Siapkan cabe saya pakai cabe keriting 10 buah. Cabe rawit merah 5 buah dan cabe rawit hijau 5 buah.
1. Goreng bawang putih yang sudah diiris-iris menggunakan minyak. Sampai harum dan kekuningan. Angkat dan sisihkan.
1. Goreng cabe merah yang sudah diiris-iris dengan minyak ketika harum masukkan tomat. Masak sebentar sampai tomat layu kemudian masukkan daun kemangi. Masak sampai kemangi layu. Matikan ati.
1. Campur tumisan cabe, tomat, kemangi dan bawang putih, ulek sampai tingkat kehalusan yang diinginkan atau blender sebentar sampai cabe terlihat hancur. Beri garam dan tes rasa. Sajikan




Demikianlah cara membuat sambal kemangi ala pecel lele yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
