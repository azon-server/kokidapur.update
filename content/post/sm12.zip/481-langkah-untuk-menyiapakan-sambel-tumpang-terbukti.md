---
description: "Langkah untuk menyiapakan Sambel Tumpang Terbukti"
title: "Langkah untuk menyiapakan Sambel Tumpang Terbukti"
slug: 481-langkah-untuk-menyiapakan-sambel-tumpang-terbukti
date: 2021-01-16T05:57:13.661Z
image: https://img-global.cpcdn.com/recipes/9f1168faf0c188c4/680x482cq70/sambel-tumpang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9f1168faf0c188c4/680x482cq70/sambel-tumpang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9f1168faf0c188c4/680x482cq70/sambel-tumpang-foto-resep-utama.jpg
author: Daniel Summers
ratingvalue: 4.5
reviewcount: 31559
recipeingredient:
- "400 gram tempe potong 3 x 3 cm"
- "350 ml santan dengan kekentalan sedang"
- "600 ml air untuk merebus tempe"
- "10 buah tahu gembos potong2"
- " Bumbu halus"
- "5 buah cabai merah keriting"
- "5 buah cabai rawit merah"
- "1 cm kencur"
- "5 siung bawang merah"
- "4 siung bawang putih"
- " Bumbu lain"
- "2 cm lengkuas"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "2 sendok makan gula jawa sisir halus"
- "2 sendok teh garam"
- "1 sdt kaldu bubuk rasa ayam"
recipeinstructions:
- "Masukkan santan segar (saya pakai 3 sdm @fibercreme). Masukkan gula, garam, kaldu bubuk rasa ayam @roycoindonesia,tahu gembos dan masak sambal dengan api sedang sambil sesekali diaduk hingga mendidih, santan matang dan harum."
- "Siapkan panci kecil, masukkan semua bumbu yang akan dihaluskan kedalam panci, tambahkan 400 ml air dan rebus hingga mendidih, bumbu empuk dan matang. Angkat dan tiriskan, buang air rebusannya. Haluskan bumbu. Sisihkan."
- "Siapkan panci, masukkan potongan tempe, daun salam, lengkuas, dan daun jeruk, tambahkan 600 ml air dan rebus hingga mendidih dan air berkurang hingga setengahnya. Angkat dari kompor, jangan buang air rebusan,"
- "Tiriskan tempe dan tumbuk kasar di ulekan secara manual. Jika air rebusan dipanci masih banyak maka ambil saja sekitar 200 ml air. Masukkan tempe tumbuk, bumbu halus dan air rebusan ke panci."
- "Cicipi rasanya. Jika terlalu encer maka masak hingga sambal agak kental, namun jika terlalu kental maka tambahkan air panas."
categories:
- Recipe
tags:
- sambel
- tumpang

katakunci: sambel tumpang 
nutrition: 126 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Dessert

---


![Sambel Tumpang](https://img-global.cpcdn.com/recipes/9f1168faf0c188c4/680x482cq70/sambel-tumpang-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas atau gurih. Ciri khas makanan Indonesia sambel tumpang yang penuh dengan rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kehangatan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah memasak Sambel Tumpang untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang bisa anda buat salah satunya sambel tumpang yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep sambel tumpang tanpa harus bersusah payah.
Seperti resep Sambel Tumpang yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambel Tumpang:

1. Siapkan 400 gram tempe, potong 3 x 3 cm
1. Diperlukan 350 ml santan dengan kekentalan sedang
1. Diperlukan 600 ml air untuk merebus tempe
1. Tambah 10 buah tahu gembos potong2
1. Jangan lupa  Bumbu halus:
1. Harap siapkan 5 buah cabai merah keriting
1. Diperlukan 5 buah cabai rawit merah
1. Tambah 1 cm kencur
1. Tambah 5 siung bawang merah
1. Diperlukan 4 siung bawang putih
1. Dibutuhkan  Bumbu lain:
1. Diperlukan 2 cm lengkuas
1. Harap siapkan 3 lembar daun salam
1. Jangan lupa 3 lembar daun jeruk
1. Jangan lupa 2 sendok makan gula jawa sisir halus
1. Jangan lupa 2 sendok teh garam
1. Dibutuhkan 1 sdt kaldu bubuk rasa ayam




<!--inarticleads2-->

##### Instruksi membuat  Sambel Tumpang:

1. Masukkan santan segar (saya pakai 3 sdm @fibercreme). Masukkan gula, garam, kaldu bubuk rasa ayam @roycoindonesia,tahu gembos dan masak sambal dengan api sedang sambil sesekali diaduk hingga mendidih, santan matang dan harum.
1. Siapkan panci kecil, masukkan semua bumbu yang akan dihaluskan kedalam panci, tambahkan 400 ml air dan rebus hingga mendidih, bumbu empuk dan matang. Angkat dan tiriskan, buang air rebusannya. Haluskan bumbu. Sisihkan.
1. Siapkan panci, masukkan potongan tempe, daun salam, lengkuas, dan daun jeruk, tambahkan 600 ml air dan rebus hingga mendidih dan air berkurang hingga setengahnya. Angkat dari kompor, jangan buang air rebusan,
1. Tiriskan tempe dan tumbuk kasar di ulekan secara manual. Jika air rebusan dipanci masih banyak maka ambil saja sekitar 200 ml air. Masukkan tempe tumbuk, bumbu halus dan air rebusan ke panci.
1. Cicipi rasanya. Jika terlalu encer maka masak hingga sambal agak kental, namun jika terlalu kental maka tambahkan air panas.




Demikianlah cara membuat sambel tumpang yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
