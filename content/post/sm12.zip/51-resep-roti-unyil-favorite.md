---
description: "Resep : Roti Unyil Favorite"
title: "Resep : Roti Unyil Favorite"
slug: 51-resep-roti-unyil-favorite
date: 2020-11-24T00:52:06.546Z
image: https://img-global.cpcdn.com/recipes/0ba2d16148d36e24/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0ba2d16148d36e24/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0ba2d16148d36e24/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Clyde Carlson
ratingvalue: 4.8
reviewcount: 13475
recipeingredient:
- " tepung terigu protein tinggi"
- " susu bubuk"
- " kentang kukus haluskan berat setelah dikukus"
- " gula pasir"
- " ragi instan"
- " telur"
- " susu cair"
- " butter"
- " garam"
recipeinstructions:
- "Dalam wadah masukkan terigu protein tinggi, kentang, gula, ragi instant, susu bubuk, dan telur aduk rata. Tuangi susu cair sedikit demi sedikit sampai konsistensi yang diinginkan (stop jika sudah pas) uleni sampai setengah kalis  masukkan butter dan garam."
- "Uleni lagi sampai kalis elastic. saya dibantu hand mixer. 😁 Bulatkan adonan taruh di wadah lalu tutup dengan plastik wrap atau kain bersih lembab (saya tutup pake tutup panci 🙏😊)"
- "Diamkan sampai mengembang 2x lipat, diamkan selama 40 menit (saya kurleb 1 jam) Lalu kempeskan uleni sebentar Bagi adonan menjadi 20 buah @25 g/perbuah"
- "Bentuk2 sesuai selera. Saya blm bisa secantik bentuk rotinya mb Fitri 🙏😊. Tutup dengan plastik wrap (saya dengan kain serbet bersih) biarkan selama 15-20menit sampai mengembang lagi, silakan dioles dengan susu cair (bisa juga pakai kuning telur dan susu cair)"
- "Panaskan oven suhu 170 derajad lalu panggang selama 20-25 menit (sesuaikan oven masing2). Karena oven saya kecil, jadinya roti unyilnya mepet banget di loyang 🤭. Keluarkan dari oven, oles dengan butter. Sajikan"
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 296 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dessert

---


![Roti Unyil](https://img-global.cpcdn.com/recipes/0ba2d16148d36e24/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga gurih. Karasteristik makanan Nusantara roti unyil yang kaya dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga dapat diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Roti Unyil untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang dapat anda coba salah satunya roti unyil yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep roti unyil tanpa harus bersusah payah.
Seperti resep Roti Unyil yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Unyil:

1. Dibutuhkan  tepung terigu protein tinggi
1. Harap siapkan  susu bubuk
1. Siapkan  kentang (kukus, haluskan) &gt;berat setelah dikukus
1. Diperlukan  gula pasir
1. Harus ada  ragi instan
1. Dibutuhkan  telur
1. Harap siapkan  susu cair
1. Harap siapkan  butter
1. Diperlukan  garam




<!--inarticleads2-->

##### Cara membuat  Roti Unyil:

1. Dalam wadah masukkan terigu protein tinggi, kentang, gula, ragi instant, susu bubuk, dan telur aduk rata. Tuangi susu cair sedikit demi sedikit sampai konsistensi yang diinginkan (stop jika sudah pas) uleni sampai setengah kalis  - masukkan butter dan garam.
1. Uleni lagi sampai kalis elastic. saya dibantu hand mixer. 😁 - Bulatkan adonan taruh di wadah lalu tutup dengan plastik wrap atau kain bersih lembab (saya tutup pake tutup panci 🙏😊)
1. Diamkan sampai mengembang 2x lipat, diamkan selama 40 menit (saya kurleb 1 jam) Lalu kempeskan uleni sebentar - Bagi adonan menjadi 20 buah @25 g/perbuah
1. Bentuk2 sesuai selera. Saya blm bisa secantik bentuk rotinya mb Fitri 🙏😊. Tutup dengan plastik wrap (saya dengan kain serbet bersih) biarkan selama 15-20menit sampai mengembang lagi, silakan dioles dengan susu cair (bisa juga pakai kuning telur dan susu cair)
1. Panaskan oven suhu 170 derajad lalu panggang selama 20-25 menit (sesuaikan oven masing2). Karena oven saya kecil, jadinya roti unyilnya mepet banget di loyang 🤭. - Keluarkan dari oven, oles dengan butter. Sajikan




Demikianlah cara membuat roti unyil yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan terbukti, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
