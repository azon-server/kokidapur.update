---
description: "Resep : Roti Unyil (Tanpa Ulen) Luar biasa"
title: "Resep : Roti Unyil (Tanpa Ulen) Luar biasa"
slug: 19-resep-roti-unyil-tanpa-ulen-luar-biasa
date: 2021-01-31T03:41:36.116Z
image: https://img-global.cpcdn.com/recipes/1f9b5c2618f99fa0/680x482cq70/roti-unyil-tanpa-ulen-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1f9b5c2618f99fa0/680x482cq70/roti-unyil-tanpa-ulen-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1f9b5c2618f99fa0/680x482cq70/roti-unyil-tanpa-ulen-foto-resep-utama.jpg
author: Antonio Rhodes
ratingvalue: 4.7
reviewcount: 5701
recipeingredient:
- " terigu cakra"
- " telur kocok lepas"
- " susu cair full cream hangat"
- " gula pasir"
- " garam"
- " ragi instan"
- " butter saya Anchor"
- " untuk olesan sblm oven kuning telurputih telursusu cair"
- " untuk isi meisis keju sosis nutella dll"
- " untuk olesan setelah keluar oven butter"
recipeinstructions:
- "Aktifkan ragi. Campur 50ml susu hangat dengan ragi, aduk rata. Tambahkan 1sdm gula pasir. Diamkan 5-8 menit hingga berbuih. Tanda ragi aktif."
- "Siapkan wadah, campir terigu yg sudah di ayak, garam dan gula pasir. Aduk rata."
- "Masukan butter, remas2 dgn tangan hingga adonan scrumble."
- "Masukan kocokan telur, cairan ragi, dan sisa susu cair yg 250ml. Aduk rata dgn tangan."
- "Bersihkan tangan dengan spatula. Bentuk bulat adonan. Tutup plastik wrap, dan kain kering. Diamkan 1 jam hingga mengembang."
- "Setelah mengembang, aduk2 dgn spatula hingga adonan kempis lagi. Diamkan 20 menit."
- "Lalukan proses ini 2-3x. Saya 3x@20 menit."
- "Keluarkan adonan dr wadah, alasi terigu. Tepuk2 adonan dengan terigu agar tidak lengket."
- "Timbang @25 gram, bentuk dan isi sesuai selera. Diamkan lagi 15 menit, biarkan mengembang."
- "Olesi dgn bahan oles. Loyang olesi dgn margarin/alasi baking sheet."
- "Panggang 180&#39;C 15 menit, atau sesuaikan kondisi oven masing2. Jangan over bake ya nanti rotinya keras."
- "Tips: Adonan ini lengket karena tidak di uleni. Untuk bentuk roti unyil sebaiknya yg simpel saja, tangan jg harus di lumuri terigu. Tapi jgn terlalu banyak terigu, roti bs jadi keras. Tipis2 saja."
- "Memanggang roti bagusnya mmg api atas dan bawah. Kalau bawah saja, kdg bawah roti sudah coklat tp atasnya msh pucat. Olesan kuning telur bs membantu membuat warna roti lebih kuning."
categories:
- Recipe
tags:
- roti
- unyil
- tanpa

katakunci: roti unyil tanpa 
nutrition: 204 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Lunch

---


![Roti Unyil (Tanpa Ulen)](https://img-global.cpcdn.com/recipes/1f9b5c2618f99fa0/680x482cq70/roti-unyil-tanpa-ulen-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti roti unyil (tanpa ulen) yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan ciri khas yang merupakan keragaman Nusantara

Keharmonisan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah memasak Roti Unyil (Tanpa Ulen) untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang bisa anda buat salah satunya roti unyil (tanpa ulen) yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep roti unyil (tanpa ulen) tanpa harus bersusah payah.
Berikut ini resep Roti Unyil (Tanpa Ulen) yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 13 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Unyil (Tanpa Ulen):

1. Tambah  terigu cakra
1. Harap siapkan  telur, kocok lepas
1. Diperlukan  susu cair full cream hangat
1. Harus ada  gula pasir
1. Jangan lupa  garam
1. Siapkan  ragi instan
1. Tambah  butter, saya Anchor
1. Diperlukan  untuk olesan sblm oven: kuning telur/putih telur/susu cair
1. Jangan lupa  untuk isi: meisis, keju, sosis, nutella dll
1. Siapkan  untuk olesan setelah keluar oven: butter




<!--inarticleads2-->

##### Langkah membuat  Roti Unyil (Tanpa Ulen):

1. Aktifkan ragi. Campur 50ml susu hangat dengan ragi, aduk rata. Tambahkan 1sdm gula pasir. Diamkan 5-8 menit hingga berbuih. Tanda ragi aktif.
1. Siapkan wadah, campir terigu yg sudah di ayak, garam dan gula pasir. Aduk rata.
1. Masukan butter, remas2 dgn tangan hingga adonan scrumble.
1. Masukan kocokan telur, cairan ragi, dan sisa susu cair yg 250ml. Aduk rata dgn tangan.
1. Bersihkan tangan dengan spatula. Bentuk bulat adonan. Tutup plastik wrap, dan kain kering. Diamkan 1 jam hingga mengembang.
1. Setelah mengembang, aduk2 dgn spatula hingga adonan kempis lagi. Diamkan 20 menit.
1. Lalukan proses ini 2-3x. Saya 3x@20 menit.
1. Keluarkan adonan dr wadah, alasi terigu. Tepuk2 adonan dengan terigu agar tidak lengket.
1. Timbang @25 gram, bentuk dan isi sesuai selera. Diamkan lagi 15 menit, biarkan mengembang.
1. Olesi dgn bahan oles. Loyang olesi dgn margarin/alasi baking sheet.
1. Panggang 180&#39;C 15 menit, atau sesuaikan kondisi oven masing2. Jangan over bake ya nanti rotinya keras.
1. Tips: Adonan ini lengket karena tidak di uleni. Untuk bentuk roti unyil sebaiknya yg simpel saja, tangan jg harus di lumuri terigu. Tapi jgn terlalu banyak terigu, roti bs jadi keras. Tipis2 saja.
1. Memanggang roti bagusnya mmg api atas dan bawah. Kalau bawah saja, kdg bawah roti sudah coklat tp atasnya msh pucat. Olesan kuning telur bs membantu membuat warna roti lebih kuning.




Demikianlah cara membuat roti unyil (tanpa ulen) yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
