---
description: "Cara membuat Roti Unyil Homemade"
title: "Cara membuat Roti Unyil Homemade"
slug: 110-cara-membuat-roti-unyil-homemade
date: 2020-09-30T23:57:32.924Z
image: https://img-global.cpcdn.com/recipes/3a788b30313be67b/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3a788b30313be67b/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3a788b30313be67b/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Landon Shelton
ratingvalue: 4.4
reviewcount: 15449
recipeingredient:
- "250 gram tepung cakra kembar"
- "1 buah telur ayam suhu ruang"
- "125 ml susu cair dingin"
- "5 gram ragi"
- "45 gram gula pasir"
- "1 sachet susu bubuk saya pakai Dancow"
- "50 gram margarin"
- "Sejumput garam"
- " Toppingisian"
- " Keju"
- " Sosis"
- " Ceres"
- " Olesan"
- "1 sdm margarin dioles setelah keluar dr oven"
- "50 ml susu cair dioles sebelum masuk oven"
recipeinstructions:
- "Campur tepung, ragi, susu bubuk, gula pasir dan telur. Untuk susu tuang perlahan sambil diuleni/mixer, jika dirasa sudah cukup lembek, distop saja. Karena bergantung pada ukuran telur juga. Uleni semua hingga setengah kalis. Lalu tambahkan garam dan mentega, lanjut uleni hingga kalis elastis, saat ditarik tipis adonan tidak sobek. Bulatkan adonan taruh dimangkuk dan tutup dengan lap basah atau plastik wrap. Diamkan selama 15 menit."
- "Adonan saya timbang setelah mengembang sekitar 550 gram. Bagi adonan kecil-kecil sesuai selera (saya 12 gram dan ada 1 roti ukuran besar sisanya) setelah ditimbang, bulatkan adonan kecil dan baru bisa dibentuk sesuai selera."
- "Setelah selesai dibentuk dan diberi isian sesuai selera, olesi dengan susu cair kemudian panggang dalam oven dengan suhu 180° sekitar 12 menit. Langsung olesi dengan mentega ketika baru keluar dari oven."
- "Tips: ketika akan membagi menjadi adonan kecil, lebih baik lakukan sebagian dulu, sebagian lagi tetap dibungkus plastik wrap. Agar adonan tidak kering dan tetap lembap."
- "Untuk isian roti yg saya buat saya memotong 1 sosis menjadi 8 buah untuk isian sosis keju. Memotong 1 sosis menjadi 4 buah untuk isian sosis saja. Memotong keju panjang seukuran sosis, dan sebagian saya parut untuk isian keju juga isian keju coklat."
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 193 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Dinner

---


![Roti Unyil](https://img-global.cpcdn.com/recipes/3a788b30313be67b/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan renyah. Karasteristik makanan Indonesia roti unyil yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Roti Unyil untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang dapat anda contoh salah satunya roti unyil yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep roti unyil tanpa harus bersusah payah.
Seperti resep Roti Unyil yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Unyil:

1. Diperlukan 250 gram tepung cakra kembar
1. Tambah 1 buah telur ayam suhu ruang
1. Tambah 125 ml susu cair dingin
1. Dibutuhkan 5 gram ragi
1. Harap siapkan 45 gram gula pasir
1. Jangan lupa 1 sachet susu bubuk (saya pakai Dancow)
1. Harap siapkan 50 gram margarin
1. Diperlukan Sejumput garam
1. Dibutuhkan  Topping/isian
1. Siapkan  Keju
1. Diperlukan  Sosis
1. Siapkan  Ceres
1. Siapkan  Olesan
1. Siapkan 1 sdm margarin, dioles setelah keluar dr oven
1. Harap siapkan 50 ml susu cair, dioles sebelum masuk oven




<!--inarticleads2-->

##### Langkah membuat  Roti Unyil:

1. Campur tepung, ragi, susu bubuk, gula pasir dan telur. Untuk susu tuang perlahan sambil diuleni/mixer, jika dirasa sudah cukup lembek, distop saja. Karena bergantung pada ukuran telur juga. Uleni semua hingga setengah kalis. Lalu tambahkan garam dan mentega, lanjut uleni hingga kalis elastis, saat ditarik tipis adonan tidak sobek. Bulatkan adonan taruh dimangkuk dan tutup dengan lap basah atau plastik wrap. Diamkan selama 15 menit.
1. Adonan saya timbang setelah mengembang sekitar 550 gram. Bagi adonan kecil-kecil sesuai selera (saya 12 gram dan ada 1 roti ukuran besar sisanya) setelah ditimbang, bulatkan adonan kecil dan baru bisa dibentuk sesuai selera.
1. Setelah selesai dibentuk dan diberi isian sesuai selera, olesi dengan susu cair kemudian panggang dalam oven dengan suhu 180° sekitar 12 menit. Langsung olesi dengan mentega ketika baru keluar dari oven.
1. Tips: ketika akan membagi menjadi adonan kecil, lebih baik lakukan sebagian dulu, sebagian lagi tetap dibungkus plastik wrap. Agar adonan tidak kering dan tetap lembap.
1. Untuk isian roti yg saya buat saya memotong 1 sosis menjadi 8 buah untuk isian sosis keju. Memotong 1 sosis menjadi 4 buah untuk isian sosis saja. Memotong keju panjang seukuran sosis, dan sebagian saya parut untuk isian keju juga isian keju coklat.




Demikianlah cara membuat roti unyil yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
