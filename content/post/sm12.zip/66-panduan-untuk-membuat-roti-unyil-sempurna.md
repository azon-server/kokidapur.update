---
description: "Panduan untuk membuat Roti Unyil Sempurna"
title: "Panduan untuk membuat Roti Unyil Sempurna"
slug: 66-panduan-untuk-membuat-roti-unyil-sempurna
date: 2021-02-28T00:24:54.240Z
image: https://img-global.cpcdn.com/recipes/c8ce3891b1023877/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c8ce3891b1023877/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c8ce3891b1023877/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Jimmy Nash
ratingvalue: 4.5
reviewcount: 18000
recipeingredient:
- " Bahan A "
- "50 gr Tepung "
- "200 gr Tepung Cakra"
- "30 gr Susu Bubuk"
- "30 gr Gula Pasir"
- "4 gr Ragi Instan"
- " Bahan B "
- "140 gr UHT Dingin"
- "1 btr Kuning Telur"
- " Bahan C "
- "40 gr Mentega  Butter"
- "secukupnya Garam"
recipeinstructions:
- "Campur bahan A sampai rata, tambahkan bahan B dan C aduk sambil uleni sampai kalis (u/ hasil maksimal gunakan ragi yg baru atau dicek dulu apakah masih aktif atau tidak)"
- "Diamkan adonan tutupi dengan kain basah tunggu 1 jam"
- "Setelah mengembang kempiskan adonan baru dibentuk sesuka hati dan beri isiian sesuai selera"
- "Sebelum dimasukan oven olesi dengan butter dan kuning telur agar warnanya kuning lalu panggang 180° selama kurleb 25 menit"
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 238 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Lunch

---


![Roti Unyil](https://img-global.cpcdn.com/recipes/c8ce3891b1023877/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan renyah. Ciri khas makanan Nusantara roti unyil yang penuh dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Roti Unyil untuk keluarga. Momen makan bersama anak sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang dapat anda contoh salah satunya roti unyil yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep roti unyil tanpa harus bersusah payah.
Berikut ini resep Roti Unyil yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 12 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Unyil:

1. Diperlukan  Bahan A :
1. Tambah 50 gr Tepung ∆
1. Harus ada 200 gr Tepung Cakra
1. Diperlukan 30 gr Susu Bubuk
1. Siapkan 30 gr Gula Pasir
1. Jangan lupa 4 gr Ragi Instan
1. Harus ada  Bahan B :
1. Harus ada 140 gr UHT Dingin
1. Jangan lupa 1 btr Kuning Telur
1. Tambah  Bahan C :
1. Harus ada 40 gr Mentega + Butter
1. Jangan lupa secukupnya Garam




<!--inarticleads2-->

##### Langkah membuat  Roti Unyil:

1. Campur bahan A sampai rata, tambahkan bahan B dan C aduk sambil uleni sampai kalis (u/ hasil maksimal gunakan ragi yg baru atau dicek dulu apakah masih aktif atau tidak)
1. Diamkan adonan tutupi dengan kain basah tunggu 1 jam
1. Setelah mengembang kempiskan adonan baru dibentuk sesuka hati dan beri isiian sesuai selera
1. Sebelum dimasukan oven olesi dengan butter dan kuning telur agar warnanya kuning lalu panggang 180° selama kurleb 25 menit




Demikianlah cara membuat roti unyil yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan teruji, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
