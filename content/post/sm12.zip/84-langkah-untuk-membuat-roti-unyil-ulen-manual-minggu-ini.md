---
description: "Langkah untuk membuat Roti Unyil (Ulen Manual) minggu ini"
title: "Langkah untuk membuat Roti Unyil (Ulen Manual) minggu ini"
slug: 84-langkah-untuk-membuat-roti-unyil-ulen-manual-minggu-ini
date: 2021-03-05T23:18:07.811Z
image: https://img-global.cpcdn.com/recipes/37a6a560cdc9b755/680x482cq70/roti-unyil-ulen-manual-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/37a6a560cdc9b755/680x482cq70/roti-unyil-ulen-manual-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/37a6a560cdc9b755/680x482cq70/roti-unyil-ulen-manual-foto-resep-utama.jpg
author: Leon Maxwell
ratingvalue: 4.2
reviewcount: 15300
recipeingredient:
- "250 gr tepung terigu protein tinggi"
- "1 sdm susu bubuk"
- "100 gr kentang berat setelah dikukushaluskan"
- "1 butir telur"
- "45 gr gula pasir"
- "1/4 sdt garam"
- "40 gr butter"
- "50 ml susu cair"
- "1 sdt ragi instant"
recipeinstructions:
- "Dalam wadah masukkan terigu,susu bubuk,kentang,ragi dan telur,tuangi susu cair sedikit demi sedikit sampai konsistensi yg diinginkan (stop jk sdh pas) uleni sampai setenhah kalis,masukkan butter dan garam."
- "Uleni sampai kalis elastis. Bulatkan adonan taruh di wadah lalu tutup dgn plastik wrap atau kain bersih lembab."
- "Diamkan sampai mengembang 2X lipat selama 40 menit. Lalu kempeskan uleni sebentar. Bagi adonan menjadi 20 buah @25 gr (sy nggak ditimbang adonannya 🙊)"
- "Bentuk sesuai selera beri topping suka2, Kemudian ada kismis, jdnya di jadikan topping 😊😊 tutup dgn plastik wrap,biarkan kurleb 15 - 20 menit sampai mengembang lagi, lalu oles dgn susu cair (pisa jg pakai kuning telur dan susu cair)."
- "Panaskan oven 170 decel (sesuai oven msg2) selama 20 - 25 menit (sy pakai api bawah 15 menit dan api atas 5 menit atau utk memberi efek kining pd roti). Keluarkan dr oven, oles dgn butter. Sajikan."
categories:
- Recipe
tags:
- roti
- unyil
- ulen

katakunci: roti unyil ulen 
nutrition: 203 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT55M"
recipeyield: "2"
recipecategory: Dinner

---


![Roti Unyil (Ulen Manual)](https://img-global.cpcdn.com/recipes/37a6a560cdc9b755/680x482cq70/roti-unyil-ulen-manual-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau empuk. Ciri kuliner Indonesia roti unyil (ulen manual) yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Roti Unyil (Ulen Manual) untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang dapat anda coba salah satunya roti unyil (ulen manual) yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep roti unyil (ulen manual) tanpa harus bersusah payah.
Seperti resep Roti Unyil (Ulen Manual) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 9 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Unyil (Ulen Manual):

1. Siapkan 250 gr tepung terigu protein tinggi
1. Harap siapkan 1 sdm susu bubuk
1. Harap siapkan 100 gr kentang berat setelah dikukus,haluskan
1. Harap siapkan 1 butir telur
1. Jangan lupa 45 gr gula pasir
1. Dibutuhkan 1/4 sdt garam
1. Tambah 40 gr butter
1. Harus ada 50 ml susu cair
1. Tambah 1 sdt ragi instant




<!--inarticleads2-->

##### Cara membuat  Roti Unyil (Ulen Manual):

1. Dalam wadah masukkan terigu,susu bubuk,kentang,ragi dan telur,tuangi susu cair sedikit demi sedikit sampai konsistensi yg diinginkan (stop jk sdh pas) uleni sampai setenhah kalis,masukkan butter dan garam.
1. Uleni sampai kalis elastis. Bulatkan adonan taruh di wadah lalu tutup dgn plastik wrap atau kain bersih lembab.
1. Diamkan sampai mengembang 2X lipat selama 40 menit. Lalu kempeskan uleni sebentar. Bagi adonan menjadi 20 buah @25 gr (sy nggak ditimbang adonannya 🙊)
1. Bentuk sesuai selera beri topping suka2, Kemudian ada kismis, jdnya di jadikan topping 😊😊 tutup dgn plastik wrap,biarkan kurleb 15 - 20 menit sampai mengembang lagi, lalu oles dgn susu cair (pisa jg pakai kuning telur dan susu cair).
1. Panaskan oven 170 decel (sesuai oven msg2) selama 20 - 25 menit (sy pakai api bawah 15 menit dan api atas 5 menit atau utk memberi efek kining pd roti). Keluarkan dr oven, oles dgn butter. Sajikan.




Demikianlah cara membuat roti unyil (ulen manual) yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
