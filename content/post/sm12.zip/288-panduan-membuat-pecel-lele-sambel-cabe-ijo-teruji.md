---
description: "Panduan membuat Pecel lele sambel cabe ijo Teruji"
title: "Panduan membuat Pecel lele sambel cabe ijo Teruji"
slug: 288-panduan-membuat-pecel-lele-sambel-cabe-ijo-teruji
date: 2021-02-02T13:59:40.403Z
image: https://img-global.cpcdn.com/recipes/2ab4689d9497d435/680x482cq70/pecel-lele-sambel-cabe-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2ab4689d9497d435/680x482cq70/pecel-lele-sambel-cabe-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2ab4689d9497d435/680x482cq70/pecel-lele-sambel-cabe-ijo-foto-resep-utama.jpg
author: Nannie Wagner
ratingvalue: 4.1
reviewcount: 16297
recipeingredient:
- "2 ekor lele di rendam dulu pke jerukgaram"
- "15 cabe ijo keriting"
- "10 cabe ijo besar"
- "10 cabe rawit domba"
- "5 bamer"
- "3 baput"
- "2 tomat merah gede"
- " Garamgula secukupnya nya"
recipeinstructions:
- "Cuci lelenya hingga bersih lalu rendem pake jeruk+garam sekitar 5 menit, sambil nunggu kita buat sambel cabe ijo nya"
- "Siapkan semua bahan cabe kriting, cabe gede, rawit, domba, tomat, baput+bamer, cuci semuanya lalu blender hingga halus, siapkan minyak secukupnya dgn api sedang, masukkan semuanya tunggu hingga mengental lalu masukkan gula+garamnya icip rasanya"
- "Untuk lele nya sudah 5 menit di rendam lalu guling2 di tepung goreng kena minyak panas biar kering, angkat jika wrna berubah kecoklatan"
- "Siapkan piring angkat lele taburin sambal cabe ijo nya di atas lele selamat menikmati"
categories:
- Recipe
tags:
- pecel
- lele
- sambel

katakunci: pecel lele sambel 
nutrition: 213 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Lunch

---


![Pecel lele sambel cabe ijo](https://img-global.cpcdn.com/recipes/2ab4689d9497d435/680x482cq70/pecel-lele-sambel-cabe-ijo-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti pecel lele sambel cabe ijo yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan keistimewahan yang merupakan keragaman Kita



Kehangatan keluarga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Pecel lele sambel cabe ijo untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang dapat anda coba salah satunya pecel lele sambel cabe ijo yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep pecel lele sambel cabe ijo tanpa harus bersusah payah.
Berikut ini resep Pecel lele sambel cabe ijo yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 8 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Pecel lele sambel cabe ijo:

1. Diperlukan 2 ekor lele (di rendam dulu pke jeruk+garam)
1. Tambah 15 cabe ijo keriting
1. Harus ada 10 cabe ijo besar
1. Siapkan 10 cabe rawit domba
1. Siapkan 5 bamer
1. Dibutuhkan 3 baput
1. Harap siapkan 2 tomat merah gede
1. Jangan lupa  Garam+gula secukupnya nya




<!--inarticleads2-->

##### Bagaimana membuat  Pecel lele sambel cabe ijo:

1. Cuci lelenya hingga bersih lalu rendem pake jeruk+garam sekitar 5 menit, sambil nunggu kita buat sambel cabe ijo nya
1. Siapkan semua bahan cabe kriting, cabe gede, rawit, domba, tomat, baput+bamer, cuci semuanya lalu blender hingga halus, siapkan minyak secukupnya dgn api sedang, masukkan semuanya tunggu hingga mengental lalu masukkan gula+garamnya icip rasanya
1. Untuk lele nya sudah 5 menit di rendam lalu guling2 di tepung goreng kena minyak panas biar kering, angkat jika wrna berubah kecoklatan
1. Siapkan piring angkat lele taburin sambal cabe ijo nya di atas lele selamat menikmati




Demikianlah cara membuat pecel lele sambel cabe ijo yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan terbukti, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
