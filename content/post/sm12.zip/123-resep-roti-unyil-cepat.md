---
description: "Resep : Roti Unyil Cepat"
title: "Resep : Roti Unyil Cepat"
slug: 123-resep-roti-unyil-cepat
date: 2021-02-11T15:22:52.791Z
image: https://img-global.cpcdn.com/recipes/ce841cfb191ef112/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ce841cfb191ef112/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ce841cfb191ef112/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Ethel Burgess
ratingvalue: 4.2
reviewcount: 25991
recipeingredient:
- " tepung terigu protein tinggi"
- " susu bubuk"
- " kentang kukusberat setelah dikukus"
- " telur segar"
- " gula pasir"
- " garam"
- " butter"
- " susu cair"
- " ragi instan"
recipeinstructions:
- "Siapkan bahan-bahan"
- "Haluskan kentang yg sudah dikukus"
- "Masukkan tepung terigu,susu bubuk, kentang kukus, telur, gula pasir, ragi instan. Aduk sampai rata."
- "Tuang susu cair perlahan sambil diaduk sampai dirasa pas. Kemudian uleni/mixer sampai setengah kalis"
- "Masukkan butter dan garam. Uleni/mixer lg sampai kalis elastis."
- "Setelah kalis elastis melewati windowpane test, bulatkan, tutup dengan plastik wrap/kain bersih lembab. Diamkan sampai mengembang 2x lipat (45 menit-1 jam). Lalu tinju, uleni sebentar."
- "Bagi adonan 25 gr/sesuai selera. Sy @30 gr. Bentuk,beri isian sesuai selera.Setelah itu tutup lg dg plastik wrap. Biarkan sampai mengembang lagi. 15-20 menit. Saya 30 menit."
- "Langkah terakhir sebelum di oven, oles dengan susu cair atau dikombinasikan dengan kuning telur. Oven selama 20-25 menit dengan suhu 170 derajat. Lama pengovenan menyesuaikan oven masing-masing. Jgn lupa, oven dipanaskan dulu sebelumya. Saya 5 menit pertama dg api bawah, sisa dengan api atas bawah."
- "Setelah matang, angkat. Pindah ke cooling rak. Oles dengan butter."
- "Segera masukkan dlm plastik kemasan / toples kedap udara unt menjaga kelembabannya"
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 209 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Dinner

---


![Roti Unyil](https://img-global.cpcdn.com/recipes/ce841cfb191ef112/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis dan renyah. Karasteristik kuliner Nusantara roti unyil yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Keharmonisan rumah tangga bisa didapat dengan cara simple. Diantaranya adalah memasak Roti Unyil untuk orang di rumah. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang dapat anda coba salah satunya roti unyil yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep roti unyil tanpa harus bersusah payah.
Seperti resep Roti Unyil yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Unyil:

1. Jangan lupa  tepung terigu protein tinggi
1. Harus ada  susu bubuk
1. Jangan lupa  kentang kukus(berat setelah dikukus)
1. Dibutuhkan  telur segar
1. Tambah  gula pasir
1. Tambah  garam
1. Dibutuhkan  butter
1. Harus ada  susu cair
1. Harap siapkan  ragi instan




<!--inarticleads2-->

##### Cara membuat  Roti Unyil:

1. Siapkan bahan-bahan
1. Haluskan kentang yg sudah dikukus
1. Masukkan tepung terigu,susu bubuk, kentang kukus, telur, gula pasir, ragi instan. Aduk sampai rata.
1. Tuang susu cair perlahan sambil diaduk sampai dirasa pas. Kemudian uleni/mixer sampai setengah kalis
1. Masukkan butter dan garam. Uleni/mixer lg sampai kalis elastis.
1. Setelah kalis elastis melewati windowpane test, bulatkan, tutup dengan plastik wrap/kain bersih lembab. Diamkan sampai mengembang 2x lipat (45 menit-1 jam). Lalu tinju, uleni sebentar.
1. Bagi adonan 25 gr/sesuai selera. Sy @30 gr. Bentuk,beri isian sesuai selera.Setelah itu tutup lg dg plastik wrap. Biarkan sampai mengembang lagi. 15-20 menit. Saya 30 menit.
1. Langkah terakhir sebelum di oven, oles dengan susu cair atau dikombinasikan dengan kuning telur. Oven selama 20-25 menit dengan suhu 170 derajat. Lama pengovenan menyesuaikan oven masing-masing. Jgn lupa, oven dipanaskan dulu sebelumya. Saya 5 menit pertama dg api bawah, sisa dengan api atas bawah.
1. Setelah matang, angkat. Pindah ke cooling rak. Oles dengan butter.
1. Segera masukkan dlm plastik kemasan / toples kedap udara unt menjaga kelembabannya




Demikianlah cara membuat roti unyil yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
