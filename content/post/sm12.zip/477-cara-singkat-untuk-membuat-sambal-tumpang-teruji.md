---
description: "Cara singkat untuk membuat Sambal Tumpang Teruji"
title: "Cara singkat untuk membuat Sambal Tumpang Teruji"
slug: 477-cara-singkat-untuk-membuat-sambal-tumpang-teruji
date: 2020-10-20T10:55:56.392Z
image: https://img-global.cpcdn.com/recipes/778d3c8bcb42c013/680x482cq70/sambal-tumpang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/778d3c8bcb42c013/680x482cq70/sambal-tumpang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/778d3c8bcb42c013/680x482cq70/sambal-tumpang-foto-resep-utama.jpg
author: Lilly Osborne
ratingvalue: 4.2
reviewcount: 21146
recipeingredient:
- "500 gr tempe semangitbusuk"
- "7 buah cabe merah besar"
- "10 buah cabai rawit"
- "8 butir bawang merah"
- "5 siung bawang putih"
- "4 cm kencur"
- "1/2 sdm ketumbar"
- "2 cm lengkuas"
- "500 ml santan"
- "5 lembar daun salam"
- "250 ml air"
- "Secukupnya gula garam kaldu jamur"
- " Bahan pelengkap "
- " Nasi putih"
- " Rempeyek teri kacang"
- " Sayur kangkung rebus"
- " Taouge rebus"
recipeinstructions:
- "Kukus cabai rawit, cabai merah besar, bawang merah, bawang putih, dan kencur hingga semua layu."
- "Haluskan cabai, bawang, kencur dan tempe yang sudah di kukus sebelumnya serta ketumbar."
- "Campur semua bahan dalam wajan. Tempe dan bumbu yang sudah di haluskan, lengkuas,daun salam, santan dan air."
- "Tambahkan gula, kaldu jamur dan garam. Koreksi rasa. Masak hingga air sedikit menyusut, kental dan minyak dari santan keluar."
- "Sajikan bersama sayuran rebus, rempeyek dan nasi hangat."
categories:
- Recipe
tags:
- sambal
- tumpang

katakunci: sambal tumpang 
nutrition: 197 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dinner

---


![Sambal Tumpang](https://img-global.cpcdn.com/recipes/778d3c8bcb42c013/680x482cq70/sambal-tumpang-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga gurih. Ciri makanan Indonesia sambal tumpang yang penuh dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kedekatan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah memasak Sambal Tumpang untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang bisa anda buat salah satunya sambal tumpang yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep sambal tumpang tanpa harus bersusah payah.
Seperti resep Sambal Tumpang yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambal Tumpang:

1. Dibutuhkan 500 gr tempe semangit/busuk
1. Harap siapkan 7 buah cabe merah besar
1. Harap siapkan 10 buah cabai rawit
1. Jangan lupa 8 butir bawang merah
1. Diperlukan 5 siung bawang putih
1. Harap siapkan 4 cm kencur
1. Harus ada 1/2 sdm ketumbar
1. Harap siapkan 2 cm lengkuas
1. Diperlukan 500 ml santan
1. Harus ada 5 lembar daun salam
1. Dibutuhkan 250 ml air
1. Dibutuhkan Secukupnya gula, garam, kaldu jamur
1. Siapkan  Bahan pelengkap :
1. Harap siapkan  Nasi putih
1. Diperlukan  Rempeyek teri kacang
1. Diperlukan  Sayur kangkung rebus
1. Tambah  Taouge rebus




<!--inarticleads2-->

##### Langkah membuat  Sambal Tumpang:

1. Kukus cabai rawit, cabai merah besar, bawang merah, bawang putih, dan kencur hingga semua layu.
1. Haluskan cabai, bawang, kencur dan tempe yang sudah di kukus sebelumnya serta ketumbar.
1. Campur semua bahan dalam wajan. Tempe dan bumbu yang sudah di haluskan, lengkuas,daun salam, santan dan air.
1. Tambahkan gula, kaldu jamur dan garam. Koreksi rasa. Masak hingga air sedikit menyusut, kental dan minyak dari santan keluar.
1. Sajikan bersama sayuran rebus, rempeyek dan nasi hangat.




Demikianlah cara membuat sambal tumpang yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan terbukti, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
