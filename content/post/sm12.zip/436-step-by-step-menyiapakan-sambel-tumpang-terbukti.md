---
description: "Step-by-Step menyiapakan Sambel Tumpang Terbukti"
title: "Step-by-Step menyiapakan Sambel Tumpang Terbukti"
slug: 436-step-by-step-menyiapakan-sambel-tumpang-terbukti
date: 2020-12-31T23:07:41.901Z
image: https://img-global.cpcdn.com/recipes/44d9de9f05a4c2fc/680x482cq70/sambel-tumpang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/44d9de9f05a4c2fc/680x482cq70/sambel-tumpang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/44d9de9f05a4c2fc/680x482cq70/sambel-tumpang-foto-resep-utama.jpg
author: Floyd Rodriquez
ratingvalue: 4.6
reviewcount: 46353
recipeingredient:
- "2 papan tempe semangit saya diamkan di kulkas selama 4 hari"
- "200 ml santan kental"
- "500 ml santan encer"
- "1 ruas lengkuas geprek"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 sdt garam"
- "1 sdt kaldu bubuk"
- "1/2 sdt gula pasir"
- " Minyak untuk menumis"
- " Bumbu Halus "
- "8 siung bawang putih"
- "15 buah cabe rawit"
- "2 ruas kencur"
- "3 buah cabe merah saya skip ternyata stok cabe merah habis"
recipeinstructions:
- "Panaskan minyak goreng, tumis bumbu halus hingga harum. Tambahkan daun salam, daun jeruk dan lengkuas. Aduk rata."
- "Kemudian masukkan santan encer. Masak hingga mendidih."
- "Ulek kasar tempe semangit, kemudian masukkan ke dalam santan yang sudah mendidih. Bumbui dengan garam, gula pasir, dan kaldu bubuk. Aduk rata, koreksi rasa."
- "Terakhir masukkan santan kental. Biarkan mendidih sebentar. Matikan api."
- "Sajikan hangat."
categories:
- Recipe
tags:
- sambel
- tumpang

katakunci: sambel tumpang 
nutrition: 181 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Dinner

---


![Sambel Tumpang](https://img-global.cpcdn.com/recipes/44d9de9f05a4c2fc/680x482cq70/sambel-tumpang-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga gurih. Ciri masakan Nusantara sambel tumpang yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kehangatan keluarga bisa ditemukan dengan cara simple. Diantaranya adalah membuat makanan Sambel Tumpang untuk keluarga. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang dapat anda buat salah satunya sambel tumpang yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep sambel tumpang tanpa harus bersusah payah.
Seperti resep Sambel Tumpang yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambel Tumpang:

1. Harus ada 2 papan tempe semangit (saya diamkan di kulkas selama 4 hari)
1. Dibutuhkan 200 ml santan kental
1. Harap siapkan 500 ml santan encer
1. Harap siapkan 1 ruas lengkuas (geprek)
1. Dibutuhkan 2 lembar daun salam
1. Diperlukan 2 lembar daun jeruk
1. Jangan lupa 1 sdt garam
1. Tambah 1 sdt kaldu bubuk
1. Harus ada 1/2 sdt gula pasir
1. Tambah  Minyak untuk menumis
1. Siapkan  Bumbu Halus :
1. Tambah 8 siung bawang putih
1. Siapkan 15 buah cabe rawit
1. Dibutuhkan 2 ruas kencur
1. Siapkan 3 buah cabe merah (saya skip, ternyata stok cabe merah habis)




<!--inarticleads2-->

##### Bagaimana membuat  Sambel Tumpang:

1. Panaskan minyak goreng, tumis bumbu halus hingga harum. Tambahkan daun salam, daun jeruk dan lengkuas. Aduk rata.
1. Kemudian masukkan santan encer. Masak hingga mendidih.
1. Ulek kasar tempe semangit, kemudian masukkan ke dalam santan yang sudah mendidih. Bumbui dengan garam, gula pasir, dan kaldu bubuk. Aduk rata, koreksi rasa.
1. Terakhir masukkan santan kental. Biarkan mendidih sebentar. Matikan api.
1. Sajikan hangat.




Demikianlah cara membuat sambel tumpang yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
