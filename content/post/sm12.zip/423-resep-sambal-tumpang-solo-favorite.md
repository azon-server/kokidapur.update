---
description: "Resep : Sambal Tumpang Solo Favorite"
title: "Resep : Sambal Tumpang Solo Favorite"
slug: 423-resep-sambal-tumpang-solo-favorite
date: 2021-03-07T06:16:18.924Z
image: https://img-global.cpcdn.com/recipes/520db53006c9e52d/680x482cq70/sambal-tumpang-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/520db53006c9e52d/680x482cq70/sambal-tumpang-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/520db53006c9e52d/680x482cq70/sambal-tumpang-solo-foto-resep-utama.jpg
author: Jorge Larson
ratingvalue: 4.1
reviewcount: 39698
recipeingredient:
- "1/2 papan tempe semangitpotong2"
- "1/4 papan tempe biasayang masih baguspotong2"
- "3 potong tahu putih"
- "3 siung bw putih"
- "6 btr bw merah"
- "3 bh cabe merah besar"
- "3 cm kencur"
- "1 ltr air"
- "3 btr kemiri sangrai"
- "2 lbr daun jeruk"
- "2 lbr daun salam"
- "1 ruas jempol lengkuasgeprek"
- " Cabe rawit utuh"
- "1 sdt gula merah"
- "1 sdt garam"
- "1 sdt kaldu bubuk"
- "2 sdm santan Kara"
recipeinstructions:
- "Potong tahu kotak2 kecil,goreng,sisihkan. Rebus tempe bersama bw putih+bw merah+cabe merah+kencur dengan 1 ltr air hingga matang."
- "Keluarkan tempe,haluskan. Haluskan juga semua bumbu yang direbus+kemiri."
- "Tumis bumbu halus sampai harum. Masukkan kembali dalam air rebusannya,juga tempe yang sudah dihaluskan+daun salam+daun jeruk+lengkuas. Didihkan kembali."
- "Masukkan tahu goreng dan cabe rawit utuh. Tambahkan garam+gula merah+kaldu bubuk+santan. Cek rasa. Masak sampai kuah agak menyusut,angkat."
categories:
- Recipe
tags:
- sambal
- tumpang
- solo

katakunci: sambal tumpang solo 
nutrition: 101 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Dessert

---


![Sambal Tumpang Solo](https://img-global.cpcdn.com/recipes/520db53006c9e52d/680x482cq70/sambal-tumpang-solo-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang harus kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti sambal tumpang solo yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan ciri khas yang merupakan keragaman Indonesia

Keharmonisan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Sambal Tumpang Solo untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang dapat anda contoh salah satunya sambal tumpang solo yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep sambal tumpang solo tanpa harus bersusah payah.
Seperti resep Sambal Tumpang Solo yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambal Tumpang Solo:

1. Dibutuhkan 1/2 papan tempe semangit,potong2
1. Tambah 1/4 papan tempe biasa,yang masih bagus,potong2
1. Dibutuhkan 3 potong tahu putih
1. Diperlukan 3 siung bw putih
1. Harus ada 6 btr bw merah
1. Dibutuhkan 3 bh cabe merah besar
1. Jangan lupa 3 cm kencur
1. Diperlukan 1 ltr air
1. Siapkan 3 btr kemiri sangrai
1. Diperlukan 2 lbr daun jeruk
1. Siapkan 2 lbr daun salam
1. Harus ada 1 ruas jempol lengkuas,geprek
1. Jangan lupa  Cabe rawit utuh
1. Siapkan 1 sdt gula merah
1. Diperlukan 1 sdt garam
1. Siapkan 1 sdt kaldu bubuk
1. Dibutuhkan 2 sdm santan Kara




<!--inarticleads2-->

##### Instruksi membuat  Sambal Tumpang Solo:

1. Potong tahu kotak2 kecil,goreng,sisihkan. Rebus tempe bersama bw putih+bw merah+cabe merah+kencur dengan 1 ltr air hingga matang.
1. Keluarkan tempe,haluskan. Haluskan juga semua bumbu yang direbus+kemiri.
1. Tumis bumbu halus sampai harum. Masukkan kembali dalam air rebusannya,juga tempe yang sudah dihaluskan+daun salam+daun jeruk+lengkuas. Didihkan kembali.
1. Masukkan tahu goreng dan cabe rawit utuh. Tambahkan garam+gula merah+kaldu bubuk+santan. Cek rasa. Masak sampai kuah agak menyusut,angkat.




Demikianlah cara membuat sambal tumpang solo yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
