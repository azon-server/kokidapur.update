---
description: "Bagaimana membuat Sambel tumpang asli solo teraktual"
title: "Bagaimana membuat Sambel tumpang asli solo teraktual"
slug: 335-bagaimana-membuat-sambel-tumpang-asli-solo-teraktual
date: 2020-10-01T09:32:08.414Z
image: https://img-global.cpcdn.com/recipes/9ed60c7c4d226080/680x482cq70/sambel-tumpang-asli-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9ed60c7c4d226080/680x482cq70/sambel-tumpang-asli-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9ed60c7c4d226080/680x482cq70/sambel-tumpang-asli-solo-foto-resep-utama.jpg
author: Ethel Allison
ratingvalue: 4.4
reviewcount: 5765
recipeingredient:
- "1 potong kecil tempe semangit yg sudah coklat dan bau"
- "1 potong utuh tempe biasa 2x ukuran tempe semangit"
- "1 gelas santan"
- " Tahu Pong  goreng"
- "secukupnya Minyak goreng"
- " Bumbu"
- "4 siung bawang putih"
- "5 siung bawang merah"
- "3 kemiri"
- "1 ruas kencur"
- "5 lembar daun jeruk purut boleh jeruk purutnya"
- "2 ruas lengkuas"
- "3 lembar daun salam"
- "5 biji Lombok rawit merah"
- "10 biji Lombok keriting  besar merah"
- " Garam"
- " Gula pasir jawa"
- " Penyedap rasa"
recipeinstructions:
- "Cuci semua bahan rebus dg air lebih banyak dari bahanya kecuali kencur,kemiri,lengkuas,daun salam,daun jeruk dan tahu"
- "Rebus sampe hampir mau asat airnya kemudian angkat..pilih tempenya dulu di uleg halus sisihkan kemudian uleg bumbunya tambahkan kencur ma kemiri uleg halus"
- "Panaskan minyak lalu gongso bumbu halusnya dulu sampe harum baru kemudian tempe halusnya tambahkan daun jeruk lengkuas daun salam garam gula dan penyedap rasa"
- "Bumbu dan tercampur rata baru tambahkan santan dan tahunya.. masak sampe mendidih tunggu Tanak santanya dan tes rasanya.. taburi bawang goreng kalo ada......dah selesai mudah kan bunda...selamat mencoba dan terima kasih 🙏"
categories:
- Recipe
tags:
- sambel
- tumpang
- asli

katakunci: sambel tumpang asli 
nutrition: 177 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dessert

---


![Sambel tumpang asli solo](https://img-global.cpcdn.com/recipes/9ed60c7c4d226080/680x482cq70/sambel-tumpang-asli-solo-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita lestarikan karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti sambel tumpang asli solo yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa ciri khas yang merupakan keragaman Nusantara



Kedekatan keluarga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Sambel tumpang asli solo untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang bisa anda contoh salah satunya sambel tumpang asli solo yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep sambel tumpang asli solo tanpa harus bersusah payah.
Seperti resep Sambel tumpang asli solo yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambel tumpang asli solo:

1. Harus ada 1 potong kecil tempe semangit (yg sudah coklat dan bau)
1. Dibutuhkan 1 potong utuh tempe biasa (2x ukuran tempe semangit)
1. Harap siapkan 1 gelas santan
1. Diperlukan  Tahu Pong / goreng
1. Harus ada secukupnya Minyak goreng
1. Dibutuhkan  Bumbu
1. Tambah 4 siung bawang putih
1. Jangan lupa 5 siung bawang merah
1. Siapkan 3 kemiri
1. Harus ada 1 ruas kencur
1. Diperlukan 5 lembar daun jeruk purut/ boleh jeruk purutnya
1. Jangan lupa 2 ruas lengkuas
1. Tambah 3 lembar daun salam
1. Diperlukan 5 biji Lombok rawit merah
1. Diperlukan 10 biji Lombok keriting / besar merah
1. Tambah  Garam
1. Harus ada  Gula (pasir/ jawa)
1. Tambah  Penyedap rasa




<!--inarticleads2-->

##### Instruksi membuat  Sambel tumpang asli solo:

1. Cuci semua bahan rebus dg air lebih banyak dari bahanya kecuali kencur,kemiri,lengkuas,daun salam,daun jeruk dan tahu
1. Rebus sampe hampir mau asat airnya kemudian angkat..pilih tempenya dulu di uleg halus sisihkan kemudian uleg bumbunya tambahkan kencur ma kemiri uleg halus
1. Panaskan minyak lalu gongso bumbu halusnya dulu sampe harum baru kemudian tempe halusnya tambahkan daun jeruk lengkuas daun salam garam gula dan penyedap rasa
1. Bumbu dan tercampur rata baru tambahkan santan dan tahunya.. masak sampe mendidih tunggu Tanak santanya dan tes rasanya.. taburi bawang goreng kalo ada......dah selesai mudah kan bunda...selamat mencoba dan terima kasih 🙏




Demikianlah cara membuat sambel tumpang asli solo yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
