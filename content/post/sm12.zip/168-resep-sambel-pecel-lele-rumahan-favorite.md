---
description: "Resep : Sambel Pecel Lele Rumahan Favorite"
title: "Resep : Sambel Pecel Lele Rumahan Favorite"
slug: 168-resep-sambel-pecel-lele-rumahan-favorite
date: 2020-12-09T06:46:27.421Z
image: https://img-global.cpcdn.com/recipes/1b8d16212df6c19b/680x482cq70/sambel-pecel-lele-rumahan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1b8d16212df6c19b/680x482cq70/sambel-pecel-lele-rumahan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1b8d16212df6c19b/680x482cq70/sambel-pecel-lele-rumahan-foto-resep-utama.jpg
author: Andre Allison
ratingvalue: 4
reviewcount: 28305
recipeingredient:
- "1/4 kg lele"
- "1/2 butir jeruk nipis"
- " Bahan Rendaman"
- "1 siung bawang putih"
- "2 siung bawang merah"
- "1/2 cm kunyit"
- "1/4 sdt garam"
- "1/2 cm jahe"
- " Bahan Sambal"
- "4 siung bawang putih"
- "2 siung bawang merah"
- "4 cabe hijau besar"
- "6 cabe keriting kecil"
- "6 rawit hijau"
- "6 rawit merah"
- "1/2 sdt garam atau lebih"
- "1/2 sdt gula pasir"
- "1 sdt munjung terasi lombok sangrai"
- "1 sdm gula merah"
recipeinstructions:
- "Cuci bersih lele, kucuri jeruk nipis diamkan kurleb 10 menit lalu bilas bersih, balur dengan bahan rendaman, biarkan hingga meresap, lalu goreng"
- "Goreng bahan sambal hingga cabe berkulit, ulek hingga halus bersama terasi, garam dan gula"
- "Koreksi rasa, setelah pas siram dengan minyak panas sebanyak takaran (harus benar benar panas ya)"
- "Sajikan sambal dengan lele goreng dan lalapan sesuai selera"
categories:
- Recipe
tags:
- sambel
- pecel
- lele

katakunci: sambel pecel lele 
nutrition: 170 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Lunch

---


![Sambel Pecel Lele Rumahan](https://img-global.cpcdn.com/recipes/1b8d16212df6c19b/680x482cq70/sambel-pecel-lele-rumahan-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas dan enak. Ciri makanan Indonesia sambel pecel lele rumahan yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Sambel Pecel Lele Rumahan untuk orang di rumah. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian masakan yang bisa anda buat salah satunya sambel pecel lele rumahan yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep sambel pecel lele rumahan tanpa harus bersusah payah.
Berikut ini resep Sambel Pecel Lele Rumahan yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambel Pecel Lele Rumahan:

1. Harus ada 1/4 kg lele
1. Tambah 1/2 butir jeruk nipis
1. Diperlukan  Bahan Rendaman:
1. Harus ada 1 siung bawang putih
1. Diperlukan 2 siung bawang merah
1. Tambah 1/2 cm kunyit
1. Harap siapkan 1/4 sdt garam
1. Siapkan 1/2 cm jahe
1. Jangan lupa  Bahan Sambal:
1. Tambah 4 siung bawang putih
1. Diperlukan 2 siung bawang merah
1. Siapkan 4 cabe hijau besar
1. Tambah 6 cabe keriting kecil
1. Jangan lupa 6 rawit hijau
1. Dibutuhkan 6 rawit merah
1. Tambah 1/2 sdt garam atau lebih
1. Dibutuhkan 1/2 sdt gula pasir
1. Dibutuhkan 1 sdt munjung terasi lombok, sangrai
1. Dibutuhkan 1 sdm gula merah




<!--inarticleads2-->

##### Cara membuat  Sambel Pecel Lele Rumahan:

1. Cuci bersih lele, kucuri jeruk nipis diamkan kurleb 10 menit lalu bilas bersih, balur dengan bahan rendaman, biarkan hingga meresap, lalu goreng
1. Goreng bahan sambal hingga cabe berkulit, ulek hingga halus bersama terasi, garam dan gula
1. Koreksi rasa, setelah pas siram dengan minyak panas sebanyak takaran (harus benar benar panas ya)
1. Sajikan sambal dengan lele goreng dan lalapan sesuai selera




Demikianlah cara membuat sambel pecel lele rumahan yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
