---
description: "Langkah untuk menyiapakan Roti Unyil Sempurna"
title: "Langkah untuk menyiapakan Roti Unyil Sempurna"
slug: 122-langkah-untuk-menyiapakan-roti-unyil-sempurna
date: 2020-11-14T17:32:56.364Z
image: https://img-global.cpcdn.com/recipes/ce841cfb191ef112/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ce841cfb191ef112/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ce841cfb191ef112/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Frank Shaw
ratingvalue: 4.5
reviewcount: 10976
recipeingredient:
- "250 gr tepung terigu protein tinggi"
- "1 sdm susu bubuk"
- "100 gr kentang kukusberat setelah dikukus"
- "1 butir telur segar"
- "45 gr gula pasir"
- "1/4 sdt garam"
- "40 gr butter"
- "50 ml susu cair"
- "1 sdt ragi instan"
recipeinstructions:
- "Siapkan bahan-bahan"
- "Haluskan kentang yg sudah dikukus"
- "Masukkan tepung terigu,susu bubuk, kentang kukus, telur, gula pasir, ragi instan. Aduk sampai rata."
- "Tuang susu cair perlahan sambil diaduk sampai dirasa pas. Kemudian uleni/mixer sampai setengah kalis"
- "Masukkan butter dan garam. Uleni/mixer lg sampai kalis elastis."
- "Setelah kalis elastis melewati windowpane test, bulatkan, tutup dengan plastik wrap/kain bersih lembab. Diamkan sampai mengembang 2x lipat (45 menit-1 jam). Lalu tinju, uleni sebentar."
- "Bagi adonan 25 gr/sesuai selera. Sy @30 gr. Bentuk,beri isian sesuai selera.Setelah itu tutup lg dg plastik wrap. Biarkan sampai mengembang lagi. 15-20 menit. Saya 30 menit."
- "Langkah terakhir sebelum di oven, oles dengan susu cair atau dikombinasikan dengan kuning telur. Oven selama 20-25 menit dengan suhu 170 derajat. Lama pengovenan menyesuaikan oven masing-masing. Jgn lupa, oven dipanaskan dulu sebelumya. Saya 5 menit pertama dg api bawah, sisa dengan api atas bawah."
- "Setelah matang, angkat. Pindah ke cooling rak. Oles dengan butter."
- "Segera masukkan dlm plastik kemasan / toples kedap udara unt menjaga kelembabannya"
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 122 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT55M"
recipeyield: "4"
recipecategory: Dinner

---


![Roti Unyil](https://img-global.cpcdn.com/recipes/ce841cfb191ef112/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti roti unyil yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan ciri khas yang merupakan keragaman Kita



Keharmonisan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah memasak Roti Unyil untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang dapat anda praktekkan salah satunya roti unyil yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep roti unyil tanpa harus bersusah payah.
Seperti resep Roti Unyil yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 9 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Unyil:

1. Jangan lupa 250 gr tepung terigu protein tinggi
1. Siapkan 1 sdm susu bubuk
1. Harus ada 100 gr kentang kukus(berat setelah dikukus)
1. Diperlukan 1 butir telur segar
1. Diperlukan 45 gr gula pasir
1. Dibutuhkan 1/4 sdt garam
1. Jangan lupa 40 gr butter
1. Tambah 50 ml susu cair
1. Harus ada 1 sdt ragi instan




<!--inarticleads2-->

##### Langkah membuat  Roti Unyil:

1. Siapkan bahan-bahan
1. Haluskan kentang yg sudah dikukus
1. Masukkan tepung terigu,susu bubuk, kentang kukus, telur, gula pasir, ragi instan. Aduk sampai rata.
1. Tuang susu cair perlahan sambil diaduk sampai dirasa pas. Kemudian uleni/mixer sampai setengah kalis
1. Masukkan butter dan garam. Uleni/mixer lg sampai kalis elastis.
1. Setelah kalis elastis melewati windowpane test, bulatkan, tutup dengan plastik wrap/kain bersih lembab. Diamkan sampai mengembang 2x lipat (45 menit-1 jam). Lalu tinju, uleni sebentar.
1. Bagi adonan 25 gr/sesuai selera. Sy @30 gr. Bentuk,beri isian sesuai selera.Setelah itu tutup lg dg plastik wrap. Biarkan sampai mengembang lagi. 15-20 menit. Saya 30 menit.
1. Langkah terakhir sebelum di oven, oles dengan susu cair atau dikombinasikan dengan kuning telur. Oven selama 20-25 menit dengan suhu 170 derajat. Lama pengovenan menyesuaikan oven masing-masing. Jgn lupa, oven dipanaskan dulu sebelumya. Saya 5 menit pertama dg api bawah, sisa dengan api atas bawah.
1. Setelah matang, angkat. Pindah ke cooling rak. Oles dengan butter.
1. Segera masukkan dlm plastik kemasan / toples kedap udara unt menjaga kelembabannya




Demikianlah cara membuat roti unyil yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan teruji, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
