---
description: "Steps untuk menyiapakan Roti Unyil Sempurna"
title: "Steps untuk menyiapakan Roti Unyil Sempurna"
slug: 50-steps-untuk-menyiapakan-roti-unyil-sempurna
date: 2021-01-31T09:05:09.356Z
image: https://img-global.cpcdn.com/recipes/0ba2d16148d36e24/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0ba2d16148d36e24/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0ba2d16148d36e24/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Polly Thornton
ratingvalue: 4.4
reviewcount: 15171
recipeingredient:
- "250 gr tepung terigu protein tinggi"
- "1 sdm susu bubuk"
- "100 gram kentang kukus haluskan berat setelah dikukus"
- "45 gr gula pasir"
- "1 sdt ragi instan"
- "1 butir telur"
- "50 ml susu cair"
- "40 gr butter"
- "1/4 sdt garam"
recipeinstructions:
- "Dalam wadah masukkan terigu protein tinggi, kentang, gula, ragi instant, susu bubuk, dan telur aduk rata. Tuangi susu cair sedikit demi sedikit sampai konsistensi yang diinginkan (stop jika sudah pas) uleni sampai setengah kalis  masukkan butter dan garam."
- "Uleni lagi sampai kalis elastic. saya dibantu hand mixer. 😁 Bulatkan adonan taruh di wadah lalu tutup dengan plastik wrap atau kain bersih lembab (saya tutup pake tutup panci 🙏😊)"
- "Diamkan sampai mengembang 2x lipat, diamkan selama 40 menit (saya kurleb 1 jam) Lalu kempeskan uleni sebentar Bagi adonan menjadi 20 buah @25 g/perbuah"
- "Bentuk2 sesuai selera. Saya blm bisa secantik bentuk rotinya mb Fitri 🙏😊. Tutup dengan plastik wrap (saya dengan kain serbet bersih) biarkan selama 15-20menit sampai mengembang lagi, silakan dioles dengan susu cair (bisa juga pakai kuning telur dan susu cair)"
- "Panaskan oven suhu 170 derajad lalu panggang selama 20-25 menit (sesuaikan oven masing2). Karena oven saya kecil, jadinya roti unyilnya mepet banget di loyang 🤭. Keluarkan dari oven, oles dengan butter. Sajikan"
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 161 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dessert

---


![Roti Unyil](https://img-global.cpcdn.com/recipes/0ba2d16148d36e24/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti roti unyil yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan ciri khas yang merupakan keragaman Kita



Kedekatan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah memasak Roti Unyil untuk keluarga. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang bisa anda coba salah satunya roti unyil yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep roti unyil tanpa harus bersusah payah.
Seperti resep Roti Unyil yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Unyil:

1. Siapkan 250 gr tepung terigu protein tinggi
1. Tambah 1 sdm susu bubuk
1. Tambah 100 gram kentang (kukus, haluskan) &gt;berat setelah dikukus
1. Dibutuhkan 45 gr gula pasir
1. Diperlukan 1 sdt ragi instan
1. Diperlukan 1 butir telur
1. Harap siapkan 50 ml susu cair
1. Harus ada 40 gr butter
1. Harap siapkan 1/4 sdt garam




<!--inarticleads2-->

##### Instruksi membuat  Roti Unyil:

1. Dalam wadah masukkan terigu protein tinggi, kentang, gula, ragi instant, susu bubuk, dan telur aduk rata. Tuangi susu cair sedikit demi sedikit sampai konsistensi yang diinginkan (stop jika sudah pas) uleni sampai setengah kalis  - masukkan butter dan garam.
1. Uleni lagi sampai kalis elastic. saya dibantu hand mixer. 😁 - Bulatkan adonan taruh di wadah lalu tutup dengan plastik wrap atau kain bersih lembab (saya tutup pake tutup panci 🙏😊)
1. Diamkan sampai mengembang 2x lipat, diamkan selama 40 menit (saya kurleb 1 jam) Lalu kempeskan uleni sebentar - Bagi adonan menjadi 20 buah @25 g/perbuah
1. Bentuk2 sesuai selera. Saya blm bisa secantik bentuk rotinya mb Fitri 🙏😊. Tutup dengan plastik wrap (saya dengan kain serbet bersih) biarkan selama 15-20menit sampai mengembang lagi, silakan dioles dengan susu cair (bisa juga pakai kuning telur dan susu cair)
1. Panaskan oven suhu 170 derajad lalu panggang selama 20-25 menit (sesuaikan oven masing2). Karena oven saya kecil, jadinya roti unyilnya mepet banget di loyang 🤭. - Keluarkan dari oven, oles dengan butter. Sajikan




Demikianlah cara membuat roti unyil yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
