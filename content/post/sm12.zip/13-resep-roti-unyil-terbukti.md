---
description: "Resep : Roti unyil Terbukti"
title: "Resep : Roti unyil Terbukti"
slug: 13-resep-roti-unyil-terbukti
date: 2020-09-14T21:23:13.350Z
image: https://img-global.cpcdn.com/recipes/73fb113fb410fddc/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/73fb113fb410fddc/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/73fb113fb410fddc/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Douglas Abbott
ratingvalue: 4.2
reviewcount: 29769
recipeingredient:
- " tepung cakra"
- " tepung segitiga"
- " susu bubuk"
- " gula pasir"
- " ragi instan"
- " 1 telur utuh 20 gram whip cream bubuk susu cair"
- " butter sy pake margarin royal palmia"
- " garam"
- " pasta susu sy skip"
- " Isian toping keju meseschoco chip wijen dll"
recipeinstructions:
- "Uleni/ mixer semua bahan kecuali butter/margarin dan garam sampai kalis(sy hanya punya hand mixer jadinya sy kadang mix sebntr matiin sy lanjut ulen pake tangan)"
- "Setelah kalis masukan garam dan butter lalu uleni sampai kalis elastis"
- "Timbang masing masing adonan 15 gram."
- "Isi dan bentuk sesuai selera, saya isi pake meses, keju, choco chips,dan tanpa isi krn sy mau oles buttercream dan ditaburi meses."
- "Diamkan minimal sejam sampai mengembang lalu oles dengan campuran kuning telur dan susu cair, taburi dengan toping keju, meses,wijen dll"
- "Oven dengam suhu 180 derajat selama 25 menit atau sesuai oven masing masing. Sampai kecoklatan dan matang."
- "Setelah matang keluarkan dr oven dan lngsung oles dengan butter/ margarin siap disajikan."
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 284 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Lunch

---


![Roti unyil](https://img-global.cpcdn.com/recipes/73fb113fb410fddc/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga enak. Ciri masakan Nusantara roti unyil yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kehangatan keluarga bisa ditemukan dengan cara simple. Diantaranya adalah memasak Roti unyil untuk keluarga. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang dapat anda contoh salah satunya roti unyil yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep roti unyil tanpa harus bersusah payah.
Seperti resep Roti unyil yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti unyil:

1. Siapkan  tepung cakra
1. Siapkan  tepung segitiga
1. Diperlukan  susu bubuk
1. Diperlukan  gula pasir
1. Diperlukan  ragi instan
1. Harus ada  (1 telur utuh+ 20 gram whip cream bubuk+ susu cair)
1. Tambah  butter (sy pake margarin royal palmia)
1. Siapkan  garam
1. Jangan lupa  pasta susu (sy skip)
1. Harus ada  Isian+ toping: keju, meses,choco chip, wijen dll




<!--inarticleads2-->

##### Bagaimana membuat  Roti unyil:

1. Uleni/ mixer semua bahan kecuali butter/margarin dan garam sampai kalis(sy hanya punya hand mixer jadinya sy kadang mix sebntr matiin sy lanjut ulen pake tangan)
1. Setelah kalis masukan garam dan butter lalu uleni sampai kalis elastis
1. Timbang masing masing adonan 15 gram.
1. Isi dan bentuk sesuai selera, saya isi pake meses, keju, choco chips,dan tanpa isi krn sy mau oles buttercream dan ditaburi meses.
1. Diamkan minimal sejam sampai mengembang lalu oles dengan campuran kuning telur dan susu cair, taburi dengan toping keju, meses,wijen dll
1. Oven dengam suhu 180 derajat selama 25 menit atau sesuai oven masing masing. Sampai kecoklatan dan matang.
1. Setelah matang keluarkan dr oven dan lngsung oles dengan butter/ margarin siap disajikan.




Demikianlah cara membuat roti unyil yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan terbukti, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
