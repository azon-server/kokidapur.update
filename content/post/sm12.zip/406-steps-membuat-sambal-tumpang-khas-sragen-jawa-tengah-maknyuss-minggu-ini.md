---
description: "Steps membuat Sambal tumpang khas sragen jawa tengah maknyuss.. ;) minggu ini"
title: "Steps membuat Sambal tumpang khas sragen jawa tengah maknyuss.. ;) minggu ini"
slug: 406-steps-membuat-sambal-tumpang-khas-sragen-jawa-tengah-maknyuss-minggu-ini
date: 2020-12-30T04:42:20.861Z
image: https://img-global.cpcdn.com/recipes/902bd7187b0bd1bc/680x482cq70/sambal-tumpang-khas-sragen-jawa-tengah-maknyuss-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/902bd7187b0bd1bc/680x482cq70/sambal-tumpang-khas-sragen-jawa-tengah-maknyuss-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/902bd7187b0bd1bc/680x482cq70/sambal-tumpang-khas-sragen-jawa-tengah-maknyuss-foto-resep-utama.jpg
author: Annie Sanchez
ratingvalue: 4.5
reviewcount: 37660
recipeingredient:
- "1 bungkus (10 biji) tahu coklat basah"
- "1 papan tempe semangit yg udah fermentasi y moms tapi ya gag harus semngit kok moms yg biasa juga bisa tapi lebih enak klo pke semngit moms lebih keluar citarasa nya Hihihi"
- "5 siung bawang putih"
- "6 siung bawang merah"
- "4 lembar daun jeruk"
- "3 lembar daun salam"
- "3 butir kemiri"
- "3 cm kencur"
- "2 cm lengkuas"
- "8 buah cabe merah kriting"
- "5 buah cabe rawit merah jika suka pedas bisa di tambah cabe nya kok moms"
- "1 sdt gula pasir"
- "2 sdt garam"
- " Penyedap optional"
- "1 1/2 bungkus santan kara yg kecil 65 ml bisa pake air kelapa asli kok moms kmren aku pake yg cepet aj"
recipeinstructions:
- "Siapkan panci berisi air, potong2 tempe seprti mau di goreng tapi lebih tebel lagi y mom&#39;s, lalu masukan ke dalam panci berisi air tadi,dan masukan tahu coklat juga(sedikit di kerat-kerat)"
- "Lalu siapkan semua bumbu cuci bersih, masukan ke dalam air di panci tadi bersama tahu dan tempe,rebus kira-kira 20 menitan,seprti ini gambr nya mom&#39;s"
- "Setelah selesai di rebus pisahkan tahu,tempe lengkuas,daun jeruk,dan juga daun salam ke piring, seprti ini mom&#39;s.."
- "Lalu tuang bumbu ke cobek kemudian haluskan,"
- "Ini menampakan yg udah di halusin mom&#39;s"
- "Masukan tempe sedikit demi sedikit sambil di halusin"
- "Kemudian tumis bumbu yg sudah di haluskan dengan tempe tadi smpek harum,"
- "Stelah harum masukan tuangi air kira2 400 ml (di kira2 aj sesuai selera ya mom&#39;s)"
- "Kemudian masukan tahu, lalu tutup panci biarkan bumbu meresap sbntar sampi air nya tadi mendidih,,"
- "Setelah mendidih masukan garam,gula,penyedap dan santan aduk2 jangan smpek santan pecah ya mom&#39;s, lalu koreksi rasa"
- "Jika sudah matang taburi dengan bawang goreng mom&#39;s... Yummyy siap di hidangkan dengan pelengkap bubur gurih dan urap, kmren aku pernah bkin tapi lupa gag di foto mom&#39;s jadi ini sambal tumpang nya dlu aj, he:)"
- "Ini penampkan lengkuas+kencur nya ya mom&#39;s berpa cm nya di kira2 ajah ya.."
- "Jangan takut mencoba karna ada pemakaian tempe semangit ya mom&#39;s ini beneran enak kok menambah citarasa.. Hehehe klo gag tau tempe semngit beli aj tempe yg masih bagus lalu diamnkan 2 hari mom&#39;s nanti akan semngit sendiri kok,"
- "Note : klo mau pake santan asli air yg tuang setelah menumis bumbu kira2 200ml aj ya mom&#39;s jangan banyak2 karna santan nya mengandung air juga nanti nya,,"
- "~ selamat mencoba ~"
categories:
- Recipe
tags:
- sambal
- tumpang
- khas

katakunci: sambal tumpang khas 
nutrition: 163 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Lunch

---


![Sambal tumpang khas sragen jawa tengah maknyuss.. ;)](https://img-global.cpcdn.com/recipes/902bd7187b0bd1bc/680x482cq70/sambal-tumpang-khas-sragen-jawa-tengah-maknyuss-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang dapat kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti sambal tumpang khas sragen jawa tengah maknyuss.. ;) yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan keistimewahan yang merupakan keragaman Kita

Kedekatan rumah tangga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Sambal tumpang khas sragen jawa tengah maknyuss.. ;) untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang bisa anda contoh salah satunya sambal tumpang khas sragen jawa tengah maknyuss.. ;) yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep sambal tumpang khas sragen jawa tengah maknyuss.. ;) tanpa harus bersusah payah.
Berikut ini resep Sambal tumpang khas sragen jawa tengah maknyuss.. ;) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 15 bahan dan 15 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambal tumpang khas sragen jawa tengah maknyuss.. ;):

1. Jangan lupa 1 bungkus (10 biji) tahu coklat basah
1. Siapkan 1 papan tempe semangit (yg udah fermentasi y mom&#39;s tapi ya gag harus semngit kok mom&#39;s yg biasa juga bisa tapi lebih enak klo pke semngit mom&#39;s lebih keluar citarasa nya.. Hihihi:)
1. Jangan lupa 5 siung bawang putih
1. Harus ada 6 siung bawang merah
1. Harus ada 4 lembar daun jeruk
1. Siapkan 3 lembar daun salam
1. Harus ada 3 butir kemiri
1. Jangan lupa 3 cm kencur
1. Harus ada 2 cm lengkuas
1. Dibutuhkan 8 buah cabe merah kriting
1. Diperlukan 5 buah cabe rawit merah (jika suka pedas bisa di tambah cabe nya kok mom&#39;s)
1. Harus ada 1 sdt gula pasir
1. Diperlukan 2 sdt garam
1. Jangan lupa  Penyedap (optional)
1. Diperlukan 1 1/2 bungkus santan kara yg kecil 65 ml (bisa pake air kelapa asli kok mom&#39;s kmren aku pake yg cepet aj)




<!--inarticleads2-->

##### Bagaimana membuat  Sambal tumpang khas sragen jawa tengah maknyuss.. ;):

1. Siapkan panci berisi air, potong2 tempe seprti mau di goreng tapi lebih tebel lagi y mom&#39;s, lalu masukan ke dalam panci berisi air tadi,dan masukan tahu coklat juga(sedikit di kerat-kerat)
1. Lalu siapkan semua bumbu cuci bersih, masukan ke dalam air di panci tadi bersama tahu dan tempe,rebus kira-kira 20 menitan,seprti ini gambr nya mom&#39;s
1. Setelah selesai di rebus pisahkan tahu,tempe lengkuas,daun jeruk,dan juga daun salam ke piring, seprti ini mom&#39;s..
1. Lalu tuang bumbu ke cobek kemudian haluskan,
1. Ini menampakan yg udah di halusin mom&#39;s
1. Masukan tempe sedikit demi sedikit sambil di halusin
1. Kemudian tumis bumbu yg sudah di haluskan dengan tempe tadi smpek harum,
1. Stelah harum masukan tuangi air kira2 400 ml (di kira2 aj sesuai selera ya mom&#39;s)
1. Kemudian masukan tahu, lalu tutup panci biarkan bumbu meresap sbntar sampi air nya tadi mendidih,,
1. Setelah mendidih masukan garam,gula,penyedap dan santan aduk2 jangan smpek santan pecah ya mom&#39;s, lalu koreksi rasa
1. Jika sudah matang taburi dengan bawang goreng mom&#39;s... Yummyy siap di hidangkan dengan pelengkap bubur gurih dan urap, kmren aku pernah bkin tapi lupa gag di foto mom&#39;s jadi ini sambal tumpang nya dlu aj, he:)
1. Ini penampkan lengkuas+kencur nya ya mom&#39;s berpa cm nya di kira2 ajah ya..
1. Jangan takut mencoba karna ada pemakaian tempe semangit ya mom&#39;s ini beneran enak kok menambah citarasa.. Hehehe klo gag tau tempe semngit beli aj tempe yg masih bagus lalu diamnkan 2 hari mom&#39;s nanti akan semngit sendiri kok,
1. Note : klo mau pake santan asli air yg tuang setelah menumis bumbu kira2 200ml aj ya mom&#39;s jangan banyak2 karna santan nya mengandung air juga nanti nya,,
1. ~ selamat mencoba ~




Demikianlah cara membuat sambal tumpang khas sragen jawa tengah maknyuss.. ;) yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
