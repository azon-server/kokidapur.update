---
description: "Panduan untuk menyiapakan Sambal Tumpang Kediri Cepat"
title: "Panduan untuk menyiapakan Sambal Tumpang Kediri Cepat"
slug: 450-panduan-untuk-menyiapakan-sambal-tumpang-kediri-cepat
date: 2020-10-16T17:29:29.040Z
image: https://img-global.cpcdn.com/recipes/883ad7870bb552ad/680x482cq70/sambal-tumpang-kediri-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/883ad7870bb552ad/680x482cq70/sambal-tumpang-kediri-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/883ad7870bb552ad/680x482cq70/sambal-tumpang-kediri-foto-resep-utama.jpg
author: Bettie Garner
ratingvalue: 4.3
reviewcount: 26552
recipeingredient:
- "1/2 papan tempe hampir busuk 3 hari menginap potong dadu ukuran sedang"
- "Secukupnya air"
- "Secukupnya gula garam lada penyedap jika berkenan"
- "300 ml santan sekitar 15 gelas"
- " Bumbu"
- "3 siung bawang putih"
- "5 siung bawang merah"
- "1 cm kencur"
- "2 cm lengkuas"
- "1-2 biji cabe merah besar"
- "8 biji cabe rawit merah"
- "3 lembar daun salam"
- "4 lembar daun jeruk"
- "3 sdt ketumbar bubuk"
- "2 butir kemiri sangrai"
recipeinstructions:
- "Didihkan air yang ditambahkan 1/2 sdt garam. Kemudian masukkan bawang putih, bawang merah, kencur, lengkuas, cabe, daun salam, daun jeruk, dan juga tempe ke dalam air. Rebus hingga sedikit layu kira-kira 10 menit. Air rebusan tidak usah dibuang. (TIPS: garam di sini dimasukkan supaya air lebih cepat mendidih. Tidak wajib dilakukan ya.)"
- "Setelah layu, angkat semua bumbu kecuali daun salam. Tambahkan ketumbar bubuk dan kemiri sangrai. Haluskan."
- "Masukkan juga tempe yang sudah direbus. Hancurkan secara kasar dan aduk bersama bumbu."
- "Masukkan semua bahan yang sudah dihaluskan ke dalam air sisa rebusan tadi. Masak hingga sedikit mendidih kemudian tambahkan santan. (TIPS: masak dengan api kecil-sedang agar santan tidak pecah)."
- "Tambahkan gula, garam, sedikit lada, dan penyedap (jika berkenan). Koreksi rasa dan sajikan."
- "Saran penyajian, bisa dihidangkan bersama dengan pecel. Resep sambal/bumbu pecel pernah saya tulis, boleh mampir ke link yang saya tulis di kolom deskripsi di atas ya 😍👍🏻"
categories:
- Recipe
tags:
- sambal
- tumpang
- kediri

katakunci: sambal tumpang kediri 
nutrition: 178 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Dinner

---


![Sambal Tumpang Kediri](https://img-global.cpcdn.com/recipes/883ad7870bb552ad/680x482cq70/sambal-tumpang-kediri-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga renyah. Ciri khas masakan Indonesia sambal tumpang kediri yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kedekatan keluarga bisa didapat dengan cara simple. Salah satunya adalah memasak Sambal Tumpang Kediri untuk keluarga. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang dapat anda praktekkan salah satunya sambal tumpang kediri yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep sambal tumpang kediri tanpa harus bersusah payah.
Berikut ini resep Sambal Tumpang Kediri yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambal Tumpang Kediri:

1. Harus ada 1/2 papan tempe hampir busuk (3 hari menginap, potong dadu ukuran sedang)
1. Siapkan Secukupnya air
1. Tambah Secukupnya gula, garam, lada, penyedap (jika berkenan)
1. Diperlukan 300 ml santan (sekitar 1,5 gelas)
1. Harap siapkan  Bumbu
1. Siapkan 3 siung bawang putih
1. Tambah 5 siung bawang merah
1. Tambah 1 cm kencur
1. Siapkan 2 cm lengkuas
1. Siapkan 1-2 biji cabe merah besar
1. Diperlukan 8 biji cabe rawit merah
1. Diperlukan 3 lembar daun salam
1. Tambah 4 lembar daun jeruk
1. Jangan lupa 3 sdt ketumbar bubuk
1. Siapkan 2 butir kemiri (sangrai)




<!--inarticleads2-->

##### Bagaimana membuat  Sambal Tumpang Kediri:

1. Didihkan air yang ditambahkan 1/2 sdt garam. Kemudian masukkan bawang putih, bawang merah, kencur, lengkuas, cabe, daun salam, daun jeruk, dan juga tempe ke dalam air. Rebus hingga sedikit layu kira-kira 10 menit. Air rebusan tidak usah dibuang. (TIPS: garam di sini dimasukkan supaya air lebih cepat mendidih. Tidak wajib dilakukan ya.)
1. Setelah layu, angkat semua bumbu kecuali daun salam. Tambahkan ketumbar bubuk dan kemiri sangrai. Haluskan.
1. Masukkan juga tempe yang sudah direbus. Hancurkan secara kasar dan aduk bersama bumbu.
1. Masukkan semua bahan yang sudah dihaluskan ke dalam air sisa rebusan tadi. Masak hingga sedikit mendidih kemudian tambahkan santan. (TIPS: masak dengan api kecil-sedang agar santan tidak pecah).
1. Tambahkan gula, garam, sedikit lada, dan penyedap (jika berkenan). Koreksi rasa dan sajikan.
1. Saran penyajian, bisa dihidangkan bersama dengan pecel. Resep sambal/bumbu pecel pernah saya tulis, boleh mampir ke link yang saya tulis di kolom deskripsi di atas ya 😍👍🏻




Demikianlah cara membuat sambal tumpang kediri yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
