---
description: "Langkah menyiapakan Sambal Tumpang Khas Solo teraktual"
title: "Langkah menyiapakan Sambal Tumpang Khas Solo teraktual"
slug: 367-langkah-menyiapakan-sambal-tumpang-khas-solo-teraktual
date: 2020-09-20T17:53:36.559Z
image: https://img-global.cpcdn.com/recipes/9d466f18d6d788a0/680x482cq70/sambal-tumpang-khas-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9d466f18d6d788a0/680x482cq70/sambal-tumpang-khas-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9d466f18d6d788a0/680x482cq70/sambal-tumpang-khas-solo-foto-resep-utama.jpg
author: Barbara Hodges
ratingvalue: 4.5
reviewcount: 33658
recipeingredient:
- " BAHAN REBUSAN "
- "1/2 papan tempe semangit"
- "1/4 papan tempe biasa"
- "7 siung bawang merah"
- "5 siung bawang putih"
- "25 buah cabai rawit sesuai selera pedas"
- "7 buah cabai merah keriting"
- "1 ruas kencur"
- "2 ruas lengkuas"
- "6 butir kemiri"
- "Sejumput ebi"
- "2 lembar daun salam"
- "6 lembar daun jeruk"
- " BAHAN PELENGKAP "
- "300 ml santan kental"
- "500 ml santan cair"
- "7 kotak tahu sayur potong2 bentuk segitiga"
- "1 bungkus krecek kerupuk kulit"
- " Garam"
- " Gula pasir"
- " Totolekaldu jamurroyco"
- " Merica bubuk"
- " BAHAN REBUSAN SAYURAN "
- "1/2 ikat sayur bayam"
- "1/4 ikat kacang panjang"
- "1,5 ons tauge"
recipeinstructions:
- "Masukkan ke dalam panci semua bahan rebusan lalu rebus bentar. Setelah itu angkat dr panci bumbu2 sperti bawang merah, putih, cabai, dan semuanya kecuali sisakan tempe saja utk direbus aga lama agar benar2 empuk. Air rebusan tempe jangan dibuang krn akan dipake utk kuah"
- "Uleg bumbu2 rebusan tadi seperti bawang merah, bawang putih, cabai, kencur, kemiri, daun jeruk, ebi kecuali lengkuas dan daun salam jangan ikut diulek ya moms"
- "Lalu uleg tempe yg sdh direbus td. Ingat ya moms nguleg bumbu dan tempe harus dipisahkan krn nanti bumbu akan ditumis dulu."
- "Tumis ulekan bumbu2 tadi hingga harum. Kemudian angkat dan masukkan ke dalam panci yg sdh terisi air rebusan tempe dan bumbu2 tadi. Masukkan ulekan tempe rebus. Masak hingga mendidih lalu masukkan santan. Sesekali aduk agar santan tdk pecah."
- "Masukkan tahu sayur. Beri bumbu garam, gula, totole/kaldu jamur/royco dan merica bubuk. Koreksi rasa (cenderung aga manis tp asin haha gmn tuh pkoknya itu lah)"
- "Terakhir masukkan krecek/ kerupuk kulit dan langsung matikan api lalu sambal tumpang bisa dinikmati dengan cara disiram di atas rebusan sayuran bayam, kacang panjang, dan tauge."
categories:
- Recipe
tags:
- sambal
- tumpang
- khas

katakunci: sambal tumpang khas 
nutrition: 147 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT30M"
recipeyield: "2"
recipecategory: Dessert

---


![Sambal Tumpang Khas Solo](https://img-global.cpcdn.com/recipes/9d466f18d6d788a0/680x482cq70/sambal-tumpang-khas-solo-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti sambal tumpang khas solo yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Indonesia



Kedekatan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah membuat makanan Sambal Tumpang Khas Solo untuk keluarga. Momen makan bersama anak sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang dapat anda contoh salah satunya sambal tumpang khas solo yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep sambal tumpang khas solo tanpa harus bersusah payah.
Berikut ini resep Sambal Tumpang Khas Solo yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 26 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambal Tumpang Khas Solo:

1. Siapkan  BAHAN REBUSAN :
1. Dibutuhkan 1/2 papan tempe semangit
1. Dibutuhkan 1/4 papan tempe biasa
1. Harap siapkan 7 siung bawang merah
1. Diperlukan 5 siung bawang putih
1. Siapkan 25 buah cabai rawit (sesuai selera pedas)
1. Dibutuhkan 7 buah cabai merah keriting
1. Diperlukan 1 ruas kencur
1. Siapkan 2 ruas lengkuas
1. Harap siapkan 6 butir kemiri
1. Siapkan Sejumput ebi
1. Harus ada 2 lembar daun salam
1. Diperlukan 6 lembar daun jeruk
1. Siapkan  BAHAN PELENGKAP :
1. Jangan lupa 300 ml santan kental
1. Diperlukan 500 ml santan cair
1. Harap siapkan 7 kotak tahu sayur potong2 bentuk segitiga
1. Harus ada 1 bungkus krecek/ kerupuk kulit
1. Jangan lupa  Garam
1. Diperlukan  Gula pasir
1. Tambah  Totole/kaldu jamur/royco
1. Tambah  Merica bubuk
1. Diperlukan  BAHAN REBUSAN SAYURAN :
1. Dibutuhkan 1/2 ikat sayur bayam
1. Tambah 1/4 ikat kacang panjang
1. Harap siapkan 1,5 ons tauge




<!--inarticleads2-->

##### Langkah membuat  Sambal Tumpang Khas Solo:

1. Masukkan ke dalam panci semua bahan rebusan lalu rebus bentar. Setelah itu angkat dr panci bumbu2 sperti bawang merah, putih, cabai, dan semuanya kecuali sisakan tempe saja utk direbus aga lama agar benar2 empuk. Air rebusan tempe jangan dibuang krn akan dipake utk kuah
1. Uleg bumbu2 rebusan tadi seperti bawang merah, bawang putih, cabai, kencur, kemiri, daun jeruk, ebi kecuali lengkuas dan daun salam jangan ikut diulek ya moms
1. Lalu uleg tempe yg sdh direbus td. Ingat ya moms nguleg bumbu dan tempe harus dipisahkan krn nanti bumbu akan ditumis dulu.
1. Tumis ulekan bumbu2 tadi hingga harum. Kemudian angkat dan masukkan ke dalam panci yg sdh terisi air rebusan tempe dan bumbu2 tadi. Masukkan ulekan tempe rebus. Masak hingga mendidih lalu masukkan santan. Sesekali aduk agar santan tdk pecah.
1. Masukkan tahu sayur. Beri bumbu garam, gula, totole/kaldu jamur/royco dan merica bubuk. Koreksi rasa (cenderung aga manis tp asin haha gmn tuh pkoknya itu lah)
1. Terakhir masukkan krecek/ kerupuk kulit dan langsung matikan api lalu sambal tumpang bisa dinikmati dengan cara disiram di atas rebusan sayuran bayam, kacang panjang, dan tauge.




Demikianlah cara membuat sambal tumpang khas solo yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
