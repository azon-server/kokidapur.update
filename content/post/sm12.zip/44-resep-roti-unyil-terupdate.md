---
description: "Resep : Roti unyil terupdate"
title: "Resep : Roti unyil terupdate"
slug: 44-resep-roti-unyil-terupdate
date: 2021-02-01T02:27:24.922Z
image: https://img-global.cpcdn.com/recipes/13d82156959131c2/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/13d82156959131c2/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/13d82156959131c2/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Rosetta Valdez
ratingvalue: 4.2
reviewcount: 21668
recipeingredient:
- "300 gr tepung pro tinggi"
- "10 gr susu bubukoptionaltadi ga pake"
- "5 gr ragi instan"
- "1 butir telurkocok lepasbagi 2utk adonan  egg wash"
- "30 gr gula pasir"
- "150 ml susu cair dingin"
- "30 gr margarin"
- "1/2 sdt garam"
- " Isian"
- " meses coklat"
- " sosis"
- " kejukental manis"
recipeinstructions:
- "Campur tepung,ragi,gula dan telur kocok,masukkan sedikit demi sedikit susu cair,sambil di mixer dengan kecepatan rendah.Hentikan penambahan susu,jika adonan sudah setengah kalis."
- "Tambahkan separuh margarin dan garam,mixer dengan kecepatan tinggi selama +-5 menit.tambahkan lagi sisa margarin,mixer lagi dengan kecepatan tinggi selama +-10 menit hingga kalis elastis(saya 20 menit mixer).Bulatkan adonan,tutup lap kering,diamkan 1 jam hingga mengembang 2x lipat."
- "Setelah 1 jam,kempiskan adonan.Bagi2 adonan sesuai selera,saya bagi jadi 20 buah,ukuran mini2 😁"
- "Ambil satu adonan,pipihkan.Isi dengan bahan isi.Bentuk sesuai selera.Susun di loyang yang sudah diolesi margarin dan dialasi kertas roti."
- "Lakukan sampai adonan habis,lalu diamkan 20 menit tanpa ditutup.Panaskan oven,sambil menunggu roti mengembang."
- "Setelah 20 menit,olesi roti dengan egg wash,untuk yang rasa sosis,saya tambahkan mayonais,keju parut dan parsley."
- "Panggang selama -+20 menit,sesuaikan dengan oven masing2.Panas2 olesi dengan margarin."
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 166 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Lunch

---


![Roti unyil](https://img-global.cpcdn.com/recipes/13d82156959131c2/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan renyah. Ciri khas kuliner Nusantara roti unyil yang penuh dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak Roti unyil untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang dapat anda buat salah satunya roti unyil yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep roti unyil tanpa harus bersusah payah.
Seperti resep Roti unyil yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 12 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti unyil:

1. Tambah 300 gr tepung pro tinggi
1. Dibutuhkan 10 gr susu bubuk(optional,tadi ga pake)
1. Dibutuhkan 5 gr ragi instan
1. Jangan lupa 1 butir telur,kocok lepas,bagi 2(utk adonan &amp; egg wash)
1. Dibutuhkan 30 gr gula pasir
1. Diperlukan 150 ml susu cair dingin
1. Harap siapkan 30 gr margarin
1. Harap siapkan 1/2 sdt garam
1. Harap siapkan  Isian:
1. Harus ada  meses coklat
1. Siapkan  sosis
1. Harus ada  keju+kental manis




<!--inarticleads2-->

##### Bagaimana membuat  Roti unyil:

1. Campur tepung,ragi,gula dan telur kocok,masukkan sedikit demi sedikit susu cair,sambil di mixer dengan kecepatan rendah.Hentikan penambahan susu,jika adonan sudah setengah kalis.
1. Tambahkan separuh margarin dan garam,mixer dengan kecepatan tinggi selama +-5 menit.tambahkan lagi sisa margarin,mixer lagi dengan kecepatan tinggi selama +-10 menit hingga kalis elastis(saya 20 menit mixer).Bulatkan adonan,tutup lap kering,diamkan 1 jam hingga mengembang 2x lipat.
1. Setelah 1 jam,kempiskan adonan.Bagi2 adonan sesuai selera,saya bagi jadi 20 buah,ukuran mini2 😁
1. Ambil satu adonan,pipihkan.Isi dengan bahan isi.Bentuk sesuai selera.Susun di loyang yang sudah diolesi margarin dan dialasi kertas roti.
1. Lakukan sampai adonan habis,lalu diamkan 20 menit tanpa ditutup.Panaskan oven,sambil menunggu roti mengembang.
1. Setelah 20 menit,olesi roti dengan egg wash,untuk yang rasa sosis,saya tambahkan mayonais,keju parut dan parsley.
1. Panggang selama -+20 menit,sesuaikan dengan oven masing2.Panas2 olesi dengan margarin.




Demikianlah cara membuat roti unyil yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
