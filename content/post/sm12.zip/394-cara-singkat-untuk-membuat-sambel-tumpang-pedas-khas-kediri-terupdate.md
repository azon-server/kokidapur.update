---
description: "Cara singkat untuk membuat Sambel Tumpang Pedas khas Kediri terupdate"
title: "Cara singkat untuk membuat Sambel Tumpang Pedas khas Kediri terupdate"
slug: 394-cara-singkat-untuk-membuat-sambel-tumpang-pedas-khas-kediri-terupdate
date: 2020-11-16T09:50:49.471Z
image: https://img-global.cpcdn.com/recipes/6ec8ce8eaf99f0c9/680x482cq70/sambel-tumpang-pedas-khas-kediri-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6ec8ce8eaf99f0c9/680x482cq70/sambel-tumpang-pedas-khas-kediri-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6ec8ce8eaf99f0c9/680x482cq70/sambel-tumpang-pedas-khas-kediri-foto-resep-utama.jpg
author: Georgie Warren
ratingvalue: 4.3
reviewcount: 29013
recipeingredient:
- "1 buah tempe yang sudah busuk kalo saya pake yg 1 bungkus 2000 an"
- "1 santan kara segitiga"
- "10 lembar daun salam saya suka byk agar wangi dan rasa lebih sedap"
- "5 lembar daun jeruk"
- "3 iris lengkuas d geprek"
- "25 biji Cabe rawit merah"
- "7 Bawang merah"
- "4 Bawang putih"
- "1 cm Kencur"
- "secukupnya Garam"
- "1 sendok makan Gula"
- "1 saset Royco"
- "2 butir Kemiri yg sudah di goreng"
- "1 sendok makan Ketumbar"
recipeinstructions:
- "Siapkan air dalam panci yang sudah mendidih"
- "Kemudian masukan semua bahan di atas (cabe,bawang merah, bawang putih, lengkuas geprek, daun salam, daun jeruk,kencur,tempe).. Rebus smpai kurleb ±10 menit"
- "Matikan api.. Angkat cabe.bawang. brambang. Kencur....biarkan tempe lengkuas dan daun&#34;any ttp di panci"
- "Kemudian.. Bumbu yg sudh di angkat di haluskan dengan cobek dan di tambah dgn kemiri.ketumbar. Garam gula.. Setelah halus masukan bumbu halus nya ke dalam panci. Aduk&#34;"
- "Masukan santan kara dan aduk&#34; sampai mendidih.."
- "Koreksi rasa dan angkat ke dalam mangkuk."
categories:
- Recipe
tags:
- sambel
- tumpang
- pedas

katakunci: sambel tumpang pedas 
nutrition: 232 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Lunch

---


![Sambel Tumpang Pedas khas Kediri](https://img-global.cpcdn.com/recipes/6ec8ce8eaf99f0c9/680x482cq70/sambel-tumpang-pedas-khas-kediri-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti sambel tumpang pedas khas kediri yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Indonesia

Kehangatan keluarga bisa didapat dengan cara mudah. Diantaranya adalah membuat makanan Sambel Tumpang Pedas khas Kediri untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi makanan yang dapat anda coba salah satunya sambel tumpang pedas khas kediri yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep sambel tumpang pedas khas kediri tanpa harus bersusah payah.
Seperti resep Sambel Tumpang Pedas khas Kediri yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambel Tumpang Pedas khas Kediri:

1. Diperlukan 1 buah tempe yang sudah busuk (kalo saya pake yg 1 bungkus 2000 an)
1. Harap siapkan 1 santan kara segitiga
1. Siapkan 10 lembar daun salam (saya suka byk agar wangi dan rasa lebih sedap)
1. Dibutuhkan 5 lembar daun jeruk
1. Diperlukan 3 iris lengkuas d geprek
1. Dibutuhkan 25 biji Cabe rawit merah
1. Dibutuhkan 7 Bawang merah
1. Jangan lupa 4 Bawang putih
1. Tambah 1 cm Kencur
1. Jangan lupa secukupnya Garam
1. Dibutuhkan 1 sendok makan Gula
1. Siapkan 1 saset Royco
1. Siapkan 2 butir Kemiri yg sudah di goreng
1. Harus ada 1 sendok makan Ketumbar




<!--inarticleads2-->

##### Bagaimana membuat  Sambel Tumpang Pedas khas Kediri:

1. Siapkan air dalam panci yang sudah mendidih
1. Kemudian masukan semua bahan di atas (cabe,bawang merah, bawang putih, lengkuas geprek, daun salam, daun jeruk,kencur,tempe).. Rebus smpai kurleb ±10 menit
1. Matikan api.. Angkat cabe.bawang. brambang. Kencur....biarkan tempe lengkuas dan daun&#34;any ttp di panci
1. Kemudian.. Bumbu yg sudh di angkat di haluskan dengan cobek dan di tambah dgn kemiri.ketumbar. Garam gula.. Setelah halus masukan bumbu halus nya ke dalam panci. Aduk&#34;
1. Masukan santan kara dan aduk&#34; sampai mendidih..
1. Koreksi rasa dan angkat ke dalam mangkuk.




Demikianlah cara membuat sambel tumpang pedas khas kediri yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
