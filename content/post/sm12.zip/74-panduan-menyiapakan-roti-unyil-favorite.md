---
description: "Panduan menyiapakan Roti unyil Favorite"
title: "Panduan menyiapakan Roti unyil Favorite"
slug: 74-panduan-menyiapakan-roti-unyil-favorite
date: 2021-01-27T15:23:29.144Z
image: https://img-global.cpcdn.com/recipes/9df67b73e508ebdc/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9df67b73e508ebdc/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9df67b73e508ebdc/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Marian Holt
ratingvalue: 5
reviewcount: 40802
recipeingredient:
- " bahan adonan"
- "5 gr ragi instan"
- "110 ml air hangat"
- "250 gram tepung terigu"
- "2 butir kuning telur"
- "3 sdm gula"
- "40 gr margarin"
- "1 sdt garam"
- "1 sachet susu bubuk instan dancow sachet"
- "secuil TBM ini utk pelembut boleh pakai boleh engak sih"
- " bahan toping"
- " keju parut"
- " misses"
- " sossis"
- " abon"
- " skm dan mayoness khusus utk roti abon"
recipeinstructions:
- "Aktifkan ragi instan dengan cara Masukkan ragi instan dan 1 sdm gula kedalam 110 ml air hangat, diaduk dan ditutup kemudian didiamkan kurleb 5 menit, selanjutnya akan muncul buih2 atau busa digelas. hal ini dilakukan utk memastikan ragi aktif atau tidak. jika tidak muncul buih, maka ragi sudah tidak aktif dan tidak dapat digunakan lagi"
- "Campur semua adonan kecuali margarin, garam dan TBM.. ulen sampai bercampur sempurna"
- "Lalu masukkan margarin dan garam dan sedikit TBM lalu uleni terus sampai benar2 kalis"
- "Bentuk adonan menjadi bulat lalu tutp dengan kain dan diamkan sampai adonan mengembang (kurleb 25 mnt)"
- "Setelah adonan mengembang, tumbok adonan dan bagi2 sekitar 10 atau 20 gram perbagian, lalu bentuk bulat2 kecil, tutup lagi dan diamkan kurleb 15 menit"
- "Ambil adonan tadi, lalu berkreasilah sesuai selera masing2 dengan toping2 yang diinginkan."
- "Nah, ini saat nya bunda berkreasi, utk roti isian missess, cukup diambil adonan, bentuk lingkaran, tekan2 pinggirnya, lalu masukkan missess dan bulatkan kembali."
- "Utk roti abon, bunda cukup membentuk roti bulat lonjong saja. setelah dipanggang, oleskan campuran mayoness dengan SKM lalu gulingkan bagian atasnya di abon"
- "Utk isian sossis, ambil adonan, tipiskan, isi dengan sossis, lalu gulung adonan, lalu potong2 menjadi 6 bagian,dan kreasikan sesuai selera.."
- "Utk isian pisang coklat, ambil adonan tipiskan, isi pisang yg sudah dipotong kecil memanjang, tambah misses, gulung adonan,. kreasikan gulungan adonan sesuai selera"
- "Setelah dibentuk2 sesuai selera, lalu panggang di oven sesuai dengan temp oven masing2 dengan api atas bawah selama 10 -15 menit"
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 179 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Lunch

---


![Roti unyil](https://img-global.cpcdn.com/recipes/9df67b73e508ebdc/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga enak. Ciri kuliner Indonesia roti unyil yang kaya dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan keluarga dapat didapat dengan cara sederhana. Diantaranya adalah membuat makanan Roti unyil untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang dapat anda praktekkan salah satunya roti unyil yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep roti unyil tanpa harus bersusah payah.
Berikut ini resep Roti unyil yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 11 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti unyil:

1. Jangan lupa  bahan adonan
1. Harap siapkan 5 gr ragi instan
1. Tambah 110 ml air hangat
1. Harus ada 250 gram tepung terigu
1. Diperlukan 2 butir kuning telur
1. Harap siapkan 3 sdm gula
1. Diperlukan 40 gr margarin
1. Jangan lupa 1 sdt garam
1. Tambah 1 sachet susu bubuk instan (dancow sachet)
1. Siapkan secuil TBM (ini utk pelembut, boleh pakai boleh engak sih)
1. Jangan lupa  bahan toping
1. Diperlukan  keju parut
1. Dibutuhkan  misses
1. Diperlukan  sossis
1. Harus ada  abon
1. Tambah  skm dan mayoness (khusus utk roti abon)




<!--inarticleads2-->

##### Cara membuat  Roti unyil:

1. Aktifkan ragi instan dengan cara Masukkan ragi instan dan 1 sdm gula kedalam 110 ml air hangat, diaduk dan ditutup kemudian didiamkan kurleb 5 menit, selanjutnya akan muncul buih2 atau busa digelas. hal ini dilakukan utk memastikan ragi aktif atau tidak. jika tidak muncul buih, maka ragi sudah tidak aktif dan tidak dapat digunakan lagi
1. Campur semua adonan kecuali margarin, garam dan TBM.. ulen sampai bercampur sempurna
1. Lalu masukkan margarin dan garam dan sedikit TBM lalu uleni terus sampai benar2 kalis
1. Bentuk adonan menjadi bulat lalu tutp dengan kain dan diamkan sampai adonan mengembang (kurleb 25 mnt)
1. Setelah adonan mengembang, tumbok adonan dan bagi2 sekitar 10 atau 20 gram perbagian, lalu bentuk bulat2 kecil, tutup lagi dan diamkan kurleb 15 menit
1. Ambil adonan tadi, lalu berkreasilah sesuai selera masing2 dengan toping2 yang diinginkan.
1. Nah, ini saat nya bunda berkreasi, utk roti isian missess, cukup diambil adonan, bentuk lingkaran, tekan2 pinggirnya, lalu masukkan missess dan bulatkan kembali.
1. Utk roti abon, bunda cukup membentuk roti bulat lonjong saja. setelah dipanggang, oleskan campuran mayoness dengan SKM lalu gulingkan bagian atasnya di abon
1. Utk isian sossis, ambil adonan, tipiskan, isi dengan sossis, lalu gulung adonan, lalu potong2 menjadi 6 bagian,dan kreasikan sesuai selera..
1. Utk isian pisang coklat, ambil adonan tipiskan, isi pisang yg sudah dipotong kecil memanjang, tambah misses, gulung adonan,. kreasikan gulungan adonan sesuai selera
1. Setelah dibentuk2 sesuai selera, lalu panggang di oven sesuai dengan temp oven masing2 dengan api atas bawah selama 10 -15 menit




Demikianlah cara membuat roti unyil yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan terbukti, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
