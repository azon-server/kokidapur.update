---
description: "Resep : Pecel Lele &amp;amp; Sambal Tomat Favorite"
title: "Resep : Pecel Lele &amp;amp; Sambal Tomat Favorite"
slug: 319-resep-pecel-lele-and-amp-sambal-tomat-favorite
date: 2020-11-21T02:09:03.812Z
image: https://img-global.cpcdn.com/recipes/3326d397094c9ca8/680x482cq70/pecel-lele-sambal-tomat-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3326d397094c9ca8/680x482cq70/pecel-lele-sambal-tomat-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3326d397094c9ca8/680x482cq70/pecel-lele-sambal-tomat-foto-resep-utama.jpg
author: Micheal Day
ratingvalue: 4
reviewcount: 13026
recipeingredient:
- "500 gr ikan lele"
- "1 sdm air jeruk nipis"
- " Bumbu halus"
- "4 siung bawang putih"
- "2 cm jahe"
- "2 cm kunyit"
- "1 sdt garam"
- " Sambal tomat"
- "10 buah cabe rawit"
- "3 buah cabe keriting"
- "2 siung bawang putih"
- "4 siung bawang merah"
- "1 buah tomat"
- "1/2 sdt terasi"
- " Gula garam sckpnya"
recipeinstructions:
- "Ikan lele: bersihkan ikan lele, kerat2, kucuri air jeruk nipis, biarkan sebentar. Lumuri ikan dgn bumbu halus diamkan di kulkas saya simpan semalaman supaya bumbunya lbh meresep ke ikan, goreng dgn minyak panas yg banyak sampai garing.Sajikan ikan lele dgn sambal tomat dan aneka lalapan sayuran."
- "Sambal tomat: goreng semua bahan kecuali gula dan garam. Haluskan semua bahan, cicipi rasa."
categories:
- Recipe
tags:
- pecel
- lele
- 

katakunci: pecel lele  
nutrition: 121 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Lunch

---


![Pecel Lele &amp; Sambal Tomat](https://img-global.cpcdn.com/recipes/3326d397094c9ca8/680x482cq70/pecel-lele-sambal-tomat-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau empuk. Ciri kuliner Nusantara pecel lele &amp; sambal tomat yang kaya dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga dapat diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Pecel Lele &amp; Sambal Tomat untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang dapat anda contoh salah satunya pecel lele &amp; sambal tomat yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep pecel lele &amp; sambal tomat tanpa harus bersusah payah.
Seperti resep Pecel Lele &amp; Sambal Tomat yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 15 bahan dan 2 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Pecel Lele &amp; Sambal Tomat:

1. Harap siapkan 500 gr ikan lele
1. Harap siapkan 1 sdm air jeruk nipis
1. Harus ada  Bumbu halus:
1. Tambah 4 siung bawang putih
1. Diperlukan 2 cm jahe
1. Dibutuhkan 2 cm kunyit
1. Siapkan 1 sdt garam
1. Siapkan  Sambal tomat:
1. Tambah 10 buah cabe rawit
1. Siapkan 3 buah cabe keriting
1. Dibutuhkan 2 siung bawang putih
1. Siapkan 4 siung bawang merah
1. Siapkan 1 buah tomat
1. Dibutuhkan 1/2 sdt terasi
1. Harus ada  Gula&amp; garam sckpnya




<!--inarticleads2-->

##### Bagaimana membuat  Pecel Lele &amp; Sambal Tomat:

1. Ikan lele: bersihkan ikan lele, kerat2, kucuri air jeruk nipis, biarkan sebentar. Lumuri ikan dgn bumbu halus diamkan di kulkas saya simpan semalaman supaya bumbunya lbh meresep ke ikan, goreng dgn minyak panas yg banyak sampai garing.Sajikan ikan lele dgn sambal tomat dan aneka lalapan sayuran.
1. Sambal tomat: goreng semua bahan kecuali gula dan garam. Haluskan semua bahan, cicipi rasa.




Demikianlah cara membuat pecel lele &amp; sambal tomat yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
