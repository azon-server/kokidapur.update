---
description: "Steps membuat Sambal Tumpang aka tempe busuk Cepat"
title: "Steps membuat Sambal Tumpang aka tempe busuk Cepat"
slug: 486-steps-membuat-sambal-tumpang-aka-tempe-busuk-cepat
date: 2021-02-28T12:29:23.490Z
image: https://img-global.cpcdn.com/recipes/e9984f93f253ca19/680x482cq70/sambal-tumpang-aka-tempe-busuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e9984f93f253ca19/680x482cq70/sambal-tumpang-aka-tempe-busuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e9984f93f253ca19/680x482cq70/sambal-tumpang-aka-tempe-busuk-foto-resep-utama.jpg
author: Myrtle Parks
ratingvalue: 4
reviewcount: 32083
recipeingredient:
- "2 papan tempe busuk"
- "1 papan tempe sehat"
- "8 ulas bawang merah"
- "8 ulas bawang putih"
- "4 ulas kencur"
- "4 biji kemiri"
- "5 biji cabe merah besar"
- "2 genggam tangan cabe rawit"
- "8 helai daun salam"
- "4 helai daun jeruk purut"
- "1 sendok makan ketumbar bisa biji halus"
- "4 sendok makan udang rebon kering"
- "2 sendok teh garam"
- "2 sendok makan gula putih"
- "500 ml santan"
- " Pelengkap 4 biji tahu masintahu goreng"
recipeinstructions:
- "Rebus tempe dan aneka bumbu jadi satu,kecuali ketumbar rebusnya sampai air menyusut ya air bekas rebusan jangan di buang,udang rebonnya di sisihkan dulu"
- "Ulek tempe sampai hancur"
- "Ulek/blender semua bumbu kecuali dedaunan"
- "Masukkan semua bahan dan bumbu ke dalam panci yang berisi air rebusan tadi,masak sampai mendidih"
- "Tambahkan santan masak sampai mendidih(di aduk ya biar santan gak pecah),tes rasa terakhir masuk kan tahu goreng"
- "Dan siap di sajikan"
categories:
- Recipe
tags:
- sambal
- tumpang
- aka

katakunci: sambal tumpang aka 
nutrition: 292 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Dessert

---


![Sambal Tumpang aka tempe busuk](https://img-global.cpcdn.com/recipes/e9984f93f253ca19/680x482cq70/sambal-tumpang-aka-tempe-busuk-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti sambal tumpang aka tempe busuk yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Kita



Kehangatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Sambal Tumpang aka tempe busuk untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang dapat anda contoh salah satunya sambal tumpang aka tempe busuk yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep sambal tumpang aka tempe busuk tanpa harus bersusah payah.
Seperti resep Sambal Tumpang aka tempe busuk yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambal Tumpang aka tempe busuk:

1. Harus ada 2 papan tempe busuk
1. Harap siapkan 1 papan tempe sehat
1. Jangan lupa 8 ulas bawang merah
1. Harap siapkan 8 ulas bawang putih
1. Harap siapkan 4 ulas kencur
1. Siapkan 4 biji kemiri
1. Diperlukan 5 biji cabe merah besar
1. Dibutuhkan 2 genggam tangan cabe rawit
1. Harap siapkan 8 helai daun salam
1. Siapkan 4 helai daun jeruk purut
1. Dibutuhkan 1 sendok makan ketumbar (bisa biji /halus)
1. Diperlukan 4 sendok makan udang rebon kering
1. Diperlukan 2 sendok teh garam
1. Harus ada 2 sendok makan gula putih
1. Diperlukan 500 ml santan
1. Tambah  Pelengkap 4 biji tahu masin(tahu goreng)




<!--inarticleads2-->

##### Instruksi membuat  Sambal Tumpang aka tempe busuk:

1. Rebus tempe dan aneka bumbu jadi satu,kecuali ketumbar rebusnya sampai air menyusut ya air bekas rebusan jangan di buang,udang rebonnya di sisihkan dulu
1. Ulek tempe sampai hancur
1. Ulek/blender semua bumbu kecuali dedaunan
1. Masukkan semua bahan dan bumbu ke dalam panci yang berisi air rebusan tadi,masak sampai mendidih
1. Tambahkan santan masak sampai mendidih(di aduk ya biar santan gak pecah),tes rasa terakhir masuk kan tahu goreng
1. Dan siap di sajikan




Demikianlah cara membuat sambal tumpang aka tempe busuk yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
