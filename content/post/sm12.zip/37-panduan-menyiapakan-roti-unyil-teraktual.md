---
description: "Panduan menyiapakan Roti Unyil teraktual"
title: "Panduan menyiapakan Roti Unyil teraktual"
slug: 37-panduan-menyiapakan-roti-unyil-teraktual
date: 2021-02-10T21:32:00.992Z
image: https://img-global.cpcdn.com/recipes/517fc1be7ea42832/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/517fc1be7ea42832/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/517fc1be7ea42832/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Isabella Morris
ratingvalue: 4.1
reviewcount: 17178
recipeingredient:
- " Bahan A"
- "300 gr tepung terigu protein tinggi"
- "3 gr ragi instan"
- "30 gr gula pasir"
- "10 gr susu bubuk"
- " Bahan B "
- "1 butir telur 25gr untuk adonan dan sisanya untuk egg wash"
- "135 gr air"
- "50 ml susu"
- " Bahan C "
- "30 gr margarine"
- "3 gr garam"
recipeinstructions:
- "Campur bahan A tambahkan bahan B, aduk dengan mixer slow speed sampai semua bahan kering tercampur"
- "Ketika semua bahan kering tidak ada lagi yang menempel di mangkok ubah menjadi fast speed sampai setengah kalis. Kalau adonan mulai halus, stop mixer sebentar dan tambahkan bahan C (mentega harus sudah lembut tapi tidak cair)"
- "Aduk kembali sampai mentega tercampur rata dan adonan menjadi mengkilap. Untuk tahu kalau adonan sudah ready boleh di test dengan window pane (ambil sedikit adonan, bulatkan, lalu tarik tarik dengan jari sampai bisa stretch tanpa merobek adonan). Tutup mangkok dan simpan di tempat lembab dan hangat kira-kira 1 jam sampai ukuran mengembang 2x lipat."
- "Setelah mengembang 2xnya kempeskan adonan dan bagi menjadi beberapa bagian adonan sama besar @20gr. Bentuk sesuai keinginan."
- "Bisa diisi coklat dan keju gulung dan gunting bagian atasnya tp jgn sampe putus"
- "Beri isian meses lalu bentuk bulat dan taburin dengan meses di atasnya"
- "Gilas adonan dan beri isian meses lalu gilas lagi dan potong setengah bagian dan gulung dan bentuk menjadi lingkaran"
- "Bagi adonan menjadi 3 bagian dan kepang adonan"
- "Beri isian sosis dan gulung dan potong bagian atasnya jangan sampe putus"
- "Ambil setengah bagian sosis dan taruh di atas adonan lalu gulung kemudian potong-potong jangan sampe putus dan tarik sejajar tiap potongan membentuk seperti papan bermata sosis"
- "Ambil adonan isi dengan meses lalu tutup kembali sampe rapat kemudian potong menjadi 4 bagian dan potong lagi 4 bagian sehingga menyerupai bunga"
- "Setelah semua adonan terbentuk letakkan di loyang. Beri jarak. Simpan kembali di tempat hangat dan lembab (tidak usah ditutup) kira-kira 20 menit."
- "Panaskan oven 175⁰C. Kalau adonan mulai terlihat agak transparant. Oleskan egg wash dan bakar 15 menit. Putar bila warna tidak merata. Setelah matang angkat dan siap di nikmatin. Selamat mencoba"
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 134 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Dinner

---


![Roti Unyil](https://img-global.cpcdn.com/recipes/517fc1be7ea42832/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan renyah. Ciri khas kuliner Indonesia roti unyil yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah memasak Roti Unyil untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang dapat anda praktekkan salah satunya roti unyil yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep roti unyil tanpa harus bersusah payah.
Berikut ini resep Roti Unyil yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 13 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Unyil:

1. Dibutuhkan  Bahan A:
1. Jangan lupa 300 gr tepung terigu protein tinggi
1. Diperlukan 3 gr ragi instan
1. Tambah 30 gr gula pasir
1. Diperlukan 10 gr susu bubuk
1. Harap siapkan  Bahan B :
1. Siapkan 1 butir telur (25gr untuk adonan dan sisanya untuk egg wash)
1. Siapkan 135 gr air
1. Siapkan 50 ml susu
1. Tambah  Bahan C :
1. Harap siapkan 30 gr margarine
1. Harap siapkan 3 gr garam




<!--inarticleads2-->

##### Instruksi membuat  Roti Unyil:

1. Campur bahan A tambahkan bahan B, aduk dengan mixer slow speed sampai semua bahan kering tercampur
1. Ketika semua bahan kering tidak ada lagi yang menempel di mangkok ubah menjadi fast speed sampai setengah kalis. Kalau adonan mulai halus, stop mixer sebentar dan tambahkan bahan C (mentega harus sudah lembut tapi tidak cair)
1. Aduk kembali sampai mentega tercampur rata dan adonan menjadi mengkilap. Untuk tahu kalau adonan sudah ready boleh di test dengan window pane (ambil sedikit adonan, bulatkan, lalu tarik tarik dengan jari sampai bisa stretch tanpa merobek adonan). Tutup mangkok dan simpan di tempat lembab dan hangat kira-kira 1 jam sampai ukuran mengembang 2x lipat.
1. Setelah mengembang 2xnya kempeskan adonan dan bagi menjadi beberapa bagian adonan sama besar @20gr. Bentuk sesuai keinginan.
1. Bisa diisi coklat dan keju gulung dan gunting bagian atasnya tp jgn sampe putus
1. Beri isian meses lalu bentuk bulat dan taburin dengan meses di atasnya
1. Gilas adonan dan beri isian meses lalu gilas lagi dan potong setengah bagian dan gulung dan bentuk menjadi lingkaran
1. Bagi adonan menjadi 3 bagian dan kepang adonan
1. Beri isian sosis dan gulung dan potong bagian atasnya jangan sampe putus
1. Ambil setengah bagian sosis dan taruh di atas adonan lalu gulung kemudian potong-potong jangan sampe putus dan tarik sejajar tiap potongan membentuk seperti papan bermata sosis
1. Ambil adonan isi dengan meses lalu tutup kembali sampe rapat kemudian potong menjadi 4 bagian dan potong lagi 4 bagian sehingga menyerupai bunga
1. Setelah semua adonan terbentuk letakkan di loyang. Beri jarak. Simpan kembali di tempat hangat dan lembab (tidak usah ditutup) kira-kira 20 menit.
1. Panaskan oven 175⁰C. Kalau adonan mulai terlihat agak transparant. Oleskan egg wash dan bakar 15 menit. Putar bila warna tidak merata. Setelah matang angkat dan siap di nikmatin. Selamat mencoba




Demikianlah cara membuat roti unyil yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan terbukti, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
