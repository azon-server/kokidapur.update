---
description: "Bagaimana untuk menyiapakan Sambal Tumpang dan Jenang Lemu khas Salatiga Homemade"
title: "Bagaimana untuk menyiapakan Sambal Tumpang dan Jenang Lemu khas Salatiga Homemade"
slug: 349-bagaimana-untuk-menyiapakan-sambal-tumpang-dan-jenang-lemu-khas-salatiga-homemade
date: 2020-12-17T03:41:16.636Z
image: https://img-global.cpcdn.com/recipes/93302711c8a83e25/680x482cq70/sambal-tumpang-dan-jenang-lemu-khas-salatiga-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/93302711c8a83e25/680x482cq70/sambal-tumpang-dan-jenang-lemu-khas-salatiga-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/93302711c8a83e25/680x482cq70/sambal-tumpang-dan-jenang-lemu-khas-salatiga-foto-resep-utama.jpg
author: Teresa Daniel
ratingvalue: 4.5
reviewcount: 14306
recipeingredient:
- "125 gram koyor sapi di ganti dengan krecek"
- "1 papan tempe waras"
- "3 bungkus tempe bosok skip"
- "600 ml air"
- "500 ml santan sedang"
- " Bumbu halus"
- "3 cabe merah besar buang bijinya"
- "10 buah bawang merah"
- "3 siung bawang putih"
- "3 ruas kencur"
- "Secukupnya garam"
- "Secukupnya gula pasir"
- " Bumbu dapur"
- "5 lembar daun jeruk segar"
- "2 lembar daun salam"
- "1 ruas lengkuas geprek"
- " Pelengkap"
- "Secukupnya Kaldu bubuk sapi optional"
- "Segenggam cabe rawit merah"
- " Jenang Lemu bubur"
- "2 cup beras putih"
- "500 l tambah air secukupnya smp bubur matang"
- "2 lbr daur salam"
- "Secukupnya garam"
- "Secukupnya santan saya skip"
recipeinstructions:
- "Rebus tempe waras, tempe bosok lalu angkat dan tiriskan. Rendam pula krecek dalam air, sisihkan"
- "Tambahkan bawang merah, bawang putih, cabe merah, kencur, daun salam, daun jeruk segar, dan lengkuas yang sudah digeprek hingga mendidih, matikan api haluskan bawang merah, bawang putih, cabe merah, kencur, daun jeruk, haluskan juga tempe waras dan tempe busuk (tingkat kehalusan atau agak kasar disesuaikan selera) masukkan kembali bersama krecek kedalam air rebusan tadi. Masak hingga krecek lembut dan bumbu meresap."
- "Tambahkan santan aduk hingga rata, bisa tambahkan cabe rawit merah utuh kedalamnya, bumbui dengan gula, garam dan kaldu bubuk aduk rata, koreksi rasa,"
- "Bubur/jenang lemu, masukan jadi satu dalam panci semua bahan jenang lemu (bubur) kecuali santan terakhir. Masak sambil sesekali di aduk agar tidak gosong. Masak hingga bubur matang dan kental, masukan santan dan cek rasa."
- "Sajikan sambal tumpang dengan bubur/jenang lemu atau rebusan sayuran (seperti sayuran untuk pecel) serta krupuk karak. Selamat mencoba."
categories:
- Recipe
tags:
- sambal
- tumpang
- dan

katakunci: sambal tumpang dan 
nutrition: 173 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Lunch

---


![Sambal Tumpang dan Jenang Lemu khas Salatiga](https://img-global.cpcdn.com/recipes/93302711c8a83e25/680x482cq70/sambal-tumpang-dan-jenang-lemu-khas-salatiga-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan gurih. Ciri kuliner Indonesia sambal tumpang dan jenang lemu khas salatiga yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Sambal Tumpang dan Jenang Lemu khas Salatiga untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang dapat anda coba salah satunya sambal tumpang dan jenang lemu khas salatiga yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep sambal tumpang dan jenang lemu khas salatiga tanpa harus bersusah payah.
Berikut ini resep Sambal Tumpang dan Jenang Lemu khas Salatiga yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 25 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambal Tumpang dan Jenang Lemu khas Salatiga:

1. Siapkan 125 gram koyor sapi di ganti dengan krecek
1. Tambah 1 papan tempe waras
1. Tambah 3 bungkus tempe bosok (skip)
1. Harus ada 600 ml air
1. Harus ada 500 ml santan sedang
1. Harus ada  Bumbu halus
1. Jangan lupa 3 cabe merah besar buang bijinya
1. Tambah 10 buah bawang merah
1. Siapkan 3 siung bawang putih
1. Jangan lupa 3 ruas kencur
1. Siapkan Secukupnya garam
1. Siapkan Secukupnya gula pasir
1. Harap siapkan  Bumbu dapur
1. Harap siapkan 5 lembar daun jeruk segar
1. Dibutuhkan 2 lembar daun salam
1. Jangan lupa 1 ruas lengkuas geprek
1. Harap siapkan  Pelengkap
1. Diperlukan Secukupnya Kaldu bubuk sapi (optional)
1. Dibutuhkan Segenggam cabe rawit merah
1. Dibutuhkan  Jenang Lemu (bubur)
1. Dibutuhkan 2 cup beras putih
1. Diperlukan 500 l (tambah air secukupnya smp bubur matang)
1. Siapkan 2 lbr daur salam
1. Harus ada Secukupnya garam
1. Harap siapkan Secukupnya santan (saya skip)




<!--inarticleads2-->

##### Langkah membuat  Sambal Tumpang dan Jenang Lemu khas Salatiga:

1. Rebus tempe waras, tempe bosok lalu angkat dan tiriskan. Rendam pula krecek dalam air, sisihkan
1. Tambahkan bawang merah, bawang putih, cabe merah, kencur, daun salam, daun jeruk segar, dan lengkuas yang sudah digeprek hingga mendidih, matikan api haluskan bawang merah, bawang putih, cabe merah, kencur, daun jeruk, haluskan juga tempe waras dan tempe busuk (tingkat kehalusan atau agak kasar disesuaikan selera) masukkan kembali bersama krecek kedalam air rebusan tadi. Masak hingga krecek lembut dan bumbu meresap.
1. Tambahkan santan aduk hingga rata, bisa tambahkan cabe rawit merah utuh kedalamnya, bumbui dengan gula, garam dan kaldu bubuk aduk rata, koreksi rasa,
1. Bubur/jenang lemu, masukan jadi satu dalam panci semua bahan jenang lemu (bubur) kecuali santan terakhir. Masak sambil sesekali di aduk agar tidak gosong. Masak hingga bubur matang dan kental, masukan santan dan cek rasa.
1. Sajikan sambal tumpang dengan bubur/jenang lemu atau rebusan sayuran (seperti sayuran untuk pecel) serta krupuk karak. Selamat mencoba.




Demikianlah cara membuat sambal tumpang dan jenang lemu khas salatiga yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan terbukti, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
