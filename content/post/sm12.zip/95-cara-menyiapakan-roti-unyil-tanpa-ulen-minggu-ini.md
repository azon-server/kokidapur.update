---
description: "Cara menyiapakan Roti Unyil (tanpa ulen) minggu ini"
title: "Cara menyiapakan Roti Unyil (tanpa ulen) minggu ini"
slug: 95-cara-menyiapakan-roti-unyil-tanpa-ulen-minggu-ini
date: 2021-01-01T04:45:48.249Z
image: https://img-global.cpcdn.com/recipes/c72da0c8337ff22c/680x482cq70/roti-unyil-tanpa-ulen-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c72da0c8337ff22c/680x482cq70/roti-unyil-tanpa-ulen-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c72da0c8337ff22c/680x482cq70/roti-unyil-tanpa-ulen-foto-resep-utama.jpg
author: Leonard Washington
ratingvalue: 4.4
reviewcount: 10870
recipeingredient:
- "300 gr terigu protein tinggi"
- "50 gr gula pasir"
- "40 gr susu bubuk"
- "4 gr ragi instant1 sdt"
- "1 butir telur sisakan sedikit untuk polesan"
- "100 ml air"
- "40 gr butter"
- "1/2 sdt garam halus"
- " Bahan tangzhong"
- "2 sdm peres terigu"
- "100 ml air"
- " Bahan isian sesuai selera"
- " Selai coklat"
- "Irisan sosis"
- "Irisan keju soft"
recipeinstructions:
- "Adonan biang tangzhong dibuat terlebih dahulu. Campur bahan tangzhong dalam panci kecil. Panaskan diatas kompor, api kecil saja, sembari diaduk hingga tampak menggumpal. Matikan api. Biarkan hangat"
- "Campur semua bahan roti (kecuali butter dan garam) dan adonan tangzhong dalam wadah. Aduk rata dengan tangan."
- "Tambahkan butter dan garam. Aduk rata kembali dengan tangan hinggal kalis, tidak lengket ditangan"
- "Tutup dengan plastik wrap, simpan ditempat hangat hingga mengembang 2x lipat. Karena cuaca mendung, adonan saya perlu 3 jam untuk mengembang"
- "Setelah mengembang, ambil adonan, pindahkan ke alas datar, uleni sebentar. Kemudian bagi menjadi beberapa bagian kecil. Diamkan 15 menit sebelum diisi."
- "Ambil 1 buah adonan, bentuk sesuai selera dan isi sesuai keinginan. Lakukan hingga semua adonan habis dibentuk"
- "Ini salah satu cara membentuk roti unyil isian keju"
- "Tata roti unyil pada loyang yang sudah dialasi kertas roti. Diamkan 30 menit, kemudian poles dengan dengan kocokkan telur. Beri topping. Panggang dengan api sedang (175⁰C)10 menit kemudian turunkan suhu oven, panggang lagi 5 menit"
- "Beri polesan butter saat roti unyil keluar dari oven supaya tampak berkilat dan lembab."
categories:
- Recipe
tags:
- roti
- unyil
- tanpa

katakunci: roti unyil tanpa 
nutrition: 149 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT50M"
recipeyield: "1"
recipecategory: Dinner

---


![Roti Unyil (tanpa ulen)](https://img-global.cpcdn.com/recipes/c72da0c8337ff22c/680x482cq70/roti-unyil-tanpa-ulen-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga gurih. Ciri masakan Indonesia roti unyil (tanpa ulen) yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah membuat makanan Roti Unyil (tanpa ulen) untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang bisa anda coba salah satunya roti unyil (tanpa ulen) yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep roti unyil (tanpa ulen) tanpa harus bersusah payah.
Seperti resep Roti Unyil (tanpa ulen) yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 9 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Unyil (tanpa ulen):

1. Harus ada 300 gr terigu protein tinggi
1. Tambah 50 gr gula pasir
1. Siapkan 40 gr susu bubuk
1. Jangan lupa 4 gr ragi instant/1 sdt
1. Jangan lupa 1 butir telur (sisakan sedikit untuk polesan)
1. Jangan lupa 100 ml air
1. Harus ada 40 gr butter
1. Diperlukan 1/2 sdt garam halus
1. Harus ada  Bahan tangzhong:
1. Harap siapkan 2 sdm peres terigu
1. Harus ada 100 ml air
1. Harap siapkan  Bahan isian (sesuai selera)
1. Jangan lupa  Selai coklat
1. Harap siapkan Irisan sosis
1. Harus ada Irisan keju soft




<!--inarticleads2-->

##### Langkah membuat  Roti Unyil (tanpa ulen):

1. Adonan biang tangzhong dibuat terlebih dahulu. Campur bahan tangzhong dalam panci kecil. Panaskan diatas kompor, api kecil saja, sembari diaduk hingga tampak menggumpal. Matikan api. Biarkan hangat
1. Campur semua bahan roti (kecuali butter dan garam) dan adonan tangzhong dalam wadah. Aduk rata dengan tangan.
1. Tambahkan butter dan garam. Aduk rata kembali dengan tangan hinggal kalis, tidak lengket ditangan
1. Tutup dengan plastik wrap, simpan ditempat hangat hingga mengembang 2x lipat. Karena cuaca mendung, adonan saya perlu 3 jam untuk mengembang
1. Setelah mengembang, ambil adonan, pindahkan ke alas datar, uleni sebentar. Kemudian bagi menjadi beberapa bagian kecil. Diamkan 15 menit sebelum diisi.
1. Ambil 1 buah adonan, bentuk sesuai selera dan isi sesuai keinginan. Lakukan hingga semua adonan habis dibentuk
1. Ini salah satu cara membentuk roti unyil isian keju
1. Tata roti unyil pada loyang yang sudah dialasi kertas roti. Diamkan 30 menit, kemudian poles dengan dengan kocokkan telur. Beri topping. Panggang dengan api sedang (175⁰C)10 menit kemudian turunkan suhu oven, panggang lagi 5 menit
1. Beri polesan butter saat roti unyil keluar dari oven supaya tampak berkilat dan lembab.




Demikianlah cara membuat roti unyil (tanpa ulen) yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat gampang dan teruji, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
