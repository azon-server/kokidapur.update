---
description: "Langkah untuk membuat Nasi Pecel Sambal Tumpang Khas Jawa Timur Terbukti"
title: "Langkah untuk membuat Nasi Pecel Sambal Tumpang Khas Jawa Timur Terbukti"
slug: 422-langkah-untuk-membuat-nasi-pecel-sambal-tumpang-khas-jawa-timur-terbukti
date: 2020-12-10T12:58:22.160Z
image: https://img-global.cpcdn.com/recipes/58b213b5d1e58c7e/680x482cq70/nasi-pecel-sambal-tumpang-khas-jawa-timur-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/58b213b5d1e58c7e/680x482cq70/nasi-pecel-sambal-tumpang-khas-jawa-timur-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/58b213b5d1e58c7e/680x482cq70/nasi-pecel-sambal-tumpang-khas-jawa-timur-foto-resep-utama.jpg
author: Anthony Fitzgerald
ratingvalue: 4.1
reviewcount: 2756
recipeingredient:
- " Sayur Rebus "
- "1 Ikat Kangkung"
- "1/2 Buah Kubis"
- "2 Genggam Tauge"
- "8 Buah Kacang Panjang"
- " Bahan Sambal Tumpang "
- "200 Gram Tempe Busuk Tempe segar setelah disimpan 23 hari"
- "2 Butir Kemiri"
- "5 Buah Bawang Merah"
- "3 Buah Bawang Putih"
- "Buah Cabai Merah Besar"
- "Buah Cabai Rawit"
- "1/2 ruas Lengkuas Geprek"
- "2 Lembar Daun Salam"
- "Sedikit Kencur"
- "Secukupnya Gula"
- "Secukupnya Garam"
- "Secukupnya Kaldu Bubuk"
- " Bahan Sambal Goreng "
- "1/2 Papan Tempe"
- "3 Buah Tahu"
- "2 Lembar Daun Salam"
- "3 Buah Cabai hijau besar iris serong"
- "Secukupnya GaramGulaKaldu Bubuk"
- "Secukupnya Kecap Manis"
- "Secukupnya Lada Bubuk"
- " Bumbu Halus Sambal Goreng"
- "2 Butir Kemiri"
- "5 Buah Bawang Merah"
- "2 Buah Bawang Putih"
- "5 Buah Cabai Rawit"
- "1/2 Ruas Jahe"
- "1/2 Ruas Lengkuas"
- " Bahan Rempeyek Kacang "
- "100 Gram Tepung Beras"
- "1 Butir Putih Telur"
- "Secukupnya Kacang Tanah belah jadi 2"
- "3 Lembar Daun Jeruk"
- "Secukupnya Air"
- "Secukupnya GaramKaldu Bubuk"
- "1/4 Santan Kara Cair 65 ml"
- " Bumbu Halus Rempeyek"
- "4 Buah Cabai Rawit boleh skip atau ditambah sesuai selera"
- "2 Buah Kemiri"
- "1 Sdm Ketumbar"
- "1 Ruas Kunyit"
- " Pelengkap "
- "Secukupnya Kerupuk"
- "Secukupnya Sambal Kacang larutkan dengan air panas"
- "Secukupnya Telur CeplokDadar Goreng"
- "Secukupnya TahuTempe Goreng"
recipeinstructions:
- "Rebus sayur kangkung, kubis, kacang panjang dan Rendam tauge dengan air panas lalu tiriskan."
- "Kita buat sambal tumpangnya terlebih dahulu, rebus bahan dan tempe sampai matang. Kemudian tumbuk hingga halus kecuali lengkuas. Air rebusan sisihkan, jangan dibuang."
- "Rebus bumbu yang sudah dihaluskan dan juga tempe menggunakan air bekas rebusan tadi. Bumbui dengan garam, gula, kaldu bubuk, lengkuas,dan daun salam. Tambahkan santan kara. Aduk rata tunggu hingga mendidih dan mengental. Finally, koreksi rasa sajikan"
- "Selanjutnya kita buat Sambal goreng. Potong tahu tempe lalu goreng setengah matang."
- "Tumbu bumbu halus, lalu tumis hingga harum. Tambahkan Daun salam dan cabai hijau, masukkan tahu tempe dan tambahkan garam, gula, kaldu bubuk, dan kecap manis. Aduk rata tunggu hingga matang."
- "Lanjut kita buat adonan rempeyek. Tumbuk bumbu halus dan tambahkan kacang tanah, irisan daun jeruk, putih telur, air,dan santan. Lalu goreng dengan minyak panas hingga matang."
- "Nasi Pecel Sambal Tumpang siap dihidangkann.. 😊"
categories:
- Recipe
tags:
- nasi
- pecel
- sambal

katakunci: nasi pecel sambal 
nutrition: 153 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Lunch

---


![Nasi Pecel Sambal Tumpang Khas Jawa Timur](https://img-global.cpcdn.com/recipes/58b213b5d1e58c7e/680x482cq70/nasi-pecel-sambal-tumpang-khas-jawa-timur-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau gurih. Karasteristik masakan Indonesia nasi pecel sambal tumpang khas jawa timur yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Nasi Pecel Sambal Tumpang Khas Jawa Timur untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang dapat anda praktekkan salah satunya nasi pecel sambal tumpang khas jawa timur yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep nasi pecel sambal tumpang khas jawa timur tanpa harus bersusah payah.
Berikut ini resep Nasi Pecel Sambal Tumpang Khas Jawa Timur yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 51 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Nasi Pecel Sambal Tumpang Khas Jawa Timur:

1. Harus ada  Sayur Rebus :
1. Harus ada 1 Ikat Kangkung
1. Harus ada 1/2 Buah Kubis
1. Harap siapkan 2 Genggam Tauge
1. Harus ada 8 Buah Kacang Panjang
1. Jangan lupa  Bahan Sambal Tumpang :
1. Diperlukan 200 Gram Tempe Busuk (Tempe segar setelah disimpan 2-3 hari)
1. Diperlukan 2 Butir Kemiri
1. Diperlukan 5 Buah Bawang Merah
1. Harus ada 3 Buah Bawang Putih
1. Tambah Buah Cabai Merah Besar
1. Dibutuhkan Buah Cabai Rawit
1. Harap siapkan 1/2 ruas Lengkuas Geprek
1. Jangan lupa 2 Lembar Daun Salam
1. Dibutuhkan Sedikit Kencur
1. Harap siapkan Secukupnya Gula
1. Jangan lupa Secukupnya Garam
1. Siapkan Secukupnya Kaldu Bubuk
1. Diperlukan  Bahan Sambal Goreng :
1. Tambah 1/2 Papan Tempe
1. Tambah 3 Buah Tahu
1. Harap siapkan 2 Lembar Daun Salam
1. Tambah 3 Buah Cabai hijau besar, iris serong
1. Siapkan Secukupnya Garam+Gula+Kaldu Bubuk
1. Diperlukan Secukupnya Kecap Manis
1. Harus ada Secukupnya Lada Bubuk
1. Tambah  Bumbu Halus Sambal Goreng:
1. Jangan lupa 2 Butir Kemiri
1. Jangan lupa 5 Buah Bawang Merah
1. Tambah 2 Buah Bawang Putih
1. Dibutuhkan 5 Buah Cabai Rawit
1. Harap siapkan 1/2 Ruas Jahe
1. Tambah 1/2 Ruas Lengkuas
1. Diperlukan  Bahan Rempeyek Kacang :
1. Siapkan 100 Gram Tepung Beras
1. Harap siapkan 1 Butir Putih Telur
1. Siapkan Secukupnya Kacang Tanah, belah jadi 2
1. Jangan lupa 3 Lembar Daun Jeruk
1. Harap siapkan Secukupnya Air
1. Tambah Secukupnya Garam+Kaldu Bubuk
1. Diperlukan 1/4 Santan Kara Cair 65 ml
1. Harap siapkan  Bumbu Halus Rempeyek:
1. Harus ada 4 Buah Cabai Rawit, boleh skip atau ditambah sesuai selera
1. Diperlukan 2 Buah Kemiri
1. Dibutuhkan 1 Sdm Ketumbar
1. Diperlukan 1 Ruas Kunyit
1. Tambah  Pelengkap :
1. Dibutuhkan Secukupnya Kerupuk
1. Siapkan Secukupnya Sambal Kacang, larutkan dengan air panas
1. Diperlukan Secukupnya Telur Ceplok/Dadar Goreng
1. Siapkan Secukupnya Tahu/Tempe Goreng




<!--inarticleads2-->

##### Instruksi membuat  Nasi Pecel Sambal Tumpang Khas Jawa Timur:

1. Rebus sayur kangkung, kubis, kacang panjang dan Rendam tauge dengan air panas lalu tiriskan.
1. Kita buat sambal tumpangnya terlebih dahulu, rebus bahan dan tempe sampai matang. Kemudian tumbuk hingga halus kecuali lengkuas. Air rebusan sisihkan, jangan dibuang.
1. Rebus bumbu yang sudah dihaluskan dan juga tempe menggunakan air bekas rebusan tadi. Bumbui dengan garam, gula, kaldu bubuk, lengkuas,dan daun salam. Tambahkan santan kara. Aduk rata tunggu hingga mendidih dan mengental. Finally, koreksi rasa sajikan
1. Selanjutnya kita buat Sambal goreng. Potong tahu tempe lalu goreng setengah matang.
1. Tumbu bumbu halus, lalu tumis hingga harum. Tambahkan Daun salam dan cabai hijau, masukkan tahu tempe dan tambahkan garam, gula, kaldu bubuk, dan kecap manis. Aduk rata tunggu hingga matang.
1. Lanjut kita buat adonan rempeyek. Tumbuk bumbu halus dan tambahkan kacang tanah, irisan daun jeruk, putih telur, air,dan santan. Lalu goreng dengan minyak panas hingga matang.
1. Nasi Pecel Sambal Tumpang siap dihidangkann.. 😊




Demikianlah cara membuat nasi pecel sambal tumpang khas jawa timur yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan cepat, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
