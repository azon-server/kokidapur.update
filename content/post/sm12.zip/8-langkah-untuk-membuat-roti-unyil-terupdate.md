---
description: "Langkah untuk membuat RoTi Unyil terupdate"
title: "Langkah untuk membuat RoTi Unyil terupdate"
slug: 8-langkah-untuk-membuat-roti-unyil-terupdate
date: 2020-11-04T23:30:31.753Z
image: https://img-global.cpcdn.com/recipes/d59e6442d6e5390c/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d59e6442d6e5390c/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d59e6442d6e5390c/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Mina Love
ratingvalue: 4.2
reviewcount: 19042
recipeingredient:
- "400 gr terigu protein tinggi"
- "100 gr terigu protein sedang"
- "30 gr susu bubuk"
- "75 gr gula pasir butiran halus"
- "11 gr ragi instan"
- "360 ml di dapat dari susu cair  1 kuning telur  2 telur utuh"
- "2 sdt garam"
- "60 gr butter"
- " BAHAN OLESAN 1"
- "1 telur utuh  12 sdt air"
- " BAHAN OLESAN 2 "
- "Secukup nya butter lelehkan"
- " ISIAN DAN TOPPING "
- "Secukup nya keju meses sosis biji wijen oregano kering"
recipeinstructions:
- "Campur semua bahan kering (tepung, gula, ragi, susu bubuk) kecuali garam dan butter aduk rata sisihkan. Kocok lepas 360 ml campuran susu dan telur"
- "Masukan campuran susu dan telur ke bahan kering sedikit demi sedikit sambil di ulen stop sekira nya sudah di dapat adonan lembek atau cukup air hasil adonan lengket. Lalu masukan butter dan garam ulenin hingga setengah kalis"
- "Mikser adonan sekitar 10 menit kalo mikser sudah panas stop lanjut ngulen pake tangan sekitar 5-10 menit atau sampe mikser adem lanjut lagi mikser sekitar 5-10 menit hingga di dapat adonan kalis tanda nya adonan bila di tarik tidak mudah robek #kunci roti empuk adonan kalis elastis. Lama mikser tergantung mikser masing2 yah, kalo aq ngeri mikser jebol kalo terlalu lama 😁"
- "Diamkan adonan hingga 2x lipat karena cuaca panas ga sampe 10 menit udh ngembang lalu tinju untuk mengeluarkan udara di adonan"
- "Bagi2 adonan sekitar 25gr kalo aq tapi biasa nya klo roti unyil itu 10gr segini aja aq mah ga sabar 🤭"
- "Lalu bentuk adonan sesuai selera. Ini masih ga jelas bentuk nya 🤭 untuk lebih jelas bisa liat di channel youtube nya bu fatmah bahlawan di situ jelas semua 😂. Istirahat kan roti sekitar 20 menit lalu oles menggunakan bahan olesan 1 langsung panggang sekitar 15 menit suhu 160 dc tergantung oven masing2 yah atau hingga kecoklatan. Aq pake otang menggunakan api sedang cenderung kecil"
- "Setelah matang keluarkan dari oven lalu langsung di oles menggunakan bahan olesan 2 diam kan hingga dingin"
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 137 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Dessert

---


![RoTi Unyil](https://img-global.cpcdn.com/recipes/d59e6442d6e5390c/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang harus kita jaga karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti roti unyil yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa kesan tersendiri yang merupakan keragaman Kita

Kehangatan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah membuat makanan RoTi Unyil untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang bisa anda contoh salah satunya roti unyil yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep roti unyil tanpa harus bersusah payah.
Berikut ini resep RoTi Unyil yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 14 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat RoTi Unyil:

1. Tambah 400 gr terigu protein tinggi
1. Harus ada 100 gr terigu protein sedang
1. Harap siapkan 30 gr susu bubuk
1. Harus ada 75 gr gula pasir butiran halus
1. Harus ada 11 gr ragi instan
1. Siapkan 360 ml di dapat dari (susu cair + 1 kuning telur + 2 telur utuh)
1. Siapkan 2 sdt garam
1. Dibutuhkan 60 gr butter
1. Diperlukan  BAHAN OLESAN 1:
1. Harus ada 1 telur utuh + 1/2 sdt air
1. Tambah  BAHAN OLESAN 2 :
1. Harus ada Secukup nya butter lelehkan
1. Tambah  ISIAN DAN TOPPING :
1. Siapkan Secukup nya keju, meses, sosis, biji wijen, oregano kering




<!--inarticleads2-->

##### Bagaimana membuat  RoTi Unyil:

1. Campur semua bahan kering (tepung, gula, ragi, susu bubuk) kecuali garam dan butter aduk rata sisihkan. Kocok lepas 360 ml campuran susu dan telur
1. Masukan campuran susu dan telur ke bahan kering sedikit demi sedikit sambil di ulen stop sekira nya sudah di dapat adonan lembek atau cukup air hasil adonan lengket. Lalu masukan butter dan garam ulenin hingga setengah kalis
1. Mikser adonan sekitar 10 menit kalo mikser sudah panas stop lanjut ngulen pake tangan sekitar 5-10 menit atau sampe mikser adem lanjut lagi mikser sekitar 5-10 menit hingga di dapat adonan kalis tanda nya adonan bila di tarik tidak mudah robek #kunci roti empuk adonan kalis elastis. Lama mikser tergantung mikser masing2 yah, kalo aq ngeri mikser jebol kalo terlalu lama 😁
1. Diamkan adonan hingga 2x lipat karena cuaca panas ga sampe 10 menit udh ngembang lalu tinju untuk mengeluarkan udara di adonan
1. Bagi2 adonan sekitar 25gr kalo aq tapi biasa nya klo roti unyil itu 10gr segini aja aq mah ga sabar 🤭
1. Lalu bentuk adonan sesuai selera. Ini masih ga jelas bentuk nya 🤭 untuk lebih jelas bisa liat di channel youtube nya bu fatmah bahlawan di situ jelas semua 😂. Istirahat kan roti sekitar 20 menit lalu oles menggunakan bahan olesan 1 langsung panggang sekitar 15 menit suhu 160 dc tergantung oven masing2 yah atau hingga kecoklatan. Aq pake otang menggunakan api sedang cenderung kecil
1. Setelah matang keluarkan dari oven lalu langsung di oles menggunakan bahan olesan 2 diam kan hingga dingin




Demikianlah cara membuat roti unyil yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
