---
description: "Cara untuk membuat Sambel Tumpang khas solo Homemade"
title: "Cara untuk membuat Sambel Tumpang khas solo Homemade"
slug: 340-cara-untuk-membuat-sambel-tumpang-khas-solo-homemade
date: 2021-02-14T18:45:43.307Z
image: https://img-global.cpcdn.com/recipes/bf825116dd542d6c/680x482cq70/sambel-tumpang-khas-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bf825116dd542d6c/680x482cq70/sambel-tumpang-khas-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bf825116dd542d6c/680x482cq70/sambel-tumpang-khas-solo-foto-resep-utama.jpg
author: Lucille Andrews
ratingvalue: 4.6
reviewcount: 12872
recipeingredient:
- "1/4 papan Tempe semangit"
- "Secukupnya tempe biasa sy 14 papan"
- "3 tahu putih potong kecil"
- "1 sds santan Sasa santan asli"
- "2 daun salam"
- "2 lembar daun jeruk"
- "1 ruas lengkuas"
- "3 buah cabe rawit utuh sesuai selera saya 6buah"
- "Secukupnya garam"
- "Secukupnya penyedap optional"
- "Secukupnya gula jawa"
- "Secukupnya gula pasir"
- "800 ml airsesuai selera"
- " Minyak secukupnya untuk menggoreng dan menumis"
- " Bumbu Halus "
- "6 siung Bawang merah"
- "3 siung Bawang putih"
- "2 ruas kencur"
- "3 buah Kemiri"
- "3 buah Cabe merah besar"
- "15 buah Cabe rawitboleh pake boleh tidak"
recipeinstructions:
- "Goreng tahu sampai berkulit. Sisihkan."
- "Masukkan air, tempe, bawang putih, bawang merah, cabe besar, kencur. Rebus hingga matang. (Jangan buang airnya)"
- "Tiriskan bumbu yang sudah direbus (bawang putih, bawang merah, kencur, cabai) + kemiri kemudian haluskan. Tumis sampai harum, masukkan dalam air rebusan. (Bisa langsung masukan ke air rebusan tanpa ditumis)"
- "Tiriskan tempe dan haluskan, masukkan dalam rebusan."
- "Panaskan kembali rebusan air berisi tempe dan bumbu halus, masukkan garam, penyedap gula, daun salam, daun jeruk, lengkuas. Tggu smpai mendidih."
- "Masukkan tahu. Koreksi rasa. Jika sudah pas masukkan santan dan rawit utuh."
- "Masak sampai kuah sedikit menyusut dan mengental. Sajikan."
categories:
- Recipe
tags:
- sambel
- tumpang
- khas

katakunci: sambel tumpang khas 
nutrition: 249 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Dessert

---


![Sambel Tumpang khas solo](https://img-global.cpcdn.com/recipes/bf825116dd542d6c/680x482cq70/sambel-tumpang-khas-solo-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis atau renyah. Ciri khas masakan Indonesia sambel tumpang khas solo yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah memasak Sambel Tumpang khas solo untuk orang di rumah. Momen makan bersama anak sudah menjadi kultur, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang bisa anda buat salah satunya sambel tumpang khas solo yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep sambel tumpang khas solo tanpa harus bersusah payah.
Berikut ini resep Sambel Tumpang khas solo yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambel Tumpang khas solo:

1. Jangan lupa 1/4 papan Tempe semangit
1. Jangan lupa Secukupnya tempe biasa (sy 1/4 papan)
1. Tambah 3 tahu putih (potong kecil)
1. Jangan lupa 1 sds santan Sasa/ santan asli
1. Siapkan 2 daun salam
1. Harap siapkan 2 lembar daun jeruk
1. Jangan lupa 1 ruas lengkuas
1. Tambah 3 buah cabe rawit utuh, sesuai selera (saya 6buah)
1. Harap siapkan Secukupnya garam
1. Harus ada Secukupnya penyedap (optional)
1. Tambah Secukupnya gula jawa
1. Jangan lupa Secukupnya gula pasir
1. Diperlukan 800 ml air/sesuai selera
1. Harap siapkan  Minyak secukupnya untuk menggoreng dan menumis
1. Harap siapkan  Bumbu Halus :
1. Siapkan 6 siung Bawang merah
1. Dibutuhkan 3 siung Bawang putih
1. Tambah 2 ruas kencur
1. Harap siapkan 3 buah Kemiri
1. Harus ada 3 buah Cabe merah besar
1. Diperlukan 15 buah Cabe rawit(boleh pake boleh tidak)




<!--inarticleads2-->

##### Langkah membuat  Sambel Tumpang khas solo:

1. Goreng tahu sampai berkulit. Sisihkan.
1. Masukkan air, tempe, bawang putih, bawang merah, cabe besar, kencur. Rebus hingga matang. (Jangan buang airnya)
1. Tiriskan bumbu yang sudah direbus (bawang putih, bawang merah, kencur, cabai) + kemiri kemudian haluskan. Tumis sampai harum, masukkan dalam air rebusan. (Bisa langsung masukan ke air rebusan tanpa ditumis)
1. Tiriskan tempe dan haluskan, masukkan dalam rebusan.
1. Panaskan kembali rebusan air berisi tempe dan bumbu halus, masukkan garam, penyedap gula, daun salam, daun jeruk, lengkuas. Tggu smpai mendidih.
1. Masukkan tahu. Koreksi rasa. Jika sudah pas masukkan santan dan rawit utuh.
1. Masak sampai kuah sedikit menyusut dan mengental. Sajikan.




Demikianlah cara membuat sambel tumpang khas solo yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan terbukti, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
