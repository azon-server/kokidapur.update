---
description: "Step-by-Step menyiapakan Sambel Tumpang Krecek Terbukti"
title: "Step-by-Step menyiapakan Sambel Tumpang Krecek Terbukti"
slug: 468-step-by-step-menyiapakan-sambel-tumpang-krecek-terbukti
date: 2020-12-26T17:52:41.135Z
image: https://img-global.cpcdn.com/recipes/5aba9eb79ed8b232/680x482cq70/sambel-tumpang-krecek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5aba9eb79ed8b232/680x482cq70/sambel-tumpang-krecek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5aba9eb79ed8b232/680x482cq70/sambel-tumpang-krecek-foto-resep-utama.jpg
author: Sylvia Santiago
ratingvalue: 5
reviewcount: 1679
recipeingredient:
- "5 tahu merah"
- "4 buah krecek panjang"
- "400 ml santan"
- "1 papan tempe"
- "1/2 papan tempe semangit"
- "6 bawang merah"
- "3 bawang putih"
- "1/2 cm kencur"
- "2 daun salam"
- "2 daun jeruk"
- "2 iris lengkuas geprek"
recipeinstructions:
- "Siapkan bahan untuk membuat sambel tumpang krecek. Tahu merah dibelah menjadi dua bagian."
- "Rendam krecek dengan air panas agar lunak. Kemudian potong-potong sesuai selera."
- "Rebus tempe, tempe semangit, bawang merah, bawang putih, cabai dan kencur. Rebus sampai matang jangan buang airnya."
- "Uleg semua bahan yang telah direbus."
- "Campurkan air hasil rebusan tadi dengan bumbu halus, tambahkan daun salam, daun jeruk purut dan lengkuas."
- "Masukkan santan sambil diaduk-aduk agar santan tidak pecah. Tambahkan gula dan garam. Masak sebentar hingga mendidih."
- "Masukkan tahu dan krecek. Aduk-aduk sebentar kemudian icip-icip."
- "Jika rasa sudah pas, terakhir beri taburan bawang goreng agar sambel tumpang makin harum dan nikmat."
categories:
- Recipe
tags:
- sambel
- tumpang
- krecek

katakunci: sambel tumpang krecek 
nutrition: 281 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT59M"
recipeyield: "2"
recipecategory: Lunch

---


![Sambel Tumpang Krecek](https://img-global.cpcdn.com/recipes/5aba9eb79ed8b232/680x482cq70/sambel-tumpang-krecek-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan renyah. Karasteristik masakan Nusantara sambel tumpang krecek yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Sambel Tumpang Krecek untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang bisa anda buat salah satunya sambel tumpang krecek yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep sambel tumpang krecek tanpa harus bersusah payah.
Berikut ini resep Sambel Tumpang Krecek yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 11 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambel Tumpang Krecek:

1. Diperlukan 5 tahu merah
1. Siapkan 4 buah krecek panjang
1. Siapkan 400 ml santan
1. Siapkan 1 papan tempe
1. Dibutuhkan 1/2 papan tempe semangit
1. Harap siapkan 6 bawang merah
1. Harap siapkan 3 bawang putih
1. Siapkan 1/2 cm kencur
1. Jangan lupa 2 daun salam
1. Harus ada 2 daun jeruk
1. Jangan lupa 2 iris lengkuas geprek




<!--inarticleads2-->

##### Cara membuat  Sambel Tumpang Krecek:

1. Siapkan bahan untuk membuat sambel tumpang krecek. Tahu merah dibelah menjadi dua bagian.
1. Rendam krecek dengan air panas agar lunak. Kemudian potong-potong sesuai selera.
1. Rebus tempe, tempe semangit, bawang merah, bawang putih, cabai dan kencur. Rebus sampai matang jangan buang airnya.
1. Uleg semua bahan yang telah direbus.
1. Campurkan air hasil rebusan tadi dengan bumbu halus, tambahkan daun salam, daun jeruk purut dan lengkuas.
1. Masukkan santan sambil diaduk-aduk agar santan tidak pecah. Tambahkan gula dan garam. Masak sebentar hingga mendidih.
1. Masukkan tahu dan krecek. Aduk-aduk sebentar kemudian icip-icip.
1. Jika rasa sudah pas, terakhir beri taburan bawang goreng agar sambel tumpang makin harum dan nikmat.




Demikianlah cara membuat sambel tumpang krecek yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
