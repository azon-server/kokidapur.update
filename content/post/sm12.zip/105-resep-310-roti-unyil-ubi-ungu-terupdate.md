---
description: "Resep : 310. Roti Unyil Ubi Ungu terupdate"
title: "Resep : 310. Roti Unyil Ubi Ungu terupdate"
slug: 105-resep-310-roti-unyil-ubi-ungu-terupdate
date: 2020-12-17T08:04:13.251Z
image: https://img-global.cpcdn.com/recipes/2e53c6de5bb8af22/680x482cq70/310-roti-unyil-ubi-ungu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2e53c6de5bb8af22/680x482cq70/310-roti-unyil-ubi-ungu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2e53c6de5bb8af22/680x482cq70/310-roti-unyil-ubi-ungu-foto-resep-utama.jpg
author: Jeanette Moran
ratingvalue: 4.2
reviewcount: 25293
recipeingredient:
- "150 gr tepung cakra"
- "50 gr tepung segitiga"
- "50 gr gula pasir"
- "1 butir telur"
- "100 gr ubi ungu berat setelah di kukus dan dihaluskan"
- "1 sdt ragi instan"
- "80 ml susu cair dingin jangan di tuang semua"
- "30 gr butter"
- "1/4 sdt garam"
recipeinstructions:
- "Campur tepung, gula, dan ragi hingga rata."
- "Masukkan ubi ungu. Aduk kembali hingga rata."
- "Masukkan telur.. Campur hingga rata."
- "Tuang susu dingin sedikit demi sedikit. Uleni hingga adonan mulai lembab. Jangan dituang semua ya.. Td sy hanya pakai sekitar 55 ml saja. Kemudian masukkan butter dan garam."
- "Uleni hingga kalis elastis. Diamkan 60 menit sampai mengembang 2x lipat. Tutup dengan plastik wrap / serbet."
- "Ini adonan yg sudah sy diamkan 60 menit."
- "Bagi adonan masing2 10 gr"
- "Bentuk dan kasih isian sesuai selera. Olesi bagian atasnya dengan kuning telur. Panaskan oven dengan suhu 200°."
- "Oven dengan suhu 200° selama 11 menit atau hingga matang.. Sesuaikan dengan oven masing2 ya."
- "Enjoy 🤗"
categories:
- Recipe
tags:
- 310
- roti
- unyil

katakunci: 310 roti unyil 
nutrition: 264 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Dessert

---


![310. Roti Unyil Ubi Ungu](https://img-global.cpcdn.com/recipes/2e53c6de5bb8af22/680x482cq70/310-roti-unyil-ubi-ungu-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang setidaknya kita lestarikan karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti 310. roti unyil ubi ungu yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa ciri khas yang merupakan keragaman Indonesia

Keharmonisan keluarga dapat ditemukan dengan cara simple. Salah satunya adalah memasak 310. Roti Unyil Ubi Ungu untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang bisa anda coba salah satunya 310. roti unyil ubi ungu yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep 310. roti unyil ubi ungu tanpa harus bersusah payah.
Seperti resep 310. Roti Unyil Ubi Ungu yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 10 langkah dan 9 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat 310. Roti Unyil Ubi Ungu:

1. Tambah 150 gr tepung cakra
1. Harap siapkan 50 gr tepung segitiga
1. Jangan lupa 50 gr gula pasir
1. Diperlukan 1 butir telur
1. Diperlukan 100 gr ubi ungu (berat setelah di kukus dan dihaluskan)
1. Jangan lupa 1 sdt ragi instan
1. Harus ada 80 ml susu cair dingin (jangan di tuang semua)
1. Siapkan 30 gr butter
1. Harap siapkan 1/4 sdt garam




<!--inarticleads2-->

##### Bagaimana membuat  310. Roti Unyil Ubi Ungu:

1. Campur tepung, gula, dan ragi hingga rata.
1. Masukkan ubi ungu. Aduk kembali hingga rata.
1. Masukkan telur.. Campur hingga rata.
1. Tuang susu dingin sedikit demi sedikit. Uleni hingga adonan mulai lembab. Jangan dituang semua ya.. Td sy hanya pakai sekitar 55 ml saja. Kemudian masukkan butter dan garam.
1. Uleni hingga kalis elastis. Diamkan 60 menit sampai mengembang 2x lipat. Tutup dengan plastik wrap / serbet.
1. Ini adonan yg sudah sy diamkan 60 menit.
1. Bagi adonan masing2 10 gr
1. Bentuk dan kasih isian sesuai selera. Olesi bagian atasnya dengan kuning telur. Panaskan oven dengan suhu 200°.
1. Oven dengan suhu 200° selama 11 menit atau hingga matang.. Sesuaikan dengan oven masing2 ya.
1. Enjoy 🤗




Demikianlah cara membuat 310. roti unyil ubi ungu yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan teruji, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
