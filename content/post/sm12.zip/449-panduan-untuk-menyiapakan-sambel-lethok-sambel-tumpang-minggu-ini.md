---
description: "Panduan untuk menyiapakan Sambel lethok/sambel tumpang minggu ini"
title: "Panduan untuk menyiapakan Sambel lethok/sambel tumpang minggu ini"
slug: 449-panduan-untuk-menyiapakan-sambel-lethok-sambel-tumpang-minggu-ini
date: 2020-11-21T23:41:04.955Z
image: https://img-global.cpcdn.com/recipes/312d3ab949d8ff75/680x482cq70/sambel-lethoksambel-tumpang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/312d3ab949d8ff75/680x482cq70/sambel-lethoksambel-tumpang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/312d3ab949d8ff75/680x482cq70/sambel-lethoksambel-tumpang-foto-resep-utama.jpg
author: Stephen Richards
ratingvalue: 4.8
reviewcount: 30511
recipeingredient:
- "1 tempe semangitbosok biasanya beli yg 6000an"
- "1 tempe biasa beli yg 3000an"
- "5 siung bawang putih besar"
- "5 siung bawang merah besar"
- "50 gr cabai rawit sesuai selera"
- " Cabai keriting merah sesuai selera"
- "3 cm kencur"
- "3 cm lengkuaslaos"
- "4 lembar daun salam"
- "10 lembar daun jeruk"
- " Air"
- " Santan cair"
- "secukupnya Gula garam royco"
- " Bahan isi"
- "10 buah tahu pong"
- " Tetelan sapi opsional"
recipeinstructions:
- "Untuk tempe semangit, biasa nya aku beli tempe biasa trus aku diamkan selama kurang lebih 3hari sampai ada bau khas."
- "Siapkan bahan. Bagi tempe semangit dan tempe biasa menjadi 4 agar mudah saat di uleg."
- "Rebus semua bahan. Tempe semangit, tempe biasa, cabai, bawang merah, bawang putih, lengkuas, kencur, daun salam dan daun jeruk hingga menyisakan sedikit air."
- "Setelah direbus, pisahkan semua bahan agar mudah di uleg. Air rebusan jangan sampai di buang ya."
- "Uleg semua bahan dengan lembut atau agak kasar sesuai selera kecuali daun salam,daun jeruk dan lengkuas. Untuk lengkuas cukup di geprek. Setelah semua bahan selesai di uleg, campur kan bahan tsb kedalam air sisa rebusan dan santan cair. Tambahkan tahu pong, gula, garam dan royco. Koreksi rasa dan siap untuk dihidangkan."
categories:
- Recipe
tags:
- sambel
- lethoksambel
- tumpang

katakunci: sambel lethoksambel tumpang 
nutrition: 277 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Dessert

---


![Sambel lethok/sambel tumpang](https://img-global.cpcdn.com/recipes/312d3ab949d8ff75/680x482cq70/sambel-lethoksambel-tumpang-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau gurih. Ciri kuliner Nusantara sambel lethok/sambel tumpang yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga dapat diperoleh dengan cara simple. Diantaranya adalah membuat makanan Sambel lethok/sambel tumpang untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang bisa anda coba salah satunya sambel lethok/sambel tumpang yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep sambel lethok/sambel tumpang tanpa harus bersusah payah.
Seperti resep Sambel lethok/sambel tumpang yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambel lethok/sambel tumpang:

1. Jangan lupa 1 tempe semangit/bosok (biasanya beli yg 6000an)
1. Dibutuhkan 1 tempe biasa (beli yg 3000an)
1. Jangan lupa 5 siung bawang putih (besar)
1. Diperlukan 5 siung bawang merah (besar)
1. Jangan lupa 50 gr cabai rawit (sesuai selera)
1. Diperlukan  Cabai keriting merah (sesuai selera)
1. Diperlukan 3 cm kencur
1. Dibutuhkan 3 cm lengkuas/laos
1. Tambah 4 lembar daun salam
1. Siapkan 10 lembar daun jeruk
1. Tambah  Air
1. Harus ada  Santan cair
1. Diperlukan secukupnya Gula, garam, royco
1. Dibutuhkan  Bahan isi
1. Harus ada 10 buah tahu pong
1. Tambah  Tetelan sapi (opsional)




<!--inarticleads2-->

##### Bagaimana membuat  Sambel lethok/sambel tumpang:

1. Untuk tempe semangit, biasa nya aku beli tempe biasa trus aku diamkan selama kurang lebih 3hari sampai ada bau khas.
1. Siapkan bahan. Bagi tempe semangit dan tempe biasa menjadi 4 agar mudah saat di uleg.
1. Rebus semua bahan. Tempe semangit, tempe biasa, cabai, bawang merah, bawang putih, lengkuas, kencur, daun salam dan daun jeruk hingga menyisakan sedikit air.
1. Setelah direbus, pisahkan semua bahan agar mudah di uleg. Air rebusan jangan sampai di buang ya.
1. Uleg semua bahan dengan lembut atau agak kasar sesuai selera kecuali daun salam,daun jeruk dan lengkuas. Untuk lengkuas cukup di geprek. Setelah semua bahan selesai di uleg, campur kan bahan tsb kedalam air sisa rebusan dan santan cair. Tambahkan tahu pong, gula, garam dan royco. Koreksi rasa dan siap untuk dihidangkan.




Demikianlah cara membuat sambel lethok/sambel tumpang yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat simple dan cepat, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
