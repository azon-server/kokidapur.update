---
description: "Step-by-Step menyiapakan Sambel tumpang khas solo terupdate"
title: "Step-by-Step menyiapakan Sambel tumpang khas solo terupdate"
slug: 411-step-by-step-menyiapakan-sambel-tumpang-khas-solo-terupdate
date: 2021-02-03T09:22:25.402Z
image: https://img-global.cpcdn.com/recipes/c60dbb6fcb1f27cb/680x482cq70/sambel-tumpang-khas-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c60dbb6fcb1f27cb/680x482cq70/sambel-tumpang-khas-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c60dbb6fcb1f27cb/680x482cq70/sambel-tumpang-khas-solo-foto-resep-utama.jpg
author: Theodore Hughes
ratingvalue: 4.2
reviewcount: 2703
recipeingredient:
- "5 bungkus tempe segar uk Kecil"
- "2 bungkus tempe busuk wayu"
- "5 potong tahu putih  kulit"
- "3 butir telur ayam"
- " Krecek  kerupuk kulit kerbau sapi"
- "200 ml santan"
- "200 ml air"
- "4 siung bawang putih"
- "5 siung bawang merah"
- "10 buah cabe merah keriting  besar"
- "10 buah cabe rawit merah"
- "secukupnya Lengkuas kencur daun salam daun jeruk sereh"
- "secukupnya Gula kaldu jamur lada garam"
- " Minyak untuk menumis"
- "1 gemgam toge"
- "1 ikat daun bayam"
recipeinstructions:
- "Rebus tempe, bawang merah, bawang putih, cabe hingga empuk kurang lebih 15 menit"
- "Bila menggunakan tahu putih goreng sebentar ya tp kalu tahu nya tahu kulit gak perlu di goreng"
- "Haluskan bawang merah, bawang putih, cabe yg sudah direbus beserta kencur kemudian tumis hingga harum"
- "Setelah bumbu harum masukan tempe rebus yg sudah dihaluskan terlebih dahulu kemudian tambah kan air dan masukan lengkuas, sereh daun salam daun jeruk"
- "Jika udah mendidih masukan tahu, krecek, dan telur yg sudah direbus kemudian masukan santan"
- "Aduk2 hingga mendidih kemudian beri garam, gula, lada dan kaldu jamur"
- "Aduk2 hingga matang dan cek rasa jika sudah pas angkat dan siramkan pada toge &amp; bayam yg sudah di rebus"
categories:
- Recipe
tags:
- sambel
- tumpang
- khas

katakunci: sambel tumpang khas 
nutrition: 104 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT54M"
recipeyield: "3"
recipecategory: Lunch

---


![Sambel tumpang khas solo](https://img-global.cpcdn.com/recipes/c60dbb6fcb1f27cb/680x482cq70/sambel-tumpang-khas-solo-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti sambel tumpang khas solo yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Indonesia

Kehangatan keluarga dapat ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Sambel tumpang khas solo untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.

Sambal atau Sambel Tumpang adalah makanan khas Bumi Sukowati, lebih-lebih sambal tumpang pecel mbah templek kuwungsari Sragen yang memiliki cita rasa tinggi. Jenis bubur ini atau JENANG sering juga ada di waktu pagi hari, biasanya untuk sarapan pagi Jenang sambel goreng khas solo, mungkin hampir sama dengan bubur ayam khas betawi. Tetapi perbedaannya adalah kuah atau sayurnya dan mungkin untuk. Enak dibikin masakan khas kota Solo, namanya sambal tumpang ala tutty frutty.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang bisa anda coba salah satunya sambel tumpang khas solo yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep sambel tumpang khas solo tanpa harus bersusah payah.
Berikut ini resep Sambel tumpang khas solo yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 16 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambel tumpang khas solo:

1. Harap siapkan 5 bungkus tempe segar uk. Kecil
1. Siapkan 2 bungkus tempe busuk/ wayu
1. Siapkan 5 potong tahu putih / kulit
1. Diperlukan 3 butir telur ayam
1. Harap siapkan  Krecek / kerupuk kulit kerbau/ sapi
1. Harus ada 200 ml santan
1. Harus ada 200 ml air
1. Siapkan 4 siung bawang putih
1. Dibutuhkan 5 siung bawang merah
1. Harus ada 10 buah cabe merah keriting / besar
1. Siapkan 10 buah cabe rawit merah
1. Harus ada secukupnya Lengkuas, kencur, daun salam, daun jeruk, sereh
1. Harus ada secukupnya Gula, kaldu jamur, lada, garam
1. Siapkan  Minyak untuk menumis
1. Harap siapkan 1 gemgam toge
1. Tambah 1 ikat daun bayam


Tapi tenang saja, walaupun membuatnya menggunakan tempe yang sudah busuk, tapi rasanya jangan ditanya, tidak ada bau maupun rasa tempe busuknya. Sambel tumpang sendiri memiliki cita rasa gurih, pedas, sedikit manis dan segar. Dengan aneka bahan - bahan dan bumbu, semakin membuat kuliner khas Solo ini kaya rasa. Sambel tumpang disajikan dengan cara disiramkan di atas nasi dan rebusan sayuran seperti sawi, bayam, daun nikir. 

<!--inarticleads2-->

##### Bagaimana membuat  Sambel tumpang khas solo:

1. Rebus tempe, bawang merah, bawang putih, cabe hingga empuk kurang lebih 15 menit
1. Bila menggunakan tahu putih goreng sebentar ya tp kalu tahu nya tahu kulit gak perlu di goreng
1. Haluskan bawang merah, bawang putih, cabe yg sudah direbus beserta kencur kemudian tumis hingga harum
1. Setelah bumbu harum masukan tempe rebus yg sudah dihaluskan terlebih dahulu kemudian tambah kan air dan masukan lengkuas, sereh daun salam daun jeruk
1. Jika udah mendidih masukan tahu, krecek, dan telur yg sudah direbus kemudian masukan santan
1. Aduk2 hingga mendidih kemudian beri garam, gula, lada dan kaldu jamur
1. Aduk2 hingga matang dan cek rasa jika sudah pas angkat dan siramkan pada toge &amp; bayam yg sudah di rebus


Dengan aneka bahan - bahan dan bumbu, semakin membuat kuliner khas Solo ini kaya rasa. Sambel tumpang disajikan dengan cara disiramkan di atas nasi dan rebusan sayuran seperti sawi, bayam, daun nikir. Makanan ini ngangenin banget lo, kalo dah ada masakan ini nafsu makanq bertambah hihi. Nie kalo di Solo, namanya tumpang dan enak disajikan dengan sayuran gudangan (bayam, tauge, kacang panjang direbus). chili sauce tumpang recipes from solo city. 

Demikianlah cara membuat sambel tumpang khas solo yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan cepat, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
