---
description: "Resep : Sambal Tumpang khas Kediri #pekaninspirasi Homemade"
title: "Resep : Sambal Tumpang khas Kediri #pekaninspirasi Homemade"
slug: 396-resep-sambal-tumpang-khas-kediri-pekaninspirasi-homemade
date: 2020-11-19T20:11:33.497Z
image: https://img-global.cpcdn.com/recipes/9245f530f7333042/680x482cq70/sambal-tumpang-khas-kediri-pekaninspirasi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9245f530f7333042/680x482cq70/sambal-tumpang-khas-kediri-pekaninspirasi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9245f530f7333042/680x482cq70/sambal-tumpang-khas-kediri-pekaninspirasi-foto-resep-utama.jpg
author: Maud Wallace
ratingvalue: 4.3
reviewcount: 18250
recipeingredient:
- "1 papan tempe waras ukuran sedang"
- "1/2 papan tempe busuk ukuran sedang"
- "1/2 butir kelapa parut"
- "5 siung bawang putih"
- "2 siung bawang merah"
- "3 cabe merah"
- "8 cabe rawit merah"
- " Ketumbar"
- " Lengkuas geprek"
- " Kencur"
- " Daun salam"
- " Daun jeruk"
- " Garam"
- " Gula"
- " Kaldu jamur"
- " Ebi udang kecil"
- " Pelengkap "
- " Kacang panjang kukus"
- " Pepaya muda serut kukus"
- " Kecambah kukus"
- " Peyek Kacang"
recipeinstructions:
- "Untuk santannya: peras kelapa parut dengan air.. Ambil santan kentalnya terlebih dahulu. Lalu santan encernya."
- "Didihkan santan encer dalam panci. Sambil tetap diaduk. Setelah mendidih, masukkan tempe, bawang putih, bawang merah, cabe merah, cabe rawit, kencur dan sebagian daun jeruknya. Biarkan sampai matang. Tiriskan."
- "Ambil cabe merah, cabe rawit, bawang merah, bawang putih, kencur dan daun jeruk lalu haluskan bumbu tersebut."
- "Setelah bumbu dihaluskan, masukkan dalam santan encer bekas rebusan tempe tadi. Haluskan pula tempenya. Masukkan pula dalam santan encer bekas rebusan tempe tadi. Aduk merata."
- "Biarkan sampai mendidih. Sambil tetap diaduk. Tambahkan daun salam, lengkuas dan daun jeruknya."
- "Sambil menunggu mendidih, masukkan garam, gula, ketumbar dan kaldu jamurnya. Menjelang kuahnya menyusut. Masukkan santan kentalnya. Masak sampai mendidih. Sambil tetap diaduk supaya santan tidak pecah. Jangan lupa koreksi rasa. Terakhir masukkan ebi udangnya."
- "Hidangkan dengan lalapan sayur kacang panjang, daun turi dan kecambah (kukus). Tak lupa peyek kacangnya. 😊"
- "Makannya bisa juga dicampur dengan sambal pecel. Selamat mencoba yaaa..."
categories:
- Recipe
tags:
- sambal
- tumpang
- khas

katakunci: sambal tumpang khas 
nutrition: 205 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Lunch

---


![Sambal Tumpang khas Kediri #pekaninspirasi](https://img-global.cpcdn.com/recipes/9245f530f7333042/680x482cq70/sambal-tumpang-khas-kediri-pekaninspirasi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang harus kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti sambal tumpang khas kediri #pekaninspirasi yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara

Kedekatan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah memasak Sambal Tumpang khas Kediri #pekaninspirasi untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang bisa anda buat salah satunya sambal tumpang khas kediri #pekaninspirasi yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep sambal tumpang khas kediri #pekaninspirasi tanpa harus bersusah payah.
Berikut ini resep Sambal Tumpang khas Kediri #pekaninspirasi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambal Tumpang khas Kediri #pekaninspirasi:

1. Diperlukan 1 papan tempe (waras) ukuran sedang
1. Tambah 1/2 papan tempe (busuk) ukuran sedang
1. Harus ada 1/2 butir kelapa parut
1. Harap siapkan 5 siung bawang putih
1. Dibutuhkan 2 siung bawang merah
1. Diperlukan 3 cabe merah
1. Diperlukan 8 cabe rawit merah
1. Siapkan  Ketumbar
1. Dibutuhkan  Lengkuas, geprek
1. Jangan lupa  Kencur
1. Dibutuhkan  Daun salam
1. Harap siapkan  Daun jeruk
1. Siapkan  Garam
1. Siapkan  Gula
1. Jangan lupa  Kaldu jamur
1. Siapkan  Ebi udang kecil
1. Jangan lupa  Pelengkap :
1. Harus ada  Kacang panjang (kukus)
1. Jangan lupa  Pepaya muda serut (kukus)
1. Dibutuhkan  Kecambah (kukus)
1. Diperlukan  Peyek Kacang




<!--inarticleads2-->

##### Langkah membuat  Sambal Tumpang khas Kediri #pekaninspirasi:

1. Untuk santannya: peras kelapa parut dengan air.. Ambil santan kentalnya terlebih dahulu. Lalu santan encernya.
1. Didihkan santan encer dalam panci. Sambil tetap diaduk. Setelah mendidih, masukkan tempe, bawang putih, bawang merah, cabe merah, cabe rawit, kencur dan sebagian daun jeruknya. Biarkan sampai matang. Tiriskan.
1. Ambil cabe merah, cabe rawit, bawang merah, bawang putih, kencur dan daun jeruk lalu haluskan bumbu tersebut.
1. Setelah bumbu dihaluskan, masukkan dalam santan encer bekas rebusan tempe tadi. Haluskan pula tempenya. Masukkan pula dalam santan encer bekas rebusan tempe tadi. Aduk merata.
1. Biarkan sampai mendidih. Sambil tetap diaduk. Tambahkan daun salam, lengkuas dan daun jeruknya.
1. Sambil menunggu mendidih, masukkan garam, gula, ketumbar dan kaldu jamurnya. Menjelang kuahnya menyusut. Masukkan santan kentalnya. Masak sampai mendidih. Sambil tetap diaduk supaya santan tidak pecah. Jangan lupa koreksi rasa. Terakhir masukkan ebi udangnya.
1. Hidangkan dengan lalapan sayur kacang panjang, daun turi dan kecambah (kukus). Tak lupa peyek kacangnya. 😊
1. Makannya bisa juga dicampur dengan sambal pecel. Selamat mencoba yaaa...




Demikianlah cara membuat sambal tumpang khas kediri #pekaninspirasi yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
