---
description: "Resep : Sambel Tumpang Cepat"
title: "Resep : Sambel Tumpang Cepat"
slug: 448-resep-sambel-tumpang-cepat
date: 2021-03-09T16:05:47.805Z
image: https://img-global.cpcdn.com/recipes/8671a3d51b496a84/680x482cq70/sambel-tumpang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8671a3d51b496a84/680x482cq70/sambel-tumpang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8671a3d51b496a84/680x482cq70/sambel-tumpang-foto-resep-utama.jpg
author: Julian Daniels
ratingvalue: 4
reviewcount: 40972
recipeingredient:
- "1 papan tempe waras"
- "1/2 papan tempe semangit"
- "2 helai daun salam"
- "3 helai daun jeruk"
- "1 sdm ebi cuci dan rendam dlm air panas sebentar lalu tiriskan"
- "1 ruas lengkuas"
- "1 santan kara"
- "secukupnya gula garam kaldu bubuk"
- " kurleb 1 L air disesuaikan ya"
- " Bumbu Halus rebus dulu sebelum dihaluskan"
- "5 buah bawang merah"
- "4 siung bawang putih"
- "3 buah cabe merah besar buang bijinya"
- "15 cabe rawit ini sesuai selera ya"
- "1 ruas kencur"
- "2 buah kemiri sangrai"
recipeinstructions:
- "Potong² tempe, lalu rebus bersama bumbu yang akan dihaluskan, daun jeruk dan daun salam (kecuali kemiri) ke dlm air mendidih. Rebus kurleb 15 menit."
- "Saring Semua bahan, kecuali daun jeruk dan daun salam, tiriskan. (Air rebusan jangan dibuang). Uleg kasar tempe, sisihkan."
- "Haluskan semua bumbu halus, lalu masukkan ke dalam air rebusan tadi beserta tempe. Tambahkan santan kara, ebi, gula, garam, dan kaldu bubuk. Tes rasa"
- "Aduk² sampai mendidih dan air agak menyusut, matikan api. Enak banget dimakan sama pecel, peyek dan telur dadar 🥰"
categories:
- Recipe
tags:
- sambel
- tumpang

katakunci: sambel tumpang 
nutrition: 231 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT46M"
recipeyield: "2"
recipecategory: Dinner

---


![Sambel Tumpang](https://img-global.cpcdn.com/recipes/8671a3d51b496a84/680x482cq70/sambel-tumpang-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis dan renyah. Ciri masakan Indonesia sambel tumpang yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Sambel Tumpang untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang dapat anda contoh salah satunya sambel tumpang yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep sambel tumpang tanpa harus bersusah payah.
Berikut ini resep Sambel Tumpang yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 16 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambel Tumpang:

1. Jangan lupa 1 papan tempe waras
1. Harap siapkan 1/2 papan tempe semangit
1. Jangan lupa 2 helai daun salam
1. Harap siapkan 3 helai daun jeruk
1. Siapkan 1 sdm ebi, cuci dan rendam dlm air panas sebentar, lalu tiriskan
1. Siapkan 1 ruas lengkuas
1. Siapkan 1 santan kara
1. Jangan lupa secukupnya gula, garam, kaldu bubuk
1. Diperlukan  kurleb 1 L air (disesuaikan ya)
1. Tambah  Bumbu Halus (rebus dulu sebelum dihaluskan):
1. Harap siapkan 5 buah bawang merah
1. Jangan lupa 4 siung bawang putih
1. Dibutuhkan 3 buah cabe merah besar, buang bijinya
1. Jangan lupa 15 cabe rawit (ini sesuai selera ya)
1. Diperlukan 1 ruas kencur
1. Harap siapkan 2 buah kemiri sangrai




<!--inarticleads2-->

##### Cara membuat  Sambel Tumpang:

1. Potong² tempe, lalu rebus bersama bumbu yang akan dihaluskan, daun jeruk dan daun salam (kecuali kemiri) ke dlm air mendidih. Rebus kurleb 15 menit.
1. Saring Semua bahan, kecuali daun jeruk dan daun salam, tiriskan. (Air rebusan jangan dibuang). Uleg kasar tempe, sisihkan.
1. Haluskan semua bumbu halus, lalu masukkan ke dalam air rebusan tadi beserta tempe. Tambahkan santan kara, ebi, gula, garam, dan kaldu bubuk. Tes rasa
1. Aduk² sampai mendidih dan air agak menyusut, matikan api. Enak banget dimakan sama pecel, peyek dan telur dadar 🥰




Demikianlah cara membuat sambel tumpang yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
