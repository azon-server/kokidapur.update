---
description: "Steps membuat Pecel Lele Komplit (Lele Goreng, Sambel &amp;amp; Cah Kangkung) Terbukti"
title: "Steps membuat Pecel Lele Komplit (Lele Goreng, Sambel &amp;amp; Cah Kangkung) Terbukti"
slug: 284-steps-membuat-pecel-lele-komplit-lele-goreng-sambel-and-amp-cah-kangkung-terbukti
date: 2020-11-15T03:23:01.093Z
image: https://img-global.cpcdn.com/recipes/433aacea47d85575/680x482cq70/pecel-lele-komplit-lele-goreng-sambel-cah-kangkung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/433aacea47d85575/680x482cq70/pecel-lele-komplit-lele-goreng-sambel-cah-kangkung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/433aacea47d85575/680x482cq70/pecel-lele-komplit-lele-goreng-sambel-cah-kangkung-foto-resep-utama.jpg
author: Rosetta Rivera
ratingvalue: 4.6
reviewcount: 42296
recipeingredient:
- " Bahan a lele goreng"
- "5 ekor ikan lele"
- "1 buah jeruk nipis"
- "1 sdm tepung beras"
- "1 sdm tepung bumbu instan"
- "1 sdt garam"
- " Bumbu halus"
- "3 siung bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 sdt ketumbar"
- "1 butir kemiri"
- " Bahan b sambel pecel lele"
- "15 buah cabe rawit merah"
- "5 buah cabe merah keriting"
- "7 siung bawang merah"
- "2 siung bawang putih"
- "2 butir kemiri"
- "1/2 sdt terasi"
- "1/2 sdt gula merah"
- "1/2 sdm garam"
- " Bahan c cah kangkung"
- "1 ikat kangkung"
- "5 siung bawang merah"
- "2 siung bawang putih"
- "1/2 sdt terasi"
- "1/2 sdt kaldu bubuk"
- "100 ml air"
recipeinstructions:
- "Siapkan bahan lele goreng. Cuci bersih lele dengan garam dan air jeruk nipis, diamkan 15 menit."
- "Haluskan bahan bumbu, campurkan ke lele, tambahkan garam, diamkan 15 menit agar bumbu meresap, taburi dengan campuran tepung beras dan tepung bumbu lalu goreng."
- "Siapkan bahan sambel. Tumis bahan sambel (kecuali garam dan gula merah) hingga setengah layu saja lalu ulek bersama garam dan gula merah."
- "Siapkan bahan cah kangkung. Kangkung di siangi lalu cuci bersih. Iris bawang merah, bawang putih dan cabe rawit merah. Panaskan sedikit minyak goreng, tumis bawang hingga wangi lalu masukkan terasi dan cabe. Oseng sebentar lalu masukkan air, garam dan kaldu bubuk. Biarkan hingga mendidih lalu masukkan kangkung. Tumis sebentar sambil terus di aduk, angkat."
categories:
- Recipe
tags:
- pecel
- lele
- komplit

katakunci: pecel lele komplit 
nutrition: 140 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Dessert

---


![Pecel Lele Komplit (Lele Goreng, Sambel &amp; Cah Kangkung)](https://img-global.cpcdn.com/recipes/433aacea47d85575/680x482cq70/pecel-lele-komplit-lele-goreng-sambel-cah-kangkung-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga empuk. Ciri makanan Indonesia pecel lele komplit (lele goreng, sambel &amp; cah kangkung) yang kaya dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan keluarga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan Pecel Lele Komplit (Lele Goreng, Sambel &amp; Cah Kangkung) untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda coba salah satunya pecel lele komplit (lele goreng, sambel &amp; cah kangkung) yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep pecel lele komplit (lele goreng, sambel &amp; cah kangkung) tanpa harus bersusah payah.
Berikut ini resep Pecel Lele Komplit (Lele Goreng, Sambel &amp; Cah Kangkung) yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 28 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Pecel Lele Komplit (Lele Goreng, Sambel &amp; Cah Kangkung):

1. Diperlukan  Bahan a (lele goreng):
1. Diperlukan 5 ekor ikan lele
1. Diperlukan 1 buah jeruk nipis
1. Siapkan 1 sdm tepung beras
1. Harus ada 1 sdm tepung bumbu instan
1. Diperlukan 1 sdt garam
1. Siapkan  Bumbu halus:
1. Siapkan 3 siung bawang putih
1. Harap siapkan 1 ruas jahe
1. Harus ada 1 ruas kunyit
1. Tambah 1 sdt ketumbar
1. Diperlukan 1 butir kemiri
1. Harap siapkan  Bahan b (sambel pecel lele):
1. Jangan lupa 15 buah cabe rawit merah
1. Tambah 5 buah cabe merah keriting
1. Diperlukan 7 siung bawang merah
1. Dibutuhkan 2 siung bawang putih
1. Dibutuhkan 2 butir kemiri
1. Harus ada 1/2 sdt terasi
1. Siapkan 1/2 sdt gula merah
1. Dibutuhkan 1/2 sdm garam
1. Harus ada  Bahan c (cah kangkung):
1. Diperlukan 1 ikat kangkung
1. Tambah 5 siung bawang merah
1. Jangan lupa 2 siung bawang putih
1. Jangan lupa 1/2 sdt terasi
1. Harus ada 1/2 sdt kaldu bubuk
1. Siapkan 100 ml air




<!--inarticleads2-->

##### Langkah membuat  Pecel Lele Komplit (Lele Goreng, Sambel &amp; Cah Kangkung):

1. Siapkan bahan lele goreng. Cuci bersih lele dengan garam dan air jeruk nipis, diamkan 15 menit.
1. Haluskan bahan bumbu, campurkan ke lele, tambahkan garam, diamkan 15 menit agar bumbu meresap, taburi dengan campuran tepung beras dan tepung bumbu lalu goreng.
1. Siapkan bahan sambel. Tumis bahan sambel (kecuali garam dan gula merah) hingga setengah layu saja lalu ulek bersama garam dan gula merah.
1. Siapkan bahan cah kangkung. Kangkung di siangi lalu cuci bersih. Iris bawang merah, bawang putih dan cabe rawit merah. Panaskan sedikit minyak goreng, tumis bawang hingga wangi lalu masukkan terasi dan cabe. Oseng sebentar lalu masukkan air, garam dan kaldu bubuk. Biarkan hingga mendidih lalu masukkan kangkung. Tumis sebentar sambil terus di aduk, angkat.




Demikianlah cara membuat pecel lele komplit (lele goreng, sambel &amp; cah kangkung) yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan terbukti, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
