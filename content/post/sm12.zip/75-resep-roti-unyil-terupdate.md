---
description: "Resep : Roti unyil terupdate"
title: "Resep : Roti unyil terupdate"
slug: 75-resep-roti-unyil-terupdate
date: 2020-09-30T13:30:10.842Z
image: https://img-global.cpcdn.com/recipes/9df67b73e508ebdc/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9df67b73e508ebdc/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9df67b73e508ebdc/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Herbert Richardson
ratingvalue: 4.5
reviewcount: 5721
recipeingredient:
- " bahan adonan"
- " ragi instan"
- " air hangat"
- " tepung terigu"
- " kuning telur"
- " gula"
- " margarin"
- " garam"
- " susu bubuk instan dancow sachet"
- " TBM ini utk pelembut boleh pakai boleh engak sih"
- " bahan toping"
- " keju parut"
- " misses"
- " sossis"
- " abon"
- " skm dan mayoness khusus utk roti abon"
recipeinstructions:
- "Aktifkan ragi instan dengan cara Masukkan ragi instan dan 1 sdm gula kedalam 110 ml air hangat, diaduk dan ditutup kemudian didiamkan kurleb 5 menit, selanjutnya akan muncul buih2 atau busa digelas. hal ini dilakukan utk memastikan ragi aktif atau tidak. jika tidak muncul buih, maka ragi sudah tidak aktif dan tidak dapat digunakan lagi"
- "Campur semua adonan kecuali margarin, garam dan TBM.. ulen sampai bercampur sempurna"
- "Lalu masukkan margarin dan garam dan sedikit TBM lalu uleni terus sampai benar2 kalis"
- "Bentuk adonan menjadi bulat lalu tutp dengan kain dan diamkan sampai adonan mengembang (kurleb 25 mnt)"
- "Setelah adonan mengembang, tumbok adonan dan bagi2 sekitar 10 atau 20 gram perbagian, lalu bentuk bulat2 kecil, tutup lagi dan diamkan kurleb 15 menit"
- "Ambil adonan tadi, lalu berkreasilah sesuai selera masing2 dengan toping2 yang diinginkan."
- "Nah, ini saat nya bunda berkreasi, utk roti isian missess, cukup diambil adonan, bentuk lingkaran, tekan2 pinggirnya, lalu masukkan missess dan bulatkan kembali."
- "Utk roti abon, bunda cukup membentuk roti bulat lonjong saja. setelah dipanggang, oleskan campuran mayoness dengan SKM lalu gulingkan bagian atasnya di abon"
- "Utk isian sossis, ambil adonan, tipiskan, isi dengan sossis, lalu gulung adonan, lalu potong2 menjadi 6 bagian,dan kreasikan sesuai selera.."
- "Utk isian pisang coklat, ambil adonan tipiskan, isi pisang yg sudah dipotong kecil memanjang, tambah misses, gulung adonan,. kreasikan gulungan adonan sesuai selera"
- "Setelah dibentuk2 sesuai selera, lalu panggang di oven sesuai dengan temp oven masing2 dengan api atas bawah selama 10 -15 menit"
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 166 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Dessert

---


![Roti unyil](https://img-global.cpcdn.com/recipes/9df67b73e508ebdc/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti roti unyil yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Indonesia



Keharmonisan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Roti unyil untuk orang di rumah. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang dapat anda contoh salah satunya roti unyil yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep roti unyil tanpa harus bersusah payah.
Berikut ini resep Roti unyil yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 16 bahan dan 11 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti unyil:

1. Siapkan  bahan adonan
1. Harus ada  ragi instan
1. Diperlukan  air hangat
1. Jangan lupa  tepung terigu
1. Siapkan  kuning telur
1. Jangan lupa  gula
1. Jangan lupa  margarin
1. Dibutuhkan  garam
1. Tambah  susu bubuk instan (dancow sachet)
1. Jangan lupa  TBM (ini utk pelembut, boleh pakai boleh engak sih)
1. Siapkan  bahan toping
1. Siapkan  keju parut
1. Tambah  misses
1. Tambah  sossis
1. Harap siapkan  abon
1. Diperlukan  skm dan mayoness (khusus utk roti abon)




<!--inarticleads2-->

##### Bagaimana membuat  Roti unyil:

1. Aktifkan ragi instan dengan cara Masukkan ragi instan dan 1 sdm gula kedalam 110 ml air hangat, diaduk dan ditutup kemudian didiamkan kurleb 5 menit, selanjutnya akan muncul buih2 atau busa digelas. hal ini dilakukan utk memastikan ragi aktif atau tidak. jika tidak muncul buih, maka ragi sudah tidak aktif dan tidak dapat digunakan lagi
1. Campur semua adonan kecuali margarin, garam dan TBM.. ulen sampai bercampur sempurna
1. Lalu masukkan margarin dan garam dan sedikit TBM lalu uleni terus sampai benar2 kalis
1. Bentuk adonan menjadi bulat lalu tutp dengan kain dan diamkan sampai adonan mengembang (kurleb 25 mnt)
1. Setelah adonan mengembang, tumbok adonan dan bagi2 sekitar 10 atau 20 gram perbagian, lalu bentuk bulat2 kecil, tutup lagi dan diamkan kurleb 15 menit
1. Ambil adonan tadi, lalu berkreasilah sesuai selera masing2 dengan toping2 yang diinginkan.
1. Nah, ini saat nya bunda berkreasi, utk roti isian missess, cukup diambil adonan, bentuk lingkaran, tekan2 pinggirnya, lalu masukkan missess dan bulatkan kembali.
1. Utk roti abon, bunda cukup membentuk roti bulat lonjong saja. setelah dipanggang, oleskan campuran mayoness dengan SKM lalu gulingkan bagian atasnya di abon
1. Utk isian sossis, ambil adonan, tipiskan, isi dengan sossis, lalu gulung adonan, lalu potong2 menjadi 6 bagian,dan kreasikan sesuai selera..
1. Utk isian pisang coklat, ambil adonan tipiskan, isi pisang yg sudah dipotong kecil memanjang, tambah misses, gulung adonan,. kreasikan gulungan adonan sesuai selera
1. Setelah dibentuk2 sesuai selera, lalu panggang di oven sesuai dengan temp oven masing2 dengan api atas bawah selama 10 -15 menit




Demikianlah cara membuat roti unyil yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
