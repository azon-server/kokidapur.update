---
description: "Step-by-Step menyiapakan Roti unyil Favorite"
title: "Step-by-Step menyiapakan Roti unyil Favorite"
slug: 69-step-by-step-menyiapakan-roti-unyil-favorite
date: 2021-02-09T22:21:56.629Z
image: https://img-global.cpcdn.com/recipes/188241841ebc62a2/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/188241841ebc62a2/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/188241841ebc62a2/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Antonio Pittman
ratingvalue: 4.8
reviewcount: 29478
recipeingredient:
- " terigu protein tinggi"
- " kentang kukus lumatkan berat setelah dikukus"
- " ragi instan"
- " telur"
- " gula pasir"
- " susu bubuk"
- " susu cair sy ultra plain"
- " mentega boleh ganti margarin"
- " garam"
- " Olesan"
- " kuning telur"
- " susu cair"
- " Mentega margarin"
recipeinstructions:
- "Campurkan tepung terigu, ragi instan, susu bubuk, gula pasir, telur dan kentang. Aduk rata."
- "Masukkan susu cair sedikit demi sedikit. Uleni hingga setengah kalis."
- "Masukkan mentega dan garam. Uleni sampai kalis elastis. Sy pake handmixer, kurang lebih 15 menit."
- "Bulatkan adonan. Simpan di baskom. Tutup dengan plastik atau lap bersih. Tunggu hingga memgembang 2x lipat."
- "Timbang adonan @10 gram."
- "Bentuk adonan roti dengan isian sesuai selera."
- "Oles dengan kuning telur &amp; susu cair. Panggang di oven 170⁰c selama 20-25 menit. (oven sebelumnya sudah dipanaskan selama 10-15 menit). Sy 20 menit api bawah, 5 menit api atas."
- "Setelah matang, langsung oles pake mentega/ margarin."
- "Roti unyil siap disantap. Hmmm wangi dan lembut teksturnya.."
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 159 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Lunch

---


![Roti unyil](https://img-global.cpcdn.com/recipes/188241841ebc62a2/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang patut kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti roti unyil yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Indonesia



Kedekatan keluarga bisa didapat dengan cara mudah. Diantaranya adalah membuat makanan Roti unyil untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang dapat anda buat salah satunya roti unyil yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep roti unyil tanpa harus bersusah payah.
Berikut ini resep Roti unyil yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 13 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti unyil:

1. Tambah  terigu protein tinggi
1. Harap siapkan  kentang kukus, lumatkan (berat setelah dikukus)
1. Siapkan  ragi instan
1. Diperlukan  telur
1. Jangan lupa  gula pasir
1. Harus ada  susu bubuk
1. Tambah  susu cair (sy ultra plain)
1. Dibutuhkan  mentega (boleh ganti margarin)
1. Siapkan  garam
1. Siapkan  Olesan
1. Jangan lupa  kuning telur
1. Siapkan  susu cair
1. Diperlukan  Mentega/ margarin




<!--inarticleads2-->

##### Langkah membuat  Roti unyil:

1. Campurkan tepung terigu, ragi instan, susu bubuk, gula pasir, telur dan kentang. Aduk rata.
1. Masukkan susu cair sedikit demi sedikit. Uleni hingga setengah kalis.
1. Masukkan mentega dan garam. Uleni sampai kalis elastis. Sy pake handmixer, kurang lebih 15 menit.
1. Bulatkan adonan. Simpan di baskom. Tutup dengan plastik atau lap bersih. Tunggu hingga memgembang 2x lipat.
1. Timbang adonan @10 gram.
1. Bentuk adonan roti dengan isian sesuai selera.
1. Oles dengan kuning telur &amp; susu cair. Panggang di oven 170⁰c selama 20-25 menit. (oven sebelumnya sudah dipanaskan selama 10-15 menit). Sy 20 menit api bawah, 5 menit api atas.
1. Setelah matang, langsung oles pake mentega/ margarin.
1. Roti unyil siap disantap. Hmmm wangi dan lembut teksturnya..




Demikianlah cara membuat roti unyil yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
