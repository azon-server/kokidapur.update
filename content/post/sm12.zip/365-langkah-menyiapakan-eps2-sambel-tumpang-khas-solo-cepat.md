---
description: "Langkah menyiapakan Eps.2 Sambel Tumpang Khas Solo Cepat"
title: "Langkah menyiapakan Eps.2 Sambel Tumpang Khas Solo Cepat"
slug: 365-langkah-menyiapakan-eps2-sambel-tumpang-khas-solo-cepat
date: 2020-11-24T01:04:31.117Z
image: https://img-global.cpcdn.com/recipes/54eff3d858f1aa07/680x482cq70/eps2-sambel-tumpang-khas-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/54eff3d858f1aa07/680x482cq70/eps2-sambel-tumpang-khas-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/54eff3d858f1aa07/680x482cq70/eps2-sambel-tumpang-khas-solo-foto-resep-utama.jpg
author: Bettie Simmons
ratingvalue: 4.5
reviewcount: 5096
recipeingredient:
- " Bahan A"
- "5 bungkus tempe bosokbusuksemangit"
- "1 papan tempe"
- "8 siung bawang merah"
- "4 siung Bawang putih"
- "2 ruas kencur"
- "5 buah cabe keriting selera"
- "7 buah cabe rawit selera"
- " Bahan B"
- "2 lembar daun salam"
- "4 lembar daun jeruk"
- "5 buah tahu coklat di bagi 2"
- "1 keping gula merah selera"
- "1 bungkus santan kelapa segitiga"
- "2 sdt garam selera"
- "2 sdt kaldu serlera"
recipeinstructions:
- "Siapkan bahan A, kecuali daun salam dan daun jeruk (salah foto)"
- "Rebus semua bahan A"
- "Jika dirasa sudah empuk, uleg semua bahan A"
- "Siapkan bahan B tambah daun salam dan daun jeruk (di foto kurang daun salam dan daun jeruk)"
- "Siapkan air sekitar 600ml, lalu rebus semua bahan B (kecuali santan terakhir masuk), dan masukan hasil ulekan bahan A"
- "Setelah diaduk, dicicipi dulu sebelum dimasukan santan, pastikan rasanya sudah pas dengan selera, lalu jika sudah pas masukan santan"
- "Tunggu sampai mendidih dan bumbu menyerap semua, lalu siap disajikan"
categories:
- Recipe
tags:
- eps2
- sambel
- tumpang

katakunci: eps2 sambel tumpang 
nutrition: 241 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT50M"
recipeyield: "1"
recipecategory: Dessert

---


![Eps.2 Sambel Tumpang Khas Solo](https://img-global.cpcdn.com/recipes/54eff3d858f1aa07/680x482cq70/eps2-sambel-tumpang-khas-solo-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau renyah. Ciri makanan Indonesia eps.2 sambel tumpang khas solo yang penuh dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Eps.2 Sambel Tumpang Khas Solo untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang bisa anda buat salah satunya eps.2 sambel tumpang khas solo yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep eps.2 sambel tumpang khas solo tanpa harus bersusah payah.
Berikut ini resep Eps.2 Sambel Tumpang Khas Solo yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Eps.2 Sambel Tumpang Khas Solo:

1. Diperlukan  Bahan A
1. Jangan lupa 5 bungkus tempe bosok/busuk/semangit
1. Dibutuhkan 1 papan tempe
1. Harus ada 8 siung bawang merah
1. Harus ada 4 siung Bawang putih
1. Harap siapkan 2 ruas kencur
1. Harus ada 5 buah cabe keriting (selera)
1. Harap siapkan 7 buah cabe rawit (selera)
1. Dibutuhkan  Bahan B
1. Tambah 2 lembar daun salam
1. Tambah 4 lembar daun jeruk
1. Harus ada 5 buah tahu coklat di bagi 2
1. Diperlukan 1 keping gula merah (selera)
1. Harap siapkan 1 bungkus santan kelapa segitiga
1. Jangan lupa 2 sdt garam (selera)
1. Tambah 2 sdt kaldu (serlera)




<!--inarticleads2-->

##### Cara membuat  Eps.2 Sambel Tumpang Khas Solo:

1. Siapkan bahan A, kecuali daun salam dan daun jeruk (salah foto)
1. Rebus semua bahan A
1. Jika dirasa sudah empuk, uleg semua bahan A
1. Siapkan bahan B tambah daun salam dan daun jeruk (di foto kurang daun salam dan daun jeruk)
1. Siapkan air sekitar 600ml, lalu rebus semua bahan B (kecuali santan terakhir masuk), dan masukan hasil ulekan bahan A
1. Setelah diaduk, dicicipi dulu sebelum dimasukan santan, pastikan rasanya sudah pas dengan selera, lalu jika sudah pas masukan santan
1. Tunggu sampai mendidih dan bumbu menyerap semua, lalu siap disajikan




Demikianlah cara membuat eps.2 sambel tumpang khas solo yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan teruji, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
