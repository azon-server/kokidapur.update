---
description: "Bagaimana menyiapakan Roti Unyil Kolache teraktual"
title: "Bagaimana menyiapakan Roti Unyil Kolache teraktual"
slug: 98-bagaimana-menyiapakan-roti-unyil-kolache-teraktual
date: 2021-02-23T15:28:29.240Z
image: https://img-global.cpcdn.com/recipes/2ad8df4fa30f70f4/680x482cq70/roti-unyil-kolache-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2ad8df4fa30f70f4/680x482cq70/roti-unyil-kolache-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2ad8df4fa30f70f4/680x482cq70/roti-unyil-kolache-foto-resep-utama.jpg
author: Blanche Graves
ratingvalue: 4.9
reviewcount: 3094
recipeingredient:
- " terigu protein tinggi"
- " susu cair"
- " gula pasir"
- " mentega"
- " merah telur"
- " ragi instant"
- " garam halus"
- " Isian "
- " Vla u Pie"
- " mayonaise"
- " Topping bisa diganti bahan lain"
- " Jagung rebus"
- " Irisan Sosis"
- " Manisan ceri"
- " buah Berry"
- " Brokoli rebus"
- " Meses"
- " Olesan"
- " kuning telurresep asli mengoles dengan putih telur"
recipeinstructions:
- "Campur rata terigu, gula dan garam."
- "Masukkan dalam gelas: 1 sdm gula ambil dari total gula, ragi instant dan 75 ml susu hangat kuku yg diambil dr total keperluan susu. Aduk rata dan diamkan 10 menit atau sampai berbuih."
- "Campur dan aduk rata, campuran tepung terigu, larutan ragi, sisa susu, merah telur dan mentega. Hasil adonan adalah lengket. Bersihkan tangan, lalu bedaki dengan tepung terigu. Uleni dan banting-banting adonan sampai kalis elastis sambil tetap membedaki tangan."
- "Istirahatkan adonan sampai mengembang 2x lipat. Kempiskan dan ulen lagi adonan sebentar"
- "Potong-potong adonan masing-masing 10-15 gram. Lalu bentuk bulat-bulat. (Untuk menghindari over proofing, sy menggunakan sebagian adonan roti dulu, sebagian lagi sy bungkus dalam plastik dan disimpan di dalam kulkas. Dikeluarkan saat adonan yang pertama sudah habis)"
- "Gepengkan adonan membentuk lingkaran, lalu letakkan diatas loyang yang dialaai kertas baking dan margarin. Biarkan adoan sampai mengembang 2x lipat."
- "Setelah adonan mengembang 2x lipat, tekan-tekan bagian tengan adonan dengan jari atau alat yg sesuai sampai berbentuk mangkuk."
- "Beri isian vla dan tambahkan topingnya."
- "Oven dengan api sedang selama 20 menit. Lalu keluarkan dan oles permukaan rotinya dengan kuning/putih telur. Oven lagi selama 5 menit sampai permukaan roti keemasan. Keluarkan dari oven."
categories:
- Recipe
tags:
- roti
- unyil
- kolache

katakunci: roti unyil kolache 
nutrition: 295 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Lunch

---


![Roti Unyil Kolache](https://img-global.cpcdn.com/recipes/2ad8df4fa30f70f4/680x482cq70/roti-unyil-kolache-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan enak. Ciri makanan Indonesia roti unyil kolache yang penuh dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan rumah tangga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Roti Unyil Kolache untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang bisa anda praktekkan salah satunya roti unyil kolache yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep roti unyil kolache tanpa harus bersusah payah.
Berikut ini resep Roti Unyil Kolache yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 9 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Unyil Kolache:

1. Jangan lupa  terigu protein tinggi
1. Diperlukan  susu cair
1. Harap siapkan  gula pasir
1. Siapkan  mentega
1. Diperlukan  merah telur
1. Dibutuhkan  ragi instant
1. Dibutuhkan  garam halus
1. Diperlukan  Isian :
1. Jangan lupa  Vla u/ Pie
1. Tambah  mayonaise
1. Harap siapkan  Topping (bisa diganti bahan lain)
1. Jangan lupa  Jagung rebus
1. Jangan lupa  Irisan Sosis
1. Harus ada  Manisan ceri
1. Dibutuhkan  buah Berry
1. Siapkan  Brokoli rebus
1. Harap siapkan  Meses
1. Diperlukan  Olesan:
1. Dibutuhkan  kuning telur/resep asli mengoles dengan putih telur




<!--inarticleads2-->

##### Langkah membuat  Roti Unyil Kolache:

1. Campur rata terigu, gula dan garam.
1. Masukkan dalam gelas: 1 sdm gula ambil dari total gula, ragi instant dan 75 ml susu hangat kuku yg diambil dr total keperluan susu. Aduk rata dan diamkan 10 menit atau sampai berbuih.
1. Campur dan aduk rata, campuran tepung terigu, larutan ragi, sisa susu, merah telur dan mentega. Hasil adonan adalah lengket. Bersihkan tangan, lalu bedaki dengan tepung terigu. Uleni dan banting-banting adonan sampai kalis elastis sambil tetap membedaki tangan.
1. Istirahatkan adonan sampai mengembang 2x lipat. Kempiskan dan ulen lagi adonan sebentar
1. Potong-potong adonan masing-masing 10-15 gram. Lalu bentuk bulat-bulat. (Untuk menghindari over proofing, sy menggunakan sebagian adonan roti dulu, sebagian lagi sy bungkus dalam plastik dan disimpan di dalam kulkas. Dikeluarkan saat adonan yang pertama sudah habis)
1. Gepengkan adonan membentuk lingkaran, lalu letakkan diatas loyang yang dialaai kertas baking dan margarin. Biarkan adoan sampai mengembang 2x lipat.
1. Setelah adonan mengembang 2x lipat, tekan-tekan bagian tengan adonan dengan jari atau alat yg sesuai sampai berbentuk mangkuk.
1. Beri isian vla dan tambahkan topingnya.
1. Oven dengan api sedang selama 20 menit. Lalu keluarkan dan oles permukaan rotinya dengan kuning/putih telur. Oven lagi selama 5 menit sampai permukaan roti keemasan. Keluarkan dari oven.




Demikianlah cara membuat roti unyil kolache yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
