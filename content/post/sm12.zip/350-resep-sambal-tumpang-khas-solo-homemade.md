---
description: "Resep : Sambal Tumpang khas Solo Homemade"
title: "Resep : Sambal Tumpang khas Solo Homemade"
slug: 350-resep-sambal-tumpang-khas-solo-homemade
date: 2020-12-09T12:06:37.664Z
image: https://img-global.cpcdn.com/recipes/cd96c65750a7cfe7/680x482cq70/sambal-tumpang-khas-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cd96c65750a7cfe7/680x482cq70/sambal-tumpang-khas-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cd96c65750a7cfe7/680x482cq70/sambal-tumpang-khas-solo-foto-resep-utama.jpg
author: Edna Abbott
ratingvalue: 4.6
reviewcount: 38492
recipeingredient:
- "125 gr tempe biasa"
- "175 gr tempe semangit bosok"
- "3 bj cabe merah besar"
- "5 bj cabe rawit merah"
- "6 siung bawang merah"
- "2 siung bawang putih"
- "1 ruas jari kencur"
- "2 ruas jari lengkuas geprek"
- "5 lb daun jeruk sobeksobek"
- "3 lb daun salam"
- "1 liter air"
- "100 ml santan saya 30ml santan instanair matang"
- "1/2 sdt garam sesuai selera"
- "1 sdt royco sesuai selera"
- "1 sdt gula pasir"
- "5 bj cabe rawit utuh"
- "3 bj tahu"
- " Pelengkap"
- " Bakwan goreng           lihat resep"
- " Peyek"
- " bayam"
- " kacang panjang"
- " toge"
- " timun"
recipeinstructions:
- "Rebus kacang panjang, tiriskan airnya. Sisihkan. Rebus bayam, tiriskan airnya. Sisihkan."
- "Rendam toge dengan air panas selama 5 menit, tiriskan airnya. Sisihkan. Cuci bersih timun, potong-potong, sisihkan. Tata bayam, kacang panjang, toge dan timun di piring."
- "Belah tahu secara diagonal, goreng hingga berkulit. Tiriskan, sisihkan."
- "Siapakah bahan-bahan yang akan digunakan. Potong tempe biasa dan tempe semangit kotak-kotak."
- "Didihkan 1 liter air, Rebus tempe biasa, tempe semangit bersama cabe merah, cabe rawit, bawang merah, bawang putih, kencur, daun jeruk, daun salam dan Laos. Rebus hingga tempe matang."
- "Angkat cabe merah, cabe rawit, bawang merah, bawang putih, kencur kemudian ulek hingga halus. Masukkan kembali ke air rebusan tempe."
- "Angkat tempe, taruh di cobek (bekas ulek bumbu halus tadi) kemudian ulek tempe sampai hancur. (sesuai selera mau halus atau kasar) Kalau saya ada yang masih kasar. Masukkan kembali ke air rebusan tempe."
- "Beri santan, garam, gula, kaldu bubuk sambil diaduk-aduk. Koreksi rasa."
- "Masukkan tahu goreng dan cabe rawit. masak hingga air mendidih dan matang."
- "Sajikan hangat bersama sayur, gorengan dan rempeyek."
categories:
- Recipe
tags:
- sambal
- tumpang
- khas

katakunci: sambal tumpang khas 
nutrition: 107 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Dessert

---


![Sambal Tumpang khas Solo](https://img-global.cpcdn.com/recipes/cd96c65750a7cfe7/680x482cq70/sambal-tumpang-khas-solo-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang setidaknya kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti sambal tumpang khas solo yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa kesan tersendiri yang merupakan keragaman Indonesia



Keharmonisan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Sambal Tumpang khas Solo untuk orang di rumah. Momen makan bersama keluarga sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda coba salah satunya sambal tumpang khas solo yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep sambal tumpang khas solo tanpa harus bersusah payah.
Seperti resep Sambal Tumpang khas Solo yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 10 langkah dan 24 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambal Tumpang khas Solo:

1. Harap siapkan 125 gr tempe biasa
1. Diperlukan 175 gr tempe semangit (bosok)
1. Siapkan 3 bj cabe merah besar
1. Diperlukan 5 bj cabe rawit merah
1. Harus ada 6 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Jangan lupa 1 ruas jari kencur
1. Siapkan 2 ruas jari lengkuas geprek
1. Harap siapkan 5 lb daun jeruk (sobek-sobek)
1. Harap siapkan 3 lb daun salam
1. Tambah 1 liter air
1. Jangan lupa 100 ml santan (saya 30ml santan instan+air matang)
1. Harap siapkan 1/2 sdt garam (sesuai selera)
1. Harus ada 1 sdt royco (sesuai selera)
1. Diperlukan 1 sdt gula pasir
1. Tambah 5 bj cabe rawit utuh
1. Tambah 3 bj tahu
1. Harus ada  Pelengkap
1. Diperlukan  Bakwan goreng           (lihat resep)
1. Diperlukan  Peyek
1. Dibutuhkan  bayam
1. Harus ada  kacang panjang
1. Siapkan  toge
1. Siapkan  timun




<!--inarticleads2-->

##### Langkah membuat  Sambal Tumpang khas Solo:

1. Rebus kacang panjang, tiriskan airnya. Sisihkan. - Rebus bayam, tiriskan airnya. Sisihkan.
1. Rendam toge dengan air panas selama 5 menit, tiriskan airnya. Sisihkan. - Cuci bersih timun, potong-potong, sisihkan. Tata bayam, kacang panjang, toge dan timun di piring.
1. Belah tahu secara diagonal, goreng hingga berkulit. Tiriskan, sisihkan.
1. Siapakah bahan-bahan yang akan digunakan. Potong tempe biasa dan tempe semangit kotak-kotak.
1. Didihkan 1 liter air, Rebus tempe biasa, tempe semangit bersama cabe merah, cabe rawit, bawang merah, bawang putih, kencur, daun jeruk, daun salam dan Laos. Rebus hingga tempe matang.
1. Angkat cabe merah, cabe rawit, bawang merah, bawang putih, kencur kemudian ulek hingga halus. Masukkan kembali ke air rebusan tempe.
1. Angkat tempe, taruh di cobek (bekas ulek bumbu halus tadi) kemudian ulek tempe sampai hancur. (sesuai selera mau halus atau kasar) Kalau saya ada yang masih kasar. Masukkan kembali ke air rebusan tempe.
1. Beri santan, garam, gula, kaldu bubuk sambil diaduk-aduk. Koreksi rasa.
1. Masukkan tahu goreng dan cabe rawit. masak hingga air mendidih dan matang.
1. Sajikan hangat bersama sayur, gorengan dan rempeyek.




Demikianlah cara membuat sambal tumpang khas solo yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
