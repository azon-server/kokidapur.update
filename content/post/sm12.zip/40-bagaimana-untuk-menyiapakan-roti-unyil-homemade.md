---
description: "Bagaimana untuk menyiapakan Roti Unyil Homemade"
title: "Bagaimana untuk menyiapakan Roti Unyil Homemade"
slug: 40-bagaimana-untuk-menyiapakan-roti-unyil-homemade
date: 2020-11-06T15:20:28.684Z
image: https://img-global.cpcdn.com/recipes/fabc71a5673964fd/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fabc71a5673964fd/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fabc71a5673964fd/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Angel Hoffman
ratingvalue: 4.8
reviewcount: 26114
recipeingredient:
- " Bahan A "
- " Tepung Terigu protein tinggi"
- " tepung terigu protein rendah"
- " susu bubuk"
- " ragi instan"
- " gula castor"
- " Bahan B "
- " cairan 1 butir telur  susu cair  170gr"
- " Bahan C "
- " Butter"
- " garam"
- " Bahan olesan "
- " telur kocok lepas"
- " Isian "
- " Keju"
- " Sosis Ayam"
- " Pisang"
- " Selai coklat"
- " Selai strawberry"
- " Selai blueberry"
recipeinstructions:
- "Campur semua bahan A, aduk rata."
- "Siapkan bahan B, aduk rata. Masukkan Bahan B ke bahan A sambil di uleni hingga 1/2 kalis."
- "Lalu masukkan bahan C, uleni hingga kalis elastis dan bila ditest adonannya tidak mudah sobek dan terlihat windowpane. Bulatkan adonan, dan masukkan kedalam bowl dan tutup atasnya dengan plastik wrap."
- "Istirahatkan kurleb 30-45 menit hingga mengembang 2x lipat. Setelah mengembang, kempiskan adonan, lalu timbang 11-15 gr peradonan."
- "Bentuk dan Isi sesuai selera, lalu letakkan diatas loyang yang sudah dialasi kertas roti. Panaskan oven, setelah panas lalu oles roti dengan telur lalu oven roti 15-20 menit dengan suhu 180°C (sesuaikan oven masing-masing)"
- "Sudah matang dan siap dihidangkan."
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 131 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dessert

---


![Roti Unyil](https://img-global.cpcdn.com/recipes/fabc71a5673964fd/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau enak. Ciri kuliner Nusantara roti unyil yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Keharmonisan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Roti Unyil untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang dapat anda praktekkan salah satunya roti unyil yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep roti unyil tanpa harus bersusah payah.
Berikut ini resep Roti Unyil yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Unyil:

1. Jangan lupa  Bahan A :
1. Tambah  Tepung Terigu protein tinggi
1. Harus ada  tepung terigu protein rendah
1. Jangan lupa  susu bubuk
1. Harus ada  ragi instan
1. Dibutuhkan  gula castor
1. Harus ada  Bahan B :
1. Jangan lupa  cairan (1 butir telur + susu cair = 170gr)
1. Siapkan  Bahan C :
1. Jangan lupa  Butter
1. Harus ada  garam
1. Diperlukan  Bahan olesan :
1. Harus ada  telur, kocok lepas
1. Harus ada  Isian :
1. Tambah  Keju
1. Jangan lupa  Sosis Ayam
1. Harus ada  Pisang
1. Diperlukan  Selai coklat
1. Tambah  Selai strawberry
1. Siapkan  Selai blueberry




<!--inarticleads2-->

##### Instruksi membuat  Roti Unyil:

1. Campur semua bahan A, aduk rata.
1. Siapkan bahan B, aduk rata. Masukkan Bahan B ke bahan A sambil di uleni hingga 1/2 kalis.
1. Lalu masukkan bahan C, uleni hingga kalis elastis dan bila ditest adonannya tidak mudah sobek dan terlihat windowpane. Bulatkan adonan, dan masukkan kedalam bowl dan tutup atasnya dengan plastik wrap.
1. Istirahatkan kurleb 30-45 menit hingga mengembang 2x lipat. Setelah mengembang, kempiskan adonan, lalu timbang 11-15 gr peradonan.
1. Bentuk dan Isi sesuai selera, lalu letakkan diatas loyang yang sudah dialasi kertas roti. Panaskan oven, setelah panas lalu oles roti dengan telur lalu oven roti 15-20 menit dengan suhu 180°C (sesuaikan oven masing-masing)
1. Sudah matang dan siap dihidangkan.




Demikianlah cara membuat roti unyil yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
