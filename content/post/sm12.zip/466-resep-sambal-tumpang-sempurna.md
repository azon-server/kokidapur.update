---
description: "Resep : Sambal Tumpang Sempurna"
title: "Resep : Sambal Tumpang Sempurna"
slug: 466-resep-sambal-tumpang-sempurna
date: 2020-11-14T07:10:08.564Z
image: https://img-global.cpcdn.com/recipes/7daf2ce4fc6ca103/680x482cq70/sambal-tumpang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7daf2ce4fc6ca103/680x482cq70/sambal-tumpang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7daf2ce4fc6ca103/680x482cq70/sambal-tumpang-foto-resep-utama.jpg
author: Lucille McCoy
ratingvalue: 4.9
reviewcount: 43529
recipeingredient:
- "1 papan tempe semangit tempe yang sudah 2 hari"
- "1/2 papan tempe kecil tempe tidak semangitbaru"
- "10 siung bawang merah kecil"
- "4 siung bawang putih"
- "50 gram cabe rawit merah"
- "1 sdt ketumbar bubuk"
- "1 butir kemiri"
- "1 ruas jari kencur"
- "1 ruas jari lengkuas"
- "3 lembar daun jeruk purut"
- "2 lembar daun salam"
- "200 ml santan kental"
- "500 ml air"
- "Secukupnya garam gula kaldu bubuk saya pakai kaldu jamur"
recipeinstructions:
- "Siapkan bahan. Geprek lengkuas."
- "Rebus tempe, cabe, bawang merah, bawang putih, sampai air mendidih. Matikan kompor."
- "Ambil cabe, bawang merah &amp; bawang putih, ulek bersama kencur, kemiri, ketumbar &amp; garam. Air rebusan jangan dibuang, sisihkan saja."
- "Lalu ulek jg tempe semangit &amp; tempe baru yg sdh direbus tadi, hingga halus."
- "Panaskan air bekas rebusan. Setelah mendidih, masukkan bumbu &amp; tempe yg sudah diulek. Aduk rata. Tambahkan gula, kaldu bubuk, daun salam, daun jeruk purut &amp; lengkuas geprek. Aduk rata. Tes rasa. Biarkan mendidih."
- "Setelah mendidih, tambahkan santan. Aduk rata. Biarkan mendidih lagi, usahakan santan tidak pecah."
- "Setelah matang, matikan kompor."
- "Sambal Tumpang siap disajikan untuk keluarga."
categories:
- Recipe
tags:
- sambal
- tumpang

katakunci: sambal tumpang 
nutrition: 237 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT36M"
recipeyield: "4"
recipecategory: Dinner

---


![Sambal Tumpang](https://img-global.cpcdn.com/recipes/7daf2ce4fc6ca103/680x482cq70/sambal-tumpang-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis dan enak. Ciri masakan Indonesia sambal tumpang yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa didapat dengan cara simple. Salah satunya adalah membuat makanan Sambal Tumpang untuk keluarga. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang bisa anda buat salah satunya sambal tumpang yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep sambal tumpang tanpa harus bersusah payah.
Berikut ini resep Sambal Tumpang yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 14 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambal Tumpang:

1. Dibutuhkan 1 papan tempe semangit (tempe yang sudah 2 hari)
1. Jangan lupa 1/2 papan tempe kecil (tempe tidak semangit/baru)
1. Siapkan 10 siung bawang merah kecil
1. Dibutuhkan 4 siung bawang putih
1. Dibutuhkan 50 gram cabe rawit merah
1. Tambah 1 sdt ketumbar bubuk
1. Dibutuhkan 1 butir kemiri
1. Tambah 1 ruas jari kencur
1. Harap siapkan 1 ruas jari lengkuas
1. Siapkan 3 lembar daun jeruk purut
1. Siapkan 2 lembar daun salam
1. Dibutuhkan 200 ml santan kental
1. Harap siapkan 500 ml air
1. Dibutuhkan Secukupnya garam, gula, kaldu bubuk (saya pakai kaldu jamur)




<!--inarticleads2-->

##### Instruksi membuat  Sambal Tumpang:

1. Siapkan bahan. Geprek lengkuas.
1. Rebus tempe, cabe, bawang merah, bawang putih, sampai air mendidih. Matikan kompor.
1. Ambil cabe, bawang merah &amp; bawang putih, ulek bersama kencur, kemiri, ketumbar &amp; garam. Air rebusan jangan dibuang, sisihkan saja.
1. Lalu ulek jg tempe semangit &amp; tempe baru yg sdh direbus tadi, hingga halus.
1. Panaskan air bekas rebusan. Setelah mendidih, masukkan bumbu &amp; tempe yg sudah diulek. Aduk rata. Tambahkan gula, kaldu bubuk, daun salam, daun jeruk purut &amp; lengkuas geprek. Aduk rata. Tes rasa. Biarkan mendidih.
1. Setelah mendidih, tambahkan santan. Aduk rata. Biarkan mendidih lagi, usahakan santan tidak pecah.
1. Setelah matang, matikan kompor.
1. Sambal Tumpang siap disajikan untuk keluarga.




Demikianlah cara membuat sambal tumpang yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan terbukti, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
