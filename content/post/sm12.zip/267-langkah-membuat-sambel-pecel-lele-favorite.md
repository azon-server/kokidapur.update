---
description: "Langkah membuat Sambel Pecel Lele Favorite"
title: "Langkah membuat Sambel Pecel Lele Favorite"
slug: 267-langkah-membuat-sambel-pecel-lele-favorite
date: 2020-10-11T07:25:22.106Z
image: https://img-global.cpcdn.com/recipes/78a9af0c000e1a0d/680x482cq70/sambel-pecel-lele-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/78a9af0c000e1a0d/680x482cq70/sambel-pecel-lele-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/78a9af0c000e1a0d/680x482cq70/sambel-pecel-lele-foto-resep-utama.jpg
author: Matthew Drake
ratingvalue: 4
reviewcount: 4728
recipeingredient:
- "2 siung bawang putih"
- "2 buah tomat di resep 3 buah"
- "20 buah cabe rawit"
- "3/4 sdm terasi"
- "7 lembar daun kemangi"
- "5 sdm minyak goreng"
- "50 ml air"
- "secukupnya garam"
- "secukupnya gula pasir"
recipeinstructions:
- "Iris bawang putih, goreng dengan 3 sdm minyak goreng hingga berwarna kecoklatan tapi jangan sampai gosong. Angkat dan sisihkan."
- "Potong masing-masing tomat menjadi 4 bagian. Lalu tumis bersama cabe rawit dan terasi dengan 3 sdm minyak goreng sampai layu, masukkan daun kemangi dan air, masak sampai mengental."
- "Angkat, pindahkan ke cobek. Tambahkan juga bawang putih goreng tadi, haluskan tambahkan garam dan gula secukupnya."
- "Sajikan."
categories:
- Recipe
tags:
- sambel
- pecel
- lele

katakunci: sambel pecel lele 
nutrition: 118 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Dinner

---


![Sambel Pecel Lele](https://img-global.cpcdn.com/recipes/78a9af0c000e1a0d/680x482cq70/sambel-pecel-lele-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti sambel pecel lele yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa kesan tersendiri yang merupakan keragaman Indonesia

Kedekatan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Sambel Pecel Lele untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang dapat anda praktekkan salah satunya sambel pecel lele yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep sambel pecel lele tanpa harus bersusah payah.
Seperti resep Sambel Pecel Lele yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 9 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sambel Pecel Lele:

1. Jangan lupa 2 siung bawang putih
1. Diperlukan 2 buah tomat (di resep 3 buah)
1. Harus ada 20 buah cabe rawit
1. Siapkan 3/4 sdm terasi
1. Tambah 7 lembar daun kemangi
1. Siapkan 5 sdm minyak goreng
1. Harap siapkan 50 ml air
1. Diperlukan secukupnya garam
1. Tambah secukupnya gula pasir




<!--inarticleads2-->

##### Cara membuat  Sambel Pecel Lele:

1. Iris bawang putih, goreng dengan 3 sdm minyak goreng hingga berwarna kecoklatan tapi jangan sampai gosong. Angkat dan sisihkan.
1. Potong masing-masing tomat menjadi 4 bagian. Lalu tumis bersama cabe rawit dan terasi dengan 3 sdm minyak goreng sampai layu, masukkan daun kemangi dan air, masak sampai mengental.
1. Angkat, pindahkan ke cobek. Tambahkan juga bawang putih goreng tadi, haluskan tambahkan garam dan gula secukupnya.
1. Sajikan.




Demikianlah cara membuat sambel pecel lele yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
