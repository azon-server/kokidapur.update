---
description: "Panduan untuk membuat Roti Unyil minggu ini"
title: "Panduan untuk membuat Roti Unyil minggu ini"
slug: 120-panduan-untuk-membuat-roti-unyil-minggu-ini
date: 2020-12-01T03:47:55.919Z
image: https://img-global.cpcdn.com/recipes/cb85be7e7d4ac8e3/680x482cq70/roti-unyil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cb85be7e7d4ac8e3/680x482cq70/roti-unyil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cb85be7e7d4ac8e3/680x482cq70/roti-unyil-foto-resep-utama.jpg
author: Ethel Berry
ratingvalue: 4.6
reviewcount: 38658
recipeingredient:
- "250 Gr Tepung protein tinggi  Cakra"
- "100 Gr kentang kukushaluskan berat setelah di kukus"
- "1 Sdm susu bubuk"
- "1 btr telur"
- "45 gr Gula pasir"
- "40 gr butter"
- "1/4 sdt garam"
- "50 ml air susu cair"
- "1 sdt ragi instan me fernipan"
- " Bahan Olesan susu kental manis SKM"
- " Bahan Isi"
- " CoklatKejoKismis"
- " Bahan Pelengkap"
- " Abon Gula pasir Gula halus dll"
recipeinstructions:
- "Siapkan bahan."
- "Dalam wadah, masukkan Terigu, kentang halus, gula, ragi instan, susu bubuk dan telur. Aduk rata. Tuangi susu cair sedikit sedikit, lalu uleni sampai setengah kalis. Masukkan butter dan garam, lalu uleni lagi sampai kalis elastis (saya pakai mixer biar cepat dan gak capek)"
- "Bulatkan adonan dan tutup dengan wrap atau kain basah. tunggu sampai mengembang +-40 menit."
- "Kempiskan adonan, uleni sebentar lalu timbang masing2 30 gr. isi degan isian lalu bentuk sesuai selera. biarkan mengembang lagi sekitar 30 menit, lalu olesi SKM. masukkan oven, panggang +- 20-30 menit atau sampai kulit atas kecoklatan. (kenali oven masing2)."
- "Tarrrraaaaa...sudah jadi...roti mini ala aku.."
categories:
- Recipe
tags:
- roti
- unyil

katakunci: roti unyil 
nutrition: 232 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Dinner

---


![Roti Unyil](https://img-global.cpcdn.com/recipes/cb85be7e7d4ac8e3/680x482cq70/roti-unyil-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau renyah. Ciri makanan Nusantara roti unyil yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga dapat ditemukan dengan cara mudah. Salah satunya adalah memasak Roti Unyil untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis makanan yang bisa anda contoh salah satunya roti unyil yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep roti unyil tanpa harus bersusah payah.
Seperti resep Roti Unyil yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Unyil:

1. Siapkan 250 Gr Tepung protein tinggi ( Cakra
1. Dibutuhkan 100 Gr kentang (kukus,haluskan) berat setelah di kukus
1. Jangan lupa 1 Sdm susu bubuk
1. Harap siapkan 1 btr telur
1. Siapkan 45 gr Gula pasir
1. Jangan lupa 40 gr butter
1. Tambah 1/4 sdt garam
1. Siapkan 50 ml air susu cair
1. Dibutuhkan 1 sdt ragi instan (me fernipan)
1. Harap siapkan  Bahan Olesan: susu kental manis (SKM)
1. Tambah  Bahan Isi:
1. Diperlukan  Coklat/Kejo/Kismis
1. Harus ada  Bahan Pelengkap:
1. Siapkan  Abon, Gula pasir, Gula halus dll




<!--inarticleads2-->

##### Cara membuat  Roti Unyil:

1. Siapkan bahan.
1. Dalam wadah, masukkan Terigu, kentang halus, gula, ragi instan, susu bubuk dan telur. Aduk rata. Tuangi susu cair sedikit sedikit, lalu uleni sampai setengah kalis. Masukkan butter dan garam, lalu uleni lagi sampai kalis elastis (saya pakai mixer biar cepat dan gak capek)
1. Bulatkan adonan dan tutup dengan wrap atau kain basah. tunggu sampai mengembang +-40 menit.
1. Kempiskan adonan, uleni sebentar lalu timbang masing2 30 gr. isi degan isian lalu bentuk sesuai selera. biarkan mengembang lagi sekitar 30 menit, lalu olesi SKM. masukkan oven, panggang +- 20-30 menit atau sampai kulit atas kecoklatan. (kenali oven masing2).
1. Tarrrraaaaa...sudah jadi...roti mini ala aku..




Demikianlah cara membuat roti unyil yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan terbukti, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
