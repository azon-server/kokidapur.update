---
description: "Steps menyiapakan Sambal Tumpang Solo Cepat"
title: "Steps menyiapakan Sambal Tumpang Solo Cepat"
slug: 491-steps-menyiapakan-sambal-tumpang-solo-cepat
date: 2021-01-25T22:09:34.180Z
image: https://img-global.cpcdn.com/recipes/56c19450c2426f87/680x482cq70/sambal-tumpang-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/56c19450c2426f87/680x482cq70/sambal-tumpang-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/56c19450c2426f87/680x482cq70/sambal-tumpang-solo-foto-resep-utama.jpg
author: Andre Mendez
ratingvalue: 5
reviewcount: 25064
recipeingredient:
- "1 papan tempe potong kotak"
- "1 potong tahu putih potong dadu"
- "5 btr bawang merah"
- "5 btr bawang putih"
- "5 btr kemiri"
- "2 buah cabe merah besar"
- "5 buah cabe rawit"
- "Secukupnya garam"
- "Secukupnya gula pasir"
- " Kaldu blok opsional"
- "1 buah tomat"
- "2 lbr daun salam"
- "5 lbr daun jeruk"
- "1 ruas lengkuas"
- "1 btg serai"
- "1,5 liter santan"
- " Pelengkap"
- " Kerupuk nasikarak saya kerupuk udang"
- " Kacang panjang rebus"
- " Kecambah rebus"
- " Daun kemangi"
- " Daun pepaya rebus iris saya skip"
- " Bawang goreng"
recipeinstructions:
- "Rebus bersama: tempe, bawang merah putih, cabe merah, cabe rawit menyesuaikan."
- "Uleg kasar tempe dan bumbu yang telah direbus. Ditambah kemiri."
- "Rebus kembali dengan santan encer beserta daun salam, daun jeruk, lengkuas, serai, tomat utuh, gula, dan garam. Masukkan tahu putih."
- "Tuang santan. Didihkan. Masukkan kaldu blok. Tes rasa. Matikan api."
- "Sajikan bersama sayuran rebus dan kerupuk. Taburi bawang goreng. Sambal tumpang nikmat disajikan dengan nasi putih maupun bubur lemu (bubur nasi santan)."
categories:
- Recipe
tags:
- sambal
- tumpang
- solo

katakunci: sambal tumpang solo 
nutrition: 235 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Lunch

---


![Sambal Tumpang Solo](https://img-global.cpcdn.com/recipes/56c19450c2426f87/680x482cq70/sambal-tumpang-solo-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau enak. Ciri khas kuliner Indonesia sambal tumpang solo yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga dapat ditemukan dengan cara simple. Salah satunya adalah membuat makanan Sambal Tumpang Solo untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang dapat anda coba salah satunya sambal tumpang solo yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep sambal tumpang solo tanpa harus bersusah payah.
Seperti resep Sambal Tumpang Solo yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 23 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sambal Tumpang Solo:

1. Dibutuhkan 1 papan tempe, potong kotak
1. Diperlukan 1 potong tahu putih, potong dadu
1. Jangan lupa 5 btr bawang merah
1. Harus ada 5 btr bawang putih
1. Siapkan 5 btr kemiri
1. Siapkan 2 buah cabe merah besar
1. Dibutuhkan 5 buah cabe rawit
1. Diperlukan Secukupnya garam
1. Harus ada Secukupnya gula pasir
1. Jangan lupa  Kaldu blok (opsional)
1. Jangan lupa 1 buah tomat
1. Diperlukan 2 lbr daun salam
1. Tambah 5 lbr daun jeruk
1. Dibutuhkan 1 ruas lengkuas
1. Tambah 1 btg serai
1. Harap siapkan 1,5 liter santan
1. Dibutuhkan  Pelengkap
1. Harus ada  Kerupuk nasi/karak (saya kerupuk udang)
1. Harap siapkan  Kacang panjang rebus
1. Dibutuhkan  Kecambah rebus
1. Jangan lupa  Daun kemangi
1. Tambah  Daun pepaya rebus iris (saya skip)
1. Harap siapkan  Bawang goreng




<!--inarticleads2-->

##### Cara membuat  Sambal Tumpang Solo:

1. Rebus bersama: tempe, bawang merah putih, cabe merah, cabe rawit menyesuaikan.
1. Uleg kasar tempe dan bumbu yang telah direbus. Ditambah kemiri.
1. Rebus kembali dengan santan encer beserta daun salam, daun jeruk, lengkuas, serai, tomat utuh, gula, dan garam. Masukkan tahu putih.
1. Tuang santan. Didihkan. Masukkan kaldu blok. Tes rasa. Matikan api.
1. Sajikan bersama sayuran rebus dan kerupuk. Taburi bawang goreng. Sambal tumpang nikmat disajikan dengan nasi putih maupun bubur lemu (bubur nasi santan).




Demikianlah cara membuat sambal tumpang solo yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
