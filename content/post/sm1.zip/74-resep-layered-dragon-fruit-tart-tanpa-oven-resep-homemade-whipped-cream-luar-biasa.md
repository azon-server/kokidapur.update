---
description: "Resep : Layered Dragon Fruit Tart (Tanpa Oven) + Resep Homemade Whipped Cream Luar biasa"
title: "Resep : Layered Dragon Fruit Tart (Tanpa Oven) + Resep Homemade Whipped Cream Luar biasa"
slug: 74-resep-layered-dragon-fruit-tart-tanpa-oven-resep-homemade-whipped-cream-luar-biasa
date: 2020-12-03T12:56:27.733Z
image: https://img-global.cpcdn.com/recipes/6428432eef761a2e/751x532cq70/layered-dragon-fruit-tart-tanpa-oven-resep-homemade-whipped-cream-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6428432eef761a2e/751x532cq70/layered-dragon-fruit-tart-tanpa-oven-resep-homemade-whipped-cream-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6428432eef761a2e/751x532cq70/layered-dragon-fruit-tart-tanpa-oven-resep-homemade-whipped-cream-foto-resep-utama.jpg
author: Eliza Mitchell
ratingvalue: 4.7
reviewcount: 34542
recipeingredient:
- " Bahan Crust Dasar Tart"
- "120 gr biskuit saya Regal bungkus kecil"
- "80 gr butter leleh saya margarin"
- " Bahan Filling"
- "50 ml susu cair"
- "2 kuning telur"
- "35 gr gula pasir halus"
- "35 gr tepung custard saya Maizena"
- "200 ml susu cair"
- "35 gr gula pasir halus"
- "1 sdt pasta vanila saya essence vanila"
- "35 gr butter dingin saya margarin"
- "100 gr whipped cream"
- " Bahan Lapisan Jelly"
- "100 gr buah naga haluskan dengan sendok saja"
- "50 ml air"
- "3 sdm gula"
- "1 sdt agaragar plain"
- " Bahan Whipped Cream"
- "75 gr krimer saya Fibercreme"
- "1 sdm gula halus"
- "30-50 ml air dingin"
- "5 sdm air jeruk lemonnipis"
- " Bahan Topping"
- "Secukupnya buah naga"
- "Secukupnya agaragar plain untuk olesan 1 sdt agar50 ml air dimasak sampai mendidih"
recipeinstructions:
- "Crust : Hancurkan biskuit, tidak usah terlalu halus spt pasir. Lalu campur dengan margarin leleh, aduk rata. Tuang ke loyang, padatkan, simpan di kulkas sampai set."
- "Filling : campur dulu dalam mangkuk, 100 ml susu cair+gula+kuning telur, aduk dgn whisk sampai gula larut. Lalu masukkan tepung maizena aduk rata."
- "Kemudian campur dalam panci 200 ml susu+gula+vanila, aduk rata didihkan. Matikan kompor. Tuang perlahan 1/2 bagian susu yang dididihkan tadi ke adonan kuning telur sambil diaduk terus spy telur tidak bergumpal."
- "Lalu tuang adonan kuning telur kembali ke panci yang berisi susu, aduk rata. Nyalakan kompor api kecil, masak sampai adonan kental. Matikan kompor, masukkan margarin, aduk sampai tercampur rata."
- "Tuang filling di dalam container, bungkus permukaannya dgn plastik lalu tutup containernya, Dinginkan dalam kulkas. Tujuannya ditutup plastik spy adonan tdk berkulit atasnya."
- "Sambil menunggu dingin, buat lapisan jelly : campur semua bahan, masak sampai mendidih, lalu cetak di piring datar. Biarkan dingin sampai set."
- "Whipped cream : campur krimer+gula+air dingin aduk rata, lalu masukkan air jeruk aduk sampai kental. Dinginkan dalam kulkas. Setelah filling dingin keluarkan dari kulkas lalu campur dgn whipped cream aduk rata."
- "Jika semua sudah set, keluarkan crust, beri 1/3 bagian filling, lalu taruh jelly di atasnya, tekan perlahan sedikit, lalu tutup lagi dgn filling, ratakan."
- "Beri topping buah naga dan oles dengan adonan agar-agar spy buah lebih awet. Simpan kembali dalam kulkas agar lebih set."
- "Ini penampakan layernya setelah dipotong. Sayang tadi crustnya belum terlalu set jadi agak hancur saat dipotong...anak2 sudah tdk sabar sih pengen cicip 🙈"
categories:
- Recipe
tags:
- layered
- dragon
- fruit

katakunci: layered dragon fruit 
nutrition: 226 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Lunch

---


![Layered Dragon Fruit Tart (Tanpa Oven) + Resep Homemade Whipped Cream](https://img-global.cpcdn.com/recipes/6428432eef761a2e/751x532cq70/layered-dragon-fruit-tart-tanpa-oven-resep-homemade-whipped-cream-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti layered dragon fruit tart (tanpa oven) + resep homemade whipped cream yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Nusantara



Keharmonisan keluarga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Layered Dragon Fruit Tart (Tanpa Oven) + Resep Homemade Whipped Cream untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang dapat anda coba salah satunya layered dragon fruit tart (tanpa oven) + resep homemade whipped cream yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep layered dragon fruit tart (tanpa oven) + resep homemade whipped cream tanpa harus bersusah payah.
Seperti resep Layered Dragon Fruit Tart (Tanpa Oven) + Resep Homemade Whipped Cream yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 10 langkah dan 26 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Layered Dragon Fruit Tart (Tanpa Oven) + Resep Homemade Whipped Cream:

1. Tambah  Bahan Crust (Dasar Tart)
1. Jangan lupa 120 gr biskuit (saya Regal bungkus kecil)
1. Jangan lupa 80 gr butter leleh (saya margarin)
1. Dibutuhkan  Bahan Filling
1. Jangan lupa 50 ml susu cair
1. Jangan lupa 2 kuning telur
1. Siapkan 35 gr gula pasir halus
1. Harap siapkan 35 gr tepung custard (saya Maizena)
1. Siapkan 200 ml susu cair
1. Tambah 35 gr gula pasir halus
1. Harus ada 1 sdt pasta vanila (saya essence vanila)
1. Diperlukan 35 gr butter dingin (saya margarin)
1. Dibutuhkan 100 gr whipped cream
1. Diperlukan  Bahan Lapisan Jelly
1. Harap siapkan 100 gr buah naga, haluskan dengan sendok saja
1. Diperlukan 50 ml air
1. Tambah 3 sdm gula
1. Tambah 1 sdt agar-agar plain
1. Jangan lupa  Bahan Whipped Cream
1. Tambah 75 gr krimer (saya Fibercreme)
1. Diperlukan 1 sdm gula halus
1. Dibutuhkan 30-50 ml air dingin
1. Diperlukan 5 sdm air jeruk lemon/nipis
1. Jangan lupa  Bahan Topping
1. Dibutuhkan Secukupnya buah naga
1. Tambah Secukupnya agar-agar plain untuk olesan (1 sdt agar”+50 ml air dimasak sampai mendidih)




<!--inarticleads2-->

##### Bagaimana membuat  Layered Dragon Fruit Tart (Tanpa Oven) + Resep Homemade Whipped Cream:

1. Crust : Hancurkan biskuit, tidak usah terlalu halus spt pasir. Lalu campur dengan margarin leleh, aduk rata. Tuang ke loyang, padatkan, simpan di kulkas sampai set.
1. Filling : campur dulu dalam mangkuk, 100 ml susu cair+gula+kuning telur, aduk dgn whisk sampai gula larut. Lalu masukkan tepung maizena aduk rata.
1. Kemudian campur dalam panci 200 ml susu+gula+vanila, aduk rata didihkan. Matikan kompor. Tuang perlahan 1/2 bagian susu yang dididihkan tadi ke adonan kuning telur sambil diaduk terus spy telur tidak bergumpal.
1. Lalu tuang adonan kuning telur kembali ke panci yang berisi susu, aduk rata. Nyalakan kompor api kecil, masak sampai adonan kental. Matikan kompor, masukkan margarin, aduk sampai tercampur rata.
1. Tuang filling di dalam container, bungkus permukaannya dgn plastik lalu tutup containernya, Dinginkan dalam kulkas. Tujuannya ditutup plastik spy adonan tdk berkulit atasnya.
1. Sambil menunggu dingin, buat lapisan jelly : campur semua bahan, masak sampai mendidih, lalu cetak di piring datar. Biarkan dingin sampai set.
1. Whipped cream : campur krimer+gula+air dingin aduk rata, lalu masukkan air jeruk aduk sampai kental. Dinginkan dalam kulkas. Setelah filling dingin keluarkan dari kulkas lalu campur dgn whipped cream aduk rata.
1. Jika semua sudah set, keluarkan crust, beri 1/3 bagian filling, lalu taruh jelly di atasnya, tekan perlahan sedikit, lalu tutup lagi dgn filling, ratakan.
1. Beri topping buah naga dan oles dengan adonan agar-agar spy buah lebih awet. Simpan kembali dalam kulkas agar lebih set.
1. Ini penampakan layernya setelah dipotong. Sayang tadi crustnya belum terlalu set jadi agak hancur saat dipotong...anak2 sudah tdk sabar sih pengen cicip 🙈




Demikianlah cara membuat layered dragon fruit tart (tanpa oven) + resep homemade whipped cream yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan teruji, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
