---
description: "Langkah menyiapakan Ice Cream Ubi (Tanpa Whipped cream Tanpa Ovalet) Teruji"
title: "Langkah menyiapakan Ice Cream Ubi (Tanpa Whipped cream Tanpa Ovalet) Teruji"
slug: 170-langkah-menyiapakan-ice-cream-ubi-tanpa-whipped-cream-tanpa-ovalet-teruji
date: 2021-02-15T15:01:11.234Z
image: https://img-global.cpcdn.com/recipes/b1d88ac1b5a22093/751x532cq70/ice-cream-ubi-tanpa-whipped-cream-tanpa-ovalet-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b1d88ac1b5a22093/751x532cq70/ice-cream-ubi-tanpa-whipped-cream-tanpa-ovalet-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b1d88ac1b5a22093/751x532cq70/ice-cream-ubi-tanpa-whipped-cream-tanpa-ovalet-foto-resep-utama.jpg
author: John Wade
ratingvalue: 4.2
reviewcount: 18594
recipeingredient:
- "250 gram ubi jalar kukus tanpa kulit"
- "470 ml susu cair plain"
- "80 gram SKM susu kental manis"
- "60 gram gula pasir sesuaikan dengan kemanisan ubi"
- "40 gram santan bubuk"
- "1/4 sdt garam"
- "3-5 tetes pewarna merah"
- " Topping sesuai selera"
- "2 sdm nata de coco"
recipeinstructions:
- "Masukkan semua bahan ice cream (kecuali topping) ke dalam blender lalu blender hingga halus"
- "Pindahkan ke dalam wadah lalu masukkan frezer selama 5-6 jam (hingga kristal es terbentuk) lalu mixer hingga kristal es hancur dan tekstur lembut. Masukkan frezer kembali selama 1 jam"
- "Setelah satu jam mixer kembali eskrim hingga lembut (ulangi proses ini 3-4x hingga tingkat kelembutan yang diinginkan)"
- "Masukkan kembali dalam frezer dan tunggu hingga mengeras."
- "Eskrim nan lembut siap disajikan jangan lupa tambahkan nata de coco atau topping lain sesuai selera."
categories:
- Recipe
tags:
- ice
- cream
- ubi

katakunci: ice cream ubi 
nutrition: 153 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Lunch

---


![Ice Cream Ubi (Tanpa Whipped cream Tanpa Ovalet)](https://img-global.cpcdn.com/recipes/b1d88ac1b5a22093/751x532cq70/ice-cream-ubi-tanpa-whipped-cream-tanpa-ovalet-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga empuk. Ciri khas makanan Indonesia ice cream ubi (tanpa whipped cream tanpa ovalet) yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.


Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ice Cream Ubi (Tanpa Whipped cream Tanpa Ovalet) untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda praktekkan salah satunya ice cream ubi (tanpa whipped cream tanpa ovalet) yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep ice cream ubi (tanpa whipped cream tanpa ovalet) tanpa harus bersusah payah.
Seperti resep Ice Cream Ubi (Tanpa Whipped cream Tanpa Ovalet) yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 9 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ice Cream Ubi (Tanpa Whipped cream Tanpa Ovalet):

1. Harus ada 250 gram ubi jalar kukus (tanpa kulit)
1. Tambah 470 ml susu cair plain
1. Harap siapkan 80 gram SKM (susu kental manis)
1. Tambah 60 gram gula pasir (sesuaikan dengan kemanisan ubi)
1. Harus ada 40 gram santan bubuk
1. Siapkan 1/4 sdt garam
1. Siapkan 3-5 tetes pewarna merah
1. Jangan lupa  Topping sesuai selera
1. Harus ada 2 sdm nata de coco




<!--inarticleads2-->

##### Langkah membuat  Ice Cream Ubi (Tanpa Whipped cream Tanpa Ovalet):

1. Masukkan semua bahan ice cream (kecuali topping) ke dalam blender lalu blender hingga halus
1. Pindahkan ke dalam wadah lalu masukkan frezer selama 5-6 jam (hingga kristal es terbentuk) lalu mixer hingga kristal es hancur dan tekstur lembut. Masukkan frezer kembali selama 1 jam
1. Setelah satu jam mixer kembali eskrim hingga lembut (ulangi proses ini 3-4x hingga tingkat kelembutan yang diinginkan)
1. Masukkan kembali dalam frezer dan tunggu hingga mengeras.
1. Eskrim nan lembut siap disajikan jangan lupa tambahkan nata de coco atau topping lain sesuai selera.




Demikianlah cara membuat ice cream ubi (tanpa whipped cream tanpa ovalet) yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan cepat, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
