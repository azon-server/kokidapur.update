---
description: "Langkah membuat Cireng Cocol Bumbu Rujak teraktual"
title: "Langkah membuat Cireng Cocol Bumbu Rujak teraktual"
slug: 372-langkah-membuat-cireng-cocol-bumbu-rujak-teraktual
date: 2021-01-24T05:54:55.705Z
image: https://img-global.cpcdn.com/recipes/da98f8f12b1fb0bc/751x532cq70/cireng-cocol-bumbu-rujak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/da98f8f12b1fb0bc/751x532cq70/cireng-cocol-bumbu-rujak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/da98f8f12b1fb0bc/751x532cq70/cireng-cocol-bumbu-rujak-foto-resep-utama.jpg
author: Jared Maldonado
ratingvalue: 4.5
reviewcount: 6747
recipeingredient:
- " Bahan biangbahan basah "
- "100 gr10 sdm tepung tapiokakanjisagu"
- "3 siung bawang putih rajang halus tumis"
- "2-3 helai daun bawang iris tumis"
- "1 sdt garam"
- "1 bungkus royco ayam"
- "1 sdm gula pasir"
- "400 ml air matang"
- " Bahan kering "
- "100 gr10 sdm tepung tapioka kanji sagu dalam wadah terpisah"
- " Bumbu rujak "
- "1 bonggol gula merah"
- "Secukupnya cabe rawit"
- "2 cm terasi bakar"
- "Secukupnya asam jawa"
- "3-4 sdm air matang"
recipeinstructions:
- "Pertama siapkan adonan biang dalam panci sebelum dimasak, campur semua bahan biang termasuk air 400 ml (rajangan bawang putih&amp;daun bawang sdh ditumis terlebih dahulu). Aduk rata sampai tdk menggumpal lalu masak dlm api sangat kecil smbil terus diaduk &amp; sampai mengental SEPERTI LEM ! Tapi warna jangan sampai transparan"
- "Jika adonan biang sudah mengental, matikan api kompor selanjutnya campurkan adonan biang dgn adonan kering yg sbelumnya sdh disiapkan dlm wadah yg lebih besar. Campur &amp; uleni dgn ujung jari² tangan (hati² masih panas)"
- "Karena ini cireng polosan jd ketika menguleninya tidak perlu smpai kalis, uleni asal saja yg penting adonan basah terbalur adonan kering, biarkan tekstur adonan bergumpal (Disitulah yg bikin luarnya garing stelah digoreng). comot per adonan bentuk sesuai selera tp tdk perlu menekan²."
- "Kemudian goreng adonan cireng diatas api kecil smbil diaduk² agar tidak meletup². NB : mulailah menggoreng cireng ketika minyak belum terlalu panas. Jika sdh mangapung &amp; ringan/garing, angkat lalu sisihkan. Nikmat selagi hangat"
- "Buatlah sambal rujak sebagai cocolan dengan ulek semua bahan sambal rujak &amp; campur dgn bbrp sendok air matang agar tdk trlalu kental."
categories:
- Recipe
tags:
- cireng
- cocol
- bumbu

katakunci: cireng cocol bumbu 
nutrition: 182 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Dessert

---


![Cireng Cocol Bumbu Rujak](https://img-global.cpcdn.com/recipes/da98f8f12b1fb0bc/751x532cq70/cireng-cocol-bumbu-rujak-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga gurih. Ciri masakan Nusantara cireng cocol bumbu rujak yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Cireng Cocol Bumbu Rujak untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang dapat anda coba salah satunya cireng cocol bumbu rujak yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep cireng cocol bumbu rujak tanpa harus bersusah payah.
Seperti resep Cireng Cocol Bumbu Rujak yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Cireng Cocol Bumbu Rujak:

1. Siapkan  Bahan biang/bahan basah :
1. Jangan lupa 100 gr/10 sdm tepung tapioka/kanji/sagu
1. Harus ada 3 siung bawang putih (rajang halus, tumis)
1. Tambah 2-3 helai daun bawang (iris, tumis)
1. Harap siapkan 1 sdt garam
1. Jangan lupa 1 bungkus royco ayam
1. Harap siapkan 1 sdm gula pasir
1. Diperlukan 400 ml air matang
1. Diperlukan  Bahan kering :
1. Harap siapkan 100 gr/10 sdm tepung tapioka /kanji /sagu (dalam wadah terpisah)
1. Siapkan  Bumbu rujak :
1. Harap siapkan 1 bonggol gula merah
1. Jangan lupa Secukupnya cabe rawit
1. Harap siapkan 2 cm terasi bakar
1. Dibutuhkan Secukupnya asam jawa
1. Jangan lupa 3-4 sdm air matang




<!--inarticleads2-->

##### Instruksi membuat  Cireng Cocol Bumbu Rujak:

1. Pertama siapkan adonan biang dalam panci sebelum dimasak, campur semua bahan biang termasuk air 400 ml (rajangan bawang putih&amp;daun bawang sdh ditumis terlebih dahulu). Aduk rata sampai tdk menggumpal lalu masak dlm api sangat kecil smbil terus diaduk &amp; sampai mengental SEPERTI LEM ! Tapi warna jangan sampai transparan
1. Jika adonan biang sudah mengental, matikan api kompor selanjutnya campurkan adonan biang dgn adonan kering yg sbelumnya sdh disiapkan dlm wadah yg lebih besar. Campur &amp; uleni dgn ujung jari² tangan (hati² masih panas)
1. Karena ini cireng polosan jd ketika menguleninya tidak perlu smpai kalis, uleni asal saja yg penting adonan basah terbalur adonan kering, biarkan tekstur adonan bergumpal (Disitulah yg bikin luarnya garing stelah digoreng). comot per adonan bentuk sesuai selera tp tdk perlu menekan².
1. Kemudian goreng adonan cireng diatas api kecil smbil diaduk² agar tidak meletup². NB : mulailah menggoreng cireng ketika minyak belum terlalu panas. Jika sdh mangapung &amp; ringan/garing, angkat lalu sisihkan. Nikmat selagi hangat
1. Buatlah sambal rujak sebagai cocolan dengan ulek semua bahan sambal rujak &amp; campur dgn bbrp sendok air matang agar tdk trlalu kental.




Demikianlah cara membuat cireng cocol bumbu rujak yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
