---
description: "Cara untuk menyiapakan Odading atau Roti Goreng (tanpa ulen) Favorite"
title: "Cara untuk menyiapakan Odading atau Roti Goreng (tanpa ulen) Favorite"
slug: 58-cara-untuk-menyiapakan-odading-atau-roti-goreng-tanpa-ulen-favorite
date: 2020-12-08T20:37:00.108Z
image: https://img-global.cpcdn.com/recipes/98ac5bb621d379c9/751x532cq70/odading-atau-roti-goreng-tanpa-ulen-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/98ac5bb621d379c9/751x532cq70/odading-atau-roti-goreng-tanpa-ulen-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/98ac5bb621d379c9/751x532cq70/odading-atau-roti-goreng-tanpa-ulen-foto-resep-utama.jpg
author: Luis Bryan
ratingvalue: 5
reviewcount: 37925
recipeingredient:
- "100 ml air hangat"
- "4 sdm gula pasir"
- "1 sdt ragi instan"
- "1 butir telur"
- "3 sdm minyak goreng"
- "250 gram tepung terigu protein tinggi"
- "1 sdt garam"
- "Secukupnya wijen"
- " Minyak untuk menggoreng"
- " Bahan Olesan"
- "1,5 sdm gula pasir"
- "2 sdm air hangat"
recipeinstructions:
- "Siapkan air hangat, masukkan gula, aduk hingga larut"
- "Tambahkan ragi, tunggu sekitar 10-15 menit sampai berbuih"
- "Masukkan telur dan minyak, aduk rata"
- "Dalam wadah yang berbeda, campurkan terigu dan garam, aduk rata"
- "Tuang larutan ragi sedikit demi sedikit sambil diaduk"
- "Jika sudah kalis, tutup dengan lap bersih, tunggu sekitar 30-1 jam"
- "Setelah adonan mengembang, kempiskan dan gilas dengan ketebalan 1-1,5 cm, potong sesuai selera"
- "Beri olesan dari bahan olesan yang telah dicampur rata, taburi wijen dan diamkan sekitar 15-25 menit"
- "Panaskan minyak, goreng dengan api sedang hingga kecoklatan, kemudian angkat"
- "Siap disajikan. Empuuuk dan nikmat sekali. Selamat mencoba"
categories:
- Recipe
tags:
- odading
- atau
- roti

katakunci: odading atau roti 
nutrition: 198 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Lunch

---


![Odading atau Roti Goreng (tanpa ulen)](https://img-global.cpcdn.com/recipes/98ac5bb621d379c9/751x532cq70/odading-atau-roti-goreng-tanpa-ulen-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga empuk. Ciri khas makanan Nusantara odading atau roti goreng (tanpa ulen) yang kaya dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah memasak Odading atau Roti Goreng (tanpa ulen) untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang bisa anda praktekkan salah satunya odading atau roti goreng (tanpa ulen) yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep odading atau roti goreng (tanpa ulen) tanpa harus bersusah payah.
Berikut ini resep Odading atau Roti Goreng (tanpa ulen) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 12 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Odading atau Roti Goreng (tanpa ulen):

1. Tambah 100 ml air hangat
1. Siapkan 4 sdm gula pasir
1. Jangan lupa 1 sdt ragi instan
1. Harus ada 1 butir telur
1. Diperlukan 3 sdm minyak goreng
1. Jangan lupa 250 gram tepung terigu protein tinggi
1. Tambah 1 sdt garam
1. Harap siapkan Secukupnya wijen
1. Dibutuhkan  Minyak untuk menggoreng
1. Siapkan  Bahan Olesan
1. Tambah 1,5 sdm gula pasir
1. Jangan lupa 2 sdm air hangat




<!--inarticleads2-->

##### Bagaimana membuat  Odading atau Roti Goreng (tanpa ulen):

1. Siapkan air hangat, masukkan gula, aduk hingga larut
1. Tambahkan ragi, tunggu sekitar 10-15 menit sampai berbuih
1. Masukkan telur dan minyak, aduk rata
1. Dalam wadah yang berbeda, campurkan terigu dan garam, aduk rata
1. Tuang larutan ragi sedikit demi sedikit sambil diaduk
1. Jika sudah kalis, tutup dengan lap bersih, tunggu sekitar 30-1 jam
1. Setelah adonan mengembang, kempiskan dan gilas dengan ketebalan 1-1,5 cm, potong sesuai selera
1. Beri olesan dari bahan olesan yang telah dicampur rata, taburi wijen dan diamkan sekitar 15-25 menit
1. Panaskan minyak, goreng dengan api sedang hingga kecoklatan, kemudian angkat
1. Siap disajikan. Empuuuk dan nikmat sekali. Selamat mencoba




Demikianlah cara membuat odading atau roti goreng (tanpa ulen) yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat gampang dan teruji, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
