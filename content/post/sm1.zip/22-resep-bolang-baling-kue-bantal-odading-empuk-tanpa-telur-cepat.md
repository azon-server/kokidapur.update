---
description: "Resep : Bolang baling/kue bantal/odading (empuk tanpa telur) Cepat"
title: "Resep : Bolang baling/kue bantal/odading (empuk tanpa telur) Cepat"
slug: 22-resep-bolang-baling-kue-bantal-odading-empuk-tanpa-telur-cepat
date: 2021-02-02T12:48:03.708Z
image: https://img-global.cpcdn.com/recipes/0a17b6c4f84994a8/751x532cq70/bolang-balingkue-bantalodading-empuk-tanpa-telur-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0a17b6c4f84994a8/751x532cq70/bolang-balingkue-bantalodading-empuk-tanpa-telur-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0a17b6c4f84994a8/751x532cq70/bolang-balingkue-bantalodading-empuk-tanpa-telur-foto-resep-utama.jpg
author: Sam Bridges
ratingvalue: 4.8
reviewcount: 45352
recipeingredient:
- "250 gr terigu protein tinggi mecakra"
- "50 gr terigu protein sedang mesegitiga"
- "100 gr gula pasir halus medblender"
- "1.5 sdt ragi instant mefermipan"
- "1 sdt soda kue measahi td pake 12sdt"
- "150 ml air putih biasa"
- "40 gr margarin mebband"
- " Secukupnya"
- " Wijen meskip"
- " Minyak untuk menggoreng"
recipeinstructions:
- "Campur jd satu, tepung terigu, gula pasir halus, ragi, soda kue, aduk rata.. Tuang air sedikit2 uleni sampai setengah Kalis pakai tangan.. Setelah setengah Kalis masukan margarin uleni lagi sampai kalis pake mixer (ga kalis2 banget juga gpp, uleni smpe bisa d tarik aja)"
- "Bulatkan adonan.Diamkan d wadah yg sudah d taburi sedikit tepung.. Diamkan sama 50-1 jam trgantung suhu tempat masing2 dngan d tutup plastik.. (Sy td 50 menit)"
- "Setelah mengembang 2x lipat.. Tinju adonan supaya udara keluar, kmudian uleni lg sebentar."
- "Gilas adonan dgn rollin ketebalan 1 atau 1.5 cm.."
- "Potong2 pakai pisau besar nya sesuaikan selera ya.."
- "Kemudian olesi dgn air dan taburi wijen sedikit tekan2 supaya wijen nempel.. Tata d loyang.."
- "Tutup lagi dgn plastik, diamkan lagi 10 menit.."
- "Panaskan minyak.. goreng bolang baling sampe kekuningan.."
- "Note*  1. Tips saat menggoreng..  *Minyak jangan trlalu panas nanti cepet gosong  *Goreng nya pakai api kecil aja  *jangan d bolak balik, sekali balik aja  *saat masukan bolang baling ke wajan"
- ""
categories:
- Recipe
tags:
- bolang
- balingkue
- bantalodading

katakunci: bolang balingkue bantalodading 
nutrition: 155 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Dinner

---


![Bolang baling/kue bantal/odading (empuk tanpa telur)](https://img-global.cpcdn.com/recipes/0a17b6c4f84994a8/751x532cq70/bolang-balingkue-bantalodading-empuk-tanpa-telur-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga gurih. Karasteristik kuliner Indonesia bolang baling/kue bantal/odading (empuk tanpa telur) yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Bolang baling/kue bantal/odading (empuk tanpa telur) untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.

Donat Empuk Tanpa Telur Tanpa Susu Tanpa Mixer Sekali Proofing Takaran Sendok Cuma Enam Bahan. Kue Bantal Bolang Baling Empuk Banget Cara Buat Tips Dan Trik. Odading jadi perbincangan hangat belakangan ini. Roti goreng khas Bandung ini ternyata punya banyak nama lain di daerah Indonesia.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang dapat anda praktekkan salah satunya bolang baling/kue bantal/odading (empuk tanpa telur) yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep bolang baling/kue bantal/odading (empuk tanpa telur) tanpa harus bersusah payah.
Berikut ini resep Bolang baling/kue bantal/odading (empuk tanpa telur) yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 10 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Bolang baling/kue bantal/odading (empuk tanpa telur):

1. Harus ada 250 gr terigu protein tinggi (me:cakra)
1. Siapkan 50 gr terigu protein sedang (me:segitiga)
1. Dibutuhkan 100 gr gula pasir halus (me:dblender)
1. Tambah 1.5 sdt ragi instant (me:fermipan)
1. Dibutuhkan 1 sdt soda kue (me:asahi td pake 1/2sdt)
1. Harap siapkan 150 ml air putih biasa
1. Jangan lupa 40 gr margarin (me:b.band)
1. Siapkan  Secukupnya:
1. Harus ada  Wijen (me:skip)
1. Harus ada  Minyak untuk menggoreng


Cara Membuat Kue Bantal Kopong Tengah Atau Kue Bolang Baling Yang Empuk Dari Juragan Kue Bantal. Kendati tampak mirip dengan bolang-baling atau kue bantal, ternyata keduanya beda, lo, Millens. Perbedaan paling kentara terletak pada bahan pembuatannya. Bolang-baling menggunakan soda kue dan amoniak dalam pembuatannya, sedangkan odading tidak. 

<!--inarticleads2-->

##### Langkah membuat  Bolang baling/kue bantal/odading (empuk tanpa telur):

1. Campur jd satu, tepung terigu, gula pasir halus, ragi, soda kue, aduk rata.. Tuang air sedikit2 uleni sampai setengah Kalis pakai tangan.. Setelah setengah Kalis masukan margarin uleni lagi sampai kalis pake mixer (ga kalis2 banget juga gpp, uleni smpe bisa d tarik aja)
1. Bulatkan adonan.Diamkan d wadah yg sudah d taburi sedikit tepung.. Diamkan sama 50-1 jam trgantung suhu tempat masing2 dngan d tutup plastik.. (Sy td 50 menit)
1. Setelah mengembang 2x lipat.. Tinju adonan supaya udara keluar, kmudian uleni lg sebentar.
1. Gilas adonan dgn rollin ketebalan 1 atau 1.5 cm..
1. Potong2 pakai pisau besar nya sesuaikan selera ya..
1. Kemudian olesi dgn air dan taburi wijen sedikit tekan2 supaya wijen nempel.. Tata d loyang..
1. Tutup lagi dgn plastik, diamkan lagi 10 menit..
1. Panaskan minyak.. goreng bolang baling sampe kekuningan..
1. Note*  - 1. Tips saat menggoreng..  - *Minyak jangan trlalu panas nanti cepet gosong  - *Goreng nya pakai api kecil aja  - *jangan d bolak balik, sekali balik aja  - *saat masukan bolang baling ke wajan
1. 


Perbedaan paling kentara terletak pada bahan pembuatannya. Bolang-baling menggunakan soda kue dan amoniak dalam pembuatannya, sedangkan odading tidak. Tahu bolang baling atau odading ga? Resep kue bantal anti gagal garing diluar empuk didalam. Resep Kue Odading Bantal Khas Bandung Sederhana Lembut dan Empuk Spesial Asli Enak. 

Demikianlah cara membuat bolang baling/kue bantal/odading (empuk tanpa telur) yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
