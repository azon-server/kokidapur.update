---
description: "Step-by-Step untuk membuat Odading HULK aka isi Kacang Ijo Teruji"
title: "Step-by-Step untuk membuat Odading HULK aka isi Kacang Ijo Teruji"
slug: 54-step-by-step-untuk-membuat-odading-hulk-aka-isi-kacang-ijo-teruji
date: 2020-09-29T10:25:55.197Z
image: https://img-global.cpcdn.com/recipes/e168e3070c366d61/751x532cq70/odading-hulk-aka-isi-kacang-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e168e3070c366d61/751x532cq70/odading-hulk-aka-isi-kacang-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e168e3070c366d61/751x532cq70/odading-hulk-aka-isi-kacang-ijo-foto-resep-utama.jpg
author: Mike Smith
ratingvalue: 4.8
reviewcount: 16504
recipeingredient:
- "250 gr Tepung Cakra"
- "1 butir telur"
- "2 Sdm Mentega"
- "1 Sachet SKM"
- "1 bks Vanilli bubuk"
- " Bahan Biang"
- "100 ml Air Hangat"
- "1 Sdt Ragi Instant"
- "2 Sdm Gula Pasir"
- " bahan pelengkap"
- "Biji wijen putih secukupnya"
- " Minyak untuk menggoreng"
- " bahan isian"
- "125 gr Kacang Ijo Kupas"
- "75 gr Gula"
- "1 Bks Santan Kara 60ml"
- "1 Sdt Pasta Pandan"
- " Air Secukupnya untuk merebus kacang"
recipeinstructions:
- "Membuat biang: Campur ragi, gula pasir dan air hangat, aduk rata sampe gula larut diamkan 5-10 menit. Kalo tdk berbuih buang saja ganti yg baru."
- "Taruh di wadah, margarin, telur, skm, vanili, bahan biang dan terigu. Uleni atau Mixer hingga kalis"
- "Siapkan wadah, olesi dengan minyak tipis2, simpan adonan, tutup dan diamkan selama 45 menit"
- "Sementara menunggu rebus kacang ijo dengan air secukupnya sampai saat. Siapkan santan kara ditambah dengan 40ml air, aduk sampai larut. Masukkan ke dalam kacang yang sudah matang, tambahkan gula dan pandan. Masak kembali hingga santan menyusut. Jika kurang halus boleh di blender. Sisihkan"
- "Setelah 45menit, timbang adonan masing2 30gr, rounding,tutup dan diamkan selama 15 menit. Pipihkan adonan lalu isi dengan isian kacang hijau."
- "Basahi wijen dengan sedikit air putih agar lembab, tempel adonan ke wijen. Agak ditekan agar menempel. Setelah selesai diamkan kembali 15 menit. Lalu goreng dengan api kecil hingga matang. Odading HULK pun sudah siaaap.. rasanya empuuk enaak layak jual juga ya moms. SELAMAT MENCOBA! 🤗😘"
categories:
- Recipe
tags:
- odading
- hulk
- aka

katakunci: odading hulk aka 
nutrition: 162 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Dinner

---


![Odading HULK aka isi Kacang Ijo](https://img-global.cpcdn.com/recipes/e168e3070c366d61/751x532cq70/odading-hulk-aka-isi-kacang-ijo-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau empuk. Ciri kuliner Indonesia odading hulk aka isi kacang ijo yang penuh dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Odading HULK aka isi Kacang Ijo untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang dapat anda buat salah satunya odading hulk aka isi kacang ijo yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep odading hulk aka isi kacang ijo tanpa harus bersusah payah.
Berikut ini resep Odading HULK aka isi Kacang Ijo yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Odading HULK aka isi Kacang Ijo:

1. Dibutuhkan 250 gr Tepung Cakra
1. Harap siapkan 1 butir telur
1. Jangan lupa 2 Sdm Mentega
1. Siapkan 1 Sachet SKM
1. Dibutuhkan 1 bks Vanilli bubuk
1. Dibutuhkan  Bahan Biang
1. Harus ada 100 ml Air Hangat
1. Jangan lupa 1 Sdt Ragi Instant
1. Tambah 2 Sdm Gula Pasir
1. Tambah  bahan pelengkap
1. Diperlukan Biji wijen putih secukupnya
1. Dibutuhkan  Minyak untuk menggoreng
1. Jangan lupa  bahan isian
1. Diperlukan 125 gr Kacang Ijo Kupas
1. Tambah 75 gr Gula
1. Harap siapkan 1 Bks Santan Kara 60ml
1. Harus ada 1 Sdt Pasta Pandan
1. Tambah  Air Secukupnya untuk merebus kacang




<!--inarticleads2-->

##### Instruksi membuat  Odading HULK aka isi Kacang Ijo:

1. Membuat biang: Campur ragi, gula pasir dan air hangat, aduk rata sampe gula larut diamkan 5-10 menit. Kalo tdk berbuih buang saja ganti yg baru.
1. Taruh di wadah, margarin, telur, skm, vanili, bahan biang dan terigu. Uleni atau Mixer hingga kalis
1. Siapkan wadah, olesi dengan minyak tipis2, simpan adonan, tutup dan diamkan selama 45 menit
1. Sementara menunggu rebus kacang ijo dengan air secukupnya sampai saat. Siapkan santan kara ditambah dengan 40ml air, aduk sampai larut. Masukkan ke dalam kacang yang sudah matang, tambahkan gula dan pandan. Masak kembali hingga santan menyusut. Jika kurang halus boleh di blender. Sisihkan
1. Setelah 45menit, timbang adonan masing2 30gr, rounding,tutup dan diamkan selama 15 menit. Pipihkan adonan lalu isi dengan isian kacang hijau.
1. Basahi wijen dengan sedikit air putih agar lembab, tempel adonan ke wijen. Agak ditekan agar menempel. Setelah selesai diamkan kembali 15 menit. Lalu goreng dengan api kecil hingga matang. - Odading HULK pun sudah siaaap.. rasanya empuuk enaak layak jual juga ya moms. SELAMAT MENCOBA! 🤗😘




Demikianlah cara membuat odading hulk aka isi kacang ijo yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
