---
description: "Bagaimana untuk membuat Roti Bantal/ Bolang Baling/Odading Empuk Renyah terupdate"
title: "Bagaimana untuk membuat Roti Bantal/ Bolang Baling/Odading Empuk Renyah terupdate"
slug: 21-bagaimana-untuk-membuat-roti-bantal-bolang-baling-odading-empuk-renyah-terupdate
date: 2021-01-28T09:20:51.738Z
image: https://img-global.cpcdn.com/recipes/a6f7ec871eab725b/751x532cq70/roti-bantal-bolang-balingodading-empuk-renyah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a6f7ec871eab725b/751x532cq70/roti-bantal-bolang-balingodading-empuk-renyah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a6f7ec871eab725b/751x532cq70/roti-bantal-bolang-balingodading-empuk-renyah-foto-resep-utama.jpg
author: Nathan McKinney
ratingvalue: 4.9
reviewcount: 39509
recipeingredient:
- "250 gr tepung terigu"
- "1 btr telur ayam utuh"
- "2 sdm margarin"
- "2 sdm Skm susu kental manis"
- "2 sdm gula pasir"
- "100 ml air hangat"
- "1 sdt ragi instan FermipanSaf"
- "1/4 sdt vanili"
- "secukupnya wijen dan gula pasir"
recipeinstructions:
- "❤ bahan biang :: Campur ragi, gula pasir dan air hangat, aduk rata sampe gula larut diamkan 5-10 menit. Kalo tdk berbuih buang saja ganti yg baru."
- "Taruh di wadah, margarin, telur, skm, vanili dan terigu."
- "Mixer/uleni manual smp tercampur rata, masukkan biang sedikit2 dan lanjut uleni smp benar2 kalis."
- "Pindahkan ke wadah yg udh dioles minyak tipis2. Diamkan smp mengembang 2xlipat (mimi 45menit)"
- "Stlh mengembang kempeskan...ambil adonan dan pipihkan setebal kurleb 2 cm, diamkan lagi 10-15 menit."
- "Potong memanjang dan potong lagi bentuk kotak, pisahkan jgn berdempetan. Adonan ini empuk sampe metat metot kalo di pegang...(artinya opo yo...😃). Sy taburi dgn sdkt tepung biar tdk lengket ketika di pegang."
- "Beri permukaan dgn air (saya pake kuas), kemudian taburi wijen&amp; gula pasir...nanti ada krenyes2 dr gulanya. Bisa semua permukaan di baluri wijen/hanya satu permukaannya saja silahkan...sy hanya 1 permukaannya sj."
- "Goreng dgn api sedang cenderung kecil sampe kuning kecoklatan kedua sisinya,sekali balik aja ya moms.. Angkat tiriskan."
- "Sajikan anget2.."
categories:
- Recipe
tags:
- roti
- bantal
- bolang

katakunci: roti bantal bolang 
nutrition: 229 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Dessert

---


![Roti Bantal/ Bolang Baling/Odading Empuk Renyah](https://img-global.cpcdn.com/recipes/a6f7ec871eab725b/751x532cq70/roti-bantal-bolang-balingodading-empuk-renyah-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga enak. Karasteristik masakan Nusantara roti bantal/ bolang baling/odading empuk renyah yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kedekatan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah memasak Roti Bantal/ Bolang Baling/Odading Empuk Renyah untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi resep yang bisa anda buat salah satunya roti bantal/ bolang baling/odading empuk renyah yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep roti bantal/ bolang baling/odading empuk renyah tanpa harus bersusah payah.
Berikut ini resep Roti Bantal/ Bolang Baling/Odading Empuk Renyah yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 9 langkah dan 9 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Bantal/ Bolang Baling/Odading Empuk Renyah:

1. Harus ada 250 gr tepung terigu
1. Harap siapkan 1 btr telur ayam utuh
1. Siapkan 2 sdm margarin
1. Jangan lupa 2 sdm Skm (susu kental manis)
1. Harus ada 2 sdm gula pasir
1. Jangan lupa 100 ml air hangat
1. Siapkan 1 sdt ragi instan (Fermipan/Saf)
1. Harap siapkan 1/4 sdt vanili
1. Dibutuhkan secukupnya wijen dan gula pasir




<!--inarticleads2-->

##### Bagaimana membuat  Roti Bantal/ Bolang Baling/Odading Empuk Renyah:

1. ❤ bahan biang :: Campur ragi, gula pasir dan air hangat, aduk rata sampe gula larut diamkan 5-10 menit. Kalo tdk berbuih buang saja ganti yg baru.
1. Taruh di wadah, margarin, telur, skm, vanili dan terigu.
1. Mixer/uleni manual smp tercampur rata, masukkan biang sedikit2 dan lanjut uleni smp benar2 kalis.
1. Pindahkan ke wadah yg udh dioles minyak tipis2. Diamkan smp mengembang 2xlipat (mimi 45menit)
1. Stlh mengembang kempeskan...ambil adonan dan pipihkan setebal kurleb 2 cm, diamkan lagi 10-15 menit.
1. Potong memanjang dan potong lagi bentuk kotak, pisahkan jgn berdempetan. Adonan ini empuk sampe metat metot kalo di pegang...(artinya opo yo...😃). Sy taburi dgn sdkt tepung biar tdk lengket ketika di pegang.
1. Beri permukaan dgn air (saya pake kuas), kemudian taburi wijen&amp; gula pasir...nanti ada krenyes2 dr gulanya. Bisa semua permukaan di baluri wijen/hanya satu permukaannya saja silahkan...sy hanya 1 permukaannya sj.
1. Goreng dgn api sedang cenderung kecil sampe kuning kecoklatan kedua sisinya,sekali balik aja ya moms.. Angkat tiriskan.
1. Sajikan anget2..




Demikianlah cara membuat roti bantal/ bolang baling/odading empuk renyah yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan cepat, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
