---
description: "Steps untuk menyiapakan Pineapple Roll with Whipped Cream Homemade"
title: "Steps untuk menyiapakan Pineapple Roll with Whipped Cream Homemade"
slug: 205-steps-untuk-menyiapakan-pineapple-roll-with-whipped-cream-homemade
date: 2021-02-03T19:20:32.975Z
image: https://img-global.cpcdn.com/recipes/a71045d1cc9f1067/751x532cq70/pineapple-roll-with-whipped-cream-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a71045d1cc9f1067/751x532cq70/pineapple-roll-with-whipped-cream-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a71045d1cc9f1067/751x532cq70/pineapple-roll-with-whipped-cream-foto-resep-utama.jpg
author: Corey Hardy
ratingvalue: 4.8
reviewcount: 27021
recipeingredient:
- "1 cangkir selai nanas"
- "5 butir telur"
- "3 sdm tepung maizena"
- "1/3 gelas tepung serba guna"
- "1/2 Gelas Gula  2 sdm"
- "1 1/2 ekstrak vanila"
- "2 sdm buttercream"
- "Sejumput garam"
- " Whipped cream untuk topping"
recipeinstructions:
- "Alasi Loyang dengan kertas roti olesi dengan margarine. Sisihkan. Pre heat oven ke 450 F"
- "Ayak tepung serba guna, tepung maizena dan garam, sisihkan"
- "Pisahkan telur. Tambahkan 1/2 gelas gula ke kuning telur dan kocok dengan mixer selama 5-7 menit sampai berubah halus dan hampir putih"
- "Tambahkan ekstrak vanila dan kocok"
- "Tambahkan campuran semua tepung dan garam ke kuning telur sedikit demi sedikit sambil di aduk perlahan-lahan"
- "Dalam mangkok terpisah kocok putih telur dan 2 sdm gula sampai mengembang"
- "Tambahkan putih telur ke dalam campuran kuning telur dan tepung lalu aduk dengan lembut sampai rata"
- "Tuang adonan ke dalam Loyang yang sudah di Siapkan dan ratakan. Oven adonan selama 5-6 menit"
- "Letakkan kertas roti di permukaan spons roti yang sudah matang lalu balikkan dari loyang. Tambahkan butter cream di atas spons ratakan. Tambahkan selai nanas di atasnya ratakan"
- "Dengan lembut tapi erat gulung spons dengan kertas roti. Biarkan dingin sepenuhnya. Bila sudah benar-benar dingin, potong sesuai selera topping dengan whipped cream. Sajikan"
categories:
- Recipe
tags:
- pineapple
- roll
- with

katakunci: pineapple roll with 
nutrition: 271 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Dessert

---


![Pineapple Roll with Whipped Cream](https://img-global.cpcdn.com/recipes/a71045d1cc9f1067/751x532cq70/pineapple-roll-with-whipped-cream-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan enak. Karasteristik masakan Indonesia pineapple roll with whipped cream yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Pineapple Roll with Whipped Cream untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang bisa anda coba salah satunya pineapple roll with whipped cream yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep pineapple roll with whipped cream tanpa harus bersusah payah.
Berikut ini resep Pineapple Roll with Whipped Cream yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 10 langkah dan 9 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Pineapple Roll with Whipped Cream:

1. Diperlukan 1 cangkir selai nanas
1. Dibutuhkan 5 butir telur
1. Dibutuhkan 3 sdm tepung maizena
1. Harus ada 1/3 gelas tepung serba guna
1. Diperlukan 1/2 Gelas Gula + 2 sdm
1. Jangan lupa 1 1/2 ekstrak vanila
1. Jangan lupa 2 sdm buttercream
1. Tambah Sejumput garam
1. Harap siapkan  Whipped cream untuk topping




<!--inarticleads2-->

##### Bagaimana membuat  Pineapple Roll with Whipped Cream:

1. Alasi Loyang dengan kertas roti olesi dengan margarine. Sisihkan. Pre heat oven ke 450 F
1. Ayak tepung serba guna, tepung maizena dan garam, sisihkan
1. Pisahkan telur. Tambahkan 1/2 gelas gula ke kuning telur dan kocok dengan mixer selama 5-7 menit sampai berubah halus dan hampir putih
1. Tambahkan ekstrak vanila dan kocok
1. Tambahkan campuran semua tepung dan garam ke kuning telur sedikit demi sedikit sambil di aduk perlahan-lahan
1. Dalam mangkok terpisah kocok putih telur dan 2 sdm gula sampai mengembang
1. Tambahkan putih telur ke dalam campuran kuning telur dan tepung lalu aduk dengan lembut sampai rata
1. Tuang adonan ke dalam Loyang yang sudah di Siapkan dan ratakan. Oven adonan selama 5-6 menit
1. Letakkan kertas roti di permukaan spons roti yang sudah matang lalu balikkan dari loyang. Tambahkan butter cream di atas spons ratakan. Tambahkan selai nanas di atasnya ratakan
1. Dengan lembut tapi erat gulung spons dengan kertas roti. Biarkan dingin sepenuhnya. Bila sudah benar-benar dingin, potong sesuai selera topping dengan whipped cream. Sajikan




Demikianlah cara membuat pineapple roll with whipped cream yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
