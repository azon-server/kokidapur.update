---
description: "Resep : Eclair Cake (tanpa whipped cream) Homemade"
title: "Resep : Eclair Cake (tanpa whipped cream) Homemade"
slug: 254-resep-eclair-cake-tanpa-whipped-cream-homemade
date: 2020-09-28T21:29:11.585Z
image: https://img-global.cpcdn.com/recipes/d32410b5a14720fa/751x532cq70/eclair-cake-tanpa-whipped-cream-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d32410b5a14720fa/751x532cq70/eclair-cake-tanpa-whipped-cream-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d32410b5a14720fa/751x532cq70/eclair-cake-tanpa-whipped-cream-foto-resep-utama.jpg
author: Nathan Allen
ratingvalue: 4.1
reviewcount: 40367
recipeingredient:
- "350 ml susu cair boleh susu UHT atau susu bubuk dicairkan"
- "100 ml Santan"
- " Chocolate compound saya pakai merk Colatta yg dark coklat"
- "3 sdm Gula pasir atau sesuai selera tapi jgn terlalu manis"
- "1 lembar Daun pandan"
- "1 bungkus Cream crackers saya pakai merk Roma"
- "4-5 sdm Tepung maizena"
- "1 sdt Vanili atau bisa diganti rhum Saya pakai rhum"
recipeinstructions:
- "Campurkan susu cair, gula pasir, vanili, dan santan. Aduk rata sampai gula larut"
- "Masak campuran susu, gula, vanili, &amp; santan, cemplungin daun pandan biar wangi sedep. Aduk terus sampai mendidih dengan api sedang cenderung kecil, agar santan tidak pecah."
- "Setelah mendidih, masukkan tepung maizena yang sudah dilarutkan dengan sedikit air, aduk hingga mengental. Teksturnya sesuaikan aja ya, jangan terlalu encer tetapi jangan terlalu kental/kaku seperti isi kue sus. Bagi yg pakai rhum, jangan lupa masukkan rhum secukupnya &amp; aduk rata. Fla rampung, kita pindah ke coklat."
- "Sambil menunggu fla dingin, lelehkan coklat. Saya pakai cara di tim. Banyaknya coklat dikira-kira saja ya. Kalau saya td pakai (kurang lebih) 3 baris coklat."
- "Setelah coklat meleleh dan fla mulai dingin, markitsun alias mari kita susun di wadah. Wadahnya lebih cakep pakai yang bening biar keliatan lapisan-lapisan cakenya."
- "Paling bawah taruh biskuit. Jumlahnya sesuaikan ukuran wadah ya, 1 lapis aja. Tuang fla, ratakan sampai biskut tersiram semua, lalu siram coklat di atas fla. Setelah itu susun biskuit lagi, lanjut fla, dan coklat. Bikin berapa lapis? Bebaaas. Sampai wadahnya penuh bolee."
- "Lapisan paling atas (lapisan coklat) boleh dikasi topping. Saya adanya regal, jadi pakai regal aja. Mau pakai almond boleh, remukan oreo boleh, polosan juga engga masyalaah. Jadi deh! Diamkan sebentar sampai suhu ruang, masukkan kulkas &amp; hidangkan dingin-dingin enaaa. Selamat mencobaa 😋"
categories:
- Recipe
tags:
- eclair
- cake
- tanpa

katakunci: eclair cake tanpa 
nutrition: 210 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Dessert

---


![Eclair Cake (tanpa whipped cream)](https://img-global.cpcdn.com/recipes/d32410b5a14720fa/751x532cq70/eclair-cake-tanpa-whipped-cream-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti eclair cake (tanpa whipped cream) yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Nusantara



Keharmonisan keluarga bisa didapat dengan cara simple. Salah satunya adalah membuat makanan Eclair Cake (tanpa whipped cream) untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang bisa anda contoh salah satunya eclair cake (tanpa whipped cream) yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep eclair cake (tanpa whipped cream) tanpa harus bersusah payah.
Berikut ini resep Eclair Cake (tanpa whipped cream) yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 8 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Eclair Cake (tanpa whipped cream):

1. Harap siapkan 350 ml susu cair (boleh susu UHT atau susu bubuk dicairkan)
1. Siapkan 100 ml Santan
1. Harap siapkan  Chocolate compound (saya pakai merk Colatta yg dark coklat)
1. Harap siapkan 3 sdm Gula pasir atau sesuai selera tapi jgn terlalu manis
1. Diperlukan 1 lembar Daun pandan
1. Tambah 1 bungkus Cream crackers (saya pakai merk Roma)
1. Diperlukan 4-5 sdm Tepung maizena
1. Tambah 1 sdt Vanili (atau bisa diganti rhum. Saya pakai rhum)




<!--inarticleads2-->

##### Langkah membuat  Eclair Cake (tanpa whipped cream):

1. Campurkan susu cair, gula pasir, vanili, dan santan. Aduk rata sampai gula larut
1. Masak campuran susu, gula, vanili, &amp; santan, cemplungin daun pandan biar wangi sedep. Aduk terus sampai mendidih dengan api sedang cenderung kecil, agar santan tidak pecah.
1. Setelah mendidih, masukkan tepung maizena yang sudah dilarutkan dengan sedikit air, aduk hingga mengental. Teksturnya sesuaikan aja ya, jangan terlalu encer tetapi jangan terlalu kental/kaku seperti isi kue sus. Bagi yg pakai rhum, jangan lupa masukkan rhum secukupnya &amp; aduk rata. Fla rampung, kita pindah ke coklat.
1. Sambil menunggu fla dingin, lelehkan coklat. Saya pakai cara di tim. Banyaknya coklat dikira-kira saja ya. Kalau saya td pakai (kurang lebih) 3 baris coklat.
1. Setelah coklat meleleh dan fla mulai dingin, markitsun alias mari kita susun di wadah. Wadahnya lebih cakep pakai yang bening biar keliatan lapisan-lapisan cakenya.
1. Paling bawah taruh biskuit. Jumlahnya sesuaikan ukuran wadah ya, 1 lapis aja. Tuang fla, ratakan sampai biskut tersiram semua, lalu siram coklat di atas fla. Setelah itu susun biskuit lagi, lanjut fla, dan coklat. Bikin berapa lapis? Bebaaas. Sampai wadahnya penuh bolee.
1. Lapisan paling atas (lapisan coklat) boleh dikasi topping. Saya adanya regal, jadi pakai regal aja. Mau pakai almond boleh, remukan oreo boleh, polosan juga engga masyalaah. Jadi deh! Diamkan sebentar sampai suhu ruang, masukkan kulkas &amp; hidangkan dingin-dingin enaaa. Selamat mencobaa 😋




Demikianlah cara membuat eclair cake (tanpa whipped cream) yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan teruji, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
