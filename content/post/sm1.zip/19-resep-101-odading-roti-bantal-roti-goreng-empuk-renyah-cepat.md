---
description: "Resep : (10.1) Odading/Roti Bantal/Roti Goreng (Empuk Renyah) Cepat"
title: "Resep : (10.1) Odading/Roti Bantal/Roti Goreng (Empuk Renyah) Cepat"
slug: 19-resep-101-odading-roti-bantal-roti-goreng-empuk-renyah-cepat
date: 2021-01-10T16:01:37.330Z
image: https://img-global.cpcdn.com/recipes/2b4e85e571da221e/751x532cq70/101-odadingroti-bantalroti-goreng-empuk-renyah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2b4e85e571da221e/751x532cq70/101-odadingroti-bantalroti-goreng-empuk-renyah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2b4e85e571da221e/751x532cq70/101-odadingroti-bantalroti-goreng-empuk-renyah-foto-resep-utama.jpg
author: Christopher Castro
ratingvalue: 4.7
reviewcount: 4977
recipeingredient:
- " Bahan A"
- "150 gr Tepung terigu cakra"
- "1 sdm Mentega"
- "1 sdm gula pasir"
- "1/4 sdt Vanili bubuk"
- "1 sdm SKM meSusu bubuk"
- "1 Butir telur ayam"
- " Bahan B bahan biang"
- "1/2 sdt Ragi instan"
- "1/2 sdt Gula pasir"
- "50 ml Air hangat"
- " Bahan C Taburan"
- "Secukupnya Biji wijen  gula pasir"
recipeinstructions:
- "Masukan semua bahan B/bahan biang dlm gelas. Tunggu hgga berbuih byk tanda ragi aktif. (Kalau tdk berbuih harap diganti)"
- "Masukan semua bahan A yaitu tepung, mentega, telur, susu bubuk, gula pasir dan vanili bubuk dalam satu wadah. Lalu tuang bahan biang sedikit demi sedikit, sambil di uleni hgga kalis elastis (Pakai mixer spiral)."
- "Jika adonan terasa msh lengket setelah cukup lama diuleni, bisa tambahkan tepung sedikit demi sedikit sambil terus diuleni hgga kalis elastis. (Saya lanjut uleni dgn tangan). Ga sampe elastis bgt kalau saya hanya sampai jika dibulatkan permukaannya mulus dan terasa lembut."
- "Bulatkan adonan, diamkan hgga mengembang 2x lipat, lamanya tergantung suhu ruang masing masing (45 menit sampai 1 jam). Selama didiamkan, diberi tutup kain serbet."
- "Setelah mengembang 2x lipat, kempeskan dgn cara ditinju, lalu uleni sebentar saja."
- "Taruh adonan diatas meja/silmat yang sudah ditaburi tepung tipis tipis. Pipihkan adonan setebal kira kira 2 cm. Olesi dgn air, lalu tabur biji wijen dan gula pasir sambil ditekan tekan agar biji wijennya melekat dgn baik. Lalu diamkan kembali sekitar 15 menit."
- "Panaskan minyak goreng secukupnya, pakai api kecil. Potong potong adonan sesuai selera. Lalu goreng hgga kedua sisi matang/kecoklatan (dgn api kecil saja)."
- "Angkat, tiriskan. Siap dihidangkan bersama segelas kopi atau teh kesukaan masing masing. Teksturnya empuk didalam, renyah diluar!"
categories:
- Recipe
tags:
- 101
- odadingroti
- bantalroti

katakunci: 101 odadingroti bantalroti 
nutrition: 272 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT39M"
recipeyield: "1"
recipecategory: Dinner

---


![(10.1) Odading/Roti Bantal/Roti Goreng (Empuk Renyah)](https://img-global.cpcdn.com/recipes/2b4e85e571da221e/751x532cq70/101-odadingroti-bantalroti-goreng-empuk-renyah-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga renyah. Ciri masakan Indonesia (10.1) odading/roti bantal/roti goreng (empuk renyah) yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan (10.1) Odading/Roti Bantal/Roti Goreng (Empuk Renyah) untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang bisa anda contoh salah satunya (10.1) odading/roti bantal/roti goreng (empuk renyah) yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep (10.1) odading/roti bantal/roti goreng (empuk renyah) tanpa harus bersusah payah.
Berikut ini resep (10.1) Odading/Roti Bantal/Roti Goreng (Empuk Renyah) yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 13 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat (10.1) Odading/Roti Bantal/Roti Goreng (Empuk Renyah):

1. Dibutuhkan  Bahan A:
1. Dibutuhkan 150 gr Tepung terigu (cakra)
1. Jangan lupa 1 sdm Mentega
1. Diperlukan 1 sdm gula pasir
1. Tambah 1/4 sdt Vanili bubuk
1. Diperlukan 1 sdm SKM (me:Susu bubuk)
1. Dibutuhkan 1 Butir telur ayam
1. Jangan lupa  Bahan B (bahan biang):
1. Harap siapkan 1/2 sdt Ragi instan
1. Jangan lupa 1/2 sdt Gula pasir
1. Diperlukan 50 ml Air hangat
1. Siapkan  Bahan C (Taburan):
1. Diperlukan Secukupnya Biji wijen + gula pasir




<!--inarticleads2-->

##### Cara membuat  (10.1) Odading/Roti Bantal/Roti Goreng (Empuk Renyah):

1. Masukan semua bahan B/bahan biang dlm gelas. Tunggu hgga berbuih byk tanda ragi aktif. (Kalau tdk berbuih harap diganti)
1. Masukan semua bahan A yaitu tepung, mentega, telur, susu bubuk, gula pasir dan vanili bubuk dalam satu wadah. Lalu tuang bahan biang sedikit demi sedikit, sambil di uleni hgga kalis elastis (Pakai mixer spiral).
1. Jika adonan terasa msh lengket setelah cukup lama diuleni, bisa tambahkan tepung sedikit demi sedikit sambil terus diuleni hgga kalis elastis. (Saya lanjut uleni dgn tangan). Ga sampe elastis bgt kalau saya hanya sampai jika dibulatkan permukaannya mulus dan terasa lembut.
1. Bulatkan adonan, diamkan hgga mengembang 2x lipat, lamanya tergantung suhu ruang masing masing (45 menit sampai 1 jam). Selama didiamkan, diberi tutup kain serbet.
1. Setelah mengembang 2x lipat, kempeskan dgn cara ditinju, lalu uleni sebentar saja.
1. Taruh adonan diatas meja/silmat yang sudah ditaburi tepung tipis tipis. Pipihkan adonan setebal kira kira 2 cm. Olesi dgn air, lalu tabur biji wijen dan gula pasir sambil ditekan tekan agar biji wijennya melekat dgn baik. Lalu diamkan kembali sekitar 15 menit.
1. Panaskan minyak goreng secukupnya, pakai api kecil. Potong potong adonan sesuai selera. Lalu goreng hgga kedua sisi matang/kecoklatan (dgn api kecil saja).
1. Angkat, tiriskan. Siap dihidangkan bersama segelas kopi atau teh kesukaan masing masing. Teksturnya empuk didalam, renyah diluar!




Demikianlah cara membuat (10.1) odading/roti bantal/roti goreng (empuk renyah) yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan cepat, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
