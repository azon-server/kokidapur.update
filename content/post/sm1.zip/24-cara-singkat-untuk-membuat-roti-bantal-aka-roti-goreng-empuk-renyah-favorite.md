---
description: "Cara singkat untuk membuat Roti Bantal a.k.a Roti Goreng Empuk Renyah 🤩 Favorite"
title: "Cara singkat untuk membuat Roti Bantal a.k.a Roti Goreng Empuk Renyah 🤩 Favorite"
slug: 24-cara-singkat-untuk-membuat-roti-bantal-aka-roti-goreng-empuk-renyah-favorite
date: 2020-09-23T23:39:24.200Z
image: https://img-global.cpcdn.com/recipes/b3b1c5463eccdd2a/751x532cq70/roti-bantal-aka-roti-goreng-empuk-renyah-🤩-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b3b1c5463eccdd2a/751x532cq70/roti-bantal-aka-roti-goreng-empuk-renyah-🤩-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b3b1c5463eccdd2a/751x532cq70/roti-bantal-aka-roti-goreng-empuk-renyah-🤩-foto-resep-utama.jpg
author: Fannie Burns
ratingvalue: 4.3
reviewcount: 30151
recipeingredient:
- "125-150 gr tepung terigu"
- "1 butir telur ayam"
- "1 sdm margarin"
- "1 sdm skmme  susu bubuk"
- "1 sdm gula pasir"
- "50 ml air hangat"
- "1/2 sdt ragi instanme  saf"
- "1/4 sdt vanilli"
- "Secukupnya wijen dan gula pasir"
recipeinstructions:
- "Bikin biang dulu...dengan cara campur ragi,gula pasir dan air hangat..aduk rata diamkan 5-10 menit hingga berbuih...(kalau tidak berbuih buang saja dan ganti yang baru)"
- "Dalam wadah,masukkan tepung terigu,telur,margarin,susu bubuk dan vanilli..."
- "Lalu tuang bahan biang sedikit demi sedikit..uleni hingga kalis dan elastis...(bisa pakai mixer dengan pengaduk yang spiral)"
- "Diamkan dan tutup dengan kain/plastik selama 45menit-1 jam hingga mengembang 2x lipat"
- "Setelah mengembang lalu kempeskan dan ulen sebentar saja"
- "Setelah itu ambil adonan dan pipihkan setebal 2cm..lalu oles permukaan adonan dengan air,beri taburan wijen dan taburan gula sambil di tekan&#34; dikit ya ciinnn(ini tujuannya agar waktu di goreng wijen gak banyak yang rontok tertinggal di minyak)...diamkan lagi selama 15 menit"
- "Panaskan minyak...lalu kecilkan api..."
- "Sebelum menggoreng...potong&#34; adonan sesuai selera..lalu goreng hingga kecoklatan #dengan api kecil ya ciiinn"
- "Setelah matang angkat tiriskan dan sajikan"
- "🤩🤩🤩😍"
categories:
- Recipe
tags:
- roti
- bantal
- aka

katakunci: roti bantal aka 
nutrition: 159 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dessert

---


![Roti Bantal a.k.a Roti Goreng Empuk Renyah 🤩](https://img-global.cpcdn.com/recipes/b3b1c5463eccdd2a/751x532cq70/roti-bantal-aka-roti-goreng-empuk-renyah-🤩-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti roti bantal a.k.a roti goreng empuk renyah 🤩 yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa ciri khas yang merupakan keragaman Nusantara

Keharmonisan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Roti Bantal a.k.a Roti Goreng Empuk Renyah 🤩 untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang bisa anda contoh salah satunya roti bantal a.k.a roti goreng empuk renyah 🤩 yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep roti bantal a.k.a roti goreng empuk renyah 🤩 tanpa harus bersusah payah.
Berikut ini resep Roti Bantal a.k.a Roti Goreng Empuk Renyah 🤩 yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 10 langkah dan 9 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Bantal a.k.a Roti Goreng Empuk Renyah 🤩:

1. Dibutuhkan 125-150 gr tepung terigu
1. Siapkan 1 butir telur ayam
1. Diperlukan 1 sdm margarin
1. Harap siapkan 1 sdm skm(me : susu bubuk)
1. Dibutuhkan 1 sdm gula pasir
1. Jangan lupa 50 ml air hangat
1. Harap siapkan 1/2 sdt ragi instan(me : saf)
1. Siapkan 1/4 sdt vanilli
1. Dibutuhkan Secukupnya wijen dan gula pasir




<!--inarticleads2-->

##### Bagaimana membuat  Roti Bantal a.k.a Roti Goreng Empuk Renyah 🤩:

1. Bikin biang dulu...dengan cara campur ragi,gula pasir dan air hangat..aduk rata diamkan 5-10 menit hingga berbuih...(kalau tidak berbuih buang saja dan ganti yang baru)
1. Dalam wadah,masukkan tepung terigu,telur,margarin,susu bubuk dan vanilli...
1. Lalu tuang bahan biang sedikit demi sedikit..uleni hingga kalis dan elastis...(bisa pakai mixer dengan pengaduk yang spiral)
1. Diamkan dan tutup dengan kain/plastik selama 45menit-1 jam hingga mengembang 2x lipat
1. Setelah mengembang lalu kempeskan dan ulen sebentar saja
1. Setelah itu ambil adonan dan pipihkan setebal 2cm..lalu oles permukaan adonan dengan air,beri taburan wijen dan taburan gula sambil di tekan&#34; dikit ya ciinnn(ini tujuannya agar waktu di goreng wijen gak banyak yang rontok tertinggal di minyak)...diamkan lagi selama 15 menit
1. Panaskan minyak...lalu kecilkan api...
1. Sebelum menggoreng...potong&#34; adonan sesuai selera..lalu goreng hingga kecoklatan #dengan api kecil ya ciiinn
1. Setelah matang angkat tiriskan dan sajikan
1. 🤩🤩🤩😍




Demikianlah cara membuat roti bantal a.k.a roti goreng empuk renyah 🤩 yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
