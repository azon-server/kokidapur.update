---
description: "Resep : Bolang baling/Kue Bantal/Odading (empuk, tanpa telur) Cepat"
title: "Resep : Bolang baling/Kue Bantal/Odading (empuk, tanpa telur) Cepat"
slug: 41-resep-bolang-baling-kue-bantal-odading-empuk-tanpa-telur-cepat
date: 2020-08-21T04:34:39.037Z
image: https://img-global.cpcdn.com/recipes/62bc17b223888a35/751x532cq70/bolang-balingkue-bantalodading-empuk-tanpa-telur-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/62bc17b223888a35/751x532cq70/bolang-balingkue-bantalodading-empuk-tanpa-telur-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/62bc17b223888a35/751x532cq70/bolang-balingkue-bantalodading-empuk-tanpa-telur-foto-resep-utama.jpg
author: Augusta Rodriquez
ratingvalue: 4.9
reviewcount: 3684
recipeingredient:
- "250 gr terigu protein tinggi cakra kembar"
- "50 gr terigu protein sedang segitiga biru"
- "100 gr gula pasir halus"
- "1.5 sdt ragi sy fermipan"
- "1 sdt soda kue"
- "150 ml air putih biasa"
- "40 gr margarin"
- "Secukupnya wijen"
- "Secukupnya minyak untuk menggoreng"
recipeinstructions:
- "Campur jd satu, tepung terigu, gula pasir halus, ragi, soda kue, aduk rata.. Tuang air sedikit2 uleni sampai setengah Kalis pakai tangan.. Setelah setengah Kalis masukan margarin uleni lagi sampai kalis pake mixer (ga kalis2 banget juga gpp, uleni smpe bisa d tarik aja)"
- "Bulatkan adonan,"
- "Diamkan d wadah yg sudah d taburi sedikit tepung.. Diamkan sama 50-1 jam trgantung suhu tempat masing2 dngan d tutup plastik.. (Sy td 50 menit)"
- "Setelah mengembang 2x lipat.. Tinju adonan supaya udara keluar, kmudian uleni lg sebentar."
- "Gilas adonan dgn rollin ketebalan 1 atau 1.5 cm.."
- "Potong2 pakai pisau besar nya sesuaikan selera ya.."
- "Kemudian olesi dgn air dan taburi wijen sedikit tekan2 supaya wijen nempel.. Tata d loyang.."
- "Tutup lagi dgn plastik, diamkan lagi 10 menit.."
- "Panaskan minyak.. goreng bolang baling sampe kekuningan.."
- "Note* 1. Tips saat menggoreng.. *Minyak jangan trlalu panas nanti cepet gosong *Goreng nya pakai api kecil aja *jangan d bolak balik, sekali balik aja *saat masukan bolang baling ke wajan"
- "Nyummy"
- "Lembuut"
- "Empuuuk 😍"
categories:
- Recipe
tags:
- bolang
- balingkue
- bantalodading

katakunci: bolang balingkue bantalodading 
nutrition: 186 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dessert

---


![Bolang baling/Kue Bantal/Odading (empuk, tanpa telur)](https://img-global.cpcdn.com/recipes/62bc17b223888a35/751x532cq70/bolang-balingkue-bantalodading-empuk-tanpa-telur-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau enak. Ciri makanan Nusantara bolang baling/kue bantal/odading (empuk, tanpa telur) yang penuh dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga bisa didapat dengan cara sederhana. Salah satunya adalah memasak Bolang baling/Kue Bantal/Odading (empuk, tanpa telur) untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang dapat anda coba salah satunya bolang baling/kue bantal/odading (empuk, tanpa telur) yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep bolang baling/kue bantal/odading (empuk, tanpa telur) tanpa harus bersusah payah.
Seperti resep Bolang baling/Kue Bantal/Odading (empuk, tanpa telur) yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 9 bahan dan 13 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Bolang baling/Kue Bantal/Odading (empuk, tanpa telur):

1. Tambah 250 gr terigu protein tinggi (cakra kembar)
1. Jangan lupa 50 gr terigu protein sedang (segitiga biru)
1. Dibutuhkan 100 gr gula pasir halus
1. Siapkan 1.5 sdt ragi (sy fermipan)
1. Tambah 1 sdt soda kue
1. Harap siapkan 150 ml air putih biasa
1. Harus ada 40 gr margarin
1. Harap siapkan Secukupnya wijen
1. Jangan lupa Secukupnya minyak untuk menggoreng




<!--inarticleads2-->

##### Bagaimana membuat  Bolang baling/Kue Bantal/Odading (empuk, tanpa telur):

1. Campur jd satu, tepung terigu, gula pasir halus, ragi, soda kue, aduk rata.. Tuang air sedikit2 uleni sampai setengah Kalis pakai tangan.. Setelah setengah Kalis masukan margarin uleni lagi sampai kalis pake mixer (ga kalis2 banget juga gpp, uleni smpe bisa d tarik aja)
1. Bulatkan adonan,
1. Diamkan d wadah yg sudah d taburi sedikit tepung.. Diamkan sama 50-1 jam trgantung suhu tempat masing2 dngan d tutup plastik.. (Sy td 50 menit)
1. Setelah mengembang 2x lipat.. Tinju adonan supaya udara keluar, kmudian uleni lg sebentar.
1. Gilas adonan dgn rollin ketebalan 1 atau 1.5 cm..
1. Potong2 pakai pisau besar nya sesuaikan selera ya..
1. Kemudian olesi dgn air dan taburi wijen sedikit tekan2 supaya wijen nempel.. Tata d loyang..
1. Tutup lagi dgn plastik, diamkan lagi 10 menit..
1. Panaskan minyak.. goreng bolang baling sampe kekuningan..
1. Note* - 1. Tips saat menggoreng.. - *Minyak jangan trlalu panas nanti cepet gosong - *Goreng nya pakai api kecil aja - *jangan d bolak balik, sekali balik aja - *saat masukan bolang baling ke wajan
1. Nyummy
1. Lembuut
1. Empuuuk 😍




Demikianlah cara membuat bolang baling/kue bantal/odading (empuk, tanpa telur) yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
