---
description: "Cara singkat untuk membuat Roti Bantal/Bolang Baling Empuk Cepat"
title: "Cara singkat untuk membuat Roti Bantal/Bolang Baling Empuk Cepat"
slug: 17-cara-singkat-untuk-membuat-roti-bantal-bolang-baling-empuk-cepat
date: 2020-11-27T17:59:34.628Z
image: https://img-global.cpcdn.com/recipes/f1f5ab14b91ef172/751x532cq70/roti-bantalbolang-baling-empuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f1f5ab14b91ef172/751x532cq70/roti-bantalbolang-baling-empuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f1f5ab14b91ef172/751x532cq70/roti-bantalbolang-baling-empuk-foto-resep-utama.jpg
author: Jeremy Harper
ratingvalue: 4.3
reviewcount: 40642
recipeingredient:
- "250 g terigu"
- "1 btr telur"
- "2 sdm margarin"
- "2 sdm skm"
- "2 sdm gula pasir"
- "100 ml air hangat"
- "1 sdt ragi instant"
- "1/4 sdt vanili"
- "secukupnya wijen dan gula pasir"
recipeinstructions:
- "Bahan biang: campur ragi,gula pasir dan air hangat,aduk rata sampai gula larut diamkan 5-10menit"
- "Taruh di wadah margarin,telor,skm,vanili dan terigu"
- "Mixer/uleni manual sampai rata,masukkan biang sedikit2 dan lanjut uleni sampai kalis"
- "Pindah ke wadah yg udh dioles minyak tipis2 diamkan sampai mengembang 2x lipat kurleb 30 menit (tergantung suhu udara ditempat masing2 ya moms)"
- "Setelah mengembang kempiskan adonan lalu pipihkan kurleb 2cm,potong2 memanjang dan potong lagi kotak2,setelah dipotong pisahkan diamkan 10-15 menit beri taburan"
- "Olesi adonan dgn air lalu tabur gula dan wijen,goreng dgn api sedang cenderung kecil,sekali balik aja ya,selamat mencoba ya moms😍"
categories:
- Recipe
tags:
- roti
- bantalbolang
- baling

katakunci: roti bantalbolang baling 
nutrition: 228 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dinner

---


![Roti Bantal/Bolang Baling Empuk](https://img-global.cpcdn.com/recipes/f1f5ab14b91ef172/751x532cq70/roti-bantalbolang-baling-empuk-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti roti bantal/bolang baling empuk yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia



Kedekatan rumah tangga bisa didapat dengan cara simple. Diantaranya adalah memasak Roti Bantal/Bolang Baling Empuk untuk keluarga. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang bisa anda coba salah satunya roti bantal/bolang baling empuk yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep roti bantal/bolang baling empuk tanpa harus bersusah payah.
Berikut ini resep Roti Bantal/Bolang Baling Empuk yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 9 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Bantal/Bolang Baling Empuk:

1. Diperlukan 250 g terigu
1. Diperlukan 1 btr telur
1. Harus ada 2 sdm margarin
1. Harap siapkan 2 sdm skm
1. Diperlukan 2 sdm gula pasir
1. Tambah 100 ml air hangat
1. Harap siapkan 1 sdt ragi instant
1. Siapkan 1/4 sdt vanili
1. Siapkan secukupnya wijen dan gula pasir




<!--inarticleads2-->

##### Langkah membuat  Roti Bantal/Bolang Baling Empuk:

1. Bahan biang: campur ragi,gula pasir dan air hangat,aduk rata sampai gula larut diamkan 5-10menit
1. Taruh di wadah margarin,telor,skm,vanili dan terigu
1. Mixer/uleni manual sampai rata,masukkan biang sedikit2 dan lanjut uleni sampai kalis
1. Pindah ke wadah yg udh dioles minyak tipis2 diamkan sampai mengembang 2x lipat kurleb 30 menit (tergantung suhu udara ditempat masing2 ya moms)
1. Setelah mengembang kempiskan adonan lalu pipihkan kurleb 2cm,potong2 memanjang dan potong lagi kotak2,setelah dipotong pisahkan diamkan 10-15 menit beri taburan
1. Olesi adonan dgn air lalu tabur gula dan wijen,goreng dgn api sedang cenderung kecil,sekali balik aja ya,selamat mencoba ya moms😍




Demikianlah cara membuat roti bantal/bolang baling empuk yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat mudah dan terbukti, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
