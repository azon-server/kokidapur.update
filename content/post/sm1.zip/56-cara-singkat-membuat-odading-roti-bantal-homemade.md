---
description: "Cara singkat membuat Odading/roti bantal Homemade"
title: "Cara singkat membuat Odading/roti bantal Homemade"
slug: 56-cara-singkat-membuat-odading-roti-bantal-homemade
date: 2020-09-09T20:25:49.308Z
image: https://img-global.cpcdn.com/recipes/af7c90d75fc46001/751x532cq70/odadingroti-bantal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/af7c90d75fc46001/751x532cq70/odadingroti-bantal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/af7c90d75fc46001/751x532cq70/odadingroti-bantal-foto-resep-utama.jpg
author: Lloyd Schwartz
ratingvalue: 4.4
reviewcount: 49378
recipeingredient:
- "250 gr tepung terigu pro tinggi"
- "70 grm gula pasir"
- "1 sdm susu bubuk"
- "1 butir telur"
- "1 1/2 sdt ragi instan"
- "1/2 sdt baking powder"
- "90 ml air"
- "30 grm margarine"
- "1/4 sdt garam"
- "secukupnya Wijen"
- " Minyak sayur untuk menggoreng"
- " Topping  glaze coklat glaze keju crispy ball"
recipeinstructions:
- "Campurkan terigu, gula pasir, ragi, susu bubuk aduk rata. Buat lubang ditengah tambahkan air dan telur aduk/uleni sampai tidak menempel di wadah."
- "Masukkan margarine dan garam uleni hingga setengah Kalis saja"
- "Tutup dengan kain bersih diamkan 45 menit. Kempeskan adonan keluarkan gelembungnya, taruh diatas wadah datar. Pipihkan bentuk kotak. Potong-potong menjadi kotak kecil/sesuai selera. Taruh diatas alas yang sudah ditaburi tepung terigu."
- "Diamkan kembali 20 menit. Siapkan minyak dengan api kecil goreng odading hanya 1x balik ya.  Untuk yang menggunakan wijen, olesi bagian atas adonan dengan air lalu taburi wijen tekan-tekan sedikit. Goreng odading sampai kecoklatan. Beri toping sesuai selera."
- "Sajikan hangat-hangat sambil minum kopi atau teh. Rasa Kue odading ini enak dan lembut didalam kres diluar."
categories:
- Recipe
tags:
- odadingroti
- bantal

katakunci: odadingroti bantal 
nutrition: 241 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dessert

---


![Odading/roti bantal](https://img-global.cpcdn.com/recipes/af7c90d75fc46001/751x532cq70/odadingroti-bantal-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan enak. Karasteristik masakan Nusantara odading/roti bantal yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kali ini aku sharing resep toti goreng simple ala aku. Resep Odading Mang Oleh Virall !! - odading mang oleh. Campur tepung, gula, ragi, telur jadi satu. Aduk dengan tangan hingga tercampur rata, bergerindil.

Kehangatan keluarga dapat didapat dengan cara simple. Diantaranya adalah memasak Odading/roti bantal untuk keluarga. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang bisa anda contoh salah satunya odading/roti bantal yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep odading/roti bantal tanpa harus bersusah payah.
Berikut ini resep Odading/roti bantal yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Odading/roti bantal:

1. Jangan lupa 250 gr tepung terigu pro tinggi
1. Dibutuhkan 70 grm gula pasir
1. Tambah 1 sdm susu bubuk
1. Dibutuhkan 1 butir telur
1. Dibutuhkan 1 1/2 sdt ragi instan
1. Dibutuhkan 1/2 sdt baking powder
1. Jangan lupa 90 ml air
1. Dibutuhkan 30 grm margarine
1. Siapkan 1/4 sdt garam
1. Siapkan secukupnya Wijen
1. Siapkan  Minyak sayur untuk menggoreng
1. Dibutuhkan  Topping : glaze coklat, glaze keju, crispy ball


Selain disebut roti goreng, odading juga memiliki nama sebutan lainnya, yaitu roti bantal. Berhasil berhasil #rotigoreng #rotibantal #rotigorengjadul https Aku udah tua baru tau roti bantal itu disebut roti odading! https. Resep Roti Goreng Odading Kue Bantal Simple Enak. Resep Kue Odading Bantal Khas Bandung Sederhana Lembut dan Empuk Spesial Asli Enak. 

<!--inarticleads2-->

##### Langkah membuat  Odading/roti bantal:

1. Campurkan terigu, gula pasir, ragi, susu bubuk aduk rata. Buat lubang ditengah tambahkan air dan telur aduk/uleni sampai tidak menempel di wadah.
1. Masukkan margarine dan garam uleni hingga setengah Kalis saja
1. Tutup dengan kain bersih diamkan 45 menit. Kempeskan adonan keluarkan gelembungnya, taruh diatas wadah datar. Pipihkan bentuk kotak. Potong-potong menjadi kotak kecil/sesuai selera. Taruh diatas alas yang sudah ditaburi tepung terigu.
1. Diamkan kembali 20 menit. Siapkan minyak dengan api kecil goreng odading hanya 1x balik ya.  - Untuk yang menggunakan wijen, olesi bagian atas adonan dengan air lalu taburi wijen tekan-tekan sedikit. Goreng odading sampai kecoklatan. Beri toping sesuai selera.
1. Sajikan hangat-hangat sambil minum kopi atau teh. - Rasa Kue odading ini enak dan lembut didalam kres diluar.


Resep Roti Goreng Odading Kue Bantal Simple Enak. Resep Kue Odading Bantal Khas Bandung Sederhana Lembut dan Empuk Spesial Asli Enak. Odading juga bisa dibuat dengan aneka kreasi tanpa telur sama halnya dengan roti. Kue Tradisional Odading Viral di Media Sosial Berkat Marketing &#34;nyeleneh&#34; dari Odading Mang Belum lama ini, kue tradisional Odading viral di media sosial berkat marketing &#34;nyeleneh&#34; dari. Odading adalah kue/roti goreng khas Bandung yang memiliki tekstur seperti Cakwe. 

Demikianlah cara membuat odading/roti bantal yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
