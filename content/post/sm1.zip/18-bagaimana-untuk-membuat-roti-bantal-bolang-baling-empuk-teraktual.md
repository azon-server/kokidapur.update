---
description: "Bagaimana untuk membuat Roti Bantal/Bolang Baling (empuk) teraktual"
title: "Bagaimana untuk membuat Roti Bantal/Bolang Baling (empuk) teraktual"
slug: 18-bagaimana-untuk-membuat-roti-bantal-bolang-baling-empuk-teraktual
date: 2020-10-24T23:00:37.684Z
image: https://img-global.cpcdn.com/recipes/a34a462bf0cee923/751x532cq70/roti-bantalbolang-baling-empuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a34a462bf0cee923/751x532cq70/roti-bantalbolang-baling-empuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a34a462bf0cee923/751x532cq70/roti-bantalbolang-baling-empuk-foto-resep-utama.jpg
author: Jackson Reese
ratingvalue: 4.3
reviewcount: 7177
recipeingredient:
- "250 gr tepung terigu"
- "1 btr telur ayam utuh"
- "2 sdm margarin"
- "2 sdm Skm susu kental manis"
- "2 sdm gula pasir"
- "100 ml air hangat"
- "1 sdt ragi instan FermipanSaf"
- "1/4 sdt vanili"
- "secukupnya wijen dan gula pasir"
recipeinstructions:
- "Bahan biang : Campur ragi, gula pasir dan air hangat, aduk rata sampe gula larut diamkan 5-10 menit."
- "Taruh di wadah, margarin, telur, skm, vanili dan terigu."
- "Mixer/uleni manual smp tercampur rata, masukkan biang sedikit2 dan lanjut uleni smp benar2 kalis."
- "Pindahkan ke wadah yg udh dioles minyak tipis2. Diamkan smp mengembang 2xlipat. Saya sekitar 30 menit. Karna cuaca lagi panas banget."
- "Setelah mengembang kempiskan.ambil adonan dan pipihkan setebal kurleb 2 cm,Potong memanjang dan potong lagi bentuk kotak."
- "Setelah dipotong, pisahkan jgn berdempetan. Diamkan 10-15 menit.Adonan ini empuk sekali. Beri taburan sedikit tepung agar tidak lengket ketika di pegang."
- "Beri permukaan dgn air (saya pake kuas), kemudian taburi wijen&amp; gula pasir. Ada sensasi krenyes dr gula. Bisa semua permukaan di baluri wijen/hanya satu permukaan saja."
- "Goreng dgn api sedang cenderung kecil sampe kuning kecoklatan kedua sisinya,sekali balik aja ya bund."
- "Sajikan untuk teman ngopi atau ngeteh."
categories:
- Recipe
tags:
- roti
- bantalbolang
- baling

katakunci: roti bantalbolang baling 
nutrition: 141 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT35M"
recipeyield: "2"
recipecategory: Dessert

---


![Roti Bantal/Bolang Baling (empuk)](https://img-global.cpcdn.com/recipes/a34a462bf0cee923/751x532cq70/roti-bantalbolang-baling-empuk-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang dapat kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti roti bantal/bolang baling (empuk) yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa ciri khas yang merupakan keragaman Nusantara



Kehangatan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah memasak Roti Bantal/Bolang Baling (empuk) untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang bisa anda buat salah satunya roti bantal/bolang baling (empuk) yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep roti bantal/bolang baling (empuk) tanpa harus bersusah payah.
Seperti resep Roti Bantal/Bolang Baling (empuk) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 9 langkah dan 9 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Bantal/Bolang Baling (empuk):

1. Harus ada 250 gr tepung terigu
1. Diperlukan 1 btr telur ayam utuh
1. Harus ada 2 sdm margarin
1. Diperlukan 2 sdm Skm (susu kental manis)
1. Siapkan 2 sdm gula pasir
1. Dibutuhkan 100 ml air hangat
1. Harus ada 1 sdt ragi instan (Fermipan/Saf)
1. Harus ada 1/4 sdt vanili
1. Siapkan secukupnya wijen dan gula pasir




<!--inarticleads2-->

##### Bagaimana membuat  Roti Bantal/Bolang Baling (empuk):

1. Bahan biang : Campur ragi, gula pasir dan air hangat, aduk rata sampe gula larut diamkan 5-10 menit.
1. Taruh di wadah, margarin, telur, skm, vanili dan terigu.
1. Mixer/uleni manual smp tercampur rata, masukkan biang sedikit2 dan lanjut uleni smp benar2 kalis.
1. Pindahkan ke wadah yg udh dioles minyak tipis2. Diamkan smp mengembang 2xlipat. Saya sekitar 30 menit. Karna cuaca lagi panas banget.
1. Setelah mengembang kempiskan.ambil adonan dan pipihkan setebal kurleb 2 cm,Potong memanjang dan potong lagi bentuk kotak.
1. Setelah dipotong, pisahkan jgn berdempetan. Diamkan 10-15 menit.Adonan ini empuk sekali. Beri taburan sedikit tepung agar tidak lengket ketika di pegang.
1. Beri permukaan dgn air (saya pake kuas), kemudian taburi wijen&amp; gula pasir. Ada sensasi krenyes dr gula. Bisa semua permukaan di baluri wijen/hanya satu permukaan saja.
1. Goreng dgn api sedang cenderung kecil sampe kuning kecoklatan kedua sisinya,sekali balik aja ya bund.
1. Sajikan untuk teman ngopi atau ngeteh.




Demikianlah cara membuat roti bantal/bolang baling (empuk) yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan terbukti, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
