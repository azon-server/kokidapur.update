---
description: "Panduan membuat Buko Pandan Whipcream Homemade"
title: "Panduan membuat Buko Pandan Whipcream Homemade"
slug: 113-panduan-membuat-buko-pandan-whipcream-homemade
date: 2020-10-20T00:06:46.158Z
image: https://img-global.cpcdn.com/recipes/e494fb4a5dccdba8/751x532cq70/buko-pandan-whipcream-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e494fb4a5dccdba8/751x532cq70/buko-pandan-whipcream-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e494fb4a5dccdba8/751x532cq70/buko-pandan-whipcream-foto-resep-utama.jpg
author: Caroline Tucker
ratingvalue: 5
reviewcount: 26783
recipeingredient:
- "500 gram nata de coco"
- "1 sachet agar agar swallow plain tanpa rasa"
- "1 sachet nutrijell kelapa"
- "1 buah kelapa muda"
- "50 gram whipcream  100ml air dingin"
- "2 kaleng susu evaporasi"
- "1/2 kaleng susu kental manis"
- "200 gram gula pasir bagi 2"
- "10 lembar daun pandan"
- "6 gelas belimbing air putih"
recipeinstructions:
- "Siapkan bahan, kita buat agar agar pandan terlebih dahulu. cuci bersih daun pandan, kemudian blender dengan 1 gelas air. setelah halus, saring daun pandan dan buang ampasnya. masukkan air daun pandan ke dalam panci, tambahkan 2 gelas air, agar agar plain, dan gula pasir. aduk aduk selama memasak agar tidak menggumpal hingga mendidih. lalu tuang ke dalam cetakan dan dinginkan."
- "Selanjutnya kita buat nutrijell kelapa. masukkan 3 gelas air ke dalam panci, lalu disusul gula, dan nutrijel kelapa. aduk aduk hingga mendidih, lalu tuang ke dalam cetakan dan dinginkan."
- "Setelah kedua jelly tadi set, siapkan wadah, potong2 dadu kedua jelly tersebut. lalu tuang ke dalam wadah. campurkan kelapa muda, nata de coco, whipcream, susu evaporasi dan susu kental manis. aduk hingga semua tercampur rata. lalu masukkan ke dalam kulkas. setelah 10-20 menit, keluarkan dan siap di hidangkan. selamat mencoba!!"
categories:
- Recipe
tags:
- buko
- pandan
- whipcream

katakunci: buko pandan whipcream 
nutrition: 271 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Dessert

---


![Buko Pandan Whipcream](https://img-global.cpcdn.com/recipes/e494fb4a5dccdba8/751x532cq70/buko-pandan-whipcream-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang patut kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti buko pandan whipcream yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan ciri khas yang merupakan keragaman Indonesia

Keharmonisan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Buko Pandan Whipcream untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang dapat anda praktekkan salah satunya buko pandan whipcream yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep buko pandan whipcream tanpa harus bersusah payah.
Berikut ini resep Buko Pandan Whipcream yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Buko Pandan Whipcream:

1. Harus ada 500 gram nata de coco
1. Jangan lupa 1 sachet agar agar swallow plain (tanpa rasa)
1. Harus ada 1 sachet nutrijell kelapa
1. Diperlukan 1 buah kelapa muda
1. Siapkan 50 gram whipcream + 100ml air dingin
1. Harap siapkan 2 kaleng susu evaporasi
1. Diperlukan 1/2 kaleng susu kental manis
1. Harus ada 200 gram gula pasir (bagi 2)
1. Harus ada 10 lembar daun pandan
1. Siapkan 6 gelas belimbing air putih




<!--inarticleads2-->

##### Bagaimana membuat  Buko Pandan Whipcream:

1. Siapkan bahan, kita buat agar agar pandan terlebih dahulu. cuci bersih daun pandan, kemudian blender dengan 1 gelas air. setelah halus, saring daun pandan dan buang ampasnya. masukkan air daun pandan ke dalam panci, tambahkan 2 gelas air, agar agar plain, dan gula pasir. aduk aduk selama memasak agar tidak menggumpal hingga mendidih. lalu tuang ke dalam cetakan dan dinginkan.
1. Selanjutnya kita buat nutrijell kelapa. masukkan 3 gelas air ke dalam panci, lalu disusul gula, dan nutrijel kelapa. aduk aduk hingga mendidih, lalu tuang ke dalam cetakan dan dinginkan.
1. Setelah kedua jelly tadi set, siapkan wadah, potong2 dadu kedua jelly tersebut. lalu tuang ke dalam wadah. campurkan kelapa muda, nata de coco, whipcream, susu evaporasi dan susu kental manis. aduk hingga semua tercampur rata. lalu masukkan ke dalam kulkas. setelah 10-20 menit, keluarkan dan siap di hidangkan. selamat mencoba!!




Demikianlah cara membuat buko pandan whipcream yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
