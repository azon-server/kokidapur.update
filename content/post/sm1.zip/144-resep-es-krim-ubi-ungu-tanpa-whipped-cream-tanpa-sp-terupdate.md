---
description: "Resep : Es krim ubi ungu (Tanpa whipped cream tanpa SP) terupdate"
title: "Resep : Es krim ubi ungu (Tanpa whipped cream tanpa SP) terupdate"
slug: 144-resep-es-krim-ubi-ungu-tanpa-whipped-cream-tanpa-sp-terupdate
date: 2021-01-30T04:36:23.054Z
image: https://img-global.cpcdn.com/recipes/f8803b9f2111d1b7/751x532cq70/es-krim-ubi-ungu-tanpa-whipped-cream-tanpa-sp-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f8803b9f2111d1b7/751x532cq70/es-krim-ubi-ungu-tanpa-whipped-cream-tanpa-sp-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f8803b9f2111d1b7/751x532cq70/es-krim-ubi-ungu-tanpa-whipped-cream-tanpa-sp-foto-resep-utama.jpg
author: Isabel Pope
ratingvalue: 4.4
reviewcount: 35123
recipeingredient:
- "300 gr ubi ungu resep asli 250gr"
- "400 ml susu full cream"
- "100 ml air putih"
- "40 gr gula pasir"
- "60 gr SKM"
- "1 sachet santan bubuk"
- "1/2 sdt garam"
- " Topping"
- " Nata de coco"
- " Springkel"
recipeinstructions:
- "Cuci bersih dan sikat kulit ubi. Kukus selama 25 menit (kulit ubi dikupas setelah dikukus. Agar warna ubi tetap terang). Setelah dikukus dinginkan baru kupas ubi. Siapkan blender masukkan ubi, susu,air, gula, SKM,santan bubuk,garam blender hingga halus."
- "Masukkan bahan es ke dalam frezzer sekitar 3-4 jam. Setelah itu mixer kembali hingga kristal es hancur dan tekstur lembut. Masukkan kembali kedalam frezzer selama 1 jam. Setelah 1 jam mixer kembali (ulangi langkah ini 3-4 x sampai kelembutan yang diinginkan,saya 3x mixer)"
- "Setalah masuk freezer 1 jam, kerok es krim ubi. Tambahkan topping sesuai selera (saya nata de coco dan springkel). Es krim ini lembut banget...wajib coba."
categories:
- Recipe
tags:
- es
- krim
- ubi

katakunci: es krim ubi 
nutrition: 293 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dessert

---


![Es krim ubi ungu (Tanpa whipped cream tanpa SP)](https://img-global.cpcdn.com/recipes/f8803b9f2111d1b7/751x532cq70/es-krim-ubi-ungu-tanpa-whipped-cream-tanpa-sp-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga enak. Ciri khas kuliner Indonesia es krim ubi ungu (tanpa whipped cream tanpa sp) yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Halo semuanya, hari ini aku akan membuat es krim dengan ubi ungu. Pembuatan Es Krim Ubi Ungu ini menggunakan bahan dasar susu sapi segar dengan penambahan Ubi Ungu. Pertama-tama kukus ubi sampai matang dan empuk. Lalu blender dengan SKM dan air dingin sampai halus.

Kehangatan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah memasak Es krim ubi ungu (Tanpa whipped cream tanpa SP) untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang bisa anda praktekkan salah satunya es krim ubi ungu (tanpa whipped cream tanpa sp) yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep es krim ubi ungu (tanpa whipped cream tanpa sp) tanpa harus bersusah payah.
Seperti resep Es krim ubi ungu (Tanpa whipped cream tanpa SP) yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Es krim ubi ungu (Tanpa whipped cream tanpa SP):

1. Tambah 300 gr ubi ungu (resep asli 250gr)
1. Dibutuhkan 400 ml susu full cream
1. Tambah 100 ml air putih
1. Harus ada 40 gr gula pasir
1. Siapkan 60 gr SKM
1. Siapkan 1 sachet santan bubuk
1. Harap siapkan 1/2 sdt garam
1. Diperlukan  Topping
1. Harus ada  Nata de coco
1. Harus ada  Springkel


Resep Kue Mangkuk Ubi Ungu yang Lembut dan Mekar, Wajib Coba! Cara Membuat Es Krim Ubi Ungu - Selain nikmat, es cream ini sangat menarik dengan warnanya yang ungu alami. Nah bunda bagaimana cara membuat embuat Es Krim Stik Ubi Ungu Sehat Sederhana dengan mudah dan dapat dipraktekkan sendiri mari kita simak Resep Minuman Segar. Buah adalah salah satu makanan yang mempunyai nilai gizi yang cukup banyak contohnya vitamin yang baik bagi kesehatan tubuh. 

<!--inarticleads2-->

##### Langkah membuat  Es krim ubi ungu (Tanpa whipped cream tanpa SP):

1. Cuci bersih dan sikat kulit ubi. Kukus selama 25 menit (kulit ubi dikupas setelah dikukus. Agar warna ubi tetap terang). Setelah dikukus dinginkan baru kupas ubi. Siapkan blender masukkan ubi, susu,air, gula, SKM,santan bubuk,garam blender hingga halus.
1. Masukkan bahan es ke dalam frezzer sekitar 3-4 jam. Setelah itu mixer kembali hingga kristal es hancur dan tekstur lembut. Masukkan kembali kedalam frezzer selama 1 jam. Setelah 1 jam mixer kembali (ulangi langkah ini 3-4 x sampai kelembutan yang diinginkan,saya 3x mixer)
1. Setalah masuk freezer 1 jam, kerok es krim ubi. Tambahkan topping sesuai selera (saya nata de coco dan springkel). Es krim ini lembut banget...wajib coba.


Nah bunda bagaimana cara membuat embuat Es Krim Stik Ubi Ungu Sehat Sederhana dengan mudah dan dapat dipraktekkan sendiri mari kita simak Resep Minuman Segar. Buah adalah salah satu makanan yang mempunyai nilai gizi yang cukup banyak contohnya vitamin yang baik bagi kesehatan tubuh. Es krim buah sangat diminati karena nilai gizinya tidak jauh beda dengan buah aslinya. Sebenarnya buah mau dimakan secara langsung atau diolahan. Yuk intip resep es krim tanpa ribet di bawah ini. 

Demikianlah cara membuat es krim ubi ungu (tanpa whipped cream tanpa sp) yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan terbukti, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
