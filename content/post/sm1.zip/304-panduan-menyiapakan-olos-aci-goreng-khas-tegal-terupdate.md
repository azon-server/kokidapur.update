---
description: "Panduan menyiapakan Olos (Aci Goreng Khas Tegal) terupdate"
title: "Panduan menyiapakan Olos (Aci Goreng Khas Tegal) terupdate"
slug: 304-panduan-menyiapakan-olos-aci-goreng-khas-tegal-terupdate
date: 2021-02-09T09:54:47.339Z
image: https://img-global.cpcdn.com/recipes/f518186056e5b281/751x532cq70/olos-aci-goreng-khas-tegal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f518186056e5b281/751x532cq70/olos-aci-goreng-khas-tegal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f518186056e5b281/751x532cq70/olos-aci-goreng-khas-tegal-foto-resep-utama.jpg
author: Ian Williams
ratingvalue: 4.2
reviewcount: 13374
recipeingredient:
- " Bahan Adonan "
- "300 gram tepung kanjitapioka"
- "100 gram tepung terigu"
- "1 sdt kaldu bubuk"
- "Secukupnya garam dan lada bubuk"
- "300 ml air panas"
- " Bahan Isian "
- "200 gram kol rajang tipis"
- "2 batang daun bawang iris"
- "4 butir bawang merah cincang"
- "2 siung bawang putih cincang"
- "8 buah cabe rawit iris"
- "Secukupnya garam merica dan kaldu bubuk"
- "Secukupnya minyak untuk menumis dan menggoreng"
recipeinstructions:
- "Buat isiannya dulu, panaskan sedikit minyak. Tumis duo bawang dan cabe hingga harum dan matang."
- "Masukkan kol dan daun bawang."
- "Bumbui garam, merica bubuk dan kaldu bubuk."
- "Aduk rata. Masak sampai sayur matang. Sisihkan, biarkan dingin."
- "Buat adonannya. Masukkan tepung terigu, tepung tapioka, garam, merica bubuk dan kaldu bubuk"
- "Aduk rata. Ayak jika perlu."
- "Tuang air panas sambil diaduk"
- "Setelah air dituang semua, aduk rata dengan spatula, lalu uleni sebentar dg tangan yg dibungkus sarung tangan plastik. Adonan tidak sampai kalis, masih agak lengket, tapi tidak lembek."
- "Lumuri telapak tangan dengan tepung tipis2. Ambil sedikit adonan, beri isian."
- "Setelah diisi, bulatkan. Lakukan sampai habis."
- "Taruh minyak agak banyak dalam wajan, nyalakan api, saat minyak belum panas masukkan bulatan2 tadi secukupnya, kira2 setengah menit setelah api menyala."
- "Goreng sambil agak diaduk2. Goreng sampai matang. Angkat, tiriskan. Bisa langsung disantap atau bisa diberi bumbu tabur sesuai selera."
categories:
- Recipe
tags:
- olos
- aci
- goreng

katakunci: olos aci goreng 
nutrition: 164 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Lunch

---


![Olos (Aci Goreng Khas Tegal)](https://img-global.cpcdn.com/recipes/f518186056e5b281/751x532cq70/olos-aci-goreng-khas-tegal-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang setidaknya kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti olos (aci goreng khas tegal) yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan ciri khas yang merupakan keragaman Indonesia



Kehangatan rumah tangga dapat ditemukan dengan cara mudah. Salah satunya adalah memasak Olos (Aci Goreng Khas Tegal) untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang dapat anda praktekkan salah satunya olos (aci goreng khas tegal) yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep olos (aci goreng khas tegal) tanpa harus bersusah payah.
Berikut ini resep Olos (Aci Goreng Khas Tegal) yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 12 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Olos (Aci Goreng Khas Tegal):

1. Harus ada  Bahan Adonan :
1. Harap siapkan 300 gram tepung kanji/tapioka
1. Diperlukan 100 gram tepung terigu
1. Jangan lupa 1 sdt kaldu bubuk
1. Harap siapkan Secukupnya garam dan lada bubuk
1. Tambah 300 ml air panas
1. Harap siapkan  Bahan Isian :
1. Siapkan 200 gram kol, rajang tipis
1. Diperlukan 2 batang daun bawang, iris
1. Jangan lupa 4 butir bawang merah, cincang
1. Diperlukan 2 siung bawang putih, cincang
1. Dibutuhkan 8 buah cabe rawit, iris
1. Jangan lupa Secukupnya garam, merica dan kaldu bubuk
1. Diperlukan Secukupnya minyak untuk menumis dan menggoreng




<!--inarticleads2-->

##### Cara membuat  Olos (Aci Goreng Khas Tegal):

1. Buat isiannya dulu, panaskan sedikit minyak. Tumis duo bawang dan cabe hingga harum dan matang.
1. Masukkan kol dan daun bawang.
1. Bumbui garam, merica bubuk dan kaldu bubuk.
1. Aduk rata. Masak sampai sayur matang. Sisihkan, biarkan dingin.
1. Buat adonannya. Masukkan tepung terigu, tepung tapioka, garam, merica bubuk dan kaldu bubuk
1. Aduk rata. Ayak jika perlu.
1. Tuang air panas sambil diaduk
1. Setelah air dituang semua, aduk rata dengan spatula, lalu uleni sebentar dg tangan yg dibungkus sarung tangan plastik. Adonan tidak sampai kalis, masih agak lengket, tapi tidak lembek.
1. Lumuri telapak tangan dengan tepung tipis2. Ambil sedikit adonan, beri isian.
1. Setelah diisi, bulatkan. Lakukan sampai habis.
1. Taruh minyak agak banyak dalam wajan, nyalakan api, saat minyak belum panas masukkan bulatan2 tadi secukupnya, kira2 setengah menit setelah api menyala.
1. Goreng sambil agak diaduk2. Goreng sampai matang. Angkat, tiriskan. Bisa langsung disantap atau bisa diberi bumbu tabur sesuai selera.




Demikianlah cara membuat olos (aci goreng khas tegal) yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
