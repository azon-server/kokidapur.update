---
description: "Steps untuk membuat Odading (kue bantal) *toping ala abang-abang Homemade"
title: "Steps untuk membuat Odading (kue bantal) *toping ala abang-abang Homemade"
slug: 45-steps-untuk-membuat-odading-kue-bantal-toping-ala-abang-abang-homemade
date: 2021-02-09T02:13:11.749Z
image: https://img-global.cpcdn.com/recipes/478ba9b3cbfbd155/751x532cq70/odading-kue-bantal-toping-ala-abang-abang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/478ba9b3cbfbd155/751x532cq70/odading-kue-bantal-toping-ala-abang-abang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/478ba9b3cbfbd155/751x532cq70/odading-kue-bantal-toping-ala-abang-abang-foto-resep-utama.jpg
author: Milton Doyle
ratingvalue: 4.5
reviewcount: 1526
recipeingredient:
- "150 gr tepung segitiga biru"
- "100 gr tepung cakra"
- "50 gr gula pasir"
- "1 butir telur"
- "1 sdt ragi instan"
- "100 ml air hangat kuku"
- "30 gr mentegamargarine lebih lembut pakai mentega"
- "1/4 sdt garam"
- " Bahan toping nya "
- "3 sdm gula pasir"
- "1 sdt brown sugar boleh skip kalo palai lebih legit"
- "2 sdm tepung segitiga biru"
- " Air secukupnya sampai jadi pasta"
- " Wijen putih"
recipeinstructions:
- "Aktifkan ragi : masukan ragi instan +1sdt gula (gula dari takaran yg sudah ada) aduk rata biarkan 5-7menit sampai berbuih"
- "Campur semua bahan kecuali mentega dan garam, lalu uleni hingga kalis"
- "Setelah kalis masukkan mentega dan garam, lalu uleni lagi hingga kalis elastis"
- "Bulatkan adonan, tutup serbet/clingwarp selama 30 menit atau sampai mengembang 2x lipat"
- "Sambil menunggu adonan mengembang buat toping nya dulu ya"
- "Caranya campur semua bahan jadi 1, aduk2 sampai jadi pasta, dan rata, kasih airnya sedikit2 aja ya.. lalu sisihkan"
- "Setelah adonan mengembang lalu gilas adonan dan pipihkan, bisa diberi tepung sedikit agar tidak lengket ya"
- "Lalu potong2 sesuai selera, setelah dipotong2 beri jarak agar tidak menempel 1 sama lain"
- "Beri toping merata di atasnya lalu taburi dengan wijen putih,"
- "Diamkan 15-20 menit, lalu goreng di minyak yg sudah panas, pastikan goreng dengan minyak yg banyak agar matang dan mengembang sempurna, goreng dengan 1x balik agar tidak banyak menyerap minyak, maaf ya ini videonya malah pake filter jd warna nya agak buram 🙈"
- "Note : gorengnya posisi toping tetap di atas awalnya ya, nt kalo bagian bawah sudah mulai berwarna coklat baru dibalik sampai topingnya juga berwarna coklat, biar topingnya ga beleber dan jd agak krispi manis gitu kayak di abang2 jual tapi menurutku lebih enak ini😁"
categories:
- Recipe
tags:
- odading
- kue
- bantal

katakunci: odading kue bantal 
nutrition: 158 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Dessert

---


![Odading (kue bantal) *toping ala abang-abang](https://img-global.cpcdn.com/recipes/478ba9b3cbfbd155/751x532cq70/odading-kue-bantal-toping-ala-abang-abang-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga enak. Ciri makanan Nusantara odading (kue bantal) *toping ala abang-abang yang kaya dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Odading (kue bantal) *toping ala abang-abang untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang dapat anda praktekkan salah satunya odading (kue bantal) *toping ala abang-abang yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep odading (kue bantal) *toping ala abang-abang tanpa harus bersusah payah.
Seperti resep Odading (kue bantal) *toping ala abang-abang yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 14 bahan dan 11 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Odading (kue bantal) *toping ala abang-abang:

1. Diperlukan 150 gr tepung segitiga biru
1. Dibutuhkan 100 gr tepung cakra
1. Siapkan 50 gr gula pasir
1. Siapkan 1 butir telur
1. Jangan lupa 1 sdt ragi instan
1. Tambah 100 ml air hangat kuku
1. Jangan lupa 30 gr mentega/margarine (lebih lembut pakai mentega)
1. Harus ada 1/4 sdt garam
1. Siapkan  Bahan toping nya :
1. Siapkan 3 sdm gula pasir
1. Siapkan 1 sdt brown sugar (boleh skip, kalo palai lebih legit)
1. Jangan lupa 2 sdm tepung segitiga biru
1. Dibutuhkan  Air secukupnya sampai jadi pasta
1. Siapkan  Wijen putih




<!--inarticleads2-->

##### Cara membuat  Odading (kue bantal) *toping ala abang-abang:

1. Aktifkan ragi : masukan ragi instan +1sdt gula (gula dari takaran yg sudah ada) aduk rata biarkan 5-7menit sampai berbuih
1. Campur semua bahan kecuali mentega dan garam, lalu uleni hingga kalis
1. Setelah kalis masukkan mentega dan garam, lalu uleni lagi hingga kalis elastis
1. Bulatkan adonan, tutup serbet/clingwarp selama 30 menit atau sampai mengembang 2x lipat
1. Sambil menunggu adonan mengembang buat toping nya dulu ya
1. Caranya campur semua bahan jadi 1, aduk2 sampai jadi pasta, dan rata, kasih airnya sedikit2 aja ya.. lalu sisihkan
1. Setelah adonan mengembang lalu gilas adonan dan pipihkan, bisa diberi tepung sedikit agar tidak lengket ya
1. Lalu potong2 sesuai selera, setelah dipotong2 beri jarak agar tidak menempel 1 sama lain
1. Beri toping merata di atasnya lalu taburi dengan wijen putih,
1. Diamkan 15-20 menit, lalu goreng di minyak yg sudah panas, pastikan goreng dengan minyak yg banyak agar matang dan mengembang sempurna, goreng dengan 1x balik agar tidak banyak menyerap minyak, maaf ya ini videonya malah pake filter jd warna nya agak buram 🙈
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Odading (kue bantal) *toping ala abang-abang">1. Note : gorengnya posisi toping tetap di atas awalnya ya, nt kalo bagian bawah sudah mulai berwarna coklat baru dibalik sampai topingnya juga berwarna coklat, biar topingnya ga beleber dan jd agak krispi manis gitu kayak di abang2 jual tapi menurutku lebih enak ini😁




Demikianlah cara membuat odading (kue bantal) *toping ala abang-abang yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
