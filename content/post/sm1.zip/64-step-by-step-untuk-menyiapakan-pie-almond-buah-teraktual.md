---
description: "Step-by-Step untuk menyiapakan Pie Almond Buah teraktual"
title: "Step-by-Step untuk menyiapakan Pie Almond Buah teraktual"
slug: 64-step-by-step-untuk-menyiapakan-pie-almond-buah-teraktual
date: 2021-02-19T05:25:21.943Z
image: https://img-global.cpcdn.com/recipes/66e564d6b9140666/751x532cq70/pie-almond-buah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/66e564d6b9140666/751x532cq70/pie-almond-buah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/66e564d6b9140666/751x532cq70/pie-almond-buah-foto-resep-utama.jpg
author: Logan Watts
ratingvalue: 4.1
reviewcount: 46737
recipeingredient:
- " Bahan Kulit Pie"
- "150 gr mentega Blueband"
- "75 gr gula halus ayak"
- "310 gr tepung terigu segitiga ayak"
- "2 sdm susu bubuk Dancow"
- "2 butir kuning telur"
- "1/4 sdt garam"
- " Custard Filling saya buat 12 bahan"
- "50 ml susu cair"
- "2 butir kuning telur"
- "35 gr gula castor"
- "35 gr tepung maizena"
- "200 ml susu cair"
- "1 sdt pasta vanilla"
- "35 gr gula castor"
- "15 gr butter  mentega dingin"
- "100 ml whipped cream"
- " Topping"
- "2 sdm kacang almond slices"
- "Secukupnya strawberry"
- "Secukupnya kiwi"
- "Secukupnya anggur"
- " Resep custard filling           lihat resep"
recipeinstructions:
- "Siapkan semua bahan kulit. Campur kuning telur, gula, mentega dan garam hingga mengembang dan tercampur rata. Ini saya mixer.. diresep asli hanya menggunakan garpu untuk mencampur"
- "Tambahkan terigu dan susu sedikit demi sedikit sambil diayak, campur hingga kalis dan tidak menempel di wadah. Lalu bungkus dengan plastik wrap. Masukkan ke dalam kulkas selama 30 menit."
- "Selama menunggu adonan masuk kulkas, kita olesi loyang dengan mentega"
- "Membuat Custard Filling: untuk membuat custard silahkan lihat resep layered strawberry tart (no bake)           (lihat resep)"
- "Setelah 30 menit keluarkan adonan, masukkan secukupnya adonan ke dalam loyang pie, tekan-tekan dengan jari dan ratakan ke seluruh bagian dalam loyang. Setelah selesai semua, tusuk-tusuk dasar kulit pienya dengan garpu atau tusuk sate"
- "Masukkan ke dalam oven yang sudah dipanaskan terlebih dahulu, dan panggang dengan suhu 150 derajat selama 30 menit. Atau sampai kulit pie matang"
- "Setelah matang keluarkan kulit pie, isi dengan custard filling dan taburi dengan almond slices"
- "Panggang lagi sekitar 20 menit, siapkan buah- buahan yang akan dijadikan topping"
- "Setelah 20 menit keluarkan pie dan beri topping. Pie Almond Buah siap disajikan."
categories:
- Recipe
tags:
- pie
- almond
- buah

katakunci: pie almond buah 
nutrition: 214 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Lunch

---


![Pie Almond Buah](https://img-global.cpcdn.com/recipes/66e564d6b9140666/751x532cq70/pie-almond-buah-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang setidaknya kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti pie almond buah yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Indonesia



Kedekatan keluarga bisa didapat dengan cara mudah. Diantaranya adalah memasak Pie Almond Buah untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang dapat anda praktekkan salah satunya pie almond buah yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep pie almond buah tanpa harus bersusah payah.
Berikut ini resep Pie Almond Buah yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 23 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Pie Almond Buah:

1. Harus ada  Bahan Kulit Pie
1. Tambah 150 gr mentega Blueband
1. Tambah 75 gr gula halus, ayak
1. Diperlukan 310 gr tepung terigu (segitiga), ayak
1. Harus ada 2 sdm susu bubuk (Dancow)
1. Siapkan 2 butir kuning telur
1. Dibutuhkan 1/4 sdt garam
1. Siapkan  Custard Filling (saya buat 1/2 bahan)
1. Harus ada 50 ml susu cair
1. Jangan lupa 2 butir kuning telur
1. Siapkan 35 gr gula castor
1. Diperlukan 35 gr tepung maizena
1. Jangan lupa 200 ml susu cair
1. Siapkan 1 sdt pasta vanilla
1. Jangan lupa 35 gr gula castor
1. Dibutuhkan 15 gr butter / mentega dingin
1. Dibutuhkan 100 ml whipped cream
1. Diperlukan  Topping
1. Jangan lupa 2 sdm kacang almond slices
1. Harus ada Secukupnya strawberry
1. Dibutuhkan Secukupnya kiwi
1. Harus ada Secukupnya anggur
1. Siapkan  Resep custard filling           (lihat resep)




<!--inarticleads2-->

##### Langkah membuat  Pie Almond Buah:

1. Siapkan semua bahan kulit. Campur kuning telur, gula, mentega dan garam hingga mengembang dan tercampur rata. Ini saya mixer.. diresep asli hanya menggunakan garpu untuk mencampur
1. Tambahkan terigu dan susu sedikit demi sedikit sambil diayak, campur hingga kalis dan tidak menempel di wadah. Lalu bungkus dengan plastik wrap. Masukkan ke dalam kulkas selama 30 menit.
1. Selama menunggu adonan masuk kulkas, kita olesi loyang dengan mentega
1. Membuat Custard Filling: untuk membuat custard silahkan lihat resep layered strawberry tart (no bake) -           (lihat resep)
1. Setelah 30 menit keluarkan adonan, masukkan secukupnya adonan ke dalam loyang pie, tekan-tekan dengan jari dan ratakan ke seluruh bagian dalam loyang. Setelah selesai semua, tusuk-tusuk dasar kulit pienya dengan garpu atau tusuk sate
1. Masukkan ke dalam oven yang sudah dipanaskan terlebih dahulu, dan panggang dengan suhu 150 derajat selama 30 menit. Atau sampai kulit pie matang
1. Setelah matang keluarkan kulit pie, isi dengan custard filling dan taburi dengan almond slices
1. Panggang lagi sekitar 20 menit, siapkan buah- buahan yang akan dijadikan topping
1. Setelah 20 menit keluarkan pie dan beri topping. Pie Almond Buah siap disajikan.




Demikianlah cara membuat pie almond buah yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan cepat, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
