---
description: "Resep : Puding Whipcream Taro Teruji"
title: "Resep : Puding Whipcream Taro Teruji"
slug: 175-resep-puding-whipcream-taro-teruji
date: 2020-10-15T23:38:20.579Z
image: https://img-global.cpcdn.com/recipes/b8f535c76491732a/751x532cq70/puding-whipcream-taro-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b8f535c76491732a/751x532cq70/puding-whipcream-taro-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b8f535c76491732a/751x532cq70/puding-whipcream-taro-foto-resep-utama.jpg
author: Mike Wood
ratingvalue: 4.5
reviewcount: 21834
recipeingredient:
- "1 bks nutrijell plain"
- "50 ml whipcream kental"
- "600 ml susu cair"
- "125 gr gula pasir"
- " Pewarna Ungu"
- "1,5 sdm taro powder"
recipeinstructions:
- "Rebus Susu, Gula, jelly plain, dan whipcream, bubuk taro. Aduk hingga rata, tidak ada yang menggumpal. Masak hingga mendidih"
- "Saya bagi jadi 2 lapisan ya bu. Lapis pertama beri 2 tetes pewarna ungu. Ambil 3 sendok sayur dan masukkan ke dalam cetakan. Tunggu hingga permukaan atas berkerak dan bisa ditimpa utk lapisan berikutnya."
- "Setelah membentuk lapisan. Tambahkan lagi 3 tetes pewarna ungu. Jika adonan membeku, hangatkan dulu ya bu. Kemudian jika sudah mencair smua, tuang perlahan sbg lapisan k2."
- "Tunggu hingga uap panas hilang, dan dinginkan di kulkas. Setelah menunggu dingin, siap disantap... yumm yumm yumm... nambah deh satu resep favorit puding. Bisa ganti rasa lain juga ya buibu... selamat mencoba"
categories:
- Recipe
tags:
- puding
- whipcream
- taro

katakunci: puding whipcream taro 
nutrition: 220 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dinner

---


![Puding Whipcream Taro](https://img-global.cpcdn.com/recipes/b8f535c76491732a/751x532cq70/puding-whipcream-taro-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti puding whipcream taro yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Kita



Kehangatan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Puding Whipcream Taro untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang bisa anda buat salah satunya puding whipcream taro yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep puding whipcream taro tanpa harus bersusah payah.
Seperti resep Puding Whipcream Taro yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Puding Whipcream Taro:

1. Tambah 1 bks nutrijell plain
1. Diperlukan 50 ml whipcream kental
1. Jangan lupa 600 ml susu cair
1. Harap siapkan 125 gr gula pasir
1. Jangan lupa  Pewarna Ungu
1. Dibutuhkan 1,5 sdm taro powder




<!--inarticleads2-->

##### Langkah membuat  Puding Whipcream Taro:

1. Rebus Susu, Gula, jelly plain, dan whipcream, bubuk taro. Aduk hingga rata, tidak ada yang menggumpal. Masak hingga mendidih
1. Saya bagi jadi 2 lapisan ya bu. Lapis pertama beri 2 tetes pewarna ungu. Ambil 3 sendok sayur dan masukkan ke dalam cetakan. Tunggu hingga permukaan atas berkerak dan bisa ditimpa utk lapisan berikutnya.
1. Setelah membentuk lapisan. Tambahkan lagi 3 tetes pewarna ungu. Jika adonan membeku, hangatkan dulu ya bu. Kemudian jika sudah mencair smua, tuang perlahan sbg lapisan k2.
1. Tunggu hingga uap panas hilang, dan dinginkan di kulkas. Setelah menunggu dingin, siap disantap... yumm yumm yumm... nambah deh satu resep favorit puding. Bisa ganti rasa lain juga ya buibu... selamat mencoba




Demikianlah cara membuat puding whipcream taro yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan terbukti, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
