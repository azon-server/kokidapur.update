---
description: "Panduan menyiapakan Basic Soft Bun (with whipcream) Favorite"
title: "Panduan menyiapakan Basic Soft Bun (with whipcream) Favorite"
slug: 142-panduan-menyiapakan-basic-soft-bun-with-whipcream-favorite
date: 2020-10-26T08:52:16.585Z
image: https://img-global.cpcdn.com/recipes/b0002ff72e62ce80/751x532cq70/basic-soft-bun-with-whipcream-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b0002ff72e62ce80/751x532cq70/basic-soft-bun-with-whipcream-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b0002ff72e62ce80/751x532cq70/basic-soft-bun-with-whipcream-foto-resep-utama.jpg
author: Cora Miller
ratingvalue: 4
reviewcount: 17049
recipeingredient:
- " Bahan A"
- "300 gr tepung protein tinggi cakra"
- "3 gr ragi saya diaktifkandahulu"
- "30 gr gula pasir"
- " Bahan B"
- "1 butir telur ambil 25 gr sisanya untuk olesan sblm dipanggang"
- " Bahan C"
- "30 gr butter"
- "3 gr garam"
- " Bahan D mixer"
- "55 gram whipcream asal 10gr susu di A dan 50 ml susu di B"
- "135 gr air asal di bahan B"
- " Filling optional"
- " Sosis selai coklat pisang selai keju susu cinnamon"
recipeinstructions:
- "Siapkan semua bahan, campur bahan A dalam satu wadah dan bahan D yg sudah di mix. Raginya saya aktifkan dulu karena tdk pede kalau langsung cemplung (maaf ya chef)"
- "Gabung semua bahan A,B dan D dan mix sampai tercampur rata dan pinggirannya sudah tidak ada yg menempel kemudian masukan bahan C"
- "Mixer kembali sampai adonan kalis (cek dengan cara window pane) ambil sedikit adonan, bulatkan dan tarik"
- "Istirahatkan adonan"
- "Cek adonan dg cara tusuk dg jari, jika tidak kembali, maka adonan siap di bentuk"
- "Kempiskan adonan untuk mengeluarkan udaranya.. dan bagi adonan menjadi sama besar (saya timbang per 50 gr)kemudian bulatkan"
- "Bentuk dan isi dengan filling sesuai keinginan (saya pakai, pisang, selai coklat, selai keju susu, dan sosis)"
- "Jangan lupa oles dengan sisa telur di bahan B kemudian panggang di oven yg sudah panas"
- "Panggang sekitar 15 menit dengan suhu 180° oles dengan margarin sesaat setelah diangkat supaya roti cantik dan mengkilat"
- "Cantik dan lembut banget... yg tidur sampai terbangun dan tak sabar menunggu dingin🥰"
categories:
- Recipe
tags:
- basic
- soft
- bun

katakunci: basic soft bun 
nutrition: 233 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Dessert

---


![Basic Soft Bun (with whipcream)](https://img-global.cpcdn.com/recipes/b0002ff72e62ce80/751x532cq70/basic-soft-bun-with-whipcream-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga renyah. Karasteristik makanan Nusantara basic soft bun (with whipcream) yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga dapat ditemukan dengan cara simple. Salah satunya adalah memasak Basic Soft Bun (with whipcream) untuk keluarga. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian masakan yang dapat anda praktekkan salah satunya basic soft bun (with whipcream) yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep basic soft bun (with whipcream) tanpa harus bersusah payah.
Berikut ini resep Basic Soft Bun (with whipcream) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 14 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Basic Soft Bun (with whipcream):

1. Jangan lupa  Bahan A
1. Harus ada 300 gr tepung protein tinggi (cakra)
1. Harus ada 3 gr ragi (saya diaktifkan.dahulu)
1. Harap siapkan 30 gr gula pasir
1. Harap siapkan  Bahan B
1. Siapkan 1 butir telur (ambil 25 gr, sisanya untuk olesan sblm dipanggang
1. Tambah  Bahan C
1. Tambah 30 gr butter
1. Dibutuhkan 3 gr garam
1. Jangan lupa  Bahan D (mixer)
1. Diperlukan 55 gram whipcream (asal 10gr susu di A dan 50 ml susu di B)
1. Jangan lupa 135 gr air (asal di bahan B)
1. Harus ada  Filling (optional)
1. Dibutuhkan  Sosis, selai coklat, pisang, selai keju susu, cinnamon




<!--inarticleads2-->

##### Langkah membuat  Basic Soft Bun (with whipcream):

1. Siapkan semua bahan, campur bahan A dalam satu wadah dan bahan D yg sudah di mix. Raginya saya aktifkan dulu karena tdk pede kalau langsung cemplung (maaf ya chef)
1. Gabung semua bahan A,B dan D dan mix sampai tercampur rata dan pinggirannya sudah tidak ada yg menempel kemudian masukan bahan C
1. Mixer kembali sampai adonan kalis (cek dengan cara window pane) ambil sedikit adonan, bulatkan dan tarik
1. Istirahatkan adonan
1. Cek adonan dg cara tusuk dg jari, jika tidak kembali, maka adonan siap di bentuk
1. Kempiskan adonan untuk mengeluarkan udaranya.. dan bagi adonan menjadi sama besar (saya timbang per 50 gr)kemudian bulatkan
1. Bentuk dan isi dengan filling sesuai keinginan (saya pakai, pisang, selai coklat, selai keju susu, dan sosis)
1. Jangan lupa oles dengan sisa telur di bahan B kemudian panggang di oven yg sudah panas
1. Panggang sekitar 15 menit dengan suhu 180° oles dengan margarin sesaat setelah diangkat supaya roti cantik dan mengkilat
1. Cantik dan lembut banget... yg tidur sampai terbangun dan tak sabar menunggu dingin🥰




Demikianlah cara membuat basic soft bun (with whipcream) yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
