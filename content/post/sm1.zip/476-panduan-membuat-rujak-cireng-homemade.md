---
description: "Panduan membuat Rujak Cireng Homemade"
title: "Panduan membuat Rujak Cireng Homemade"
slug: 476-panduan-membuat-rujak-cireng-homemade
date: 2020-10-05T14:38:26.692Z
image: https://img-global.cpcdn.com/recipes/2541032_a74a801683c3efe5/751x532cq70/rujak-cireng-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2541032_a74a801683c3efe5/751x532cq70/rujak-cireng-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2541032_a74a801683c3efe5/751x532cq70/rujak-cireng-foto-resep-utama.jpg
author: Lily Holland
ratingvalue: 4
reviewcount: 25505
recipeingredient:
- "250 gram tepung kanji"
- "200 ml air"
- "4 siung bawang putih haluskan"
- "2 batang daun bawang iris tipis"
- "1 1/4 sdt garam"
- "1 sdm kaldu bubuk"
- "3 buah cabe merah besar"
- "3 buah cabe rawit"
- "50 gr gula merah"
- "1 sdt garam"
- "2 sdm air asam jawa"
- "secukupnya minyak untuk menggoreng"
recipeinstructions:
- "Campurkan tepung kanji dengan irisan daun bawang"
- "rebus air,bawang putih halus,garam 1 1/4 sdt dan kaldu bubuk"
- "masukkan air bumbu panas-panas ke dalam tepung,aduk rata,adonan akan lengket"
- "panaskan minyak,ambil 1 sendok makan adonan lalu goreng,tidak usah menggoreng terlalu lama,pastikan cireng sudah krispi dan matang"
- "haluskan cabai merah besar,cabai rawit,garam. setelah halus tambahkan gula jawa dan air asam jawa."
- "sajikan cireng hangat dengan sambalnya, bisa disiramkan,bisa dicocol :)"
categories:
- Recipe
tags:
- rujak
- cireng

katakunci: rujak cireng 
nutrition: 143 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Dinner

---


![Rujak Cireng](https://img-global.cpcdn.com/recipes/2541032_a74a801683c3efe5/751x532cq70/rujak-cireng-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga gurih. Karasteristik masakan Indonesia rujak cireng yang penuh dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga bisa didapat dengan cara sederhana. Salah satunya adalah memasak Rujak Cireng untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang bisa anda praktekkan salah satunya rujak cireng yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep rujak cireng tanpa harus bersusah payah.
Seperti resep Rujak Cireng yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 12 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Rujak Cireng:

1. Harap siapkan 250 gram tepung kanji
1. Tambah 200 ml air
1. Harus ada 4 siung bawang putih, haluskan
1. Siapkan 2 batang daun bawang, iris tipis
1. Harus ada 1 1/4 sdt garam
1. Diperlukan 1 sdm kaldu bubuk
1. Harap siapkan 3 buah cabe merah besar
1. Diperlukan 3 buah cabe rawit
1. Harus ada 50 gr gula merah
1. Harus ada 1 sdt garam
1. Tambah 2 sdm air asam jawa
1. Jangan lupa secukupnya minyak untuk menggoreng




<!--inarticleads2-->

##### Bagaimana membuat  Rujak Cireng:

1. Campurkan tepung kanji dengan irisan daun bawang
1. rebus air,bawang putih halus,garam 1 1/4 sdt dan kaldu bubuk
1. masukkan air bumbu panas-panas ke dalam tepung,aduk rata,adonan akan lengket
1. panaskan minyak,ambil 1 sendok makan adonan lalu goreng,tidak usah menggoreng terlalu lama,pastikan cireng sudah krispi dan matang
1. haluskan cabai merah besar,cabai rawit,garam. setelah halus tambahkan gula jawa dan air asam jawa.
1. sajikan cireng hangat dengan sambalnya, bisa disiramkan,bisa dicocol :)




Demikianlah cara membuat rujak cireng yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
