---
description: "Step-by-Step menyiapakan Roti Bantal/ Bolang-baling Empuk minggu ini"
title: "Step-by-Step menyiapakan Roti Bantal/ Bolang-baling Empuk minggu ini"
slug: 14-step-by-step-menyiapakan-roti-bantal-bolang-baling-empuk-minggu-ini
date: 2020-11-18T08:56:12.480Z
image: https://img-global.cpcdn.com/recipes/ff0f6e7b4551ed3c/751x532cq70/roti-bantal-bolang-baling-empuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ff0f6e7b4551ed3c/751x532cq70/roti-bantal-bolang-baling-empuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ff0f6e7b4551ed3c/751x532cq70/roti-bantal-bolang-baling-empuk-foto-resep-utama.jpg
author: Louisa Gray
ratingvalue: 4.4
reviewcount: 2010
recipeingredient:
- "200 gr tepung terigu protein sedang"
- "40 gr gula pasir"
- "1/2 sdt ragi instan"
- "1/2 sdt baking powder"
- "50 ml susu cair saya ganti dengan 65 ml santan instan"
- "50 ml air hangat sesuaikan"
- "15 ml minyak"
- "1/4 sdt garam"
- "Secukupnya wijen"
recipeinstructions:
- "Siapkan bahan."
- "Campur tepung terigu, gula pasir, ragi instan dan baking powder. Tambahkan santan dan air hangat, uleni sebentar hingga tercampur rata lalu masukkan minyak goreng dan garam, uleni (tidak perlu terlalu kalis) Diamkan selama 1 jam."
- "Gilas adonan dengan rolling pin, potong persegi. Celupkan sebentar dalam air lalu gulingkan kedalam wijen, diamkan lagi lebih kurang selama 30 menit. Panaskan minyak goreng, goreng roti dengan api kecil (satu kali balik saja)."
categories:
- Recipe
tags:
- roti
- bantal
- bolangbaling

katakunci: roti bantal bolangbaling 
nutrition: 121 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT53M"
recipeyield: "4"
recipecategory: Dinner

---


![Roti Bantal/ Bolang-baling Empuk](https://img-global.cpcdn.com/recipes/ff0f6e7b4551ed3c/751x532cq70/roti-bantal-bolang-baling-empuk-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang setidaknya kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti roti bantal/ bolang-baling empuk yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan ciri khas yang merupakan keragaman Indonesia



Kedekatan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Roti Bantal/ Bolang-baling Empuk untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang bisa anda coba salah satunya roti bantal/ bolang-baling empuk yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep roti bantal/ bolang-baling empuk tanpa harus bersusah payah.
Seperti resep Roti Bantal/ Bolang-baling Empuk yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 9 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Bantal/ Bolang-baling Empuk:

1. Siapkan 200 gr tepung terigu protein sedang
1. Siapkan 40 gr gula pasir
1. Siapkan 1/2 sdt ragi instan
1. Harus ada 1/2 sdt baking powder
1. Harap siapkan 50 ml susu cair (saya ganti dengan 65 ml santan instan)
1. Tambah 50 ml air hangat (sesuaikan)
1. Tambah 15 ml minyak
1. Tambah 1/4 sdt garam
1. Tambah Secukupnya wijen




<!--inarticleads2-->

##### Langkah membuat  Roti Bantal/ Bolang-baling Empuk:

1. Siapkan bahan.
1. Campur tepung terigu, gula pasir, ragi instan dan baking powder. Tambahkan santan dan air hangat, uleni sebentar hingga tercampur rata lalu masukkan minyak goreng dan garam, uleni (tidak perlu terlalu kalis) Diamkan selama 1 jam.
1. Gilas adonan dengan rolling pin, potong persegi. Celupkan sebentar dalam air lalu gulingkan kedalam wijen, diamkan lagi lebih kurang selama 30 menit. Panaskan minyak goreng, goreng roti dengan api kecil (satu kali balik saja).




Demikianlah cara membuat roti bantal/ bolang-baling empuk yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat gampang dan teruji, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
