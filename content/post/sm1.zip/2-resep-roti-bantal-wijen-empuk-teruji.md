---
description: "Resep : Roti Bantal Wijen Empuk Teruji"
title: "Resep : Roti Bantal Wijen Empuk Teruji"
slug: 2-resep-roti-bantal-wijen-empuk-teruji
date: 2020-08-25T21:19:58.432Z
image: https://img-global.cpcdn.com/recipes/2439514f231d0117/751x532cq70/roti-bantal-wijen-empuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2439514f231d0117/751x532cq70/roti-bantal-wijen-empuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2439514f231d0117/751x532cq70/roti-bantal-wijen-empuk-foto-resep-utama.jpg
author: Eliza Walton
ratingvalue: 4
reviewcount: 16204
recipeingredient:
- "260 gram tepung terigu"
- "80 gram gula pasir"
- "50 gram margarin"
- "125 ml air"
- "1 sdt garam"
- "3 (1/2 sdt) ragi instan"
- " Tambahan"
- "3-4 sdm tepung terigu"
- "1 sendok air"
recipeinstructions:
- "Masukkan tepung terigu, gula, garam dan ragi. Aduk hingga tercampur rata."
- "Tambahkan air biasa (tidak usah air hangat), aduk hingga rata. Lelehkan margarin dan masukkan kedalam adonan. Aduk hingga rata."
- "Uleni sebentar hingga agak tidak lengket. Sambil diuleni, jika masih lengket, tambahkan tepung lagi kira-kira 3-4 sdm. Uleni hingga sedikit lengket. Diamkan selama 45-60 menit."
- "Lalu siapkan tatakan penggilingan. Taburi dengantepung dahulu tatakannya, baru giling adonannya hingga berbentuk kotak/persegi panjang."
- "Taburi lagi tepung di atasnya. Lalu balik lagi adonannya. Beri tepung lagi, barulah beri wijen di atasnya. Warning ⚠⚠⚠ JANGAN BANYAK-BANYAK MEMBERI WIJEN, KARENA RASANYA BISA TIDAK ENAK."
- "Jika wijen tidak menempel, olesi adonan yang berwijen dengan air (tapi jangan terlalu banyak agar adonan bisa mengembang)."
- "Diamkan adonan lagi selama 15-20 menit, lalu potong sesuai selera."
- "Panaskan api sedang, lalu masukkan adonan. Perlu diperhatikan, bahwa adonan ini cepat matang, jadi harus cepat dibalik agar tidak gosong."
- "Angkat roti bantal dan........."
- "Hidangkan di meja."
- "Cocok untuk sarapan pagi bersama keluarga."
- "Lihat dalamnya......."
- ""
categories:
- Recipe
tags:
- roti
- bantal
- wijen

katakunci: roti bantal wijen 
nutrition: 158 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Lunch

---


![Roti Bantal Wijen Empuk](https://img-global.cpcdn.com/recipes/2439514f231d0117/751x532cq70/roti-bantal-wijen-empuk-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang setidaknya kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti roti bantal wijen empuk yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa keistimewahan yang merupakan keragaman Indonesia

Kedekatan rumah tangga bisa didapat dengan cara sederhana. Diantaranya adalah memasak Roti Bantal Wijen Empuk untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang dapat anda buat salah satunya roti bantal wijen empuk yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep roti bantal wijen empuk tanpa harus bersusah payah.
Seperti resep Roti Bantal Wijen Empuk yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 9 bahan dan 13 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Roti Bantal Wijen Empuk:

1. Harap siapkan 260 gram tepung terigu
1. Siapkan 80 gram gula pasir
1. Diperlukan 50 gram margarin
1. Harap siapkan 125 ml air
1. Harus ada 1 sdt garam
1. Jangan lupa 3 (1/2 sdt) ragi instan
1. Jangan lupa  Tambahan:
1. Siapkan 3-4 sdm tepung terigu
1. Diperlukan 1 sendok air




<!--inarticleads2-->

##### Langkah membuat  Roti Bantal Wijen Empuk:

1. Masukkan tepung terigu, gula, garam dan ragi. Aduk hingga tercampur rata.
1. Tambahkan air biasa (tidak usah air hangat), aduk hingga rata. Lelehkan margarin dan masukkan kedalam adonan. Aduk hingga rata.
1. Uleni sebentar hingga agak tidak lengket. Sambil diuleni, jika masih lengket, tambahkan tepung lagi kira-kira 3-4 sdm. Uleni hingga sedikit lengket. Diamkan selama 45-60 menit.
1. Lalu siapkan tatakan penggilingan. Taburi dengantepung dahulu tatakannya, baru giling adonannya hingga berbentuk kotak/persegi panjang.
1. Taburi lagi tepung di atasnya. Lalu balik lagi adonannya. Beri tepung lagi, barulah beri wijen di atasnya. Warning ⚠⚠⚠ JANGAN BANYAK-BANYAK MEMBERI WIJEN, KARENA RASANYA BISA TIDAK ENAK.
1. Jika wijen tidak menempel, olesi adonan yang berwijen dengan air (tapi jangan terlalu banyak agar adonan bisa mengembang).
1. Diamkan adonan lagi selama 15-20 menit, lalu potong sesuai selera.
1. Panaskan api sedang, lalu masukkan adonan. Perlu diperhatikan, bahwa adonan ini cepat matang, jadi harus cepat dibalik agar tidak gosong.
1. Angkat roti bantal dan.........
1. Hidangkan di meja.
1. Cocok untuk sarapan pagi bersama keluarga.
1. Lihat dalamnya.......
1. 




Demikianlah cara membuat roti bantal wijen empuk yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
