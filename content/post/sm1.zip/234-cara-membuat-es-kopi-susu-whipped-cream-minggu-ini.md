---
description: "Cara membuat Es Kopi Susu Whipped Cream minggu ini"
title: "Cara membuat Es Kopi Susu Whipped Cream minggu ini"
slug: 234-cara-membuat-es-kopi-susu-whipped-cream-minggu-ini
date: 2020-08-27T10:58:53.813Z
image: https://img-global.cpcdn.com/recipes/85b6fe21b1e9f6d8/751x532cq70/es-kopi-susu-whipped-cream-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/85b6fe21b1e9f6d8/751x532cq70/es-kopi-susu-whipped-cream-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/85b6fe21b1e9f6d8/751x532cq70/es-kopi-susu-whipped-cream-foto-resep-utama.jpg
author: Cody Cox
ratingvalue: 4.9
reviewcount: 44290
recipeingredient:
- "2 sdt kopi nescafe classic"
- "2 sdt gula pasir"
- "1 sdt gula jawa bubuk"
- "1/3 sdt garam"
- "1 sdt vanilla extract"
- " Es batu"
- " Susu full cream"
- " Topping"
- "100 gr whipping cream"
- "2 sdm gula pasir"
recipeinstructions:
- "Campurkan di cangkir kecil atau mangkok kecil kopi nescafe, gula pasir, gula jawa, garam dan vanilla extract, beri air panas sedikit dan aduk hingga smua tercampur rata."
- "Siapkan gelas besar, tuang kopi lalu beri es batu sesuai selera, tambahkan susu full cream."
- "Cara membuat whipped cream, mixer dengan kecepatan tinggi whipping cream dengan gula sampai texture nya mengental, kira-kira 3 sampai 4 menit. Masukan ke piping bag yg sudah dimasukan spuit dalamnya (saya membuat whipped cream dulu sebelum membuat coffee nya, setelah dimasukan ke piping bag, taruh di freezer selama membuat kopi) semprotkan diatas es kopi untuk topping. 😊"
categories:
- Recipe
tags:
- es
- kopi
- susu

katakunci: es kopi susu 
nutrition: 287 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dinner

---


![Es Kopi Susu Whipped Cream](https://img-global.cpcdn.com/recipes/85b6fe21b1e9f6d8/751x532cq70/es-kopi-susu-whipped-cream-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan gurih. Ciri khas makanan Indonesia es kopi susu whipped cream yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga dapat diperoleh dengan cara mudah. Diantaranya adalah memasak Es Kopi Susu Whipped Cream untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang bisa anda praktekkan salah satunya es kopi susu whipped cream yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep es kopi susu whipped cream tanpa harus bersusah payah.
Seperti resep Es Kopi Susu Whipped Cream yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 10 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Es Kopi Susu Whipped Cream:

1. Jangan lupa 2 sdt kopi nescafe classic
1. Harap siapkan 2 sdt gula pasir
1. Harus ada 1 sdt gula jawa bubuk
1. Siapkan 1/3 sdt garam
1. Siapkan 1 sdt vanilla extract
1. Jangan lupa  Es batu
1. Tambah  Susu full cream
1. Siapkan  Topping
1. Dibutuhkan 100 gr whipping cream
1. Harap siapkan 2 sdm gula pasir




<!--inarticleads2-->

##### Instruksi membuat  Es Kopi Susu Whipped Cream:

1. Campurkan di cangkir kecil atau mangkok kecil kopi nescafe, gula pasir, gula jawa, garam dan vanilla extract, beri air panas sedikit dan aduk hingga smua tercampur rata.
1. Siapkan gelas besar, tuang kopi lalu beri es batu sesuai selera, tambahkan susu full cream.
1. Cara membuat whipped cream, mixer dengan kecepatan tinggi whipping cream dengan gula sampai texture nya mengental, kira-kira 3 sampai 4 menit. Masukan ke piping bag yg sudah dimasukan spuit dalamnya (saya membuat whipped cream dulu sebelum membuat coffee nya, setelah dimasukan ke piping bag, taruh di freezer selama membuat kopi) semprotkan diatas es kopi untuk topping. 😊




Demikianlah cara membuat es kopi susu whipped cream yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan cepat, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
