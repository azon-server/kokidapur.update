---
description: "Cara singkat membuat Key Lime Raspberry Pie Homemade"
title: "Cara singkat membuat Key Lime Raspberry Pie Homemade"
slug: 79-cara-singkat-membuat-key-lime-raspberry-pie-homemade
date: 2020-09-21T17:20:21.544Z
image: https://img-global.cpcdn.com/recipes/fbe703919319c064/751x532cq70/key-lime-raspberry-pie-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fbe703919319c064/751x532cq70/key-lime-raspberry-pie-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fbe703919319c064/751x532cq70/key-lime-raspberry-pie-foto-resep-utama.jpg
author: Hattie Curry
ratingvalue: 4.6
reviewcount: 40690
recipeingredient:
- " Bahan pie crust "
- "200 gr tepung terigu"
- "15 gr gula halus"
- "100 gr butter dingin"
- "1 butir kuning telur"
- " Bahan custard saya buat 12 resep"
- "2 butir kuning telur"
- "1 sdm yogurt"
- "60 ml perasan jeruk nipis"
- "1 sdm lime zest parut kulit jeruk nipis"
- "160 gr kental manis"
- " Bahan garnis "
- "200 ml Whipped cream yang sudah manis"
- "2 sdm Kental Manisgula halus saya skip"
- " Lime zest parut"
- "Potongan jeruk nipis dan raspberry"
- " Trimit hati"
recipeinstructions:
- "Berdoa dan cuci tangan dulu. Uleni tepung, gula halus dan kuning telur dengan mixer atau baloon wisker (saya pakai prosesor) lalu masukan bertahap butter sambil terus uleni hingga semua bahan tercampur rata. Bungkus plastik, diamkan di kulkas selama 30 menit."
- "Panaskan oven dengan suhu 170°C. Setelah 30 menit, keluarkan dari kulkas, cetakan dalam cetakan pie. Tusuk-tusuk dasar pie. Lalu oven sampai matang agak kecoklatan. Dinginkan. Keluarkan hati-hati dari cetakan (awas pie rapuh). Saya simpan di kulkas ya."
- "Sekarang buat custard. Mixer kuning telur dengan kecepatan tinggi hingga mengembang dan agak pucat, beri parutan lime zest dan kental manis, kocok lagi, lalu tuang jeruk nipis peras, kocok lagiiiiii...."
- "Terakhir masukkan yogurt. Kocok rata. Masukkan kedalam piping bag atau plastik, potong sedikit ujungnya, isi pie dengan custard."
- "Panggang lagi pie dengan suhu 150°C sekitar 30menit, keluarkan, dinginkan."
- "Tahap akhir, mixer dengan kecepatan tinggi whipping cream sampai kaku. Masukkan dalam piping bag. Semprotkan diatas custard, hias sesuai selera."
- "Jadi deeehhhh..... dalamnya seperti itu ya. Pie ini ga terlalu manis, saya suka seperti ini, jadi ga mblengeri. Tapi kalau yang suka manis tinggal tambah aja takaran kental manisnya. Selamat mencoba..."
categories:
- Recipe
tags:
- key
- lime
- raspberry

katakunci: key lime raspberry 
nutrition: 148 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT49M"
recipeyield: "4"
recipecategory: Dinner

---


![Key Lime Raspberry Pie](https://img-global.cpcdn.com/recipes/fbe703919319c064/751x532cq70/key-lime-raspberry-pie-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan empuk. Ciri kuliner Indonesia key lime raspberry pie yang penuh dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan keluarga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Key Lime Raspberry Pie untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang bisa anda contoh salah satunya key lime raspberry pie yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep key lime raspberry pie tanpa harus bersusah payah.
Seperti resep Key Lime Raspberry Pie yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Key Lime Raspberry Pie:

1. Harap siapkan  Bahan pie crust :
1. Tambah 200 gr tepung terigu
1. Harus ada 15 gr gula halus
1. Harus ada 100 gr butter dingin
1. Jangan lupa 1 butir kuning telur
1. Jangan lupa  Bahan custard (saya buat 1/2 resep):
1. Diperlukan 2 butir kuning telur
1. Jangan lupa 1 sdm yogurt
1. Harap siapkan 60 ml perasan jeruk nipis
1. Dibutuhkan 1 sdm lime zest parut (kulit jeruk nipis)
1. Diperlukan 160 gr kental manis
1. Harus ada  Bahan garnis :
1. Jangan lupa 200 ml Whipped cream yang sudah manis
1. Jangan lupa 2 sdm Kental Manis/gula halus (saya skip)
1. Harus ada  Lime zest parut
1. Dibutuhkan Potongan jeruk nipis dan raspberry
1. Siapkan  Trimit hati




<!--inarticleads2-->

##### Cara membuat  Key Lime Raspberry Pie:

1. Berdoa dan cuci tangan dulu. Uleni tepung, gula halus dan kuning telur dengan mixer atau baloon wisker (saya pakai prosesor) lalu masukan bertahap butter sambil terus uleni hingga semua bahan tercampur rata. Bungkus plastik, diamkan di kulkas selama 30 menit.
1. Panaskan oven dengan suhu 170°C. Setelah 30 menit, keluarkan dari kulkas, cetakan dalam cetakan pie. Tusuk-tusuk dasar pie. Lalu oven sampai matang agak kecoklatan. Dinginkan. Keluarkan hati-hati dari cetakan (awas pie rapuh). Saya simpan di kulkas ya.
1. Sekarang buat custard. Mixer kuning telur dengan kecepatan tinggi hingga mengembang dan agak pucat, beri parutan lime zest dan kental manis, kocok lagi, lalu tuang jeruk nipis peras, kocok lagiiiiii....
1. Terakhir masukkan yogurt. Kocok rata. Masukkan kedalam piping bag atau plastik, potong sedikit ujungnya, isi pie dengan custard.
1. Panggang lagi pie dengan suhu 150°C sekitar 30menit, keluarkan, dinginkan.
1. Tahap akhir, mixer dengan kecepatan tinggi whipping cream sampai kaku. Masukkan dalam piping bag. Semprotkan diatas custard, hias sesuai selera.
1. Jadi deeehhhh..... dalamnya seperti itu ya. Pie ini ga terlalu manis, saya suka seperti ini, jadi ga mblengeri. Tapi kalau yang suka manis tinggal tambah aja takaran kental manisnya. Selamat mencoba...




Demikianlah cara membuat key lime raspberry pie yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
