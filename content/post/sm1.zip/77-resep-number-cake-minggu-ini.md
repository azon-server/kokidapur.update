---
description: "Resep : Number Cake minggu ini"
title: "Resep : Number Cake minggu ini"
slug: 77-resep-number-cake-minggu-ini
date: 2021-02-13T04:56:01.642Z
image: https://img-global.cpcdn.com/recipes/028647b1ad1c2088/751x532cq70/number-cake-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/028647b1ad1c2088/751x532cq70/number-cake-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/028647b1ad1c2088/751x532cq70/number-cake-foto-resep-utama.jpg
author: Jeanette Gilbert
ratingvalue: 4.7
reviewcount: 39100
recipeingredient:
- " Bahan A "
- "4 butir telur"
- "200 gr gula pasir"
- "1 sdt sp"
- " Bahan B "
- "200 gr tepung terigu"
- "1/2 sdt baking powder"
- "1/2 sdt vanili bubuk"
- " Aduk rata lalu ayak"
- " Bahan C "
- "100 ml santan"
- "100 ml minyak"
- " Bahan D "
- "Secukupnya pasta talasresep asli pakai bubuk taro"
- " Pelengkap "
- " Whipped cream"
- "Buah strawberry"
- "Cube Milo"
- "stik Biskuit"
- " Coklat kacang"
recipeinstructions:
- "Siapkan semua bahan"
- "Mixer bahan I sampai mengembang kental putih berjejak 👇🏻"
- "Masukan bahan B aduk balik pakai spatula (resep asli di Mixer pakai speed rendah)👇🏻"
- "Terakhir masuka bahan C dan D aduk balik sampai tercampur rata 👇🏻 (adonan tetap kental tapi semua bahan tercampur rata)hasil akhirnya lupa di foto 🤭"
- "Tuang di loyang ukuran 24x10x7 yang di alasi baking papper,kukus selama 30 menit(tes tusuk kue untuk memastikan matang 😉)gunakan api kecil agar hasil kue tidak bergelombang,kukusan harus sudah dipanaskan sebelumnya ya 😉"
- "Setelah matang langsung keluarkan dari loyang biarakn dingin baru belah dua kue kemudian tumpuk lagi dan bentuk angka 1 atau sesuai kebutuhan ya😉 angkat satu bagian kue beri whipped cream yang di semprotkan menggunakan spuit 👇🏻"
- "Tumpuk kue satunya lalu semprotkan lagi whipped cream,hias dengan buat strawberry,coklat, biskuit apapun sesuai selera 😉 kreasikan sendiri ya😁"
categories:
- Recipe
tags:
- number
- cake

katakunci: number cake 
nutrition: 162 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Dinner

---


![Number Cake](https://img-global.cpcdn.com/recipes/028647b1ad1c2088/751x532cq70/number-cake-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga renyah. Karasteristik masakan Nusantara number cake yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Number Cake untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi resep yang dapat anda coba salah satunya number cake yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep number cake tanpa harus bersusah payah.
Berikut ini resep Number Cake yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Number Cake:

1. Tambah  Bahan A :
1. Harus ada 4 butir telur
1. Harap siapkan 200 gr gula pasir
1. Dibutuhkan 1 sdt sp
1. Dibutuhkan  Bahan B :
1. Dibutuhkan 200 gr tepung terigu
1. Tambah 1/2 sdt baking powder
1. Diperlukan 1/2 sdt vanili bubuk
1. Diperlukan  Aduk rata lalu ayak
1. Tambah  Bahan C :
1. Harus ada 100 ml santan
1. Dibutuhkan 100 ml minyak
1. Jangan lupa  Bahan D :
1. Harus ada Secukupnya pasta talas(resep asli pakai bubuk taro)
1. Dibutuhkan  Pelengkap :
1. Harus ada  Whipped cream
1. Tambah Buah strawberry
1. Diperlukan Cube Milo
1. Dibutuhkan stik Biskuit
1. Jangan lupa  Coklat kacang




<!--inarticleads2-->

##### Langkah membuat  Number Cake:

1. Siapkan semua bahan
1. Mixer bahan I sampai mengembang kental putih berjejak 👇🏻
1. Masukan bahan B aduk balik pakai spatula (resep asli di Mixer pakai speed rendah)👇🏻
1. Terakhir masuka bahan C dan D aduk balik sampai tercampur rata 👇🏻 (adonan tetap kental tapi semua bahan tercampur rata)hasil akhirnya lupa di foto 🤭
1. Tuang di loyang ukuran 24x10x7 yang di alasi baking papper,kukus selama 30 menit(tes tusuk kue untuk memastikan matang 😉)gunakan api kecil agar hasil kue tidak bergelombang,kukusan harus sudah dipanaskan sebelumnya ya 😉
1. Setelah matang langsung keluarkan dari loyang biarakn dingin baru belah dua kue kemudian tumpuk lagi dan bentuk angka 1 atau sesuai kebutuhan ya😉 angkat satu bagian kue beri whipped cream yang di semprotkan menggunakan spuit 👇🏻
1. Tumpuk kue satunya lalu semprotkan lagi whipped cream,hias dengan buat strawberry,coklat, biskuit apapun sesuai selera 😉 kreasikan sendiri ya😁




Demikianlah cara membuat number cake yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan terbukti, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
