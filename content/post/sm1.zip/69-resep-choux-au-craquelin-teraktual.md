---
description: "Resep : Choux Au Craquelin 🥐 teraktual"
title: "Resep : Choux Au Craquelin 🥐 teraktual"
slug: 69-resep-choux-au-craquelin-teraktual
date: 2020-10-05T17:49:09.836Z
image: https://img-global.cpcdn.com/recipes/94babb937bac5e5c/751x532cq70/choux-au-craquelin-🥐-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/94babb937bac5e5c/751x532cq70/choux-au-craquelin-🥐-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/94babb937bac5e5c/751x532cq70/choux-au-craquelin-🥐-foto-resep-utama.jpg
author: Marian Larson
ratingvalue: 4.6
reviewcount: 4432
recipeingredient:
- " Craquelin"
- "25 gr margarin"
- "1 1/2 sdm gula"
- "25 gr tepung"
- " Choux"
- "35 ml air"
- "30 gr margarin"
- "30 gr tepung"
- "1 butir telur"
- " Basic Custard"
- "1 butir kuning telur"
- "17 gr gula"
- "80 ml susu"
- "1 sdm tepung"
- "1/2 sdt pasta vanilla"
- " Vla VanillaDiplomat Cream"
- "1 resep basic custard"
- "60 ml whipped cream cair pake yg bubuk jg bisa kurangi gulanya"
recipeinstructions:
- "Pertama, bikin basic custard dulu karna nanti bakal disimpen kulkas sebelum dipake. Campur kuning telur sama gula, aduk sampe pucat. Tambahkan susu, aduk rata. Masukkan tepung, aduk."
- "Masak dg api kecil sampai kental. Lalu, tambahkan pasta vanilla. Tutup plastik wrap, simpan kulkas."
- "Kedua, bikin craquelin. Campurkan margarin &amp; gula. Lalu, tambahkan tepung. Aduk sampe rata, simpan di kulkas."
- "Ketiga, bikin choux. Masukkan margarin &amp; air dalam panci masak sampai larut."
- "Tambahkan tepung, langsung aduk sampe kalis."
- "Dinginkan sebentar, lalu campur dg telur."
- "Masukkan adonan kedalam plastik segita, cetak. Ambil craquelin, bentuk bulat-bulat (langsung cetak sebelum masuk kulkas jg bisa). Tempel craquelin diatas adonan choux."
- "Preheat oven. Panggang dg suhu 180°C - 25 menit."
- "Selanjutnya bikin diplomat cream. Kocok whipped cream sampai mengembang. Campurkan dg adonan custard, simpan kulkas."
- "Jika choux sudah matang, dinginkan diatas cooling rack, lalu isi diplomat cream dg cara disemprot dari lubang bawah."
- "Hasil jadi 9 choux. Diplomat cream cuma cukup untuk 5 choux. Next resep isiannya x2 biar cukup 🤣"
categories:
- Recipe
tags:
- choux
- au
- craquelin

katakunci: choux au craquelin 
nutrition: 175 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dinner

---


![Choux Au Craquelin 🥐](https://img-global.cpcdn.com/recipes/94babb937bac5e5c/751x532cq70/choux-au-craquelin-🥐-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti choux au craquelin 🥐 yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan keistimewahan yang merupakan keragaman Kita



Keharmonisan keluarga dapat diperoleh dengan cara simple. Salah satunya adalah memasak Choux Au Craquelin 🥐 untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang bisa anda coba salah satunya choux au craquelin 🥐 yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep choux au craquelin 🥐 tanpa harus bersusah payah.
Seperti resep Choux Au Craquelin 🥐 yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 11 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Choux Au Craquelin 🥐:

1. Siapkan  Craquelin:
1. Siapkan 25 gr margarin
1. Tambah 1 1/2 sdm gula
1. Harus ada 25 gr tepung
1. Tambah  Choux:
1. Siapkan 35 ml air
1. Siapkan 30 gr margarin
1. Jangan lupa 30 gr tepung
1. Harus ada 1 butir telur
1. Harus ada  Basic Custard:
1. Diperlukan 1 butir kuning telur
1. Tambah 17 gr gula
1. Harap siapkan 80 ml susu
1. Harap siapkan 1 sdm tepung
1. Harap siapkan 1/2 sdt pasta vanilla
1. Tambah  Vla Vanilla/Diplomat Cream:
1. Tambah 1 resep basic custard
1. Dibutuhkan 60 ml whipped cream cair (pake yg bubuk jg bisa kurangi gulanya)




<!--inarticleads2-->

##### Langkah membuat  Choux Au Craquelin 🥐:

1. Pertama, bikin basic custard dulu karna nanti bakal disimpen kulkas sebelum dipake. Campur kuning telur sama gula, aduk sampe pucat. Tambahkan susu, aduk rata. Masukkan tepung, aduk.
1. Masak dg api kecil sampai kental. Lalu, tambahkan pasta vanilla. Tutup plastik wrap, simpan kulkas.
1. Kedua, bikin craquelin. Campurkan margarin &amp; gula. Lalu, tambahkan tepung. Aduk sampe rata, simpan di kulkas.
1. Ketiga, bikin choux. Masukkan margarin &amp; air dalam panci masak sampai larut.
1. Tambahkan tepung, langsung aduk sampe kalis.
1. Dinginkan sebentar, lalu campur dg telur.
1. Masukkan adonan kedalam plastik segita, cetak. Ambil craquelin, bentuk bulat-bulat (langsung cetak sebelum masuk kulkas jg bisa). Tempel craquelin diatas adonan choux.
1. Preheat oven. Panggang dg suhu 180°C - 25 menit.
1. Selanjutnya bikin diplomat cream. Kocok whipped cream sampai mengembang. Campurkan dg adonan custard, simpan kulkas.
1. Jika choux sudah matang, dinginkan diatas cooling rack, lalu isi diplomat cream dg cara disemprot dari lubang bawah.
1. Hasil jadi 9 choux. Diplomat cream cuma cukup untuk 5 choux. Next resep isiannya x2 biar cukup 🤣




Demikianlah cara membuat choux au craquelin 🥐 yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat gampang dan teruji, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
