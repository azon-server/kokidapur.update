---
description: "Cara singkat menyiapakan Roti Bantal/ Bolang Baling/Odading Empuk Renyah Terbukti"
title: "Cara singkat menyiapakan Roti Bantal/ Bolang Baling/Odading Empuk Renyah Terbukti"
slug: 42-cara-singkat-menyiapakan-roti-bantal-bolang-baling-odading-empuk-renyah-terbukti
date: 2020-10-13T00:11:14.813Z
image: https://img-global.cpcdn.com/recipes/a7131348d3f26574/751x532cq70/roti-bantal-bolang-balingodading-empuk-renyah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a7131348d3f26574/751x532cq70/roti-bantal-bolang-balingodading-empuk-renyah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a7131348d3f26574/751x532cq70/roti-bantal-bolang-balingodading-empuk-renyah-foto-resep-utama.jpg
author: Sophie Schmidt
ratingvalue: 4.4
reviewcount: 22058
recipeingredient:
- "250 gr tepung terigu cakra"
- "1 btr telur ayam utuh"
- "2 sdm margarin"
- "2 sdm Skm susu kental manis"
- "2 sdm gula pasir"
- "100 ml air hangat"
- "1 sdt ragi instan FermipanSaf"
- "1/4 sdt vanili"
- "secukupnya wijen dan gula pasir"
recipeinstructions:
- "❤ bahan biang :: Campur ragi, gula pasir dan air hangat, aduk rata sampe gula larut diamkan 5-10 menit. Kalo tdk berbuih buang saja ganti yg baru krn nanti rotinya bisa bantat/tdk mengembang."
- "Taruh di wadah, margarin, telur, skm, vanili dan terigu. Tuang bahan biang sedikit demi sedikit uleni sampe kalis elastis dan empuk tapi tdk lengket di tangan (bisa pake mixer). Diamkan sampe mengembang 2x lipat slm kurleb 45 mnt - 1 jam dgn ditutup."
- "Stlh mengembang kempeskan...ambil adonan dan pipihkan setebal kurleb 2 cm, diamkan lagi 10-15 menit."
- "Potong memanjang dan potong lagi bentuk kotak, pisahkan jgn berdempetan. Adonan ini empuk sampe metat metot kalo di pegang...(artinya opo yo...😃). Sy taburi dgn sdkt tepung biar tdk lengket ketika di pegang atau baluri tangan dgn terigu."
- "Beri permukaan dgn air (saya pake kuas), kemudian gulingkan ke wijen &amp; gula pasir...nanti ada krenyes2 dr gulanya. Bsa semua permukaan di baluri wijen/hanya satu permukaannya saja silahkan...sy hanya 1 permukaannya sj."
- "Goreng dgn api sedang cenderung kecil sampe kuning kecoklatan kedua sisinya, angkat tiriskan."
- ""
- "08/01/2018, Ada sisa sdkt wijen sy bikin lagi...ini belajar langsung sm abang yg jualan 😃. Biar gula pasir dan wijennya gak rontok waktu di goreng caranya stlh adonan di pipihkan kuas permukaannya dgn air kemudian taburi gula pasir dan sdkt wijen, jadi wijennya gak terlalu banyak kata yg jual hanya sbg syarat aja..😊kemudian di tutup dgn ditumpuk lagi dgn adonan yg sdh di pipihkan trus istirahatkan lagi kurleb 15 menitan."
- "Setelah mau di goreng baru di potong2 jadi nanti gula dan wijen akan menempel sempurna kemudian ketika hampir matang akan lepas/pisah mjd 2 rotinya 👆, dan ini hasilnya..montok empuk dan renyah krenyes2 dr gula pasirnya..👇"
categories:
- Recipe
tags:
- roti
- bantal
- bolang

katakunci: roti bantal bolang 
nutrition: 272 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT58M"
recipeyield: "1"
recipecategory: Dessert

---


![Roti Bantal/ Bolang Baling/Odading Empuk Renyah](https://img-global.cpcdn.com/recipes/a7131348d3f26574/751x532cq70/roti-bantal-bolang-balingodading-empuk-renyah-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti roti bantal/ bolang baling/odading empuk renyah yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa keistimewahan yang merupakan keragaman Nusantara



Kehangatan keluarga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Roti Bantal/ Bolang Baling/Odading Empuk Renyah untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi budaya, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang bisa anda buat salah satunya roti bantal/ bolang baling/odading empuk renyah yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya saat ini anda dapat dengan mudah menemukan resep roti bantal/ bolang baling/odading empuk renyah tanpa harus bersusah payah.
Seperti resep Roti Bantal/ Bolang Baling/Odading Empuk Renyah yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Bantal/ Bolang Baling/Odading Empuk Renyah:

1. Dibutuhkan 250 gr tepung terigu cakra
1. Dibutuhkan 1 btr telur ayam utuh
1. Tambah 2 sdm margarin
1. Harap siapkan 2 sdm Skm (susu kental manis)
1. Siapkan 2 sdm gula pasir
1. Dibutuhkan 100 ml air hangat
1. Dibutuhkan 1 sdt ragi instan (Fermipan/Saf)
1. Harus ada 1/4 sdt vanili
1. Harus ada secukupnya wijen dan gula pasir




<!--inarticleads2-->

##### Cara membuat  Roti Bantal/ Bolang Baling/Odading Empuk Renyah:

1. ❤ bahan biang :: Campur ragi, gula pasir dan air hangat, aduk rata sampe gula larut diamkan 5-10 menit. Kalo tdk berbuih buang saja ganti yg baru krn nanti rotinya bisa bantat/tdk mengembang.
1. Taruh di wadah, margarin, telur, skm, vanili dan terigu. Tuang bahan biang sedikit demi sedikit uleni sampe kalis elastis dan empuk tapi tdk lengket di tangan (bisa pake mixer). Diamkan sampe mengembang 2x lipat slm kurleb 45 mnt - 1 jam dgn ditutup.
1. Stlh mengembang kempeskan...ambil adonan dan pipihkan setebal kurleb 2 cm, diamkan lagi 10-15 menit.
1. Potong memanjang dan potong lagi bentuk kotak, pisahkan jgn berdempetan. Adonan ini empuk sampe metat metot kalo di pegang...(artinya opo yo...😃). Sy taburi dgn sdkt tepung biar tdk lengket ketika di pegang atau baluri tangan dgn terigu.
1. Beri permukaan dgn air (saya pake kuas), kemudian gulingkan ke wijen &amp; gula pasir...nanti ada krenyes2 dr gulanya. Bsa semua permukaan di baluri wijen/hanya satu permukaannya saja silahkan...sy hanya 1 permukaannya sj.
1. Goreng dgn api sedang cenderung kecil sampe kuning kecoklatan kedua sisinya, angkat tiriskan.
1. 
1. 08/01/2018, Ada sisa sdkt wijen sy bikin lagi...ini belajar langsung sm abang yg jualan 😃. Biar gula pasir dan wijennya gak rontok waktu di goreng caranya stlh adonan di pipihkan kuas permukaannya dgn air kemudian taburi gula pasir dan sdkt wijen, jadi wijennya gak terlalu banyak kata yg jual hanya sbg syarat aja..😊kemudian di tutup dgn ditumpuk lagi dgn adonan yg sdh di pipihkan trus istirahatkan lagi kurleb 15 menitan.
1. Setelah mau di goreng baru di potong2 jadi nanti gula dan wijen akan menempel sempurna kemudian ketika hampir matang akan lepas/pisah mjd 2 rotinya 👆, dan ini hasilnya..montok empuk dan renyah krenyes2 dr gula pasirnya..👇




Demikianlah cara membuat roti bantal/ bolang baling/odading empuk renyah yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
