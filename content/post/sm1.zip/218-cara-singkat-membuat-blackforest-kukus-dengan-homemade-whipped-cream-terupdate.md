---
description: "Cara singkat membuat Blackforest Kukus dengan Homemade Whipped Cream terupdate"
title: "Cara singkat membuat Blackforest Kukus dengan Homemade Whipped Cream terupdate"
slug: 218-cara-singkat-membuat-blackforest-kukus-dengan-homemade-whipped-cream-terupdate
date: 2020-10-16T04:10:03.344Z
image: https://img-global.cpcdn.com/recipes/0acdafcb5024aff6/751x532cq70/blackforest-kukus-dengan-homemade-whipped-cream-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0acdafcb5024aff6/751x532cq70/blackforest-kukus-dengan-homemade-whipped-cream-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0acdafcb5024aff6/751x532cq70/blackforest-kukus-dengan-homemade-whipped-cream-foto-resep-utama.jpg
author: Jonathan Carr
ratingvalue: 4.2
reviewcount: 11992
recipeingredient:
- " Bahan brownies"
- "180 gr margarine"
- "150 gr DCC"
- "170 gr tepung terigu"
- "50 gr bubuk kakao"
- "150 gr gula pasir sesuai selera"
- "1 sdt baking powder"
- "1/2 sdt vanilli bubuk"
- "8 butir telur"
- "1 sdm pengemulsi"
- " Bahan Whipped Cream"
- "2 sachet susu bubuk"
- "5 sdm SKM"
- "1 sdm pengemulsi"
- "100 cc susu cair dibekukan sebentar"
- "secukupnya Es batu"
- " Vanilli secukupnya saya skip"
- " Bahan Ganache"
- "3 sdm whipped cream bubuk"
- "100 cc air"
- "75 gr DCC"
- " Bahan Lainnya"
- " Selai strawberry blueberry"
- " Simple syrup saya 4 sdm gula dalam 5 sdm air panas Dinginkan"
- " Parutan DCC"
recipeinstructions:
- "Buat whipped cream dulu. Saya buat sendiri karena persediaan whipped cream kemasan sisa sedikit. Namun hasil yang saya buat hasilnya lebih enak dan lembut. Rasanya seperti ice cream vanilla 😄😄"
- "Mixer susu bubuk, SKM, pengemulsi dan susu cair yang dibekukan (haluskan/hancurkan kecil-kecil agar mudah dimixer. Pakai es batu biasa juga bisa). Di bagian bawah loyang, letakkan es batu secukupnya. Mixer dengan kecepatan tinggi sampai kaku (kurang lebih 20 menit). Tutup dengan plastic wrap. Simpan di kulkas."
- "Lelehkan DCC dan margarine. Sisihkan agar dingin."
- "Ayak tepung, bubuk kakao, baking powder, vanilli."
- "Panaskan dandang kukus. Lapisi penutupnya dengan kain bersih."
- "Mixer telur, pengemulsi dan gula pasir hingga kaku. Masukkan campuran tepung, mixer hingga tercampur merata dengan kecepatan sedang."
- "Matikkan mixer, lalu tuang DCC dan margarine yang sudah dilelehkan. Aduk cukup dengan spatula."
- "Masukkan adonan di dalam cetakkan. Kukus dalam dandang yang sudah dipanaskan selama kurang lebih 30 menit."
- "Untuk memastikan apakah adonan sudah matang bisa dengan tes tusuk. Kalau sudah tidak ada adonan yang menempel, artinya kue sudah matang. Angkat lalu biarkan hingga dingin."
- "Buat ganache. Campurkan whipped cream bubuk dengan air. Aduk dan masak di atas kompor dengan api sedang hingga mendidih. Matikan api, masukkan DCC. Aduk rata hingga DCC meleleh."
- "Setelah kue dingin, potong kue menjadi 2 lapis (boleh 3 lapis). Ratakan juga bagian atas kue. Tuang simple syrup secukupnya. Lapisi dengan selai, lalu timpa dengan whipped cream."
- "Begitu juga dengan lapisan kedua."
- "Cover semua bagian kue dengan whipped cream. Ratakan agar permukaan kue rapi."
- "Buat ganache drop. (Punya saya terlalu besar sehingga kelihatan tidak rapi 😅. Maklum ini pertama kalinya membuatnya)."
- "Parut DCC secukupnya di bagian atas kue."
- "Bila sudah selesai dihias, masukkan kembali ke dalam kulkas, agar whipped creamnya set dan tidak meleleh."
categories:
- Recipe
tags:
- blackforest
- kukus
- dengan

katakunci: blackforest kukus dengan 
nutrition: 260 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dinner

---


![Blackforest Kukus dengan Homemade Whipped Cream](https://img-global.cpcdn.com/recipes/0acdafcb5024aff6/751x532cq70/blackforest-kukus-dengan-homemade-whipped-cream-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti blackforest kukus dengan homemade whipped cream yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan ciri khas yang merupakan keragaman Kita

Keharmonisan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak Blackforest Kukus dengan Homemade Whipped Cream untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang dapat anda praktekkan salah satunya blackforest kukus dengan homemade whipped cream yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep blackforest kukus dengan homemade whipped cream tanpa harus bersusah payah.
Seperti resep Blackforest Kukus dengan Homemade Whipped Cream yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 25 bahan dan 16 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Blackforest Kukus dengan Homemade Whipped Cream:

1. Harus ada  Bahan brownies
1. Harap siapkan 180 gr margarine
1. Dibutuhkan 150 gr DCC
1. Harus ada 170 gr tepung terigu
1. Siapkan 50 gr bubuk kakao
1. Siapkan 150 gr gula pasir (sesuai selera)
1. Tambah 1 sdt baking powder
1. Tambah 1/2 sdt vanilli bubuk
1. Jangan lupa 8 butir telur
1. Harus ada 1 sdm pengemulsi
1. Tambah  Bahan Whipped Cream
1. Harap siapkan 2 sachet susu bubuk
1. Siapkan 5 sdm SKM
1. Jangan lupa 1 sdm pengemulsi
1. Harus ada 100 cc susu cair (dibekukan sebentar)
1. Siapkan secukupnya Es batu
1. Siapkan  Vanilli secukupnya (saya skip)
1. Tambah  Bahan Ganache
1. Tambah 3 sdm whipped cream bubuk
1. Tambah 100 cc air
1. Harap siapkan 75 gr DCC
1. Diperlukan  Bahan Lainnya
1. Dibutuhkan  Selai strawberry /blueberry
1. Jangan lupa  Simple syrup (saya: 4 sdm gula dalam 5 sdm air panas. Dinginkan)
1. Diperlukan  Parutan DCC




<!--inarticleads2-->

##### Bagaimana membuat  Blackforest Kukus dengan Homemade Whipped Cream:

1. Buat whipped cream dulu. Saya buat sendiri karena persediaan whipped cream kemasan sisa sedikit. Namun hasil yang saya buat hasilnya lebih enak dan lembut. Rasanya seperti ice cream vanilla 😄😄
1. Mixer susu bubuk, SKM, pengemulsi dan susu cair yang dibekukan (haluskan/hancurkan kecil-kecil agar mudah dimixer. Pakai es batu biasa juga bisa). Di bagian bawah loyang, letakkan es batu secukupnya. Mixer dengan kecepatan tinggi sampai kaku (kurang lebih 20 menit). Tutup dengan plastic wrap. Simpan di kulkas.
1. Lelehkan DCC dan margarine. Sisihkan agar dingin.
1. Ayak tepung, bubuk kakao, baking powder, vanilli.
1. Panaskan dandang kukus. Lapisi penutupnya dengan kain bersih.
1. Mixer telur, pengemulsi dan gula pasir hingga kaku. Masukkan campuran tepung, mixer hingga tercampur merata dengan kecepatan sedang.
1. Matikkan mixer, lalu tuang DCC dan margarine yang sudah dilelehkan. Aduk cukup dengan spatula.
1. Masukkan adonan di dalam cetakkan. Kukus dalam dandang yang sudah dipanaskan selama kurang lebih 30 menit.
1. Untuk memastikan apakah adonan sudah matang bisa dengan tes tusuk. Kalau sudah tidak ada adonan yang menempel, artinya kue sudah matang. Angkat lalu biarkan hingga dingin.
1. Buat ganache. Campurkan whipped cream bubuk dengan air. Aduk dan masak di atas kompor dengan api sedang hingga mendidih. Matikan api, masukkan DCC. Aduk rata hingga DCC meleleh.
1. Setelah kue dingin, potong kue menjadi 2 lapis (boleh 3 lapis). Ratakan juga bagian atas kue. Tuang simple syrup secukupnya. Lapisi dengan selai, lalu timpa dengan whipped cream.
1. Begitu juga dengan lapisan kedua.
1. Cover semua bagian kue dengan whipped cream. Ratakan agar permukaan kue rapi.
1. Buat ganache drop. (Punya saya terlalu besar sehingga kelihatan tidak rapi 😅. Maklum ini pertama kalinya membuatnya).
1. Parut DCC secukupnya di bagian atas kue.
1. Bila sudah selesai dihias, masukkan kembali ke dalam kulkas, agar whipped creamnya set dan tidak meleleh.




Demikianlah cara membuat blackforest kukus dengan homemade whipped cream yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan teruji, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
