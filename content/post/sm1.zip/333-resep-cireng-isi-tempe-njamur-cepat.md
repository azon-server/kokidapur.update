---
description: "Resep : Cireng Isi Tempe Njamur Cepat"
title: "Resep : Cireng Isi Tempe Njamur Cepat"
slug: 333-resep-cireng-isi-tempe-njamur-cepat
date: 2020-09-30T18:16:16.634Z
image: https://img-global.cpcdn.com/recipes/7098deb26ebfdab8/751x532cq70/cireng-isi-tempe-njamur-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7098deb26ebfdab8/751x532cq70/cireng-isi-tempe-njamur-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7098deb26ebfdab8/751x532cq70/cireng-isi-tempe-njamur-foto-resep-utama.jpg
author: Minerva Little
ratingvalue: 4.2
reviewcount: 11979
recipeingredient:
- " Bahan Kulit Cireng "
- "300 gr tepung tapioka"
- "1 sdm tepung terigu"
- "1 sdm tepung beras"
- "200 ml air mendidih"
- "1/2 sdt lada bubuk"
- "1 sdt garam"
- "1 sdt kaldu bubuk"
- " Bahan Isian Cireng Sambel Tempe "
- "1 papan tempe ukuran sedang"
- "250 gr jamur tiram cuci bersih suwir cincang"
- "150 gr jamur kuping cuci bersih iris cincang"
- "5 btg daun bawang bagian hijaunya saja iris"
- "3 siung bawang merah"
- "2 siung bawang putih"
- "10 buah cabe rawit merah"
- "3 buah cabe merah keriting"
- "secukupnya Gula"
- "secukupnya Garam"
- " Minyak untuk menggoreng"
- " Bahan Sambel Cocolan Bumbu Rujak "
- "5 buah cabe rawit merah"
- "1 siung bawang putih"
- "1/2 lingkaran gula merah"
- "1/4 sdt asam jawa"
- "1/4 sdt garam"
- "secukupnya Air hangat"
recipeinstructions:
- "Siapkan semua bahan-bahan."
- "Untuk isian : Goreng tempe hingga setengah kering. Kemudian uleg kasar tempe, sisihkan."
- "Ulek halus bawang merah, bawang putih, cabe rawit dan cabe merah keriting. Kemudian tumis bumbu halus hingga harum."
- "Masukkan jamur tiram dan jamur kuping, kemudian masukkan tempe yang sudah diuleg."
- "Aduk rata, bumbui dengan garam dan gula pasir secukupnya, tes rasa. Masak hingga jamur layu, terakhir tambahkan daun bawang, aduk rata sebentar. Matikan api. Sisihkan."
- "Untuk kulit cireng : Campur semua bahan kering ke dalam wadah, aduk rata dengan spatula. Kemudian tuang air mendidih, aduk rata kembali dengan spatula, biarkan selama 5-10 menit hingga agak dingin. Kemudian uleni adonan hingga tercampur rata dan kalis."
- "Bagi adonan menjadi beberapa bagian (bulatkan) sesuai selera. Kemudian pipihkan bulatan adonan."
- "Beri isian sambel tempe secukupnya, kemudian tutup hingga kedua sisinya bisa direkatkan. Pilin bagian pinggirnya agar isian tidak keluar (bisa juga menggunakan cetakan pastel). Lakukan hingga adonan kulit habis."
- "Goreng cireng dalam minyak panas (dengan api sedang) hingga bagian permukaan kulitnya kering. Angkat dan tiriskan."
- "Untuk sambal cocolan : Ulek hingga lembut semua bahan, kemudian tambahkan air hangat. Aduk rata."
- "Sajikan cireng isi dengan sambal rujak."
categories:
- Recipe
tags:
- cireng
- isi
- tempe

katakunci: cireng isi tempe 
nutrition: 241 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT55M"
recipeyield: "2"
recipecategory: Dessert

---


![Cireng Isi Tempe Njamur](https://img-global.cpcdn.com/recipes/7098deb26ebfdab8/751x532cq70/cireng-isi-tempe-njamur-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan renyah. Ciri khas makanan Indonesia cireng isi tempe njamur yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah memasak Cireng Isi Tempe Njamur untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang dapat anda buat salah satunya cireng isi tempe njamur yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep cireng isi tempe njamur tanpa harus bersusah payah.
Seperti resep Cireng Isi Tempe Njamur yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 11 langkah dan 27 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Cireng Isi Tempe Njamur:

1. Harap siapkan  Bahan Kulit Cireng :
1. Jangan lupa 300 gr tepung tapioka
1. Jangan lupa 1 sdm tepung terigu
1. Tambah 1 sdm tepung beras
1. Diperlukan 200 ml air mendidih
1. Siapkan 1/2 sdt lada bubuk
1. Tambah 1 sdt garam
1. Harap siapkan 1 sdt kaldu bubuk
1. Siapkan  Bahan Isian Cireng (Sambel Tempe) :
1. Dibutuhkan 1 papan tempe ukuran sedang
1. Jangan lupa 250 gr jamur tiram (cuci bersih, suwir, cincang)
1. Harap siapkan 150 gr jamur kuping (cuci bersih, iris, cincang)
1. Harap siapkan 5 btg daun bawang (bagian hijaunya saja, iris)
1. Dibutuhkan 3 siung bawang merah
1. Tambah 2 siung bawang putih
1. Jangan lupa 10 buah cabe rawit merah
1. Harus ada 3 buah cabe merah keriting
1. Diperlukan secukupnya Gula
1. Dibutuhkan secukupnya Garam
1. Harap siapkan  Minyak untuk menggoreng
1. Jangan lupa  Bahan Sambel Cocolan (Bumbu Rujak) :
1. Harus ada 5 buah cabe rawit merah
1. Jangan lupa 1 siung bawang putih
1. Siapkan 1/2 lingkaran gula merah
1. Harus ada 1/4 sdt asam jawa
1. Siapkan 1/4 sdt garam
1. Jangan lupa secukupnya Air hangat




<!--inarticleads2-->

##### Langkah membuat  Cireng Isi Tempe Njamur:

1. Siapkan semua bahan-bahan.
1. Untuk isian : Goreng tempe hingga setengah kering. Kemudian uleg kasar tempe, sisihkan.
1. Ulek halus bawang merah, bawang putih, cabe rawit dan cabe merah keriting. Kemudian tumis bumbu halus hingga harum.
1. Masukkan jamur tiram dan jamur kuping, kemudian masukkan tempe yang sudah diuleg.
1. Aduk rata, bumbui dengan garam dan gula pasir secukupnya, tes rasa. Masak hingga jamur layu, terakhir tambahkan daun bawang, aduk rata sebentar. Matikan api. Sisihkan.
1. Untuk kulit cireng : Campur semua bahan kering ke dalam wadah, aduk rata dengan spatula. Kemudian tuang air mendidih, aduk rata kembali dengan spatula, biarkan selama 5-10 menit hingga agak dingin. Kemudian uleni adonan hingga tercampur rata dan kalis.
1. Bagi adonan menjadi beberapa bagian (bulatkan) sesuai selera. Kemudian pipihkan bulatan adonan.
1. Beri isian sambel tempe secukupnya, kemudian tutup hingga kedua sisinya bisa direkatkan. Pilin bagian pinggirnya agar isian tidak keluar (bisa juga menggunakan cetakan pastel). Lakukan hingga adonan kulit habis.
1. Goreng cireng dalam minyak panas (dengan api sedang) hingga bagian permukaan kulitnya kering. Angkat dan tiriskan.
1. Untuk sambal cocolan : Ulek hingga lembut semua bahan, kemudian tambahkan air hangat. Aduk rata.
1. Sajikan cireng isi dengan sambal rujak.




Demikianlah cara membuat cireng isi tempe njamur yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat simple dan cepat, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
