---
description: "Cara untuk membuat Cireng Nasi Homemade"
title: "Cara untuk membuat Cireng Nasi Homemade"
slug: 408-cara-untuk-membuat-cireng-nasi-homemade
date: 2020-12-03T14:33:41.437Z
image: https://img-global.cpcdn.com/recipes/2cb33161b8effc5a/751x532cq70/cireng-nasi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2cb33161b8effc5a/751x532cq70/cireng-nasi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2cb33161b8effc5a/751x532cq70/cireng-nasi-foto-resep-utama.jpg
author: Catherine Bennett
ratingvalue: 4.8
reviewcount: 22090
recipeingredient:
- "1 centong nasi"
- "1 sdm munjung sagu untuk disirami air panas"
- "3 sdm sagu untuk diuleni"
- "1/2 sdt garam"
- "1/2 sdt kaldu bubuk"
- "1 helai daun bawang iris halus"
- "100 ml air panas"
- "1/4 sdt merica bubuk"
- " Sambal rujak "
- "3 sdm gula jawa sisir sy 1 balok kecil"
- "3 buah cabai rawit merah sesuai selera"
- "1/4 sdt terasi yang sudah di sangraibakar"
- "Sejumput garam"
- "1 sdt air asam jawa"
recipeinstructions:
- "Siapkan nasi, lalu beri 1 sdm tepung sagu. Siram dengan air panas. Beri 2 sdm sagu."
- "Aduk cepat dan beri daun bawang, garam, merica bubuk dan kaldu bubuk. Aduk2 rata hingga agak padat dan bisa dibentuk. (Bisa tambahkan sagu lagi jika kurang padat). Ambil sedikit adonan lalu bulatkan dan pipihkan."
- "Dalam keadaan agak lengket balurkan ke atas sisa sagu dan tempatkan di wadah. Simpan dalam chiller agar set sebelum di goreng."
- "Goreng dalam minyak dengan panas sedang hingga agak kecoklatan tanda sudah garing. Lalu angkat dan tiriskan."
- "Sambal rujak : haluskan cabai, terasi dan gula. Tambahkan garam."
- "Beri air asam jawa lalu aduk rata. Koreksi rasa dan sajikan bersama cireng nasi."
categories:
- Recipe
tags:
- cireng
- nasi

katakunci: cireng nasi 
nutrition: 254 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dinner

---


![Cireng Nasi](https://img-global.cpcdn.com/recipes/2cb33161b8effc5a/751x532cq70/cireng-nasi-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga empuk. Karasteristik kuliner Indonesia cireng nasi yang penuh dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Cireng Nasi untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang dapat anda coba salah satunya cireng nasi yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya saat ini kamu bisa dengan gampang menemukan resep cireng nasi tanpa harus bersusah payah.
Seperti resep Cireng Nasi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 14 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Cireng Nasi:

1. Dibutuhkan 1 centong nasi
1. Harus ada 1 sdm munjung sagu (untuk disirami air panas)
1. Tambah 3 sdm sagu untuk diuleni
1. Tambah 1/2 sdt garam
1. Siapkan 1/2 sdt kaldu bubuk
1. Harus ada 1 helai daun bawang, iris halus
1. Harap siapkan 100 ml air panas
1. Diperlukan 1/4 sdt merica bubuk
1. Siapkan  Sambal rujak :
1. Harap siapkan 3 sdm gula jawa sisir (sy 1 balok kecil)
1. Dibutuhkan 3 buah cabai rawit merah (sesuai selera)
1. Tambah 1/4 sdt terasi yang sudah di sangrai/bakar
1. Tambah Sejumput garam
1. Dibutuhkan 1 sdt air asam jawa




<!--inarticleads2-->

##### Instruksi membuat  Cireng Nasi:

1. Siapkan nasi, lalu beri 1 sdm tepung sagu. Siram dengan air panas. Beri 2 sdm sagu.
1. Aduk cepat dan beri daun bawang, garam, merica bubuk dan kaldu bubuk. Aduk2 rata hingga agak padat dan bisa dibentuk. (Bisa tambahkan sagu lagi jika kurang padat). Ambil sedikit adonan lalu bulatkan dan pipihkan.
1. Dalam keadaan agak lengket balurkan ke atas sisa sagu dan tempatkan di wadah. Simpan dalam chiller agar set sebelum di goreng.
1. Goreng dalam minyak dengan panas sedang hingga agak kecoklatan tanda sudah garing. Lalu angkat dan tiriskan.
1. Sambal rujak : haluskan cabai, terasi dan gula. Tambahkan garam.
1. Beri air asam jawa lalu aduk rata. Koreksi rasa dan sajikan bersama cireng nasi.




Demikianlah cara membuat cireng nasi yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan terbukti, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
