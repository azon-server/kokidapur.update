---
description: "Steps untuk membuat Whipped cream Strawberry Tart Cepat"
title: "Steps untuk membuat Whipped cream Strawberry Tart Cepat"
slug: 191-steps-untuk-membuat-whipped-cream-strawberry-tart-cepat
date: 2020-10-10T01:22:12.773Z
image: https://img-global.cpcdn.com/recipes/ec4c5b4980f7f687/751x532cq70/whipped-cream-strawberry-tart-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ec4c5b4980f7f687/751x532cq70/whipped-cream-strawberry-tart-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ec4c5b4980f7f687/751x532cq70/whipped-cream-strawberry-tart-foto-resep-utama.jpg
author: Oscar Lopez
ratingvalue: 4.2
reviewcount: 22441
recipeingredient:
- " Untuk cakenya "
- "6 butir telur"
- "200 gr gula pasir"
- "200 gr selfraising flour"
- "1 sdt penuh Baking Powder"
- "40 gr mentega tawar"
- "1/2 sdt esens vanila"
- "Sejumput garam"
- " Untuk olesan dan toppingnya "
- "1 liter whipping cream merk apa saja"
- "5 bungkus klopfix penguat struktur whipped cream"
- "500 gr strawberry segar"
- "15 gr vanili bubuk"
- "1 batang vanili"
- "120 gr gula bubuk"
recipeinstructions:
- "Kocok telur sampai merata dulu dg mixer kecepatan rendah, tambahkan gula sedikit2, mixer jalan terus kemudian naikkan kecepatan mixer, kocok adonan sampai mengembang dan creamy."
- "Cairkan mentega, kemudian masukkan kedalam adonan telur dan gula, aduk lipat dengan spatula, tambahkan esens vanila garam dan baking powder, aduk sampai menyatu."
- "Ayak terigu dan tambahkan dalam adonan. Aduk rata. Pastikan semua adonan betul2 menyatu dan tercampur rata. Adonan akan sedikit turun, karena sudah di bebani dg terigu ya.. jadi no worries..."
- "Olesi loyang dengan mentega dan taburi dg terigu. Saya pakai loyang springvorm yg diameternya 18cm dan tingginya 9cm."
- "Tuang adonan kedalam loyang, ratakan atasnya, banting2 sebentar supaya udaranya keluar dan cake tidak bolong2."
- "Panggang di suhu 180°C selama kurang lebih 40 menit.(kenali oven masing2 yaaa)"
- "Sementara nunggu si kue matang, kita buat whipped creamnya."
- "Kocok dalam mangkok besar terpisah whipped cream gula bubuk klopfix vanili bubuk dan isi batangan dg kecapatan tinggi sampai cream benar2 kaku dan berjejak."
- "Tutup mangkok dg plastic foil dan masukan kedalam kulkas."
- "Setelah kue matang, keluarkan dari oven, untuk memastikan apakah kue sudah matang sempurna, gunakan tusuk gigi."
- "Dinginkan kue di rak. Pastikan kue sudah benar2 dingin, kemudian potong kue menjadi 3 bagian."
- "Olesi dasar potongan pertama dg sedikit air gula. Tujuannya adl supaya cream yg akan di oleskan bisa melekat didasar kue. Kemudian oleskan selai starwberry ratakan, kemudian diikuti dg whipped cream."
- "Timpa dg potongan kue kedua. Kemudian olesi lagi potongan kue kedua dg air gula, kemudian selai strawberry terakhir dg whipped cream. Kemudian timpa dg potongan kue terakhir."
- "Fase yg terakhir adl pengolesan whipped cream ke seluruh permukaan kue. Sampai semua tertutup cream. Kemudian hias permukaan dan samping kue dengan strawberry segar."
- "Kue siap di sajikan. Jika udara sedang panas, lebih baik kue segera di simpan ke dalam kulkas dulu sebelum di potong dan di nikmati. Supaya whipped cream tidak cepat meleleh."
- "Tips: iris iris dulu strawberry sebelum mulai membuat kue, disimpan di kulkas. Supaya memudahkan pekerjaan."
- "Selamat mencoba yaa🙏"
categories:
- Recipe
tags:
- whipped
- cream
- strawberry

katakunci: whipped cream strawberry 
nutrition: 161 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Dinner

---


![Whipped cream Strawberry Tart](https://img-global.cpcdn.com/recipes/ec4c5b4980f7f687/751x532cq70/whipped-cream-strawberry-tart-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau empuk. Karasteristik kuliner Nusantara whipped cream strawberry tart yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Whipped cream Strawberry Tart untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang dapat anda praktekkan salah satunya whipped cream strawberry tart yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep whipped cream strawberry tart tanpa harus bersusah payah.
Seperti resep Whipped cream Strawberry Tart yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 17 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Whipped cream Strawberry Tart:

1. Harap siapkan  Untuk cakenya :
1. Diperlukan 6 butir telur
1. Jangan lupa 200 gr gula pasir
1. Harap siapkan 200 gr selfraising flour
1. Jangan lupa 1 sdt penuh Baking Powder
1. Diperlukan 40 gr mentega tawar
1. Harap siapkan 1/2 sdt esens vanila
1. Diperlukan Sejumput garam
1. Harap siapkan  Untuk olesan dan toppingnya :
1. Harus ada 1 liter whipping cream merk apa saja
1. Dibutuhkan 5 bungkus klopfix (penguat struktur whipped cream)
1. Tambah 500 gr strawberry segar
1. Siapkan 15 gr vanili bubuk
1. Tambah 1 batang vanili
1. Jangan lupa 120 gr gula bubuk




<!--inarticleads2-->

##### Langkah membuat  Whipped cream Strawberry Tart:

1. Kocok telur sampai merata dulu dg mixer kecepatan rendah, tambahkan gula sedikit2, mixer jalan terus kemudian naikkan kecepatan mixer, kocok adonan sampai mengembang dan creamy.
1. Cairkan mentega, kemudian masukkan kedalam adonan telur dan gula, aduk lipat dengan spatula, tambahkan esens vanila garam dan baking powder, aduk sampai menyatu.
1. Ayak terigu dan tambahkan dalam adonan. Aduk rata. Pastikan semua adonan betul2 menyatu dan tercampur rata. Adonan akan sedikit turun, karena sudah di bebani dg terigu ya.. jadi no worries...
1. Olesi loyang dengan mentega dan taburi dg terigu. Saya pakai loyang springvorm yg diameternya 18cm dan tingginya 9cm.
1. Tuang adonan kedalam loyang, ratakan atasnya, banting2 sebentar supaya udaranya keluar dan cake tidak bolong2.
1. Panggang di suhu 180°C selama kurang lebih 40 menit.(kenali oven masing2 yaaa)
1. Sementara nunggu si kue matang, kita buat whipped creamnya.
1. Kocok dalam mangkok besar terpisah whipped cream gula bubuk klopfix vanili bubuk dan isi batangan dg kecapatan tinggi sampai cream benar2 kaku dan berjejak.
1. Tutup mangkok dg plastic foil dan masukan kedalam kulkas.
1. Setelah kue matang, keluarkan dari oven, untuk memastikan apakah kue sudah matang sempurna, gunakan tusuk gigi.
1. Dinginkan kue di rak. Pastikan kue sudah benar2 dingin, kemudian potong kue menjadi 3 bagian.
1. Olesi dasar potongan pertama dg sedikit air gula. Tujuannya adl supaya cream yg akan di oleskan bisa melekat didasar kue. Kemudian oleskan selai starwberry ratakan, kemudian diikuti dg whipped cream.
1. Timpa dg potongan kue kedua. Kemudian olesi lagi potongan kue kedua dg air gula, kemudian selai strawberry terakhir dg whipped cream. Kemudian timpa dg potongan kue terakhir.
1. Fase yg terakhir adl pengolesan whipped cream ke seluruh permukaan kue. Sampai semua tertutup cream. Kemudian hias permukaan dan samping kue dengan strawberry segar.
1. Kue siap di sajikan. Jika udara sedang panas, lebih baik kue segera di simpan ke dalam kulkas dulu sebelum di potong dan di nikmati. Supaya whipped cream tidak cepat meleleh.
1. Tips: iris iris dulu strawberry sebelum mulai membuat kue, disimpan di kulkas. Supaya memudahkan pekerjaan.
1. Selamat mencoba yaa🙏




Demikianlah cara membuat whipped cream strawberry tart yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan teruji, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
