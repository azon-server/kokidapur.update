---
description: "Cara singkat untuk membuat Es krim ubi ungu (Tanpa whipped cream tanpa SP) terupdate"
title: "Cara singkat untuk membuat Es krim ubi ungu (Tanpa whipped cream tanpa SP) terupdate"
slug: 95-cara-singkat-untuk-membuat-es-krim-ubi-ungu-tanpa-whipped-cream-tanpa-sp-terupdate
date: 2021-02-03T10:06:46.234Z
image: https://img-global.cpcdn.com/recipes/f8803b9f2111d1b7/751x532cq70/es-krim-ubi-ungu-tanpa-whipped-cream-tanpa-sp-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f8803b9f2111d1b7/751x532cq70/es-krim-ubi-ungu-tanpa-whipped-cream-tanpa-sp-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f8803b9f2111d1b7/751x532cq70/es-krim-ubi-ungu-tanpa-whipped-cream-tanpa-sp-foto-resep-utama.jpg
author: Anne Morton
ratingvalue: 5
reviewcount: 48896
recipeingredient:
- "300 gr ubi ungu resep asli 250gr"
- "400 ml susu full cream"
- "100 ml air putih"
- "40 gr gula pasir"
- "60 gr SKM"
- "1 sachet santan bubuk"
- "1/2 sdt garam"
- " Topping"
- " Nata de coco"
- " Springkel"
recipeinstructions:
- "Cuci bersih dan sikat kulit ubi. Kukus selama 25 menit (kulit ubi dikupas setelah dikukus. Agar warna ubi tetap terang). Setelah dikukus dinginkan baru kupas ubi. Siapkan blender masukkan ubi, susu,air, gula, SKM,santan bubuk,garam blender hingga halus."
- "Masukkan bahan es ke dalam frezzer sekitar 3-4 jam. Setelah itu mixer kembali hingga kristal es hancur dan tekstur lembut. Masukkan kembali kedalam frezzer selama 1 jam. Setelah 1 jam mixer kembali (ulangi langkah ini 3-4 x sampai kelembutan yang diinginkan,saya 3x mixer)"
- "Setalah masuk freezer 1 jam, kerok es krim ubi. Tambahkan topping sesuai selera (saya nata de coco dan springkel). Es krim ini lembut banget...wajib coba."
categories:
- Recipe
tags:
- es
- krim
- ubi

katakunci: es krim ubi 
nutrition: 145 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Lunch

---


![Es krim ubi ungu (Tanpa whipped cream tanpa SP)](https://img-global.cpcdn.com/recipes/f8803b9f2111d1b7/751x532cq70/es-krim-ubi-ungu-tanpa-whipped-cream-tanpa-sp-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti es krim ubi ungu (tanpa whipped cream tanpa sp) yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan keistimewahan yang merupakan keragaman Kita

Keharmonisan keluarga bisa ditemukan dengan cara mudah. Salah satunya adalah memasak Es krim ubi ungu (Tanpa whipped cream tanpa SP) untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang dapat anda contoh salah satunya es krim ubi ungu (tanpa whipped cream tanpa sp) yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep es krim ubi ungu (tanpa whipped cream tanpa sp) tanpa harus bersusah payah.
Seperti resep Es krim ubi ungu (Tanpa whipped cream tanpa SP) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 10 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Es krim ubi ungu (Tanpa whipped cream tanpa SP):

1. Dibutuhkan 300 gr ubi ungu (resep asli 250gr)
1. Tambah 400 ml susu full cream
1. Harap siapkan 100 ml air putih
1. Tambah 40 gr gula pasir
1. Siapkan 60 gr SKM
1. Harus ada 1 sachet santan bubuk
1. Diperlukan 1/2 sdt garam
1. Harap siapkan  Topping
1. Harus ada  Nata de coco
1. Harap siapkan  Springkel




<!--inarticleads2-->

##### Instruksi membuat  Es krim ubi ungu (Tanpa whipped cream tanpa SP):

1. Cuci bersih dan sikat kulit ubi. Kukus selama 25 menit (kulit ubi dikupas setelah dikukus. Agar warna ubi tetap terang). Setelah dikukus dinginkan baru kupas ubi. Siapkan blender masukkan ubi, susu,air, gula, SKM,santan bubuk,garam blender hingga halus.
1. Masukkan bahan es ke dalam frezzer sekitar 3-4 jam. Setelah itu mixer kembali hingga kristal es hancur dan tekstur lembut. Masukkan kembali kedalam frezzer selama 1 jam. Setelah 1 jam mixer kembali (ulangi langkah ini 3-4 x sampai kelembutan yang diinginkan,saya 3x mixer)
1. Setalah masuk freezer 1 jam, kerok es krim ubi. Tambahkan topping sesuai selera (saya nata de coco dan springkel). Es krim ini lembut banget...wajib coba.




Demikianlah cara membuat es krim ubi ungu (tanpa whipped cream tanpa sp) yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan teruji, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
