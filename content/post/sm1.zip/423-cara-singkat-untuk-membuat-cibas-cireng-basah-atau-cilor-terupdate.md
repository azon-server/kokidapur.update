---
description: "Cara singkat untuk membuat Cibas (cireng basah) atau Cilor terupdate"
title: "Cara singkat untuk membuat Cibas (cireng basah) atau Cilor terupdate"
slug: 423-cara-singkat-untuk-membuat-cibas-cireng-basah-atau-cilor-terupdate
date: 2020-09-24T20:40:33.199Z
image: https://img-global.cpcdn.com/recipes/276fbbd2af9760be/751x532cq70/cibas-cireng-basah-atau-cilor-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/276fbbd2af9760be/751x532cq70/cibas-cireng-basah-atau-cilor-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/276fbbd2af9760be/751x532cq70/cibas-cireng-basah-atau-cilor-foto-resep-utama.jpg
author: Louise Bradley
ratingvalue: 4.2
reviewcount: 28707
recipeingredient:
- "1 gelas tepung kanjisaguaci"
- "1 gayung air"
- "1 butir telur"
- " Bumbu balado merk Antaka"
- " Cabe bubuk merk Aida"
- " Royco"
recipeinstructions:
- "Masak air sampai mendidih, kemudian kecilkan api. Ambil beberapa sendok untuk menguleni aci."
- "Campurkan tepung kanji/sagu/aci dengan air panas tadi, uleni sampai bisa dibentuk."
- "Bentuk adonan menjadi kotak-kotak (kalo saya langsung dipotek-potek aja pake tangan biar cepet)."
- "Setelah dibentuk langsung rebus ke dalam air panas yang tadi. Besarkan apinya sedikit."
- "Jika cibas sudah mengapung, matikan kompor, lalu angkat, buang air rebusan, dan tiriskan."
- "Panaskan wajan, beri sedikit minyak, kemudian siapkan bahan dan bumbu taburan."
- "Kocok telur, lalu masukkan ke wajan, kemudian masukkan cibas."
- "Setelah itu beri bumbu balado, cabe bubuk, dan Royco secukupnya."
- "Aduk-aduk sampai semua bumbu tercampur, koreksi rasa."
- "Jika bumbu sudah tercampur dan meresap, matikan kompor, kemudian hidangkan selagi hangat."
categories:
- Recipe
tags:
- cibas
- cireng
- basah

katakunci: cibas cireng basah 
nutrition: 129 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Dessert

---


![Cibas (cireng basah) atau Cilor](https://img-global.cpcdn.com/recipes/276fbbd2af9760be/751x532cq70/cibas-cireng-basah-atau-cilor-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang setidaknya kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti cibas (cireng basah) atau cilor yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Indonesia



Kehangatan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah memasak Cibas (cireng basah) atau Cilor untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang bisa anda coba salah satunya cibas (cireng basah) atau cilor yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep cibas (cireng basah) atau cilor tanpa harus bersusah payah.
Berikut ini resep Cibas (cireng basah) atau Cilor yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Cibas (cireng basah) atau Cilor:

1. Jangan lupa 1 gelas tepung kanji/sagu/aci
1. Harus ada 1 gayung air
1. Tambah 1 butir telur
1. Harus ada  Bumbu balado (merk Antaka)
1. Tambah  Cabe bubuk (merk Aida)
1. Diperlukan  Royco




<!--inarticleads2-->

##### Langkah membuat  Cibas (cireng basah) atau Cilor:

1. Masak air sampai mendidih, kemudian kecilkan api. Ambil beberapa sendok untuk menguleni aci.
1. Campurkan tepung kanji/sagu/aci dengan air panas tadi, uleni sampai bisa dibentuk.
1. Bentuk adonan menjadi kotak-kotak (kalo saya langsung dipotek-potek aja pake tangan biar cepet).
1. Setelah dibentuk langsung rebus ke dalam air panas yang tadi. Besarkan apinya sedikit.
1. Jika cibas sudah mengapung, matikan kompor, lalu angkat, buang air rebusan, dan tiriskan.
1. Panaskan wajan, beri sedikit minyak, kemudian siapkan bahan dan bumbu taburan.
1. Kocok telur, lalu masukkan ke wajan, kemudian masukkan cibas.
1. Setelah itu beri bumbu balado, cabe bubuk, dan Royco secukupnya.
1. Aduk-aduk sampai semua bumbu tercampur, koreksi rasa.
1. Jika bumbu sudah tercampur dan meresap, matikan kompor, kemudian hidangkan selagi hangat.




Demikianlah cara membuat cibas (cireng basah) atau cilor yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan teruji, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
