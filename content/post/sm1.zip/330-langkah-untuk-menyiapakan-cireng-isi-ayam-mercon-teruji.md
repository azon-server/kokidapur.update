---
description: "Langkah untuk menyiapakan Cireng Isi Ayam Mercon Teruji"
title: "Langkah untuk menyiapakan Cireng Isi Ayam Mercon Teruji"
slug: 330-langkah-untuk-menyiapakan-cireng-isi-ayam-mercon-teruji
date: 2020-12-07T09:04:03.212Z
image: https://img-global.cpcdn.com/recipes/b4266e4bb74d2e9e/751x532cq70/cireng-isi-ayam-mercon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b4266e4bb74d2e9e/751x532cq70/cireng-isi-ayam-mercon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b4266e4bb74d2e9e/751x532cq70/cireng-isi-ayam-mercon-foto-resep-utama.jpg
author: Eugenia Foster
ratingvalue: 4.2
reviewcount: 41484
recipeingredient:
- " Bahan cireng "
- "250 gr tepung tapiokaaci"
- "8 sdm tepung terigu aci  terigu  31"
- "1 sachet kaldu bubuk"
- "250 ml air mendidih"
- " Bahan isian "
- "250 gr ayam"
- "6 siung bawang merah"
- "2 siung bawang putih"
- "2 butir kemiri"
- "1 cm jahe"
- "1 cm kunyit"
- "sejumput ketumbar"
- "sejumput lada"
- "secukupnya cabe merah dan cabe rawit"
- "secukupnya garam"
- "secukupnya gula"
- "sedikit air"
recipeinstructions:
- "Siram ayam dengan air panas, lalu bersihkan dan berikan sedikit perasan lemon/jeruk nipis. Rebus sampai matang, tunggu hingga dingin lalu suwir-suwir"
- "Haluskan bumbu untuk isian cireng"
- "Tumis bumbu hingga harum, kemudian masukkan ayam suwir. Kemudian beri sedikit air, gula, dan garam. Biarkan sampai air surut dan koreksi rasa"
- "Campur aci, terigu, kaldu bubuk, lada dengan air panas yang baru mendidih. Uleni sampai adonan kalis"
- "Beri alas dengan sedikit aci. Ambil adonan sedikit, bulatkan lalu pipihkan. Ambil isian lalu rekatkan kembali. Jika ingin disimpan di kulkas sebaiknya jangan terlalu rapat dan diberi jarak agar tidak saling menempel"
- "Goreng sampai warna kecoklatan dan cireng siap dihidangkan selagi hangat"
categories:
- Recipe
tags:
- cireng
- isi
- ayam

katakunci: cireng isi ayam 
nutrition: 241 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT50M"
recipeyield: "3"
recipecategory: Lunch

---


![Cireng Isi Ayam Mercon](https://img-global.cpcdn.com/recipes/b4266e4bb74d2e9e/751x532cq70/cireng-isi-ayam-mercon-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas atau empuk. Karasteristik makanan Nusantara cireng isi ayam mercon yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Cireng Isi Ayam Mercon untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi resep yang dapat anda praktekkan salah satunya cireng isi ayam mercon yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep cireng isi ayam mercon tanpa harus bersusah payah.
Berikut ini resep Cireng Isi Ayam Mercon yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Cireng Isi Ayam Mercon:

1. Diperlukan  Bahan cireng :
1. Siapkan 250 gr tepung tapioka/aci
1. Diperlukan 8 sdm tepung terigu (aci : terigu = 3:1)
1. Harap siapkan 1 sachet kaldu bubuk
1. Tambah 250 ml air mendidih
1. Harus ada  Bahan isian :
1. Jangan lupa 250 gr ayam
1. Jangan lupa 6 siung bawang merah
1. Diperlukan 2 siung bawang putih
1. Tambah 2 butir kemiri
1. Harap siapkan 1 cm jahe
1. Diperlukan 1 cm kunyit
1. Jangan lupa sejumput ketumbar
1. Dibutuhkan sejumput lada
1. Harap siapkan secukupnya cabe merah dan cabe rawit
1. Dibutuhkan secukupnya garam
1. Tambah secukupnya gula
1. Harap siapkan sedikit air




<!--inarticleads2-->

##### Cara membuat  Cireng Isi Ayam Mercon:

1. Siram ayam dengan air panas, lalu bersihkan dan berikan sedikit perasan lemon/jeruk nipis. Rebus sampai matang, tunggu hingga dingin lalu suwir-suwir
1. Haluskan bumbu untuk isian cireng
1. Tumis bumbu hingga harum, kemudian masukkan ayam suwir. Kemudian beri sedikit air, gula, dan garam. Biarkan sampai air surut dan koreksi rasa
1. Campur aci, terigu, kaldu bubuk, lada dengan air panas yang baru mendidih. Uleni sampai adonan kalis
1. Beri alas dengan sedikit aci. Ambil adonan sedikit, bulatkan lalu pipihkan. Ambil isian lalu rekatkan kembali. Jika ingin disimpan di kulkas sebaiknya jangan terlalu rapat dan diberi jarak agar tidak saling menempel
1. Goreng sampai warna kecoklatan dan cireng siap dihidangkan selagi hangat




Demikianlah cara membuat cireng isi ayam mercon yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
