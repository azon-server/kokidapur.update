---
description: "Cara untuk membuat 34. Layered Lemon Tart (No Bake) ala Chef Juni Napitupulu terupdate"
title: "Cara untuk membuat 34. Layered Lemon Tart (No Bake) ala Chef Juni Napitupulu terupdate"
slug: 70-cara-untuk-membuat-34-layered-lemon-tart-no-bake-ala-chef-juni-napitupulu-terupdate
date: 2021-01-12T19:29:33.225Z
image: https://img-global.cpcdn.com/recipes/ef77c09ab9e89e85/751x532cq70/34-layered-lemon-tart-no-bake-ala-chef-juni-napitupulu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ef77c09ab9e89e85/751x532cq70/34-layered-lemon-tart-no-bake-ala-chef-juni-napitupulu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ef77c09ab9e89e85/751x532cq70/34-layered-lemon-tart-no-bake-ala-chef-juni-napitupulu-foto-resep-utama.jpg
author: Lizzie Sharp
ratingvalue: 5
reviewcount: 37906
recipeingredient:
- " Bahan crust "
- "120 gr biskuit Marie Regal regal bungkus kecil"
- "80 gr mentega leleh aku margarin forvita"
- " Custard filling ada dua resep"
- " Bahan 1 "
- "50 ml susu cair"
- "2 butir kuning telur"
- "30 gula castor aku gula pasir di blender"
- "30 custard powder aku pakai tepung maezena"
- " Bahan 2 "
- "200 ml susu cair"
- "1 sdt pasta vanila vanilli bubuk 14 sdt"
- "30 gula castor aku gula pasir di blender"
- "15 gr butter aku margarin forvita dinginsuhu udara"
- "100 ml whipped Cream aku gagal buat yg homemade"
- " Whipped Cream aku ganti butter Cream "
- "2 sdm Margarin aku forvita kocok sampai putih"
- "1/2 scht SKM putih"
- " Lemon jelly "
- "100 ml air"
- "2 sdm sirup lemon sdh manis"
- "3 tetes pewarna makanan kuning"
- "2 sdt agar agar bubuk"
- "  buah Lemon dan anggur untuk hiasan di atasnya"
recipeinstructions:
- "Siapkan bahan-bahannya, lelehkan margarin lalu hancurkan biskuit (aku tdk halus bgt) lalu tuang margarin ke biskuit dan aduk rata"
- "Masukkan biskuit yg td sdh tercampur margarin leleh ke loyang, tekan tekan dan pastikan rata ya lalu masukkan kulkas agar kokoh (aku tdk ada loyang pie atau loyang bongkar pasang) jd pakai loyang yg ada dirumah. Selanjutnya masukkan bahan custard filling ke mangkok (lihat bahan 1 nya di atas ya) aduk rata pakai wisk dan sisihkan dulu"
- "Siapkan bahan custard filling (bahan 2) ke panci/teplon masak sampai susu mendidih (blubuk blubuk tengahnya) lalu tuang perlahan ke bahan 1 td sampai tuntas sambil di gerakan wisknya di mangkok agar tdk ada gumpalan bahan 1 nya lalu masukkan kembali ke teplon dan masak di api kecil sampai mulai solid dan matikan kompor lalu masukkan Margarin dan aduk rata."
- "Jika sdh tercampur simpan di wadah lalu tutup dgn plastik wrap (aku plastik kiloan yg di gunting) sampai menempel ke bagian atas Custard nya dan masukkan kulkas jika sdh tdk panas."
- "Siapkan bahan lemon jelly (lihat resepnya di atas) aku pakai sirup lemon yg sdh manis, kalo pakai buah tambahkan gula ya sesuai selera lalu masak sampai mendidih"
- "Lemon jelly di tuang ke piring ceper ya seperti ini dan diamkan sampai set."
- "Whipped Cream aku buat cuma gagal dan akhirnya putar haluan jd butter Cream pakai Margarin forvita dan susu kental manis (SKM) putih. Takarannya lihat resep di atas ya. Caranya aduk margarin dgn alat kocok sampai berwarna pucat dan kental lalu masukkan SKM putih lalu kocok lagi."
- "Cara membuat layernya dgn step step lagi ya 🥳"
- "Custard filling keluarkan dr kulkas dan campur dgn butter Cream/whipped Cream sampai rata (warna akan lebih light) lalu masukkan 1/3 nya ke plastik segitiga (aku plastik putih yg ukuran seprapat) lalu gunting ujungnya dan mulai di pencet dgn cara mengelilingi biskuit dlm loyang lalu ratakan dgn spatula dan letakkan lemon jelly lalu masukkan lagi custard sisanya dan di rapihkan dgn spatula atau pisau. Punyaku atasnya jelly susu (awalannya mau buat whipped Cream cuma gagal jd aku kasih ager ager"
- "Harusnya biskuit ini nempel dan kokoh cuma aku kurang margarin lelehnya (hanya 40 gr saja waktu buat, aku lupa) dan akan lebih bagus lagi jika dimakan esok hari Karena sdh dingin jd lebih kencang dan kuat tartnya. Mohon maaf punyaku ambyar Karena alasan td di atas"
categories:
- Recipe
tags:
- 34
- layered
- lemon

katakunci: 34 layered lemon 
nutrition: 169 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dinner

---


![34. Layered Lemon Tart (No Bake) ala Chef Juni Napitupulu](https://img-global.cpcdn.com/recipes/ef77c09ab9e89e85/751x532cq70/34-layered-lemon-tart-no-bake-ala-chef-juni-napitupulu-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti 34. layered lemon tart (no bake) ala chef juni napitupulu yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa ciri khas yang merupakan keragaman Kita



Keharmonisan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah memasak 34. Layered Lemon Tart (No Bake) ala Chef Juni Napitupulu untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang bisa anda contoh salah satunya 34. layered lemon tart (no bake) ala chef juni napitupulu yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep 34. layered lemon tart (no bake) ala chef juni napitupulu tanpa harus bersusah payah.
Berikut ini resep 34. Layered Lemon Tart (No Bake) ala Chef Juni Napitupulu yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 10 langkah dan 24 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 34. Layered Lemon Tart (No Bake) ala Chef Juni Napitupulu:

1. Siapkan  🟡Bahan crust :
1. Harus ada 120 gr biskuit Marie Regal (regal bungkus kecil)
1. Tambah 80 gr mentega leleh (aku margarin forvita)
1. Jangan lupa  🟡Custard filling (ada dua resep)
1. Siapkan  🔺Bahan 1 :
1. Harap siapkan 50 ml susu cair
1. Dibutuhkan 2 butir kuning telur
1. Tambah 30 gula castor (aku gula pasir di blender)
1. Siapkan 30 custard powder (aku pakai tepung maezena)
1. Tambah  🔺Bahan 2 :
1. Harus ada 200 ml susu cair
1. Jangan lupa 1 sdt pasta vanila (vanilli bubuk 1/4 sdt)
1. Dibutuhkan 30 gula castor (aku gula pasir di blender)
1. Tambah 15 gr butter (aku margarin forvita dingin/suhu udara)
1. Siapkan 100 ml whipped Cream (aku gagal buat yg homemade)
1. Siapkan  🟡Whipped Cream aku ganti butter Cream :
1. Harap siapkan 2 sdm Margarin (aku forvita), kocok sampai putih
1. Jangan lupa 1/2 scht SKM putih
1. Harus ada  🟡Lemon jelly :
1. Tambah 100 ml air
1. Tambah 2 sdm sirup lemon (sdh manis)
1. Diperlukan 3 tetes pewarna makanan kuning
1. Jangan lupa 2 sdt agar agar bubuk
1. Harus ada  🟡 buah Lemon dan anggur untuk hiasan di atasnya




<!--inarticleads2-->

##### Cara membuat  34. Layered Lemon Tart (No Bake) ala Chef Juni Napitupulu:

1. Siapkan bahan-bahannya, lelehkan margarin lalu hancurkan biskuit (aku tdk halus bgt) lalu tuang margarin ke biskuit dan aduk rata
1. Masukkan biskuit yg td sdh tercampur margarin leleh ke loyang, tekan tekan dan pastikan rata ya lalu masukkan kulkas agar kokoh (aku tdk ada loyang pie atau loyang bongkar pasang) jd pakai loyang yg ada dirumah. Selanjutnya masukkan bahan custard filling ke mangkok (lihat bahan 1 nya di atas ya) aduk rata pakai wisk dan sisihkan dulu
1. Siapkan bahan custard filling (bahan 2) ke panci/teplon masak sampai susu mendidih (blubuk blubuk tengahnya) lalu tuang perlahan ke bahan 1 td sampai tuntas sambil di gerakan wisknya di mangkok agar tdk ada gumpalan bahan 1 nya lalu masukkan kembali ke teplon dan masak di api kecil sampai mulai solid dan matikan kompor lalu masukkan Margarin dan aduk rata.
1. Jika sdh tercampur simpan di wadah lalu tutup dgn plastik wrap (aku plastik kiloan yg di gunting) sampai menempel ke bagian atas Custard nya dan masukkan kulkas jika sdh tdk panas.
1. Siapkan bahan lemon jelly (lihat resepnya di atas) aku pakai sirup lemon yg sdh manis, kalo pakai buah tambahkan gula ya sesuai selera lalu masak sampai mendidih
1. Lemon jelly di tuang ke piring ceper ya seperti ini dan diamkan sampai set.
1. Whipped Cream aku buat cuma gagal dan akhirnya putar haluan jd butter Cream pakai Margarin forvita dan susu kental manis (SKM) putih. Takarannya lihat resep di atas ya. Caranya aduk margarin dgn alat kocok sampai berwarna pucat dan kental lalu masukkan SKM putih lalu kocok lagi.
1. Cara membuat layernya dgn step step lagi ya 🥳
1. Custard filling keluarkan dr kulkas dan campur dgn butter Cream/whipped Cream sampai rata (warna akan lebih light) lalu masukkan 1/3 nya ke plastik segitiga (aku plastik putih yg ukuran seprapat) lalu gunting ujungnya dan mulai di pencet dgn cara mengelilingi biskuit dlm loyang lalu ratakan dgn spatula dan letakkan lemon jelly lalu masukkan lagi custard sisanya dan di rapihkan dgn spatula atau pisau. Punyaku atasnya jelly susu (awalannya mau buat whipped Cream cuma gagal jd aku kasih ager ager
1. Harusnya biskuit ini nempel dan kokoh cuma aku kurang margarin lelehnya (hanya 40 gr saja waktu buat, aku lupa) dan akan lebih bagus lagi jika dimakan esok hari Karena sdh dingin jd lebih kencang dan kuat tartnya. Mohon maaf punyaku ambyar Karena alasan td di atas




Demikianlah cara membuat 34. layered lemon tart (no bake) ala chef juni napitupulu yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
