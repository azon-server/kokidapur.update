---
description: "Cara untuk membuat Layered Strawberry Tart (No Bake) Cepat"
title: "Cara untuk membuat Layered Strawberry Tart (No Bake) Cepat"
slug: 63-cara-untuk-membuat-layered-strawberry-tart-no-bake-cepat
date: 2020-09-21T17:51:25.722Z
image: https://img-global.cpcdn.com/recipes/815a4655d75c8126/751x532cq70/layered-strawberry-tart-no-bake-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/815a4655d75c8126/751x532cq70/layered-strawberry-tart-no-bake-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/815a4655d75c8126/751x532cq70/layered-strawberry-tart-no-bake-foto-resep-utama.jpg
author: Joshua Schultz
ratingvalue: 4.1
reviewcount: 42709
recipeingredient:
- " Crust "
- "150 gr biskuit regal yg sudah dihancurkan"
- "90 gr mentega cair"
- " Custard Filling "
- "100 ml susu cair"
- "4 butir kuning telur"
- "65 gr gula castor"
- "65 gr maizenaresep asli pake custard powder"
- "400 ml susu cair"
- "2 sdt pasta vanilla"
- "65 gr gula castor"
- "30 gr mentega dingin"
- "200 ml whipped creamaq pake whipped cream bubuk 150gr250ml air"
- " Strawberry jelly "
- "50 ml air"
- "50 gr gula pasirdisesuaikan aq skip karna selainya udah manis"
- "50 gr selai strawberryresep asli pake 100 gr strawberry asli"
- "2 sdt agar2 plain"
- " Topping "
- " Whipped cream granola ato bisa diganti buah2an"
recipeinstructions:
- "Siapkan bahan crust, haluskan biscuit regal, ga usah lembut2 biar ada sensasi krenyes2 nya, kemudian campurkan mentega cair, aduk rata"
- "Siapkan loyang(aq pake loyang uk. 20, bawahnya aq kasih tambahan plastik wrap, bwt bantu lepasin tartnya nanti dr loyang), masukkan adonan crust ke loyang lalu tekan2 dasar sampe sisi2 loyang jg, usahakan ketebalan sama, padatkan dengan bawah gelas ato apa aja yg rata, kemudian simpan dalam kulkas, agar mentega padat dan kokoh adonan crustnya"
- "Untuk membuat Custard Filling : di dalam mangkok, campurkan 100ml susu cair, kuning telur, 65 gr gula castor dan maizena, kocok hingga tercampur rata, sisihkan"
- "Siapkan panci masukkan 400 ml susu cair, pasta vanilla dan 65 gr gula castor, kemudian panaskan hingga susu mendidih, sambil diaduk-aduk, angkat"
- "Tuang susu panas ke dalam mangkok yang berisi kuning telur sambil dikocok agar kuning telur tidak menggumpal tuang sampe habis, kemudian masukkan kembali adonan ke panci, panaskan sambil diaduk hingga custard mengental(solid), matikan kompor, kemudian masukkan mentega, aduk hingga tercampur rata, lalu pindahkan ke wadah dan tutup dengan cling wrap menempel di custard, simpan di kulkas sampe benar2 dingin"
- "Siapkan whipped cream kocok sampe peak, simpan di dalam kulkas sambil menunggu custard dingin"
- "Siapkan bahan strawberry jelly, selai strawberry, air, gula dan agar2, masak jadi satu hingga mendidih, kemudian tuang ke piring pipih, supaya membentuk lembaran, dinginkan biar set"
- "Setelah custard benar2 dingin, kocok kembali custard agar lebih halus, kemudian masukkan whipped cream kemudian aduk rata dengan spatula, warnanya nanti akan lebih light, sisihkan"
- "Ambil crust dan tuang sebagian custard filling, kemudian letakkan jelly di tengah lalu tutup dengan custard filling lagi hingga memenuhi crust, hias suka-suka, bisa dengan buah2 an lgsg dan dioles agar2 bening biar awet buahnya ato bisa dihias dengan custard filling ato whipped cream, aq hias pake whipped cream, custard filling, selai sama granola aja yg simpel dan pasti anak2 suka ☺️"
- "Layered Strawberry Tart siap dinikmati 😋"
categories:
- Recipe
tags:
- layered
- strawberry
- tart

katakunci: layered strawberry tart 
nutrition: 274 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Dinner

---


![Layered Strawberry Tart (No Bake)](https://img-global.cpcdn.com/recipes/815a4655d75c8126/751x532cq70/layered-strawberry-tart-no-bake-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti layered strawberry tart (no bake) yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan keistimewahan yang merupakan keragaman Nusantara



Keharmonisan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Layered Strawberry Tart (No Bake) untuk keluarga. Momen makan bersama keluarga sudah menjadi budaya, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang dapat anda buat salah satunya layered strawberry tart (no bake) yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep layered strawberry tart (no bake) tanpa harus bersusah payah.
Berikut ini resep Layered Strawberry Tart (No Bake) yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 10 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Layered Strawberry Tart (No Bake):

1. Harap siapkan  Crust :
1. Harus ada 150 gr biskuit regal yg sudah dihancurkan
1. Harus ada 90 gr mentega cair
1. Tambah  Custard Filling :
1. Harap siapkan 100 ml susu cair
1. Harap siapkan 4 butir kuning telur
1. Siapkan 65 gr gula castor
1. Siapkan 65 gr maizena(resep asli pake custard powder)
1. Tambah 400 ml susu cair
1. Diperlukan 2 sdt pasta vanilla
1. Siapkan 65 gr gula castor
1. Jangan lupa 30 gr mentega dingin
1. Harus ada 200 ml whipped cream(aq pake whipped cream bubuk 150gr+250ml air
1. Dibutuhkan  Strawberry jelly :
1. Siapkan 50 ml air
1. Dibutuhkan 50 gr gula pasir(disesuaikan, aq skip karna selainya udah manis)
1. Siapkan 50 gr selai strawberry(resep asli pake 100 gr strawberry asli)
1. Dibutuhkan 2 sdt agar2 plain
1. Tambah  Topping :
1. Harap siapkan  Whipped cream, granola ato bisa diganti buah2an




<!--inarticleads2-->

##### Instruksi membuat  Layered Strawberry Tart (No Bake):

1. Siapkan bahan crust, haluskan biscuit regal, ga usah lembut2 biar ada sensasi krenyes2 nya, kemudian campurkan mentega cair, aduk rata
1. Siapkan loyang(aq pake loyang uk. 20, bawahnya aq kasih tambahan plastik wrap, bwt bantu lepasin tartnya nanti dr loyang), masukkan adonan crust ke loyang lalu tekan2 dasar sampe sisi2 loyang jg, usahakan ketebalan sama, padatkan dengan bawah gelas ato apa aja yg rata, kemudian simpan dalam kulkas, agar mentega padat dan kokoh adonan crustnya
1. Untuk membuat Custard Filling : di dalam mangkok, campurkan 100ml susu cair, kuning telur, 65 gr gula castor dan maizena, kocok hingga tercampur rata, sisihkan
1. Siapkan panci masukkan 400 ml susu cair, pasta vanilla dan 65 gr gula castor, kemudian panaskan hingga susu mendidih, sambil diaduk-aduk, angkat
1. Tuang susu panas ke dalam mangkok yang berisi kuning telur sambil dikocok agar kuning telur tidak menggumpal tuang sampe habis, kemudian masukkan kembali adonan ke panci, panaskan sambil diaduk hingga custard mengental(solid), matikan kompor, kemudian masukkan mentega, aduk hingga tercampur rata, lalu pindahkan ke wadah dan tutup dengan cling wrap menempel di custard, simpan di kulkas sampe benar2 dingin
1. Siapkan whipped cream kocok sampe peak, simpan di dalam kulkas sambil menunggu custard dingin
1. Siapkan bahan strawberry jelly, selai strawberry, air, gula dan agar2, masak jadi satu hingga mendidih, kemudian tuang ke piring pipih, supaya membentuk lembaran, dinginkan biar set
1. Setelah custard benar2 dingin, kocok kembali custard agar lebih halus, kemudian masukkan whipped cream kemudian aduk rata dengan spatula, warnanya nanti akan lebih light, sisihkan
1. Ambil crust dan tuang sebagian custard filling, kemudian letakkan jelly di tengah lalu tutup dengan custard filling lagi hingga memenuhi crust, hias suka-suka, bisa dengan buah2 an lgsg dan dioles agar2 bening biar awet buahnya ato bisa dihias dengan custard filling ato whipped cream, aq hias pake whipped cream, custard filling, selai sama granola aja yg simpel dan pasti anak2 suka ☺️
1. Layered Strawberry Tart siap dinikmati 😋




Demikianlah cara membuat layered strawberry tart (no bake) yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan terbukti, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
