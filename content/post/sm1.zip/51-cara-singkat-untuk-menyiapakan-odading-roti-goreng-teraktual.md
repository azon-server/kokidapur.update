---
description: "Cara singkat untuk menyiapakan Odading (roti goreng) teraktual"
title: "Cara singkat untuk menyiapakan Odading (roti goreng) teraktual"
slug: 51-cara-singkat-untuk-menyiapakan-odading-roti-goreng-teraktual
date: 2021-01-30T13:53:45.678Z
image: https://img-global.cpcdn.com/recipes/e8d1d0ef29fe90c1/751x532cq70/odading-roti-goreng-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e8d1d0ef29fe90c1/751x532cq70/odading-roti-goreng-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e8d1d0ef29fe90c1/751x532cq70/odading-roti-goreng-foto-resep-utama.jpg
author: Isaac Rowe
ratingvalue: 4.9
reviewcount: 37668
recipeingredient:
- "25 sdm tepung terigu"
- "1 butir telur"
- "1 sachet susu bubuk"
- "2 sdm gula pasir"
- "1/2 sdm fermipan"
- "100 ml air hangat"
- "1/2 sdt garam"
- "2 sdm margarin"
recipeinstructions:
- "Larutkan fermipan dan gula pasir dengan air hangat. Tutup gelasnya biarkan sampai berbuih"
- "Campurkan tepung terigu, susu bubuk dan telur. Masukkan cairan fermipan ke dalam campuran tepung, uleni sampai setengah kalis."
- "Tambahkan margarin dan garam lalu uleni lagi sampai kalis. Kalau masih lengket boleh ditambahkan sedikit saja tepung terigu."
- "Bulatkan adonan, tutup dengan kain bersih biarkan mengembang sampai kurleb 40 menit."
- "Setelah mengembang, kempeskan kembali adonan lalu bentuk bulat2 kecil dan beri isian coklat blok kalau mau. Gak dikasih isian juga gpp ya ttap enak kok"
- "Diamkan lagi 15 menit. Lalu goreng di minyak yg panas. Setelah matang angkat dan sajikan."
- "Lembut, tapi isiannya kurang banyak jadi gak begitu kerasa, dan adonannya kurang manis juga jadi saya taburi gula donat deh biar ada manis2nya 😅"
categories:
- Recipe
tags:
- odading
- roti
- goreng

katakunci: odading roti goreng 
nutrition: 158 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT52M"
recipeyield: "1"
recipecategory: Dinner

---


![Odading (roti goreng)](https://img-global.cpcdn.com/recipes/e8d1d0ef29fe90c1/751x532cq70/odading-roti-goreng-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti odading (roti goreng) yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia

Kehangatan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah memasak Odading (roti goreng) untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis makanan yang bisa anda contoh salah satunya odading (roti goreng) yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep odading (roti goreng) tanpa harus bersusah payah.
Seperti resep Odading (roti goreng) yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 8 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Odading (roti goreng):

1. Jangan lupa 25 sdm tepung terigu
1. Tambah 1 butir telur
1. Dibutuhkan 1 sachet susu bubuk
1. Siapkan 2 sdm gula pasir
1. Harus ada 1/2 sdm fermipan
1. Jangan lupa 100 ml air hangat
1. Harap siapkan 1/2 sdt garam
1. Tambah 2 sdm margarin




<!--inarticleads2-->

##### Instruksi membuat  Odading (roti goreng):

1. Larutkan fermipan dan gula pasir dengan air hangat. Tutup gelasnya biarkan sampai berbuih
1. Campurkan tepung terigu, susu bubuk dan telur. Masukkan cairan fermipan ke dalam campuran tepung, uleni sampai setengah kalis.
1. Tambahkan margarin dan garam lalu uleni lagi sampai kalis. Kalau masih lengket boleh ditambahkan sedikit saja tepung terigu.
1. Bulatkan adonan, tutup dengan kain bersih biarkan mengembang sampai kurleb 40 menit.
1. Setelah mengembang, kempeskan kembali adonan lalu bentuk bulat2 kecil dan beri isian coklat blok kalau mau. Gak dikasih isian juga gpp ya ttap enak kok
1. Diamkan lagi 15 menit. Lalu goreng di minyak yg panas. Setelah matang angkat dan sajikan.
1. Lembut, tapi isiannya kurang banyak jadi gak begitu kerasa, dan adonannya kurang manis juga jadi saya taburi gula donat deh biar ada manis2nya 😅




Demikianlah cara membuat odading (roti goreng) yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan teruji, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
