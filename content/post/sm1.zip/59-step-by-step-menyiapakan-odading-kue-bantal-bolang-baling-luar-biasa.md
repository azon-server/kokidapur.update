---
description: "Step-by-Step menyiapakan Odading/kue bantal/bolang baling Luar biasa"
title: "Step-by-Step menyiapakan Odading/kue bantal/bolang baling Luar biasa"
slug: 59-step-by-step-menyiapakan-odading-kue-bantal-bolang-baling-luar-biasa
date: 2020-11-09T14:06:04.597Z
image: https://img-global.cpcdn.com/recipes/056219d2f97aef4e/751x532cq70/odadingkue-bantalbolang-baling-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/056219d2f97aef4e/751x532cq70/odadingkue-bantalbolang-baling-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/056219d2f97aef4e/751x532cq70/odadingkue-bantalbolang-baling-foto-resep-utama.jpg
author: Harriett Smith
ratingvalue: 4.1
reviewcount: 48527
recipeingredient:
- "50 gram tepung cakra"
- "210 gram tepung segitiga"
- "1 butir telur"
- "5 gram fermipan"
- "100 ml air hangatme 1sdm susu bubuk air hangat smpe 100ml"
- "65 gram gula pasir"
- "3-4 sdm minyak gorengme 4sdm"
- "Sejumput garam"
recipeinstructions:
- "Aktifkan ragi dng Cara mencampur ragi dng susu hangat ditambah 1sdm gula..aduk rata...biarkan smpai berbuih banyak sambil Kita siapkan bahan2lain nya"
- "Dlm wadah bersih Masuk kan tepung2an nya..tambah sisa gula,telur(kocok lepas dulu) tambah minyak goreng tambahkan larutan ragi sdkt demi sedikit smpai habis"
- "Mixer smpai kalis tdk usah sampai kalis elastis..tambahkan garam...mixer lagi sebentar"
- "Pindahkan ke alas yg sdh ditaburi tepung...uleni sebentar biar semua tercampur.. tambahkan tepung sdkit sj bila lengket sekali...(adonan memang lengket ya mom&#39;s...bisa ditambah tepung sdkit dmi sedikt sj..)stlh rata...diamkan selama 40mnt smpai memgembang"
- "Stlh 40mnt tinju adonan...kemudian gilas dng rolling pin smpai ketebalan tertentu.. kemudian olesi atas adonan dng air sdkit sj...Lalu tabur wijen nya..."
- "Stlh ditaburi wijen potong menjdi beberapa bagian...diamkan 10mnt lagi"
- "Stlh 10mnt goreng dlm minyak api kecil..krn cenderung cepat gosong..goreng dng dibolak balik"
- "Stlh golden brown angkat...sajikan untuk teman minum Teh atau kopi..enakkkk bgt..empukkk kebangetan..enjoyy mom&#39;s 🤗"
categories:
- Recipe
tags:
- odadingkue
- bantalbolang
- baling

katakunci: odadingkue bantalbolang baling 
nutrition: 100 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT35M"
recipeyield: "3"
recipecategory: Dessert

---


![Odading/kue bantal/bolang baling](https://img-global.cpcdn.com/recipes/056219d2f97aef4e/751x532cq70/odadingkue-bantalbolang-baling-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau enak. Ciri masakan Indonesia odading/kue bantal/bolang baling yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah memasak Odading/kue bantal/bolang baling untuk keluarga. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang bisa anda contoh salah satunya odading/kue bantal/bolang baling yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep odading/kue bantal/bolang baling tanpa harus bersusah payah.
Seperti resep Odading/kue bantal/bolang baling yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 8 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Odading/kue bantal/bolang baling:

1. Siapkan 50 gram tepung cakra
1. Harap siapkan 210 gram tepung segitiga
1. Dibutuhkan 1 butir telur
1. Harus ada 5 gram fermipan
1. Harus ada 100 ml air hangat(me: 1sdm susu bubuk +air hangat smpe 100ml)
1. Diperlukan 65 gram gula pasir
1. Tambah 3-4 sdm minyak goreng(me: 4sdm)
1. Siapkan Sejumput garam




<!--inarticleads2-->

##### Cara membuat  Odading/kue bantal/bolang baling:

1. Aktifkan ragi dng Cara mencampur ragi dng susu hangat ditambah 1sdm gula..aduk rata...biarkan smpai berbuih banyak sambil Kita siapkan bahan2lain nya
1. Dlm wadah bersih Masuk kan tepung2an nya..tambah sisa gula,telur(kocok lepas dulu) tambah minyak goreng tambahkan larutan ragi sdkt demi sedikit smpai habis
1. Mixer smpai kalis tdk usah sampai kalis elastis..tambahkan garam...mixer lagi sebentar
1. Pindahkan ke alas yg sdh ditaburi tepung...uleni sebentar biar semua tercampur.. tambahkan tepung sdkit sj bila lengket sekali...(adonan memang lengket ya mom&#39;s...bisa ditambah tepung sdkit dmi sedikt sj..)stlh rata...diamkan selama 40mnt smpai memgembang
1. Stlh 40mnt tinju adonan...kemudian gilas dng rolling pin smpai ketebalan tertentu.. kemudian olesi atas adonan dng air sdkit sj...Lalu tabur wijen nya...
1. Stlh ditaburi wijen potong menjdi beberapa bagian...diamkan 10mnt lagi
1. Stlh 10mnt goreng dlm minyak api kecil..krn cenderung cepat gosong..goreng dng dibolak balik
1. Stlh golden brown angkat...sajikan untuk teman minum Teh atau kopi..enakkkk bgt..empukkk kebangetan..enjoyy mom&#39;s 🤗




Demikianlah cara membuat odading/kue bantal/bolang baling yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan terbukti, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
