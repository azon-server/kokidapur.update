---
description: "Bagaimana menyiapakan 754. Odading Viral aka Roti Goreng/Roti Bantal || Soft Teruji"
title: "Bagaimana menyiapakan 754. Odading Viral aka Roti Goreng/Roti Bantal || Soft Teruji"
slug: 32-bagaimana-menyiapakan-754-odading-viral-aka-roti-goreng-roti-bantal-soft-teruji
date: 2020-10-30T03:15:06.689Z
image: https://img-global.cpcdn.com/recipes/35d56abf9f89088c/751x532cq70/754-odading-viral-aka-roti-gorengroti-bantal-soft-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/35d56abf9f89088c/751x532cq70/754-odading-viral-aka-roti-gorengroti-bantal-soft-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/35d56abf9f89088c/751x532cq70/754-odading-viral-aka-roti-gorengroti-bantal-soft-foto-resep-utama.jpg
author: Lenora Rose
ratingvalue: 4.7
reviewcount: 37397
recipeingredient:
- " Bahan biang"
- "50 ml air hangat"
- "3 gr (1 sdt) ragi instan"
- "1 sdm gula pasir"
- "1 sachet (2 sdm) kental manis putih"
- "1 sdm tepung terigu"
- " Bahan Roti"
- "250 gr tepung terigu pro tinggi"
- "40 gr margarin"
- "20 gr gula pasir"
- "1 btr telur antero"
- " Bahan taburan"
- " Wijen putih"
- " Gula pasir"
recipeinstructions:
- "Buat biang: campur semua bahan, aduk rata. Diamkan 5-10 menit."
- "Campur bahan roti kecuali margarin, tambahkan bahan biang. Aduk rata dan uleni hingga setengah kalis."
- "Masukkan margarin, uleni lagi hingga kalis elastis."
- "Bulatkan adonan lalu diamkan selama 30-45 menit hingga mengembang 2 kali lipat. Kempiskan."
- "Gilas adonan setebal 1-1,5 cm."
- "Potong-potong dengan ukuran 4 x 5 cm atau sesuai selera. Letakkan diatas nampan yang sudah ditaburi dengan sedikit tepung. Tutup dengan serbet/plastik, diamkan 5-10 menit."
- "Olesi permukaannya dengan air lalu taburi dengan bahan taburan (wijen dan gula pasir), sambil sedikit ditekan agar lengket."
- "Goreng dengan api sedang hanya dengan sekali balik, agar tidak terlalu banyak menyerap minyak. Angkat lalu tiriskan."
- "Sajikan👍😋"
- "Happy baking 👍🥰"
categories:
- Recipe
tags:
- 754
- odading
- viral

katakunci: 754 odading viral 
nutrition: 142 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT44M"
recipeyield: "3"
recipecategory: Dessert

---


![754. Odading Viral aka Roti Goreng/Roti Bantal || Soft](https://img-global.cpcdn.com/recipes/35d56abf9f89088c/751x532cq70/754-odading-viral-aka-roti-gorengroti-bantal-soft-foto-resep-utama.jpg)
 soft yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Indonesia
 Soft untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang dapat anda buat salah satunya 754. odading viral aka roti goreng/roti bantal || soft yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep 754. odading viral aka roti goreng/roti bantal || soft tanpa harus bersusah payah.
Seperti resep 754. Odading Viral aka Roti Goreng/Roti Bantal || Soft yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 10 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat 754. Odading Viral aka Roti Goreng/Roti Bantal || Soft:

1. Jangan lupa  Bahan biang:
1. Harus ada 50 ml air hangat
1. Harus ada 3 gr (1 sdt) ragi instan
1. Tambah 1 sdm gula pasir
1. Harus ada 1 sachet (2 sdm) kental manis putih
1. Harap siapkan 1 sdm tepung terigu
1. Dibutuhkan  Bahan Roti:
1. Diperlukan 250 gr tepung terigu pro tinggi
1. Dibutuhkan 40 gr margarin
1. Harap siapkan 20 gr gula pasir
1. Jangan lupa 1 btr telur antero
1. Jangan lupa  Bahan taburan:
1. Diperlukan  Wijen putih
1. Diperlukan  Gula pasir




<!--inarticleads2-->

##### Instruksi membuat  754. Odading Viral aka Roti Goreng/Roti Bantal || Soft:

1. Buat biang: campur semua bahan, aduk rata. Diamkan 5-10 menit.
1. Campur bahan roti kecuali margarin, tambahkan bahan biang. Aduk rata dan uleni hingga setengah kalis.
1. Masukkan margarin, uleni lagi hingga kalis elastis.
1. Bulatkan adonan lalu diamkan selama 30-45 menit hingga mengembang 2 kali lipat. Kempiskan.
1. Gilas adonan setebal 1-1,5 cm.
1. Potong-potong dengan ukuran 4 x 5 cm atau sesuai selera. Letakkan diatas nampan yang sudah ditaburi dengan sedikit tepung. Tutup dengan serbet/plastik, diamkan 5-10 menit.
1. Olesi permukaannya dengan air lalu taburi dengan bahan taburan (wijen dan gula pasir), sambil sedikit ditekan agar lengket.
1. Goreng dengan api sedang hanya dengan sekali balik, agar tidak terlalu banyak menyerap minyak. Angkat lalu tiriskan.
1. Sajikan👍😋
1. Happy baking 👍🥰




Demikianlah cara membuat 754. odading viral aka roti goreng/roti bantal || soft yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
