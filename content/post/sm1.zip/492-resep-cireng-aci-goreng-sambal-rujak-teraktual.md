---
description: "Resep : Cireng (Aci Goreng) Sambal Rujak teraktual"
title: "Resep : Cireng (Aci Goreng) Sambal Rujak teraktual"
slug: 492-resep-cireng-aci-goreng-sambal-rujak-teraktual
date: 2020-09-13T04:49:19.566Z
image: https://img-global.cpcdn.com/recipes/d0d683fec2b61d76/751x532cq70/cireng-aci-goreng-sambal-rujak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d0d683fec2b61d76/751x532cq70/cireng-aci-goreng-sambal-rujak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d0d683fec2b61d76/751x532cq70/cireng-aci-goreng-sambal-rujak-foto-resep-utama.jpg
author: Samuel Smith
ratingvalue: 4.3
reviewcount: 9981
recipeingredient:
- " Bahan Biang Adonan Kental"
- "1 gelas tepung tapioka ukuran gelas 250 ml"
- "2 gelas air putih 400500 ml"
- "1/2 sdm garam"
- "1/2 sdm lada bubuk"
- "Sedikit kaldu jamur"
- "1 batang daun bawang di iris untuk taburan biang"
- " Bumbu Halus"
- "3 siung bawang putih"
- "2 butir kencur saya skip"
- "1/2 gelas air 125 ml"
- " Bahan Adonan Tepung"
- "1/4 sdm garam"
- "2 gelas tepung tapioka ukuran gelas 250 ml"
- "Secukupnya tepung terigu untuk lapisan luar cireng"
- " Bahan Sambal Rujak"
- " Gula aren  merah"
- "2 cabe merah keriting"
- " Cabe rawit sesuai selera"
- "1 siung bawang putih mentah"
- "Sedikit garam"
- "1 sdm air asam matang saya ganti perasan jeruk lemonnipis"
- "Secukupnya air matang hangat"
recipeinstructions:
- "Siapkan bahan biang atau adonan kental. Haluskan bumbu. Siapkan panci, campur semua bahan biang kecuali daun bawang. Masukkan bumbu halus, aduk merata. Masak dengan api kecil sambil terus-menerus diaduk hingga adonan mengental"
- "Setelah adonan mengental, matikan api beri taburan irisan daun bawang aduk rata. Sisihkan"
- "Selagi adonan kental masih panas, segera siapkan tepung tapioka kering dalam wadah, masukkan biang atau adonan kental sedikit demi sedikit. Aduk menggunakan tangan supaya merata cukup dicubit-cubit saja sambil dibentuk bulat-bulat pipih dan tebal. Ulangi sampai adonan habis. Letakkan pada piring yang sudah ditaburi tepung terigu supaya tidak menempel satu sama lain"
- "Panaskan minyak dalam wajan. Goreng adonan cireng dengan api sedang sampai matang merata. Angkat dan tiriskan"
- "Buat sambal rujak, dalam cobek campur gula aren atau gula merah, bawang, cabe dan garam lalu haluskan atau uleg. Beri sedikit air uleg kembali sampai halus kemudian tuangkan ke dalam wadah tambahkan sedikit air dan perasan jeruk lemon atau jeruk nipis secukupnya (jika pakai blender masukkan semua bahan lalu blender). Koreksi rasa"
- "Sajikan cireng (aci goreng) beserta sambal rujak. Selesai"
- ""
categories:
- Recipe
tags:
- cireng
- aci
- goreng

katakunci: cireng aci goreng 
nutrition: 249 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Dessert

---


![Cireng (Aci Goreng) Sambal Rujak](https://img-global.cpcdn.com/recipes/d0d683fec2b61d76/751x532cq70/cireng-aci-goreng-sambal-rujak-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau gurih. Karasteristik kuliner Nusantara cireng (aci goreng) sambal rujak yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah memasak Cireng (Aci Goreng) Sambal Rujak untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang bisa anda buat salah satunya cireng (aci goreng) sambal rujak yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep cireng (aci goreng) sambal rujak tanpa harus bersusah payah.
Seperti resep Cireng (Aci Goreng) Sambal Rujak yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 23 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Cireng (Aci Goreng) Sambal Rujak:

1. Tambah  Bahan Biang (Adonan Kental)
1. Jangan lupa 1 gelas tepung tapioka (ukuran gelas 250 ml)
1. Harus ada 2 gelas air putih (400-500 ml)
1. Dibutuhkan 1/2 sdm garam
1. Harap siapkan 1/2 sdm lada bubuk
1. Siapkan Sedikit kaldu jamur
1. Jangan lupa 1 batang daun bawang (di iris untuk taburan biang)
1. Jangan lupa  Bumbu Halus
1. Dibutuhkan 3 siung bawang putih
1. Siapkan 2 butir kencur (saya skip)
1. Jangan lupa 1/2 gelas air (125 ml)
1. Harus ada  Bahan Adonan Tepung
1. Tambah 1/4 sdm garam
1. Siapkan 2 gelas tepung tapioka (ukuran gelas 250 ml)
1. Harap siapkan Secukupnya tepung terigu (untuk lapisan luar cireng)
1. Dibutuhkan  Bahan Sambal Rujak
1. Tambah  Gula aren / merah
1. Harus ada 2 cabe merah keriting
1. Tambah  Cabe rawit (sesuai selera)
1. Jangan lupa 1 siung bawang putih mentah
1. Jangan lupa Sedikit garam
1. Harus ada 1 sdm air asam matang (saya ganti perasan jeruk lemon/nipis)
1. Tambah Secukupnya air matang hangat




<!--inarticleads2-->

##### Cara membuat  Cireng (Aci Goreng) Sambal Rujak:

1. Siapkan bahan biang atau adonan kental. Haluskan bumbu. Siapkan panci, campur semua bahan biang kecuali daun bawang. Masukkan bumbu halus, aduk merata. Masak dengan api kecil sambil terus-menerus diaduk hingga adonan mengental
1. Setelah adonan mengental, matikan api beri taburan irisan daun bawang aduk rata. Sisihkan
1. Selagi adonan kental masih panas, segera siapkan tepung tapioka kering dalam wadah, masukkan biang atau adonan kental sedikit demi sedikit. Aduk menggunakan tangan supaya merata cukup dicubit-cubit saja sambil dibentuk bulat-bulat pipih dan tebal. Ulangi sampai adonan habis. Letakkan pada piring yang sudah ditaburi tepung terigu supaya tidak menempel satu sama lain
1. Panaskan minyak dalam wajan. Goreng adonan cireng dengan api sedang sampai matang merata. Angkat dan tiriskan
1. Buat sambal rujak, dalam cobek campur gula aren atau gula merah, bawang, cabe dan garam lalu haluskan atau uleg. Beri sedikit air uleg kembali sampai halus kemudian tuangkan ke dalam wadah tambahkan sedikit air dan perasan jeruk lemon atau jeruk nipis secukupnya (jika pakai blender masukkan semua bahan lalu blender). Koreksi rasa
1. Sajikan cireng (aci goreng) beserta sambal rujak. Selesai
1. 




Demikianlah cara membuat cireng (aci goreng) sambal rujak yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan cepat, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
