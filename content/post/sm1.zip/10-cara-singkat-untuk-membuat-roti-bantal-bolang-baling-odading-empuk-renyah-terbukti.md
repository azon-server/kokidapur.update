---
description: "Cara singkat untuk membuat Roti Bantal/ Bolang Baling/Odading Empuk Renyah Terbukti"
title: "Cara singkat untuk membuat Roti Bantal/ Bolang Baling/Odading Empuk Renyah Terbukti"
slug: 10-cara-singkat-untuk-membuat-roti-bantal-bolang-baling-odading-empuk-renyah-terbukti
date: 2020-11-09T01:42:01.938Z
image: https://img-global.cpcdn.com/recipes/aec28e88097a2abb/751x532cq70/roti-bantal-bolang-balingodading-empuk-renyah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/aec28e88097a2abb/751x532cq70/roti-bantal-bolang-balingodading-empuk-renyah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/aec28e88097a2abb/751x532cq70/roti-bantal-bolang-balingodading-empuk-renyah-foto-resep-utama.jpg
author: Justin Massey
ratingvalue: 5
reviewcount: 34173
recipeingredient:
- "250 gr tepung terigu"
- "1 butir telur ayam utuh"
- "2 sdm margarine"
- "2 sdm SKMSusu Kental Manis"
- "2 sdm gula pasir"
- "100 ml air hangat"
- "1 sdt ragi instan fermipan"
- "1/4 sdt vanili"
- "Secukupnya wijen dan gula pasir"
recipeinstructions:
- "Bahan Biang: campur ragi gula pasir dan air hangat (jangan air panas, nanti ragi mati) aduk rata sampai gula larut, diamkan 5-10 menit. Kalo tidak berbuih berarti ragi tidak bekerja, buang saja ganti yang baru"
- "Masukkan tepung, margarin e, telur, SKM, vanili. Oleni sampai tercampur rata, masukkan buang sedikit demi sedikit dan oleni lagi sampai benar2 Kalis."
- "Pindahkan ke wadah yang sudah di olesi minyak tipis2. Diamkan sampai mengembang 2 kali lipat(kurang lebih 45 menit)"
- "Setelah mengembang, kempeskan adonan"
- "Di alas taburi teoung, Ambil adonan dan pipihkan setebal 2 cm, diamkan lagi 10-15 menit. Potong memanjang dan potong lagi bentuk kotak, pisahkan jangan berdempetan. Atasnya olesi air (pakai kuas), taburi wijen dan gula pasir"
- "Goreng dengan api sedang cenderung kecil sampai kuning kecoklatan, balik sekali saja, angkat tiriskan."
- "Jadi deh.."
categories:
- Recipe
tags:
- roti
- bantal
- bolang

katakunci: roti bantal bolang 
nutrition: 159 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT35M"
recipeyield: "3"
recipecategory: Dessert

---


![Roti Bantal/ Bolang Baling/Odading Empuk Renyah](https://img-global.cpcdn.com/recipes/aec28e88097a2abb/751x532cq70/roti-bantal-bolang-balingodading-empuk-renyah-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas dan enak. Ciri makanan Nusantara roti bantal/ bolang baling/odading empuk renyah yang kaya dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Roti Bantal/ Bolang Baling/Odading Empuk Renyah untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang bisa anda praktekkan salah satunya roti bantal/ bolang baling/odading empuk renyah yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep roti bantal/ bolang baling/odading empuk renyah tanpa harus bersusah payah.
Seperti resep Roti Bantal/ Bolang Baling/Odading Empuk Renyah yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 9 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Bantal/ Bolang Baling/Odading Empuk Renyah:

1. Siapkan 250 gr tepung terigu
1. Siapkan 1 butir telur ayam utuh
1. Harap siapkan 2 sdm margarine
1. Tambah 2 sdm SKM(Susu Kental Manis)
1. Tambah 2 sdm gula pasir
1. Harap siapkan 100 ml air hangat
1. Jangan lupa 1 sdt ragi instan (fermipan)
1. Harus ada 1/4 sdt vanili
1. Diperlukan Secukupnya wijen dan gula pasir




<!--inarticleads2-->

##### Bagaimana membuat  Roti Bantal/ Bolang Baling/Odading Empuk Renyah:

1. Bahan Biang: campur ragi gula pasir dan air hangat (jangan air panas, nanti ragi mati) aduk rata sampai gula larut, diamkan 5-10 menit. Kalo tidak berbuih berarti ragi tidak bekerja, buang saja ganti yang baru
1. Masukkan tepung, margarin e, telur, SKM, vanili. Oleni sampai tercampur rata, masukkan buang sedikit demi sedikit dan oleni lagi sampai benar2 Kalis.
1. Pindahkan ke wadah yang sudah di olesi minyak tipis2. Diamkan sampai mengembang 2 kali lipat(kurang lebih 45 menit)
1. Setelah mengembang, kempeskan adonan
1. Di alas taburi teoung, Ambil adonan dan pipihkan setebal 2 cm, diamkan lagi 10-15 menit. Potong memanjang dan potong lagi bentuk kotak, pisahkan jangan berdempetan. Atasnya olesi air (pakai kuas), taburi wijen dan gula pasir
1. Goreng dengan api sedang cenderung kecil sampai kuning kecoklatan, balik sekali saja, angkat tiriskan.
1. Jadi deh..




Demikianlah cara membuat roti bantal/ bolang baling/odading empuk renyah yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat gampang dan terbukti, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
