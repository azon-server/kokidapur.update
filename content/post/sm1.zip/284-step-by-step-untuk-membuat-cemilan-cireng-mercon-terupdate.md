---
description: "Step-by-Step untuk membuat Cemilan cireng mercon terupdate"
title: "Step-by-Step untuk membuat Cemilan cireng mercon terupdate"
slug: 284-step-by-step-untuk-membuat-cemilan-cireng-mercon-terupdate
date: 2021-01-05T06:35:14.455Z
image: https://img-global.cpcdn.com/recipes/b5e3da111f808ea8/751x532cq70/cemilan-cireng-mercon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b5e3da111f808ea8/751x532cq70/cemilan-cireng-mercon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b5e3da111f808ea8/751x532cq70/cemilan-cireng-mercon-foto-resep-utama.jpg
author: Mike Hogan
ratingvalue: 4.1
reviewcount: 48642
recipeingredient:
- " Bahan kulit"
- "200 gr tapioka"
- "70 gr tepung"
- "3 siung bawang putih atau 1 12 sdt bubuk bawang putih"
- "1/2 sdt garam"
- "1 sdt royco ayam"
- "250 ml air mendidih"
- " Isian"
- "9 buah baso potong semaunya"
- "4 buah sosis potong semaunya"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "8 cabe merah"
- "12 cabe rawit"
- "3 buah kemiri"
- "1 sdt ketumbar"
- "1 cm jahe"
- "1/2 sdt lada"
- "100 ml air"
- "secukupnya Royco"
- "secukupnya Gula"
- "secukupnya Garam"
- "1 tangkai daun bawang optional"
- "5 sdm saos belibil optional"
- "Sedikit kecap biar warna nya keluar aja optional"
- " Minyak utk menumis"
recipeinstructions:
- "Ulek atau blender cabe, bawang, kemiri, ketumbar, jahe dan tambahkan air."
- "Kemudian tumis sampai harum tambahkan gula, garam dan royco, lada, masukan baso dan sosis, aduk rata, tes rasa"
- "Noted: sebenernya ini bumbunya kebanyakan, bisa ditambahkan ayam suwir atau baso, sosis lagi. Tapi karna aku suka yg kebanyakan bumbu gini jadi kaya lumer gitu. Trus juga ditambahin minyak lagi dikit biar ada minyak2nya gitu (optional ya)"
- "Utk isiannya campur semua bahan, dan masukan air sedikit2 sampai bisa dipulung aja yaa jgn semuanya, pertama kali bikin aku masukin air semuanya jadi lengket, akhirnya ditambahin lagi tapioka nya sedikit2 sampe gak lengket di tangan, nah jgn lupa tambahin royco lagi yaa"
- "Bulatkan adonan secukupnya, pipihkan lalu cetak di cetakan pastel, goreng dengan api sedang"
categories:
- Recipe
tags:
- cemilan
- cireng
- mercon

katakunci: cemilan cireng mercon 
nutrition: 260 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT40M"
recipeyield: "3"
recipecategory: Lunch

---


![Cemilan cireng mercon](https://img-global.cpcdn.com/recipes/b5e3da111f808ea8/751x532cq70/cemilan-cireng-mercon-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita lestarikan karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti cemilan cireng mercon yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia



Keharmonisan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah memasak Cemilan cireng mercon untuk orang di rumah. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang dapat anda coba salah satunya cemilan cireng mercon yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep cemilan cireng mercon tanpa harus bersusah payah.
Berikut ini resep Cemilan cireng mercon yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 26 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Cemilan cireng mercon:

1. Jangan lupa  Bahan kulit
1. Tambah 200 gr tapioka
1. Jangan lupa 70 gr tepung
1. Harus ada 3 siung bawang putih atau 1 1/2 sdt bubuk bawang putih
1. Harap siapkan 1/2 sdt garam
1. Harus ada 1 sdt royco ayam
1. Diperlukan 250 ml air mendidih*
1. Jangan lupa  Isian
1. Siapkan 9 buah baso, potong semaunya
1. Siapkan 4 buah sosis, potong semaunya
1. Harap siapkan 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Harus ada 8 cabe merah
1. Siapkan 12 cabe rawit
1. Tambah 3 buah kemiri
1. Jangan lupa 1 sdt ketumbar
1. Siapkan 1 cm jahe
1. Harus ada 1/2 sdt lada
1. Dibutuhkan 100 ml air
1. Tambah secukupnya Royco
1. Jangan lupa secukupnya Gula
1. Siapkan secukupnya Garam
1. Tambah 1 tangkai daun bawang (optional)
1. Diperlukan 5 sdm saos belibil (optional)
1. Dibutuhkan Sedikit kecap biar warna nya keluar aja (optional)
1. Harus ada  Minyak utk menumis




<!--inarticleads2-->

##### Instruksi membuat  Cemilan cireng mercon:

1. Ulek atau blender cabe, bawang, kemiri, ketumbar, jahe dan tambahkan air.
1. Kemudian tumis sampai harum tambahkan gula, garam dan royco, lada, masukan baso dan sosis, aduk rata, tes rasa
1. Noted: sebenernya ini bumbunya kebanyakan, bisa ditambahkan ayam suwir atau baso, sosis lagi. Tapi karna aku suka yg kebanyakan bumbu gini jadi kaya lumer gitu. Trus juga ditambahin minyak lagi dikit biar ada minyak2nya gitu (optional ya)
1. Utk isiannya campur semua bahan, dan masukan air sedikit2 sampai bisa dipulung aja yaa jgn semuanya, pertama kali bikin aku masukin air semuanya jadi lengket, akhirnya ditambahin lagi tapioka nya sedikit2 sampe gak lengket di tangan, nah jgn lupa tambahin royco lagi yaa
1. Bulatkan adonan secukupnya, pipihkan lalu cetak di cetakan pastel, goreng dengan api sedang




Demikianlah cara membuat cemilan cireng mercon yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
