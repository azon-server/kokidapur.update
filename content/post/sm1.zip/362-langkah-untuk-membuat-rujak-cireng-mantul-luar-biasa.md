---
description: "Langkah untuk membuat Rujak Cireng Mantul Luar biasa"
title: "Langkah untuk membuat Rujak Cireng Mantul Luar biasa"
slug: 362-langkah-untuk-membuat-rujak-cireng-mantul-luar-biasa
date: 2021-01-20T18:53:03.996Z
image: https://img-global.cpcdn.com/recipes/aee3d373d4565341/751x532cq70/rujak-cireng-mantul-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/aee3d373d4565341/751x532cq70/rujak-cireng-mantul-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/aee3d373d4565341/751x532cq70/rujak-cireng-mantul-foto-resep-utama.jpg
author: Russell Hansen
ratingvalue: 4
reviewcount: 11783
recipeingredient:
- "250 gr Tepung Tapioka"
- "50 gr Tepung Terigu"
- "1 bks Penyedap rasa royco"
- "Irisan daun bawang secukupnya"
- " Air panas"
- " Bumbu Rujak "
- "5 Cabai Jablay"
- "10 Cabai Merah Keriting"
- "secukupnya Gula Merah"
- "secukupnya Air"
- "secukupnya Asem"
- "secukupnya Garam"
recipeinstructions:
- "Campur Tepung tapioka, tepung Terigu, penyedap rasa, daun bawang, lalu aduk. Setelah itu masukkan air panas sedikit demi sedikit sampai tidak lengket."
- "Setelah adonan siap. Ambil sedikit demi sedikit adonan dan bentuk sesuai selera, lalu taburi dengan tepung terigu supaya tidak lengket."
- "Panaskan minyak goreng. Lalu masukkan cireng ke dalam penggorengan, masak cireng hingga matang. Dan siap diangjat lalu tiriskan."
- "Bumbu rujak : ulek cabai dan garam sampai halus. Setelah itu masukkan gula merah. Dan campur. Masukkan bumbu ke dalam penggorengan, lalu masukkan air yang telah dicampuri dengan asem. Tunggu sampai mendidih dan kental."
- "Rujak Cireng siap disajikan."
categories:
- Recipe
tags:
- rujak
- cireng
- mantul

katakunci: rujak cireng mantul 
nutrition: 243 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Dessert

---


![Rujak Cireng Mantul](https://img-global.cpcdn.com/recipes/aee3d373d4565341/751x532cq70/rujak-cireng-mantul-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga renyah. Karasteristik masakan Indonesia rujak cireng mantul yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Rujak Cireng Mantul untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang bisa anda contoh salah satunya rujak cireng mantul yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep rujak cireng mantul tanpa harus bersusah payah.
Seperti resep Rujak Cireng Mantul yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Rujak Cireng Mantul:

1. Dibutuhkan 250 gr Tepung Tapioka
1. Harap siapkan 50 gr Tepung Terigu
1. Harap siapkan 1 bks Penyedap rasa (royco)
1. Siapkan Irisan daun bawang secukupnya
1. Harap siapkan  Air panas
1. Diperlukan  Bumbu Rujak :
1. Jangan lupa 5 Cabai Jablay
1. Tambah 10 Cabai Merah Keriting
1. Jangan lupa secukupnya Gula Merah
1. Diperlukan secukupnya Air
1. Harap siapkan secukupnya Asem
1. Siapkan secukupnya Garam




<!--inarticleads2-->

##### Cara membuat  Rujak Cireng Mantul:

1. Campur Tepung tapioka, tepung Terigu, penyedap rasa, daun bawang, lalu aduk. Setelah itu masukkan air panas sedikit demi sedikit sampai tidak lengket.
1. Setelah adonan siap. Ambil sedikit demi sedikit adonan dan bentuk sesuai selera, lalu taburi dengan tepung terigu supaya tidak lengket.
1. Panaskan minyak goreng. Lalu masukkan cireng ke dalam penggorengan, masak cireng hingga matang. Dan siap diangjat lalu tiriskan.
1. Bumbu rujak : ulek cabai dan garam sampai halus. Setelah itu masukkan gula merah. Dan campur. Masukkan bumbu ke dalam penggorengan, lalu masukkan air yang telah dicampuri dengan asem. Tunggu sampai mendidih dan kental.
1. Rujak Cireng siap disajikan.




Demikianlah cara membuat rujak cireng mantul yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
