---
description: "Panduan membuat Strawberry Watermelon Cake teraktual"
title: "Panduan membuat Strawberry Watermelon Cake teraktual"
slug: 86-panduan-membuat-strawberry-watermelon-cake-teraktual
date: 2020-09-08T11:29:38.650Z
image: https://img-global.cpcdn.com/recipes/9414481f0d517c56/751x532cq70/strawberry-watermelon-cake-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9414481f0d517c56/751x532cq70/strawberry-watermelon-cake-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9414481f0d517c56/751x532cq70/strawberry-watermelon-cake-foto-resep-utama.jpg
author: Anthony Gonzales
ratingvalue: 4.4
reviewcount: 37430
recipeingredient:
- " Almond Dacquoise "
- "150 gram tepung almond aku ganti tepung oatmeal"
- "150 gram icing sugar"
- "5 bh putih telur 180 gram"
- "150 gram garam"
- " Rose Cream "
- "150 gram whipped cream bubuk"
- "300 ml air teh bunga mawar dingin resep asli pakai whipped cream cair dan air mawar"
- " Layer Semangka "
- "Secukupnya Semangka"
- "Secukupnya Gula"
- "Secukupnya Air mawar aku pakai teh mawar"
- " Strawberry jelly "
- "1 cup strawberry"
- "6 sdm air"
- "2 gram bubuk agar"
- "4 sdm gula"
- " Pelengkap "
- "Secukupnya kacang pistachios"
recipeinstructions:
- "Kocok putih telur, tambahkan sedikit2 gula pasir. Kocok hingga soft peak."
- "Masukkan tepung dan icing sugar, aduk hingga merata."
- "Bagi menjadi 2, masukkan ke dalam loyang, panggang hingga matang dan kecoklatan. Sisihkan"
- "Campur semua bahan rose cream, mixer hingga kaku. Sisihkan"
- "Potong semangka sesuai bentuk loyang, taburi dengan gula dan air mawar di kedua sisi nya. Diamkan diatas saringan. Sisihkan"
- "Campur semua bahan strawberry jelly, masak hingga mendidih. Sisihkan"
- "Setelah semua kondimen jadi, susun cake di lapisan pertama. Semprotkan whipper cream."
- "Lap semangka dengan tissue, letalkan di layer ke 3. Semprot lagi whipped cream lalu letalkan lagi cake diatas nya. Layer terakhir semprotkan lagi whipped cream lalu taburi strawberry jelly, pistachios dan kelopak mawar diatasnya"
categories:
- Recipe
tags:
- strawberry
- watermelon
- cake

katakunci: strawberry watermelon cake 
nutrition: 129 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT44M"
recipeyield: "3"
recipecategory: Dessert

---


![Strawberry Watermelon Cake](https://img-global.cpcdn.com/recipes/9414481f0d517c56/751x532cq70/strawberry-watermelon-cake-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas atau gurih. Ciri masakan Nusantara strawberry watermelon cake yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Strawberry Watermelon Cake untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang dapat anda buat salah satunya strawberry watermelon cake yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep strawberry watermelon cake tanpa harus bersusah payah.
Seperti resep Strawberry Watermelon Cake yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Strawberry Watermelon Cake:

1. Jangan lupa  Almond Dacquoise :
1. Siapkan 150 gram tepung almond (aku ganti tepung oatmeal)
1. Tambah 150 gram icing sugar
1. Harap siapkan 5 bh putih telur (180 gram)
1. Siapkan 150 gram garam
1. Harap siapkan  Rose Cream :
1. Jangan lupa 150 gram whipped cream bubuk
1. Siapkan 300 ml air teh bunga mawar dingin (resep asli pakai whipped cream cair dan air mawar)
1. Diperlukan  Layer Semangka :
1. Tambah Secukupnya Semangka
1. Jangan lupa Secukupnya Gula
1. Jangan lupa Secukupnya Air mawar (aku pakai teh mawar)
1. Jangan lupa  Strawberry jelly :
1. Jangan lupa 1 cup strawberry
1. Dibutuhkan 6 sdm air
1. Harus ada 2 gram bubuk agar
1. Jangan lupa 4 sdm gula
1. Dibutuhkan  Pelengkap :
1. Tambah Secukupnya kacang pistachios




<!--inarticleads2-->

##### Bagaimana membuat  Strawberry Watermelon Cake:

1. Kocok putih telur, tambahkan sedikit2 gula pasir. Kocok hingga soft peak.
1. Masukkan tepung dan icing sugar, aduk hingga merata.
1. Bagi menjadi 2, masukkan ke dalam loyang, panggang hingga matang dan kecoklatan. Sisihkan
1. Campur semua bahan rose cream, mixer hingga kaku. Sisihkan
1. Potong semangka sesuai bentuk loyang, taburi dengan gula dan air mawar di kedua sisi nya. Diamkan diatas saringan. Sisihkan
1. Campur semua bahan strawberry jelly, masak hingga mendidih. Sisihkan
1. Setelah semua kondimen jadi, susun cake di lapisan pertama. Semprotkan whipper cream.
1. Lap semangka dengan tissue, letalkan di layer ke 3. Semprot lagi whipped cream lalu letalkan lagi cake diatas nya. Layer terakhir semprotkan lagi whipped cream lalu taburi strawberry jelly, pistachios dan kelopak mawar diatasnya




Demikianlah cara membuat strawberry watermelon cake yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan teruji, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
