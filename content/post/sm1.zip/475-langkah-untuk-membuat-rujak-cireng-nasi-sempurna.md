---
description: "Langkah untuk membuat Rujak Cireng Nasi Sempurna"
title: "Langkah untuk membuat Rujak Cireng Nasi Sempurna"
slug: 475-langkah-untuk-membuat-rujak-cireng-nasi-sempurna
date: 2020-12-07T04:14:03.246Z
image: https://img-global.cpcdn.com/recipes/f304264e2877ba9f/751x532cq70/rujak-cireng-nasi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f304264e2877ba9f/751x532cq70/rujak-cireng-nasi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f304264e2877ba9f/751x532cq70/rujak-cireng-nasi-foto-resep-utama.jpg
author: Roy Richardson
ratingvalue: 4.7
reviewcount: 18820
recipeingredient:
- "1 mangkok nasi"
- "4 sdm tepung kanjitapioka"
- "2 sdm tepung terigu"
- "2 siung bawang putih"
- "secukupnya garam  penyedap rasa"
- "secukupnya air panas"
- "secukupnya minyak goreng"
- " Bumbu rujak uleg "
- "6 buah cabe rawit"
- "1/2 sdt garam"
- "secukupnya asam jawa"
- "secukupnya gula merah"
- "sedikit air"
recipeinstructions:
- "Pertama rendam nasi dlam mangkok dengan air panas tunggu sampai 10menit supaya nasi bisa agak lembek"
- "Setelah itu saring nasi buang airnya ,uleg nasi sampai benar&#34; lembut menggunakan uleg,an .Haluskan bumbu halus bawang putih ,garam ,&amp; penyedap rasa .Masukkan bumbu halus, tepung kanji,&amp; tepung terigu ke dalam mangkok uleni bersama nasi hingga tercampur rata."
- "Kemudian siapkan loyang beri tepung kanji pada loyang lalu ambil adonan cireng satu sendok bentuk bundar tipis ,ulangi sampai adonan habis. Kemudian taruh adonan di loyang beri sedikit tepung kanji di atas adonan agar tdk lengket"
- "Panaskan minyak goreng lalu goreng cireng nasi sampai matang angkat tiriskan ,segera hidangkan selagi hangat lebih nikmat dgn sambel rujak  :)"
categories:
- Recipe
tags:
- rujak
- cireng
- nasi

katakunci: rujak cireng nasi 
nutrition: 285 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Dinner

---


![Rujak Cireng Nasi](https://img-global.cpcdn.com/recipes/f304264e2877ba9f/751x532cq70/rujak-cireng-nasi-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang setidaknya kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti rujak cireng nasi yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa kesan tersendiri yang merupakan keragaman Nusantara



Kedekatan keluarga dapat didapat dengan cara sederhana. Diantaranya adalah membuat makanan Rujak Cireng Nasi untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang bisa anda buat salah satunya rujak cireng nasi yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep rujak cireng nasi tanpa harus bersusah payah.
Berikut ini resep Rujak Cireng Nasi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 13 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Rujak Cireng Nasi:

1. Harap siapkan 1 mangkok nasi
1. Diperlukan 4 sdm tepung kanji/tapioka
1. Harus ada 2 sdm tepung terigu
1. Jangan lupa 2 siung bawang putih
1. Tambah secukupnya garam &amp; penyedap rasa
1. Jangan lupa secukupnya air panas
1. Harus ada secukupnya minyak goreng
1. Harus ada  *Bumbu rujak uleg :
1. Harus ada 6 buah cabe rawit
1. Diperlukan 1/2 sdt garam
1. Jangan lupa secukupnya asam jawa
1. Tambah secukupnya gula merah
1. Harap siapkan sedikit air




<!--inarticleads2-->

##### Cara membuat  Rujak Cireng Nasi:

1. Pertama rendam nasi dlam mangkok dengan air panas tunggu sampai 10menit supaya nasi bisa agak lembek
1. Setelah itu saring nasi buang airnya ,uleg nasi sampai benar&#34; lembut menggunakan uleg,an .Haluskan bumbu halus bawang putih ,garam ,&amp; penyedap rasa .Masukkan bumbu halus, tepung kanji,&amp; tepung terigu ke dalam mangkok uleni bersama nasi hingga tercampur rata.
1. Kemudian siapkan loyang beri tepung kanji pada loyang lalu ambil adonan cireng satu sendok bentuk bundar tipis ,ulangi sampai adonan habis. Kemudian taruh adonan di loyang beri sedikit tepung kanji di atas adonan agar tdk lengket
1. Panaskan minyak goreng lalu goreng cireng nasi sampai matang angkat tiriskan ,segera hidangkan selagi hangat lebih nikmat dgn sambel rujak  :)




Demikianlah cara membuat rujak cireng nasi yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat simple dan teruji, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
