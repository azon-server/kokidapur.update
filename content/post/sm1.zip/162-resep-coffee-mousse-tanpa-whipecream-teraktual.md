---
description: "Resep : Coffee Mousse (tanpa whipecream) teraktual"
title: "Resep : Coffee Mousse (tanpa whipecream) teraktual"
slug: 162-resep-coffee-mousse-tanpa-whipecream-teraktual
date: 2020-09-29T17:43:01.010Z
image: https://img-global.cpcdn.com/recipes/e952e7d485b7fb4a/751x532cq70/coffee-mousse-tanpa-whipecream-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e952e7d485b7fb4a/751x532cq70/coffee-mousse-tanpa-whipecream-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e952e7d485b7fb4a/751x532cq70/coffee-mousse-tanpa-whipecream-foto-resep-utama.jpg
author: Lenora Guzman
ratingvalue: 4.7
reviewcount: 31926
recipeingredient:
- " Bahan Pastry Cream Vla "
- "5-6 sachet kapal api grande white coffee with choco topping"
- "2 sdm kapal api krim kafe"
- "375 ml susu"
- "1 butir telur"
- "2 butir kuning telur"
- "25 gr tepung maizena"
- "40 gr butter  mentega"
- "1/4 sdt garam"
- " Bahan Italian Meringue "
- "2 butir putih telur"
- "120 gr gula pasir"
- "40 ml air"
- " Cream of tartar opsional"
- " Bahan Biskuit "
- "1 pack egg drop cookies  biskuit lain sesuai selera"
- "Secukupnya susu cair"
recipeinstructions:
- "Buat pastry cream : panaskan susu."
- "Campurkan kapal api grande white coffee (untuk choco topping nya sisihkan yah, krn di gunakan untuk taburan), kapal api krim kafe, telur, dan tepung Maizena ke dalam wadah, aduk hingga semua tercampur rata"
- "Masukkan sedikit demi sedikit susu yang sudah dipanaskan, sambil diaduk. Tuang ke panci lalu masak, Aduk terus hingga pastry cream mengental"
- "Setelah mengental Tambahkan mentega dan garam, aduk rata. tutup dengan baking paper / plastik. Diamkan hingga dingin."
- "Buat italian meringue : panaskan air dan gula di suhu 118-121°C. Masak hingga menjadi sirup gula (krn sy tdk ada termometer, sy hanya kira2, jika air dan guladi rasa sudah mencair dan mendidih, angkat) hati hati hangus yah)"
- "Kocok putih telur,"
- "Lalu tambahkan sirup gula sedikit demi sedikit sambil dikocok hingga kaku. Diamkan hingga dingin."
- "Campur meringue dengan pastry cream lalu aduk rata, sisakan sedikit meringue untuk topping. Masukkan ke dalam piping bag."
- "Siapkan susu cair, rendam biskuit, lalu tata egg drop cookies yang sudah direndam di gelas / wadah. Tambahkan dengan adonan mousse"
- "Kemudian beri topping meringue di atasnya dan tabur dengan choco topping, masukan kulkas hingga dingin dan siap di sajikan"
categories:
- Recipe
tags:
- coffee
- mousse
- tanpa

katakunci: coffee mousse tanpa 
nutrition: 262 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Lunch

---


![Coffee Mousse (tanpa whipecream)](https://img-global.cpcdn.com/recipes/e952e7d485b7fb4a/751x532cq70/coffee-mousse-tanpa-whipecream-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau renyah. Ciri masakan Nusantara coffee mousse (tanpa whipecream) yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak Coffee Mousse (tanpa whipecream) untuk keluarga. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang dapat anda contoh salah satunya coffee mousse (tanpa whipecream) yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep coffee mousse (tanpa whipecream) tanpa harus bersusah payah.
Seperti resep Coffee Mousse (tanpa whipecream) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 10 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Coffee Mousse (tanpa whipecream):

1. Harus ada  Bahan Pastry Cream (Vla) :
1. Tambah 5-6 sachet kapal api grande white coffee (with choco topping)
1. Harap siapkan 2 sdm kapal api krim kafe
1. Harus ada 375 ml susu
1. Harus ada 1 butir telur
1. Jangan lupa 2 butir kuning telur
1. Siapkan 25 gr tepung maizena
1. Harus ada 40 gr butter / mentega
1. Harap siapkan 1/4 sdt garam
1. Jangan lupa  Bahan Italian Meringue :
1. Harap siapkan 2 butir putih telur
1. Jangan lupa 120 gr gula pasir
1. Diperlukan 40 ml air
1. Siapkan  Cream of tartar (opsional)
1. Diperlukan  Bahan Biskuit :
1. Harap siapkan 1 pack egg drop cookies / biskuit lain sesuai selera
1. Diperlukan Secukupnya susu cair




<!--inarticleads2-->

##### Instruksi membuat  Coffee Mousse (tanpa whipecream):

1. Buat pastry cream : panaskan susu.
1. Campurkan kapal api grande white coffee (untuk choco topping nya sisihkan yah, krn di gunakan untuk taburan), kapal api krim kafe, telur, dan tepung Maizena ke dalam wadah, aduk hingga semua tercampur rata
1. Masukkan sedikit demi sedikit susu yang sudah dipanaskan, sambil diaduk. Tuang ke panci lalu masak, Aduk terus hingga pastry cream mengental
1. Setelah mengental Tambahkan mentega dan garam, aduk rata. tutup dengan baking paper / plastik. Diamkan hingga dingin.
1. Buat italian meringue : panaskan air dan gula di suhu 118-121°C. Masak hingga menjadi sirup gula (krn sy tdk ada termometer, sy hanya kira2, jika air dan guladi rasa sudah mencair dan mendidih, angkat) hati hati hangus yah)
1. Kocok putih telur,
1. Lalu tambahkan sirup gula sedikit demi sedikit sambil dikocok hingga kaku. Diamkan hingga dingin.
1. Campur meringue dengan pastry cream lalu aduk rata, sisakan sedikit meringue untuk topping. Masukkan ke dalam piping bag.
1. Siapkan susu cair, rendam biskuit, lalu tata egg drop cookies yang sudah direndam di gelas / wadah. Tambahkan dengan adonan mousse
1. Kemudian beri topping meringue di atasnya dan tabur dengan choco topping, masukan kulkas hingga dingin dan siap di sajikan




Demikianlah cara membuat coffee mousse (tanpa whipecream) yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan cepat, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
