---
description: "Resep : Rujak Cireng Cepat"
title: "Resep : Rujak Cireng Cepat"
slug: 401-resep-rujak-cireng-cepat
date: 2021-01-15T08:39:37.513Z
image: https://img-global.cpcdn.com/recipes/9e735c9ad65cbeeb/751x532cq70/rujak-cireng-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9e735c9ad65cbeeb/751x532cq70/rujak-cireng-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9e735c9ad65cbeeb/751x532cq70/rujak-cireng-foto-resep-utama.jpg
author: Jesus Strickland
ratingvalue: 4.8
reviewcount: 10954
recipeingredient:
- "250 gram tepung tapiokakanjiaci"
- "32 ml santan kental 12 bungkus santan segitiga sun kara"
- "2 siung bawang putih haluskan"
- "1 batang daun bawang pre rajang halus"
- "250 ml air"
- "Secukupnya garam"
- " Bahan Bumbu Rujak "
- "7 buah cabai rawit merah jumlah sesuai selera"
- "2 bongkah gula arenmerah"
- "50-70 ml air matang"
- "Secukupnya asam jawa sisir halus"
- "Secukupnya garam"
recipeinstructions:
- "Campur rata semua bahan cireng kecuali santan dan air, sisihkan"
- "Rebus air sampai benar-benar mendidih, lalu masukan santan, aduk merata. Matikan kompor"
- "Tuang campuran air mendidih dan santan ke dalam adonan tepung, aduk rata menggunakan sendok kayu atau spatula plastik, hati-hati panas ya"
- "Jangan khawatir adonannya menjadi lembek, karena lama-lama akan memadat/mengeras dengan sendirinya. Dan setelah beberapa menit adonan akan kalis"
- "Selalu balur telapak tangan menggunakan tepung tapioka saat membentuk. Lalu ambil adonan cireng secukupnya, bentuk sesuai selera"
- "Tabur wadah untuk menaruh adonan yang sudah selesai dibentuk dengan tepung tapioka supaya tidak lengket. Lakukan sampai adonan habis"
- "Panaskan minyak sayur, setelah panas kecilkan apinya. Kemudian goreng cireng sampai matang"
- "Cara membuat saus cocolannya : Haluskan semua bahan, campur rata dengan air lalu didihkan. Beri garam secukupnya, tes rasa. Angkat, saus siap digunakan"
- "Sajikan cireng dengan saus rujak cocolannya. Yummmyy 👍"
categories:
- Recipe
tags:
- rujak
- cireng

katakunci: rujak cireng 
nutrition: 183 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Dinner

---


![Rujak Cireng](https://img-global.cpcdn.com/recipes/9e735c9ad65cbeeb/751x532cq70/rujak-cireng-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang setidaknya kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti rujak cireng yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Indonesia

Keharmonisan keluarga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak Rujak Cireng untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda coba salah satunya rujak cireng yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep rujak cireng tanpa harus bersusah payah.
Seperti resep Rujak Cireng yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 12 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Rujak Cireng:

1. Jangan lupa 250 gram tepung tapioka/kanji/aci
1. Dibutuhkan 32 ml santan kental (1/2 bungkus santan segitiga sun kara)
1. Tambah 2 siung bawang putih, haluskan
1. Harus ada 1 batang daun bawang pre, rajang halus
1. Dibutuhkan 250 ml air
1. Siapkan Secukupnya garam
1. Harap siapkan  Bahan Bumbu Rujak :
1. Tambah 7 buah cabai rawit merah (jumlah sesuai selera)
1. Diperlukan 2 bongkah gula aren/merah
1. Harap siapkan 50-70 ml air matang
1. Dibutuhkan Secukupnya asam jawa, sisir halus
1. Diperlukan Secukupnya garam




<!--inarticleads2-->

##### Cara membuat  Rujak Cireng:

1. Campur rata semua bahan cireng kecuali santan dan air, sisihkan
1. Rebus air sampai benar-benar mendidih, lalu masukan santan, aduk merata. Matikan kompor
1. Tuang campuran air mendidih dan santan ke dalam adonan tepung, aduk rata menggunakan sendok kayu atau spatula plastik, hati-hati panas ya
1. Jangan khawatir adonannya menjadi lembek, karena lama-lama akan memadat/mengeras dengan sendirinya. Dan setelah beberapa menit adonan akan kalis
1. Selalu balur telapak tangan menggunakan tepung tapioka saat membentuk. Lalu ambil adonan cireng secukupnya, bentuk sesuai selera
1. Tabur wadah untuk menaruh adonan yang sudah selesai dibentuk dengan tepung tapioka supaya tidak lengket. Lakukan sampai adonan habis
1. Panaskan minyak sayur, setelah panas kecilkan apinya. Kemudian goreng cireng sampai matang
1. Cara membuat saus cocolannya : Haluskan semua bahan, campur rata dengan air lalu didihkan. Beri garam secukupnya, tes rasa. Angkat, saus siap digunakan
1. Sajikan cireng dengan saus rujak cocolannya. Yummmyy 👍




Demikianlah cara membuat rujak cireng yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
