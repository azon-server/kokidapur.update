---
description: "Resep : 06. Roti Bantal / Odading Empuk Sempurna"
title: "Resep : 06. Roti Bantal / Odading Empuk Sempurna"
slug: 38-resep-06-roti-bantal-odading-empuk-sempurna
date: 2020-11-28T15:13:34.300Z
image: https://img-global.cpcdn.com/recipes/92966e6f235aef54/751x532cq70/06-roti-bantal-odading-empuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/92966e6f235aef54/751x532cq70/06-roti-bantal-odading-empuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/92966e6f235aef54/751x532cq70/06-roti-bantal-odading-empuk-foto-resep-utama.jpg
author: Nathan Greer
ratingvalue: 4
reviewcount: 14858
recipeingredient:
- "250 gr tepung terigu"
- "1 butir telur"
- "1 sdt fermipanragi"
- "3 sdt gula pasir"
- "1 sdt bubuk kayu manis"
- "100 ml air hangat"
- " Taburan "
- "Biji wijen"
- " Gula pasir"
- " Gula halus"
recipeinstructions:
- "Larutkan fermipan dan gula kedalam air hangat 100ml sampai tercampur rata. Tunggu hingga 5-10 menit (sampai terlihat berbusa), jika tidak berbusa ganti dengan yg baru."
- "Siapkan wadah &amp; Masukkan terigu, telur, gula dan juga bubuk kayu manis."
- "Lalu aduk menggunakan mixer / uleni sampai tercampur rata dan masukkan cairan ragi sedikit demi sedikit."
- "Setelah tercampur rata, pindahkan ke wadah yg sudah di olesi minyak tipis&#34;. Diamkan adonan min. 45 menit sampai adonan mengembang."
- "Lalu kempeskan adonan, lumuri alas dengan tepung (agar tidak lengket) dan pipihkan sampai ketebalannya ± 2cm. Diamkan kembali 10-15 menit."
- "Lalu lumuri adonan bagian atas dengan sedikit air lalu taburi dengan wijen dan gula pasir. Dan potong-potong sesuai selera. /// Bisa di potong kotak memanjang dulu agar bentuknya sama. Tapi karna gak ada tatakan yg besar jadi aku gak di potong memanjang lagi makanya bentuknya ada yang gak kotak 😋"
- "Siapkan minyak panas dengan api sedang &amp; goreng adonan odading sampai kecoklatan. Di balik sesekali agar kedua sisi matang merata."
categories:
- Recipe
tags:
- 06
- roti
- bantal

katakunci: 06 roti bantal 
nutrition: 122 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Dessert

---


![06. Roti Bantal / Odading Empuk](https://img-global.cpcdn.com/recipes/92966e6f235aef54/751x532cq70/06-roti-bantal-odading-empuk-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas hingga enak. Ciri khas makanan Nusantara 06. roti bantal / odading empuk yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak 06. Roti Bantal / Odading Empuk untuk keluarga. Momen makan bersama orang tua sudah menjadi budaya, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang dapat anda contoh salah satunya 06. roti bantal / odading empuk yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep 06. roti bantal / odading empuk tanpa harus bersusah payah.
Berikut ini resep 06. Roti Bantal / Odading Empuk yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 10 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat 06. Roti Bantal / Odading Empuk:

1. Harus ada 250 gr tepung terigu
1. Dibutuhkan 1 butir telur
1. Diperlukan 1 sdt fermipan/ragi
1. Tambah 3 sdt gula pasir
1. Tambah 1 sdt bubuk kayu manis
1. Diperlukan 100 ml air hangat
1. Harap siapkan  Taburan :
1. Siapkan Biji wijen
1. Harus ada  Gula pasir
1. Jangan lupa  Gula halus




<!--inarticleads2-->

##### Langkah membuat  06. Roti Bantal / Odading Empuk:

1. Larutkan fermipan dan gula kedalam air hangat 100ml sampai tercampur rata. Tunggu hingga 5-10 menit (sampai terlihat berbusa), jika tidak berbusa ganti dengan yg baru.
1. Siapkan wadah &amp; Masukkan terigu, telur, gula dan juga bubuk kayu manis.
1. Lalu aduk menggunakan mixer / uleni sampai tercampur rata dan masukkan cairan ragi sedikit demi sedikit.
1. Setelah tercampur rata, pindahkan ke wadah yg sudah di olesi minyak tipis&#34;. Diamkan adonan min. 45 menit sampai adonan mengembang.
1. Lalu kempeskan adonan, lumuri alas dengan tepung (agar tidak lengket) dan pipihkan sampai ketebalannya ± 2cm. Diamkan kembali 10-15 menit.
1. Lalu lumuri adonan bagian atas dengan sedikit air lalu taburi dengan wijen dan gula pasir. Dan potong-potong sesuai selera. /// Bisa di potong kotak memanjang dulu agar bentuknya sama. Tapi karna gak ada tatakan yg besar jadi aku gak di potong memanjang lagi makanya bentuknya ada yang gak kotak 😋
1. Siapkan minyak panas dengan api sedang &amp; goreng adonan odading sampai kecoklatan. Di balik sesekali agar kedua sisi matang merata.




Demikianlah cara membuat 06. roti bantal / odading empuk yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan cepat, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
