---
description: "Cara singkat membuat Kue bantal empuk Teruji"
title: "Cara singkat membuat Kue bantal empuk Teruji"
slug: 20-cara-singkat-membuat-kue-bantal-empuk-teruji
date: 2020-09-14T02:52:03.545Z
image: https://img-global.cpcdn.com/recipes/823ca225b464378f/751x532cq70/kue-bantal-empuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/823ca225b464378f/751x532cq70/kue-bantal-empuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/823ca225b464378f/751x532cq70/kue-bantal-empuk-foto-resep-utama.jpg
author: Eva Roy
ratingvalue: 4.1
reviewcount: 30246
recipeingredient:
- "250 gr tepung terigu segitiga biru"
- "1 butir telur ayam"
- "2 SDM margarin"
- "2 SDM susu kental manis bendera"
- "5 SDM gula pasir"
- "1 SDT ragi instan fermipan"
- "1 SDT vanili cair"
- "100 Ml air"
- "secukupnya wijen"
recipeinstructions:
- "Larutkan gula kedalam 100 ml air"
- "Campurkan tepung terigu,margarin,ragi,susu kental manis,telur dan vanili aduk hingga rata"
- "Tambahkan air sedikit demi sedikit lalu uleni sampai kalis (kurang lebih 10 menit)"
- "Diamkan adonan dan tutup dengan kain bersih sekitar 1 jam"
- "Pipihkan adonan kemudian olesi air dan taburkan wijen diatasnya lalu diamkan kurang lebih 10 menit lagi"
- "Potong potong adonan dalam bentuk persegi"
- "Siapkan minyak untuk menggoreng lalu goreng dengan api kecil balik cukup sekali saja agar muncul white ring pada kue bantal"
- "Goreng sampai kecoklatan angkat lalu sajikan 😍😍"
categories:
- Recipe
tags:
- kue
- bantal
- empuk

katakunci: kue bantal empuk 
nutrition: 154 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Dinner

---


![Kue bantal empuk](https://img-global.cpcdn.com/recipes/823ca225b464378f/751x532cq70/kue-bantal-empuk-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan gurih. Ciri masakan Indonesia kue bantal empuk yang penuh dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga dapat ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Kue bantal empuk untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.

Odading atau kue bantal mang oleh bisa kopong tengah, resep kue bolang baling khas semarang. Recipe: Pillow cake. [YT: Cara Membuat Kue Bantal (Ham Chim Piang) Lembut Dan Praktis!!!] Ingredients: Salt. Hasilnya mirip seperti yang dijual di abang-abang. Resep cara membuat kue bantal, hasilnya ngembang besar, hemat bahan, dan rasanya empuk manis pastinya.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang bisa anda buat salah satunya kue bantal empuk yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep kue bantal empuk tanpa harus bersusah payah.
Berikut ini resep Kue bantal empuk yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 9 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue bantal empuk:

1. Dibutuhkan 250 gr tepung terigu (segitiga biru)
1. Diperlukan 1 butir telur ayam
1. Siapkan 2 SDM margarin
1. Dibutuhkan 2 SDM susu kental manis (bendera)
1. Harus ada 5 SDM gula pasir
1. Tambah 1 SDT ragi instan (fermipan)
1. Harap siapkan 1 SDT vanili cair
1. Diperlukan 100 Ml air
1. Harus ada secukupnya wijen


Saat mereka sudah memasuki fase tersebut, digunakan untuk tidurpemiliknya pun buru-buru mengisi kembali material dalamnya. Kue bantal dan roti bantal adalah jajanan yang sudah ada sejak zaman dahulu, namun Category. Bosan dengan Kue Bantal atau Roti Bantal Biasa? Ingin berbuka dengan kue yang empuk dan manis? 

<!--inarticleads2-->

##### Langkah membuat  Kue bantal empuk:

1. Larutkan gula kedalam 100 ml air
1. Campurkan tepung terigu,margarin,ragi,susu kental manis,telur dan vanili aduk hingga rata
1. Tambahkan air sedikit demi sedikit lalu uleni sampai kalis (kurang lebih 10 menit)
1. Diamkan adonan dan tutup dengan kain bersih sekitar 1 jam
1. Pipihkan adonan kemudian olesi air dan taburkan wijen diatasnya lalu diamkan kurang lebih 10 menit lagi
1. Potong potong adonan dalam bentuk persegi
1. Siapkan minyak untuk menggoreng lalu goreng dengan api kecil balik cukup sekali saja agar muncul white ring pada kue bantal
1. Goreng sampai kecoklatan angkat lalu sajikan 😍😍


Bosan dengan Kue Bantal atau Roti Bantal Biasa? Ingin berbuka dengan kue yang empuk dan manis? Cobalah odading, kue goreng khas Bandung. Teksturnya yang lembut dan empuk dengan rasa yang manis dijamin bakal bikin kamu ketagihan! Kue adalah kudapan atau makanan ringan yang bukan makanan utama. 

Demikianlah cara membuat kue bantal empuk yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan teruji, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
