---
description: "Steps untuk membuat Odading / roti goreng / bolang baling empuk Luar biasa"
title: "Steps untuk membuat Odading / roti goreng / bolang baling empuk Luar biasa"
slug: 8-steps-untuk-membuat-odading-roti-goreng-bolang-baling-empuk-luar-biasa
date: 2020-11-16T19:26:41.548Z
image: https://img-global.cpcdn.com/recipes/c6baa0032f554e5a/751x532cq70/odading-roti-goreng-bolang-baling-empuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c6baa0032f554e5a/751x532cq70/odading-roti-goreng-bolang-baling-empuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c6baa0032f554e5a/751x532cq70/odading-roti-goreng-bolang-baling-empuk-foto-resep-utama.jpg
author: Stephen Osborne
ratingvalue: 4.1
reviewcount: 18240
recipeingredient:
- "200 g tepung cakra"
- "40 g gula pasir"
- "3/4 sdt ragi instan"
- "80 ml susu full cream"
- "1 butir telur"
- "1 sdt baking powder"
- "1 1/2 sdm margarin"
recipeinstructions:
- "Campur semua bahan (kecuali margarin), uleni hingga rata, masukkan margarin, uleni hingga kalis sekitar 20-30 menit (adonan memang agak lembek, tandan sudah bagus jika sudah halus dan mengkilat rata, diambil menggunakan spatula tidak lengket)"
- "Bulatkan adonan, tutup dengan plastik /lap basah di dalam wadah, biarkan mengembang 2xnya"
- "Taburi meja kerja dengan tepung, kempiskan adona taburi adonan dengan tepung, gilas adonan hingga sekitar 1-2 cm dan iris kotak sesuai selera, olesi permukaan adonan dengan air dan tabur wijen"
- "Tutup dengan plastik dan diamkan 10-20 menit agar mengembang"
- "Goreng adonan dalam minyak panas, api kecil sedang, karena adonan akan menggembung dan cepat gosong krn manis, pada saat menggoreng bisa dibolak balik agar rata"
categories:
- Recipe
tags:
- odading
- 
- roti

katakunci: odading  roti 
nutrition: 200 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Dinner

---


![Odading / roti goreng / bolang baling empuk](https://img-global.cpcdn.com/recipes/c6baa0032f554e5a/751x532cq70/odading-roti-goreng-bolang-baling-empuk-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau enak. Karasteristik kuliner Indonesia odading / roti goreng / bolang baling empuk yang penuh dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Odading / roti goreng / bolang baling empuk untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi resep yang bisa anda contoh salah satunya odading / roti goreng / bolang baling empuk yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep odading / roti goreng / bolang baling empuk tanpa harus bersusah payah.
Seperti resep Odading / roti goreng / bolang baling empuk yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 7 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Odading / roti goreng / bolang baling empuk:

1. Jangan lupa 200 g tepung cakra
1. Siapkan 40 g gula pasir
1. Harap siapkan 3/4 sdt ragi instan
1. Harap siapkan 80 ml susu full cream
1. Dibutuhkan 1 butir telur
1. Dibutuhkan 1 sdt baking powder
1. Jangan lupa 1 1/2 sdm margarin




<!--inarticleads2-->

##### Cara membuat  Odading / roti goreng / bolang baling empuk:

1. Campur semua bahan (kecuali margarin), uleni hingga rata, masukkan margarin, uleni hingga kalis sekitar 20-30 menit (adonan memang agak lembek, tandan sudah bagus jika sudah halus dan mengkilat rata, diambil menggunakan spatula tidak lengket)
1. Bulatkan adonan, tutup dengan plastik /lap basah di dalam wadah, biarkan mengembang 2xnya
1. Taburi meja kerja dengan tepung, kempiskan adona taburi adonan dengan tepung, gilas adonan hingga sekitar 1-2 cm dan iris kotak sesuai selera, olesi permukaan adonan dengan air dan tabur wijen
1. Tutup dengan plastik dan diamkan 10-20 menit agar mengembang
1. Goreng adonan dalam minyak panas, api kecil sedang, karena adonan akan menggembung dan cepat gosong krn manis, pada saat menggoreng bisa dibolak balik agar rata




Demikianlah cara membuat odading / roti goreng / bolang baling empuk yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
