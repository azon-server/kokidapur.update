---
description: "Step-by-Step menyiapakan Odading Empuk/Roti Goreng/Roti Bantal minggu ini"
title: "Step-by-Step menyiapakan Odading Empuk/Roti Goreng/Roti Bantal minggu ini"
slug: 5-step-by-step-menyiapakan-odading-empuk-roti-goreng-roti-bantal-minggu-ini
date: 2020-12-11T16:15:22.743Z
image: https://img-global.cpcdn.com/recipes/7fdae301ef49b162/751x532cq70/odading-empukroti-gorengroti-bantal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7fdae301ef49b162/751x532cq70/odading-empukroti-gorengroti-bantal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7fdae301ef49b162/751x532cq70/odading-empukroti-gorengroti-bantal-foto-resep-utama.jpg
author: Alexander Summers
ratingvalue: 5
reviewcount: 9049
recipeingredient:
- " Bahan biang "
- "50 ml air hangat"
- "3 gr (1 sdt) ragi instan"
- "1 sdm tepung terigu"
- "1 sdm gula pasir"
- "2 sdm kental manis putih"
- " Bahan roti "
- "250 gr tepung terigu pro tinggi"
- "1 butir telur"
- "40 gr margarin"
- "20 gr gula pasir"
- " Bahan taburan "
- "secukupnya Gula pasir"
- "secukupnya Air"
recipeinstructions:
- "Campur semua bahan biang diamkan selama 5-10 menit sampai berbuih tanda ragi aktif."
- "Campur semua bahan roti kecuali margarin aduk rata ulenin sampai setengah kalis."
- "Tambahkan margarin ulenin kembali sampai kalis elatis. Bulatkan adonan diamkan selama 30-45 menit atau sampai menggembang 2x lipat."
- "Setelah itu kempiskan adonan lalu pipihkan setebal 1-1,5 cm. Potong adonan kotak sesuai selera diamkan kembali 10-15 menit jangan lupa alas ditaburi tepung."
- "Panaskan minyak, oles permukaan adonan dengan air lalu tabur gula pasir tekan2 supaya menempel. Goreng dalam minyak panas api kecil balik apabila sudah berwarna kecoklatan balik sekali saja."
- "Hasilnya menul-menul."
categories:
- Recipe
tags:
- odading
- empukroti
- gorengroti

katakunci: odading empukroti gorengroti 
nutrition: 208 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Dessert

---


![Odading Empuk/Roti Goreng/Roti Bantal](https://img-global.cpcdn.com/recipes/7fdae301ef49b162/751x532cq70/odading-empukroti-gorengroti-bantal-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan empuk. Ciri makanan Indonesia odading empuk/roti goreng/roti bantal yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak Odading Empuk/Roti Goreng/Roti Bantal untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang bisa anda buat salah satunya odading empuk/roti goreng/roti bantal yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep odading empuk/roti goreng/roti bantal tanpa harus bersusah payah.
Seperti resep Odading Empuk/Roti Goreng/Roti Bantal yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 14 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Odading Empuk/Roti Goreng/Roti Bantal:

1. Harus ada  Bahan biang :
1. Dibutuhkan 50 ml air hangat
1. Jangan lupa 3 gr (1 sdt) ragi instan
1. Siapkan 1 sdm tepung terigu
1. Harus ada 1 sdm gula pasir
1. Tambah 2 sdm kental manis putih
1. Harap siapkan  Bahan roti :
1. Jangan lupa 250 gr tepung terigu pro tinggi
1. Diperlukan 1 butir telur
1. Harap siapkan 40 gr margarin
1. Jangan lupa 20 gr gula pasir
1. Jangan lupa  Bahan taburan :
1. Harap siapkan secukupnya Gula pasir
1. Tambah secukupnya Air




<!--inarticleads2-->

##### Langkah membuat  Odading Empuk/Roti Goreng/Roti Bantal:

1. Campur semua bahan biang diamkan selama 5-10 menit sampai berbuih tanda ragi aktif.
1. Campur semua bahan roti kecuali margarin aduk rata ulenin sampai setengah kalis.
1. Tambahkan margarin ulenin kembali sampai kalis elatis. Bulatkan adonan diamkan selama 30-45 menit atau sampai menggembang 2x lipat.
1. Setelah itu kempiskan adonan lalu pipihkan setebal 1-1,5 cm. Potong adonan kotak sesuai selera diamkan kembali 10-15 menit jangan lupa alas ditaburi tepung.
1. Panaskan minyak, oles permukaan adonan dengan air lalu tabur gula pasir tekan2 supaya menempel. Goreng dalam minyak panas api kecil balik apabila sudah berwarna kecoklatan balik sekali saja.
1. Hasilnya menul-menul.




Demikianlah cara membuat odading empuk/roti goreng/roti bantal yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
