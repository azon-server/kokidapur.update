---
description: "Resep : Cireng sambal hijau teraktual"
title: "Resep : Cireng sambal hijau teraktual"
slug: 387-resep-cireng-sambal-hijau-teraktual
date: 2020-09-23T06:11:48.756Z
image: https://img-global.cpcdn.com/recipes/426d619bb6221607/751x532cq70/cireng-sambal-hijau-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/426d619bb6221607/751x532cq70/cireng-sambal-hijau-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/426d619bb6221607/751x532cq70/cireng-sambal-hijau-foto-resep-utama.jpg
author: Viola Matthews
ratingvalue: 4.7
reviewcount: 31634
recipeingredient:
- "2-3 sdm tepung tapioka"
- "300-400 gr tepung kanji kurang lebih"
- "200 ml Air kurang lebih"
- "3 siung bawang putih"
- "1 blok kaldu jamur"
- "secukupnya Garam"
- " Minyak ikan 1 Sdt optional"
- " Minyak goreng 500ml kurang lebih tergantung besar wajan"
- " Sambal hijau "
- "7-8 cabe hijau keriting"
- "7-8 cabe merah kecil rawit"
- "1 blok kaldu jamur"
- "2 siung bawang putih"
- "2-3 Sdm Minyak goreng"
recipeinstructions:
- "Mari kita bikin sambal hijaunya terlebih dahulu.. cuci bersih cabe..disini saya pakai blender untuk menghaluskan.. karena ga kuat kalau harus pake ulekan. Masukan semua bahan sambal hijau kedalam blender. Dan haluskan."
- "Siapkan minyak diatas teflon / wajan. Kira kira 2-3 sendok makan. Setelah minyak panas. Masukan sambal yg telah di blender. Goreng sambil terus diaduk biar tidak gosong. Setelah warna keemasan matikan kompor dan sajikan sambal hijau di mangkuk untuk cocolan cireng nanti."
- "Selanjutnya mari kita buat cirengnya. Siapkan ulek&#39;an untuk menghaluskan bawang putih dan garam. Setelah halus sisihkan."
- "Siapkan wajan bersih dan beri air diatas wajan,kira kira 200ml,pasang api pada level tinggi, tunggu sampai hampir mendidih.setelah terlihat sedikit gelembung air turunkan api di level sedang."
- "Masukan kaldu blok jamur, minyak ikan, bawang putih+garam (yg telah dihaluskan) kedalam wajan aduk hingga tercampur rata."
- "Setelah itu masukan tepung tapioka, aduk dan campur merata sehingga terlihat lengket bening seperti lem, matikan api angkat wajan. Pindahkan adonan lengket tadi kedalam baskom yang telah dilumuri tepung kanji. Uleni dengan menambahkan sedikit demi sedikit tepung kanji hingga adonan tidak lengket lagi."
- "Bentuk adonan sesuai selera. Lebih disarankan tipis saja jangan terlalu tebal. Supaya ketika digoreng tidak meletus atau memercikan minyak."
- "Panaskan minyak untuk menggoreng kira kira 500 ml tergantung wajan ya.. apinya hampir level tinggi jangan mentok ke tinggi ya.. pokoknya pas goreng nanti si acinya tenggelam di minyak. Setelah panas goreng acinya, kalau pingin krispi goreng sampai ada terlihat warna keemasan sedikit, semakin keemasan semakin krispi."
- "Taraaaaa cireng sambal hijau jadi cocok untuk menu camilan sore hari bersama keluarga 🥰"
categories:
- Recipe
tags:
- cireng
- sambal
- hijau

katakunci: cireng sambal hijau 
nutrition: 254 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Dinner

---


![Cireng sambal hijau](https://img-global.cpcdn.com/recipes/426d619bb6221607/751x532cq70/cireng-sambal-hijau-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga gurih. Karasteristik makanan Nusantara cireng sambal hijau yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Cireng sambal hijau untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang bisa anda praktekkan salah satunya cireng sambal hijau yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep cireng sambal hijau tanpa harus bersusah payah.
Seperti resep Cireng sambal hijau yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 14 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Cireng sambal hijau:

1. Dibutuhkan 2-3 sdm tepung tapioka
1. Harap siapkan 300-400 gr tepung kanji (kurang lebih)
1. Tambah 200 ml Air kurang lebih
1. Diperlukan 3 siung bawang putih
1. Jangan lupa 1 blok kaldu jamur
1. Jangan lupa secukupnya Garam
1. Tambah  Minyak ikan 1 Sdt (optional)
1. Jangan lupa  Minyak goreng 500ml kurang lebih tergantung besar wajan
1. Harap siapkan  Sambal hijau :
1. Diperlukan 7-8 cabe hijau keriting
1. Dibutuhkan 7-8 cabe merah kecil (rawit)
1. Siapkan 1 blok kaldu jamur
1. Jangan lupa 2 siung bawang putih
1. Harap siapkan 2-3 Sdm Minyak goreng




<!--inarticleads2-->

##### Langkah membuat  Cireng sambal hijau:

1. Mari kita bikin sambal hijaunya terlebih dahulu.. cuci bersih cabe..disini saya pakai blender untuk menghaluskan.. karena ga kuat kalau harus pake ulekan. Masukan semua bahan sambal hijau kedalam blender. Dan haluskan.
1. Siapkan minyak diatas teflon / wajan. Kira kira 2-3 sendok makan. Setelah minyak panas. Masukan sambal yg telah di blender. Goreng sambil terus diaduk biar tidak gosong. Setelah warna keemasan matikan kompor dan sajikan sambal hijau di mangkuk untuk cocolan cireng nanti.
1. Selanjutnya mari kita buat cirengnya. Siapkan ulek&#39;an untuk menghaluskan bawang putih dan garam. Setelah halus sisihkan.
1. Siapkan wajan bersih dan beri air diatas wajan,kira kira 200ml,pasang api pada level tinggi, tunggu sampai hampir mendidih.setelah terlihat sedikit gelembung air turunkan api di level sedang.
1. Masukan kaldu blok jamur, minyak ikan, bawang putih+garam (yg telah dihaluskan) kedalam wajan aduk hingga tercampur rata.
1. Setelah itu masukan tepung tapioka, aduk dan campur merata sehingga terlihat lengket bening seperti lem, matikan api angkat wajan. Pindahkan adonan lengket tadi kedalam baskom yang telah dilumuri tepung kanji. Uleni dengan menambahkan sedikit demi sedikit tepung kanji hingga adonan tidak lengket lagi.
1. Bentuk adonan sesuai selera. Lebih disarankan tipis saja jangan terlalu tebal. Supaya ketika digoreng tidak meletus atau memercikan minyak.
1. Panaskan minyak untuk menggoreng kira kira 500 ml tergantung wajan ya.. apinya hampir level tinggi jangan mentok ke tinggi ya.. pokoknya pas goreng nanti si acinya tenggelam di minyak. Setelah panas goreng acinya, kalau pingin krispi goreng sampai ada terlihat warna keemasan sedikit, semakin keemasan semakin krispi.
1. Taraaaaa cireng sambal hijau jadi cocok untuk menu camilan sore hari bersama keluarga 🥰




Demikianlah cara membuat cireng sambal hijau yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan teruji, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
