---
description: "Langkah untuk menyiapakan Kue Bantal / Odading Favorite"
title: "Langkah untuk menyiapakan Kue Bantal / Odading Favorite"
slug: 50-langkah-untuk-menyiapakan-kue-bantal-odading-favorite
date: 2020-12-19T16:24:15.135Z
image: https://img-global.cpcdn.com/recipes/4bc08754c50bd5b3/751x532cq70/kue-bantal-odading-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4bc08754c50bd5b3/751x532cq70/kue-bantal-odading-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4bc08754c50bd5b3/751x532cq70/kue-bantal-odading-foto-resep-utama.jpg
author: Nelle Jordan
ratingvalue: 5
reviewcount: 2892
recipeingredient:
- "250 gr terigu"
- "2 sdm gula pasir"
- "100 ml air hangat"
- "1 sdt ragi instan sy fermipan"
- "1 telur ayam utuh"
- "2 sdm skm"
- "2 sdm margarine"
- "1/4 sdt vanili bubuk"
- " Taburan "
- "Secukupnya gula pasir atau wijen"
recipeinstructions:
- "Siapkan dulu bahan biang, campur ragi, gula pasir dan air hangat dlm satu wadah, aduk rata, diamkan kurleb 30menit - 1 jam. Tanda raginya aktif berbusa ya, klo gak berbusa buang dan bikin baru lg."
- "Dalam wadh terpisah, campurkan terigu, margarine, telur, skm dan vanili,uleni (sy blender)."
- "Masukan cairan ragi td sedikit demi sedikit, sambil diuleni/mixer sampai benar2 kalis."
- "Pindahkan kedalam wadah yg sudah diolesi minyak tipis2. Tutup adonan dgn serbet, diamkan sampai mengembang 2x lipat(sy 2 jam)"
- "Setelah mengembang, tinju2 adonan, pipihkan kurleb 2 cm. Lalu biarkan 15-30 menit. Ini adonan bener2 super empuk deh."
- "Siapkan alas untuk mencetak dengan tepung biar gak lengket, bentuk adonan memanjang olesi adonan dengan air lalu taburi wijen/gula pasir. lalu potong kotak2. Setelah dipotong simpan adonannya Jgn terlalu berdempetan ya,kasih jarak."
- "Goreng adonan dengan minyak yg banyak dan api kecil sampai warnanya kecokelatan."
- "Siap sajikan...👩‍🍳😘asli ini empuk bgt dan enak deh..."
categories:
- Recipe
tags:
- kue
- bantal
- 

katakunci: kue bantal  
nutrition: 202 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Lunch

---


![Kue Bantal / Odading](https://img-global.cpcdn.com/recipes/4bc08754c50bd5b3/751x532cq70/kue-bantal-odading-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang setidaknya kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti kue bantal / odading yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan keistimewahan yang merupakan keragaman Indonesia



Keharmonisan rumah tangga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak Kue Bantal / Odading untuk keluarga. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang bisa anda buat salah satunya kue bantal / odading yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep kue bantal / odading tanpa harus bersusah payah.
Seperti resep Kue Bantal / Odading yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kue Bantal / Odading:

1. Harus ada 250 gr terigu
1. Diperlukan 2 sdm gula pasir
1. Diperlukan 100 ml air hangat
1. Tambah 1 sdt ragi instan (sy fermipan)
1. Siapkan 1 telur ayam utuh
1. Dibutuhkan 2 sdm skm
1. Jangan lupa 2 sdm margarine
1. Dibutuhkan 1/4 sdt vanili bubuk
1. Siapkan  Taburan :
1. Siapkan Secukupnya gula pasir atau wijen




<!--inarticleads2-->

##### Cara membuat  Kue Bantal / Odading:

1. Siapkan dulu bahan biang, campur ragi, gula pasir dan air hangat dlm satu wadah, aduk rata, diamkan kurleb 30menit - 1 jam. Tanda raginya aktif berbusa ya, klo gak berbusa buang dan bikin baru lg.
1. Dalam wadh terpisah, campurkan terigu, margarine, telur, skm dan vanili,uleni (sy blender).
1. Masukan cairan ragi td sedikit demi sedikit, sambil diuleni/mixer sampai benar2 kalis.
1. Pindahkan kedalam wadah yg sudah diolesi minyak tipis2. Tutup adonan dgn serbet, diamkan sampai mengembang 2x lipat(sy 2 jam)
1. Setelah mengembang, tinju2 adonan, pipihkan kurleb 2 cm. Lalu biarkan 15-30 menit. Ini adonan bener2 super empuk deh.
1. Siapkan alas untuk mencetak dengan tepung biar gak lengket, bentuk adonan memanjang olesi adonan dengan air lalu taburi wijen/gula pasir. lalu potong kotak2. Setelah dipotong simpan adonannya Jgn terlalu berdempetan ya,kasih jarak.
1. Goreng adonan dengan minyak yg banyak dan api kecil sampai warnanya kecokelatan.
1. Siap sajikan...👩‍🍳😘asli ini empuk bgt dan enak deh...




Demikianlah cara membuat kue bantal / odading yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
