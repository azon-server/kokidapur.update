---
description: "Langkah untuk menyiapakan Tahu Walik Aci Goreng (Jamur Shitake) Luar biasa"
title: "Langkah untuk menyiapakan Tahu Walik Aci Goreng (Jamur Shitake) Luar biasa"
slug: 343-langkah-untuk-menyiapakan-tahu-walik-aci-goreng-jamur-shitake-luar-biasa
date: 2020-09-11T09:10:05.374Z
image: https://img-global.cpcdn.com/recipes/b7b0d675f11f999e/751x532cq70/tahu-walik-aci-goreng-jamur-shitake-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b7b0d675f11f999e/751x532cq70/tahu-walik-aci-goreng-jamur-shitake-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b7b0d675f11f999e/751x532cq70/tahu-walik-aci-goreng-jamur-shitake-foto-resep-utama.jpg
author: Steve Meyer
ratingvalue: 4.6
reviewcount: 30287
recipeingredient:
- "6 buah tahu ukuran sedang goreng cukup garing"
- "9 sdm tepung tapioka"
- "3 sdm tepung terigu"
- "1/4 sdt lada bubuk"
- "1 sdm bawang putih bubuk"
- "1,5 sdt garam"
- "3 batang daun bawang potong potong"
- "100 gram jamur shitake kering"
- "50 gram udang kupas kulitnya"
- "100 ml air rendaman jamur panaskan"
- " Sambal Kecap "
- "2 buah cabe rawit sesuai selera"
- "1 siung bawang putih"
- "1 siung bawang merah"
- "sesuai selera Kecap manis"
recipeinstructions:
- "Cuci jamur lalu rendam dengan air panas. Pastikan bagian jamur terendam semua. Rendam hingga jamur empuk lalu iris sesuai selera. Lanjutkan mencincang kasar udang. Sisihkan."
- "Potong tahu menjadi 2 bagian. Balik tahu dan bagian putihnya ambil dan sisihkan."
- "Di wadah campur tapioka, terigu, lada bubuk, bawang putih bubuk, garam, jamur shitake, udang, daun bawang, bagian putih tahu goreng. Aduk rata lalu beri air rendaman jamur yang sudah dipanaskan. Aduk rata."
- "Beri adonan aci di bagian tahu yang berwarna coklat. Goreng di minyak panas api sedang hingga kuning kecoklatan."
- "Tiriskan dan sajikan hangat hangat dengan pelengkap sambal kecap dari cabe rawit, duo bawang diiris lalu digoreng, tiriskan (bisa diulek kalau suka) lalu di beri kecap manis."
- "Dalamnya cukup lembut meski sudah dingin. Dicocol sambal kecap makin mantap 👍"
categories:
- Recipe
tags:
- tahu
- walik
- aci

katakunci: tahu walik aci 
nutrition: 281 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Lunch

---


![Tahu Walik Aci Goreng (Jamur Shitake)](https://img-global.cpcdn.com/recipes/b7b0d675f11f999e/751x532cq70/tahu-walik-aci-goreng-jamur-shitake-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang dapat kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti tahu walik aci goreng (jamur shitake) yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Nusantara

Kedekatan rumah tangga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Tahu Walik Aci Goreng (Jamur Shitake) untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda praktekkan salah satunya tahu walik aci goreng (jamur shitake) yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep tahu walik aci goreng (jamur shitake) tanpa harus bersusah payah.
Seperti resep Tahu Walik Aci Goreng (Jamur Shitake) yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Tahu Walik Aci Goreng (Jamur Shitake):

1. Siapkan 6 buah tahu ukuran sedang, goreng cukup garing
1. Dibutuhkan 9 sdm tepung tapioka
1. Harus ada 3 sdm tepung terigu
1. Jangan lupa 1/4 sdt lada bubuk
1. Jangan lupa 1 sdm bawang putih bubuk
1. Harap siapkan 1,5 sdt garam
1. Jangan lupa 3 batang daun bawang, potong potong
1. Jangan lupa 100 gram jamur shitake kering
1. Jangan lupa 50 gram udang, kupas kulitnya
1. Tambah 100 ml air rendaman jamur, panaskan
1. Tambah  Sambal Kecap :
1. Harap siapkan 2 buah cabe rawit (sesuai selera)
1. Diperlukan 1 siung bawang putih
1. Dibutuhkan 1 siung bawang merah
1. Tambah sesuai selera Kecap manis




<!--inarticleads2-->

##### Instruksi membuat  Tahu Walik Aci Goreng (Jamur Shitake):

1. Cuci jamur lalu rendam dengan air panas. Pastikan bagian jamur terendam semua. Rendam hingga jamur empuk lalu iris sesuai selera. Lanjutkan mencincang kasar udang. Sisihkan.
1. Potong tahu menjadi 2 bagian. Balik tahu dan bagian putihnya ambil dan sisihkan.
1. Di wadah campur tapioka, terigu, lada bubuk, bawang putih bubuk, garam, jamur shitake, udang, daun bawang, bagian putih tahu goreng. Aduk rata lalu beri air rendaman jamur yang sudah dipanaskan. Aduk rata.
1. Beri adonan aci di bagian tahu yang berwarna coklat. Goreng di minyak panas api sedang hingga kuning kecoklatan.
1. Tiriskan dan sajikan hangat hangat dengan pelengkap sambal kecap dari cabe rawit, duo bawang diiris lalu digoreng, tiriskan (bisa diulek kalau suka) lalu di beri kecap manis.
1. Dalamnya cukup lembut meski sudah dingin. Dicocol sambal kecap makin mantap 👍




Demikianlah cara membuat tahu walik aci goreng (jamur shitake) yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
