---
description: "Resep : Roti Bantal / Roti Goreng Empuk Sempurna"
title: "Resep : Roti Bantal / Roti Goreng Empuk Sempurna"
slug: 16-resep-roti-bantal-roti-goreng-empuk-sempurna
date: 2020-12-25T13:07:16.414Z
image: https://img-global.cpcdn.com/recipes/be26d33cf66354b7/751x532cq70/roti-bantal-roti-goreng-empuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/be26d33cf66354b7/751x532cq70/roti-bantal-roti-goreng-empuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/be26d33cf66354b7/751x532cq70/roti-bantal-roti-goreng-empuk-foto-resep-utama.jpg
author: Frances Blake
ratingvalue: 4.6
reviewcount: 35053
recipeingredient:
- "125-150 gr Terigu Cakra"
- "1 butir Telur"
- "1 sdm Margarin"
- "1 sdm susu bubuk"
- "1 sdm Gula pasir"
- "50 ml air hangat"
- "1/2 sdt ragi instan"
- "1/4 sdt vanili"
- "Secukupnya wijen dan gula pasir"
recipeinstructions:
- "Buat biang dengan mencampur air hangat, gula pasir dan ragi. Aduk2. Diamkan 5-10 menit. (Kalau berbuih tanda ragi masih aktif)."
- "Dalam wadah masukkan terigu, margarin, telur, susu bubuk, dan vanili. Tuang bahan biang sedikit2 sambil diuleni hingga kalis."
- "Diamkan dan tutup adonan dengan kain / plastik hingga mengembang 2x lipat selama 45 menit - 1 jam."
- "Setelah mengembang kempeskan adonan. Ulen sebentar saja. Lalu pipihkan / gilas adonan setebal 2cm. Olesi adonan dengan air lalu taburi wijen dan gula pasir sambil ditekan-tekan biar wijen nya gak rontok. Potong2 adonan persegi panjang dan diamkan lagi sekitar 15 menit"
- "Goreng adonan di api kecil hingga kecoklatan. Sajikan"
- "Lembut banget dalamnya..Luarnya crispy renyah 😍"
categories:
- Recipe
tags:
- roti
- bantal
- 

katakunci: roti bantal  
nutrition: 177 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Dinner

---


![Roti Bantal / Roti Goreng Empuk](https://img-global.cpcdn.com/recipes/be26d33cf66354b7/751x532cq70/roti-bantal-roti-goreng-empuk-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti roti bantal / roti goreng empuk yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan ciri khas yang merupakan keragaman Nusantara

Kehangatan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak Roti Bantal / Roti Goreng Empuk untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang bisa anda buat salah satunya roti bantal / roti goreng empuk yang merupakan resep favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep roti bantal / roti goreng empuk tanpa harus bersusah payah.
Seperti resep Roti Bantal / Roti Goreng Empuk yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Roti Bantal / Roti Goreng Empuk:

1. Diperlukan 125-150 gr Terigu Cakra
1. Dibutuhkan 1 butir Telur
1. Dibutuhkan 1 sdm Margarin
1. Tambah 1 sdm susu bubuk
1. Dibutuhkan 1 sdm Gula pasir
1. Dibutuhkan 50 ml air hangat
1. Jangan lupa 1/2 sdt ragi instan
1. Tambah 1/4 sdt vanili
1. Harus ada Secukupnya wijen dan gula pasir




<!--inarticleads2-->

##### Cara membuat  Roti Bantal / Roti Goreng Empuk:

1. Buat biang dengan mencampur air hangat, gula pasir dan ragi. Aduk2. Diamkan 5-10 menit. (Kalau berbuih tanda ragi masih aktif).
1. Dalam wadah masukkan terigu, margarin, telur, susu bubuk, dan vanili. Tuang bahan biang sedikit2 sambil diuleni hingga kalis.
1. Diamkan dan tutup adonan dengan kain / plastik hingga mengembang 2x lipat selama 45 menit - 1 jam.
1. Setelah mengembang kempeskan adonan. Ulen sebentar saja. Lalu pipihkan / gilas adonan setebal 2cm. Olesi adonan dengan air lalu taburi wijen dan gula pasir sambil ditekan-tekan biar wijen nya gak rontok. Potong2 adonan persegi panjang dan diamkan lagi sekitar 15 menit
1. Goreng adonan di api kecil hingga kecoklatan. Sajikan
1. Lembut banget dalamnya..Luarnya crispy renyah 😍




Demikianlah cara membuat roti bantal / roti goreng empuk yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
