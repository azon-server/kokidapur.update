---
description: "Resep : Cireng Mercon isi Ayam Pedas Terbukti"
title: "Resep : Cireng Mercon isi Ayam Pedas Terbukti"
slug: 360-resep-cireng-mercon-isi-ayam-pedas-terbukti
date: 2020-12-20T13:22:25.166Z
image: https://img-global.cpcdn.com/recipes/986f70ab14d7be7d/751x532cq70/cireng-mercon-isi-ayam-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/986f70ab14d7be7d/751x532cq70/cireng-mercon-isi-ayam-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/986f70ab14d7be7d/751x532cq70/cireng-mercon-isi-ayam-pedas-foto-resep-utama.jpg
author: Martha Baker
ratingvalue: 4.6
reviewcount: 45730
recipeingredient:
- "500 gram Tepung Kanji"
- "1 genggam Tepung Terigu"
- "1 sdm Garam"
- "Secukupnya Air Panas Mendidih"
- " Isian"
- "1/2 kg Ayam Bagian Dada Ambil Dagingnya Aja"
- "3 batang Daun Bawang iris"
- "5 siung Bawang Putih"
- "1 ruas CikurKencur"
- "Sesuai selera Cabai Rawit Merah Lebih Banyak Lebih Pedas"
- "4 sdm Saos Sambal"
- "Secukupnya Garam"
- "Secukupnya Gula"
- "Secukupnya Penyedap Rasa Ayam"
recipeinstructions:
- "Buat isian dulu.. Rebus ayam tanpa tulang lalu suwir. Haluskan bawang putih, kencur, cabai rawit merah, lalu tumis. Masukkan ayam dan irisan daun bawang, aduk. Kasih garam, gula, penyedap rasa dan saos sambal. Sudah matang angkat dan biarkan dingin."
- "Buat kulit cirengnya.. Siapkan wadah masukkan tepung kanji, terigu, dan garam. Siram air panas mendidih sedikit demi sedikit sambil diaduk pakai centong nasi. Kalau sudah hangat bisa aduk pakai tangan. Uleni sampai kalis."
- "Giling2 adonan kulit, cetak bulat, masukkan isian lalu pilin (seperti memilin pastel). Atau bisa pakai cetakan pastel bahan plastik (lebih praktis 😊)"
- "Goreng cireng sampai kulitnga kering, angkat, sajikan dengan saos sambal.. Mantapppssss....!!!! 😋😋"
- "Tips : Agar cirengnya tidak Bledosss saat digoreng, dan kulitnya benar2 matang.. goreng cireng saat minyak masih dingin.. semoga bermanfaat.. 😘😘"
- "Selamat Mencoba.. 😊😊"
categories:
- Recipe
tags:
- cireng
- mercon
- isi

katakunci: cireng mercon isi 
nutrition: 153 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Lunch

---


![Cireng Mercon isi Ayam Pedas](https://img-global.cpcdn.com/recipes/986f70ab14d7be7d/751x532cq70/cireng-mercon-isi-ayam-pedas-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan empuk. Ciri khas kuliner Nusantara cireng mercon isi ayam pedas yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Keharmonisan keluarga dapat didapat dengan cara mudah. Salah satunya adalah memasak Cireng Mercon isi Ayam Pedas untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang bisa anda buat salah satunya cireng mercon isi ayam pedas yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep cireng mercon isi ayam pedas tanpa harus bersusah payah.
Seperti resep Cireng Mercon isi Ayam Pedas yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Cireng Mercon isi Ayam Pedas:

1. Harus ada 500 gram Tepung Kanji
1. Harap siapkan 1 genggam Tepung Terigu
1. Dibutuhkan 1 sdm Garam
1. Harap siapkan Secukupnya Air Panas Mendidih
1. Dibutuhkan  Isian
1. Tambah 1/2 kg Ayam Bagian Dada (Ambil Dagingnya Aja)
1. Siapkan 3 batang Daun Bawang iris
1. Harus ada 5 siung Bawang Putih
1. Diperlukan 1 ruas Cikur/Kencur
1. Harus ada Sesuai selera Cabai Rawit Merah (Lebih Banyak, Lebih Pedas)
1. Siapkan 4 sdm Saos Sambal
1. Dibutuhkan Secukupnya Garam
1. Harus ada Secukupnya Gula
1. Jangan lupa Secukupnya Penyedap Rasa Ayam




<!--inarticleads2-->

##### Langkah membuat  Cireng Mercon isi Ayam Pedas:

1. Buat isian dulu.. Rebus ayam tanpa tulang lalu suwir. Haluskan bawang putih, kencur, cabai rawit merah, lalu tumis. Masukkan ayam dan irisan daun bawang, aduk. Kasih garam, gula, penyedap rasa dan saos sambal. Sudah matang angkat dan biarkan dingin.
1. Buat kulit cirengnya.. Siapkan wadah masukkan tepung kanji, terigu, dan garam. Siram air panas mendidih sedikit demi sedikit sambil diaduk pakai centong nasi. Kalau sudah hangat bisa aduk pakai tangan. Uleni sampai kalis.
1. Giling2 adonan kulit, cetak bulat, masukkan isian lalu pilin (seperti memilin pastel). Atau bisa pakai cetakan pastel bahan plastik (lebih praktis 😊)
1. Goreng cireng sampai kulitnga kering, angkat, sajikan dengan saos sambal.. Mantapppssss....!!!! 😋😋
1. Tips : Agar cirengnya tidak Bledosss saat digoreng, dan kulitnya benar2 matang.. goreng cireng saat minyak masih dingin.. semoga bermanfaat.. 😘😘
1. Selamat Mencoba.. 😊😊




Demikianlah cara membuat cireng mercon isi ayam pedas yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
