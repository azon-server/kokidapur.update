---
description: "Resep : Soes Jepang (Choux Craquelin) Cepat"
title: "Resep : Soes Jepang (Choux Craquelin) Cepat"
slug: 85-resep-soes-jepang-choux-craquelin-cepat
date: 2020-11-30T02:17:29.296Z
image: https://img-global.cpcdn.com/recipes/ad7865bf9b56e492/751x532cq70/soes-jepang-choux-craquelin-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ad7865bf9b56e492/751x532cq70/soes-jepang-choux-craquelin-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ad7865bf9b56e492/751x532cq70/soes-jepang-choux-craquelin-foto-resep-utama.jpg
author: Adeline Chambers
ratingvalue: 4.3
reviewcount: 2064
recipeingredient:
- " Craquelin"
- "35 gr brown sugar"
- "35 gr tepung protein sedang"
- "30 gr butter"
- " Choux"
- "30 gr butter resep asli 60gr"
- "30 gr margarin"
- "Sejumput garam"
- "60 ml Susu UHT"
- "60 ml air resep asli full air 120ml tanpa susu ya"
- "75 gr tepung protein sedang"
- "2 butir telur"
- " Vla"
- "35 gr maizena"
- "1 butir kuning telur"
- "250 ml susu cair resep asli 350ml full susu ya"
- "100 ml whipped cream 50gr whipped cream bubuk100ml air"
- "40 gr gula pasir resep asli 55gr"
- "1 sdt vanilli"
- "1 sdt Rhum bakar boleh skip"
- "1/2 sdm butter"
recipeinstructions:
- "Siapkan Craquelin: campur semua bahan sampai kalis/bisa dibentuk lalu pipihkan dan bungkus dengan plastic wrap gilas rata sampai ketebalan kira2 0,5cm dan masukan di kulkas kira2 30menit atau sampai selesai siapin bahan soes."
- "Siapkan Soes: masukan semua bahan ke panci kecuali terigu dan telur; masak sampai mendidih lalu matikan kompor dan masukan terigu aduk sampai menyatu dan nyalakan lagi kompor aduk rata kurang lebih 3menit (pokoknya sampai adonan kalis)"
- "Masih persiapan Soes: pindahkan adonan tadi ke magkok/baskom diamkan sampai suhu ruang baru masukan telur satu persatu sambil diaduk sampai adonan menjadi satu dan mengkilat lalu masukan ke pipping bag pake spuit yang bolong bawahnya doank ngga ada bentuk2an kalo ngga punya spuit gunting aja bawahnya.. 😛 (jadi sekitar 18choux - bisa lebih kalo size lebih kecil)"
- "Soes dan Craquelin: setelah selesai semua di spuit, craquelin di keluarkan dari kulkas dan di cetak bulat2 saya pake tutup botol minuman, lalu taruh si craquelin diatas adonan choux; panggang 40menit dengan api 180° atau sesuaikan oven masing2 (tutup oven jangan dibuka supaya ngga kempes lagi ya, selesainya pun jangan langsung dikeluarin tunggu sampai buih2 &#34;panas&#34; di si choex/loyang hilang)"
- "Siapkan Vla: sambil panggang Soes tadi, bisa nyambi bikin vla.. campurkan semua bahan vla kecuali butter, masak sampai meletup2 baru masukan butter aduk rata dan vla siap"
- "Finishing: (saya) gunting Soes dan isi dengan Vla.. siap deh Choux au Craquelin atau Soes Jepangnya.. ngga nunggu sejam sudah habis.. dan mami hanya bisa menatap ngilerrrr 😂"
categories:
- Recipe
tags:
- soes
- jepang
- choux

katakunci: soes jepang choux 
nutrition: 141 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Lunch

---


![Soes Jepang (Choux Craquelin)](https://img-global.cpcdn.com/recipes/ad7865bf9b56e492/751x532cq70/soes-jepang-choux-craquelin-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang setidaknya kita jaga karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti soes jepang (choux craquelin) yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Kita



Kedekatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Soes Jepang (Choux Craquelin) untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang dapat anda praktekkan salah satunya soes jepang (choux craquelin) yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep soes jepang (choux craquelin) tanpa harus bersusah payah.
Berikut ini resep Soes Jepang (Choux Craquelin) yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 21 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Soes Jepang (Choux Craquelin):

1. Diperlukan  Craquelin:
1. Harus ada 35 gr brown sugar
1. Diperlukan 35 gr tepung protein sedang
1. Jangan lupa 30 gr butter
1. Dibutuhkan  Choux:
1. Diperlukan 30 gr butter (resep asli 60gr)
1. Dibutuhkan 30 gr margarin
1. Dibutuhkan Sejumput garam
1. Harus ada 60 ml Susu UHT
1. Jangan lupa 60 ml air (resep asli full air 120ml tanpa susu ya)
1. Harus ada 75 gr tepung protein sedang
1. Dibutuhkan 2 butir telur
1. Siapkan  Vla:
1. Harap siapkan 35 gr maizena
1. Siapkan 1 butir kuning telur
1. Harap siapkan 250 ml susu cair (resep asli 350ml, full susu ya)
1. Jangan lupa 100 ml whipped cream (50gr whipped cream bubuk+100ml air)
1. Harus ada 40 gr gula pasir (resep asli 55gr)
1. Harus ada 1 sdt vanilli
1. Jangan lupa 1 sdt Rhum bakar (boleh skip)
1. Jangan lupa 1/2 sdm butter




<!--inarticleads2-->

##### Bagaimana membuat  Soes Jepang (Choux Craquelin):

1. Siapkan Craquelin: campur semua bahan sampai kalis/bisa dibentuk lalu pipihkan dan bungkus dengan plastic wrap gilas rata sampai ketebalan kira2 0,5cm dan masukan di kulkas kira2 30menit atau sampai selesai siapin bahan soes.
1. Siapkan Soes: masukan semua bahan ke panci kecuali terigu dan telur; masak sampai mendidih lalu matikan kompor dan masukan terigu aduk sampai menyatu dan nyalakan lagi kompor aduk rata kurang lebih 3menit (pokoknya sampai adonan kalis)
1. Masih persiapan Soes: pindahkan adonan tadi ke magkok/baskom diamkan sampai suhu ruang baru masukan telur satu persatu sambil diaduk sampai adonan menjadi satu dan mengkilat lalu masukan ke pipping bag pake spuit yang bolong bawahnya doank ngga ada bentuk2an kalo ngga punya spuit gunting aja bawahnya.. 😛 (jadi sekitar 18choux - bisa lebih kalo size lebih kecil)
1. Soes dan Craquelin: setelah selesai semua di spuit, craquelin di keluarkan dari kulkas dan di cetak bulat2 saya pake tutup botol minuman, lalu taruh si craquelin diatas adonan choux; panggang 40menit dengan api 180° atau sesuaikan oven masing2 (tutup oven jangan dibuka supaya ngga kempes lagi ya, selesainya pun jangan langsung dikeluarin tunggu sampai buih2 &#34;panas&#34; di si choex/loyang hilang)
1. Siapkan Vla: sambil panggang Soes tadi, bisa nyambi bikin vla.. campurkan semua bahan vla kecuali butter, masak sampai meletup2 baru masukan butter aduk rata dan vla siap
1. Finishing: (saya) gunting Soes dan isi dengan Vla.. siap deh Choux au Craquelin atau Soes Jepangnya.. ngga nunggu sejam sudah habis.. dan mami hanya bisa menatap ngilerrrr 😂




Demikianlah cara membuat soes jepang (choux craquelin) yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
