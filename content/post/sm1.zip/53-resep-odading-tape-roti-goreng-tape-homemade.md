---
description: "Resep : Odading Tape / Roti Goreng Tape Homemade"
title: "Resep : Odading Tape / Roti Goreng Tape Homemade"
slug: 53-resep-odading-tape-roti-goreng-tape-homemade
date: 2020-11-20T03:29:52.270Z
image: https://img-global.cpcdn.com/recipes/d696b1a431f12d00/751x532cq70/odading-tape-roti-goreng-tape-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d696b1a431f12d00/751x532cq70/odading-tape-roti-goreng-tape-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d696b1a431f12d00/751x532cq70/odading-tape-roti-goreng-tape-foto-resep-utama.jpg
author: Harry Clark
ratingvalue: 4.8
reviewcount: 49486
recipeingredient:
- "400 gr tepung terigu"
- "100 gr tape singkong boleh d skip"
- "1 butir telur"
- "3 sdm gula"
- "1 sdm mentega"
- "1/2 sdt garam"
- "1/2 sachet vanili bubuk"
- " Bahan biang "
- "1/2 sachet ragi roti saft instant  fermipan"
- "1 sdm gula"
- "200 ml air hangat kuku"
- " Untuk toping "
- "50 gr wijen putih"
- "50 ml air utk olesan"
recipeinstructions:
- "Siapkan bahan"
- "Buat biang nya dulu.. campur semua bahan utk biang, aduk rata.. tunggu 10 menit &amp; pastikan kluar busa seperti di gambar.. ini fungsinya utk memastikan ragi masih aktif &amp; bagus.."
- "Sambil menunggu biang, lumatkan tape dgn bantuan garpu.. buang sumbunya.."
- "Masukkan semua bahan termasuk biang, kecuali mentega.. adon menggunakan tangan.."
- "Setelah adonan tercampur rata, lalu tambahkan mentega nya.. adon lagi menggunakan tangan.. jika masih lengket, tambahkan tepung terigu sedikit2.. sampai adonan tidak lengket lagi di tangan / Kalis.."
- "Sy adon sampai jadi seperti yg d foto.. Krn menggunakan tangan, jdi sulit utk kalis elastis.. yg penting adonan sdh tercampur rata &amp; tdk lengket lagi d tangan.. tapi hasilnya jg ttp memuaskan kok.. 😁"
- "Lalu bulatkan adonan dan tutup dengan serbet bersih.. diamkan +/- 30 menit, sampai adonan naik 2x lipat.."
- "Ini hasil adonan stlh naik 2x lipat.. lalu kempeskan adonan.."
- "Jika ingin dibentuk persegi, ambil adonan &amp; ratakan dgn rolling pin.. lalu potong2 bentuk persegi.. olesin permukaan roti dengan air lalu taburi wijennya.. biarkan adonan 10 menit, biar kembang lagi.."
- "Yg ini sy buat versi bulat.. dibulatin dulu, lalu pipihkan menggunakan tangan.. oles air &amp; taburi wijennya.. tunggu 10 menit biar kembang.."
- "Panaskan minyak.. lalu goreng rotinya dgn posisi wijennya diatas.. lalu balikkan stlh bagian bawah roti berwarna golden brown.. cukup 1 kali dibalik.."
- "Jika sdh mateng &amp; warnanya golden brown, angkat &amp; tiriskan.."
- "Tinggal ditata k piring saji.. 😋"
- "Ini penampakan dalamnya.. empyuuuk.. 😋🤤"
- "Kalaupun seandainya dimasak tanpa tape juga rasanya tetap enak, krn ini resep yg biasa sy pakai utk bwt donat.. 😍😋"
categories:
- Recipe
tags:
- odading
- tape
- 

katakunci: odading tape  
nutrition: 254 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dinner

---


![Odading Tape / Roti Goreng Tape](https://img-global.cpcdn.com/recipes/d696b1a431f12d00/751x532cq70/odading-tape-roti-goreng-tape-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga empuk. Karasteristik masakan Nusantara odading tape / roti goreng tape yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Odading Tape / Roti Goreng Tape untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang bisa anda praktekkan salah satunya odading tape / roti goreng tape yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep odading tape / roti goreng tape tanpa harus bersusah payah.
Berikut ini resep Odading Tape / Roti Goreng Tape yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 15 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Odading Tape / Roti Goreng Tape:

1. Diperlukan 400 gr tepung terigu
1. Dibutuhkan 100 gr tape singkong (boleh d skip)
1. Jangan lupa 1 butir telur
1. Diperlukan 3 sdm gula
1. Tambah 1 sdm mentega
1. Jangan lupa 1/2 sdt garam
1. Harus ada 1/2 sachet vanili bubuk
1. Dibutuhkan  Bahan biang :
1. Diperlukan 1/2 sachet ragi roti (saft instant / fermipan)
1. Harus ada 1 sdm gula
1. Tambah 200 ml air hangat kuku
1. Harap siapkan  Untuk toping :
1. Tambah 50 gr wijen putih
1. Dibutuhkan 50 ml air (utk olesan)




<!--inarticleads2-->

##### Langkah membuat  Odading Tape / Roti Goreng Tape:

1. Siapkan bahan
1. Buat biang nya dulu.. campur semua bahan utk biang, aduk rata.. tunggu 10 menit &amp; pastikan kluar busa seperti di gambar.. ini fungsinya utk memastikan ragi masih aktif &amp; bagus..
1. Sambil menunggu biang, lumatkan tape dgn bantuan garpu.. buang sumbunya..
1. Masukkan semua bahan termasuk biang, kecuali mentega.. adon menggunakan tangan..
1. Setelah adonan tercampur rata, lalu tambahkan mentega nya.. adon lagi menggunakan tangan.. jika masih lengket, tambahkan tepung terigu sedikit2.. sampai adonan tidak lengket lagi di tangan / Kalis..
1. Sy adon sampai jadi seperti yg d foto.. Krn menggunakan tangan, jdi sulit utk kalis elastis.. yg penting adonan sdh tercampur rata &amp; tdk lengket lagi d tangan.. tapi hasilnya jg ttp memuaskan kok.. 😁
1. Lalu bulatkan adonan dan tutup dengan serbet bersih.. diamkan +/- 30 menit, sampai adonan naik 2x lipat..
1. Ini hasil adonan stlh naik 2x lipat.. lalu kempeskan adonan..
1. Jika ingin dibentuk persegi, ambil adonan &amp; ratakan dgn rolling pin.. lalu potong2 bentuk persegi.. olesin permukaan roti dengan air lalu taburi wijennya.. biarkan adonan 10 menit, biar kembang lagi..
1. Yg ini sy buat versi bulat.. dibulatin dulu, lalu pipihkan menggunakan tangan.. oles air &amp; taburi wijennya.. tunggu 10 menit biar kembang..
1. Panaskan minyak.. lalu goreng rotinya dgn posisi wijennya diatas.. lalu balikkan stlh bagian bawah roti berwarna golden brown.. cukup 1 kali dibalik..
1. Jika sdh mateng &amp; warnanya golden brown, angkat &amp; tiriskan..
1. Tinggal ditata k piring saji.. 😋
1. Ini penampakan dalamnya.. empyuuuk.. 😋🤤
1. Kalaupun seandainya dimasak tanpa tape juga rasanya tetap enak, krn ini resep yg biasa sy pakai utk bwt donat.. 😍😋




Demikianlah cara membuat odading tape / roti goreng tape yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan cepat, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
