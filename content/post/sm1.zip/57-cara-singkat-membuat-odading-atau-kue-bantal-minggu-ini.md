---
description: "Cara singkat membuat Odading atau kue bantal minggu ini"
title: "Cara singkat membuat Odading atau kue bantal minggu ini"
slug: 57-cara-singkat-membuat-odading-atau-kue-bantal-minggu-ini
date: 2020-11-14T16:58:42.897Z
image: https://img-global.cpcdn.com/recipes/011e2b5f13929f29/751x532cq70/odading-atau-kue-bantal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/011e2b5f13929f29/751x532cq70/odading-atau-kue-bantal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/011e2b5f13929f29/751x532cq70/odading-atau-kue-bantal-foto-resep-utama.jpg
author: Harold McDaniel
ratingvalue: 4.3
reviewcount: 11940
recipeingredient:
- "250 gram tepung terigu"
- "100 gram gula pasir"
- "1 butir telur"
- "1 sdt fermipan"
- "1/4 kurang garam"
- "secukupnya air"
recipeinstructions:
- "Campurkan dahulu tepung terigu dan gula(ayak dahulu ya tepungnya)"
- "Kemudian masukkan telur, tambahkan fermipan dan tambahkan garam"
- "Tambahkan air aduk semua adonan sampai tercampur rata. Uleni sampai kalis."
- "Kalau sudah kalis istirahatkan dahulu adonan 1jam an. Dengan ditutup plastik wrap."
- "Setelah kurang lebih satujam lalu kempiskan dan potong-potong adonan sesuai dengan selera aja ukurannya"
- "Dan kemudian digoreng ya, kalau aku biar cantik warnanya kubalik balik dan disiram-siramkan minyaknya."
- "Taraa dah matang dalamnya empuk banget. Enak bener dimakan panas-panas sambil ngopi makjleb deh..."
categories:
- Recipe
tags:
- odading
- atau
- kue

katakunci: odading atau kue 
nutrition: 267 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT60M"
recipeyield: "2"
recipecategory: Lunch

---


![Odading atau kue bantal](https://img-global.cpcdn.com/recipes/011e2b5f13929f29/751x532cq70/odading-atau-kue-bantal-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan gurih. Karasteristik kuliner Nusantara odading atau kue bantal yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Odading atau kue bantal untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.

Campurkan dahulu tepung terigu dan gula (ayak dahulu ya tepungnya). Kemudian masukkan telur, tambahkan fermipan dan tambahkan garam. resep odading simpel kue bantal , tips supaya kopong. ODADING / Kue Bantal - Jajanan Bandung.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang dapat anda contoh salah satunya odading atau kue bantal yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep odading atau kue bantal tanpa harus bersusah payah.
Berikut ini resep Odading atau kue bantal yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Odading atau kue bantal:

1. Jangan lupa 250 gram tepung terigu
1. Tambah 100 gram gula pasir
1. Siapkan 1 butir telur
1. Jangan lupa 1 sdt fermipan
1. Dibutuhkan 1/4 kurang garam
1. Harus ada secukupnya air


Namanya bolang-baling, tekstur dan bentuk rotinya sama persis. Odading atau Cakue Bantal atau Donat Kopong. PagesPublic FigureVideo CreatorEpipastryVideosOdading atau Cakue Bantal atau Donat Kopong. Odading adalah jajanan khas Paling enak disantap bersama dengan kopi atau teh. 

<!--inarticleads2-->

##### Langkah membuat  Odading atau kue bantal:

1. Campurkan dahulu tepung terigu dan gula(ayak dahulu ya tepungnya)
1. Kemudian masukkan telur, tambahkan fermipan dan tambahkan garam
1. Tambahkan air aduk semua adonan sampai tercampur rata. Uleni sampai kalis.
1. Kalau sudah kalis istirahatkan dahulu adonan 1jam an. Dengan ditutup plastik wrap.
1. Setelah kurang lebih satujam lalu kempiskan dan potong-potong adonan sesuai dengan selera aja ukurannya
1. Dan kemudian digoreng ya, kalau aku biar cantik warnanya kubalik balik dan disiram-siramkan minyaknya.
1. Taraa dah matang dalamnya empuk banget. Enak bener dimakan panas-panas sambil ngopi makjleb deh...


PagesPublic FigureVideo CreatorEpipastryVideosOdading atau Cakue Bantal atau Donat Kopong. Odading adalah jajanan khas Paling enak disantap bersama dengan kopi atau teh. Selain disebut roti goreng, odading juga memiliki nama sebutan lainnya, yaitu roti bantal. Odading is Sundanese fried sweet bread found in West Java region. It is a part of Sundanese cuisine. 

Demikianlah cara membuat odading atau kue bantal yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan cepat, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
