---
description: "Step-by-Step Guide to Prepare Ultimate Bubur Kacang Ijo Praktis"
title: "Step-by-Step Guide to Prepare Ultimate Bubur Kacang Ijo Praktis"
slug: 103-step-by-step-guide-to-prepare-ultimate-bubur-kacang-ijo-praktis

<p>
	<strong>Bubur Kacang Ijo Praktis</strong>. 
	Masak bubur kacang hijau dan ketan hitam itu susah-susah gampang. Tapi sekarang aku ga perlu lagi. Selamat datang dichannel daftar masak!resep cara membuat bubur kacang ijo ketan hitam.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/24e3299f7e0fd2e8/680x482cq70/bubur-kacang-ijo-praktis-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Praktis" style="width: 100%;">
	
	
		Bubur Kacang Ijo adalah makanan berbahan utama kacang hijau yang biasa dikonsumsi oleh masyarakat Indonesia.
	
		Bubur kacang hijau bisa dibikin tanpa santan, kuah cukup pakai air dan gula merah.
	
		Kacang hijau direbus sampai empuk dengan daun pandan.
	
</p>
<p>
	Hey everyone, hope you are having an incredible day today. Today, I'm gonna show you how to prepare a distinctive dish, bubur kacang ijo praktis. It is one of my favorites food recipes. For mine, I am going to make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo Praktis is one of the most favored of current trending meals on earth. It is simple, it is quick, it tastes delicious. It is enjoyed by millions daily. They're nice and they look fantastic. Bubur Kacang Ijo Praktis is something that I have loved my whole life.
</p>
<p>
	Masak bubur kacang hijau dan ketan hitam itu susah-susah gampang. Tapi sekarang aku ga perlu lagi. Selamat datang dichannel daftar masak!resep cara membuat bubur kacang ijo ketan hitam.
</p>

<p>
To begin with this recipe, we must prepare a few components. You can cook bubur kacang ijo praktis using 9 ingredients and 4 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Praktis:</h3>

<ol>
	
		<li>{Prepare 250 gr of Kacang Ijo. </li>
	
		<li>{Take 5-7 keping of gula merah (seperlunya). </li>
	
		<li>{Take 1/2 sdt of garam. </li>
	
		<li>{Make ready  of ⁵ sdm gula pasir (seperlunya). </li>
	
		<li>{Take 1 lbr of daun pandan (simpulkan). </li>
	
		<li>{Take 1 ruas of jahe (kupas kulit lalu geprek). </li>
	
		<li>{Make ready 1 bks of santan kara (65ml). </li>
	
		<li>{Prepare 50 ml of SKM. </li>
	
		<li>{Prepare 1500 ml of air. </li>
	
</ol>
<p>
	
		KOMPAS.com - Olahan kacang hijau dapat menjadi sarapan praktis, cukup dijadikan bubur tanpa santan dengan tambahan gula merah.
	
		Bubur kacang hijau, abbreviated burjo, is a Southeast Asian sweet porridge (bubur) made from mung beans (kacang hijau), coconut milk, and palm sugar or cane sugar.
	
		Kacang hijau / ijo merupakan salah satu bahan makanan yang bukan saja enak di buat minuman maupun makanan.
	
		Es bubur kacang hijau sangat nikmat dan segar.
	
</p>

<h3>Steps to make Bubur Kacang Ijo Praktis:</h3>

<ol>
	
		<li>
			Siapkan bahan-bahan dan Cuci bersih kacang ijo dan rendam agar terlihat kacang ijo yg mengapung (buang untuk yg mengapung).
			
			
		</li>
	
		<li>
			Panaskan panci yg sudah terisi air.. biarkan hingga mendidih... Lalu masukkan kacang ijo.. masak hingga kacang mengelupas...
			
			
		</li>
	
		<li>
			Jika kacang sudah mengelupas tambahkan gulpas, garam, daun pandan dan jahe.. aduk rata.
			
			
		</li>
	
		<li>
			Biarkan hingga kacang empuk.. test rasa... Lalu masukkan santan kara aduk hingga rata.. terakhir tambahkan susu kental manis... Aduk lagi hingga tercampur rata... Terakhir test rasa final jika semua sudah pas rasanya matikan kompor dan pindahkan ke mangkok saji... Selamat mencoba 💜💜💜.
			
			
		</li>
	
</ol>

<p>
	
		Inilah petunjuk komplit cara membuat bubur kacang ijo secara cepat dan praktis.
	
		Menyantap bubur kacang hijau di sore hari apalagi saat cuaca dingin merupakan pilihan yang tepat.
	
		Berikut ini akan dijelaskan cara membuat bubur kacang hijau yang praktis Resep membuat bubur kacang hijau.
	
		Bubur kacang hijau biji salak. foto: Instagram/@t_finna.
	
		Cara Membuat Bubur Kacang Hijau Mudah Praktis.
	
</p>

<p>
	So that is going to wrap it up for this special food bubur kacang ijo praktis recipe. Thanks so much for reading. I am sure that you will make this at home. There's gonna be interesting food in home recipes coming up. Remember to bookmark this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
