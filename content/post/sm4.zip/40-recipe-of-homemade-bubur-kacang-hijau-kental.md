---
description: "Recipe of Homemade Bubur Kacang Hijau Kental"
title: "Recipe of Homemade Bubur Kacang Hijau Kental"
slug: 40-recipe-of-homemade-bubur-kacang-hijau-kental

<p>
	<strong>Bubur Kacang Hijau Kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/cc4d6120559148e7/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an incredible day today. Today, I'm gonna show you how to make a distinctive dish, bubur kacang hijau kental. One of my favorites food recipes. This time, I am going to make it a bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Hijau Kental is one of the most well liked of current trending foods in the world. It is easy, it's fast, it tastes delicious. It is appreciated by millions daily. Bubur Kacang Hijau Kental is something that I've loved my whole life. They're nice and they look wonderful.
</p>

<p>
To get started with this particular recipe, we have to prepare a few components. You can cook bubur kacang hijau kental using 11 ingredients and 4 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>{Prepare 250 gram of kacang hijau. </li>
	
		<li>{Make ready 1 liter of air. </li>
	
		<li>{Make ready 4 buah of gula merah, sisir. </li>
	
		<li>{Get 2 sdm of gula pasir. </li>
	
		<li>{Get 1 ruas of jahe, geprek. </li>
	
		<li>{Prepare 2 sdm of tepung sagu, campur dengan sedikit air. </li>
	
		<li>{Make ready 2 lembar of daun pandan. </li>
	
		<li>{Take  of Kuah santan:. </li>
	
		<li>{Make ready 500 ml of santan kental. </li>
	
		<li>{Make ready Secukupnya of garam. </li>
	
		<li>{Get 1 lembar of daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>
			Rendam kacang hijau semalaman. Cuci bersih kacang hijau lalu rebus kacang hijau sampai empuk..
			
			
		</li>
	
		<li>
			Tambahkan gula merah, gula pasir, daun pandan dan jahe. Setelah gula larut dan air menyusut, tambahkan larutan sagu, masak sampai kental dan mendidih. Matikan api..
			
			
		</li>
	
		<li>
			Membuat kuah santan: masak santan dengan garam dan daun pandan. Aduk-aduk supaya santan tidak pecah, masak sampai mendidih..
			
			
		</li>
	
		<li>
			Cara penyajian: taruh bubur kacang hijau dalam mangkuk, lalu siram dengan kuah santan. Sajikan hangat 😘.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this special food bubur kacang hijau kental recipe. Thank you very much for reading. I am confident you can make this at home. There's gonna be interesting food in home recipes coming up. Don't forget to save this page in your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
