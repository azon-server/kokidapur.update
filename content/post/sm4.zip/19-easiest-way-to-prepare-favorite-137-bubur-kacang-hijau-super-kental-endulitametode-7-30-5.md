---
description: "Easiest Way to Prepare Favorite #137 Bubur Kacang Hijau Super Kental, Endulita(Metode 7 30 5)"
title: "Easiest Way to Prepare Favorite #137 Bubur Kacang Hijau Super Kental, Endulita(Metode 7 30 5)"
slug: 19-easiest-way-to-prepare-favorite-137-bubur-kacang-hijau-super-kental-endulitametode-7-30-5

<p>
	<strong>#137 Bubur Kacang Hijau Super Kental, Endulita(Metode 7 30 5)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/de0e41d38b70a3c5/680x482cq70/137-bubur-kacang-hijau-super-kental-endulitametode-7-30-5-foto-resep-utama.jpg" alt="#137 Bubur Kacang Hijau Super Kental, Endulita(Metode 7 30 5)" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is John, welcome to our recipe page. Today, I will show you a way to prepare a distinctive dish, #137 bubur kacang hijau super kental, endulita(metode 7 30 5). It is one of my favorites. For mine, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	#137 Bubur Kacang Hijau Super Kental, Endulita(Metode 7 30 5) is one of the most popular of current trending foods in the world. It's simple, it is quick, it tastes delicious. It is appreciated by millions daily. They're fine and they look fantastic. #137 Bubur Kacang Hijau Super Kental, Endulita(Metode 7 30 5) is something that I have loved my entire life.
</p>

<p>
To begin with this recipe, we must first prepare a few components. You can have #137 bubur kacang hijau super kental, endulita(metode 7 30 5) using 10 ingredients and 4 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make #137 Bubur Kacang Hijau Super Kental, Endulita(Metode 7 30 5):</h3>

<ol>
	
		<li>{Get 125 gr of kacang hijau. </li>
	
		<li>{Take 4 butir of gula merah uk kecil bulat. </li>
	
		<li>{Take 2 sdm of gula pasir. </li>
	
		<li>{Make ready 2 sdt of garam. </li>
	
		<li>{Make ready 1/2 sdt of vanilli. </li>
	
		<li>{Make ready 1 ruas jari of jahe, geprek. </li>
	
		<li>{Make ready 2 lbr of daun pandan. </li>
	
		<li>{Prepare 2 bungkus of santan kara. </li>
	
		<li>{Make ready 3 sdm of maizena, larutkan dalam 2sdm air. </li>
	
		<li>{Make ready 600 ml of air. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make #137 Bubur Kacang Hijau Super Kental, Endulita(Metode 7 30 5):</h3>

<ol>
	
		<li>
			Setelah kacang hijau dicuci bersih, rendam selama 1jam, 2 jam lebih baik lagi ya. Setelah itu rebus air hingga mendidih lalu masukkan kacang hijau yang telah direndam bersama dengan jahe geprek dan daun pandan. Rebus selama 7 menit..
			
			
		</li>
	
		<li>
			Setelah 7 menit, matikan kompor diamkan selama 30 menit tanpa membuka tutup panci. Selepas 30 menit, nyalakan kembali api kompor dan rebus selama 5 menit. Jadi selama proses metode 7 30 5, tutup panci jangan pernah dibuka..
			
			
		</li>
	
		<li>
			Pastikan kacang hijau telah benar-benar lunak. Lalu masukkan irisan gula jawa dan gula pasir, serta larutan maizena. NOTE: Kalau dirasa air terlalu banyak, sebelum memasukkan larutan maizena dan gula, maka buang terlebih dahulu airnya.

Aduk kacang hijau sampai gula larut dan adonan mengental. Kalau sudah matikan api..
			
			
		</li>
	
		<li>
			Untuk santan, masak 2 bungkus santan kara dengan 500ml air bersama 1 lembar daun pandan. Beri 1sdt garam(optional, boleh diskip untuk pemakaian garam). Masak hingga mendidih. Sajikan bersama dengan kacang hijau kental..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this exceptional food #137 bubur kacang hijau super kental, endulita(metode 7 30 5) recipe. Thanks so much for your time. I'm sure you will make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to save this page in your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
