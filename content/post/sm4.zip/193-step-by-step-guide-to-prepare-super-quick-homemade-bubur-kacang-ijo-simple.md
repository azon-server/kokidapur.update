---
description: "Step-by-Step Guide to Prepare Super Quick Homemade Bubur Kacang Ijo SIMPLE"
title: "Step-by-Step Guide to Prepare Super Quick Homemade Bubur Kacang Ijo SIMPLE"
slug: 193-step-by-step-guide-to-prepare-super-quick-homemade-bubur-kacang-ijo-simple

<p>
	<strong>Bubur Kacang Ijo SIMPLE</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/a2e2ddfe9980cdbb/680x482cq70/bubur-kacang-ijo-simple-foto-resep-utama.jpg" alt="Bubur Kacang Ijo SIMPLE" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you are having an incredible day today. Today, I'm gonna show you how to make a distinctive dish, bubur kacang ijo simple. One of my favorites. This time, I am going to make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo SIMPLE is one of the most well liked of recent trending foods on earth. It's appreciated by millions every day. It is easy, it's fast, it tastes delicious. Bubur Kacang Ijo SIMPLE is something which I've loved my entire life. They're fine and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we must prepare a few ingredients. You can have bubur kacang ijo simple using 7 ingredients and 4 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo SIMPLE:</h3>

<ol>
	
		<li>{Get 1/4 of kacang hijau. </li>
	
		<li>{Prepare 1/4 of Gula merah (bebas gula putih bisa). </li>
	
		<li>{Make ready 1 1/2 gayung of air bersih. </li>
	
		<li>{Prepare 2 SDM of tepung sagu/aci (Larutkan dgn sedkit air). </li>
	
		<li>{Get 1 of santan kara. </li>
	
		<li>{Take 1 of daun pandan besar. </li>
	
		<li>{Make ready  of Jahe UK sedang (Geprek). </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo SIMPLE:</h3>

<ol>
	
		<li>
			Didihkan air, lalu masukan kacang hijau, daun pandan, jahe &amp; gula. tutup tunggu 5mnt mendidih.
			
			
		</li>
	
		<li>
			Matikan kompor tunggu hingga 30mnt. Ditutup ya.
			
			
		</li>
	
		<li>
			Nyalakan kompor. Masak hingga matang, lalu masukan santan &amp; larutan tepung sagu/aci.
			
			
		</li>
	
		<li>
			Fungsi tepung sagu/Aci yaitu biar tekstur air kental.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this special food bubur kacang ijo simple recipe. Thanks so much for your time. I am confident that you can make this at home. There is gonna be interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
