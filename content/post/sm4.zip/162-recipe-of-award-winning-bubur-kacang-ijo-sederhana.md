---
description: "Recipe of Award-winning Bubur Kacang Ijo Sederhana"
title: "Recipe of Award-winning Bubur Kacang Ijo Sederhana"
slug: 162-recipe-of-award-winning-bubur-kacang-ijo-sederhana

<p>
	<strong>Bubur Kacang Ijo Sederhana</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/2ef68d0cac8abe11/680x482cq70/bubur-kacang-ijo-sederhana-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Sederhana" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Drew, welcome to our recipe site. Today, we're going to prepare a special dish, bubur kacang ijo sederhana. It is one of my favorites. This time, I am going to make it a bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo Sederhana is one of the most popular of current trending meals on earth. It's easy, it is fast, it tastes yummy. It is enjoyed by millions every day. Bubur Kacang Ijo Sederhana is something which I've loved my whole life. They are nice and they look fantastic.
</p>

<p>
To begin with this particular recipe, we must first prepare a few ingredients. You can cook bubur kacang ijo sederhana using 7 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Sederhana:</h3>

<ol>
	
		<li>{Make ready 1 of gelas kacang hijau. </li>
	
		<li>{Get 1 bungkus of santan kara. </li>
	
		<li>{Prepare 2 buah of gula merah. </li>
	
		<li>{Prepare  of Jahe secukupnya di geprek. </li>
	
		<li>{Get secukupnya of Garam. </li>
	
		<li>{Get  of Daun pandan secukupnya dibuat simpul. </li>
	
		<li>{Get 500 ml of air mineral. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo Sederhana:</h3>

<ol>
	
		<li>
			Rendam terlebih dahulu kacang hijau supaya mudah empuk saat di masak kurleb 2 jam..
			
			
		</li>
	
		<li>
			Jika kacang sudah merekah cuci kembali, tiriskan. Siapkan panci panaskan air, masukan kacang hijau, biarkan mendidih..
			
			
		</li>
	
		<li>
			Masukan gula merah, sedikit garam, jahe geprek dan daun pandan. Masak hingga kacang menjadi agak kental dan lembut..
			
			
		</li>
	
		<li>
			Di panci terpisah, masak santan kara dengan sedikit air, supaya santan tetap kental saat dituang di atas bubur kacang hijaunya..
			
			
		</li>
	
		<li>
			Jika bubur sudah matang, siapkan mangkuk untuk tempatnya. Siram diatas bubur kuah santan kara. Hias dan siap di sajikan. Selamat mencoba bunda&#34; cantik. Semoga berhasil ya..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this special food bubur kacang ijo sederhana recipe. Thank you very much for reading. I'm confident you will make this at home. There is gonna be more interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
