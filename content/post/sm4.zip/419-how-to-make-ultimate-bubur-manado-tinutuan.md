---
description: "How to Make Ultimate Bubur Manado/Tinutuan"
title: "How to Make Ultimate Bubur Manado/Tinutuan"
slug: 419-how-to-make-ultimate-bubur-manado-tinutuan

<p>
	<strong>Bubur Manado/Tinutuan</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/84dd3929ba4f38c6/680x482cq70/bubur-manadotinutuan-foto-resep-utama.jpg" alt="Bubur Manado/Tinutuan" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's Jim, welcome to our recipe site. Today, I will show you a way to make a special dish, bubur manado/tinutuan. It is one of my favorites food recipes. For mine, I will make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Manado/Tinutuan is one of the most popular of current trending meals on earth. It's appreciated by millions daily. It is simple, it is fast, it tastes delicious. Bubur Manado/Tinutuan is something that I have loved my whole life. They're fine and they look wonderful.
</p>

<p>
To get started with this recipe, we must prepare a few components. You can cook bubur manado/tinutuan using 20 ingredients and 9 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Manado/Tinutuan:</h3>

<ol>
	
		<li>{Get 2 genggam of beras. </li>
	
		<li>{Make ready 2 buah of ubi jalar (saya pakai yg ukuran besar dan kecil). </li>
	
		<li>{Prepare 1/2 buah of labu kecil. </li>
	
		<li>{Take  of Rempah-rempah. </li>
	
		<li>{Take 1 buah of serai. </li>
	
		<li>{Take 2 lembar of daun kunyit. </li>
	
		<li>{Make ready 2 siung of bawang merah. </li>
	
		<li>{Get 2 siung of bawang putih. </li>
	
		<li>{Take Secukupnya of kemangi (sesuai selera). </li>
	
		<li>{Get  of Minyak goreng (secukupnya utk menumis). </li>
	
		<li>{Get secukupnya of Garam. </li>
	
		<li>{Make ready  of Bahan Sayuran. </li>
	
		<li>{Prepare 1 ikat of bayam (merah/hijau). </li>
	
		<li>{Prepare 1 ikat of kangkung. </li>
	
		<li>{Make ready 1 ikat of gedi (optional). </li>
	
		<li>{Get secukupnya of Garam. </li>
	
		<li>{Make ready  of Bahan Tumis Sayuran. </li>
	
		<li>{Take 3 siung of bawang putih. </li>
	
		<li>{Prepare 3 siung of bawang merah. </li>
	
		<li>{Make ready  of Minyak goreng (secukupnya). </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Manado/Tinutuan:</h3>

<ol>
	
		<li>
			Panaskan panci, kemudian masukkan minyak goreng.
			
			
		</li>
	
		<li>
			Setelah itu, masukkan bawang merah &amp; putih dari rempah2.
			
			
		</li>
	
		<li>
			Setelah wangi, masukkan bahan rempah.
			
			
		</li>
	
		<li>
			Kemudian, masukkan air. Tidak perlu tunggu mendidih, langsung masukkan beras. Tunggu sampai 2-3 menit. Kemudian masukkan labu dan ubi jalar. Tunggu sampai semua bahannya lembut..
			
			
		</li>
	
		<li>
			Apabila sudah lembut, hancurkan labu satu per satu, agar bubur tidak pucat..
			
			
		</li>
	
		<li>
			Setelah itu, tambahkan garam. Koreksi rasa..
			
			
		</li>
	
		<li>
			Panaskan wajan. Kemudian masukkan bahan tumis sayuran..
			
			
		</li>
	
		<li>
			Setelah wangi, masukkan bahan sayuran dan garam. Koreksi rasa..
			
			
		</li>
	
		<li>
			Setelah sayuran matang, masukkan bubur yg sudah jadi ke dalam wajan dan aduk rata. Kemudian tinutuan siap disajikan. Bisa tambahkan lauk tahu dan juga ikan asin. Jangan lupa sambal terasi atau sambal roa..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this special food bubur manado/tinutuan recipe. Thank you very much for reading. I am sure that you will make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
