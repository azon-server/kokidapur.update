---
description: "Recipe of Quick Tinutuan Bubur Manado"
title: "Recipe of Quick Tinutuan Bubur Manado"
slug: 468-recipe-of-quick-tinutuan-bubur-manado

<p>
	<strong>Tinutuan Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/cfd51c83f4a5cb13/680x482cq70/tinutuan-bubur-manado-foto-resep-utama.jpg" alt="Tinutuan Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you are having an amazing day today. Today, I'm gonna show you how to make a special dish, tinutuan bubur manado. It is one of my favorites. For mine, I'm gonna make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	Tinutuan Bubur Manado is one of the most favored of recent trending meals on earth. It is appreciated by millions daily. It's simple, it is quick, it tastes yummy. Tinutuan Bubur Manado is something that I have loved my whole life. They're fine and they look wonderful.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we must first prepare a few ingredients. You can have tinutuan bubur manado using 21 ingredients and 10 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Tinutuan Bubur Manado:</h3>

<ol>
	
		<li>{Prepare 2 cup of beras. </li>
	
		<li>{Prepare 2 bh of jagung, pipil. </li>
	
		<li>{Make ready 1 btg of singkong. </li>
	
		<li>{Get 200 gr of ubi kuning (saya: skip). </li>
	
		<li>{Prepare 300 gr of labu kuning, kukus. </li>
	
		<li>{Prepare 1,5 lt of air kaldu. </li>
	
		<li>{Get  of Bahan sayur :. </li>
	
		<li>{Make ready 5 of lb daun Gedi (gak ada). </li>
	
		<li>{Make ready 1 of lb daun kunyit. </li>
	
		<li>{Prepare 2 btg of daun bawang. </li>
	
		<li>{Take 1 ikat of kangkung. </li>
	
		<li>{Prepare 1 ikat of bayam. </li>
	
		<li>{Prepare 2 ikat of kemangi. </li>
	
		<li>{Take  of Bumbu daun :. </li>
	
		<li>{Take 2 btg of serai, memarkan. </li>
	
		<li>{Make ready 1 ruas of lengkuas, memarkan. </li>
	
		<li>{Get 3 of lb daun salam. </li>
	
		<li>{Make ready 2 siung of bawang merah. </li>
	
		<li>{Prepare 2 siung of bawang putih. </li>
	
		<li>{Prepare 1/2 sdt of merica. </li>
	
		<li>{Make ready 1 sdm of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Tinutuan Bubur Manado:</h3>

<ol>
	
		<li>
			Kukus labu kuning, haluskan. Potong dadu singkong. Pipil jagung manis..
			
			
		</li>
	
		<li>
			Iris halus daun gedi, daun kunyit, dan daun bawang. Potong kasar kangkung dan bayam. Petiki kemangi. Cuci bersih semuanya..
			
			
		</li>
	
		<li>
			Memarkan serai dan lengkuas. Iris halus bawang putih dan bawang merah..
			
			
		</li>
	
		<li>
			Cuci bersih beras. Masak beras dalam wajan besar dengan perbandingan air 1:4 masukkan singkong, labu kuning yg sudah dihaluskan dan jagung manis dalam rebusan beras, tunggu hingga air menyusut..
			
			
		</li>
	
		<li>
			Masukkan serai, lengkuas dan daun salam. Aduk bubur sesekali agar bubur tidak lengket di wajan..
			
			
		</li>
	
		<li>
			Setelah air menyusut masukkan daun gedi, daun kunyit, bayam, kangkung, dan irisan bawang putih bawang merah,. Aduk lagi..
			
			
		</li>
	
		<li>
			Masukkan daun kemangi dan daun bawang. Tambahkan garam dan lada bubuk. Koreksi rasa dan aduk lagi..
			
			
		</li>
	
		<li>
			Jika bubur sudah mengental dan sayuran layu, bubur Manado siap dihidangkan..
			
			
		</li>
	
		<li>
			Sajikan bersama ikan asin goreng dan sambal Roa. Tapi berhubung tidak ada ikan Roa, maka saya ganti dengan ikan teri..
			
			
		</li>
	
		<li>
			Sambal Ikan Roa :
50 gr ikan Roa (saya: ikan teri) 
11 bh Cabe rawit merah 
12 bh Cabe merah keriting 
3 bh Tomat merah
1/2 sdt Garam
1/2 bh terasi ABC

Caranya :
Goreng ikan teri. Tumis tomat hingga layu. Lalu uleg cabe rawit, cabe merah, garam, tomat, dan ikan teri. Uleg semua hingga halus..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food tinutuan bubur manado recipe. Thank you very much for reading. I am confident that you can make this at home. There is gonna be more interesting food at home recipes coming up. Remember to save this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
