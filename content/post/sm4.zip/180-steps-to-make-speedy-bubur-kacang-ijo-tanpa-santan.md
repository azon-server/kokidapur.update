---
description: "Steps to Make Speedy Bubur kacang ijo tanpa santan"
title: "Steps to Make Speedy Bubur kacang ijo tanpa santan"
slug: 180-steps-to-make-speedy-bubur-kacang-ijo-tanpa-santan

<p>
	<strong>Bubur kacang ijo tanpa santan</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/321adfbd1a2a7472/680x482cq70/bubur-kacang-ijo-tanpa-santan-foto-resep-utama.jpg" alt="Bubur kacang ijo tanpa santan" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you are having an incredible day today. Today, I'm gonna show you how to make a special dish, bubur kacang ijo tanpa santan. One of my favorites. For mine, I'm gonna make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo tanpa santan is one of the most favored of recent trending foods on earth. It is enjoyed by millions daily. It is simple, it's quick, it tastes yummy. Bubur kacang ijo tanpa santan is something which I have loved my whole life. They are nice and they look fantastic.
</p>

<p>
To get started with this recipe, we have to first prepare a few ingredients. You can have bubur kacang ijo tanpa santan using 9 ingredients and 4 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo tanpa santan:</h3>

<ol>
	
		<li>{Get 250 gram of kacang hijau. </li>
	
		<li>{Prepare 3 Buah of ubi (campur). </li>
	
		<li>{Make ready 1 lembar of daun pandan. </li>
	
		<li>{Prepare 8 sdm of gula putih. </li>
	
		<li>{Prepare 1/2 sdt of garam. </li>
	
		<li>{Make ready 1 ruas of jahe. </li>
	
		<li>{Take 1 bulat kecil of gula merah. </li>
	
		<li>{Make ready secukupnya of Susu. </li>
	
		<li>{Take secukupnya of Air. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo tanpa santan:</h3>

<ol>
	
		<li>
			Cuci kacang hijau hingga bersih dan rendam selama 5 jam (agar kacang cepat hancur ketika di masak).
			
			
		</li>
	
		<li>
			Rebus air hingga mendidih. Kemudian masukan kacang hijau, gula merah, gula putih, daun pandan, jahe, garam. Aduk hingga rata... Tunggu sampai benar2 mendidih..
			
			
		</li>
	
		<li>
			Setelah kacang terlihat pecah, masukan ubi tunggu lagi sampai benar2 empuk..
			
			
		</li>
	
		<li>
			Angkat dan sajikan dengan susu kental manis. 👌.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this special food bubur kacang ijo tanpa santan recipe. Thank you very much for reading. I'm confident that you can make this at home. There is gonna be more interesting food in home recipes coming up. Remember to bookmark this page in your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
