---
description: "Steps to Prepare Perfect Bubur Kacang Hijau Kental"
title: "Steps to Prepare Perfect Bubur Kacang Hijau Kental"
slug: 27-steps-to-prepare-perfect-bubur-kacang-hijau-kental

<p>
	<strong>Bubur Kacang Hijau Kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/d63d23051647bafd/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's me, Dave, welcome to my recipe site. Today, we're going to prepare a special dish, bubur kacang hijau kental. It is one of my favorites food recipes. This time, I am going to make it a bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Hijau Kental is one of the most favored of recent trending foods in the world. It is appreciated by millions every day. It's easy, it is fast, it tastes delicious. They are nice and they look wonderful. Bubur Kacang Hijau Kental is something that I have loved my whole life.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we must prepare a few components. You can cook bubur kacang hijau kental using 11 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>{Prepare 250 gr of kacang hijau. </li>
	
		<li>{Make ready 250 gr of gula merah (saya cuma 2 keping). </li>
	
		<li>{Prepare 2 sdm of gula pasir (saya kurang lebih 200gr/ selera ya). </li>
	
		<li>{Make ready 4 lembar of daun pandan. </li>
	
		<li>{Take  of Jahe di gebrek (tambahan dari saya). </li>
	
		<li>{Prepare 2-3 sdm of tepung maizena (larutan dengan air). </li>
	
		<li>{Get  of Saus Santan :. </li>
	
		<li>{Get 600 ml of santan. </li>
	
		<li>{Prepare 2 lembar of daun pandan. </li>
	
		<li>{Prepare secukupnya of Garam. </li>
	
		<li>{Make ready 1/2 sdt of vanili. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau, nyalakan api besar, masak air hingga mendidih lalu masukkan kecang hijau dan beri daun pandan,jahe (versi saya) ttp Tutup panci dan masak selama 5 menit.
			
			
		</li>
	
		<li>
			Setelah 5 menit = matikan kompor. Jangan buka tutup panci. Diamkan selama 30 menit, lalu nyalakan lagi dengan api besar dan masak selama 7 menit (jangan pernah sekali pun membuka tutup Panci).
			
			
		</li>
	
		<li>
			Setelah 7 menit = buka tutup panci, tambahkan gula merah, gula pasir aduk hingga gula larut dan air mendidih. Tambahkan larutan tepung maizena, aduk rata hingga mengental. Sisihkan.
			
			
				
					<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Bubur Kacang Hijau Kental"> <br>
				
			
		</li>
	
		<li>
			Buat saus santan = campur semua bahan, Masak sambil di aduk aduk hingga matang, sisihkan.
			
			
		</li>
	
		<li>
			Sajikan.
			
			
				
					<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Bubur Kacang Hijau Kental"> <br>
				
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur kacang hijau kental recipe. Thank you very much for your time. I am sure you can make this at home. There's gonna be more interesting food in home recipes coming up. Don't forget to save this page on your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
