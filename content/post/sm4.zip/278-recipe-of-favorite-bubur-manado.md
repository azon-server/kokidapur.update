---
description: "Recipe of Favorite Bubur Manado"
title: "Recipe of Favorite Bubur Manado"
slug: 278-recipe-of-favorite-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/357617b5dd022dbf/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is Brad, welcome to our recipe page. Today, I'm gonna show you how to prepare a distinctive dish, bubur manado. One of my favorites. This time, I will make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Manado is one of the most well liked of recent trending meals on earth. It's easy, it is fast, it tastes yummy. It's enjoyed by millions daily. They're fine and they look fantastic. Bubur Manado is something which I have loved my whole life.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we must prepare a few components. You can have bubur manado using 22 ingredients and 5 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Make ready 250 gr of beras. </li>
	
		<li>{Prepare 2 ltr of air. </li>
	
		<li>{Prepare 1 lbr of daun kunyit rajang halus. </li>
	
		<li>{Make ready 1 lbr of daun pandan simpul. </li>
	
		<li>{Make ready 4 lbr of daun jeruk sobek-sobek. </li>
	
		<li>{Prepare 1 ruas of jahe geprek. </li>
	
		<li>{Take 6 siung of bawang merah iris tipis. </li>
	
		<li>{Prepare 4 siung of bawang putih rajang halus goreng sampai warna kecoklatan. </li>
	
		<li>{Prepare 2 btg of serai geprek. </li>
	
		<li>{Make ready 1 btg of daun bawang rajang halus. </li>
	
		<li>{Make ready secukupnya of Gula,garam,merica,penyedap rasa. </li>
	
		<li>{Make ready  of Pelengkap. </li>
	
		<li>{Prepare  of Telur rebus. </li>
	
		<li>{Take  of Ikan asin goreng. </li>
	
		<li>{Take  of Sambal. </li>
	
		<li>{Get  of Bahan sayur. </li>
	
		<li>{Get 1 bongol of jagung pipil. </li>
	
		<li>{Prepare 350 gr of labu kuning potong kotak. </li>
	
		<li>{Get 300 gr of ubu jalar kuning/putih potong kotak. </li>
	
		<li>{Get 2 ikat kecil of bayam ambil daunnya. </li>
	
		<li>{Get 2 ikat of kecik kangkung ambil daunnya. </li>
	
		<li>{Get 2 ikat kecil of kemangi ambil daunnya. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado:</h3>

<ol>
	
		<li>
			Semua bahan harus di cuci bersih ya bund say..
			
			
		</li>
	
		<li>
			Cuci beras masukan ke panci tambah 2 ltr air,hidupkan kompor ke api sedang.masukan labu kuning 200gr,semua ubi jalarnya,daun kunyit,daun pandan,daun jeruk dan jahe geprek.tunggu sampai beras pecah sambil di aduk-aduk..
			
			
		</li>
	
		<li>
			Beras sdh pecah labu kuningnya sambil di penyet sampai hancur ya bund supaya warna buburnya berubah jd cantik,jika sdh di penyet masukan sisa labu kuning,pipil jagung,bawang merah,bawang putih goreng beserta garam,gula,merica dan penyedap rasa.koreksi rasa..
			
			
		</li>
	
		<li>
			Aduk aduk sambil di cek kelembutan dan kekentalan bubur,jika rasa sdh pas masukan bayamnya,aduk-aduk skitar 2mnt lalu masukan daun bawang,daun kemangi,daun kangkung.aduk-aduk sampai semua sayur merata di bubur kurleb 2mnt.matikan kompor dan siap di sajikan..
			
			
		</li>
	
		<li>
			Sajikan dgn bahan pelengkap sesuai selera.Sumpah enak banget bund hehehe...
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this special food bubur manado recipe. Thank you very much for reading. I am sure you will make this at home. There is gonna be interesting food at home recipes coming up. Remember to bookmark this page in your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
