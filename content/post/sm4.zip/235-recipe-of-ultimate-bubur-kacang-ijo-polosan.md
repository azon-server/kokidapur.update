---
description: "Recipe of Ultimate Bubur kacang ijo polosan"
title: "Recipe of Ultimate Bubur kacang ijo polosan"
slug: 235-recipe-of-ultimate-bubur-kacang-ijo-polosan

<p>
	<strong>Bubur kacang ijo polosan</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/93a78555161538bb/680x482cq70/bubur-kacang-ijo-polosan-foto-resep-utama.jpg" alt="Bubur kacang ijo polosan" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's Louise, welcome to our recipe site. Today, we're going to make a distinctive dish, bubur kacang ijo polosan. One of my favorites food recipes. This time, I'm gonna make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo polosan is one of the most well liked of current trending meals in the world. It's enjoyed by millions every day. It is simple, it's quick, it tastes delicious. They're nice and they look fantastic. Bubur kacang ijo polosan is something that I have loved my whole life.
</p>

<p>
To begin with this recipe, we must prepare a few components. You can cook bubur kacang ijo polosan using 6 ingredients and 6 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo polosan:</h3>

<ol>
	
		<li>{Make ready 1/4 kg of kacang hijau. </li>
	
		<li>{Take 100 gram of gula merah, iris2 (3 bulatan). </li>
	
		<li>{Prepare 7 sdm of gula pasir. </li>
	
		<li>{Make ready 3 cm of jahe, Geprek. </li>
	
		<li>{Take 1 sdt of garem. </li>
	
		<li>{Prepare Secukupnya of air, untuk merebus. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo polosan:</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau, lalu rendam semalaman kacang hijau biar cepet empuk saat direbus nanti.
			
			
		</li>
	
		<li>
			Rebus kacang hijau hingga setengah matang, masukan jahe.
			
			
		</li>
	
		<li>
			Dipanci lain, Rebus gula merah dengan sedikit air hingga gula larut, saring lalu tuang ke dalam rebusan kacang hijau.
			
			
		</li>
	
		<li>
			Masukan juga gula putih, aduk rata, test rasa dan rebus hingga benar2 matang.
			
			
		</li>
	
		<li>
			Terakhir test rasa lagi sebelum di angkat, jika kurang manis boleh tambah gula, jika kurang air boleh tambah air, sesuai selera aja yah...
			
			
		</li>
	
		<li>
			Sajikan hangat nikmatt... makan pake susu kental manis juga enak, anakku suka banget pake susu kental manis.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this exceptional food bubur kacang ijo polosan recipe. Thanks so much for reading. I'm confident that you will make this at home. There is gonna be interesting food in home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
