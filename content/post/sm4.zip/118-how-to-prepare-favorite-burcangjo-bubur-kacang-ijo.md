---
description: "How to Prepare Favorite Burcangjo (bubur kacang ijo)"
title: "How to Prepare Favorite Burcangjo (bubur kacang ijo)"
slug: 118-how-to-prepare-favorite-burcangjo-bubur-kacang-ijo

<p>
	<strong>Burcangjo (bubur kacang ijo)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/0d1f79c48e84ff74/680x482cq70/burcangjo-bubur-kacang-ijo-foto-resep-utama.jpg" alt="Burcangjo (bubur kacang ijo)" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is Brad, welcome to my recipe page. Today, I will show you a way to make a special dish, burcangjo (bubur kacang ijo). One of my favorites food recipes. This time, I'm gonna make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Burcangjo (bubur kacang ijo) is one of the most popular of recent trending foods in the world. It is simple, it's fast, it tastes yummy. It is appreciated by millions every day. Burcangjo (bubur kacang ijo) is something that I've loved my whole life. They're fine and they look fantastic.
</p>

<p>
To get started with this recipe, we have to first prepare a few ingredients. You can cook burcangjo (bubur kacang ijo) using 5 ingredients and 6 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Burcangjo (bubur kacang ijo):</h3>

<ol>
	
		<li>{Get 1 ons of kacang hijau. </li>
	
		<li>{Get  of Gula merah. </li>
	
		<li>{Prepare  of Jahe. </li>
	
		<li>{Get  of Santan kara. </li>
	
		<li>{Make ready  of Terigu(tambahan)optional. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Burcangjo (bubur kacang ijo):</h3>

<ol>
	
		<li>
			Pertama kita rendam terlebih dahulu kacang hijau ny kl bs semalaman biar mudah lembut pas dimasak.
			
			
		</li>
	
		<li>
			Kt masukan kacang hijau dan gula merah ke panci dan tambahkan jahe ke dlm nya kemudian rebus.
			
			
		</li>
	
		<li>
			Setelah mendidih dan kita coba kacang nya sdh lembut boleh tambahkan terigu 4 sendok td yg sdh dilarutkan ke air biar nanti lebih kental.
			
			
		</li>
	
		<li>
			Aduk sampai rata kemudian kl sdh agak meletup2 brrti itu sdh hampir lembut kacang nya.
			
			
		</li>
	
		<li>
			Buat santan : 1.masukan santan kara dlm panci kt panaskan dan tambahkan air dan garam secukupnya sesuai takaran.
			
			
		</li>
	
		<li>
			Setelah bubur nya masak dan siap disajikan lalu tambahkan santan diatas nya boleh ditambah susu kental manis 😉.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this special food burcangjo (bubur kacang ijo) recipe. Thank you very much for reading. I am sure that you will make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
