---
description: "Easiest Way to Prepare Any-night-of-the-week Bubur kacang hijau santan kental"
title: "Easiest Way to Prepare Any-night-of-the-week Bubur kacang hijau santan kental"
slug: 53-easiest-way-to-prepare-any-night-of-the-week-bubur-kacang-hijau-santan-kental

<p>
	<strong>Bubur kacang hijau santan kental</strong>. 
	Siapkan mangkuk saji, tuang bubur kacang hijau. Beri krim kental manis dan rice crispy. Artikel ini telah tayang di SajianSedap dengan judul &#34; Resep Bubur Kacang Hijau Rice Crispy Enak Ini Pas Untuk Menu.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/5c4a70cbf6309474/680x482cq70/bubur-kacang-hijau-santan-kental-foto-resep-utama.jpg" alt="Bubur kacang hijau santan kental" style="width: 100%;">
	
	
		Masak hingga mendidih dan mengental. - Sajikan bubur kacang hijau bersama ketan hitam dan.
	
		Biasanya bubur kacang hijau terbuat dari campuran santan dan gula jawa.
	
		Namun, kalau kamu gak suka santan, kamu tak perlu menyertakannya.
	
</p>
<p>
	Hey everyone, it is Louise, welcome to our recipe site. Today, I'm gonna show you how to make a distinctive dish, bubur kacang hijau santan kental. It is one of my favorites food recipes. This time, I am going to make it a bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur kacang hijau santan kental is one of the most favored of current trending meals in the world. It is easy, it is fast, it tastes yummy. It is appreciated by millions every day. They're fine and they look fantastic. Bubur kacang hijau santan kental is something that I have loved my entire life.
</p>
<p>
	Siapkan mangkuk saji, tuang bubur kacang hijau. Beri krim kental manis dan rice crispy. Artikel ini telah tayang di SajianSedap dengan judul &#34; Resep Bubur Kacang Hijau Rice Crispy Enak Ini Pas Untuk Menu.
</p>

<p>
To get started with this recipe, we must prepare a few ingredients. You can have bubur kacang hijau santan kental using 7 ingredients and 5 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur kacang hijau santan kental:</h3>

<ol>
	
		<li>{Make ready 250 gram of kacang hijau. </li>
	
		<li>{Get 1/2 of kelapa parut (di peras). </li>
	
		<li>{Prepare  of Gula merah (dilarutkan d atas kompor dengan air). </li>
	
		<li>{Get secukupnya of Gula putih. </li>
	
		<li>{Take 1 ruas of jahe d grepek. </li>
	
		<li>{Take 4 of daun pandan. </li>
	
		<li>{Make ready 1 sdt of vanili. </li>
	
</ol>
<p>
	
		Sebagai penggantinya, kamu bisa menggunakan jahe yang lebih bernutrisi.
	
		Sebelum membuat bubur kacang hijau, berikut tips yang bisa diikuti agar bubur kacang hijau menjadi lebih enak Setelah itu, masukan santan kental dan garam sambil diaduk.
	
		Bubur kacang hijau atau burjo adalah menu khas Nusantara yang sangat mudah ditemukan di mana-mana.
	
		Bubur kacang hijau dapat dijadikan sebagai menu sarapan, camilan, atau dessert.
	
</p>

<h3>Instructions to make Bubur kacang hijau santan kental:</h3>

<ol>
	
		<li>
			Rendam kacang hijau dlm air selama 1 jam saja sdh empuk.
			
			
		</li>
	
		<li>
			Untuk buat kuah santannya, peras ampas kelapa ny dengan 300 ml air dengan 2 lembar daun pandan, dan garam secukupnya lalu masukkan larutan tepung maizena sebanyak 1 sdm dengan 5 SDM air sdm..masak jangan sampai santannya meluap lalu matikan kompor nya.
			
			
		</li>
	
		<li>
			Untuk merebus kacang hijau nya, menggunakan santan encer yg sdh tdk kental sisa dr ampas kelapa yg sudah diperas dengan daun pandan.
			
			
		</li>
	
		<li>
			Masak hingga mendidih, masukkan kacang hijaunya smpai setengah matang lalu tambahkan air gula merah, jahe, vanili, daun pandan, tambahkan gula putih sesuai selera, jgn lupa larutan tepung maizena...
			
			
		</li>
	
		<li>
			Masak hingga matang meletup-letup dan sajikan..🤗🤗.
			
			
		</li>
	
</ol>

<p>
	
		Beli bahan dan peralatan masak - DISINI JAMIN TERMURAH.
	
		Bubur kacang hijau saat ini juga banyak divariasikan dengan berbagai tambahan makanan, Dahulu Green Beans satu-satunya bahan atau topping utama dalam pembuatannya.
	
		Namun, seiiring berjalannya waktu semakin banyak varian topping untuk menambah kelezatan makanan ini.
	
		Menyantap bubur kacang hijau di sore hari apalagi saat cuaca dingin merupakan pilihan yang tepat.
	
		Selain menghangatkan tubuh, kandungan gizi pada kacang hijau juga bagus untuk meningkatkan daya tahan tubuh.
	
</p>

<p>
	So that is going to wrap this up with this special food bubur kacang hijau santan kental recipe. Thanks so much for reading. I'm confident that you can make this at home. There's gonna be more interesting food at home recipes coming up. Remember to bookmark this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
