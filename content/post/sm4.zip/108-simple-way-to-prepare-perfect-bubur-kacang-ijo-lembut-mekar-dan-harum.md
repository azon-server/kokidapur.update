---
description: "Simple Way to Prepare Perfect Bubur Kacang Ijo Lembut, Mekar, dan Harum"
title: "Simple Way to Prepare Perfect Bubur Kacang Ijo Lembut, Mekar, dan Harum"
slug: 108-simple-way-to-prepare-perfect-bubur-kacang-ijo-lembut-mekar-dan-harum

<p>
	<strong>Bubur Kacang Ijo Lembut, Mekar, dan Harum</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/aebc44f29a5e891b/680x482cq70/bubur-kacang-ijo-lembut-mekar-dan-harum-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Lembut, Mekar, dan Harum" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's John, welcome to my recipe site. Today, I will show you a way to make a special dish, bubur kacang ijo lembut, mekar, dan harum. One of my favorites. For mine, I am going to make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo Lembut, Mekar, dan Harum is one of the most popular of recent trending meals on earth. It is easy, it's fast, it tastes yummy. It's appreciated by millions every day. Bubur Kacang Ijo Lembut, Mekar, dan Harum is something that I've loved my whole life. They're fine and they look wonderful.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we must prepare a few components. You can cook bubur kacang ijo lembut, mekar, dan harum using 12 ingredients and 6 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Lembut, Mekar, dan Harum:</h3>

<ol>
	
		<li>{Prepare 250 gr of kacang hijau. </li>
	
		<li>{Get 1 liter of air. </li>
	
		<li>{Prepare 150 gr of gula pasir (sesuai selera). </li>
	
		<li>{Get 1 ruas of jahe geprek. </li>
	
		<li>{Get 2 lembar of daun pandan. </li>
	
		<li>{Make ready Sejumput of garam. </li>
	
		<li>{Prepare 1/2 sdt of essence vanilla. </li>
	
		<li>{Take 1 sdm of maizena larutkan dengan sedikit air. </li>
	
		<li>{Take  of Kuah Santan. </li>
	
		<li>{Make ready 1 bungkus of santan instan (aku pakai merk kara). </li>
	
		<li>{Take 200 ml of air matang. </li>
	
		<li>{Take Sejumput of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo Lembut, Mekar, dan Harum:</h3>

<ol>
	
		<li>
			Cuci kacang hijau, lalu rendam semalaman ± 8 jam. Ini merupakan proses yg penting agar kacang ijo mekar dan lembut nantinya. Setelah itu buang air rendaman, masak kacang hijau, daun pandan, dan jahe selama 20 menit dengan api besar. Masak dengan panci tertutup..
			
			
		</li>
	
		<li>
			Matikan kompor, buang jahe dan daun pandan, lalu diamkan selama 30 menit dengan panci tertutup..
			
			
		</li>
	
		<li>
			Setelah 30 menit, masukkan gula, garam, dan essence vanilla. Aduk rata, masak dgn api besar selama 5 menit dengan panci tertutup..
			
			
		</li>
	
		<li>
			Masukkan maizena yang sudah dicampur air, aduk rata, masak lagi ± 5 menit sampai kental. Matikan kompor..
			
			
		</li>
	
		<li>
			Kuah santan : Campurkan semua bahan, aduk-aduk terus agar santan tidak pecah sampai mendidih. Matikan kompor, tiriskan..
			
			
		</li>
	
		<li>
			Selamat menikmati selagi hangat ☺️ yummy!.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this exceptional food bubur kacang ijo lembut, mekar, dan harum recipe. Thank you very much for reading. I am confident that you will make this at home. There's gonna be more interesting food in home recipes coming up. Don't forget to save this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
