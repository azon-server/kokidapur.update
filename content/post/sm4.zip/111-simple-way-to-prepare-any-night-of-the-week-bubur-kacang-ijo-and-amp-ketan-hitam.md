---
description: "Simple Way to Prepare Any-night-of-the-week Bubur kacang ijo &amp;amp; ketan hitam"
title: "Simple Way to Prepare Any-night-of-the-week Bubur kacang ijo &amp;amp; ketan hitam"
slug: 111-simple-way-to-prepare-any-night-of-the-week-bubur-kacang-ijo-and-amp-ketan-hitam

<p>
	<strong>Bubur kacang ijo &amp; ketan hitam</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/e1993c71277f2909/680x482cq70/bubur-kacang-ijo-ketan-hitam-foto-resep-utama.jpg" alt="Bubur kacang ijo &amp; ketan hitam" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, I will show you a way to make a distinctive dish, bubur kacang ijo &amp; ketan hitam. It is one of my favorites. This time, I'm gonna make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo &amp; ketan hitam is one of the most popular of recent trending foods in the world. It's simple, it's fast, it tastes yummy. It is appreciated by millions every day. Bubur kacang ijo &amp; ketan hitam is something that I have loved my entire life. They are fine and they look fantastic.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to prepare a few ingredients. You can have bubur kacang ijo &amp; ketan hitam using 16 ingredients and 3 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo &amp; ketan hitam:</h3>

<ol>
	
		<li>{Make ready  of bahan burjo. </li>
	
		<li>{Prepare 500 gram of kacang ijo rendam satu malam. </li>
	
		<li>{Make ready 2 liter of air. </li>
	
		<li>{Take 1 of santan segitiga. </li>
	
		<li>{Make ready 3 ruas of jahe iris tipis. </li>
	
		<li>{Take 4 lembar of daun pandan potong2. </li>
	
		<li>{Make ready 1/4 of gula merah iris. </li>
	
		<li>{Make ready 200 gram of gula putih. </li>
	
		<li>{Get 1/2 sdm of garam. </li>
	
		<li>{Prepare 4 sdm of maizena. </li>
	
		<li>{Get  of bahan toping.;. </li>
	
		<li>{Make ready 250 gram of ketan hitam rendam satu malam. </li>
	
		<li>{Take 200 gram of gula merah iris. </li>
	
		<li>{Get 2 of santan segitiga. </li>
	
		<li>{Make ready 1/2 sdt of garam. </li>
	
		<li>{Take 2 sdm of maizena cairkan. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo &amp; ketan hitam:</h3>

<ol>
	
		<li>
			Bahan burjo;;cuci bersih kacang yg sudah di rendam. lalu masukan ke panci dan rebus sampai kacang empuk,masukan pandan,jahe,garam,santan gula merah dan putih. aduk sampai rata. dan kemudian terakhir kalau sudah matang masukan maizena yang sudah di kasih air lalu masukan dan aduk..
			
			
		</li>
	
		<li>
			Bahan toping.; rebus ketan dengan satu liter air kurleb 6 menit lalu diamkan selama 30 menit. setelah 30 menit masukan gula merah,garam, rebus kembali selama 10 menit. jika air menyurut tambahkan air secukupnya. setelah itu masukan maizena lalu aduk cepat supaya kental. lalu diamkan kembali sampai dingin..
			
			
		</li>
	
		<li>
			Dan terakhir rebus santan dengan 2 gelas air dan tambahkan 1/2 sdt garam. takjil untuk bersama semoga berkah. amin..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this special food bubur kacang ijo &amp; ketan hitam recipe. Thanks so much for reading. I am confident you can make this at home. There is gonna be interesting food in home recipes coming up. Don't forget to save this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
