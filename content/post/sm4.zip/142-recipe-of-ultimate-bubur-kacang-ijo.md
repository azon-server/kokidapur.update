---
description: "Recipe of Ultimate Bubur kacang ijo"
title: "Recipe of Ultimate Bubur kacang ijo"
slug: 142-recipe-of-ultimate-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/7990da640a4fe388/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
		Resep bubur kacang ijo itu sendiri ada berbagai macam dengan tambahan bahan yang melengkapinya.
	
		Cara bikin bubur kacang hijau / ijo memerlukan trik dan tips tersendiri, sehingga hasilnya bisa lebih bagus dan juga enak serta lembut.
	
		Sebenarnya tidak ada yang istimewa saat anda membuat.
	
</p>
<p>
	Hello everybody, it is me, Dave, welcome to our recipe page. Today, we're going to prepare a distinctive dish, bubur kacang ijo. It is one of my favorites. This time, I will make it a bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>
<p>
	Bubur kacang ijo is one of the most favored of current trending meals on earth. It's easy, it's fast, it tastes delicious. It is enjoyed by millions daily. Bubur kacang ijo is something that I have loved my whole life. They're fine and they look wonderful.
</p>

<p>
To get started with this recipe, we must first prepare a few components. You can have bubur kacang ijo using 5 ingredients and 5 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Make ready 250 gr of kacang ijo. </li>
	
		<li>{Make ready 2-3 of gelondongan kecil gula merah. </li>
	
		<li>{Get 2-3 lbr of daun pandan,ikat sampul. </li>
	
		<li>{Make ready 1/2 kotak of santan kental instan @200ml. </li>
	
		<li>{Get Sejumput of garam. </li>
	
</ol>
<p>
	
		Bubur kacang hejo (su) Bubur kacang ijo (jv) Burjo.
	
		Slightly different names may be used in different regions of Indonesia, such as kacang ijo in Javanese areas.
	
		Cara masak bubur kacang ijo super simple dan enak.
	
		Rahasia Peyek Kacang Ijo Renyah, Tidak Keras dan Tahan Lama Bu Yun kali inia akan membagikan resep, tips dan tutorial cara.
	
</p>

<h3>Instructions to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Cuci bersih kacang ijo..masak kacang ijo bersama daun pandan sampe mendidih dan kacang ijo empuk.
			
			
		</li>
	
		<li>
			Setelah empuk,tambahkan gula merah,rebus hingga Gula merah larut,tambahkn garam dan santan biarkan santan mendidih,aduk2 agar santan tidak pecah.
			
			
		</li>
	
		<li>
			Selamat mencoba.
			
			
		</li>
	
		<li>
			Tingkat kemanisan dan kekentalan santan bisa di sesuaikan.
			
			
		</li>
	
		<li>
			Tips: agar kacang ijo cepat empuk,sewaktu merebus beberapa menit,matikan api lalu biarkan hingga 30-45 mnt,lalu nyalakan api dan rebus kembali kacang hijaunya,di jamin langsung cepat empuk loh.
			
			
		</li>
	
</ol>

<p>
	
		Cara Membuat Bubur Kacang Hijau Sederhana Yang Enak amp Kental Ala Dapur Dina.
	
		Ingin mencoba memasak Bubur Kacang Hijau sendiri, Burjo Pisang (Tips spy kacang ijo cepat empuk dan lembut), Bubur kacang ijo ketan item durian enakk, Burjo Nangka dan lain-lain yang lezat untuk.
	
		Sajikan bubur kacang hijau beserta rebusan santan saat akan di konsumsi untuk menghindari kacang hijau cepat basi Resep membuat bubur kacang hijau.
	
		Resep Bubur Kacang Ijo Enak Dan Cepat Mekar Atau Empuk.
	
		Kacang hijau / ijo merupakan salah satu bahan makanan yang bukan saja enak di buat minuman maupun makanan.
	
</p>

<p>
	So that is going to wrap this up for this exceptional food bubur kacang ijo recipe. Thanks so much for your time. I'm sure that you can make this at home. There's gonna be more interesting food in home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
