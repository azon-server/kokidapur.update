---
description: "Recipe of Speedy Bubur kacang ijo kental dan mantul"
title: "Recipe of Speedy Bubur kacang ijo kental dan mantul"
slug: 9-recipe-of-speedy-bubur-kacang-ijo-kental-dan-mantul

<p>
	<strong>Bubur kacang ijo kental dan mantul</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/dc9a4923d70a3fe4/680x482cq70/bubur-kacang-ijo-kental-dan-mantul-foto-resep-utama.jpg" alt="Bubur kacang ijo kental dan mantul" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Brad, welcome to my recipe page. Today, we're going to make a distinctive dish, bubur kacang ijo kental dan mantul. It is one of my favorites food recipes. For mine, I will make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo kental dan mantul is one of the most favored of current trending foods in the world. It's easy, it is quick, it tastes yummy. It is enjoyed by millions every day. They're nice and they look wonderful. Bubur kacang ijo kental dan mantul is something that I have loved my entire life.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to prepare a few components. You can cook bubur kacang ijo kental dan mantul using 7 ingredients and 5 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo kental dan mantul:</h3>

<ol>
	
		<li>{Get  of Gula jawa. </li>
	
		<li>{Prepare  of Jahe. </li>
	
		<li>{Prepare  of Santan. </li>
	
		<li>{Get  of Kacang ijo. </li>
	
		<li>{Take  of Daun pandan. </li>
	
		<li>{Make ready sedikit of Garam. </li>
	
		<li>{Get Sedikit of tepung meizena. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo kental dan mantul:</h3>

<ol>
	
		<li>
			Rendam kacang ijo semaleman agar empuk, kemudian cuci bersih..
			
			
		</li>
	
		<li>
			Panaskan air lalu masukkan kacang ijo yang udah di cuci bersih, biarkan kacang ijo lebih empuk sampai air menyusut..
			
			
		</li>
	
		<li>
			Masukkan santan, daun pandan,jahe geprek, gula jawa yang sudah di irisiris dan sedikit garam..
			
			
		</li>
	
		<li>
			Aduk aduk jangan sampai santan pecah, kemudikan apalabila sudah tercampur rata dan santan masak, masukkan sedikit cairan tepung meizena..
			
			
		</li>
	
		<li>
			Aduk adukk, kemudian angkat dan sajikan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this special food bubur kacang ijo kental dan mantul recipe. Thanks so much for reading. I am confident you will make this at home. There's gonna be more interesting food at home recipes coming up. Remember to save this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
