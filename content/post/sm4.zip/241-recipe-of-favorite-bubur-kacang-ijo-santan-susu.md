---
description: "Recipe of Favorite Bubur kacang ijo santan susu"
title: "Recipe of Favorite Bubur kacang ijo santan susu"
slug: 241-recipe-of-favorite-bubur-kacang-ijo-santan-susu

<p>
	<strong>Bubur kacang ijo santan susu</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/94d544d71846ea4f/680x482cq70/bubur-kacang-ijo-santan-susu-foto-resep-utama.jpg" alt="Bubur kacang ijo santan susu" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you are having an incredible day today. Today, I'm gonna show you how to make a distinctive dish, bubur kacang ijo santan susu. It is one of my favorites food recipes. For mine, I am going to make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo santan susu is one of the most well liked of current trending foods on earth. It is appreciated by millions every day. It's easy, it's fast, it tastes delicious. Bubur kacang ijo santan susu is something which I've loved my entire life. They're nice and they look wonderful.
</p>

<p>
To get started with this recipe, we must first prepare a few components. You can cook bubur kacang ijo santan susu using 8 ingredients and 4 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo santan susu:</h3>

<ol>
	
		<li>{Take 1/4 of kacang hijau. </li>
	
		<li>{Prepare 1 lembar of daun pandan. </li>
	
		<li>{Prepare 1 bh of gula merah. </li>
	
		<li>{Make ready 1 siung of jahe. </li>
	
		<li>{Make ready  of Gula putih. </li>
	
		<li>{Prepare  of Santan. </li>
	
		<li>{Take  of Vanilli dan garam. </li>
	
		<li>{Prepare 1 of scht susu kental manis. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo santan susu:</h3>

<ol>
	
		<li>
			Rendam kacang hijau semalaman,ssetelah di rendam cuci kacang hijau lalu rebus..
			
			
		</li>
	
		<li>
			Jika sudah terasa empuk masukan santan yg sudah tercampur air,daun pandan lalu geprek jahe kemudian campur lalu aduk hingga trasa wangi.
			
			
		</li>
	
		<li>
			Kemudian tuang susu kental manis,gula merah siecukupnya lalu sedikit garam dan gula putih, vanilli aduk lalu koreksi rasa..
			
			
		</li>
	
		<li>
			Tunggu hingga mendidih,kemudian jika sudah matang lalu sajikan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this special food bubur kacang ijo santan susu recipe. Thanks so much for reading. I'm confident you can make this at home. There's gonna be more interesting food in home recipes coming up. Remember to bookmark this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
