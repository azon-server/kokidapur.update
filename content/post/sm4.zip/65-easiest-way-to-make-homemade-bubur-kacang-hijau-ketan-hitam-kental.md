---
description: "Easiest Way to Make Homemade Bubur kacang hijau ketan hitam Kental"
title: "Easiest Way to Make Homemade Bubur kacang hijau ketan hitam Kental"
slug: 65-easiest-way-to-make-homemade-bubur-kacang-hijau-ketan-hitam-kental

<p>
	<strong>Bubur kacang hijau ketan hitam Kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/41c28a934fbe73e3/680x482cq70/bubur-kacang-hijau-ketan-hitam-kental-foto-resep-utama.jpg" alt="Bubur kacang hijau ketan hitam Kental" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you are having an incredible day today. Today, I will show you a way to make a distinctive dish, bubur kacang hijau ketan hitam kental. One of my favorites food recipes. For mine, I will make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang hijau ketan hitam Kental is one of the most favored of recent trending foods in the world. It's enjoyed by millions every day. It's simple, it's quick, it tastes delicious. They're nice and they look wonderful. Bubur kacang hijau ketan hitam Kental is something which I've loved my entire life.
</p>

<p>
To begin with this recipe, we have to first prepare a few ingredients. You can cook bubur kacang hijau ketan hitam kental using 7 ingredients and 6 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang hijau ketan hitam Kental:</h3>

<ol>
	
		<li>{Make ready 250 gr of Kacang hijau. </li>
	
		<li>{Take 250 gr of ketan hitam. </li>
	
		<li>{Take 1 liter of Air. </li>
	
		<li>{Make ready 65 ml of santan instan (kara) dicampur 1 gelas air. </li>
	
		<li>{Take 2 sdt of jahe bubuk. </li>
	
		<li>{Get 3 keping of gula merah (opsional). </li>
	
		<li>{Prepare Secukupnya of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang hijau ketan hitam Kental:</h3>

<ol>
	
		<li>
			Rendam kacang hijau dan ketan hitam dalam wadah terpisah dalam waktu semalam.
			
			
		</li>
	
		<li>
			Masak kacang hijau dan ketan hitam dengan air sampai air hampir menyusut.
			
			
		</li>
	
		<li>
			Setelah air hampir menyusut, masukkan santan, gula merah, secukupnya garam, dan jahe bubuk.
			
			
		</li>
	
		<li>
			Aduk² sampai kental dan air menyusut.
			
			
		</li>
	
		<li>
			Sajikan dengan ditambah santan instan diatasnya.
			
			
		</li>
	
		<li>
			Note : Ditambah daun pandan lebih sedap. Saya tidak pakai gula pasir karena gulanya pas habis 😆.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this exceptional food bubur kacang hijau ketan hitam kental recipe. Thank you very much for reading. I am confident that you will make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
