---
description: "Step-by-Step Guide to Prepare Quick Bubur Kacang Ijo"
title: "Step-by-Step Guide to Prepare Quick Bubur Kacang Ijo"
slug: 192-step-by-step-guide-to-prepare-quick-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/001f1396c0a458e8/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
		Resep bubur kacang ijo itu sendiri ada berbagai macam dengan tambahan bahan yang melengkapinya.
	
		Cara bikin bubur kacang hijau / ijo memerlukan trik dan tips tersendiri, sehingga hasilnya bisa lebih bagus dan juga enak serta lembut.
	
		Sebenarnya tidak ada yang istimewa saat anda membuat.
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, we're going to prepare a distinctive dish, bubur kacang ijo. It is one of my favorites food recipes. For mine, I will make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo is one of the most popular of recent trending meals on earth. It's appreciated by millions every day. It is simple, it's fast, it tastes yummy. Bubur Kacang Ijo is something that I've loved my whole life. They're fine and they look fantastic.
</p>
<p>
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>

<p>
To begin with this recipe, we must prepare a few components. You can have bubur kacang ijo using 9 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Get 125 gr of kacang hijau. </li>
	
		<li>{Prepare 800 ml of air. </li>
	
		<li>{Take 150 gr of gula aren. </li>
	
		<li>{Take 2 lbr of daun pandan, simpulkan. </li>
	
		<li>{Take  of Saus santan :. </li>
	
		<li>{Take 100 ml of santan kental. </li>
	
		<li>{Prepare 1/4 sdt of garam. </li>
	
		<li>{Take 1 lbr of daun pandan, simpulkan. </li>
	
		<li>{Get  of Taburan : potongan buah nangka. </li>
	
</ol>
<p>
	
		Bubur kacang hejo (su) Bubur kacang ijo (jv) Burjo.
	
		Slightly different names may be used in different regions of Indonesia, such as kacang ijo in Javanese areas.
	
		Cara masak bubur kacang ijo super simple dan enak.
	
		Rahasia Peyek Kacang Ijo Renyah, Tidak Keras dan Tahan Lama Bu Yun kali inia akan membagikan resep, tips dan tutorial cara.
	
</p>

<h3>Steps to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Rendam kacang hijau semalaman, tiriskan, cuci bersih, tiriskan lg..
			
			
		</li>
	
		<li>
			Rebus air dan daun pandan hingga mendidih, masukkan kacang hijau, masak sampai kacang hijau pecah..
			
			
		</li>
	
		<li>
			Masukkan gula aren, aduk rata. Jgn lupa dicicipi ya,,,, masak sampai gula larut. Matikan api..
			
			
		</li>
	
		<li>
			Saus santan : masak santan, garam dan daun pandan sambil terus diaduk sampai mendidih, angkat..
			
			
		</li>
	
		<li>
			Penyajian : tuang bubur kacang hijau di mangkok, beri secukupnya saus santan, taburi nangka, sajikan,,,,.
			
			
		</li>
	
</ol>

<p>
	
		Cara Membuat Bubur Kacang Hijau Sederhana Yang Enak amp Kental Ala Dapur Dina.
	
		Ingin mencoba memasak Bubur Kacang Hijau sendiri, Burjo Pisang (Tips spy kacang ijo cepat empuk dan lembut), Bubur kacang ijo ketan item durian enakk, Burjo Nangka dan lain-lain yang lezat untuk.
	
		Sajikan bubur kacang hijau beserta rebusan santan saat akan di konsumsi untuk menghindari kacang hijau cepat basi Resep membuat bubur kacang hijau.
	
		Resep Bubur Kacang Ijo Enak Dan Cepat Mekar Atau Empuk.
	
		Kacang hijau / ijo merupakan salah satu bahan makanan yang bukan saja enak di buat minuman maupun makanan.
	
</p>

<p>
	So that is going to wrap this up with this exceptional food bubur kacang ijo recipe. Thank you very much for your time. I am confident that you can make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
