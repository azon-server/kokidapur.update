---
description: "Steps to Make Favorite Bubur Kacang Ijo"
title: "Steps to Make Favorite Bubur Kacang Ijo"
slug: 87-steps-to-make-favorite-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/8fd714877aad7263/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, I'm gonna show you how to make a special dish, bubur kacang ijo. It is one of my favorites food recipes. This time, I will make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo is one of the most well liked of recent trending meals in the world. It is appreciated by millions every day. It's simple, it is fast, it tastes yummy. They are nice and they look fantastic. Bubur Kacang Ijo is something that I've loved my entire life.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to prepare a few components. You can cook bubur kacang ijo using 6 ingredients and 4 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Take  of ❤️bahan :. </li>
	
		<li>{Prepare 250 gr of kacang ijo, cuci bersih. </li>
	
		<li>{Make ready 200 gr of gula merah. </li>
	
		<li>{Get 500 ml of santan kental. </li>
	
		<li>{Make ready 1/2 sdt of garam. </li>
	
		<li>{Prepare 2 lembar of daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Rebus kacang ijo sampai kembang....
			
			
		</li>
	
		<li>
			Setelah itu, masukkan gula merah, pandan, dan garam. Masak sampai gula larut.
			
			
		</li>
	
		<li>
			Terakhir masukkan santan, masak sampai kuah matang.
			
			
		</li>
	
		<li>
			Jangan lupa koreksi rasa, selamat mencoba.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this special food bubur kacang ijo recipe. Thanks so much for reading. I am confident you will make this at home. There is gonna be more interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
