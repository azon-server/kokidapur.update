---
description: "How to Make Homemade Bubur Kacang Ijo"
title: "How to Make Homemade Bubur Kacang Ijo"
slug: 179-how-to-make-homemade-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/ccda7bc0405f45d5/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's me, Dave, welcome to my recipe site. Today, I'm gonna show you how to make a special dish, bubur kacang ijo. One of my favorites food recipes. For mine, I am going to make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo is one of the most well liked of current trending foods in the world. It is simple, it's quick, it tastes yummy. It is appreciated by millions daily. They're fine and they look wonderful. Bubur Kacang Ijo is something which I have loved my whole life.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to first prepare a few ingredients. You can cook bubur kacang ijo using 9 ingredients and 2 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Prepare 250 gr of kacang ijo. </li>
	
		<li>{Prepare 2 sdm of gula merah. </li>
	
		<li>{Take 3 sdm of gula pasir. </li>
	
		<li>{Make ready 1/2 sdt of garam. </li>
	
		<li>{Get 2 buah of daun pandan. </li>
	
		<li>{Make ready 1 ruas of jahe, geprek. </li>
	
		<li>{Prepare 3 sachet of susu kental manis. </li>
	
		<li>{Take 65 ml of santan kara (kemasan kecil). </li>
	
		<li>{Get 1-2 lt of air (sesuaikan). </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Cuci bersih kacang ijo. Didihkan air dipanci. Rebus kacang kurang lebih 5 menit..
			
			
		</li>
	
		<li>
			Diamkan selama kurang lebih 30 menit hingga kacang mekar. Lalu didihkan kembali, masukan jahe, daun pandan, santan, susu kental manis,gula merah, gula pasir, dan garam. Aduk-aduk, koreksi rasa lalu sajikan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this exceptional food bubur kacang ijo recipe. Thanks so much for your time. I'm confident you can make this at home. There's gonna be interesting food in home recipes coming up. Don't forget to save this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
