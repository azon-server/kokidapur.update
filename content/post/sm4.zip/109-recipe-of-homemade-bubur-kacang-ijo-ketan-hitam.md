---
description: "Recipe of Homemade Bubur Kacang Ijo Ketan Hitam"
title: "Recipe of Homemade Bubur Kacang Ijo Ketan Hitam"
slug: 109-recipe-of-homemade-bubur-kacang-ijo-ketan-hitam

<p>
	<strong>Bubur Kacang Ijo Ketan Hitam</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/cc306fd56a2a3eda/680x482cq70/bubur-kacang-ijo-ketan-hitam-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Ketan Hitam" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is me, Dave, welcome to my recipe page. Today, I'm gonna show you how to make a distinctive dish, bubur kacang ijo ketan hitam. One of my favorites. This time, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo Ketan Hitam is one of the most well liked of recent trending foods on earth. It is simple, it's fast, it tastes delicious. It is appreciated by millions every day. They are nice and they look wonderful. Bubur Kacang Ijo Ketan Hitam is something that I've loved my entire life.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we must first prepare a few components. You can have bubur kacang ijo ketan hitam using 18 ingredients and 4 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Ketan Hitam:</h3>

<ol>
	
		<li>{Take  of Bubur Ketan Hitam:. </li>
	
		<li>{Make ready 250 gram of ketan hitam. </li>
	
		<li>{Make ready 10 sdm of gula pasir. </li>
	
		<li>{Get 800 ml of santan cair (santan perasan ketiga dari 1 butir kelapa). </li>
	
		<li>{Take 1/2 sdt of garam. </li>
	
		<li>{Get  of Bubur Kacang Hijau:. </li>
	
		<li>{Make ready 250 gram of kacang hijau. </li>
	
		<li>{Make ready 1000 ml of air. </li>
	
		<li>{Prepare 500 ml of santan cair (santan perasan kedua). </li>
	
		<li>{Take 8 sdm of gula pasir. </li>
	
		<li>{Make ready 1 1/2 sdm of vanilla essence. </li>
	
		<li>{Make ready 300 gram of gula aren (gula sulawesi). </li>
	
		<li>{Take 10 cm of jahe (geprek). </li>
	
		<li>{Prepare  of Kuah Santan:. </li>
	
		<li>{Take 500 ml of santan kental (santan perasan pertama). </li>
	
		<li>{Take 1/2 sdt of garam. </li>
	
		<li>{Make ready 4 sdm of gula pasir. </li>
	
		<li>{Get 2 sdm of tepung maizena. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo Ketan Hitam:</h3>

<ol>
	
		<li>
			Cara Membuat Bubur Ketan Hitam: 1. Cuci bersih ketan lalu rendam semalaman 2. Masukkan ketan ke dalam panci rice cooker tambahkan santan, garam dan gula lalu cook sampai matang dan lembek.
			
			
		</li>
	
		<li>
			Cara Membuat Bubur Kacang Hijau: 1. Cuci bersih lalu rendam kacang hijau kurleb 3 jam 2. Didihkan air lalu masak kacang hijau sampai mekar dan pecah 3. Masukkan gula aren, jahe, gula pasir, vanilla essence dan santan masak sampai gula aren mencair 4. Aduk sesekali agar santan tidak pecah.
			
			
		</li>
	
		<li>
			Cara Membuat Kuah Santan: 1. Masak santan kental sampai mendidih 2. Tambahkan gula pasir dan garam 3. Masukkan tepung maizena (larutkan dg sedikit air) masak sampai meletup2.
			
			
		</li>
	
		<li>
			Penyelesaiannya: sajikan di atas mangkuk bubur kacang hijau lalu taruh bubur ketan hitam di atasnya dan beri siraman kuah santan kental di atasnya..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this special food bubur kacang ijo ketan hitam recipe. Thank you very much for your time. I am confident that you will make this at home. There's gonna be more interesting food at home recipes coming up. Remember to bookmark this page in your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
