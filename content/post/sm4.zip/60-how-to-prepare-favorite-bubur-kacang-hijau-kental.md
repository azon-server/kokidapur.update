---
description: "How to Prepare Favorite Bubur Kacang Hijau Kental"
title: "How to Prepare Favorite Bubur Kacang Hijau Kental"
slug: 60-how-to-prepare-favorite-bubur-kacang-hijau-kental

<p>
	<strong>Bubur Kacang Hijau Kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/59d054b9091afe8e/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is Louise, welcome to my recipe site. Today, I'm gonna show you how to make a distinctive dish, bubur kacang hijau kental. It is one of my favorites food recipes. This time, I am going to make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Hijau Kental is one of the most popular of current trending meals in the world. It is easy, it is quick, it tastes delicious. It's enjoyed by millions every day. Bubur Kacang Hijau Kental is something that I've loved my whole life. They're nice and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we must prepare a few components. You can have bubur kacang hijau kental using 8 ingredients and 4 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>{Get 2 cup of kacang hijau (rendam 1jam). </li>
	
		<li>{Take  of Daun pandan. </li>
	
		<li>{Take 2 bh of gula merah. </li>
	
		<li>{Take 1 sdm of gula pasir. </li>
	
		<li>{Take 1/2 sendok teh of garam. </li>
	
		<li>{Take 1 sdm of maizena (larutkan dengan air). </li>
	
		<li>{Prepare 500 ml of Santan kental. </li>
	
		<li>{Get 200 ml of air. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>
			Rebus air hingga mendidih. Masukkan kacang hijau dan daun pandan. Rebus hingga air berkurang...
			
			
		</li>
	
		<li>
			Tambahkan gula merah, gula pasir dan garam dan masukkan santan.
			
			
		</li>
	
		<li>
			Aduk hingga mendidih. Beri larutan maizena aduk trus.. kemudian Tes rasa...
			
			
		</li>
	
		<li>
			Bubur kacang hijau kental siap dihidangkan... 😊😊.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur kacang hijau kental recipe. Thank you very much for reading. I'm sure you will make this at home. There's gonna be interesting food at home recipes coming up. Remember to bookmark this page on your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
