---
description: "Simple Way to Make Any-night-of-the-week Bubur Kacang Ijo Dan Ketan Hitam"
title: "Simple Way to Make Any-night-of-the-week Bubur Kacang Ijo Dan Ketan Hitam"
slug: 234-simple-way-to-make-any-night-of-the-week-bubur-kacang-ijo-dan-ketan-hitam

<p>
	<strong>Bubur Kacang Ijo Dan Ketan Hitam</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/b59cdfbaa42010e5/680x482cq70/bubur-kacang-ijo-dan-ketan-hitam-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Dan Ketan Hitam" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you're having an incredible day today. Today, we're going to prepare a distinctive dish, bubur kacang ijo dan ketan hitam. One of my favorites food recipes. This time, I am going to make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo Dan Ketan Hitam is one of the most popular of recent trending foods on earth. It is simple, it is fast, it tastes delicious. It's appreciated by millions every day. They are nice and they look wonderful. Bubur Kacang Ijo Dan Ketan Hitam is something that I have loved my whole life.
</p>

<p>
To begin with this recipe, we must first prepare a few components. You can have bubur kacang ijo dan ketan hitam using 17 ingredients and 4 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Dan Ketan Hitam:</h3>

<ol>
	
		<li>{Get  of Bubur Ketan Hitam. </li>
	
		<li>{Get  of Bahan. </li>
	
		<li>{Prepare 200 gr of beras ketan hitam. </li>
	
		<li>{Make ready 2 ltr of air. </li>
	
		<li>{Get 100 gr of gula pasir. </li>
	
		<li>{Take 2 lbr of daun pandan. </li>
	
		<li>{Prepare  of Saus santan :. </li>
	
		<li>{Take 250 ml of santan kental. </li>
	
		<li>{Take 1/4 sdt of garam. </li>
	
		<li>{Take  of Bubur Kacang Hijau. </li>
	
		<li>{Prepare  of Bahan :. </li>
	
		<li>{Make ready 150 gr of kacang hijau. </li>
	
		<li>{Make ready 600 ml of air (untuk merebus). </li>
	
		<li>{Prepare 6 sdm of gula pasir (sesuai selera). </li>
	
		<li>{Make ready 1 bungkus of santan instan atau lebih enak lagi diganti pakai susu (plain). </li>
	
		<li>{Take 2 lembar of daun pandan. </li>
	
		<li>{Make ready Sedikit of Garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo Dan Ketan Hitam:</h3>

<ol>
	
		<li>
			Cara membuat ketan hitam:
 1.Cuci bersih beras ketan hitam, rendam semalaman (6 jam).
2.Masak beras ketan dan air hingga mendidih meletupletup dan menjadi bubur
3.Masukkan gula pasir dan daun pandan, masak hingga bubur kental. Angkat.
4.Masak bahan saus sambil diaduk-aduk hingga mendidih. Angkat.
5.Sajikan bubur ketan hitam bersama sausnya..
			
			
		</li>
	
		<li>
			Cara Membuat bubur Kacang Hijau : 
1.Cuci bersih dan rendam kacang hijau (kalau saya minimal 3 jam rendamnya)
2 Rebus kacang hijau dengan 600 more air sampai setengah matang, masukkan jahe yang sudah digeprek
3.Masukkan gula pasir dan garam, aduk sesekali
4.Setelah kacang hijau menjadi empuk, masukkan santan Dan Daun Pandan, Icip - icip. Done.
			
			
		</li>
	
		<li>
			Cara Membuat Saus Santan :
Campur semua bahan jadi satu, lalu masak sampai mendidih.
			
			
		</li>
	
		<li>
			Penyajian nya bisa kaya gini ya :P 
atau kalo suka dipisah pisah juga bisa :D
tergantung selera...
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur kacang ijo dan ketan hitam recipe. Thanks so much for your time. I am sure you will make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
