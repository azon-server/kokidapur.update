---
description: "Recipe of Super Quick Homemade Bubur kacang ijo tanpa rendam"
title: "Recipe of Super Quick Homemade Bubur kacang ijo tanpa rendam"
slug: 187-recipe-of-super-quick-homemade-bubur-kacang-ijo-tanpa-rendam

<p>
	<strong>Bubur kacang ijo tanpa rendam</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/7868bd9fcec98cb8/680x482cq70/bubur-kacang-ijo-tanpa-rendam-foto-resep-utama.jpg" alt="Bubur kacang ijo tanpa rendam" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is Drew, welcome to our recipe page. Today, I will show you a way to prepare a special dish, bubur kacang ijo tanpa rendam. One of my favorites. This time, I am going to make it a little bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo tanpa rendam is one of the most favored of current trending meals on earth. It's simple, it's fast, it tastes yummy. It's enjoyed by millions every day. They are fine and they look wonderful. Bubur kacang ijo tanpa rendam is something that I have loved my whole life.
</p>

<p>
To begin with this recipe, we must first prepare a few ingredients. You can cook bubur kacang ijo tanpa rendam using 7 ingredients and 4 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo tanpa rendam:</h3>

<ol>
	
		<li>{Take 500 gram of kacang hijau mentah. </li>
	
		<li>{Make ready 200 gram of gula merah. </li>
	
		<li>{Make ready 100 gram of gula pasir. </li>
	
		<li>{Take 5 lembar of daun pandan. </li>
	
		<li>{Prepare 2,5 liter of air. </li>
	
		<li>{Prepare  of Pelengkap :. </li>
	
		<li>{Get sesuai selera of Susu kental manis atau santan. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo tanpa rendam:</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau, buang kacang yg buruk, yg hancur2 dan mengambang. Cuci beberapa kali sampai air bilasan agak jernih..
			
			
		</li>
	
		<li>
			Potong2 daun pandan ukuran sekitar 5-10cm. Rebus kacang hijau dan daun pandan dengan api besar sampai mendidih. Gunakan panci tertutup. Biarkan mendidih agak lama, lalu matikan api. Jangan buka tutup panci, selama kurang lebih 30 menit..
			
			
		</li>
	
		<li>
			Setelah 30 menit, buka tutup panci, kacang hijau sudah empuk. Masukkan gula jawa dan gula pasir. Kalau suka banyak airnya, boleh ditambahkan air lagi. Masak lagi sebentar sampai semua gula larut, tes rasa..
			
			
		</li>
	
		<li>
			Hidangkan dengan susu kental manis ataupun santan. Nikmat, gurih, sehat..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this exceptional food bubur kacang ijo tanpa rendam recipe. Thanks so much for your time. I am sure you can make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
