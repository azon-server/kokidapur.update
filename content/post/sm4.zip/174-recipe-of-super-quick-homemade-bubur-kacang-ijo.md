---
description: "Recipe of Super Quick Homemade Bubur Kacang Ijo"
title: "Recipe of Super Quick Homemade Bubur Kacang Ijo"
slug: 174-recipe-of-super-quick-homemade-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/1c5e2dcc75e63b2f/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
		Resep bubur kacang ijo itu sendiri ada berbagai macam dengan tambahan bahan yang melengkapinya.
	
		Cara bikin bubur kacang hijau / ijo memerlukan trik dan tips tersendiri, sehingga hasilnya bisa lebih bagus dan juga enak serta lembut.
	
		Sebenarnya tidak ada yang istimewa saat anda membuat.
	
</p>
<p>
	Hey everyone, hope you're having an incredible day today. Today, we're going to make a special dish, bubur kacang ijo. One of my favorites. For mine, I will make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo is one of the most favored of recent trending meals on earth. It is enjoyed by millions daily. It is simple, it's quick, it tastes delicious. Bubur Kacang Ijo is something which I have loved my whole life. They are fine and they look wonderful.
</p>
<p>
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>

<p>
To get started with this particular recipe, we have to prepare a few components. You can cook bubur kacang ijo using 9 ingredients and 6 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Get 250 gr of kacang hijau. </li>
	
		<li>{Take 200 gr of gula merah sisir. </li>
	
		<li>{Prepare 50 gr of gula pasir (boleh tambah atau tidak pakai, sesuai selera). </li>
	
		<li>{Make ready 1 bks of kara kecil. </li>
	
		<li>{Take 2 sdm of tepung terigu (cairkan dg sedikit air). </li>
	
		<li>{Take 3 lembar of daun pandan (simpulkan). </li>
	
		<li>{Prepare 1 ruas of jahe (geprek). </li>
	
		<li>{Make ready 1/4 sdt of garam. </li>
	
		<li>{Get secukupnya of air. </li>
	
</ol>
<p>
	
		Bubur kacang hejo (su) Bubur kacang ijo (jv) Burjo.
	
		Slightly different names may be used in different regions of Indonesia, such as kacang ijo in Javanese areas.
	
		Cara masak bubur kacang ijo super simple dan enak.
	
		Rahasia Peyek Kacang Ijo Renyah, Tidak Keras dan Tahan Lama Bu Yun kali inia akan membagikan resep, tips dan tutorial cara.
	
</p>

<h3>Steps to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Cuci dan rendam kacang hijau 2-3 jam, saya 2 jam,.
			
			
		</li>
	
		<li>
			Setelah di rendam,rebus kacang hijau dgn 1,5 liter air bersama dgn daun pandan dan jahe, Rebus sampai empuk.
			
			
		</li>
	
		<li>
			Masukan garam, gula merah,gula pasir,dan santan,,,aduk2 rata.
			
			
		</li>
	
		<li>
			Tambahkan tepung terigu yg sudah di cairkan tadi,,aduk2 rata,,cek rasa apa bila terlalu manis boleh tambah air,atau kurang manis tambah gula, Masak sampai air mendidih lalu matikan api ya,.
			
			
		</li>
	
		<li>
			NB : bubur kacang ijo yg saya buat disini airnya sedikit kental,, karena saya agak kurang suka bubur yg airnya encer, Jadi buat yg mau coba,, sesuaikan sama selera masing2 ya !mau di kasih atau nggak..
			
			
		</li>
	
		<li>
			Masukan dlm mangkuk,, siap di hidangkan selagi hangat atau dingin.
			
			
		</li>
	
</ol>

<p>
	
		Cara Membuat Bubur Kacang Hijau Sederhana Yang Enak amp Kental Ala Dapur Dina.
	
		Ingin mencoba memasak Bubur Kacang Hijau sendiri, Burjo Pisang (Tips spy kacang ijo cepat empuk dan lembut), Bubur kacang ijo ketan item durian enakk, Burjo Nangka dan lain-lain yang lezat untuk.
	
		Sajikan bubur kacang hijau beserta rebusan santan saat akan di konsumsi untuk menghindari kacang hijau cepat basi Resep membuat bubur kacang hijau.
	
		Resep Bubur Kacang Ijo Enak Dan Cepat Mekar Atau Empuk.
	
		Kacang hijau / ijo merupakan salah satu bahan makanan yang bukan saja enak di buat minuman maupun makanan.
	
</p>

<p>
	So that's going to wrap it up with this special food bubur kacang ijo recipe. Thank you very much for your time. I'm confident you will make this at home. There's gonna be interesting food in home recipes coming up. Remember to bookmark this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
