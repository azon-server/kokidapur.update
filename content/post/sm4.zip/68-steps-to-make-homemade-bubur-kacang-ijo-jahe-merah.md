---
description: "Steps to Make Homemade Bubur Kacang Ijo Jahe Merah"
title: "Steps to Make Homemade Bubur Kacang Ijo Jahe Merah"
slug: 68-steps-to-make-homemade-bubur-kacang-ijo-jahe-merah

<p>
	<strong>Bubur Kacang Ijo Jahe Merah</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/48f11bbad0005e68/680x482cq70/bubur-kacang-ijo-jahe-merah-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Jahe Merah" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is Drew, welcome to my recipe page. Today, I will show you a way to make a special dish, bubur kacang ijo jahe merah. It is one of my favorites food recipes. This time, I'm gonna make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo Jahe Merah is one of the most favored of recent trending foods on earth. It is easy, it's fast, it tastes yummy. It is appreciated by millions daily. Bubur Kacang Ijo Jahe Merah is something which I've loved my entire life. They are nice and they look wonderful.
</p>

<p>
To get started with this particular recipe, we have to prepare a few ingredients. You can have bubur kacang ijo jahe merah using 9 ingredients and 6 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Jahe Merah:</h3>

<ol>
	
		<li>{Make ready 500 gr of kacang ijo. </li>
	
		<li>{Take 150 of gula pasir. </li>
	
		<li>{Prepare 50 gr of gula merah sisir. </li>
	
		<li>{Prepare 1500 ml of air. </li>
	
		<li>{Make ready 500 ml of santan kental. </li>
	
		<li>{Take 2 helai of daun pandan simpulkan. </li>
	
		<li>{Take 1 saset of Vanili. </li>
	
		<li>{Make ready 1 cm of jahe merah. </li>
	
		<li>{Get 1/4 sdt of Garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo Jahe Merah:</h3>

<ol>
	
		<li>
			Rendam kacang ijo semalaman (min 1 jam).
			
			
		</li>
	
		<li>
			Rebus kacang ijo dengan air dan daun pandan selama 5 menit dengan api besar dan panci tertutup..
			
			
		</li>
	
		<li>
			Setelah kacang ijo empuk masukkan santan kental dari 1 buah kelapa.
			
			
		</li>
	
		<li>
			Tambahkan garam dan jahe merah yang telah di kupas bersih.
			
			
		</li>
	
		<li>
			Tambahkan vanili aduk rata.
			
			
		</li>
	
		<li>
			Masukkan gula pasir dan gula merah. Aduk rata jika sudah mendidih matikan api.. Koreksi rasa dan sajikan.. ❤.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this special food bubur kacang ijo jahe merah recipe. Thank you very much for your time. I'm confident you will make this at home. There's gonna be interesting food in home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
