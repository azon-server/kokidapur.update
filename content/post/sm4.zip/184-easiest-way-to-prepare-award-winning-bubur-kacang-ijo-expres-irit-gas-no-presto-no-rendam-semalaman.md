---
description: "Easiest Way to Prepare Award-winning Bubur kacang ijo expres (irit gas,no presto no rendam semalaman)"
title: "Easiest Way to Prepare Award-winning Bubur kacang ijo expres (irit gas,no presto no rendam semalaman)"
slug: 184-easiest-way-to-prepare-award-winning-bubur-kacang-ijo-expres-irit-gas-no-presto-no-rendam-semalaman

<p>
	<strong>Bubur kacang ijo expres (irit gas,no presto no rendam semalaman)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/f1155c5590008768/680x482cq70/bubur-kacang-ijo-expres-irit-gasno-presto-no-rendam-semalaman-foto-resep-utama.jpg" alt="Bubur kacang ijo expres (irit gas,no presto no rendam semalaman)" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is me again, Dan, welcome to our recipe site. Today, I'm gonna show you how to prepare a distinctive dish, bubur kacang ijo expres (irit gas,no presto no rendam semalaman). It is one of my favorites. This time, I will make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang ijo expres (irit gas,no presto no rendam semalaman) is one of the most well liked of current trending meals in the world. It's enjoyed by millions every day. It's simple, it's quick, it tastes delicious. They're fine and they look wonderful. Bubur kacang ijo expres (irit gas,no presto no rendam semalaman) is something that I've loved my whole life.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we have to prepare a few components. You can have bubur kacang ijo expres (irit gas,no presto no rendam semalaman) using 8 ingredients and 4 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo expres (irit gas,no presto no rendam semalaman):</h3>

<ol>
	
		<li>{Take 2 genggam of kacang hijau. </li>
	
		<li>{Get 3 gelas of air. </li>
	
		<li>{Take 1 buah of gula merah ukuran sedang. </li>
	
		<li>{Get 3 sdm of gula pasir. </li>
	
		<li>{Prepare Sejumput of garam. </li>
	
		<li>{Make ready Sejumput of vanila bubuk. </li>
	
		<li>{Make ready 1 bungkus of santan instan 65gr. </li>
	
		<li>{Prepare 2 helai of daun pandan simpulkan. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo expres (irit gas,no presto no rendam semalaman):</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau, buang kotoran dan biji kecil yang mengapung, didihkan air bersama daun pandan. Masukan kacang hijau setelah air mendidih. Masak kacang hijau selama 5 menit..
			
			
		</li>
	
		<li>
			Setelah 5 menit, matikan kompor, tutup panci biarkan diatas kompor jangan dipindahkan biarkan ditempat yang sama selama 30 menit. Pakai timer supaya waktunya pas..
			
			
		</li>
	
		<li>
			Setelah 30menit nyalakan kembali kompor, masukan gula merah, gula pasir, garam, vanila dan santan instan. Aduk rata didihkan kembali selama 5 menit..
			
			
		</li>
	
		<li>
			Tuang di gelas saji, jika kurang manis boleh ditambahkan susu kental manis. Kacangnya merekah sempurna, foto agak gelap karena hujan. Siap di sajikan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this exceptional food bubur kacang ijo expres (irit gas,no presto no rendam semalaman) recipe. Thank you very much for reading. I am confident you will make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to save this page in your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
