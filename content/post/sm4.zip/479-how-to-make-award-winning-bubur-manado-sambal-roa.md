---
description: "How to Make Award-winning Bubur Manado Sambal Roa"
title: "How to Make Award-winning Bubur Manado Sambal Roa"
slug: 479-how-to-make-award-winning-bubur-manado-sambal-roa

<p>
	<strong>Bubur Manado Sambal Roa</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/f3f95d601cd53df3/680x482cq70/bubur-manado-sambal-roa-foto-resep-utama.jpg" alt="Bubur Manado Sambal Roa" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is me, Dave, welcome to my recipe site. Today, I will show you a way to prepare a distinctive dish, bubur manado sambal roa. One of my favorites. For mine, I will make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Manado Sambal Roa is one of the most well liked of current trending foods in the world. It's simple, it's fast, it tastes yummy. It's enjoyed by millions every day. Bubur Manado Sambal Roa is something that I have loved my whole life. They're nice and they look wonderful.
</p>

<p>
To get started with this particular recipe, we have to first prepare a few components. You can have bubur manado sambal roa using 14 ingredients and 3 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Manado Sambal Roa:</h3>

<ol>
	
		<li>{Get 2 pcs of Jagung di pipil. </li>
	
		<li>{Get 1/2 kg of ubi. </li>
	
		<li>{Prepare 1/4 kg of Labu kuning. </li>
	
		<li>{Prepare 1/2 cup of beras. </li>
	
		<li>{Prepare 1 ikat of kangkung. </li>
	
		<li>{Prepare 1 ikat of bayam merah/ijo. </li>
	
		<li>{Make ready 1 ikat of sayur Gedi (gak Tau apa bahasa indonesianya). </li>
	
		<li>{Make ready  of Sereh. </li>
	
		<li>{Make ready  of Daun kunyit. </li>
	
		<li>{Get  of Untuk Sambal:. </li>
	
		<li>{Make ready Secukupnya of bawang. </li>
	
		<li>{Take Secukupnya of Cabe. </li>
	
		<li>{Get Secukupnya of tomat. </li>
	
		<li>{Get  of Ikan Roa. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado Sambal Roa:</h3>

<ol>
	
		<li>
			Kupas Dan cuci bersih semua bahan. Masukan beras, Labu kuning, jagung, ubi, sereh,daun kuning dan 2 liter Air masak sampai menjadi bubur.
			
			
		</li>
	
		<li>
			Sementara itu siapkan Sambal: ulek bawang, cabe dan tomat kemudian panaskan minya di pan dan masukkan semua bahan yang di ulek setelah bahan mateng masukkan ikan roa yang terlebih dahulu di blender menjadi halus tambahkan gula, garam Dan Lada koreksi rasa angkat Dan sajikan.
			
			
		</li>
	
		<li>
			Setelah buburnya masak, masukan garam dan masako koreksi rasa apabila sudah pas,campurkan semua sayur angkat dan hidangkan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur manado sambal roa recipe. Thanks so much for reading. I am confident you will make this at home. There's gonna be interesting food at home recipes coming up. Remember to save this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
