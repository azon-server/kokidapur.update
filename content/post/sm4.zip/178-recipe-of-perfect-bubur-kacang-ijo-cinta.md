---
description: "Recipe of Perfect Bubur kacang ijo cinta"
title: "Recipe of Perfect Bubur kacang ijo cinta"
slug: 178-recipe-of-perfect-bubur-kacang-ijo-cinta

<p>
	<strong>Bubur kacang ijo cinta</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/33bc3bd6bfda8d33/680x482cq70/bubur-kacang-ijo-cinta-foto-resep-utama.jpg" alt="Bubur kacang ijo cinta" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Drew, welcome to our recipe site. Today, we're going to make a distinctive dish, bubur kacang ijo cinta. One of my favorites. For mine, I am going to make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo cinta is one of the most favored of current trending meals in the world. It's appreciated by millions every day. It's easy, it is quick, it tastes yummy. They are nice and they look fantastic. Bubur kacang ijo cinta is something which I've loved my whole life.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we must first prepare a few ingredients. You can have bubur kacang ijo cinta using 5 ingredients and 6 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo cinta:</h3>

<ol>
	
		<li>{Make ready 1/2 kg of kacang hijau. </li>
	
		<li>{Make ready 2 liter of air. </li>
	
		<li>{Make ready 1 ruas of jahe. </li>
	
		<li>{Make ready 4 SDM of gula pasir. </li>
	
		<li>{Prepare sesuai selera of Susu cair/ susu kental manis. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo cinta:</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau, lalu rendam dengan air bersih semalaman.. Agar tidak basi, letakkan dalam kulkas...
			
			
		</li>
	
		<li>
			Buang air bekas rendaman, rebus kacang hijau dan jahe yg telah digeprek dengan 2 liter air...
			
			
		</li>
	
		<li>
			Setelah air mendidih, kecilkan api kompor, masak hingga kacang hijau empuk...
			
			
		</li>
	
		<li>
			Setelah empuk, tambahkan gula pasir, aduk rata...
			
			
		</li>
	
		<li>
			Setelah benar-benar empuk, matikan api, angkat bubur kacang hijau dari kompor,,.
			
			
		</li>
	
		<li>
			Bubur kacang hijau siap dihidangkan bersama susu cair/ susu kental manis 😄😄😄.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this special food bubur kacang ijo cinta recipe. Thanks so much for reading. I'm sure you can make this at home. There's gonna be more interesting food in home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
