---
description: "Recipe of Any-night-of-the-week Bubur Manado simpel"
title: "Recipe of Any-night-of-the-week Bubur Manado simpel"
slug: 253-recipe-of-any-night-of-the-week-bubur-manado-simpel

<p>
	<strong>Bubur Manado simpel</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/36f9e3b3773c0531/680x482cq70/bubur-manado-simpel-foto-resep-utama.jpg" alt="Bubur Manado simpel" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is Louise, welcome to our recipe site. Today, I'm gonna show you how to prepare a special dish, bubur manado simpel. One of my favorites. This time, I am going to make it a bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Manado simpel is one of the most well liked of current trending foods in the world. It's appreciated by millions every day. It's easy, it is fast, it tastes delicious. Bubur Manado simpel is something which I've loved my whole life. They are nice and they look fantastic.
</p>

<p>
To begin with this particular recipe, we have to first prepare a few ingredients. You can cook bubur manado simpel using 11 ingredients and 6 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Manado simpel:</h3>

<ol>
	
		<li>{Get 1/2 liter of Beras. </li>
	
		<li>{Make ready 1/2 kilo of Labu kuning kira2. </li>
	
		<li>{Take 1 buah of Jagung. </li>
	
		<li>{Prepare 1/2 ikat of Bayam. </li>
	
		<li>{Make ready  of Kemangi 2000. </li>
	
		<li>{Make ready 4 siung of Bawang putih sedang. </li>
	
		<li>{Prepare 2 batang of Daun bawang. </li>
	
		<li>{Take 3 lembar of Daun salam. </li>
	
		<li>{Make ready 2 of Masako. </li>
	
		<li>{Make ready setengah sendok teh of garam. </li>
	
		<li>{Get 2 liter of Air kira2  jika kurang boleh ditambah sesuai selera. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado simpel:</h3>

<ol>
	
		<li>
			Cuci beras lalu rebus bersama air dan daun salam.
			
			
		</li>
	
		<li>
			Cincang bawang putih dan iris dadu bawang lalu ditumis hingga harum lalu masukkan ke beras yg sedang di rebus.
			
			
		</li>
	
		<li>
			Sambil menunggu beras nya mekar boleh potong potong labu, pipil jagung, petik daun bayam dan daun kemangi lalu cuci bersih.
			
			
		</li>
	
		<li>
			Bila beras sudah mekar dan airnya sudah mengental masukkan labu dan jagung lalu sesekali aduk agar tidak lengket.
			
			
		</li>
	
		<li>
			Bila labu sudah empuk dan bubur sudah mengental baru masukkan bayam dan kemangi sambil di aduk sampai bayam dan kemangi matang.
			
			
		</li>
	
		<li>
			Siap dihidangkan dengan sambal tomat terasi dan ikan asin goreng... Hemmm yummy.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur manado simpel recipe. Thanks so much for reading. I am confident you can make this at home. There's gonna be more interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
