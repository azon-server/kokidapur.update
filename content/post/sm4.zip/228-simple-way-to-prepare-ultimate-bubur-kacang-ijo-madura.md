---
description: "Simple Way to Prepare Ultimate Bubur Kacang Ijo Madura"
title: "Simple Way to Prepare Ultimate Bubur Kacang Ijo Madura"
slug: 228-simple-way-to-prepare-ultimate-bubur-kacang-ijo-madura

<p>
	<strong>Bubur Kacang Ijo Madura</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/911cf924dfcdf3e1/680x482cq70/bubur-kacang-ijo-madura-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Madura" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you are having an incredible day today. Today, I will show you a way to prepare a special dish, bubur kacang ijo madura. One of my favorites. For mine, I am going to make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo Madura is one of the most popular of current trending meals in the world. It's easy, it's fast, it tastes yummy. It is appreciated by millions daily. Bubur Kacang Ijo Madura is something which I have loved my whole life. They're nice and they look fantastic.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we must prepare a few ingredients. You can have bubur kacang ijo madura using 7 ingredients and 6 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Madura:</h3>

<ol>
	
		<li>{Prepare 250 gr of Kacang hijau. </li>
	
		<li>{Prepare 300 gr of Ketan hitam. </li>
	
		<li>{Get secukupnya of Santan, saya pakai Ayam Brand. </li>
	
		<li>{Prepare secukupnya of Gula pasir. </li>
	
		<li>{Make ready secukupnya of Garam. </li>
	
		<li>{Prepare 1 sdt of Vanili. </li>
	
		<li>{Take secukupnya of Air untuk memasak. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo Madura:</h3>

<ol>
	
		<li>
			Kacang hijau : Cuci bersih, masak dengan air secukupnya (saya 4 gelas) hingga matang &amp; air menyusut. Aduk sebentar, neri gula pasir, Sisihkan..
			
			
		</li>
	
		<li>
			Ketan hitam : cuci bersih hingga air bening, rendam sebentar sekitar 3 jam. Kukus 20 mnt. Rebus lagi dengan 1,5 gelas air rendamannya hingga airnya menyusut. Diamkan sebentar. Kukus lagi 20mnt..
			
			
		</li>
	
		<li>
			Santan : Air matang 700ml + santan 300ml + Vanili + garam didihkan sambil diaduk..
			
			
		</li>
	
		<li>
			Setelah semua matang, tata di mangkuk, siap dinikmati.
			
			
		</li>
	
		<li>
			Bisa juga dinikmati dengan penambahan potongan roti tawar..
			
			
		</li>
	
		<li>
			Atau menikmatinya disiang hari dengan tambahan es batu. Kalau ini bisa tambah susu kental manis 😋 enak banget..👍 yuk, dicoba....
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food bubur kacang ijo madura recipe. Thanks so much for reading. I am sure that you can make this at home. There is gonna be interesting food in home recipes coming up. Remember to bookmark this page in your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
