---
description: "Recipe of Super Quick Homemade Bubur Kacang Ijo"
title: "Recipe of Super Quick Homemade Bubur Kacang Ijo"
slug: 139-recipe-of-super-quick-homemade-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/7ce1d37a6672fe0d/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's John, welcome to our recipe page. Today, I'm gonna show you how to prepare a distinctive dish, bubur kacang ijo. It is one of my favorites food recipes. For mine, I will make it a bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo is one of the most well liked of recent trending foods in the world. It's easy, it is quick, it tastes yummy. It is enjoyed by millions every day. They're fine and they look wonderful. Bubur Kacang Ijo is something which I have loved my entire life.
</p>

<p>
To get started with this particular recipe, we have to prepare a few components. You can have bubur kacang ijo using 8 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Prepare 250 gr of Kacang Hijau. </li>
	
		<li>{Make ready 700 ml of Air. </li>
	
		<li>{Get 100 gr of Gula Merah (Sisir Halus). </li>
	
		<li>{Take 2 Sdm of Gula Pasir / Secukupnya Sesuai Selera. </li>
	
		<li>{Get 150 ml of Santan Kental. </li>
	
		<li>{Take 1 Ruas Jari of Jahe (Geprek/Memarkan). </li>
	
		<li>{Prepare 1 Helai of Daun Pandan (Ikat Simpul). </li>
	
		<li>{Take Sejumput of Garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau. Tiriskan..
			
			
		</li>
	
		<li>
			Rebus air hingga mendidih lalu masukkan kacang hijau, rebus hingga empuk. Jika sudah empuk tambahkan gula merah, gula pasir, dan jahe..
			
			
		</li>
	
		<li>
			Masukkan daun pandan dan sejumput garam. Aduk hingga gula larut dan semua bahan tercampur rata..
			
			
		</li>
	
		<li>
			Terakhir, masukkan santan kelapa. Masak sampai mendidih sambil diaduk terus agar santan tidak pecah dan menggumpal. Jika sudah matang, matikan kompor..
			
			
		</li>
	
		<li>
			Tarraaa.. bubur kacang ijonya siap disajikan. 😊🥰.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur kacang ijo recipe. Thanks so much for your time. I am sure that you will make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
