---
description: "How to Prepare Favorite Bubur Manado Daun Gedi dan Labu Kuning"
title: "How to Prepare Favorite Bubur Manado Daun Gedi dan Labu Kuning"
slug: 331-how-to-prepare-favorite-bubur-manado-daun-gedi-dan-labu-kuning

<p>
	<strong>Bubur Manado Daun Gedi dan Labu Kuning</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/ab80d9ed4bb75f42/680x482cq70/bubur-manado-daun-gedi-dan-labu-kuning-foto-resep-utama.jpg" alt="Bubur Manado Daun Gedi dan Labu Kuning" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you are having an amazing day today. Today, I'm gonna show you how to make a special dish, bubur manado daun gedi dan labu kuning. It is one of my favorites. For mine, I am going to make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Manado Daun Gedi dan Labu Kuning is one of the most popular of current trending meals in the world. It's easy, it's fast, it tastes delicious. It's appreciated by millions daily. They're fine and they look wonderful. Bubur Manado Daun Gedi dan Labu Kuning is something that I have loved my entire life.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we must prepare a few components. You can have bubur manado daun gedi dan labu kuning using 17 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Manado Daun Gedi dan Labu Kuning:</h3>

<ol>
	
		<li>{Prepare 1 cup of beras. </li>
	
		<li>{Get 1/2 buah of labu kuning sedang. </li>
	
		<li>{Prepare 2 ikat of kangkung. </li>
	
		<li>{Prepare 1 ikat of bayam. </li>
	
		<li>{Get 1 ikat of sayur gedi. </li>
	
		<li>{Make ready 1 ikat of kemangi. </li>
	
		<li>{Prepare secukupnya of garam. </li>
	
		<li>{Prepare secukupnya of air. </li>
	
		<li>{Take  of Sambal Terasi:. </li>
	
		<li>{Prepare 3 buah of cabai merah besar. </li>
	
		<li>{Prepare 3 buah of cabai rawit merah. </li>
	
		<li>{Take 1 buah of tomat besar. </li>
	
		<li>{Get 1 sendok teh of terasi. </li>
	
		<li>{Make ready secukupnya of garam. </li>
	
		<li>{Make ready secukupnya of gula pasir. </li>
	
		<li>{Make ready  of Pelengkap:. </li>
	
		<li>{Get  of ikan asin goreng renyah (yang seperti kerupuk). </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Manado Daun Gedi dan Labu Kuning:</h3>

<ol>
	
		<li>
			Kupas labu kuning, kemudian buang bijinya dan potong-potong. Siangi kangkung dan bayam, lalu iris daun gedi sesuai selera. Petik kemangi per kuntum..
			
			
		</li>
	
		<li>
			Rebus beras bersama air secukupnya hingga menjadi bubur encer. Aduk-aduk terus agar dasar panci tidak hangus..
			
			
		</li>
	
		<li>
			Setelah itu masukkan kangkung, daun gedi, dan bayam. Masak sampai sayuran matang..
			
			
		</li>
	
		<li>
			Jika sayuran sudah matang, bumbui bubur dengan garam dan kemangi. Aduk sebentar, lalu segera angkat dari kompor..
			
			
		</li>
	
		<li>
			Uleg bahan-bahan sambal terasi, lalu sajikan bubur Manado bersama ikan asin dan sambalnya..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur manado daun gedi dan labu kuning recipe. Thank you very much for your time. I am sure that you can make this at home. There's gonna be more interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
