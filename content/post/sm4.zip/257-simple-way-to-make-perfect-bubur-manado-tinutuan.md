---
description: "Simple Way to Make Perfect Bubur manado (tinutuan)"
title: "Simple Way to Make Perfect Bubur manado (tinutuan)"
slug: 257-simple-way-to-make-perfect-bubur-manado-tinutuan

<p>
	<strong>Bubur manado (tinutuan)</strong>. 
	Bubur Manado atau TINUTUAN kini menjadi makan favorite bukan hanya untuk masyarakat Manado tapi juga untuk seluruh masyarakat indonesia. Tinutuan is originated in Manado, a city located in North Sulawesi island of Idonesia. Tinutuan atau Bubur Manado adalah makanan khas Indonesia dari Manado, Sulawesi Utara.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/99ba3132beeceb86/680x482cq70/bubur-manado-tinutuan-foto-resep-utama.jpg" alt="Bubur manado (tinutuan)" style="width: 100%;">
	
	
		Tinutuan, also known as bubur manado or Manadonese porridge is a specialty of the Manado At its place of origin, Manado, tinutuan usually served with cakalang fufu (smoked skipjack tuna), shrimp.
	
		Bubur Manado atau juga dikenal dengan nama Tinutuan adalah bubur khas suku Minahasa, Manado, Indonesia.
	
		Bubur memiliki kombinasi rasa manis, gurih, asin dan juga pedas.
	
</p>
<p>
	Hello everybody, hope you're having an incredible day today. Today, I will show you a way to make a special dish, bubur manado (tinutuan). One of my favorites food recipes. For mine, I'm gonna make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur manado (tinutuan) is one of the most favored of current trending meals on earth. It's appreciated by millions every day. It is easy, it is quick, it tastes yummy. They are fine and they look wonderful. Bubur manado (tinutuan) is something that I've loved my entire life.
</p>
<p>
	Bubur Manado atau TINUTUAN kini menjadi makan favorite bukan hanya untuk masyarakat Manado tapi juga untuk seluruh masyarakat indonesia. Tinutuan is originated in Manado, a city located in North Sulawesi island of Idonesia. Tinutuan atau Bubur Manado adalah makanan khas Indonesia dari Manado, Sulawesi Utara.
</p>

<p>
To begin with this particular recipe, we have to prepare a few ingredients. You can have bubur manado (tinutuan) using 22 ingredients and 7 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur manado (tinutuan):</h3>

<ol>
	
		<li>{Prepare  of Bahan bubur:. </li>
	
		<li>{Take 4 piring of nasi. </li>
	
		<li>{Prepare 1/2 ikat of bayam. </li>
	
		<li>{Take 5 potong of labu kuning (bersihkan kemudian rebus). </li>
	
		<li>{Prepare 1/2 batang of jagung, sisir jagung. </li>
	
		<li>{Take 5 siung of bawang merah (iris tipis). </li>
	
		<li>{Get 3 siung of bawang putih (iris tipis). </li>
	
		<li>{Take 1 batang of sereh uk besar (geprek). </li>
	
		<li>{Prepare 1 lembar of daun salam. </li>
	
		<li>{Get 3 lembar of daun jeruk. </li>
	
		<li>{Prepare secukupnya of Garam, gula, kaldu jamur. </li>
	
		<li>{Prepare 1 lt of air matang. </li>
	
		<li>{Prepare  of Topping: ikan asin. </li>
	
		<li>{Make ready  of Bahan sambal:. </li>
	
		<li>{Take 3 siung of bawang merah. </li>
	
		<li>{Get 2 siung of bawang putih. </li>
	
		<li>{Make ready 20 of cabe rawit merah. </li>
	
		<li>{Take 3 of cabe merah keriting. </li>
	
		<li>{Take 1 buah of tomat uk sedang. </li>
	
		<li>{Take 1 sachet of terasi. </li>
	
		<li>{Take  of Minyak untuk menumis. </li>
	
		<li>{Get secukupnya of Garam, kaldu jamur. </li>
	
</ol>
<p>
	
		Waroeng Masakan Manado &#34;cassava&#34; Pujasera Blok M Square Lt.basement blok J.
	
		Tinutuan atau Bubur Manado adalah makanan khas dari Manado - Provinsi Sulawesi Utara.
	
		Ibarat Nasi Goreng di Pulau Jawa atau Mpek-Mpek di Palembang begitu juga halnya dengan Tinutuan.
	
		KULINER TINUTUAN/BUBUR MANADO(Manado pooridge) - PRODUKSI TVRI SULUT.
	
</p>

<h3>Instructions to make Bubur manado (tinutuan):</h3>

<ol>
	
		<li>
			Siapkan bahan bubur.
			
			
		</li>
	
		<li>
			Masukan nasi kedalam panci kemudian masukan air 1 lt, bawang2an, jagung, labu, sereh, daun jeruk, daun salam. Masak dengan api sedang.
			
			
		</li>
	
		<li>
			Jika nasi sudah mulai menjadi bubur masukan bayam, garam, gula dan kaldu jamur. Aduk2 sampe rata. Kecilkan api. Koreksi rasa, sambil terus di aduk masak sampai bayam layu dan labu kuning hancur. Kalau mau bubur lebih encer bisa tambahkan air matang lagi kemudian tinggal tambahkan sedikit lagi garam, gula dan kaldu jamurnya.
			
			
		</li>
	
		<li>
			Untuk sambalnya: siapkan bahan, panaskan penggorengan, masukan minyak kemudian tumis bahan sampe matang (untuk terasi tumis sebentar saja karna akan mudah hancur).
			
			
		</li>
	
		<li>
			Jika sudah matang, angkat kemudian blender sambal sampai halus.
			
			
		</li>
	
		<li>
			Tumis kembali sambal dengan sedikit minyak, masukan garam, dan kaldu jamur secukupnya. Aduk2 angkat dan sajikan.
			
			
		</li>
	
		<li>
			Bubur manado dan sambalnya siap di nikmati, sajikan dengan ikan asin lebih nikmat.
			
			
		</li>
	
</ol>

<p>
	
		Bubur Manado atau TINUTUAN kini menjadi makan favorite bukan hanya untuk masyarakat MUKANG bubur manado tinutuan sama mie cakalang!!!
	
		Ayo ayo mulai food trip di Manado!
	
		JAKARTA,KOMPAS.com - Bubur manado atau tinutuan terkenal sehat dan nikmat.
	
		Bubur manado adalah bubur yang dicampur dengan aneka sayur seperti labu kuning, ubi, kangkung, bayam, daun.
	
		Tinutuan atau Bubur Manado adalah makanan khas Indonesia dari Manado, Sulawesi Utara.
	
</p>

<p>
	So that is going to wrap this up with this special food bubur manado (tinutuan) recipe. Thank you very much for your time. I'm sure you will make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
