---
description: "How to Make Homemade #6. Bubur Kacang Ijo Pandan #prRamadhan_Takjil #pekaninspirasi"
title: "How to Make Homemade #6. Bubur Kacang Ijo Pandan #prRamadhan_Takjil #pekaninspirasi"
slug: 226-how-to-make-homemade-6-bubur-kacang-ijo-pandan-prramadhan-takjil-pekaninspirasi

<p>
	<strong>#6. Bubur Kacang Ijo Pandan #prRamadhan_Takjil #pekaninspirasi</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/25e104033c0526f7/680x482cq70/6-bubur-kacang-ijo-pandan-prramadhan_takjil-pekaninspirasi-foto-resep-utama.jpg" alt="#6. Bubur Kacang Ijo Pandan #prRamadhan_Takjil #pekaninspirasi" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's Brad, welcome to our recipe page. Today, we're going to make a distinctive dish, #6. bubur kacang ijo pandan #prramadhan_takjil #pekaninspirasi. One of my favorites. This time, I'm gonna make it a little bit unique. This will be really delicious.
</p>
	
<p>
	#6. Bubur Kacang Ijo Pandan #prRamadhan_Takjil #pekaninspirasi is one of the most well liked of current trending meals on earth. It's enjoyed by millions daily. It's simple, it's fast, it tastes yummy. #6. Bubur Kacang Ijo Pandan #prRamadhan_Takjil #pekaninspirasi is something which I've loved my entire life. They are nice and they look fantastic.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we have to first prepare a few ingredients. You can cook #6. bubur kacang ijo pandan #prramadhan_takjil #pekaninspirasi using 9 ingredients and 2 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make #6. Bubur Kacang Ijo Pandan #prRamadhan_Takjil #pekaninspirasi:</h3>

<ol>
	
		<li>{Prepare 200 gr of kacang ijo, direndam semalam. </li>
	
		<li>{Get 1 lt of air. </li>
	
		<li>{Get 700 ml of santan dr 1 btr kelapa. </li>
	
		<li>{Make ready 3 lbr of daun pandan, simpulkan. </li>
	
		<li>{Prepare 1/2 sdt of garam. </li>
	
		<li>{Take 200 gr of gula pasir. </li>
	
		<li>{Make ready 2 sdm of tepung maizena, larutkan dgn. </li>
	
		<li>{Take 2 sdm of air. </li>
	
		<li>{Prepare 50 ml of jus pandan (10 lbr daun pandan + air) atau + daun suji. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make #6. Bubur Kacang Ijo Pandan #prRamadhan_Takjil #pekaninspirasi:</h3>

<ol>
	
		<li>
			Rebus kacang ijo, air dan daun pandan sampai kacang ijo nya pecah. Masukkan gula pasir, garam dan air pandan, aduk hingga mendidih..
			
			
		</li>
	
		<li>
			Tambahkan santan dan larutan tepung maizena, didihkan sekali lg hingga kental lalu angkat. Bisa jg ditambahkan nangka kalau suka ya,,,,.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this special food #6. bubur kacang ijo pandan #prramadhan_takjil #pekaninspirasi recipe. Thank you very much for reading. I am confident that you will make this at home. There's gonna be more interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
