---
description: "Step-by-Step Guide to Prepare Super Quick Homemade Bubur Manado dengan Udang dan Ikan Asin"
title: "Step-by-Step Guide to Prepare Super Quick Homemade Bubur Manado dengan Udang dan Ikan Asin"
slug: 481-step-by-step-guide-to-prepare-super-quick-homemade-bubur-manado-dengan-udang-dan-ikan-asin

<p>
	<strong>Bubur Manado dengan Udang dan Ikan Asin</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/961e6c05f1be04f4/680x482cq70/bubur-manado-dengan-udang-dan-ikan-asin-foto-resep-utama.jpg" alt="Bubur Manado dengan Udang dan Ikan Asin" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's Jim, welcome to my recipe page. Today, we're going to prepare a special dish, bubur manado dengan udang dan ikan asin. One of my favorites food recipes. This time, I'm gonna make it a bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Manado dengan Udang dan Ikan Asin is one of the most favored of recent trending foods on earth. It's enjoyed by millions daily. It's easy, it is quick, it tastes delicious. They're fine and they look wonderful. Bubur Manado dengan Udang dan Ikan Asin is something that I've loved my whole life.
</p>

<p>
To get started with this recipe, we must first prepare a few components. You can have bubur manado dengan udang dan ikan asin using 26 ingredients and 4 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Manado dengan Udang dan Ikan Asin:</h3>

<ol>
	
		<li>{Prepare 1 cup of Beras. </li>
	
		<li>{Prepare 400 ml of Air kaldu udang. </li>
	
		<li>{Take 250 gram of udang (cuci bersih, rebus dan sisihkan air kaldunya). </li>
	
		<li>{Take 1 buah of jagung (sisir kasar). </li>
	
		<li>{Prepare  of Bayam (petik daunnya). </li>
	
		<li>{Get  of Kacang panjang (potong-potong). </li>
	
		<li>{Get  of Labu kuning (iris kotak kecil). </li>
	
		<li>{Make ready  of Ikan asin (Rendam sekitar 10 menit dengan air panas jika terlalu asin kemudian goreng hingga kering). </li>
	
		<li>{Make ready secukupnya of Garam. </li>
	
		<li>{Make ready  of Bahan Perkedel. </li>
	
		<li>{Make ready 1 buah of jagung (disisir). </li>
	
		<li>{Take 1 siung of Bawang putih (haluskan). </li>
	
		<li>{Make ready Sejumput of merica. </li>
	
		<li>{Make ready secukupnya of Tepung terigu. </li>
	
		<li>{Prepare  of Daun bawang (iris halus). </li>
	
		<li>{Get 1 btr of telur. </li>
	
		<li>{Prepare  of Air. </li>
	
		<li>{Make ready  of Bahan sambel terasi:. </li>
	
		<li>{Prepare Sejumput of garam. </li>
	
		<li>{Prepare 1 siung of bawang putih. </li>
	
		<li>{Take 1 siung of bawang merah. </li>
	
		<li>{Prepare  of Cabe rawit (sesuai selera, saya pakai 2 karena tidak suka pedas). </li>
	
		<li>{Make ready 2 buah of tomat kecil. </li>
	
		<li>{Take  of Garam. </li>
	
		<li>{Prepare  of Terasi udang. </li>
	
		<li>{Make ready 1/2 of jeruk purut. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado dengan Udang dan Ikan Asin:</h3>

<ol>
	
		<li>
			Cuci beras kemudian masak dengan air kaldu udang di rice cooker. Saat setengah matang tambahkan labu dan jagung. Aduk sekali-kali. Jika sudah hampir matang dan masih berair tambahkan secara bertahap kacang panjang lalu bayam dan garam secukupnya. Aduk rata dan matikan rice cooker..
			
			
		</li>
	
		<li>
			Buat perkedel dengan mencampurkan jagung yang sudah disisir, telur, bawang putih, bawang goreng, merica, garam, air secukupnya dan terigu secukupnya hingga mengental. Goreng hingga kuning keemasan..
			
			
		</li>
	
		<li>
			Buat sambel terasi dengan terlebih dahulu menggoreng tomat, cabe, bawang dan terasi (dapat diikutkan saat menggoreng ikan asin/perkedel). Ulek semua bahan kemudian peraskan 1/2 jeruk purut..
			
			
		</li>
	
		<li>
			Sajikan bubur dengan ditambahkan ikan asin, udang, perkedel jagung dan sambel terasi.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this special food bubur manado dengan udang dan ikan asin recipe. Thank you very much for your time. I am confident you will make this at home. There is gonna be more interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
