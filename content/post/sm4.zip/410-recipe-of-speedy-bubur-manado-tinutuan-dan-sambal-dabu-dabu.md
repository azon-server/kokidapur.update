---
description: "Recipe of Speedy Bubur Manado “Tinutuan” dan sambal dabu-dabu"
title: "Recipe of Speedy Bubur Manado “Tinutuan” dan sambal dabu-dabu"
slug: 410-recipe-of-speedy-bubur-manado-tinutuan-dan-sambal-dabu-dabu

<p>
	<strong>Bubur Manado “Tinutuan” dan sambal dabu-dabu</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/7a4b412983c474dc/680x482cq70/bubur-manado-tinutuan-dan-sambal-dabu-dabu-foto-resep-utama.jpg" alt="Bubur Manado “Tinutuan” dan sambal dabu-dabu" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you're having an amazing day today. Today, I will show you a way to make a distinctive dish, bubur manado “tinutuan” dan sambal dabu-dabu. It is one of my favorites food recipes. This time, I will make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Manado “Tinutuan” dan sambal dabu-dabu is one of the most well liked of current trending meals on earth. It is easy, it's quick, it tastes delicious. It is appreciated by millions every day. Bubur Manado “Tinutuan” dan sambal dabu-dabu is something that I have loved my whole life. They are nice and they look wonderful.
</p>

<p>
To begin with this recipe, we have to first prepare a few components. You can cook bubur manado “tinutuan” dan sambal dabu-dabu using 17 ingredients and 3 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Manado “Tinutuan” dan sambal dabu-dabu:</h3>

<ol>
	
		<li>{Take 1 cup of beras. </li>
	
		<li>{Take 1/4 of kabocha (saya pakai 3 pcs ubi ukuran sedang). </li>
	
		<li>{Get 2 pcs of jagung (pipil). </li>
	
		<li>{Get 3 siung of bawang putih (iris tipis). </li>
	
		<li>{Make ready 1 batang of serai (geprek). </li>
	
		<li>{Get 1 ruas of jahe (geprek). </li>
	
		<li>{Get 3 lembar of daun bawang. </li>
	
		<li>{Make ready 3 lembar of daun salam. </li>
	
		<li>{Take  of 3 lembar daun kunyit (saya skip). </li>
	
		<li>{Prepare 15 helai of sayur kangkung (saya pakai sayur bayam dan disini bayam hanya dijual daun nya saja tanpa batang). </li>
	
		<li>{Take 1 ikat of daun kemangi (saya skip). </li>
	
		<li>{Prepare 1 gelas of tinggi air putih. </li>
	
		<li>{Make ready  of Bahan sambal dabu-dabu. </li>
	
		<li>{Make ready 1 buah of tomat (iris kecil). </li>
	
		<li>{Make ready 2 siung of bawang merah ukuran besar (iris tipis). </li>
	
		<li>{Prepare 1 buah of perasan lemon cu’i (saya ganti dengan lemon biasa). </li>
	
		<li>{Take 5 pcs of cabe rawit. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado “Tinutuan” dan sambal dabu-dabu:</h3>

<ol>
	
		<li>
			Panaskan air di panci besar (intinya air harus 3x lebih banyak dari memasak nasi biasa), masukan beras dan kabocha/ubi yang sudah dipotong sesuai selera terlebih dahulu...disusul dengan jagung, bawang putih, daun salam, daun kunyit serai &amp; jahe..
			
			
		</li>
	
		<li>
			Setelah semua bahan dimasukan, masak di api medium sambil sesekali di aduk.. kemudian bumbui bubur dengan garam, gula, sedikit lada bubuk, kaldu jamur / penyedap (optional)... tambahkan air bila perlu, sampai mencapai konsistensi kekentalan bubur yang diinginkan..setelah hampir matang, masukan daun bawang, kangkung / bayam &amp; daun kemangi sambil kembali di aduk hingga semua bersatu. Pindahkan ke wadah lain agar tidak overcooked.
			
			
		</li>
	
		<li>
			Untuk dabu-dabu, iris smua bahan dan aduk menjadi 1.. tambahkan perasan lemon dan tambahkan sejumput garam.. Tinutuan lebih nikmat lagi bila dinikmati bersama dengan ikan tongkol goreng.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this exceptional food bubur manado “tinutuan” dan sambal dabu-dabu recipe. Thank you very much for reading. I'm sure that you can make this at home. There's gonna be interesting food in home recipes coming up. Remember to bookmark this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
