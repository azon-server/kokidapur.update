---
description: "Simple Way to Make Super Quick Homemade Bubur Kacang Ijo"
title: "Simple Way to Make Super Quick Homemade Bubur Kacang Ijo"
slug: 80-simple-way-to-make-super-quick-homemade-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/173679d9b17a9c10/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's Louise, welcome to my recipe page. Today, I will show you a way to make a distinctive dish, bubur kacang ijo. One of my favorites food recipes. This time, I'm gonna make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo is one of the most well liked of recent trending meals in the world. It is simple, it is fast, it tastes delicious. It's appreciated by millions daily. Bubur Kacang Ijo is something which I've loved my whole life. They are nice and they look wonderful.
</p>

<p>
To get started with this particular recipe, we must prepare a few components. You can have bubur kacang ijo using 13 ingredients and 10 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Prepare 500 gr of Kacang Ijo. </li>
	
		<li>{Take 2000 ml of Air. </li>
	
		<li>{Take 1/2 sdt of garam. </li>
	
		<li>{Prepare 1 lembar of daun pandan. </li>
	
		<li>{Make ready 2 potong of jahe iris tipis. </li>
	
		<li>{Make ready 150 gr of gula jawa potong lembut. </li>
	
		<li>{Prepare 100 gr of gula pasir (kalau kurang manis bisa ditambahkan). </li>
	
		<li>{Get 3 sdm of tepung Maizena + air 50ml (bisa pake tepung Tapioka). </li>
	
		<li>{Make ready  of Bahan Kuah:. </li>
	
		<li>{Prepare 1 of . Susu full cream 1/2 kotak. </li>
	
		<li>{Get 2 of . Air 500ml (kalau kekentalan bisa ditambahin). </li>
	
		<li>{Get 3 of . Santan kental 100ml (aku pake santan Sama yg kental). </li>
	
		<li>{Make ready 1 sdm of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Cuci bersih Kacang Hijau, biarkan 15menit sambil siapin bahan lainnya.
			
			
		</li>
	
		<li>
			Masukan Kacang Hijau yang sudah dicuci, gunakan api sedang masak sampai mendidih. Setelah mendidih rebus selama 5menit. Tutup panci biar maksimal merebus nya..
			
			
		</li>
	
		<li>
			Setelah 5 menit matikan api dan biarkan dalam keadaan menutup..
			
			
		</li>
	
		<li>
			Kacang hijaunya belum terbuka lanjutkan/diamkan selama 30menit dengan keadaan masih tertutup..
			
			
		</li>
	
		<li>
			Selama 30 menit Kacang hijau sudah merekah tapi belum empuk maksimal..
			
			
		</li>
	
		<li>
			Masukan daun pandan yg sudah diikat simpul Dan jahe yg sudah dipotong. Kemudian nyalakan api sedang masak hingga 7menit. tutup Panci..
			
			
		</li>
	
		<li>
			Setelah 7 menit hasilnya matang Dan empuk. Merekah semua..
			
			
		</li>
	
		<li>
			Tambahkan gula aduk hingga merata sampai gulanya larut. Kemudian masukan tepung Maizena/Tapioka yg sudah dicairkan. Aduk sampai benar-benar mengental. Gunakan api kecil jika dirasa cukup matikan.
			
			
		</li>
	
		<li>
			Untuk Kuah nya. Masukan semua bahan aduk rata sampai mendidih. Angkat..
			
			
		</li>
	
		<li>
			Bubur siap dihidangkan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this special food bubur kacang ijo recipe. Thanks so much for your time. I am sure that you can make this at home. There's gonna be interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
