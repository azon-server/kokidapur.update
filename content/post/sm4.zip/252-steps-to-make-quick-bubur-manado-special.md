---
description: "Steps to Make Quick Bubur Manado Special"
title: "Steps to Make Quick Bubur Manado Special"
slug: 252-steps-to-make-quick-bubur-manado-special

<p>
	<strong>Bubur Manado Special</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/21f534460ff6285e/680x482cq70/bubur-manado-special-foto-resep-utama.jpg" alt="Bubur Manado Special" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you are having an incredible day today. Today, I'm gonna show you how to prepare a distinctive dish, bubur manado special. It is one of my favorites. For mine, I am going to make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Manado Special is one of the most favored of recent trending foods on earth. It is appreciated by millions daily. It is simple, it's quick, it tastes yummy. They are fine and they look fantastic. Bubur Manado Special is something that I have loved my entire life.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we must first prepare a few ingredients. You can cook bubur manado special using 19 ingredients and 8 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Manado Special:</h3>

<ol>
	
		<li>{Prepare  of Ceker bisa bagian lain. </li>
	
		<li>{Prepare 1/2 gelas of Beras. </li>
	
		<li>{Prepare  of Batata red:ubi jalar. </li>
	
		<li>{Take  of Sambiki red labu kuning. </li>
	
		<li>{Make ready  of Milu red jagung. </li>
	
		<li>{Make ready  of Bayam, kangkung atau daun gedi. </li>
	
		<li>{Make ready  of Sereh. </li>
	
		<li>{Make ready  of Daun salam. </li>
	
		<li>{Make ready  of Bawang bombai. </li>
	
		<li>{Get  of Daun pandan. </li>
	
		<li>{Make ready  of Kemangi. </li>
	
		<li>{Take  of Garam atau sejeninya. </li>
	
		<li>{Make ready  of Bawang putih. </li>
	
		<li>{Take  of Pelengkap. </li>
	
		<li>{Take  of Tahu goreng gurih,ikan asin. </li>
	
		<li>{Prepare  of Sambal bawang atau sambal bakasang. </li>
	
		<li>{Take  of Bawang goreng. </li>
	
		<li>{Make ready  of Bakwan nike /bakwan rebon. </li>
	
		<li>{Get  of Mana yg ada y. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Manado Special:</h3>

<ol>
	
		<li>
			Rebus ceker atau ayam dengan 2 liter air. Masukin bawang Bombay, bawang putih geprek dan daun salam sampai kluar kaldu. Kluarkan daun salam, bawang putih, bawang Bombay dan ceker jd cuma ambil airnya.
			
			
		</li>
	
		<li>
			Masukan beras, labu, ubi dan jagung ke dalam air kaldu.
			
			
		</li>
	
		<li>
			Tambahkan sereh yg uda digeprek, daun pandan bbrp tetes zaitun.
			
			
		</li>
	
		<li>
			Masak sampai empuk, jika uda bnr2 matang masukan sayur, koreksi rasa..
			
			
		</li>
	
		<li>
			1-2 menit sebelum diangkat masukan daun kemangi cukup sampai layu aja.
			
			
		</li>
	
		<li>
			Apabila airnya kurang ditambah y. Sesuai kebutuhan..
			
			
		</li>
	
		<li>
			Buat kalian yg ngg makan nasi bisa ganti oatmeal dimasukan bersamaan dengan bayam.
			
			
		</li>
	
		<li>
			Sajikan dengan tambahan pelengkap.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this special food bubur manado special recipe. Thank you very much for reading. I'm sure you will make this at home. There is gonna be more interesting food at home recipes coming up. Remember to bookmark this page on your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
