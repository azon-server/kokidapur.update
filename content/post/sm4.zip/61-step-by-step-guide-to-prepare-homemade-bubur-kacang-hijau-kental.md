---
description: "Step-by-Step Guide to Prepare Homemade Bubur kacang hijau kental"
title: "Step-by-Step Guide to Prepare Homemade Bubur kacang hijau kental"
slug: 61-step-by-step-guide-to-prepare-homemade-bubur-kacang-hijau-kental

<p>
	<strong>Bubur kacang hijau kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/70a1265515234a8f/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur kacang hijau kental" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you're having an incredible day today. Today, I'm gonna show you how to make a distinctive dish, bubur kacang hijau kental. It is one of my favorites food recipes. For mine, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang hijau kental is one of the most well liked of recent trending foods on earth. It's enjoyed by millions every day. It is simple, it is quick, it tastes yummy. Bubur kacang hijau kental is something which I have loved my entire life. They're fine and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to first prepare a few components. You can cook bubur kacang hijau kental using 8 ingredients and 8 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur kacang hijau kental:</h3>

<ol>
	
		<li>{Take  of Kacang hijau. </li>
	
		<li>{Get  of Santan. </li>
	
		<li>{Get  of Air. </li>
	
		<li>{Make ready  of Gula merah. </li>
	
		<li>{Prepare  of Garam. </li>
	
		<li>{Make ready  of Pandan. </li>
	
		<li>{Take  of Jahe. </li>
	
		<li>{Prepare  of Susu (opsional). </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang hijau kental:</h3>

<ol>
	
		<li>
			Rendam kacang hijau dengan air, kurang lebih 1 jam.
			
			
		</li>
	
		<li>
			Rebus kacang hijau hingga empuk.
			
			
		</li>
	
		<li>
			Masukkan santan dan susu.
			
			
		</li>
	
		<li>
			Tambahkan gula merah dan sedikit garam. Aduk rata dan tunggu hingga santan mendidih.
			
			
		</li>
	
		<li>
			Masukkan pandan dan jahe.
			
			
		</li>
	
		<li>
			Masukkan tepung maizena yang sudah dilarutkan menggunakan air.
			
			
		</li>
	
		<li>
			Aduk hingga tercampur rata.
			
			
		</li>
	
		<li>
			Setelah mendidih, bubur siap dihidangkan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this special food bubur kacang hijau kental recipe. Thank you very much for your time. I'm confident you can make this at home. There's gonna be interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
