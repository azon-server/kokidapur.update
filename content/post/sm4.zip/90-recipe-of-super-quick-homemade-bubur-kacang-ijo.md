---
description: "Recipe of Super Quick Homemade Bubur kacang ijo"
title: "Recipe of Super Quick Homemade Bubur kacang ijo"
slug: 90-recipe-of-super-quick-homemade-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/214228e92874327e/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an incredible day today. Today, I will show you a way to make a special dish, bubur kacang ijo. One of my favorites food recipes. For mine, I am going to make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang ijo is one of the most popular of current trending foods on earth. It is easy, it is fast, it tastes delicious. It's enjoyed by millions every day. Bubur kacang ijo is something that I have loved my whole life. They are nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we must prepare a few ingredients. You can cook bubur kacang ijo using 9 ingredients and 3 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Get 1/4 kg of kacang ijo. </li>
	
		<li>{Prepare 1/2 kaleng susu of kental manis. </li>
	
		<li>{Get 1 ons of gula pasir. </li>
	
		<li>{Take 1 ons of gula jawa. </li>
	
		<li>{Make ready 1 sdt of garam. </li>
	
		<li>{Prepare 2 ruas of jahe, geprek. </li>
	
		<li>{Take 1 of santan kara kecil. </li>
	
		<li>{Take 3 lembar of daun pandan. </li>
	
		<li>{Prepare 1 1/2 gayung of air. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau. Didihkan air secukupnya dan masukkan kacang hijau..
			
			
		</li>
	
		<li>
			Tambahkan jahe dan daun pandan. Rebus hingga empuk..
			
			
		</li>
	
		<li>
			Tambahkan air, susu, gula jawa, gula pasir, santan dan garam. Tes rasa. Masak sampai mendidih. Sajikan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur kacang ijo recipe. Thank you very much for reading. I am sure that you will make this at home. There's gonna be interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
