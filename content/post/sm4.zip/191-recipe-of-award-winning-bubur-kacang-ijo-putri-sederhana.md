---
description: "Recipe of Award-winning Bubur kacang ijo putri sederhana"
title: "Recipe of Award-winning Bubur kacang ijo putri sederhana"
slug: 191-recipe-of-award-winning-bubur-kacang-ijo-putri-sederhana

<p>
	<strong>Bubur kacang ijo putri sederhana</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/8840a1b46841cf1c/680x482cq70/bubur-kacang-ijo-putri-sederhana-foto-resep-utama.jpg" alt="Bubur kacang ijo putri sederhana" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Drew, welcome to my recipe page. Today, I'm gonna show you how to prepare a special dish, bubur kacang ijo putri sederhana. It is one of my favorites. For mine, I'm gonna make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo putri sederhana is one of the most favored of current trending meals in the world. It is simple, it is fast, it tastes delicious. It is appreciated by millions every day. Bubur kacang ijo putri sederhana is something which I've loved my entire life. They're nice and they look fantastic.
</p>

<p>
To begin with this recipe, we have to first prepare a few ingredients. You can have bubur kacang ijo putri sederhana using 6 ingredients and 4 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo putri sederhana:</h3>

<ol>
	
		<li>{Make ready 1/4 kg of Kajang ijo. </li>
	
		<li>{Make ready  of Santan kental. </li>
	
		<li>{Prepare secukupnya of Gula merah. </li>
	
		<li>{Take secukupnya of Gula pasir. </li>
	
		<li>{Get sejumput of Garam. </li>
	
		<li>{Prepare 1 ruas of Jahe digeprek. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo putri sederhana:</h3>

<ol>
	
		<li>
			Cuci kacang hijau hingga bersih lalu tambahkan air 1liter direbus hingga kacang ijo matang dan pecah,kurang lebih 30 menit.
			
			
		</li>
	
		<li>
			Masukan gula merah disaring dahulu biar gk ada ampasnya.
			
			
		</li>
	
		<li>
			Masukan santan, daun pandan.
			
			
		</li>
	
		<li>
			Tambahnkan sejumput garam dan jahe digeprek. Masak hingga meresap semua.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this exceptional food bubur kacang ijo putri sederhana recipe. Thanks so much for reading. I am confident that you can make this at home. There is gonna be more interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
