---
description: "Step-by-Step Guide to Make Favorite Bubur kacang ijo"
title: "Step-by-Step Guide to Make Favorite Bubur kacang ijo"
slug: 72-step-by-step-guide-to-make-favorite-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/ae58aa0cdd42fd41/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's John, welcome to my recipe page. Today, I will show you a way to prepare a special dish, bubur kacang ijo. It is one of my favorites. This time, I'm gonna make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo is one of the most well liked of recent trending meals on earth. It's appreciated by millions daily. It's simple, it is fast, it tastes yummy. They are fine and they look wonderful. Bubur kacang ijo is something which I've loved my whole life.
</p>

<p>
To begin with this particular recipe, we must prepare a few ingredients. You can cook bubur kacang ijo using 8 ingredients and 3 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Prepare 125 ml of kacang ijo (saya pakai gelas ukur). </li>
	
		<li>{Prepare 700 ml of air (kalau mau tdk tll kental bs tamb air). </li>
	
		<li>{Make ready 1 of daun pandan. </li>
	
		<li>{Get 1 ruas of jahe. </li>
	
		<li>{Take 200 ml of santan (saya pakai 8-10 sdm santan bubuk ditamb air). </li>
	
		<li>{Get 4-6 sdm of gula aren bubuk. </li>
	
		<li>{Get 3-5 sdm of gula pasir. </li>
	
		<li>{Take 1/4 sdt of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Didihkan air. Masukkan kacang ijo, daun pandan dan jahe. Rebus selama 25-30 menit dan ditutup pancinya. Api sedang. Cek apakah kacang sudah lunak, bila sudah lanjut ke tahap 2..
			
			
		</li>
	
		<li>
			Masukkan gula aren, gula pasir dan garam. Aduk rata..
			
			
		</li>
	
		<li>
			Tambahkan santan dan aduk2 sampai mendidih. Tes rasa. Sajikan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur kacang ijo recipe. Thanks so much for your time. I am sure you will make this at home. There's gonna be interesting food in home recipes coming up. Don't forget to save this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
