---
description: "Steps to Make Award-winning Bubur manado"
title: "Steps to Make Award-winning Bubur manado"
slug: 430-steps-to-make-award-winning-bubur-manado

<p>
	<strong>Bubur manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/f63cb830a6516c58/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur manado" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is Brad, welcome to my recipe page. Today, we're going to make a distinctive dish, bubur manado. One of my favorites food recipes. For mine, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur manado is one of the most favored of current trending foods on earth. It's enjoyed by millions every day. It is easy, it is quick, it tastes yummy. Bubur manado is something that I have loved my entire life. They are nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to first prepare a few components. You can cook bubur manado using 9 ingredients and 4 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur manado:</h3>

<ol>
	
		<li>{Get  of Beras 1 gelas takaran. </li>
	
		<li>{Get 1 ikat of kangkung. </li>
	
		<li>{Get 1000 ml of air. </li>
	
		<li>{Get 2 lembar of daun salam. </li>
	
		<li>{Get 2 batang of serai geprek. </li>
	
		<li>{Make ready 1 sdm of garam. </li>
	
		<li>{Prepare 1 sdm of kaldu jamur/penyedap (saya pakai totole). </li>
	
		<li>{Make ready 1 buah of jagung disisir. </li>
	
		<li>{Take 250 gr of labu kabocha merah/ labu kuning. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur manado:</h3>

<ol>
	
		<li>
			Rebus beras dengan air masukan jagung,labu,sereh,daun salam,garam dan kaldu jamur dengan api sedang.
			
			
		</li>
	
		<li>
			Aduk2 dan diamkan sampai bubur mengental sambil sesekali diaduk agar tidak gosong bawahnya kalau sudah mau matang baru masukan kangkung terus diaduk sampai kangkung matang lalu matikan..
			
			
		</li>
	
		<li>
			Kalau sudah jd bubur masukan ke dalam magic jar dengan posisi warm ya bukan memasak agar selalu hangat kalau mau dimakan.
			
			
		</li>
	
		<li>
			Tinggal tambah topping dengan teri kacang balado,ikan cakalang suir atau ikan asin goreng dengan sambal goreng atau rebus.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this exceptional food bubur manado recipe. Thank you very much for reading. I'm confident you will make this at home. There is gonna be interesting food in home recipes coming up. Remember to bookmark this page on your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
