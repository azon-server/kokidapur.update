---
description: "Recipe of Speedy Bubur Manado rumahan"
title: "Recipe of Speedy Bubur Manado rumahan"
slug: 390-recipe-of-speedy-bubur-manado-rumahan

<p>
	<strong>Bubur Manado rumahan</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/c0b3114fc3efaf12/680x482cq70/bubur-manado-rumahan-foto-resep-utama.jpg" alt="Bubur Manado rumahan" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's John, welcome to my recipe page. Today, I'm gonna show you how to make a special dish, bubur manado rumahan. It is one of my favorites. This time, I will make it a little bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Manado rumahan is one of the most well liked of current trending foods in the world. It's easy, it is fast, it tastes delicious. It is enjoyed by millions daily. They're nice and they look wonderful. Bubur Manado rumahan is something that I've loved my whole life.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we must prepare a few components. You can cook bubur manado rumahan using 10 ingredients and 5 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Manado rumahan:</h3>

<ol>
	
		<li>{Make ready 2 ikat of kangkung. </li>
	
		<li>{Make ready 1/2 kg of Beras. </li>
	
		<li>{Take secukupnya of Air. </li>
	
		<li>{Take 1 ikat of kemangi. </li>
	
		<li>{Get 2 buah of jagung, sisir. </li>
	
		<li>{Make ready  of Daun salam. </li>
	
		<li>{Prepare  of Sereh. </li>
	
		<li>{Prepare  of Garam. </li>
	
		<li>{Take  of Merica. </li>
	
		<li>{Get  of Tambahan : ikan asin, sambal terasi. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Manado rumahan:</h3>

<ol>
	
		<li>
			Masak beras tambahkan daun salam, sereh, garam dan merica, masak hingga menjadi bubur.
			
			
		</li>
	
		<li>
			Masukkan jagung dan kangkung.
			
			
		</li>
	
		<li>
			Masak hingga matang dan mengental.
			
			
		</li>
	
		<li>
			Tambahkan daun kemangi.
			
			
		</li>
	
		<li>
			Siap disajikan dengan tambahan sambal terasi dan ikan asin.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this exceptional food bubur manado rumahan recipe. Thank you very much for your time. I am confident you can make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
