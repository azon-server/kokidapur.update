---
description: "Simple Way to Make Quick Bubur kacang ijo simple"
title: "Simple Way to Make Quick Bubur kacang ijo simple"
slug: 99-simple-way-to-make-quick-bubur-kacang-ijo-simple

<p>
	<strong>Bubur kacang ijo simple</strong>. 
	Wb genks Yups kali ini saya mau buat bubur kacang ijo campur mata ikan, kali ini buatnya gk pake ribet ya genks. Bubur kacang hijau, abbreviated burjo, is a Southeast Asian sweet porridge (bubur) made from mung beans (kacang hijau), coconut milk, and palm sugar or cane sugar. Cara bikin bubur kacang hijau / ijo memerlukan trik dan tips tersendiri, sehingga hasilnya bisa lebih bagus dan juga enak serta lembut.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/5d14b1be781047b0/680x482cq70/bubur-kacang-ijo-simple-foto-resep-utama.jpg" alt="Bubur kacang ijo simple" style="width: 100%;">
	
	
		Kacang hijau direbus sampai empuk dengan daun pandan.
	
		KOMPAS.com - Olahan kacang hijau dapat menjadi sarapan praktis, cukup dijadikan bubur tanpa santan dengan tambahan gula merah.
	
		Bubur kacang ijo ini sudah tersebar di hampir seluruh daerah yang ada di nusantara sehingga Anda pun dapat dengan mudah untuk menemukannya.
	
</p>
<p>
	Hello everybody, it is me, Dave, welcome to my recipe page. Today, we're going to prepare a distinctive dish, bubur kacang ijo simple. One of my favorites food recipes. This time, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang ijo simple is one of the most favored of recent trending foods on earth. It is simple, it is fast, it tastes yummy. It's appreciated by millions every day. They're fine and they look wonderful. Bubur kacang ijo simple is something that I have loved my entire life.
</p>
<p>
	Wb genks Yups kali ini saya mau buat bubur kacang ijo campur mata ikan, kali ini buatnya gk pake ribet ya genks. Bubur kacang hijau, abbreviated burjo, is a Southeast Asian sweet porridge (bubur) made from mung beans (kacang hijau), coconut milk, and palm sugar or cane sugar. Cara bikin bubur kacang hijau / ijo memerlukan trik dan tips tersendiri, sehingga hasilnya bisa lebih bagus dan juga enak serta lembut.
</p>

<p>
To get started with this recipe, we have to prepare a few ingredients. You can have bubur kacang ijo simple using 7 ingredients and 9 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo simple:</h3>

<ol>
	
		<li>{Make ready 250 grm of kacang hijau. </li>
	
		<li>{Prepare 2 batang of jahe. </li>
	
		<li>{Take 2 bungkus of vanilli. </li>
	
		<li>{Get 1/4 of gula merah. </li>
	
		<li>{Prepare 5 sdt of gula pasir. </li>
	
		<li>{Get 1 sdt of garam. </li>
	
		<li>{Prepare 500 ml of air. </li>
	
</ol>
<p>
	
		Setiap daerah biasanya memiliki ciri khas sendiri, namun salah satu jenis yang paling terkenal adalah bubur kacang ijo dari Madura.
	
		Simple, namun rasanya yang legit dan sedap selalu membuat kami datang kesana setiap minggu, tepatnya setiap hari Rabu.
	
		Komposisinya memang hanya kacang hijau dan sagu mutiara, namun karena menggunakan gula aren dan santan kental yang gurih membuat rasa bubur menjadi istimewa.
	
		Bubur kacang ijo inggih punika salah satunggaling olah-olahan Indonesia ingkang dipundamel saking kacang ijo lan dipunsukani toya, ron pandhan saha gula jawa ingkang salajengipun dipungodhog ngantos umub lan kacangipun empuk.
	
</p>

<h3>Instructions to make Bubur kacang ijo simple:</h3>

<ol>
	
		<li>
			Rendam kacang hijau sekitar 4/5 jam agar pas di masak tidak terlalu lama dan cepet mpuk.
			
			
		</li>
	
		<li>
			Siapkan air di panci sekitar 500ml,tunggu sampai mendidih.
			
			
		</li>
	
		<li>
			Setelah mendidih masukan kacang hijau yg sudah dibrendam tadi.
			
			
		</li>
	
		<li>
			Rajang² gula merah,masukan ke rebusan kacang hijau,gula pasir dan vanilli,jangan lupa lupa jahe di geprek ya.
			
			
		</li>
	
		<li>
			Tunggu sekitar 35mnit jika airnya tinggal surut tambahkan lg sdikit air sampai si kacang hijau benar² mekar ancur.
			
			
		</li>
	
		<li>
			Tambahkan garam aduk² lalu matikan kompor.
			
			
		</li>
	
		<li>
			Tuang santan ke panci tambahkan air sedikit lalu aduk² sampai mendidih,matikan kompor lalu angkat.
			
			
		</li>
	
		<li>
			Ambil bubur kacang hijau ke mangkok lalu tuang santan sesuai selera bisa jg di tambah susu kental manis jika suka manis.
			
			
		</li>
	
		<li>
			Bubur kacang hijau siap di santap.
			
			
		</li>
	
</ol>

<p>
	
		Bubur kacang hijau sometimes is pronounced as bubur kacang ijo.
	
		Well, I didn&#39;t have time to make the complex version.
	
		So I made a version that was enriched with palm sugar (gula aren), flavoured with pandan leaves and touched of coconut milk at the end.
	
		Fimela.com, Jakarta Bubur kacang ijo yang bertekstur lembut adalah yang paling sempurna.
	
		Kacang Hijau memiliki kandungan gizi yang lengkap seperti kalsium, zat besi, kalium, fosfor, folat, vitamin B, vitamin A, vitamin C, magnesium, karbohidrat dan beragam nutrisi lainnya.
	
</p>

<p>
	So that is going to wrap it up for this special food bubur kacang ijo simple recipe. Thank you very much for your time. I am sure that you will make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to save this page in your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
