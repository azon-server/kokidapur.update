---
description: "Easiest Way to Make Super Quick Homemade Bubur Manado"
title: "Easiest Way to Make Super Quick Homemade Bubur Manado"
slug: 460-easiest-way-to-make-super-quick-homemade-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/eb8353751e5e87eb/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's John, welcome to our recipe page. Today, I'm gonna show you how to make a distinctive dish, bubur manado. One of my favorites food recipes. For mine, I am going to make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Manado is one of the most favored of current trending meals in the world. It is easy, it's quick, it tastes yummy. It's enjoyed by millions daily. Bubur Manado is something which I have loved my entire life. They're fine and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we have to first prepare a few components. You can cook bubur manado using 20 ingredients and 6 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Prepare 100 gr of beras. </li>
	
		<li>{Make ready 200 gr of buah labu. </li>
	
		<li>{Take 1 liter of air. </li>
	
		<li>{Get 100 gr of ubi jalar/ketela (me: kentang). </li>
	
		<li>{Take 1 buah of jagung. </li>
	
		<li>{Make ready 1 ikat of bayam. </li>
	
		<li>{Get 1 ikat of kangkung. </li>
	
		<li>{Take 1 ikat of kemangi. </li>
	
		<li>{Prepare 1 batang of serai. </li>
	
		<li>{Take 1 lembar of daun salam. </li>
	
		<li>{Take 3 siung of bawang putih. </li>
	
		<li>{Take 1 batang of daun bawang. </li>
	
		<li>{Get secukupnya of Garam. </li>
	
		<li>{Prepare  of Lada bubuk secukupnya (optional). </li>
	
		<li>{Make ready  of Kaldu ayam bubuk secukupnya (optional). </li>
	
		<li>{Prepare  of Pelengkap:. </li>
	
		<li>{Take  of Bawang goreng. </li>
	
		<li>{Prepare  of Ikan asin/ikan teri goreng. </li>
	
		<li>{Take  of Sambal. </li>
	
		<li>{Prepare  of Telur rebus. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado:</h3>

<ol>
	
		<li>
			Siapkan bahan.
			
			
		</li>
	
		<li>
			Potong-potong kecil labu dan ubi/kentang lalu cuci. Iris kasar jagung. Potong2 bayam dan kangkung.
			
			
		</li>
	
		<li>
			Iris tipis daun bawang dan bawang putih lalu tumis hingga kering, sisihkan.
			
			
		</li>
	
		<li>
			Rebus air dengan labu, ubi/kentang, dan beras yg telah dicuci bersih. Masukkan serai dan daun salam. Masak hingga labu sdh mulai melunak dan mengental. Masukkan jagung pipil dan aduk-aduk.
			
			
		</li>
	
		<li>
			Setelah bubur sudah mulai matang, masukkan gorengan bawang putih dan daun bawang lalu aduk rata. Beri garam dan bumbu lain lalu koreksi rasa. Jika sdh pas, masukkan sayuran aduk sebentar. Masukkan daun kemangi, aduk rata lalu matikan api kompor.
			
			
		</li>
	
		<li>
			Bubur manado siap disajikan dengan ikan asin atau teri goreng, telur rebus plus sambal roa. Mantappp.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this exceptional food bubur manado recipe. Thank you very much for reading. I am confident you will make this at home. There is gonna be more interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
