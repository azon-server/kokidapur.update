---
description: "Step-by-Step Guide to Prepare Perfect Bubur kacang ijo (no santan)"
title: "Step-by-Step Guide to Prepare Perfect Bubur kacang ijo (no santan)"
slug: 203-step-by-step-guide-to-prepare-perfect-bubur-kacang-ijo-no-santan

<p>
	<strong>Bubur kacang ijo (no santan)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/6f55fc96f03980ea/680x482cq70/bubur-kacang-ijo-no-santan-foto-resep-utama.jpg" alt="Bubur kacang ijo (no santan)" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you're having an incredible day today. Today, we're going to make a special dish, bubur kacang ijo (no santan). One of my favorites. This time, I am going to make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo (no santan) is one of the most favored of current trending meals on earth. It's simple, it's fast, it tastes yummy. It's appreciated by millions every day. Bubur kacang ijo (no santan) is something that I have loved my entire life. They're fine and they look wonderful.
</p>

<p>
To begin with this recipe, we must first prepare a few ingredients. You can cook bubur kacang ijo (no santan) using 5 ingredients and 4 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo (no santan):</h3>

<ol>
	
		<li>{Prepare 1/4 kg of kacang ijo. </li>
	
		<li>{Make ready 2 buah of gula merah. </li>
	
		<li>{Make ready 1/2 ruas of jahe. </li>
	
		<li>{Prepare secukupnya of Air. </li>
	
		<li>{Take  of Susu kental manis secukupnya (hanya ditambahkan saat dikonsumsi). </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo (no santan):</h3>

<ol>
	
		<li>
			Rendam kacang ijo kurang lebih 1 jam dn geprek jahe nya.
			
			
		</li>
	
		<li>
			Rebus kacang ijo dengan air secukupnya.
			
			
		</li>
	
		<li>
			Setelah setengah matang, tambahkan gula merah dan jahe.
			
			
		</li>
	
		<li>
			Masak sampai matang 😊.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this special food bubur kacang ijo (no santan) recipe. Thank you very much for reading. I am sure that you will make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
