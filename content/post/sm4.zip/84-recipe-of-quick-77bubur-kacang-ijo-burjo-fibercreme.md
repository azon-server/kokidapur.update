---
description: "Recipe of Quick 77.Bubur Kacang Ijo (Burjo) Fibercreme 🍵😍🤤"
title: "Recipe of Quick 77.Bubur Kacang Ijo (Burjo) Fibercreme 🍵😍🤤"
slug: 84-recipe-of-quick-77bubur-kacang-ijo-burjo-fibercreme

<p>
	<strong>77.Bubur Kacang Ijo (Burjo) Fibercreme 🍵😍🤤</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/aa9e9e5a9fb31f0c/680x482cq70/77bubur-kacang-ijo-burjo-fibercreme-🍵😍🤤-foto-resep-utama.jpg" alt="77.Bubur Kacang Ijo (Burjo) Fibercreme 🍵😍🤤" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's me, Dave, welcome to our recipe site. Today, I'm gonna show you how to make a distinctive dish, 77.bubur kacang ijo (burjo) fibercreme 🍵😍🤤. It is one of my favorites food recipes. For mine, I will make it a bit unique. This will be really delicious.
</p>
	
<p>
	77.Bubur Kacang Ijo (Burjo) Fibercreme 🍵😍🤤 is one of the most popular of current trending meals on earth. It's enjoyed by millions every day. It is simple, it is fast, it tastes yummy. They are fine and they look wonderful. 77.Bubur Kacang Ijo (Burjo) Fibercreme 🍵😍🤤 is something that I've loved my entire life.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to prepare a few components. You can cook 77.bubur kacang ijo (burjo) fibercreme 🍵😍🤤 using 11 ingredients and 4 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make 77.Bubur Kacang Ijo (Burjo) Fibercreme 🍵😍🤤:</h3>

<ol>
	
		<li>{Take 250 gram of kacang hijau. </li>
	
		<li>{Take 100 gram of gula pasir. </li>
	
		<li>{Take Sejumput of garam. </li>
	
		<li>{Take 1 lembar of daun pandan. </li>
	
		<li>{Take 500-750 ml of air. </li>
	
		<li>{Prepare 2 sdm of tepung beras larutkan dg air secukupnya. </li>
	
		<li>{Get  of Santan. </li>
	
		<li>{Make ready 3 sdm of fibercreme dalam 250ml air. </li>
	
		<li>{Take 2 sdm of tepung beras larutkan air. </li>
	
		<li>{Make ready Sejumput of garam. </li>
	
		<li>{Make ready 1 lembar of daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make 77.Bubur Kacang Ijo (Burjo) Fibercreme 🍵😍🤤:</h3>

<ol>
	
		<li>
			Rendam kacang hijau semalaman. Keesokan paginya tiriskan dan cuci bersih lalu rebus 10 menit dg api besar..
			
			
		</li>
	
		<li>
			Setelah direbus 10 menit dg api besar tutup rapat panci jgn dibuka2 selama 30 menit.
			
			
		</li>
	
		<li>
			Setelah 30 menit, masukkan daun pandan, gula merah, gula pasir, garam dan rebus kembali sambil aduk2 sampai kuah menyusut. Masukkan larutan tepung beras untuk mengentalkan. Jika dirasa kekentalan sdh sesuai selera, larutan tepung beras tdk perlu dimasukkan smp habis (*sy sukanya yg kacang ijonya lembek kental pekat kuahnya). Kurleb 10 menitan yg rebus kembali. Setelah 10 mnt tutup kembali kacang hijau, sisihkan, kita membuat santannya..
			
			
		</li>
	
		<li>
			Larutan fibercreme dimasak dgn api kecil, masukkan daun pandan, sejumput garam, kentalkan dg tepung beras. Kekentalan sesuai selera. Lalu tata dalam mangkok dan siap disajikan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this exceptional food 77.bubur kacang ijo (burjo) fibercreme 🍵😍🤤 recipe. Thanks so much for your time. I am confident that you can make this at home. There is gonna be interesting food at home recipes coming up. Remember to bookmark this page in your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
