---
description: "Easiest Way to Make Any-night-of-the-week Bubur kacang ijo kental creamy"
title: "Easiest Way to Make Any-night-of-the-week Bubur kacang ijo kental creamy"
slug: 17-easiest-way-to-make-any-night-of-the-week-bubur-kacang-ijo-kental-creamy

<p>
	<strong>Bubur kacang ijo kental creamy</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/f87ada64775d1980/680x482cq70/bubur-kacang-ijo-kental-creamy-foto-resep-utama.jpg" alt="Bubur kacang ijo kental creamy" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you're having an incredible day today. Today, we're going to prepare a special dish, bubur kacang ijo kental creamy. It is one of my favorites. This time, I am going to make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo kental creamy is one of the most favored of recent trending foods on earth. It's enjoyed by millions every day. It is easy, it's fast, it tastes yummy. Bubur kacang ijo kental creamy is something that I have loved my whole life. They are fine and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to first prepare a few ingredients. You can cook bubur kacang ijo kental creamy using 11 ingredients and 5 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo kental creamy:</h3>

<ol>
	
		<li>{Prepare 250 gr of kacang ijo. </li>
	
		<li>{Prepare  of Gula merah. </li>
	
		<li>{Take 1 bks of santan kara kecil. </li>
	
		<li>{Prepare  of Jahe (geprak). </li>
	
		<li>{Prepare  of Bawang putih (potong2). </li>
	
		<li>{Get  of Kayu manis. </li>
	
		<li>{Prepare 2 sdm of tepung maizena (larutkan dgn air). </li>
	
		<li>{Get 1 sdm of gula pasir. </li>
	
		<li>{Prepare 2 btr of telur. </li>
	
		<li>{Get  of Garam. </li>
	
		<li>{Get  of Air. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo kental creamy:</h3>

<ol>
	
		<li>
			Rebus kacang ijo, kalo sya d presto 15-20 menit.
			
			
		</li>
	
		<li>
			Rebus air dgn gula merah, setelah mendidih saring air rebusan td..
			
			
		</li>
	
		<li>
			Tambahkan baput,jahe,kayu manis,garam dan gula pasir,tunggu hingga mendidih lg sampai aroma ny tercium.
			
			
		</li>
	
		<li>
			Masukkan kacang ijo yg sdh d presto td dan santan, masak dgn api kecil hingga mendidih. Tambahkan telur, aduk2.
			
			
		</li>
	
		<li>
			Terakhir larutkan tepung maizena, aduk rata hingga bubur mjd kental..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this special food bubur kacang ijo kental creamy recipe. Thank you very much for reading. I'm sure you can make this at home. There's gonna be more interesting food at home recipes coming up. Remember to bookmark this page on your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
