---
description: "Step-by-Step Guide to Prepare Ultimate Bubur kacang hijau kental &amp;amp; Mudah dibuat (Tanpa direndam berjam-jam)"
title: "Step-by-Step Guide to Prepare Ultimate Bubur kacang hijau kental &amp;amp; Mudah dibuat (Tanpa direndam berjam-jam)"
slug: 52-step-by-step-guide-to-prepare-ultimate-bubur-kacang-hijau-kental-and-amp-mudah-dibuat-tanpa-direndam-berjam-jam

<p>
	<strong>Bubur kacang hijau kental &amp; Mudah dibuat (Tanpa direndam berjam-jam)</strong>. 
	Resep Rahasia Bubur Kacang Hijau Kental Dan Enak, bubur kacang hijau, resep bubur kacang hijau, bubur kacang hijau lezat, bubur kacang ijo seperti tukang. Ada bubur ayam, bubur sumsum, bubur mutiara, bubur kacang hijau dan banyak lainnya. Bubur kacang hijau, abbreviated burjo, is a Southeast Asian sweet porridge (bubur) made from mung beans (kacang hijau), coconut milk, and palm sugar or cane sugar.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/0ee023741593c0af/680x482cq70/bubur-kacang-hijau-kental-mudah-dibuat-tanpa-direndam-berjam-jam-foto-resep-utama.jpg" alt="Bubur kacang hijau kental &amp; Mudah dibuat (Tanpa direndam berjam-jam)" style="width: 100%;">
	
	
		Mau buka puasa begini enaknya kita buat Bubur Kacang.
	
		Bahan kacang hijau kental: Membuat bubur ketan hitam Bubur kacang hijau di hidangkan selagi masih hangat, kemudian siram dengan santan gurih.
	
		Tambahkan santan kental, masak hingga kacang hijau empuk.
	
</p>
<p>
	Hello everybody, I hope you are having an amazing day today. Today, I will show you a way to prepare a distinctive dish, bubur kacang hijau kental &amp; mudah dibuat (tanpa direndam berjam-jam). It is one of my favorites. This time, I will make it a bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur kacang hijau kental &amp; Mudah dibuat (Tanpa direndam berjam-jam) is one of the most popular of current trending foods in the world. It's easy, it's quick, it tastes yummy. It is enjoyed by millions every day. Bubur kacang hijau kental &amp; Mudah dibuat (Tanpa direndam berjam-jam) is something that I have loved my entire life. They're nice and they look fantastic.
</p>
<p>
	Resep Rahasia Bubur Kacang Hijau Kental Dan Enak, bubur kacang hijau, resep bubur kacang hijau, bubur kacang hijau lezat, bubur kacang ijo seperti tukang. Ada bubur ayam, bubur sumsum, bubur mutiara, bubur kacang hijau dan banyak lainnya. Bubur kacang hijau, abbreviated burjo, is a Southeast Asian sweet porridge (bubur) made from mung beans (kacang hijau), coconut milk, and palm sugar or cane sugar.
</p>

<p>
To begin with this recipe, we have to prepare a few components. You can cook bubur kacang hijau kental &amp; mudah dibuat (tanpa direndam berjam-jam) using 7 ingredients and 5 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang hijau kental &amp; Mudah dibuat (Tanpa direndam berjam-jam):</h3>

<ol>
	
		<li>{Get 250 gr of kacang hijau (seperempat). </li>
	
		<li>{Get 6 sdm of gula pasir (bisa disesuaikan sendiri tingkat kemanisannya). </li>
	
		<li>{Take 2 lembar of daun pandan. </li>
	
		<li>{Make ready 5 sdm of gula merah serut (bisa diskip, saya pakai biar warnanya agak coklat). </li>
	
		<li>{Prepare Secukupnya of garam (biar gurih, Bisa diskip). </li>
	
		<li>{Get 1.5 Liter of air(usahakan airnya banyak karena untuk membuat kacang ijo matang memakan waktu yg agak lama). </li>
	
		<li>{Prepare 6 sdm of (bisa lebih) tepung tapioka merk rose brand yg dicampur dengan 6 sendok air. untuk mengentalkan bubur. </li>
	
</ol>
<p>
	
		Angkat, sajikan dalam keadaan hanggar bersama potongan roti tawar.
	
		Resep bubur kacang hijau kental baik dengan santan maupun bubur kacang hijau tanpa santan.
	
		Bubur kacang hijau termasuk dalam resep jajanan tradisional yang sangat terkenal sejak puluhan tahun silam.
	
		Bahkan sering kita lihat pedagang bubur kacang hijau keliling dengan sepeda lewat di.
	
</p>

<h3>Steps to make Bubur kacang hijau kental &amp; Mudah dibuat (Tanpa direndam berjam-jam):</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau, setelah itu masukkan kacang hijau beserta air 1.5 liter tadi. Tambahkan daun pandan..
			
			
		</li>
	
		<li>
			Tutup panci, setelah selang 20 menit tambahkan gula pasir dan garam.
			
			
		</li>
	
		<li>
			Tunggu 20 menit lagi sampai kacang hijau matang sempurna, kacang hijaunya mengembang dan membelah.
			
			
		</li>
	
		<li>
			Jangan biarkan airnya habis. Sisakan sedikit agar nanti bisa jadi bubur dan bisa kental..
			
			
		</li>
	
		<li>
			Tes rasa jika sudah pas. Campurkan larutan tepung tapioka/kanji kedalam rebusan kacang hijau. Jika sudah meletup-letup matikan kompor dan bubur kacang ijo siap disajikan..
			
			
		</li>
	
</ol>

<p>
	
		Bubur kacang hijau termasuk sajian nikmat keluarga.
	
		Cara Membuat Bubur Kacang Hijau Ketan Hitam: Kacang hijau, rebus kacang hijau, air, dan daun pandan sampai matang dan mekar.
	
		Sisihkan. rebus beras ketan hitam bersama daun pandan.
	
		Bubur kacang hijau adalah salah satu menu sarapan atau larut malam yang populer di Indonesia.
	
		Masak bubur kacang hijau gak perlu lama-lama lho.
	
</p>

<p>
	So that's going to wrap this up with this exceptional food bubur kacang hijau kental &amp; mudah dibuat (tanpa direndam berjam-jam) recipe. Thanks so much for reading. I'm sure you can make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
