---
description: "Recipe of Any-night-of-the-week Bubur Kacang Hijau Kental"
title: "Recipe of Any-night-of-the-week Bubur Kacang Hijau Kental"
slug: 33-recipe-of-any-night-of-the-week-bubur-kacang-hijau-kental

<p>
	<strong>Bubur Kacang Hijau Kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/9cd45a6ed79443e4/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you're having an amazing day today. Today, we're going to make a distinctive dish, bubur kacang hijau kental. One of my favorites food recipes. For mine, I am going to make it a little bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Hijau Kental is one of the most popular of recent trending foods in the world. It is easy, it's fast, it tastes delicious. It is appreciated by millions daily. They are nice and they look wonderful. Bubur Kacang Hijau Kental is something that I've loved my whole life.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to first prepare a few components. You can cook bubur kacang hijau kental using 13 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>{Make ready  of Bahan Bubur. </li>
	
		<li>{Make ready 2 ons of Kacang Hijau. </li>
	
		<li>{Prepare 2 helai of daun pandan. </li>
	
		<li>{Get 1 ruas of jahe (sedang). </li>
	
		<li>{Get 8 sdm of gula pasir. </li>
	
		<li>{Get 1/2 sdt of garam 🧂. </li>
	
		<li>{Get 4 sdm of tepung tapioka. </li>
	
		<li>{Make ready 4 gelas of air 🥛 (3 u/rebus k.hijau &amp; 1 u/larutkan tepung tapioka). </li>
	
		<li>{Prepare  of Bahan Kuah. </li>
	
		<li>{Take 65 ml of santan (1 pack santan Sunkara). </li>
	
		<li>{Make ready 1/2 sdt of garam 🧂. </li>
	
		<li>{Take 1 helai of daun pandan. </li>
	
		<li>{Take 1/2 gelas of air 🥛. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>
			Siapkan bahan-bahan yg akan diolah. Sebelumnya cuci daun pandan dan kacang hijau, lalu rendam kacang hijau semalaman smp mengembang..
			
			
		</li>
	
		<li>
			Bahan kuah: campur santan dg air, tambahkan garam dan daun pandan. Kemudian panaskan dg api kecil smp mendidih, aduk trs jangan smp pecah santannya. Lalu dinginkan..
			
			
		</li>
	
		<li>
			Bahan Bubur : Panaskan air tambahkan daun pandan dan jahe (digeprek) smp mendidih. Kemudian masukkan Kacang hijau, garam dan gula. Lalu aduk dan biarkan mendidih selama 30 menit, hingga kacang hijau empuk..
			
			
		</li>
	
		<li>
			Sembari menunggu, larutkan tepung tapioka dg air. Kemudian masukkan kedalam bubur, aduk kembali. Biarkan mendidih smp meletup-letup. Angkat dan dinginkan. Jangan lupa matiin kompornya yaaa 😉..
			
			
		</li>
	
		<li>
			Sajikan burjo dg siraman kuah santan dan pemanis daun pandan. 🤗Taaaaraaaa....burjo siap dinikmati selagi hangat..🤤😋 Silahkan icip-icip yaaa.....
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this exceptional food bubur kacang hijau kental recipe. Thanks so much for your time. I'm sure you will make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to save this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
