---
description: "Steps to Make Ultimate Bubur kacang ijo kental"
title: "Steps to Make Ultimate Bubur kacang ijo kental"
slug: 5-steps-to-make-ultimate-bubur-kacang-ijo-kental

<p>
	<strong>Bubur kacang ijo kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/1b9ae57373853ad4/680x482cq70/bubur-kacang-ijo-kental-foto-resep-utama.jpg" alt="Bubur kacang ijo kental" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you are having an amazing day today. Today, we're going to make a distinctive dish, bubur kacang ijo kental. One of my favorites food recipes. For mine, I am going to make it a bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo kental is one of the most well liked of recent trending meals in the world. It's simple, it is fast, it tastes yummy. It's enjoyed by millions every day. They're fine and they look wonderful. Bubur kacang ijo kental is something that I have loved my whole life.
</p>

<p>
To begin with this particular recipe, we must prepare a few ingredients. You can have bubur kacang ijo kental using 6 ingredients and 6 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo kental:</h3>

<ol>
	
		<li>{Make ready 200 gram of kacang hijau. </li>
	
		<li>{Take 150 gram of gula merah. </li>
	
		<li>{Make ready 3 sdm of gula pasir. </li>
	
		<li>{Take 3 sdm of tapioka. </li>
	
		<li>{Prepare 250 ml of santan dari setengah butir kelapa. </li>
	
		<li>{Prepare  of Daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo kental:</h3>

<ol>
	
		<li>
			Rebus kacang hijau sampe air mendidih, kurleb 5 menit..
			
			
		</li>
	
		<li>
			Matikan api, tutup pancinya. Diamkan 1jam sampai kacang ijo empuk.
			
			
		</li>
	
		<li>
			Nyalakan lagi apinya, kembali masak kacang ijo. Kalo air nya terserap habis bisa ditambahkan air lagi secukupnya. Biarkan sampai mendidih, tambahkan gula merah, gula pasir, sedikit garam.. masak hingga gula larut.
			
			
		</li>
	
		<li>
			Masukkan tapioka yg sdh dilarutkan dengan sedikit air. Aduk hingga kental dan meletup letup..
			
			
		</li>
	
		<li>
			Sajikan dengan kuah santan..
			
			
		</li>
	
		<li>
			Kuah santan : rebus santan, dengan daun pandan. Aduk2 terus supaya ngga pecah. Masak hingga mendidih.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this exceptional food bubur kacang ijo kental recipe. Thanks so much for your time. I am confident you can make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
