---
description: "Steps to Prepare Perfect Bubur Manado dari Nasi Semalam"
title: "Steps to Prepare Perfect Bubur Manado dari Nasi Semalam"
slug: 471-steps-to-prepare-perfect-bubur-manado-dari-nasi-semalam

<p>
	<strong>Bubur Manado dari Nasi Semalam</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/6099ce4ce33ae719/680x482cq70/bubur-manado-dari-nasi-semalam-foto-resep-utama.jpg" alt="Bubur Manado dari Nasi Semalam" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you're having an amazing day today. Today, I will show you a way to prepare a special dish, bubur manado dari nasi semalam. It is one of my favorites food recipes. This time, I'm gonna make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Manado dari Nasi Semalam is one of the most favored of current trending meals in the world. It is simple, it is quick, it tastes yummy. It is enjoyed by millions daily. They're fine and they look wonderful. Bubur Manado dari Nasi Semalam is something which I've loved my entire life.
</p>

<p>
To begin with this recipe, we have to first prepare a few ingredients. You can cook bubur manado dari nasi semalam using 9 ingredients and 14 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Manado dari Nasi Semalam:</h3>

<ol>
	
		<li>{Take 1 piring penuh of nasi kemarin. </li>
	
		<li>{Prepare 250 gr of labu kuning/waluh. </li>
	
		<li>{Prepare 1 ikat of kemangi. </li>
	
		<li>{Make ready 1/2 ikat of kangkung. </li>
	
		<li>{Take 1 batang of serai. </li>
	
		<li>{Get 2 liter of air. </li>
	
		<li>{Get  of Garam. </li>
	
		<li>{Get  of Lada bubuk. </li>
	
		<li>{Get  of Kaldu jamur. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado dari Nasi Semalam:</h3>

<ol>
	
		<li>
			Siapkan bahan bahan yang diperlukan.
			
			
		</li>
	
		<li>
			Masak air di panci. Kira kira 1.5 liter.
			
			
		</li>
	
		<li>
			Sambil menunggu air mendidih bersihkan jagung. Kemudian dipipil atau disisir dengan pisau..
			
			
		</li>
	
		<li>
			Kupas labu kuning. Potong potong agak besar. Cuci bersih..
			
			
		</li>
	
		<li>
			Setelah air mendidih, masukkan labu. Kemudian menyusul nasi..
			
			
		</li>
	
		<li>
			Setelah semua nasi masuk, tambahkan serai yang sudah digeprek. Aduk rata. Masak dengan api sedang sambil sesekali diaduk..
			
			
		</li>
	
		<li>
			Jika labu sudah setengah matang, masukkan jagung manis. Aduk rata..
			
			
		</li>
	
		<li>
			Setelah mendidih 15 menit. Matikan api. Tutup panci. Biarkan 20-30 menit (untuk menghemat gas).
			
			
		</li>
	
		<li>
			Siapkan kemangi dan kangkung. Cuci bersih. Tiriskan.
			
			
		</li>
	
		<li>
			Setelah 20-30 menit, nyalakan lagi api. Tambahkan satu gelas air panas. Rebus lagi buburnya..
			
			
		</li>
	
		<li>
			Bumbui dengan garam, lada bubuk dan kaldu jamur (bisa juga kaldu bubuk). Koreksi rasa..
			
			
		</li>
	
		<li>
			Masak hingga bubur semakin empuk. Jika suka agak berkuah, bisa ditambah air panas..
			
			
		</li>
	
		<li>
			Kemudian tambahkan kemangi. Aduk rata..
			
			
		</li>
	
		<li>
			Terakhir masukkan kangkung. Aduk rata. Tunggu hingga kangkung empuk. Matikan api. Siapa dihidangkan bersama sambal dan ikan asin goreng..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this special food bubur manado dari nasi semalam recipe. Thanks so much for your time. I'm sure that you will make this at home. There's gonna be more interesting food in home recipes coming up. Don't forget to save this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
