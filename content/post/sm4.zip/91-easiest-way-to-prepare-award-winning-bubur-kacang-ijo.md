---
description: "Easiest Way to Prepare Award-winning Bubur kacang ijo"
title: "Easiest Way to Prepare Award-winning Bubur kacang ijo"
slug: 91-easiest-way-to-prepare-award-winning-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/23c6b6116c3289c3/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an amazing day today. Today, I will show you a way to prepare a distinctive dish, bubur kacang ijo. One of my favorites food recipes. For mine, I am going to make it a little bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo is one of the most well liked of recent trending meals on earth. It is simple, it's quick, it tastes yummy. It is appreciated by millions every day. Bubur kacang ijo is something which I have loved my entire life. They're fine and they look fantastic.
</p>

<p>
To begin with this particular recipe, we must first prepare a few components. You can have bubur kacang ijo using 14 ingredients and 4 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Make ready 200 gram of kacang ijo (rendam 3 jam). </li>
	
		<li>{Get 200 ml of santan instan. </li>
	
		<li>{Get 1 ruas of jahe,iris tebal. </li>
	
		<li>{Make ready 1 lembar of daun pandan. </li>
	
		<li>{Get 2 sendok makan of gula merah. </li>
	
		<li>{Get 5 sendok makan of gula pasir (sesuai selera ya). </li>
	
		<li>{Take 1/2 panci of Air. </li>
	
		<li>{Get  of Bahan2. </li>
	
		<li>{Get 200 gram of ketan item (rendam semalaman). </li>
	
		<li>{Take 1 L of air. </li>
	
		<li>{Prepare 6 sendok makan of gula pasir (sesuai selera). </li>
	
		<li>{Make ready 1/2 sdt of garam. </li>
	
		<li>{Prepare 1 lembar of daun pandan. </li>
	
		<li>{Take 200 ml of santai instan. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Rendam terlebih dahulu kacang ijo selama 3jam kemudian rebus kacang ijo dengan air,jahe,daun pandan dan gula merah sampai kacang ijo melunak.
			
			
		</li>
	
		<li>
			Tambahkan santan dan gula pasir,masak sampai mendidih sambil terus diaduk, koreksi rasa.
			
			
		</li>
	
		<li>
			Bahan 2 : rebus ketan item dengan air,daun pandan,gula dan garam,rebus sampai mengental seperti bubur.koreksi rasa.
			
			
		</li>
	
		<li>
			Dipanci terpisah masak santan kental dan beri garam,masak hingga mendidih dan mengental siram kuah santan ke atas bubur kacang, ketan item saat penyajian.....
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur kacang ijo recipe. Thanks so much for reading. I am confident you can make this at home. There is gonna be interesting food in home recipes coming up. Remember to bookmark this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
