---
description: "Easiest Way to Prepare Homemade BURJO (Bubur Kacang Ijo)"
title: "Easiest Way to Prepare Homemade BURJO (Bubur Kacang Ijo)"
slug: 96-easiest-way-to-prepare-homemade-burjo-bubur-kacang-ijo

<p>
	<strong>BURJO (Bubur Kacang Ijo)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/37fc3a7042a52d11/680x482cq70/burjo-bubur-kacang-ijo-foto-resep-utama.jpg" alt="BURJO (Bubur Kacang Ijo)" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's me again, Dan, welcome to my recipe page. Today, I will show you a way to make a special dish, burjo (bubur kacang ijo). One of my favorites food recipes. This time, I will make it a little bit unique. This will be really delicious.
</p>
	
<p>
	BURJO (Bubur Kacang Ijo) is one of the most popular of current trending meals in the world. It is easy, it is quick, it tastes yummy. It is appreciated by millions daily. They're fine and they look fantastic. BURJO (Bubur Kacang Ijo) is something which I've loved my entire life.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to first prepare a few components. You can cook burjo (bubur kacang ijo) using 8 ingredients and 6 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make BURJO (Bubur Kacang Ijo):</h3>

<ol>
	
		<li>{Get 250 gram of kacang ijo/hijau. </li>
	
		<li>{Prepare 250 ml of santan kental. </li>
	
		<li>{Make ready 1500 ml of air. </li>
	
		<li>{Take 150 gram of gula merah. </li>
	
		<li>{Take 75 gram of gula pasir (manis sesuai selera). </li>
	
		<li>{Take 1 lembar of daun pandan. </li>
	
		<li>{Make ready 2 ruas jari of jahe, memarkan. </li>
	
		<li>{Make ready 1/2 sdt of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make BURJO (Bubur Kacang Ijo):</h3>

<ol>
	
		<li>
			Rendah kacang hijau sekitar 1 jam, cuci bersih dan tiriskan sebentar..
			
			
		</li>
	
		<li>
			Masukkan kedalam panci kacang hijau, daun pandan, jahe dan air..
			
			
		</li>
	
		<li>
			Lalu rebus dengan api sedang hingga kacang lunak dan pecah/hancur..
			
			
		</li>
	
		<li>
			Masukkan gula merah, gula pasir dan garam, aduk-aduk hingga gula larut..
			
			
		</li>
	
		<li>
			Masukkan santan dan aduk perlahan hingga mendidih. Koreksi rasa dan matikan api..
			
			
		</li>
	
		<li>
			Bubur kacang ijo siap disajikan hangat maupun dingin..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this exceptional food burjo (bubur kacang ijo) recipe. Thank you very much for your time. I'm confident that you will make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to save this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
