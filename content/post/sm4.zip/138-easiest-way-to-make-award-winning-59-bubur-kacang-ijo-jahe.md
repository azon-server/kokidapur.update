---
description: "Easiest Way to Make Award-winning 59. Bubur kacang ijo jahe"
title: "Easiest Way to Make Award-winning 59. Bubur kacang ijo jahe"
slug: 138-easiest-way-to-make-award-winning-59-bubur-kacang-ijo-jahe

<p>
	<strong>59. Bubur kacang ijo jahe</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/ee168f057f19bb5e/680x482cq70/59-bubur-kacang-ijo-jahe-foto-resep-utama.jpg" alt="59. Bubur kacang ijo jahe" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Louise, welcome to our recipe site. Today, I will show you a way to prepare a distinctive dish, 59. bubur kacang ijo jahe. One of my favorites. For mine, I'm gonna make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	59. Bubur kacang ijo jahe is one of the most popular of current trending foods on earth. It's easy, it is fast, it tastes delicious. It is enjoyed by millions every day. 59. Bubur kacang ijo jahe is something that I have loved my entire life. They're nice and they look fantastic.
</p>

<p>
To begin with this particular recipe, we have to first prepare a few components. You can cook 59. bubur kacang ijo jahe using 7 ingredients and 6 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make 59. Bubur kacang ijo jahe:</h3>

<ol>
	
		<li>{Prepare 250 gr of kacang ijo. </li>
	
		<li>{Make ready 150 gr of gula merah. </li>
	
		<li>{Make ready 100 gr of gula pasir. </li>
	
		<li>{Take 1 ltr of santan kental dari 1/2 btr kelapa tua. </li>
	
		<li>{Prepare 1 sdt of garam. </li>
	
		<li>{Get 2 ruas of jahe diparut. </li>
	
		<li>{Make ready 1 bks of vanili bubuk. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make 59. Bubur kacang ijo jahe:</h3>

<ol>
	
		<li>
			Kacang ijo dicuci brsih direndam +-2 jam agar saat direbus cpt empuk.
			
			
		</li>
	
		<li>
			Rebus air +- 2 gelas biarkan mendidihlalu masukan kacang ijo yg sdh direndam.
			
			
		</li>
	
		<li>
			Rebus gula merah dan parutan jahe menggunakan air 1 gelas di panci terpisah.
			
			
		</li>
	
		<li>
			Setelah kacang ijo empuk lalu masukan air gula jahe tsb dg disaring terlebih dahulu...kenapa ada jahe krn supaya ada aroma2 hangat jahe yg bisa menghangatkan dicuaca ekstrim spt ini.
			
			
		</li>
	
		<li>
			Lalu tmbhkn gula pasir,garam,dan santan aduk rata biarkn mendidih lagi.
			
			
		</li>
	
		<li>
			Angkat lalu sajikan hangat2 kalo ak suka disajikan dg teman teh hangat tawar krn sdh ada manis dari bubur kacang ijo tsb....
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this special food 59. bubur kacang ijo jahe recipe. Thanks so much for your time. I'm sure you can make this at home. There's gonna be interesting food in home recipes coming up. Remember to bookmark this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
