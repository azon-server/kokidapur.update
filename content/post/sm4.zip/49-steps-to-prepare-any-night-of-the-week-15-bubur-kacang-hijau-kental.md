---
description: "Steps to Prepare Any-night-of-the-week 15. Bubur Kacang Hijau (Kental)"
title: "Steps to Prepare Any-night-of-the-week 15. Bubur Kacang Hijau (Kental)"
slug: 49-steps-to-prepare-any-night-of-the-week-15-bubur-kacang-hijau-kental

<p>
	<strong>15. Bubur Kacang Hijau (Kental)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/bef8d5f880434273/680x482cq70/15-bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="15. Bubur Kacang Hijau (Kental)" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is Jim, welcome to our recipe page. Today, we're going to prepare a distinctive dish, 15. bubur kacang hijau (kental). One of my favorites food recipes. This time, I will make it a bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	15. Bubur Kacang Hijau (Kental) is one of the most favored of current trending meals in the world. It is simple, it is fast, it tastes yummy. It's appreciated by millions every day. They're fine and they look fantastic. 15. Bubur Kacang Hijau (Kental) is something which I have loved my entire life.
</p>

<p>
To begin with this particular recipe, we have to first prepare a few components. You can cook 15. bubur kacang hijau (kental) using 7 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make 15. Bubur Kacang Hijau (Kental):</h3>

<ol>
	
		<li>{Make ready 160 gr of kacang hijau. </li>
	
		<li>{Take 12 sdm of gula pasir atau sesuai selera. </li>
	
		<li>{Take 3/4 sdt of garam halus. </li>
	
		<li>{Take 2 lbr of daun pandan (simpulkan). </li>
	
		<li>{Get 700 ml of air. </li>
	
		<li>{Prepare 750 ml of santan dgn kekentalan sedang. </li>
	
		<li>{Prepare 3-4 sdm of tapioka larutkan dgn sedikit air. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make 15. Bubur Kacang Hijau (Kental):</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau lalu rendam selama 3jam. Setelah 3jam bilas kembali hingga bersih.....
			
			
		</li>
	
		<li>
			Rebus air sampai mendidih setelah mendidih masukkan kacang hijau,masak sampai empuk &amp; air menyusut....
			
			
		</li>
	
		<li>
			Selanjutnya masukkan santan,gula,garam &amp; daun pandan masak sampai mendidih. Sambil sesekali diaduk supaya santan tidak pecah....
			
			
		</li>
	
		<li>
			Selanjutnya masukkan larutan tapioka aduk terus supaya tidak menggumpal &amp; masak sampai mendidih lagi y moms. Setelah matang angkat &amp; sajikan....
			
			
		</li>
	
		<li>
			Enak lo dimakan selagi masih hangat &amp; ditambah roti tawar...😋😋.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this exceptional food 15. bubur kacang hijau (kental) recipe. Thanks so much for your time. I'm sure that you will make this at home. There's gonna be interesting food in home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
