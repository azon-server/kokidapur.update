---
description: "Recipe of Quick Bubur kacang ijo labu kuning"
title: "Recipe of Quick Bubur kacang ijo labu kuning"
slug: 119-recipe-of-quick-bubur-kacang-ijo-labu-kuning

<p>
	<strong>Bubur kacang ijo labu kuning</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/90977eaad11d1540/680x482cq70/bubur-kacang-ijo-labu-kuning-foto-resep-utama.jpg" alt="Bubur kacang ijo labu kuning" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you are having an amazing day today. Today, I'm gonna show you how to make a special dish, bubur kacang ijo labu kuning. One of my favorites. This time, I will make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo labu kuning is one of the most well liked of recent trending meals in the world. It is appreciated by millions daily. It is easy, it is quick, it tastes delicious. They are nice and they look wonderful. Bubur kacang ijo labu kuning is something which I have loved my whole life.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to prepare a few ingredients. You can have bubur kacang ijo labu kuning using 8 ingredients and 6 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo labu kuning:</h3>

<ol>
	
		<li>{Make ready 1 ons of Kacang ijo. </li>
	
		<li>{Take 1/4 of Labu kuning. </li>
	
		<li>{Take biji of Santan kelapa sebelah. </li>
	
		<li>{Take 2 lembar of Pandan. </li>
	
		<li>{Take  of Susu kental manis. </li>
	
		<li>{Make ready secukupnya of Gula pasir. </li>
	
		<li>{Prepare 2 ibu jari of Jahe. </li>
	
		<li>{Prepare  of Air secukupnya nya. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo labu kuning:</h3>

<ol>
	
		<li>
			Rendam kacang ijo selama 20 menit lalu cuci sampai bersih..dan kupas labu kuning potong dadu trus cuci...
			
			
		</li>
	
		<li>
			Masak air 5 gelas sampai mendidih.
			
			
		</li>
	
		<li>
			Lalu masukan kacang ijo yg sudah di rendam,masak sampai 5 menit.
			
			
		</li>
	
		<li>
			Lalu masukan jahe dan daun pandan berserta air santan nya,tunggu sampai mendidih.
			
			
		</li>
	
		<li>
			Lalu masukan gula pasir dan susu kental manis nya sesuai selera.
			
			
		</li>
	
		<li>
			Dan yang terakhir masukan labu kuning nya tunggu sampai mendidih dan matang labu nya....
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this special food bubur kacang ijo labu kuning recipe. Thanks so much for your time. I am confident that you will make this at home. There is gonna be more interesting food in home recipes coming up. Remember to bookmark this page in your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
