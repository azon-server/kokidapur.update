---
description: "Recipe of Favorite Bubur Kacang Ijo Kental Yummyyy"
title: "Recipe of Favorite Bubur Kacang Ijo Kental Yummyyy"
slug: 12-recipe-of-favorite-bubur-kacang-ijo-kental-yummyyy

<p>
	<strong>Bubur Kacang Ijo Kental Yummyyy</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/dc4365285f32c7ea/680x482cq70/bubur-kacang-ijo-kental-yummyyy-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Kental Yummyyy" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you're having an incredible day today. Today, I will show you a way to make a distinctive dish, bubur kacang ijo kental yummyyy. One of my favorites. This time, I will make it a bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo Kental Yummyyy is one of the most favored of recent trending meals in the world. It is enjoyed by millions every day. It's simple, it's quick, it tastes delicious. They are nice and they look wonderful. Bubur Kacang Ijo Kental Yummyyy is something that I've loved my entire life.
</p>

<p>
To begin with this recipe, we have to prepare a few components. You can cook bubur kacang ijo kental yummyyy using 8 ingredients and 7 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Kental Yummyyy:</h3>

<ol>
	
		<li>{Prepare 1/4 of Kacang hijau. </li>
	
		<li>{Get 1/2 iris of Gula merah ukuran besar. </li>
	
		<li>{Get 5 sdm of Gula pasir (sesuai selera). </li>
	
		<li>{Take 1 ruas of Jahe. </li>
	
		<li>{Get 1 mangkok of Santan. </li>
	
		<li>{Make ready 2 lembar of Daun pandan. </li>
	
		<li>{Make ready 3 sdm of Tepung maizena. </li>
	
		<li>{Get  of Air. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo Kental Yummyyy:</h3>

<ol>
	
		<li>
			Rendam kacang ijo semalaman, setelah di rendam semalaman cuci sampai bersih.
			
			
		</li>
	
		<li>
			Iris gula jawa agar mudah larut saat di rebus nanti, dan ulek jahe.
			
			
		</li>
	
		<li>
			Larutkan tepung maizena menggunakan air, jika ingin lebih kental boleh ditambahkan tepung maizena sesuai selera.
			
			
		</li>
	
		<li>
			Rebus air sampai mendidih, lalu masukkan kacang ijo yg sudah dicuci, tunggu hingga kacang ijo benar2 empuk.
			
			
		</li>
	
		<li>
			Lalu masukkan jahe, gula pasir, gula jawa, dan daun pandan. Koreksi rasa, jika masih kurang manis bisa ditambahkan gula sesuai selera. Masukkan tepung maizena yg sudah dilarutkan, jika masih kurang kental bisa ditambah tepung maizena lagi sesuai selera. Jika ingin lebih cair bisa ditambahkan air lagi. Aduk merata, koreksi rasa, lalu angkat..
			
			
		</li>
	
		<li>
			Sementara didihkan santan di panci yg berbeda, santan saya pisah karna takut cepat basi, tapi boleh langsung dicampur dengan kacang ijo sesuai selera saja hehe. Jika sudah mendidih, angkat..
			
			
		</li>
	
		<li>
			Jika sudah matang, angkat dan sajikan. Ambil bubur kacang ijo masukkan ke dalam mangkok, tambahkan santan. Dan bubur kacang ijo kental siap untuk disajikan. Selamat mencoba bunda😊.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this special food bubur kacang ijo kental yummyyy recipe. Thanks so much for your time. I am confident that you can make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
