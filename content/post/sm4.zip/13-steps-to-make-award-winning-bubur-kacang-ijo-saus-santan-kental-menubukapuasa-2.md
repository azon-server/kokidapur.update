---
description: "Steps to Make Award-winning Bubur Kacang Ijo Saus Santan Kental #menubukapuasa_2"
title: "Steps to Make Award-winning Bubur Kacang Ijo Saus Santan Kental #menubukapuasa_2"
slug: 13-steps-to-make-award-winning-bubur-kacang-ijo-saus-santan-kental-menubukapuasa-2

<p>
	<strong>Bubur Kacang Ijo Saus Santan Kental #menubukapuasa_2</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/bb50bd3ad95e2a27/680x482cq70/bubur-kacang-ijo-saus-santan-kental-menubukapuasa_2-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Saus Santan Kental #menubukapuasa_2" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, we're going to make a distinctive dish, bubur kacang ijo saus santan kental #menubukapuasa_2. It is one of my favorites. For mine, I'm gonna make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo Saus Santan Kental #menubukapuasa_2 is one of the most favored of recent trending foods on earth. It's enjoyed by millions every day. It is easy, it's quick, it tastes delicious. Bubur Kacang Ijo Saus Santan Kental #menubukapuasa_2 is something which I've loved my whole life. They're fine and they look fantastic.
</p>

<p>
To get started with this particular recipe, we have to first prepare a few components. You can cook bubur kacang ijo saus santan kental #menubukapuasa_2 using 14 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Saus Santan Kental #menubukapuasa_2:</h3>

<ol>
	
		<li>{Get 250 gr of Kacang Hijau (cuci bersih, rendam semalaman). </li>
	
		<li>{Take 2 Lembar of Daun Pandan. </li>
	
		<li>{Take 5 cm of Jahe (geprek). </li>
	
		<li>{Prepare 150 gr of Gula Pasir (Bisa ganti gula merah/ gula jawa). </li>
	
		<li>{Make ready 2 Sdm of Tepung Maizena. </li>
	
		<li>{Take 1200 ml of Air. </li>
	
		<li>{Take 1/2 Sdt of Garam. </li>
	
		<li>{Make ready  of Bahan Kuah/ Saus Santan :. </li>
	
		<li>{Take 65 gr of Santan Santan Instan. </li>
	
		<li>{Take 200 ml of Air. </li>
	
		<li>{Get 1 Sdm of Tepung Maizena. </li>
	
		<li>{Get 1/2 Sdt of Garam. </li>
	
		<li>{Prepare 1 Saset of Vanili. </li>
	
		<li>{Make ready 1 Lembar of Daun Pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo Saus Santan Kental #menubukapuasa_2:</h3>

<ol>
	
		<li>
			Saus Santan : Tuang air, santan, garam, tepung Maizena dan vanili, serta 1 lembar daun pandan kedalam panci, aduk hingga rata kemudian didihkan. Aduk terus selama memasak, matikan api sehabis benar-benar mendidih..
			
			
		</li>
	
		<li>
			Rebus Kacang Ijo dengan air bersama jahe dan 2 lembar daun pandan, aduk sesekali selama memasak..
			
			
		</li>
	
		<li>
			Setelah kacang hijau mekar dan kuah agak menyusut masukkan gula pasir serta aduk rata, kemudian masak sampai kuah hampir menyusut. Terakhir tuang larutan tepung maizena, aduk rata dan masak sampai kental, matikan api..
			
			
		</li>
	
		<li>
			Bubur kacang hijau siap disajikan dengan siraman saus santan..
			
			
		</li>
	
		<li>
			Selamat mencoba guys, semoga bermanfaat 😁👌. Salam Baking dan Happy Cooking 😁🙏.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this special food bubur kacang ijo saus santan kental #menubukapuasa_2 recipe. Thank you very much for your time. I'm confident you can make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to save this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
