---
description: "How to Prepare Any-night-of-the-week Tinutuan (Bubur Manado)"
title: "How to Prepare Any-night-of-the-week Tinutuan (Bubur Manado)"
slug: 383-how-to-prepare-any-night-of-the-week-tinutuan-bubur-manado

<p>
	<strong>Tinutuan (Bubur Manado)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/76d960dcc388f4ec/680x482cq70/tinutuan-bubur-manado-foto-resep-utama.jpg" alt="Tinutuan (Bubur Manado)" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Drew, welcome to my recipe page. Today, I'm gonna show you how to prepare a distinctive dish, tinutuan (bubur manado). It is one of my favorites. This time, I am going to make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Tinutuan (Bubur Manado) is one of the most favored of recent trending meals on earth. It is enjoyed by millions every day. It's easy, it is fast, it tastes yummy. Tinutuan (Bubur Manado) is something that I have loved my entire life. They're fine and they look wonderful.
</p>

<p>
To get started with this particular recipe, we have to first prepare a few components. You can have tinutuan (bubur manado) using 14 ingredients and 6 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Tinutuan (Bubur Manado):</h3>

<ol>
	
		<li>{Get 150 gr of beras. </li>
	
		<li>{Get 230 gr of labu kuning. </li>
	
		<li>{Get 125 gr of singkong. </li>
	
		<li>{Get 150 gr of ubi. </li>
	
		<li>{Take 2 buah of jagung. </li>
	
		<li>{Prepare 8 buah of ceker ayam. </li>
	
		<li>{Get 1 buah of Daun Kunyit. </li>
	
		<li>{Take 2 buah of sereh. </li>
	
		<li>{Take 3 Ikat of Kangkung. </li>
	
		<li>{Prepare 2 Ikat of Bayam. </li>
	
		<li>{Take 1 genggam of kemangi. </li>
	
		<li>{Make ready 2 sdt of garam. </li>
	
		<li>{Make ready 1 sdt of kaldu jamur. </li>
	
		<li>{Prepare 2 L of air. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Tinutuan (Bubur Manado):</h3>

<ol>
	
		<li>
			Siapkan dulu semua bahannya, cuci berasnya, pipil jagungnya, potong-potong singkong, ubi dan labu. Potong labu jangan terlalu kecil ya, agar tidak benyek. Jika tidak ada atau tidak suka singkong dan/atau ubi, bisa di skip ya, tapi jangan skip labu, karena itu yang bikin manis bubur ini..
			
			
		</li>
	
		<li>
			Rebus 2L air, masukkan ceker, jagung, singkong, ubi, daun kunyit, sereh dan beras. Aduk asal rata saja.
			
			
		</li>
	
		<li>
			Jika singkong dan ubi sudah mulai empuk, masukkan labu (jika suka labunya agak hancur nantinya, bisa dimasukkan berbarengan di step sebelumnya). Tambahkan juga garam dan kaldu jamur di step ini ya.
			
			
				
					<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Tinutuan (Bubur Manado)"> <br>
				
			
		</li>
	
		<li>
			Jika jagung dan semua umbi sudah matang dan empuk, test rasa, test juga kekentalannya. Saat ini bubur harus agak encer, karena masih akan di tambahkan sayur. Jika bubur dirasa terlalu kental, tambahkan air dan biarkan mendidih lagi sebelum dimasukkan sayur.
			
			
				
					<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Tinutuan (Bubur Manado)"> <br>
				
					<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Tinutuan (Bubur Manado)"> <br>
				
			
		</li>
	
		<li>
			Terakhir, jika bubur sudah mendidih, sudah test rasa, sudah matang semua jagung dan umbi-umbian, masukkan bayam, kemangi dan kangkung. Aduk asal rata, matikan kompor. Panas dari bubur akan terus memasak sayurnya..
			
			
				
					<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Tinutuan (Bubur Manado)"> <br>
				
					<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Tinutuan (Bubur Manado)"> <br>
				
			
		</li>
	
		<li>
			Sajikan dengan sambal cakalang, bisa dengan sambel terasi dan ikan asin juga loh.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food tinutuan (bubur manado) recipe. Thanks so much for your time. I am sure that you will make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
