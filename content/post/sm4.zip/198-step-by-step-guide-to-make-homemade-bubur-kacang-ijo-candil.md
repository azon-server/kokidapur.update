---
description: "Step-by-Step Guide to Make Homemade Bubur kacang ijo + Candil"
title: "Step-by-Step Guide to Make Homemade Bubur kacang ijo + Candil"
slug: 198-step-by-step-guide-to-make-homemade-bubur-kacang-ijo-candil

<p>
	<strong>Bubur kacang ijo + Candil</strong>. 
	Bubur Kacang Ijo adalah makanan berbahan utama kacang hijau yang biasa dikonsumsi oleh masyarakat Indonesia. Bubur kacang ijo ini sudah tersebar di hampir seluruh daerah yang ada di nusantara sehingga Anda pun dapat dengan mudah untuk menemukannya. Satu hal yang paling digemari dari bubur kacang ijo ini adalah rasanya yang enak dan lezat sehingga semua orang hampir suka untuk mencicipinya.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/3cc94b034f873508/680x482cq70/bubur-kacang-ijo-candil-foto-resep-utama.jpg" alt="Bubur kacang ijo + Candil" style="width: 100%;">
	
	
		Ternyata membuat bubur candil tidak sesulit yang dibayangkan lho.
	
		Bubur Candil merupakan hidangan penutup yang populer dan hampir merakyat di sebagian besar pulau Jawa.
	
		Meski kelihatannya rumit, sebenarnya proses pembuatan Bubur Candil cukup gampang dan cepat.
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, we're going to prepare a distinctive dish, bubur kacang ijo + candil. One of my favorites. For mine, I am going to make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo adalah makanan berbahan utama kacang hijau yang biasa dikonsumsi oleh masyarakat Indonesia. Bubur kacang ijo ini sudah tersebar di hampir seluruh daerah yang ada di nusantara sehingga Anda pun dapat dengan mudah untuk menemukannya. Satu hal yang paling digemari dari bubur kacang ijo ini adalah rasanya yang enak dan lezat sehingga semua orang hampir suka untuk mencicipinya.
</p>
<p>
	Bubur kacang ijo + Candil is one of the most popular of recent trending meals on earth. It is easy, it's quick, it tastes yummy. It's enjoyed by millions daily. They're fine and they look wonderful. Bubur kacang ijo + Candil is something that I have loved my whole life.
</p>

<p>
To get started with this particular recipe, we must first prepare a few ingredients. You can cook bubur kacang ijo + candil using 12 ingredients and 11 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo + Candil:</h3>

<ol>
	
		<li>{Make ready 1/2 kg of kacang ijo. </li>
	
		<li>{Get  of Bahan candil:. </li>
	
		<li>{Take 250 gr of tepung ketan. </li>
	
		<li>{Make ready  of Pewarna makanan. </li>
	
		<li>{Prepare Secukupnya of garam. </li>
	
		<li>{Get Secukupnya of air. </li>
	
		<li>{Get  of Bahan pelengkap:. </li>
	
		<li>{Make ready 2 sdm of maizena. </li>
	
		<li>{Prepare 6 buah of gula jawa. </li>
	
		<li>{Prepare Secukupnya of gula pasir. </li>
	
		<li>{Prepare Secukupnya of garam. </li>
	
		<li>{Take Secukupnya of air. </li>
	
</ol>
<p>
	
		Bubur Kacang Ijo adalah makanan berbahan utama kacang hijau yang biasa dikonsumsi oleh masyarakat Indonesia.
	
		Resep bubur kacang hijau kental baik dengan santan maupun bubur kacang hijau tanpa santan.
	
		Bubur kacang hijau termasuk dalam resep jajanan tradisional yang sangat terkenal sejak puluhan tahun silam.
	
		Bahkan sering kita lihat pedagang bubur kacang hijau keliling dengan sepeda lewat di.
	
</p>

<h3>Instructions to make Bubur kacang ijo + Candil:</h3>

<ol>
	
		<li>
			Rendam kacang ijo 15jam (minimal 6jam ya) lebih bagus lagi jika direndam seharian..
			
			
		</li>
	
		<li>
			Buat candil: Campur tepung ketan dengan garam secukupnya lalu tuangi air sedikit demi sedikit sampai adonan bisa dibuat cukup kalis dan bisa dibentuk bulatan2..
			
			
		</li>
	
		<li>
			Bagi adonan menjadi 3 lalu beri warna yg berbeda. (adonan bisa dibagi sesuai selera mau berapa warna) Lalu bentuk bulatan kecil2..
			
			
		</li>
	
		<li>
			.
			
			
		</li>
	
		<li>
			.
			
			
		</li>
	
		<li>
			Masukkan candil ke air yang sudah mendidih, jika sudah mengapung tunggu beberapa saat lalu angkat..
			
			
		</li>
	
		<li>
			Buat bubur kacang ijo+candil: Ambil kacang ijo yang sudah direndam, masukkan ke dalam air dan rebus sampai kacang ijo benar2 empuk (airnya yg penting diatas kacang ijonya, jika kurang empuk bisa tambah air smpai empuk, saya 30menitan untuk rebus kacang ijonya).
			
			
		</li>
	
		<li>
			Jika sudah empuk tambahkan air santan, ini sesuai seleramu ya, mau bubur yg sedikit air atau bnyak air..
			
			
		</li>
	
		<li>
			Lalu tambahkan gula jawa,garam, gula pasir dan tepung maizena. Aduk sampai mengental. (gula jawanya di sisir ya, jika kurang kental bisa tambahkan maizena lagi).
			
			
		</li>
	
		<li>
			Masukkan candil dan aduk-aduk, lalu tes rasa..
			
			
		</li>
	
		<li>
			Jika rasanya sudah pas, angkat dan selamat menikmati..
			
			
		</li>
	
</ol>

<p>
	
		Kue putu umumnya berwarna hijau muda dari campuran daun suji atau pewarna makanan, sedangkan kue dongkal hanya mengikuti warna tepung beras yaitu putih.
	
		Setelah makan kue dongkal, chef Gerry melanjutkan perburuan takjil dengan mencicipi bubur kacang hijau Madura yang masih di seputaran.
	
		Bubur kacang hijau atau dikenal juga dengan kacang ijo merupakan sajian yang nikmat dan kaya akan gizi.
	
		Rebus kacang hijau bersama air sampai empuk dan air.
	
		Ngomong-ngomong masalah bubur kacang ijo, ane jadi inget istilah BURJO saat kuliah di Jogja.
	
</p>

<p>
	So that's going to wrap it up for this special food bubur kacang ijo + candil recipe. Thanks so much for reading. I am sure that you can make this at home. There's gonna be interesting food in home recipes coming up. Don't forget to save this page in your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
