---
description: "Simple Way to Prepare Perfect Bubur kacang ijo ketan putih"
title: "Simple Way to Prepare Perfect Bubur kacang ijo ketan putih"
slug: 190-simple-way-to-prepare-perfect-bubur-kacang-ijo-ketan-putih

<p>
	<strong>Bubur kacang ijo ketan putih</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/96577764cfadef18/680x482cq70/bubur-kacang-ijo-ketan-putih-foto-resep-utama.jpg" alt="Bubur kacang ijo ketan putih" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's me, Dave, welcome to my recipe page. Today, I'm gonna show you how to make a distinctive dish, bubur kacang ijo ketan putih. It is one of my favorites food recipes. This time, I will make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo ketan putih is one of the most popular of current trending foods in the world. It is easy, it's fast, it tastes delicious. It is appreciated by millions every day. They're nice and they look fantastic. Bubur kacang ijo ketan putih is something that I've loved my entire life.
</p>

<p>
To begin with this recipe, we have to first prepare a few ingredients. You can cook bubur kacang ijo ketan putih using 8 ingredients and 4 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo ketan putih:</h3>

<ol>
	
		<li>{Make ready 250 gr of kacang ijo. </li>
	
		<li>{Take 1 of , 5 liter air. </li>
	
		<li>{Make ready Segenggam of ketan putih. </li>
	
		<li>{Prepare 2 of lmbar daun pandan. </li>
	
		<li>{Get 300 gr of gula pasir (manis sesuai selera). </li>
	
		<li>{Take 1 sdt of garam. </li>
	
		<li>{Take 1/2 sdt of vanilli. </li>
	
		<li>{Take 500 ml of santan kental. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo ketan putih:</h3>

<ol>
	
		<li>
			Rebus kacang ijo dan ketan hingga empuk..
			
			
		</li>
	
		<li>
			Beri daun pandan, gula, garam dan vanilli, aduk hingga gula larut.
			
			
		</li>
	
		<li>
			Masukkan santan.. masak hingga mendidih...
			
			
		</li>
	
		<li>
			Saya kurang suka pke gula merah, jd sy pke gula pasir semua, jd kl moms ada yg mau dicampur monggo...
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur kacang ijo ketan putih recipe. Thanks so much for reading. I am confident that you will make this at home. There's gonna be interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
