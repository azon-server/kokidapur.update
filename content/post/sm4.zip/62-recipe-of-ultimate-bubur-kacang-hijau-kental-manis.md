---
description: "Recipe of Ultimate Bubur kacang hijau kental manis"
title: "Recipe of Ultimate Bubur kacang hijau kental manis"
slug: 62-recipe-of-ultimate-bubur-kacang-hijau-kental-manis

<p>
	<strong>Bubur kacang hijau kental manis</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/b83c5b24e05acada/680x482cq70/bubur-kacang-hijau-kental-manis-foto-resep-utama.jpg" alt="Bubur kacang hijau kental manis" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an incredible day today. Today, I will show you a way to prepare a special dish, bubur kacang hijau kental manis. It is one of my favorites. This time, I will make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang hijau kental manis is one of the most well liked of current trending foods on earth. It's enjoyed by millions daily. It's easy, it's fast, it tastes yummy. They are fine and they look wonderful. Bubur kacang hijau kental manis is something that I have loved my whole life.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to prepare a few components. You can cook bubur kacang hijau kental manis using 8 ingredients and 6 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang hijau kental manis:</h3>

<ol>
	
		<li>{Make ready 1/4 of kacang hijau. </li>
	
		<li>{Get 1 buah of gula merah. </li>
	
		<li>{Get 5 sdm of gula pasir. </li>
	
		<li>{Get 2 sdm of tepung maizena. </li>
	
		<li>{Make ready 1 ruas of jahe. </li>
	
		<li>{Get 1 bks of santan kara (65 ml). </li>
	
		<li>{Take 1 lt of air. </li>
	
		<li>{Make ready sejumput of Garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang hijau kental manis:</h3>

<ol>
	
		<li>
			Rebus kacang hijau selama 5 menit, setelah 5 menit matikan kompor dan diamkan kacang hijau di dlm panci tertutup selama 30 menit.
			
			
		</li>
	
		<li>
			Sambil nunggu 30 menit iris&#34; gula merah.
			
			
		</li>
	
		<li>
			Setelah 30 menit, nyalakan kompor dan tambahkan sisa air nya lalu masukan Gula merah,gula pasir,garam, dan jahe yg sudah di geprek.
			
			
		</li>
	
		<li>
			Setelah mendidih masukan tepung maizena yg sudah di larutkan,aduk&#34; sampai rata.
			
			
		</li>
	
		<li>
			Terakhir masukan santan dan aduk&#34; lg supaya santan tidak pecah, kemudian matikan kompor setelah mendidih dngn sempurna.
			
			
		</li>
	
		<li>
			Bubur kacang hijau kental manis siap di sajikan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this exceptional food bubur kacang hijau kental manis recipe. Thank you very much for your time. I'm sure that you will make this at home. There's gonna be interesting food in home recipes coming up. Remember to bookmark this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
