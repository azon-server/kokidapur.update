---
description: "How to Prepare Perfect Bubur kacang ijo"
title: "How to Prepare Perfect Bubur kacang ijo"
slug: 168-how-to-prepare-perfect-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/20b760455d5b5baa/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's Brad, welcome to our recipe page. Today, I'm gonna show you how to make a special dish, bubur kacang ijo. One of my favorites. This time, I will make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang ijo is one of the most popular of current trending foods on earth. It is easy, it is quick, it tastes yummy. It is enjoyed by millions every day. They are fine and they look wonderful. Bubur kacang ijo is something that I have loved my entire life.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we must prepare a few components. You can cook bubur kacang ijo using 5 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Get 1 mangkok of kacang hijau. </li>
	
		<li>{Take 250 ml of susu cair full cream. </li>
	
		<li>{Prepare secukupnya of Air. </li>
	
		<li>{Make ready secukupnya of Gula jawa. </li>
	
		<li>{Get secukupnya of Garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Rebus kacang hijau sampai empuk.
			
			
		</li>
	
		<li>
			Setelah empuk tambahkan susu cair, garam dan gula.
			
			
		</li>
	
		<li>
			Kalau susu terlalu kental bisa ditambah dengan air sesuai selera.
			
			
		</li>
	
		<li>
			Tunggu sampai mendidih.
			
			
		</li>
	
		<li>
			Bubur kacang ijo siap disajikan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur kacang ijo recipe. Thank you very much for your time. I am sure that you will make this at home. There is gonna be more interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
