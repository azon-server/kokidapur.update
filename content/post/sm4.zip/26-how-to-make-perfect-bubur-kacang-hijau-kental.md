---
description: "How to Make Perfect Bubur kacang hijau kental"
title: "How to Make Perfect Bubur kacang hijau kental"
slug: 26-how-to-make-perfect-bubur-kacang-hijau-kental

<p>
	<strong>Bubur kacang hijau kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/9009ac18b1eb55d0/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur kacang hijau kental" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you're having an amazing day today. Today, I will show you a way to make a distinctive dish, bubur kacang hijau kental. It is one of my favorites. This time, I am going to make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang hijau kental is one of the most favored of current trending foods in the world. It is simple, it's quick, it tastes delicious. It's appreciated by millions every day. Bubur kacang hijau kental is something which I've loved my entire life. They are fine and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to prepare a few components. You can cook bubur kacang hijau kental using 11 ingredients and 4 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur kacang hijau kental:</h3>

<ol>
	
		<li>{Get 200 gr of Kacang hijau. </li>
	
		<li>{Get 3 keping of Gula merah / gula aren. </li>
	
		<li>{Make ready 4 sdm of Gulpas. </li>
	
		<li>{Prepare 1 buah of Santan instan. </li>
	
		<li>{Make ready 1 of Daun pandan. </li>
	
		<li>{Get  of Tepung maizena 2 di kasih air secukupnya. </li>
	
		<li>{Take 1 liter of Air. </li>
	
		<li>{Take  of Saus santan:. </li>
	
		<li>{Get 1 buah of Santan instan. </li>
	
		<li>{Take  of Daun pandan. </li>
	
		<li>{Take 300 ml of Air. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang hijau kental:</h3>

<ol>
	
		<li>
			Rendam kacang hijau selama 1jam lalu cuci bersih kemudian masak kacang hijau,air,daun pandan,saya masak di magic com biar irit gas,heheheh setelah empuk masukkan gula Jawa,gulpas sampai gula larut.
			
			
		</li>
	
		<li>
			Kemudian tuangkan santan instan aduk rata lalu masukkan tepung maizena.
			
			
		</li>
	
		<li>
			Saus santan: masukkan santan instan,air,daun pandan lalu masak sampai mendidih.
			
			
		</li>
	
		<li>
			Tata di mangkok bubur kacang hijau kemudian siram dg saus santan,rasanya gurih dan kental.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this special food bubur kacang hijau kental recipe. Thanks so much for reading. I am confident you can make this at home. There is gonna be interesting food at home recipes coming up. Remember to bookmark this page in your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
