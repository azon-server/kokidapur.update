---
description: "Simple Way to Make Super Quick Homemade Bubur manado"
title: "Simple Way to Make Super Quick Homemade Bubur manado"
slug: 284-simple-way-to-make-super-quick-homemade-bubur-manado

<p>
	<strong>Bubur manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/2c8d73ef43cc18b4/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur manado" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you are having an amazing day today. Today, I will show you a way to make a special dish, bubur manado. One of my favorites. This time, I'm gonna make it a bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur manado is one of the most favored of recent trending meals in the world. It's simple, it's fast, it tastes yummy. It is enjoyed by millions every day. Bubur manado is something that I've loved my entire life. They are nice and they look fantastic.
</p>

<p>
To get started with this recipe, we have to first prepare a few ingredients. You can cook bubur manado using 14 ingredients and 6 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur manado:</h3>

<ol>
	
		<li>{Prepare 1/2 kg of ayam kampung (ayam biasa juga gpp) potong kecil2. </li>
	
		<li>{Make ready 2 batang of serai. </li>
	
		<li>{Get 5 lembar of daun jeruk. </li>
	
		<li>{Prepare 1 buah of jagung sisir. </li>
	
		<li>{Prepare 1 iket of bayem / kangkung. </li>
	
		<li>{Make ready 2 cup of beras atau sesuai kebutuhan. </li>
	
		<li>{Take 5 of bawang putih iris halus. </li>
	
		<li>{Take 6 of bawang merah iris halus. </li>
	
		<li>{Take  of Bahan sambal 👇. </li>
	
		<li>{Prepare 1 buah of tomat potong kotak kecil. </li>
	
		<li>{Get 5 of bawang merah iris tipis. </li>
	
		<li>{Make ready 10 of rawit hijau iris. </li>
	
		<li>{Take 5 of rawit merah iris. </li>
	
		<li>{Take 1 buah of jeruk limo. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur manado:</h3>

<ol>
	
		<li>
			Cuci bersih semua bahan, siapkan panci besar, masukkan duo bawang yg di iris halus, daun jeruk dan serai beri air 2L, masak dgn api kecil, sambil sesekali di aduk agar tidak gosong.
			
			
		</li>
	
		<li>
			Jika sdh mendidih, masukkan ayam dan jagung. Tambahkan air jika nasi belum lembut..
			
			
		</li>
	
		<li>
			Beri gula dan garam (tanpa penyedap karna sudah ada kaldu dr ayam).
			
			
		</li>
	
		<li>
			Jika sdh matang, masukkan bayam, diamkan sejenak hingga bayam lembut. Matikan..
			
			
		</li>
	
		<li>
			Siapkan bahan sambal di mangkok, lalu beri garam, siramkan sedikit minyak panas, lalu beri perasan jeruk limo.
			
			
		</li>
	
		<li>
			Nikmat di sajikan dgn tambahan kecap asin dan ikan asin goreng kering. Selamat mencoba 😊.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur manado recipe. Thank you very much for reading. I'm sure that you can make this at home. There is gonna be more interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
