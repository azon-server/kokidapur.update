---
description: "Simple Way to Make Speedy Bubur Kacang Ijo ketan putih"
title: "Simple Way to Make Speedy Bubur Kacang Ijo ketan putih"
slug: 153-simple-way-to-make-speedy-bubur-kacang-ijo-ketan-putih

<p>
	<strong>Bubur Kacang Ijo ketan putih</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/bfbfe44ca7531914/680x482cq70/bubur-kacang-ijo-ketan-putih-foto-resep-utama.jpg" alt="Bubur Kacang Ijo ketan putih" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Louise, welcome to my recipe page. Today, we're going to prepare a distinctive dish, bubur kacang ijo ketan putih. One of my favorites food recipes. For mine, I'm gonna make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo ketan putih is one of the most well liked of current trending foods in the world. It is enjoyed by millions every day. It is simple, it's quick, it tastes yummy. Bubur Kacang Ijo ketan putih is something which I have loved my entire life. They are fine and they look wonderful.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we must prepare a few components. You can have bubur kacang ijo ketan putih using 9 ingredients and 5 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo ketan putih:</h3>

<ol>
	
		<li>{Prepare 250 gram of kacang ijo. </li>
	
		<li>{Prepare 100 gram of ketan putih. </li>
	
		<li>{Prepare 200 gram of gula merah. </li>
	
		<li>{Take 40 gram of jahe bakar geprek. </li>
	
		<li>{Prepare 2 lembar of pandan. </li>
	
		<li>{Make ready Sedikit of garam, vanilli. </li>
	
		<li>{Prepare 500 ml of santan kental. </li>
	
		<li>{Get 2 liter of air. </li>
	
		<li>{Make ready 2-3 sdm of tepung sagu dilarutkan air sedikit bila kurang kental. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo ketan putih:</h3>

<ol>
	
		<li>
			Rendam kacang ijo semalam, ketan putih direndam 1 jam.
			
			
		</li>
	
		<li>
			Cuci bersih, bilas tiriskan, didihkan air, siapkan gula dan jahe geprek serta pandan.
			
			
		</li>
	
		<li>
			Didihkan air, masukan kacan ijo, ketan rebus sampai lunak sambil diaduk aduk supaya tidak lengket, tambahkan gula jawa, garam, jahe.
			
			
		</li>
	
		<li>
			Test rasa, masak hingga agak mengental sisihkan.
			
			
		</li>
	
		<li>
			Masak santan cair, garam, serta daun pandan, penyajian tuang santan baru bubur kacang ijo yummy.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this exceptional food bubur kacang ijo ketan putih recipe. Thank you very much for reading. I am sure you will make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
