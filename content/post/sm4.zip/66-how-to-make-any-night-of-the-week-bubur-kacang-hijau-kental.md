---
description: "How to Make Any-night-of-the-week Bubur kacang hijau kental"
title: "How to Make Any-night-of-the-week Bubur kacang hijau kental"
slug: 66-how-to-make-any-night-of-the-week-bubur-kacang-hijau-kental

<p>
	<strong>Bubur kacang hijau kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/e2ede9fe761a022f/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur kacang hijau kental" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is me again, Dan, welcome to our recipe page. Today, I'm gonna show you how to make a distinctive dish, bubur kacang hijau kental. It is one of my favorites. For mine, I'm gonna make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur kacang hijau kental is one of the most well liked of current trending meals on earth. It is appreciated by millions daily. It is easy, it is quick, it tastes delicious. Bubur kacang hijau kental is something which I've loved my entire life. They're nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we must prepare a few components. You can have bubur kacang hijau kental using 8 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang hijau kental:</h3>

<ol>
	
		<li>{Make ready 250 gram of kacang hijau. </li>
	
		<li>{Get 1 ruas of jahe. </li>
	
		<li>{Get 200 ml of santan. </li>
	
		<li>{Prepare  of Gula merah. </li>
	
		<li>{Get  of Gula pasir. </li>
	
		<li>{Get 2 of daun pandan. </li>
	
		<li>{Take 3 sdm of tepung Sagu. </li>
	
		<li>{Take  of Garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang hijau kental:</h3>

<ol>
	
		<li>
			Rendam kacang hijau sampai mekar.
			
			
		</li>
	
		<li>
			Setelah mekar rebus kacang hijau, bersama pandan, jahe geprek, gula merah dan gula pasir dengan air secukupnya sampai lembut/matang.
			
			
		</li>
	
		<li>
			Saat air rebusan mulai menyusut masukan tepung Sagu yg sudah di cairkan.
			
			
		</li>
	
		<li>
			Membuat santan : santan 200 ml di didihkan terpisah, tambahkan daun pandan dan sedikit garam.
			
			
		</li>
	
		<li>
			Sajikan dengan air tawar dan beri santan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur kacang hijau kental recipe. Thanks so much for your time. I am confident that you will make this at home. There's gonna be interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
