---
description: "Simple Way to Prepare Perfect Bubur Kacang Ijo"
title: "Simple Way to Prepare Perfect Bubur Kacang Ijo"
slug: 143-simple-way-to-prepare-perfect-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/117b7c674c95420c/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
		Resep bubur kacang ijo itu sendiri ada berbagai macam dengan tambahan bahan yang melengkapinya.
	
		Cara bikin bubur kacang hijau / ijo memerlukan trik dan tips tersendiri, sehingga hasilnya bisa lebih bagus dan juga enak serta lembut.
	
		Sebenarnya tidak ada yang istimewa saat anda membuat.
	
</p>
<p>
	Hey everyone, it's Drew, welcome to our recipe site. Today, I'm gonna show you how to prepare a distinctive dish, bubur kacang ijo. It is one of my favorites. This time, I will make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo is one of the most favored of recent trending meals in the world. It is enjoyed by millions every day. It is simple, it's fast, it tastes delicious. They are nice and they look fantastic. Bubur Kacang Ijo is something which I've loved my whole life.
</p>
<p>
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>

<p>
To begin with this particular recipe, we have to first prepare a few components. You can have bubur kacang ijo using 9 ingredients and 6 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Get 500 gr of Kacang Hijau. </li>
	
		<li>{Prepare 300 ml of santan cair. </li>
	
		<li>{Prepare 200 ml of santan kental. </li>
	
		<li>{Take 300 ml of Gula merah cair. </li>
	
		<li>{Prepare 100 gr of Gula Pasir. </li>
	
		<li>{Get 1 ruas of jahe (dikupas dan digeprek). </li>
	
		<li>{Prepare  of Air. </li>
	
		<li>{Take  of Garam. </li>
	
		<li>{Make ready 1 lembar of daun pandan (optional). </li>
	
</ol>
<p>
	
		Bubur kacang hejo (su) Bubur kacang ijo (jv) Burjo.
	
		Slightly different names may be used in different regions of Indonesia, such as kacang ijo in Javanese areas.
	
		Cara masak bubur kacang ijo super simple dan enak.
	
		Rahasia Peyek Kacang Ijo Renyah, Tidak Keras dan Tahan Lama Bu Yun kali inia akan membagikan resep, tips dan tutorial cara.
	
</p>

<h3>Steps to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Didihkan air sebanyak 150ml dan tambahkan gula merah. Masak hingga gula merah menjadi cair. Tambahkan sedikit garam. Saring gula merah dan simpan disuhu ruang..
			
			
		</li>
	
		<li>
			Cuci kacang hijau hingga bersih dan rendam selama 6 jam..
			
			
		</li>
	
		<li>
			Setelah kacang hijau direndam, buang air rendaman dan bilas 1 kali. Masak kacang hijau dengan perbandingan air sebesar 1:1 (volume air bisa disesuaikan hingga tekstur kacang ijo empuk). Tambahkan gula pasir, santan cair dan jahe yang sudah digeprek..
			
			
		</li>
	
		<li>
			Apabila tekstur sudah menyerupai bubur, tambahkan santan kental dan gula merah cair. Masak dan aduk hingga merata..
			
			
		</li>
	
		<li>
			Sajikan bubur kacang hijau selagi hangat. Kacang hijau juga dapat disimpan dikulkas terlebih dahulu dan disantap dingin..
			
			
		</li>
	
		<li>
			Notes: Biasanya bubur kacang hijau disajikan dengan gula merah cair dan santan kental secara terpisah supaya yang mengkonsumsi bisa menyesuaikan dengan seleranya..
			
			
		</li>
	
</ol>

<p>
	
		Cara Membuat Bubur Kacang Hijau Sederhana Yang Enak amp Kental Ala Dapur Dina.
	
		Ingin mencoba memasak Bubur Kacang Hijau sendiri, Burjo Pisang (Tips spy kacang ijo cepat empuk dan lembut), Bubur kacang ijo ketan item durian enakk, Burjo Nangka dan lain-lain yang lezat untuk.
	
		Sajikan bubur kacang hijau beserta rebusan santan saat akan di konsumsi untuk menghindari kacang hijau cepat basi Resep membuat bubur kacang hijau.
	
		Resep Bubur Kacang Ijo Enak Dan Cepat Mekar Atau Empuk.
	
		Kacang hijau / ijo merupakan salah satu bahan makanan yang bukan saja enak di buat minuman maupun makanan.
	
</p>

<p>
	So that is going to wrap this up with this special food bubur kacang ijo recipe. Thank you very much for reading. I am sure that you can make this at home. There's gonna be more interesting food at home recipes coming up. Remember to bookmark this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
