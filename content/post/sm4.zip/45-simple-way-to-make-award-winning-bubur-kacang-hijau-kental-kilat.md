---
description: "Simple Way to Make Award-winning Bubur kacang hijau (kental) kilat"
title: "Simple Way to Make Award-winning Bubur kacang hijau (kental) kilat"
slug: 45-simple-way-to-make-award-winning-bubur-kacang-hijau-kental-kilat

<p>
	<strong>Bubur kacang hijau (kental) kilat</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/a5bc16066ae8800b/680x482cq70/bubur-kacang-hijau-kental-kilat-foto-resep-utama.jpg" alt="Bubur kacang hijau (kental) kilat" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's me, Dave, welcome to our recipe site. Today, I'm gonna show you how to make a distinctive dish, bubur kacang hijau (kental) kilat. It is one of my favorites. For mine, I am going to make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang hijau (kental) kilat is one of the most popular of recent trending foods in the world. It is enjoyed by millions daily. It's easy, it is quick, it tastes delicious. Bubur kacang hijau (kental) kilat is something which I have loved my entire life. They are fine and they look fantastic.
</p>

<p>
To get started with this particular recipe, we must first prepare a few ingredients. You can cook bubur kacang hijau (kental) kilat using 9 ingredients and 4 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang hijau (kental) kilat:</h3>

<ol>
	
		<li>{Take 1/4 kg of kacang hijau. </li>
	
		<li>{Make ready 2 sdm of tepung tapioka. </li>
	
		<li>{Get 4 lbr of daun pandan. </li>
	
		<li>{Make ready 1 ruas of jahe. </li>
	
		<li>{Make ready Secukupnya of gula merah. </li>
	
		<li>{Make ready Secukupnya of gula pasir. </li>
	
		<li>{Get Secukupnya of garam. </li>
	
		<li>{Take 1 liter of air. </li>
	
		<li>{Take 2 Bks of santan kara. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang hijau (kental) kilat:</h3>

<ol>
	
		<li>
			Didihkan air 1,5lt (untuk bubur yang encer), masukkan kacang hijau yang sudah dibersihkan, tutup rapat panci biarkan 5 menit. Matikan kompor, dalam keadaan tertutup diamkan 30 menit.
			
			
		</li>
	
		<li>
			Sambil menunggu 30 menit, sisir gula merah, ikat daun pandan, bakar dan geprek jahe, setelah 30 menit nyalakan kompor tunggu mendidih masukkan semua bahan kecuali santan dan tepung tapioka, aduk2 tes rasa, tunggu sampai 7 menit biarkan kembali tertutup.
			
			
		</li>
	
		<li>
			Encerkan tepung tapioka, setelah rasa pas masukkan tepung tapioka sedikit2 sambil diaduk, biarkan mendidih lalu angkat.
			
			
		</li>
	
		<li>
			Sajikan bubur kacang hijau dengan santan kara kental sesuai selera.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this exceptional food bubur kacang hijau (kental) kilat recipe. Thanks so much for reading. I'm sure you can make this at home. There's gonna be more interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
