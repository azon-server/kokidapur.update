---
description: "Recipe of Perfect Bubur kacang Ijo santan kental"
title: "Recipe of Perfect Bubur kacang Ijo santan kental"
slug: 55-recipe-of-perfect-bubur-kacang-ijo-santan-kental

<p>
	<strong>Bubur kacang Ijo santan kental</strong>. 
	Resep bubur kacang ijo memiliki berbagai macam jenisnya. Resep Rahasia Bubur Kacang Hijau Kental Dan Enak, bubur kacang hijau, resep bubur kacang hijau, bubur kacang hijau lezat, bubur kacang ijo seperti tukang. Kuah santannya yang kental berpadu dengan bubur kacang ijo yang lembut akan memanjakan lidah.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/bcbb1ee074b0cc79/680x482cq70/bubur-kacang-ijo-santan-kental-foto-resep-utama.jpg" alt="Bubur kacang Ijo santan kental" style="width: 100%;">
	
	
		Cara Membuat Bubur Kacang Ijo Khas Madura Yang Enak Dan Mudah.
	
		Bubur kacang hijau bisa dibikin tanpa santan, kuah cukup pakai air dan gula merah.
	
		Siapkan mangkuk saji, tuang bubur kacang hijau.
	
</p>
<p>
	Hey everyone, it is Jim, welcome to our recipe site. Today, I'm gonna show you how to prepare a distinctive dish, bubur kacang ijo santan kental. One of my favorites food recipes. For mine, I am going to make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang Ijo santan kental is one of the most favored of recent trending foods in the world. It's easy, it's fast, it tastes yummy. It is enjoyed by millions every day. Bubur kacang Ijo santan kental is something which I've loved my whole life. They're nice and they look wonderful.
</p>
<p>
	Resep bubur kacang ijo memiliki berbagai macam jenisnya. Resep Rahasia Bubur Kacang Hijau Kental Dan Enak, bubur kacang hijau, resep bubur kacang hijau, bubur kacang hijau lezat, bubur kacang ijo seperti tukang. Kuah santannya yang kental berpadu dengan bubur kacang ijo yang lembut akan memanjakan lidah.
</p>

<p>
To get started with this particular recipe, we must prepare a few ingredients. You can cook bubur kacang ijo santan kental using 12 ingredients and 4 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang Ijo santan kental:</h3>

<ol>
	
		<li>{Get 1000 ml of air. </li>
	
		<li>{Prepare 150 gram of kacang ijo. </li>
	
		<li>{Take 2 buah of gula merah di iris. </li>
	
		<li>{Make ready 2 SDM of gula pasir. </li>
	
		<li>{Make ready 2 SDM of sagu (larutkan dengan air). </li>
	
		<li>{Take 1 ruas of jahe di geprek. </li>
	
		<li>{Take 1 lembar of daun pandan. </li>
	
		<li>{Take Sejumput of garam. </li>
	
		<li>{Prepare  of Bahan santan. </li>
	
		<li>{Make ready 250 ml of santan kental. </li>
	
		<li>{Make ready Sejumput of garam. </li>
	
		<li>{Get 1 lembar of daun pandan. </li>
	
</ol>
<p>
	
		Beri krim kental manis dan rice crispy.
	
		Resep bubur kacang hijau kental baik dengan santan maupun bubur kacang hijau tanpa santan.
	
		Cara bikin bubur kacang hijau / ijo memerlukan trik dan tips tersendiri, sehingga hasilnya bisa lebih bagus dan juga enak serta lembut.
	
		Resep Mudah Praktis Bubur Kacang Hijau Tanpa Santan - Kacang Hijau Agar Cepat Empuk Kacang hijau sangat bergizi maka.
	
</p>

<h3>Instructions to make Bubur kacang Ijo santan kental:</h3>

<ol>
	
		<li>
			Rendam kacang Ijo semalaman. Lalu cuci bersih. Rebus kacang Ijo hingga lunak..
			
			
		</li>
	
		<li>
			Setelah kacang Ijo lunak. Masukan gula merah, gula pasir, pandan dan garam dan larutan sagu. Masak hingga mendidih dan mengental. Lalu sisihkan.
			
			
		</li>
	
		<li>
			Masak santan dan bahan lain nya. Sambil di aduk hingga mendidih. Lalu sisihkan.
			
			
		</li>
	
		<li>
			Hidangkan kacang Ijo selagi hangat. Selamat mencoba. ☺️.
			
			
		</li>
	
</ol>

<p>
	
		Biasanya bubur kacang hijau terbuat dari campuran santan dan gula jawa.
	
		Namun, kalau kamu gak suka santan, kamu tak perlu menyertakannya.
	
		Cocok dan aman untuk penderita maag atau asam lambung.
	
		Bubur kacang hijau biji salak. foto: Instagram/@t_finna.
	
		Bubur kacang hijau termasuk sajian nikmat keluarga.
	
</p>

<p>
	So that's going to wrap this up for this special food bubur kacang ijo santan kental recipe. Thank you very much for your time. I am sure that you can make this at home. There is gonna be interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
