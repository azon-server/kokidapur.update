---
description: "How to Prepare Ultimate Tinutuan (Bubur Manado)"
title: "How to Prepare Ultimate Tinutuan (Bubur Manado)"
slug: 261-how-to-prepare-ultimate-tinutuan-bubur-manado

<p>
	<strong>Tinutuan (Bubur Manado)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/ee2936d219a4669e/680x482cq70/tinutuan-bubur-manado-foto-resep-utama.jpg" alt="Tinutuan (Bubur Manado)" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, I will show you a way to prepare a special dish, tinutuan (bubur manado). It is one of my favorites food recipes. This time, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Tinutuan (Bubur Manado) is one of the most popular of recent trending meals in the world. It's appreciated by millions daily. It's simple, it's quick, it tastes delicious. They're fine and they look wonderful. Tinutuan (Bubur Manado) is something which I've loved my entire life.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we have to first prepare a few components. You can have tinutuan (bubur manado) using 15 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Tinutuan (Bubur Manado):</h3>

<ol>
	
		<li>{Take  of Beras 1½ cup (nantinya akan jadi bubur). </li>
	
		<li>{Prepare  of Jagung (serut kasar). </li>
	
		<li>{Make ready  of Kangkung (bersihkan + pilih daun saja). </li>
	
		<li>{Get  of Labu kuning (potong dadu besar²). </li>
	
		<li>{Get  of Kemangi. </li>
	
		<li>{Make ready  of Sereh (geprek kasar). </li>
	
		<li>{Make ready  of Garam. </li>
	
		<li>{Get  of Kaldu jamur bubuk. </li>
	
		<li>{Get  of Air. </li>
	
		<li>{Prepare  of Bahan Sambel. </li>
	
		<li>{Get  of Beberapa cabe rawit (sesuai pedas yg diinginkan). </li>
	
		<li>{Take 2 siung of bawang merah &amp; putih. </li>
	
		<li>{Get 1 buah of tomat besar. </li>
	
		<li>{Get  of Minyak (untuk menumis). </li>
	
		<li>{Get  of Garam &amp; gula. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Tinutuan (Bubur Manado):</h3>

<ol>
	
		<li>
			Masak beras bersama sereg dengan air yang agak banyak. Tujuannya agar membuat beras menjadi bubur..
			
			
		</li>
	
		<li>
			Masak hingga beras menjadi nasi lembek (sambil tambahkan air sedikit² agar tidak gosong).
			
			
		</li>
	
		<li>
			Setelah nasi mulai lembek, masukkan labu kuning &amp; jagung sambil tambahkan air sedikit. Masak hingga ½ matang. Ditahap ini mulai masukkan garam &amp; kaldu jamur bubuk hingga rasa enak..
			
			
		</li>
	
		<li>
			Setelah bumbu sudah pas dan jagung serta labu mulai matang, masukkan kangkung &amp; kemangi. Lalu masak hingga sayur matang. Siap disajikan.
			
			
		</li>
	
		<li>
			Membuat sambal: ulek seluruh bahan (kecuali minyak) lalu coba rasa. Setelah itu, tumis sebentar dengan minyak. Sajikan bersama tinutuan hangat..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this special food tinutuan (bubur manado) recipe. Thanks so much for reading. I am sure that you can make this at home. There is gonna be more interesting food at home recipes coming up. Remember to save this page in your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
