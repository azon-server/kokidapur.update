---
description: "Recipe of Favorite Bubur Kacang Hijau Kental Saus Santan"
title: "Recipe of Favorite Bubur Kacang Hijau Kental Saus Santan"
slug: 42-recipe-of-favorite-bubur-kacang-hijau-kental-saus-santan

<p>
	<strong>Bubur Kacang Hijau Kental Saus Santan</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/9523e93265d846ce/680x482cq70/bubur-kacang-hijau-kental-saus-santan-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental Saus Santan" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, I will show you a way to make a distinctive dish, bubur kacang hijau kental saus santan. It is one of my favorites food recipes. This time, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Hijau Kental Saus Santan is one of the most popular of current trending meals on earth. It is enjoyed by millions daily. It's simple, it's quick, it tastes yummy. Bubur Kacang Hijau Kental Saus Santan is something that I have loved my entire life. They are nice and they look wonderful.
</p>

<p>
To get started with this particular recipe, we must first prepare a few components. You can have bubur kacang hijau kental saus santan using 11 ingredients and 6 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental Saus Santan:</h3>

<ol>
	
		<li>{Take  of Bahan Bubur :. </li>
	
		<li>{Make ready 200 gram of kacang hijau. </li>
	
		<li>{Make ready 2 lembar of daun pandan. </li>
	
		<li>{Make ready 1 cm of jahe, geprek (optional). </li>
	
		<li>{Prepare 150 gram of gula pasir/gula merah. </li>
	
		<li>{Make ready 2 sdm of tepung maizena, larutkan dengan sedikit air. </li>
	
		<li>{Get 1000 ml of air untuk merebus. </li>
	
		<li>{Get  of Bahan Saus Santan :. </li>
	
		<li>{Take 200 ml of santan kekentalan sedang. </li>
	
		<li>{Get 1 lembar of daun pandan, sobek2. </li>
	
		<li>{Make ready 1/2 sdt of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Hijau Kental Saus Santan:</h3>

<ol>
	
		<li>
			Rendam kacang hijau selama seharian, lalu cuci bersih..
			
			
		</li>
	
		<li>
			Masukkan air ke panci. Lalu masukkan kacang hijau, daun pandan dan jahe geprek. Rebus hingga air agak menyusut..
			
			
		</li>
	
		<li>
			Masukkan gula pasir. Aduk rata..
			
			
		</li>
	
		<li>
			Terakhir masukkan larutan tepung maizena. Aduk dan masak hingga mengental. Matikan api..
			
			
		</li>
	
		<li>
			Buat sausnya, campur semua bahan. Rebus hingga mendidih. Aduk supaya santan tidak pecah ya..
			
			
		</li>
	
		<li>
			Sajikan bubur kacang hijau dengan disiram saus santan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur kacang hijau kental saus santan recipe. Thanks so much for reading. I am confident that you can make this at home. There's gonna be interesting food in home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
