---
description: "Steps to Prepare Quick Bubur kacang ijo kental"
title: "Steps to Prepare Quick Bubur kacang ijo kental"
slug: 15-steps-to-prepare-quick-bubur-kacang-ijo-kental

<p>
	<strong>Bubur kacang ijo kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/cf4466b2def7f1a2/680x482cq70/bubur-kacang-ijo-kental-foto-resep-utama.jpg" alt="Bubur kacang ijo kental" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an incredible day today. Today, I will show you a way to prepare a special dish, bubur kacang ijo kental. One of my favorites food recipes. For mine, I'm gonna make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang ijo kental is one of the most well liked of current trending meals on earth. It's enjoyed by millions every day. It is easy, it's quick, it tastes yummy. Bubur kacang ijo kental is something that I've loved my entire life. They're fine and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we have to first prepare a few components. You can have bubur kacang ijo kental using 6 ingredients and 6 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo kental:</h3>

<ol>
	
		<li>{Get secukupnya of Kacang hijau. </li>
	
		<li>{Take 500 gram of Gula merah. </li>
	
		<li>{Take 1 sdm of Gula pasir. </li>
	
		<li>{Make ready 1/2 sdt of Garam. </li>
	
		<li>{Take 500 ml of Air. </li>
	
		<li>{Prepare 3 sdm of Santan kara. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo kental:</h3>

<ol>
	
		<li>
			Bila.
			
			
		</li>
	
		<li>
			Ingin cepat lembut sebaiknya rendam kacang hijau semalaman dlu.
			
			
		</li>
	
		<li>
			Masukkan kacang hijau yg sdh direbus terlebih dahulu ke air 500ml yg sdh mendidih (jika suka byk kuah boleh ditambah sesukanya dan bahan bs menyesuaikan).
			
			
		</li>
	
		<li>
			Tunggu kacang hijau pecah dan lembut baru masukan semua bahan2.
			
			
		</li>
	
		<li>
			Koreksi rasa bila sdh pas aduk sampai kacang hijau benar2 lembut dan mengental.
			
			
		</li>
	
		<li>
			Proses pengentalan memang agak lama tp klo saya lbih suka yg kental.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur kacang ijo kental recipe. Thanks so much for reading. I am sure you will make this at home. There is gonna be interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
