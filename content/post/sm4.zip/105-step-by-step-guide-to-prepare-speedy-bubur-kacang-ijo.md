---
description: "Step-by-Step Guide to Prepare Speedy Bubur Kacang Ijo"
title: "Step-by-Step Guide to Prepare Speedy Bubur Kacang Ijo"
slug: 105-step-by-step-guide-to-prepare-speedy-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/355adffa650720a0/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you are having an amazing day today. Today, I'm gonna show you how to make a special dish, bubur kacang ijo. It is one of my favorites. This time, I will make it a bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo is one of the most favored of recent trending meals in the world. It's easy, it is quick, it tastes delicious. It's appreciated by millions every day. Bubur Kacang Ijo is something that I've loved my entire life. They are nice and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we must prepare a few ingredients. You can cook bubur kacang ijo using 12 ingredients and 2 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Prepare 500 gr of kacang hijau, rendam 1 jam, umi 250gr. </li>
	
		<li>{Take 100 gr of ketan, umi skip krn ga punya. </li>
	
		<li>{Make ready 250 gr of gula merah, umi 1/4 batok. </li>
	
		<li>{Prepare 2 lembar of daun pandan. </li>
	
		<li>{Prepare 1 sdt of garam. </li>
	
		<li>{Make ready Secukupnya of gula. </li>
	
		<li>{Prepare 1 sdt of vanilli. </li>
	
		<li>{Make ready  of Kuah:. </li>
	
		<li>{Get 1,5 l of Santan, umi 1 bungkus santan kara kecil. </li>
	
		<li>{Take 2 lbr of daun pandan. </li>
	
		<li>{Get 1 cangkir of air. </li>
	
		<li>{Make ready Sejumput of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Rebus kacang hijau bersama daun pandan, jika kurang empuk tambahkan air, begitu seterusnya hingga keempukan yang diinginkan. Setelah empuk bubuhi gula merah, garam, vanili dan gula pasir. Cek rasa. Jika sudah dapat tingkat kemanisan yang diinginkan, tambahkan larutan 1 sdm maizena dengan 1/2 cangkir air, aduk hingga kental, matikan api..
			
			
		</li>
	
		<li>
			Buat kuah santan. Aduk 1 sachet santan instan dengan air, daun pandan dan garam. Cek rasa, umi suka lebih asin dari rata2 santan diluaran. Suka2 yaa.. nah santan ini ditaruh diatas bubur kacang hijau tadi..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food bubur kacang ijo recipe. Thank you very much for reading. I'm confident that you will make this at home. There is gonna be more interesting food in home recipes coming up. Remember to bookmark this page in your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
