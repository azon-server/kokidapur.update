---
description: "Simple Way to Make Any-night-of-the-week Bubur manado sambal roa"
title: "Simple Way to Make Any-night-of-the-week Bubur manado sambal roa"
slug: 281-simple-way-to-make-any-night-of-the-week-bubur-manado-sambal-roa

<p>
	<strong>Bubur manado sambal roa</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/0154e1c01d722511/680x482cq70/bubur-manado-sambal-roa-foto-resep-utama.jpg" alt="Bubur manado sambal roa" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's me, Dave, welcome to my recipe site. Today, we're going to make a distinctive dish, bubur manado sambal roa. One of my favorites food recipes. For mine, I'm gonna make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur manado sambal roa is one of the most popular of current trending foods in the world. It's appreciated by millions daily. It is easy, it's quick, it tastes delicious. They're nice and they look wonderful. Bubur manado sambal roa is something which I have loved my entire life.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we must first prepare a few components. You can have bubur manado sambal roa using 17 ingredients and 8 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur manado sambal roa:</h3>

<ol>
	
		<li>{Get 3 buah of ikan roa ambil dagingnya blender. </li>
	
		<li>{Take 10 buah of cabe rawit. </li>
	
		<li>{Make ready 10 buah of cabe merah kriting. </li>
	
		<li>{Make ready 4 buah of bawang merah. </li>
	
		<li>{Get 3 siung of bawang putih. </li>
	
		<li>{Make ready  of Minyak unt menumis. </li>
	
		<li>{Make ready 1 of gelas takaran beras (tdk full). </li>
	
		<li>{Take 2 btg of sereh. </li>
	
		<li>{Take 1 lembar of daun kunyit. </li>
	
		<li>{Get 1 lembar of daun pandan. </li>
	
		<li>{Prepare 2 lt of air. </li>
	
		<li>{Make ready  of Garam sckpnya. </li>
	
		<li>{Take secukupnya of Bayam + kangkung. </li>
	
		<li>{Take 1 buah of jagung uk sedang pipil. </li>
	
		<li>{Prepare 1 buah of ubi putih. </li>
	
		<li>{Make ready secukupnya of Kemangi. </li>
	
		<li>{Get  of Sambaal roa :. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur manado sambal roa:</h3>

<ol>
	
		<li>
			Bubur :.
			
			
		</li>
	
		<li>
			Masak beras dgn pandan, daun kunyit, serah hingga menjadi bubur masukkan jagung dan ubi rebus yg sdh dipotong potong masukkan garam masak bubur sampai matang sempurna masukkan kemangi.
			
			
		</li>
	
		<li>
			Rebus kangkung dan bayam sebentar sisihkan.
			
			
		</li>
	
		<li>
			Sambal roa :.
			
			
		</li>
	
		<li>
			Blender semua bumbu tumis dengan api sedang hingga harum.
			
			
		</li>
	
		<li>
			Masukkan ikan roa dan gargul masak hingga matang.
			
			
		</li>
	
		<li>
			Unt tambahan gorengnikan asin sesuai selera.
			
			
		</li>
	
		<li>
			Campur semua sayuran kedalam bubur aduk rata bubur manado siap disantap bersama sambel roa dan ikan asin... enak dimakan selagi panas.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this exceptional food bubur manado sambal roa recipe. Thanks so much for reading. I'm sure you will make this at home. There's gonna be more interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
