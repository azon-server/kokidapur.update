---
description: "Recipe of Favorite Bubur Kacang Ijo &amp;amp; Ubi"
title: "Recipe of Favorite Bubur Kacang Ijo &amp;amp; Ubi"
slug: 126-recipe-of-favorite-bubur-kacang-ijo-and-amp-ubi

<p>
	<strong>Bubur Kacang Ijo &amp; Ubi</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/ce3730d624e465ff/680x482cq70/bubur-kacang-ijo-ubi-foto-resep-utama.jpg" alt="Bubur Kacang Ijo &amp; Ubi" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an incredible day today. Today, we're going to make a special dish, bubur kacang ijo &amp; ubi. It is one of my favorites food recipes. For mine, I will make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo &amp; Ubi is one of the most favored of recent trending foods in the world. It's easy, it is quick, it tastes yummy. It's appreciated by millions every day. Bubur Kacang Ijo &amp; Ubi is something which I have loved my entire life. They are nice and they look wonderful.
</p>

<p>
To begin with this recipe, we must prepare a few ingredients. You can have bubur kacang ijo &amp; ubi using 8 ingredients and 7 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo &amp; Ubi:</h3>

<ol>
	
		<li>{Get 2 Ons of Kacang Ijo. </li>
	
		<li>{Take 1 Buah of Ubi Jalar Orange potong kotak. </li>
	
		<li>{Make ready  of Gula Merah. </li>
	
		<li>{Prepare  of Gula Putih. </li>
	
		<li>{Take 100 ml of Santan kental. </li>
	
		<li>{Get Seruas of Jahe. </li>
	
		<li>{Make ready sesuai selera of Garam. </li>
	
		<li>{Take 2 lembar of Daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo &amp; Ubi:</h3>

<ol>
	
		<li>
			Bahan - Bahan :.
			
			
		</li>
	
		<li>
			Rebus kacang ijo dg air 800 ml sampai kacang ijo pecah,kemudian masuk kan jahe yg telah digeprek.
			
			
		</li>
	
		<li>
			Masukan ubi jalar rebus kembali hingga agak lembek.
			
			
		</li>
	
		<li>
			Masuk kan santan aduk2 jng sampe santan nya pecah.
			
			
		</li>
	
		<li>
			Masukan gula merah,gula putih,garam tes rasa sesuai selera.
			
			
		</li>
	
		<li>
			Terakhir masukan daun pandan agar harum.
			
			
		</li>
	
		<li>
			Selesai bisa disantap saat hangat atau dingin.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this exceptional food bubur kacang ijo &amp; ubi recipe. Thank you very much for reading. I am confident you will make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
