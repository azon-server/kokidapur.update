---
description: "Step-by-Step Guide to Prepare Super Quick Homemade Bubur kacang ijo kental"
title: "Step-by-Step Guide to Prepare Super Quick Homemade Bubur kacang ijo kental"
slug: 14-step-by-step-guide-to-prepare-super-quick-homemade-bubur-kacang-ijo-kental

<p>
	<strong>Bubur kacang ijo kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/dd598ecae50e70fc/680x482cq70/bubur-kacang-ijo-kental-foto-resep-utama.jpg" alt="Bubur kacang ijo kental" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you are having an incredible day today. Today, we're going to make a distinctive dish, bubur kacang ijo kental. It is one of my favorites food recipes. This time, I am going to make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo kental is one of the most favored of current trending meals in the world. It's simple, it's fast, it tastes yummy. It's appreciated by millions every day. They're nice and they look wonderful. Bubur kacang ijo kental is something which I have loved my whole life.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we have to prepare a few ingredients. You can cook bubur kacang ijo kental using 13 ingredients and 6 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo kental:</h3>

<ol>
	
		<li>{Prepare  of Bahan bubur :. </li>
	
		<li>{Get 250 gr of kacang ijo. </li>
	
		<li>{Make ready 1 ltr of air. </li>
	
		<li>{Prepare 100 gr of gula pasir/gula merah. </li>
	
		<li>{Get 1/2 sdt of garam. </li>
	
		<li>{Prepare 2 of lmbar daun pandan. </li>
	
		<li>{Take  of Pengental :. </li>
	
		<li>{Make ready 100 gr of tapioca + 200 ml air. </li>
	
		<li>{Make ready  of Bahan kuah santan :. </li>
	
		<li>{Make ready 1 bgkus of kara 65 ml. </li>
	
		<li>{Make ready 500 ml of air. </li>
	
		<li>{Get 1/2 sdt of garam. </li>
	
		<li>{Take 1 ikat of daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo kental:</h3>

<ol>
	
		<li>
			Rendam kacang ijo 6 jm/sharian, lalu cuci sampai bersih.
			
			
		</li>
	
		<li>
			Didihkan air di panci, masukkan kacang hijau lalu tutp pancinya dan masak ±10 menit, lalu matikan apinya dan diamkan 30 menit.
			
			
		</li>
	
		<li>
			Setelah itu nyalakan api lagi, masukkan gula, tambahkan garam, aduk rata masak sampai air mendidih.
			
			
		</li>
	
		<li>
			Larutkan tepung sagu dg sdkit air matang,masukkn k dlm panci smbil d aduk cepat agar tdk mnggumpal,.
			
			
		</li>
	
		<li>
			Tambahkan daun pandan, aduk terus sampai matang meletup-letup.
			
			
		</li>
	
		<li>
			Kuah bubur : masak santan dg sgelas air, tambahkan garam, api kecil, masukkan pandan, tunggu mndidih, angkat sajikan dg bubur....
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this special food bubur kacang ijo kental recipe. Thank you very much for your time. I am sure you will make this at home. There's gonna be more interesting food in home recipes coming up. Don't forget to save this page in your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
