---
description: "Simple Way to Make Perfect Bubur kacang ijo durian"
title: "Simple Way to Make Perfect Bubur kacang ijo durian"
slug: 70-simple-way-to-make-perfect-bubur-kacang-ijo-durian

<p>
	<strong>Bubur kacang ijo durian</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/50debcd848562be1/680x482cq70/bubur-kacang-ijo-durian-foto-resep-utama.jpg" alt="Bubur kacang ijo durian" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you're having an amazing day today. Today, we're going to prepare a distinctive dish, bubur kacang ijo durian. One of my favorites. This time, I am going to make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo durian is one of the most popular of recent trending foods on earth. It is appreciated by millions daily. It's simple, it's fast, it tastes yummy. Bubur kacang ijo durian is something which I've loved my whole life. They are nice and they look wonderful.
</p>

<p>
To begin with this particular recipe, we must prepare a few ingredients. You can cook bubur kacang ijo durian using 8 ingredients and 8 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo durian:</h3>

<ol>
	
		<li>{Take 250 gr of kacang ijo. </li>
	
		<li>{Prepare 250 gr of gula merah. </li>
	
		<li>{Make ready 5 sendok makan of gula pasir. </li>
	
		<li>{Make ready 2 sachset of susu kental manis. </li>
	
		<li>{Prepare  of Jahe. </li>
	
		<li>{Take 1 sachet of santan kara siap pakai. </li>
	
		<li>{Make ready  of Durian. </li>
	
		<li>{Make ready  of Air kurang lebih 1L karna merebus kacangngmya harus banyak air. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo durian:</h3>

<ol>
	
		<li>
			Rebus kacang dengan air +-1L banyak karna merebusnya lama dan harus banyak air agar matang merata, kalo gamau boros air bisa juga kacang d rendam air biasa selama 1 malam atau 5 jam kalo bunda pakai presto bisa lebih cepat juga tapi saya pakai panci biasa.
			
			
		</li>
	
		<li>
			Jika kacang sudah matang merata pastikan masih ada airnya jika sudah surut bisa d tambahkan lagi air.
			
			
		</li>
	
		<li>
			Masukan jahe, gula merah, gula pasir.
			
			
		</li>
	
		<li>
			Tunggu 5 menit sampai gula hancur dan menyatu dengan air kemudian masukan susu kental manis dan santan siap pakai.
			
			
		</li>
	
		<li>
			Aduk aduk agar santan tidak pecah jika suka kental bisa ditambahkan 1 sachet santan lagi atau di tambahkan tepung meizena,.
			
			
		</li>
	
		<li>
			Tambahkan durian tidak apa dengan bijinya nanti pisah sendiri..
			
			
		</li>
	
		<li>
			Jika santan sudah matang matikan api.
			
			
		</li>
	
		<li>
			Bubur kacang ijo siap dihidangkan untuk vidio memasaknm ada d chanel youtubeku d intip yaa.. jangan lupa like share and subscribe ya bund 🙏☺️.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this special food bubur kacang ijo durian recipe. Thanks so much for your time. I am confident that you can make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
