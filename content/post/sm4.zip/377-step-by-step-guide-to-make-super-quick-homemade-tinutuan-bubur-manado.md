---
description: "Step-by-Step Guide to Make Super Quick Homemade Tinutuan/Bubur Manado"
title: "Step-by-Step Guide to Make Super Quick Homemade Tinutuan/Bubur Manado"
slug: 377-step-by-step-guide-to-make-super-quick-homemade-tinutuan-bubur-manado

<p>
	<strong>Tinutuan/Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/64add63e706a1337/680x482cq70/tinutuanbubur-manado-foto-resep-utama.jpg" alt="Tinutuan/Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Drew, welcome to my recipe site. Today, we're going to make a distinctive dish, tinutuan/bubur manado. One of my favorites. For mine, I am going to make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Tinutuan/Bubur Manado is one of the most favored of recent trending foods on earth. It's easy, it's quick, it tastes yummy. It is enjoyed by millions every day. They are nice and they look fantastic. Tinutuan/Bubur Manado is something that I have loved my whole life.
</p>

<p>
To begin with this particular recipe, we have to first prepare a few components. You can have tinutuan/bubur manado using 11 ingredients and 5 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Tinutuan/Bubur Manado:</h3>

<ol>
	
		<li>{Get 1/4 of labu kuning, potong kotak kecil2. </li>
	
		<li>{Make ready 4 potong of singkong, bersihkan. </li>
	
		<li>{Make ready 1 ikat of bayam, bersihkan. </li>
	
		<li>{Prepare 1 ikat of kangkung, bersihkan. </li>
	
		<li>{Take 1 ikat of gedi, bersihkan. </li>
	
		<li>{Make ready 1 ikat of kemangi, bersihkan. </li>
	
		<li>{Get 2 biji of jagung, serut. </li>
	
		<li>{Get 1 batang of sereh, memarkan. </li>
	
		<li>{Make ready 1 cup of beras, cuci bersih. </li>
	
		<li>{Prepare  of Garam. </li>
	
		<li>{Get  of Gula. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Tinutuan/Bubur Manado:</h3>

<ol>
	
		<li>
			Masak beras dengan ukuran air 3-4 kali lipat..
			
			
		</li>
	
		<li>
			Setelah mendidih, sudah menjadi bubur, tambahkan sereh, jagung, singkong dan labu, sambil aduk sesekali..
			
			
		</li>
	
		<li>
			Setelah labu dan singkong matang dam lembut. Koreksi rasa dengan garam dan gula..
			
			
		</li>
	
		<li>
			Tambahkan kangkung, gedi dan bayam, sambil diaduk sesekali..
			
			
		</li>
	
		<li>
			Setelah sayur matang, tambahkan kemangi. Aduk rata. Tinutuan siap disantap..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this special food tinutuan/bubur manado recipe. Thank you very much for your time. I am sure you will make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to save this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
