---
description: "Recipe of Perfect Bubur kacang Hijau Kental Masakan Rumahan Simpel Enaaakkk 🤤"
title: "Recipe of Perfect Bubur kacang Hijau Kental Masakan Rumahan Simpel Enaaakkk 🤤"
slug: 47-recipe-of-perfect-bubur-kacang-hijau-kental-masakan-rumahan-simpel-enaaakkk

<p>
	<strong>Bubur kacang Hijau Kental Masakan Rumahan Simpel Enaaakkk 🤤</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/989c54c127a4a8d4/680x482cq70/bubur-kacang-hijau-kental-masakan-rumahan-simpel-enaaakkk-🤤-foto-resep-utama.jpg" alt="Bubur kacang Hijau Kental Masakan Rumahan Simpel Enaaakkk 🤤" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you're having an incredible day today. Today, I will show you a way to prepare a distinctive dish, bubur kacang hijau kental masakan rumahan simpel enaaakkk 🤤. One of my favorites food recipes. This time, I will make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang Hijau Kental Masakan Rumahan Simpel Enaaakkk 🤤 is one of the most well liked of recent trending foods on earth. It is simple, it's quick, it tastes yummy. It's appreciated by millions every day. They're nice and they look wonderful. Bubur kacang Hijau Kental Masakan Rumahan Simpel Enaaakkk 🤤 is something that I've loved my whole life.
</p>

<p>
To get started with this recipe, we must first prepare a few ingredients. You can have bubur kacang hijau kental masakan rumahan simpel enaaakkk 🤤 using 8 ingredients and 6 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang Hijau Kental Masakan Rumahan Simpel Enaaakkk 🤤:</h3>

<ol>
	
		<li>{Get 250 gr of kacang hijau. </li>
	
		<li>{Get 200 gr of gula aren. </li>
	
		<li>{Take 5 sdm of gula putih. </li>
	
		<li>{Prepare 1 sdt of garam. </li>
	
		<li>{Make ready 1 bungkus of santan kara. </li>
	
		<li>{Get 2 lembar of daun pandan. </li>
	
		<li>{Prepare 2 ruas of jahe (saya di geprek aja). </li>
	
		<li>{Make ready  of 5 sdm aci/tapioka. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang Hijau Kental Masakan Rumahan Simpel Enaaakkk 🤤:</h3>

<ol>
	
		<li>
			Rendam kacang hijau dengan air (saya di rendam semalaman).
			
			
		</li>
	
		<li>
			Rebus kacang hijau dengan 750 ml air dengan gula aren yang disisir, gula putih, jahe, garam, dan daun pandan..
			
			
		</li>
	
		<li>
			Setelah mendidih masukan santan kara, aduk hingga rata.
			
			
		</li>
	
		<li>
			Caurkan aci dengan air. Ingat larutan aci harus benar2 cair, agar tidak menggumpal!.
			
			
		</li>
	
		<li>
			Masukan larutan aci ke dalam panci, aduk hingga merata dan mengental..
			
			
		</li>
	
		<li>
			Bubur kacang hijau kental siap dinikmati 🤤🤤.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this exceptional food bubur kacang hijau kental masakan rumahan simpel enaaakkk 🤤 recipe. Thank you very much for your time. I'm sure you will make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to save this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
