---
description: "How to Prepare Speedy Bubur Manado Ala Mertua"
title: "How to Prepare Speedy Bubur Manado Ala Mertua"
slug: 356-how-to-prepare-speedy-bubur-manado-ala-mertua

<p>
	<strong>Bubur Manado Ala Mertua</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/fb6404f961e0d319/680x482cq70/bubur-manado-ala-mertua-foto-resep-utama.jpg" alt="Bubur Manado Ala Mertua" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's Brad, welcome to my recipe site. Today, I will show you a way to make a distinctive dish, bubur manado ala mertua. It is one of my favorites food recipes. For mine, I am going to make it a bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur Manado Ala Mertua is one of the most well liked of current trending meals on earth. It's simple, it's fast, it tastes yummy. It is appreciated by millions daily. They're nice and they look fantastic. Bubur Manado Ala Mertua is something which I've loved my whole life.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we must prepare a few ingredients. You can cook bubur manado ala mertua using 11 ingredients and 4 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Manado Ala Mertua:</h3>

<ol>
	
		<li>{Get 1/2 Kg of Beras. </li>
	
		<li>{Take 2 buah of wortel. </li>
	
		<li>{Get 1 buah of jagung. </li>
	
		<li>{Prepare 1 ikat of kangkung (ikatan sedang). </li>
	
		<li>{Prepare 1,5 Lt of Air Mineral. </li>
	
		<li>{Get Secukupnya of minyak (untuk menumis). </li>
	
		<li>{Get  of Bumbu Halus. </li>
	
		<li>{Prepare 4 Siung of bawang putih. </li>
	
		<li>{Get 6 Siung of bawang merah. </li>
	
		<li>{Make ready Secukupnya of ketumbar, garam/penyedap rasa. </li>
	
		<li>{Take 1 iris of kecil kunyit. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado Ala Mertua:</h3>

<ol>
	
		<li>
			Siapkan seluruh bahan. Cuci bersih beras, iris jagung &amp; potong wortel kecil&#34;..
			
			
		</li>
	
		<li>
			Panaskan air mineral &amp; masukan beras wortel &amp; jagung masak hingga mendidih..
			
			
		</li>
	
		<li>
			Haluskan bumbu (Saya memakaj ulekan) lalu tumis hingga harum..
			
			
		</li>
	
		<li>
			Setelah air dalam beras mengurang masukan kangkung yang telah dipotong lalu masukan bumbu halusnya aduk hingga rata &amp; koreksi rasa. Air dalam bubur dapat disesuaikan sesuai selera yahh. Siap disajikan. Tambahkan Sambal &amp; ikan asin agar lebih nikmat..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this exceptional food bubur manado ala mertua recipe. Thanks so much for reading. I'm confident that you will make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
