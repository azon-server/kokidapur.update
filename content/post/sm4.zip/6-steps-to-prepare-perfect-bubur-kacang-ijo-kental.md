---
description: "Steps to Prepare Perfect Bubur kacang ijo kental"
title: "Steps to Prepare Perfect Bubur kacang ijo kental"
slug: 6-steps-to-prepare-perfect-bubur-kacang-ijo-kental

<p>
	<strong>Bubur kacang ijo kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/7539545586d1ec9f/680x482cq70/bubur-kacang-ijo-kental-foto-resep-utama.jpg" alt="Bubur kacang ijo kental" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is Brad, welcome to our recipe page. Today, I will show you a way to make a distinctive dish, bubur kacang ijo kental. One of my favorites. This time, I am going to make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo kental is one of the most favored of recent trending foods in the world. It is enjoyed by millions daily. It is simple, it is quick, it tastes yummy. Bubur kacang ijo kental is something which I have loved my entire life. They're fine and they look fantastic.
</p>

<p>
To get started with this recipe, we have to prepare a few ingredients. You can cook bubur kacang ijo kental using 8 ingredients and 6 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo kental:</h3>

<ol>
	
		<li>{Get Segenggam of kacang hijau. </li>
	
		<li>{Get 1/4 batok of gula merah, iris tipis. </li>
	
		<li>{Prepare 1 sdm of gula pasir. </li>
	
		<li>{Prepare 50 ml of santan kara. </li>
	
		<li>{Prepare 1 sdm of creamer. </li>
	
		<li>{Make ready 1 sdm of skm. </li>
	
		<li>{Get 2 sdm of maizena. </li>
	
		<li>{Prepare Sejumput of garam dan vanili. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo kental:</h3>

<ol>
	
		<li>
			Rebus kacang hijau sampai setengah mekar. Tutup wadah. Kalau mau cepat, cukup rendam kacang hijau semalaman.
			
			
		</li>
	
		<li>
			Jika sudah setengah mekar, masukkan gula merah. Tambah kan terus air jika memang air sampai kacang hijau betul2 mekar. Tambahkan daun pandan jika ingin tercium harum.
			
			
		</li>
	
		<li>
			Setelah mekar, dan terlihat kacang hijau mulai mekar dan lunak, masukkan gula pasir.
			
			
		</li>
	
		<li>
			Tambahkan santan, creamer, dan skm. Sebelum melakukan tahap ini, pastikan kacang hijau sudah lunak. Aduk terus di atas api kecil agar santan tidak pecah.
			
			
		</li>
	
		<li>
			Tambahkan garam dan sedikit vanili.
			
			
		</li>
	
		<li>
			Koreksi rasa. Apabila dianggap sudah pas, dan kacang hijau betul2 lunak, tambahkan maizena yang sudah di larutkan. Aduk terus smpai mendidih..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this special food bubur kacang ijo kental recipe. Thanks so much for reading. I'm sure you can make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
