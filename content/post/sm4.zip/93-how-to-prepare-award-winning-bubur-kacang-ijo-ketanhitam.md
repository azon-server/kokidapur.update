---
description: "How to Prepare Award-winning BUBUR KACANG IJO KETANHITAM"
title: "How to Prepare Award-winning BUBUR KACANG IJO KETANHITAM"
slug: 93-how-to-prepare-award-winning-bubur-kacang-ijo-ketanhitam

<p>
	<strong>BUBUR KACANG IJO KETANHITAM</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/426a6713084fa246/680x482cq70/bubur-kacang-ijo-ketanhitam-foto-resep-utama.jpg" alt="BUBUR KACANG IJO KETANHITAM" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an incredible day today. Today, I will show you a way to make a distinctive dish, bubur kacang ijo ketanhitam. One of my favorites. This time, I am going to make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	BUBUR KACANG IJO KETANHITAM is one of the most favored of recent trending foods on earth. It is simple, it is fast, it tastes yummy. It's appreciated by millions daily. They're fine and they look fantastic. BUBUR KACANG IJO KETANHITAM is something that I have loved my whole life.
</p>

<p>
To begin with this recipe, we must prepare a few ingredients. You can cook bubur kacang ijo ketanhitam using 7 ingredients and 4 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make BUBUR KACANG IJO KETANHITAM:</h3>

<ol>
	
		<li>{Prepare 250 gr of kacang ijo. </li>
	
		<li>{Make ready 250 gr of beras ketan hitam. </li>
	
		<li>{Prepare 200 gr of gulpas./selara. </li>
	
		<li>{Prepare 250 ml of santan kental. </li>
	
		<li>{Make ready 2 btg of d.pandan. </li>
	
		<li>{Get 2 ltr of setengak air. </li>
	
		<li>{Get 3 sdt of garem/selera. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make BUBUR KACANG IJO KETANHITAM:</h3>

<ol>
	
		<li>
			Pertama menyiapkan bahan yg mau di olah,beras ketan divuci bersih lalu direndam selam 30 mnt lebih jugak gk pp,panci dikasih air 11/2ltr sudah panas kacang ijo yg sudah sicuci dimasukan dan situtup selama 8-10mnt api matikan kira&#34; tuk menghemat gas dan mempercepat lunaknya kacang ijo 20 -25 mnt api dinyalakan.
			
			
		</li>
	
		<li>
			Sambil menunggu api dimati masak sisa air dr 3ktr dipanci lainya dan sudah mendidih tentunya beras ketan sudah dicucu bersih dimasukan ditambah 1sdt garem 1bth d.pandan disobek sobek terus didimpulkan sesekali diaduk agar gaklengket setelah air tinggal sedikit api dikecilkan dan bawah panci dialasin seng/teplon supaya nasi ketanya gk hangus sesekali dibuka diaduk kalau sudah saat api dimatikan ditutup lagi.
			
			
		</li>
	
		<li>
			Rebusan kacang ijo selama dimatikan 20 mnt api dinyala kan lagi 5 -8 mnt kacang ijo sudah empuk kemudian ditambah garem d.pandan yg disimpulkan gulpas santan diaduk aduk supaya santan gk pecah jangan lupa kireksi raaanya kalau sudah yg diinginkan api dimatikan selesai buburnya sudah matang dan liwet ketannya.
			
			
		</li>
	
		<li>
			Untuk penyajianya ambil mangkok kemudian masukan bubur kacang dan ketan hitam kemudian dinikmati kebetul cuacanya dingin dibarengi hujan jadi menikmati rasanyan gurih hemmmm mantap trimakasih..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this exceptional food bubur kacang ijo ketanhitam recipe. Thanks so much for reading. I am confident that you will make this at home. There is gonna be more interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
