---
description: "Steps to Make Perfect Bubur Kacang Ijo Gula Putih"
title: "Steps to Make Perfect Bubur Kacang Ijo Gula Putih"
slug: 177-steps-to-make-perfect-bubur-kacang-ijo-gula-putih

<p>
	<strong>Bubur Kacang Ijo Gula Putih</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/b9e08b201512457d/680x482cq70/bubur-kacang-ijo-gula-putih-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Gula Putih" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, we're going to prepare a special dish, bubur kacang ijo gula putih. It is one of my favorites. For mine, I will make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo Gula Putih is one of the most well liked of recent trending foods in the world. It is easy, it's fast, it tastes yummy. It is appreciated by millions daily. They are fine and they look fantastic. Bubur Kacang Ijo Gula Putih is something which I've loved my whole life.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we must prepare a few components. You can have bubur kacang ijo gula putih using 8 ingredients and 3 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Gula Putih:</h3>

<ol>
	
		<li>{Get 1/2 kg of kacang ijo. </li>
	
		<li>{Get 600 ml of santan (tidak terlalu kental, sedang2 aja) + 400 ml air. </li>
	
		<li>{Get 400 gr of gula putih. </li>
	
		<li>{Get 3 ruas of jahe digeprek. </li>
	
		<li>{Prepare 1 batang of kayu manis (kurleb 4cm). </li>
	
		<li>{Prepare 4 helai of daun pandan. </li>
	
		<li>{Prepare 1 sdt of garam. </li>
	
		<li>{Get  of air untuk merebus kacang hijau (rebusan awal). </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo Gula Putih:</h3>

<ol>
	
		<li>
			Rendam kacang ijo sekitar 2 jam.
			
			
		</li>
	
		<li>
			Didihkan air lalu Rebus kacang hijau beri daun pandan, kayu manis, dan jahe ukuran air dikira2 asal kacang hijau terendam(kurang lebih 800ml) sepeti difoto. rebus sampai kacang hijau empuk dan air sat.
			
			
		</li>
	
		<li>
			Setelah kacang hijau empuk, tambahkan santan dan air aduk rata lalu tambahkan gula dan garam. masak hingga santan meresap pada kacang hijau. selama memasak santan harus selalu diaduk. selamat mencoba..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this exceptional food bubur kacang ijo gula putih recipe. Thanks so much for your time. I'm confident you will make this at home. There is gonna be more interesting food at home recipes coming up. Remember to save this page in your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
