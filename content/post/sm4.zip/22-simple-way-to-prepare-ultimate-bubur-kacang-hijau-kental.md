---
description: "Simple Way to Prepare Ultimate Bubur kacang hijau kental"
title: "Simple Way to Prepare Ultimate Bubur kacang hijau kental"
slug: 22-simple-way-to-prepare-ultimate-bubur-kacang-hijau-kental

<p>
	<strong>Bubur kacang hijau kental</strong>. 
	Resep Rahasia Bubur Kacang Hijau Kental Dan Enak, bubur kacang hijau, resep bubur kacang hijau, bubur kacang hijau lezat, bubur kacang ijo seperti tukang. Ada bubur ayam, bubur sumsum, bubur mutiara, bubur kacang hijau dan banyak lainnya. Bubur kacang hijau, abbreviated burjo, is a Southeast Asian sweet porridge (bubur) made from mung beans (kacang hijau), coconut milk, and palm sugar or cane sugar.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/82b009b23e9b7622/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur kacang hijau kental" style="width: 100%;">
	
	
		Mau buka puasa begini enaknya kita buat Bubur Kacang.
	
		Bahan kacang hijau kental: Membuat bubur ketan hitam Bubur kacang hijau di hidangkan selagi masih hangat, kemudian siram dengan santan gurih.
	
		Tambahkan santan kental, masak hingga kacang hijau empuk.
	
</p>
<p>
	Hello everybody, hope you're having an amazing day today. Today, I will show you a way to make a distinctive dish, bubur kacang hijau kental. One of my favorites. This time, I am going to make it a little bit unique. This will be really delicious.
</p>
	
<p>
	Resep Rahasia Bubur Kacang Hijau Kental Dan Enak, bubur kacang hijau, resep bubur kacang hijau, bubur kacang hijau lezat, bubur kacang ijo seperti tukang. Ada bubur ayam, bubur sumsum, bubur mutiara, bubur kacang hijau dan banyak lainnya. Bubur kacang hijau, abbreviated burjo, is a Southeast Asian sweet porridge (bubur) made from mung beans (kacang hijau), coconut milk, and palm sugar or cane sugar.
</p>
<p>
	Bubur kacang hijau kental is one of the most popular of current trending foods in the world. It is appreciated by millions every day. It's easy, it is quick, it tastes delicious. They are fine and they look fantastic. Bubur kacang hijau kental is something which I've loved my whole life.
</p>

<p>
To begin with this recipe, we must prepare a few ingredients. You can cook bubur kacang hijau kental using 12 ingredients and 6 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur kacang hijau kental:</h3>

<ol>
	
		<li>{Take  of Bahan :. </li>
	
		<li>{Get 1.500 ml of air ( 1.300 ml u/ mrebus kacang hijau, 200 ml u/ g merah. </li>
	
		<li>{Get 150 gr of kacang hijau (rendam selama 1 jam). </li>
	
		<li>{Make ready 2 lembar of daun pandan. </li>
	
		<li>{Make ready 170 gr of gula merah. </li>
	
		<li>{Make ready 3 sdm of tepung maizena. </li>
	
		<li>{Prepare 3 ruas of jahe. </li>
	
		<li>{Get  of Bahan santan :. </li>
	
		<li>{Get 130 ml of santan instant. </li>
	
		<li>{Take 250 ml of air. </li>
	
		<li>{Make ready 1 sdt of garam. </li>
	
		<li>{Get 2 lembar of daun pandan. </li>
	
</ol>
<p>
	
		Angkat, sajikan dalam keadaan hanggar bersama potongan roti tawar.
	
		Resep bubur kacang hijau kental baik dengan santan maupun bubur kacang hijau tanpa santan.
	
		Bubur kacang hijau termasuk dalam resep jajanan tradisional yang sangat terkenal sejak puluhan tahun silam.
	
		Bahkan sering kita lihat pedagang bubur kacang hijau keliling dengan sepeda lewat di.
	
</p>

<h3>Steps to make Bubur kacang hijau kental:</h3>

<ol>
	
		<li>
			Masak 200 ml air dan gula merah sampai larut, kemudian saring dan dinginkan.
			
			
		</li>
	
		<li>
			Bikin air santannya : campurkan semua bahan2 rebus sampai mendidih dan aduk2 jgn sampai santannya pecah.
			
			
		</li>
	
		<li>
			Didihkan air 1.300 ml, setelah itu masukan kacang hijau rebus selama 5 menit pancinya di tutup ya. Setelah itu matikan kompor jgn di buka tutup pancinya diamkan selama 30 menit. Setelah 30 menit masukan jahe dan daun pandan aduk2 sebentar nyalahkan kompornya dan rebus lagi kacang hijau selama 7 menit..
			
			
		</li>
	
		<li>
			Campur air gula merah dengan tepung maizena aduk rata..
			
			
		</li>
	
		<li>
			Setelah 7 menit tuangkan larutan gula merah dan tepung maizena kemudian aduk rata, tunggu sebentar kemudain matikan kompornya.
			
			
		</li>
	
		<li>
			Bubur kacang hijau siap di sajikan bersama santan gurih. Selamat mencoba ya👩‍🍳👩‍🍳👩‍🍳.
			
			
		</li>
	
</ol>

<p>
	
		Bubur kacang hijau termasuk sajian nikmat keluarga.
	
		Cara Membuat Bubur Kacang Hijau Ketan Hitam: Kacang hijau, rebus kacang hijau, air, dan daun pandan sampai matang dan mekar.
	
		Sisihkan. rebus beras ketan hitam bersama daun pandan.
	
		Bubur kacang hijau adalah salah satu menu sarapan atau larut malam yang populer di Indonesia.
	
		Masak bubur kacang hijau gak perlu lama-lama lho.
	
</p>

<p>
	So that's going to wrap it up for this exceptional food bubur kacang hijau kental recipe. Thank you very much for your time. I am confident you will make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
