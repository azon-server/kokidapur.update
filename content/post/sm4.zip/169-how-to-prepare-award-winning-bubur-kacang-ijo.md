---
description: "How to Prepare Award-winning Bubur kacang ijo"
title: "How to Prepare Award-winning Bubur kacang ijo"
slug: 169-how-to-prepare-award-winning-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/28e0eca58c1d7f09/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's John, welcome to my recipe site. Today, I'm gonna show you how to prepare a special dish, bubur kacang ijo. One of my favorites food recipes. For mine, I'm gonna make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo is one of the most favored of recent trending foods on earth. It is easy, it's quick, it tastes delicious. It is appreciated by millions daily. They're fine and they look fantastic. Bubur kacang ijo is something that I have loved my whole life.
</p>

<p>
To begin with this recipe, we have to first prepare a few ingredients. You can cook bubur kacang ijo using 7 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Make ready 250 gr of Kacang hijau (saya rendam semalaman). </li>
	
		<li>{Get 2 Lt of Air mineral. </li>
	
		<li>{Make ready 100 gr of Gula merah. </li>
	
		<li>{Make ready 1/2 bh of Kelapa parut. </li>
	
		<li>{Take 1 sdt of Garam. </li>
	
		<li>{Prepare 3 sdm of Tepung maizena (bisa skip). </li>
	
		<li>{Make ready 2 lembar of Daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau yang sudah direndam semalaman (biar cepat empuk atau bisa menggunakan teknik 5/30/7) kemudian rebus dengan 1 lt air sampai merekah..
			
			
		</li>
	
		<li>
			Sambil menunggu kacang hijau empuk, peras santan dengan sisa air (kira-kira sampai santan tidak kental)..
			
			
		</li>
	
		<li>
			Setelah kacang hijau empuk, masukan gula merah, santan, pandan, dan garam. Koreksi rasa. Aduk sampai mendidih..
			
			
		</li>
	
		<li>
			Terakhir saya masukan larutan tepung maizena supaya kuah santan sedikit kental, bila tidak suka tidak usah pakai..
			
			
		</li>
	
		<li>
			Aduk kembali, sampai matang dan bubur kacang hijau siap dinikmati..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this special food bubur kacang ijo recipe. Thank you very much for your time. I'm sure you will make this at home. There's gonna be more interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
