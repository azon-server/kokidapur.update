---
description: "How to Make Ultimate Bubur kacang ijo #BikinRamadanBerkesan"
title: "How to Make Ultimate Bubur kacang ijo #BikinRamadanBerkesan"
slug: 220-how-to-make-ultimate-bubur-kacang-ijo-bikinramadanberkesan

<p>
	<strong>Bubur kacang ijo #BikinRamadanBerkesan</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/153d5d89b8ef1df6/680x482cq70/bubur-kacang-ijo-bikinramadanberkesan-foto-resep-utama.jpg" alt="Bubur kacang ijo #BikinRamadanBerkesan" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Louise, welcome to our recipe site. Today, I will show you a way to prepare a distinctive dish, bubur kacang ijo #bikinramadanberkesan. It is one of my favorites food recipes. For mine, I am going to make it a bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo #BikinRamadanBerkesan is one of the most popular of recent trending meals in the world. It is simple, it's quick, it tastes delicious. It's appreciated by millions daily. Bubur kacang ijo #BikinRamadanBerkesan is something which I've loved my whole life. They are nice and they look wonderful.
</p>

<p>
To begin with this particular recipe, we must first prepare a few ingredients. You can cook bubur kacang ijo #bikinramadanberkesan using 4 ingredients and 4 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo #BikinRamadanBerkesan:</h3>

<ol>
	
		<li>{Get 250 gr of kacang ijo, rendam semalaman. </li>
	
		<li>{Make ready 200 gr of gula merah. </li>
	
		<li>{Take 1/4 butir of kelapa parut,utk santannya. </li>
	
		<li>{Make ready secukupnya of Garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo #BikinRamadanBerkesan:</h3>

<ol>
	
		<li>
			Rendam kacang ijo semalaman biar pas direbus cepat empuk, buang air rendaman.
			
			
		</li>
	
		<li>
			Rebus kacang ijo dg air 500ml sampe merekah, masukan gula merah, biarkan sampai kental (ini krna suami suka nya yg kental).
			
			
		</li>
	
		<li>
			Sambil nunggu kacang ijo kental, rebus santan kasih garam biar gurih.
			
			
		</li>
	
		<li>
			Siap buat takjil,, selamat mencoba.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this special food bubur kacang ijo #bikinramadanberkesan recipe. Thanks so much for reading. I'm sure that you can make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
