---
description: "Step-by-Step Guide to Prepare Quick Bubur kacang hijau(kental)"
title: "Step-by-Step Guide to Prepare Quick Bubur kacang hijau(kental)"
slug: 32-step-by-step-guide-to-prepare-quick-bubur-kacang-hijaukental

<p>
	<strong>Bubur kacang hijau(kental)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/004bbb9ade40d3d1/680x482cq70/bubur-kacang-hijaukental-foto-resep-utama.jpg" alt="Bubur kacang hijau(kental)" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's John, welcome to my recipe page. Today, I will show you a way to make a special dish, bubur kacang hijau(kental). One of my favorites. This time, I am going to make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang hijau(kental) is one of the most favored of recent trending meals on earth. It's enjoyed by millions daily. It's easy, it is fast, it tastes delicious. Bubur kacang hijau(kental) is something which I've loved my entire life. They are nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to first prepare a few components. You can cook bubur kacang hijau(kental) using 13 ingredients and 6 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang hijau(kental):</h3>

<ol>
	
		<li>{Make ready 1/4 kg of kacang hijau. </li>
	
		<li>{Make ready 3 keping of gula jawa. </li>
	
		<li>{Prepare 4 sdm of gula pasir. </li>
	
		<li>{Prepare 1 lmbr of daun pandan. </li>
	
		<li>{Take 1 sachet of Santan kara. </li>
	
		<li>{Take 1/4 sdt of garam. </li>
	
		<li>{Take 2 sdm of maizena larutkan dng air 50ml. </li>
	
		<li>{Prepare 1,3 L of air. </li>
	
		<li>{Prepare  of Saos Santan :. </li>
	
		<li>{Make ready 1 sachet of Santan kara. </li>
	
		<li>{Take 200 ml of air. </li>
	
		<li>{Take Sejumput of garam. </li>
	
		<li>{Make ready 1 lmbr of daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang hijau(kental):</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau,rendam..(sya rendam pagi baru dimasak sore),stlh rendam cuci bersih lagi....
			
			
		</li>
	
		<li>
			Dlm panci didihkan air smpai mendidih...kemudian masuk kan kacang hijau ne,tanbahk 1lmbr daun pandan Dan garam masak selama 5mnt..stlh 5mnt matikan api kemudian tutup panci diamkan selamat 30mnt,jangan dibuka2 ya moms.
			
			
		</li>
	
		<li>
			Stlh 30 mnt didiamkan buka tutup panci,masak kembali sembari dimasuk kan gula jawa,gula pasir sampe gula larut,kemudian masuk kan Santan nya tambahkan larutan maizena nya...masak selama 7mnt..stlh 7mnt matikan api, sisihkan.
			
			
		</li>
	
		<li>
			Kita bikin kuah Santan nya...didihkan air 200ml Masuk kan Santan Dan daun pandan,beri garam sejumput..aduk2 smpai mendidih.
			
			
		</li>
	
		<li>
			Platting 👉 dlm mangkok tuang 2centomg sayur larutan kacang hijau nya kemudian tambahkan santannya..hhmm..nyummy.. empuk tanpa hrs keluarin panci presto😂😀..enjoyyy mom&#39;s 🤗.
			
			
		</li>
	
		<li>
			Kl sya suka tambah es batu Dan roti tawar... biar tambah kenyang😁😁🤭.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur kacang hijau(kental) recipe. Thanks so much for your time. I'm confident you can make this at home. There is gonna be interesting food in home recipes coming up. Don't forget to save this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
