---
description: "Recipe of Homemade Bubur Manado"
title: "Recipe of Homemade Bubur Manado"
slug: 385-recipe-of-homemade-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/2347c256f0542068/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is me again, Dan, welcome to my recipe page. Today, I'm gonna show you how to prepare a special dish, bubur manado. One of my favorites food recipes. This time, I will make it a little bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Manado is one of the most popular of recent trending foods on earth. It is simple, it's quick, it tastes yummy. It's enjoyed by millions every day. Bubur Manado is something that I have loved my whole life. They're nice and they look fantastic.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to prepare a few ingredients. You can have bubur manado using 19 ingredients and 5 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Prepare 150 gr of Beras (1 cup). </li>
	
		<li>{Take 3 buah of Ubi rambat, potong kotak. </li>
	
		<li>{Get 1/2 buah of Labu kuning, potong kotak. </li>
	
		<li>{Make ready 1 buah of Jagung, pipil /iris. </li>
	
		<li>{Take 1 ikat of Bayam, iris. </li>
	
		<li>{Prepare 1 ikat of Kangkung, iris. </li>
	
		<li>{Take 3 ikat of Daun kemangi, petik. </li>
	
		<li>{Prepare 1 liter of Air. </li>
	
		<li>{Prepare  of Bumbu Halus. </li>
	
		<li>{Take 5 butir of Bawang merah. </li>
	
		<li>{Make ready 3 butir of bawang putih. </li>
	
		<li>{Prepare  of Bumbu Tambahan. </li>
	
		<li>{Prepare 1 batang of Serai, geprek. </li>
	
		<li>{Get 2 lembar of Daun salam. </li>
	
		<li>{Take 2 sdt of Garam. </li>
	
		<li>{Get 1 sdt of Kaldu jamur. </li>
	
		<li>{Make ready  of Bahan Pelengkap. </li>
	
		<li>{Get  of Ikan asin tipis. </li>
	
		<li>{Take  of Sambal merah (saya pake sambal bawang). </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado:</h3>

<ol>
	
		<li>
			Cuci bersih beras, masukkan ke dalam rice cooker/ smart cooker. Saya pakai smart cookeer..
			
			
		</li>
	
		<li>
			Tumis bumbu halus sampai harum..
			
			
		</li>
	
		<li>
			Masukkan labu kuning, jagung, ubi, sereh, daun salam, air dan bumbu halus. Masak selama 15 menit..
			
			
		</li>
	
		<li>
			Kemudian masukkan kangkung, bayam, daun kemangi, garam dan kaldu jamur. Masak lagi selama 5 menit..
			
			
		</li>
	
		<li>
			Siap dihidangkan dengan bahan pelengkap..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this special food bubur manado recipe. Thank you very much for reading. I'm confident that you can make this at home. There's gonna be interesting food in home recipes coming up. Don't forget to save this page in your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
