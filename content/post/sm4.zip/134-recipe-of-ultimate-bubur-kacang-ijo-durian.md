---
description: "Recipe of Ultimate Bubur Kacang Ijo Durian"
title: "Recipe of Ultimate Bubur Kacang Ijo Durian"
slug: 134-recipe-of-ultimate-bubur-kacang-ijo-durian

<p>
	<strong>Bubur Kacang Ijo Durian</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/6f794648dc007639/680x482cq70/bubur-kacang-ijo-durian-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Durian" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you're having an incredible day today. Today, I will show you a way to prepare a distinctive dish, bubur kacang ijo durian. One of my favorites. For mine, I'm gonna make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo Durian is one of the most well liked of recent trending meals on earth. It's enjoyed by millions daily. It's easy, it's fast, it tastes delicious. Bubur Kacang Ijo Durian is something that I have loved my whole life. They are fine and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we must first prepare a few components. You can cook bubur kacang ijo durian using 8 ingredients and 4 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Durian:</h3>

<ol>
	
		<li>{Make ready 250 gram of kacang ijo/hijau. </li>
	
		<li>{Take 1 buah of durian, ambil daging buah beserta bijinya. </li>
	
		<li>{Make ready 250 ml of santan kental. </li>
	
		<li>{Take 250 gram of gula merah. </li>
	
		<li>{Take secukupnya of gula pasir. </li>
	
		<li>{Get 1/2 sdt of garam. </li>
	
		<li>{Prepare 2 lembar of daun pandan. </li>
	
		<li>{Prepare secukupnya of air. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo Durian:</h3>

<ol>
	
		<li>
			Rebus kacang ijo dan daun pandan dengan air sampai kacang ijo lunak dan hancur, masukkan durian, gula merah, gula pasir dan garam, masak kembali sekitar 15 menit..
			
			
		</li>
	
		<li>
			Masukkan santan kental dan aduk rata, masak sampai mendidih kembali..
			
			
		</li>
	
		<li>
			Koreksi rasa dan bila sudah pas matikan api..
			
			
		</li>
	
		<li>
			Pindahkan kemangkok dan siap disajikan 😊.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this special food bubur kacang ijo durian recipe. Thank you very much for reading. I am sure that you will make this at home. There is gonna be more interesting food in home recipes coming up. Remember to bookmark this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
