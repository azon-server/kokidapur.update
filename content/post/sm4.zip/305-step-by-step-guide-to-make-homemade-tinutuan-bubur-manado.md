---
description: "Step-by-Step Guide to Make Homemade Tinutuan (Bubur Manado)"
title: "Step-by-Step Guide to Make Homemade Tinutuan (Bubur Manado)"
slug: 305-step-by-step-guide-to-make-homemade-tinutuan-bubur-manado

<p>
	<strong>Tinutuan (Bubur Manado)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/f248eb230b2c30fb/680x482cq70/tinutuan-bubur-manado-foto-resep-utama.jpg" alt="Tinutuan (Bubur Manado)" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, I'm gonna show you how to prepare a distinctive dish, tinutuan (bubur manado). One of my favorites food recipes. For mine, I'm gonna make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Tinutuan (Bubur Manado) is one of the most well liked of recent trending meals on earth. It is simple, it is fast, it tastes delicious. It is enjoyed by millions daily. Tinutuan (Bubur Manado) is something which I have loved my entire life. They're fine and they look fantastic.
</p>

<p>
To begin with this recipe, we have to prepare a few ingredients. You can have tinutuan (bubur manado) using 16 ingredients and 4 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Tinutuan (Bubur Manado):</h3>

<ol>
	
		<li>{Get 3 centong of nasi. </li>
	
		<li>{Take 5 gelas of air (saya campur dg air kaldu). </li>
	
		<li>{Take 3 btg of sereh, ambil putihnya, geprek. </li>
	
		<li>{Take 250 gr of labu kuning potong kotak. </li>
	
		<li>{Take 1 bh of jagung disisir. </li>
	
		<li>{Prepare 1 ikat kecil of kangkung iris kasar. </li>
	
		<li>{Prepare 2 sdt of garam. </li>
	
		<li>{Prepare 1/2 sdt of merica halus. </li>
	
		<li>{Prepare 1 sdt of bawang putih halus. </li>
	
		<li>{Prepare 1 btg of daun bawang iris halus. </li>
	
		<li>{Prepare 1 lbr of daun kunyit iris halus. </li>
	
		<li>{Make ready secukupnya of daun kemangi. </li>
	
		<li>{Make ready secukupnya of kaldu bubuk. </li>
	
		<li>{Get  of pelengkap:. </li>
	
		<li>{Make ready  of ikan asin. </li>
	
		<li>{Make ready  of sambal terasi. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Tinutuan (Bubur Manado):</h3>

<ol>
	
		<li>
			Siapkan panci. Masukkan air, nasi, sereh, jagung, labu kuning dan garam. Masak sampai nasi menjadi lunak dan mengental. Silakan tambahkan air kalau dirasa kurang. Hancurkan labu kuning yg sdh melunak didalam panci. Aduk2 terus ya supaya bawahnya ngga gosong..
			
			
		</li>
	
		<li>
			Masukkan sayuran, daun kunyit n daun bawang iris. Tambahkan kaldu bubuk, bawang putih n merica. Check rasa..
			
			
		</li>
	
		<li>
			Masak sampai sayuran lunak. Masukkan daun kemangi. Aduk sebentar. Angkat..
			
			
		</li>
	
		<li>
			Bubur siap disantap panas2 dengan pelengkapnya. Super yummy!.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food tinutuan (bubur manado) recipe. Thank you very much for your time. I am sure that you will make this at home. There's gonna be interesting food in home recipes coming up. Don't forget to save this page in your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
