---
description: "How to Prepare Perfect Bubur kacang ijo + ketan item"
title: "How to Prepare Perfect Bubur kacang ijo + ketan item"
slug: 213-how-to-prepare-perfect-bubur-kacang-ijo-ketan-item

<p>
	<strong>Bubur kacang ijo + ketan item</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/0e65323dcd4e6add/680x482cq70/bubur-kacang-ijo-ketan-item-foto-resep-utama.jpg" alt="Bubur kacang ijo + ketan item" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is Brad, welcome to my recipe page. Today, I'm gonna show you how to prepare a distinctive dish, bubur kacang ijo + ketan item. One of my favorites. For mine, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang ijo + ketan item is one of the most favored of current trending meals on earth. It's enjoyed by millions every day. It is easy, it's fast, it tastes delicious. They're fine and they look wonderful. Bubur kacang ijo + ketan item is something which I have loved my entire life.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we must prepare a few ingredients. You can cook bubur kacang ijo + ketan item using 19 ingredients and 6 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo + ketan item:</h3>

<ol>
	
		<li>{Make ready  of Bubur kacang :. </li>
	
		<li>{Get 250 gram of kacang ijo. </li>
	
		<li>{Get 1000 ml of air. </li>
	
		<li>{Make ready 1 lembar of daun pandan (simpul). </li>
	
		<li>{Make ready 1/2 sdt of garam. </li>
	
		<li>{Get 2 gandu of gula merah. </li>
	
		<li>{Get 5 sdm of gula pasir (boleh tambah kalo suka manis). </li>
	
		<li>{Prepare 1 sdm of maizena (larutkan). </li>
	
		<li>{Prepare  of 👉 saus santan :. </li>
	
		<li>{Take 1 bks of santan kara (65 ml). </li>
	
		<li>{Take Sejumput of garam. </li>
	
		<li>{Make ready 250 ml of air. </li>
	
		<li>{Get 1 lembar of daun pandan. </li>
	
		<li>{Prepare 1 sdt of maizena (larutkan). </li>
	
		<li>{Prepare  of 👉 bubur ketan item :. </li>
	
		<li>{Make ready 100 gr of ketan item. </li>
	
		<li>{Get 1000 ml of air. </li>
	
		<li>{Make ready 8 sdm of gula pasir. </li>
	
		<li>{Get Sejumput of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo + ketan item:</h3>

<ol>
	
		<li>
			👉 bubur kacang ijo : cuci bersih kacang lalu rendam -+ 2 jam. Rebus kacang ijo dan daun pandan sampai empuk (-+ 30 menit).
			
			
		</li>
	
		<li>
			Setelah empuk, tambahkan gula merah, gula putih dan garam. Setelah mendidih masukan larutan maizena lalu masak hingga meletup-letup. Angkat.
			
			
		</li>
	
		<li>
			👉Bubur ketan item : cuci bersih beras ketan item lalu rendem -+ 2 jam..
			
			
		</li>
	
		<li>
			Masak beras ketan, air dan garam hingga matang menjadi bubur (kuah menjadi kental dan meletup letup) masukan gula pasir lalu aduk aduk sebentar. Angkat.
			
			
		</li>
	
		<li>
			👉 saus santan : masak santan, air dan garam hingga mendidih sambil sesekali diaduk. Lalu masukan larutan maizena..
			
			
		</li>
	
		<li>
			Penyajian : tuang bubur kacang ijo pada mangkok, lalu tambahkan bubur ketan item di tengahnya dan siram dengan saus santan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this exceptional food bubur kacang ijo + ketan item recipe. Thanks so much for your time. I'm confident you will make this at home. There is gonna be more interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
