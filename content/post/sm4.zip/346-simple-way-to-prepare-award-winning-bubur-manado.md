---
description: "Simple Way to Prepare Award-winning Bubur Manado"
title: "Simple Way to Prepare Award-winning Bubur Manado"
slug: 346-simple-way-to-prepare-award-winning-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/c274c8d6e28dc213/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Louise, welcome to our recipe site. Today, I will show you a way to prepare a distinctive dish, bubur manado. It is one of my favorites food recipes. For mine, I will make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Manado is one of the most popular of current trending meals in the world. It is appreciated by millions daily. It is easy, it is quick, it tastes delicious. Bubur Manado is something which I have loved my entire life. They're fine and they look wonderful.
</p>

<p>
To begin with this recipe, we must prepare a few components. You can have bubur manado using 23 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Prepare 1 gls of beras. </li>
	
		<li>{Prepare 1 buah of sinkong,. </li>
	
		<li>{Make ready 1 buah of wortel. </li>
	
		<li>{Make ready 1 buah of jagung. </li>
	
		<li>{Prepare 250 gr of labu kuning. </li>
	
		<li>{Get 1 ikat of kangkung. </li>
	
		<li>{Make ready 1 ikat of bayam. </li>
	
		<li>{Make ready 2 ikat of kemangi. </li>
	
		<li>{Prepare 8 gls of air. </li>
	
		<li>{Get  of Bumbu:. </li>
	
		<li>{Get 2 siung of bawang putih. </li>
	
		<li>{Prepare 4 siung of bawang merah. </li>
	
		<li>{Make ready 2 sdm of minyak. </li>
	
		<li>{Make ready 2 of bt sereh. </li>
	
		<li>{Make ready 1 of lb daun kunyit. </li>
	
		<li>{Take  of Pelengkap:. </li>
	
		<li>{Prepare  of Sambel trasi. </li>
	
		<li>{Take  of Bahan:. </li>
	
		<li>{Get 8 buah of cabe kriting. </li>
	
		<li>{Take 4 buah of cabe rawit( pedas sesuaikan saja. </li>
	
		<li>{Prepare 1 buah of tomat. </li>
	
		<li>{Get 1 potong of terasi. </li>
	
		<li>{Prepare  of Ikan asin. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Manado:</h3>

<ol>
	
		<li>
			Cuci beras,dan siapkan semua bahan,potong² singkong,ubi,dll.
			
			
		</li>
	
		<li>
			Geprek sereh,sisihkan,Haluskan bawang merah dan putih,lalu tumis hingga harum,lalu beri air,masukan beras,singkong,labu,wortel,jagung,sereh,daun kunyit,karena sy pake presto,jd masuk semua bahan keras.masak 20 mnt setelah panci mendesis..
			
			
		</li>
	
		<li>
			Setelah uap hilang,buka tutup presto,masukan sayuran hijau,sambil masak dg api kecil,beri garam,cek rasa,lalu masukan kemangi,masuk rata,matikan api..
			
			
		</li>
	
		<li>
			Untuk sambelnya,haluskan bawang merah dan cabe,iris kecil tomat,lalu goreng,bersama terasi,beri gula dan garam..
			
			
		</li>
	
		<li>
			Sajikan bubur dg sambal dan ikan asinya,selamat mencoba..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food bubur manado recipe. Thanks so much for reading. I'm confident you can make this at home. There is gonna be more interesting food at home recipes coming up. Remember to bookmark this page in your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
