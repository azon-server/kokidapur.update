---
description: "How to Prepare Quick Bubur kacang ijo"
title: "How to Prepare Quick Bubur kacang ijo"
slug: 106-how-to-prepare-quick-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/e6811bcfe50c5945/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
		Resep bubur kacang ijo itu sendiri ada berbagai macam dengan tambahan bahan yang melengkapinya.
	
		Cara bikin bubur kacang hijau / ijo memerlukan trik dan tips tersendiri, sehingga hasilnya bisa lebih bagus dan juga enak serta lembut.
	
		Sebenarnya tidak ada yang istimewa saat anda membuat.
	
</p>
<p>
	Hello everybody, it's me, Dave, welcome to our recipe page. Today, I will show you a way to prepare a special dish, bubur kacang ijo. One of my favorites. This time, I will make it a bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo is one of the most popular of current trending meals on earth. It's simple, it is quick, it tastes yummy. It's appreciated by millions every day. They're nice and they look fantastic. Bubur kacang ijo is something that I've loved my entire life.
</p>
<p>
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>

<p>
To get started with this recipe, we have to first prepare a few ingredients. You can cook bubur kacang ijo using 6 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Prepare 1/4 kg of kacang ijo. </li>
	
		<li>{Make ready 4 sdm of santan kental. </li>
	
		<li>{Take 1/4 kg of gula merah diiris tipis. </li>
	
		<li>{Prepare 2 sdm of gula pasir. </li>
	
		<li>{Make ready 1 sdm of garam. </li>
	
		<li>{Get 2 sdm of maizena (kalo mau dibikin kental). </li>
	
</ol>
<p>
	
		Bubur kacang hejo (su) Bubur kacang ijo (jv) Burjo.
	
		Slightly different names may be used in different regions of Indonesia, such as kacang ijo in Javanese areas.
	
		Cara masak bubur kacang ijo super simple dan enak.
	
		Rahasia Peyek Kacang Ijo Renyah, Tidak Keras dan Tahan Lama Bu Yun kali inia akan membagikan resep, tips dan tutorial cara.
	
</p>

<h3>Steps to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Mau wedang kacang ijo yg bnyk kuah tp encer? bs bikin tanpa santan dan maizena.
			
			
		</li>
	
		<li>
			Cuci bersih kacang ijo, rebus dengan api besar di 1ltr air selama 10mnt kemudian tutup panci selama 15 menit (biar kacang kebuka dan empuk dl)..
			
			
		</li>
	
		<li>
			Rebus lg kacang ijo, lalu masukkan santan, gula merah (diiris tipis biar bs cpt meleleh) gula pasir dan garam. koreksi rasa dan pastikan kacang ijo sdh matang semua. aduk maizena 2 sdm dengan 1/4 gelas air matang, aduk rata di panci..
			
			
		</li>
	
		<li>
			Sajikan selagi hangat 😆.
			
			
		</li>
	
		<li>
			Mau es burjo ala warung burjo?? tambahkan es batu, santan dan sedikit sirup merah. sajikan dengan potongan roti tawar 😆.
			
			
		</li>
	
</ol>

<p>
	
		Cara Membuat Bubur Kacang Hijau Sederhana Yang Enak amp Kental Ala Dapur Dina.
	
		Ingin mencoba memasak Bubur Kacang Hijau sendiri, Burjo Pisang (Tips spy kacang ijo cepat empuk dan lembut), Bubur kacang ijo ketan item durian enakk, Burjo Nangka dan lain-lain yang lezat untuk.
	
		Sajikan bubur kacang hijau beserta rebusan santan saat akan di konsumsi untuk menghindari kacang hijau cepat basi Resep membuat bubur kacang hijau.
	
		Resep Bubur Kacang Ijo Enak Dan Cepat Mekar Atau Empuk.
	
		Kacang hijau / ijo merupakan salah satu bahan makanan yang bukan saja enak di buat minuman maupun makanan.
	
</p>

<p>
	So that is going to wrap this up for this special food bubur kacang ijo recipe. Thank you very much for reading. I am sure that you can make this at home. There is gonna be interesting food at home recipes coming up. Remember to bookmark this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
