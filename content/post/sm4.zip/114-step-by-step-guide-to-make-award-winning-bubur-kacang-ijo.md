---
description: "Step-by-Step Guide to Make Award-winning Bubur kacang ijo"
title: "Step-by-Step Guide to Make Award-winning Bubur kacang ijo"
slug: 114-step-by-step-guide-to-make-award-winning-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/a9262fcd00859562/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an amazing day today. Today, I will show you a way to make a distinctive dish, bubur kacang ijo. It is one of my favorites food recipes. This time, I'm gonna make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo is one of the most popular of recent trending foods in the world. It is enjoyed by millions every day. It is easy, it's quick, it tastes yummy. They're fine and they look fantastic. Bubur kacang ijo is something which I have loved my entire life.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to first prepare a few components. You can have bubur kacang ijo using 6 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Prepare 1/4 kg of kacang hijau, cuci, rendam sejam. </li>
	
		<li>{Get 1 gelas of santan kental. </li>
	
		<li>{Take 1/2 keping of gula merah. </li>
	
		<li>{Make ready 3 lembar of daun pandan. </li>
	
		<li>{Prepare 2 L of air. </li>
	
		<li>{Get  of Garam seikhlasnya. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Rebus air sampai mendidih, masukkan daun pandan dan kacang ijo, rebus sampe kacang pecah pecah.
			
			
		</li>
	
		<li>
			Setelah pecah beri garam sejumput, dan aduk terus sampe menyusut airnya.
			
			
		</li>
	
		<li>
			Masukkan gula merah langsung kalau yakin gulahya gak berampas,(atau cairkan lalu saring, masukkan dalam rebusan kacang ijo kalau gula merahnya ada sampahnya).
			
			
		</li>
	
		<li>
			Tuang santan kental dan terus aduk sampai masak...
			
			
		</li>
	
		<li>
			Ohya, supaya makin sedap, saya masukin sejempol jahe waktu ngerebus air dan daun pandan + kacang hijau.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur kacang ijo recipe. Thank you very much for reading. I am confident that you will make this at home. There's gonna be interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
