---
description: "Recipe of Speedy Bubur Manado"
title: "Recipe of Speedy Bubur Manado"
slug: 434-recipe-of-speedy-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/a8f12e9523ed9737/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you are having an incredible day today. Today, I will show you a way to make a special dish, bubur manado. It is one of my favorites food recipes. This time, I will make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Manado is one of the most well liked of current trending meals on earth. It is enjoyed by millions daily. It is simple, it is fast, it tastes delicious. They are nice and they look wonderful. Bubur Manado is something that I've loved my whole life.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we must prepare a few components. You can have bubur manado using 21 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Take 1 cup of Beras rendam kurleb 30 menit. </li>
	
		<li>{Get 2 lt of Air matang. </li>
	
		<li>{Prepare 2 lembar of Daun salam. </li>
	
		<li>{Prepare 1 buah of Serai digeprek. </li>
	
		<li>{Prepare  of Kaldu Ayam. </li>
	
		<li>{Take 2 buah of Ubi/Labu potong dadu. </li>
	
		<li>{Take 2 buah of Jagung (ambil bulir’nya saja). </li>
	
		<li>{Prepare  of Bayam. </li>
	
		<li>{Make ready  of Kangkung. </li>
	
		<li>{Take  of Daun kemangi. </li>
	
		<li>{Get  of Garam. </li>
	
		<li>{Prepare  of Gula. </li>
	
		<li>{Make ready  of Sambal Dabu-dabu. </li>
	
		<li>{Prepare  of Tomat. </li>
	
		<li>{Make ready  of Air jeruk nipis/lemon. </li>
	
		<li>{Make ready  of Bawang merah. </li>
	
		<li>{Make ready  of Cabe rawit. </li>
	
		<li>{Get  of Daun kemangi. </li>
	
		<li>{Take  of Pelengkap. </li>
	
		<li>{Get  of Ikan cakalang suwir. </li>
	
		<li>{Get  of Ikan asin. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Manado:</h3>

<ol>
	
		<li>
			Masukkan dalam panci : Beras, air (masukkan setengah dahulu), daun salam, sereh, kaldu ayam..
			
			
		</li>
	
		<li>
			Masak hingga 1/3 matang lalu masukkan ubi/labu, jagung, sisa air masukkan perlahan dan kira kekentalan bubur..
			
			
		</li>
	
		<li>
			Jika sudah agak matang, masukkan kemangi, kangkung dan bayam (jangan sampai overcooked), garam, gula. Lalu icip rasa..
			
			
		</li>
	
		<li>
			Untuk sambal dabu2 iris dadu tomat, iris tipis bawang merah dan cabe rawit. Campurkan dengan air perasan jeruk nipis/lemon dan daun kemangi..
			
			
		</li>
	
		<li>
			Sajikan bubur di mangkok dengan pelengkap dan sambal dabu-dabu..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur manado recipe. Thank you very much for reading. I'm sure you will make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
