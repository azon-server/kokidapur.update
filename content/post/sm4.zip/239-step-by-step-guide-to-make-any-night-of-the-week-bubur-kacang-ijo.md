---
description: "Step-by-Step Guide to Make Any-night-of-the-week Bubur Kacang Ijo"
title: "Step-by-Step Guide to Make Any-night-of-the-week Bubur Kacang Ijo"
slug: 239-step-by-step-guide-to-make-any-night-of-the-week-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/bb896f03731c13b5/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is Brad, welcome to our recipe site. Today, I'm gonna show you how to make a special dish, bubur kacang ijo. One of my favorites food recipes. For mine, I will make it a little bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo is one of the most popular of recent trending foods on earth. It is enjoyed by millions daily. It is easy, it is quick, it tastes yummy. Bubur Kacang Ijo is something which I have loved my entire life. They are nice and they look wonderful.
</p>

<p>
To get started with this recipe, we must first prepare a few ingredients. You can cook bubur kacang ijo using 7 ingredients and 8 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Take 1/4 kg of kacang hijau. </li>
	
		<li>{Make ready 4 gelas of santan kental. </li>
	
		<li>{Make ready 3 sendok of gula pasir. </li>
	
		<li>{Get selera of Gula jawa menurut. </li>
	
		<li>{Prepare 1/2 sendok teh of garam meja. </li>
	
		<li>{Get  of Jahe geprek sedikit saja. </li>
	
		<li>{Take secukupnya of Daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Rendam kacang hijau kurang lebih sekitar 1jam.
			
			
		</li>
	
		<li>
			Cuci bersih kacang hijau lalu dimasak dengan api kecil usahakan air sedikit lebih banyak.
			
			
		</li>
	
		<li>
			Aduk jangan sampai gosong / ngintip.
			
			
		</li>
	
		<li>
			Masukkan daun pandan, jahe geprek dan garam.
			
			
		</li>
	
		<li>
			Jika terasa agak empuk kacangnya, masukkan gula jawa sisir dan gula pasir tadi.
			
			
		</li>
	
		<li>
			Masak sampai meresap dan surut airnya.
			
			
		</li>
	
		<li>
			Jika sudah surut masukkan santan tadi tunggu sampai matang dan berbau harum.
			
			
		</li>
	
		<li>
			Bubur kacang hijau siap di santap. Selamat Mencoba.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur kacang ijo recipe. Thank you very much for your time. I'm sure you can make this at home. There is gonna be more interesting food in home recipes coming up. Remember to bookmark this page on your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
