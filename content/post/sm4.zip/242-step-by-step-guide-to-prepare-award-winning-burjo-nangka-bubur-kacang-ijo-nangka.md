---
description: "Step-by-Step Guide to Prepare Award-winning BURJO + Nangka (Bubur Kacang Ijo + Nangka)"
title: "Step-by-Step Guide to Prepare Award-winning BURJO + Nangka (Bubur Kacang Ijo + Nangka)"
slug: 242-step-by-step-guide-to-prepare-award-winning-burjo-nangka-bubur-kacang-ijo-nangka

<p>
	<strong>BURJO + Nangka (Bubur Kacang Ijo + Nangka)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/f372d80d50db7ae5/680x482cq70/burjo-nangka-bubur-kacang-ijo-nangka-foto-resep-utama.jpg" alt="BURJO + Nangka (Bubur Kacang Ijo + Nangka)" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an incredible day today. Today, I'm gonna show you how to make a special dish, burjo + nangka (bubur kacang ijo + nangka). It is one of my favorites. For mine, I'm gonna make it a bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	BURJO + Nangka (Bubur Kacang Ijo + Nangka) is one of the most favored of current trending foods in the world. It is enjoyed by millions daily. It's simple, it is quick, it tastes yummy. They are fine and they look fantastic. BURJO + Nangka (Bubur Kacang Ijo + Nangka) is something that I've loved my entire life.
</p>

<p>
To get started with this particular recipe, we must prepare a few ingredients. You can have burjo + nangka (bubur kacang ijo + nangka) using 10 ingredients and 4 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make BURJO + Nangka (Bubur Kacang Ijo + Nangka):</h3>

<ol>
	
		<li>{Prepare 250 gr of Kacang ijo, rendam dulu (aku semalaman rendamnya). </li>
	
		<li>{Make ready 10 Buah of nangka, buang biji potong kecil². </li>
	
		<li>{Get 3 of Bandul gula merah, sisir halus. </li>
	
		<li>{Prepare Secukupnya of gula batu dan gula pasir. </li>
	
		<li>{Take  of Air. </li>
	
		<li>{Make ready optional of Garam. </li>
	
		<li>{Make ready 100 ml of santan kental. </li>
	
		<li>{Prepare 2 Lembar of daun pandan, simpulkan. </li>
	
		<li>{Make ready 1/2 Sdt of Vanilli (boleh skip). </li>
	
		<li>{Get 3 Sdm of maizena larutkan dengan sedikit air. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make BURJO + Nangka (Bubur Kacang Ijo + Nangka):</h3>

<ol>
	
		<li>
			Didihkan air, rebus kacang ijo sampai kira² matang..
			
			
		</li>
	
		<li>
			Masukan gulmer, gula batu, gula pasir, garam, vanilli, daun pandan, rebus sampai mendidih..
			
			
		</li>
	
		<li>
			Masukan santan sambil diaduk agar tidak pecah, lalu masukan larutan maizena, aduk..
			
			
		</li>
	
		<li>
			Terakhir masukan potongan nangka, biarkan sebentar, matikan api. Sajikan (enak dimakan hangat, atau masukan ke kulkas dimakan dingin). Semoga bermanfaat 😊..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this special food burjo + nangka (bubur kacang ijo + nangka) recipe. Thanks so much for reading. I am confident that you can make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to save this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
