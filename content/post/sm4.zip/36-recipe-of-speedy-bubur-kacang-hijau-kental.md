---
description: "Recipe of Speedy Bubur Kacang Hijau Kental"
title: "Recipe of Speedy Bubur Kacang Hijau Kental"
slug: 36-recipe-of-speedy-bubur-kacang-hijau-kental

<p>
	<strong>Bubur Kacang Hijau Kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/8893ae01c8eaacb6/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is me again, Dan, welcome to our recipe site. Today, we're going to prepare a special dish, bubur kacang hijau kental. One of my favorites food recipes. For mine, I will make it a little bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Hijau Kental is one of the most well liked of recent trending foods in the world. It is appreciated by millions daily. It's simple, it's fast, it tastes delicious. Bubur Kacang Hijau Kental is something that I have loved my entire life. They're fine and they look fantastic.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we have to prepare a few components. You can have bubur kacang hijau kental using 8 ingredients and 3 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>{Make ready 1/4 kg of kacang hijau. </li>
	
		<li>{Prepare secukupnya of Gula aren. </li>
	
		<li>{Get secukupnya of Gula pasir. </li>
	
		<li>{Get 3 sdm of tapioka, larutkan dengan sedikit air. </li>
	
		<li>{Take  of Santan kental/santan instan. </li>
	
		<li>{Make ready  of Jahe geprek. </li>
	
		<li>{Get  of Daun pandan. </li>
	
		<li>{Prepare secukupnya of Garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>
			Cuci kacang hijau. Didihkan air, masukkan kacang hijau. Matikan api, tutup panci. Diamkan selama 3-5 jam..
			
			
		</li>
	
		<li>
			Buang air rendaman, cuci bersih. Rebus kembali, tambahkan jahe geprek, garam, daun pandan, dan gula. Koreksi rasa..
			
			
		</li>
	
		<li>
			Setelah kacang empuk tambahkan larutan tapioka. Didihkan, lalu angkat dari kompor. Sajikan bersama dengan santan yang sudah direbus dengan garam..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur kacang hijau kental recipe. Thank you very much for reading. I am sure you will make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
