---
description: "Easiest Way to Make Homemade Bubur Kacang Hijau kuah kental"
title: "Easiest Way to Make Homemade Bubur Kacang Hijau kuah kental"
slug: 35-easiest-way-to-make-homemade-bubur-kacang-hijau-kuah-kental

<p>
	<strong>Bubur Kacang Hijau kuah kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/c5fbb2b3f0a1f0d0/680x482cq70/bubur-kacang-hijau-kuah-kental-foto-resep-utama.jpg" alt="Bubur Kacang Hijau kuah kental" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is Brad, welcome to my recipe site. Today, we're going to prepare a distinctive dish, bubur kacang hijau kuah kental. One of my favorites. This time, I will make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Hijau kuah kental is one of the most well liked of recent trending meals in the world. It is simple, it is quick, it tastes delicious. It is enjoyed by millions every day. They're fine and they look wonderful. Bubur Kacang Hijau kuah kental is something which I've loved my entire life.
</p>

<p>
To get started with this particular recipe, we have to prepare a few components. You can cook bubur kacang hijau kuah kental using 11 ingredients and 4 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau kuah kental:</h3>

<ol>
	
		<li>{Make ready 200 gram of kacang hijau. </li>
	
		<li>{Prepare 50 gram of gula pasir bisa lebih kalau suka manis. </li>
	
		<li>{Get secukupnya of garam. </li>
	
		<li>{Prepare secukupnya of vanili atau daun pandan. </li>
	
		<li>{Take  of air. </li>
	
		<li>{Take 4 lembar of roti. </li>
	
		<li>{Make ready sedikit of sirup coco pndan. </li>
	
		<li>{Make ready  of es batu. </li>
	
		<li>{Take  of Kuah kental. </li>
	
		<li>{Prepare 1 bungkus of santan kara 65 ml. </li>
	
		<li>{Prepare 4 sendok makan of tepung beras. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Hijau kuah kental:</h3>

<ol>
	
		<li>
			Bersihkan kacang hijau. panaskan air jika sudah mendidih masukan kacang hijau, garam, vanili atau daun pandan. panaskan dengan api sedang sampai mendidih. Matikan kompor saat sudah mendidih dan tutup pancinya, diamkan selama 30 menit. Nyalakan api lagi dan panaskan sampai butiran kacang pecah lalu tambahkan gula pasir. jika air sudah kosong bisa ditambah air. Jika mau lebih ceepat proses memasak rendam dulu kacang hijau semalaman..
			
			
		</li>
	
		<li>
			Panaskan santan sampai mendidih, encerkan tepung beras dengan air biasa. Jika santan sudah mendidih masukan larutan tepung beras tambahkan garam aduk sampai agak mengental..
			
			
		</li>
	
		<li>
			Potong-potong roti tawar, lalu tata sesuai urutan es batu, kacang hijau, potongan roti tawar, kuah kental..
			
			
		</li>
	
		<li>
			Tambahkan sirupp coco pandan supaya terlihat lebih menarik. Siap di hidangkan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this special food bubur kacang hijau kuah kental recipe. Thank you very much for reading. I'm sure you can make this at home. There is gonna be interesting food in home recipes coming up. Don't forget to save this page in your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
