---
description: "How to Make Ultimate Bubur kacang hijau kental"
title: "How to Make Ultimate Bubur kacang hijau kental"
slug: 21-how-to-make-ultimate-bubur-kacang-hijau-kental

<p>
	<strong>Bubur kacang hijau kental</strong>. 
	Resep Rahasia Bubur Kacang Hijau Kental Dan Enak, bubur kacang hijau, resep bubur kacang hijau, bubur kacang hijau lezat, bubur kacang ijo seperti tukang. Ada bubur ayam, bubur sumsum, bubur mutiara, bubur kacang hijau dan banyak lainnya. Bubur kacang hijau, abbreviated burjo, is a Southeast Asian sweet porridge (bubur) made from mung beans (kacang hijau), coconut milk, and palm sugar or cane sugar.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/6c7dbf8a2b2e23fa/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur kacang hijau kental" style="width: 100%;">
	
	
		Mau buka puasa begini enaknya kita buat Bubur Kacang.
	
		Bahan kacang hijau kental: Membuat bubur ketan hitam Bubur kacang hijau di hidangkan selagi masih hangat, kemudian siram dengan santan gurih.
	
		Tambahkan santan kental, masak hingga kacang hijau empuk.
	
</p>
<p>
	Hello everybody, hope you're having an incredible day today. Today, I will show you a way to prepare a special dish, bubur kacang hijau kental. It is one of my favorites. For mine, I am going to make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Resep Rahasia Bubur Kacang Hijau Kental Dan Enak, bubur kacang hijau, resep bubur kacang hijau, bubur kacang hijau lezat, bubur kacang ijo seperti tukang. Ada bubur ayam, bubur sumsum, bubur mutiara, bubur kacang hijau dan banyak lainnya. Bubur kacang hijau, abbreviated burjo, is a Southeast Asian sweet porridge (bubur) made from mung beans (kacang hijau), coconut milk, and palm sugar or cane sugar.
</p>
<p>
	Bubur kacang hijau kental is one of the most popular of recent trending foods on earth. It is simple, it is fast, it tastes delicious. It is appreciated by millions every day. Bubur kacang hijau kental is something which I have loved my entire life. They're nice and they look fantastic.
</p>

<p>
To begin with this particular recipe, we must first prepare a few components. You can cook bubur kacang hijau kental using 11 ingredients and 4 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang hijau kental:</h3>

<ol>
	
		<li>{Get 250 gr of kacang hijau. </li>
	
		<li>{Get 4 sdm of tepung maizena. </li>
	
		<li>{Get  of gula 150gr (sesuai selera). </li>
	
		<li>{Get 2 lbr of pandan. </li>
	
		<li>{Get sejumput of garam. </li>
	
		<li>{Get  of bahan santan :. </li>
	
		<li>{Get 2 buah of santan kara. </li>
	
		<li>{Take 150 ml of air. </li>
	
		<li>{Get  of vanili. </li>
	
		<li>{Take 1 sdt of garam. </li>
	
		<li>{Make ready 2 lmbr of daun pandan. </li>
	
</ol>
<p>
	
		Angkat, sajikan dalam keadaan hanggar bersama potongan roti tawar.
	
		Resep bubur kacang hijau kental baik dengan santan maupun bubur kacang hijau tanpa santan.
	
		Bubur kacang hijau termasuk dalam resep jajanan tradisional yang sangat terkenal sejak puluhan tahun silam.
	
		Bahkan sering kita lihat pedagang bubur kacang hijau keliling dengan sepeda lewat di.
	
</p>

<h3>Instructions to make Bubur kacang hijau kental:</h3>

<ol>
	
		<li>
			Kacang hijau di masak dulu dg metode 3.5.7... lalu jika matang campur gula dan masukan tepung maizena, aduk² hingga matang.
			
			
		</li>
	
		<li>
			Lalu jika kacang hijau matang kita persiapkan untuk santan gurihnya yaa.
			
			
		</li>
	
		<li>
			Masukkan santan kara dlm air mendidih 150ml dan lalu vanili, garam dan daun pandan... jika sudah mendidih tunggu dingin.
			
			
		</li>
	
		<li>
			Dan siap di sajikan ❤️.
			
			
		</li>
	
</ol>

<p>
	
		Bubur kacang hijau termasuk sajian nikmat keluarga.
	
		Cara Membuat Bubur Kacang Hijau Ketan Hitam: Kacang hijau, rebus kacang hijau, air, dan daun pandan sampai matang dan mekar.
	
		Sisihkan. rebus beras ketan hitam bersama daun pandan.
	
		Bubur kacang hijau adalah salah satu menu sarapan atau larut malam yang populer di Indonesia.
	
		Masak bubur kacang hijau gak perlu lama-lama lho.
	
</p>

<p>
	So that is going to wrap it up with this exceptional food bubur kacang hijau kental recipe. Thanks so much for your time. I'm sure you will make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
