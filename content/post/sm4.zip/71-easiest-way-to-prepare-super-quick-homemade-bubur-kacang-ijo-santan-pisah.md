---
description: "Easiest Way to Prepare Super Quick Homemade Bubur Kacang Ijo Santan Pisah"
title: "Easiest Way to Prepare Super Quick Homemade Bubur Kacang Ijo Santan Pisah"
slug: 71-easiest-way-to-prepare-super-quick-homemade-bubur-kacang-ijo-santan-pisah

<p>
	<strong>Bubur Kacang Ijo Santan Pisah</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/7cd84dc974264b7c/680x482cq70/bubur-kacang-ijo-santan-pisah-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Santan Pisah" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you're having an amazing day today. Today, we're going to make a distinctive dish, bubur kacang ijo santan pisah. It is one of my favorites food recipes. For mine, I'm gonna make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo Santan Pisah is one of the most favored of recent trending meals on earth. It is simple, it's fast, it tastes yummy. It's enjoyed by millions daily. Bubur Kacang Ijo Santan Pisah is something that I have loved my whole life. They're nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to prepare a few components. You can cook bubur kacang ijo santan pisah using 16 ingredients and 8 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Santan Pisah:</h3>

<ol>
	
		<li>{Get  of Bahan Bubur. </li>
	
		<li>{Prepare 2 gelas kecil of kacang ijo yang udah direndam semalaman. </li>
	
		<li>{Make ready 3 gelas of air untuk merebus. </li>
	
		<li>{Take 2 sdm of tepung tapioka yang dilarutkan dengan ½ gelas air. </li>
	
		<li>{Make ready 2 1/2 keping of gula merah kecil. </li>
	
		<li>{Get 1 of sc kecil vanili bubuk. </li>
	
		<li>{Prepare secukupnya of jahe segar. </li>
	
		<li>{Get secukupnya of daun pandan. </li>
	
		<li>{Make ready sejumput of garam. </li>
	
		<li>{Prepare  of Bahan Kuah Santan. </li>
	
		<li>{Take 3 gelas of santan kelapa segar. </li>
	
		<li>{Make ready sejumput of garam. </li>
	
		<li>{Make ready secukupnya of daun pandan. </li>
	
		<li>{Get 1 of sc kecil vanili bubuk. </li>
	
		<li>{Get  of Toping. </li>
	
		<li>{Prepare  of SKM putih. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo Santan Pisah:</h3>

<ol>
	
		<li>
			Cuci kacang ijo yang udah direndam semalaman..
			
			
		</li>
	
		<li>
			Masukkan semua bahan bubur kecuali larutan tapioka. Masak dengan api sedang sambil sesekali diaduk..
			
			
		</li>
	
		<li>
			Setelah air tinggal sedikit, masukkan larutan tepung tapioka, sambil diaduk-aduk sampai kental..
			
			
		</li>
	
		<li>
			Tes rasa, jika kurang manis bisa ditambah gula pasir atau gula merah lagi. Selesai..
			
			
		</li>
	
		<li>
			Diwadah terpisah masukkan sema bahan kuah santan..
			
			
		</li>
	
		<li>
			Masak dengan api kecil, sambil diaduk pelan supaya santan tidak pecah..
			
			
		</li>
	
		<li>
			Setelah mendidih matikan api dan siap platting 😁😁.
			
			
		</li>
	
		<li>
			Tuangkan bubur, kemudian kuah santan, dibri SKM diatasnya, jadi deh 😍😍 dimakan hangat atau dingin rasanya tetap mantul 💚💚 Selamat mencoba 😘.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this special food bubur kacang ijo santan pisah recipe. Thanks so much for reading. I am confident you will make this at home. There's gonna be more interesting food in home recipes coming up. Don't forget to save this page on your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
