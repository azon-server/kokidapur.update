---
description: "Steps to Make Perfect Bubur Kacang Hijau Kental"
title: "Steps to Make Perfect Bubur Kacang Hijau Kental"
slug: 25-steps-to-make-perfect-bubur-kacang-hijau-kental

<p>
	<strong>Bubur Kacang Hijau Kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/37af91a016375605/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you're having an amazing day today. Today, I'm gonna show you how to make a special dish, bubur kacang hijau kental. It is one of my favorites. This time, I am going to make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Hijau Kental is one of the most favored of recent trending meals on earth. It is enjoyed by millions every day. It's simple, it is quick, it tastes yummy. They are nice and they look wonderful. Bubur Kacang Hijau Kental is something that I have loved my entire life.
</p>

<p>
To begin with this recipe, we must first prepare a few ingredients. You can cook bubur kacang hijau kental using 9 ingredients and 4 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>{Make ready 250 gr of Kacang hijau. </li>
	
		<li>{Take 800 ml of Air. </li>
	
		<li>{Make ready 300 ml of Air santan kental dari 1/2 butir kelapa. </li>
	
		<li>{Make ready 1/2 Sdt of garam. </li>
	
		<li>{Make ready 6 Sdm of gula (selera aja). </li>
	
		<li>{Make ready 1/4 Sdt of vanili. </li>
	
		<li>{Get 2 lembar of daun pandan. </li>
	
		<li>{Make ready 2 ruas of jahe (memarkan). </li>
	
		<li>{Get 2 Sdm of Tepung maizena (larutkan dengan sedikit air). </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>
			Siapkan bahan utama kacang ijo lalu cuci bersih..
			
			
		</li>
	
		<li>
			Masak air sampai mendidih masukan kacang hijau masak sampai lebur dan masukan daun pandan, garam, vanili, gula dan jahe aduk rata..
			
			
		</li>
	
		<li>
			Lalu tuang 150 ml air santan sisakan utk topping (Selera aja) aduk kembali sampai rata baru tuang air maizena aduk terus sampai sedikit kesat matikan kompor..
			
			
		</li>
	
		<li>
			Siapkan tempat saji, Bubur kacang hijau da siap dihidangkan selagi masih hangat. Selamat mencoba..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur kacang hijau kental recipe. Thanks so much for reading. I am sure that you can make this at home. There's gonna be interesting food in home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
