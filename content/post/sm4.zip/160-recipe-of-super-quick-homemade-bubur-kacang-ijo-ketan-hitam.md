---
description: "Recipe of Super Quick Homemade Bubur Kacang Ijo Ketan Hitam"
title: "Recipe of Super Quick Homemade Bubur Kacang Ijo Ketan Hitam"
slug: 160-recipe-of-super-quick-homemade-bubur-kacang-ijo-ketan-hitam

<p>
	<strong>Bubur Kacang Ijo Ketan Hitam</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/90ba3293b916e388/680x482cq70/bubur-kacang-ijo-ketan-hitam-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Ketan Hitam" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you're having an incredible day today. Today, I'm gonna show you how to make a distinctive dish, bubur kacang ijo ketan hitam. One of my favorites food recipes. For mine, I will make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo Ketan Hitam is one of the most favored of current trending foods on earth. It's easy, it is quick, it tastes yummy. It's appreciated by millions every day. Bubur Kacang Ijo Ketan Hitam is something which I've loved my entire life. They're nice and they look wonderful.
</p>

<p>
To get started with this particular recipe, we have to first prepare a few components. You can cook bubur kacang ijo ketan hitam using 16 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Ketan Hitam:</h3>

<ol>
	
		<li>{Get  of bahan bubur ketan hitam. </li>
	
		<li>{Make ready 200 gr of ketan hitam. </li>
	
		<li>{Get 1 ltr of air atau sesuai kebutuhan. </li>
	
		<li>{Get 1 lbr of daun pandan. </li>
	
		<li>{Get 50 gr of gula pasir atau sesuai selera. </li>
	
		<li>{Get  of bahan bubur kacang ijo. </li>
	
		<li>{Get 500 gr of kacang hijau. </li>
	
		<li>{Make ready 1 ltr of air atau sesuai kebutuhan. </li>
	
		<li>{Take 2 lbr of daun Pandan. </li>
	
		<li>{Get 100 gr of gula merah atau sesuai selera. </li>
	
		<li>{Get 1 ltr of santan (santan instan 200 ml + air sampai menjadi seliter). </li>
	
		<li>{Prepare 3 btg of kayu manis. </li>
	
		<li>{Make ready  of bahan santan. </li>
	
		<li>{Make ready 500 ml of Santan (santan instan 200 ml + air menjadi 500 ml). </li>
	
		<li>{Get 1 lbr of daun pandan. </li>
	
		<li>{Make ready secukupnya of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo Ketan Hitam:</h3>

<ol>
	
		<li>
			Untuk melunakan kacang hijau dan ketan hitam ada dua cara : 1. Merendam kurang lebih 3 jam sebelum direbus atau 2. memasak pakai metode fah umi yasmin 5.30.7. Saat merebusnya daun pandan ikut serta direbus..
			
			
		</li>
	
		<li>
			Untuk ketan hitam apabila sudah empuk sesuai keinginan kita baru masukan gula pasirnya. dan biarkan kental.Sisihkan.
			
			
		</li>
	
		<li>
			Untuk Kacang ijo apabila sudah empuk baru kita masukan santan dan gula merah,garam biarkan hingga menyusut kental dan sisihkan.
			
			
		</li>
	
		<li>
			Untuk bahan santan masak semua bahan sambil diaduk biar santannya nga pecah hingga mendidih. sisihkan.
			
			
		</li>
	
		<li>
			Tata di mangkok kacang hijau, ketan hitam dan santan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food bubur kacang ijo ketan hitam recipe. Thank you very much for reading. I'm sure that you can make this at home. There's gonna be interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
