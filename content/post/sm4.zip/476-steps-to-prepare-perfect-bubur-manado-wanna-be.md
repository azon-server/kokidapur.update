---
description: "Steps to Prepare Perfect Bubur manado wanna be"
title: "Steps to Prepare Perfect Bubur manado wanna be"
slug: 476-steps-to-prepare-perfect-bubur-manado-wanna-be

<p>
	<strong>Bubur manado wanna be</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/2b87db58c7c992c5/680x482cq70/bubur-manado-wanna-be-foto-resep-utama.jpg" alt="Bubur manado wanna be" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you are having an amazing day today. Today, we're going to make a distinctive dish, bubur manado wanna be. One of my favorites. For mine, I am going to make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur manado wanna be is one of the most popular of current trending foods on earth. It is appreciated by millions every day. It's simple, it's quick, it tastes yummy. Bubur manado wanna be is something that I've loved my entire life. They're nice and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we have to prepare a few components. You can have bubur manado wanna be using 20 ingredients and 6 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur manado wanna be:</h3>

<ol>
	
		<li>{Prepare  of Bahan utama. </li>
	
		<li>{Prepare 1,5 cup of beras. </li>
	
		<li>{Prepare 1/2 ikat of Kangkung ambil daunnyaa yg atas. </li>
	
		<li>{Take  of Labu (beli 2000 dipasar). </li>
	
		<li>{Prepare 1/4 ons of kacang tanah. </li>
	
		<li>{Prepare 1 bonggol of jagung. </li>
	
		<li>{Get 5 buah of kacang panjang. </li>
	
		<li>{Get secukupnya of Air. </li>
	
		<li>{Take  of Wortel secukupny. </li>
	
		<li>{Take  of Bumbu. </li>
	
		<li>{Make ready 2 siung of bawang putih. </li>
	
		<li>{Make ready 2 siung of bawang merah. </li>
	
		<li>{Prepare 1 batang of sereh/serai. </li>
	
		<li>{Prepare Secukupnya of garam. </li>
	
		<li>{Take Secukupnya of kaldu jamur. </li>
	
		<li>{Get  of Tambahan. </li>
	
		<li>{Get  of Ikan asin. </li>
	
		<li>{Get  of Tahu. </li>
	
		<li>{Get  of Tempe. </li>
	
		<li>{Make ready  of Sambal terasi. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur manado wanna be:</h3>

<ol>
	
		<li>
			Cuci semua bahan, lalu potong-potong labu berbentuk dadu, kacang panjang, wortel, kangkung dan Serut jagung.
			
			
		</li>
	
		<li>
			Haluskan bumbu(bawang merah, bawang putih) geprek serai.
			
			
		</li>
	
		<li>
			Masukkan beras, kacang tanah, labu dan bumbu kedalam panci atau presto(agar lebih cepat). Tambahkan air kira2 satu jari. Tutup dan rebus hingga menjadi bubur. Kalau saya pake presto setelah presto berbunyi tunggu 15 menit lalu matikan..
			
			
		</li>
	
		<li>
			Sembari menunggu siapkan tambahan, tempe di goreng, tahu digoreng, ikan asin digoreng, dan siapkan sambal terasi.
			
			
		</li>
	
		<li>
			Setelah beras mejadi bubur masukkan bahan lainnya dan masak lagi hingga matang, koreksi rasa..
			
			
		</li>
	
		<li>
			Hidangkan dengan tahu, tempe, dan ikan asin serta sambal terasi.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this exceptional food bubur manado wanna be recipe. Thanks so much for your time. I'm sure you can make this at home. There is gonna be interesting food in home recipes coming up. Remember to bookmark this page on your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
