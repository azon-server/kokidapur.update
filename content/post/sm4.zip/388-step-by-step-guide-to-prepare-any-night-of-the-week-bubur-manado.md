---
description: "Step-by-Step Guide to Prepare Any-night-of-the-week Bubur Manado"
title: "Step-by-Step Guide to Prepare Any-night-of-the-week Bubur Manado"
slug: 388-step-by-step-guide-to-prepare-any-night-of-the-week-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/a00e0a0a36836d99/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you're having an amazing day today. Today, I'm gonna show you how to make a special dish, bubur manado. One of my favorites. This time, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Manado is one of the most well liked of recent trending meals on earth. It's easy, it's fast, it tastes delicious. It is appreciated by millions daily. They're fine and they look wonderful. Bubur Manado is something that I have loved my entire life.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we have to prepare a few ingredients. You can cook bubur manado using 15 ingredients and 4 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Get 150 gr of Beras. </li>
	
		<li>{Prepare 200 gr of Labu Kuning potong dadu. </li>
	
		<li>{Get 150 gr of Singkong potong dadu. </li>
	
		<li>{Prepare  of Jagung 1 buah Bersihkan dan pipil. </li>
	
		<li>{Prepare 1 ikat of Daun bayam. </li>
	
		<li>{Make ready 1 ikat of Daung Kangkung. </li>
	
		<li>{Make ready 1 cup of Kemangi. </li>
	
		<li>{Make ready 1 cm of Jahe, geprek. </li>
	
		<li>{Take 2 batang of Serai, geprek. </li>
	
		<li>{Make ready 1 sdm of bawang putih, goreng dan haluskan. </li>
	
		<li>{Get  of Merica. </li>
	
		<li>{Prepare  of Gula. </li>
	
		<li>{Take  of Garam. </li>
	
		<li>{Prepare  of Air. </li>
	
		<li>{Make ready  of Ikan Asin Jambal, goreng sebagai pelengkap. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Manado:</h3>

<ol>
	
		<li>
			Cuci bersih beras, tambah air masak bersama jahe, serai hingga mendidih dan setengah matang.
			
			
		</li>
	
		<li>
			Masukkan labu, singkong dan jagung. Masak kembali hingga menjadi bubur.
			
			
		</li>
	
		<li>
			Masukkan garam, gula, bawang dan lada. Aduk rata lalu masukkan kangkung, bayam dan kemangi. Aduk dan masak sebentar hingga sayur matang. Koreksi rasa dan Angkat..
			
			
		</li>
	
		<li>
			Sajikan dengan ikan jambal goreng dan sambal roa.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur manado recipe. Thanks so much for your time. I am sure you will make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
