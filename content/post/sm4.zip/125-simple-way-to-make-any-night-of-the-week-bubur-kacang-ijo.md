---
description: "Simple Way to Make Any-night-of-the-week Bubur kacang ijo"
title: "Simple Way to Make Any-night-of-the-week Bubur kacang ijo"
slug: 125-simple-way-to-make-any-night-of-the-week-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/3c013ad32fac399c/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you are having an amazing day today. Today, I'm gonna show you how to prepare a special dish, bubur kacang ijo. It is one of my favorites. For mine, I'm gonna make it a little bit unique. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo is one of the most popular of recent trending foods on earth. It is enjoyed by millions daily. It is simple, it's quick, it tastes yummy. Bubur kacang ijo is something that I've loved my whole life. They are nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to first prepare a few components. You can have bubur kacang ijo using 7 ingredients and 6 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Get 1/4 of kacang ijo. </li>
	
		<li>{Prepare 1/2 btr of kelapa. </li>
	
		<li>{Get 1 btr of gula jawa. </li>
	
		<li>{Take 1 ons of gula pasir/sesuai selera. </li>
	
		<li>{Get 1 sdt of garam. </li>
	
		<li>{Get secukupnya of air. </li>
	
		<li>{Prepare 5 cm of jahe. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Cuci kacang lalu rendam 2 jam,lebih bagus ngrendamnya semalaman..
			
			
		</li>
	
		<li>
			Rebus air sampai menutupi permukaan kacang saja,lalu masukkan kacangnya.tambahkan jahe yg telah dikupas dan digeprek..
			
			
		</li>
	
		<li>
			Setelah 5 menit,matikan.Tutup panci rapat2..
			
			
		</li>
	
		<li>
			Sambil menunggu 30 menit,peras kelapa untuk jadi santan.pisahkan santan bening dan kental..
			
			
		</li>
	
		<li>
			Setelah 30 menit,nyalakan apinya lagi.Masukkan santan bening+gula jawa sambil diaduk-aduk.Lanjut Santan kental+garam+gula pasir.Terus diaduk-aduk sampai mendidih..
			
			
		</li>
	
		<li>
			Bubur siap dinikmati dech....
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this exceptional food bubur kacang ijo recipe. Thank you very much for your time. I am sure you will make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
