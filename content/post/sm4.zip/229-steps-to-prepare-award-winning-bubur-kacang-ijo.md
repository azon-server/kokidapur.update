---
description: "Steps to Prepare Award-winning Bubur Kacang Ijo"
title: "Steps to Prepare Award-winning Bubur Kacang Ijo"
slug: 229-steps-to-prepare-award-winning-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/482475ac0ed7c5bb/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is John, welcome to my recipe page. Today, we're going to prepare a distinctive dish, bubur kacang ijo. One of my favorites food recipes. For mine, I will make it a little bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo is one of the most popular of current trending foods in the world. It is simple, it is quick, it tastes delicious. It's enjoyed by millions daily. They are fine and they look wonderful. Bubur Kacang Ijo is something that I have loved my whole life.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we have to first prepare a few ingredients. You can cook bubur kacang ijo using 8 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Make ready 250 gram of kacang ijo. </li>
	
		<li>{Get 750 ml of air. </li>
	
		<li>{Make ready 3 cm of jahe. </li>
	
		<li>{Prepare 1 lembar of daun pandan. </li>
	
		<li>{Get 150 gram of gula merah (aren). </li>
	
		<li>{Make ready 7 sdm of gula pasir. </li>
	
		<li>{Make ready 1 sdt of garam. </li>
	
		<li>{Prepare 350 ml of santan kental. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Bersihkan kemudian cuci kacang hijau hingga bersih, lalu rendam dengan air biasa kurang lebih 30menit - 1jam..
			
			
		</li>
	
		<li>
			Kemudian Rabus kacang hijau hingga setengah matang dengan air, jahe, dan daun pandan..
			
			
		</li>
	
		<li>
			Setelah kacang hijau dalam keadaan setengah matang, masukkan garam, gula merah, dan gula pasir. Atau bisa sesuaikan takaran gulanya sesuai dengan selera kita. Masak kacang hijau hingga benar2 lembut, sisihkan..
			
			
		</li>
	
		<li>
			Masak santan kental berikan sedikit garam. Masak hingga santan mendidih..
			
			
		</li>
	
		<li>
			Masukkan bubur kacang ijo yg sudah matang kedalam mangkuk, kemudian tuangkan santannya sesuai dengan selera anda. Dan Bubur Kacang Ijo pun siap untuk dinikmati..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this exceptional food bubur kacang ijo recipe. Thank you very much for your time. I am sure you can make this at home. There is gonna be more interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
