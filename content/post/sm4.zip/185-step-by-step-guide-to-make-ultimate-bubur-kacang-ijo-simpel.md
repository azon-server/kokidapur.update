---
description: "Step-by-Step Guide to Make Ultimate Bubur kacang ijo simpel"
title: "Step-by-Step Guide to Make Ultimate Bubur kacang ijo simpel"
slug: 185-step-by-step-guide-to-make-ultimate-bubur-kacang-ijo-simpel

<p>
	<strong>Bubur kacang ijo simpel</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/861b18e9eb6b2f51/680x482cq70/bubur-kacang-ijo-simpel-foto-resep-utama.jpg" alt="Bubur kacang ijo simpel" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an amazing day today. Today, we're going to prepare a special dish, bubur kacang ijo simpel. One of my favorites food recipes. For mine, I'm gonna make it a bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo simpel is one of the most well liked of recent trending meals on earth. It's appreciated by millions every day. It is simple, it is quick, it tastes delicious. They are nice and they look wonderful. Bubur kacang ijo simpel is something that I have loved my whole life.
</p>

<p>
To get started with this recipe, we have to prepare a few components. You can have bubur kacang ijo simpel using 8 ingredients and 4 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo simpel:</h3>

<ol>
	
		<li>{Take 500 gram of Kacang hijau. </li>
	
		<li>{Prepare 250 gram of gula merah. </li>
	
		<li>{Make ready 1 of Santan cair (aku pakai sun kara). </li>
	
		<li>{Prepare 100 gram of gula putih. </li>
	
		<li>{Prepare 1-2 sachet of vanili (sesuai selera). </li>
	
		<li>{Get 1 ruas of jahe. </li>
	
		<li>{Prepare 500 ml of air mineral. </li>
	
		<li>{Make ready Sejumput of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo simpel:</h3>

<ol>
	
		<li>
			Rebus kacang hijau, gula merah dan jahe dengan air mineral sampai empuk atau sampai mateng kurang lebih kalo GAK pake presto 45 menit lah bun sampai air nya agak nyusut ya...
			
			
		</li>
	
		<li>
			Setelah agak nyusut masukan vanili, gula putih, garam dan jangan lupa santan kental nya ya bun.
			
			
		</li>
	
		<li>
			Kocek sebentar dan koreksi rasanya...
			
			
		</li>
	
		<li>
			Selesaiiii simple kan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this special food bubur kacang ijo simpel recipe. Thank you very much for reading. I am confident you can make this at home. There is gonna be more interesting food at home recipes coming up. Remember to bookmark this page in your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
