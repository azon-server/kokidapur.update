---
description: "Easiest Way to Make Quick Bubur kacang ijo"
title: "Easiest Way to Make Quick Bubur kacang ijo"
slug: 86-easiest-way-to-make-quick-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/60efc7fc14039934/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you're having an incredible day today. Today, we're going to make a special dish, bubur kacang ijo. It is one of my favorites food recipes. This time, I will make it a bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo is one of the most well liked of recent trending foods on earth. It's appreciated by millions every day. It is easy, it's quick, it tastes delicious. They're nice and they look wonderful. Bubur kacang ijo is something that I've loved my whole life.
</p>

<p>
To begin with this particular recipe, we must first prepare a few ingredients. You can cook bubur kacang ijo using 9 ingredients and 8 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Take 1/4 of kacang hijau. </li>
	
		<li>{Take  of Gula Jawa secukupnya sesuai selera ya. </li>
	
		<li>{Prepare 1 bungkus of vanili. </li>
	
		<li>{Prepare 3 of pandan. </li>
	
		<li>{Make ready 1 buah of kelapa untuk Santan kental. </li>
	
		<li>{Take  of Air. </li>
	
		<li>{Take  of Jahe. </li>
	
		<li>{Take  of Garam. </li>
	
		<li>{Prepare 3 sdm of Tepung beras. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Cuci hingga bersih kacang hijau.
			
			
		</li>
	
		<li>
			Rebus kacang hijau hingga empuk.
			
			
		</li>
	
		<li>
			Parut kelapa lalu santan dengan kental.
			
			
		</li>
	
		<li>
			Masukan gula merah, vanili, pandan, jahe yang sudah dibakar dan digepuk, sedikit garam lalu aduk.
			
			
		</li>
	
		<li>
			Masukan santan kental aduk kembali.
			
			
		</li>
	
		<li>
			Masukan tepung beras yang sudah dicairkan dengan air aduh terus.
			
			
		</li>
	
		<li>
			Tunggu sampai mendidih dan sedikit kental.
			
			
		</li>
	
		<li>
			Koreksi rasa dan bubur kacang hijau siap disajikan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur kacang ijo recipe. Thank you very much for reading. I am confident that you can make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
