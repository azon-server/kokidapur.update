---
description: "Easiest Way to Make Any-night-of-the-week Bubur kacang hijau kental"
title: "Easiest Way to Make Any-night-of-the-week Bubur kacang hijau kental"
slug: 64-easiest-way-to-make-any-night-of-the-week-bubur-kacang-hijau-kental

<p>
	<strong>Bubur kacang hijau kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/4f887155d6dc4710/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur kacang hijau kental" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's John, welcome to my recipe site. Today, I'm gonna show you how to prepare a distinctive dish, bubur kacang hijau kental. One of my favorites. For mine, I will make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang hijau kental is one of the most popular of current trending meals on earth. It is easy, it is quick, it tastes yummy. It's enjoyed by millions daily. They're fine and they look wonderful. Bubur kacang hijau kental is something that I have loved my whole life.
</p>

<p>
To begin with this particular recipe, we have to prepare a few ingredients. You can have bubur kacang hijau kental using 12 ingredients and 2 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang hijau kental:</h3>

<ol>
	
		<li>{Take 250 gr of kacang hijau (rendam semalaman). </li>
	
		<li>{Make ready  of Jahe. </li>
	
		<li>{Prepare 2 of daun pandan. </li>
	
		<li>{Make ready  of Garam. </li>
	
		<li>{Take  of Gula merah. </li>
	
		<li>{Get  of Air. </li>
	
		<li>{Make ready 3 SDM of tepung tapioka. </li>
	
		<li>{Make ready  of Santan pisah. </li>
	
		<li>{Make ready 1 of santan ka*a. </li>
	
		<li>{Take  of Air. </li>
	
		<li>{Take  of Garam. </li>
	
		<li>{Prepare  of Daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang hijau kental:</h3>

<ol>
	
		<li>
			Rebus kacang hijau dalam air SMP empuk, masukkan garam, gulden, daun pandan, jahe, terakhir jika sudah empuk masukkan larutan tepung tapioka. Tes rasa.
			
			
		</li>
	
		<li>
			Air beserta santan, daun pandan, garam didihkan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur kacang hijau kental recipe. Thank you very much for reading. I am confident you will make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
