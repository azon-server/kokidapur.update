---
description: "Steps to Prepare Quick Bubur kacang ijo"
title: "Steps to Prepare Quick Bubur kacang ijo"
slug: 236-steps-to-prepare-quick-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/7f9c9e7ebb363d8a/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's me, Dave, welcome to our recipe site. Today, I'm gonna show you how to make a distinctive dish, bubur kacang ijo. It is one of my favorites food recipes. For mine, I am going to make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang ijo is one of the most well liked of current trending foods on earth. It's easy, it's quick, it tastes yummy. It is enjoyed by millions daily. They're nice and they look fantastic. Bubur kacang ijo is something that I've loved my entire life.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we must first prepare a few ingredients. You can cook bubur kacang ijo using 9 ingredients and 5 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Take 1/4 kg of kacang hijau(saya rendam dulu semalaman). </li>
	
		<li>{Prepare 1/4 kg of gula merah. </li>
	
		<li>{Get 2 liter of air. </li>
	
		<li>{Make ready 1 bks of santan kara 65 ml. </li>
	
		<li>{Take 3 lembar of daun pandan,simpulkan. </li>
	
		<li>{Take 1/2 sdt of garam. </li>
	
		<li>{Get  of pelengkap:. </li>
	
		<li>{Prepare  of roti tawar. </li>
	
		<li>{Get  of krimer kental manis/SKM. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Cairkan gula merah dengan sedikit air,saring.sisihkan.
			
			
		</li>
	
		<li>
			Rebus kacang ijo,air,daun pandan garam hingga kacang ijo mekar dan air menusut 30-40 menit dengan api sedang.tambahkan gula merah,gula pasir dan santan,aduk rata.test rasa,angkat.
			
			
		</li>
	
		<li>
			Lebih nikmat dengan pelengkap.bisa di sajikan hangat atau dingin.tinggal tambahkan es batu jadi deh es kacang ijo😋😋.
			
			
		</li>
	
		<li>
			Note:rendam kacang ijo dengan air banyak supaya air ngga sampe saat/rob.pengalaman saya gara2 air saat/rob kacang ijonya keluar ekor alias jadi toge😅😅😅.setelah menambahkan santan aduk2 dulu sampe bener2 mendidih (saya aduk2 terus kira2 5 menit) supaya santen ngga pecah.
			
			
		</li>
	
		<li>
			Selamat mencoba😉😉.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this special food bubur kacang ijo recipe. Thanks so much for your time. I'm sure you will make this at home. There's gonna be more interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
