---
description: "Recipe of Super Quick Homemade Bubur Kacang Ijo Ketan Hitam"
title: "Recipe of Super Quick Homemade Bubur Kacang Ijo Ketan Hitam"
slug: 173-recipe-of-super-quick-homemade-bubur-kacang-ijo-ketan-hitam

<p>
	<strong>Bubur Kacang Ijo Ketan Hitam</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/3d7d2b46c3912d63/680x482cq70/bubur-kacang-ijo-ketan-hitam-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Ketan Hitam" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you are having an amazing day today. Today, we're going to prepare a special dish, bubur kacang ijo ketan hitam. It is one of my favorites. For mine, I am going to make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo Ketan Hitam is one of the most popular of recent trending foods on earth. It's appreciated by millions every day. It is simple, it is fast, it tastes yummy. Bubur Kacang Ijo Ketan Hitam is something that I have loved my whole life. They are nice and they look fantastic.
</p>

<p>
To get started with this recipe, we must prepare a few components. You can have bubur kacang ijo ketan hitam using 7 ingredients and 6 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Ketan Hitam:</h3>

<ol>
	
		<li>{Get 150 gram of Kacang Hijau. </li>
	
		<li>{Take 3.5 Liter of Air. </li>
	
		<li>{Get 8 Lembar of Daun Pandan Ikat. </li>
	
		<li>{Take 1.25 sdt of Garam. </li>
	
		<li>{Prepare 400 gram of Gula Pasir. </li>
	
		<li>{Take 150 gram of Ketan Hitam. </li>
	
		<li>{Take 500 mL of Santan (1 Butir Kelapa). </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo Ketan Hitam:</h3>

<ol>
	
		<li>
			Ketan hitam direndam semalaman dengan air kemudian kacang hijau direndam selama 1 jam dalam wadah yang berbeda..
			
			
		</li>
	
		<li>
			Kacang hijau dan ketan hitam dibilas dan dicuci dengan air..
			
			
		</li>
	
		<li>
			Kacang hijau direbus dengan 2 Liter air dan 3 lembar daun pandan ikat hingga matang dan mekar. Masukkan 1/2 sdt garam dan 200 gram gula pasir. Kemudian masak dengan diaduk hingga meresap dan kental..
			
			
		</li>
	
		<li>
			Ketan hitam direbus dengan 1.5 Liter air dan 3 lembar daun pandan ikat hingga lunak dan kental sambil diaduk. Masukkan 1/2 sdt garam dan 200 gram gula pasir. Kemudian masak dengan diaduk hingga kental..
			
			
		</li>
	
		<li>
			500 mL santan direbus dengan menambahkan 2 lembar daun pandan ikat dan 1/4 sdt garam hingga mendidih sambil diaduk..
			
			
		</li>
	
		<li>
			Bubur kacang hijau dimasukkan ke dalam mangkok, kemudian ditambahkan dengan ketan hitam dan kuah santan lalu bubur kacang hijau ketan hitam siap disajikan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this exceptional food bubur kacang ijo ketan hitam recipe. Thank you very much for your time. I am confident that you can make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
