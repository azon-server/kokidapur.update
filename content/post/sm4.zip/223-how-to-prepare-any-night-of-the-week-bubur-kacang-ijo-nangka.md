---
description: "How to Prepare Any-night-of-the-week Bubur Kacang Ijo Nangka"
title: "How to Prepare Any-night-of-the-week Bubur Kacang Ijo Nangka"
slug: 223-how-to-prepare-any-night-of-the-week-bubur-kacang-ijo-nangka

<p>
	<strong>Bubur Kacang Ijo Nangka</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/7a3eecdfadd7279e/680x482cq70/bubur-kacang-ijo-nangka-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Nangka" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's me again, Dan, welcome to our recipe page. Today, I'm gonna show you how to prepare a distinctive dish, bubur kacang ijo nangka. It is one of my favorites food recipes. This time, I am going to make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo Nangka is one of the most popular of current trending meals in the world. It's appreciated by millions every day. It is easy, it is fast, it tastes delicious. They are fine and they look fantastic. Bubur Kacang Ijo Nangka is something which I have loved my whole life.
</p>

<p>
To get started with this particular recipe, we must prepare a few components. You can have bubur kacang ijo nangka using 13 ingredients and 8 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Nangka:</h3>

<ol>
	
		<li>{Prepare 250 gr of kacang hijau. </li>
	
		<li>{Make ready 1 liter of air. </li>
	
		<li>{Prepare 3 lembar of daun pandan, simpulkan. </li>
	
		<li>{Get 3 ruas of jahe, geprek. </li>
	
		<li>{Take 2 sdt of maizena, larutkan dengan sedikit air. </li>
	
		<li>{Make ready 3 buah of nangka, potong kotak2 kecil. </li>
	
		<li>{Get  of Air gula :. </li>
	
		<li>{Take 100 gr of gula merah, sisir halus. </li>
	
		<li>{Make ready 100 gr of gula pasir. </li>
	
		<li>{Take  of Kuah santan :. </li>
	
		<li>{Take 300 ml of santan kental. </li>
	
		<li>{Get Sejumput of garam. </li>
	
		<li>{Get 3 lembar of daun pandan, simpulkan. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo Nangka:</h3>

<ol>
	
		<li>
			Air gula : Didihkan dengan sedikit air hingga gula larut. Angkat lalu saring. Sisihkan..
			
			
		</li>
	
		<li>
			Kuah santan : Masak diatas api kecil, aduk hingga mendidih. Dinginkan..
			
			
		</li>
	
		<li>
			Cuci bersih kacang hijau. Lalu rendam dengan air banyak semalaman..
			
			
		</li>
	
		<li>
			Tiriskan air rendaman. Rebus kacang hingga empuk &amp; merekah..
			
			
		</li>
	
		<li>
			Masukkan air gula, pandan, &amp; jahe. Aduk rata &amp; masak hingga mendidih..
			
			
		</li>
	
		<li>
			Beri larutan maizena. Aduk hingga mengental..
			
			
		</li>
	
		<li>
			Tambahkan potongan nangka. Tunggu sebentar. Matikan api..
			
			
		</li>
	
		<li>
			Sajikan dengan siraman kuah santan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this exceptional food bubur kacang ijo nangka recipe. Thank you very much for reading. I am sure you will make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to save this page in your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
