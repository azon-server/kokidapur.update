---
description: "Simple Way to Make Any-night-of-the-week Bubur kacang ijo dan ketan hitam empuk"
title: "Simple Way to Make Any-night-of-the-week Bubur kacang ijo dan ketan hitam empuk"
slug: 219-simple-way-to-make-any-night-of-the-week-bubur-kacang-ijo-dan-ketan-hitam-empuk

<p>
	<strong>Bubur kacang ijo dan ketan hitam empuk</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/43d98c0e5f086c53/680x482cq70/bubur-kacang-ijo-dan-ketan-hitam-empuk-foto-resep-utama.jpg" alt="Bubur kacang ijo dan ketan hitam empuk" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Jim, welcome to my recipe site. Today, I will show you a way to prepare a special dish, bubur kacang ijo dan ketan hitam empuk. It is one of my favorites food recipes. This time, I'm gonna make it a bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo dan ketan hitam empuk is one of the most favored of current trending meals in the world. It's simple, it's fast, it tastes yummy. It is enjoyed by millions daily. They're fine and they look wonderful. Bubur kacang ijo dan ketan hitam empuk is something which I have loved my whole life.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we have to first prepare a few ingredients. You can have bubur kacang ijo dan ketan hitam empuk using 9 ingredients and 8 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo dan ketan hitam empuk:</h3>

<ol>
	
		<li>{Make ready 100 gr of kacang hijau (direndam semaleman). </li>
	
		<li>{Get 100 gr of ketan hitam (direndam semalaman). </li>
	
		<li>{Prepare secukupnya of Santan cair. </li>
	
		<li>{Get secukupnya of Gula. </li>
	
		<li>{Prepare  of Daun pandan. </li>
	
		<li>{Make ready  of Gula merah. </li>
	
		<li>{Take secukupnya of Tepung beras. </li>
	
		<li>{Make ready  of Kayu manis (optional). </li>
	
		<li>{Get  of Jahe (optional untuk aroma kacang ijo). </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo dan ketan hitam empuk:</h3>

<ol>
	
		<li>
			Rebus kacang hijau yg uda direndam air jgn terlalu banyak yaa pokoknya sampe mateng dan empuk 😁 masukkan jg daun pandan biar wangii.
			
			
		</li>
	
		<li>
			Masak jg ketan hitam sampai matang dan ngga keras.
			
			
		</li>
	
		<li>
			Kacang ijo : setelah matang dan empuk baru masukkan gula secukupnya, kalo mau pake gula merah juga bisa ya biar tambah legit 😚.
			
			
		</li>
	
		<li>
			TIPS : supaya kental ditambahkan larutan tepung beras yaa biar kayak abang2 yg jual bubur biasanya itu loh.
			
			
		</li>
	
		<li>
			Ketan item : setelah matang jg baru masukkan gula pasir ga tambahkan daun pandan juga biar haruumm. Masak sambil diaduk2 agar tidak gosong bawahnya.
			
			
		</li>
	
		<li>
			Setelah ketan dan kacang ijo matang siapkan santannya yukk.. kmrn aku pake kara yg kecil 60gr kalo ngga salah ditambah air secukupnya direbus sebentar sambil diaduk2 dan dikasi daun pandan jg..
			
			
		</li>
	
		<li>
			Tadaaa.. bubur bikinan sendiri uda jadi dehh 😄.
			
			
		</li>
	
		<li>
			.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food bubur kacang ijo dan ketan hitam empuk recipe. Thanks so much for reading. I'm sure that you can make this at home. There's gonna be interesting food in home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
