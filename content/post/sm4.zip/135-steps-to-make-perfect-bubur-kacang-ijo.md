---
description: "Steps to Make Perfect Bubur kacang ijo"
title: "Steps to Make Perfect Bubur kacang ijo"
slug: 135-steps-to-make-perfect-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/d411f1156d037a29/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is John, welcome to our recipe site. Today, I'm gonna show you how to make a special dish, bubur kacang ijo. It is one of my favorites. This time, I am going to make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo is one of the most well liked of recent trending meals in the world. It is easy, it's quick, it tastes delicious. It is enjoyed by millions daily. Bubur kacang ijo is something which I've loved my whole life. They're nice and they look fantastic.
</p>

<p>
To begin with this particular recipe, we must prepare a few ingredients. You can cook bubur kacang ijo using 8 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Prepare 1/4 of kacang ijo. </li>
	
		<li>{Make ready 1/2 cm of jahe. </li>
	
		<li>{Get 1 siung of bawang putih. </li>
	
		<li>{Make ready 1/4 sdt of fanili. </li>
	
		<li>{Make ready 200 ml of santan. </li>
	
		<li>{Make ready 1 of daun pandan. </li>
	
		<li>{Take secukupnya of Air. </li>
	
		<li>{Get 1/2 gelas of gula pasir. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Masak dulu kacang ijo dengan 250ml air, tambahkan jahe dan bawang putih(di iris) sampai blutusan dan air berkurang.
			
			
		</li>
	
		<li>
			Tambahkan santan sambil diaduk, jika gak mau kental tambahkan air secukupnya, masukan fanili, gula dan daun pandan aduk sampai mendidih,.
			
			
		</li>
	
		<li>
			Jangan lupa cicip rasa.
			
			
		</li>
	
		<li>
			Jika sudah matang, buburnya siap disajikan.
			
			
		</li>
	
		<li>
			Terima kasih.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this exceptional food bubur kacang ijo recipe. Thank you very much for your time. I'm confident that you can make this at home. There is gonna be interesting food in home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
