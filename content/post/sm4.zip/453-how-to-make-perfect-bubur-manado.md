---
description: "How to Make Perfect Bubur Manado"
title: "How to Make Perfect Bubur Manado"
slug: 453-how-to-make-perfect-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/8c90d5a0ecd7d22d/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you're having an incredible day today. Today, I will show you a way to prepare a distinctive dish, bubur manado. It is one of my favorites food recipes. This time, I will make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Manado is one of the most popular of current trending foods on earth. It's appreciated by millions daily. It's easy, it is quick, it tastes delicious. They are nice and they look wonderful. Bubur Manado is something which I've loved my whole life.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we have to first prepare a few components. You can cook bubur manado using 11 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Make ready 1 1/2 cup of beras (di rendam semalam). </li>
	
		<li>{Take 2 buah of jagung (di pipil). </li>
	
		<li>{Get 1 1/2 of labu kuning (potong dadu). </li>
	
		<li>{Take 1 ikat of kangkung. </li>
	
		<li>{Prepare secukupnya of Daun kemangi. </li>
	
		<li>{Make ready 2 btr of bawang putih (geprek). </li>
	
		<li>{Get 1 btg of sereh besar. </li>
	
		<li>{Take 2 btg of daun bawang (di rajang). </li>
	
		<li>{Get  of Garam, lada, kaldu bubuk. </li>
	
		<li>{Make ready  of Sambal terasi. </li>
	
		<li>{Prepare  of Ikan asin goreng. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Manado:</h3>

<ol>
	
		<li>
			Masukkan beras yang sudah di rendam ke dalam panci yang berisi air kurleb 650 ml..
			
			
		</li>
	
		<li>
			Masukkan jagung, labu, sereh, bawang putih. Aduk aduk bersama berasnya. Sering sering diaduk karna biar gak mengintip di bawah berasnya..
			
			
		</li>
	
		<li>
			Saat sudah mendidih, bumbui dengan lada, garam, kaldu bubuk. Jangan lupa juga masukkan daun kemangi dan daun bawang sambil terus diaduk..
			
			
		</li>
	
		<li>
			Setelah sudah menjadi bubur, masukkan kangkungnya, diaduk hingga matang. Jika kurang air, boleh di tambah air lagi. Sesuai selera.
			
			
		</li>
	
		<li>
			Sajikan bubur Manado dengan sambal terasi dan ikan Asin..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur manado recipe. Thanks so much for reading. I'm confident that you can make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to save this page in your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
