---
description: "Simple Way to Make Homemade Bubur Kacang ijo"
title: "Simple Way to Make Homemade Bubur Kacang ijo"
slug: 101-simple-way-to-make-homemade-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/fd18835067b78390/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you're having an amazing day today. Today, I will show you a way to prepare a special dish, bubur kacang ijo. One of my favorites food recipes. For mine, I will make it a bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang ijo is one of the most popular of current trending meals in the world. It is easy, it is fast, it tastes delicious. It is enjoyed by millions daily. They are nice and they look fantastic. Bubur Kacang ijo is something which I have loved my whole life.
</p>

<p>
To get started with this recipe, we have to prepare a few components. You can cook bubur kacang ijo using 8 ingredients and 4 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang ijo:</h3>

<ol>
	
		<li>{Take 150 gram of kacang ijo. </li>
	
		<li>{Take 1 blok of gula merah ukuran kecil, sisir. </li>
	
		<li>{Get 3 sdm of gula pasir (manis sesuai selera). </li>
	
		<li>{Make ready 4 sdm of gula palm. </li>
	
		<li>{Take 1 of daun pandan, ikat simpul. </li>
	
		<li>{Take 65 ml of santan (me: kara). </li>
	
		<li>{Get 2 cm of jahe, iris geprek. </li>
	
		<li>{Prepare Secukupnya of air. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang ijo:</h3>

<ol>
	
		<li>
			Cuci bersih kacang ijo, kemudian pindahkan dalam panci, tambahkan air, jahe, dan daun pandan. Masak menggunakan metode 5:30:7 (jangan lupa ditutup pancinya).
			
			
		</li>
	
		<li>
			Setelah 7menit selesai, masak hingga kacang hijaunya pecah.(apabila kacang hijaunya belum terlalu pecah). bisa ditambahkan air apabila dirasa kurang airnya..
			
			
		</li>
	
		<li>
			Masukkan gula merah, gula putih dan gula palm aduk rata.
			
			
		</li>
	
		<li>
			Tambahkan santan, aduk rata dan tes rasa. Klo dikira kurang kental bisa ditambah yaa santannya. Masak menggunakan api sedang sambil diaduk terus agar santan tidak pecah ya. Masak hingga mendidih, matikan api.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this exceptional food bubur kacang ijo recipe. Thanks so much for your time. I'm confident you can make this at home. There's gonna be interesting food in home recipes coming up. Remember to bookmark this page in your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
