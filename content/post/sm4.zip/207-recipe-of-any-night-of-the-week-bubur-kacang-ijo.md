---
description: "Recipe of Any-night-of-the-week Bubur Kacang Ijo"
title: "Recipe of Any-night-of-the-week Bubur Kacang Ijo"
slug: 207-recipe-of-any-night-of-the-week-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/5269b852fe65d65c/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
		Resep bubur kacang ijo itu sendiri ada berbagai macam dengan tambahan bahan yang melengkapinya.
	
		Cara bikin bubur kacang hijau / ijo memerlukan trik dan tips tersendiri, sehingga hasilnya bisa lebih bagus dan juga enak serta lembut.
	
		Sebenarnya tidak ada yang istimewa saat anda membuat.
	
</p>
<p>
	Hey everyone, hope you are having an amazing day today. Today, I'm gonna show you how to make a distinctive dish, bubur kacang ijo. One of my favorites food recipes. This time, I'm gonna make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>
<p>
	Bubur Kacang Ijo is one of the most favored of current trending foods on earth. It's enjoyed by millions daily. It is easy, it's quick, it tastes yummy. They are nice and they look fantastic. Bubur Kacang Ijo is something which I have loved my whole life.
</p>

<p>
To begin with this particular recipe, we must first prepare a few components. You can have bubur kacang ijo using 8 ingredients and 3 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Make ready 250 gr of kacang ijo. </li>
	
		<li>{Get 1 helai of daun pandan. </li>
	
		<li>{Make ready 5 sdm of gula pasir (sesuai selera). </li>
	
		<li>{Take 1 bulat kecil of gula merah, sisir (sesuai selera). </li>
	
		<li>{Take sejumput of garam. </li>
	
		<li>{Make ready 1 bungkus of santan kara 65 ml. </li>
	
		<li>{Take secukupnya of air. </li>
	
		<li>{Prepare 3 cm of jahe, geprek. </li>
	
</ol>
<p>
	
		Bubur kacang hejo (su) Bubur kacang ijo (jv) Burjo.
	
		Slightly different names may be used in different regions of Indonesia, such as kacang ijo in Javanese areas.
	
		Cara masak bubur kacang ijo super simple dan enak.
	
		Rahasia Peyek Kacang Ijo Renyah, Tidak Keras dan Tahan Lama Bu Yun kali inia akan membagikan resep, tips dan tutorial cara.
	
</p>

<h3>Steps to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Cuci bersih kacang ijo dengan air mengalir, atau air diganti 3x seperti cuci beras ya.. Masukkan ke panci, beri air sekitar 4x lipat tinggi kacang ijo. Sesuai selera untuk air ya, nanti kacang ijonya ngembang jadi besar. Kalau mau kuah agak kental airnya ga banyak. 

Masak dg panci tertutup, hingga kacang lembut/ pecah-pecah tanda sudah matang..
			
			
		</li>
	
		<li>
			Kalau sudah lembut kacangnya, masukkan gula merah, gula pasir. garam, daun pandan, jahe. Rebus hingga semua gula larut, baru masukkan santan. Aduk terus, test rasa..
			
			
		</li>
	
		<li>
			Sajikan...
			
			
		</li>
	
</ol>

<p>
	
		Cara Membuat Bubur Kacang Hijau Sederhana Yang Enak amp Kental Ala Dapur Dina.
	
		Ingin mencoba memasak Bubur Kacang Hijau sendiri, Burjo Pisang (Tips spy kacang ijo cepat empuk dan lembut), Bubur kacang ijo ketan item durian enakk, Burjo Nangka dan lain-lain yang lezat untuk.
	
		Sajikan bubur kacang hijau beserta rebusan santan saat akan di konsumsi untuk menghindari kacang hijau cepat basi Resep membuat bubur kacang hijau.
	
		Resep Bubur Kacang Ijo Enak Dan Cepat Mekar Atau Empuk.
	
		Kacang hijau / ijo merupakan salah satu bahan makanan yang bukan saja enak di buat minuman maupun makanan.
	
</p>

<p>
	So that is going to wrap it up with this exceptional food bubur kacang ijo recipe. Thank you very much for reading. I am sure that you will make this at home. There is gonna be interesting food in home recipes coming up. Remember to bookmark this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
