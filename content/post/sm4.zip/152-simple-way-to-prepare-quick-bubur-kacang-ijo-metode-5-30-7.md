---
description: "Simple Way to Prepare Quick Bubur kacang ijo metode 5:30:7"
title: "Simple Way to Prepare Quick Bubur kacang ijo metode 5:30:7"
slug: 152-simple-way-to-prepare-quick-bubur-kacang-ijo-metode-5-30-7

<p>
	<strong>Bubur kacang ijo metode 5:30:7</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/3b7710ed5eccf026/680x482cq70/bubur-kacang-ijo-metode-5307-foto-resep-utama.jpg" alt="Bubur kacang ijo metode 5:30:7" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you are having an incredible day today. Today, we're going to make a special dish, bubur kacang ijo metode 5:30:7. It is one of my favorites. For mine, I will make it a little bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo metode 5:30:7 is one of the most well liked of recent trending meals in the world. It's simple, it is quick, it tastes yummy. It's enjoyed by millions every day. Bubur kacang ijo metode 5:30:7 is something that I have loved my whole life. They are nice and they look wonderful.
</p>

<p>
To get started with this recipe, we have to first prepare a few components. You can have bubur kacang ijo metode 5:30:7 using 7 ingredients and 2 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo metode 5:30:7:</h3>

<ol>
	
		<li>{Prepare 250 gr of Kacang ijo. </li>
	
		<li>{Get 250 gr of Gula merah. </li>
	
		<li>{Take secukupnya of Air. </li>
	
		<li>{Take secukupnya of Garam. </li>
	
		<li>{Make ready 2 sachet of Susu kental manis. </li>
	
		<li>{Prepare 1 sdm of Maizena. </li>
	
		<li>{Take 65 ml of Santan kara. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo metode 5:30:7:</h3>

<ol>
	
		<li>
			Cuci bersih kacang ijo.rebus dgn panci tertutup selama 5 menit.jika sudah 5 menit matikan api.diamkan selama 30 menit tutup jgn dibuka.jika sudah 30 menit rebus kembali selama 7 menit..
			
			
		</li>
	
		<li>
			Tambahkan gula merah. Susu kental manis. Garam secukupnya. Santan kara dan maizena yg sudah di cairkan dengan sedikit air.koreksi rasa jika sudah pas matikan api. Bubur kacang ijo siap di hidangkan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this special food bubur kacang ijo metode 5:30:7 recipe. Thank you very much for your time. I'm confident that you will make this at home. There is gonna be more interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
