---
description: "Simple Way to Make Award-winning Lek Tau Suan (Bubur Kacang Ijo Kupas)"
title: "Simple Way to Make Award-winning Lek Tau Suan (Bubur Kacang Ijo Kupas)"
slug: 95-simple-way-to-make-award-winning-lek-tau-suan-bubur-kacang-ijo-kupas

<p>
	<strong>Lek Tau Suan (Bubur Kacang Ijo Kupas)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/661e7136d09d5bd2/680x482cq70/lek-tau-suan-bubur-kacang-ijo-kupas-foto-resep-utama.jpg" alt="Lek Tau Suan (Bubur Kacang Ijo Kupas)" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an amazing day today. Today, I will show you a way to make a distinctive dish, lek tau suan (bubur kacang ijo kupas). It is one of my favorites food recipes. For mine, I'm gonna make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Lek Tau Suan (Bubur Kacang Ijo Kupas) is one of the most favored of recent trending foods in the world. It's enjoyed by millions every day. It is simple, it is quick, it tastes yummy. They are nice and they look wonderful. Lek Tau Suan (Bubur Kacang Ijo Kupas) is something which I have loved my whole life.
</p>

<p>
To begin with this recipe, we have to prepare a few ingredients. You can have lek tau suan (bubur kacang ijo kupas) using 8 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Lek Tau Suan (Bubur Kacang Ijo Kupas):</h3>

<ol>
	
		<li>{Prepare 150 gr of kacang hijau kupas. </li>
	
		<li>{Prepare 6 sdm of gula pasir (sesuaikan dgn selera msg). </li>
	
		<li>{Get 3-4 lembar of daun pandan. </li>
	
		<li>{Make ready 3 cm of jahe dibagi menjdi 2. </li>
	
		<li>{Prepare secukupnya of Air. </li>
	
		<li>{Make ready 2-3 sdm of tepung maizena. </li>
	
		<li>{Prepare 65 ml of santan kental (me=kara). </li>
	
		<li>{Take 1/2 sdt of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Lek Tau Suan (Bubur Kacang Ijo Kupas):</h3>

<ol>
	
		<li>
			Rendam kacang ijo kupas selama 2-3 jam sblm dimasak..
			
			
		</li>
	
		<li>
			Kukus kacang hijau kupas beserta daun pandan biar wangi tunggu hingga matang..
			
			
		</li>
	
		<li>
			Diwadah berbeda panaskan air sktr 350ml dgn air jahe jika sudah mendidih masukan gula aduk hingga rata dan masukan kacang hijau kupas yg terakhir masukan tepung maizena yg sudah dicampur air sdkt utk mengentalkan, sisihkan.
			
			
		</li>
	
		<li>
			Campurkan santan dan air 150ml di dalam panci beserta daun pandan masak dgn api kecil tunggu hingga mendidih, matikan.
			
			
		</li>
	
		<li>
			Sajikan kacang hijau kupas dgn santan dan jgn lupa cakwe. Selamat menikmati.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this exceptional food lek tau suan (bubur kacang ijo kupas) recipe. Thank you very much for reading. I'm sure that you can make this at home. There is gonna be more interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
