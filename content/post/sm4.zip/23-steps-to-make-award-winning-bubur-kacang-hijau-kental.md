---
description: "Steps to Make Award-winning Bubur Kacang Hijau Kental"
title: "Steps to Make Award-winning Bubur Kacang Hijau Kental"
slug: 23-steps-to-make-award-winning-bubur-kacang-hijau-kental

<p>
	<strong>Bubur Kacang Hijau Kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/2b76ffb97907b6f9/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an amazing day today. Today, I will show you a way to make a special dish, bubur kacang hijau kental. One of my favorites food recipes. For mine, I'm gonna make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Hijau Kental is one of the most popular of current trending meals in the world. It is enjoyed by millions every day. It is simple, it is quick, it tastes delicious. They are fine and they look wonderful. Bubur Kacang Hijau Kental is something that I have loved my entire life.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we must first prepare a few components. You can cook bubur kacang hijau kental using 10 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>{Get 250 gr of kacang hijau. </li>
	
		<li>{Prepare 250 gr of gula merah. </li>
	
		<li>{Get 5-6 of sedok gula pasir (sesuai selera). </li>
	
		<li>{Prepare 1 saset of Sunkara. </li>
	
		<li>{Get 2 of Daun salam. </li>
	
		<li>{Make ready Sejumput of vanili. </li>
	
		<li>{Prepare Sejumput of garam. </li>
	
		<li>{Prepare 2 ruas of Jahe. </li>
	
		<li>{Make ready 1400 ml of air. </li>
	
		<li>{Prepare 4 sendok of tepung maezena (larutkan dengan air sedikit). </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>
			Cuci kacang hijau, rendam semalaman.
			
			
		</li>
	
		<li>
			Masak air sesuai takaran hingga mendidih, masukan kacang hijau &amp; daun pandan, tutup panci masak selama 5 menit dengan api besar..
			
			
		</li>
	
		<li>
			Mati kan kompor, diamkan selama 30 menit, tutup panci harus bener2 ketutup, nyalakan kembali apinya masak selama 7 menit..
			
			
		</li>
	
		<li>
			Buka tutup panci masukan gula merah, gula pasir, jahe, garam, aduk2 sampe mendidih sampe gula mencair,, masukan vanili &amp; santen, aduk2 kembali..
			
			
		</li>
	
		<li>
			Masukan tepung maezena, aduk2 hingga mengental, kalau sudah mengental matikan api &amp; sajikan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this exceptional food bubur kacang hijau kental recipe. Thank you very much for reading. I am confident that you can make this at home. There's gonna be more interesting food in home recipes coming up. Don't forget to save this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
