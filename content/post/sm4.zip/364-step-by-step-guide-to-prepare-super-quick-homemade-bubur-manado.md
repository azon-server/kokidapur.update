---
description: "Step-by-Step Guide to Prepare Super Quick Homemade Bubur Manado"
title: "Step-by-Step Guide to Prepare Super Quick Homemade Bubur Manado"
slug: 364-step-by-step-guide-to-prepare-super-quick-homemade-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/35138a6f8b396acd/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is John, welcome to my recipe site. Today, I'm gonna show you how to make a distinctive dish, bubur manado. One of my favorites food recipes. For mine, I will make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Manado is one of the most popular of current trending foods in the world. It's simple, it is quick, it tastes yummy. It is enjoyed by millions daily. Bubur Manado is something which I have loved my whole life. They're nice and they look fantastic.
</p>

<p>
To begin with this particular recipe, we must first prepare a few components. You can have bubur manado using 17 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Get 300 gram of beras (2 cup). </li>
	
		<li>{Take 2 liter of air. </li>
	
		<li>{Take 3 buah of ubi rambat,potong kotak. </li>
	
		<li>{Get 1 buah of jagung, pipil iris. </li>
	
		<li>{Prepare 2 ikat of bayam. </li>
	
		<li>{Prepare 3 ikat of daun kemangi. </li>
	
		<li>{Get 3 batang of serai, geprek. </li>
	
		<li>{Prepare 4 lembar of daun salam. </li>
	
		<li>{Make ready 2 sdt of garam. </li>
	
		<li>{Make ready 1 sdt of kaldu bubuk. </li>
	
		<li>{Get  of Bumbu halus:. </li>
	
		<li>{Make ready 5 siung of bawang merah. </li>
	
		<li>{Take 3 siung of bawang putih. </li>
	
		<li>{Get  of Bahan pelengkap:. </li>
	
		<li>{Take  of Ikan asin. </li>
	
		<li>{Take  of Tahu goreng. </li>
	
		<li>{Take  of Sambal terasi. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Manado:</h3>

<ol>
	
		<li>
			Rendam beras semaleman dan cuci bersih beras.
			
			
		</li>
	
		<li>
			Tumis bumbu halus sampai harum..
			
			
		</li>
	
		<li>
			Masukkan labu kuning, ubi,jagung,sereh, daun salam, air dan bumbu halus. Masak sampai menjadi bubur.
			
			
		</li>
	
		<li>
			Kemudian masukkan bayam, daun kemangi, garam dan kaldu bubuk,Masak lagi selama 5 menit..
			
			
		</li>
	
		<li>
			Siap dihidangkan dengan bahan pelengkap.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur manado recipe. Thanks so much for your time. I am sure that you can make this at home. There is gonna be interesting food at home recipes coming up. Remember to bookmark this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
