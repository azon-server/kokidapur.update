---
description: "Simple Way to Prepare Speedy Bubur Manado / Tinutuan"
title: "Simple Way to Prepare Speedy Bubur Manado / Tinutuan"
slug: 271-simple-way-to-prepare-speedy-bubur-manado-tinutuan

<p>
	<strong>Bubur Manado / Tinutuan</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/b1172c3e047807be/680x482cq70/bubur-manado-tinutuan-foto-resep-utama.jpg" alt="Bubur Manado / Tinutuan" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's me again, Dan, welcome to my recipe site. Today, I will show you a way to make a special dish, bubur manado / tinutuan. It is one of my favorites food recipes. For mine, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Manado / Tinutuan is one of the most popular of recent trending foods in the world. It is easy, it's quick, it tastes delicious. It is appreciated by millions every day. They're nice and they look wonderful. Bubur Manado / Tinutuan is something that I have loved my whole life.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to first prepare a few components. You can have bubur manado / tinutuan using 16 ingredients and 4 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Manado / Tinutuan:</h3>

<ol>
	
		<li>{Get 2 ikat of Kangkung. </li>
	
		<li>{Make ready 1 ikat of Kemangi. </li>
	
		<li>{Make ready  of Bumbu Sambal Terasi. </li>
	
		<li>{Get  of Cabe rawit (banyaknya sesuai selera). </li>
	
		<li>{Take 5 siung of bawang merah. </li>
	
		<li>{Make ready 3 bh of tomat. </li>
	
		<li>{Make ready 2 bgks of terasi ABC. </li>
	
		<li>{Take  of Bubur. </li>
	
		<li>{Take  of Beras (ukur sesuai keinginan). </li>
	
		<li>{Get 4 siung of bawang putih. </li>
	
		<li>{Get 3 btg of sereh. </li>
	
		<li>{Prepare 2 potongan sedang of labu kuning. </li>
	
		<li>{Take  of Gorengan. </li>
	
		<li>{Prepare 3 bh of tahu. </li>
	
		<li>{Take 2 bgkus of tempe. </li>
	
		<li>{Make ready  of Ikan asin. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado / Tinutuan:</h3>

<ol>
	
		<li>
			Iris kangkung menjadi bagian2 kecil. Petik kemangi, dan campur ke kangkung. Cuci bersih sisihkan..
			
			
		</li>
	
		<li>
			Potong kecil2 labu kuning,rebus. Setelah masak angkat tiriskan airnya, haluskan labu hingga halus, sisihkan. Cuci beras hingga bersih, tuang air, masukan labu yg telah halus beserta sereh. Masak hingga menjadi bubur. Agar bubur menjadi harum tumis bawang putih yg telah di iris2 masukan ke dalam adonan bubur tadi..
			
			
		</li>
	
		<li>
			Untuk sambal terasi, blender cabe rawit, bawang merah, dan tomat..
			
			
		</li>
	
		<li>
			Jika sdh ingin makan bubur manadonya, sediakan wajan, tuang bubur ke wajan sesuai banyaknya porsi yg ingin makan, masukan sayuran yg telah di potong2 tadi, tambahkan masako masak hingga mendidih. jika terlalu kental boleh tambahkan air masak sedikit sesuai seleras. Angkat sajikan. Tambahkan dgn gorengan biar lebih nikmat..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this special food bubur manado / tinutuan recipe. Thank you very much for your time. I am confident that you can make this at home. There is gonna be more interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
