---
description: "Recipe of Super Quick Homemade Bubur kacang hijau kental simpel"
title: "Recipe of Super Quick Homemade Bubur kacang hijau kental simpel"
slug: 41-recipe-of-super-quick-homemade-bubur-kacang-hijau-kental-simpel

<p>
	<strong>Bubur kacang hijau kental simpel</strong>. 
	Terimakasih sudah menonton video Bunda Aini Channel. Kali ini saya ingin sharing resep bubur kacang hijau. Bubur kacang hijau, abbreviated burjo, is a Southeast Asian sweet porridge (bubur) made from mung beans (kacang hijau), coconut milk, and palm sugar or cane sugar.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/ded44e5b3dbd2683/680x482cq70/bubur-kacang-hijau-kental-simpel-foto-resep-utama.jpg" alt="Bubur kacang hijau kental simpel" style="width: 100%;">
	
	
		Awas jangan sampai santan pecah, setelah mendidih angkat dan tempatkan dalam wadah.
	
		Cara Kang Yaya memasak Bubur Kacang Ijo yang Kental &amp; Manis,Yaitu yang di kenal orang Burjo Kang Yaya.
	
		Siapkan mangkuk saji, tuang bubur kacang hijau.
	
</p>
<p>
	Hey everyone, hope you are having an incredible day today. Today, I will show you a way to make a special dish, bubur kacang hijau kental simpel. It is one of my favorites. This time, I am going to make it a little bit unique. This will be really delicious.
</p>
	
<p>
	Terimakasih sudah menonton video Bunda Aini Channel. Kali ini saya ingin sharing resep bubur kacang hijau. Bubur kacang hijau, abbreviated burjo, is a Southeast Asian sweet porridge (bubur) made from mung beans (kacang hijau), coconut milk, and palm sugar or cane sugar.
</p>
<p>
	Bubur kacang hijau kental simpel is one of the most favored of current trending foods on earth. It's appreciated by millions daily. It is simple, it's quick, it tastes yummy. They are fine and they look wonderful. Bubur kacang hijau kental simpel is something which I've loved my whole life.
</p>

<p>
To begin with this recipe, we have to prepare a few ingredients. You can have bubur kacang hijau kental simpel using 9 ingredients and 8 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur kacang hijau kental simpel:</h3>

<ol>
	
		<li>{Take 250 gram of Kacang hijau. </li>
	
		<li>{Get  of Fiber creme (bisa diganti santan). </li>
	
		<li>{Make ready 1/2 of cth Garam. </li>
	
		<li>{Take 2 cm of Jahe digeprek. </li>
	
		<li>{Make ready  of Maizena secukupnya (bisa diganti tepung tapioka). </li>
	
		<li>{Make ready 2 lembar of Daun pandan. </li>
	
		<li>{Take 2 sdt of Vanilli. </li>
	
		<li>{Make ready 3 potong of Gula jawa atau gula pasir (sesuai selera) disisir. </li>
	
		<li>{Prepare 1 liter of Air. </li>
	
</ol>
<p>
	
		Beri krim kental manis dan rice crispy.
	
		Artikel ini telah tayang di SajianSedap dengan judul &#34; Resep Bubur Kacang Hijau Rice Crispy Enak Ini Pas Untuk Menu.
	
		Membahas mengenai bubur kacang hijau rasanya tak lengkap apabila tidak mengulas mengenai resep bubur kacang hijau.
	
		Cara membuat bubur kacang hijau Ücretsiz.
	
</p>

<h3>Steps to make Bubur kacang hijau kental simpel:</h3>

<ol>
	
		<li>
			Siapkan bahan-bahan.
			
			
		</li>
	
		<li>
			Rebus air 1 liter dan daun pandan secukupnya sampai mendidih.
			
			
		</li>
	
		<li>
			Setelah 5 menit api dimatikan dan tunggu selama 30 menit (panci ditutup rapat).
			
			
		</li>
	
		<li>
			Setelah mendidih rebus kacang hijau selama 5 menit dengan api besar (panci ditutup rapat)..
			
			
		</li>
	
		<li>
			Setelah 30 menit, masukkan jahe, gula,garam, fiber creme dan vanili. Rebus selama 7 menit dengan api sedang.
			
			
		</li>
	
		<li>
			Setelah 7 menit kacang hijau akan empuk dan pecah. tambahkan larutan maizena (tepung tapioka)agar mengental. Tes rasa.
			
			
		</li>
	
		<li>
			Larutkan Fiber creme atau santan bubuk dan air. rebus bersama daun pandan dan sedikit garam. aduk-aduk angkat dan ssisihkan..
			
			
		</li>
	
		<li>
			Bubur Kacang Hijau disajikan dengan fiber creme atau santan.
			
			
		</li>
	
</ol>

<p>
	
		Cara sederhana mengolah makanan yang kaya gizi, resep bubur kacang hijau kental dengan atau tanpa santan karena dipisah ini bisa menjadi pilihan.
	
		Rasanya yang enak dan empuk membuat bubur kacang ijo yang sering disingkat burjo juga sangat disukai.
	
		Bubur kacang hijau atau burjo adalah menu khas Nusantara yang sangat mudah ditemukan di mana-mana.
	
		Bubur kacang hijau dapat dijadikan sebagai menu sarapan, camilan, atau dessert.
	
		Selain menyehatkan, burjo ini juga cukup mengenyangkan.
	
</p>

<p>
	So that's going to wrap this up for this special food bubur kacang hijau kental simpel recipe. Thank you very much for your time. I'm sure you can make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to save this page in your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
