---
description: "Steps to Prepare Award-winning Bubur Manado - Tinutuan"
title: "Steps to Prepare Award-winning Bubur Manado - Tinutuan"
slug: 340-steps-to-prepare-award-winning-bubur-manado-tinutuan

<p>
	<strong>Bubur Manado - Tinutuan</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/248cd90cbf1b6f56/680x482cq70/bubur-manado-tinutuan-foto-resep-utama.jpg" alt="Bubur Manado - Tinutuan" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is me again, Dan, welcome to my recipe site. Today, we're going to make a special dish, bubur manado - tinutuan. One of my favorites food recipes. For mine, I am going to make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Manado - Tinutuan is one of the most well liked of recent trending foods on earth. It is easy, it's fast, it tastes yummy. It is appreciated by millions every day. Bubur Manado - Tinutuan is something which I have loved my entire life. They're fine and they look fantastic.
</p>

<p>
To get started with this particular recipe, we must first prepare a few components. You can cook bubur manado - tinutuan using 14 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Manado - Tinutuan:</h3>

<ol>
	
		<li>{Get 1,5 mug of takar (rice cooker) beras. </li>
	
		<li>{Get 1500 ml of air. </li>
	
		<li>{Get 200 gr of labu kuning, ptg kotak kecil. </li>
	
		<li>{Prepare 100 gr of ubi keledek merah, ptg kotak kecil. </li>
	
		<li>{Take 1 bh of tomat merah, bagi 8 (opt). </li>
	
		<li>{Make ready 100 gr of kangkung, petiki. </li>
	
		<li>{Take 2 sdm of kecap ikan / saus tiram. </li>
	
		<li>{Take 1/2 sdt of bubuk lada. </li>
	
		<li>{Get 1 sdt of garam. </li>
	
		<li>{Take  of Bahan Sambal Bawang :. </li>
	
		<li>{Take 100 gr of cabe merah. </li>
	
		<li>{Prepare 5 siung of bawang merah. </li>
	
		<li>{Take 1/3 sdt of garam. </li>
	
		<li>{Prepare 3 sdm of minyak sayur. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado - Tinutuan:</h3>

<ol>
	
		<li>
			Siapkan bahan-bahan. Ubi dan labu dipotong², kangkung dipetiki lalu cuci bersih.
			
			
		</li>
	
		<li>
			Masak beras dipanci hingga mendidih, setelah beras 1/2 matang masukkan potonga labu dan ubi lalu masak hingga mengental sanpai menjadi bubur sambil terus diaduk lk 1 jam..
			
			
		</li>
	
		<li>
			Lalu tambahkan lada, kecap ikan / saus tiram, garam lalu cek rasa baru masukkan potongan tomat, aduk² kembali sampai tomat lunak dan buburnya tanak. Terakhir masukkan kangkung lalu matikan api..
			
			
		</li>
	
		<li>
			Membuat Sambal Bawang : Blender halus semua bahan, lalu tumis sebentar saja sampai keluar aroma manis dari bawang, matikan api..
			
			
		</li>
	
		<li>
			Sajikan panas² bersama sambal dan ikan asin goreng kering. Bubur tampak berwarna kuning krn labu dan ubinya sudah hancur ya Moms. Lezatnya... 😋👍.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this exceptional food bubur manado - tinutuan recipe. Thanks so much for reading. I'm confident that you will make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to save this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
