---
description: "Recipe of Speedy Bubur manado sambal dabu + ikan teri maknyus"
title: "Recipe of Speedy Bubur manado sambal dabu + ikan teri maknyus"
slug: 307-recipe-of-speedy-bubur-manado-sambal-dabu-ikan-teri-maknyus

<p>
	<strong>Bubur manado sambal dabu + ikan teri maknyus</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/d71ae0f284aed89e/680x482cq70/bubur-manado-sambal-dabu-ikan-teri-maknyus-foto-resep-utama.jpg" alt="Bubur manado sambal dabu + ikan teri maknyus" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an amazing day today. Today, I will show you a way to make a special dish, bubur manado sambal dabu + ikan teri maknyus. One of my favorites. This time, I am going to make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur manado sambal dabu + ikan teri maknyus is one of the most popular of recent trending foods on earth. It is appreciated by millions daily. It's easy, it's quick, it tastes yummy. Bubur manado sambal dabu + ikan teri maknyus is something which I've loved my entire life. They are fine and they look wonderful.
</p>

<p>
To get started with this particular recipe, we must first prepare a few ingredients. You can cook bubur manado sambal dabu + ikan teri maknyus using 24 ingredients and 4 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur manado sambal dabu + ikan teri maknyus:</h3>

<ol>
	
		<li>{Make ready 1 of canting beras / 4 genggam cuci bersih. </li>
	
		<li>{Make ready 500 gr of labu kuning iris kecil. </li>
	
		<li>{Prepare 2 ikat of kangkung. </li>
	
		<li>{Make ready 2 ikat of bayam. </li>
	
		<li>{Get 2 buah of jagung bersihkan kmudian pipil. </li>
	
		<li>{Get 5 batang of serai geprek. </li>
	
		<li>{Get 2 batang of kemangi petik daunnya. </li>
	
		<li>{Take 100 gr of daun bawang / bawang prei. </li>
	
		<li>{Prepare 1 lembar of daun kunyi belah 2. </li>
	
		<li>{Make ready secukupnya of garam micin. </li>
	
		<li>{Take  of air. </li>
	
		<li>{Get  of bahan teri :. </li>
	
		<li>{Prepare 2 ons of ikan teri. </li>
	
		<li>{Prepare 6 siung of bawang merah. </li>
	
		<li>{Take 2 siung of bawang putih. </li>
	
		<li>{Make ready 15 btg of cabe (sesuai selera). </li>
	
		<li>{Make ready sedikit of cuka. </li>
	
		<li>{Make ready secukupnya of terasi. </li>
	
		<li>{Prepare  of sambal dabu. </li>
	
		<li>{Take 10 biji of cabe. </li>
	
		<li>{Make ready 4 bh of tomat iris kecil. </li>
	
		<li>{Make ready 6 bh of bawang merah. </li>
	
		<li>{Make ready 1 bungkus of terasi. </li>
	
		<li>{Make ready secukupnya of garam micin. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur manado sambal dabu + ikan teri maknyus:</h3>

<ol>
	
		<li>
			Cuci bersih beras, petik sayuran.. Masukan beras, jagung, labu kuning, serai dan air.. masak hingga menjadi bubur.
			
			
		</li>
	
		<li>
			Masukan bayam, kangkung, daun kunyit, bawang prei, kemangi aduk rata tambahkan micin dan garam.. rasa hingga pas sesuai selera. Matikan api.
			
			
		</li>
	
		<li>
			Kemudian blender hingga halus bumbu untuk teri, sisihkan.. goreng teri dgn api kecil hingga garing. Kemudian angkat teri. Tumis bumbu halus hingga harum, masukan teri aduk2 tambahkan sedikit cuka dan micin. Tes rasa.. jika sudah pas matikan api.. siap disajikan.
			
			
		</li>
	
		<li>
			Sambal dabu : Iris tipis bawang merah.. Ulek cabe kemudian masukan terasi.. baru masukan tomat yg sudah di iris kecil ulek kasar.. masukan bawang merah yg diiris tipis tambahkan garam dan micin.. aduk rata. Siap disajikan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this exceptional food bubur manado sambal dabu + ikan teri maknyus recipe. Thanks so much for reading. I'm sure that you will make this at home. There is gonna be interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
