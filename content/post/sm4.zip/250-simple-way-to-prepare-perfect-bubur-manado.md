---
description: "Simple Way to Prepare Perfect Bubur Manado"
title: "Simple Way to Prepare Perfect Bubur Manado"
slug: 250-simple-way-to-prepare-perfect-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/77c10aec8262140d/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you are having an amazing day today. Today, I will show you a way to prepare a distinctive dish, bubur manado. It is one of my favorites food recipes. For mine, I will make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Manado is one of the most well liked of recent trending foods on earth. It is enjoyed by millions daily. It is simple, it's fast, it tastes yummy. Bubur Manado is something which I've loved my whole life. They're nice and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we must first prepare a few ingredients. You can have bubur manado using 14 ingredients and 4 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Get 2 mug of beras cuci bersih. </li>
	
		<li>{Make ready 2 batang of sereh. </li>
	
		<li>{Prepare 2 helai of daun salam. </li>
	
		<li>{Make ready 1 bonggol of jagung pipil. </li>
	
		<li>{Prepare 1/2 bulatan of labu kuning (potong potong). </li>
	
		<li>{Take 1 buah of wortel ukuran sedang (potong potong). </li>
	
		<li>{Prepare 2 helai of kacang panjang (potong potong). </li>
	
		<li>{Get 1 ikat of kangkung tanpa batang (siangi). </li>
	
		<li>{Take 1 ikat of kemangi (siangi). </li>
	
		<li>{Prepare 1 batang of singkong bukuran kecil (kupas kemudian potong). </li>
	
		<li>{Get Secukupnya of garam,gula,merica dan kaldu bubuk. </li>
	
		<li>{Take  of BUMBU HALUS (ditumis terpisah). </li>
	
		<li>{Prepare 4 siung of bawang merah. </li>
	
		<li>{Take 3 siung of bawang putih. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Manado:</h3>

<ol>
	
		<li>
			Siapkan semua bahan. Didihkan air. Tuang beras, jagung pipil, labu kuning, singkong dan wortel. Masak hingga empuk..
			
			
		</li>
	
		<li>
			Masukkan sereh dan daun salam. Aduk aduk kembali (saya masak dengan ditutup). Tumis bumbu halus. Tuang kedalam adonan bubur yang telah empuk. Tuang tumisan bawang. Beri garam,gula pasir, merica bubuk dan kaldu bubuk. Masak hingga sayuran empuk (hancurkan labu kuning hingga kuah kaldu berwarna kuning)
5. Masukkan kacang panjang. Tunggu empuk kembali. 
6. Sesaat sebelum mematikan kompor masukkan kangkung dan kemangi. Koreksi rasa. 
7. Sajikan dengan bahan pelengkap. Yummy 😍😍😍.
			
			
		</li>
	
		<li>
			Masukkan kacang panjang. Tunggu empuk kembali. Sesaat sebelum mematikan kompor masukkan kangkung dan kemangi..
			
			
		</li>
	
		<li>
			Koreksi rasa. Sajikan dengan bahan pelengkap. Yummy banget moms 😍😍😍.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this exceptional food bubur manado recipe. Thank you very much for your time. I'm sure you can make this at home. There is gonna be interesting food in home recipes coming up. Remember to bookmark this page in your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
