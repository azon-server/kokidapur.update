---
description: "Easiest Way to Prepare Speedy Bubur kacang ijo"
title: "Easiest Way to Prepare Speedy Bubur kacang ijo"
slug: 107-easiest-way-to-prepare-speedy-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/50f5f218de922341/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an incredible day today. Today, we're going to make a distinctive dish, bubur kacang ijo. It is one of my favorites food recipes. This time, I am going to make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo is one of the most favored of recent trending foods on earth. It's appreciated by millions daily. It's easy, it is fast, it tastes yummy. Bubur kacang ijo is something which I've loved my entire life. They are nice and they look fantastic.
</p>

<p>
To get started with this particular recipe, we have to first prepare a few ingredients. You can cook bubur kacang ijo using 5 ingredients and 9 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Get 100 gr of kacang ijo. </li>
	
		<li>{Get 250 ml of susu cair. </li>
	
		<li>{Get 2 sachet of susu kental manis. </li>
	
		<li>{Prepare Sejumput of garam. </li>
	
		<li>{Get 1 sdm of vanilla cair. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Rebus kacang ijo.
			
			
		</li>
	
		<li>
			Hingga air menyusut dan kacang ijo mulai &#39;mekar&#39; tandanya mateng dan udah empuk.
			
			
		</li>
	
		<li>
			Masukan susu cair.
			
			
		</li>
	
		<li>
			Masukan susu kental manis, Jika kurang manis boleh di tambahkan gula pasir, tergantung selera yah.
			
			
		</li>
	
		<li>
			Masukan garam.
			
			
		</li>
	
		<li>
			Masukan 1 sdm vanilla.
			
			
		</li>
	
		<li>
			Aduk dan masak sebentar hingga mendidih.
			
			
		</li>
	
		<li>
			Bubur kacang ijo udah siap, jangan lupa tes rasa yah.. resep ini saya buat berdasarkan selera saya yang kurang suka terlalu manis.
			
			
		</li>
	
		<li>
			Paling nikmat bubur kacang ijo itu di makan dengan roti tawar... Alhamdulillah nikmat... selamat mencoba. Selamat menikmati..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this special food bubur kacang ijo recipe. Thank you very much for your time. I'm sure you will make this at home. There's gonna be interesting food in home recipes coming up. Remember to bookmark this page on your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
