---
description: "Easiest Way to Prepare Perfect Bubur kacang ijo"
title: "Easiest Way to Prepare Perfect Bubur kacang ijo"
slug: 136-easiest-way-to-prepare-perfect-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/5f735a97496ef79c/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you're having an incredible day today. Today, I will show you a way to make a special dish, bubur kacang ijo. It is one of my favorites food recipes. For mine, I'm gonna make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo is one of the most favored of current trending foods in the world. It is easy, it's fast, it tastes delicious. It is appreciated by millions daily. Bubur kacang ijo is something that I've loved my entire life. They are nice and they look wonderful.
</p>

<p>
To begin with this particular recipe, we have to first prepare a few components. You can cook bubur kacang ijo using 7 ingredients and 4 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Prepare 250 gr of kacang ijo rendam semalaman. </li>
	
		<li>{Make ready 2 Gandu of gula merah. </li>
	
		<li>{Prepare 1 sdm of maizena+air untuk pengental. </li>
	
		<li>{Get 600 ml of santan kental. </li>
	
		<li>{Prepare 200 ml of air. </li>
	
		<li>{Make ready 2 lembar of daun pandan. </li>
	
		<li>{Get Sejumput of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Didihkan air masukkan kacang hijau dan daun pandan sampai air menyusut.
			
			
		</li>
	
		<li>
			Tambahkan gula,garam masak sampai lunak masukkan campuran maizena aduk sampai mendidih dan matikan.
			
			
		</li>
	
		<li>
			Masak santan sampai mendidih sambil diaduk terus agar tdk pecah tambahkan daun pandan dan sedikit garam.
			
			
		</li>
	
		<li>
			Sajikan bubur kacang dan tambahkan santan diatasnya.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur kacang ijo recipe. Thank you very much for your time. I am confident you can make this at home. There is gonna be interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
