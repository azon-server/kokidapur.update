---
description: "Steps to Make Homemade Bubur Manado"
title: "Steps to Make Homemade Bubur Manado"
slug: 366-steps-to-make-homemade-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/dcf4becdf982fbdc/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's John, welcome to our recipe site. Today, we're going to prepare a special dish, bubur manado. It is one of my favorites food recipes. This time, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Manado is one of the most popular of recent trending foods in the world. It is easy, it's fast, it tastes delicious. It's enjoyed by millions every day. They're nice and they look wonderful. Bubur Manado is something that I've loved my whole life.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we have to first prepare a few components. You can have bubur manado using 12 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Get 100 gram of beras. </li>
	
		<li>{Take 100 gr of bayam batik. </li>
	
		<li>{Get 1/2 buah of labu kuning. </li>
	
		<li>{Get 70 gr of kangkung. </li>
	
		<li>{Get 1 buah of jagung. </li>
	
		<li>{Get 40 gram of bawang putih kupas. </li>
	
		<li>{Prepare 2 batang of daun bawang. </li>
	
		<li>{Get 4 of daun jeruk. </li>
	
		<li>{Take 2 of serai. </li>
	
		<li>{Prepare 1 of daun pandan. </li>
	
		<li>{Prepare 1 ikat of kemangi (30 gram). </li>
	
		<li>{Get 1600 ml of air. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Manado:</h3>

<ol>
	
		<li>
			Potong dadu labu siam, geprek bawang putih &amp; serai, siangi sayuran, sisir jagung..
			
			
		</li>
	
		<li>
			Didihkan air dalam panci. Masukkan labu siam, jagung &amp; beras.
			
			
		</li>
	
		<li>
			Tumis bawang putih &amp; daun bawang. Masukkan dalam panci.
			
			
		</li>
	
		<li>
			Tambahkan garam. Aduk rata sampai bubur matang, daun jeruk, serai, pandan..
			
			
		</li>
	
		<li>
			Setelah bubur matang masukkan sayuran, aduk rata kira kira 2-3 menit, icipi rasa. Sajikan dg ikan asin goreng &amp; sambal terasi..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this special food bubur manado recipe. Thank you very much for your time. I'm sure you will make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
