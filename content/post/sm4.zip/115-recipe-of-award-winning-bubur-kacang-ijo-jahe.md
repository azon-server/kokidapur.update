---
description: "Recipe of Award-winning Bubur Kacang Ijo Jahe"
title: "Recipe of Award-winning Bubur Kacang Ijo Jahe"
slug: 115-recipe-of-award-winning-bubur-kacang-ijo-jahe

<p>
	<strong>Bubur Kacang Ijo Jahe</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/b7badf3f37178dfb/680x482cq70/bubur-kacang-ijo-jahe-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Jahe" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's Louise, welcome to my recipe site. Today, I'm gonna show you how to make a special dish, bubur kacang ijo jahe. One of my favorites food recipes. This time, I am going to make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo Jahe is one of the most popular of recent trending meals in the world. It's simple, it's fast, it tastes yummy. It's appreciated by millions every day. Bubur Kacang Ijo Jahe is something which I've loved my whole life. They're fine and they look fantastic.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we must prepare a few components. You can cook bubur kacang ijo jahe using 7 ingredients and 4 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Jahe:</h3>

<ol>
	
		<li>{Prepare 200 gr of kacang ijo. </li>
	
		<li>{Take 150 ml of santan. </li>
	
		<li>{Take 150 ml of air. </li>
	
		<li>{Take 100 gr of Gula Merah. </li>
	
		<li>{Make ready 2 sdm of Gula Pasir. </li>
	
		<li>{Prepare 1 sdt of Garam. </li>
	
		<li>{Make ready 1 Ruas of Jahe. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo Jahe:</h3>

<ol>
	
		<li>
			Rendam kacang ijo beberapa jam sblm di masak agar lbh mengembang dan mempercepat proses pemasakan/pengolahan..
			
			
		</li>
	
		<li>
			Masukkan Air ke dalam panci lalu tambahkan kacang ijo tambahkan gula merah tunggu hingga hampir mendidih..
			
			
		</li>
	
		<li>
			Setelah hampir mendidih masukkan garam, jahe,gula pasir dan santan aduk trus agar kental..
			
			
		</li>
	
		<li>
			Setelah masak siap di sajikan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food bubur kacang ijo jahe recipe. Thanks so much for your time. I am confident that you will make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
