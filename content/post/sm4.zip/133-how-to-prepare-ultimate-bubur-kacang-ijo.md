---
description: "How to Prepare Ultimate Bubur kacang ijo"
title: "How to Prepare Ultimate Bubur kacang ijo"
slug: 133-how-to-prepare-ultimate-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/aa2ddb57319c09bf/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you're having an incredible day today. Today, I'm gonna show you how to make a distinctive dish, bubur kacang ijo. It is one of my favorites. This time, I am going to make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo is one of the most well liked of recent trending foods on earth. It is easy, it's quick, it tastes delicious. It's enjoyed by millions daily. They are nice and they look fantastic. Bubur kacang ijo is something which I have loved my entire life.
</p>

<p>
To begin with this recipe, we must first prepare a few components. You can have bubur kacang ijo using 6 ingredients and 4 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Prepare 3 genggam of kacang ijo. </li>
	
		<li>{Take 1 sachet of santan bubuk. </li>
	
		<li>{Get 3 sdm of tepung beras (untuk yang suka kental). </li>
	
		<li>{Take secukupnya of Garam. </li>
	
		<li>{Get 1 butir of gula merah. </li>
	
		<li>{Prepare secukupnya of Gula pasir. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Cuci bersih kacang ijo. Rebus hingga empuk..
			
			
		</li>
	
		<li>
			Tambahkan gula merah dan garam..
			
			
		</li>
	
		<li>
			Seduh santan dan tepung beras menggunakan air matang..
			
			
		</li>
	
		<li>
			Masukkan adonan santan dan tepung beras ke dalam rebusan kacang ijo. Tambahkan gula pasir. Aduk hingga rata. Tunggu hingga mendidih..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this exceptional food bubur kacang ijo recipe. Thanks so much for your time. I'm sure you will make this at home. There's gonna be more interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
