---
description: "Recipe of Favorite 🌈 Bubur Manado Pelangi"
title: "Recipe of Favorite 🌈 Bubur Manado Pelangi"
slug: 264-recipe-of-favorite-bubur-manado-pelangi

<p>
	<strong>🌈 Bubur Manado Pelangi</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/05a78f1cf7da8cae/680x482cq70/🌈-bubur-manado-pelangi-foto-resep-utama.jpg" alt="🌈 Bubur Manado Pelangi" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you're having an amazing day today. Today, I will show you a way to make a distinctive dish, 🌈 bubur manado pelangi. One of my favorites. This time, I am going to make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	🌈 Bubur Manado Pelangi is one of the most well liked of recent trending meals in the world. It's appreciated by millions every day. It is simple, it is fast, it tastes yummy. They are fine and they look fantastic. 🌈 Bubur Manado Pelangi is something that I've loved my entire life.
</p>

<p>
To get started with this particular recipe, we have to prepare a few components. You can cook 🌈 bubur manado pelangi using 13 ingredients and 4 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make 🌈 Bubur Manado Pelangi:</h3>

<ol>
	
		<li>{Prepare 1 gelas of beras. </li>
	
		<li>{Take 1 L of air. </li>
	
		<li>{Get secukupnya of Garam. </li>
	
		<li>{Take secukupnya of Kaldu bubuk. </li>
	
		<li>{Prepare  of Sayuran (bisa sesuaikan apa yang ada). </li>
	
		<li>{Make ready 1 of ubi ungu, potong dadu. </li>
	
		<li>{Take 1 of wortel, potong dadu. </li>
	
		<li>{Get 2 genggam of daun kelor. </li>
	
		<li>{Make ready 2 genggam of kemangi. </li>
	
		<li>{Prepare  of Pelengkap. </li>
	
		<li>{Make ready  of Tumis cakalang pedas (optional). </li>
	
		<li>{Make ready  of Sambal. </li>
	
		<li>{Take sesuai selera of Ikan asin. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make 🌈 Bubur Manado Pelangi:</h3>

<ol>
	
		<li>
			Panaskan air dan beras di panci. Aduk-aduk sesekali hingga mengental menjadi bubur, dengan konsistensi sesuai selera..
			
			
		</li>
	
		<li>
			Masukkan ubi dan wortel, masak hingga lunak. Beri garam dan kaldu bubuk, koreksi rasa..
			
			
		</li>
	
		<li>
			Rebus daun kelor selama 3 menit. Masukkan ke dalam panci bubur bersama daun kemangi. Aduk hingga tercampur rata..
			
			
		</li>
	
		<li>
			Sajikan di mangkuk, beri pelengkap sesuai selera. Makin mantap pakai ikan asin (saya pakai teri medan) dan sambal uleg (saya pakai sambal botolan saja biar praktis)..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this exceptional food 🌈 bubur manado pelangi recipe. Thanks so much for your time. I'm confident you will make this at home. There's gonna be interesting food in home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
