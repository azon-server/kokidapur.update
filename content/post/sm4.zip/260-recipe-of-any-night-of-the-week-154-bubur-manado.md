---
description: "Recipe of Any-night-of-the-week 154. Bubur Manado"
title: "Recipe of Any-night-of-the-week 154. Bubur Manado"
slug: 260-recipe-of-any-night-of-the-week-154-bubur-manado

<p>
	<strong>154. Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/466259284bcc3a86/680x482cq70/154-bubur-manado-foto-resep-utama.jpg" alt="154. Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an incredible day today. Today, we're going to prepare a distinctive dish, 154. bubur manado. It is one of my favorites food recipes. For mine, I am going to make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	154. Bubur Manado is one of the most popular of current trending foods in the world. It's simple, it is fast, it tastes delicious. It's appreciated by millions daily. They are fine and they look fantastic. 154. Bubur Manado is something that I've loved my entire life.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to first prepare a few components. You can cook 154. bubur manado using 18 ingredients and 7 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make 154. Bubur Manado:</h3>

<ol>
	
		<li>{Prepare 2 cup of beras (bisa 1 cup saja). </li>
	
		<li>{Prepare 3.5 liter of air (1 cup= 1,5-1,7l). </li>
	
		<li>{Make ready 1/4 of labu kuning (lebih enak 1/2 labu). </li>
	
		<li>{Prepare 1 buah of ubi jalar (saya lagi habis). </li>
	
		<li>{Prepare 1 buah of singkong (saya lagi habis). </li>
	
		<li>{Prepare 1 ikat of bayam. </li>
	
		<li>{Make ready 1 ikat of kankung. </li>
	
		<li>{Prepare 2 buah of jagung pipil. </li>
	
		<li>{Prepare 1 sdm of garam (tidak munjung u/2 cup). </li>
	
		<li>{Take 1 sdm of kaldu jamur. </li>
	
		<li>{Prepare 2 ikat of kemangi. </li>
	
		<li>{Take 2 helai of daun bawang (rajang kasar). </li>
	
		<li>{Take  of BUMBU CEMPLUNG:::. </li>
	
		<li>{Take 2 lembar of daun salam. </li>
	
		<li>{Take 1 batang of serai. </li>
	
		<li>{Make ready 4 lembar of daun jeruk. </li>
	
		<li>{Prepare 1 lembar of daun kunyit. </li>
	
		<li>{Make ready 1 lembar of daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make 154. Bubur Manado:</h3>

<ol>
	
		<li>
			Cuci bersih beras setelah itu rendam beras 30-60 menit kemudian panaskan api. Untuk labu, singkong dan ubi potong kotak-kotak kecil. Kangkung dan bayam ambil bagian dari daun sampai tangkainya yang kecil..
			
			
		</li>
	
		<li>
			Jika sudah mendidih, masukkan beras yang sudah direndam tadi. Aduk-aduk sebentar kemudian tutup dan masak sampai beras jadi mekar digambar no.3. Oh iya saya pakai api sedang ya..
			
			
		</li>
	
		<li>
			Jika sudah, masukkan semua bumbu cemplung dan tambahkan potongan labu kuningnya. Jika ada ubi dan singkong boleh dimasukkan sekarang. Lebih enak kalau 3 sejoli itu hancur...😋.
			
			
		</li>
	
		<li>
			Masak sampai labu matang ya (udah setengah empuk) dan jangan lupa sambil nunggu proses matang sesekali tetap diaduk--tetap pakai api sedang. Nah jika sudah, kecilkan api tapi jangan mentok, masukkan jagung..
			
			
		</li>
	
		<li>
			Kemudian tambahkan garam dan kaldu bubuk. Nah saat ini harus sering ngaduk agar bawah tidak gosong. Dan jangan pernah mindah ke api yang besar biar bisa matang sempurna..
			
			
		</li>
	
		<li>
			Jika sudah empuk semua dan semakin mengental masukkan daun bayam dan kangkung. Dilanjut masukkan daun kemangi dan potongan daun bawang..
			
			
		</li>
	
		<li>
			Koreksi rasa ya...bisa tambahkan kaldu bubuk lagi jika kurang. Jika sudah layu bisa dimatikan...kalau ada yang suka dihasil akhirnya bisa ditambah air perasan jeruk nipis 1 biji. Angkat dan sajikan dengan ikan asin dan sambal..dijamin enakkkkkk (sayangnya bukan ikan roa 😆)..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this special food 154. bubur manado recipe. Thank you very much for reading. I am confident you will make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to save this page in your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
