---
description: "Steps to Prepare Perfect Bubur Kacang Ijo"
title: "Steps to Prepare Perfect Bubur Kacang Ijo"
slug: 121-steps-to-prepare-perfect-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/25a3aefbe3f87d2c/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you're having an incredible day today. Today, we're going to prepare a distinctive dish, bubur kacang ijo. One of my favorites. For mine, I'm gonna make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo is one of the most favored of recent trending foods in the world. It's easy, it's quick, it tastes yummy. It is enjoyed by millions daily. They are fine and they look fantastic. Bubur Kacang Ijo is something that I've loved my entire life.
</p>

<p>
To get started with this particular recipe, we have to first prepare a few ingredients. You can cook bubur kacang ijo using 14 ingredients and 5 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Prepare 250 gr of Kacang ijo (rendam 12 jam). </li>
	
		<li>{Take 8 sdm of Gula pasir. </li>
	
		<li>{Take 1 bongkah of gula jawa. </li>
	
		<li>{Prepare 1 ruas of jahe. </li>
	
		<li>{Make ready 1 batang of pandan, iris atau ikat. </li>
	
		<li>{Prepare 1 sdt of garam. </li>
	
		<li>{Prepare 750 ml of air. </li>
	
		<li>{Prepare 3 sdm of maizena. </li>
	
		<li>{Get  of bahan santan. </li>
	
		<li>{Prepare 65 ml of santan kental (bisa pake santan Instan). </li>
	
		<li>{Make ready 200 ml of air. </li>
	
		<li>{Make ready Sejumput of garam. </li>
	
		<li>{Prepare  of Daun pandan. </li>
	
		<li>{Make ready 1 sdm of maizena. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Rendam Kancang hijau selama 12 jam atau 1 hari supaya empuk dan memasaknya lebih cepat.
			
			
		</li>
	
		<li>
			Siapkan air, jahe, pandan, gula jawa dan gula pasirdan rebus hingga aromanya keluar.
			
			
		</li>
	
		<li>
			Masukan kacang hijau dan masak hingga empuk, tanda kacang ijo sudah empuk - sudah mulai pecah kacangnya, lalu tambahkan maizena yg sudah dicampur air..
			
			
		</li>
	
		<li>
			CARA MEMBUAT SANTAN : Rebus, air, santan kental, pandan, garam, maizena cair dengan api kecil hingga mendidih.
			
			
		</li>
	
		<li>
			Dan bubur kacang hijau siap dihidangkan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this special food bubur kacang ijo recipe. Thank you very much for your time. I am confident that you can make this at home. There's gonna be more interesting food in home recipes coming up. Remember to bookmark this page on your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
