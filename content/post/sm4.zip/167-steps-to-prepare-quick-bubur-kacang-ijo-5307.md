---
description: "Steps to Prepare Quick Bubur Kacang Ijo (5.30.7)"
title: "Steps to Prepare Quick Bubur Kacang Ijo (5.30.7)"
slug: 167-steps-to-prepare-quick-bubur-kacang-ijo-5307

<p>
	<strong>Bubur Kacang Ijo (5.30.7)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/35765b35bed024fd/680x482cq70/bubur-kacang-ijo-5307-foto-resep-utama.jpg" alt="Bubur Kacang Ijo (5.30.7)" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you are having an amazing day today. Today, I will show you a way to make a distinctive dish, bubur kacang ijo (5.30.7). One of my favorites. This time, I will make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo (5.30.7) is one of the most well liked of current trending foods on earth. It's easy, it is quick, it tastes delicious. It's enjoyed by millions daily. Bubur Kacang Ijo (5.30.7) is something which I've loved my whole life. They are nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to prepare a few components. You can cook bubur kacang ijo (5.30.7) using 9 ingredients and 7 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo (5.30.7):</h3>

<ol>
	
		<li>{Get 100 gr of kacang hijau (beli 3000 perak). </li>
	
		<li>{Get 100 gr of gula jawa, sisir (saya 2 keping kecil). </li>
	
		<li>{Take 600 ml of air, untuk perebusan awal. </li>
	
		<li>{Prepare 200 ml of air, tambahkan di langkah ke-3. </li>
	
		<li>{Get 165 ml of santan (1 sachet kecil santan instan +100ml air matang). </li>
	
		<li>{Make ready 1-2 sdm of gula pasir (munjung). </li>
	
		<li>{Take 1/2 sdt of garam (dilarutkan dalam santan). </li>
	
		<li>{Take Sejumput of garam, dilarutkan dalam rebusan kacang ijo. </li>
	
		<li>{Make ready 1-2 lembar of daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo (5.30.7):</h3>

<ol>
	
		<li>
			Pertama, cuci bersih kacang hijau dan tiriskan. Rebus 600ml air hingga mendidih dalam panci tertutup. Kemudian masukkan kacang hijau dan daun pandan. Tutup panci. Rebus selama 5 menit, gunakan api besar. Lalu matikan api, diamkan panci dalam keadaan tertutup..
			
			
		</li>
	
		<li>
			Sementara itu, gunakan panci lain, kita rebus santan. Saya menggunakan santan instan. Tapi bisa juga menggunakan santan segar. Aduk-aduk santan hingga larut rata, tambahkan garam. Lalu masak di atas api sedang hingga meletup (tak usah sampai mendidih banget, tapi pastikan santan telah matang). Sekadar tips, saya menggunakan air matang di sini. Jangan lupa aduk terus santan selama dimasak agar tidak pecah..
			
			
		</li>
	
		<li>
			Setelah santan matang, sisihkan..
			
			
		</li>
	
		<li>
			Kita kembali ke panci yang berisi kacang hijau. Setelah 30 menit berlalu, masuk ke langkah terakhir, yaitu rebus kembali kacang hijau selama 7 menit. Lebih baik dalam keadaan panci tertutup agar kacang cepat empuk. Masukkan sisiran gula jawa, sejumput garam, dan sedikit gula pasir. Hati-hati, air akan menyusut habis. Jika suka bubur yang kental, maka setelah kacang merekah, segera matikan api. Sudah matang. Proses memasak selesai di sini..
			
			
		</li>
	
		<li>
			Jika suka bubur yang berkuah banyak, maka tambahkan sekitar 200ml air, masak hingga mendidih. Tes rasa, dan matikan api..
			
			
		</li>
	
		<li>
			Enak disajikan hangat, dengan dicampurkan santan yang kita buat tadi..
			
			
		</li>
	
		<li>
			Hmmm....yummyyy....😉. Bisa juga ditambahkan jahe, rebus bersama gula merah. Tapi karena saya tidak suka maka tidak pakai..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur kacang ijo (5.30.7) recipe. Thanks so much for reading. I am confident that you can make this at home. There's gonna be more interesting food in home recipes coming up. Don't forget to save this page on your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
