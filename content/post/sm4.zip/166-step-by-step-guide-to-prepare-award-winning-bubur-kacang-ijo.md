---
description: "Step-by-Step Guide to Prepare Award-winning Bubur kacang ijo"
title: "Step-by-Step Guide to Prepare Award-winning Bubur kacang ijo"
slug: 166-step-by-step-guide-to-prepare-award-winning-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/316366a495c2cc50/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, I will show you a way to make a special dish, bubur kacang ijo. One of my favorites. For mine, I am going to make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo is one of the most well liked of current trending meals on earth. It's easy, it's quick, it tastes delicious. It's enjoyed by millions every day. They're fine and they look fantastic. Bubur kacang ijo is something that I have loved my entire life.
</p>

<p>
To begin with this recipe, we have to first prepare a few ingredients. You can have bubur kacang ijo using 5 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Get 2 genggam of kacang hijau. </li>
	
		<li>{Make ready 5 sdm of gula merah sisir. </li>
	
		<li>{Make ready 3 sdm of gula putih. </li>
	
		<li>{Prepare 150 ml of santan kental instan. </li>
	
		<li>{Get  of Air. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Siapkan bahan..
			
			
		</li>
	
		<li>
			Didihkan 1 gelas blimbing air matang. Masukkan kacang hijau. Masak selama 10 menit. Matikan kompor. Diamkan selama 2 jam. Biarkan kacang hijau menjadi empuk..
			
			
		</li>
	
		<li>
			Setelah 2 jam, masak lagi kacang hijau, tambahkan 3 gelas blimbing air matang..
			
			
		</li>
	
		<li>
			Tambahkan gula merah dan gula pasir. Aduk sambil menekan kacang hijau. Koreksi rasa. Setelah rasa pas, kacang hijau sudah &#34;pecah&#34;, masukkan santan kental instan. Masak hingga matang..
			
			
		</li>
	
		<li>
			Bubur kacang hijau siap disantap..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this special food bubur kacang ijo recipe. Thanks so much for reading. I am confident that you can make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
