---
description: "Steps to Make Homemade Bubur kacang ijo &amp;amp; ketan  hitam#MenuSehatAnak"
title: "Steps to Make Homemade Bubur kacang ijo &amp;amp; ketan  hitam#MenuSehatAnak"
slug: 211-steps-to-make-homemade-bubur-kacang-ijo-and-amp-ketan-hitammenusehatanak

<p>
	<strong>Bubur kacang ijo &amp; ketan  hitam#MenuSehatAnak</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/e8ee4d259e77c907/680x482cq70/bubur-kacang-ijo-ketan-hitammenusehatanak-foto-resep-utama.jpg" alt="Bubur kacang ijo &amp; ketan  hitam#MenuSehatAnak" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's Brad, welcome to our recipe page. Today, I will show you a way to make a special dish, bubur kacang ijo &amp; ketan  hitam#menusehatanak. One of my favorites. For mine, I am going to make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo &amp; ketan  hitam#MenuSehatAnak is one of the most popular of recent trending foods in the world. It's appreciated by millions every day. It is simple, it's fast, it tastes delicious. Bubur kacang ijo &amp; ketan  hitam#MenuSehatAnak is something that I have loved my entire life. They're nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to prepare a few components. You can cook bubur kacang ijo &amp; ketan  hitam#menusehatanak using 20 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo &amp; ketan  hitam#MenuSehatAnak:</h3>

<ol>
	
		<li>{Prepare  of Bahan bubur kacang hijau :. </li>
	
		<li>{Make ready 2 ons of kacang hijau. </li>
	
		<li>{Make ready 3 block of gula merah. </li>
	
		<li>{Take 1 ruas of jahe. </li>
	
		<li>{Prepare 3 lembar of daun pandan. </li>
	
		<li>{Make ready 1/4 sdt of vanili bubuk. </li>
	
		<li>{Make ready 2 sdm of tepung maizena. </li>
	
		<li>{Make ready 2 liter of air. </li>
	
		<li>{Get 1 sdm of gula pasir. </li>
	
		<li>{Make ready 1 bungkus of santan instant. </li>
	
		<li>{Get  of Bahan bubur ketan hitam :. </li>
	
		<li>{Prepare 1 cup kecil of beras ketan hitam. </li>
	
		<li>{Take secukupnya of garam. </li>
	
		<li>{Prepare 5 tangkai of daun pandan. </li>
	
		<li>{Prepare 3 block of gula merah. </li>
	
		<li>{Take 2 ruas kecil of jahe. </li>
	
		<li>{Make ready secukupnya of Vanili. </li>
	
		<li>{Prepare 4 liter of air. </li>
	
		<li>{Prepare 1 sdm of gula pasir. </li>
	
		<li>{Make ready 1 bungkus of santan instant. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo &amp; ketan  hitam#MenuSehatAnak:</h3>

<ol>
	
		<li>
			Bubur kacang ijo: rebus 2 liter air sampai mendidih baru masukan kacang hijau yang sdh direndam dan jahe geprek rebus sampai lunak masukan daun pandan gula merah garam dan vanili biarkan sampai air agak menyusut lalu masukan tepung maizena yg sdh dicampur air sebagai pengental bubur koreksi rasa bila kurabg manis bisa tambahkan gula pasir setelah bubur mengental baru angkat sisihkan.
			
			
		</li>
	
		<li>
			Bubur ketan hitam : cuci beras ketan masukan kedalam 2 liter rebusan air yg mendidih lalu aduk masukan jahe geprek, gula merah, daun pandan, vanili bubuk, garam biarkan beras ketan mengental sampai menjadi bubur koreksi rasa jika kurang manis bisa ditambahkan gula pasir setelah matang angkat sajikan..
			
			
		</li>
	
		<li>
			Masak santan dengan api agak kecil campur sedikit air dan garam angkat sisihkan.
			
			
		</li>
	
		<li>
			Penyajian: siapkan mangkuk masukan bubur ketan hitam disebelah kiri dan bubur kacang hijau sebelah kanan mangkuk mau dipisah ataupun di mix sama aja enaknya lalu siram dengan santan agak kental yg sudah dimasak oh ya yg diphoto cookpad sy masukan susu yg biasa diminum jagoan sy makanya dia jd mau dan Suka menyantap bubur yg saya bikin..
			
			
		</li>
	
		<li>
			Selamat mencoba.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur kacang ijo &amp; ketan  hitam#menusehatanak recipe. Thanks so much for reading. I'm sure that you will make this at home. There is gonna be more interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
