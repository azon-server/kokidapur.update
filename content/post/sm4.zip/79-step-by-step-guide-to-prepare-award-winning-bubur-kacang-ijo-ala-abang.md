---
description: "Step-by-Step Guide to Prepare Award-winning Bubur kacang ijo ala abang²"
title: "Step-by-Step Guide to Prepare Award-winning Bubur kacang ijo ala abang²"
slug: 79-step-by-step-guide-to-prepare-award-winning-bubur-kacang-ijo-ala-abang

<p>
	<strong>Bubur kacang ijo ala abang²</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/0f099f0f1cf2194d/680x482cq70/bubur-kacang-ijo-ala-abang-foto-resep-utama.jpg" alt="Bubur kacang ijo ala abang²" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's Drew, welcome to our recipe site. Today, I'm gonna show you how to make a distinctive dish, bubur kacang ijo ala abang². One of my favorites. This time, I am going to make it a bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo ala abang² is one of the most popular of recent trending meals in the world. It is simple, it's quick, it tastes yummy. It is enjoyed by millions every day. They're nice and they look wonderful. Bubur kacang ijo ala abang² is something which I have loved my entire life.
</p>

<p>
To begin with this particular recipe, we must first prepare a few ingredients. You can cook bubur kacang ijo ala abang² using 13 ingredients and 5 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo ala abang²:</h3>

<ol>
	
		<li>{Make ready 1/4 gram of kacang hijau. </li>
	
		<li>{Make ready 1500 ml of air. </li>
	
		<li>{Prepare 4 sdm of gula. </li>
	
		<li>{Make ready 7 butir of gula merah. </li>
	
		<li>{Prepare 1/2 sdt of garam. </li>
	
		<li>{Prepare 3 lembar of daun pandan. </li>
	
		<li>{Take 1 sdm of tapioca yang dilarutkan dngn 1/2 gelas air. </li>
	
		<li>{Make ready  of Kuah santan. </li>
	
		<li>{Make ready 65 ml of santan instan. </li>
	
		<li>{Make ready 300 ml of air. </li>
	
		<li>{Make ready 1/2 sdt of garam. </li>
	
		<li>{Get 1 lembar of daun pandan. </li>
	
		<li>{Prepare 1/2 sdt of maizena yg dilarutkan dngn air. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo ala abang²:</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau. Rebus air, kacang hijau dan pandan. Jika sudah mendidih kecilkan api dan tutup panci, masak selama kurleb 30mnt..
			
			
		</li>
	
		<li>
			Setelah kacang hijau membelah (terlihat bagian dalamnya) masukkan gula dan garam, tunggu hingga gula merah larut..
			
			
		</li>
	
		<li>
			Terakhir masukkan tapioca yang sdh dilarutkan, aduk hingga kental dan mendidih..
			
			
		</li>
	
		<li>
			Untuk kuah santan masukkan semua bahan kecuali larutan maizena. Masak hingga mendidih. Dan masukkan larutan maizena, aduk hingga kental dan mendidih..
			
			
		</li>
	
		<li>
			Sajikan bubur kacang hijau, siram dengan kuah santan. Dan siap di santap selagi panas..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food bubur kacang ijo ala abang² recipe. Thanks so much for your time. I am confident that you can make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
