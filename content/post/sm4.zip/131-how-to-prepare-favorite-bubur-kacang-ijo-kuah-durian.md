---
description: "How to Prepare Favorite Bubur kacang ijo kuah durian"
title: "How to Prepare Favorite Bubur kacang ijo kuah durian"
slug: 131-how-to-prepare-favorite-bubur-kacang-ijo-kuah-durian

<p>
	<strong>Bubur kacang ijo kuah durian</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/f6ed372490220fd4/680x482cq70/bubur-kacang-ijo-kuah-durian-foto-resep-utama.jpg" alt="Bubur kacang ijo kuah durian" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is Louise, welcome to our recipe site. Today, I will show you a way to prepare a distinctive dish, bubur kacang ijo kuah durian. One of my favorites. For mine, I'm gonna make it a bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo kuah durian is one of the most popular of recent trending meals on earth. It is easy, it's quick, it tastes yummy. It is enjoyed by millions daily. They are nice and they look wonderful. Bubur kacang ijo kuah durian is something that I have loved my entire life.
</p>

<p>
To get started with this recipe, we have to first prepare a few components. You can cook bubur kacang ijo kuah durian using 9 ingredients and 4 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo kuah durian:</h3>

<ol>
	
		<li>{Take 1 kg of kacang hijau. </li>
	
		<li>{Prepare 1/2 kg of gula merah. </li>
	
		<li>{Get 1/4 kg of gula pasir. </li>
	
		<li>{Make ready 1 buah of durian lokal. </li>
	
		<li>{Make ready secukupnya of Garam. </li>
	
		<li>{Get 2 bungkus of kara 65gr. </li>
	
		<li>{Prepare secukupnya of Air putih. </li>
	
		<li>{Get 3 lembar of Daun pandan. </li>
	
		<li>{Prepare 5 cm of jahe digeprek. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo kuah durian:</h3>

<ol>
	
		<li>
			Rebus kacang hijau beserta air sampai kacang hijau pecah dan matang sempurna... Sisihkan ditutup rapat lebih baik... Biar semakin mengembang biarkan uap panasnya mengumpul agar kacang hijau benar2 semakin empuk.
			
			
		</li>
	
		<li>
			Rebus gula merah ditempat terpisah sampai larut dan matang saring masukan kedalam kacang hijau yg telah direbus tadi... Dg api sedang aduk2 masukan durian garam... Daun pandan... Gula pasir Aduk perlahan2 tunggu sampai bau durian tercium harum baru matikan kompor.
			
			
		</li>
	
		<li>
			Santan: masukan kara beserta air satu gelas saja aduk perlahan2 tambahkan sejumput garam daun pandan tunggu sampai mendidih angkat sisihkan..
			
			
		</li>
	
		<li>
			Siapkan kacang hijau dan durian lalu siram dg santan kental secukupnya sesuai selera... Kacang hijau siap dinikmati..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur kacang ijo kuah durian recipe. Thanks so much for your time. I am confident that you will make this at home. There is gonna be interesting food in home recipes coming up. Don't forget to save this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
