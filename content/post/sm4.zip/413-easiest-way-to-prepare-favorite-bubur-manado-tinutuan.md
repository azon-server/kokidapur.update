---
description: "Easiest Way to Prepare Favorite Bubur Manado (Tinutuan)"
title: "Easiest Way to Prepare Favorite Bubur Manado (Tinutuan)"
slug: 413-easiest-way-to-prepare-favorite-bubur-manado-tinutuan

<p>
	<strong>Bubur Manado (Tinutuan)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/108bf51256e5cd4d/680x482cq70/bubur-manado-tinutuan-foto-resep-utama.jpg" alt="Bubur Manado (Tinutuan)" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an incredible day today. Today, I will show you a way to prepare a distinctive dish, bubur manado (tinutuan). It is one of my favorites food recipes. This time, I am going to make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Manado (Tinutuan) is one of the most well liked of recent trending meals on earth. It is enjoyed by millions every day. It's easy, it's fast, it tastes yummy. Bubur Manado (Tinutuan) is something that I have loved my whole life. They are nice and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to first prepare a few ingredients. You can cook bubur manado (tinutuan) using 14 ingredients and 7 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Manado (Tinutuan):</h3>

<ol>
	
		<li>{Take 1 cangkir of beras (bersihkan lalu rendam 30 menit). </li>
	
		<li>{Get 1 buah of Batata (ketela pohon/singkong) potong dadu. </li>
	
		<li>{Make ready 1 bagian of labu kuning (potong dadu). </li>
	
		<li>{Make ready 1 buah of jagung (pipil). </li>
	
		<li>{Take 1 ikat of daun kangkung. </li>
	
		<li>{Take 3 lembar of daun gedi (kalau ada). </li>
	
		<li>{Make ready 5 lembar of daun kemangi. </li>
	
		<li>{Prepare 1 batang of sereh. </li>
	
		<li>{Make ready 1 lembar of daun kunyit (potong). </li>
	
		<li>{Make ready 3 buah of tahu (potong dadu). </li>
	
		<li>{Prepare  of Penyedap rasa. </li>
	
		<li>{Prepare  of Garam, gula pasir. </li>
	
		<li>{Make ready 3 siung of Bawang putih. </li>
	
		<li>{Get 1 batang of daun bawang (iris). </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Manado (Tinutuan):</h3>

<ol>
	
		<li>
			Panaskan air, kemudian masukkan beras yg sudah direndam. Aduk terus.
			
			
		</li>
	
		<li>
			Setelah beras cukup lunak, masukkan singkong dan aduh hingga lunak, kemudian masukkan labu kuning, masukkan jagung. Tunggu hingga melunak sambil diaduk aduk.
			
			
		</li>
	
		<li>
			Masukkan bawang putih yg sudah dihaluskan dan daun kunyit..
			
			
		</li>
	
		<li>
			Masukkan sereh yg digeprek, kemudian masukkan garam gula dan penyedap rasa..
			
			
		</li>
	
		<li>
			Jika air dirasa kurang, tambahkan secukupnya..
			
			
		</li>
	
		<li>
			Masukkan daun gedi, kangkung, dan daun kemangi, dan yg terakhir daun bawang..
			
			
		</li>
	
		<li>
			Masak hingga semua lunak dan mendidih. Selamat mencoba. Oiyaa lebih enak dimakan dengan sambel roa. Lihat selanjutnya resep sambel roa 😂.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food bubur manado (tinutuan) recipe. Thank you very much for reading. I am confident that you can make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
