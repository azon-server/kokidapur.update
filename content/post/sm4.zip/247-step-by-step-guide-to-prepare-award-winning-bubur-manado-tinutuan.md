---
description: "Step-by-Step Guide to Prepare Award-winning Bubur Manado (Tinutuan)"
title: "Step-by-Step Guide to Prepare Award-winning Bubur Manado (Tinutuan)"
slug: 247-step-by-step-guide-to-prepare-award-winning-bubur-manado-tinutuan

<p>
	<strong>Bubur Manado (Tinutuan)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/0f629a91afb6cf7f/680x482cq70/bubur-manado-tinutuan-foto-resep-utama.jpg" alt="Bubur Manado (Tinutuan)" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you are having an amazing day today. Today, we're going to prepare a special dish, bubur manado (tinutuan). It is one of my favorites. For mine, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Manado (Tinutuan) is one of the most well liked of current trending meals on earth. It is enjoyed by millions daily. It is simple, it's quick, it tastes delicious. Bubur Manado (Tinutuan) is something which I have loved my entire life. They're nice and they look fantastic.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we must first prepare a few components. You can cook bubur manado (tinutuan) using 13 ingredients and 7 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Manado (Tinutuan):</h3>

<ol>
	
		<li>{Get 1,5 cup of beras. </li>
	
		<li>{Prepare 2 buah of ubi putih/singkong. </li>
	
		<li>{Take 250 gram of labu kuning. </li>
	
		<li>{Take 1 buah of jagung, sisir. </li>
	
		<li>{Make ready 2 ikat of kangkung/bayam (dirajang kecil2). </li>
	
		<li>{Get 1 ikat of kemangi. </li>
	
		<li>{Prepare 4 siung of bawang putih, cincang halus. </li>
	
		<li>{Prepare 3 lembar of daun bawang, rajang kecil2. </li>
	
		<li>{Take 2 lembar of daun salam. </li>
	
		<li>{Get 5 batang of sereh. </li>
	
		<li>{Prepare Secukupnya of garam dan merica. </li>
	
		<li>{Prepare  of Air 2 liter atau lebih. </li>
	
		<li>{Prepare 100 gram of teri medan (tumis sebentar). </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado (Tinutuan):</h3>

<ol>
	
		<li>
			Potong dahulu ubi/singkong dan labu kuning bentuk dadu kecil. Kukus hingga lunak..
			
			
		</li>
	
		<li>
			Masak beras bersama jagung, ubi/singkong dengan air dan sereh+daun salam. Aduk-aduk hingga menjadi bubur..
			
			
		</li>
	
		<li>
			Saat bubur mulai lunak, masukkan labu kuning, sayuran, serta daun bawang, masak terus hingga lunak..
			
			
		</li>
	
		<li>
			Tumis bawang putih bersama sedikit merica, hingga kecoklatan. Masukkan ke dalam bubur, aduk rata. Koreksi rasa, boleh tambahkan garam dan merica secukupnya..
			
			
		</li>
	
		<li>
			Terakhir masukkan daun kemangi. Aduk sebentar, matikan api..
			
			
		</li>
	
		<li>
			Sajikan dengan taburan teri medan di atas nya..
			
			
		</li>
	
		<li>
			Dimakan bareng bakwan jagung dan sambal Roa makin mantap. 🤗.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur manado (tinutuan) recipe. Thank you very much for your time. I am confident you will make this at home. There is gonna be interesting food at home recipes coming up. Remember to bookmark this page on your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
