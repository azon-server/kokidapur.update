---
description: "Easiest Way to Prepare Super Quick Homemade Bubur kacang ijo"
title: "Easiest Way to Prepare Super Quick Homemade Bubur kacang ijo"
slug: 231-easiest-way-to-prepare-super-quick-homemade-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/9f302fbb60425b33/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an amazing day today. Today, I will show you a way to make a distinctive dish, bubur kacang ijo. One of my favorites. For mine, I will make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang ijo is one of the most well liked of current trending meals on earth. It's appreciated by millions daily. It's simple, it's quick, it tastes delicious. They are fine and they look fantastic. Bubur kacang ijo is something that I have loved my whole life.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we must first prepare a few ingredients. You can have bubur kacang ijo using 8 ingredients and 5 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Get 3 cup kecil of kacang hijau. </li>
	
		<li>{Get 1/2 buah of kelapa. </li>
	
		<li>{Take 3 buah of gula merah bundar. </li>
	
		<li>{Take 2 sdm of gula pasir. </li>
	
		<li>{Take 2 ruas of jahe. </li>
	
		<li>{Get 2 buah of daun jeruk. </li>
	
		<li>{Make ready Secukupnya of air. </li>
	
		<li>{Take Secukupnya of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Parut kelapa, kasih air matang 2 gelas lalu peras ambil santanya. Kemudian cuci bersih kacang hijau, lalu rebus kacang hijau dengan air sampai kulit kacang hijau mengelupas dan air menyusut sedikit..
			
			
		</li>
	
		<li>
			Masak gula merah dengan sdkit air setelah itu saring lalu masukan air gula merah ke dalam kacang hijau yg sudah mengelupas kulitnya dan empuk..
			
			
		</li>
	
		<li>
			Masak santan ke dalam panci, masukan jahe yg sudah digeprek, masukan daun jeruk,gula pasur, garam kemudian aduk2 santan terus menerus hingga mendidih dan agak kental. Kalau g diaduk bisa gumpal dan santan pecah..
			
			
		</li>
	
		<li>
			Ambil kacang hijau taruh dimangkuk kemudian, tambahkan santan secukupnya..
			
			
		</li>
	
		<li>
			Kemudian hidangkan, bisa panas atau bisa dijadikan es burjo jika ditambahkan es serut, sirup merah rasa kelapa dan roti tawar yg dipotobg2 dadum selamat menikmati..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this exceptional food bubur kacang ijo recipe. Thanks so much for your time. I'm sure you can make this at home. There's gonna be interesting food in home recipes coming up. Don't forget to save this page on your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
