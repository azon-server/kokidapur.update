---
description: "Step-by-Step Guide to Prepare Any-night-of-the-week BurJo Labu Kental"
title: "Step-by-Step Guide to Prepare Any-night-of-the-week BurJo Labu Kental"
slug: 67-step-by-step-guide-to-prepare-any-night-of-the-week-burjo-labu-kental

<p>
	<strong>BurJo Labu Kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/60b8fd02d4b91a04/680x482cq70/burjo-labu-kental-foto-resep-utama.jpg" alt="BurJo Labu Kental" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is Drew, welcome to our recipe page. Today, we're going to make a distinctive dish, burjo labu kental. One of my favorites. This time, I am going to make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	BurJo Labu Kental is one of the most well liked of recent trending foods in the world. It's easy, it is quick, it tastes yummy. It is appreciated by millions daily. They are fine and they look fantastic. BurJo Labu Kental is something which I have loved my entire life.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we must prepare a few ingredients. You can have burjo labu kental using 7 ingredients and 4 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make BurJo Labu Kental:</h3>

<ol>
	
		<li>{Get 250 gr of kacang ijo, di rendam air dr pagi sampai sore / sebalikny. </li>
	
		<li>{Make ready 200 gr of labu kuning / sesuai selera. </li>
	
		<li>{Make ready 2 gelas of santan dr 1/2 butir kelapa. </li>
	
		<li>{Make ready 3 sdm of tepung tapioka, di cairkan dgn air. </li>
	
		<li>{Make ready 1 lmbr of daun pandan. </li>
	
		<li>{Make ready 200 gr of gula merah, jk kurang manis bisa ditambah gula pasir. </li>
	
		<li>{Prepare  of garam dan vanili. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make BurJo Labu Kental:</h3>

<ol>
	
		<li>
			Rebuslah kacang hijau dengan 3 gelas air sampai lunak, sambil di tambahkan garam, vanili, daun pandan, dan gula.
			
			
		</li>
	
		<li>
			Tambahkan labu, santan, sering di aduk sampai mendidih, dan labu lunak.
			
			
		</li>
	
		<li>
			Tambahkan tepung tapioka cair, sambil di aduk2 sampai mendidih kental.
			
			
		</li>
	
		<li>
			Bubur kacang ijo siap di sajikan hangat2. Selamat Mencoba. 😊😊.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food burjo labu kental recipe. Thanks so much for reading. I am confident you will make this at home. There's gonna be more interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
