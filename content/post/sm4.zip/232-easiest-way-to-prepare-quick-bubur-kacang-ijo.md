---
description: "Easiest Way to Prepare Quick Bubur Kacang Ijo"
title: "Easiest Way to Prepare Quick Bubur Kacang Ijo"
slug: 232-easiest-way-to-prepare-quick-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/0431db9083576037/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is me again, Dan, welcome to my recipe page. Today, I will show you a way to prepare a distinctive dish, bubur kacang ijo. One of my favorites food recipes. For mine, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo is one of the most well liked of current trending foods on earth. It's simple, it's fast, it tastes delicious. It's appreciated by millions daily. Bubur Kacang Ijo is something which I've loved my entire life. They're nice and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to first prepare a few ingredients. You can have bubur kacang ijo using 7 ingredients and 7 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Prepare 150 gr of kacang ijo. </li>
	
		<li>{Make ready 40 gr of gula merah. </li>
	
		<li>{Make ready 3-4 sdm of gula pasir. </li>
	
		<li>{Make ready 1 sdm of susu kental manis. </li>
	
		<li>{Prepare 1 sachet of santan kara 65 ml. </li>
	
		<li>{Take 1 liter of air. </li>
	
		<li>{Get Sejumput of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Rendam kacang ijo semalaman dgn air yg banyak..
			
			
		</li>
	
		<li>
			Rebus 1 liter air sampai mendidih. Kecilkan api lalu masukkan kacang ijo yg sudah direndam semalaman. Aduk2 sampai kacang ijo empuk..
			
			
		</li>
	
		<li>
			Masukkan susu,gula pasir, gula merah, garam &amp; santan. Aduk2 sampai semua bahan matang. Koreksi rasa..
			
			
		</li>
	
		<li>
			Siap disajikan 😊.
			
			
		</li>
	
		<li>
			Note : 1. sebaiknya rendam kacang ijo semalaman ya biar kacang ijonya mekar &amp; nantinya cepet empuk. 2. Air untuk merendam hrs sangat banyak krn klo airnya sedikit ntr jadi kecambah 😂.
			
			
		</li>
	
		<li>
			3. Klo santan udah dituang wajib diaduk2 yaa..klo gak diaduk ntr santannya bisa pecah.
			
			
		</li>
	
		<li>
			4. Boleh ditambah jahe geprek kalo suka.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this special food bubur kacang ijo recipe. Thanks so much for your time. I am confident you can make this at home. There's gonna be interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
