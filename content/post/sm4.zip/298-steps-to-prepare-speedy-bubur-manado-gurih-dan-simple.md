---
description: "Steps to Prepare Speedy Bubur Manado gurih dan simple"
title: "Steps to Prepare Speedy Bubur Manado gurih dan simple"
slug: 298-steps-to-prepare-speedy-bubur-manado-gurih-dan-simple

<p>
	<strong>Bubur Manado gurih dan simple</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/e6c56166af2c04ee/680x482cq70/bubur-manado-gurih-dan-simple-foto-resep-utama.jpg" alt="Bubur Manado gurih dan simple" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's Jim, welcome to our recipe site. Today, I will show you a way to make a special dish, bubur manado gurih dan simple. It is one of my favorites. For mine, I will make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Manado gurih dan simple is one of the most well liked of current trending foods on earth. It's appreciated by millions daily. It is easy, it's fast, it tastes delicious. Bubur Manado gurih dan simple is something that I have loved my entire life. They are nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we must prepare a few ingredients. You can cook bubur manado gurih dan simple using 20 ingredients and 4 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Manado gurih dan simple:</h3>

<ol>
	
		<li>{Prepare 2 gelas of beras (gelas u/beras yah yg kecil itu loh). </li>
	
		<li>{Make ready 1 of jagung uk. Besar diserut. </li>
	
		<li>{Prepare Secukupnya of labu kuning (biasa aku beli 3rb cukup) potong potong. </li>
	
		<li>{Take 1 ikat of kangkung akar petik dan bersihkan. </li>
	
		<li>{Prepare 1 ikat of bayam petik dan bersihkan. </li>
	
		<li>{Make ready secukupnya of Kemangi. </li>
	
		<li>{Make ready 2 lembar of sereh digeprek. </li>
	
		<li>{Get 4 lembar of daun salam. </li>
	
		<li>{Make ready 2 SM of garam. </li>
	
		<li>{Get  of Royco rasa ayam. </li>
	
		<li>{Take  of Air. </li>
	
		<li>{Take  of Bahan sambal terasi;. </li>
	
		<li>{Get 4 of cabe keriting. </li>
	
		<li>{Take 10 of cabe gendut. </li>
	
		<li>{Prepare 1 of tomat uk.sedang (lebih enak sih pake tomat yg kecil kecil). </li>
	
		<li>{Get 1/2 bungkus of terasi ABC (dibakar sebentar). </li>
	
		<li>{Make ready 1 of bawang merah. </li>
	
		<li>{Take 1/2 of bawang putih. </li>
	
		<li>{Take secukupnya of Garam. </li>
	
		<li>{Take  of Gula seujung kuku alias dikitttt bgt aja. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado gurih dan simple:</h3>

<ol>
	
		<li>
			Masak nasi terlebih dahulu dimagic com dan airnya dibanyakin biar agak jdi bubur krn kl masak nasinya direbus lama ngabisin gas ehehe (masukan sereh, daun salam, garam secukupnya).
			
			
		</li>
	
		<li>
			Sambil nunggu nasi matang goreng ikan asyinnya dl, setelah itu bikin sambalnya aj dl (cabe keriting &amp; cabe gendut sesuai selera, bawang merah, bawang putih, tomat, digoreng sebentar 1mnt diminyak panas tiriskan, 1,5 terasi dibakar lalu semua diuleg dihaluskan beri sdkit garam dan sdkit bgt gula).
			
			
		</li>
	
		<li>
			Rebus jagung dan labu kuning, jika labu sdh agak stengah matang masukan nasi yg sdh matang dimagic com td bila air sisa rebusan jagung menyusut tambahkan air lg aduk aduk nasi tambahkan garam dan royco koreksi rasa (perhatikan jgn sampai gosong dibawahnya, maka terus diaduk).
			
			
		</li>
	
		<li>
			Masukan sayuran, aduk dan jika sudah layu dan rasa sudah gurih syedap masukan kemangi lalu matikan api, Bubur manado homemade ready to serve.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur manado gurih dan simple recipe. Thanks so much for your time. I am sure you can make this at home. There's gonna be more interesting food at home recipes coming up. Remember to bookmark this page in your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
