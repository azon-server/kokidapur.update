---
description: "Recipe of Perfect Bubur mix sayur (bubur Manado)ala aku"
title: "Recipe of Perfect Bubur mix sayur (bubur Manado)ala aku"
slug: 275-recipe-of-perfect-bubur-mix-sayur-bubur-manadoala-aku

<p>
	<strong>Bubur mix sayur (bubur Manado)ala aku</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/0aedc010dc6dc892/680x482cq70/bubur-mix-sayur-bubur-manadoala-aku-foto-resep-utama.jpg" alt="Bubur mix sayur (bubur Manado)ala aku" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an incredible day today. Today, I will show you a way to prepare a special dish, bubur mix sayur (bubur manado)ala aku. One of my favorites food recipes. This time, I will make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur mix sayur (bubur Manado)ala aku is one of the most well liked of current trending meals on earth. It's easy, it's quick, it tastes yummy. It is appreciated by millions every day. They are fine and they look wonderful. Bubur mix sayur (bubur Manado)ala aku is something which I have loved my whole life.
</p>

<p>
To get started with this particular recipe, we must prepare a few ingredients. You can cook bubur mix sayur (bubur manado)ala aku using 14 ingredients and 7 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur mix sayur (bubur Manado)ala aku:</h3>

<ol>
	
		<li>{Make ready  of Nasi sesuai kebutuhan aku pake 1 mangkuk. </li>
	
		<li>{Take 1 bungkus of santan instan aku pakai kara. </li>
	
		<li>{Make ready 1/2 ikat of bayam. </li>
	
		<li>{Get 5 batang of kacang panjang potong kecil-kecil. </li>
	
		<li>{Make ready 1 buah of terong potong dadu. </li>
	
		<li>{Get 4 siung of bawang merah. </li>
	
		<li>{Make ready 3 siung of bawang putih. </li>
	
		<li>{Get sesuai selera of Cabai rawit merah. </li>
	
		<li>{Get 2 lembar of daun salam. </li>
	
		<li>{Get  of Lengkuas geprek. </li>
	
		<li>{Make ready secukupnya of Garam. </li>
	
		<li>{Take secukupnya of Gula pasir. </li>
	
		<li>{Prepare secukupnya of Kaldu bubuk. </li>
	
		<li>{Get 500 ml of air. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur mix sayur (bubur Manado)ala aku:</h3>

<ol>
	
		<li>
			Kita cincang bawang merah dan bawang putih dan cabai kita potong serong.
			
			
		</li>
	
		<li>
			Kita tumis bawang merah dan bawang putih juga cabai + daun salam lengkuas ke dalam magicom tumis hingga harum(tomobol magicom jangan lupa dlm keadaan cook ya temen2).
			
			
		</li>
	
		<li>
			Setelah kita tumis hingga harum masukkan nasi tambahkan garam,kaldu bubuk,gula pasir lalu aduk2 campur hingga rata.
			
			
		</li>
	
		<li>
			Masukan kacang panjang dan 500 ml air,aduk2 dan tes rasa sekiranya sudah terasa pas asinnya tutup magicom hingga air bnr2 menyusut dan sesekali aduk2 ya biar gk gosong.
			
			
		</li>
	
		<li>
			Setelah air menyusut dan nasi sudah menjadi bubur masukan terong tambahkan sedikit air kurang lebih 100ml lagi aduk2 tunggu hingga air menyusut.
			
			
		</li>
	
		<li>
			Setelah air menyusut dan terong empuk/matang masukan bayam dan 1 bungkus santan kara aduk2 sampai mendidih dan tunggu hingga bubur mengental jika kurang asin bisa d tambah garam/kaldu bubuknya temen2,,,kalo misal temen2 pengen bubur lebih kental bisa tambahkan 2sdm tepung beras lalu larutkan dlm 60ml air tuang sedikit demi sedikit sesambi di aduk.
			
			
		</li>
	
		<li>
			Bubur Manado ala aku siap di santap,,selamat mencoba ya temen2,dan harus coba di jamin bikin sekali tar ketagihan lho,,,hehee lebih nikmat di makan dengan lauk bakwan/tempe tepung,,pokoknya gurih dan pedesnya nyuuusss,,harus dan wajib coba 😁😉.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this special food bubur mix sayur (bubur manado)ala aku recipe. Thank you very much for reading. I'm confident you can make this at home. There's gonna be interesting food in home recipes coming up. Remember to bookmark this page in your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
