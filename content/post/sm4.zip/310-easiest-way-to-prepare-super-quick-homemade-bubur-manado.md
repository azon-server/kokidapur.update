---
description: "Easiest Way to Prepare Super Quick Homemade Bubur Manado"
title: "Easiest Way to Prepare Super Quick Homemade Bubur Manado"
slug: 310-easiest-way-to-prepare-super-quick-homemade-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/b74b50c493616670/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's me again, Dan, welcome to my recipe site. Today, we're going to prepare a distinctive dish, bubur manado. One of my favorites food recipes. For mine, I will make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Manado is one of the most favored of recent trending meals on earth. It is simple, it's fast, it tastes yummy. It is appreciated by millions every day. They're nice and they look wonderful. Bubur Manado is something which I have loved my whole life.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to first prepare a few components. You can cook bubur manado using 11 ingredients and 8 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Take 1 cup of beras. </li>
	
		<li>{Get 1 buah of jagung (pipil). </li>
	
		<li>{Prepare 1 ikat of kangkung. </li>
	
		<li>{Prepare 4-5 buah of kacang panjang. </li>
	
		<li>{Take 1 genggam of kemangi. </li>
	
		<li>{Make ready 2 siung of bawang putih. </li>
	
		<li>{Prepare 1 sdt of garam. </li>
	
		<li>{Take 1/2 sdt of kaldu bubuk (optional). </li>
	
		<li>{Make ready 1 batang of sereh (geprek). </li>
	
		<li>{Prepare 2 lembar of daun salam. </li>
	
		<li>{Make ready 1-1,5 liter of air bersih. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado:</h3>

<ol>
	
		<li>
			Siapkan bahan..potong2 sayuran lalu cuci bersih.
			
			
		</li>
	
		<li>
			Kemangi.
			
			
		</li>
	
		<li>
			Masukan beras dan air bersih kurang lebih 1liter..masak dengan api sedang.. masukan bawang putih yg sudah diiris, daun salam dan batang sereh.. aduk2 sampai beras menjadi lembek.
			
			
		</li>
	
		<li>
			Setelah beras sudah menjadi bubur, tambahkan sayuran..pertama jagung..lalu sisa sayuran yaitu kacang panjang, kangkung, daun kemangi.
			
			
		</li>
	
		<li>
			Masukan garam dan kaldu bubuk..Aduk2 terus sampai sayuran matang dan bubur matang...
			
			
		</li>
	
		<li>
			Jadi deh...
			
			
		</li>
	
		<li>
			Kondimen/ pelengkap makan bubur manado, biasanya keluargaku pakai ikan teri yg ditumis dengan bawang merah putih, cabe dan kacang goreng.. Plusss jangan lupa sambel terasi..😆😊😊.
			
			
		</li>
	
		<li>
			Ini enak banget.. tiap suapannya bikin ga mau berhenti makan.. hehhehe.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur manado recipe. Thanks so much for your time. I am confident that you will make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
