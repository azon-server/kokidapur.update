---
description: "Recipe of Homemade Bubur Kacang ijo empuk dan kental"
title: "Recipe of Homemade Bubur Kacang ijo empuk dan kental"
slug: 56-recipe-of-homemade-bubur-kacang-ijo-empuk-dan-kental

<p>
	<strong>Bubur Kacang ijo empuk dan kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/5f66bd7c08d87038/680x482cq70/bubur-kacang-ijo-empuk-dan-kental-foto-resep-utama.jpg" alt="Bubur Kacang ijo empuk dan kental" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is Louise, welcome to our recipe site. Today, I'm gonna show you how to make a distinctive dish, bubur kacang ijo empuk dan kental. It is one of my favorites food recipes. This time, I'm gonna make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang ijo empuk dan kental is one of the most favored of recent trending meals on earth. It is enjoyed by millions daily. It's easy, it's quick, it tastes delicious. Bubur Kacang ijo empuk dan kental is something which I have loved my entire life. They're nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to first prepare a few ingredients. You can cook bubur kacang ijo empuk dan kental using 8 ingredients and 4 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang ijo empuk dan kental:</h3>

<ol>
	
		<li>{Get 1/4 kg of kacang hijau. </li>
	
		<li>{Prepare 2 buah of gula merah. </li>
	
		<li>{Make ready 150 gr of Gula pasir. </li>
	
		<li>{Make ready 5 cm of jahe. </li>
	
		<li>{Get 2 lembar of daun pandan. </li>
	
		<li>{Get 1 bks of santan instant. </li>
	
		<li>{Take 1 sdm of tepung maizena (selera). </li>
	
		<li>{Take secukupnya of Air. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang ijo empuk dan kental:</h3>

<ol>
	
		<li>
			Cuci dan rendam kacang hijau selama 30 menit.
			
			
		</li>
	
		<li>
			Didihkan air, setelah mendidih masukan kacang hijau yg telah di rendam rebus kacang beserta daun pandan selama 5 menit, setelah 5 menit matikan kompor lalu biarkan selama 30 menit dalam panci tertutup.
			
			
		</li>
	
		<li>
			Setelah 30 menit didihkan kembali kacang selama 7 menit, setelah 7 menit masukan gula merah, gula pasir, santan, jahe aduk satu arah agar santan tidak pecah.
			
			
		</li>
	
		<li>
			Lalurkan 1 sdm tepung maizena kedalam sedikit air, kemudian masukan kedalam rebusan kacang hijau sedikit demi sediki sampai kental matikan api lalu sajikan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur kacang ijo empuk dan kental recipe. Thanks so much for reading. I am confident you will make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
