---
description: "Recipe of Any-night-of-the-week Bubur kacang ijo"
title: "Recipe of Any-night-of-the-week Bubur kacang ijo"
slug: 110-recipe-of-any-night-of-the-week-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/2df7dc2a3800bd67/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is Jim, welcome to our recipe site. Today, I'm gonna show you how to make a special dish, bubur kacang ijo. One of my favorites food recipes. For mine, I'm gonna make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo is one of the most favored of current trending foods on earth. It's simple, it is quick, it tastes yummy. It is enjoyed by millions daily. Bubur kacang ijo is something which I've loved my entire life. They're nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we must prepare a few components. You can have bubur kacang ijo using 7 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Take 350 gram of k.ijo. </li>
	
		<li>{Make ready 150 gram of beras ketan(100gr ketan hitam 50gr ketan putih). </li>
	
		<li>{Take 500 gr of gula merah. </li>
	
		<li>{Prepare 1/2 sndk of t merica. </li>
	
		<li>{Take  of Kayu manis sebesar kelingking. </li>
	
		<li>{Prepare  of Toping. </li>
	
		<li>{Take  of Santan atau susu UHT. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Kacang ijo + beras ketan campur cuci dan rendam selama 4 jam.
			
			
		</li>
	
		<li>
			Setelah direndam masak dg api sedang dan tutup sehingga cepat lunak.
			
			
		</li>
	
		<li>
			Setelah lunak aduk2 terus supaya buburnya tdk gosong dibagian bawah kemudian tuang sambil disaring gula merah yg telah dimasak sambil di aduk2.
			
			
		</li>
	
		<li>
			Tambahkan merica dan kayu.manis sambil diaduk, kalau terlalu kental tambahkan air sampai kekentalan yg sukai,aduk terus sampai mendidih...icip2 kalau berasa belum pas manisnya boleh ditambah gula pasir.
			
			
		</li>
	
		<li>
			Siap dihidangkan dg toping susu UHT....tapii bisa jg dg santan kental yg telah dimasak.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this special food bubur kacang ijo recipe. Thanks so much for your time. I am confident that you will make this at home. There's gonna be more interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
