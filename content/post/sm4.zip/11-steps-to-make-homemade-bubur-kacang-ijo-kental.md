---
description: "Steps to Make Homemade Bubur kacang ijo kental"
title: "Steps to Make Homemade Bubur kacang ijo kental"
slug: 11-steps-to-make-homemade-bubur-kacang-ijo-kental

<p>
	<strong>Bubur kacang ijo kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/d4534626e05d877f/680x482cq70/bubur-kacang-ijo-kental-foto-resep-utama.jpg" alt="Bubur kacang ijo kental" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you are having an amazing day today. Today, we're going to prepare a special dish, bubur kacang ijo kental. One of my favorites. For mine, I will make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo kental is one of the most well liked of recent trending meals in the world. It's enjoyed by millions daily. It is easy, it's quick, it tastes delicious. Bubur kacang ijo kental is something which I've loved my entire life. They are nice and they look wonderful.
</p>

<p>
To begin with this recipe, we have to prepare a few components. You can have bubur kacang ijo kental using 7 ingredients and 5 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo kental:</h3>

<ol>
	
		<li>{Take 1/2 kg of kacang hijau. </li>
	
		<li>{Take 1/2 of kelapa dibuat santan (bisa diganti 2 buah santan KARA). </li>
	
		<li>{Take 1 ruas of jahe. </li>
	
		<li>{Prepare 6 keping of gula merah. </li>
	
		<li>{Get sesuai selera of Gula pasir. </li>
	
		<li>{Take 3 lembar of daun pandang. </li>
	
		<li>{Get  of Air 2 kali lipat jumlah kacang ijo. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo kental:</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau.
			
			
		</li>
	
		<li>
			Iris-iris tipis gula merah dan sisihkan. Potong jahe dan geprek..
			
			
		</li>
	
		<li>
			Masukan air, jahe geprek, dan kacang hijau. Rebus hingga setengah pecah..
			
			
		</li>
	
		<li>
			Setelah setengah kacang hijau pecah tambahkan irisan gula merah dan beberapa sendok gula pasir (sesuai selera)..
			
			
		</li>
	
		<li>
			Tambahkan santan dan aduk hingga rata dengan diaduk sesekali. Tunggu sampai air menyusut dan siap disajikan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur kacang ijo kental recipe. Thank you very much for reading. I am sure you can make this at home. There is gonna be interesting food in home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
