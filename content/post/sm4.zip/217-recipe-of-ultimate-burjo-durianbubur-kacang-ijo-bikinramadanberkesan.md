---
description: "Recipe of Ultimate Burjo durian(bubur kacang ijo) #BikinRamadanBerkesan"
title: "Recipe of Ultimate Burjo durian(bubur kacang ijo) #BikinRamadanBerkesan"
slug: 217-recipe-of-ultimate-burjo-durianbubur-kacang-ijo-bikinramadanberkesan

<p>
	<strong>Burjo durian(bubur kacang ijo) #BikinRamadanBerkesan</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/bbe51150de27dd17/680x482cq70/burjo-durianbubur-kacang-ijo-bikinramadanberkesan-foto-resep-utama.jpg" alt="Burjo durian(bubur kacang ijo) #BikinRamadanBerkesan" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you are having an incredible day today. Today, we're going to prepare a distinctive dish, burjo durian(bubur kacang ijo) #bikinramadanberkesan. One of my favorites. For mine, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Burjo durian(bubur kacang ijo) #BikinRamadanBerkesan is one of the most popular of recent trending meals in the world. It is easy, it is quick, it tastes yummy. It's appreciated by millions every day. Burjo durian(bubur kacang ijo) #BikinRamadanBerkesan is something that I have loved my entire life. They're nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we have to prepare a few ingredients. You can have burjo durian(bubur kacang ijo) #bikinramadanberkesan using 7 ingredients and 3 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Burjo durian(bubur kacang ijo) #BikinRamadanBerkesan:</h3>

<ol>
	
		<li>{Prepare 250 gram of kacang hijau. </li>
	
		<li>{Take 2 lembar of daun pandan(simpulkan). </li>
	
		<li>{Take 1 buah of durian(ambil isi buahnya). </li>
	
		<li>{Get 900 cc of santan kental. </li>
	
		<li>{Take secukupnya of air(uk panci sedang). </li>
	
		<li>{Prepare secukupnya of gula(krna saya kurang suka manis jd tadi cuma pakai h. </li>
	
		<li>{Make ready secubit of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Burjo durian(bubur kacang ijo) #BikinRamadanBerkesan:</h3>

<ol>
	
		<li>
			Rebus kacang hijau,daun pandan dengan secukupnya air,rebus sampai kacang hijau pecah..
			
			
		</li>
	
		<li>
			Tambahkan gula,dan garam lalu aduk rata..
			
			
		</li>
	
		<li>
			Masukan santan kental,kecilkan api dan terakhir masukan durian.masak sampai santan mendidih..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this exceptional food burjo durian(bubur kacang ijo) #bikinramadanberkesan recipe. Thanks so much for your time. I am sure you will make this at home. There's gonna be more interesting food in home recipes coming up. Remember to bookmark this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
