---
description: "Recipe of Ultimate Bubur Manado (Daun Gedi)"
title: "Recipe of Ultimate Bubur Manado (Daun Gedi)"
slug: 407-recipe-of-ultimate-bubur-manado-daun-gedi

<p>
	<strong>Bubur Manado (Daun Gedi)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/fda2856453879f17/680x482cq70/bubur-manado-daun-gedi-foto-resep-utama.jpg" alt="Bubur Manado (Daun Gedi)" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an incredible day today. Today, I will show you a way to make a distinctive dish, bubur manado (daun gedi). It is one of my favorites food recipes. This time, I am going to make it a little bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Manado (Daun Gedi) is one of the most favored of current trending meals in the world. It is enjoyed by millions daily. It is simple, it is fast, it tastes yummy. Bubur Manado (Daun Gedi) is something which I've loved my entire life. They're nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to prepare a few components. You can cook bubur manado (daun gedi) using 19 ingredients and 7 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Manado (Daun Gedi):</h3>

<ol>
	
		<li>{Get  of bahan. </li>
	
		<li>{Get 2 Gelas Takar of Beras (Berasnya bebas dan dicuci dulu yah). </li>
	
		<li>{Make ready 7 Gelas of Air ( Pakai gelas takar Beras ya,kalo kurang tambah lagi. </li>
	
		<li>{Take  of isi. </li>
	
		<li>{Take 1 Ikat of daun kemangi. </li>
	
		<li>{Get 2 Batang of sereh geprek. </li>
	
		<li>{Make ready 1 Lembar of daun kunyit besar. </li>
	
		<li>{Make ready Secukupnya of daun gedi (Kalo ga ada, pake kangkung boleh). </li>
	
		<li>{Get 1/2 of Labu Kuning. </li>
	
		<li>{Take  of Bumbu. </li>
	
		<li>{Prepare 2 sdt of Garam. </li>
	
		<li>{Prepare  of Sambal. </li>
	
		<li>{Prepare Secukupnya of Cabe Merah dan Rawit. </li>
	
		<li>{Make ready 4 Siung of bawang putih. </li>
	
		<li>{Prepare 8 Siung of bawang merah. </li>
	
		<li>{Get 1/2 Jempol of terasi. </li>
	
		<li>{Take sesuai selera of Royco sedikit,. </li>
	
		<li>{Prepare  of Toping. </li>
	
		<li>{Get  of Ikan Asin (Bebas). </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado (Daun Gedi):</h3>

<ol>
	
		<li>
			Cuci beras, kemudian masak sampai setengah matang..
			
			
		</li>
	
		<li>
			Kemudian Masukan Labu Kuning, sereh dan Daun kunyit sampai 3/4 menjadi bubur.
			
			
		</li>
	
		<li>
			Setelah itu masukan daun gedi/kangkung dan kemangi.
			
			
		</li>
	
		<li>
			Aduk terus dengan api kecil, sambil santai. Masak hingga labu kuning hancur.
			
			
		</li>
	
		<li>
			Sambil nunggu bubur matang, goreng cabai,terasi dan bawang. Tiriskan ke cobek,kemudian ulek dan campur royco sesuai selera.
			
			
		</li>
	
		<li>
			Jangan lupa goreng ikan asinnya😊.
			
			
		</li>
	
		<li>
			Bila bubur sudah matang, matikan kompor. Sajikan hangat2 ibu-ibu... Ikan asin dan sambel terasi...nyam nyam.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur manado (daun gedi) recipe. Thanks so much for reading. I'm confident you will make this at home. There's gonna be interesting food in home recipes coming up. Remember to bookmark this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
