---
description: "Simple Way to Prepare Award-winning Bubur Kacang Ijo SKJ (Susu Kacang Ijo Jahe)"
title: "Simple Way to Prepare Award-winning Bubur Kacang Ijo SKJ (Susu Kacang Ijo Jahe)"
slug: 181-simple-way-to-prepare-award-winning-bubur-kacang-ijo-skj-susu-kacang-ijo-jahe

<p>
	<strong>Bubur Kacang Ijo SKJ (Susu Kacang Ijo Jahe)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/1671b8ad086ec2da/680x482cq70/bubur-kacang-ijo-skj-susu-kacang-ijo-jahe-foto-resep-utama.jpg" alt="Bubur Kacang Ijo SKJ (Susu Kacang Ijo Jahe)" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you are having an amazing day today. Today, we're going to prepare a special dish, bubur kacang ijo skj (susu kacang ijo jahe). It is one of my favorites food recipes. For mine, I will make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo SKJ (Susu Kacang Ijo Jahe) is one of the most favored of current trending meals on earth. It's appreciated by millions daily. It is simple, it is fast, it tastes yummy. Bubur Kacang Ijo SKJ (Susu Kacang Ijo Jahe) is something that I've loved my entire life. They're nice and they look wonderful.
</p>

<p>
To get started with this particular recipe, we must first prepare a few ingredients. You can have bubur kacang ijo skj (susu kacang ijo jahe) using 5 ingredients and 5 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo SKJ (Susu Kacang Ijo Jahe):</h3>

<ol>
	
		<li>{Make ready 150 gram of kacang ijo. </li>
	
		<li>{Prepare 600 ml of santan kara. </li>
	
		<li>{Get 3 cm of jahe iris. </li>
	
		<li>{Make ready secukupnya of gula. </li>
	
		<li>{Get sesuai selera of susu kental manis. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo SKJ (Susu Kacang Ijo Jahe):</h3>

<ol>
	
		<li>
			Rendam Kacang hijau 24 jam, Rebus hingga merekah.
			
			
		</li>
	
		<li>
			Masukkan irisan jahe, santan kara yang sudah di encerkan ke dalam rebusan kacang ijo hingga mendidih,.
			
			
		</li>
	
		<li>
			Tambahkan susu kental manis sesuai selera.
			
			
		</li>
	
		<li>
			Tambahkan gula secukupnya.
			
			
		</li>
	
		<li>
			Aduk, hidangkan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this exceptional food bubur kacang ijo skj (susu kacang ijo jahe) recipe. Thanks so much for your time. I am sure that you will make this at home. There is gonna be interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
