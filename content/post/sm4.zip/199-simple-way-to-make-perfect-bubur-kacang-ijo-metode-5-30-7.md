---
description: "Simple Way to Make Perfect Bubur kacang ijo metode 5;30;7"
title: "Simple Way to Make Perfect Bubur kacang ijo metode 5;30;7"
slug: 199-simple-way-to-make-perfect-bubur-kacang-ijo-metode-5-30-7

<p>
	<strong>Bubur kacang ijo metode 5;30;7</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/be1a2ab2f9014b4e/680x482cq70/bubur-kacang-ijo-metode-5307-foto-resep-utama.jpg" alt="Bubur kacang ijo metode 5;30;7" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you are having an amazing day today. Today, I will show you a way to prepare a special dish, bubur kacang ijo metode 5;30;7. It is one of my favorites food recipes. This time, I am going to make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang ijo metode 5;30;7 is one of the most well liked of recent trending meals in the world. It is easy, it's quick, it tastes delicious. It's enjoyed by millions every day. They're nice and they look wonderful. Bubur kacang ijo metode 5;30;7 is something which I've loved my entire life.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we must first prepare a few components. You can have bubur kacang ijo metode 5;30;7 using 8 ingredients and 3 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo metode 5;30;7:</h3>

<ol>
	
		<li>{Take 1/4 kg of kacang ijo(cuci bersih tiriskan). </li>
	
		<li>{Get 600 ml of air. </li>
	
		<li>{Make ready 200 grm of gula merah(manis sesuai selera). </li>
	
		<li>{Take 30 grm of gula pasir(manis sesuai selera). </li>
	
		<li>{Make ready Sejumput of garam. </li>
	
		<li>{Get 2 lbr of daun pandan. </li>
	
		<li>{Get Secukupnya of Jahe diparut/digeprek boleh jg. </li>
	
		<li>{Make ready 1 bks of santan instan. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo metode 5;30;7:</h3>

<ol>
	
		<li>
			Campur kacang ijo+air masak sampai air mendidih selama 5 mnt matikan apinya lalu tutup diamkan selama 30 mnt..
			
			
		</li>
	
		<li>
			Masak air secukupnya gula merah dan gula pasir sampai gula larut sisihkan..
			
			
		</li>
	
		<li>
			Setelah 30 mnt perendaman,,campur air gula dan tambahkan daun pandan (kalau kurang air bisa ditambahkan sesuai selera) beri santan kental(saya pakai santan instan) masukkan parutan jahe dan sejumput garam masak selama 7 mnt sambil diaduk supaya santannya tidak pecah.Bubur kacang ijo siap dinikmati😋👍👌.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur kacang ijo metode 5;30;7 recipe. Thank you very much for your time. I'm sure you can make this at home. There is gonna be more interesting food at home recipes coming up. Remember to save this page in your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
