---
description: "Steps to Prepare Award-winning Bubur Kacang Ijo (Metode 5-30-7 Fah Umi Yasmin)"
title: "Steps to Prepare Award-winning Bubur Kacang Ijo (Metode 5-30-7 Fah Umi Yasmin)"
slug: 186-steps-to-prepare-award-winning-bubur-kacang-ijo-metode-5-30-7-fah-umi-yasmin

<p>
	<strong>Bubur Kacang Ijo (Metode 5-30-7 Fah Umi Yasmin)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/318b27ca1c0bead0/680x482cq70/bubur-kacang-ijo-metode-5-30-7-fah-umi-yasmin-foto-resep-utama.jpg" alt="Bubur Kacang Ijo (Metode 5-30-7 Fah Umi Yasmin)" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Brad, welcome to my recipe site. Today, we're going to make a special dish, bubur kacang ijo (metode 5-30-7 fah umi yasmin). One of my favorites food recipes. This time, I will make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo (Metode 5-30-7 Fah Umi Yasmin) is one of the most well liked of recent trending foods in the world. It is simple, it's quick, it tastes delicious. It is appreciated by millions every day. Bubur Kacang Ijo (Metode 5-30-7 Fah Umi Yasmin) is something that I've loved my entire life. They are fine and they look fantastic.
</p>

<p>
To begin with this recipe, we must first prepare a few components. You can have bubur kacang ijo (metode 5-30-7 fah umi yasmin) using 7 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo (Metode 5-30-7 Fah Umi Yasmin):</h3>

<ol>
	
		<li>{Prepare 250 gr of kacang hijau mentah. </li>
	
		<li>{Take 1,5 liter of air. </li>
	
		<li>{Get 1 lembar of daun pandan. </li>
	
		<li>{Take 100 gr of jahe (bisa kurang/lebih sesuai selera). </li>
	
		<li>{Prepare 2 sdt of garam (bisa kurang/lebih sesuai selera). </li>
	
		<li>{Make ready sesuai selera of gula pasir/gula merah. </li>
	
		<li>{Take 100 gr of fiber creme (dapat diganti dengan santan sesuai selera). </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo (Metode 5-30-7 Fah Umi Yasmin):</h3>

<ol>
	
		<li>
			Bakar jahe, kupas, bersihkan, dan memarkan. Cuci bersih kacang hijau. Sisihkan..
			
			
		</li>
	
		<li>
			Didihkan air. Masukkan kacang hijau, jahe, daun pandan, dan garam. Tutup panci dan masak selama 5 menit (saya pakai api sedang)..
			
			
		</li>
	
		<li>
			Matikan api, dan tunggu 30 menit. Jangan buka tutup panci, ya. Panci harus tetap dalam keadaan tertutup..
			
			
		</li>
	
		<li>
			Buka panci, masukkan gula dan fiber creme/santan, koreksi rasa. Masak lagi dengan api kecil-sedang selama 7 menit..
			
			
		</li>
	
		<li>
			Catatan: kalau suka kuah yang kental, tambahkan tepung maizena yang sudah dilarutkan dengan sedikit air. Masak sebentar sambil diaduk-aduk hingga mengental..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur kacang ijo (metode 5-30-7 fah umi yasmin) recipe. Thanks so much for your time. I'm sure that you will make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to save this page in your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
