---
description: "How to Make Perfect Bubur Manado Bonggol Pisang (tanpa beras)"
title: "How to Make Perfect Bubur Manado Bonggol Pisang (tanpa beras)"
slug: 362-how-to-make-perfect-bubur-manado-bonggol-pisang-tanpa-beras

<p>
	<strong>Bubur Manado Bonggol Pisang (tanpa beras)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/34fa3864c4d6ad92/680x482cq70/bubur-manado-bonggol-pisang-tanpa-beras-foto-resep-utama.jpg" alt="Bubur Manado Bonggol Pisang (tanpa beras)" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you're having an incredible day today. Today, I will show you a way to make a distinctive dish, bubur manado bonggol pisang (tanpa beras). It is one of my favorites food recipes. This time, I'm gonna make it a little bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Manado Bonggol Pisang (tanpa beras) is one of the most popular of recent trending meals in the world. It is enjoyed by millions every day. It is easy, it's quick, it tastes delicious. Bubur Manado Bonggol Pisang (tanpa beras) is something which I've loved my entire life. They're nice and they look fantastic.
</p>

<p>
To begin with this recipe, we have to prepare a few components. You can have bubur manado bonggol pisang (tanpa beras) using 21 ingredients and 7 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Manado Bonggol Pisang (tanpa beras):</h3>

<ol>
	
		<li>{Make ready 500 gr of bonggol pisang kepok, sudah bersih. </li>
	
		<li>{Get 500 ml of air. </li>
	
		<li>{Get  of Perendam bonggol pisang:. </li>
	
		<li>{Prepare 1,5 liter of air. </li>
	
		<li>{Get 1,5 sdm of garam. </li>
	
		<li>{Get  of Campuran bubur:. </li>
	
		<li>{Prepare 100 gr of jagung yg sudah dipipil. </li>
	
		<li>{Prepare 75 gr of singkong yg sudah dipotong kotak kecil. </li>
	
		<li>{Prepare 75 gr of labu parang yg sudah dipotong kotak kecil. </li>
	
		<li>{Prepare 75 gr of wortel yg sudah dipotong kotak kecil. </li>
	
		<li>{Take 25 gr of bayam sudah dipetiki. </li>
	
		<li>{Get 25 gr of kangkung sudah dipetiki. </li>
	
		<li>{Make ready  of Bumbu &amp; perasa:. </li>
	
		<li>{Prepare 1 batang of sereh sudah digeprek. </li>
	
		<li>{Prepare 3 tangkai of daun kemangi yg sudah dipetiki (sy tidak pakai). </li>
	
		<li>{Take 2 sdm of minyak sayur (boleh tidak). </li>
	
		<li>{Take 1/2 sdm of garam (sesuaikan lagi). </li>
	
		<li>{Get  of Pelengkap:. </li>
	
		<li>{Get  of Ikan asin goreng/rempeyek teri. </li>
	
		<li>{Take  of Sambal tomat. </li>
	
		<li>{Prepare  of Kerupuk. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado Bonggol Pisang (tanpa beras):</h3>

<ol>
	
		<li>
			Potong-potong kecil/iris bonggol pisang yang sudah dikupas (gunakan bagian yg putih dan teksturnya seperti bangkuang) lalu rendam dalam larutan perendam. Rendam semalaman, cicipi, jika masih terasa kelat, cuci bersih bonggol pisang dan ulangi perendaman menggunakan larutan yg baru..
			
			
		</li>
	
		<li>
			Tiriskan bonggol pisang yg sudah direndam. Cuci bersih, lalu rebus dengan air menggenang sambil ditutup kurang lebih 15 menit. Tiriskan..
			
			
		</li>
	
		<li>
			Rebus menggunakan api sedang cenderung kecil: labu parang, singkong dan 300 ml air. Tutup panci dan rebus sampai singkong dan labu empuk. Setelah empuk, tambahkan wortel dan serai. Rebus sampai wortel empuk..
			
			
		</li>
	
		<li>
			Sambil menunggu wortel empuk, masukkan 200 ml air ke dalam blender. Tambahkan setengah dari bonggol pisang, lalu blender sampai halus. Setelah halus, tambahkan sisa bonggol pisang secara bertahap sampai semua bonggol habis dan halus. Setelah bonggol pisang halus, tambahkan jagung, lalu blender lagi sampai halus..
			
			
		</li>
	
		<li>
			Tuang hasil blenderan ke panci rebusan labu, singkong dan wortel. Jika ada bonggol jagung, masukkan juga agar kaldunya menambah citarasa bubur. Tambahkan juga minyak sayur. Masak bubur sambil sesekali diaduk agar bagian bawahnya tidak gosong. Masak sampai bubur mengental dan semua bahan matang. Tambahkan garam lalu cicipi dan perbaiki rasanya. (Mungkin masih ada garam dari proses perendaman yg terbawa di bonggol pisang, pastikan dl rasa asin bubur sebelum menambahkan garam).
			
			
		</li>
	
		<li>
			Terakhir masukkan bayam, kangkung dan kemangi. Sambil diaduk, masak sebentar sampai sayuran layu. Matikan api..
			
			
		</li>
	
		<li>
			Pindahkan ke wadah saji. Hidangkan dengan pelengkapnya..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this special food bubur manado bonggol pisang (tanpa beras) recipe. Thanks so much for reading. I'm confident that you can make this at home. There is gonna be interesting food in home recipes coming up. Remember to bookmark this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
