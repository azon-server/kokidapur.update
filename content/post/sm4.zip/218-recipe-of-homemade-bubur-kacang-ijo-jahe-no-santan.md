---
description: "Recipe of Homemade Bubur Kacang Ijo Jahe (no santan)"
title: "Recipe of Homemade Bubur Kacang Ijo Jahe (no santan)"
slug: 218-recipe-of-homemade-bubur-kacang-ijo-jahe-no-santan

<p>
	<strong>Bubur Kacang Ijo Jahe (no santan)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/223d6419cb4dd125/680x482cq70/bubur-kacang-ijo-jahe-no-santan-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Jahe (no santan)" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Brad, welcome to my recipe site. Today, I'm gonna show you how to prepare a special dish, bubur kacang ijo jahe (no santan). It is one of my favorites food recipes. This time, I'm gonna make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo Jahe (no santan) is one of the most favored of recent trending foods on earth. It's appreciated by millions every day. It's easy, it's quick, it tastes yummy. They're nice and they look wonderful. Bubur Kacang Ijo Jahe (no santan) is something that I've loved my whole life.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we must first prepare a few ingredients. You can cook bubur kacang ijo jahe (no santan) using 6 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Jahe (no santan):</h3>

<ol>
	
		<li>{Prepare 5 sdm of biji kacang hijau. </li>
	
		<li>{Take 2 sdm of gula pasir. </li>
	
		<li>{Take 3 cm of ruas jahe iris geprek. </li>
	
		<li>{Get 500 ml of air. </li>
	
		<li>{Make ready 2 sdm of susu kental manis. </li>
	
		<li>{Get 2 sdm of sirup maple. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo Jahe (no santan):</h3>

<ol>
	
		<li>
			Rendam biji kacang hijau (saya rendam jam 8 pagi dimasak jam 6 malam) fungsinya agar tidak terlalu lama merebusnya.
			
			
		</li>
	
		<li>
			Buang air rendaman kemudian cuci biji sebanyak 1-2 kali..
			
			
		</li>
	
		<li>
			Tambahkan air matang, gula dan jahe pada biji kacang hijau yang sudah dicuci. Didihkan dengan api sedang hingga kacang empuk (kadar empuk sesuai selera).
			
			
		</li>
	
		<li>
			Matikan api. Tambahkan susu kental manis dan sirup maple. Jika dirasa kurang manis bisa ditambahkan sirup maplenya..
			
			
		</li>
	
		<li>
			Bubur kacang hijau siap disajikan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this special food bubur kacang ijo jahe (no santan) recipe. Thank you very much for your time. I'm sure that you will make this at home. There's gonna be more interesting food at home recipes coming up. Remember to bookmark this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
