---
description: "Recipe of Speedy Bubur Kacang Ijo"
title: "Recipe of Speedy Bubur Kacang Ijo"
slug: 120-recipe-of-speedy-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/0b1a1ab19b878a8f/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an amazing day today. Today, I will show you a way to prepare a distinctive dish, bubur kacang ijo. It is one of my favorites. For mine, I'm gonna make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo is one of the most well liked of current trending meals on earth. It is easy, it is fast, it tastes yummy. It's enjoyed by millions daily. Bubur Kacang Ijo is something that I have loved my whole life. They are fine and they look fantastic.
</p>

<p>
To begin with this particular recipe, we must prepare a few ingredients. You can cook bubur kacang ijo using 9 ingredients and 3 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Get 250 gr of kacang hijau (cuci,rendam semalam). </li>
	
		<li>{Prepare 100 gr of gula pasir. </li>
	
		<li>{Prepare 1/2 butir of gula Jawa (biar mantap rasanya). </li>
	
		<li>{Make ready 1/2 sdt of garam halus. </li>
	
		<li>{Make ready 1,5 L of air. </li>
	
		<li>{Prepare  of Jahe (memarkan). </li>
	
		<li>{Make ready 1 helai of daun pandan. </li>
	
		<li>{Get 1 sdm of maizena (larutkan dengan sedikit air). </li>
	
		<li>{Get  of Pelengkap : santan. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Siapkan bahan.
			
			
		</li>
	
		<li>
			Rebus kacang hijau bersama jahe +pandan+ garam..
			
			
		</li>
	
		<li>
			Stelah empuk tambahkan gula pasir+ Jawa. Tambahkan larutan maizena,masak hingga kental. Angkat,sajikan dengan santan😄.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur kacang ijo recipe. Thanks so much for reading. I'm sure that you can make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
