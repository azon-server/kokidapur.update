---
description: "Easiest Way to Make Homemade Bubur Kacang Ijo"
title: "Easiest Way to Make Homemade Bubur Kacang Ijo"
slug: 161-easiest-way-to-make-homemade-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/e5c699fdb16d46cb/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you're having an amazing day today. Today, I will show you a way to prepare a special dish, bubur kacang ijo. One of my favorites. For mine, I am going to make it a little bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo is one of the most popular of current trending meals on earth. It is enjoyed by millions every day. It is simple, it is fast, it tastes yummy. Bubur Kacang Ijo is something which I have loved my entire life. They're nice and they look wonderful.
</p>

<p>
To begin with this particular recipe, we must first prepare a few ingredients. You can have bubur kacang ijo using 8 ingredients and 4 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Make ready 150 gr of kacang ijo. </li>
	
		<li>{Prepare 1 liter of air untuk merebus. </li>
	
		<li>{Take 1 lembar of daun pandan, ikat simpul. </li>
	
		<li>{Prepare 4 cm of jahe merah, geprek. </li>
	
		<li>{Take 450 ml of santan kental. </li>
	
		<li>{Get 1 sdm of gula merah aren sisir. </li>
	
		<li>{Take Secukupnya of gula pasir. </li>
	
		<li>{Make ready Sejumput of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Didihkan air, masukkan kacang ijo. Didihkan lagi 5 menit. Matikan api dan diamkan 30 menit sambil ditutup rapat pancinya (gambar no.2).
			
			
		</li>
	
		<li>
			Setelah 30 menit, masak lagi kacang hijau dengan daun pandan dan jahe kurleb 10 menit hingga merekah/mekar (seperti foto dibawah).
			
			
		</li>
	
		<li>
			Tuang santan, tambahkan gula merah aren, gula pasir dan garam. Didihkan lagi kurleb 5 menit sambil koreksi rasa. Tuang campuran sagu dan air. Didihkan lagi sebentar/2 menit hingga mengental.
			
			
		</li>
	
		<li>
			Angkat dan sajikan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this special food bubur kacang ijo recipe. Thank you very much for reading. I'm confident that you can make this at home. There's gonna be interesting food at home recipes coming up. Remember to bookmark this page on your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
