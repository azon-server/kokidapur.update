---
description: "Easiest Way to Prepare Perfect Bubur kacang ijo"
title: "Easiest Way to Prepare Perfect Bubur kacang ijo"
slug: 130-easiest-way-to-prepare-perfect-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/3a5242039b2d3fb4/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Brad, welcome to my recipe page. Today, we're going to make a distinctive dish, bubur kacang ijo. It is one of my favorites. This time, I am going to make it a little bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo is one of the most well liked of recent trending meals in the world. It's easy, it is fast, it tastes delicious. It is enjoyed by millions every day. Bubur kacang ijo is something that I have loved my entire life. They're fine and they look wonderful.
</p>

<p>
To get started with this particular recipe, we have to prepare a few ingredients. You can have bubur kacang ijo using 9 ingredients and 6 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Prepare 1/4 of kacang hijau(rendam)&#34;aku rendam pagi jam 3 sore diangkat). </li>
	
		<li>{Make ready 1/4 of Gula merah. </li>
	
		<li>{Get 125 gr of Gula pasir. </li>
	
		<li>{Get 1/2 of kaleg susu kental manis(boleh skip). </li>
	
		<li>{Prepare Sejumput of garam. </li>
	
		<li>{Make ready 1 sdt of vanili. </li>
	
		<li>{Make ready 3 helai of daum pandan. </li>
	
		<li>{Prepare 1 of Santan kara. </li>
	
		<li>{Prepare  of Air 2liter sengaja banyak yahh(biqr sisanya aku jadiin es). </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Panaskan air, tambahkan daub pandan.
			
			
		</li>
	
		<li>
			Masukan kacang hijau yang sudah dicuci bersih, sampai pecahpecah gitu yahh,.
			
			
		</li>
	
		<li>
			Kalau udh belah/pecah gtu kasih gula, susu, vanili dan garam.
			
			
		</li>
	
		<li>
			Nah tes rasa deh kalau udah gitu bisa tambahin santan(aku kasih sedkit karna lagi gk bgtu banget sama makanan bersantan).
			
			
		</li>
	
		<li>
			Angkat dan sajikan.
			
			
		</li>
	
		<li>
			Selamat mencoba bunda.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this special food bubur kacang ijo recipe. Thank you very much for your time. I'm confident you will make this at home. There's gonna be interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
