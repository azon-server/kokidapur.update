---
description: "Recipe of Homemade Bubur Kacang Hijau Kental"
title: "Recipe of Homemade Bubur Kacang Hijau Kental"
slug: 54-recipe-of-homemade-bubur-kacang-hijau-kental

<p>
	<strong>Bubur Kacang Hijau Kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/25bb69a3e2a26b10/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is me, Dave, welcome to our recipe page. Today, we're going to make a distinctive dish, bubur kacang hijau kental. It is one of my favorites. For mine, I will make it a bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Hijau Kental is one of the most favored of current trending meals on earth. It is simple, it's fast, it tastes yummy. It is enjoyed by millions every day. Bubur Kacang Hijau Kental is something that I've loved my entire life. They are fine and they look wonderful.
</p>

<p>
To get started with this recipe, we have to first prepare a few components. You can have bubur kacang hijau kental using 9 ingredients and 4 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>{Get 150 gr of kacang hijau. </li>
	
		<li>{Prepare 50 gr of gula merah. </li>
	
		<li>{Get 1 sdm of gula pasir. </li>
	
		<li>{Get 1/2 sdt of garam. </li>
	
		<li>{Make ready 1 ruas kecil of jahe di geprek. </li>
	
		<li>{Take 1 cm of kayu manis jika suka (saya skip). </li>
	
		<li>{Make ready 1 helai of daun pandan diikat. </li>
	
		<li>{Take 500 ml of santan kental. </li>
	
		<li>{Take 500 ml of air. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>
			Cuci kacang hijau. Bisa direndam didalam air dulu semalaman sebelum dimasak..
			
			
		</li>
	
		<li>
			Rebus air sampai mendidih dan masukkan kacang hijau rebus hingga benar benar empuk sambil diaduk..
			
			
		</li>
	
		<li>
			Masukkan daun pandan. Jika sudah cukup kental masukkan gula merah, gula pasir, garam, jahe, kayu manis dan santan. Ini sudah hampir hancur kacang hijaunya..
			
			
		</li>
	
		<li>
			Aduk terus hingga kekentalan yg diinginkan. Jika air hampir menyusut tapi masih blm empuk / hancur, tambahkan lagi air panasnya. Sambil diaduk aduk terus. Tes rasa. Matikan kompor. Siap disajikan 😊.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food bubur kacang hijau kental recipe. Thank you very much for reading. I am sure that you will make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to save this page in your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
