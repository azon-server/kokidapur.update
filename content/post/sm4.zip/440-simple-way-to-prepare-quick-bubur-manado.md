---
description: "Simple Way to Prepare Quick Bubur Manado"
title: "Simple Way to Prepare Quick Bubur Manado"
slug: 440-simple-way-to-prepare-quick-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/4357c4ea7c190f2e/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, I'm gonna show you how to prepare a special dish, bubur manado. It is one of my favorites food recipes. This time, I will make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Manado is one of the most popular of recent trending meals in the world. It is appreciated by millions daily. It is simple, it's fast, it tastes yummy. They are nice and they look wonderful. Bubur Manado is something that I have loved my entire life.
</p>

<p>
To get started with this recipe, we have to prepare a few components. You can have bubur manado using 10 ingredients and 3 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Make ready 200 gr of beras, cuci bersih, tiriskan. </li>
	
		<li>{Prepare 1.500 ml of air. </li>
	
		<li>{Get 2 bh of jagung, dipipil/disisir. </li>
	
		<li>{Make ready 2 bh of ubi jalar. </li>
	
		<li>{Make ready 1 ikat of bayam. </li>
	
		<li>{Prepare 1 ikat of kangkung. </li>
	
		<li>{Take 1 ikat of kemangi. </li>
	
		<li>{Prepare 1 btg of serai, dimemarkan. </li>
	
		<li>{Take 1 cm of jahe, dimemarkan. </li>
	
		<li>{Make ready 2 sdm of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado:</h3>

<ol>
	
		<li>
			Semua sayuran dibersihkan dan dipetik daunnya. Jagung boleh dipipil, boleh disisir. Saya pilih yg disisir krn lbh praktis. Ubi dikupas, potong kotak2 kecil.
			
			
		</li>
	
		<li>
			Siapkan panci berisi air, masukkan beras, jahe dan serai yg telah dimemarkan. Masak beras sampai setengah matang (keluar tajin), lalu masukkan jagung dan garam. Aduk rata..
			
			
		</li>
	
		<li>
			Masukkan ubi, aduk. Biarkan sampai ubi empuk. Terakhir masukkan bahan sayuran. Aduk rata. Masak selama 10 menit, angkat. Hidangkan dengan sambal tomat/sambal roa dan ikan asin..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur manado recipe. Thanks so much for your time. I'm sure you will make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to save this page in your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
