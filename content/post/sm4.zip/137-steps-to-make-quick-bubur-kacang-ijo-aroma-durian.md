---
description: "Steps to Make Quick Bubur Kacang Ijo Aroma Durian"
title: "Steps to Make Quick Bubur Kacang Ijo Aroma Durian"
slug: 137-steps-to-make-quick-bubur-kacang-ijo-aroma-durian

<p>
	<strong>Bubur Kacang Ijo Aroma Durian</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/73dafec1cc82c76f/680x482cq70/bubur-kacang-ijo-aroma-durian-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Aroma Durian" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you are having an amazing day today. Today, I will show you a way to make a distinctive dish, bubur kacang ijo aroma durian. It is one of my favorites food recipes. This time, I'm gonna make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo Aroma Durian is one of the most well liked of current trending meals in the world. It's enjoyed by millions daily. It's easy, it is fast, it tastes yummy. Bubur Kacang Ijo Aroma Durian is something that I've loved my entire life. They are fine and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we must first prepare a few components. You can cook bubur kacang ijo aroma durian using 10 ingredients and 5 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Aroma Durian:</h3>

<ol>
	
		<li>{Make ready 300 gr of kacang ijo, cuci bersih dan tiriskan. </li>
	
		<li>{Make ready 1 buah of durian kupas. </li>
	
		<li>{Take Secukupnya of gula merah aren sisir. </li>
	
		<li>{Get Secukupnya of gula pasir. </li>
	
		<li>{Make ready Sejumput of garam. </li>
	
		<li>{Prepare 2 cm of jahe, geprek. </li>
	
		<li>{Get 1 lembar of daun pandan. </li>
	
		<li>{Get 1.2 liter of air. </li>
	
		<li>{Make ready 600 ml of santan agak kental. </li>
	
		<li>{Get 50 ml of air larutan sagu (1sdm sagu + air). </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo Aroma Durian:</h3>

<ol>
	
		<li>
			Didihkan air, masukkan kacang ijo. Didihkan lagi kurleb 5 menit. Matikan api diamkan minimal 30 menit dengan panci tertutup rapat.
			
			
		</li>
	
		<li>
			Tambahkan daun pandan dan jahe. Didihkan lagi hingga airnya habis dan kacangnya merekah.
			
			
		</li>
	
		<li>
			Tuang santan, beri gula aren, gula pasir dan sejumput garam. Biarkan mendidih.
			
			
		</li>
	
		<li>
			Masukkan durian sambil diaduk. Setelah mendidih kurleb 5 menit, tuang larutan sagu. Aduk cepat, biarkan mendidih sebentar. Koreksi rasa dan matikan api.
			
			
		</li>
	
		<li>
			Angkat dan sajikan hangat.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this exceptional food bubur kacang ijo aroma durian recipe. Thanks so much for your time. I'm confident that you will make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to save this page in your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
