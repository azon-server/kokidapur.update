---
description: "Recipe of Award-winning Bubur Manado"
title: "Recipe of Award-winning Bubur Manado"
slug: 268-recipe-of-award-winning-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/d7e17e57bb52dce8/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's Louise, welcome to our recipe site. Today, I'm gonna show you how to make a special dish, bubur manado. It is one of my favorites. This time, I will make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Manado is one of the most favored of current trending meals on earth. It is enjoyed by millions daily. It's simple, it is quick, it tastes yummy. Bubur Manado is something that I have loved my entire life. They're nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we must prepare a few ingredients. You can have bubur manado using 7 ingredients and 6 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Take  of Kaldu ayam. </li>
	
		<li>{Prepare 1 bh of jagung di pipil. </li>
	
		<li>{Get 1/4 bh of labu kuning potong2. </li>
	
		<li>{Make ready 1 batang of sereh. </li>
	
		<li>{Get 1 cup of beras. </li>
	
		<li>{Prepare Segenggam of bayam. </li>
	
		<li>{Take secukupnya of Garam, gula, merica. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Manado:</h3>

<ol>
	
		<li>
			Cuci beras. Didihkan kaldu, masukkan beras dan sereh.
			
			
		</li>
	
		<li>
			Saya pindah ke wajan biar lbh enak masaknya.
			
			
		</li>
	
		<li>
			Masak beras spt kalau masak nasi biasa, tp airnya lbh bny. Sesekali diaduk agar tdk lengket di wajan. Kalau kurang air bisa ditambah air lagi.
			
			
		</li>
	
		<li>
			Setelah beras lunak, masukkan jagung, labu kuning, beri garam, merica, gula masak smp empuk dan beras jd bubur. Sebagian labu saya haluskan di wajan, sebagian masih utuh, cek rasa.
			
			
		</li>
	
		<li>
			Saya bagi bubur jd 2, sebagian tanpa bayam. Yg sebagian pakai bayam..
			
			
		</li>
	
		<li>
			Sajikan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food bubur manado recipe. Thank you very much for reading. I am confident that you can make this at home. There is gonna be interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
