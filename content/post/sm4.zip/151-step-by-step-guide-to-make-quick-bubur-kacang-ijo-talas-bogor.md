---
description: "Step-by-Step Guide to Make Quick Bubur Kacang Ijo Talas Bogor"
title: "Step-by-Step Guide to Make Quick Bubur Kacang Ijo Talas Bogor"
slug: 151-step-by-step-guide-to-make-quick-bubur-kacang-ijo-talas-bogor

<p>
	<strong>Bubur Kacang Ijo Talas Bogor</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/ce7a29562d39cde9/680x482cq70/bubur-kacang-ijo-talas-bogor-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Talas Bogor" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, I'm gonna show you how to prepare a special dish, bubur kacang ijo talas bogor. One of my favorites. For mine, I am going to make it a bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo Talas Bogor is one of the most well liked of recent trending foods in the world. It's easy, it is fast, it tastes delicious. It's appreciated by millions every day. Bubur Kacang Ijo Talas Bogor is something that I have loved my whole life. They're fine and they look wonderful.
</p>

<p>
To begin with this recipe, we must first prepare a few components. You can cook bubur kacang ijo talas bogor using 12 ingredients and 4 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Talas Bogor:</h3>

<ol>
	
		<li>{Prepare  of Bahan bubur kacang hijau :. </li>
	
		<li>{Prepare 200 gr of kacang hijau. </li>
	
		<li>{Get 200 gr of talas bogor potong kotak. </li>
	
		<li>{Take 200 gr of buah nangka ambil dagingnya dan potong-potong. </li>
	
		<li>{Prepare 250 gr of gula aren larutkan dengan air. </li>
	
		<li>{Get 1/2 gelas of santan kental. </li>
	
		<li>{Make ready secukupnya of air. </li>
	
		<li>{Make ready  of Bahan saos santan :. </li>
	
		<li>{Prepare 1 gelas of santan kental. </li>
	
		<li>{Get 2 lembar of daun pandan. </li>
	
		<li>{Make ready 1/2 sendok teh of tepung maezena. </li>
	
		<li>{Make ready Sedikit of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo Talas Bogor:</h3>

<ol>
	
		<li>
			Siapkan nangka tanpa biji, talas yang sudah dikupas, potong-potong sedang..
			
			
		</li>
	
		<li>
			Rebus kacang hijau hingga mendidih, tutup pancinya, matikan kompor, biarkan selama 15 menit sampai kacang hijau mengembang. Setelah 15 menit masak kembali kacang hijau sampai empuk, masukkan talas bogor tambahkan gula merah, aduk-aduk, tambahkan 1/2 gelas santan kental, biarkan mendidih, tambahkan buah nangka, aduk2 dan angkat. Sisihkan..
			
			
		</li>
	
		<li>
			Buat saos santannya : campurkan 1 gelas santan kental dengan tepung maezena, tambahkan daun pandan, aduk2 rebus hingga mendidih, tambahkan sedikit garam, aduk-aduk, selesai..
			
			
		</li>
	
		<li>
			Tuang kacang ijo di dalam mangkok saji, siram dengan saos santan diatasnya.. kacang ijo talas bogor siap dinikmati.. 😋👍.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this special food bubur kacang ijo talas bogor recipe. Thank you very much for reading. I'm confident you can make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to save this page in your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
