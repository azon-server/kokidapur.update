---
description: "Step-by-Step Guide to Prepare Super Quick Homemade Burjo (bubur kacang ijo)"
title: "Step-by-Step Guide to Prepare Super Quick Homemade Burjo (bubur kacang ijo)"
slug: 94-step-by-step-guide-to-prepare-super-quick-homemade-burjo-bubur-kacang-ijo

<p>
	<strong>Burjo (bubur kacang ijo)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/dd9e42e55fcf8350/680x482cq70/burjo-bubur-kacang-ijo-foto-resep-utama.jpg" alt="Burjo (bubur kacang ijo)" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you are having an amazing day today. Today, we're going to make a distinctive dish, burjo (bubur kacang ijo). It is one of my favorites food recipes. For mine, I will make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Burjo (bubur kacang ijo) is one of the most favored of recent trending meals in the world. It is enjoyed by millions every day. It's simple, it's quick, it tastes delicious. They're nice and they look wonderful. Burjo (bubur kacang ijo) is something which I have loved my entire life.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we have to first prepare a few components. You can have burjo (bubur kacang ijo) using 11 ingredients and 4 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Burjo (bubur kacang ijo):</h3>

<ol>
	
		<li>{Prepare  of Bahan bubur. </li>
	
		<li>{Prepare 250 gr of kacang hijau, cuci bersih. </li>
	
		<li>{Get 2 liter of air utk merebus. </li>
	
		<li>{Take 2 lembar of daun pandan, simpulkan. </li>
	
		<li>{Make ready 1/2 bungkus of tepung hunkwe. </li>
	
		<li>{Take 150 gr of gula pasir. </li>
	
		<li>{Get 1/2 sdt of garam. </li>
	
		<li>{Make ready  of Bahan santan. </li>
	
		<li>{Prepare 300 ml of santan kental. </li>
	
		<li>{Make ready 1/2 sdt of garam. </li>
	
		<li>{Get 1 lembar of daun pandan, simpulkan. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Burjo (bubur kacang ijo):</h3>

<ol>
	
		<li>
			Masukan smua bahan kecuali tepung hunkwe, masak slama 10-15 menit sejak kompor dinyalakan..
			
			
		</li>
	
		<li>
			Stelah matang matikan api dan tunggu sampai uap panasnya hilang. Aduk hunkwe dengan sdikit air, lalu masukan ke dalam bubur kacang hijaunya aduk dg api sedang sampai meletup (tanda sudah matang).
			
			
		</li>
	
		<li>
			Rebus bahan santan, sdikit garam dan daun pandan, aduk² hingga mendidih.
			
			
		</li>
	
		<li>
			Sajikan kacang hijau dengan kuah santan, saya dan suami klo makan suka di ksh krimer kental manis sedikit, biar brasa ky beli di langganan 🤭..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food burjo (bubur kacang ijo) recipe. Thanks so much for reading. I'm confident you can make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
