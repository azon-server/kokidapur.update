---
description: "Recipe of Any-night-of-the-week Bubur Pahit (Bubur Manado)"
title: "Recipe of Any-night-of-the-week Bubur Pahit (Bubur Manado)"
slug: 462-recipe-of-any-night-of-the-week-bubur-pahit-bubur-manado

<p>
	<strong>Bubur Pahit (Bubur Manado)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/b19f5097a8115e78/680x482cq70/bubur-pahit-bubur-manado-foto-resep-utama.jpg" alt="Bubur Pahit (Bubur Manado)" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is Louise, welcome to my recipe site. Today, we're going to prepare a special dish, bubur pahit (bubur manado). It is one of my favorites. For mine, I'm gonna make it a bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur Pahit (Bubur Manado) is one of the most popular of recent trending meals in the world. It is easy, it is fast, it tastes delicious. It's enjoyed by millions daily. Bubur Pahit (Bubur Manado) is something that I have loved my whole life. They're nice and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we must prepare a few ingredients. You can have bubur pahit (bubur manado) using 18 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Pahit (Bubur Manado):</h3>

<ol>
	
		<li>{Make ready 1/2 kg of beras cuci bersih. </li>
	
		<li>{Make ready 1 ikat of kangkung. </li>
	
		<li>{Take 2 lembar of daun pepaya (bila ingin lebih pahit bisa ditambah). </li>
	
		<li>{Take 1 ikat of daun singkong buang batangnya. </li>
	
		<li>{Make ready 2 buah of jagung preteli. </li>
	
		<li>{Make ready 1 bungkus of kecambah (saya skip gaada). </li>
	
		<li>{Get 2 lembar of daun salam. </li>
	
		<li>{Make ready Secukupnya of daun melinjo (saya skip gaada). </li>
	
		<li>{Make ready Secukupnya of merica. </li>
	
		<li>{Prepare Secukupnya of garam (saya pakai royco). </li>
	
		<li>{Make ready Secukupnya of air. </li>
	
		<li>{Make ready  of Bahan Sambal. </li>
	
		<li>{Prepare 1 bungkus kecil of terasi. </li>
	
		<li>{Take 10 buah of cabe rawit (optional pedasnya). </li>
	
		<li>{Take 1 buah of tomat. </li>
	
		<li>{Prepare 5 siung of bawang merah. </li>
	
		<li>{Take 3 siung of bawang putih. </li>
	
		<li>{Get 1/2 sdt of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Pahit (Bubur Manado):</h3>

<ol>
	
		<li>
			Iris semua sayur dedaunan dan cuci bersih..
			
			
		</li>
	
		<li>
			Didihkan air, masukan beras yang sudah di cuci dan daun salam masak hingga menjadi bubur (koreksi kekentalan bila ingin tambah air bisa) setelah bubur matang, masukan semua sayuran dan aduk sampai matang..
			
			
		</li>
	
		<li>
			Tambahkan royco dan merica. Koreksi rasa..
			
			
		</li>
	
		<li>
			Untuk bahan sambal, rebus semua bahan kecuali terasi dan garam. Tiriskan dan ulek sampai lembut bersama terasi dan garam. Sajikan bubur bersama sambal, taburan bawang goreng dan kecap manis..
			
			
		</li>
	
		<li>
			Tuang bubur ke dalam mangkok sesuai porsi kemudian kucuri dengan sambal terasi yang sudah dibuat diatasnya. Bisa juga ditambah bawang goreng dan kecap. Sajikan hangat..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this exceptional food bubur pahit (bubur manado) recipe. Thank you very much for your time. I'm confident that you can make this at home. There is gonna be more interesting food at home recipes coming up. Don't forget to save this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
