---
description: "Recipe of Quick Bubur Kacang Ijo"
title: "Recipe of Quick Bubur Kacang Ijo"
slug: 222-recipe-of-quick-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/52083a74a7f80a21/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you are having an incredible day today. Today, we're going to prepare a special dish, bubur kacang ijo. It is one of my favorites. This time, I will make it a bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo is one of the most well liked of recent trending meals on earth. It is appreciated by millions every day. It is simple, it's quick, it tastes yummy. They are fine and they look fantastic. Bubur Kacang Ijo is something which I have loved my whole life.
</p>

<p>
To begin with this particular recipe, we must prepare a few ingredients. You can have bubur kacang ijo using 6 ingredients and 4 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Take 250 gr of Kacang ijo. </li>
	
		<li>{Prepare 250 gr of gula merah(manis sesuai selera). </li>
	
		<li>{Take 5 sdm of susu kental manis. </li>
	
		<li>{Prepare 1000 ml of air putih bersih. </li>
	
		<li>{Get 1 pcs of santan kara. </li>
	
		<li>{Prepare 1/2 sdt of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Masukan kacang ijo yang sudah di rendam semalam kedalam air sampai mendidih.
			
			
		</li>
	
		<li>
			Tambahkan gula merah dan susu sambil aduk.
			
			
		</li>
	
		<li>
			Tambahkan garam. Aduk kembali.
			
			
		</li>
	
		<li>
			Setelah kacang mulai empuk, tambahkan santan kara. Aduk merata dan angkat.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur kacang ijo recipe. Thank you very much for reading. I'm sure you can make this at home. There is gonna be interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
