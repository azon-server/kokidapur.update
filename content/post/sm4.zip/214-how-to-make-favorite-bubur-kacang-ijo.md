---
description: "How to Make Favorite Bubur Kacang Ijo"
title: "How to Make Favorite Bubur Kacang Ijo"
slug: 214-how-to-make-favorite-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/0210e0d1e1b490be/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is Louise, welcome to my recipe site. Today, I'm gonna show you how to make a special dish, bubur kacang ijo. It is one of my favorites. For mine, I will make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo is one of the most favored of recent trending meals in the world. It's easy, it is quick, it tastes delicious. It's appreciated by millions every day. They're nice and they look wonderful. Bubur Kacang Ijo is something that I have loved my entire life.
</p>

<p>
To get started with this recipe, we have to first prepare a few components. You can have bubur kacang ijo using 12 ingredients and 6 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Prepare  of Bahan:. </li>
	
		<li>{Get 200 gr of kacang hijau. </li>
	
		<li>{Get 2 lembar of daun pandan. </li>
	
		<li>{Prepare 3 sisir of gula merah. </li>
	
		<li>{Get  of Gula pasir secukupnya (apabila kurang manis). </li>
	
		<li>{Get 800 ml of air. </li>
	
		<li>{Take 3 sdm of tepung maizena. </li>
	
		<li>{Get Sejumput of garam. </li>
	
		<li>{Get  of Kuah santan:. </li>
	
		<li>{Take 200 ml of santan. </li>
	
		<li>{Make ready 2 lembar of daun pandan. </li>
	
		<li>{Make ready Sejumput of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau lalu rendam dengan air selama 1 malam. Kemudian bilas dengan air mengalir dan tiriskan..
			
			
		</li>
	
		<li>
			Masukkan kacang hijau kedalam panci, tambahkan 800ml air, daun pandan dan sejumput garam. Rebus hingga setengah empuk lalu masukkan gula jawa yang telah disisir halus..
			
			
		</li>
	
		<li>
			Aduk hingga gula jawa larut dan kacang hijau empuk, koreksi rasa. Jika kurang manis, boleh ditambah gula pasir sesuai selera..
			
			
		</li>
	
		<li>
			Tambahkan 3 sdm maizena yang telah dilarutkan dengan sedikit air sambil terus diaduk hingga mengental. Angkat dan sisihkan..
			
			
		</li>
	
		<li>
			Kuah santan: masukkan santan kental kedalam panci, tambahkan daun pandan dan sejumput garam. Masak hingga mendidih sambil terus diaduk. Angkat dan sisihkan..
			
			
		</li>
	
		<li>
			Sajikan bubur kacang hijau bersama kuah santan. Bubur kacang hijau siap untuk dinikmati 😊.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur kacang ijo recipe. Thanks so much for your time. I'm confident you will make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
