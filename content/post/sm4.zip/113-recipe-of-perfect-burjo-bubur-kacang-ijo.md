---
description: "Recipe of Perfect Burjo (Bubur Kacang Ijo)"
title: "Recipe of Perfect Burjo (Bubur Kacang Ijo)"
slug: 113-recipe-of-perfect-burjo-bubur-kacang-ijo

<p>
	<strong>Burjo (Bubur Kacang Ijo)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/3dfc766c7242ed1b/680x482cq70/burjo-bubur-kacang-ijo-foto-resep-utama.jpg" alt="Burjo (Bubur Kacang Ijo)" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Jim, welcome to my recipe site. Today, I will show you a way to make a distinctive dish, burjo (bubur kacang ijo). It is one of my favorites. For mine, I will make it a bit unique. This will be really delicious.
</p>
	
<p>
	Burjo (Bubur Kacang Ijo) is one of the most popular of recent trending foods in the world. It is enjoyed by millions every day. It is easy, it is quick, it tastes yummy. They are nice and they look wonderful. Burjo (Bubur Kacang Ijo) is something which I have loved my entire life.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we must first prepare a few components. You can have burjo (bubur kacang ijo) using 17 ingredients and 2 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Burjo (Bubur Kacang Ijo):</h3>

<ol>
	
		<li>{Make ready 250 gr of kacang hijau (rendam dulu selama kurleb 3 jam). </li>
	
		<li>{Take 4 bh of gula jawa. </li>
	
		<li>{Get 4 sdm of gula pasir. </li>
	
		<li>{Make ready 3 ruas of jahe (geprek). </li>
	
		<li>{Prepare 2 lbr of daun pandan (ikat simpul). </li>
	
		<li>{Prepare 100 gr of sagu (larutkan dengan air). </li>
	
		<li>{Get 1/2 sdt of garam. </li>
	
		<li>{Take 1/4 sdt of vanili bubuk. </li>
	
		<li>{Get 1200 ml of air. </li>
	
		<li>{Prepare  of Kuah santan:. </li>
	
		<li>{Make ready 2 bks of santan Kara kemasan 65 ml. </li>
	
		<li>{Prepare 2 lbr of daun pandan (ikat simpul). </li>
	
		<li>{Take 2 sdm of tepung beras (larutkan dengan air). </li>
	
		<li>{Take 1/4 sdt of garam. </li>
	
		<li>{Take 1/4 sdt of vanili bubuk. </li>
	
		<li>{Make ready Secukupnya of gula pasir. </li>
	
		<li>{Make ready 300 ml of air. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Burjo (Bubur Kacang Ijo):</h3>

<ol>
	
		<li>
			Presto kacang hijau dengan air secukupnya selama kurleb 10-15 menit. Setelah itu pindahkan ke panci biasa, tambahkan 1200 ml air, gula (gula jawa &amp; gula pasir), garam, jahe, vanili, dan daun pandan, masak hingga mendidih. Setelah itu baru masukkan larutan sagu, aduk cepat lalu matikan api. Cara ke-2 bisa juga pada saat presto kacang hijau sekalian masukkan jahe, gula jawa, dan daun pandan..
			
			
		</li>
	
		<li>
			Masak kuah santan pada panci terpisah, tambahkan garam, gula, vanili, dan daun pandan. Masak sambil diaduk terus hingga mendidih agar santan tidak pecah. Lalu masukkan larutan tepung beras, aduk hingga kuah kental dan meletup-letup. Angkat dan matikan api. Bubur kacang ijo siap untuk disajikan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food burjo (bubur kacang ijo) recipe. Thank you very much for your time. I am confident you can make this at home. There's gonna be more interesting food in home recipes coming up. Don't forget to save this page on your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
