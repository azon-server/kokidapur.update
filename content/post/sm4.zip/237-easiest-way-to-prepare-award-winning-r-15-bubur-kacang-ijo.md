---
description: "Easiest Way to Prepare Award-winning R-15.. Bubur Kacang iJo"
title: "Easiest Way to Prepare Award-winning R-15.. Bubur Kacang iJo"
slug: 237-easiest-way-to-prepare-award-winning-r-15-bubur-kacang-ijo

<p>
	<strong>R-15.. Bubur Kacang iJo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/ba176bc5f9312c35/680x482cq70/r-15-bubur-kacang-ijo-foto-resep-utama.jpg" alt="R-15.. Bubur Kacang iJo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you are having an amazing day today. Today, we're going to make a special dish, r-15.. bubur kacang ijo. It is one of my favorites. This time, I will make it a bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	R-15.. Bubur Kacang iJo is one of the most favored of recent trending foods on earth. It's enjoyed by millions daily. It's easy, it is fast, it tastes delicious. R-15.. Bubur Kacang iJo is something which I've loved my entire life. They're nice and they look wonderful.
</p>

<p>
To get started with this particular recipe, we have to prepare a few ingredients. You can have r-15.. bubur kacang ijo using 8 ingredients and 6 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make R-15.. Bubur Kacang iJo:</h3>

<ol>
	
		<li>{Get 250 g of Kacang hijau , cuci bersih dan rendam selama 1 jam. </li>
	
		<li>{Get 100 g of Gula merah , cincang halus. </li>
	
		<li>{Take 2 L of Air mineral. </li>
	
		<li>{Take 4 sdm of Gula pasir. </li>
	
		<li>{Get 150 ml of Santan kental. </li>
	
		<li>{Get 1 sdt of Garam. </li>
	
		<li>{Prepare 2 cm of Jahe , memarkan. </li>
	
		<li>{Get 2 lembar of Daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make R-15.. Bubur Kacang iJo:</h3>

<ol>
	
		<li>
			Kacang hijau yang sudah direndam selama 1 jam kemudian rebus dengan 1 L air hingga matang dan empuk. Sisihkan..
			
			
		</li>
	
		<li>
			Rebus gula merah dan gula pasir dengan 500 ml air. Tunggu hingga larut..
			
			
		</li>
	
		<li>
			Setelah gula merah dan gula pasir larut dan mendidih, tuang ke dalam airrebusan kacang hijau dengan memakai saringan..
			
			
		</li>
	
		<li>
			Rebus kembali kacang hijau dan masukkan pula daun pandan dan santan. Aduk hingga rata..
			
			
		</li>
	
		<li>
			Masukan jahe dan juga garam. Aduk hingga rata. Aduk hingga santan berbusa..
			
			
		</li>
	
		<li>
			Bubur kacang hijau siap dinikmati selagi hangat..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this special food r-15.. bubur kacang ijo recipe. Thanks so much for your time. I am sure that you can make this at home. There is gonna be interesting food at home recipes coming up. Remember to save this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
