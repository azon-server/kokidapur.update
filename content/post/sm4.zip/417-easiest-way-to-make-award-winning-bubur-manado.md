---
description: "Easiest Way to Make Award-winning Bubur Manado"
title: "Easiest Way to Make Award-winning Bubur Manado"
slug: 417-easiest-way-to-make-award-winning-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/10e8b97a1e9a0774/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you're having an amazing day today. Today, we're going to prepare a special dish, bubur manado. One of my favorites. This time, I am going to make it a bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Manado is one of the most popular of recent trending meals in the world. It is appreciated by millions daily. It's easy, it is fast, it tastes delicious. They are fine and they look wonderful. Bubur Manado is something which I've loved my whole life.
</p>

<p>
To get started with this recipe, we have to first prepare a few components. You can have bubur manado using 16 ingredients and 6 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Make ready  of Nasi 2 sekul. </li>
	
		<li>{Get 1 sisir of Jagung. </li>
	
		<li>{Get 1 ikat of Kangkung. </li>
	
		<li>{Prepare 1 ikat of kemangi. </li>
	
		<li>{Get 1 potong of Labu. </li>
	
		<li>{Make ready  of Ikan asin jambal. </li>
	
		<li>{Make ready  of Kaldu ayam. </li>
	
		<li>{Take  of Gula. </li>
	
		<li>{Take  of Garam. </li>
	
		<li>{Prepare secukupnya of Air. </li>
	
		<li>{Take  of Bumbu halus. </li>
	
		<li>{Make ready 3 siung of Bawang putih. </li>
	
		<li>{Prepare  of Merica. </li>
	
		<li>{Get  of Bumbu aromatic. </li>
	
		<li>{Prepare 2 of Salam. </li>
	
		<li>{Take 2 of Sere. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Manado:</h3>

<ol>
	
		<li>
			Cuci bersih ikan asin, lalu di goreng.
			
			
		</li>
	
		<li>
			Potong dan kupas labu 1 potong, lalu di kukus. Bersihkan dan sisir jagung.
			
			
		</li>
	
		<li>
			Masukkan nasi di wajan/panci diberi air, dengan api kecil aduk2.
			
			
		</li>
	
		<li>
			Masukkan labu yg telah dikukus dan jagung yg sudah di sisir, masukkan bumbu halus dan bumbu aromatic.
			
			
		</li>
	
		<li>
			Aduk2 sampai menjadi dirasa sudah empuk, masukkan kangkung, kemangi, dan juga Gula Garam, kaldu ayam sesuai selera.
			
			
		</li>
	
		<li>
			Langkah terakhir makan pakai ikan asin dan sambel daun jeruk 😗.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this special food bubur manado recipe. Thank you very much for your time. I'm confident that you will make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to save this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
