---
description: "Recipe of Any-night-of-the-week Bubur kacang ijo simple"
title: "Recipe of Any-night-of-the-week Bubur kacang ijo simple"
slug: 144-recipe-of-any-night-of-the-week-bubur-kacang-ijo-simple

<p>
	<strong>Bubur kacang ijo simple</strong>. 
	Wb genks Yups kali ini saya mau buat bubur kacang ijo campur mata ikan, kali ini buatnya gk pake ribet ya genks. Bubur kacang hijau, abbreviated burjo, is a Southeast Asian sweet porridge (bubur) made from mung beans (kacang hijau), coconut milk, and palm sugar or cane sugar. Cara bikin bubur kacang hijau / ijo memerlukan trik dan tips tersendiri, sehingga hasilnya bisa lebih bagus dan juga enak serta lembut.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/085e920d7bb2efb6/680x482cq70/bubur-kacang-ijo-simple-foto-resep-utama.jpg" alt="Bubur kacang ijo simple" style="width: 100%;">
	
	
		Kacang hijau direbus sampai empuk dengan daun pandan.
	
		KOMPAS.com - Olahan kacang hijau dapat menjadi sarapan praktis, cukup dijadikan bubur tanpa santan dengan tambahan gula merah.
	
		Bubur kacang ijo ini sudah tersebar di hampir seluruh daerah yang ada di nusantara sehingga Anda pun dapat dengan mudah untuk menemukannya.
	
</p>
<p>
	Hey everyone, it's Louise, welcome to our recipe page. Today, I'm gonna show you how to make a special dish, bubur kacang ijo simple. One of my favorites. For mine, I will make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang ijo simple is one of the most popular of current trending meals on earth. It is easy, it is quick, it tastes yummy. It is appreciated by millions daily. Bubur kacang ijo simple is something which I have loved my entire life. They are fine and they look fantastic.
</p>
<p>
	Wb genks Yups kali ini saya mau buat bubur kacang ijo campur mata ikan, kali ini buatnya gk pake ribet ya genks. Bubur kacang hijau, abbreviated burjo, is a Southeast Asian sweet porridge (bubur) made from mung beans (kacang hijau), coconut milk, and palm sugar or cane sugar. Cara bikin bubur kacang hijau / ijo memerlukan trik dan tips tersendiri, sehingga hasilnya bisa lebih bagus dan juga enak serta lembut.
</p>

<p>
To get started with this recipe, we have to first prepare a few ingredients. You can cook bubur kacang ijo simple using 8 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo simple:</h3>

<ol>
	
		<li>{Take 250 gram of kacang hijau. </li>
	
		<li>{Prepare 100 gram of gula pasir. </li>
	
		<li>{Take  of Santan kelapa(saya pake 3 bungkus santan instan,merk terserah). </li>
	
		<li>{Take 2 sendok of tepung maizena larutkan dengan air. </li>
	
		<li>{Take 2 lembar of daun pandan. </li>
	
		<li>{Prepare 1 ruas of jahe. </li>
	
		<li>{Make ready  of Tambahan:. </li>
	
		<li>{Take  of Susu kental manis. </li>
	
</ol>
<p>
	
		Setiap daerah biasanya memiliki ciri khas sendiri, namun salah satu jenis yang paling terkenal adalah bubur kacang ijo dari Madura.
	
		Simple, namun rasanya yang legit dan sedap selalu membuat kami datang kesana setiap minggu, tepatnya setiap hari Rabu.
	
		Komposisinya memang hanya kacang hijau dan sagu mutiara, namun karena menggunakan gula aren dan santan kental yang gurih membuat rasa bubur menjadi istimewa.
	
		Bubur kacang ijo inggih punika salah satunggaling olah-olahan Indonesia ingkang dipundamel saking kacang ijo lan dipunsukani toya, ron pandhan saha gula jawa ingkang salajengipun dipungodhog ngantos umub lan kacangipun empuk.
	
</p>

<h3>Instructions to make Bubur kacang ijo simple:</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau.kemudian masak kacang hijau beserta daun pandan dan jahe.masak sekitar 1 jam kalau airnya menyusut tambahkan air..
			
			
		</li>
	
		<li>
			Jika kacang hijau sudah terlihat empuk tambahkan gula dan tepung maizena.aduk sambil cek rasa..
			
			
		</li>
	
		<li>
			Untuk santan.masak santan dan daun pandan tambahkan air.masak pake api sedang dan jangan lupa aduk terus biar santan tidak pecah..
			
			
		</li>
	
		<li>
			Cara penyajian:ambil bubur santan sajikan di mangkok siram dengan santan di atasnya.kalau suka boleh tambahkan susu kental manis dan es batu..
			
			
		</li>
	
		<li>
			Bubur kacang ijo siap di nikmati..
			
			
		</li>
	
</ol>

<p>
	
		Bubur kacang hijau sometimes is pronounced as bubur kacang ijo.
	
		Well, I didn&#39;t have time to make the complex version.
	
		So I made a version that was enriched with palm sugar (gula aren), flavoured with pandan leaves and touched of coconut milk at the end.
	
		Fimela.com, Jakarta Bubur kacang ijo yang bertekstur lembut adalah yang paling sempurna.
	
		Kacang Hijau memiliki kandungan gizi yang lengkap seperti kalsium, zat besi, kalium, fosfor, folat, vitamin B, vitamin A, vitamin C, magnesium, karbohidrat dan beragam nutrisi lainnya.
	
</p>

<p>
	So that is going to wrap this up with this special food bubur kacang ijo simple recipe. Thank you very much for reading. I'm confident that you can make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
