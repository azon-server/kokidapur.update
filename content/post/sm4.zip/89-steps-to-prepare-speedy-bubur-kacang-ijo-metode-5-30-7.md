---
description: "Steps to Prepare Speedy Bubur Kacang Ijo Metode 5-30-7"
title: "Steps to Prepare Speedy Bubur Kacang Ijo Metode 5-30-7"
slug: 89-steps-to-prepare-speedy-bubur-kacang-ijo-metode-5-30-7

<p>
	<strong>Bubur Kacang Ijo Metode 5-30-7</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/f457781ede797d65/680x482cq70/bubur-kacang-ijo-metode-5-30-7-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Metode 5-30-7" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Jim, welcome to our recipe site. Today, I'm gonna show you how to make a special dish, bubur kacang ijo metode 5-30-7. One of my favorites food recipes. For mine, I will make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo Metode 5-30-7 is one of the most favored of recent trending foods on earth. It's appreciated by millions every day. It's easy, it's quick, it tastes yummy. They're fine and they look fantastic. Bubur Kacang Ijo Metode 5-30-7 is something which I've loved my whole life.
</p>

<p>
To get started with this recipe, we have to first prepare a few ingredients. You can cook bubur kacang ijo metode 5-30-7 using 7 ingredients and 4 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Metode 5-30-7:</h3>

<ol>
	
		<li>{Take 250 gr of kacang ijo. </li>
	
		<li>{Take 200 gr of gula pasir. </li>
	
		<li>{Take 1500 ml of air. </li>
	
		<li>{Prepare 65 ml of santan instant (me: Kara). </li>
	
		<li>{Take 1 sdm of garam. </li>
	
		<li>{Prepare 2 lembar of daun pandan. </li>
	
		<li>{Prepare Sedikit of vanilli. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo Metode 5-30-7:</h3>

<ol>
	
		<li>
			Cuci bersih bubur kacang ijo dan rendam kurang lebih 2 jam (tidak direndam juga gak apa2)..
			
			
		</li>
	
		<li>
			Didihkan air dan daun pandan, setelah mendidih masukkan kacang ijo dan masak selama 5 menit. Matikan api, tutup panci dan diamkan selama 30 menit..
			
			
		</li>
	
		<li>
			Setelah 30 menit masak lagi bubur kacang ijo selama 7 menit atau sampe kacang ijo pecah dan empuk. Tambahkan garam, vanilli bubuk dan santan, aku tambah air lagi ya karena suka banyak air. Gula juga sesuai selera ya buibu bisa ditambah atau dikurangi..
			
			
		</li>
	
		<li>
			Bubur kacang ijo siap dinikmati, bisa tambah susu kental manis. Dicocol sama roti juga aduhayy 😋😁.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur kacang ijo metode 5-30-7 recipe. Thank you very much for your time. I am sure that you can make this at home. There is gonna be interesting food at home recipes coming up. Remember to bookmark this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
