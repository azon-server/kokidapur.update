---
description: "Recipe of Favorite Bubur Kacang Ijo"
title: "Recipe of Favorite Bubur Kacang Ijo"
slug: 74-recipe-of-favorite-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/5bd0fe4588ae9b81/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is Louise, welcome to our recipe site. Today, I'm gonna show you how to prepare a special dish, bubur kacang ijo. It is one of my favorites. This time, I am going to make it a bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo is one of the most favored of recent trending meals on earth. It is appreciated by millions every day. It's simple, it's quick, it tastes yummy. Bubur Kacang Ijo is something which I have loved my whole life. They're fine and they look wonderful.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we have to prepare a few ingredients. You can cook bubur kacang ijo using 7 ingredients and 3 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Take 250 gr of kacang ijo. </li>
	
		<li>{Prepare 1,5 of air. </li>
	
		<li>{Make ready 65 ml of santan kental instan(kar*). </li>
	
		<li>{Take 10 sdm of gula pasir (sesuai selera). </li>
	
		<li>{Make ready 1 jempol of jahe,geprek. </li>
	
		<li>{Prepare 1 lembar of daun pandan,ikat simpul. </li>
	
		<li>{Prepare Sejumput of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Cuci bersih kacang ijo lalu rebus sampai mendidih bersama daun pandan,jahe dengan 1,5 air selama 5 menit. Lalu matikan kompor tutup panci rebusan diamkan selama 30 menit..
			
			
		</li>
	
		<li>
			Rebus kembali kacang ijo tambahkan gula,garam dan santan. Masak sampai matang..
			
			
		</li>
	
		<li>
			Angkat dan sajikan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this exceptional food bubur kacang ijo recipe. Thank you very much for reading. I am sure that you will make this at home. There's gonna be more interesting food in home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
