---
description: "Recipe of Ultimate Bubur Manado / Tinutuan"
title: "Recipe of Ultimate Bubur Manado / Tinutuan"
slug: 326-recipe-of-ultimate-bubur-manado-tinutuan

<p>
	<strong>Bubur Manado / Tinutuan</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/d7f86f8d7bc6db51/680x482cq70/bubur-manado-tinutuan-foto-resep-utama.jpg" alt="Bubur Manado / Tinutuan" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you're having an incredible day today. Today, we're going to make a special dish, bubur manado / tinutuan. One of my favorites food recipes. This time, I am going to make it a bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Manado / Tinutuan is one of the most favored of current trending foods in the world. It's appreciated by millions daily. It is simple, it's fast, it tastes yummy. They are nice and they look wonderful. Bubur Manado / Tinutuan is something that I have loved my whole life.
</p>

<p>
To get started with this particular recipe, we must prepare a few ingredients. You can have bubur manado / tinutuan using 13 ingredients and 5 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Manado / Tinutuan:</h3>

<ol>
	
		<li>{Take 150 gram of beras. </li>
	
		<li>{Get 1 slice of labu parang (potong kecil2). </li>
	
		<li>{Prepare 1 buah of jagung (diserut). </li>
	
		<li>{Take 1 ikat of bayam. </li>
	
		<li>{Take 1 buah of wortel (potong kotak2). </li>
	
		<li>{Prepare 5 lembar of daun kemangi. </li>
	
		<li>{Prepare 1 ikat of kangkung. </li>
	
		<li>{Take 1 batang of serai. </li>
	
		<li>{Get 3 lembar of daun salam. </li>
	
		<li>{Get 1 of / sdt merica bubuk. </li>
	
		<li>{Make ready 2 sdt of garam. </li>
	
		<li>{Get 1 sdt of gula. </li>
	
		<li>{Take 3 Ltr of air putih. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado / Tinutuan:</h3>

<ol>
	
		<li>
			Cuci beras, rendam dengan air selama 30 menit.
			
			
		</li>
	
		<li>
			Setelah 30 menit, masak beras, labu dan jagung dengan serai yg sdh geprek. Masukkan bumbu2 nya. Aduk terus, masak hingga mendidik..
			
			
				
					<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Bubur Manado / Tinutuan"> <br>
				
			
		</li>
	
		<li>
			Jika sudah mendidih, masukkan wortel. Ketika wortel sudah agak melunak, masukkan kangkung, bayam, dan daun kemangi.
			
			
		</li>
	
		<li>
			Aduk2 terus hingga menjadi bubur. Jika terlalu kental, bisa ditambahkan air..
			
			
		</li>
	
		<li>
			Hidangkan dengan cakalang, ikan teri, atau ikan roa..voila!.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this special food bubur manado / tinutuan recipe. Thanks so much for your time. I am confident you can make this at home. There is gonna be interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
