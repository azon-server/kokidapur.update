---
description: "Steps to Make Favorite 34. Bubur Kacang Ijo Tetap Creamy Tanpa Santan (5.30.7)"
title: "Steps to Make Favorite 34. Bubur Kacang Ijo Tetap Creamy Tanpa Santan (5.30.7)"
slug: 77-steps-to-make-favorite-34-bubur-kacang-ijo-tetap-creamy-tanpa-santan-5307

<p>
	<strong>34. Bubur Kacang Ijo Tetap Creamy Tanpa Santan (5.30.7)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/020fbcc1f0f8d4c7/680x482cq70/34-bubur-kacang-ijo-tetap-creamy-tanpa-santan-5307-foto-resep-utama.jpg" alt="34. Bubur Kacang Ijo Tetap Creamy Tanpa Santan (5.30.7)" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is me, Dave, welcome to my recipe page. Today, I'm gonna show you how to prepare a distinctive dish, 34. bubur kacang ijo tetap creamy tanpa santan (5.30.7). One of my favorites. For mine, I will make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	34. Bubur Kacang Ijo Tetap Creamy Tanpa Santan (5.30.7) is one of the most popular of recent trending foods on earth. It is easy, it is fast, it tastes delicious. It's enjoyed by millions daily. They're nice and they look fantastic. 34. Bubur Kacang Ijo Tetap Creamy Tanpa Santan (5.30.7) is something which I've loved my whole life.
</p>

<p>
To get started with this recipe, we have to first prepare a few components. You can cook 34. bubur kacang ijo tetap creamy tanpa santan (5.30.7) using 9 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make 34. Bubur Kacang Ijo Tetap Creamy Tanpa Santan (5.30.7):</h3>

<ol>
	
		<li>{Get 150 gr of Kacang hijau. </li>
	
		<li>{Get 600 ml of Air (tahap 1). </li>
	
		<li>{Get 500 ml of Air (tahap 2, boleh skip). </li>
	
		<li>{Prepare 50 gr of Gula aren/gula merah. </li>
	
		<li>{Make ready 35 gr of Gula pasir. </li>
	
		<li>{Make ready 1/2 sdt of Garam. </li>
	
		<li>{Take 1/8 sdt of lada/pala bubuk (boleh skip). </li>
	
		<li>{Get 1 lembar of Daun pandan (saya tidak pakai). </li>
	
		<li>{Prepare secukupnya of Krimer bubuk. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make 34. Bubur Kacang Ijo Tetap Creamy Tanpa Santan (5.30.7):</h3>

<ol>
	
		<li>
			Pertama rebus 600ml air dalam panci tertutup hingga mendidih. Sambil menunggu, cuci bersih kacang hijau dan tiriskan. Masukkan kacang setelah air mendidih. Rebus dengan api sedang cenderung besar selama 5 menit. Tutup panci. Jaga agar air tetap mendidih (bergelembung banyak) selama kacang direbus. Bila ada, rebus daun pandan bersama kacang hijau..
			
			
		</li>
	
		<li>
			Setelah 5 menit, matikan api. Biarkan panci tetap di atas kompor dan tutup rapat. Diamkan selama 30 menit. Sembari menunggu, siapkan gula merah, sisir, agar nanti mudah larut. Saya menggunakan gula aren bubuk. Dalam foto, gula aren telah dicampur dengan gula pasir..
			
			
		</li>
	
		<li>
			Setelah 30 menit, rebus kembali kacang hijau dengan api sedang. Masukkan gula merah, gula pasir, garam dan lada/pala bubuk. Aduk rata dan tutup kembali panci. Masak selama 7 menit. Biasanya kacang hijau baru merekah pada tahap ini..
			
			
		</li>
	
		<li>
			Setelah 7 menit, buka tutup panci. Pada tahap ini air biasanya menyusut banyak. Bila Anda suka bubur kental maka matikan api. Proses memasak selesai. Tetapi bila Anda suka bubur yang berkuah banyak seperti saya, tambahkan lagi 500ml air dan rebus hingga mendidih. Lalu matikan api. Bubur siap dinikmati..
			
			
		</li>
	
		<li>
			Tambahkan krimer secukupya di setiap mangkuk saji sesaat sebelum disantap..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this exceptional food 34. bubur kacang ijo tetap creamy tanpa santan (5.30.7) recipe. Thank you very much for your time. I am sure you can make this at home. There is gonna be more interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
