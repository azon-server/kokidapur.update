---
description: "Recipe of Award-winning Bubur Kacang Ijo"
title: "Recipe of Award-winning Bubur Kacang Ijo"
slug: 83-recipe-of-award-winning-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/56209c850d23f158/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is Drew, welcome to my recipe page. Today, I'm gonna show you how to prepare a special dish, bubur kacang ijo. It is one of my favorites food recipes. For mine, I am going to make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo is one of the most well liked of current trending meals in the world. It's enjoyed by millions daily. It is easy, it's quick, it tastes yummy. Bubur Kacang Ijo is something which I have loved my whole life. They're fine and they look wonderful.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we must prepare a few components. You can cook bubur kacang ijo using 13 ingredients and 5 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Get  of Bahan Bubur. </li>
	
		<li>{Get 250 gr of kacang ijo (rendam semalam). </li>
	
		<li>{Prepare 125 gr of gula merah (sisir). </li>
	
		<li>{Prepare 2 sdm of gula pasir. </li>
	
		<li>{Prepare 2 sdm of maizena (larutkan). </li>
	
		<li>{Get 2 lembar of daun pandan (simpulkan). </li>
	
		<li>{Make ready 1 liter of air. </li>
	
		<li>{Make ready  of Bahan kuah. </li>
	
		<li>{Get 2 bungkus of santan Kara. </li>
	
		<li>{Make ready 6 bungkus of air matang bekas santan. </li>
	
		<li>{Make ready 2 lembar of daun pandan (simpulkan). </li>
	
		<li>{Take 2 sdm of maizena (larutkan). </li>
	
		<li>{Make ready 1/2 sdm of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Rebus kacang ijo yang sudah di rendam semalam..
			
			
		</li>
	
		<li>
			Tunggu hingga surut air nya dan merekah kacang ijo nya. Kemudian masukkan gula merah, daun pandan dan gula pasir. Aduk rata..
			
			
		</li>
	
		<li>
			Aduk pelan-pelan kemudian tambahkan maizena. Bila dirasa sudah kental, angkat dan matikan kompor..
			
			
		</li>
	
		<li>
			Buat kuah : dalam panci masukkan santan, daun pandan, garam dan air. Aduk - aduk jangan sampai pecah, tunggu kental dan meletup-letup. Kemudian masukkan larutan maizena. Aduk sebentar lagi, kemudian angkat..
			
			
		</li>
	
		<li>
			Penyajian : taruh bubur dalam mangkok, kemudian siram dengan kuah santan. Siap dinikmati🥰.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this special food bubur kacang ijo recipe. Thanks so much for reading. I am sure you will make this at home. There's gonna be interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
