---
description: "Recipe of Quick Bolu Santan Kukus Lapis Trio /Pelangi Tanpa Pengembang Tanpa Emulsifier, Ringan&amp;amp;Lembut"
title: "Recipe of Quick Bolu Santan Kukus Lapis Trio /Pelangi Tanpa Pengembang Tanpa Emulsifier, Ringan&amp;amp;Lembut"
slug: 1-recipe-of-quick-bolu-santan-kukus-lapis-trio-pelangi-tanpa-pengembang-tanpa-emulsifier-ringan-and-amp-lembut

<p>
	<strong>Bolu Santan Kukus Lapis Trio /Pelangi Tanpa Pengembang Tanpa Emulsifier, Ringan&amp;Lembut</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/daa28296dee87946/680x482cq70/bolu-santan-kukus-lapis-trio-pelangi-tanpa-pengembang-tanpa-emulsifier-ringanlembut-foto-resep-utama.jpg" alt="Bolu Santan Kukus Lapis Trio /Pelangi Tanpa Pengembang Tanpa Emulsifier, Ringan&amp;Lembut" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an amazing day today. Today, I'm gonna show you how to make a distinctive dish, bolu santan kukus lapis trio /pelangi tanpa pengembang tanpa emulsifier, ringan&amp;lembut. One of my favorites food recipes. For mine, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bolu Santan Kukus Lapis Trio /Pelangi Tanpa Pengembang Tanpa Emulsifier, Ringan&amp;Lembut is one of the most well liked of current trending foods in the world. It is simple, it is fast, it tastes delicious. It is enjoyed by millions daily. Bolu Santan Kukus Lapis Trio /Pelangi Tanpa Pengembang Tanpa Emulsifier, Ringan&amp;Lembut is something which I have loved my entire life. They are fine and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we must prepare a few components. You can have bolu santan kukus lapis trio /pelangi tanpa pengembang tanpa emulsifier, ringan&amp;lembut using 7 ingredients and 8 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bolu Santan Kukus Lapis Trio /Pelangi Tanpa Pengembang Tanpa Emulsifier, Ringan&amp;Lembut:</h3>

<ol>
	
		<li>{Make ready 4 butir of telur. </li>
	
		<li>{Prepare 1 gelas of peres gula pasir. </li>
	
		<li>{Prepare 1 gelas of peres tepung terigu. </li>
	
		<li>{Prepare 1/4 sdt of garam. </li>
	
		<li>{Make ready 65 ml (1 sachet) of santan instan. </li>
	
		<li>{Prepare 1/2 gelas of minyak sayur. </li>
	
		<li>{Prepare  of Pewarna merah dan hijau. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bolu Santan Kukus Lapis Trio /Pelangi Tanpa Pengembang Tanpa Emulsifier, Ringan&amp;Lembut:</h3>

<ol>
	
		<li>
			Sebelumnya saya ingin tunjukkan gelas jadoel yang saya gunakan untuk menakar.
			
			
		</li>
	
		<li>
			Kocok telur dan gula pasir dengan mixer kecepatan tinggi hingga kental (adonan tidak menetes jika dicolek dengan jari tangan).
			
			
		</li>
	
		<li>
			Masukkan terigu dan garam dengan menggunakan mixer speed terendah hingga menyatu.
			
			
		</li>
	
		<li>
			Masukkan santan diikuti minyak masih dengan mixer speed terendah hingga rata.
			
			
		</li>
	
		<li>
			Bagi adonan menjadi 3 bagian, satu bagian dibiarkan tanpa warna, satu lagi diberi pewarna hijau dan sisanya diberi warna merah.
			
			
		</li>
	
		<li>
			Panaskan dandang, masukkan loyang ukuran 18 x 18 cm yang sudah dialasi kertas roti (tidak perlu diolesi apapun).
			
			
		</li>
	
		<li>
			Kukus adonan selapis demi selapis, tuang adonan berikutnya jika lapisan bolu sebelumnya sudah matang (sekitar 10-15 menit).
			
			
		</li>
	
		<li>
			Catatan: konversi takaran yang digunakan 1 gelas peres gula pasir sekitar 200 gram, 1 gelas peres terigu sekitar 100 gram dan 1/2 gelas minyak sayur sekitar 125 ml.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this special food bolu santan kukus lapis trio /pelangi tanpa pengembang tanpa emulsifier, ringan&amp;lembut recipe. Thank you very much for your time. I'm sure that you can make this at home. There's gonna be more interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
