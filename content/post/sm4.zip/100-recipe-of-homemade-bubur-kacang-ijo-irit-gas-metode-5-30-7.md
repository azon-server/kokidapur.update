---
description: "Recipe of Homemade Bubur Kacang Ijo Irit gas (metode 5:30:7)"
title: "Recipe of Homemade Bubur Kacang Ijo Irit gas (metode 5:30:7)"
slug: 100-recipe-of-homemade-bubur-kacang-ijo-irit-gas-metode-5-30-7

<p>
	<strong>Bubur Kacang Ijo Irit gas (metode 5:30:7)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/a2e728ece41eba58/680x482cq70/bubur-kacang-ijo-irit-gas-metode-5307-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Irit gas (metode 5:30:7)" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is Brad, welcome to my recipe site. Today, I'm gonna show you how to make a special dish, bubur kacang ijo irit gas (metode 5:30:7). It is one of my favorites food recipes. For mine, I am going to make it a little bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo Irit gas (metode 5:30:7) is one of the most favored of current trending foods on earth. It is simple, it is quick, it tastes delicious. It is enjoyed by millions daily. They're nice and they look fantastic. Bubur Kacang Ijo Irit gas (metode 5:30:7) is something which I have loved my entire life.
</p>

<p>
To get started with this particular recipe, we must first prepare a few ingredients. You can cook bubur kacang ijo irit gas (metode 5:30:7) using 14 ingredients and 8 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Irit gas (metode 5:30:7):</h3>

<ol>
	
		<li>{Get  of Bubur kacang ijo :. </li>
	
		<li>{Make ready 250 gr of kacang hijau. </li>
	
		<li>{Make ready 2 liter of air. </li>
	
		<li>{Prepare 25 gr of gula pasir. </li>
	
		<li>{Take 1/4 sdt of garam. </li>
	
		<li>{Prepare 2 lembar of daun pandan, potong2. </li>
	
		<li>{Take 120 gr of gula merah, sisir halus. </li>
	
		<li>{Prepare 30 gr of jahe, geprek. </li>
	
		<li>{Get 2 sdm of tepung tapioka, larutkan dengan 4 sdm air. </li>
	
		<li>{Prepare  of Kuah santan :. </li>
	
		<li>{Prepare 130 ml of santan kental. </li>
	
		<li>{Prepare 100 ml of air. </li>
	
		<li>{Take 1 lembar of daun pandan, simpulkan. </li>
	
		<li>{Take 1/2 sdt of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo Irit gas (metode 5:30:7):</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau. Tidak perlu direndam semalaman ya..
			
			
		</li>
	
		<li>
			Siapkan jahe, daun pandan, dan gula merah (disisir halus).
			
			
		</li>
	
		<li>
			Masak air sampai mendidih, kemudian masukkan kacang hijau, masak selama 5 menit dengan api besar. Lalu matikan kompor. Tutup panci, diamkan selama 30 menit. (baca caption diatas ya).
			
			
		</li>
	
		<li>
			Setelah didiamkan selama 30 menit. Nyalakan kompor, masak kembali selama 7 menit, masukkan jahe, gula pasir, gula merah, daun pandan, dan garam. Aduk2..
			
			
		</li>
	
		<li>
			Lalu tuang larutan tepung tapioka. Aduk. Matikan kompor..
			
			
		</li>
	
		<li>
			Kuah santan : masukkan semua bahan kuah santan dalam panci, aduk2, masak sampai meletup2. Matikan kompor..
			
			
		</li>
	
		<li>
			Sajikan bubur kacang hijau bersama kuah santan 😊.
			
			
		</li>
	
		<li>
			Saya suka dengan tekstur bubur kacang hijau yang kental seperti ini. Enak dan hemat gas 🤗😊 tidak perlu lagi rendam kacangnya semalaman. Selamat mencoba ya 🙏🤗.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this special food bubur kacang ijo irit gas (metode 5:30:7) recipe. Thank you very much for your time. I am sure you will make this at home. There is gonna be interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
