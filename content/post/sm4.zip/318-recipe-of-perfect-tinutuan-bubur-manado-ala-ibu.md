---
description: "Recipe of Perfect Tinutuan (Bubur Manado) Ala Ibu"
title: "Recipe of Perfect Tinutuan (Bubur Manado) Ala Ibu"
slug: 318-recipe-of-perfect-tinutuan-bubur-manado-ala-ibu

<p>
	<strong>Tinutuan (Bubur Manado) Ala Ibu</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/f6c737c77d5fd367/680x482cq70/tinutuan-bubur-manado-ala-ibu-foto-resep-utama.jpg" alt="Tinutuan (Bubur Manado) Ala Ibu" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you are having an incredible day today. Today, I'm gonna show you how to make a distinctive dish, tinutuan (bubur manado) ala ibu. It is one of my favorites. This time, I am going to make it a bit tasty. This will be really delicious.
</p>
	
<p>
	Tinutuan (Bubur Manado) Ala Ibu is one of the most favored of recent trending foods on earth. It is enjoyed by millions daily. It is simple, it is quick, it tastes yummy. Tinutuan (Bubur Manado) Ala Ibu is something that I've loved my entire life. They are nice and they look fantastic.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we must prepare a few ingredients. You can cook tinutuan (bubur manado) ala ibu using 23 ingredients and 10 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Tinutuan (Bubur Manado) Ala Ibu:</h3>

<ol>
	
		<li>{Take  of Tinutuan:. </li>
	
		<li>{Get 2 cup of beras putih, cuci bersih. </li>
	
		<li>{Get 2 ikat of sayur bayam, petik. </li>
	
		<li>{Prepare 6 ikat of sayur kangkung, petik dan potong sebagian batangnya. </li>
	
		<li>{Take 2 ikat of sayur daun kacang, petik. </li>
	
		<li>{Make ready 1 ikat of daun kemangi, petik. </li>
	
		<li>{Take 3 buah of jagung, serut. </li>
	
		<li>{Get 1/2 buah of labu kuning, kupas dan potong dadu. </li>
	
		<li>{Prepare 3 buah of ubi kayu/jalar ukuran sedang. </li>
	
		<li>{Make ready 2 batang of serai, memarkan. </li>
	
		<li>{Prepare secukupnya of garam. </li>
	
		<li>{Take secukupnya of air. </li>
	
		<li>{Get  of ikan:. </li>
	
		<li>{Take 4 ekor of ikan asin, potong 3 bagian/ekor. </li>
	
		<li>{Get secukupnya of air dingin/es. </li>
	
		<li>{Prepare secukupnya of minyak goreng. </li>
	
		<li>{Make ready  of sambal:. </li>
	
		<li>{Make ready 5 siung of bawang merah, iris. </li>
	
		<li>{Prepare 2 genggam of cabe rawit, ulek. </li>
	
		<li>{Take 3 buah of tomat, iris. </li>
	
		<li>{Prepare 2 bungkus of terasi abc. </li>
	
		<li>{Make ready secukupnya of garam. </li>
	
		<li>{Take secukupnya of minyak goreng. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Tinutuan (Bubur Manado) Ala Ibu:</h3>

<ol>
	
		<li>
			Siapkan semua bahan tinutuan. Petik semua sayuran (khusus sayur kangkung, sebagian batangnya di potong). Potong dadu labu kuning, serut jagung, memarkan serai, dan potong ubi. Kemudian cuci bersih semua sayuran dan bahan..
			
			
		</li>
	
		<li>
			Masukkan beras dan air secukupnya sampai menjadi bubur. Lalu masukkan serai dan labu, tunggu sampai matang. Tiriskan labu lalu haluskan. Kemudian masukkan kembali labu yang telah halus. Tambahkan ubi, tunggu sampai ubi matang dan empuk. (tambahkan air jika berkurang/sesuai keinginan Anda, agar bubur tidak hangus).
			
			
		</li>
	
		<li>
			Setelah ubi telah empuk dan matang. Masukkan sayuran saat bubur telah mendidih &amp; meletup. Kecilkan api kompor, campur bubur dengan sayuran. Matikan kompor. (jangan terlalu lama di masak agar sayuran tidak terlalu layu/lembek) nb: saya mengganti dandang/panci, karena dandang yang pertama tak cukup ukurannya 😂.
			
			
		</li>
	
		<li>
			Siapakan semua bahan, haluskan cabe rawit dan sedikit garam. Panaskan minyak goreng, masukkan irisan bawang merah (sampai harum), tomat dan 2 terasi sampai matang dan tomat layu. Kemudian masukkan cabe rawit yang telah di ulek. Tumis sambel sampai matang dan tercampur rata..
			
			
		</li>
	
		<li>
			Setelah matang, tiriskan pada mangkok yang telah Anda sediakan.
			
			
		</li>
	
		<li>
			Potong ikan asin menjadi 3 bagian/ekor. Lalu rendam dengan air dingin/es selama kurang lebih 10-15 menit. Lalu tiriskan. Panaskan minyak goreng, masukkan ikan. Goreng ikan asin sampai kering dan garing..
			
			
		</li>
	
		<li>
			Tiriskan ikan asin pada pirinh yang telah Anda sediakan..
			
			
		</li>
	
		<li>
			Tinutuan atau Bubur Manado pun telah siap di santap. Lengkap dengan ikan asin dan sambal pedas. Enaaaak~~.
			
			
		</li>
	
		<li>
			Jadi pengen nambah lagi dan lagi 😂.
			
			
		</li>
	
		<li>
			(jika disekitar rumah ada yang jualan atau menanam sayuran daun gedi, bisa di tambahkan kedalam kelompok sayuran tinutuan ini).
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this special food tinutuan (bubur manado) ala ibu recipe. Thank you very much for your time. I am confident that you will make this at home. There is gonna be interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
