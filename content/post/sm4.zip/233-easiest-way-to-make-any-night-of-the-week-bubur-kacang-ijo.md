---
description: "Easiest Way to Make Any-night-of-the-week Bubur Kacang Ijo"
title: "Easiest Way to Make Any-night-of-the-week Bubur Kacang Ijo"
slug: 233-easiest-way-to-make-any-night-of-the-week-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/29cd09ce24fa3332/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an amazing day today. Today, I'm gonna show you how to prepare a special dish, bubur kacang ijo. One of my favorites. For mine, I am going to make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo is one of the most favored of recent trending meals in the world. It's easy, it's fast, it tastes delicious. It is enjoyed by millions daily. Bubur Kacang Ijo is something which I've loved my entire life. They're nice and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we must prepare a few components. You can have bubur kacang ijo using 9 ingredients and 1 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Prepare 150 gr of kacang ijo. </li>
	
		<li>{Make ready Segenggam of beras. </li>
	
		<li>{Get 2 lbr of pandan (ikat). </li>
	
		<li>{Prepare 400 ml of santan kental (1/2 btr kelapa). </li>
	
		<li>{Take 2 sendok sayur of gula pasir. </li>
	
		<li>{Prepare 1 L of air. </li>
	
		<li>{Make ready Sejempol of jahe iris tipis. </li>
	
		<li>{Prepare 3 cm of kayu manis. </li>
	
		<li>{Take 1 bh of bunga lawang. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Cuci bersih kacang ijo,dlm panci masukkan irisan jahe, bunga lawang, kayu manis, pandan dan kacang ijo tambahkan air,masak 15 mnt disusul dg beras. Masak sampai kacang dan berasnya lunak masukkan santan,gula pasir aduk aduk agar santan gk pecah. Sajikan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur kacang ijo recipe. Thanks so much for your time. I'm sure that you will make this at home. There is gonna be more interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
