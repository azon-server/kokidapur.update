---
description: "Recipe of Ultimate Bubur Kacang Hijau Kental dan Lembut"
title: "Recipe of Ultimate Bubur Kacang Hijau Kental dan Lembut"
slug: 28-recipe-of-ultimate-bubur-kacang-hijau-kental-dan-lembut

<p>
	<strong>Bubur Kacang Hijau Kental dan Lembut</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/40fcecb21db47757/680x482cq70/bubur-kacang-hijau-kental-dan-lembut-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental dan Lembut" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is Drew, welcome to our recipe page. Today, I'm gonna show you how to prepare a distinctive dish, bubur kacang hijau kental dan lembut. It is one of my favorites food recipes. For mine, I am going to make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Hijau Kental dan Lembut is one of the most popular of current trending foods in the world. It is easy, it's quick, it tastes delicious. It is appreciated by millions daily. They're nice and they look fantastic. Bubur Kacang Hijau Kental dan Lembut is something that I have loved my whole life.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we have to first prepare a few components. You can cook bubur kacang hijau kental dan lembut using 9 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental dan Lembut:</h3>

<ol>
	
		<li>{Make ready 2 cup of biji kacang hijau. </li>
	
		<li>{Get 150 gram of gula aren. </li>
	
		<li>{Take 1 sdt of garam. </li>
	
		<li>{Get 500 ml of santan. </li>
	
		<li>{Make ready 3 sdm of tepung tapioka. </li>
	
		<li>{Get 1000 ml of air. </li>
	
		<li>{Prepare 50 ml of air. </li>
	
		<li>{Take 3 helai of daun pandan. </li>
	
		<li>{Make ready 3 ruas of jahe. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Hijau Kental dan Lembut:</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau, kemudian rendam sekitar 30 menit..
			
			
		</li>
	
		<li>
			Buang air rendaman, kemudian tuang 700 ml air. Rebus selama 5 menit, 5 menit dihitung dari saat air mendidih. Setelah 5 menit, matikan kompor dan panci ditutup biarkan 30 menit. Setelah 30 menit, kacang hijau sudah banyak yang pecah..
			
			
		</li>
	
		<li>
			Masukan sisa air, gula aren, jahe dan daun pandan. Masak sampai gula larut. Larutkan tepung tapioka dengan 50ml air, kemudian masukan ke dalam bubur kacang hijau, aduk sampai kental. Pakai api kecil saja supaya tidak gosong..
			
			
		</li>
	
		<li>
			Kalau sudah rata matangnya matikan kompor. Selanjutnya membuat kuah santan: santan dimasak bersama daun pandan dan garam, sambil diaduk. Oiya kalau mau ga ribet, bisa pakai santan instan yang langsung bisa dipakai..
			
			
		</li>
	
		<li>
			Bubur kacang hijau kental dan lembut sudah matang, siap dimakan bersama dengan kuah santan. Dimakan tanpa santan sudah enak 😍..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur kacang hijau kental dan lembut recipe. Thank you very much for reading. I'm sure that you will make this at home. There's gonna be more interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
