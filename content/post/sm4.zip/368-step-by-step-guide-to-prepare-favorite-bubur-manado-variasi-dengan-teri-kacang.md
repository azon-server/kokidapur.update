---
description: "Step-by-Step Guide to Prepare Favorite Bubur manado variasi dengan teri kacang"
title: "Step-by-Step Guide to Prepare Favorite Bubur manado variasi dengan teri kacang"
slug: 368-step-by-step-guide-to-prepare-favorite-bubur-manado-variasi-dengan-teri-kacang

<p>
	<strong>Bubur manado variasi dengan teri kacang</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/6e32c143ffc29001/680x482cq70/bubur-manado-variasi-dengan-teri-kacang-foto-resep-utama.jpg" alt="Bubur manado variasi dengan teri kacang" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you are having an amazing day today. Today, we're going to make a special dish, bubur manado variasi dengan teri kacang. It is one of my favorites. For mine, I'm gonna make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur manado variasi dengan teri kacang is one of the most popular of recent trending foods on earth. It is enjoyed by millions every day. It's easy, it's fast, it tastes yummy. They are fine and they look wonderful. Bubur manado variasi dengan teri kacang is something which I've loved my whole life.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we must prepare a few ingredients. You can have bubur manado variasi dengan teri kacang using 15 ingredients and 8 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur manado variasi dengan teri kacang:</h3>

<ol>
	
		<li>{Get 1 mangkuk kecil of beras (kurang lebih/sesuai selera). </li>
	
		<li>{Make ready 1 buah of wortel. </li>
	
		<li>{Make ready 1 ikat of bayam. </li>
	
		<li>{Take 100 gr of labu kuning (kurang lebih/sesuai selera). </li>
	
		<li>{Take 100 gr of jagung pipil (kurang lebih/sesuai selera). </li>
	
		<li>{Make ready 4 buah of bawang putih. </li>
	
		<li>{Take 4 buah of bawang merah. </li>
	
		<li>{Make ready Secukupnya of mentega. </li>
	
		<li>{Prepare Secukupnya of garam, gula, totole. </li>
	
		<li>{Make ready 100 gr of teri mentah (kurang lebih). </li>
	
		<li>{Take Secukupnya of kacang tanah mentah. </li>
	
		<li>{Make ready Secukupnya of minyak goreng. </li>
	
		<li>{Make ready Secukupnya of cabe rawit. </li>
	
		<li>{Prepare Secukupnya of bawang goreng. </li>
	
		<li>{Get Secukupnya of air putih. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur manado variasi dengan teri kacang:</h3>

<ol>
	
		<li>
			Hihihi maafkan jika semua bahan takarannya sesuai selera..
			
			
		</li>
	
		<li>
			Potong wortel dan labu kuning kotak2. Petik daun bayam. Cuci bersih. Sisihkan.
			
			
		</li>
	
		<li>
			Kupas semua bawang merah dan putih. Cuci bersih. Iris masing2 bawang 3 buah. Tumis hingga harum dengan mentega..
			
			
		</li>
	
		<li>
			Jika sudah harum dan cukup matang, masukkan labu kuning, tambahkan air putih. Rebus hingga lunak. Jika sudah lunak masukkan wortel dan jagung pipil. Tambahkan air putih nya. Harus tenggelam..
			
			
		</li>
	
		<li>
			Cuci bersih beras. Jika labu kuning dan wortel udh lunak masukkan beras. Tambahkan air putih. Aduk2 dan tambahkan gula garam totole. Tambahkan air putih terus-menerus sampai beras melunak dan menjadi bubur. Aduk2 dan koreksi rasa. Bayam dimasukkan terakhir yaa. Saat buburnya udh siap disajikan krn bayam dimasak nya sebentar aja..
			
			
		</li>
	
		<li>
			Sambil menunggu bubur, kita goreng teri dulu. Cuci bersih teri dan kacang tanah. Siapkan wajan dan beri minyak goreng. Goreng teri dan kacang hingga matang..
			
			
		</li>
	
		<li>
			Iris sisa bawang merah dan putih. Tumis dengan minyak goreng hingga harum. Masukkan cabe rawit yg diulek, tambahkan air putih sedikit. Masukkan teri dan kacang tanah nya. aduk2 dan tambahkan gula garam. Jika udh matang. Sisihkan.
			
			
		</li>
	
		<li>
			Sajikan semua makanan yang kita buat diatas piring atau mangkok. Bubur, diatas nya teri kacang dan bawang goreng. Bubur manado variasi dengan teri kacang sudah siap dinikmati.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this special food bubur manado variasi dengan teri kacang recipe. Thanks so much for your time. I'm confident that you can make this at home. There's gonna be more interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
