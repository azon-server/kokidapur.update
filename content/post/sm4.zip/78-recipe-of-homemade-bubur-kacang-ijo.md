---
description: "Recipe of Homemade Bubur Kacang ijo"
title: "Recipe of Homemade Bubur Kacang ijo"
slug: 78-recipe-of-homemade-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/f192c229b864f38c/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's John, welcome to my recipe site. Today, we're going to prepare a distinctive dish, bubur kacang ijo. One of my favorites food recipes. For mine, I am going to make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang ijo is one of the most popular of current trending meals in the world. It's simple, it's fast, it tastes delicious. It is appreciated by millions every day. Bubur Kacang ijo is something that I've loved my whole life. They're nice and they look fantastic.
</p>

<p>
To get started with this particular recipe, we must first prepare a few components. You can cook bubur kacang ijo using 8 ingredients and 3 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang ijo:</h3>

<ol>
	
		<li>{Make ready 250 gr of kacang ijo. </li>
	
		<li>{Get 150 gr of gula pasir. </li>
	
		<li>{Make ready 2 ruas of jahe. </li>
	
		<li>{Take 2 lembar of daun pandan. </li>
	
		<li>{Get  of Bahan untuk santan:. </li>
	
		<li>{Get 200 ml of santan kental + 100 ml air. </li>
	
		<li>{Make ready 1/2 sdt of garam. </li>
	
		<li>{Prepare 1 lembar of daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang ijo:</h3>

<ol>
	
		<li>
			Rendam kacang ijo 6 jam, lalu masukkan kedalam panci dgn air secukupnya. Masukkan jahe, gula pasir dan daun pandan. Masak hingga kacang ijo empuk. Lalu matikan kompor..
			
			
		</li>
	
		<li>
			Cara membuat santan: masukkan santan kental, air, garam dan daun pandan. Aduk-aduk hingga mendidih. Lalu diamkan..
			
			
		</li>
	
		<li>
			Kacang ijo siap di santap😊.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur kacang ijo recipe. Thanks so much for reading. I am sure you can make this at home. There is gonna be more interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
