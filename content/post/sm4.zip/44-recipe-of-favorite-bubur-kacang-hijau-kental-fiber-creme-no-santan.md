---
description: "Recipe of Favorite Bubur Kacang Hijau Kental Fiber Creme (No Santan)"
title: "Recipe of Favorite Bubur Kacang Hijau Kental Fiber Creme (No Santan)"
slug: 44-recipe-of-favorite-bubur-kacang-hijau-kental-fiber-creme-no-santan

<p>
	<strong>Bubur Kacang Hijau Kental Fiber Creme (No Santan)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/b91b4df7140004eb/680x482cq70/bubur-kacang-hijau-kental-fiber-creme-no-santan-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental Fiber Creme (No Santan)" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you are having an incredible day today. Today, I will show you a way to make a distinctive dish, bubur kacang hijau kental fiber creme (no santan). It is one of my favorites. For mine, I am going to make it a bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Hijau Kental Fiber Creme (No Santan) is one of the most favored of recent trending meals in the world. It's simple, it is quick, it tastes yummy. It is appreciated by millions daily. They are nice and they look fantastic. Bubur Kacang Hijau Kental Fiber Creme (No Santan) is something that I've loved my whole life.
</p>

<p>
To get started with this particular recipe, we must first prepare a few components. You can cook bubur kacang hijau kental fiber creme (no santan) using 13 ingredients and 7 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental Fiber Creme (No Santan):</h3>

<ol>
	
		<li>{Prepare 250-300 gr of kacang hijau. </li>
	
		<li>{Prepare 3 l of air. </li>
	
		<li>{Take 5-7 lbr of daun pandan (krn sy punya kecil jadi 2x nya). </li>
	
		<li>{Make ready 1 sdt of jahe bubuk. </li>
	
		<li>{Take 2 sdt of vanili bubuk. </li>
	
		<li>{Make ready 2 blok of gula jawa/gula merah, parut. </li>
	
		<li>{Make ready Sejumput of garam. </li>
	
		<li>{Make ready Secukupnya of gula pasir. </li>
	
		<li>{Prepare 10 sdm of tepung sagu (sy pake sagu ubi), larutkan. </li>
	
		<li>{Take  of Bahan pengganti santan:. </li>
	
		<li>{Take 3 sdm of fiber creme. </li>
	
		<li>{Make ready 1 cup of air/ secukupnya. </li>
	
		<li>{Get Sejumput of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Hijau Kental Fiber Creme (No Santan):</h3>

<ol>
	
		<li>
			Rendam kacang hijau minimal 8 jam. Saya semalaman. Taruh di kulkas yah..
			
			
		</li>
	
		<li>
			Tiriskan air rendaman, lalu cuci kacang. Tiriskan lagi..
			
			
		</li>
	
		<li>
			Rebus kacang dengan pandan, jahe, vanili. Pastikan kacang benar-benar empuk. Air akan sat lumayan banyak, jadi pastikan cukup air untuk kuah bubur..
			
			
		</li>
	
		<li>
			Setelah empuk, masukkan gula jawa, garam, gula pasir. Aduk rata. Tes rasa..
			
			
		</li>
	
		<li>
			Pastikan kacang sudah sangat empuk ya. Cirinya: kulit kacang terbuka/sobek semua &amp; kacang mudah tergerus. Tambahkan larutan tepung sagu sedikit demi sedikit sambil diaduk terus. Pastikan tidak berhenti aduk agar tidak menggumpal. Aduk hingga mendidih kembali. Matikan kompor. Tetap aduk hingga beberapa saat. Di tahap ini sebenarnya bubur sudah bisa langsung disajikan yah. Yummy loh👍🏻.
			
			
		</li>
	
		<li>
			Sekarang buat larutan pengganti santannya dengan cara campurkan fiber creme ke dalam air, tambahkan sejumput garam. Kalau saya walaupun pake air minum, tetap saya rebus sebentar hingga mendidih/ada bubble. Jadinya sekitar 1/2 gelas kurang..
			
			
		</li>
	
		<li>
			Tuang secukupnya ke atas bubur. Bubur kacang hijau kental fiber creme jadi deh! Saya lebih suka disajikan dingin. Kamu?.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this special food bubur kacang hijau kental fiber creme (no santan) recipe. Thank you very much for reading. I'm sure you can make this at home. There is gonna be more interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
