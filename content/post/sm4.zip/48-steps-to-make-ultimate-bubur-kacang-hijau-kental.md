---
description: "Steps to Make Ultimate Bubur Kacang Hijau Kental"
title: "Steps to Make Ultimate Bubur Kacang Hijau Kental"
slug: 48-steps-to-make-ultimate-bubur-kacang-hijau-kental

<p>
	<strong>Bubur Kacang Hijau Kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/e1f083c5a7cdc102/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you are having an incredible day today. Today, I'm gonna show you how to prepare a special dish, bubur kacang hijau kental. It is one of my favorites food recipes. For mine, I'm gonna make it a bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Hijau Kental is one of the most popular of recent trending meals on earth. It is simple, it is quick, it tastes yummy. It is enjoyed by millions every day. They're nice and they look wonderful. Bubur Kacang Hijau Kental is something which I have loved my whole life.
</p>

<p>
To begin with this recipe, we must first prepare a few components. You can have bubur kacang hijau kental using 7 ingredients and 8 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>{Prepare 1 of gelas kacang hijau. </li>
	
		<li>{Make ready 4 of gula merah. </li>
	
		<li>{Prepare 5 sdm of gula putih. </li>
	
		<li>{Get 1 ruas of jahe. </li>
	
		<li>{Take 1 of santan instan (kara). </li>
	
		<li>{Get  of Daun pandan (ak skip krna gada). </li>
	
		<li>{Make ready 3 sdm of tepung kanji (aci). </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>
			Rendam bubur kacang +-6 jam, kalo bisa sih semaleman ya hehe ini ku rendam dari pagi kurang +-6jam lah yah hehee.
			
			
		</li>
	
		<li>
			Ini jahe nya ak parut dan setengahnya ku ulek biar berasa rasa jahenya.
			
			
		</li>
	
		<li>
			Iris gula merah biar mudah larut nantinya.
			
			
		</li>
	
		<li>
			Panaskan air hingga mendidih lalu masukan kacamg hijau yg sudaj diremdam hingga empuk.
			
			
		</li>
	
		<li>
			Kalo sudah setengah empuk masuik campurannya jahe,gula merah dan gula putih (koreksi rasa).
			
			
		</li>
	
		<li>
			Larutkan tepung kanji dengan air sedikit, lalu masukan ke dalam bubur kacang hijau, aduk hingga rata jangan sampai menggumpal ya (kekentalan bisa diatur ya klo terlalu kental bisa tambah air lagi, klo kurang kental didihkan trus smpe airnya susut).
			
			
		</li>
	
		<li>
			Sementara itu didihkan santan kara, klo mau pake daun pandan lebih endeuusss hehe santan ini bisa di satuin ke bubur kacangnya, tp ak dipisah karna takutnya mudah basi.
			
			
		</li>
	
		<li>
			Pindahkan bubur ke mangkok secukupnya aja, tambah santan di atasnya 😁 siap disajikan deh, selamat memcubaaa hehe.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this special food bubur kacang hijau kental recipe. Thank you very much for your time. I am confident that you will make this at home. There's gonna be more interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
