---
description: "Simple Way to Prepare Super Quick Homemade Bubur Kacang Ijo Kental Manis Endesss #kamismanis _cookpad #cookpadcommunity"
title: "Simple Way to Prepare Super Quick Homemade Bubur Kacang Ijo Kental Manis Endesss #kamismanis _cookpad #cookpadcommunity"
slug: 16-simple-way-to-prepare-super-quick-homemade-bubur-kacang-ijo-kental-manis-endesss-kamismanis-cookpad-cookpadcommunity

<p>
	<strong>Bubur Kacang Ijo Kental Manis Endesss #kamismanis _cookpad #cookpadcommunity</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/b25e49532f163574/680x482cq70/bubur-kacang-ijo-kental-manis-endesss-kamismanis-_cookpad-cookpadcommunity-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Kental Manis Endesss #kamismanis _cookpad #cookpadcommunity" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's me, Dave, welcome to our recipe page. Today, I will show you a way to prepare a distinctive dish, bubur kacang ijo kental manis endesss #kamismanis _cookpad #cookpadcommunity. It is one of my favorites food recipes. This time, I'm gonna make it a bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo Kental Manis Endesss #kamismanis _cookpad #cookpadcommunity is one of the most favored of recent trending foods on earth. It is enjoyed by millions daily. It's simple, it is quick, it tastes delicious. Bubur Kacang Ijo Kental Manis Endesss #kamismanis _cookpad #cookpadcommunity is something that I have loved my entire life. They are nice and they look fantastic.
</p>

<p>
To get started with this recipe, we have to first prepare a few ingredients. You can have bubur kacang ijo kental manis endesss #kamismanis _cookpad #cookpadcommunity using 7 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Kental Manis Endesss #kamismanis _cookpad #cookpadcommunity:</h3>

<ol>
	
		<li>{Make ready 250 gram of kacang hijau. </li>
	
		<li>{Make ready 5 lembar of pandan. </li>
	
		<li>{Make ready 250 gram of gula jawa. </li>
	
		<li>{Take 100 gram of tepung sagu / kanji. </li>
	
		<li>{Take sejumput of garam. </li>
	
		<li>{Take 2 bungkus kecil of santan instan cair siap pakai. </li>
	
		<li>{Make ready Secukupnya of air. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo Kental Manis Endesss #kamismanis _cookpad #cookpadcommunity:</h3>

<ol>
	
		<li>
			Rendam dengan air bersih kacang hijau selama 6 jam.
			
			
		</li>
	
		<li>
			6jam kemudian masak di dalam panci sampai kacang hijau matang, tidak keras, mengembang tanda sudah matang. jangan lupa beri pandan. yg sudah di remas sebentar, agar bau harum lebih keluar..
			
			
		</li>
	
		<li>
			Masukkan gula jawa yg sudah di sisir sebelumnya. tambahkan garam..
			
			
		</li>
	
		<li>
			Larutkan tepung sagu / kanji dengan sedikit air matang dan masukkan dalam panci sambil aduk aduk agar rata dan tidak mengumpal. masak sampai meletup letup tanda sudah matang. cek rasa sebentar, jika manis dan gurih sudah pas, matikan api. sisihkan.
			
			
		</li>
	
		<li>
			Beralih ke kuah santan untuk sandingan bubur. masak dengan api kecil santan instan siap pakai. tambahkan sedikit garam. masukkan pandan. beri air 1 gelas. tunggu sampai mendidih. angkat segera sajikan bubur beserta kuahnya. selamat mencoba dan semoga berhasil..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this exceptional food bubur kacang ijo kental manis endesss #kamismanis _cookpad #cookpadcommunity recipe. Thanks so much for reading. I'm confident that you will make this at home. There is gonna be more interesting food at home recipes coming up. Remember to bookmark this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
