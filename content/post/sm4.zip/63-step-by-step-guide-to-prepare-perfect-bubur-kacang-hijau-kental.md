---
description: "Step-by-Step Guide to Prepare Perfect Bubur kacang hijau kental"
title: "Step-by-Step Guide to Prepare Perfect Bubur kacang hijau kental"
slug: 63-step-by-step-guide-to-prepare-perfect-bubur-kacang-hijau-kental

<p>
	<strong>Bubur kacang hijau kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/18a0567fc3c6a34c/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur kacang hijau kental" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an incredible day today. Today, we're going to prepare a special dish, bubur kacang hijau kental. It is one of my favorites. For mine, I am going to make it a little bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang hijau kental is one of the most well liked of current trending meals on earth. It is simple, it is quick, it tastes delicious. It's enjoyed by millions every day. Bubur kacang hijau kental is something which I have loved my whole life. They're nice and they look fantastic.
</p>

<p>
To begin with this particular recipe, we must prepare a few components. You can cook bubur kacang hijau kental using 13 ingredients and 4 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur kacang hijau kental:</h3>

<ol>
	
		<li>{Take 1/4 kg of kacang hijau. </li>
	
		<li>{Prepare 3 gelas of air. </li>
	
		<li>{Prepare 3 lbr of daun pandan. </li>
	
		<li>{Get 1 ruas jari of jahe (digeprek). </li>
	
		<li>{Make ready 3 sdm of tepung tapioka. </li>
	
		<li>{Prepare 3 sdm of gula pasir. </li>
	
		<li>{Take  of Gula merah. </li>
	
		<li>{Make ready  of Garam. </li>
	
		<li>{Make ready  of Santan pisah. </li>
	
		<li>{Take 130 ml of santan. </li>
	
		<li>{Make ready 1 gelas of air. </li>
	
		<li>{Get 1 lbr of daun pandan. </li>
	
		<li>{Prepare  of Garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang hijau kental:</h3>

<ol>
	
		<li>
			Cuci kacang hijau sampai bersih, masukkan dalam panci lalu tambahkan air, daun pandan &amp; jahe. Rebus dg api besar, jika sudah mendidih tutup panci &amp; kecilkan api, tunggu sampai kacang hijau empuk &amp; air menyusut..
			
			
		</li>
	
		<li>
			Jika kacang hijau sudah empuk,masukkan tepung tapioka yang sudah di cairkan sambil diaduk&#34; agar mengental. Tambahkan gula pasir, secukupnya gula merah &amp; garam. Cek rasa..
			
			
		</li>
	
		<li>
			Untuk santan, masak dipanci terpisah. Masukkan santan, tambahkan air, daun pandan &amp; garam. Aduk jangan sampai santan pecah, api ukuran kecil. Jika sudah mendidih, matikan api..
			
			
		</li>
	
		<li>
			Masukkan kacang hijau yang sudah matang kedalam mangkuk, kemudian siram pakai santan sesuai selera. Kacang hijau kental siap disajikan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this exceptional food bubur kacang hijau kental recipe. Thank you very much for reading. I'm sure that you will make this at home. There's gonna be interesting food in home recipes coming up. Don't forget to save this page in your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
