---
description: "Recipe of Quick Es Bubur kacang ijo"
title: "Recipe of Quick Es Bubur kacang ijo"
slug: 210-recipe-of-quick-es-bubur-kacang-ijo

<p>
	<strong>Es Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/0bbfa3b726819e29/680x482cq70/es-bubur-kacang-ijo-foto-resep-utama.jpg" alt="Es Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you're having an incredible day today. Today, we're going to make a distinctive dish, es bubur kacang ijo. It is one of my favorites food recipes. This time, I will make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Es Bubur kacang ijo is one of the most well liked of current trending meals on earth. It is appreciated by millions daily. It's simple, it is quick, it tastes yummy. Es Bubur kacang ijo is something that I have loved my whole life. They are nice and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we must first prepare a few ingredients. You can cook es bubur kacang ijo using 9 ingredients and 6 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Es Bubur kacang ijo:</h3>

<ol>
	
		<li>{Get 250 gr of kacang ijo (rendam semalaman). </li>
	
		<li>{Get 2 lembar of daun pandan (bole skip). </li>
	
		<li>{Get 2 ruas of jahe. </li>
	
		<li>{Get 250 gr of gula merah. </li>
	
		<li>{Make ready 100 ml of santan kental. </li>
	
		<li>{Prepare 1500 ml of air. </li>
	
		<li>{Make ready Secukupnya of garam. </li>
	
		<li>{Make ready Secukupnya of gula putih. </li>
	
		<li>{Get Secukupnya of SKM. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Es Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Rebus kacang hijau yang sudah direndam dengan jahe, air 1000ml dan daun pandan sampai kacang hijau pecah dan lembut.
			
			
		</li>
	
		<li>
			Masukan santan dan sisa air (500ml) aduk terus.
			
			
		</li>
	
		<li>
			Masukan gula merah dan garam.
			
			
		</li>
	
		<li>
			Icip rasa sambil masukan SKM dan gula putih.
			
			
		</li>
	
		<li>
			Setelah rasa pas sesuai selera, aduk terus jangan sampai pecah santan setelah hampir mendidih matikan kompor, aduk2 sampai dingin.
			
			
		</li>
	
		<li>
			Setelah dingin masukan kedalam plastik es lilin dan simpan di lemari pembeku..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this special food es bubur kacang ijo recipe. Thanks so much for reading. I'm sure you can make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
