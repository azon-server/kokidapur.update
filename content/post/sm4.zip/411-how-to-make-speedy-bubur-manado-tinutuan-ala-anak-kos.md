---
description: "How to Make Speedy Bubur Manado (Tinutuan) ala anak kos"
title: "How to Make Speedy Bubur Manado (Tinutuan) ala anak kos"
slug: 411-how-to-make-speedy-bubur-manado-tinutuan-ala-anak-kos

<p>
	<strong>Bubur Manado (Tinutuan) ala anak kos</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/170d757f8411770d/680x482cq70/bubur-manado-tinutuan-ala-anak-kos-foto-resep-utama.jpg" alt="Bubur Manado (Tinutuan) ala anak kos" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, I will show you a way to prepare a distinctive dish, bubur manado (tinutuan) ala anak kos. One of my favorites. This time, I am going to make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Manado (Tinutuan) ala anak kos is one of the most favored of recent trending foods in the world. It's simple, it is fast, it tastes yummy. It is appreciated by millions every day. Bubur Manado (Tinutuan) ala anak kos is something that I have loved my whole life. They are fine and they look wonderful.
</p>

<p>
To begin with this recipe, we have to prepare a few components. You can cook bubur manado (tinutuan) ala anak kos using 22 ingredients and 8 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Manado (Tinutuan) ala anak kos:</h3>

<ol>
	
		<li>{Take  of Bahan bubur :. </li>
	
		<li>{Make ready 1/4 kg of beras putih. </li>
	
		<li>{Make ready 2 ikat of kangkung. </li>
	
		<li>{Take 1 ikat of bayam. </li>
	
		<li>{Make ready 2 ikat of kemangi. </li>
	
		<li>{Get 1/2 buah of labu kuning. </li>
	
		<li>{Prepare 2 buah of ubi kuning. </li>
	
		<li>{Take 2 buah of Jagung. </li>
	
		<li>{Make ready 3 lembar of daun salam. </li>
	
		<li>{Prepare 3 lembar of daun jeruk. </li>
	
		<li>{Make ready 2 batang of sereh. </li>
	
		<li>{Take secukupnya of Lada. </li>
	
		<li>{Prepare secukupnya of Garam. </li>
	
		<li>{Take secukupnya of Kaldu jamur. </li>
	
		<li>{Prepare  of Air untuk merebus beras. </li>
	
		<li>{Take  of Minyak untuk menggoreng. </li>
	
		<li>{Get  of Bahan pelengkap:. </li>
	
		<li>{Take 2 buah of tahu cina. </li>
	
		<li>{Get  of Tempe (saya beli 3 ribu). </li>
	
		<li>{Make ready  of Teri medan (saya beli 10ribu). </li>
	
		<li>{Get  of Air untuk merendam. </li>
	
		<li>{Make ready secukupnya of Garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado (Tinutuan) ala anak kos:</h3>

<ol>
	
		<li>
			Cuci beras dan rendam beras selama 1 jam. Setelah itu sisihkan.
			
			
		</li>
	
		<li>
			Potong tempe dan tahu sesuai selera kemudian rendam dengan air garam. Goreng hingga kecokelatan. Cuci teri dan goreng hingga kecokelatan..
			
			
		</li>
	
		<li>
			Cuci jagung dan pipil jagung lalu sisihkan. Saya pipil menggunkan pisau..
			
			
		</li>
	
		<li>
			Potong-potong labu dan ubi kemudian cuci hingga bersih. Kemudian rebus hingga lembut lalu angkat. Hancurkan labu dan ubi (saya pakai garpu) lalu sisihkan..
			
			
		</li>
	
		<li>
			Cuci sayuran hingga bersih. Potong kangkung, bayam dan kemangi lalu sisihkan..
			
			
		</li>
	
		<li>
			Rebus beras yang sudah direndam dan jagung. Takaran air 3x takaran beras. Setelah sedikit hancur masukkan labu dan ubi yang sudah dihaluskan kemudian aduk hingga rata..
			
			
		</li>
	
		<li>
			Setelah mendidih dan beras pecah sepenuhnya, masukkan sayuran dan masak hingga matang. Tambahkan garam, kaldu jamur, lada kemudian koreksi rasa..
			
			
		</li>
	
		<li>
			Sajikan bubur manado tambahkan bahn pelengkap. Bubur manado siap dihidangkan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this special food bubur manado (tinutuan) ala anak kos recipe. Thanks so much for reading. I'm sure that you can make this at home. There is gonna be interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
