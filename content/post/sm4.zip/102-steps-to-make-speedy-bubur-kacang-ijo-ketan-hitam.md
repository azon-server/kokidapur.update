---
description: "Steps to Make Speedy Bubur Kacang Ijo Ketan Hitam"
title: "Steps to Make Speedy Bubur Kacang Ijo Ketan Hitam"
slug: 102-steps-to-make-speedy-bubur-kacang-ijo-ketan-hitam

<p>
	<strong>Bubur Kacang Ijo Ketan Hitam</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/b66c5e8e2c4d2f0d/680x482cq70/bubur-kacang-ijo-ketan-hitam-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Ketan Hitam" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you're having an amazing day today. Today, we're going to make a special dish, bubur kacang ijo ketan hitam. It is one of my favorites. For mine, I will make it a bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo Ketan Hitam is one of the most well liked of recent trending meals in the world. It's easy, it's quick, it tastes yummy. It is enjoyed by millions daily. They're nice and they look wonderful. Bubur Kacang Ijo Ketan Hitam is something which I have loved my entire life.
</p>

<p>
To begin with this particular recipe, we have to prepare a few ingredients. You can cook bubur kacang ijo ketan hitam using 8 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Ketan Hitam:</h3>

<ol>
	
		<li>{Get 1 Cup of gelas kecil Kacang Ijo. </li>
	
		<li>{Prepare 1 Cup of gelas kecil Ketan Hitam. </li>
	
		<li>{Prepare 1 Ruas Jari of Kayu Manis. </li>
	
		<li>{Take 1 Ruas Jari of Jahe. </li>
	
		<li>{Get Sesuai selera of Gula Merah. </li>
	
		<li>{Take 200 ml of Santan Kental. </li>
	
		<li>{Prepare 3 lembar of daun pandan. </li>
	
		<li>{Take sedikit of Garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo Ketan Hitam:</h3>

<ol>
	
		<li>
			Rendam Ketan Hitam selama +/- 1,5 Jam s.d 2 Jam.
			
			
		</li>
	
		<li>
			Masak air sampai mendidih, jika sdh mendidih masukkan 2 lmbr daun panda, ketan hitam yg sudah direndam tadi, disusul dengan kacang ijo, Kayu manis, Jahe, masak selama 10 menit dgn api besar dan panci tertutup. setelah 10 menit matikan api &amp; rebusan aduk kacang &amp; ketannya lalu tutup lagi pancinya dan tunggu selama 30 menit. jika sdh masukkan Gula merah sesuai dengan manis yg diinginkan..
			
			
		</li>
	
		<li>
			Setelah itu aduk lagi dan masak selama 7 menit dengan panci masih dalam keadaan tertutup. habis itu matikan apinya dan aduk lagi lalu diamkan sampai dingin dan bubur siap disantap..
			
			
		</li>
	
		<li>
			Panaskan Santan, Daun Pandan dan beri sedikit garam..
			
			
		</li>
	
		<li>
			Sajikan Bubur Kacang Ijo Ketan Hitam bersama dengan Santan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this special food bubur kacang ijo ketan hitam recipe. Thanks so much for reading. I am confident you can make this at home. There's gonna be interesting food at home recipes coming up. Remember to bookmark this page on your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
