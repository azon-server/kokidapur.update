---
description: "Steps to Make Quick Bubur Kacang Ijo"
title: "Steps to Make Quick Bubur Kacang Ijo"
slug: 159-steps-to-make-quick-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/ad5b34c1b2b440c4/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you are having an amazing day today. Today, I'm gonna show you how to prepare a distinctive dish, bubur kacang ijo. It is one of my favorites. For mine, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo is one of the most well liked of recent trending meals in the world. It's appreciated by millions daily. It is easy, it's quick, it tastes delicious. Bubur Kacang Ijo is something that I've loved my whole life. They're fine and they look fantastic.
</p>

<p>
To begin with this particular recipe, we must first prepare a few ingredients. You can have bubur kacang ijo using 7 ingredients and 6 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Take 250 gr of kacang hijau. </li>
	
		<li>{Take 250 gr of gula merah (sesuai selera). </li>
	
		<li>{Get 2 helai of daun pandan. </li>
	
		<li>{Take 2-3 cm of jahe (geprek). </li>
	
		<li>{Make ready sejumput of garam. </li>
	
		<li>{Make ready 1 bks of santan kara. </li>
	
		<li>{Make ready secukupnya of Air. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Bersihkan kacang hijau (kadang suka ada kerikil atau bekas kulitnya) lalu cuci bersih dan rendam selama 5-6 jam.
			
			
		</li>
	
		<li>
			Buang air rendaman lalu masukkan kacang hijau kedalam panci dan diisi air secukupnya jgn lupa tambahkan daun pandan yg sdh disimpulkan, masak sampai kacang hijau merekah.
			
			
		</li>
	
		<li>
			Sambil menunggu kacang hijau matang, kita cairkan gula merah dgn air secukupnya jgn lupa tambahkan daun pandan lagi biar harum dan jahe yg sdh digeprek, masak dgn api kecil sampai gula mencair.
			
			
		</li>
	
		<li>
			Kembali ke kacang hijau : bila kacang hijau sdh matang dan merekah baru kita masukkan gula merah yg sdh cair (jgn lupa disaring biar kotoran dari Gula merah tdk ikut) jgn lupa tes rasa manisnya sdh pas atau blm, kl kemanisan tinggal kita tambah air panas secukupnya atau kl kurang manis bisa ditambah gula pasir atau kental manis putih jg bisa (sesuai selera)..
			
			
		</li>
	
		<li>
			Bila sdh pas, baru masukkan santan kara dan sejumput garam biar ada rasa gurih sambil diaduk rata, tes rasa lagi bila perlu, bila sdh ok baru matikan api kompor.
			
			
		</li>
	
		<li>
			Sajikan bubur kacang ijo utk keluarga tercinta.... nyummm, bisa jg dinikmati dgn roti tawar (tp aku lupa beli 😬).
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this exceptional food bubur kacang ijo recipe. Thank you very much for your time. I am sure you can make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
