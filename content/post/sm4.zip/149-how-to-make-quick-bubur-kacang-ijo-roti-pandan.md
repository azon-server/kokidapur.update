---
description: "How to Make Quick Bubur kacang ijo roti pandan"
title: "How to Make Quick Bubur kacang ijo roti pandan"
slug: 149-how-to-make-quick-bubur-kacang-ijo-roti-pandan

<p>
	<strong>Bubur kacang ijo roti pandan</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/580673a14d9200cf/680x482cq70/bubur-kacang-ijo-roti-pandan-foto-resep-utama.jpg" alt="Bubur kacang ijo roti pandan" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's John, welcome to our recipe site. Today, I'm gonna show you how to prepare a distinctive dish, bubur kacang ijo roti pandan. One of my favorites food recipes. This time, I will make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang ijo roti pandan is one of the most popular of recent trending meals on earth. It's enjoyed by millions daily. It's easy, it is fast, it tastes yummy. They are nice and they look wonderful. Bubur kacang ijo roti pandan is something that I've loved my entire life.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we must first prepare a few components. You can have bubur kacang ijo roti pandan using 8 ingredients and 4 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo roti pandan:</h3>

<ol>
	
		<li>{Take 1/4 of kacang hijau rendam semalaman atau minimal 6 jam. </li>
	
		<li>{Prepare 2 butir of gula merah. </li>
	
		<li>{Make ready 1 of kayu manis. </li>
	
		<li>{Prepare 1 of santan kara 660ml. </li>
	
		<li>{Get Secukupnya of air matang. </li>
	
		<li>{Prepare Sejumput of garam. </li>
	
		<li>{Make ready Secukupnya of jahe. </li>
	
		<li>{Take secukupnya of Roti pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo roti pandan:</h3>

<ol>
	
		<li>
			Basuh kacang hijau, rendam semalaman. cuci juga jahe dan kayu manis, sisihkan..
			
			
		</li>
	
		<li>
			Siapkan air mendidih, masukkan kacang hijau. Sampe pecah2 kacangnya atau sesuai selera keempukan kacang hijaunya..
			
			
		</li>
	
		<li>
			Iris gula merah mauskkan kedalam rebusan kacang hijau. Aduk rata masukkan kayu manis dan jahe. Koreksi rasa.
			
			
		</li>
	
		<li>
			Setelah kematangan oke rasa oke masukan santan kental kedalam rebusan. Tunggu sampai mendidih. Bubur kacang hijau siap santap bersama roti pandan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this special food bubur kacang ijo roti pandan recipe. Thank you very much for reading. I am sure that you can make this at home. There's gonna be interesting food at home recipes coming up. Remember to save this page in your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
