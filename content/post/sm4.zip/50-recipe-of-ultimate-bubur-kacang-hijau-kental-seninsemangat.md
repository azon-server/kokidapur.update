---
description: "Recipe of Ultimate Bubur Kacang Hijau Kental #seninsemangat"
title: "Recipe of Ultimate Bubur Kacang Hijau Kental #seninsemangat"
slug: 50-recipe-of-ultimate-bubur-kacang-hijau-kental-seninsemangat

<p>
	<strong>Bubur Kacang Hijau Kental #seninsemangat</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/543e82c9c56a169b/680x482cq70/bubur-kacang-hijau-kental-seninsemangat-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental #seninsemangat" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an amazing day today. Today, we're going to make a distinctive dish, bubur kacang hijau kental #seninsemangat. One of my favorites. For mine, I will make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Hijau Kental #seninsemangat is one of the most well liked of current trending foods in the world. It is simple, it's quick, it tastes yummy. It's appreciated by millions daily. Bubur Kacang Hijau Kental #seninsemangat is something that I have loved my entire life. They are fine and they look fantastic.
</p>

<p>
To begin with this particular recipe, we have to prepare a few ingredients. You can cook bubur kacang hijau kental #seninsemangat using 9 ingredients and 10 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental #seninsemangat:</h3>

<ol>
	
		<li>{Prepare 300 gr of kacang hijau. </li>
	
		<li>{Get 1/2 butir of kelapa parut. </li>
	
		<li>{Prepare 3 keping of gula merah. </li>
	
		<li>{Prepare 1 sendok sayur of gula pasir. </li>
	
		<li>{Make ready Sejumput of garam. </li>
	
		<li>{Prepare 2 lbr of daun pandan. </li>
	
		<li>{Prepare 1 ruas of jahe. </li>
	
		<li>{Make ready 1 of sd 2 L air. </li>
	
		<li>{Prepare 2 sdm of maizena + 2 sdm air. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Hijau Kental #seninsemangat:</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau, lalu rendam dgn air semalaman, ini dilakukan agar kacang hijau lebih empuk.
			
			
		</li>
	
		<li>
			Tambahkan 200 ml air ke kelapa parut, peras2 airnya, Sisihkan 200 ml utk santan kental.
			
			
		</li>
	
		<li>
			Beri lagi air ke kelapa parut peras2 santan encer utk merebus kacang hijau, santan encer yg dibutuhkan -+ 1,5 L sampai kacang hijau terendam.
			
			
		</li>
	
		<li>
			Jerang di atas kompor kacang hijau, santan encer, daun pandan &amp; jahe, garam, masak sampai kacang hijau empuk.
			
			
		</li>
	
		<li>
			Setelah benar2 empuk, masukkan gula merah &amp; gula pasir, aduk2, lalu tambahkan santan kental aduk2, koreksi rasa, biarkan mendidih sambil terus diaduk.
			
			
		</li>
	
		<li>
			Setelah mendidih, masukkan larutan maizenna, aduk, masak sampai meletup letup.
			
			
		</li>
	
		<li>
			Matikan api, bubur kacang hijau kuah kental siap dinikmati 😍.
			
			
		</li>
	
		<li>
			Saya lebih suka memakai santan asli karena menurut Saya lebih gurih 😍.
			
			
		</li>
	
		<li>
			.
			
			
		</li>
	
		<li>
			.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this exceptional food bubur kacang hijau kental #seninsemangat recipe. Thanks so much for your time. I'm sure that you will make this at home. There's gonna be interesting food at home recipes coming up. Remember to bookmark this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
