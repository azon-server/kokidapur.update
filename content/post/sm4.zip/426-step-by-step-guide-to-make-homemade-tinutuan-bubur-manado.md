---
description: "Step-by-Step Guide to Make Homemade TINUTUAN (BUBUR MANADO)"
title: "Step-by-Step Guide to Make Homemade TINUTUAN (BUBUR MANADO)"
slug: 426-step-by-step-guide-to-make-homemade-tinutuan-bubur-manado

<p>
	<strong>TINUTUAN (BUBUR MANADO)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/7ca8896f90c7962e/680x482cq70/tinutuan-bubur-manado-foto-resep-utama.jpg" alt="TINUTUAN (BUBUR MANADO)" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is John, welcome to my recipe site. Today, I will show you a way to prepare a special dish, tinutuan (bubur manado). One of my favorites. For mine, I am going to make it a bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	TINUTUAN (BUBUR MANADO) is one of the most well liked of current trending meals on earth. It's enjoyed by millions every day. It's easy, it's quick, it tastes yummy. They're fine and they look fantastic. TINUTUAN (BUBUR MANADO) is something that I've loved my entire life.
</p>

<p>
To get started with this particular recipe, we must first prepare a few ingredients. You can cook tinutuan (bubur manado) using 24 ingredients and 3 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make TINUTUAN (BUBUR MANADO):</h3>

<ol>
	
		<li>{Take  of Bahan bubur:. </li>
	
		<li>{Make ready 4 ruas of Labu kuning. </li>
	
		<li>{Prepare 1 of singkong. </li>
	
		<li>{Prepare 1 of ubi kuning. </li>
	
		<li>{Take 1 of jagung. </li>
	
		<li>{Get 1 genggam of beras. </li>
	
		<li>{Prepare  of Air. </li>
	
		<li>{Make ready  of Bawang merah 4 siung(iris). </li>
	
		<li>{Make ready 1 of daun kunyit. </li>
	
		<li>{Take 1 of sereh. </li>
	
		<li>{Take  of garam. </li>
	
		<li>{Get  of penyedap/kaldu jamur. </li>
	
		<li>{Make ready  of Bahan sayur:. </li>
	
		<li>{Take 1 ikat of Kangkung. </li>
	
		<li>{Take 1 ikat of bayam hijau. </li>
	
		<li>{Get  of Daun gedi (kalau ada). </li>
	
		<li>{Take  of Daun kemangi. </li>
	
		<li>{Take  of Daun bawang. </li>
	
		<li>{Get  of Bahan sambal Roa:. </li>
	
		<li>{Prepare  of ikan roa asap halus. </li>
	
		<li>{Make ready  of cabe. </li>
	
		<li>{Take  of bawang merah. </li>
	
		<li>{Get  of tomat (buang bijinya). </li>
	
		<li>{Make ready  of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make TINUTUAN (BUBUR MANADO):</h3>

<ol>
	
		<li>
			Bubur: Rebus air dalam panci, setelah mendidih masukkan beras, labu kuning yg sdh dipotong2, singkong yg sdh dipotong, ubi yg sdh dipotong, jagung yg sdh sipipil, setelah mulai menjadi bubur masukkan bawang merah, sereh, daun kunyit,garam, dan kaldu masak, masak sampai menjadi bubur(warna kuning bubur berasal dr labu tadi) matikan api.
			
			
		</li>
	
		<li>
			Siapkan wajan, cacah bawang putih 3 siung, tumis dengan minyak 2 sendok makan sampai bawang putih harum. tambahkan sedikit air. masukkan bahan sayur dan bubur yg tadi telah dibuat, aduk2 sampai meletup letup. kalau terlalu kental bisa tambahkan air mengikuti selera. berikan garam dan kaldu bubuk jika rasa sdh pas. matikan api, siap dihidangkan bersama sambal roa, dan ikan nike goreng atau ikan asin..
			
			
		</li>
	
		<li>
			Sambal roa: roa halus. jika blm halus tumbuk roa, haluskan cabe, bawang merah, setelah halus tumis semua bahan tambahkan tomat, garam, gula sedikit, koreksi rasa. siap dihidangkan bersama bubur manado..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this special food tinutuan (bubur manado) recipe. Thank you very much for reading. I am confident you can make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
