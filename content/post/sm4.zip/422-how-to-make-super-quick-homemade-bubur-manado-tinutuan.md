---
description: "How to Make Super Quick Homemade Bubur Manado/Tinutuan"
title: "How to Make Super Quick Homemade Bubur Manado/Tinutuan"
slug: 422-how-to-make-super-quick-homemade-bubur-manado-tinutuan

<p>
	<strong>Bubur Manado/Tinutuan</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/035cac74449adaf4/680x482cq70/bubur-manadotinutuan-foto-resep-utama.jpg" alt="Bubur Manado/Tinutuan" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's Jim, welcome to my recipe site. Today, we're going to prepare a special dish, bubur manado/tinutuan. One of my favorites. This time, I'm gonna make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Manado/Tinutuan is one of the most well liked of recent trending meals on earth. It is enjoyed by millions daily. It's simple, it's fast, it tastes delicious. Bubur Manado/Tinutuan is something which I have loved my whole life. They're fine and they look wonderful.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we must prepare a few components. You can have bubur manado/tinutuan using 12 ingredients and 3 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Manado/Tinutuan:</h3>

<ol>
	
		<li>{Get 1 piring of nasi. </li>
	
		<li>{Prepare 1 ikat of kangkung. </li>
	
		<li>{Prepare 1 buah of ubi. </li>
	
		<li>{Make ready 1 ikat of kemangi (aku skip). </li>
	
		<li>{Make ready 2 lbr of daun salam. </li>
	
		<li>{Prepare 1 btg of sereh. </li>
	
		<li>{Take 1 of jagung, pipil (aku pakai 3 sdm jagung rebus frozen). </li>
	
		<li>{Take secukupnya of Kaldu bubuk &amp; merica. </li>
	
		<li>{Take  of Air secukupnya (sekira2nya utk membuat bubur). </li>
	
		<li>{Prepare  of Bahan pelengkap :. </li>
	
		<li>{Take  of Ikan asin (jenisnya sesuai selera). </li>
	
		<li>{Get  of Sambal. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado/Tinutuan:</h3>

<ol>
	
		<li>
			Geprek sereh. Rebus air beserta salam dan sereh sampai mendidih. Cuci bersih bahan2, siangi/petiki kangkung, kupas &amp; potong dadu ubi..
			
			
		</li>
	
		<li>
			Masukkan nasi, masak sampai jadi bubur. Ketika hampir jadi bubur masukkan jagung dan ubi. Kalo gak punya ubi bisa ganti wortel. Aduk2 hingga ubi dan jagung empuk/matang. Tambahkan kangkung dan kaldu bubuk..
			
			
		</li>
	
		<li>
			Sajikan dengan ikan asin dan sambal.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur manado/tinutuan recipe. Thanks so much for your time. I'm confident that you will make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
