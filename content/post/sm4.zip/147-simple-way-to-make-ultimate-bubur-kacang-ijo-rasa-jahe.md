---
description: "Simple Way to Make Ultimate Bubur Kacang Ijo Rasa Jahe"
title: "Simple Way to Make Ultimate Bubur Kacang Ijo Rasa Jahe"
slug: 147-simple-way-to-make-ultimate-bubur-kacang-ijo-rasa-jahe

<p>
	<strong>Bubur Kacang Ijo Rasa Jahe</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/c31cfe098937ed01/680x482cq70/bubur-kacang-ijo-rasa-jahe-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Rasa Jahe" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an amazing day today. Today, I will show you a way to prepare a distinctive dish, bubur kacang ijo rasa jahe. It is one of my favorites food recipes. For mine, I am going to make it a bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo Rasa Jahe is one of the most popular of current trending foods in the world. It is appreciated by millions every day. It's easy, it's fast, it tastes yummy. Bubur Kacang Ijo Rasa Jahe is something which I've loved my whole life. They're nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we must prepare a few ingredients. You can have bubur kacang ijo rasa jahe using 14 ingredients and 5 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Rasa Jahe:</h3>

<ol>
	
		<li>{Get 150 gram of kacang hijau. </li>
	
		<li>{Prepare 1,5 L of air. </li>
	
		<li>{Make ready 2 lembar of daun pandan. </li>
	
		<li>{Get 150 gram of gula aren/ gula merah. </li>
	
		<li>{Take 3 sdm of gula pasir. </li>
	
		<li>{Make ready 1/2 sdt of garam. </li>
	
		<li>{Prepare 1 buah of jahe, geprek (lbh baik dibakar dulu). </li>
	
		<li>{Make ready 2 sdm of tepung tapioka. </li>
	
		<li>{Get 30 ml of air. </li>
	
		<li>{Get  of bahan santan :. </li>
	
		<li>{Prepare 65 ml of santan kental. </li>
	
		<li>{Get 100 ml of air. </li>
	
		<li>{Prepare 1/4 sdt of garam. </li>
	
		<li>{Get 1 lmbr of daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo Rasa Jahe:</h3>

<ol>
	
		<li>
			Cuci kacang hijau hingga bersih, rendam dengan air panas selama 3 jam. (hingga mengembang)..
			
			
		</li>
	
		<li>
			Rebus air hingga mendidih, tambahkan daun pandan, masukkan kacang hijau (airnya tidak dimasukin). masak hingga kacang hijau pecah..
			
			
		</li>
	
		<li>
			Masukkan jahe geprek, aduk rata. tambahkan dengan gula aren dan gula pasir juga garam. aduk hingga rata dan gula larut..
			
			
		</li>
	
		<li>
			Larutkan tapioka dengan air, aduk rata. tuang dalam bubur, masak hingga bubur mengental. (kalau tidak suka bubur yang kental, larutan ini bisa diskip)..
			
			
		</li>
	
		<li>
			Campur santan dan air, garam serta pandan. masak hingga santan mendidih. selama masak terus diaduk. (pandan sy skip) hidangkan bubur dengan santan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur kacang ijo rasa jahe recipe. Thank you very much for your time. I am confident that you will make this at home. There is gonna be more interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
