---
description: "Steps to Prepare Homemade Bubur Manado Buah Naga"
title: "Steps to Prepare Homemade Bubur Manado Buah Naga"
slug: 280-steps-to-prepare-homemade-bubur-manado-buah-naga

<p>
	<strong>Bubur Manado Buah Naga</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/12cce0f842c16ebd/680x482cq70/bubur-manado-buah-naga-foto-resep-utama.jpg" alt="Bubur Manado Buah Naga" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you're having an amazing day today. Today, I'm gonna show you how to prepare a distinctive dish, bubur manado buah naga. One of my favorites. This time, I will make it a bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur Manado Buah Naga is one of the most favored of recent trending meals on earth. It is easy, it's quick, it tastes delicious. It is appreciated by millions daily. Bubur Manado Buah Naga is something that I have loved my whole life. They're nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to first prepare a few components. You can cook bubur manado buah naga using 13 ingredients and 4 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Manado Buah Naga:</h3>

<ol>
	
		<li>{Make ready 1/2 ltr of beras, cuci bersih. </li>
	
		<li>{Prepare Secukupnya of garam. </li>
	
		<li>{Get Secukupnya of kaldu jamur/penyedap. </li>
	
		<li>{Make ready 2 btg of sereh ukuran besar, geprek bagian putihnya, buat simpul. </li>
	
		<li>{Make ready Secukupnya of air masak untuk membuat bubur. </li>
	
		<li>{Take Secukupnya of kangkung, potong2,rendam air garam 10mnt, cuci bersi. </li>
	
		<li>{Prepare Seikat of kecil kemangi, petiki daunnya, cuci bersih. </li>
	
		<li>{Take 1 bh of jagung besar, sisir bijinya dengan pisau. </li>
	
		<li>{Get 2 ruas of labu kuning, kupas kulitnya, potong kotak2. </li>
	
		<li>{Prepare 1/2 buah of naga ungu, haluskan. </li>
	
		<li>{Take  of Bahan pelengkap :. </li>
	
		<li>{Make ready Secukupnya of ikan asin goreng. </li>
	
		<li>{Get  of Sambal terasi matang. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado Buah Naga:</h3>

<ol>
	
		<li>
			Masak beras dengan air yang cukup banyak sampai beras berubah menjadi bubur. Kemudian masukkan garam, kaldu jamur &amp; sereh. Cek rasa sampai pas..
			
			
		</li>
	
		<li>
			Masukkan labu kuning &amp; jagung. Masak sampai matang sambil terus diaduk. Jangan sampai ada kerak di dasar panci..
			
			
		</li>
	
		<li>
			Menjelang matang, masukkan kangkung, dan buah naga yang dihaluskan. Aduk sebentar saja. Terakhir masukkan daun kemangi. Aduk rata. Matikan api..
			
			
		</li>
	
		<li>
			Sajikan bubur manado dengan ikan asin &amp; sambal terasi. Yummy😘.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food bubur manado buah naga recipe. Thank you very much for your time. I'm sure that you can make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
