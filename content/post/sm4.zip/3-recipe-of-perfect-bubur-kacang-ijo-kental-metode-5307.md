---
description: "Recipe of Perfect Bubur Kacang Ijo Kental (Metode 5.30.7)"
title: "Recipe of Perfect Bubur Kacang Ijo Kental (Metode 5.30.7)"
slug: 3-recipe-of-perfect-bubur-kacang-ijo-kental-metode-5307

<p>
	<strong>Bubur Kacang Ijo Kental (Metode 5.30.7)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/2ca3e8f3da3d392e/680x482cq70/bubur-kacang-ijo-kental-metode-5307-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Kental (Metode 5.30.7)" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, we're going to make a special dish, bubur kacang ijo kental (metode 5.30.7). It is one of my favorites food recipes. This time, I'm gonna make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo Kental (Metode 5.30.7) is one of the most popular of recent trending foods in the world. It is appreciated by millions every day. It's easy, it's fast, it tastes delicious. They are nice and they look fantastic. Bubur Kacang Ijo Kental (Metode 5.30.7) is something which I've loved my entire life.
</p>

<p>
To get started with this particular recipe, we have to first prepare a few ingredients. You can cook bubur kacang ijo kental (metode 5.30.7) using 11 ingredients and 4 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Kental (Metode 5.30.7):</h3>

<ol>
	
		<li>{Take 250 gram of Kacang hijau. </li>
	
		<li>{Prepare 1000 ml of air utk merebus (sy 1500 ml air). </li>
	
		<li>{Prepare 175 gram of gula merah (sy 2 balok kecil gula merah). </li>
	
		<li>{Get 50 gram of gula pasir. </li>
	
		<li>{Make ready 2 lembar of daun pandan. </li>
	
		<li>{Make ready 5 cm of jahe, geprek (sy skip). </li>
	
		<li>{Get 4 sdm of Tepung tapioka + 200 ml air. </li>
	
		<li>{Take  of Kuah Santan. </li>
	
		<li>{Take 65 ml of santan cair instan + 200 ml air. </li>
	
		<li>{Take 2 lembar of Daun pandan. </li>
	
		<li>{Take 1 sdt of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo Kental (Metode 5.30.7):</h3>

<ol>
	
		<li>
			Didihkan air, masukkan kacang hijau dan gula pasir, rebus selama 5 menit. Matikan api, biarkan panci keadaan tertutup dan diamkan selama 30 menit. Nyalakan api kembali, rebus selama 7 menit...
			
			
		</li>
	
		<li>
			Saat merebus 7 menit tambahkan gula merah, daun pandan, lalu masukkan tepung tapioka yg sudah di larutkan dg air. Aduk2 smp larutan tepung tapioka tercampur rata. Didihkan lalu Matikan api...
			
			
		</li>
	
		<li>
			Membuat Kuah Santan: Rebus semua bahan kuah santan, Aduk2 terus spy santan tdk pecah. jika sudah mendidih matikan api..
			
			
		</li>
	
		<li>
			Sajikan bubur kacang hijau kental dg kuah santan.. cocok dinikmati saat hangat2 🥰.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur kacang ijo kental (metode 5.30.7) recipe. Thanks so much for your time. I'm confident you can make this at home. There's gonna be more interesting food at home recipes coming up. Remember to save this page in your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
