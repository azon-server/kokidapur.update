---
description: "Steps to Make Any-night-of-the-week Bubur kacang ijo"
title: "Steps to Make Any-night-of-the-week Bubur kacang ijo"
slug: 158-steps-to-make-any-night-of-the-week-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/4ff7f4fbe1e98512/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you're having an amazing day today. Today, we're going to make a special dish, bubur kacang ijo. One of my favorites food recipes. This time, I am going to make it a little bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo is one of the most popular of recent trending foods on earth. It's appreciated by millions daily. It's simple, it's fast, it tastes yummy. They're nice and they look fantastic. Bubur kacang ijo is something that I've loved my entire life.
</p>

<p>
To get started with this recipe, we must prepare a few components. You can have bubur kacang ijo using 8 ingredients and 3 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Make ready 1/4 gr of kacang ijo. </li>
	
		<li>{Prepare 1 balok of gula merah (sesuai selera). </li>
	
		<li>{Make ready 1 lembar of daun pandan. </li>
	
		<li>{Prepare 400 ml of santan kental. </li>
	
		<li>{Take 500 ml of air. </li>
	
		<li>{Make ready 1/2 sdt of garam halus. </li>
	
		<li>{Prepare 3 sdm of gula pasir. </li>
	
		<li>{Get 1 ruas of jahe merah. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Rebus kacang ijo yang sudah direndam semalaman (bisa juga tidak direndam tapi lama merebusnya).
			
			
		</li>
	
		<li>
			Rebus hingga mengelupas dan lembut, air pun mengering masukan gula merah santan garam dan daun pandan.
			
			
		</li>
	
		<li>
			Geprek jahe.. dan masukan didihkan dan siap disajikan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur kacang ijo recipe. Thank you very much for your time. I'm sure you can make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
