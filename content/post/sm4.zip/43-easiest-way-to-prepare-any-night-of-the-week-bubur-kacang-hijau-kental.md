---
description: "Easiest Way to Prepare Any-night-of-the-week Bubur Kacang Hijau Kental"
title: "Easiest Way to Prepare Any-night-of-the-week Bubur Kacang Hijau Kental"
slug: 43-easiest-way-to-prepare-any-night-of-the-week-bubur-kacang-hijau-kental

<p>
	<strong>Bubur Kacang Hijau Kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/c5e8e10222606a11/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an incredible day today. Today, I'm gonna show you how to make a special dish, bubur kacang hijau kental. One of my favorites food recipes. This time, I'm gonna make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Hijau Kental is one of the most well liked of recent trending foods on earth. It's appreciated by millions daily. It is easy, it's quick, it tastes yummy. Bubur Kacang Hijau Kental is something that I've loved my whole life. They are fine and they look wonderful.
</p>

<p>
To get started with this recipe, we must first prepare a few components. You can cook bubur kacang hijau kental using 9 ingredients and 8 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>{Make ready 150 gr of kacang hijau. </li>
	
		<li>{Get 2 mangkuk of Air. </li>
	
		<li>{Make ready 1,5 keping of gula merah/aren. </li>
	
		<li>{Prepare 1 sdm of gula pasir. </li>
	
		<li>{Get 1 sdt of garam. </li>
	
		<li>{Make ready 1 sdm of tepung maizena. </li>
	
		<li>{Prepare 1 bungkus of santan instan. </li>
	
		<li>{Get 1 ruas jari of jahe. </li>
	
		<li>{Get Secukupnya of susu kental manis. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>
			Cuci kacang hijau dalam air mengalir, sambil panaskan air di panci hingga mendidih. Jika sudah, tiriskan kacang hijau dan rendam dengan air panas selama minimal 3 jam..
			
			
		</li>
	
		<li>
			Nyalakan panci, masukkan kacang dan airnya. Masukkan pula jahe yang sudah digeprek.
			
			
		</li>
	
		<li>
			Lalu masukkan gula merah yang telah diiris tipis.
			
			
		</li>
	
		<li>
			Tambahkan gula pasir dan garam.
			
			
		</li>
	
		<li>
			Masukkan pula santan dan susu kental manis secukupnya (saya sukanya manis jambu).
			
			
		</li>
	
		<li>
			Aduk-aduk, lalu terakhir tambahkan tepung maizena.
			
			
		</li>
	
		<li>
			Masak dengan api sedang sambil ditutup selama 45 menit.
			
			
		</li>
	
		<li>
			Sesekali sambil diaduk, setelah itu kecilkan api sampai kacang ijo pecah sesuai selera. (Misalnya mau lembek banget, jadi agak lamaan masaknya). Jika sudah, tinggal disajikan dengan tambahan roti 😊 selesaaai 💃.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this special food bubur kacang hijau kental recipe. Thanks so much for your time. I am confident that you can make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
