---
description: "Recipe of Super Quick Homemade Bubur Kacang Hijau Kental"
title: "Recipe of Super Quick Homemade Bubur Kacang Hijau Kental"
slug: 46-recipe-of-super-quick-homemade-bubur-kacang-hijau-kental

<p>
	<strong>Bubur Kacang Hijau Kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/fea1bb7bcd1d13ee/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you are having an incredible day today. Today, I will show you a way to prepare a special dish, bubur kacang hijau kental. One of my favorites. For mine, I am going to make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Hijau Kental is one of the most favored of recent trending foods in the world. It is simple, it's fast, it tastes delicious. It is enjoyed by millions daily. Bubur Kacang Hijau Kental is something that I've loved my whole life. They're nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to prepare a few components. You can cook bubur kacang hijau kental using 7 ingredients and 4 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>{Take 1 of gelas kacang ijo. </li>
	
		<li>{Make ready 3 gelas of air. </li>
	
		<li>{Make ready 100 gr of gula merah. </li>
	
		<li>{Take 1/2 sdt of garam. </li>
	
		<li>{Prepare 2 sdm of gula pasir. </li>
	
		<li>{Prepare 3 sdm of tepung beras. </li>
	
		<li>{Prepare 300 ml of santan kental yg sudah matang. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>
			Rendam kacang hijau semalaman, cuci bersih kemudian rebus dengan air hingga empuk..
			
			
		</li>
	
		<li>
			Masak gula merah+gula pasir+garam dengan 1/2 gelas air hingga larut kemudian saring..
			
			
		</li>
	
		<li>
			Masukkan gula merah ke dalam kacang hijau yang sudah empuk. Masak hingga mendidih..
			
			
		</li>
	
		<li>
			Terakhir masukkan tepung beras dengan sedikit air. Aduk2 hingga meletup2 dan kental..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this special food bubur kacang hijau kental recipe. Thank you very much for your time. I am sure you will make this at home. There is gonna be more interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
