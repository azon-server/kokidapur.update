---
description: "Step-by-Step Guide to Prepare Homemade Bubur Kacang Ijo"
title: "Step-by-Step Guide to Prepare Homemade Bubur Kacang Ijo"
slug: 156-step-by-step-guide-to-prepare-homemade-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/3a9b3dc6494ca86b/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
		Resep bubur kacang ijo itu sendiri ada berbagai macam dengan tambahan bahan yang melengkapinya.
	
		Cara bikin bubur kacang hijau / ijo memerlukan trik dan tips tersendiri, sehingga hasilnya bisa lebih bagus dan juga enak serta lembut.
	
		Sebenarnya tidak ada yang istimewa saat anda membuat.
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, I'm gonna show you how to make a special dish, bubur kacang ijo. One of my favorites food recipes. This time, I will make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo is one of the most well liked of recent trending meals in the world. It is enjoyed by millions daily. It is easy, it is quick, it tastes delicious. Bubur Kacang Ijo is something that I have loved my entire life. They are fine and they look wonderful.
</p>
<p>
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>

<p>
To get started with this particular recipe, we have to prepare a few ingredients. You can cook bubur kacang ijo using 8 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Prepare 200 gram of Kacang ijo. </li>
	
		<li>{Take 600 ml of Santan kental (dari 1 buah kelapa. </li>
	
		<li>{Get 3 ruas of Jahe (geprek). </li>
	
		<li>{Make ready 1 sdt of Garam. </li>
	
		<li>{Make ready 2 ruas of Air (dari atas kacang ijo). </li>
	
		<li>{Get  of Air gula :. </li>
	
		<li>{Prepare 250 gram of Gula merah. </li>
	
		<li>{Take 300 ml of Air. </li>
	
</ol>
<p>
	
		Bubur kacang hejo (su) Bubur kacang ijo (jv) Burjo.
	
		Slightly different names may be used in different regions of Indonesia, such as kacang ijo in Javanese areas.
	
		Cara masak bubur kacang ijo super simple dan enak.
	
		Rahasia Peyek Kacang Ijo Renyah, Tidak Keras dan Tahan Lama Bu Yun kali inia akan membagikan resep, tips dan tutorial cara.
	
</p>

<h3>Instructions to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Cuci bersih kacang ijo. Rendam dalam air selama 1 jam. Tiriskan..
			
			
		</li>
	
		<li>
			Larutkan gula merah pada air..
			
			
		</li>
	
		<li>
			Rebus kacang ijo dan jahe sampai kacang ijo hampir matang..
			
			
		</li>
	
		<li>
			Tambahkan garam. Aduk rata..
			
			
		</li>
	
		<li>
			Masukkan santan, aduk rata. Koreksi rasa..
			
			
		</li>
	
</ol>

<p>
	
		Cara Membuat Bubur Kacang Hijau Sederhana Yang Enak amp Kental Ala Dapur Dina.
	
		Ingin mencoba memasak Bubur Kacang Hijau sendiri, Burjo Pisang (Tips spy kacang ijo cepat empuk dan lembut), Bubur kacang ijo ketan item durian enakk, Burjo Nangka dan lain-lain yang lezat untuk.
	
		Sajikan bubur kacang hijau beserta rebusan santan saat akan di konsumsi untuk menghindari kacang hijau cepat basi Resep membuat bubur kacang hijau.
	
		Resep Bubur Kacang Ijo Enak Dan Cepat Mekar Atau Empuk.
	
		Kacang hijau / ijo merupakan salah satu bahan makanan yang bukan saja enak di buat minuman maupun makanan.
	
</p>

<p>
	So that is going to wrap this up for this exceptional food bubur kacang ijo recipe. Thank you very much for your time. I am sure that you can make this at home. There is gonna be more interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
