---
description: "How to Prepare Favorite Bubur Kacang Hijau Kental"
title: "How to Prepare Favorite Bubur Kacang Hijau Kental"
slug: 34-how-to-prepare-favorite-bubur-kacang-hijau-kental

<p>
	<strong>Bubur Kacang Hijau Kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/1ab0780058942805/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's Louise, welcome to my recipe site. Today, we're going to prepare a special dish, bubur kacang hijau kental. One of my favorites food recipes. For mine, I am going to make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Hijau Kental is one of the most popular of recent trending meals on earth. It's appreciated by millions daily. It is simple, it's fast, it tastes delicious. They're nice and they look fantastic. Bubur Kacang Hijau Kental is something which I have loved my entire life.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we must first prepare a few ingredients. You can have bubur kacang hijau kental using 10 ingredients and 6 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>{Prepare 150 gram of kacang hijau. </li>
	
		<li>{Make ready 1 ruas of jahe. </li>
	
		<li>{Take 4 sdm of gula pasir. </li>
	
		<li>{Prepare 500 ml of air. </li>
	
		<li>{Take 1/2 sdt of garam. </li>
	
		<li>{Get 4 sdm of tepung tapioka. </li>
	
		<li>{Prepare 5 tetes of esense vanila. </li>
	
		<li>{Prepare  of Saos Santan. </li>
	
		<li>{Prepare 1 bh of Santan (me: Kara 65ml). </li>
	
		<li>{Prepare 130 ml of air. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau. Rendam +/- 6 jam. (Me: rendam 15 jam di dalam kulkas). Setelah masukkan panci. Masak dengan api sedang..
			
			
		</li>
	
		<li>
			Bisa pake manual / metode rebus 5 menit. Matikan kompor dan diamkan selama 30 menit dalam panci tertutup. Nyalakan lagi kompor, rebus kira-kira 7 menit. 5-30-7.
			
			
		</li>
	
		<li>
			Setelah empuk. Siapkan tepung tapioka. Tambahkan garam, vanila &amp; gula. Tes rasa..
			
			
		</li>
	
		<li>
			Setelah di rasa enak. Baru masukkan larutan tapioka. Aduk terus karena akan mengental..
			
			
		</li>
	
		<li>
			Masukkan di piring saji. Siapkan penci lain. Masak santan dengan garam..
			
			
		</li>
	
		<li>
			Setelah matang. Taruh wadah. Siapkan gelas saji dan bubur kacang hijau siap di sajikan. (Bs tambah pandan agar lebih wangi).
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur kacang hijau kental recipe. Thank you very much for reading. I'm confident you will make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
