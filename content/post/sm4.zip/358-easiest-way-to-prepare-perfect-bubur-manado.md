---
description: "Easiest Way to Prepare Perfect Bubur Manado"
title: "Easiest Way to Prepare Perfect Bubur Manado"
slug: 358-easiest-way-to-prepare-perfect-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/90c7a2ccf547170b/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an amazing day today. Today, I'm gonna show you how to prepare a distinctive dish, bubur manado. It is one of my favorites. For mine, I will make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Manado is one of the most favored of current trending foods on earth. It's easy, it's fast, it tastes yummy. It is appreciated by millions daily. They are fine and they look wonderful. Bubur Manado is something that I have loved my whole life.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to prepare a few ingredients. You can have bubur manado using 15 ingredients and 6 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Get 1 cup of beras. </li>
	
		<li>{Get 5 batang of daun sereh, digeprek. </li>
	
		<li>{Get 1 buah of jagung, disisir. </li>
	
		<li>{Take 1 buah of kentang, dipotong kotak. </li>
	
		<li>{Take 1250 ml of air. </li>
	
		<li>{Get 1/2 sdt of garam. </li>
	
		<li>{Take 1 sdt of kaldu jamur. </li>
	
		<li>{Make ready 200 g of labu kabocha, dikukus. </li>
	
		<li>{Get 3 siung of bawang putih, digeprek dan dicincang. </li>
	
		<li>{Take 1/2 sdt of merica bubuk. </li>
	
		<li>{Take Segenggam of teri nasi. </li>
	
		<li>{Make ready 1 ikat of kangkung. </li>
	
		<li>{Take 2 batang of daun bawang, diiris. </li>
	
		<li>{Prepare 1 lembar of daun kunyit, diiris. </li>
	
		<li>{Take 3 ikat of daun kemangi, disiangi. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado:</h3>

<ol>
	
		<li>
			Siapkan bahan :
1. Dimasak beras seperti biasa, aq pake ricecooker. Atau gunakan nasi sisa jg bs. Takaran sekitar 1piring agak munjung.
2. Rajang daun bawang beserta daun kunyit.
3. Bagi labu kabocha menjadi 2bagian, satu bagian dilumatkan dan yg satubagian dipotong kotak..
			
			
		</li>
	
		<li>
			Dimasak nasi, jagung manis, kentang, serai dan 1liter air sampai jadi bubur dan kentang empuk..
			
			
		</li>
	
		<li>
			Masukkan sisa air (250 ml) dan garam, diaduk rata. Lalu masukkan kangkung, daun bawang, daun kunyit dan labu kabocha, diaduk rata. Maasak smp sayuran matang..
			
			
		</li>
	
		<li>
			Ditumis bawang putih, merica bubuk dan teri dgn 1sdm minyak sampai bawang putih kuning kecoklatan. Lalu dituang dgn minyaknya ke dlm bubur, diaduk rata..
			
			
		</li>
	
		<li>
			Terakhir, dimasukkan daun kemangi. Diaduk sebentar, test rasa. Matikan api..
			
			
		</li>
	
		<li>
			Sajikan 🤤🤤🤤.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this special food bubur manado recipe. Thank you very much for reading. I'm confident that you can make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to save this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
