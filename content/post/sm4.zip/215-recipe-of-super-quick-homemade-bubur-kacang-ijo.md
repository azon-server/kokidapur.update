---
description: "Recipe of Super Quick Homemade Bubur Kacang Ijo"
title: "Recipe of Super Quick Homemade Bubur Kacang Ijo"
slug: 215-recipe-of-super-quick-homemade-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/7334a190481059a9/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you're having an incredible day today. Today, we're going to make a distinctive dish, bubur kacang ijo. One of my favorites. This time, I am going to make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo is one of the most popular of recent trending foods on earth. It's enjoyed by millions every day. It's simple, it is fast, it tastes delicious. They're fine and they look wonderful. Bubur Kacang Ijo is something that I have loved my whole life.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we have to prepare a few ingredients. You can have bubur kacang ijo using 8 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Make ready 2 of gelas kacang hijau. </li>
	
		<li>{Make ready 300 ml of santan kental. </li>
	
		<li>{Make ready 2 buah of daun pandan segar. </li>
	
		<li>{Get 1/2 sdt of garam. </li>
	
		<li>{Make ready 1/2 gelas of gula pasir. </li>
	
		<li>{Prepare Secukupnya of susu kental manis. </li>
	
		<li>{Get Secukupnya of roti tawar. </li>
	
		<li>{Get Secukupnya of es batu. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Rebus kacang hijau hingga kulit pecah dan air menyusut.
			
			
		</li>
	
		<li>
			Tambahkan gula pasir, aduk hingga merata. Setelah matang matikan api dan biarkan hingga dingin.
			
			
		</li>
	
		<li>
			Rebus santan, tambahkan daun pandan dan garam. Aduk hingga merata sampai mendidih.
			
			
		</li>
	
		<li>
			Penyajian:
Ambil kacang ijo masukkan ke dalam mangkok. Tambahkan santan, susu kental manis, dan roti. Bila ingin dingin dan lebih segar tambahkan es batu.
			
			
		</li>
	
		<li>
			Bubur kacang hijau ready to serve now 😊.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur kacang ijo recipe. Thank you very much for your time. I'm sure you will make this at home. There is gonna be interesting food at home recipes coming up. Remember to bookmark this page in your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
