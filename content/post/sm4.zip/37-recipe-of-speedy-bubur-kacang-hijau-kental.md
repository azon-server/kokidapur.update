---
description: "Recipe of Speedy Bubur Kacang Hijau Kental"
title: "Recipe of Speedy Bubur Kacang Hijau Kental"
slug: 37-recipe-of-speedy-bubur-kacang-hijau-kental

<p>
	<strong>Bubur Kacang Hijau Kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/2e6a4ef8454f4d57/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Louise, welcome to my recipe site. Today, I'm gonna show you how to prepare a distinctive dish, bubur kacang hijau kental. It is one of my favorites. For mine, I'm gonna make it a little bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Hijau Kental is one of the most well liked of current trending foods in the world. It's enjoyed by millions every day. It's easy, it's fast, it tastes yummy. Bubur Kacang Hijau Kental is something which I have loved my entire life. They are nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to prepare a few ingredients. You can have bubur kacang hijau kental using 6 ingredients and 5 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>{Get 1/4 kg of Kacang Hijau. </li>
	
		<li>{Take 1 of gelondong Gula jawa. </li>
	
		<li>{Take  of Air untuk merebus secukupnya sampe kacang hijau empuk. </li>
	
		<li>{Prepare 150 ml of Santan kara. </li>
	
		<li>{Get 2 sendok makan of tepung gandum. </li>
	
		<li>{Make ready  of Bubuk jahe (optional). </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>
			Kacang Hijau direndam semalam. Tujuannya agar kacang hijau cepet empuk jadi ngrebusnya ga terlalu lama.
			
			
		</li>
	
		<li>
			Rebus kacang hijau dan gula jawa, tambah bubuk jahe kalo suka. Gula jawa bisa di iris dulu biar cepat larut. Koreksi rasa.
			
			
		</li>
	
		<li>
			Setelah kacang hijau empuk, tambahkan 2 sdm tepung gandum (bisa langsung tambahin atau dilarutkan dulu pake segelas air). Gandum bikin cepet mengental jadi pastikan nambahin gandum setelah kacang hijau empuk. Koreksi rasa, selesai..
			
			
		</li>
	
		<li>
			Untuk kuah santan saya biasanya 4 sdm kara untuk 150ml air, direbus dan ditambah sedikit garam. Tapi sesuaikan selera aja pengen santan kental atau cair. Rebus sampai mendidih.
			
			
		</li>
	
		<li>
			Sajikan bubur kacang hijau kental dan kuah santan. Dimakan panas enak, dimasukkan ke kulkas dulu juga enak kok. Selamat menikmatiii 😊.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur kacang hijau kental recipe. Thanks so much for reading. I'm sure you can make this at home. There is gonna be interesting food in home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
