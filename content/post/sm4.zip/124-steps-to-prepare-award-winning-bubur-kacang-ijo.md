---
description: "Steps to Prepare Award-winning Bubur kacang ijo"
title: "Steps to Prepare Award-winning Bubur kacang ijo"
slug: 124-steps-to-prepare-award-winning-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/29cf2152468ca346/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
		Resep bubur kacang ijo itu sendiri ada berbagai macam dengan tambahan bahan yang melengkapinya.
	
		Cara bikin bubur kacang hijau / ijo memerlukan trik dan tips tersendiri, sehingga hasilnya bisa lebih bagus dan juga enak serta lembut.
	
		Sebenarnya tidak ada yang istimewa saat anda membuat.
	
</p>
<p>
	Hey everyone, hope you're having an incredible day today. Today, I will show you a way to make a distinctive dish, bubur kacang ijo. One of my favorites food recipes. For mine, I'm gonna make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>
<p>
	Bubur kacang ijo is one of the most favored of current trending foods in the world. It's appreciated by millions daily. It's simple, it's quick, it tastes yummy. Bubur kacang ijo is something that I have loved my entire life. They're nice and they look fantastic.
</p>

<p>
To get started with this recipe, we have to prepare a few components. You can have bubur kacang ijo using 7 ingredients and 9 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Make ready 500 g of kacang ijo. </li>
	
		<li>{Prepare 250 of gula putih. </li>
	
		<li>{Make ready 3 sdm of tapeoka. </li>
	
		<li>{Get  of garam. </li>
	
		<li>{Get  of Pandan wangi. </li>
	
		<li>{Take 3 lt of air. </li>
	
		<li>{Take 250 ml of santan kental. </li>
	
</ol>
<p>
	
		Bubur kacang hejo (su) Bubur kacang ijo (jv) Burjo.
	
		Slightly different names may be used in different regions of Indonesia, such as kacang ijo in Javanese areas.
	
		Cara masak bubur kacang ijo super simple dan enak.
	
		Rahasia Peyek Kacang Ijo Renyah, Tidak Keras dan Tahan Lama Bu Yun kali inia akan membagikan resep, tips dan tutorial cara.
	
</p>

<h3>Steps to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Bersihkan kacang ijo..
			
			
		</li>
	
		<li>
			Rebus air Dan daun pandan. Kalo sudah mendidih masukkan kacang ijo. Tutup panci biar cepat empuk..
			
			
		</li>
	
		<li>
			Bila kacang ijo sudah empuk.masukkan gula Dan sedikit garam. Aduk2.
			
			
		</li>
	
		<li>
			Tapeoka taruh gelas Dan tambah sedikit air.aduk2. masukkan dalam rebusan kacang ijo.terus diaduk2 sampai air tinggal sedikit..
			
			
		</li>
	
		<li>
			Kalo sudah kental.matikan kompor..
			
			
		</li>
	
		<li>
			Sementara untuk santan. Peras parutan Kelapa.. ambil perasan yang pertama Dan kerua dengan sedikit air..
			
			
		</li>
	
		<li>
			Kalo sudah diperas masak Dan ditambahi sedikit garam. Aduk2 sampai mendidih..
			
			
		</li>
	
		<li>
			Sajikan bubur kacang ijo dalam mangkok..atasnya baru dituangi 1 sdm santal kental..
			
			
		</li>
	
		<li>
			Selamat menikmati..
			
			
		</li>
	
</ol>

<p>
	
		Cara Membuat Bubur Kacang Hijau Sederhana Yang Enak amp Kental Ala Dapur Dina.
	
		Ingin mencoba memasak Bubur Kacang Hijau sendiri, Burjo Pisang (Tips spy kacang ijo cepat empuk dan lembut), Bubur kacang ijo ketan item durian enakk, Burjo Nangka dan lain-lain yang lezat untuk.
	
		Sajikan bubur kacang hijau beserta rebusan santan saat akan di konsumsi untuk menghindari kacang hijau cepat basi Resep membuat bubur kacang hijau.
	
		Resep Bubur Kacang Ijo Enak Dan Cepat Mekar Atau Empuk.
	
		Kacang hijau / ijo merupakan salah satu bahan makanan yang bukan saja enak di buat minuman maupun makanan.
	
</p>

<p>
	So that is going to wrap it up with this special food bubur kacang ijo recipe. Thank you very much for your time. I am sure you can make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
