---
description: "Recipe of Homemade Bubur Kacang Ijo khas Madura"
title: "Recipe of Homemade Bubur Kacang Ijo khas Madura"
slug: 73-recipe-of-homemade-bubur-kacang-ijo-khas-madura

<p>
	<strong>Bubur Kacang Ijo khas Madura</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/0f8f5f4d371682c8/680x482cq70/bubur-kacang-ijo-khas-madura-foto-resep-utama.jpg" alt="Bubur Kacang Ijo khas Madura" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is me again, Dan, welcome to our recipe site. Today, I will show you a way to make a special dish, bubur kacang ijo khas madura. It is one of my favorites. For mine, I will make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo khas Madura is one of the most favored of recent trending foods on earth. It's appreciated by millions daily. It's simple, it's fast, it tastes delicious. Bubur Kacang Ijo khas Madura is something that I have loved my whole life. They are nice and they look fantastic.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we have to first prepare a few ingredients. You can cook bubur kacang ijo khas madura using 9 ingredients and 4 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo khas Madura:</h3>

<ol>
	
		<li>{Get 250 gr of kacang ijo (me: 200gr). </li>
	
		<li>{Make ready 1 liter of air. </li>
	
		<li>{Get 2 bks of santan kara kecil + 400 ml air. </li>
	
		<li>{Prepare 180 gr of gula pasir. </li>
	
		<li>{Take  of Vanilli. </li>
	
		<li>{Get 1 lbr of daun pandan. </li>
	
		<li>{Take 1/2 sdt of garam. </li>
	
		<li>{Get 1 ruas of jahe, geprek. </li>
	
		<li>{Prepare 1 sch of susu kental manis (optional). </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo khas Madura:</h3>

<ol>
	
		<li>
			Rendam kacang hijau semalaman..
			
			
		</li>
	
		<li>
			Rebus kacang ijo dengan daun pandan dan jahe. Ditutup jangan dibuka2 selama 30 menit. Kemudian masukkan gula, garam..
			
			
		</li>
	
		<li>
			Kemudian masukkan vanilli, santan aduk2 terus sampai mendidih, kecilkan api lalu masukkan SKM (saya skip, tdk pakai SKM).
			
			
		</li>
	
		<li>
			Sajikan dan nikmati selagi hangat..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food bubur kacang ijo khas madura recipe. Thank you very much for reading. I'm sure that you will make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
