---
description: "Recipe of Ultimate Bubur kacang ijo simple"
title: "Recipe of Ultimate Bubur kacang ijo simple"
slug: 81-recipe-of-ultimate-bubur-kacang-ijo-simple

<p>
	<strong>Bubur kacang ijo simple</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/7c9eea640d70e438/680x482cq70/bubur-kacang-ijo-simple-foto-resep-utama.jpg" alt="Bubur kacang ijo simple" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you are having an amazing day today. Today, we're going to prepare a distinctive dish, bubur kacang ijo simple. It is one of my favorites. This time, I'm gonna make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo simple is one of the most favored of recent trending foods on earth. It is enjoyed by millions daily. It's simple, it is fast, it tastes delicious. Bubur kacang ijo simple is something that I have loved my whole life. They are fine and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we must first prepare a few ingredients. You can cook bubur kacang ijo simple using 7 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo simple:</h3>

<ol>
	
		<li>{Prepare 400 g of kacang ijo. </li>
	
		<li>{Make ready 7 cm of ruas jahe (digeprek). </li>
	
		<li>{Get 300 gr of gula merah. </li>
	
		<li>{Prepare 1 sdm of gula pasir. </li>
	
		<li>{Get 1/2 sdt of garam. </li>
	
		<li>{Prepare 300 ml of santan cair (agak kental). </li>
	
		<li>{Take 1 L of air. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo simple:</h3>

<ol>
	
		<li>
			Rebus bubur kacang ijo dengan 700ml air. Jika air sdh agak menyusut dan bubur mulai lunak, tambahkan 300 ml air. (Bisa langsung direbus dalam 1 L air ya, ini pemberian airx bertahap sesuai wadah panci)..
			
			
		</li>
	
		<li>
			Tambahkan gula merah (gula merah masih dalam bentuk bongkahan, langsung dilarutkan di dalam proses perebusan bubur kacang ijo)..
			
			
		</li>
	
		<li>
			Masukkan ruas jahe yang telah digeprek, gula pasir dan garam. Masak hingga bahan gula larut sempurna..
			
			
		</li>
	
		<li>
			Tambahkan santan cair (agak kental). (Usahakan tetap diaduk biar santan tidak pecah)..
			
			
		</li>
	
		<li>
			Bubur kacang ijo siap dihidangkan. Selamat Menikmati..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this special food bubur kacang ijo simple recipe. Thank you very much for your time. I am sure you will make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
