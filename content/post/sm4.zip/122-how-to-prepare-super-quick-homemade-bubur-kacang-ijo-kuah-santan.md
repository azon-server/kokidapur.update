---
description: "How to Prepare Super Quick Homemade Bubur Kacang Ijo Kuah Santan"
title: "How to Prepare Super Quick Homemade Bubur Kacang Ijo Kuah Santan"
slug: 122-how-to-prepare-super-quick-homemade-bubur-kacang-ijo-kuah-santan

<p>
	<strong>Bubur Kacang Ijo Kuah Santan</strong>. 
	Bubur kacang ijo yang lezat dan manis ini bisa banget menjadi salah satu hidangan lezat menemani hari-harimu. Nah, pada resep kali ini akan dipaparkan cara membuat bubur kacang ijo yang manis dan gurih dari kuah santannya. Bubur Kacang Ijo adalah makanan berbahan utama kacang hijau yang biasa dikonsumsi oleh masyarakat Indonesia.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/90dde1b1f99bca21/680x482cq70/bubur-kacang-ijo-kuah-santan-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Kuah Santan" style="width: 100%;">
	
	
		Nah, untuk anda yang ingin menyajikan bubur kacang ijo untuk keluarga di rumah.
	
		Bubur kacang hijau bisa dibikin tanpa santan, kuah cukup pakai air dan gula merah.
	
		Kacang hijau direbus sampai empuk dengan daun pandan.
	
</p>
<p>
	Hey everyone, it's Louise, welcome to my recipe page. Today, we're going to make a special dish, bubur kacang ijo kuah santan. It is one of my favorites. For mine, I am going to make it a little bit unique. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo yang lezat dan manis ini bisa banget menjadi salah satu hidangan lezat menemani hari-harimu. Nah, pada resep kali ini akan dipaparkan cara membuat bubur kacang ijo yang manis dan gurih dari kuah santannya. Bubur Kacang Ijo adalah makanan berbahan utama kacang hijau yang biasa dikonsumsi oleh masyarakat Indonesia.
</p>
<p>
	Bubur Kacang Ijo Kuah Santan is one of the most popular of recent trending foods on earth. It is simple, it is fast, it tastes yummy. It's enjoyed by millions every day. They're nice and they look wonderful. Bubur Kacang Ijo Kuah Santan is something which I've loved my whole life.
</p>

<p>
To begin with this particular recipe, we must first prepare a few components. You can have bubur kacang ijo kuah santan using 8 ingredients and 8 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Kuah Santan:</h3>

<ol>
	
		<li>{Prepare  of Kacang hijau. </li>
	
		<li>{Get  of Gula merah. </li>
	
		<li>{Take  of Jahe. </li>
	
		<li>{Prepare  of Garam. </li>
	
		<li>{Get  of Kuah santan. </li>
	
		<li>{Make ready  of Santan kental. </li>
	
		<li>{Take  of Air. </li>
	
		<li>{Take  of Garam. </li>
	
</ol>
<p>
	
		Bubur kacang ijo ini sudah tersebar di hampir seluruh daerah yang ada di nusantara sehingga Anda pun dapat dengan mudah untuk Ketika Anda ingin membuat bubur kacang ijo; maka yang harus dipersiapkan adalah bahan-bahan untuk membuat bubur dan santan sebagai pelengkap kuahnya.
	
		Sajikan bubur kacang hijau dengan siraman saus santan dan saus gula agar lebih nikmat.
	
		Inilah resep bubur kacang hijau yang perlu anda perhatikan Untuk kuah santan, rebus sekuruh bahan kuah santan sembari terus diaduk hingga mendidih. • Sajikan bubur kacang hijau dengan kuah santan.
	
		Resep Mudah Praktis Bubur Kacang Hijau Tanpa Santan - Kacang Hijau Agar Cepat Empuk Kacang hijau sangat bergizi maka.
	
</p>

<h3>Steps to make Bubur Kacang Ijo Kuah Santan:</h3>

<ol>
	
		<li>
			Cuci biji kacang hijau. Boleh di rendam dahulu, sambil melakukan aktivitas lain..
			
			
		</li>
	
		<li>
			Masak gula jawa dengan air mendidih sampai larut. Tujuannya supaya dpt di saring..
			
			
		</li>
	
		<li>
			Masak kacang hijau dengan air 2 kali nya dan masukkan jahe..
			
			
		</li>
	
		<li>
			Air mulai menyusut, tambahkan air gula jawa tadi, aduk2, tambahkan garam..
			
			
		</li>
	
		<li>
			Jika masih belom matang lagi, dan air mulai menyusut, tambahkan air putih, sampai matang (mekar)..
			
			
		</li>
	
		<li>
			Bisa di koreksi rasa, jk belum manis, tambahkan air gula, namun jika sudah manis, tambahannya air putih saja..
			
			
		</li>
	
		<li>
			Membuat kuah santan. Campur santan kental dengan air. Jangan terlalu encer. Masak diatas api kecil saja, tambahkan garam, aduk terus, spy tdk pecah santanya. Jk sudah mendidih, matikan api..
			
			
		</li>
	
		<li>
			Siapkan mangkuk, isi bubur kacang hijau lalu siram dengan kuah santan. Ntaps.
			
			
		</li>
	
</ol>

<p>
	
		Kacang ijo tanpa santan masak nya super Mudah nya semua pasti bisa Terimakasih sudah menonton.
	
		Biasanya bubur kacang hijau memiliki cita rasa yang manis dan gurih.
	
		Paduan dari bahan santan, gula pasir, gula aren dan daun pandan menjadikan makanan ini nikmat disajikan dalam kondisi hangat.
	
		Meski banyak yang menjualnya di luar, kamu juga bisa, membuat bubur kacang hijau dengan variasi.
	
		Bubur kacang hijau, abbreviated burjo, is a Southeast Asian sweet porridge (bubur) made from mung beans (kacang hijau), coconut milk, and palm sugar or cane sugar.
	
</p>

<p>
	So that is going to wrap this up with this special food bubur kacang ijo kuah santan recipe. Thanks so much for reading. I am confident you can make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
