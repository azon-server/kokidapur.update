---
description: "How to Make Speedy Bubur kacang Ijo(Madura) ketan hitam #01#SeninSemangat"
title: "How to Make Speedy Bubur kacang Ijo(Madura) ketan hitam #01#SeninSemangat"
slug: 225-how-to-make-speedy-bubur-kacang-ijomadura-ketan-hitam-01seninsemangat

<p>
	<strong>Bubur kacang Ijo(Madura) ketan hitam #01#SeninSemangat</strong>. 
	Bubur Kacang Ijo &amp; Ketan Hitam MADURAAddress: Jl. Contoh dari jenis bubur kacang ijo antara lain bubur kacang ijo ketan hitam, bubur kacang hijau. Melayani katering dan Pesanan Bubur kacang ijo.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/951fd7a0b1e71edf/680x482cq70/bubur-kacang-ijomadura-ketan-hitam-01seninsemangat-foto-resep-utama.jpg" alt="Bubur kacang Ijo(Madura) ketan hitam #01#SeninSemangat" style="width: 100%;">
	
	
		Di makan di tempat dan bisa di bungkus.
	
		Udah lama bgt ngidam burcang ijo madura, akhirnya nemu deket rumah.
	
		Resep bubur kacang ijo itu sendiri ada berbagai macam dengan tambahan bahan yang melengkapinya.
	
</p>
<p>
	Hello everybody, it's Drew, welcome to our recipe page. Today, we're going to prepare a distinctive dish, bubur kacang ijo(madura) ketan hitam #01#seninsemangat. One of my favorites food recipes. This time, I'm gonna make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo &amp; Ketan Hitam MADURAAddress: Jl. Contoh dari jenis bubur kacang ijo antara lain bubur kacang ijo ketan hitam, bubur kacang hijau. Melayani katering dan Pesanan Bubur kacang ijo.
</p>
<p>
	Bubur kacang Ijo(Madura) ketan hitam #01#SeninSemangat is one of the most favored of current trending meals on earth. It's enjoyed by millions daily. It is simple, it's quick, it tastes delicious. Bubur kacang Ijo(Madura) ketan hitam #01#SeninSemangat is something that I have loved my whole life. They are nice and they look fantastic.
</p>

<p>
To begin with this recipe, we have to first prepare a few ingredients. You can cook bubur kacang ijo(madura) ketan hitam #01#seninsemangat using 21 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang Ijo(Madura) ketan hitam #01#SeninSemangat:</h3>

<ol>
	
		<li>{Get  of Bahan untuk Bubur Kacang Ijo :. </li>
	
		<li>{Make ready 250 g of kacang ijo, rendam dlm air semalaman. </li>
	
		<li>{Take 1 of lmbar daun pandan. </li>
	
		<li>{Take 100 g of gula merah. </li>
	
		<li>{Prepare 50 g of gula pasir. </li>
	
		<li>{Get 1200 ml of air. </li>
	
		<li>{Take 2 ruas jari of jahe, keprek. </li>
	
		<li>{Prepare 400 ml of santan. </li>
	
		<li>{Take 1/2 sdt of garam. </li>
	
		<li>{Make ready 1/4 sdt of vanili bubuk. </li>
	
		<li>{Make ready  of Bahan untuk Bubur Ketan Hitam :. </li>
	
		<li>{Make ready 150 g of beras ketan Hitam, rendam dlm air semalaman. </li>
	
		<li>{Take 1000 ml of air. </li>
	
		<li>{Take 75 g of gula pasir. </li>
	
		<li>{Get 1/2 of sdt. </li>
	
		<li>{Make ready 1 of lmbar daun pandan. </li>
	
		<li>{Take  of Bahan untuk Kuah Santan :. </li>
	
		<li>{Take 100 ml of santan kental Kara, aku encerkan hingga 250 ml. </li>
	
		<li>{Take 2 sdt of tepung maizena, dilarutkan dgn sedikit air. </li>
	
		<li>{Make ready 1/2 sdt of garam. </li>
	
		<li>{Make ready 1 of lmbar daun pandan. </li>
	
</ol>
<p>
	
		Nah, untuk anda yang ingin menyajikan Silakan ambil mangkuk saji.
	
		Lalu masukan bubur kacang ijo dan bubur ketan hitam dalam satu tempat.
	
		Resep Membuat Bubur Kacang Ijo Dan Ketan Hitam Yang Enak.
	
		Warung Bubur Kacang Ijo Ketan Ireng Enak.
	
</p>

<h3>Steps to make Bubur kacang Ijo(Madura) ketan hitam #01#SeninSemangat:</h3>

<ol>
	
		<li>
			Setelah direndam, cuci bersih kacang ijo Dan ketan hitam dgn air mengalir..
			
			
		</li>
	
		<li>
			Buat bubur kacang ijo: Rebus kacang in bersama dgn daun pandan yg diikat Dan jahe...biarkan hingga mendidih Dan kacang ijo mnjadi merekah empuk. Stelah empuk tambahkan gula merah, gula pasir, vanili bubuk Dan Santan... aduk2 agar Santan tidak pecah...biarkan mendidih sekali lagi hingga diperoleh kekentalan yg diinginkan...lalu koreksi rasany..
			
			
		</li>
	
		<li>
			Buat Bubur Ketan Hitam : Rebus air Dan daun pandan yg diikat hingga mendidih. Masukkan beras Ketan Hitam biarkan hingga mendidih lagi...lalu kecilkan API...masak hingga beras Ketan merekah atw lembut Dan air hampir abis lalu masukkan garam Serta gula pasir aduk2 agar beras Ketan tidak menempel didasar wajan..Biarkan meletup-letup hingga diperoleh kekentalan yg diinginkan.Koreksi rasa..
			
			
		</li>
	
		<li>
			Buat Kuah Santan : Encerkan Santan Kara 100 ml dgn air 150 ml aduk rata.. masukkan dlm panci bersama daun pandan yg tlah diikat tambahkan garam Aduk2 hingga mendidih, lalu masukkan larutan maizena biarkan mendidih kembali..matikan API Dan angkat..
			
			
		</li>
	
		<li>
			Untuk penyajian : tuang bubur kacang ijo dimangkuk lalu tambahkan bubur Ketan Hitam terakhir siram dgn kuah Santan....
			
			
		</li>
	
</ol>

<p>
	
		Cara Memasak Bubur Kacang Ijo Kental Manis Burjo Kang Yaya.
	
		Bubur kacang ijo ini sudah tersebar di hampir seluruh daerah yang ada di nusantara sehingga Anda pun dapat dengan mudah untuk menemukannya.
	
		Cara membuat bubur acang hijau: • Langkah awal yang perlu sobat lakukan yakni dengan mencuci.
	
		Namun bubur kacang ijo madura ini menggunakan tambahan topping seperti ketan hitam dan roti tawar.
	
		Biasanya disantap dengan secangkir teh tawar hangat.
	
</p>

<p>
	So that's going to wrap it up with this special food bubur kacang ijo(madura) ketan hitam #01#seninsemangat recipe. Thanks so much for your time. I am confident that you can make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
