---
description: "How to Prepare Super Quick Homemade Bubur kacang ijo 🍵"
title: "How to Prepare Super Quick Homemade Bubur kacang ijo 🍵"
slug: 117-how-to-prepare-super-quick-homemade-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo 🍵</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/076a2988e3df66cc/680x482cq70/bubur-kacang-ijo-🍵-foto-resep-utama.jpg" alt="Bubur kacang ijo 🍵" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's me, Dave, welcome to our recipe page. Today, we're going to make a special dish, bubur kacang ijo 🍵. One of my favorites. For mine, I will make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo 🍵 is one of the most popular of recent trending meals on earth. It is appreciated by millions every day. It's easy, it's quick, it tastes delicious. Bubur kacang ijo 🍵 is something which I've loved my entire life. They're nice and they look fantastic.
</p>

<p>
To get started with this recipe, we have to prepare a few components. You can cook bubur kacang ijo 🍵 using 7 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo 🍵:</h3>

<ol>
	
		<li>{Get secukupnya of kacang ijo. </li>
	
		<li>{Prepare secukupnya of Gula merah. </li>
	
		<li>{Make ready sesuai selera of susu kental manis. </li>
	
		<li>{Make ready 1 butir of telur ayam. </li>
	
		<li>{Take  of daun pandan. </li>
	
		<li>{Get secukupnya of jahe. </li>
	
		<li>{Get  of santan. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo 🍵:</h3>

<ol>
	
		<li>
			Rebus kacang hijau selma 30 menit ya kak.
			
			
		</li>
	
		<li>
			Setelah 30 menit masukan santan, Jahe, gula merah / putih dan susu kental manis ya kak.
			
			
		</li>
	
		<li>
			Tunggu sampai mendidih ya kak.....
			
			
		</li>
	
		<li>
			Lalu yang terakhir masukan telur ayam 1 butir... tunggu bbrpa menit lagi.
			
			
		</li>
	
		<li>
			Dan jadi bubur kacang ijo ala adel😍.... selmt mencoba ya kak.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur kacang ijo 🍵 recipe. Thank you very much for your time. I am confident that you can make this at home. There is gonna be interesting food in home recipes coming up. Don't forget to save this page in your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
