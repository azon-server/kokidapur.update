---
description: "Steps to Make Homemade Bubur kacang ijo susu"
title: "Steps to Make Homemade Bubur kacang ijo susu"
slug: 176-steps-to-make-homemade-bubur-kacang-ijo-susu

<p>
	<strong>Bubur kacang ijo susu</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/777ec0dad16f4905/680x482cq70/bubur-kacang-ijo-susu-foto-resep-utama.jpg" alt="Bubur kacang ijo susu" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is Jim, welcome to our recipe page. Today, I will show you a way to make a special dish, bubur kacang ijo susu. One of my favorites. For mine, I will make it a bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo susu is one of the most popular of current trending foods in the world. It's enjoyed by millions daily. It's simple, it's fast, it tastes yummy. They are fine and they look wonderful. Bubur kacang ijo susu is something which I've loved my whole life.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we must first prepare a few components. You can have bubur kacang ijo susu using 7 ingredients and 2 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo susu:</h3>

<ol>
	
		<li>{Make ready 1 mangkuk of kacang hijau. </li>
	
		<li>{Get 1 kotak of santan kara. </li>
	
		<li>{Make ready 1/2 bks of susu kental manis. </li>
	
		<li>{Get 2 sendok sayur of gula pasir. </li>
	
		<li>{Get 1/2 potong of gula merah. </li>
	
		<li>{Make ready 1 ruas of jahe. </li>
	
		<li>{Take 2 lmbr of daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo susu:</h3>

<ol>
	
		<li>
			Siapkan bahan, didihkan air di panci sesuai selera, beri daun pandan, jahe, gula merah dan gula pasir, setelah mendidih masukan kacang hijau tunggu sampai kacang hijau empuk dan matang.
			
			
		</li>
	
		<li>
			Jika kacang hijau sudah matang beri santan dan susu aduk rata jangan sampai santan pecah, aduk sampai mendidih lalu koreksi rasa jua sudah pas matikan kompor dan sajikan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur kacang ijo susu recipe. Thank you very much for your time. I am sure you will make this at home. There is gonna be interesting food in home recipes coming up. Remember to bookmark this page on your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
