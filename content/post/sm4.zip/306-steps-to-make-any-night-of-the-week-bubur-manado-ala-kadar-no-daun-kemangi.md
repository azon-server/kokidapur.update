---
description: "Steps to Make Any-night-of-the-week Bubur Manado ala kadar no daun kemangi"
title: "Steps to Make Any-night-of-the-week Bubur Manado ala kadar no daun kemangi"
slug: 306-steps-to-make-any-night-of-the-week-bubur-manado-ala-kadar-no-daun-kemangi

<p>
	<strong>Bubur Manado ala kadar no daun kemangi</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/6f59f7c3dd23e32f/680x482cq70/bubur-manado-ala-kadar-no-daun-kemangi-foto-resep-utama.jpg" alt="Bubur Manado ala kadar no daun kemangi" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you are having an incredible day today. Today, I will show you a way to prepare a distinctive dish, bubur manado ala kadar no daun kemangi. One of my favorites. This time, I am going to make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Manado ala kadar no daun kemangi is one of the most well liked of current trending meals on earth. It is simple, it's quick, it tastes yummy. It's enjoyed by millions daily. They are nice and they look fantastic. Bubur Manado ala kadar no daun kemangi is something which I've loved my entire life.
</p>

<p>
To begin with this recipe, we must first prepare a few components. You can have bubur manado ala kadar no daun kemangi using 11 ingredients and 4 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Manado ala kadar no daun kemangi:</h3>

<ol>
	
		<li>{Prepare 3 gelas belimbing of air. </li>
	
		<li>{Take 1/4 of labu kuning. </li>
	
		<li>{Prepare 2 tongkol of jagung di pipil ya. </li>
	
		<li>{Take sepiring of nasi penuh (piringnya yang agak lebar/besar). </li>
	
		<li>{Get  of sereh. </li>
	
		<li>{Get  of jahe. </li>
	
		<li>{Make ready  of daun salam. </li>
	
		<li>{Prepare secukupnya of garam. </li>
	
		<li>{Take secukupnya of daun bayam (kalo saya sih secukupnya). </li>
	
		<li>{Make ready secukupnya of daun kangkung(sama secukupnya). </li>
	
		<li>{Make ready  of sambal ikan teri. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado ala kadar no daun kemangi:</h3>

<ol>
	
		<li>
			Masak air sampai mendidih(takaran air saya cukupnya setengah panci). Sambil menunggu air mendidih, pipil jagung dan iris kecil - kecil labu kuning lalu masukkan jagung dan irisan labu kuning ke dalam air mendidih. Ini ukuran panci saya ini(maaf panci jelek hehehe).
			
			
		</li>
	
		<li>
			Setelah jagung dan labu kuning lembut, masukkan sepiring nasi diikuti dengan sereh, daun salam, jahe, dan garam. Tunggu hingga nasi menjadi bubur. Aduk sesekali agar tidak lengket dibawah panci..
			
			
		</li>
	
		<li>
			Di sela - sela nasi yang setengah menjadi bubur, masukkan daun bayam dan daun kangkung. Aduk sebentar. Tunggu kembali sampai nasi benar - benar menjadi bubur..
			
			
		</li>
	
		<li>
			Setelah nasi sudah menjadi bubur, matikan kompor (ya emang dimatiin tanpa dikasih tahu... hehehe) langsung hidangkann deh dengan sambal ikan teri... mantapp...... 😄😄😄😄😛😛😍😍😍.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this special food bubur manado ala kadar no daun kemangi recipe. Thanks so much for your time. I am sure you will make this at home. There's gonna be interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
