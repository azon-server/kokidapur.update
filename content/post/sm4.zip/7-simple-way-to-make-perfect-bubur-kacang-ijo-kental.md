---
description: "Simple Way to Make Perfect Bubur kacang ijo kental"
title: "Simple Way to Make Perfect Bubur kacang ijo kental"
slug: 7-simple-way-to-make-perfect-bubur-kacang-ijo-kental

<p>
	<strong>Bubur kacang ijo kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/e50061bc84ba7afe/680x482cq70/bubur-kacang-ijo-kental-foto-resep-utama.jpg" alt="Bubur kacang ijo kental" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is Brad, welcome to my recipe page. Today, I'm gonna show you how to make a special dish, bubur kacang ijo kental. It is one of my favorites food recipes. For mine, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang ijo kental is one of the most favored of current trending foods in the world. It's enjoyed by millions every day. It is simple, it's fast, it tastes yummy. Bubur kacang ijo kental is something that I have loved my whole life. They are nice and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to prepare a few ingredients. You can have bubur kacang ijo kental using 8 ingredients and 6 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo kental:</h3>

<ol>
	
		<li>{Take  of Kacang ijo. </li>
	
		<li>{Prepare  of Santan. </li>
	
		<li>{Make ready  of Gula pasir. </li>
	
		<li>{Get  of Gula aren. </li>
	
		<li>{Prepare  of Kayu manis. </li>
	
		<li>{Take  of Daun pandan. </li>
	
		<li>{Take  of Jahe. </li>
	
		<li>{Make ready  of Maizena. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo kental:</h3>

<ol>
	
		<li>
			Rendam Kacang ino semalam... sebenarnya sesuka kita sih kalo saya sampe kacang ijo agak pecah biar ngk lama ngerebusnya.
			
			
		</li>
	
		<li>
			Rebus air... sampai goblok goblok alias mendidih bru masukin kacang ijo yg sudah di rendamm 😘.
			
			
		</li>
	
		<li>
			Setelah kacang ijo makin lemes hahaha masukin teman temanya kayu manis, jahe dan daun pandan... masukan juga gula aren.. kalo masih kurang manis tambahakan gula pasir... masih kurang lagi... liat foto saya.. hihihi.
			
			
		</li>
	
		<li>
			Terakir tapi ngk terakir banget masukin santan aduk terus jangan sampe pecah kayak piring tetangga sebelah....
			
			
		</li>
	
		<li>
			Terakir banget larutin maizena lalu cemplungin sambil terus di aduk....
			
			
		</li>
	
		<li>
			Kesempurnaan Hanya Milik Tuhan... Selamat Mencoba.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this special food bubur kacang ijo kental recipe. Thanks so much for reading. I am sure you will make this at home. There is gonna be more interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
