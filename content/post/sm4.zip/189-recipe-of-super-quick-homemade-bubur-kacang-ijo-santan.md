---
description: "Recipe of Super Quick Homemade Bubur kacang ijo + santan"
title: "Recipe of Super Quick Homemade Bubur kacang ijo + santan"
slug: 189-recipe-of-super-quick-homemade-bubur-kacang-ijo-santan

<p>
	<strong>Bubur kacang ijo + santan</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/d776dae2b3f9d68b/680x482cq70/bubur-kacang-ijo-santan-foto-resep-utama.jpg" alt="Bubur kacang ijo + santan" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you're having an incredible day today. Today, we're going to prepare a special dish, bubur kacang ijo + santan. One of my favorites food recipes. For mine, I will make it a bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo + santan is one of the most well liked of recent trending meals on earth. It's enjoyed by millions every day. It's easy, it is quick, it tastes yummy. Bubur kacang ijo + santan is something which I've loved my entire life. They're fine and they look wonderful.
</p>

<p>
To get started with this particular recipe, we have to first prepare a few ingredients. You can cook bubur kacang ijo + santan using 12 ingredients and 3 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo + santan:</h3>

<ol>
	
		<li>{Make ready 1/4 kg of kacang hijau. </li>
	
		<li>{Get 1 ruas of jahe. </li>
	
		<li>{Make ready 2 bulatan of gula merah. </li>
	
		<li>{Take 1/2 sdt of vanili. </li>
	
		<li>{Make ready 3/4 gelas of gula pasir. </li>
	
		<li>{Prepare 1 sdm of tepung maizena blh skip. </li>
	
		<li>{Take  of (Saya suka teksturnya agak kental). </li>
	
		<li>{Make ready Secukupnya of air (kurleb 2lt). </li>
	
		<li>{Take  of Kuah santan:. </li>
	
		<li>{Take 1 sachet of kara cair 65ml. </li>
	
		<li>{Get 1 gelas of air. </li>
	
		<li>{Make ready Sejumput of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo + santan:</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau, sisihkan. Didihkan air lalu masukan kacang hijau (kalau sudah mendidih baru dimasukan ya) tutup dengan penutup panci supaya cpt empuk.
			
			
		</li>
	
		<li>
			Kuah santan: didihkan santan kara dengan segelas air beri sedikit garam, sambil terus diaduk ya hingga mendidih.
			
			
		</li>
	
		<li>
			Penyajian: ambil bubur kacang hijau kedalam mangkuk lalu beri kuah santan diatasnya, sajikan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this special food bubur kacang ijo + santan recipe. Thanks so much for reading. I'm confident you will make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
