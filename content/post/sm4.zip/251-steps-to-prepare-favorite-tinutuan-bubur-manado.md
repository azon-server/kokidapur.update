---
description: "Steps to Prepare Favorite Tinutuan (Bubur Manado)"
title: "Steps to Prepare Favorite Tinutuan (Bubur Manado)"
slug: 251-steps-to-prepare-favorite-tinutuan-bubur-manado

<p>
	<strong>Tinutuan (Bubur Manado)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/eeb6b27842a77383/680x482cq70/tinutuan-bubur-manado-foto-resep-utama.jpg" alt="Tinutuan (Bubur Manado)" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's John, welcome to my recipe site. Today, I'm gonna show you how to prepare a special dish, tinutuan (bubur manado). It is one of my favorites. For mine, I will make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Tinutuan (Bubur Manado) is one of the most popular of current trending meals on earth. It is easy, it's fast, it tastes delicious. It's enjoyed by millions every day. Tinutuan (Bubur Manado) is something which I have loved my entire life. They're nice and they look wonderful.
</p>

<p>
To begin with this particular recipe, we have to prepare a few ingredients. You can have tinutuan (bubur manado) using 8 ingredients and 4 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Tinutuan (Bubur Manado):</h3>

<ol>
	
		<li>{Take 300 gr of beras. </li>
	
		<li>{Make ready 1.5 liter of air. </li>
	
		<li>{Prepare 1 sdt of garam. </li>
	
		<li>{Take 1 sdt of kaldu bubuk. </li>
	
		<li>{Make ready 1 buah of jagung, serut. </li>
	
		<li>{Get 1 ikat of bayam, siangi. </li>
	
		<li>{Make ready 200 gr of labu kuning, potong-potong. </li>
	
		<li>{Take 1 ikat of kangkung, siangi. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Tinutuan (Bubur Manado):</h3>

<ol>
	
		<li>
			Cuci beras hingga bersih. Rebus beras dg 1.5 liter air.
			
			
		</li>
	
		<li>
			Setelah bubur mulai matang, masukkan serutan jagung. Masak hingga jagung setengah matang. Lalu masukan labu kuning.
			
			
		</li>
	
		<li>
			Setelah labu kuning mulai lunak, tambahkan bayam dan kangkung. Masak hingga kangkung dan bayam lunak..
			
			
		</li>
	
		<li>
			Siapkan bubur dalam mangkok, tinutuan siap disantap (paling enak kalau ditambah sambal terasi dan dilengkapi ikan asin goreng).
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this exceptional food tinutuan (bubur manado) recipe. Thanks so much for your time. I am sure you will make this at home. There's gonna be more interesting food in home recipes coming up. Don't forget to save this page in your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
