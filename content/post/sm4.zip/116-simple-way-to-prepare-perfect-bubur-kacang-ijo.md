---
description: "Simple Way to Prepare Perfect Bubur Kacang Ijo"
title: "Simple Way to Prepare Perfect Bubur Kacang Ijo"
slug: 116-simple-way-to-prepare-perfect-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/6560250362367b78/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, I will show you a way to prepare a distinctive dish, bubur kacang ijo. It is one of my favorites. For mine, I am going to make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo is one of the most well liked of current trending foods in the world. It's enjoyed by millions every day. It's simple, it's quick, it tastes yummy. Bubur Kacang Ijo is something which I've loved my whole life. They're nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to prepare a few components. You can cook bubur kacang ijo using 9 ingredients and 3 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Take 250 g of kacang hijau. </li>
	
		<li>{Get 5 sdm of gula pasir. </li>
	
		<li>{Make ready 2 batang of gula jawa. </li>
	
		<li>{Prepare 1 lembar of daun pandan. </li>
	
		<li>{Get 1 ruas of jahe. </li>
	
		<li>{Prepare 65 ml of sunkara. </li>
	
		<li>{Prepare 2 sachet of bubuk vanili. </li>
	
		<li>{Make ready Sedikit of garam. </li>
	
		<li>{Prepare 1,5 L of Air. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Siapkan bahan dan cuci bersih kacang hijau, jahe, daun pandan..
			
			
		</li>
	
		<li>
			Rebus kacang hijau dn jahe 20menit lalu tambahkan daun pandan gula pasir gula jawa dan sedikit garam. Tambahkan sunkara lalu aduk sampai mendidih. Test rasa (kadar manis sesuai selera ya gaess)..
			
			
		</li>
	
		<li>
			Sajikan selagi hangat atau bisa ditambah es. Taburkan potongan roti tawar, bisa juga ditambah krimer kental manis..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur kacang ijo recipe. Thanks so much for reading. I'm confident that you will make this at home. There's gonna be interesting food in home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
