---
description: "How to Prepare Ultimate Bubur kacang ijo khas madura"
title: "How to Prepare Ultimate Bubur kacang ijo khas madura"
slug: 201-how-to-prepare-ultimate-bubur-kacang-ijo-khas-madura

<p>
	<strong>Bubur kacang ijo khas madura</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/e307d2d831636c0c/680x482cq70/bubur-kacang-ijo-khas-madura-foto-resep-utama.jpg" alt="Bubur kacang ijo khas madura" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you are having an amazing day today. Today, I will show you a way to prepare a distinctive dish, bubur kacang ijo khas madura. One of my favorites food recipes. For mine, I will make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang ijo khas madura is one of the most well liked of recent trending foods in the world. It is appreciated by millions daily. It's simple, it is fast, it tastes delicious. They're fine and they look fantastic. Bubur kacang ijo khas madura is something that I have loved my entire life.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we must prepare a few components. You can have bubur kacang ijo khas madura using 6 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo khas madura:</h3>

<ol>
	
		<li>{Get 250 kg of kacang ijo. </li>
	
		<li>{Prepare 2 of santan kara. </li>
	
		<li>{Get 250 kg of gula pasir. </li>
	
		<li>{Make ready 2 of set susu kental manis. </li>
	
		<li>{Take 3 buah of vanili. </li>
	
		<li>{Prepare  of Air secukup&#39;y2 lembar daun pandan (sy tidak pake, krna gx punya). </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo khas madura:</h3>

<ol>
	
		<li>
			Rendam kacang ijo semalaman, agar tidak lama merebus&#39;y.
			
			
		</li>
	
		<li>
			Pagi&#39;y.. Rebus kacang ijo dgn air secukup&#39;y.. (Bila terasa kacang blom empuk benar boleh d tambah air&#39;y?).
			
			
		</li>
	
		<li>
			Setelah benar&#34; empuk masukkan santan kara, gula pasir, susu kental manis, dan vanili, beri garam sedikit.
			
			
		</li>
	
		<li>
			Koreksi rasa.. Bila sudah tercampur semua,dan rasa&#39;y mantap...
			
			
		</li>
	
		<li>
			Bubur kacang ijo bisa langsung d santa.. Lebih enak klo anget&#34;.. Pake roti tawar.. 👍👍☺.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur kacang ijo khas madura recipe. Thank you very much for reading. I'm sure you can make this at home. There's gonna be interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
