---
description: "How to Prepare Speedy BUBUR KACANG HIJAU KENTAL DAN EMPUK TANPA DIRENDAM DULU (metode 5-30-7)"
title: "How to Prepare Speedy BUBUR KACANG HIJAU KENTAL DAN EMPUK TANPA DIRENDAM DULU (metode 5-30-7)"
slug: 31-how-to-prepare-speedy-bubur-kacang-hijau-kental-dan-empuk-tanpa-direndam-dulu-metode-5-30-7

<p>
	<strong>BUBUR KACANG HIJAU KENTAL DAN EMPUK TANPA DIRENDAM DULU (metode 5-30-7)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/24f206172456cfbc/680x482cq70/bubur-kacang-hijau-kental-dan-empuk-tanpa-direndam-dulu-metode-5-30-7-foto-resep-utama.jpg" alt="BUBUR KACANG HIJAU KENTAL DAN EMPUK TANPA DIRENDAM DULU (metode 5-30-7)" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you're having an incredible day today. Today, I will show you a way to make a special dish, bubur kacang hijau kental dan empuk tanpa direndam dulu (metode 5-30-7). One of my favorites. For mine, I'm gonna make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	BUBUR KACANG HIJAU KENTAL DAN EMPUK TANPA DIRENDAM DULU (metode 5-30-7) is one of the most popular of recent trending meals in the world. It is easy, it's quick, it tastes delicious. It is enjoyed by millions daily. They're fine and they look wonderful. BUBUR KACANG HIJAU KENTAL DAN EMPUK TANPA DIRENDAM DULU (metode 5-30-7) is something which I have loved my entire life.
</p>

<p>
To get started with this particular recipe, we have to first prepare a few components. You can have bubur kacang hijau kental dan empuk tanpa direndam dulu (metode 5-30-7) using 11 ingredients and 7 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make BUBUR KACANG HIJAU KENTAL DAN EMPUK TANPA DIRENDAM DULU (metode 5-30-7):</h3>

<ol>
	
		<li>{Make ready 100 gr of kacang hijau. </li>
	
		<li>{Get 100 gr of gula merah. </li>
	
		<li>{Make ready 2 lembar of daun pandan. </li>
	
		<li>{Make ready 2 ruas of jahe (digeprek). </li>
	
		<li>{Get 500 ml of air untuk merebus di awal. </li>
	
		<li>{Prepare 300-400 ml of air untuk tambahan merebus di akhir. </li>
	
		<li>{Make ready 1 1/2 sdm of tepung terigu. </li>
	
		<li>{Take  of bahan untuk santan. </li>
	
		<li>{Make ready 150-200 ml of santan kental (selera orang beda2, kadang ada yg suka bnyak santan, ada jg yg gk suka). </li>
	
		<li>{Get 1 sdt of garam. </li>
	
		<li>{Get 2 lembar of daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make BUBUR KACANG HIJAU KENTAL DAN EMPUK TANPA DIRENDAM DULU (metode 5-30-7):</h3>

<ol>
	
		<li>
			Cuci dahulu kacang hijaunya agar kotoran hilang. Panaskan 500 ml air dengan api besar. Setelah mendidih masukkan kacang hijaunya. Masak selama 5 menit sambil panci ditutup. INGAT YA JANGAN PERNAH BUKA TUTUP PANCINYA SAMPAI SELESAI 7 MENIT NANTI. 😁.
			
			
		</li>
	
		<li>
			Matikan kompor. Lalu diamkan selama 30 menit. Panci masih dalam keadaan ditutup, jangan dibuka sama sekali..
			
			
		</li>
	
		<li>
			Setelah 30 menit, hidupkan kompor dan masak lagi selama 7 menit, masih dengan api besar dan panci ditutup. Setelah 7 menit, buka tutup panci, kecilkan apinya. Nanti bisa dilihat hasilnya, kacang hijau sudah jadi empuk seperti kalau direndam semalaman😻..
			
			
		</li>
	
		<li>
			Kemudian masukkan daun pandan, jahe, &amp; gula jawa yg sudah diiris tipis2. Tambahkan lagi air kira2 300-400ml. Tunggu hingga mendidih. Bisa dites rasa. Kalau kurang manis tambahkan gula pasir secukupnya, sesuai tingkat kemanisan masing2..
			
			
		</li>
	
		<li>
			Lalu masukkan tepung terigu yg sudah dicairkan dengan air. Aduk rata. Masak sebentar. Bubur kacang hijau pun akan jadi kental seperti buburnya abang2 yg jualan di pinggir jalan😋..
			
			
		</li>
	
		<li>
			MASAK SANTAN UNTUK TOPPING KACANG HIJAUNYA. Masukkan santan dalam panci. Tambahkan daun pandan &amp; garam. Lalu masak dengan api kecil saja sebab santan gampang meletup-letup. Tunggu hingga mendidih. Sambil sering2 diaduk agar santan tidak pecah..
			
			
		</li>
	
		<li>
			Siap disajikan🤤😋. Tuang bubur kacang hijau ke dalam mangkok. Lalu siram santan diatasnya. 🤤🤤🤤 Selamat mencoba !!.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this exceptional food bubur kacang hijau kental dan empuk tanpa direndam dulu (metode 5-30-7) recipe. Thank you very much for reading. I'm confident that you can make this at home. There's gonna be more interesting food in home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
