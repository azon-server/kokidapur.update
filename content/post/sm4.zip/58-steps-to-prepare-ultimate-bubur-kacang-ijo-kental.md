---
description: "Steps to Prepare Ultimate Bubur kacang ijo kental"
title: "Steps to Prepare Ultimate Bubur kacang ijo kental"
slug: 58-steps-to-prepare-ultimate-bubur-kacang-ijo-kental

<p>
	<strong>Bubur kacang ijo kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/f6f0240ad3fa4d15/680x482cq70/bubur-kacang-ijo-kental-foto-resep-utama.jpg" alt="Bubur kacang ijo kental" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is John, welcome to our recipe site. Today, I'm gonna show you how to prepare a distinctive dish, bubur kacang ijo kental. One of my favorites. For mine, I will make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang ijo kental is one of the most popular of current trending meals on earth. It is enjoyed by millions daily. It is easy, it's fast, it tastes delicious. They're fine and they look fantastic. Bubur kacang ijo kental is something that I have loved my entire life.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to prepare a few ingredients. You can have bubur kacang ijo kental using 6 ingredients and 4 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo kental:</h3>

<ol>
	
		<li>{Get 1/4 of Kacang Ijo. </li>
	
		<li>{Make ready 1 1/2 bh of Gula merah. </li>
	
		<li>{Take 2 sdm of Gula pasir. </li>
	
		<li>{Prepare secukupnya of Air. </li>
	
		<li>{Make ready 1-2 of daun pandan. </li>
	
		<li>{Prepare 2 sdm of maizena/ 2 sdm tepung terigu. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo kental:</h3>

<ol>
	
		<li>
			Rendam kacang ijo semalaman hingga pagi di panci/baskom.
			
			
		</li>
	
		<li>
			Buang air rendaman semalam, cuci bersih kacang hijau.
			
			
		</li>
	
		<li>
			Rebus kacang hijau hingga mendidih tambahkan gula merah yg sudah disisir)diiris-iris, biarkan menyatu, masukan daun pandan yg diikat menjadi simpul, tambahkan gulapasir, aduk hingga mendidih..
			
			
		</li>
	
		<li>
			Tambahkan tepung maizena/tepung terigu yg sudah dicairkan dgn air, aduk-aduk rata sesekali, biarkan hingga airnya bergejolak. Matikan api kompor. Kacang ijo kental siap dihidangkan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur kacang ijo kental recipe. Thanks so much for your time. I am sure that you can make this at home. There's gonna be more interesting food in home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
