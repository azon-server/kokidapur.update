---
description: "Easiest Way to Make Super Quick Homemade Bubur Kacang ijo"
title: "Easiest Way to Make Super Quick Homemade Bubur Kacang ijo"
slug: 163-easiest-way-to-make-super-quick-homemade-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/c3b41b5d0c910790/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's me again, Dan, welcome to my recipe site. Today, we're going to make a distinctive dish, bubur kacang ijo. It is one of my favorites food recipes. For mine, I'm gonna make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur Kacang ijo is one of the most favored of current trending meals in the world. It's easy, it is fast, it tastes delicious. It is enjoyed by millions every day. Bubur Kacang ijo is something which I've loved my whole life. They are fine and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to first prepare a few ingredients. You can cook bubur kacang ijo using 7 ingredients and 6 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang ijo:</h3>

<ol>
	
		<li>{Get 250 gram of kacang hijau, cuci bersih. Rendam semalaman. </li>
	
		<li>{Get 2 sdm of tepung kanji, dilarutkan dengan air biasa jangan air panas. </li>
	
		<li>{Make ready 1 liter of santan (boleh ditambahkan). </li>
	
		<li>{Get secukupnya of Garam. </li>
	
		<li>{Take  of Daun pandan (kalau tidak ada bisa pakai vanili). </li>
	
		<li>{Make ready  of Gula merah (saya pakai 2 bongkah). </li>
	
		<li>{Make ready secukupnya of Air. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang ijo:</h3>

<ol>
	
		<li>
			Rebus sampai empuk kacang hijau yang sudah direndam. Saya menggunakan api sedang.
			
			
		</li>
	
		<li>
			Selagi menunggu kacang hijau, rebus santan sampai mendidih.Jangan lupa beri garam dan vanili secukupnya. Icip..
			
			
		</li>
	
		<li>
			Kemudian rebus gula merah+garam secukupnya sampai benar-benar cair. Kemudian tuang larutan kanji sedikit demi sedikit..
			
			
		</li>
	
		<li>
			Jika kacang hijau sudah benar-benar empuk, tuang gula merah cair sesuai selera. Jika kurang manis bisa ditambah gula pasir. Jika kurang kental bisa ditambahkan lagi larutan kanjinya. Ingat jika kacang ijo belum empuk jangan dimasukkan gulanya karena nanti hasilnya kacang ijo tidak akan empuk walaupun direbus lama..
			
			
		</li>
	
		<li>
			Siapkan mangkuk/gelas. Tuang kacang hijau siram dengan santan. Bisa ditambahkan roti tawar ataupun es batu..
			
			
		</li>
	
		<li>
			Selamat mencoba 😊.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this special food bubur kacang ijo recipe. Thank you very much for reading. I am sure that you can make this at home. There's gonna be more interesting food at home recipes coming up. Remember to bookmark this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
