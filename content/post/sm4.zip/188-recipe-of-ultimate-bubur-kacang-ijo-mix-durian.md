---
description: "Recipe of Ultimate Bubur Kacang Ijo Mix Durian"
title: "Recipe of Ultimate Bubur Kacang Ijo Mix Durian"
slug: 188-recipe-of-ultimate-bubur-kacang-ijo-mix-durian

<p>
	<strong>Bubur Kacang Ijo Mix Durian</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/1b6e21012f28c909/680x482cq70/bubur-kacang-ijo-mix-durian-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Mix Durian" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, I'm gonna show you how to prepare a special dish, bubur kacang ijo mix durian. It is one of my favorites. This time, I am going to make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo Mix Durian is one of the most popular of current trending meals in the world. It's enjoyed by millions every day. It's simple, it is quick, it tastes yummy. They are nice and they look fantastic. Bubur Kacang Ijo Mix Durian is something that I've loved my whole life.
</p>

<p>
To get started with this particular recipe, we have to first prepare a few ingredients. You can have bubur kacang ijo mix durian using 11 ingredients and 7 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Mix Durian:</h3>

<ol>
	
		<li>{Take 1/5 kg of KACANG IJO (Rendam Selama 1 Malam). </li>
	
		<li>{Prepare 10 Biji of Durian. </li>
	
		<li>{Take 200 ml of Santan Kental. </li>
	
		<li>{Take 5 of SdmTepung Maizena (Larutkan Dengan Air). </li>
	
		<li>{Take 250 gram of Gula Merah. </li>
	
		<li>{Prepare 1/5 Gelas Belimbing of Gula Pasir. </li>
	
		<li>{Take 2 Ruas of Jahe. </li>
	
		<li>{Prepare 4 Lembar of Daun Pandan. </li>
	
		<li>{Take 1 sdt of Vanili Bubuk. </li>
	
		<li>{Make ready 1 sdt of Garam. </li>
	
		<li>{Prepare 3,5 Liter of Air. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo Mix Durian:</h3>

<ol>
	
		<li>
			Didihkan air.
			
			
		</li>
	
		<li>
			Masukkan kacang ijo.
			
			
		</li>
	
		<li>
			Rebus selama 20 menit.
			
			
		</li>
	
		<li>
			Matikan api diamkan selama 20 menit.
			
			
		</li>
	
		<li>
			Masukkkan durian, santan kental, gula merah, gula pasir, jahe, daun pandan, vanili bubuk, garam dan tepung maizena.
			
			
		</li>
	
		<li>
			Rebus kembali selama 5 menit sambil diaduk.
			
			
		</li>
	
		<li>
			Bubur kacang ijo mix durian siap dihidangkan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this special food bubur kacang ijo mix durian recipe. Thanks so much for reading. I am confident you can make this at home. There is gonna be interesting food at home recipes coming up. Remember to bookmark this page on your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
