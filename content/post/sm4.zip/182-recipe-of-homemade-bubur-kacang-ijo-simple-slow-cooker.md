---
description: "Recipe of Homemade Bubur kacang ijo simple slow cooker"
title: "Recipe of Homemade Bubur kacang ijo simple slow cooker"
slug: 182-recipe-of-homemade-bubur-kacang-ijo-simple-slow-cooker

<p>
	<strong>Bubur kacang ijo simple slow cooker</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/fed8aa1fe6047251/680x482cq70/bubur-kacang-ijo-simple-slow-cooker-foto-resep-utama.jpg" alt="Bubur kacang ijo simple slow cooker" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you are having an amazing day today. Today, I'm gonna show you how to make a special dish, bubur kacang ijo simple slow cooker. It is one of my favorites food recipes. For mine, I am going to make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang ijo simple slow cooker is one of the most popular of current trending meals in the world. It is enjoyed by millions every day. It is simple, it's quick, it tastes delicious. Bubur kacang ijo simple slow cooker is something that I've loved my entire life. They are nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we must first prepare a few components. You can have bubur kacang ijo simple slow cooker using 6 ingredients and 4 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo simple slow cooker:</h3>

<ol>
	
		<li>{Get 250 gr of kacang ijo. </li>
	
		<li>{Get 1 lt of air. </li>
	
		<li>{Make ready 100 gr of gula merah, di iris2. </li>
	
		<li>{Take 1 sdt of garam. </li>
	
		<li>{Prepare 2 sachet of SKM (susu kental manis) merk apa aja. </li>
	
		<li>{Take 2 sdm of gula pasir (apabila dirasa kurang manis bisa ditambah). </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo simple slow cooker:</h3>

<ol>
	
		<li>
			Cuci bersih kacang ijo..
			
			
		</li>
	
		<li>
			Setelah 1 jam masukan gula merah yang sudah di iris2, gula pasir, SKM dan garam. Aduk2 sebentar hingga rata..
			
			
		</li>
	
		<li>
			Masukan air ke dalam slow cooker, set high. Masukan kacang ijo yang sudah dicuci bersih..
			
			
		</li>
	
		<li>
			Tunggu sekitar 4 jam, cek kacang ijo apabila sudah dirasa matang nya dan koreksi rasa. Matikan slow cooker. Bubur lacang ijo siap dinikmati..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this special food bubur kacang ijo simple slow cooker recipe. Thank you very much for your time. I am confident that you can make this at home. There is gonna be interesting food in home recipes coming up. Remember to bookmark this page in your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
