---
description: "Easiest Way to Make Quick Bubur Kacang Ijo #PekanInspirasi"
title: "Easiest Way to Make Quick Bubur Kacang Ijo #PekanInspirasi"
slug: 216-easiest-way-to-make-quick-bubur-kacang-ijo-pekaninspirasi

<p>
	<strong>Bubur Kacang Ijo #PekanInspirasi</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/e51bf5754b55373c/680x482cq70/bubur-kacang-ijo-pekaninspirasi-foto-resep-utama.jpg" alt="Bubur Kacang Ijo #PekanInspirasi" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is me again, Dan, welcome to my recipe site. Today, I will show you a way to prepare a special dish, bubur kacang ijo #pekaninspirasi. It is one of my favorites. For mine, I'm gonna make it a bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo #PekanInspirasi is one of the most favored of current trending meals in the world. It is enjoyed by millions daily. It is simple, it is quick, it tastes yummy. They are nice and they look fantastic. Bubur Kacang Ijo #PekanInspirasi is something which I have loved my entire life.
</p>

<p>
To get started with this recipe, we have to first prepare a few ingredients. You can have bubur kacang ijo #pekaninspirasi using 9 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo #PekanInspirasi:</h3>

<ol>
	
		<li>{Take 350 gram of Kacang ijo. </li>
	
		<li>{Take 300 gram of Gula merah (masak dengan air 150 ml). </li>
	
		<li>{Make ready 500 ml of Santan (dari 1 biji kelapa). </li>
	
		<li>{Prepare 3 sdm of Gula pasir. </li>
	
		<li>{Make ready 1 sdt of Garam. </li>
	
		<li>{Take 1/2 sdt of Vanili bubuk (opsional). </li>
	
		<li>{Get 3 lembar of Daun pandan wangi. </li>
	
		<li>{Make ready Secukupnya of Kayu manis. </li>
	
		<li>{Get Secukupnya of Air. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo #PekanInspirasi:</h3>

<ol>
	
		<li>
			Pertama cuci bersih kacang ijo lalu masak dengan air secukupnya sampai kacang ijo pecah dan airnya hampir habis..
			
			
		</li>
	
		<li>
			Untul air gula merah. Masak gula merah dengan 150 ml air. Aduk sesekali agar gula tidak hangus..
			
			
		</li>
	
		<li>
			Setelah kacang ijo dan airnya hampir habis masukkan air gula merah, santan, gula pasir, garam, vanili, kayu manis dan daun pandan..
			
			
		</li>
	
		<li>
			Biarkan mendidih sampai pada kekentalan dan manis yang dinginkan. Silahkan koreksi rasa. Saya masak cukup lama sampai benar-benar kental dan kacang ijo lebih pecah lagi..
			
			
		</li>
	
		<li>
			Bubur kacang ijo siap dinikmati baik hangat maupun dingin😋.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this exceptional food bubur kacang ijo #pekaninspirasi recipe. Thank you very much for your time. I'm sure you can make this at home. There is gonna be more interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
