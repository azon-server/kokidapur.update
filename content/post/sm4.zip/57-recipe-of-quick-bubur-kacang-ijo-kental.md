---
description: "Recipe of Quick Bubur kacang ijo kental"
title: "Recipe of Quick Bubur kacang ijo kental"
slug: 57-recipe-of-quick-bubur-kacang-ijo-kental

<p>
	<strong>Bubur kacang ijo kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/2783e7c152c020bf/680x482cq70/bubur-kacang-ijo-kental-foto-resep-utama.jpg" alt="Bubur kacang ijo kental" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you are having an amazing day today. Today, we're going to prepare a special dish, bubur kacang ijo kental. One of my favorites. For mine, I am going to make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo kental is one of the most well liked of recent trending meals in the world. It is appreciated by millions every day. It's simple, it's fast, it tastes yummy. They're fine and they look wonderful. Bubur kacang ijo kental is something that I have loved my whole life.
</p>

<p>
To get started with this particular recipe, we have to prepare a few components. You can cook bubur kacang ijo kental using 16 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo kental:</h3>

<ol>
	
		<li>{Prepare  of Bahan rebus kacang hijau :. </li>
	
		<li>{Take 250 g of kacang hijau, rendam semalaman. </li>
	
		<li>{Get 1 of daun pandan, ikat pita. </li>
	
		<li>{Take 500 ml of air. </li>
	
		<li>{Make ready 2 of kotak/bulart gula merah. </li>
	
		<li>{Take 1 sdm of gula pasir. </li>
	
		<li>{Prepare 1 sdt of garam. </li>
	
		<li>{Get 1 ruas jempol of jahe, geprek. </li>
	
		<li>{Make ready  of Bahan santan kental:. </li>
	
		<li>{Make ready 1 bungkus of santan kara. </li>
	
		<li>{Take 200 ml of air. </li>
	
		<li>{Take 1 helai of daun pandan, ikat pita. </li>
	
		<li>{Get 1 sdm of tepung maizena. </li>
	
		<li>{Make ready 1 sdm of air. </li>
	
		<li>{Prepare 1 sdt of garam. </li>
	
		<li>{Take 2 sdt of gula pasir. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo kental:</h3>

<ol>
	
		<li>
			Rendam kacang hijau semalaman. Lalu cuci bersih, rebus dengan air.
			
			
		</li>
	
		<li>
			Masukkan gula merah, gula pasir, daun pandan, garam dan jahe.
			
			
		</li>
	
		<li>
			Campur 1 kara kecil dangan air 200ml, rebus, setelah aga panas, masukkan daun pandan, garam dan gula..
			
			
		</li>
	
		<li>
			Aduk agar tidak pecah santan. Masukkan tepung maizena yg sudah dilarutkan dengan 1sdm air. Aduk hingga kental. Angkat dinginkan.
			
			
		</li>
	
		<li>
			Campur bubur kacang ijo dengan santan kental sesuai selere.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur kacang ijo kental recipe. Thank you very much for reading. I'm sure that you can make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
