---
description: "Simple Way to Make Award-winning Bubur kacang ijo gula jawa"
title: "Simple Way to Make Award-winning Bubur kacang ijo gula jawa"
slug: 145-simple-way-to-make-award-winning-bubur-kacang-ijo-gula-jawa

<p>
	<strong>Bubur kacang ijo gula jawa</strong>. 
	Bubur Kacang Ijo adalah makanan berbahan utama kacang hijau yang biasa dikonsumsi oleh masyarakat Indonesia. Pembuatan bubur kacang ijo ini tiada lain untuk berbagi pengalaman dan siapa tau bisa menjadi infirasi untuk peluang usaha. Biasanya bubur kacang hijau memiliki cita rasa yang manis dan gurih.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/adadc86ce0d5cf91/680x482cq70/bubur-kacang-ijo-gula-jawa-foto-resep-utama.jpg" alt="Bubur kacang ijo gula jawa" style="width: 100%;">
	
	
		Curug Ciputrawangi Tepatnya berada di Desa Narimbang, Kecamatan Conggeang, Sumedang, Jawa Barat.
	
		Kacang yang udah disangrai secukupnya (kalo alergi ya jangan pakai ini yah).
	
		Cara Memasak : Cuci bersih kacang hijau lalu rebus sampai mendidih, diamkan.
	
</p>
<p>
	Hello everybody, it's Drew, welcome to my recipe page. Today, I'm gonna show you how to prepare a distinctive dish, bubur kacang ijo gula jawa. It is one of my favorites. For mine, I will make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo adalah makanan berbahan utama kacang hijau yang biasa dikonsumsi oleh masyarakat Indonesia. Pembuatan bubur kacang ijo ini tiada lain untuk berbagi pengalaman dan siapa tau bisa menjadi infirasi untuk peluang usaha. Biasanya bubur kacang hijau memiliki cita rasa yang manis dan gurih.
</p>
<p>
	Bubur kacang ijo gula jawa is one of the most favored of current trending meals on earth. It is simple, it is fast, it tastes delicious. It's enjoyed by millions daily. Bubur kacang ijo gula jawa is something that I have loved my entire life. They are nice and they look fantastic.
</p>

<p>
To get started with this recipe, we have to first prepare a few components. You can cook bubur kacang ijo gula jawa using 5 ingredients and 4 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo gula jawa:</h3>

<ol>
	
		<li>{Make ready 250 g of kacang ijo. </li>
	
		<li>{Take 1800 ml of air untuk merebus. </li>
	
		<li>{Prepare 8-9 sdm of gula Jawa/boleh d tambah kl kurang manis (sisir halus). </li>
	
		<li>{Prepare 3-4 lembar of daun pandan(simpulkan). </li>
	
		<li>{Make ready 150 ml of santan kental. </li>
	
</ol>
<p>
	
		Resep Bubur Kacang Hijau Enak dan Spesial.
	
		Cara bikin bubur kacang hijau / ijo memerlukan trik dan tips tersendiri, sehingga hasilnya bisa lebih bagus dan juga enak serta lembut.
	
		Sebenarnya tidak ada yang istimewa saat anda membuat penganan bubur kacang hijau ini.
	
		Namun demikian jika dilihat dari kandungan gizinya.
	
</p>

<h3>Instructions to make Bubur kacang ijo gula jawa:</h3>

<ol>
	
		<li>
			Cuci bersih kacang ijo nya lalu rendam 1-2 jam biar mekar dan rebusnya gk terlalu lama.
			
			
		</li>
	
		<li>
			Setelah cukup waktu,buang air rendaman siapkan panci untuk merebus,didihkan air dan masukan kacang ijo juga pandan,biarkan air mendidih lagi lalu tutup jangan terlalu rapat,kecilkan apinya...rebus hingga air menyusut dan kacang ijo nya lunak.
			
			
		</li>
	
		<li>
			Setelah di rasa sudah mengental,aduk&#34;tambahkan gula,boleh di tambahkan 1/2 sdt garam biar sedap,aduk rata koreksi rasanya,masukan santan aduk&#34; hingga mendidih,kalau bisa jangan sampai pecah kiranya sudah mendidih cepat matikan apinya(terimakasih buat yg komplin sudah mengingatkan santanya lupa di tambahkan🤣,maaf ngetiknya keburu pengen makan bubur).
			
			
		</li>
	
		<li>
			Bubur kacang ijo gula jawa..siap di bagikan😘👍.
			
			
		</li>
	
</ol>

<p>
	
		Bubur kacang hijau khas Kota Madura, Provinsi Jawa Timur merupakan salah satu bubur kacang hijau yang banyak peminatnya.
	
		Resep Bubur Kacang Hijau Dan Ketan Hitam Lebih Cepat Hemat Bahan Bakar Bahan-bahannya : Gula Merah jahe garam.
	
		Rebus kacang hijau bersama air sampai empuk dan air.
	
		Bubur kacang hijau bisa dibikin tanpa santan, kuah cukup pakai air dan gula merah.
	
		Kacang hijau direbus sampai empuk dengan daun pandan.
	
</p>

<p>
	So that's going to wrap it up for this special food bubur kacang ijo gula jawa recipe. Thank you very much for reading. I'm sure that you can make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to save this page in your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
