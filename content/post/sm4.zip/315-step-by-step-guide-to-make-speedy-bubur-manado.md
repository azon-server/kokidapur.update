---
description: "Step-by-Step Guide to Make Speedy Bubur manado"
title: "Step-by-Step Guide to Make Speedy Bubur manado"
slug: 315-step-by-step-guide-to-make-speedy-bubur-manado

<p>
	<strong>Bubur manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/dfc06241c32e88c5/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur manado" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you're having an amazing day today. Today, I will show you a way to make a distinctive dish, bubur manado. It is one of my favorites food recipes. This time, I am going to make it a little bit unique. This will be really delicious.
</p>
	
<p>
	Bubur manado is one of the most popular of recent trending foods in the world. It is easy, it's quick, it tastes delicious. It is appreciated by millions every day. Bubur manado is something that I have loved my whole life. They're fine and they look fantastic.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we must first prepare a few ingredients. You can have bubur manado using 14 ingredients and 5 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur manado:</h3>

<ol>
	
		<li>{Get 1 liter of beras. </li>
	
		<li>{Make ready 2 ikat of kangkung. </li>
	
		<li>{Take 2 ikat of bayam. </li>
	
		<li>{Take segenggam of daun kemangi. </li>
	
		<li>{Take 5 gerai of kacang panjang. </li>
	
		<li>{Take 3 buah of jagung. </li>
	
		<li>{Prepare secukupnya of Labu. </li>
	
		<li>{Make ready  of Untuk bumbu ;. </li>
	
		<li>{Prepare 2 sachet of masako ayam. </li>
	
		<li>{Get 1 sdm of garam dan vetsin. </li>
	
		<li>{Make ready 2 btg of sereh. </li>
	
		<li>{Prepare 1/2 sdm of merica bubuk. </li>
	
		<li>{Take 3 butir of bawang merah. </li>
	
		<li>{Take 3 butir of bawang putih. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur manado:</h3>

<ol>
	
		<li>
			Cuci bersih beras ... siapkan panci 5 liter , masukkan beras isi dgn 3 liter air biarkan nasi menjadi bubur jangan lupa diaduk agar buburnya tdk gosong..
			
			
		</li>
	
		<li>
			Potong bayam,kangkung dan kemangi sisihkan . Potong kacang panjang 2 cm , potong kotak labu , dan iris iris jagung tp cuci dlu ya . Sayuran lain jg cuci hingga bersih dan masing2 sisihkan ..
			
			
		</li>
	
		<li>
			Buat bumbunya ,, potong tipis2 sereh lalu tumbuk , bersama bawang putih dan merah . Tumbuk hingga halus ... lalu siapkan wajan masukkan 2 sdm minyak lalu tumis bumbu td dan tambahkan merica tumis hingga wangi ..
			
			
		</li>
	
		<li>
			Nah sekarang apabila nasi telah menjadi bubur barulah masukkan satu persatu mulai dari labu , jagung ;  jika labu sudah lembek barulah disusul kacang panjang lalu  bumbu yg tlh ditumis , masako , garam dan vetsin . aduk dulu hingga rata jika dirasa kurang bisa ditambah penyedap apa saja sesuai selera. Nah lanjut jika rasa sudah pas terakhir masukkan daunnya . Jika daun sudah layu maka itu tandax bubur sudah matang ..
			
			
		</li>
	
		<li>
			Matikan kompor sajikan diatas mangkok . Makanlah bersama ikan kering dan sambel ... emmm enak.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this exceptional food bubur manado recipe. Thank you very much for your time. I am sure you can make this at home. There is gonna be interesting food in home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
