---
description: "Steps to Prepare Homemade Bubur Kacang Ijo 5.30.7"
title: "Steps to Prepare Homemade Bubur Kacang Ijo 5.30.7"
slug: 171-steps-to-prepare-homemade-bubur-kacang-ijo-5307

<p>
	<strong>Bubur Kacang Ijo 5.30.7</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/cd21d4ceb5d049b4/680x482cq70/bubur-kacang-ijo-5307-foto-resep-utama.jpg" alt="Bubur Kacang Ijo 5.30.7" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is me, Dave, welcome to my recipe site. Today, I'm gonna show you how to prepare a distinctive dish, bubur kacang ijo 5.30.7. It is one of my favorites food recipes. This time, I am going to make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo 5.30.7 is one of the most well liked of recent trending foods on earth. It is easy, it is fast, it tastes delicious. It is appreciated by millions every day. They're nice and they look wonderful. Bubur Kacang Ijo 5.30.7 is something that I have loved my entire life.
</p>

<p>
To get started with this particular recipe, we must first prepare a few components. You can have bubur kacang ijo 5.30.7 using 8 ingredients and 4 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo 5.30.7:</h3>

<ol>
	
		<li>{Get 250 gr of kacang hijau. </li>
	
		<li>{Take 200 gr of gula merah. </li>
	
		<li>{Get 50 gr of gula pasir. </li>
	
		<li>{Get 1/2 sdt of garam. </li>
	
		<li>{Get 1 L of air. </li>
	
		<li>{Make ready 500 ml of santan (kara segitiga+air). </li>
	
		<li>{Make ready 2 ruas of jahe memarkan. </li>
	
		<li>{Get 1 sdt of tepung beras. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo 5.30.7:</h3>

<ol>
	
		<li>
			Rendam kacang hijau dg air panas kurleb 15 menit. Lalu rebus di atas kompor 5menit. Matikan api diamkan 30 menit dg panci tertutup. Ini kacang hijaunya setelah didiamkan 30menit..
			
			
		</li>
	
		<li>
			Masak gula merah dengan air 100ml hingga benar2 larut. Kemudian saring..
			
			
		</li>
	
		<li>
			Masukkan gula merah cair, gula pasir, jahe dan garam aduk rata. Masak hingga 7 menit setelah mendidih. Masukkan santan aduk2 agar tidak pecah. Matikan api..
			
			
		</li>
	
		<li>
			Saya yang separo saa kasih tepung beras supaya kental..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this special food bubur kacang ijo 5.30.7 recipe. Thanks so much for reading. I'm confident that you will make this at home. There's gonna be interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
