---
description: "Simple Way to Make Award-winning 505. Bubur Kacang Hijau Kental Gurih"
title: "Simple Way to Make Award-winning 505. Bubur Kacang Hijau Kental Gurih"
slug: 18-simple-way-to-make-award-winning-505-bubur-kacang-hijau-kental-gurih

<p>
	<strong>505. Bubur Kacang Hijau Kental Gurih</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/8b073b2d52538d2d/680x482cq70/505-bubur-kacang-hijau-kental-gurih-foto-resep-utama.jpg" alt="505. Bubur Kacang Hijau Kental Gurih" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, we're going to make a special dish, 505. bubur kacang hijau kental gurih. One of my favorites. For mine, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	505. Bubur Kacang Hijau Kental Gurih is one of the most favored of recent trending meals on earth. It's easy, it is quick, it tastes delicious. It is appreciated by millions every day. 505. Bubur Kacang Hijau Kental Gurih is something which I have loved my entire life. They're nice and they look fantastic.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to first prepare a few components. You can cook 505. bubur kacang hijau kental gurih using 10 ingredients and 5 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make 505. Bubur Kacang Hijau Kental Gurih:</h3>

<ol>
	
		<li>{Make ready 150 gram of Kacang hijau. </li>
	
		<li>{Take 1,5 liter of Air. </li>
	
		<li>{Get 130 ml of Santan siap pakai. </li>
	
		<li>{Get 3 keping of Gula jawa. </li>
	
		<li>{Get 4 sdm of Gula pasir. </li>
	
		<li>{Prepare 2 lembar of Daun pandan; simpulkan. </li>
	
		<li>{Make ready 1 ruas of Jahe; bakar, geprek. </li>
	
		<li>{Make ready 1 sdt of Garam. </li>
	
		<li>{Make ready Sepucuk sdt of Perisa vanilla. </li>
	
		<li>{Get 3 sdm of Tepung maizena; larutkan. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make 505. Bubur Kacang Hijau Kental Gurih:</h3>

<ol>
	
		<li>
			Siapkan bahan-bahannya. Cuci bersih kacang hijau. Siapkan juga larutan Maizena..
			
			
		</li>
	
		<li>
			Rebus Air hingga mendidih. Setelah mendidih, baru masukkan Kacang hijau. Rebus hingga mendidih kembali, tambah 5 menit lagi, lalu matikan api dan tutup pancinya. Kemudian diamkan selama 30 menit..
			
			
		</li>
	
		<li>
			Setelah itu, buka tutup panci, nyalakan api dan Kacang hijau tidak lama akan mekar. Kemudian masukkan Daun pandan, Jahe, Perisa vanilla, Gula jawa, Gula pasir, serta Garam, aduk rata, tes rasa. Setelah mendidih kembali, kecilkan api, lalu masukkan Santan. Aduk rata..
			
			
		</li>
	
		<li>
			Terakhir, masukkan larutan Maizena lalu aduk-aduk sampai agak berubah kental. Angkat..
			
			
		</li>
	
		<li>
			Bubur Kacang Hijau yang kental dan gurih pun siap disantap. Selamat mencoba 🙏😊.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this exceptional food 505. bubur kacang hijau kental gurih recipe. Thanks so much for your time. I'm confident you can make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
