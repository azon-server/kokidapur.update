---
description: "Recipe of Award-winning Bubur Kacang Ijo Kental"
title: "Recipe of Award-winning Bubur Kacang Ijo Kental"
slug: 8-recipe-of-award-winning-bubur-kacang-ijo-kental

<p>
	<strong>Bubur Kacang Ijo Kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/1a3f93f5bd6b660c/680x482cq70/bubur-kacang-ijo-kental-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Kental" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you're having an incredible day today. Today, we're going to prepare a special dish, bubur kacang ijo kental. One of my favorites food recipes. For mine, I am going to make it a little bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo Kental is one of the most well liked of recent trending meals in the world. It is simple, it is fast, it tastes delicious. It is enjoyed by millions every day. They're nice and they look wonderful. Bubur Kacang Ijo Kental is something which I've loved my whole life.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we must first prepare a few components. You can have bubur kacang ijo kental using 10 ingredients and 7 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Kental:</h3>

<ol>
	
		<li>{Prepare 250 gram of kacang hijau. </li>
	
		<li>{Make ready 5 cm of jahe. </li>
	
		<li>{Get 1200 ml of air. </li>
	
		<li>{Take 10 sdm of gula pasir (sesuai selera, bisa lebih atau kurang). </li>
	
		<li>{Get 1 sdt of garam. </li>
	
		<li>{Prepare 2 sdm of tepung maizena / tepung tapioka. </li>
	
		<li>{Prepare  of Saus santan:. </li>
	
		<li>{Prepare 65 of santan instan. </li>
	
		<li>{Make ready 200 ml of air. </li>
	
		<li>{Take Sejumput of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo Kental:</h3>

<ol>
	
		<li>
			Rendam kacang hijau dengan air minimal sejam, ini saya rendam 6 jam, bisa juga semalaman atau sehari. Direndam lama agar kacang hijau nanti empuk pada saat dimasak, direndam dengan banyak air ya biar nanti kacang hijaunya tidak jadi kecambah. Setelag direndam, cuci bersih lalu tiriskan..
			
			
		</li>
	
		<li>
			Rebus kacang hijau yang telah direndam dan dicuci bersih dengan 1200ml air dan 5cm jahe yang sudah digeprek..
			
			
		</li>
	
		<li>
			Setelah air sedikit menyusut, masukkan 10sdm gula dan 1 sdt garam lalu aduk rata. Masak sambil diaduk sesekali agak kacang hijau tidak mengerak di dasar panci..
			
			
		</li>
	
		<li>
			Larutkan 2sdm tepung maizena dengan sedikit air..
			
			
		</li>
	
		<li>
			Setelah kacang hijau airnya sudah hampir menyusut dan hampir jadi bubur seperti di foto pertama, masukkan larutan maizena dan aduk terus sampai mengental seperti foto ketiga lalu matikan api..
			
			
		</li>
	
		<li>
			Rebus 65ml santan kental dengan 200ml air dan sejumput garam, aduk terus saat merebus agar santan tidak pecah. Rebus sampai benar-benar mendidih lalu matikan api..
			
			
		</li>
	
		<li>
			Taruh bubur kacang hijau di mangkok lalu tuang sedikit saus santan dan bubur kental kacang hijau siap dinikmati hangat atau bisa juga ditambah dengan es batu..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this special food bubur kacang ijo kental recipe. Thank you very much for your time. I'm sure that you will make this at home. There is gonna be more interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
