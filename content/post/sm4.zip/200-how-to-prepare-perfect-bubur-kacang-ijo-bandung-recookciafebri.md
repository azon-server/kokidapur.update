---
description: "How to Prepare Perfect Bubur Kacang Ijo #Bandung_RecookCiaFebri"
title: "How to Prepare Perfect Bubur Kacang Ijo #Bandung_RecookCiaFebri"
slug: 200-how-to-prepare-perfect-bubur-kacang-ijo-bandung-recookciafebri

<p>
	<strong>Bubur Kacang Ijo #Bandung_RecookCiaFebri</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/fd81092e7f47a2fc/680x482cq70/bubur-kacang-ijo-bandung_recookciafebri-foto-resep-utama.jpg" alt="Bubur Kacang Ijo #Bandung_RecookCiaFebri" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Louise, welcome to my recipe page. Today, we're going to make a distinctive dish, bubur kacang ijo #bandung_recookciafebri. It is one of my favorites. This time, I am going to make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo #Bandung_RecookCiaFebri is one of the most popular of recent trending foods on earth. It is appreciated by millions daily. It's easy, it is quick, it tastes delicious. Bubur Kacang Ijo #Bandung_RecookCiaFebri is something which I've loved my whole life. They're fine and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we must first prepare a few components. You can cook bubur kacang ijo #bandung_recookciafebri using 10 ingredients and 7 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo #Bandung_RecookCiaFebri:</h3>

<ol>
	
		<li>{Get 500 gr of kacang ijo, rendam semalaman, cuci bersih. </li>
	
		<li>{Prepare 2 ltr of air. </li>
	
		<li>{Get 5 lbr of daun pandan. </li>
	
		<li>{Get 1 sachet of vanili bubuk. </li>
	
		<li>{Get Sejumput of garam. </li>
	
		<li>{Take 2 ruas of jahe, kupas. </li>
	
		<li>{Make ready  of Cengkeh dan kayu manis (jika suka). </li>
	
		<li>{Take sesuai selera of Gula pasir. </li>
	
		<li>{Prepare 3 gandu of kecil gula merah. </li>
	
		<li>{Get 2 bks of sanran instan uk 65 ml. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo #Bandung_RecookCiaFebri:</h3>

<ol>
	
		<li>
			Cuci bersih kacang ijo yg sudah direndam semalaman.
			
			
		</li>
	
		<li>
			Siapkan bahan lainnya.
			
			
		</li>
	
		<li>
			Masak kacang ijo dgn air yg sudah disiapkan, masukan garam, vanili, jahe dan daun pandan, masak hingga kacang empuk.
			
			
		</li>
	
		<li>
			Tambahkan gula merah dan gula pasir, aduk rata hingga gula larut, koreksi rasa.
			
			
		</li>
	
		<li>
			Tuang dalam wadah saji, kucuri dgn santan kental.
			
			
		</li>
	
		<li>
			Sajikan dgn potongan nangka diatasnya.
			
			
		</li>
	
		<li>
			Yummy...
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur kacang ijo #bandung_recookciafebri recipe. Thank you very much for your time. I'm sure you will make this at home. There is gonna be more interesting food in home recipes coming up. Remember to bookmark this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
