---
description: "Recipe of Perfect Bubur kacang ijo dan ketan item"
title: "Recipe of Perfect Bubur kacang ijo dan ketan item"
slug: 164-recipe-of-perfect-bubur-kacang-ijo-dan-ketan-item

<p>
	<strong>Bubur kacang ijo dan ketan item</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/bdd8e5705419d01d/680x482cq70/bubur-kacang-ijo-dan-ketan-item-foto-resep-utama.jpg" alt="Bubur kacang ijo dan ketan item" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's John, welcome to my recipe site. Today, I'm gonna show you how to make a special dish, bubur kacang ijo dan ketan item. It is one of my favorites. For mine, I will make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo dan ketan item is one of the most favored of recent trending foods on earth. It is easy, it is quick, it tastes yummy. It's appreciated by millions daily. Bubur kacang ijo dan ketan item is something that I've loved my whole life. They are nice and they look fantastic.
</p>

<p>
To get started with this particular recipe, we must prepare a few ingredients. You can have bubur kacang ijo dan ketan item using 9 ingredients and 5 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo dan ketan item:</h3>

<ol>
	
		<li>{Get 250 gr of kacang hijau. </li>
	
		<li>{Make ready 250 gr of ketan hitam. </li>
	
		<li>{Get 200 gr of gula merah. </li>
	
		<li>{Take 2 sdm of tepung maizena. </li>
	
		<li>{Take 2 sachet of santan instan (pake sun kata). </li>
	
		<li>{Prepare 200 gr of gula pasir. </li>
	
		<li>{Take 3 potong of daun pandan. </li>
	
		<li>{Get 1500 lt of air. </li>
	
		<li>{Take 3 sdm of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo dan ketan item:</h3>

<ol>
	
		<li>
			Sebelum membuat kacang hijau dan ketan hitam. Baiknya rendam dulu semalaman atau kurleb 5jam dgn air masing2 500 cc/ml. Setelah di rendam. Buang air rendaman, lalu cuci.
			
			
		</li>
	
		<li>
			Utk membuat kacang hijau yg bagus msh utuh, tdk pecah, dan empuk. Begini cara membuatnya: Rebus kacang hijau dgn air 500cc kurleb 7menit tambahkan gula merah, tepung maizena (yg sblmnya sdh dicairkan dgn 20 cc air) masukan 1 potong daun pandan. Rebus hingga mendidih dgn api sedang dan jangan lupa aduk2. Matikan api. Diamkan 20 menit dgn wadah tertutup. Lalu masak kembali 3menit hingga agak kental. Tes rasa.
			
			
		</li>
	
		<li>
			Utk membuat ketan hitam. Rebus ketan hitam dgn 500 cc/ml air. Tambahkan gula dan 1 potong daun pandan. Aduk2 hingga mendidih. Masak dgn api sedang kurleb 7menit. Matikan api. Diamkan 20 menit dgn wadah tertutup. Rebus lagi selama 3menit. Hingga agak kental. Tes rasa.
			
			
		</li>
	
		<li>
			Utk membuat santan. Cukup buka sach santan instan. Tambahkan 500 cc air, 3 sdm garam dan 1 potong daun pandan. Rebus dgn api sedang. Aduk2 kurleb 5menit hingga mendidih. Jgn lupa aduk2 supaya santan tidak pecah..
			
			
		</li>
	
		<li>
			Dari sini dapat 3 bahan dalam wadah berbeda. Ada kacang hijau, ketan hitam, santan. Jika mau makan cemilan ini. Ambil satu wadah. Ambil masing2 bahan dgn sedok sesuai selera. Bisa di sajikan dalam kondisi hangat atau dingin jg sesuai selera. Selamat makan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this special food bubur kacang ijo dan ketan item recipe. Thank you very much for reading. I am confident you can make this at home. There is gonna be interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
