---
description: "How to Prepare Any-night-of-the-week Bubur Manado ala Aliya"
title: "How to Prepare Any-night-of-the-week Bubur Manado ala Aliya"
slug: 309-how-to-prepare-any-night-of-the-week-bubur-manado-ala-aliya

<p>
	<strong>Bubur Manado ala Aliya</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/c076827faed06bf7/680x482cq70/bubur-manado-ala-aliya-foto-resep-utama.jpg" alt="Bubur Manado ala Aliya" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you're having an incredible day today. Today, we're going to prepare a special dish, bubur manado ala aliya. One of my favorites. For mine, I am going to make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Manado ala Aliya is one of the most favored of recent trending foods on earth. It is appreciated by millions daily. It is easy, it is fast, it tastes yummy. Bubur Manado ala Aliya is something that I've loved my entire life. They are fine and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we must first prepare a few components. You can cook bubur manado ala aliya using 11 ingredients and 4 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Manado ala Aliya:</h3>

<ol>
	
		<li>{Take 3 gelas kecil of beras putih. </li>
	
		<li>{Make ready secukupnya of air buat masak nasi bubur. </li>
	
		<li>{Get 1 buah of jagung (diserut). </li>
	
		<li>{Take 3 batang of bayam. </li>
	
		<li>{Make ready 1 batang of serai. </li>
	
		<li>{Prepare 3 siung of bawang putih dihaluskan. </li>
	
		<li>{Make ready 1/4 buah of labu kuning potong dadu. </li>
	
		<li>{Get 1/2 kantong of kecil ikan teri di goreng kering (untuk akhir). </li>
	
		<li>{Get 2 siung of bawang merah (untuk sambel). </li>
	
		<li>{Make ready 4 buah of cabe merah (untuk sambel). </li>
	
		<li>{Take 2 buah of cabe rawit orange (untuk sambel). </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado ala Aliya:</h3>

<ol>
	
		<li>
			Siapkan rice cooker, masukan nasi, labu, jagung, yang sudah dipotong, masukan bayam, serai, semua bahan sayuran, tambahkan air 2x takaran biasanya untuk menjadikan tekstur bubur. Jangan lupa masukan garam dan lada, gula sedikit..
			
			
		</li>
	
		<li>
			Sambil menunggu, kita buat teri goreng dan sambal yah. untuk teri digoreng kering seperti biasa..
			
			
		</li>
	
		<li>
			Untuk sambal diblender kasar, bawang merah, cabe merah dan cabe rawit orang tambahkan garam sedikit, lalu goreng sebentar..
			
			
		</li>
	
		<li>
			Setelah kurang lebih 15 menit buka rice cooker, ini belum matang, namun boleh kita aduk dua kali, lalu tutup kembali tunggu sekitar 10 menit. taste it, kalau sudah yummy, tinggal ditata dan hidangkan :).
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this special food bubur manado ala aliya recipe. Thank you very much for reading. I'm sure that you will make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to save this page in your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
