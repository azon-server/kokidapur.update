---
description: "Recipe of Quick Bubur Kacang ijo sagu lempeng"
title: "Recipe of Quick Bubur Kacang ijo sagu lempeng"
slug: 208-recipe-of-quick-bubur-kacang-ijo-sagu-lempeng

<p>
	<strong>Bubur Kacang ijo sagu lempeng</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/ef10bef7150aaadf/680x482cq70/bubur-kacang-ijo-sagu-lempeng-foto-resep-utama.jpg" alt="Bubur Kacang ijo sagu lempeng" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you're having an incredible day today. Today, we're going to make a special dish, bubur kacang ijo sagu lempeng. It is one of my favorites. For mine, I will make it a bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur Kacang ijo sagu lempeng is one of the most well liked of current trending meals on earth. It is simple, it's fast, it tastes delicious. It's appreciated by millions daily. Bubur Kacang ijo sagu lempeng is something which I have loved my entire life. They are fine and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we must first prepare a few components. You can have bubur kacang ijo sagu lempeng using 7 ingredients and 6 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang ijo sagu lempeng:</h3>

<ol>
	
		<li>{Prepare 1/4 kg of kacang ijo rendam 2jam. </li>
	
		<li>{Make ready 2 of sagu lempeng. </li>
	
		<li>{Take 1 liter of santan kental. </li>
	
		<li>{Prepare  of Gula merah sesuai rasa dan kebutuhan. </li>
	
		<li>{Prepare secukupnya of Garam. </li>
	
		<li>{Make ready  of Air. </li>
	
		<li>{Prepare 1 lbr of daun pandan/vanili secukupnya. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang ijo sagu lempeng:</h3>

<ol>
	
		<li>
			Didihkan air lalu masak kacang ijo yang sudah direndam hingga matang/lunak dan airnya berkurang.
			
			
		</li>
	
		<li>
			Rendam sagu lempeng dengan air dingin, yang tadinya padat hingga menjadi butiran-butiran kecil saring lalu tiriskan.
			
			
		</li>
	
		<li>
			Setelah kacang ijonya sudah lunak masukkan sagu lempeng, santan kental,gula merah sambil diaduk agar santan tidak pecah dan sagu lempeng tidak lengket di panci.
			
			
		</li>
	
		<li>
			Masukkan daun pandan yang sudah disimpul dan beri garam secukupnya.
			
			
		</li>
	
		<li>
			Masak hingga mendidih dan gula merah larut,lalu angkat.
			
			
		</li>
	
		<li>
			Sajikan,.bila suka boleh tambahkan susu kental manis.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this special food bubur kacang ijo sagu lempeng recipe. Thanks so much for your time. I am sure that you will make this at home. There is gonna be more interesting food at home recipes coming up. Remember to save this page in your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
