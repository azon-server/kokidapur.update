---
description: "Recipe of Favorite Bubur Kacang Ijo &amp;amp; Ketan Item"
title: "Recipe of Favorite Bubur Kacang Ijo &amp;amp; Ketan Item"
slug: 69-recipe-of-favorite-bubur-kacang-ijo-and-amp-ketan-item

<p>
	<strong>Bubur Kacang Ijo &amp; Ketan Item</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/ae3c7b86a4ccd5dd/680x482cq70/bubur-kacang-ijo-ketan-item-foto-resep-utama.jpg" alt="Bubur Kacang Ijo &amp; Ketan Item" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you are having an amazing day today. Today, I will show you a way to prepare a distinctive dish, bubur kacang ijo &amp; ketan item. One of my favorites food recipes. This time, I will make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo &amp; Ketan Item is one of the most favored of current trending meals in the world. It's appreciated by millions every day. It is easy, it's quick, it tastes delicious. Bubur Kacang Ijo &amp; Ketan Item is something which I've loved my entire life. They are fine and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to prepare a few ingredients. You can cook bubur kacang ijo &amp; ketan item using 23 ingredients and 4 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo &amp; Ketan Item:</h3>

<ol>
	
		<li>{Prepare  of Bubur Kacang hijau. </li>
	
		<li>{Take 250 gr of kacang hijau rendam 3 jam. </li>
	
		<li>{Make ready 3 of daun pandan simpulkan. </li>
	
		<li>{Get 1,5 liter of air. </li>
	
		<li>{Get 3 balok of gula merah (150 gr) atau sesuai selera. </li>
	
		<li>{Get 7 sdm of gula pasir atau sesuai selera. </li>
	
		<li>{Prepare  of Vanilla essence. </li>
	
		<li>{Take  of Pandan essence. </li>
	
		<li>{Make ready  of Garam. </li>
	
		<li>{Prepare  of Tepung tapioka secukupnya untuk dilarutkan dalam air. </li>
	
		<li>{Get  of Bubur Ketan Hitam. </li>
	
		<li>{Make ready 1,5 genggam of ketan hitam rendam 3 jam. </li>
	
		<li>{Get 700 ml of air. </li>
	
		<li>{Get  of Garam. </li>
	
		<li>{Prepare  of Tapioka secukupnya untuk dilarutkan dlam air. </li>
	
		<li>{Take 1 of daun pandan simpulkan. </li>
	
		<li>{Prepare 4 sdm of gula pasir atau sesuai selera. </li>
	
		<li>{Make ready 2-3 sdm of Santan. </li>
	
		<li>{Prepare  of Kuah Santan. </li>
	
		<li>{Make ready 100 ml of santan kental campur dengan 300ml air. </li>
	
		<li>{Prepare  of Garam. </li>
	
		<li>{Get 1 of daun pandan simpulkan. </li>
	
		<li>{Take  of Maizena secukupnya larutkan dalam air. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo &amp; Ketan Item:</h3>

<ol>
	
		<li>
			Bubur kacang ijo : rebus dalam panci 5 menit kacang hijau. Matikan api. Diamkan selama 30 menit dalam keadaan panci tertutup. Setelah 30 menit masak lg bubur kacang hijau, masukkan garam, daun pandan, vanilla essence, pandan essence, gula merah dan gula pasir. Masak selama 7 menit atau setelah agak asat, masukkan larutan tapioka. Aduk. Matikan api. Sisihkan.
			
			
		</li>
	
		<li>
			Bubur ketan hitam: rebus selama 5 menit ketan hitam. Matikan api diamkan 30 menit dlm keadaan panci tertutup. Setelah 30 menit masak kembali ketan hitam tambahkan bahan lainnya kecuali tapioka; selama 7 menit. Setelah ketan masak dan air agak asat masukkan larutan tapioka. Aduk. Matikan api. Sisihkan..
			
			
		</li>
	
		<li>
			Kuah santan: masak semua bahan hingga mendidih kecuali larutan maizena. Setelah mendidih masukkan larutan maizena, aduk. Matikan api..
			
			
		</li>
	
		<li>
			Sajikan bubur kacang hijau, ketan hitam dan siram kuah santan diatasnya..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this special food bubur kacang ijo &amp; ketan item recipe. Thanks so much for your time. I'm sure that you can make this at home. There is gonna be interesting food in home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
