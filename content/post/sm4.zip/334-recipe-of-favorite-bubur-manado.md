---
description: "Recipe of Favorite Bubur Manado"
title: "Recipe of Favorite Bubur Manado"
slug: 334-recipe-of-favorite-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/8f57d5c06a1e9565/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, we're going to make a distinctive dish, bubur manado. One of my favorites. For mine, I am going to make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Manado is one of the most favored of recent trending meals in the world. It's appreciated by millions daily. It's easy, it is fast, it tastes yummy. Bubur Manado is something which I have loved my entire life. They're fine and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we must first prepare a few components. You can have bubur manado using 6 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Prepare 1 cup of beras dicuci bersih. </li>
	
		<li>{Get 2 buah of jagung diserut. </li>
	
		<li>{Prepare 1 iris of labu kuning (ikutin bentuk potongan buah memanjang). </li>
	
		<li>{Make ready 2 buah of ubi jalar. </li>
	
		<li>{Prepare  of Sayuran hijau=kacang panjang,daun katuk,kangkung, kemangi. </li>
	
		<li>{Prepare 3 batang of sereh diambil putihnya saja, digeprek. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Manado:</h3>

<ol>
	
		<li>
			Rebus semua bahan jadi 1 kecuali sayuran ya. Tambahkan sereh geprek. Aduk2 dan tunggu sampai mendidih ya.
			
			
		</li>
	
		<li>
			Kalau labu dan ubi sudah empuk, angkat dan haluskan di wadah lain. Kemudian balikin ke panci lagi, satukan kembali, aduk kembali.
			
			
		</li>
	
		<li>
			Aduk terus hingga rasa kuning dari labu merata. Cek kekentalan air..kalau terlalu kental, tambahkan air (ini selera yaa), tambahkan garam, gula dan penyedap rasa.
			
			
		</li>
	
		<li>
			Masukkan sayur 1 persatu, langkah pertama, kacang panjang, aduk lagi. Kemudian daun katuk, kangkung, terakhir kemangi, agar aromanya semakin oke dan wangi..
			
			
		</li>
	
		<li>
			Aduk sampai mendidih... Siap dihidangkan dengan tambahan ikan asin, atau bilis, atau teri dan sambel terasi. Uhhh bakal lupa mertua deh makan ini 😉 selamat mencobaaa. #jelajahResepSayuranHijau.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur manado recipe. Thank you very much for reading. I am sure you can make this at home. There's gonna be interesting food in home recipes coming up. Remember to bookmark this page in your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
