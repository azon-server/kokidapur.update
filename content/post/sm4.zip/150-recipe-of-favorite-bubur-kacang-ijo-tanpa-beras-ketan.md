---
description: "Recipe of Favorite Bubur kacang ijo tanpa beras ketan"
title: "Recipe of Favorite Bubur kacang ijo tanpa beras ketan"
slug: 150-recipe-of-favorite-bubur-kacang-ijo-tanpa-beras-ketan

<p>
	<strong>Bubur kacang ijo tanpa beras ketan</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/af79f26e036f8e25/680x482cq70/bubur-kacang-ijo-tanpa-beras-ketan-foto-resep-utama.jpg" alt="Bubur kacang ijo tanpa beras ketan" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Drew, welcome to my recipe page. Today, I will show you a way to make a special dish, bubur kacang ijo tanpa beras ketan. One of my favorites food recipes. For mine, I'm gonna make it a little bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo tanpa beras ketan is one of the most favored of current trending meals in the world. It's appreciated by millions daily. It is easy, it is quick, it tastes yummy. They're nice and they look wonderful. Bubur kacang ijo tanpa beras ketan is something that I've loved my entire life.
</p>

<p>
To begin with this particular recipe, we have to first prepare a few components. You can have bubur kacang ijo tanpa beras ketan using 12 ingredients and 5 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo tanpa beras ketan:</h3>

<ol>
	
		<li>{Make ready 1 liter of kacang ijo (sy dapat 786 gram). </li>
	
		<li>{Get Secukupnya of kayu manis batang. </li>
	
		<li>{Get 3 liter of air bersih. </li>
	
		<li>{Get  of Air gula :. </li>
	
		<li>{Make ready 200 gram of gula merah yg sudah di sisir halus. </li>
	
		<li>{Prepare 300 gram of gula pasir(jika suka manis boleh ditambah). </li>
	
		<li>{Prepare 100 ml of air bersih. </li>
	
		<li>{Take  of Adonan santan :. </li>
	
		<li>{Make ready 1 butir of kelapa parut tua yang di peras sarinya dengan air bersih. </li>
	
		<li>{Take  of Hingga menghasilkan +- 1.500 ml air santan kental. </li>
	
		<li>{Make ready 3 gram of garam halus. </li>
	
		<li>{Prepare 10 gram of tepung maizena. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo tanpa beras ketan:</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau lalu masak dengan air sebanyak 1.500 ml air bersih hingga mendidih jika sudah mendidih biarkan selama 5 mnt setelah 5 menit matikan kompor lalu tutup rapat panci diamkan selama 30 menit..
			
			
		</li>
	
		<li>
			30 menit kemudian buka tutup panci lalu nyalakan kembali kompor dan tambahkan lagi air bersih sebanyak 1.500 ml lalu masak kembali hingga mendidih..
			
			
		</li>
	
		<li>
			Larutkan gula merah, gula pasir dan kayu manis batang dengan air hingga gula larut semua lalu saring dan sisihkan. Peras kelapa parut lalu tambahkan tepung maizena dan garam halus. Sisihkan..
			
			
		</li>
	
		<li>
			Jika kacang hijau sudah lunak/matang masukkan larutan air gula dan aduk rata. Masak hingga air gula meresap dan sesekali di aduk agar bagian bawah tidak gosong. Gunakan api sedang..
			
			
		</li>
	
		<li>
			Air santan yang sudah di siapkan boleh di masak terpisah atau boleh langsung dicampur kedalam rebusan kacang hijau. Aduk rata hingga semua bahan tercampur. Selesai. Bisa disajikan dingin atau panas..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this special food bubur kacang ijo tanpa beras ketan recipe. Thanks so much for your time. I am sure that you will make this at home. There's gonna be interesting food at home recipes coming up. Remember to bookmark this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
