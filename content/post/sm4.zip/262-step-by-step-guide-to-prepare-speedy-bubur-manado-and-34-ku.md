---
description: "Step-by-Step Guide to Prepare Speedy Bubur Manado&amp;#34;KU"
title: "Step-by-Step Guide to Prepare Speedy Bubur Manado&amp;#34;KU"
slug: 262-step-by-step-guide-to-prepare-speedy-bubur-manado-and-34-ku

<p>
	<strong>Bubur Manado&#34;KU</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/b3e8ed65199f93e7/680x482cq70/bubur-manadoku-foto-resep-utama.jpg" alt="Bubur Manado&#34;KU" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is me, Dave, welcome to our recipe page. Today, I'm gonna show you how to prepare a distinctive dish, bubur manado&#34;ku. It is one of my favorites. For mine, I am going to make it a bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur Manado&#34;KU is one of the most popular of recent trending foods on earth. It's easy, it's quick, it tastes yummy. It is enjoyed by millions every day. They're nice and they look wonderful. Bubur Manado&#34;KU is something which I've loved my whole life.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we must prepare a few components. You can have bubur manado&#34;ku using 14 ingredients and 7 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Manado&#34;KU:</h3>

<ol>
	
		<li>{Get  of Bahan-Bahan :. </li>
	
		<li>{Get 2 Biji of Jagung Uk.Besar. </li>
	
		<li>{Take 2 Biji of Ubi Jalar Uk.Besar. </li>
	
		<li>{Prepare  of Labu Kuning Uk.Sesuai Selera. </li>
	
		<li>{Take 1/2 Liter of Beras. </li>
	
		<li>{Get 1 Ikat of Kangkung. </li>
	
		<li>{Prepare 2 ikat of Kacang Panjang Muda/Segar. </li>
	
		<li>{Prepare Secukupnya of Kemangi. </li>
	
		<li>{Make ready 1 btg of Sereh. </li>
	
		<li>{Make ready 2 Sachet of Masako Ayam. </li>
	
		<li>{Make ready 1 Sachet of Ladaku. </li>
	
		<li>{Get Sejumput of Garam Halus. </li>
	
		<li>{Get Sejumput of Micin. </li>
	
		<li>{Prepare 3 Gayung of Air Bersih. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Manado&#34;KU:</h3>

<ol>
	
		<li>
			Tahap I : Kupas dan Cuci bersih Jagung, Ubi Jalar dan Labu Kuning...Kemudian Ubi Jalar dan Labu Kuning potong kotak Uk.Sedang.. Jagung di serut halus pke pisau serutan kemudian bagi 2 dlm wadah terpisah sesuai fotoku yaa Bund....
			
			
		</li>
	
		<li>
			Kangkung dan Kacang Panjang di potong potong agak sedikit besar...kemudian cuci bersih yaa...Lihat Fotoku Say..hiii.hiii..Pisahkan Daun Kemangi dri batangnya kemudian Cuci bersih....
			
			
		</li>
	
		<li>
			Tahap.II : Sediakan Panci Uk.Sedang/Agak Besar....Cuci bersih beras Aku 2x Cuci buang air,,kemudian yang ke 3 gak usah buang air Jgn lupa bacakan Surah Al Kautsar 3x spy masakannya enak Aamiinn..Beras masukkan dlm panci + Air bersih sekitar 2 Gayung..Gayungku Uk.ini yaa Bunda&#34; Say....
			
			
		</li>
	
		<li>
			Tahap.III : Nyalain kompor api sedang cenderung kecil + ambil Serutan Jagung 1 wadah tadi kemudian masukkan ke panci..Masak bersama beras...waktunya sekitar 20 menit atau tekstur sdh agak lembek..Bunda sering&#34; aduk ya pakai sendok kayu yg panjang biar aman gak kena panas...klo sdh terlihat agak lembek, masukkan Ubi Jalarnya...aduk lg +Micin +Sereh n gak usah di tutup pancinya yaa....
			
			
		</li>
	
		<li>
			Masak sampai tekstur Ubi Jalarnya agak lembek/matang, +Masukkan Labu Kuning +Masako 2 Sachet +Ladaku 1/2 Sachet aja...Aduk terus bunda n TEST RASA..klo msh kurang asin masukkan sejumput garam halus bisa skep..Jgn lupa di aduk ow iya bunda klo terlihat air dah mengental bunda tambahin air matang lagi biar gak mengental banget sekitar secukupnya aja klo aku sukanya gak kental banget jadi aku tambahin 1 gayung air matang lagi..krn saat mulai dingin akan memgental juga koq.
			
			
		</li>
	
		<li>
			Masak sekitar 5 menit atau tekstur labu sdh matang,,Kemudian masukkan campuran sayur tadi +daun kemangi..Masak dan aduk terus bunda...
			
			
		</li>
	
		<li>
			Tahap Akhir : Masak bubur manado ini harus sering di jagain yaa dan sering di aduk biar gak gosog..hiii.hii.hii...Aku masak bubur ini sekitar 1 jam gitu deh..Maaf untuk Lauknya Perkedel Jagung dan Sambelnya di pisahin resep selanjutnya yaa...Okay Bunda&#34; Syantik..Jadi deh Bubur Manadonya...Cepat dan Sederhana gak ribet bahannya...Inshaa Allah Bermanfaat dan Enak...COOKPAD MANTUL.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this exceptional food bubur manado&#34;ku recipe. Thanks so much for your time. I'm sure you will make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
