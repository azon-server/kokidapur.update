---
description: "Recipe of Any-night-of-the-week 54. Bubur kacang ijo kental"
title: "Recipe of Any-night-of-the-week 54. Bubur kacang ijo kental"
slug: 10-recipe-of-any-night-of-the-week-54-bubur-kacang-ijo-kental

<p>
	<strong>54. Bubur kacang ijo kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/cdefb25f0afc3cfb/680x482cq70/54-bubur-kacang-ijo-kental-foto-resep-utama.jpg" alt="54. Bubur kacang ijo kental" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an incredible day today. Today, I'm gonna show you how to make a special dish, 54. bubur kacang ijo kental. One of my favorites. For mine, I am going to make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	54. Bubur kacang ijo kental is one of the most popular of current trending foods on earth. It is easy, it is quick, it tastes delicious. It's enjoyed by millions daily. They're nice and they look wonderful. 54. Bubur kacang ijo kental is something that I've loved my whole life.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we must prepare a few components. You can have 54. bubur kacang ijo kental using 9 ingredients and 5 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make 54. Bubur kacang ijo kental:</h3>

<ol>
	
		<li>{Make ready 250 gr of kacang ijo. </li>
	
		<li>{Get 1 lt of air. </li>
	
		<li>{Prepare 4 keping of gula merah. </li>
	
		<li>{Get  of Gula pasir. </li>
	
		<li>{Take  of Garam. </li>
	
		<li>{Take 2 sachet of santan kara. </li>
	
		<li>{Take  of Daun pandan. </li>
	
		<li>{Take  of Jahe geprak. </li>
	
		<li>{Get 3 sdm of tepung kanji larutkan dng sedikit air. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make 54. Bubur kacang ijo kental:</h3>

<ol>
	
		<li>
			Rebus air sampai mendidih, masukkan kacang ijo yg sdh di rendam semlm, rebus selama 5 menit.
			
			
		</li>
	
		<li>
			Matikan kompor dan tunggu sampe 30 menit, panci ditutup.
			
			
		</li>
	
		<li>
			Setelah 30 menit nyalakan kompor dan rebus kacang ijo kembali selama 7 menit.
			
			
		</li>
	
		<li>
			Setelah direbus 7 menit masukkan gula merah, jahe dan gula pasir tambahkan sedikit garam, larutkan tepung kanji dan masukkan dlm rebusan kacang ijo aduk rata dan didihkan.
			
			
		</li>
	
		<li>
			Untuk kuah santan, rebus 2 sachet kara dng 250 ml air tambahkan daun pandan dan sedikit garam.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this special food 54. bubur kacang ijo kental recipe. Thank you very much for your time. I am sure that you will make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
