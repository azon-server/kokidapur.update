---
description: "How to Make Speedy Bubur kacang hijau kental"
title: "How to Make Speedy Bubur kacang hijau kental"
slug: 39-how-to-make-speedy-bubur-kacang-hijau-kental

<p>
	<strong>Bubur kacang hijau kental</strong>. 
	Resep Rahasia Bubur Kacang Hijau Kental Dan Enak, bubur kacang hijau, resep bubur kacang hijau, bubur kacang hijau lezat, bubur kacang ijo seperti tukang. Ada bubur ayam, bubur sumsum, bubur mutiara, bubur kacang hijau dan banyak lainnya. Bubur kacang hijau, abbreviated burjo, is a Southeast Asian sweet porridge (bubur) made from mung beans (kacang hijau), coconut milk, and palm sugar or cane sugar.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/364798f216b98b68/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur kacang hijau kental" style="width: 100%;">
	
	
		Mau buka puasa begini enaknya kita buat Bubur Kacang.
	
		Bahan kacang hijau kental: Membuat bubur ketan hitam Bubur kacang hijau di hidangkan selagi masih hangat, kemudian siram dengan santan gurih.
	
		Tambahkan santan kental, masak hingga kacang hijau empuk.
	
</p>
<p>
	Hello everybody, hope you're having an incredible day today. Today, we're going to prepare a distinctive dish, bubur kacang hijau kental. It is one of my favorites. This time, I'm gonna make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang hijau kental is one of the most popular of current trending foods on earth. It is easy, it's quick, it tastes yummy. It's enjoyed by millions daily. They're fine and they look wonderful. Bubur kacang hijau kental is something that I have loved my entire life.
</p>
<p>
	Resep Rahasia Bubur Kacang Hijau Kental Dan Enak, bubur kacang hijau, resep bubur kacang hijau, bubur kacang hijau lezat, bubur kacang ijo seperti tukang. Ada bubur ayam, bubur sumsum, bubur mutiara, bubur kacang hijau dan banyak lainnya. Bubur kacang hijau, abbreviated burjo, is a Southeast Asian sweet porridge (bubur) made from mung beans (kacang hijau), coconut milk, and palm sugar or cane sugar.
</p>

<p>
To get started with this recipe, we have to first prepare a few ingredients. You can have bubur kacang hijau kental using 7 ingredients and 4 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang hijau kental:</h3>

<ol>
	
		<li>{Take 250 gram of kacang hijau. </li>
	
		<li>{Make ready 3 sdm of tepung beras. </li>
	
		<li>{Take 2 keping of Gula merah. </li>
	
		<li>{Take 4 sdm of Gula pasir. </li>
	
		<li>{Take 1 of Santan Kara kecil. </li>
	
		<li>{Take  of Garam. </li>
	
		<li>{Get 2 of Daun pandan. </li>
	
</ol>
<p>
	
		Angkat, sajikan dalam keadaan hanggar bersama potongan roti tawar.
	
		Resep bubur kacang hijau kental baik dengan santan maupun bubur kacang hijau tanpa santan.
	
		Bubur kacang hijau termasuk dalam resep jajanan tradisional yang sangat terkenal sejak puluhan tahun silam.
	
		Bahkan sering kita lihat pedagang bubur kacang hijau keliling dengan sepeda lewat di.
	
</p>

<h3>Steps to make Bubur kacang hijau kental:</h3>

<ol>
	
		<li>
			Rendam selama 3 jam lalu Rebus,masukkan daun pandan.
			
			
		</li>
	
		<li>
			Siapkan gula nya, masukkan ke dalam rebusan kacang hijau.
			
			
		</li>
	
		<li>
			Campur tepung beras + air, aduk2 lalu tuang kepanci.aduk2 masak hingga kacang hijau matang.skitar 30 menit.
			
			
		</li>
	
		<li>
			Masak santan Kara+ air lalu tambahkan sedikit garam lalu aduk..
			
			
		</li>
	
</ol>

<p>
	
		Bubur kacang hijau termasuk sajian nikmat keluarga.
	
		Cara Membuat Bubur Kacang Hijau Ketan Hitam: Kacang hijau, rebus kacang hijau, air, dan daun pandan sampai matang dan mekar.
	
		Sisihkan. rebus beras ketan hitam bersama daun pandan.
	
		Bubur kacang hijau adalah salah satu menu sarapan atau larut malam yang populer di Indonesia.
	
		Masak bubur kacang hijau gak perlu lama-lama lho.
	
</p>

<p>
	So that is going to wrap this up with this special food bubur kacang hijau kental recipe. Thanks so much for reading. I am confident that you will make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to save this page in your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
