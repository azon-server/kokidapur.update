---
description: "Easiest Way to Make Quick Bubur kacang ijo"
title: "Easiest Way to Make Quick Bubur kacang ijo"
slug: 204-easiest-way-to-make-quick-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/7c019ea20ae2ef23/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you are having an incredible day today. Today, we're going to make a special dish, bubur kacang ijo. It is one of my favorites. For mine, I will make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo is one of the most popular of recent trending meals in the world. It's enjoyed by millions daily. It is easy, it's quick, it tastes yummy. Bubur kacang ijo is something which I have loved my whole life. They are nice and they look wonderful.
</p>

<p>
To get started with this recipe, we must prepare a few components. You can have bubur kacang ijo using 8 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Prepare 250 gram of kacang ijo. </li>
	
		<li>{Make ready Segenggam of beras rendam sebentar.tiriskan. </li>
	
		<li>{Prepare 1200 ml of air. </li>
	
		<li>{Take 2 ruas jari of jahe geprek. </li>
	
		<li>{Prepare 800 ml of santan kental. </li>
	
		<li>{Take 1 sdt of garam halus. </li>
	
		<li>{Make ready 200 gram of gula merah. </li>
	
		<li>{Prepare 100 gram of gula pasir. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Rendam kacang ijo selama 8 jam atau dari malam sampai pagi.cuci bersih.
			
			
		</li>
	
		<li>
			Masak kacang ijo dan beras kedalam panci tambahkan 1200 ml air dan jahe.
			
			
		</li>
	
		<li>
			Setelah kacang ijo empuk masukan gula merah dan gula pasir.aduj rata sampai gula hancur.
			
			
		</li>
	
		<li>
			Tambahkan santan dan garam.biarkan sampai santan mendidih masukan garam.
			
			
		</li>
	
		<li>
			Angkat sajikan.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this special food bubur kacang ijo recipe. Thank you very much for your time. I am confident you can make this at home. There is gonna be more interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
