---
description: "Easiest Way to Make Quick Bubur kacang hijau &amp;amp; ketan hitam kental"
title: "Easiest Way to Make Quick Bubur kacang hijau &amp;amp; ketan hitam kental"
slug: 38-easiest-way-to-make-quick-bubur-kacang-hijau-and-amp-ketan-hitam-kental

<p>
	<strong>Bubur kacang hijau &amp; ketan hitam kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/12eb697723d65cfb/680x482cq70/bubur-kacang-hijau-ketan-hitam-kental-foto-resep-utama.jpg" alt="Bubur kacang hijau &amp; ketan hitam kental" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is me again, Dan, welcome to our recipe page. Today, we're going to prepare a distinctive dish, bubur kacang hijau &amp; ketan hitam kental. It is one of my favorites food recipes. For mine, I will make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur kacang hijau &amp; ketan hitam kental is one of the most popular of current trending meals in the world. It's enjoyed by millions every day. It's simple, it's fast, it tastes yummy. Bubur kacang hijau &amp; ketan hitam kental is something that I have loved my whole life. They are fine and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we must first prepare a few ingredients. You can cook bubur kacang hijau &amp; ketan hitam kental using 10 ingredients and 4 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang hijau &amp; ketan hitam kental:</h3>

<ol>
	
		<li>{Take 1/4 of kacang hijau. </li>
	
		<li>{Take 1/4 of ketan hitam. </li>
	
		<li>{Get 10 sendok of gula pasir (sesuai selera ya). </li>
	
		<li>{Take 2 iris of jahe. </li>
	
		<li>{Prepare  of Daun pandan. </li>
	
		<li>{Take 2 sdm of Tepung maizena. </li>
	
		<li>{Make ready  of Santan. </li>
	
		<li>{Take  of Garam. </li>
	
		<li>{Get secukupnya of Air. </li>
	
		<li>{Make ready  of Pakai gula merah juga gpp. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang hijau &amp; ketan hitam kental:</h3>

<ol>
	
		<li>
			Cuci ketan hitam + kacang hijau 3kali. Sampai bener2 bersih..
			
			
		</li>
	
		<li>
			Lalu rebus 10 menit di air mendidih, dan diamkan +- 30 menit, biar hemat LPG 😁.
			
			
		</li>
	
		<li>
			Sembari menunggu 30 menit, bisa memasak santan ya, masak santan dengan daun pandan, taburkan garam sedikit. Rebut sampai mendidih.
			
			
		</li>
	
		<li>
			Setelah 30 menit. Lalu nyalakan kompor, dan masukan daun pandan, jahe, garam sedikit, gula merah / putih ya. Lalu rebus lagi +- 10 menit lagi ya.. Atau sampai empuk yg diinginkan. Setelah empuk tambahkan tepung maizena, lalu jangan lupa diaduk2 sampai +- 2 menit. Lalu siap dihidangkan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this special food bubur kacang hijau &amp; ketan hitam kental recipe. Thanks so much for your time. I am sure you can make this at home. There is gonna be more interesting food in home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
