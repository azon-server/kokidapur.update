---
description: "Steps to Make Ultimate Bubur kacang ijo jahe"
title: "Steps to Make Ultimate Bubur kacang ijo jahe"
slug: 88-steps-to-make-ultimate-bubur-kacang-ijo-jahe

<p>
	<strong>Bubur kacang ijo jahe</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/17d780a35b4693e6/680x482cq70/bubur-kacang-ijo-jahe-foto-resep-utama.jpg" alt="Bubur kacang ijo jahe" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you're having an amazing day today. Today, I'm gonna show you how to prepare a distinctive dish, bubur kacang ijo jahe. One of my favorites. This time, I will make it a bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo jahe is one of the most favored of recent trending foods in the world. It's easy, it's quick, it tastes yummy. It's appreciated by millions every day. Bubur kacang ijo jahe is something that I have loved my whole life. They are fine and they look fantastic.
</p>

<p>
To get started with this recipe, we must first prepare a few components. You can cook bubur kacang ijo jahe using 14 ingredients and 6 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo jahe:</h3>

<ol>
	
		<li>{Get 150 g of kacang hijau. </li>
	
		<li>{Make ready 1500 ml of air. </li>
	
		<li>{Take 2 lembar of daun pandan. </li>
	
		<li>{Take 150 g of gula aren. </li>
	
		<li>{Get 3 sdm of gula pasir. </li>
	
		<li>{Make ready 1/2 sdt of garam. </li>
	
		<li>{Make ready 1 buah of jahe, bakar, geprek. </li>
	
		<li>{Prepare 2 sdm of tepung tapioka. </li>
	
		<li>{Get 30 ml of air. </li>
	
		<li>{Make ready  of Bahan Santan ::. </li>
	
		<li>{Make ready 65 ml of santan kental. </li>
	
		<li>{Take 100 ml of air. </li>
	
		<li>{Make ready 1/4 sdt of garam. </li>
	
		<li>{Make ready 1 lembar of daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo jahe:</h3>

<ol>
	
		<li>
			Cuci kacang hijau hingga bersih, rendam dengan air panas selama 3 jam (hingga mengembang)..
			
			
		</li>
	
		<li>
			Rebus air hingga mendidih, tambahkan daun pandan, masukkan kacang hijau (airnya tidak dimasukkan). Masak hingga kacang hijau pecah..
			
			
		</li>
	
		<li>
			Masukkan jahe geprek, aduk rata. Tambahkan gula aren, gula pasir dan garam. Aduk hingga rata dan gula larut..
			
			
		</li>
	
		<li>
			Larutkan tapioka dengan air, aduk rata, tuang dalam bubur. Masak hingga bubur mengental..
			
			
		</li>
	
		<li>
			Campur santan dan air, garam serta pandan. Masak hingga santan mendidih sambil terus diaduk..
			
			
		</li>
	
		<li>
			Hidangkan bubur dengan santan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this special food bubur kacang ijo jahe recipe. Thanks so much for your time. I'm confident you can make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to save this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
