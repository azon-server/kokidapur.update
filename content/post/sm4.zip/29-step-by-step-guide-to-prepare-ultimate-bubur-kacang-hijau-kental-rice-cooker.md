---
description: "Step-by-Step Guide to Prepare Ultimate Bubur kacang hijau kental rice cooker"
title: "Step-by-Step Guide to Prepare Ultimate Bubur kacang hijau kental rice cooker"
slug: 29-step-by-step-guide-to-prepare-ultimate-bubur-kacang-hijau-kental-rice-cooker

<p>
	<strong>Bubur kacang hijau kental rice cooker</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/49f877862d71a83a/680x482cq70/bubur-kacang-hijau-kental-rice-cooker-foto-resep-utama.jpg" alt="Bubur kacang hijau kental rice cooker" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you're having an incredible day today. Today, I'm gonna show you how to prepare a distinctive dish, bubur kacang hijau kental rice cooker. It is one of my favorites food recipes. This time, I'm gonna make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang hijau kental rice cooker is one of the most popular of current trending foods on earth. It is appreciated by millions every day. It is easy, it's fast, it tastes yummy. Bubur kacang hijau kental rice cooker is something that I have loved my whole life. They are nice and they look wonderful.
</p>

<p>
To get started with this particular recipe, we have to prepare a few ingredients. You can have bubur kacang hijau kental rice cooker using 8 ingredients and 9 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang hijau kental rice cooker:</h3>

<ol>
	
		<li>{Prepare  of Kacang hijau. </li>
	
		<li>{Get  of Air. </li>
	
		<li>{Take  of Gula merah secukupnya, disisir. </li>
	
		<li>{Make ready 10 sdm of gula pasir. </li>
	
		<li>{Take Sejumput of garam. </li>
	
		<li>{Take 1 bks kecil of vanili. </li>
	
		<li>{Make ready 1 bks of santan instan kecil. </li>
	
		<li>{Make ready 1 sdm of maizena yg dicampur dg 2 sdm air. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang hijau kental rice cooker:</h3>

<ol>
	
		<li>
			Siapkan semua bahan.
			
			
		</li>
	
		<li>
			Cuci bersih kacang hijau.
			
			
		</li>
	
		<li>
			Masukkan kacang hijau ke loyang rice cooker dg ditambah 750ml air (sesuaikan dg banyaknya kacang ijo).
			
			
		</li>
	
		<li>
			Masak di rice cooker sampai kacang ijo mekar (tp hrs di cek juga sblm itu, takut air nya udh habis malah jd kering ke loyang nya) klo air udh habis tp kacang ijo blm mekar boleh di tambah lagi airnya selama proses &#39;cook&#39;.
			
			
		</li>
	
		<li>
			Jika air habis tambah lagi air secukupnya, biasanya air jd menyusut, aduk2.
			
			
		</li>
	
		<li>
			Klik tombol &#39;cook&#39; sambil masukkan Gula merah, gula pasir, garam, vanili, aduk2, tes rasa.
			
			
		</li>
	
		<li>
			Masukkan santan instan sambil terus diaduk supaya santan engga pecah.
			
			
		</li>
	
		<li>
			Jika sudah mendidih, masukkan maizena yg sdh dilarutkan dg air, aduk2.
			
			
		</li>
	
		<li>
			Tunggu sebentar, alhamdulillah sudah jadi burcang kental nya. Makin sedap dimakan pas buka puasa😋😍.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this exceptional food bubur kacang hijau kental rice cooker recipe. Thanks so much for your time. I am confident you will make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
