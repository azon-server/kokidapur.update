---
description: "Simple Way to Make Speedy Bubur Kacang Ijo"
title: "Simple Way to Make Speedy Bubur Kacang Ijo"
slug: 132-simple-way-to-make-speedy-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/82a7c0afefdaf4eb/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is Louise, welcome to my recipe site. Today, I will show you a way to make a special dish, bubur kacang ijo. One of my favorites. For mine, I'm gonna make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo is one of the most favored of recent trending foods on earth. It is easy, it is quick, it tastes delicious. It is appreciated by millions every day. Bubur Kacang Ijo is something that I have loved my whole life. They're fine and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we have to prepare a few components. You can have bubur kacang ijo using 14 ingredients and 4 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Make ready 250 gr of kacang ijo (rendam semaleman) saya dr jam 10 di msk jam 8. </li>
	
		<li>{Take 3 butir kecil of gula merah. </li>
	
		<li>{Take 2 lbr of daunpandan. </li>
	
		<li>{Make ready 1 sdt of garam. </li>
	
		<li>{Take 3 sdm of gula pasir (sesuai selera). </li>
	
		<li>{Prepare 850 ml of air (bisa dikira2 ya sendiri). </li>
	
		<li>{Prepare 1 ruas of jahe (geprek). </li>
	
		<li>{Prepare  of Santan :. </li>
	
		<li>{Take 1 of sct kara kecil. </li>
	
		<li>{Get 400 ml of air. </li>
	
		<li>{Prepare 2 lbr of daun pandan. </li>
	
		<li>{Prepare 1/2 sdt of garam. </li>
	
		<li>{Prepare 1 sdm of maizena (klo mau lbh kental bs 2 sdm). </li>
	
		<li>{Get 3 sdm of gula pasir. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Masukan air,kacang ijo,jahe dan daun pandan rebus smp mendidih.
			
			
		</li>
	
		<li>
			Apabila sdh mendidih masukan gula merah (sisir dulu ya biar cpt cair) dan gula pasir rebus lagi smp mendidih dan kacang ijo empuk aduk.
			
			
		</li>
	
		<li>
			Untuk santan: masukan air dan santan, beri garam dan gula pasir,daun pandan dan maizena aduk terus smp mendidih...
			
			
		</li>
	
		<li>
			Cara penyajian : siap kan mangkong ambil bubur kacang ijonya dan tuang santan nya.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this special food bubur kacang ijo recipe. Thank you very much for your time. I am sure that you will make this at home. There is gonna be more interesting food in home recipes coming up. Remember to bookmark this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
