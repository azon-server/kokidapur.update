---
description: "Step-by-Step Guide to Prepare Speedy Bubur Kacang Hijau Kental"
title: "Step-by-Step Guide to Prepare Speedy Bubur Kacang Hijau Kental"
slug: 59-step-by-step-guide-to-prepare-speedy-bubur-kacang-hijau-kental

<p>
	<strong>Bubur Kacang Hijau Kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/313493646246918e/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's Drew, welcome to my recipe page. Today, I'm gonna show you how to prepare a distinctive dish, bubur kacang hijau kental. It is one of my favorites food recipes. This time, I am going to make it a bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Hijau Kental is one of the most well liked of current trending foods in the world. It's enjoyed by millions daily. It is simple, it's fast, it tastes yummy. They are fine and they look fantastic. Bubur Kacang Hijau Kental is something which I've loved my whole life.
</p>

<p>
To get started with this particular recipe, we have to first prepare a few ingredients. You can have bubur kacang hijau kental using 8 ingredients and 7 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>{Prepare 2 ons of kacang hijau. </li>
	
		<li>{Get 10 cm of jahe. </li>
	
		<li>{Take 2 lembar of daun pandan. </li>
	
		<li>{Get 1 saset of kecil vanili. </li>
	
		<li>{Take 12 sdm of gula pasir atau gula jawa. </li>
	
		<li>{Make ready 4 sdm of tepung tapioka. </li>
	
		<li>{Get 4 gelas of santan kental. </li>
	
		<li>{Make ready Secukupnya of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>
			Cuci dan rendam kacang hijau semalaman..
			
			
		</li>
	
		<li>
			Didihkan 5 gelas air, masukkan kacang yang sdh direndam..
			
			
		</li>
	
		<li>
			Tambahkan 1sdt garam, vanili, jahe yang sudah digeprek dan gula pasir atau gula jawa. Rebus selama 30-40 menit..
			
			
		</li>
	
		<li>
			Cairkan tepung tapioka dengan 1 gelas air..
			
			
		</li>
	
		<li>
			Masukkan cairan tepung tapioka ke rebusan kacang hijaubyang sudah lunak, aduk2 sampai meletup letup..
			
			
		</li>
	
		<li>
			Didihkan santan dengan menambahkan sejimpit garam dan daun pandan, aduk2 ketika merebusnya jgn sampai pecah. Dinginkan..
			
			
		</li>
	
		<li>
			Sajikan bubur kacang hijau dengan menyiramkan sedikit santan kental ke bubur. Selamat mencoba 😊😊.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this special food bubur kacang hijau kental recipe. Thank you very much for reading. I am confident you can make this at home. There's gonna be interesting food in home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
