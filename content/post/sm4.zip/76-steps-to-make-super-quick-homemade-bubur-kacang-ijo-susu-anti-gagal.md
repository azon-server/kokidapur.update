---
description: "Steps to Make Super Quick Homemade Bubur Kacang Ijo Susu Anti Gagal"
title: "Steps to Make Super Quick Homemade Bubur Kacang Ijo Susu Anti Gagal"
slug: 76-steps-to-make-super-quick-homemade-bubur-kacang-ijo-susu-anti-gagal

<p>
	<strong>Bubur Kacang Ijo Susu Anti Gagal</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/ea4eb8d424ad6cb5/680x482cq70/bubur-kacang-ijo-susu-anti-gagal-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Susu Anti Gagal" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Jim, welcome to my recipe site. Today, I'm gonna show you how to prepare a distinctive dish, bubur kacang ijo susu anti gagal. One of my favorites. For mine, I'm gonna make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo Susu Anti Gagal is one of the most favored of current trending meals on earth. It's easy, it is quick, it tastes delicious. It is appreciated by millions every day. They are fine and they look wonderful. Bubur Kacang Ijo Susu Anti Gagal is something that I've loved my whole life.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we must prepare a few components. You can have bubur kacang ijo susu anti gagal using 6 ingredients and 7 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Susu Anti Gagal:</h3>

<ol>
	
		<li>{Take 200 gr of kacang hijau. </li>
	
		<li>{Take 4 balok of gula merah. </li>
	
		<li>{Take 0,5 sdm of garam. </li>
	
		<li>{Take 200 ml of santan instan (kalau aku pake SASA). </li>
	
		<li>{Make ready 1 lembar of daun pandan. </li>
	
		<li>{Make ready 2 sachet of susu kental manis. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo Susu Anti Gagal:</h3>

<ol>
	
		<li>
			Rendam kacang hijau kurang lebih 30-45 menit (supaya nanti lebih cepet pecah saat dimasak).
			
			
		</li>
	
		<li>
			Setelah 30 menit, panaskan air 500-600ml sampai mendidih.
			
			
		</li>
	
		<li>
			Kemudian, masukkan kacang hijau ke air yang sudah mendidih, rebus bersama garam, gula merah dan daun pandan yang sudah disimpulkan. Rebus hingga kacang hijau matang dan air rebusan mulai berkurang.
			
			
		</li>
	
		<li>
			Setelah kacang hijau matang, masukan santan instan yang dilarutkan ke dalam air panas 200ml.(bisa disesuaikan dengan kekentalan yang diinginkan).
			
			
		</li>
	
		<li>
			Aduk terus agar santan tidak pecah, masak hingga kurang lebih 10 menit..
			
			
		</li>
	
		<li>
			Bubur siap dihidangkan. Sengaja bubur dibuat tidak terlalu manis karena saat dihidangkan nanti akan ditambahkan kental manis di atasnya..
			
			
		</li>
	
		<li>
			Selamat menikmati:). Gampang dong..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this special food bubur kacang ijo susu anti gagal recipe. Thank you very much for your time. I'm sure you can make this at home. There's gonna be interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
