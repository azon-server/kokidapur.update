---
description: "Recipe of Award-winning Bubur Manado (Tinutuan)"
title: "Recipe of Award-winning Bubur Manado (Tinutuan)"
slug: 451-recipe-of-award-winning-bubur-manado-tinutuan

<p>
	<strong>Bubur Manado (Tinutuan)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/d9c4ff0e93723e70/680x482cq70/bubur-manado-tinutuan-foto-resep-utama.jpg" alt="Bubur Manado (Tinutuan)" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's me, Dave, welcome to our recipe site. Today, I will show you a way to make a special dish, bubur manado (tinutuan). One of my favorites. This time, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Manado (Tinutuan) is one of the most favored of current trending foods on earth. It's easy, it is quick, it tastes yummy. It is enjoyed by millions daily. They're fine and they look wonderful. Bubur Manado (Tinutuan) is something that I've loved my entire life.
</p>

<p>
To begin with this recipe, we must prepare a few components. You can cook bubur manado (tinutuan) using 25 ingredients and 10 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Manado (Tinutuan):</h3>

<ol>
	
		<li>{Take 1 lt of beras yg sudah dicuci,. </li>
	
		<li>{Take 3 lt of air. </li>
	
		<li>{Take 1 ikat of kangkung. </li>
	
		<li>{Get 1 genggam of daun kemangi. </li>
	
		<li>{Prepare 6 batang of kacang panjang potong-potong sedang. </li>
	
		<li>{Prepare 2 btg of daun bawang.. Iris-iris. </li>
	
		<li>{Take 1/2 of bgn labu kuning. </li>
	
		<li>{Get 3 bh of ubi rambat/jalar. </li>
	
		<li>{Prepare 3 bonggol of jagung, keluarin bijinya. </li>
	
		<li>{Make ready 1 btg of sereh, keprak. </li>
	
		<li>{Make ready  of Bumbu halus:. </li>
	
		<li>{Prepare 4 siung of bawang merah. </li>
	
		<li>{Prepare 3 siung of bawang putih. </li>
	
		<li>{Make ready 1 bks of Masako rasa sapi. </li>
	
		<li>{Prepare secukupnya of Garam. </li>
	
		<li>{Make ready secukupnya of Merica bubuk. </li>
	
		<li>{Get  of Resep sambel:. </li>
	
		<li>{Take 5 bj of cabe rawit. </li>
	
		<li>{Get 2 bh of tomat, potong kotak kecil. </li>
	
		<li>{Take 2 bh of jeruk limau. (Jeruk cui). </li>
	
		<li>{Take  of Terasi. </li>
	
		<li>{Get  of Garam. </li>
	
		<li>{Prepare  of Pelengkap:. </li>
	
		<li>{Get  of Ikan asin goreng. </li>
	
		<li>{Prepare  of Tempe goreng. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Manado (Tinutuan):</h3>

<ol>
	
		<li>
			Campur beras dan air, masak hingga menjadi 1/2 bubur..
			
			
		</li>
	
		<li>
			Masukkan bumbu halus, sereh, jagung, ubi rambat dan labu kuning, rebus bersama bubur hingga lembek..
			
			
		</li>
	
		<li>
			Sambil sesekali diaduk agar bubur tidak hangus didasar panci..
			
			
		</li>
	
		<li>
			Masukkan kangkung, kacang panjang dan kemangi. Masak hingga matang..
			
			
		</li>
	
		<li>
			Tambahkan daun bawang, masako dan garam. Coba rasanya..
			
			
		</li>
	
		<li>
			Sambel:.
			
			
		</li>
	
		<li>
			Cabe, terasi dan garam di ulek tapi jangan terlalu halus.
			
			
		</li>
	
		<li>
			Campur dengan tomat yg sudah di potong kotak-kotak.
			
			
		</li>
	
		<li>
			Berikan perasan jeruk limau (jeruk cui)..
			
			
		</li>
	
		<li>
			Nb: bisa juga menggunakan sayur bayam tapi sebaiknya dimasak terpisah karena sayur bayam tidak bisa dimakan setelah 5 jam da tidak bisa dipanaskan kembali..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur manado (tinutuan) recipe. Thank you very much for your time. I'm sure that you will make this at home. There's gonna be more interesting food at home recipes coming up. Remember to bookmark this page on your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
