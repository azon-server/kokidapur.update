---
description: "Steps to Make Super Quick Homemade Bubur kacang ijo"
title: "Steps to Make Super Quick Homemade Bubur kacang ijo"
slug: 104-steps-to-make-super-quick-homemade-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/c065d32ba66fb7e1/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
		Resep bubur kacang ijo itu sendiri ada berbagai macam dengan tambahan bahan yang melengkapinya.
	
		Cara bikin bubur kacang hijau / ijo memerlukan trik dan tips tersendiri, sehingga hasilnya bisa lebih bagus dan juga enak serta lembut.
	
		Sebenarnya tidak ada yang istimewa saat anda membuat.
	
</p>
<p>
	Hey everyone, it's Jim, welcome to my recipe site. Today, we're going to prepare a distinctive dish, bubur kacang ijo. One of my favorites food recipes. This time, I will make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo is one of the most well liked of current trending foods in the world. It's easy, it is fast, it tastes yummy. It's appreciated by millions every day. Bubur kacang ijo is something which I've loved my entire life. They are fine and they look wonderful.
</p>
<p>
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>

<p>
To get started with this particular recipe, we must first prepare a few components. You can have bubur kacang ijo using 8 ingredients and 4 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Get 1/4 kg of kacang ijo. </li>
	
		<li>{Take 1 bks of santan kara. </li>
	
		<li>{Prepare 2 buah of gula merah(me:gula kelapa). </li>
	
		<li>{Get 10 sdm of gula pasir. </li>
	
		<li>{Prepare 1 saset of susu kental manis. </li>
	
		<li>{Prepare 2 helai of daun pandan/1bks vanili bubuk. </li>
	
		<li>{Get 5 gelas of air. </li>
	
		<li>{Get 1/4 sdt of garam. </li>
	
</ol>
<p>
	
		Bubur kacang hejo (su) Bubur kacang ijo (jv) Burjo.
	
		Slightly different names may be used in different regions of Indonesia, such as kacang ijo in Javanese areas.
	
		Cara masak bubur kacang ijo super simple dan enak.
	
		Rahasia Peyek Kacang Ijo Renyah, Tidak Keras dan Tahan Lama Bu Yun kali inia akan membagikan resep, tips dan tutorial cara.
	
</p>

<h3>Steps to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Rendam kacang ijo dlm air semalaman, agar kacang ijo mengembang/mengelupas dan cepat empuk/tidak butuh waktu lama utk merebus. (aku mau buat burjo dipagi hari, jd aku rendam dr habis maghrib).
			
			
		</li>
	
		<li>
			Rebus burjo+daun pandan hingga empuk dan mengembang. (Aku kurleb 40mnt, krn aku pakai magic com). Setelah mengembang, masukan gulmer, gulput, skm. Aduk hingga larut. (Bisa tambah gula jika suka lebih manis).
			
			
		</li>
	
		<li>
			Untuk santannya: panaskan 1bks santan kara + 500ml air dan beri 1/4 sdt garam. Aduk terus jgn sampai santan pecah. Jika telah mendidih. Tiriskan..
			
			
		</li>
	
		<li>
			Tuang burjo kemangkuk dan siram dengan santan. N burjo is ready to serve. 😊.
			
			
		</li>
	
</ol>

<p>
	
		Cara Membuat Bubur Kacang Hijau Sederhana Yang Enak amp Kental Ala Dapur Dina.
	
		Ingin mencoba memasak Bubur Kacang Hijau sendiri, Burjo Pisang (Tips spy kacang ijo cepat empuk dan lembut), Bubur kacang ijo ketan item durian enakk, Burjo Nangka dan lain-lain yang lezat untuk.
	
		Sajikan bubur kacang hijau beserta rebusan santan saat akan di konsumsi untuk menghindari kacang hijau cepat basi Resep membuat bubur kacang hijau.
	
		Resep Bubur Kacang Ijo Enak Dan Cepat Mekar Atau Empuk.
	
		Kacang hijau / ijo merupakan salah satu bahan makanan yang bukan saja enak di buat minuman maupun makanan.
	
</p>

<p>
	So that is going to wrap it up with this special food bubur kacang ijo recipe. Thank you very much for reading. I'm confident you can make this at home. There is gonna be interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
