---
description: "Recipe of Award-winning Bubur manado"
title: "Recipe of Award-winning Bubur manado"
slug: 446-recipe-of-award-winning-bubur-manado

<p>
	<strong>Bubur manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/d9c9e875f15ef35a/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur manado" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you're having an amazing day today. Today, I'm gonna show you how to prepare a distinctive dish, bubur manado. One of my favorites. For mine, I am going to make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur manado is one of the most well liked of recent trending meals in the world. It's simple, it is quick, it tastes yummy. It is appreciated by millions daily. Bubur manado is something which I've loved my entire life. They are nice and they look fantastic.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to first prepare a few ingredients. You can have bubur manado using 13 ingredients and 6 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur manado:</h3>

<ol>
	
		<li>{Make ready 3 centong nasi of putih. </li>
	
		<li>{Take 1 buah of jagung,sisir. </li>
	
		<li>{Prepare 1/4 of labu kuning,potong dadu. </li>
	
		<li>{Prepare 3 buah of ubi kuning,potong dadu. </li>
	
		<li>{Make ready 5 ikat of daun kemangi. </li>
	
		<li>{Get 1 ikat of daun bayam. </li>
	
		<li>{Make ready 3 buah of sereh,geprek. </li>
	
		<li>{Get 1,5 liter of air. </li>
	
		<li>{Get Secukupnya of garam. </li>
	
		<li>{Take  of Pelengkap. </li>
	
		<li>{Get  of Sambel goreng. </li>
	
		<li>{Get  of Sambal roa kering. </li>
	
		<li>{Get  of Ikan asin tepung. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur manado:</h3>

<ol>
	
		<li>
			Masukkan air, nasi putih dan jagung di panci,masak selama 20 menit dengan ditambahkan sereh. Jgn lupa sering diaduk.
			
			
		</li>
	
		<li>
			Setelah menjadi bubur nasi tambahkan ubi kuning dan labu kuning. Aduk kembali.
			
			
		</li>
	
		<li>
			Tambahkan garam dan cicipi rasanya.
			
			
		</li>
	
		<li>
			Setelah ubi dan labu kuning empuk,tambahkan kemangi dan daun bayam. Aduk kembali.
			
			
		</li>
	
		<li>
			Masak sebentar jgn lebih dari 5 menit lalu matikan api.
			
			
		</li>
	
		<li>
			Sajikan dengan pelengkap nya😊.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this exceptional food bubur manado recipe. Thanks so much for reading. I'm confident you will make this at home. There is gonna be more interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
