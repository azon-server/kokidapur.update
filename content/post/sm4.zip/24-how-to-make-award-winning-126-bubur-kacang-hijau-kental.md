---
description: "How to Make Award-winning 126. BUBUR KACANG HIJAU KENTAL"
title: "How to Make Award-winning 126. BUBUR KACANG HIJAU KENTAL"
slug: 24-how-to-make-award-winning-126-bubur-kacang-hijau-kental

<p>
	<strong>126. BUBUR KACANG HIJAU KENTAL</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/5cfe82637e84cbf4/680x482cq70/126-bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="126. BUBUR KACANG HIJAU KENTAL" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is Drew, welcome to my recipe page. Today, I will show you a way to make a distinctive dish, 126. bubur kacang hijau kental. It is one of my favorites. This time, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	126. BUBUR KACANG HIJAU KENTAL is one of the most popular of recent trending meals in the world. It's enjoyed by millions every day. It is simple, it is quick, it tastes delicious. They're fine and they look wonderful. 126. BUBUR KACANG HIJAU KENTAL is something which I've loved my whole life.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to first prepare a few components. You can cook 126. bubur kacang hijau kental using 13 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make 126. BUBUR KACANG HIJAU KENTAL:</h3>

<ol>
	
		<li>{Make ready  of Bahan bubur :. </li>
	
		<li>{Get 250 gr of kacang hijau. </li>
	
		<li>{Prepare 250 gr of gula merah (di sisir). </li>
	
		<li>{Take 2-4 sdm of gula pasir (sesuai selera). </li>
	
		<li>{Make ready 2 lembar of daun pandan. </li>
	
		<li>{Prepare 4 sdm of maizena (larutkan dengan sedikit air). </li>
	
		<li>{Take 1400 ml of air. </li>
	
		<li>{Get  of Saus santan :. </li>
	
		<li>{Prepare 600 ml of santan (1 bks kara 65 ml + air). </li>
	
		<li>{Get 4 sdm of cremer bubuk. </li>
	
		<li>{Make ready 2 lembar of daun pandan. </li>
	
		<li>{Make ready Sejumput of garam. </li>
	
		<li>{Make ready 1/2 sdt of vanili. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make 126. BUBUR KACANG HIJAU KENTAL:</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau. Nyalakan api besar. Masak air hingga mendidih. Lalu masukkan kacang hijau. Tutup panci dan masak selama 5 menit..
			
			
		</li>
	
		<li>
			Setelah 5 menit, matikan kompor. Jangan buka tutup panci. Diamkan selama 30 menit. Lalu nyalakan lagi api besar dan masak selama 7 menit. Ingat, jangan pernah sekalipun membuka tutup panci..
			
			
		</li>
	
		<li>
			Setelah 7 menit, buka tutup panci, masukkan daun pandan, gula merah dan gula pasir. Aduk hingga gula larut dan air mendidih. Masukkan larutan maizena. Aduk hingga mengental dan sisihkan..
			
			
		</li>
	
		<li>
			Campur santan, daun pandan, vanili dan garam. Masak sambil terus diaduk hingga mendidih. Tes rasa, bila kurang gurih bisa ditambah garamnya sedikit..
			
			
		</li>
	
		<li>
			Sajikan bubur kacang hijau dengan saus santannya..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up with this special food 126. bubur kacang hijau kental recipe. Thank you very much for reading. I'm confident you can make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to save this page in your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
