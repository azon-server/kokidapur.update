---
description: "How to Prepare Perfect Bubur kacang ijo durian"
title: "How to Prepare Perfect Bubur kacang ijo durian"
slug: 157-how-to-prepare-perfect-bubur-kacang-ijo-durian

<p>
	<strong>Bubur kacang ijo durian</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/2622e660f8589411/680x482cq70/bubur-kacang-ijo-durian-foto-resep-utama.jpg" alt="Bubur kacang ijo durian" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you are having an incredible day today. Today, we're going to prepare a special dish, bubur kacang ijo durian. It is one of my favorites food recipes. For mine, I am going to make it a bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo durian is one of the most well liked of current trending meals on earth. It is simple, it is fast, it tastes delicious. It is appreciated by millions daily. Bubur kacang ijo durian is something that I have loved my entire life. They are fine and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we must first prepare a few ingredients. You can cook bubur kacang ijo durian using 8 ingredients and 8 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo durian:</h3>

<ol>
	
		<li>{Prepare 250 gr (1/4 kg) of kacang hijau. </li>
	
		<li>{Get Secukupnya of durian. </li>
	
		<li>{Get 2 gelas of santan kelapa kental. </li>
	
		<li>{Prepare 2 gelas of santan kelapa cair. </li>
	
		<li>{Make ready 1 1/2 biji of gula jawa. </li>
	
		<li>{Prepare 3 lembar of daun pandan. </li>
	
		<li>{Take Secukupnya of gula pasir. </li>
	
		<li>{Get Secukupnya of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo durian:</h3>

<ol>
	
		<li>
			Cuci kacang hijau sampai bersih..
			
			
		</li>
	
		<li>
			Tuang air panas di dalam wadah yg berisi kacang hijau dan tutup rapat..
			
			
		</li>
	
		<li>
			Panaskan air 2 gelas di dalam panci biarkan sampai mendidih kemudian masukkan kacang hijau yg sdh d tiriskan sbelumnya..
			
			
		</li>
	
		<li>
			Setelah air agak menyusut masukkan santan encer 2 gelas. Sisr gula jawa dan masukkan k dalam panci berisi kacang hijau tadi..
			
			
		</li>
	
		<li>
			Setelah agak menyusut air dan mulai lunak kacang hijaunya masukkan santan kental sambil terus diaduk..
			
			
		</li>
	
		<li>
			Setelah mendidih masukkan durian sambil terus d aduk. Cek rasa apabila kurang manis tambahkan gula pasir sesuai selera..
			
			
		</li>
	
		<li>
			Setelah air agak menyusut dan mulai agak kental dan creamy masukkan sedikit garam untuk mengangkat rasa. Untuk kuah sesuai selera masing2. Boleh agak encer atau creamy. Klo saya suka agak creamy 😊.
			
			
		</li>
	
		<li>
			Bubur kacang hijau durian siap disajikan hangat2..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this special food bubur kacang ijo durian recipe. Thanks so much for your time. I am confident that you will make this at home. There's gonna be more interesting food in home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
