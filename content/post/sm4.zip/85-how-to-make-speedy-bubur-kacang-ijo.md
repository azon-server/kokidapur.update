---
description: "How to Make Speedy Bubur kacang ijo"
title: "How to Make Speedy Bubur kacang ijo"
slug: 85-how-to-make-speedy-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/b51d14ca34ffd5ca/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Jim, welcome to my recipe site. Today, I'm gonna show you how to prepare a special dish, bubur kacang ijo. One of my favorites food recipes. This time, I'm gonna make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang ijo is one of the most well liked of current trending meals on earth. It is enjoyed by millions every day. It is simple, it's quick, it tastes delicious. Bubur kacang ijo is something that I've loved my entire life. They're nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we must prepare a few components. You can cook bubur kacang ijo using 8 ingredients and 3 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Get 150 gr of kacang ijo. </li>
	
		<li>{Make ready 3 sdm of gula pasir. </li>
	
		<li>{Take 1-1 1/2 keping of gula merah(trgantung uk. gulanya). </li>
	
		<li>{Make ready 2 lembar of daun pandan. </li>
	
		<li>{Make ready sejumput of garam. </li>
	
		<li>{Prepare 3 cm of jahe. </li>
	
		<li>{Prepare 1/2 gelas of santan kental (saya dr ⅛ kelapa yg diparut). </li>
	
		<li>{Get 1 liter of air. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Siapkan bahan,didihkan air,lalu masukkan kacang ijo slma 5 menit(panci ditutup),lalu matikan kompor,diamkan diatas kompor slma 30 menit.
			
			
		</li>
	
		<li>
			Setelah 30 menit,nyalakan kompor,setelah 7 menit baru saya buka dan menambahkan jahe,gula,daun pandan,garam.
			
			
		</li>
	
		<li>
			Masak sampai air agak mnyusut,baru masukkan santan sampai mndidih lg,dan selesaii🤗🤗 btw klo ga mau lngsung dimakan,santan ga perlu lngsung dimasukkan,masak sndiri dulu dan campurkan ketika mau dimakan☺️.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food bubur kacang ijo recipe. Thanks so much for your time. I am confident that you can make this at home. There's gonna be interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
