---
description: "Step-by-Step Guide to Make Ultimate Bubur Kacang Hijau Kental"
title: "Step-by-Step Guide to Make Ultimate Bubur Kacang Hijau Kental"
slug: 30-step-by-step-guide-to-make-ultimate-bubur-kacang-hijau-kental

<p>
	<strong>Bubur Kacang Hijau Kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/36a592f8341083dc/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you're having an incredible day today. Today, we're going to make a distinctive dish, bubur kacang hijau kental. It is one of my favorites. This time, I am going to make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Hijau Kental is one of the most popular of current trending meals in the world. It is appreciated by millions daily. It's simple, it is quick, it tastes yummy. Bubur Kacang Hijau Kental is something that I've loved my whole life. They're nice and they look fantastic.
</p>

<p>
To begin with this particular recipe, we must prepare a few components. You can have bubur kacang hijau kental using 11 ingredients and 5 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>{Prepare 250 gr of kacang hijau. </li>
	
		<li>{Get 250 gr of gula merah (di sisir). </li>
	
		<li>{Make ready 2 sdm of gula pasir (sesuai selera, boleh di skip). </li>
	
		<li>{Get 4 lembar of daun pandan. </li>
	
		<li>{Get 3-4 sdm of maizena / tapioca (larutkan dengan sedikit air). </li>
	
		<li>{Take 1400 ml of air. </li>
	
		<li>{Get  of Saus santan :. </li>
	
		<li>{Prepare 600 ml of santan. </li>
	
		<li>{Prepare 2 lembar of daun pandan. </li>
	
		<li>{Take Sejumput of garam. </li>
	
		<li>{Prepare 1/2 sdt of vanili. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>
			Cuci bersih kacang hijau. Nyalakan api besar. Masak air hingga mendidih. Lalu masukkan kacang hijau. Tutup panci dan masak selama 5 menit..
			
			
		</li>
	
		<li>
			Setelah 5 menit, matikan kompor. Jangan buka tutup panci. Diamkan selama 30 menit. Lalu nyalakan lagi api besar dan masak selama 7 menit. Ingat, jangan pernah sekalipun membuka tutup panci..
			
			
		</li>
	
		<li>
			Setelah 7 menit, buka tutup panci, masukkan daun pandan, gula merah dan gula pasir. Aduk hingga gula larut dan air mendidih. Masukkan larutan maizena. Aduk hingga mengental dan sisihkan..
			
			
		</li>
	
		<li>
			Campur santan, daun pandan, vanili dan garam. Masak sambil terus diaduk hingga mendidih..
			
			
		</li>
	
		<li>
			Sajikan bubur kacang hijau dengan saus santannya..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food bubur kacang hijau kental recipe. Thank you very much for reading. I'm sure you will make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
