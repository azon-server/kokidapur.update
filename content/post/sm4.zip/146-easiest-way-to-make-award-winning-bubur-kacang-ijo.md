---
description: "Easiest Way to Make Award-winning Bubur kacang ijo"
title: "Easiest Way to Make Award-winning Bubur kacang ijo"
slug: 146-easiest-way-to-make-award-winning-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/a82796b8fc0c4766/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
		Resep bubur kacang ijo itu sendiri ada berbagai macam dengan tambahan bahan yang melengkapinya.
	
		Cara bikin bubur kacang hijau / ijo memerlukan trik dan tips tersendiri, sehingga hasilnya bisa lebih bagus dan juga enak serta lembut.
	
		Sebenarnya tidak ada yang istimewa saat anda membuat.
	
</p>
<p>
	Hello everybody, it is Louise, welcome to my recipe site. Today, we're going to make a distinctive dish, bubur kacang ijo. One of my favorites food recipes. This time, I'm gonna make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>
<p>
	Bubur kacang ijo is one of the most favored of current trending meals in the world. It's simple, it is fast, it tastes delicious. It is enjoyed by millions daily. Bubur kacang ijo is something that I have loved my entire life. They are fine and they look fantastic.
</p>

<p>
To begin with this particular recipe, we have to first prepare a few components. You can have bubur kacang ijo using 19 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Take  of Bahan A:. </li>
	
		<li>{Take 125 gram of kacang hijau (rendam semalaman....me: 3 jam). </li>
	
		<li>{Take 1500 ml of air (kalo pake santan kurangin air jadi 1300ml). </li>
	
		<li>{Take 2 lbr of daun pandan. </li>
	
		<li>{Take 2 iris of jahe (kurleb 4cm). </li>
	
		<li>{Get 3 cm of kayumanis. </li>
	
		<li>{Get  of Bahan B:. </li>
	
		<li>{Make ready 50 ml of gula cair. </li>
	
		<li>{Get 100 ml of susu UHT. </li>
	
		<li>{Take 1 sachet of susu kental manis. </li>
	
		<li>{Make ready 3 sdm of fibercreme (ato santan kental 200ml). </li>
	
		<li>{Prepare 1 sachet of vanili. </li>
	
		<li>{Make ready 1/2 sdt of garam. </li>
	
		<li>{Get 50 gram of gula merah. </li>
	
		<li>{Make ready 3 sdm of sirup cocopandan/tjampoley pisang susu. </li>
	
		<li>{Get 40 gr of gula pasir (jika suka manis). </li>
	
		<li>{Make ready  of Bahan C : (kalo suka bubur kental). </li>
	
		<li>{Prepare 10 gram of tapioka. </li>
	
		<li>{Prepare 30 ml of air (utk melarutkan tapioka).....saya skip...bahan C. </li>
	
</ol>
<p>
	
		Bubur kacang hejo (su) Bubur kacang ijo (jv) Burjo.
	
		Slightly different names may be used in different regions of Indonesia, such as kacang ijo in Javanese areas.
	
		Cara masak bubur kacang ijo super simple dan enak.
	
		Rahasia Peyek Kacang Ijo Renyah, Tidak Keras dan Tahan Lama Bu Yun kali inia akan membagikan resep, tips dan tutorial cara.
	
</p>

<h3>Steps to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Siapkan bahan:.
			
			
		</li>
	
		<li>
			Didihkan air dengan daun pandan...setelah itu masukkan kacang hijau,jahe dan kayu manis.
			
			
		</li>
	
		<li>
			Masak sampai kacang hijau matang....buang kulit kacang hijau yang mengapung di permukaan air....lalu masukkan air gula,garam,vanili,susu uht,skm,sirup cocopandan dan gula merah.
			
			
		</li>
	
		<li>
			Biarkan sampai mendidih...dan sekali kali diaduk....tes rasa...jika kurang manis bisa ditambahkan gula pasir.... (Utk gula cair : 100 gr gula merah,50 gr gula pasir,150ml air,2 lbr daun pandan....rebus semua bahan hingga gula larut).
			
			
		</li>
	
		<li>
			Dimakan hangat enak...ato bisa di blender beri es secukupnya buat siang hari yg panas.
			
			
		</li>
	
</ol>

<p>
	
		Cara Membuat Bubur Kacang Hijau Sederhana Yang Enak amp Kental Ala Dapur Dina.
	
		Ingin mencoba memasak Bubur Kacang Hijau sendiri, Burjo Pisang (Tips spy kacang ijo cepat empuk dan lembut), Bubur kacang ijo ketan item durian enakk, Burjo Nangka dan lain-lain yang lezat untuk.
	
		Sajikan bubur kacang hijau beserta rebusan santan saat akan di konsumsi untuk menghindari kacang hijau cepat basi Resep membuat bubur kacang hijau.
	
		Resep Bubur Kacang Ijo Enak Dan Cepat Mekar Atau Empuk.
	
		Kacang hijau / ijo merupakan salah satu bahan makanan yang bukan saja enak di buat minuman maupun makanan.
	
</p>

<p>
	So that's going to wrap this up for this special food bubur kacang ijo recipe. Thanks so much for your time. I am confident that you can make this at home. There is gonna be interesting food at home recipes coming up. Remember to save this page in your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
