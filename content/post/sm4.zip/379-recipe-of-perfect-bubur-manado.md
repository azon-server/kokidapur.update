---
description: "Recipe of Perfect Bubur Manado"
title: "Recipe of Perfect Bubur Manado"
slug: 379-recipe-of-perfect-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/184edeefa273109f/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's Louise, welcome to our recipe page. Today, I'm gonna show you how to make a distinctive dish, bubur manado. One of my favorites. This time, I'm gonna make it a bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur Manado is one of the most well liked of recent trending meals on earth. It's simple, it is fast, it tastes delicious. It is appreciated by millions daily. Bubur Manado is something which I have loved my whole life. They are fine and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we have to first prepare a few ingredients. You can cook bubur manado using 17 ingredients and 9 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Prepare 300 gr of beras. </li>
	
		<li>{Prepare 3 liter of air. </li>
	
		<li>{Make ready 1 ikat of daun katuk. </li>
	
		<li>{Take 1 ikat of kangkung. </li>
	
		<li>{Make ready 6 batang of daun bawang. </li>
	
		<li>{Take 3 tangkai of daun kunyit. </li>
	
		<li>{Take 1/4 iris of labu kuning. </li>
	
		<li>{Take 3 bonggol of jagung. </li>
	
		<li>{Prepare 2 batang of sereh geprek. </li>
	
		<li>{Get segenggam of daun kemangi. </li>
	
		<li>{Prepare 5 siung of bawang putih. </li>
	
		<li>{Make ready 1/4 sdt of merica bubuk. </li>
	
		<li>{Prepare 1 sdm of kaldu jamur. </li>
	
		<li>{Take 1 sdt of garam. </li>
	
		<li>{Make ready  of Pelengkap :. </li>
	
		<li>{Get  of ikan asin goreng. </li>
	
		<li>{Prepare  of sambal terasi. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado:</h3>

<ol>
	
		<li>
			Cuci bersih sayur mayur, serut jagung, potong-potong labu kuning.
			
			
		</li>
	
		<li>
			Kupas bawang putih cuci bersih lalu cincang halus, geprek sereh, iris tipis daun bawang serta daun kunyit.
			
			
		</li>
	
		<li>
			Cuci beras hingga bersih lalu tumis daun bawang, daun kunyit dan bawang putih cincang hingga wangi.
			
			
		</li>
	
		<li>
			Lalu masukkan beras, air, labu kuning.
			
			
		</li>
	
		<li>
			Jagung, sereh geprek, ke dalam tumisan daun bawang, daun kunyit dan bawang putih cincang lalu tunggu hingga mendidih.
			
			
		</li>
	
		<li>
			Setelah mendidih aduk-aduk agar tidak gosong setelah beras sidah nampak berubah menjadi nasi, tekqn-tekan labu kuning agar hancur dan bubur berubah warna menjadi kuning.
			
			
		</li>
	
		<li>
			Lalu masukkan daun katuk aduk merata hingga daun katuk lunak saat dimakan kemudian kangkung aduk sebentar saja agar kangkung tidak terlalu layu agar sayur masih tetap berwarna hijau, jangan terlalu over cook ya biar cantik.
			
			
		</li>
	
		<li>
			Kemudian tambahkan kemangi, sama dengan bunda VY sy jg ada tanam daun kunyit dan kemangi biar sewaktu-waktu perlu tinggal petik 😊.
			
			
		</li>
	
		<li>
			Bubur Manado alhamdulillah siap untuk disajikan bersama sambal terasi dan ikan asin super nampol dah.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this special food bubur manado recipe. Thanks so much for reading. I'm confident that you will make this at home. There is gonna be interesting food at home recipes coming up. Remember to save this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
