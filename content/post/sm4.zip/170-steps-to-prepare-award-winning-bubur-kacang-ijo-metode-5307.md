---
description: "Steps to Prepare Award-winning Bubur kacang ijo metode (5.30.7)"
title: "Steps to Prepare Award-winning Bubur kacang ijo metode (5.30.7)"
slug: 170-steps-to-prepare-award-winning-bubur-kacang-ijo-metode-5307

<p>
	<strong>Bubur kacang ijo metode (5.30.7)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/6c76bbcd2c7843b5/680x482cq70/bubur-kacang-ijo-metode-5307-foto-resep-utama.jpg" alt="Bubur kacang ijo metode (5.30.7)" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's me again, Dan, welcome to our recipe site. Today, I will show you a way to make a distinctive dish, bubur kacang ijo metode (5.30.7). It is one of my favorites food recipes. This time, I'm gonna make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo metode (5.30.7) is one of the most well liked of current trending meals on earth. It's enjoyed by millions every day. It is simple, it's quick, it tastes delicious. Bubur kacang ijo metode (5.30.7) is something that I have loved my entire life. They're fine and they look wonderful.
</p>

<p>
To get started with this particular recipe, we must first prepare a few ingredients. You can have bubur kacang ijo metode (5.30.7) using 7 ingredients and 3 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo metode (5.30.7):</h3>

<ol>
	
		<li>{Take 8 genggam of kacang ijo. </li>
	
		<li>{Make ready 1 liter of air. </li>
	
		<li>{Prepare 300 ml of santan kental. </li>
	
		<li>{Make ready 350 gr of gula merah. </li>
	
		<li>{Make ready 1/2 sdt of garam. </li>
	
		<li>{Get 2 ruas of jahe (memarkan). </li>
	
		<li>{Prepare 3 lembar of daun pandan (simpulkan). </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo metode (5.30.7):</h3>

<ol>
	
		<li>
			Masak air hingga mendidih masukkan kacang ijo yang sudah dicuci bersih masak 5 menit lalu matikan kompor..
			
			
		</li>
	
		<li>
			Diamkan kacang ijo selama 30 menit dengan panci tertutup / sampai kacang ijo mengelupas..
			
			
		</li>
	
		<li>
			Nyalakan kompor masukkan santan,gula,garam,jahe,dan daun pandan masak 7menit hingga mendidih sambil diaduk terus agar santan tidak pecah.angkat dan sajikan...
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food bubur kacang ijo metode (5.30.7) recipe. Thanks so much for reading. I'm sure you can make this at home. There is gonna be interesting food in home recipes coming up. Remember to bookmark this page on your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
