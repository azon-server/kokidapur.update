---
description: "Recipe of Super Quick Homemade Bubur Kacang Ijo"
title: "Recipe of Super Quick Homemade Bubur Kacang Ijo"
slug: 209-recipe-of-super-quick-homemade-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/ef5c1c00fc9e3f9a/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Louise, welcome to our recipe page. Today, we're going to make a special dish, bubur kacang ijo. It is one of my favorites. For mine, I'm gonna make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Kacang Ijo is one of the most favored of recent trending foods in the world. It is easy, it is fast, it tastes delicious. It is appreciated by millions every day. They're nice and they look wonderful. Bubur Kacang Ijo is something which I have loved my entire life.
</p>

<p>
To get started with this recipe, we have to first prepare a few ingredients. You can have bubur kacang ijo using 9 ingredients and 2 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Get 250 gr of kacang hijau, cuci bersih, rendam semalaman. </li>
	
		<li>{Make ready 2 kotak of santan Kara isi 200 ml, jika tak suka kental ckp 1 saja. </li>
	
		<li>{Make ready 1 kotak of susu frisian flag rasa kacang hijau isi 225 ml. </li>
	
		<li>{Make ready 11 sdm of gula pasir, jika suka manis tambahkan sesuai selera. </li>
	
		<li>{Get 1/2 sdt of garam halus. </li>
	
		<li>{Make ready 2 ruas of jahe, geprek. </li>
	
		<li>{Prepare 10 cm of kayu manis, potong menjadi 2 bagian. </li>
	
		<li>{Get 1 lembar of daun pandan, cuci bersih, simpulkan. </li>
	
		<li>{Take secukupnya of Air. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Buang air rendaman kacang hijau kemudian masukkan kacang hijau dalam wajan tambahkan jahe, kulit manis, daun pandan, rebus kacang hijau hingga empuk. Jika air menyusut tambahkan air panas secukupnya..
			
			
		</li>
	
		<li>
			Tambahkan garam, aduk rata, masukkan santan, aduk hingga santan tidak pecah, masukkan gula dan susu. Aduk sebentar, setelah larutan mendidih, tes rasa. Matikan kompor, angkat dan sajikan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this special food bubur kacang ijo recipe. Thank you very much for reading. I'm confident you will make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
