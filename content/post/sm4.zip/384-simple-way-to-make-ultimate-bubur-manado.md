---
description: "Simple Way to Make Ultimate Bubur Manado"
title: "Simple Way to Make Ultimate Bubur Manado"
slug: 384-simple-way-to-make-ultimate-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/b1f592d3d204c29c/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is John, welcome to our recipe site. Today, we're going to make a special dish, bubur manado. One of my favorites food recipes. For mine, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Manado is one of the most popular of recent trending foods in the world. It's easy, it's fast, it tastes delicious. It's enjoyed by millions every day. Bubur Manado is something that I have loved my entire life. They're nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we have to prepare a few components. You can cook bubur manado using 10 ingredients and 4 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Make ready 2 of centong Nasi. </li>
	
		<li>{Prepare 1/2 bonggol of jagung (dipipil). </li>
	
		<li>{Get 1 genggam of Bayam. </li>
	
		<li>{Take 1 genggam of Kangkung. </li>
	
		<li>{Get 1 batang of sereh. </li>
	
		<li>{Prepare 5 lembar of daun kemangi. </li>
	
		<li>{Take 1 siung of Bawang putih (geprek). </li>
	
		<li>{Make ready 350 ml of air. </li>
	
		<li>{Get 1 ons of tulang ayam (kebetulan ada sisa dikulkas, skip jg gpp). </li>
	
		<li>{Take Secukupnya of garam dan penyedap. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Manado:</h3>

<ol>
	
		<li>
			Cuci tulang ayam, lalu rebus bersama bawang putih geprek&amp; sereh,hingga keluar minyak untuk diambil kaldunya. Setelah itu pisahkan tulang, sereh dan baput nya. Siapkan sayuran..
			
			
		</li>
	
		<li>
			Blender nasi matang dengan air kaldu secukupnya hingga lembut. Setelah itu masak kembali dengan jagung. Aduk rata..
			
			
		</li>
	
		<li>
			Setelah mengental, masukan daun kemangi, garam dan penyedap rasa. Jika terlalu kental bisa ditambahkan lagi air... Terakhir masukan sayuran (pastikan jagung sudah matang)..
			
			
		</li>
	
		<li>
			Jika sudah mengental seperti ini, matikan kompor. Sajikan dengan taburan bawang goreng juga sambal. 😗.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur manado recipe. Thanks so much for reading. I am sure that you will make this at home. There's gonna be interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
