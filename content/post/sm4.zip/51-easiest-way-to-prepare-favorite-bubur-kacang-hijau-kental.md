---
description: "Easiest Way to Prepare Favorite Bubur Kacang Hijau Kental"
title: "Easiest Way to Prepare Favorite Bubur Kacang Hijau Kental"
slug: 51-easiest-way-to-prepare-favorite-bubur-kacang-hijau-kental

<p>
	<strong>Bubur Kacang Hijau Kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/7b4644466fd0e7e9/680x482cq70/bubur-kacang-hijau-kental-foto-resep-utama.jpg" alt="Bubur Kacang Hijau Kental" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an incredible day today. Today, we're going to make a special dish, bubur kacang hijau kental. One of my favorites. This time, I am going to make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Hijau Kental is one of the most favored of recent trending foods on earth. It is appreciated by millions every day. It is easy, it's fast, it tastes yummy. They are fine and they look wonderful. Bubur Kacang Hijau Kental is something that I've loved my entire life.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we must first prepare a few ingredients. You can cook bubur kacang hijau kental using 13 ingredients and 4 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>{Prepare 250 gram of kacang hijau. </li>
	
		<li>{Take 2 lembar of daun pandan. </li>
	
		<li>{Take 2 keping of gula merah (sisir). </li>
	
		<li>{Make ready 2 cm of jahe (geprek). </li>
	
		<li>{Prepare 2 sdm of tepung sagu (karena habis saya pakai 5 sdm tepung beras). </li>
	
		<li>{Make ready  of gula pasir (sesuai selera). </li>
	
		<li>{Prepare sejumput of garam (sesuai selera). </li>
	
		<li>{Take secukupnya of air. </li>
	
		<li>{Prepare  of bahan santan :. </li>
	
		<li>{Make ready 1 sachet of santan bubuk. </li>
	
		<li>{Make ready 2 cup of air (sesuai selera). </li>
	
		<li>{Take 1 lembar of daun pandan. </li>
	
		<li>{Take sejumput of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Hijau Kental:</h3>

<ol>
	
		<li>
			Rendam kacang hijau minimal 6 jam. kalau saya rendam semalaman. bersihkan. lalu rebus dg daun pandan dan jahe hingga kacang hijau empuk sekali..
			
			
		</li>
	
		<li>
			Jika sudah empuk dan air menyusut, tambahkan gula merah sisir, garam, gula pasir. aduk-aduk kira-kira 5 menit baru tambahkan larutan tepung sagu (karena habis saya pakai tepung beras 5 sdm + 3 cup air). aduk-aduk terus supaya tidak lengket bawahnya dan hingga meletup-letup. cek rasa. angkat sisihkan..
			
			
		</li>
	
		<li>
			Kuah santan : larutkan santan bubuk dan air. rebus bersama daun pandan dan sedikit garam. aduk-aduk supaya tidak pecah. angkat. ssisihkan..
			
			
		</li>
	
		<li>
			Tata di piring saji, bubur kacang hijau dan santan. sajikan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this exceptional food bubur kacang hijau kental recipe. Thanks so much for reading. I'm sure that you can make this at home. There is gonna be more interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
