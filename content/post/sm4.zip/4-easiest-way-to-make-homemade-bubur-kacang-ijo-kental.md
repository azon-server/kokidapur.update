---
description: "Easiest Way to Make Homemade Bubur kacang ijo kental"
title: "Easiest Way to Make Homemade Bubur kacang ijo kental"
slug: 4-easiest-way-to-make-homemade-bubur-kacang-ijo-kental

<p>
	<strong>Bubur kacang ijo kental</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/e798cf6f6d6e2627/680x482cq70/bubur-kacang-ijo-kental-foto-resep-utama.jpg" alt="Bubur kacang ijo kental" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you're having an incredible day today. Today, we're going to prepare a distinctive dish, bubur kacang ijo kental. One of my favorites food recipes. This time, I'm gonna make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo kental is one of the most popular of recent trending foods in the world. It's appreciated by millions daily. It is easy, it's quick, it tastes yummy. Bubur kacang ijo kental is something which I've loved my whole life. They are nice and they look fantastic.
</p>

<p>
To get started with this particular recipe, we have to first prepare a few ingredients. You can have bubur kacang ijo kental using 10 ingredients and 4 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo kental:</h3>

<ol>
	
		<li>{Take 250 gram of Kacang ijo. </li>
	
		<li>{Take  of Gula merah 250 gram (di sisir). </li>
	
		<li>{Prepare 4 SDM of Maizena. </li>
	
		<li>{Get 4 SDM of Gula. </li>
	
		<li>{Make ready 1500 ml of Air. </li>
	
		<li>{Take 2 lembar of Daun pandan. </li>
	
		<li>{Get  of Kuah santan :. </li>
	
		<li>{Get  of Santan 500 ml (1/4 butir kelapa). </li>
	
		<li>{Get 1 sdt of Garam. </li>
	
		<li>{Prepare 1 lembar of Daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur kacang ijo kental:</h3>

<ol>
	
		<li>
			Rendam kacang ijo ±2 jam, lalu cuci bersih kemudian rebus 5 menit lalu matikan, jangan buka tutup panci diamkan 30 menit.
			
			
		</li>
	
		<li>
			Setelah 30 menit nyalakan kembali dengan api besar masak selama 7 menit. Jangan buka tutup panci sama sekali.
			
			
		</li>
	
		<li>
			Setelah 7 menit, buka tutup panci masukkan gula, gula merah,daun pandan,larutan maizena aduk hingga larut dan mendidih, angkat.
			
			
		</li>
	
		<li>
			Masak santan,garam, daun pandan sambil terus di aduk agar santan tidak pecah hingga mendidih, angkat dan sajikan dengan bubur kacang ijo selagi hangat.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up for this exceptional food bubur kacang ijo kental recipe. Thank you very much for reading. I'm confident you will make this at home. There is gonna be interesting food at home recipes coming up. Don't forget to save this page on your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
