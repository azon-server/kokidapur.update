---
description: "Steps to Prepare Perfect Tinutuan aka Bubur Manado"
title: "Steps to Prepare Perfect Tinutuan aka Bubur Manado"
slug: 303-steps-to-prepare-perfect-tinutuan-aka-bubur-manado

<p>
	<strong>Tinutuan aka Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/162e750471c9f901/680x482cq70/tinutuan-aka-bubur-manado-foto-resep-utama.jpg" alt="Tinutuan aka Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it is Drew, welcome to my recipe site. Today, I'm gonna show you how to prepare a distinctive dish, tinutuan aka bubur manado. One of my favorites food recipes. For mine, I am going to make it a little bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Tinutuan aka Bubur Manado is one of the most favored of recent trending foods on earth. It is enjoyed by millions every day. It's easy, it is quick, it tastes delicious. Tinutuan aka Bubur Manado is something that I have loved my entire life. They are fine and they look wonderful.
</p>

<p>
To get started with this recipe, we must prepare a few components. You can cook tinutuan aka bubur manado using 18 ingredients and 11 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Tinutuan aka Bubur Manado:</h3>

<ol>
	
		<li>{Prepare 1 kg of beras. </li>
	
		<li>{Get 3 bh of keladi potong kotak. </li>
	
		<li>{Prepare 3 bh of singkong potong bulat kecil. </li>
	
		<li>{Make ready 1 bulat of labu kuning/labu parang potong kotak. </li>
	
		<li>{Get 3 bh of serai geprek. </li>
	
		<li>{Take 1 ikat of kangkung. </li>
	
		<li>{Get 1 ikat of kemangi. </li>
	
		<li>{Prepare 1 ikat of bayam hijau. </li>
	
		<li>{Prepare 1 of tumpuk daun gedi. </li>
	
		<li>{Take 6 bh of jagung pipilin. </li>
	
		<li>{Prepare  of Bumbu:. </li>
	
		<li>{Take 6 bh of bawang putin uleg halus. </li>
	
		<li>{Prepare  of Pelengkap:. </li>
	
		<li>{Prepare  of Sambel teri terasi. </li>
	
		<li>{Get  of Ikan asin goreng. </li>
	
		<li>{Get  of Tahu goreng. </li>
	
		<li>{Get  of Bawang goreng. </li>
	
		<li>{Prepare  of Kalau suka miedal tgl ditambah mie (stok mie ngak ada). </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Tinutuan aka Bubur Manado:</h3>

<ol>
	
		<li>
			Siapkan bahan ada sebagian gk kefoto bahannya soalnya buru2 udah pd laper.
			
			
		</li>
	
		<li>
			Naikan air didihkan kemudian masukkan labu kuning dan serai masak hingga lunak angkat hancurkan labu diwadah sisihkan, masukkan singkong dan keladi kedalam air td yg sdh mendidih masak hingga lunak angkat sisihkan, air yg td digunakan jgn dibuang yaa gunakan unt membuat bubur.
			
			
		</li>
	
		<li>
			Masukkan beras masak hingga menjadi bubur kental, bila kurang bisa ditambahkan air.
			
			
		</li>
	
		<li>
			Masukkan jagung aduk rata tunggu hingga jagung lunak aduk2 kgn smp bagian bawah gosong.
			
			
		</li>
	
		<li>
			Masukkan labu kuning yg sdh dihaluskan sambil dibaurkan agar rata, aduk rata.
			
			
		</li>
	
		<li>
			Masak hingga mengental beri garam, penyedap rasa. Masukkan singkong dan keladi yg sblmnya sdh direbus hingga empuk. Tumis bawang putih jika sdh harum tuang kedalam bubur ini aduk rata sisihkan.
			
			
		</li>
	
		<li>
			Masak terus hingga bubur kental merata sambil terus diaduk.
			
			
		</li>
	
		<li>
			Bila sdh siap unt dimakan masukkan sayurannya (spy sayur ttp fresh hijau gk layu) masak sebentar sj jgn smp sayuran mjd cokelat atau over cook (nnt gk enak) angkat.
			
			
		</li>
	
		<li>
			Buat sambal dr cabe, bwg merah, bwg putih, tomat dan ikan teri sbg tman mkn bubur manado.
			
			
		</li>
	
		<li>
			Tadaaaaa jadi jugaaa sajikan dgn ikan asin, bawang goreng, tahu dan sambal teri kalau aslinya pk sambal roa berhubung stok ikan roa habis jadilah pk teri ajah yuuuuumyyyyy 👌🏻.
			
			
		</li>
	
		<li>
			Bubur manado yg asli yaa gini bkn yg wrnx butek yaa alias gk kuning, ini asli kuningnya dari labu kuning/parang tanpa tambahan pewarna atau apapun. Tinggal ditambah mie jadilah midal 😘👌🏻.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this special food tinutuan aka bubur manado recipe. Thank you very much for reading. I'm sure that you can make this at home. There's gonna be interesting food at home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
