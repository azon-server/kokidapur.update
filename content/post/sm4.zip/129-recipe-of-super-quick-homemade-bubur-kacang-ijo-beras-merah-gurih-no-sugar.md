---
description: "Recipe of Super Quick Homemade Bubur Kacang Ijo Beras Merah Gurih No Sugar"
title: "Recipe of Super Quick Homemade Bubur Kacang Ijo Beras Merah Gurih No Sugar"
slug: 129-recipe-of-super-quick-homemade-bubur-kacang-ijo-beras-merah-gurih-no-sugar

<p>
	<strong>Bubur Kacang Ijo Beras Merah Gurih No Sugar</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/242ba42cbc100587/680x482cq70/bubur-kacang-ijo-beras-merah-gurih-no-sugar-foto-resep-utama.jpg" alt="Bubur Kacang Ijo Beras Merah Gurih No Sugar" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's me again, Dan, welcome to our recipe site. Today, we're going to prepare a special dish, bubur kacang ijo beras merah gurih no sugar. One of my favorites. For mine, I'm gonna make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo Beras Merah Gurih No Sugar is one of the most popular of recent trending meals on earth. It is appreciated by millions every day. It is simple, it's quick, it tastes yummy. They are nice and they look wonderful. Bubur Kacang Ijo Beras Merah Gurih No Sugar is something which I have loved my whole life.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we have to first prepare a few ingredients. You can cook bubur kacang ijo beras merah gurih no sugar using 7 ingredients and 5 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo Beras Merah Gurih No Sugar:</h3>

<ol>
	
		<li>{Take 250 gram of kacang ijo. </li>
	
		<li>{Get 2,5 cup of beras merah. </li>
	
		<li>{Take 1 butir of kelapa parut, buat santan cair dan santan kental. </li>
	
		<li>{Make ready 4 of –5 helai daun pandan. </li>
	
		<li>{Take 1 jempol of jahe. </li>
	
		<li>{Prepare 3 of –4 sdm garam krosok (sesuai selera). </li>
	
		<li>{Prepare secukupnya of Air. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo Beras Merah Gurih No Sugar:</h3>

<ol>
	
		<li>
			Masak kacang ijo dengan air di panci besar hingga air mendidih, lalu angkat. Masukkan daun pandan..
			
			
		</li>
	
		<li>
			Masak beras merah di panci kecil hingga menjadi nasi, lalu angkat..
			
			
		</li>
	
		<li>
			Rebus kembali kacang ijo hingga pecah. Bila perlu tambahkan sedikit air agar tidak terlalu kering..
			
			
		</li>
	
		<li>
			Tuang santan cair ke dalam panci kacang ijo. Aduk sebentar. Kemudian masukkan nasi merah, jahe, dan garam. Aduk-aduk..
			
			
		</li>
	
		<li>
			Tambahkan santan kental, lalu aduk-aduk terus bubur hingga mendidih dan kental. Koreksi rasa. Jika sudah cukup, matikan kompor..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this special food bubur kacang ijo beras merah gurih no sugar recipe. Thanks so much for reading. I am sure you can make this at home. There is gonna be interesting food in home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
