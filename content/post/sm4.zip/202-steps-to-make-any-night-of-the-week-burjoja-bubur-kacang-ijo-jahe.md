---
description: "Steps to Make Any-night-of-the-week Burjoja (Bubur Kacang Ijo Jahe)"
title: "Steps to Make Any-night-of-the-week Burjoja (Bubur Kacang Ijo Jahe)"
slug: 202-steps-to-make-any-night-of-the-week-burjoja-bubur-kacang-ijo-jahe

<p>
	<strong>Burjoja (Bubur Kacang Ijo Jahe)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/29218eca1e1a699a/680x482cq70/burjoja-bubur-kacang-ijo-jahe-foto-resep-utama.jpg" alt="Burjoja (Bubur Kacang Ijo Jahe)" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, hope you are having an amazing day today. Today, I will show you a way to make a distinctive dish, burjoja (bubur kacang ijo jahe). One of my favorites food recipes. For mine, I will make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Burjoja (Bubur Kacang Ijo Jahe) is one of the most well liked of recent trending foods in the world. It is simple, it's quick, it tastes delicious. It is enjoyed by millions daily. Burjoja (Bubur Kacang Ijo Jahe) is something that I have loved my whole life. They're nice and they look fantastic.
</p>

<p>
To get started with this particular recipe, we must prepare a few ingredients. You can cook burjoja (bubur kacang ijo jahe) using 12 ingredients and 9 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Burjoja (Bubur Kacang Ijo Jahe):</h3>

<ol>
	
		<li>{Make ready 400 gram of kacang ijo. </li>
	
		<li>{Make ready 1 1/2 L of air. </li>
	
		<li>{Get 2 ruas of jahe bakar,geprek. </li>
	
		<li>{Take 150 gram of gula merah,sisir. </li>
	
		<li>{Take 1 sdt of garam. </li>
	
		<li>{Take 1/2 sdt of vanili bubuk. </li>
	
		<li>{Take 1 sdm of gula pasir (optional). </li>
	
		<li>{Make ready 2 lembar of daun pandan. </li>
	
		<li>{Make ready  of Untuk santan. </li>
	
		<li>{Prepare 600 ml of santan kental (me: 1 bks kara+ 700ml air). </li>
	
		<li>{Take secukupnya of Garam. </li>
	
		<li>{Get 2 lembar of daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Burjoja (Bubur Kacang Ijo Jahe):</h3>

<ol>
	
		<li>
			Rendam kacang ijo selama 3-4 jam.
			
			
		</li>
	
		<li>
			Rebus kacang ijo dengan 1 1/2 L air. Tambahkan jahe, daun pandan dan masak sampai setengah matang..
			
			
		</li>
	
		<li>
			Masukan gula merah,garam dan vanili.
			
			
		</li>
	
		<li>
			Masak hingga matang kacang ijo empuk..
			
			
		</li>
	
		<li>
			Untuk santan.
			
			
		</li>
	
		<li>
			Rebus santan bersama daun pandan dan garam..
			
			
		</li>
	
		<li>
			Gunakan api kecil dan diaduk aduk
 supaya tidak pecah..
			
			
		</li>
	
		<li>
			Sajikan burjo bersama kuah santan selagi masih hangat..
			
			
		</li>
	
		<li>
			Hasil karena santan keenceran,tapi enak kok😁. Bisa diambil hikmahnya ya 😊.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food burjoja (bubur kacang ijo jahe) recipe. Thank you very much for reading. I'm confident you can make this at home. There is gonna be more interesting food at home recipes coming up. Remember to bookmark this page in your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
