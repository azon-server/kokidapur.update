---
description: "Simple Way to Prepare Perfect Bubur Kacang Ijo (Recook_Tya_Kitchen)"
title: "Simple Way to Prepare Perfect Bubur Kacang Ijo (Recook_Tya_Kitchen)"
slug: 212-simple-way-to-prepare-perfect-bubur-kacang-ijo-recook-tya-kitchen

<p>
	<strong>Bubur Kacang Ijo (Recook_Tya_Kitchen)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/2de0de3569af435c/680x482cq70/bubur-kacang-ijo-recook_tya_kitchen-foto-resep-utama.jpg" alt="Bubur Kacang Ijo (Recook_Tya_Kitchen)" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's Drew, welcome to our recipe page. Today, we're going to prepare a distinctive dish, bubur kacang ijo (recook_tya_kitchen). One of my favorites food recipes. This time, I'm gonna make it a bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur Kacang Ijo (Recook_Tya_Kitchen) is one of the most popular of recent trending meals in the world. It is enjoyed by millions every day. It's easy, it is fast, it tastes delicious. They're fine and they look fantastic. Bubur Kacang Ijo (Recook_Tya_Kitchen) is something that I have loved my entire life.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we must first prepare a few ingredients. You can cook bubur kacang ijo (recook_tya_kitchen) using 9 ingredients and 6 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo (Recook_Tya_Kitchen):</h3>

<ol>
	
		<li>{Make ready 250 gr of kacang ijo. </li>
	
		<li>{Take 1 of kelapa parut untuk santan. </li>
	
		<li>{Make ready 2 lbr of daun pandan. </li>
	
		<li>{Get 1 gelas belimbing of Gula pasir (sy 100gr). </li>
	
		<li>{Make ready 1 sdt of garam. </li>
	
		<li>{Take 1 bks of vanilli. </li>
	
		<li>{Prepare 1 ruas jempol of jahe (geprek). </li>
	
		<li>{Take 2 sachet of susu kental manis. </li>
	
		<li>{Make ready secukupnya of air matang. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo (Recook_Tya_Kitchen):</h3>

<ol>
	
		<li>
			Rendam kacang ijo (klo sy pagi direndam untuk dimasak sore) supaya tidak terlalu lama merebus nya).
			
			
		</li>
	
		<li>
			Peras santan (pisahkan Pati santan perasan pertama).
			
			
		</li>
	
		<li>
			Rebus kacang ijo yg sudah direndam tadi dengan air putih bersama daun Pandan &amp; jahe. Tunggu sampai menyusut dan kacang ijo mulai mekar (sesuai selera ya).
			
			
		</li>
	
		<li>
			Tambahkan santan,gula, vanili, dan garam. Jgn lupa diaduk sampai mendidih agar tidak pecah santan..
			
			
		</li>
	
		<li>
			Masukkan susu kental manis, terakhir baru masukkan Pati santan yg disisihkan tadi.. aduk&#34; sebentar, lalu matikan kompor..
			
			
		</li>
	
		<li>
			Siap dinikmati..hangat..nikmat.. MasyaAllah...
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this exceptional food bubur kacang ijo (recook_tya_kitchen) recipe. Thank you very much for your time. I'm confident that you can make this at home. There is gonna be more interesting food in home recipes coming up. Remember to bookmark this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
