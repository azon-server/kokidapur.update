---
description: "Steps to Make Favorite Bubur Manado"
title: "Steps to Make Favorite Bubur Manado"
slug: 459-steps-to-make-favorite-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/7efa01c2dd4f6160/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is John, welcome to our recipe site. Today, I'm gonna show you how to make a special dish, bubur manado. It is one of my favorites. For mine, I will make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bubur Manado is one of the most popular of recent trending foods in the world. It is easy, it's fast, it tastes yummy. It is appreciated by millions every day. Bubur Manado is something which I have loved my whole life. They're fine and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we must prepare a few ingredients. You can cook bubur manado using 13 ingredients and 3 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Get secukupnya of Nasi. </li>
	
		<li>{Make ready 1 ikat of bayam. </li>
	
		<li>{Take 1/2 ikat of kangkung. </li>
	
		<li>{Make ready 2 buah of jagung. </li>
	
		<li>{Get 2 buah of sereh potong jadi 2. </li>
	
		<li>{Prepare secukupnya of Kemangi. </li>
	
		<li>{Take 1/4 of kabocha kuning. </li>
	
		<li>{Make ready  of Air. </li>
	
		<li>{Make ready  of Garam atau penyedap rasa. </li>
	
		<li>{Prepare  of Pelengkap. </li>
	
		<li>{Prepare  of Ikan asin. </li>
	
		<li>{Get  of Sambal terasi. </li>
	
		<li>{Get  of Jeruk nipis (saya skip krn tidak ada). </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Manado:</h3>

<ol>
	
		<li>
			Rebus nasi dengan air sampai agak mengental dan air mulai sat.
			
			
		</li>
	
		<li>
			Cuci bersih semua sayuran. Masukkan kabocha dan jagung terlebih dahulu, sambil diaduk agar tidak gosong.
			
			
		</li>
	
		<li>
			Setelah agak sat masukkan kemangi, bayam, dan kangkung. Tambahkan penyedap rasa atau garam, tes rasa. Aduk terus sampai sayuran tercampur rata dan agak layu, tidak perlu terlalu lama agar kandungan gizi di sayurannya tidak hilang. Setelah rata matikan kompor dan sajikan bersama ikan asin, sambal terasi dan jeruk nipis..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this special food bubur manado recipe. Thank you very much for your time. I am confident that you will make this at home. There is gonna be more interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
