---
description: "Steps to Make Perfect Bubur Kacang Ijo"
title: "Steps to Make Perfect Bubur Kacang Ijo"
slug: 230-steps-to-make-perfect-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/7b98c0223ae8203f/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is Drew, welcome to our recipe site. Today, I will show you a way to prepare a distinctive dish, bubur kacang ijo. One of my favorites food recipes. This time, I am going to make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo is one of the most well liked of current trending meals in the world. It's easy, it is fast, it tastes delicious. It is enjoyed by millions daily. Bubur Kacang Ijo is something that I have loved my whole life. They are fine and they look fantastic.
</p>
<p>
	
</p>

<p>
To begin with this recipe, we have to first prepare a few ingredients. You can have bubur kacang ijo using 8 ingredients and 6 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Make ready 250 gr of Kacang Hijau. </li>
	
		<li>{Take 1 buah of kelapa parut (pisahkan untuk santannya). </li>
	
		<li>{Take 1500 ml of air. </li>
	
		<li>{Make ready 10 sdm of gula pasir. </li>
	
		<li>{Get 1 buah of gula merah. </li>
	
		<li>{Take Sejumput of garam. </li>
	
		<li>{Prepare 2 sdm of tepung maizena. </li>
	
		<li>{Get 1 of daun pandan (me: tdk pakai). </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Bersihkan kacang hijau, dan masukan air kemudian rebus sampai pecah.
			
			
		</li>
	
		<li>
			Masukan gula pasir, gula merah, dan garam.
			
			
		</li>
	
		<li>
			Larutkan tepung maizena ke dlm sedikit air panas aduk2 lalu tuang ke dalam kacang hijau.
			
			
		</li>
	
		<li>
			Di aduk sampai kental.
			
			
		</li>
	
		<li>
			Untuk santannya : rebus 250 ml air dari kelapa peras, dan tambahkan sejumput garam.
			
			
		</li>
	
		<li>
			Sajikan kacang hijau dengan santannya.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this exceptional food bubur kacang ijo recipe. Thanks so much for your time. I am confident you will make this at home. There's gonna be more interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
