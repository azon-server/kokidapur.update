---
description: "Steps to Make Quick Bubur Manado"
title: "Steps to Make Quick Bubur Manado"
slug: 254-steps-to-make-quick-bubur-manado

<p>
	<strong>Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/afca24441e5bddfb/680x482cq70/bubur-manado-foto-resep-utama.jpg" alt="Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an amazing day today. Today, we're going to make a special dish, bubur manado. It is one of my favorites. For mine, I will make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur Manado is one of the most popular of recent trending meals on earth. It is appreciated by millions every day. It is simple, it's quick, it tastes delicious. Bubur Manado is something that I've loved my entire life. They're nice and they look wonderful.
</p>

<p>
To begin with this recipe, we have to first prepare a few ingredients. You can have bubur manado using 26 ingredients and 5 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Manado:</h3>

<ol>
	
		<li>{Prepare 1 cup of Beras. </li>
	
		<li>{Prepare  of Ayam 1/2 ekor untuk kaldu ayam. </li>
	
		<li>{Prepare 1 bh of Jagung. </li>
	
		<li>{Make ready 250 gr of Labu parang. </li>
	
		<li>{Prepare 2000 ml of Air. </li>
	
		<li>{Make ready  of Bahan2 Sayuran. </li>
	
		<li>{Prepare 1 lbr of daun kunyit (saya skip). </li>
	
		<li>{Make ready 1 ikat of Kangkung. </li>
	
		<li>{Make ready 1 ikat of Bayam. </li>
	
		<li>{Take 1 ikat of Kemangi. </li>
	
		<li>{Get 1 btg of Daun bawang. </li>
	
		<li>{Get  of Bumbu2. </li>
	
		<li>{Make ready 2 btg of Serai. </li>
	
		<li>{Take 4 lbr of Daun Jeruk. </li>
	
		<li>{Make ready 1 lbr of Daun Pandan. </li>
	
		<li>{Make ready  of Daun kunyit (saya skip). </li>
	
		<li>{Get 1 ruas of jahe (saya skip). </li>
	
		<li>{Prepare  of Bawang merah 4siung diiris2. </li>
	
		<li>{Prepare  of Bawang putih 1siung digeprek. </li>
	
		<li>{Prepare 1 sdt of Garam. </li>
	
		<li>{Prepare 1 sdt of Lada. </li>
	
		<li>{Take 1 sdt of Bubuk kaldu. </li>
	
		<li>{Make ready  of Pelengkap. </li>
	
		<li>{Get  of Ikan asin Jambal (saya skip ndak punya). </li>
	
		<li>{Get  of Ikan teri medan. </li>
	
		<li>{Make ready  of Sambal bawang. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Manado:</h3>

<ol>
	
		<li>
			Siapkan beras, cuci bersih, sisihkan. Labu cuci bersih kemudian potong2. Ayam cuci bersih kemudian di rebus dg air 2000ml sampai matang, angkat ayam. Kaldu ayam siap digunakan..
			
			
		</li>
	
		<li>
			Air rebusan ayam, masukan labu parang sampai labu mulai layu, masukan beras, serai, daun jeruk daun pandan, bawang merah iris dan bawang putih geprek. aduk2 kemudian masukan garam, lada dan kaldu bubuk. Jangan lupa selalu di aduk yah..
			
			
		</li>
	
		<li>
			Jagung di pipil kemudian masukan ke dlm bubur. Aduk2 bubur nya..
			
			
		</li>
	
		<li>
			Setelah bubur nya sdh mulai matang, masukan sayuran, aduk2 rata sampai sayuran layu, kemudian masukan kemangi dan teri medan yg sdh di sangrai. Matikan kompor dan angkat..
			
			
		</li>
	
		<li>
			Bubur sdh siap di santap, tambahkan sambal bawang, asli nya sih pakai sambal roa, berhubung ndak ada, pakai sambal bawang juga enak kok, selamat mencoba....
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this special food bubur manado recipe. Thanks so much for reading. I am confident you can make this at home. There's gonna be more interesting food in home recipes coming up. Don't forget to save this page in your browser, and share it to your loved ones, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
