---
description: "Easiest Way to Make Any-night-of-the-week Bubur Kacang Ijo &amp;amp; Ketan Hitam"
title: "Easiest Way to Make Any-night-of-the-week Bubur Kacang Ijo &amp;amp; Ketan Hitam"
slug: 128-easiest-way-to-make-any-night-of-the-week-bubur-kacang-ijo-and-amp-ketan-hitam

<p>
	<strong>Bubur Kacang Ijo &amp; Ketan Hitam</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/8a9858e551361adc/680x482cq70/bubur-kacang-ijo-ketan-hitam-foto-resep-utama.jpg" alt="Bubur Kacang Ijo &amp; Ketan Hitam" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, I hope you're having an incredible day today. Today, I will show you a way to make a special dish, bubur kacang ijo &amp; ketan hitam. It is one of my favorites. This time, I'm gonna make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo &amp; Ketan Hitam is one of the most popular of current trending meals in the world. It is easy, it is quick, it tastes delicious. It is appreciated by millions every day. They are nice and they look fantastic. Bubur Kacang Ijo &amp; Ketan Hitam is something which I have loved my entire life.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we must first prepare a few ingredients. You can cook bubur kacang ijo &amp; ketan hitam using 15 ingredients and 7 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo &amp; Ketan Hitam:</h3>

<ol>
	
		<li>{Take  of Bahan Burjo :. </li>
	
		<li>{Prepare 300 gr of kacang hijau. </li>
	
		<li>{Make ready 1 gengam of beras putih (kurleb 100gr). </li>
	
		<li>{Prepare 2 ruas of jahe, geprek. </li>
	
		<li>{Make ready 1 batang of kecil kayu manis (*boleh skip). </li>
	
		<li>{Take 2 lembar of daun pandan. </li>
	
		<li>{Take  of Gula aren sesuai selera (me: 1 buletan kecil). </li>
	
		<li>{Make ready  of Gula pasir sesuai selera (me: 2 sdm). </li>
	
		<li>{Take 1/2 sdt of Garam. </li>
	
		<li>{Make ready  of Bahan Bubur Ketan Hitam :. </li>
	
		<li>{Prepare 200 gr of ketan hitam. </li>
	
		<li>{Get 1/2 sdt of garam. </li>
	
		<li>{Get 1 sdm of gula pasir. </li>
	
		<li>{Make ready  of Pelengkap :. </li>
	
		<li>{Prepare  of Santan Kara (me: 2sdm fiber cream + 100ml air hangat). </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo &amp; Ketan Hitam:</h3>

<ol>
	
		<li>
			Campurkan kacang hijau dan beras putih, rendam dengan air. Ketan hitam juga direndam di wadah yang terpisah. Saya rendam semalaman karena masaknya subuh untuk sarapan pagi. Tujuan direndam supaya kacang hijau dan ketan hitam masak sempurna dan cepat matang. Tujuan kacang hijau dicampur beras supaya bubur kacang hijaunya kental (ada tajin, kalo orang jawa bilang).
			
			
		</li>
	
		<li>
			Rebus kacang hijau + beras dan ketan hitam dipanci terpisah. Tambahkan jahe, kayu manis dan daun pandan bersama rebusan kacang hijau. Masak hingga menjadi bubur..
			
			
		</li>
	
		<li>
			Jika ketan hitam sudah menjadi bubur, tambahkan garam dan gula pasir. Koreksi rasa. Angkat dan sisihkan..
			
			
		</li>
	
		<li>
			Jika kacang hijau sudah menjadi bubur, tambahkan garam, gula merah dan gula pasir. Koreksi rasa. Angkat dan sisihkan..
			
			
		</li>
	
		<li>
			Larutkan fibercream dengan air panas. Aduk hingga larut. Sisihkan..
			
			
		</li>
	
		<li>
			Tata di mangkuk saji bubur kacang hijau 3 sendok sayur, ketan hitam 1 sendol sayur dan terakhir larutan fiber cream pengganti santan..
			
			
		</li>
	
		<li>
			Siap dinikmati....
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up with this special food bubur kacang ijo &amp; ketan hitam recipe. Thank you very much for your time. I am sure that you will make this at home. There is gonna be interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
