---
description: "Steps to Prepare Super Quick Homemade Tinutuan a.k.a Bubur Manado"
title: "Steps to Prepare Super Quick Homemade Tinutuan a.k.a Bubur Manado"
slug: 352-steps-to-prepare-super-quick-homemade-tinutuan-aka-bubur-manado

<p>
	<strong>Tinutuan a.k.a Bubur Manado</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/b65ecba35acddc45/680x482cq70/tinutuan-aka-bubur-manado-foto-resep-utama.jpg" alt="Tinutuan a.k.a Bubur Manado" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you are having an incredible day today. Today, we're going to prepare a distinctive dish, tinutuan a.k.a bubur manado. It is one of my favorites. This time, I'm gonna make it a bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Tinutuan a.k.a Bubur Manado is one of the most popular of current trending meals on earth. It is simple, it is quick, it tastes delicious. It is enjoyed by millions every day. Tinutuan a.k.a Bubur Manado is something which I've loved my entire life. They are nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we have to first prepare a few components. You can have tinutuan a.k.a bubur manado using 17 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Tinutuan a.k.a Bubur Manado:</h3>

<ol>
	
		<li>{Get 1 gelas takar of beras (me: kurleb 135 gr). </li>
	
		<li>{Make ready 1 liter of air. </li>
	
		<li>{Get 200 gr of labu kuning, potong dadu kecil. </li>
	
		<li>{Make ready 1 bh (120 gr) of ubi merah, potong dadu kecil. </li>
	
		<li>{Prepare 1 bh of jagung, pipil. </li>
	
		<li>{Prepare 1 ikat of bayam. </li>
	
		<li>{Make ready 1 ikat of kemangi. </li>
	
		<li>{Get 1 btg of daun bawang, iris halus. </li>
	
		<li>{Get 1 btg of sereh, geprek (resep asli 3 btg). </li>
	
		<li>{Prepare 2 sdt of garam. </li>
	
		<li>{Get 1 sdt of kaldu bubuk. </li>
	
		<li>{Take 1/2 sdt of gula. </li>
	
		<li>{Get 3 siung of bawang putih, cincang halus. </li>
	
		<li>{Get 3 sdm of minyak sayur, utk menumis. </li>
	
		<li>{Get 1/2 sdt of lada bubuk. </li>
	
		<li>{Make ready  of Pelengkap:. </li>
	
		<li>{Make ready Secukupnya of ikan asin, sambel, bakwan jagung, kerupuk. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Tinutuan a.k.a Bubur Manado:</h3>

<ol>
	
		<li>
			Cuci bersih beras, sisihkan. Campur di dlm panci: beras, labu kuning, ubi, jagung pipil, sereh &amp; air. Masak dgn api sdg sambil diaduk2..
			
			
		</li>
	
		<li>
			Sementara itu, tumis bawang putih cincang &amp; lada bubuk sampai harum (tp jgn sampe gosong ya).
			
			
		</li>
	
		<li>
			Setelah 3/4 matang buburnya,  masukkan tumisan bawang td.  Aduk2 rata sambil ditambahkan garam, gula &amp; kaldu bubuk, aduk2 lagi..
			
			
		</li>
	
		<li>
			Terakhir masukkan sayuran: bayam,  kemangi &amp; daun bawang,  aduk2 lagi sambil koreksi rasa ya. Masak sampai bubur matang (saya gak sampe halus bener ya buburnya).
			
			
		</li>
	
		<li>
			Penyajian: tuang bubur di mangkok/piring, tambahkan ikan asin,  sambel &amp; bakwan jagung serta kerupuk.  Nikmati bubur Manado utk sarapan bersama keluarga..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up for this special food tinutuan a.k.a bubur manado recipe. Thanks so much for your time. I am sure that you can make this at home. There is gonna be interesting food in home recipes coming up. Remember to bookmark this page in your browser, and share it to your family, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
