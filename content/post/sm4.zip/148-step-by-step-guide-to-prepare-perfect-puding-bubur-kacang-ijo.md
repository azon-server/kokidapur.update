---
description: "Step-by-Step Guide to Prepare Perfect Puding bubur kacang ijo"
title: "Step-by-Step Guide to Prepare Perfect Puding bubur kacang ijo"
slug: 148-step-by-step-guide-to-prepare-perfect-puding-bubur-kacang-ijo

<p>
	<strong>Puding bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/62dd5400b84a71ff/680x482cq70/puding-bubur-kacang-ijo-foto-resep-utama.jpg" alt="Puding bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you are having an incredible day today. Today, I will show you a way to prepare a distinctive dish, puding bubur kacang ijo. It is one of my favorites. This time, I'm gonna make it a little bit tasty. This is gonna smell and look delicious.
</p>
	
<p>
	Puding bubur kacang ijo is one of the most favored of recent trending foods on earth. It is enjoyed by millions daily. It is simple, it is quick, it tastes delicious. They're nice and they look wonderful. Puding bubur kacang ijo is something which I have loved my entire life.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we have to prepare a few components. You can have puding bubur kacang ijo using 8 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Puding bubur kacang ijo:</h3>

<ol>
	
		<li>{Get 1 bungkus of agar bubuk. </li>
	
		<li>{Prepare 1 mangkok of bubur kacang ijo. </li>
	
		<li>{Get 100 gr of gula pasir. </li>
	
		<li>{Make ready 100 gr of santan. </li>
	
		<li>{Make ready 3 gelas of air. </li>
	
		<li>{Get  of Lapisan putih. </li>
	
		<li>{Make ready 50 ml of santan kental. </li>
	
		<li>{Get 5 sendok of adonan agar yg sdh matang. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Puding bubur kacang ijo:</h3>

<ol>
	
		<li>
			Siapkan bahan. Tuang air dipanci masukkan gula agar agar bubuk, bubur kacang ijo, aduk rata, lalu hidupkan kompor api sedang..
			
			
		</li>
	
		<li>
			Sambil di aduk terus, masukkan santan aduk lagi, aduk terus agar santan tidak pecah, jika sudah hampir mendidih kecilkan api tunggu sebentar sambil diaduk, dan matikan kompor..
			
			
		</li>
	
		<li>
			Lapisan putihnya: masak santan bersama 5 sdm adonan agar yg sudah matang dengan api kecil sambil diaduk jika sudah hampir mendidih langsung matikan kompor nya. Tuang lapisan putih ke cetakan, diamkan sampai mengeras..
			
			
		</li>
	
		<li>
			Setelah lapisan putih mengeras tuangkan adonan agar bubur kacang ijo panas panas kecetakkan pelan pelan sampai habis..
			
			
		</li>
	
		<li>
			Dinginkan dan masukkan kulkas, jika sudah dingin dari kulkas keluarkan dari cetakan, dan hidangkan..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food puding bubur kacang ijo recipe. Thank you very much for reading. I am confident that you will make this at home. There is gonna be interesting food at home recipes coming up. Remember to save this page on your browser, and share it to your loved ones, friends and colleague. Thank you for reading. Go on get cooking!
</p>
