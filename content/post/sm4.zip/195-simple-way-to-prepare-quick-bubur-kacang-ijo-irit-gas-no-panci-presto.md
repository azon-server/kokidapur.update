---
description: "Simple Way to Prepare Quick Bubur Kacang Ijo. IRIT GAS👌 No Panci Presto😄"
title: "Simple Way to Prepare Quick Bubur Kacang Ijo. IRIT GAS👌 No Panci Presto😄"
slug: 195-simple-way-to-prepare-quick-bubur-kacang-ijo-irit-gas-no-panci-presto

<p>
	<strong>Bubur Kacang Ijo. IRIT GAS👌 No Panci Presto😄</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/5b51d8f571bab8f3/680x482cq70/bubur-kacang-ijo-irit-gas👌-no-panci-presto😄-foto-resep-utama.jpg" alt="Bubur Kacang Ijo. IRIT GAS👌 No Panci Presto😄" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it is Brad, welcome to my recipe page. Today, I will show you a way to prepare a special dish, bubur kacang ijo. irit gas👌 no panci presto😄. It is one of my favorites. For mine, I'm gonna make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo. IRIT GAS👌 No Panci Presto😄 is one of the most popular of recent trending foods on earth. It is enjoyed by millions daily. It is easy, it is fast, it tastes yummy. They are fine and they look fantastic. Bubur Kacang Ijo. IRIT GAS👌 No Panci Presto😄 is something which I have loved my entire life.
</p>
<p>
	
</p>

<p>
To get started with this particular recipe, we must prepare a few ingredients. You can have bubur kacang ijo. irit gas👌 no panci presto😄 using 7 ingredients and 6 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo. IRIT GAS👌 No Panci Presto😄:</h3>

<ol>
	
		<li>{Make ready 8 genggam of kacang ijo. </li>
	
		<li>{Take 250 gr of gula merah. </li>
	
		<li>{Get 1 L of air. </li>
	
		<li>{Prepare 400 ml of santan kental (dari 1/2 butir kelapa). </li>
	
		<li>{Make ready 2 ruas of jahe (memarkan). </li>
	
		<li>{Take 1/2 sdt of garam. </li>
	
		<li>{Make ready 1/2 sdt of vanilli / ganti daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur Kacang Ijo. IRIT GAS👌 No Panci Presto😄:</h3>

<ol>
	
		<li>
			Masak air 1L hingga mendidih.
			
			
		</li>
	
		<li>
			Masukan kacang hijau yg telah dicuci bersih.masak selama 5 menit dengan api besar..
			
			
		</li>
	
		<li>
			Penampakan setelah dimasak 5 menit.matikan api. Pancinya ditutup. Biarkan 30 menit.
			
			
		</li>
	
		<li>
			Penampakan setelah 30 menit.sudah pecah kacang hijaunya..
			
			
		</li>
	
		<li>
			Masukan santan,gula,garam,vanilli,jahe. Masak selama 7 menit/ sampai mendidih. Jangan lupa diaduk2 supaya santan tdk pecah ya☺.
			
			
		</li>
	
		<li>
			Angkat.tuang kemangkuk..siap disajikan...yummy😋.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this special food bubur kacang ijo. irit gas👌 no panci presto😄 recipe. Thank you very much for your time. I'm confident you will make this at home. There's gonna be interesting food in home recipes coming up. Remember to save this page in your browser, and share it to your family, friends and colleague. Thank you for reading. Go on get cooking!
</p>
