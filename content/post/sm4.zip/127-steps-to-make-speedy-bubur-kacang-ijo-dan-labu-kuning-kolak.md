---
description: "Steps to Make Speedy Bubur Kacang Ijo dan Labu Kuning (Kolak)"
title: "Steps to Make Speedy Bubur Kacang Ijo dan Labu Kuning (Kolak)"
slug: 127-steps-to-make-speedy-bubur-kacang-ijo-dan-labu-kuning-kolak

<p>
	<strong>Bubur Kacang Ijo dan Labu Kuning (Kolak)</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/97fa456fa4c69f63/680x482cq70/bubur-kacang-ijo-dan-labu-kuning-kolak-foto-resep-utama.jpg" alt="Bubur Kacang Ijo dan Labu Kuning (Kolak)" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's Drew, welcome to our recipe page. Today, I will show you a way to prepare a special dish, bubur kacang ijo dan labu kuning (kolak). One of my favorites food recipes. This time, I will make it a bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo dan Labu Kuning (Kolak) is one of the most favored of recent trending foods on earth. It's easy, it's fast, it tastes yummy. It is enjoyed by millions every day. They are fine and they look wonderful. Bubur Kacang Ijo dan Labu Kuning (Kolak) is something which I have loved my entire life.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we must first prepare a few components. You can have bubur kacang ijo dan labu kuning (kolak) using 13 ingredients and 3 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo dan Labu Kuning (Kolak):</h3>

<ol>
	
		<li>{Prepare 300 gr of labu kuning kupas potong dadu. </li>
	
		<li>{Get 125 of kacang hijau rendam 1 jam. </li>
	
		<li>{Make ready 2 of daun pandan. </li>
	
		<li>{Prepare 2 keping of gula merah. </li>
	
		<li>{Take 3 sdm of gula pasir (sesuaikan). </li>
	
		<li>{Take 1/4 sdt of garam. </li>
	
		<li>{Take 65 ml of santan kental. </li>
	
		<li>{Prepare Secukupnya of air. </li>
	
		<li>{Prepare 1 ruas of jahe geprek. </li>
	
		<li>{Prepare 1 of kayumanis. </li>
	
		<li>{Make ready  of Bahan pelengkap. </li>
	
		<li>{Prepare  of Ketan. </li>
	
		<li>{Make ready  of Es batu. </li>
	
</ol>
<p>
	
</p>

<h3>Steps to make Bubur Kacang Ijo dan Labu Kuning (Kolak):</h3>

<ol>
	
		<li>
			Siapkan bahan2 rendam kacang hijau dan ketan. Rebus kacang hijau, garam, kayumanis, jahe dan pandan hingga mendidih matikan api tutup rata dan diamkan 30menit dulu. Kemudian rebus lagi dan masukan labu cek kematangan kalau sudah matang baru masukan gula..
			
			
		</li>
	
		<li>
			Masukan santan aduk terus dan koreksi rasa. Sajikan tambah ketan juga enak.
			
			
		</li>
	
		<li>
			Atau tambah ice batu.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur kacang ijo dan labu kuning (kolak) recipe. Thanks so much for your time. I'm confident you will make this at home. There's gonna be interesting food in home recipes coming up. Don't forget to save this page in your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
