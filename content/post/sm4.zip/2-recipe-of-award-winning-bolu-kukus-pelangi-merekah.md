---
description: "Recipe of Award-winning Bolu Kukus Pelangi Merekah"
title: "Recipe of Award-winning Bolu Kukus Pelangi Merekah"
slug: 2-recipe-of-award-winning-bolu-kukus-pelangi-merekah

<p>
	<strong>Bolu Kukus Pelangi Merekah</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/d9e57d82ad2cd676/680x482cq70/bolu-kukus-pelangi-merekah-foto-resep-utama.jpg" alt="Bolu Kukus Pelangi Merekah" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, I hope you are having an incredible day today. Today, I'm gonna show you how to make a special dish, bolu kukus pelangi merekah. It is one of my favorites food recipes. This time, I'm gonna make it a bit unique. This will be really delicious.
</p>
	
<p>
	Bolu Kukus Pelangi Merekah is one of the most popular of current trending foods on earth. It's easy, it is quick, it tastes delicious. It is appreciated by millions daily. They're fine and they look fantastic. Bolu Kukus Pelangi Merekah is something that I have loved my whole life.
</p>
<p>
	
</p>

<p>
To begin with this particular recipe, we must first prepare a few components. You can cook bolu kukus pelangi merekah using 6 ingredients and 8 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bolu Kukus Pelangi Merekah:</h3>

<ol>
	
		<li>{Prepare 200 gr of gula pasir. </li>
	
		<li>{Prepare 2 of telur ayam. </li>
	
		<li>{Get 1/2 sdt of sp. </li>
	
		<li>{Take 1/2 sdt of vanilli (tidak munjung). </li>
	
		<li>{Make ready 250 gr of Tepung Terigu (saya pakai segitiga biru). </li>
	
		<li>{Make ready 1 sachet of susu dancow putih yg sdh dilarutkan dg 120ml/ 1 gelas air. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bolu Kukus Pelangi Merekah:</h3>

<ol>
	
		<li>
			Panaskan dandang/pengukus, sembari kita membuat adonan.. apinya kecil aja ya mom.
			
			
		</li>
	
		<li>
			Mixer terlebih dahulu untuk gula, telur, sp, dan vanilli nya hingga putih mengembang.. dan dipastikan agar halus (sampai gula sdh hancur).
			
			
		</li>
	
		<li>
			Jika adonan td sudah putih halus mengembang, masukan susu yg sudah dilarutkan ke dalam adonan sedikit demi sedikit (jangan lupa kurangi kecepatan mixer dulu ya mom.. agar air tidak menyiprat kemana-mana) setelah sdh agak bercampur mixer boleh di tambahkan kecepatannya mom.
			
			
		</li>
	
		<li>
			Jika sudah merata, masukan terigu sedikit demi sedikit ke dalam adonan (jangan lupa kurangi kecepatan saat memasukan terigu ya bun.. jika kiranya sdh mulai tercampur, boleh dinaikan tingkat kecepatan mixernya).. Dari saya pribadi, untuk memasak atau membuat kue kuncinya harus sabar, tenang, fokus, hati gembira, agar saat memasaknya terasa asik 😁 dan jangan lupa baca basmallah.
			
			
		</li>
	
		<li>
			Pisahkan adonan yang mau diberi warna ke dlm wadah kecil/mangkok, untuk takaran disesuaikan saja.. untuk warna saya pake 3 warna.
			
			
		</li>
	
		<li>
			Masukan adonan putih (tdk diwarnai) ke dalam kertas bolu yg sudah diletakan diatas loyang.. beri topping warna sesuai kesukaan bunda² 🥰.
			
			
		</li>
	
		<li>
			Masukan kedalam dandang yang sudah dipanaskan tadi... tunggu hingga 20-25 menit (tergantung besar kecil api kompor ya Mom) tapi juga jangan terlalu sering dibuka.
			
			
		</li>
	
		<li>
			Pisahkan bolu dari masing-masing loyangnya.. Lalu Bolu siap dihidangkan 🥰🥰🧁🧁.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap it up with this exceptional food bolu kukus pelangi merekah recipe. Thank you very much for reading. I'm confident that you can make this at home. There's gonna be more interesting food at home recipes coming up. Don't forget to bookmark this page on your browser, and share it to your family, friends and colleague. Thanks again for reading. Go on get cooking!
</p>
