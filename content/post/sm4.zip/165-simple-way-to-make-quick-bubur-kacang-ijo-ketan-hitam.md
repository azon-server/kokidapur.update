---
description: "Simple Way to Make Quick Bubur kacang ijo ketan hitam"
title: "Simple Way to Make Quick Bubur kacang ijo ketan hitam"
slug: 165-simple-way-to-make-quick-bubur-kacang-ijo-ketan-hitam

<p>
	<strong>Bubur kacang ijo ketan hitam</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/b6ea95dd38ed9a3c/680x482cq70/bubur-kacang-ijo-ketan-hitam-foto-resep-utama.jpg" alt="Bubur kacang ijo ketan hitam" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, hope you're having an amazing day today. Today, we're going to make a special dish, bubur kacang ijo ketan hitam. One of my favorites. For mine, I'm gonna make it a bit unique. This will be really delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo ketan hitam is one of the most favored of current trending foods on earth. It's appreciated by millions daily. It is simple, it's quick, it tastes delicious. They're fine and they look wonderful. Bubur kacang ijo ketan hitam is something which I have loved my whole life.
</p>

<p>
To get started with this particular recipe, we have to prepare a few components. You can cook bubur kacang ijo ketan hitam using 8 ingredients and 4 steps. Here is how you cook it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo ketan hitam:</h3>

<ol>
	
		<li>{Make ready 250 gr of kacang ijo. </li>
	
		<li>{Make ready 100 gr of ketan hitam. </li>
	
		<li>{Prepare 200 gr of gula merah. </li>
	
		<li>{Prepare sesuai selera of gula putih. </li>
	
		<li>{Prepare secukupnya of santan. </li>
	
		<li>{Take sejumput of garam. </li>
	
		<li>{Prepare 3 sdm of tapioka buat pengental. </li>
	
		<li>{Take  of daun pandan. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo ketan hitam:</h3>

<ol>
	
		<li>
			Rebus kacang ijo dengan pandan sampai empuk.
			
			
		</li>
	
		<li>
			Rebus terpisah ketan hitam dengan pandan.
			
			
		</li>
	
		<li>
			Bila rebusan kacang ijo telah pecah empuk masukkan santan cair dan ketan hitam yg telah mekar empuk beri gula merah, gula putih sedikit garam, masak hingga mendidih, tambahkan santan kental, bila sdh mendidih lagi masukkan tapioka yg telah diencerkan dengan sedikit air aduk rata, cek rasa.
			
			
		</li>
	
		<li>
			Siap disantap..... 😘.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that is going to wrap this up for this special food bubur kacang ijo ketan hitam recipe. Thanks so much for reading. I am confident that you will make this at home. There's gonna be more interesting food in home recipes coming up. Don't forget to save this page on your browser, and share it to your loved ones, colleague and friends. Thanks again for reading. Go on get cooking!
</p>
