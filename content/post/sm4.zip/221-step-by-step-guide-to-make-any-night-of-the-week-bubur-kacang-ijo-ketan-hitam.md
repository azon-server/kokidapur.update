---
description: "Step-by-Step Guide to Make Any-night-of-the-week Bubur kacang ijo + ketan hitam"
title: "Step-by-Step Guide to Make Any-night-of-the-week Bubur kacang ijo + ketan hitam"
slug: 221-step-by-step-guide-to-make-any-night-of-the-week-bubur-kacang-ijo-ketan-hitam

<p>
	<strong>Bubur kacang ijo + ketan hitam</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/e2a46582c83d097f/680x482cq70/bubur-kacang-ijo-ketan-hitam-foto-resep-utama.jpg" alt="Bubur kacang ijo + ketan hitam" style="width: 100%;">
	
	
</p>
<p>
	Hello everybody, it's John, welcome to our recipe page. Today, we're going to make a distinctive dish, bubur kacang ijo + ketan hitam. It is one of my favorites food recipes. For mine, I am going to make it a little bit tasty. This will be really delicious.
</p>
	
<p>
	Bubur kacang ijo + ketan hitam is one of the most popular of recent trending foods on earth. It is easy, it's quick, it tastes delicious. It is enjoyed by millions daily. Bubur kacang ijo + ketan hitam is something which I have loved my entire life. They are nice and they look wonderful.
</p>
<p>
	
</p>

<p>
To get started with this recipe, we have to first prepare a few ingredients. You can have bubur kacang ijo + ketan hitam using 6 ingredients and 4 steps. Here is how you can achieve it.
</p>

<h3>The ingredients needed to make Bubur kacang ijo + ketan hitam:</h3>

<ol>
	
		<li>{Get 250 of ketan hitam, rendam 8 jam (semalaman). </li>
	
		<li>{Take 250 of kacang hijau. </li>
	
		<li>{Make ready 4 lembar of daun pandan. </li>
	
		<li>{Get 1 butir of kelapa, saring pisan santan kental dan encernya. </li>
	
		<li>{Prepare Sedikit of garam. </li>
	
		<li>{Get sesuai selera of Gula. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo + ketan hitam:</h3>

<ol>
	
		<li>
			Cuci bersih ketan hitam, masukan presto (gula pasir, 2 lembar pandan)+ air sampai satu ruas diatas beras ketan. Presto 15 menit setelah bunyi berdesis..
			
			
		</li>
	
		<li>
			Masak Kacang hijau, tambahkan air sampai diatas nya, didihkan setelah mendidih kecilkan api,masukan santan encer,gula, daun pandan kemudian tutup, masak hingga empuk. Ngga usah direndem ya.... Dengan cara ini kacang hijau bisa cepet empuk ko...
			
			
		</li>
	
		<li>
			Sajikan bersama ketan hitam dan kacang hijau, kemudian beri santan kental yang telah diberi garam secukupnya,,,.
			
			
		</li>
	
		<li>
			Ohya,,kalau kacang hijau mau kental ditambah 1 s/d 2 Sdm tepung maizena yg diencerkan,masukan kedalam kacang hijau sampai mendidih yaaa,,,.
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap this up for this exceptional food bubur kacang ijo + ketan hitam recipe. Thank you very much for your time. I am confident that you can make this at home. There's gonna be more interesting food at home recipes coming up. Remember to save this page in your browser, and share it to your loved ones, colleague and friends. Thank you for reading. Go on get cooking!
</p>
