---
description: "Recipe of Homemade Bubur kacang ijo"
title: "Recipe of Homemade Bubur kacang ijo"
slug: 140-recipe-of-homemade-bubur-kacang-ijo

<p>
	<strong>Bubur kacang ijo</strong>. 
	
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/8a4105a0f5373f2a/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur kacang ijo" style="width: 100%;">
	
	
</p>
<p>
	Hey everyone, it's Jim, welcome to our recipe site. Today, I will show you a way to make a distinctive dish, bubur kacang ijo. It is one of my favorites. For mine, I'm gonna make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	
</p>
<p>
	Bubur kacang ijo is one of the most well liked of recent trending meals on earth. It's easy, it is fast, it tastes yummy. It's enjoyed by millions daily. Bubur kacang ijo is something that I've loved my entire life. They're nice and they look wonderful.
</p>

<p>
To begin with this particular recipe, we must prepare a few ingredients. You can cook bubur kacang ijo using 6 ingredients and 3 steps. Here is how you cook that.
</p>

<h3>The ingredients needed to make Bubur kacang ijo:</h3>

<ol>
	
		<li>{Get 100 gram of kacang hijau, rendam semalaman. </li>
	
		<li>{Make ready 600 ml of air. </li>
	
		<li>{Get 500 ml of santan kental. </li>
	
		<li>{Make ready 170 gram of gula merah. </li>
	
		<li>{Get 25 gram of gula pasir. </li>
	
		<li>{Get 1/2 sdm of garam. </li>
	
</ol>
<p>
	
</p>

<h3>Instructions to make Bubur kacang ijo:</h3>

<ol>
	
		<li>
			Rebus kacang hijau hingga mekar semua bulirnya..
			
			
		</li>
	
		<li>
			Masukkan gula merah dan gula pasir. Tunggu hingga mendidih..
			
			
		</li>
	
		<li>
			Masukkan santan dan garam. Masak hingga mendidih..
			
			
		</li>
	
</ol>

<p>
	
</p>

<p>
	So that's going to wrap it up with this exceptional food bubur kacang ijo recipe. Thank you very much for your time. I'm sure that you can make this at home. There's gonna be more interesting food at home recipes coming up. Remember to save this page in your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
