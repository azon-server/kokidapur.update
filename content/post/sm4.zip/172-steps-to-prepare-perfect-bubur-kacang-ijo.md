---
description: "Steps to Prepare Perfect Bubur Kacang Ijo"
title: "Steps to Prepare Perfect Bubur Kacang Ijo"
slug: 172-steps-to-prepare-perfect-bubur-kacang-ijo

<p>
	<strong>Bubur Kacang Ijo</strong>. 
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>
<p>
	
	<img src="https://img-global.cpcdn.com/recipes/0e24348590cb923e/680x482cq70/bubur-kacang-ijo-foto-resep-utama.jpg" alt="Bubur Kacang Ijo" style="width: 100%;">
	
	
		Resep bubur kacang ijo itu sendiri ada berbagai macam dengan tambahan bahan yang melengkapinya.
	
		Cara bikin bubur kacang hijau / ijo memerlukan trik dan tips tersendiri, sehingga hasilnya bisa lebih bagus dan juga enak serta lembut.
	
		Sebenarnya tidak ada yang istimewa saat anda membuat.
	
</p>
<p>
	Hello everybody, hope you're having an incredible day today. Today, I will show you a way to prepare a distinctive dish, bubur kacang ijo. It is one of my favorites food recipes. This time, I am going to make it a little bit unique. This is gonna smell and look delicious.
</p>
	
<p>
	Bubur Kacang Ijo is one of the most popular of recent trending meals in the world. It is simple, it is quick, it tastes delicious. It's appreciated by millions every day. They're fine and they look wonderful. Bubur Kacang Ijo is something that I have loved my whole life.
</p>
<p>
	Bubur kacang ijo adalah makanan yang berbahan dasar kacang ijo. Tidak hanya kacang ijo bubur kacang ijo ini dilegkapi dengan bahan lainya seperti beras merah, santan, gula jawa, dan lain-lain. Resep bubur kacang ijo enak, dan cepat mekar atau empuk.
</p>

<p>
To get started with this particular recipe, we must prepare a few ingredients. You can have bubur kacang ijo using 7 ingredients and 5 steps. Here is how you can achieve that.
</p>

<h3>The ingredients needed to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>{Make ready 1/4 kg of kacang ijo dibersihkan dan rendam semalaman lebih baik. </li>
	
		<li>{Make ready 1 of atau 2 genggam beras (bila ingin kental) rendam sekalian dalam kacang ijo. </li>
	
		<li>{Take 150 gr of gula merah. </li>
	
		<li>{Take 1 ruas of jahe bersihkan dan geprek. </li>
	
		<li>{Prepare 2 lembar of daun pandan ikat. </li>
	
		<li>{Get 1 of Santan kara kecil. </li>
	
		<li>{Make ready secukupnya of gula dan garam. </li>
	
</ol>
<p>
	
		Bubur kacang hejo (su) Bubur kacang ijo (jv) Burjo.
	
		Slightly different names may be used in different regions of Indonesia, such as kacang ijo in Javanese areas.
	
		Cara masak bubur kacang ijo super simple dan enak.
	
		Rahasia Peyek Kacang Ijo Renyah, Tidak Keras dan Tahan Lama Bu Yun kali inia akan membagikan resep, tips dan tutorial cara.
	
</p>

<h3>Instructions to make Bubur Kacang Ijo:</h3>

<ol>
	
		<li>
			Rebus kacang hijau dan beras bersama jahe sampai empuk dalam air yg cukup banyak, setelah empuk masukan gula merahnya. Rebus kembali sampai larut gulanya dan kentalnya pas sesuai selera..
			
			
		</li>
	
		<li>
			Tambahkan sedikit garam dan gula pasir, cicipi rasanya, angkat dan sajikan hangat dengan kuah santan..
			
			
		</li>
	
		<li>
			Kuah santan, cairkan santan kara bersama garam, daun pandan dalam secukupnya air. Aduk2 jangan sampai santannya pecah, angkat dan sajikan bersama burjonya..
			
			
		</li>
	
		<li>
			Selamat menikmati yah bun ^_^.
			
			
		</li>
	
		<li>
			Untuk membuat burjo lebih rendah kalori, ganti 1/2 dari takaran gula merah dengan gula tropicana slim, dan tukar santan karanya dengan bubuk max creamer yang di cairkan dengan air dan ditambah garam dan daun pandan. Hati2 dengan porsinya yah bun, agar kalorinya tetap rendah..
			
			
		</li>
	
</ol>

<p>
	
		Cara Membuat Bubur Kacang Hijau Sederhana Yang Enak amp Kental Ala Dapur Dina.
	
		Ingin mencoba memasak Bubur Kacang Hijau sendiri, Burjo Pisang (Tips spy kacang ijo cepat empuk dan lembut), Bubur kacang ijo ketan item durian enakk, Burjo Nangka dan lain-lain yang lezat untuk.
	
		Sajikan bubur kacang hijau beserta rebusan santan saat akan di konsumsi untuk menghindari kacang hijau cepat basi Resep membuat bubur kacang hijau.
	
		Resep Bubur Kacang Ijo Enak Dan Cepat Mekar Atau Empuk.
	
		Kacang hijau / ijo merupakan salah satu bahan makanan yang bukan saja enak di buat minuman maupun makanan.
	
</p>

<p>
	So that is going to wrap it up for this exceptional food bubur kacang ijo recipe. Thanks so much for reading. I'm sure you will make this at home. There is gonna be interesting food in home recipes coming up. Don't forget to bookmark this page in your browser, and share it to your family, colleague and friends. Thank you for reading. Go on get cooking!
</p>
